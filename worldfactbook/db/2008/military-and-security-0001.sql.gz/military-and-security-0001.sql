SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('327002ba162a67729a7efcb3eba49480b29588039550cb8a7fc15285e3091f5f',2008,'TM','Turkmenistan','military-and-security',88,'Military branches
Military service age and obligation
Manpower available for military service
males age 2 5 — 49
females age 15-49
Manpower fit for military service
males age 15-49
females age 15-49
Manpower reaching military age annually
males
females
Military expenditures— percent of GDP
Military— note
Military expenditures— percent of
GDP: 5.3% (2005 est.)
Military— note: in the early 1990s, the
Turkish Land Force was a large but badly
equipped infantry force; there were 14
infantry divisions, but only one was
mechanized, and out of 16 infantry
brigades, only six were mechanized; a
subsequent overhaul has produced highly
mobile forces with greatly enhanced fire¬
power in accordance with NATO’s new
strategic concept (2005)
Military branches: Ground Forces,
Artillery and Rocket Forces, Navy, Air
and Air Defense Forces (2006)
Military service age and obligation: 18
years of age for compulsory military
service; conscript service obligation — 2
years (2004)
Manpower available for military service:
males age 18-49: 1,132,833
females age 2 8 — 49 : 1,162,569 (2005 est.)
Manpower fit for military service:
males age 18-49: 759,978
females age 18-49: 940,179 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 56,532
females age 18-49: 55,413 (2005 est.)
Military expenditures— percent of
GDP: 3.4% (2005 est.)','7fa674390b518b27fe28efffe552dc56a402003c582e7965a250670ec094af8a','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ff2faba2c6bfb8d573dffe925a0fd0ee3ff3388f4b9dcd70b3ead04e09ba7e0',2008,'AF','Afghanistan','military-and-security',96,'Military branches: Afghan National
Army (includes Afghan Air Force) (2006)
Military service age and obligation: 22
years of age; inductees are contracted
into service for a 4-year term (2005)
Manpower available for military service:
males age 22-49: 4,952,812
females age 22—49: 4,663,963 (2005 est.)
Manpower fit for military service:
males age 22—49: 2,662,946
females age 22-49: 2,508,574 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 275,362
females age 22-49: 259,935 (2005 est.)
Military expenditures— percent of
GDP: 1.9% (2006 est.)','aa95d7586b787dd7625314740d93536e165266947898b4186a58ee0b51a41140','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('098bbe1e04c7b304ad40f4c0ec282ee1df638328b07472152b52fcff258955ac',2008,'DZ','Algeria','military-and-security',104,'Military branches: General Staff
Headquarters, Land Forces Command
(Army), Naval Forces Command, Air
Defense Command, Logistics Command,
Training and Doctrine Command (2007)
Military service age and obligation: 19
years of age (2004)
Manpower available for military service:
males age 19-49: 809,524
females age 19-49: 784,199 (2005 est.)
Manpower fit for military service:
males age 19-49: 668,526
females age 19-49: 648,334 (2005 est.)
Manpower reaching military service
age annually:
males age 7 8 — 49: 37,407
females age 19-49: 34,587 (2005 est.)
Military expenditures— percent of
GDP: 1.49% (2005 est.)','90e08375ac29970d1c6b43112d424de3e06ac4e0daf171ce0e42790aa2497831','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('115db9fcc2d39166a8aa048b6399c81c67601174513be8a2bab6d6245b740038',2008,'AI','Anguilla','military-and-security',136,'Manpower available for military
service: males age 18^9: 3,614 (2005
est.)
21
THE CIA WORLD FACTBOOK
Manpower fit for military service: males
age 18-49: 2,986 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 120
(2005 est.)
Military — note: defense is the response
bility of the UK','326861ddd92bcc9db9df4801dcfb1b7337f40f20c0e87e07a7a27082d3b6e94f','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc52083cbce1010fc66d89e060a68d9f129b9bf74980093a5ef8ae2f7182bdb1',2008,'AG','Antigua and Barbuda','military-and-security',146,'Military — note: the Antarctic Treaty
prohibits any measures of a military
nature, such as the establishment of mil¬
itary bases and fortifications, the carrying
out of military maneuvers, or the testing
of any type of weapon; it permits the use
of military personnel or equipment for
scientific research or for any other
peaceful purposes','8cc9796aa79c674a588a43f847bb0d749444489d10797a988257e3c9b0eccabe','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b85395fb5b9f3b4c269cdcc0d8cd0b1921ded7ff6cc1e11faa50490dc4f9c62d',2008,'AR','Argentina','military-and-security',161,'Military branches: Argentine Army,
Navy of the Argentine Republic
(Armada Republica; includes naval avia¬
tion and naval infantry), Argentine Air
Force (Fuerza Aerea Argentina, FAA)
(2007)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2001)
Manpower available for military service:
males age 18-49: 8,981,886
females age 18-49: 8,883,756 (2005 est.)
Manpower fit for military service:
males age 18—49: 7,316,038
females age 18-49: 7,442,589 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 344,575
females age 18-49: 334,649 (2005 est.)
Military expenditures— percent of
GDP: 1.3% (2005 est.)
Military — note: the Argentine military
is a well-organized force constrained by
the country’s prolonged economic hard¬
ship; the country has recently experi¬
enced a strong recovery, and the military
is now implementing “Plan 2000,” aimed
at making the ground forces lighter and
more responsive (2005)','75c914926193355c8cb570b52345e4674cf8162e039e25794d20801b4d401fb9','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db22e2142d33c1a5876144c1fcaef3656c7bfebdf57cccae4fa429e66c6002e5',2008,'AW','Aruba','military-and-security',174,'Military branches: no regular indige¬
nous military forces; Royal Netherlands
Navy and Marines, Coast Guard
Manpower available for military
service: males age 18-49: 16,278 (2005
est.)
Manpower fit for military service: males
age 18-49: 13,219 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 520
(2005 est.)
Military — note: defense is the responsi¬
bility of the Kingdom of the Netherlands
Military— note: defense is the responsi¬
bility of Australia; periodic visits by the
Royal Australian Navy and Royal
Australian Air Force','b93184ce82c7161e362a987e2413763963577bbe5091a636a34fab041a6bbffa','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26b87c777090f3ce9d66c7644e0607210d95ec26e89ba2de60da61d90e0efb55',2008,'AZ','Azerbaijan','military-and-security',190,'Military branches: Land Forces
(KdoLdSK), Air Forces (KdoLuSK)
Military service age and obligation: 18
years of age for compulsory military
service; 16 years of age for voluntary
service; from 2007, at the earliest, com¬
pulsory military service obligation will be
reduced from 8 months to 6 (2005)
Manpower available for military service:
males age 18-49: 1,914,800
females age 18-49: 1,870,134 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,550,441
females age 18-49: 1,515,365 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 48,967
females age 18-49: 46,633 (2005 est.)
Military expenditures— percent of
GDP: 0.9% (2005 est.)
Military branches: Army, Navy, Air and
Air Defense Forces
Military service age and obligation:
men between 18 and 35 are liable for
military service; 18 years of age for vol¬
untary military service; length of military
service is 18 months and 12 months for
university graduates (2006)
Manpower available for military service:
males age 18-49: 1,961,973
females age 18-49: 2,033,186 (2005 est.)
Manpower fit for military service:
males age 1 8 — 49; 1,314,955
females age 18-49: 1,676,408 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 82,358
females age 18-49: 78,067 (2005 est.)
Military expenditures— percent of
GDP: 2.6% (2005 est.)','5210c4e5ffe710cd3ba50f3823c10a74e0d06400a8938fe8ce3e3e823d37781a','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f5d8bf7421cf2684d56cb865144e7973e47a629b3671cc160e4b372bca1c87c',2008,'BH','Bahrain','military-and-security',202,'Military branches: Bahrain Defense
Forces (BDF): Ground Force (includes
Air Defense), Naval Force, Air Force,
National Guard
Military service age and obligation: 18
years of age for voluntary military service
(2001)
53
THE CIA WORLD FACTBOOK
Manpower available for military service:
males age 18-49: 202,126
females age 2 8 — 49 : 151,734 (2005 est.)
Manpower fit for military service:
males age 18-4 9: 161,372
females age 18-49: 125,488 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 6,013
females age 18-49: 5,852 (2005 est.)
Military expenditures— percent of
GDP: 4.5% (2006)','8d0d350fceabf3b30dac9714b5ec4ea963b9ab8fef7e3a6441a4c6f23aca78c7','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc66e6d1e9c1651045dd1407867ada4392549c5ded3741f509be855cdf62f54a',2008,'BY','Belarus','military-and-security',217,'Military branches: Royal Barbados
Defense Force: Troops Command,
Barbados Coast Guard (2007)
Military service age and obligation: 18
years of age for voluntary military
service; volunteers at earlier age with
parental consent; no conscription (2001 )
Manpower available for military service:
males age 18-49: 71,524
females age 18-49: 72,302 (2005 est.)
Manpower fit for military service:
males age 18-49: 54,510
females age 18-49: 54,889 (2005 est.)
Military expenditures— percent of
GDP: 0.5% (2006 est.)
Military — note: the Royal Barbados
Defense Force includes a land-based
Troop Command and a small Coast
Guard; the primary role of the land ele¬
ment is to defend the island against
external aggression; the Command con¬
sists of a single, part-time battalion with
a small regular cadre that is deployed
throughout the island; it increasingly
supports the police in patrolling the
coastline to prevent smuggling and other
illicit activities (2005)
Military branches: Belarus Armed
Forces: Land Force, Air and Air Defense
Force (2006)
Military service age and obligation:
18-27 years of age for compulsory mili¬
tary service; conscript service obliga¬
tion — 18 months (2005)
Manpower available for military service:
males age 18-49: 2,520,644
females age 18-49: 2,564,696 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,657,984
females age 18-4 9: 2,102,793 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 85,202
females age 18-49: 82,037 (2005 est.)
Military expenditures — percent of
GDP: 1.4% (2005 est.)','7b3cd49baa8069fb67c3038723a84af432b0e279902f2cda39092541628a0a96','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a40a854c5fee64cead479c6be65e071d51ce71b27178caedadfbb928afd5ad7',2008,'BE','Belgium','military-and-security',230,'Military branches: Belgian Armed
Forces: Land, Naval, and Air Operations
Commands (2005)
Military service age and obligation: 16
years of age for voluntary military
service; women comprise approx. 7% of
the Belgian armed forces (2001)
Manpower available for military service:
males age 16-49: 2,436,736
females age 16—49: 2,369,463 (2005 est.)
Manpower fit for military service:
males age 16—49: 1,998,003
females age 16—49: 1,940,918 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 64,263
females age 16-49: 61,402 (2005 est.)
Military expenditures— percent of
GDP: 1.3% (2005 est.)','e5477dec8379f04a6cfcbf4b6340cc46d1294210305b12605543a79ea9434a50','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('347904495ae4eb7b1329fc6b64991d99ea79438f9b78b0db0be5e7eaf9b78ccd',2008,'BZ','Belize','military-and-security',241,'Military branches: Belize Defense Force
(BDF): Army, Maritime Wing, Air
Wing, and Volunteer Guard
Military service age and obligation: 18
years of age for voluntary military
service; laws allow for conscription only
if volunteers are insufficient; conscrip¬
tion has never been implemented; vol¬
unteers typically outnumber available
positions by 3:1 (2001)
Manpower available for military service:
males age 18-49: 61,201
females age i S — 49: 60,048 (2005 est.)
Manpower fit for military service:
males age 18-49: 44,238
females age 18-49: 43,633 (2005 est.)
Manpower reaching military service
age annually:
males age 18-4 9: 3,213
females age 18-49: 3,100 (2005 est.)
Military expenditures— percent of
GDP: 1.4% (2006)','39fd46c6cf5c448b1230de0d11049122ac7cce83c697295368ce7c99adc8cf67','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('911fc53f0517a1646d460ee9ced1b35542d657f8571eb430fb6ce01748662bd3',2008,'BM','Bermuda','military-and-security',249,'Military branches: Army, Navy, Air Force
Military service age and obligation: 21
years of age for compulsory and voluntary
military service; in practice, volunteers
may be taken at the age of 18; both sexes
are eligible for military service; conscript
tour of duty — 18 months (2006)
Manpower available for military service:
males age 21-49: 1,295,230
females age 21-49: 1,301,936 (2005 est.)
Manpower fit for military service:
males age 21-49: 749,774
females age 21-49: 751,329 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 76,661
females: 75,068 (2005 est.)
Military expenditures— percent of
GDP: 1.7% (2006)
Military branches: no regular military
forces
Manpower available for military
service: males age 18-49: 15,151 (2005
est.)
Manpower fit for military service: males
age 18—49: 12,165 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 408
(2005 est.)
Military expenditures— percent of
GDP: 0.11% (2005 est.)
Military — note: defense is the responsi¬
bility of the UK','a062a28dadcd503a5b5a1a4ccb98c42104f584f76c832ee0b02f11dfdbd796a1','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9df60781315a516db7d4c058be9cb0ed34b65c50f1f07108f7130748d4b1b55',2008,'BT','Bhutan','military-and-security',260,'Military branches: Royal Bhutan Army:
Royal Bodyguard, Royal Bhutan Police
(2005)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2001)
Manpower available for military service:
males age 18-49: 483,860
females age 18-49: 453,683 (2005 est.)
Manpower fit for military service:
males age 18-49: 314,975
females age 18-49: 296,833 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 23,939
females age 18-49: 21,979 (2005 est.)
Military expenditures— percent of
GDP: 1% (2005 est.)','7413c6520a6d1fe2d87ed2a2eef5c274ef6746a64b747d7fd55eb33f9ed11051','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5aef54c7bf5811d7314b65fe7eb5d6c5f16198de7518f2eafec5983708c1c67',2008,'BA','Bosnia and Herzegovina','military-and-security',267,'Military branches: Bolivian Armed
Forces: Bolivian Army (Ejercito Bolivi¬
ano), Bolivian Navy (Armada Boliviana;
includes marines), Bolivian Air Force
(Fuerza Aerea Boliviana, FAB) (2007)
Military service age and obligation: 18
years of age for voluntary military
service; when annual number of volun¬
teers falls short of goal, compulsory
recruitment is effected, including con¬
scription of boys as young as 14; one esti¬
mate holds that 40% of the armed forces
are under the age of 18, with 50% of
those under the age of 16; conscript tour
of duty — 12 months (2002)
Manpower available for military service:
males age 18-49: 1,923,234
females age 18-49: 2,007,315 (2005 est.)
Manpower fit for military service:
males age 1 8 — 49 : 1,311,414
females age 18-4 9: 1,502,177 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 101,101
females age 18-M9: 98,671 (2005 est.)
Military expenditures— percent of
GDP: 1.9% (2006)
Military branches: VF Army (the air
and air defense forces are subordinate
commands within the Army), VRS
Army (the air and air defense forces are
subordinate commands within the
Army)
Military service age and obligation: 18
years of age for compulsory military
service in the Federation of Bosnia and
Herzegovina; 16 years of age in times of
war; 18 years of age for Republika Srpska;
17 years of age for voluntary military
service in the Federation and in the
Republika Srpska; by law, military obli-
gations cover all healthy men between
the ages of 18 and 60, and all women
between the ages of 18 and 55; service
obligation is 4 months (July 2004)
Manpower available for military service:
males age 18-49: 1,119,508
females age 18-49: 1,079,435 (2005 est.)
Manpower fit for military service:
males age 18-49: 910,539
females age 18-49: 881,446 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 32,942
females age 18-49: 31,466 (2005 est.)
Military expenditures— percent of
GDP: 4.5% (2005 est.)','5589941d9100121d1a2d246fb4f4fd42964a441e02b8d22e8161c28f115d9630','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f446711a62998e2e9ebbdf5df774efaa45f372780bca437bfb1ca07bc9786451',2008,'BW','Botswana','military-and-security',282,'Military branches: Botswana Defense
Force (includes an air wing) (2006)
Military service age and obligation: 18
is the apparent age of voluntary military
service; the official qualifications for
determining minimum age are unknown
(2001)
Manpower available for military service:
males age 18-49: 350,649
females age 1 8 — 49: 361,642 (2005 est.)
Manpower fit for military service:
males age 18-49: 136,322
females age 18^49: 136,315 (2005 est.)
Manpower reaching military service
age annually:
males age 1 8-49 : 21,103
females age 2 8 — 49: 21,379 (2005 est.)
Military expenditures — percent of
GDP: 3.3% (2006)
85
THE CIA WORLD FACTBOOK','1d3cf6e1a3ea3b3d26b46b5fa5c43503098694c4b5f0d6c19fba73cfa5af4c70','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cecaa4de464f576a5241bf03f8c9f26e14b9c78d1a816257c9a123b711a69b5d',2008,'BR','Brazil','military-and-security',295,'. v • . .■ m ‘
Military branches: Brazilian Army,
Brazilian Navy (Marinha do Brasil (MB),
includes Naval Air and Marine Corps
(Corpo de Fuzileiros Navais)), Brazilian
Air Force (Forca Aerea Brasileira, FAB)
(2007)
Military service age and obligation:
21-45 years of age for compulsory mili-
tary service; conscript service obliga-
tion — 9 to 12 months; 17-45 years of age
for voluntary service; an increasing per-
centage of the ranks are “long-service”
volunteer professionals; women were
allowed to serve in the armed forces
beginning in early 1980s when the
Brazilian Army became the first army in
South America to accept women into
career ranks; women serve in Navy and
Air Force only in Women’s Reserve
Corps (2001)
Manpower available for military service:
males age 19-49: 45,586,036
females age 19-49: 45,728,704 (2005
est.)
Manpower fit for military service:
males age 19-49: 33,119,098
females age 19-49: 38,079,722 (2005
est.)
Manpower reaching military service
age annually:
males age 18-49: 1,785,930
females age 19-49: 1,731,648 (2005 est.)
Military expenditures — percent of
GDP: 2.6% (2006 est.)','6dea2b1062622b508ab48de35b632ede84c95682d538c5bb1ff0f1cf41ed178e','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9c2e1835ce899ffdbcb08d4e0b5142beb45b4bd13746b48c79d2135a820ef80',2008,'IO','British Indian Ocean Territory','military-and-security',303,'Military — note: defense is the responsi¬
bility of the UK; the US lease on Diego
Garcia expires in 2016
Manpower available for military
service: males age i 8 — 49: 6,410 (2005 est.)
Manpower fit for military service: males
age 18-49: 5,295 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 201
(2005 est.)
Military— note: defense is the responsi¬
bility of the UK','b93863e59fa5fc3db94c2164bfd32fdff8886a441922fcb0ddbbbca0a4ace1a0','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a8de5e2c7bdbcb4447a707930c979e1e8198696b9597b25cfd944b41bcca192',2008,'ID','Indonesia','military-and-security',311,'Military branches: Royal Brunei Armed
Forces (RBAF): Royal Brunei hand
Forces, Royal Brunei Navy, Royal Brunei
Air Force (Tentera Udara Diraja Brunei)
(2005)
Military service age and obligation: 18
years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 103,885
95
THE CIA WORLD FACTBOOK
females age 18-49: 93,024 (2005 est.)
Manpower fit for military service:
males age 18-49: 85,045
females age 18-49: 77,436 (2005 est.)
Manpower reaching military service
age annually:
males age 18-4 9: 3,478
females age 18-49: 3,342 (2005 est.)
Military expenditures— percent of
GDP: 4.5% (2006)','d7d5942cc5ddf0f4e916a37f591e4dc0733ddb45ce7398b3b30c9f80d694b606','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72ebce75ebb88ce3997ced451d61717b8620373a5dd2af817e84d633c920976f',2008,'BF','Burkina Faso','military-and-security',321,'Military branches: Bulgarian Armed
Forces: Ground Forces, Naval Forces,
Bulgarian Air Forces (Bulgarski
Voennovazdyshni Sily, BVVS) (2006)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; service in the Army is
mandatory for all men under the age of
27; conscript service Qbligation — 9
months; as of May 2006, 67% of the
Bulgarian Army comprised of profes-
sional soldiers; conscription into the
Army to end as of 1 January 2008; Air
and Air Defense Forces and Naval Forces
became fully professional at the end of
2006; Bulgarian Armed Forces encoun-
tered difficulties meeting conscript
quotas in April 2007 (2007)
Manpower available for military service:
males age 18-49: 1,661,211
females age 18-49: 1,660,982 (2005 est.)
Manpower fit for military service:
males age 18—49: 1,302,037
females age 18-49: 1,365,126 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 51,023
females age 18—49: 48,651 (2005 est.)
Military expenditures— percent of
GDP: 2.6% (2005 est.)','e1bed8ad54fc96583874cd2dde0cd3666ac015c02b59ca5bdaf174a19f38b809','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03cac29b1a04b3c8cc014f25749956c149a94f714376abf03904ec4f07a6eb04',2008,'ET','Ethiopia','military-and-security',330,'Military branches: Army, Air Force of
Burkina Faso (Force Aerienne de
Burkina Faso, FABF), National
Gendarmerie (2006)
Military service age and obligation: 18
years of age for compulsory military
service; 20 years of age for voluntary mil¬
itary service (2001 )
Manpower available for military service:
males age 18-49: 2,651,687 (2005 est.)
Manpower fit for military service: males
age 18-49: 1,530,324 (2005 est.)
Military expenditures — percent of
GDP: 1.2% (2006)
101
THE CIA WORLD FACTBOOK
Military branches: Estonian Defense
Forces: Land Force, Navy, Air Force,
Volunteer Defense League (Kaitseliit,
KL) (2006)
Military service age and obligation:
compulsory military service for men
between 19 and 28; conscription lasts 11
months for junior NCOs and reserve pla¬
toon leaders; reserve officers and desig¬
nated specialists have a different
conscript service obligation; Estonia has
committed to retaining conscription for
men up to 2010 and, unlike Latvia and
Lithuania, has no plan to transition to a
contract armed forces; 1 7 years of age for
volunteers; reserve commitment up to
the age of 60 (2006)
Manpower available for military service:
males age 18-49: 291,696
females age 18-49: 304,961 (2005 est.)
Manpower fit for military service:
males age 18-49: 200,382 (in 2004, 51%
of the young men called up for service
were determined to be unfit; main obsta¬
cles to conscription were psychiatric and
behavioral)
females age 18-49: 250,351 (2005 est.)
Manpower reaching military service
age annually:
males age 15-49: 11,146
females age 18-49: 10,605 (2005 est.)
Military expenditures— percent of
GDP: 2% (2005 est.)
Military branches: Ethiopian National
Defense Force (ENDF): Ground Forces,
Ethiopian Air Force
note: Ethiopia is landlocked and has no
navy; following the secession of Eritrea,
Ethiopian naval facilities remained in
Eritrean possession
Military service age and obligation: 18
years of age for compulsory and voluntary
military service (2001)
Manpower available for military service:
males age 18-49: 14,568,277
females age 18-49: 14,482,885 (2005 est.)
Manpower fit for military service:
males age 18-49: 8,072,755
females age 18-49: 7,902,660 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 803,777
females age 18-49: 801,789 (2005 est.)
Military expenditures— percent of
GDP: 3% (2006)
Military branches: no regular military
forces
Military expenditures— percent of
GDP: NA
Military — note: defense is the responsi¬
bility of the UK','e896b58a6ab5a0cd4f342cba2d916ef9959fcae5cff157463a2a6cc637a05db4','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1b9b5f02aec328ce5d82edeab488edf92c252ff8eea55ba370a06cbe494108d',2008,'BI','Burundi','military-and-security',336,'Military branches: Myanmar Armed
Forces (Tatmadaw): Army, Navy, Air
Force (2005)
Military service age and obligation: 18
years of age for voluntary military service
for both sexes (2004)
Manpower available for military service:
males age 1 8 — 49: 12,268,850
females age 18-49: 12,469,771 (2005
est.)
Manpower fit for military service:
males age 18-49: 7,946,701
females age 18-49: 8,543,705 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 469,841
females: 455,689 (2005 est.)
Military expenditures— percent of
GDP: 2.1% (2005 est.)
Military branches: National Defense
Force (Forces de Defense Nationales,
FDN): Army (includes Naval Detach¬
ment and Air Wing) (2006)
Military service age and obligation: 16
years of age for compulsory and voluntary
military service (2001)
Manpower available for military service:
males age 16-49: 1,676,855
females age 16-49: 1,656,366 (2005 est.)
Manpower fit for military service:
males age 16-49: 955,616
females age 16—49: 932,767 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 91,331
females age 16-49: 90,685 (2005 est.)
Military expenditures— percent of
GDP: 5.9% (2006 est.)','74916d649006fefd09a8bb607578c6137ddafa4fc4a657692d5ebe9548050a08','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('156b9235106faa5d35f4fb6ab1916dc74af9a5e749b689858b87b466e551153c',2008,'KH','Cambodia','military-and-security',351,'Military branches: Royal Cambodian
Armed Forces: Royal Cambodian Army,
Royal Khmer Navy, Royal Cambodian
Air Force (2005)
Military service age and obligation:
conscription law made effective in
October 2006 requires all males between
18-30 to register for military service;
service obligation is 18 months (2006)
Manpower available for military service:
males age 18-49: 3,002,718
females age 18-49: 3,108,254 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,955,141
females age 18-49: 2,048,611 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 175,497
females age 18-A9: 172,788 (2005 est.)
Military expenditures — percent of
GDP: 3% (2005 est.)','c61b57ef1ae82b9666ca3e8b68547a1a28b8681348ac313e35d53af6e0cf4a87','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('555f703693672c87f3b54775fa9fbde3146f1f9e8cd7b1523375b42aaeeb9001',2008,'CA','Canada','military-and-security',362,'Military branches: Cameroon Armed
Forces: Army, Navy (includes naval
infantry), Air Force (Armee de l’Air du
Cameroun, AAC) (2006)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (1999)
Manpower available for military service:
males age 18-49: 3,525,307
females age 18-49: 3,461,406 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,946,767
females age 18-49: 1,834,600 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 191,619
females age 18-49: 187,082 (2005 est.)
Military expenditures— percent of
GDP: 1.3% (2006)
Military branches: Canadian Forces:
Land Forces Command, Maritime
Command, Air Command, Canada
Command (homeland security) (2006)
Military service age and obligation: 16
years of age for voluntary military
service; women comprise approximately
11% of Canada’s armed forces (2001)
Manpower available for military service:
males age 16-49: 8,216,510
females age J6-49: 8,034,939 (2005 est.)
Manpower fit for military service:
males age 16-49: 6,740,490
females age 16-4 9: 6,580,868 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 223,821
females age 16-49: 212,900 (2005 est.)
Military expenditures— percent of
GDP: 1.1% (2005 est.)','ddb4c76f2978007d324049a6605777c7c3545e9e13bf6c2333fe82bd6e53ba01','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e44b34acd3a5645286c74ab045690be465f17012479799b6f7a401fbf967b3c9',2008,'KY','Cayman Islands','military-and-security',371,'Military branches: People’s Revolu¬
tionary Armed Forces (FARP): Army,
Coast Guard (includes maritime air
wing) (2007)
Manpower available for military service:
males age 18-49: 84,641
females age 18^9: 87,310 (2005 est.)
Manpower fit for military service:
males age i 8 — 49 : 65,614
females age 18-49: 73,662 (2005 est.)
Military expenditures— percent of
GDP: 0.7% (2005)','e99e6d1c3de8d97b49b4063fd13e38294a1cd9e0329978f84fcc0c09d0810883','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ecd02624045ebc59033c5a0cb0572a77b83d9c43afc0e1ecd31d7831745dd0d',2008,'CF','Central African Republic','military-and-security',379,'Military branches: no regular military
forces; Royal Cayman Islands Police
Force
Manpower available for military
service: males age 18-49: 10,703 (2005
est.)
Manpower fit for military service: males
age 18-49: 8,600 (2005 est.)
Manpower reaching military service
age annually: males age 18-4 9: 257
(2005 est.)
Military — note: defense is the responsi¬
bility of the UK
Military branches: Central African
Armed Forces (FACA): Ground Forces,
Military Air Service; General
Directorate of Gendarmerie Inspection
(DGIG), Republican Guard, National
Police (2006)
Military service age and obligation: 18
years of age for voluntary and compulsory
military service; conscript service obliga¬
tion is 2 years (2005)
Manpower available for military service:
males age 18-49: 853,760
females age 18-49: 835,426 (2005 est.)
Manpower fit for military service:
males age 18-49: 416,091
females age 18-49: 383,056 (2005 est.)
Military expenditures— percent of
GDP: 1.1% (2006 est.)','8fcf85bf40a129cfbecde7f5bd7eba1f4a258c727d5a2c606f4b014f7a4ebce2','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4db9ed13bebe3bc93702fdbbe65d2e4414725e286df56642e330edbdff9b2b60',2008,'TD','Chad','military-and-security',396,'Military branches: Chadian National
Army (Armee Nationale Tchadienne,
ANT), Chadian Air Force (Force
Aerienne Tchadienne, FAT), Gendar¬
merie (2007)
Military service age and obligation: 20
years of age for conscripts, with 3 -year
service obligation; 18 years of age for vol¬
unteers; no minimum age restriction for
volunteers with consent from a guardian;
women are subject to 1 year of compul¬
sory military or civic service at age of 21
(2004)
Manpower available for military service:
males age 20-49: 1,527,58 0
females age 20-49: 1,629,510 (2005 est.)
Manpower fit for military service:
males age 20-49: 794,988
females age 20-49: 849,500 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 94,536
females age 20-4 9: 93,521 (2005 est.)
Military expenditures— percent of
GDP: 4.2% (2006)','32081cad21c37698ea99f3863b349508879b5103104aad34ba87212fd3346c4a','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aef56fdac52b2c2ab5e71d6e72ae35affaa0075a0055731b29c625cf4925a93b',2008,'CL','Chile','military-and-security',405,'Military branches: Army of the Nation,
Chilean Navy (Armada de Chile,
includes naval air, marine corps, and
Maritime Territory and Merchant
Marine Directorate (Directemar)),
Chilean Air Force (Fuerza Aerea de
Chile, FACh), Chilean Carabineros
(National Police) (2007)
Military service age and obligation: all
male citizens 18-45 are obligated to per¬
form military service; conscript service
obligation — 12 months for Army, 24
months for Navy and Air Force (2004)
Manpower available for military service:
males age 18-49: 3,815,761
females age 18-49: 3,780,864 (2005 est.)
Manpower fit for military service:
males age 18-49: 3,123,281
females age 18-49: 3,128,277 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 140,084
females age 18—49: 134,518 (2005 est.)
Military expenditures— percent of
GDP: 2.7% (2006)','ed989aa9e404ca545589581addaa0911415b72ca743f79364fbab94e2c12ec99','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6f6ba107db6c241083097b37e2bc1038c3bafc9c56aaa39b3bf87e7be9d2d3f',2008,'CN','China','military-and-security',414,'Military branches: People’s Liberation
Army (PLA): Ground Forces, Navy
(includes marines and naval aviation),
Air Force (includes airborne forces), and
Second Artillery Corps (strategic missile
force); People’s Armed Police (PAP);
Reserve and Militia Forces (2006)
Military service age and obligation:
18-22 years of age for compulsory mili¬
tary service, with 24-month service obli¬
gation; no minimum age for voluntary
service (all officers are volunteers);
18-19 years of age for women high
school graduates who meet requirements
for specific military jobs (2007)
Manpower available for military service:
males age 18-49: 342,956,265
females age 18—4 9: 324,701,244 (2005
est.)
Manpower fit for military service:
males age 18-49: 281,240,272
females age 18-49: 269,025,517 (2005
est.)
Manpower reaching military service
age annually:
males age 18—49: 13,186,433
females age 18-49: 12,298,149 (2005
est.)
Military expenditures— percent of
GDP: 3.8% (2006)','d4d0a2de9495025e32b1f067f015d367e7d684f503c5468bcf49b2645481f64f','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04530e0380ae17138196b6a4b88b37bd917a5b6beaa84a9c14f7ec952ecca3cd',2008,'CX','Christmas Island','military-and-security',423,'Military — note: defense is the responsi¬
bility of Australia
Military — note: defense is the responsi¬
bility of France','19c5a847b0932186cd50e231f0225eed70d3d09105a2b2ccad5b007176c0535a','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b32b888f594b05640e92027d7ddbf3e2ba997559f7e142fa9aa15e762a52af3b',2008,'CC','Cocos (Keeling) Islands','military-and-security',432,'Military — note: defense is the responsi¬
bility of Australia; the territory has a
five-person police force','1791c791dd5d8abd0c0f42a4e1ab420462b476f0cff91102d94b9ec089b6351b','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52d3e36f6ce0e76cbacaef37acbaea5b3dc48bc09a9cefab01d5634fe80d237f',2008,'KM','Comoros','military-and-security',452,'Military branches: Comoran Defense
Force: Comoran Security Force (includes
Gendarmerie and Army), Comoran
Federal Police (2006)
Manpower available for military service:
males age 18-4 9: 138,940
females age 18-49: 139,491 (2005 est.)
Manpower fit for military service:
males age 18-49: 98,792
females age 18-49: 106,415 (2005 est.)
Military expenditures— percent of
GDP: 2.8% (2006)','d766ddd755a436e0e6595aa13b771606453db93140bb01be5a70d1c8badfd27c','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cb74ee7f0f0b84d232d871c55eff096371d5095d3355f8d137bf5665ffb9f93',2008,'AO','Angola','military-and-security',456,'Military branches: Armed Forces of the
Democratic Republic of the Congo
(FARDC): Army, Navy, Congolese Air
Force (Force Aerienne Congolaise,
FAC) (2006)
Military service age and obligation:
18-45 years of age for military service
Manpower available for military
service: males age 18-49: 11,365,610
(2005 est.)
Manpower fit for military service: males
age 18-49: 6,464,223 (2005 est.)
Military expenditures— percent of
GDP: 2.5% (2006)','3728b0bf0fc85c28e376701bd4575e67019cbdd8993998b2c0000059eb4b9ac6','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5211b7945809184d57bed80c97c8602d536644f3f2a6d36da0e92469e635902f',2008,'CK','Cook Islands','military-and-security',461,'Military branches: Congolese Armed
Forces (FAC): Army, Navy, Congolese
Air Force (Armee de I’Air Congolaise),
Gendarmerie, Republican Guard (2007)
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military service:
males age 18-49: 688,628
females age 18-49: 685,388 (2005 est.)
Manpower fit for military service:
males age 18-49: 406,016
females age 18-49: 394,745 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 38,464
females age 1 8 — 49 : 38,082 (2005 est.)
Military expenditures— percent of
GDP: 3.1% (2006)
Military branches: no regular military
forces; Ministry of Police and Disaster
Management (2005)
Military — note: defense is the responsi¬
bility of New Zealand, in consultation
with the Cook Islands and at its request
Military — note: defense is the responsi¬
bility of Australia; visited regularly by
the Royal Australian Navy; Australia has
control over the activities of visitors','d4b693f82e4f91b6bb553eaf272510f44b45f0f91111b567443d5578a1321f78','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aea15450a51c23a3a5fe6d22dc4322eb03e099dac9a0735e9f3e01955d1f5148',2008,'CR','Costa Rica','military-and-security',475,'Military branches: no regular military
forces; Ministry of Public Security,
Government, and Police (2006)
Military service age and obligation: 18
years of age (2004)
Manpower available for military service:
males age 18-49: 997,690
females age 18-^19: 968,290 (2005 est.)
Manpower fit for military service:
males age 18-49: 829,874
females age 18-49: 809,343 (2005 est.)
Manpower reaching military service
age annually:
males age i 8 — 49 ; 41,097
females age 18-49: 39,243
Military expenditures— percent of
GDP: 0.4% (2006)','9afea5ecc07d37bc5922ea1cac19e6e42b5e3b8e628216fd7cef2898d8eadc4c','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eb17af1573541821db2ebe578890da67c045bca7bf6ce2857b423ca7a6d2c1e',2008,'FR','France','military-and-security',479,'Military branches: Cote d’Ivoire
Defense and Security Forces (FDSC):
Army, Navy, Air Force (2006)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 18 months (2004)
Manpower available for military service:
males age 18—49: 3,696,106
females age 18-49: 3,569,967 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,973,265
females age 18—49: 1,911,777 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 189,354
females age i 8 — 49 : 192,600 (2005 est.)
Military expenditures — percent of
GDP: 1.6% (2005 est)','a087f4144932da2c5f1db59f5cc3af72d3d3725d323a23e01d889ef3a8e50e32','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c35283af65fd9f060d1b89fcced37edae71d2ef1c25e1ed7662ed5f0f09a303',2008,'HR','Croatia','military-and-security',488,'Military branches: Ground Forces
(Hrvatska Kopnena Vojska, HKoV),
Naval Forces (Hrvatska Ratna
Mornarica, HRM), Air and Air Defense
Forces (Hrvatsko Ratno Zrakoplovstvo i
Protuzrakoplovna Obrana, HRZiPZO),
Joint Education and Training Command,
Logistics Command; Military Police
Force supports each of the three
Croatian military forces (2006)
Military service age and obligation: 18
years of age for compulsory military
service, with 6-month service obligation;
16 years of age with consent for volun¬
tary service (December 2004)
Manpower available for military service:
males age 18-49: 1,005,058
females age 18—49: 1,008,511 (2005 est.)
Manpower fit for military service:
males age 18-49: 725,914
females age 18-49: 823,611 (2005 est.)
Manpower reaching military service
age annually:
males age 18—4 9: 29,020
females age 18—49: 27,897 (2005 est.)
Military expenditures— percent of
GDP: 2.39% (2005 est.)','4ce60736a26a7f68c3c0541b86de60caf053a940dc8c6a405b4ac62347b64996','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('303248c878e15ce377fc34304e68ca305aa5c5808ee2b872932b65a6943ee188',2008,'CY','Cyprus','military-and-security',498,'Military branches: Revolutionary
Armed Forces (FAR): Revolutionary
Army (ER), Revolutionary Navy
(Marina de Guerra Revolucionaria,
MGR), Revolutionary Air and Air
Defense Force (DAAFAR), Youth Labor
Army (EJT) (2007)
Military service age and obligation: 17
years of age; both sexes are eligible for
military service (2004)
Manpower available for military service:
males age 17-49: 2,967,865
females age 17-49: 2,913,559 (2005 est.)
Manpower fit for military service:
males age 17-49: 2,441,927
females age 17-49: 2,396,741 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 91,901
females age 18—49: 87,500 (2005 est.)
Military expenditures— percent of
GDP: 3.8% (2006 est.)
Military— note: Moscow, for decades the
key military supporter and supplier of
Cuba, cut off almost all military aid by
1993
Military branches: Republic of Cyprus:
Greek Cypriot National Guard (GCNG;
includes air and naval elements); north
Cyprus: Turkish Cypriot Security Force
(GKK)
Military service age and obligation: 18
years of age (2004)
Manpower available tor military service:
Greek Cypriot National Guard (GCNG):
males age 18-49: 184,352
females age 18—49: 175,567 (2005 est.)
Manpower fit for military service:
Greek Cypriot National Guard (GCNG):
males age 18-49: 150,750
females age 18-49: 144,344 (2005 est.)
Manpower reaching military service
age annually:
Greek Cypriot National Guard (GCNG):
males age 18—49: 6,578
females age 18—49: 6,200 (2005 est.)
Military expenditures — percent of
GDP: 3.8% (2005 est.)','1d2ae464811f103bc4230b646458aa61a4ff5dbcec2d95edc3cce218ed913b85','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09f8d611415a1831610480ec5d319eacd09cf8d70f70f6896d7bc987b7e1c933',2008,'DE','Germany','military-and-security',511,'Military branches: Army of the Czech
Republic (ACR): Joint Forces Command
(includes Army and Air Forces), Support
and Training Forces Command (2007)
Military service age and obligation:
18-50 years of age for voluntary military
service; on-going transformation of mili¬
tary service into a fully professional, all¬
volunteer force no longer dependent on
conscription began in January 2004 and
is scheduled to be completed by 2007
(2005)
Manpower available for military service:
males age 18-49: 2,414,728
females age 18-49: 2,329,412 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,996,631
females age 18^9: 1,923,508 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 66,583
females age 18-49: 63,363 (2005 est.)
Military expenditures— percent of
GDP: 1.81% (2005 est.)
Military branches: Federal Armed
Forces (Bundeswehr): Army (Heer),
Navy (Deutsche Marine, includes naval
air arm), Air Force (Luftwaffe), Joint
Service Support Command (Streit-
kraeftebasis), Central Medical Service
(Zentraler Sanitaetsdienst) (2006)
Military service age and obligation: 18
years of age (conscripts serve a 9-month
tour of compulsory military service)
(2004)
Manpower available for military service:
males age 1 8 — 49: 18,917,537
females age 18-49: 17,913,113 (2005
est.)
Manpower fit for military service:
males age 18-49: 15,258,931
females age 18-49: 14,443,412 (2005
est.)
Manpower reaching military service
age annually:
males age 18-49: 497,048
females age 18-49: 470,537 (2005 est.)
Military expenditures— percent of
GDP: 1.5% (2005 est.)','1b6b1ff206c95564670a000769f1f295773d3dc39d1f403931156b5b24acef7c','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f90a9e063fabdb8aea728b2ebdecff3c9773659d1efa10bf49f430a6dc084a3',2008,'DK','Denmark','military-and-security',522,'Military branches: Defense Command:
Army Operational Command, Admiral
Danish Fleet, Island Command Green¬
land, Tactical Air Command (2006)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscripts serve an ini¬
tial training period that varies from 4 to
12 months according to specialization;
reservists are assigned to mobilization
units following completion of their con¬
script service; women eligible to volun¬
teer for military service (2004)
177
THE CIA
WORLD FACTBOOK
Manpower available for military service:
males age 18-49: 1,175,108
females age 18-49: 1,150,627 (2005 est.)
Manpower fit for military service:
males age 1 8-49 : 955,168
females age 18-49: 935,643 (2005 est.)
Manpower reaching military service
age annually:
males age 1 8-49 : 31,317
females age 18-49: 29,558 (2005 est.)
Military expenditures— percent of
GDP: 1.5% (2005 est.) _','2f5168ff7fcb837d27f11951d0c5f2573c23b6e500ddcf963ffb187bac617afe','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb8d694e0c9b5d5fe7328d865deb13c4fb2cee9d918858e8beee10ddc1f5df2a',2008,'GL','Greenland','military-and-security',527,'Military— note: includes Dhekelia
Garrison and Ayios Nikolaos Station
connected by a roadway','fdb4d8394826384b07a1e0a999ed3c538f5f15a575d70657d5b5d7403255c00f','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24ed921b65c48b3f05cd823e5f05cb84f17727fe24aabbd5aa27ca44d323c5cc',2008,'DM','Dominica','military-and-security',535,'Military branches: Djibouti National
Army (includes Navy and Air Force)
Military service age and obligation: 18
years of age (est.); no conscription
(2001)
Manpower available for military service:
males age 18-49: 95,328
females age 18-49: 87,795 (2005 est.)
Manpower fit for military service:
males age 1 8 — 49: 46,020
females age 18-49: 42,181 (2005 est.)
Military expenditures — percent of
GDP: 3.8% (2006)
Military branches: no regular military
forces; Commonwealth of Dominica
Police Force (includes coast guard)
(2006)
Manpower available for military
Service: males age 18-49: 18,227 (2005
est.)
Manpower fit for military service: males
age 18^49: 15,136 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 602
(2005 est.)
Military expenditures— percent of
GDP: NA (2006)','d181873944497c8e720e529162ecf58230df148e74e46d25cf1176da7f91fbde','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41acaa6ec62d6568ef4f3cb6df85c357af95e097eae009620daa33fc1bb2c96f',2008,'DO','Dominican Republic','military-and-security',549,'Military branches: Army, Navy, Air
Force
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military service:
males age 18-49: 2,133,142
females age 1 8 — 49 : 2,032,840 (2005 est.)
Manpower fit for military service:
males age 18-4 9: 1,671,493
females age 18-49: 1,536,257 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 91,699
females age 18-49: 87,550 (2005 est.)
Military expenditures— percent of
GDP: 0.8% (2006)','f721b8b03ca06d95679e3330c04a0eb54246d8b5cdfbf35c8be7368a42e5c109','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74dd9fc6fb43bff3ea4eab511efbd026fa6e21c899288eeeec6fc1a71b1407b8',2008,'EC','Ecuador','military-and-security',554,'Military branches: East Timor Defense
Force (Forcas de Defesa de Timor-Leste,
FDTL): Army, Navy (Armada) (2005)
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military service:
males age 18-49: 235,198
females age 18-4 9: 223,069 (2005 est.)
Manpower fit for military service:
males age 18-49: 179,422
females age 18^9: 184,533 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 12,740
females age 18-49: 12,438 (2005 est.)
Military expenditures— percent of
GDP: NA
Military branches: Army, Navy
(includes Naval Infantry, Naval
Aviation, Coast Guard), Air Force
(Fuerza Aerea Ecuatoriana, FAE) (2007)
Military service age and obligation: 20
years of age for conscript military service;
12 -month service obligation (2004)
Manpower available for military service:
males age 20-49: 2,792,770
females age 20-49: 2,849,519 (2005 est.)
Manpower fit for military service:
males age 20-49: 2,338,428
females age 20—49: 2,380,327 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 133,922
females age 20—49: 129,758 (2005 est.)
Military expenditures— percent of
GDP: 2.8% (2006)','c84d7784b703d70eae4ac514f9759d01b279bd0298bc0fb4553b9663b3ae655f','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95393e0f506e70a9158e9b05415ef686d3966bace00380a8f879d1c1887a5ed0',2008,'EG','Egypt','military-and-security',565,'Military branches: Army, Navy, Air
Force, Air Defense Command
Military service age and obligation: 18
years of age for conscript military service;
3-year service obligation (2001)
Manpower available for military service:
males age 18-49: 18,347,560
females age 18-49: 17,683,904 (2005
est.)
195
THE CIA WORLD FACTBOOK
Manpower fit for military service:
males age 18-49: 15,540,234
females age 18-49: 14,939,378 (2005
est.)
Manpower reaching military service
age annually:
males age 18—49: 802,920
females age 18-49: 764,176 (2005 est.)
Military expenditures— percent of
GDP: 3.4% (2005 est.)','847a5d695e98c0238bc463a09ed5f84c15d1f52d2902082a4b88987004900b9f','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e760e125810b7814aa704f1569b9b152fb8a3bf6a9b32314fcf8292d56134cae',2008,'SV','El Salvador','military-and-security',573,'Military branches: Salvadoran Army
(ES), Salvadoran Navy (FNES),
Salvadoran Air Force (Fuerza Aerea
Salvadorena, FAS) (2006)
Military service age and obligation: 18
years of age for compulsory military
service, with 12-month service obliga¬
tion; 16 years of age for volunteers
(2002)
Manpower available for military service:
males age 18^9: 1,391,278
females age f 8-49: 1,542,323 (2005 est.)
Manpower fit for military service:
males age 18-49: 960,315
females age 18-49: 1,310,466 (2005 est.)
198','3d2a6e448a6cf650b005f04cfff5bafd9b60b9825050a0e467463bcd49a60581','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e77b173d949127a462790095d160da6a475236fb70714b81a4695bd3c6715e81',2008,'GQ','Equatorial Guinea','military-and-security',574,'Manpower reaching military service
age annually:
males age 18-49: 70,286
females age 18-49: 69,526 (2005 est.)
Military expenditures — percent of
GDP: 5% (2006)','9c85ffe9563e853ddab88afb739abfa9d11538104f87fe68de3434f1a9605926','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c251935aa9860d743d1bef1d90bd3a941a5a9747fe36eb822c431804de3b4e1c',2008,'ER','Eritrea','military-and-security',583,'Military branches: Army, Navy, Air
Force (2005)
Military service age and obligation: 18
years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 104,563
females age 18-49: 109,923 (2005 est.)
Manpower fit for military service:
males age 18-49: 56,462
females age 18-49: 59,260 (2005 est.)
Military expenditures — percent of
GDP: 0.1% (2006 est.)
\\
Military branches: Army, Navy, Air
Force
Military service age and obligation: 18
years of age for voluntary and compulsory
military service; conscript service obliga¬
tion — 16 months (2004)
Manpower available for military service:
males age 18-49: 893,361
females age 18—49: 891,662 (2005 est.)
Manpower fit for military service:
males age 18—49: 555,553
females age 18-49: 562,426 (2005)
Manpower reaching military service
age annually:
males age 18—49: 50,156
females age 18—49: 49,746 (2005 est.)
Military expenditures— percent of
GDP: 6.3% (2006 est.)','76f52f08e3a65f47d5d071b4a383332449c9110d99a7ffeec02cc9734f6f5f83','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('939049cb2c8f8545951728abade93b0099c92b8642ca8157a4ada647eeee68d9',2008,'FJ','Fiji','military-and-security',603,'Military branches: no regular military
forces
Manpower available for military service:
males age 18-49: 10,695 (2005 est.)','7b641c3b7f84c5294ca33548b13ec79ab8e33afee82b5663bf9e7c44fa419770','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae52940645184d6198e6d864f910d190666988afc03027a6e53a828de40e4eca',2008,'FI','Finland','military-and-security',612,'Military branches: Republic of Fiji
Military Forces (RFMF): Land Forces,
Naval Forces (2006)
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military service:
males age 18-49; 215,104
females age 18-49: 212,739 (2005 est.)
Manpower fit for military service:
males age 18—49: 163,960
females age 18-49: 178,714 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 9,266
females age 18-49: 8,916 (2005 est.)
Military expenditures— percent of
GDP: 2.2% (2005 est.)
Military branches: Finnish Defense
Forces: Army, Navy (includes coastal
defense forces), Air Force (2003)
Military service age and obligation: 18
years of age for voluntary and compulsory
military service (October 2004)
Manpower available for military service:
males age 18-49: 1,121,275
females age 18-49: 1,076,684 (2005 est.)
Manpower fit for military service:
males age 18-49: 913,617
females age 18-49: 875,689 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 32,040
females age 18-49: 30,519 (2005 est.)
Military expenditures — percent of
GDP: 2% (2005 est.)','cbb20f09cadec98a65548ef58bacce2ef062232e89a075eca2c893410e73f96a','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('473304d4687668492b1d509cc45ec2b87f6ac2f55ffe08096ad522365ffb89ca',2008,'PF','French Polynesia','military-and-security',621,'Military branches: Army (includes
marines, Foreign Legion, light aviation),
Navy (includes naval air), Air Force (in¬
cludes air defense), National Gendarmerie
Military service age and obligation: 17
years of age for voluntary military
service; conscription ended in the 1990s;
women serve in non-combat military
posts (2001)
Manpower available for military service:
males age 17-49: 13,676,509
females age 17-4 9: 13,504,539 (2005
est.)
Manpower fit for military service:
males age 17-49: 11,262,661
females age 17-49: 11,079,472 (2005
est.)
Manpower reaching military service
age annually:
males age 17—49: 389,204
females age 17—49: 372,719 (2005 est.)
Military expenditures— percent of
GDP: 2.6% (2005 est.)
Military branches: no regular military
forces; Gendarmerie and National Police
Force
Manpower available for military service:
males age 18—49: 69,679 (2005 est.)
Manpower fit for military service: males
age 18—49: 55,305 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 2,747
(2005 est.)
Military — note: defense is the responsi¬
bility of France
Military — note: defense is the responsi¬
bility of France','e4d76d81c857d9b8cb1c2526e7a94ba0196d7b1306acb522bf1e6a70669bd31c','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0902cbbbe93ff8f871e5caeadbb37da0da23ebcc5521e18d39a9d9c9838cd78e',2008,'GA','Gabon','military-and-security',636,'Military branches: Army, Navy, Air Force,
National Gendarmerie, National Police
Military service age and obligation: 20
years of age for compulsory and voluntary
military service (2007)
Manpower available for military service:
males age 18-49: 278,826
females age 18-49: 279,865 (2005 est.)
Manpower fit for military service:
males age 18-49: 159,198
females age 18-49: 156,122 (2005 est.)
Manpower reaching military service
age annually:
males age 18^49: 15,325
females age i 8 — 49; 15,367 (2005 est.)
Military expenditures— percent of
GDP: 3.4% (2005 est.)','5ab80032e32d4fc7415c39528e7942bcd1f9bb7c5618dc308bef3b3e37239a68','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11afddeb54cc6cf6e3bedf6f51addcaadade37abbc4db95a407ce830f42eaf64',2008,'GM','Gambia','military-and-security',641,'Military branches: Gambian National
Army (GNA), Gambian Navy (GN),
Gambian National Guard (includes
Presidential Guard) (2007)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2001)
Manpower available for military service:
males age 18—49: 311,025
females age 18-49: 316,214 (2005 est.)
Manpower fit for military service:
males age 18—4 9: 183,057
females age 18-49: 194,551 (2005 est.)
Military expenditures — percent of
GDP: 0.5% (2006)','e20c2a9ca44a4d7323172a499a205e53416942a35dafadaa01ab26ec0da318e9','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1631d32272863a56f38f7b3155058ebf2ae54cc170b0f02073907392001e5826',2008,'GE','Georgia','military-and-security',651,'Military branches: in accordance with
the peace agreement, the Palestinian
Authority is not permitted conventional
military forces; there are, however,
public security forces (2007)
Manpower available for military service:
males age 18^9: 260,855 (2005 est.)
Manpower fit for military service: males
age 18—49: 221,530 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 15,196
(2005 est.)
Military expenditures— percent of
GDP: NA','7c8e26c0565c030f272976c306c2571927aee34275dd7a3f704567d8079bf0fd','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f936f1ed1fffa129df4c267888f7b5b9f7e565b41f9e14390e2365e6c2b3460',2008,'GI','Gibraltar','military-and-security',665,'Military branches: Ghanaian Army,
Ghanaian Navy, Ghanaian Air Force
(2007)
Military service age and obligation: 18
years of age for compulsory and volunteer
military service (2001)
Manpower available for military service:
males age 18-49: 4,808,451
females age 18-49: 4,762,459 (2005 est.)
Manpower fit for military service:
males age 18—49: 3,011,081
females age 18-49: 2,991,551 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 251,056
females age 18-49: 247,777 (2005 est.)
Military expenditures— percent of
GDP: 0.8% (2006 est.)','38f81b1b9290f90ba9877452a0c606a1b23c5853ae21b202f0386ff0757b3e6b','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02d5041f593a716904118c99340f546a30d43844f0a1c121c0599903bf38527a',2008,'GR','Greece','military-and-security',673,'Military branches: Royal Gibraltar
Regiment
Manpower available for military service:
males age 18-49: 5,959 (2005 est.)
Manpower fit for military service: males
age 18-49: 4,893 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 187
(2005 est.)
Military— note: defense is the responsi¬
bility of the UK; the Royal Gibraltar
Regiment replaced the last British reg¬
ular infantry forces in 1992
Military branches: Hellenic Army
(Ellinikos Stratos, ES), Hellenic Navy
(Ellinikos Polemiko Navtiko, EPN),
Hellenic Air Force (Elliniki Polimiki
Aeroporia, EPA) (2007)
Military service age and obligation: 18
years of age for compulsory military
service; during wartime the law allows
for recruitment beginning January of the
year of inductee’s 18th birthday, thus
including 1 7 year olds; 1 7 years of age for
volunteers; conscript service obliga¬
tion — 12 months for the Army, Air
Force; 15 months for Navy; women are
eligible for military service (2005)
Manpower available for military service:
males age 1 8 — 49 : 2,459,988
females age i 8 — 49 : 2,442,818 (2005 est.)
Manpower fit for military service:
males age 18-49: 2,018,557
females age 18-49: 2,000,650 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 58,399
females age 18-49: 55,571 (2005 est.)
Military expenditures — percent of
GDP: 4-3% (2005 est.)','c28db653b14668f7c400609287fda9296dc595662c17f6de613bc9a974c52942','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf1b69e669eb07a230ccffd1650d1e9cd8955873d11b37ca28b74d6e22eac8ae',2008,'GD','Grenada','military-and-security',679,'Manpower available for military
service: males age 18-49: 14,653 (2005
est.)
Manpower fit for military service: males
age 18-49: 10,199 (2005 est.)','1de9361e1f2462e7d23128f46f4c105cba3c1a0d9d0c970f633a3dddcd0b2356','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecba61beaca2d82e0b9563fa8f579a08e82279efccce39aa93c87c612ee1d964',2008,'GU','Guam','military-and-security',685,'Military branches: no regular military
forces; Royal Grenada Police Force
(includes Coast Guard) (2007)
Manpower available for military
service: males age 18-49: 24,031 (2005
est.)
Manpower fit for military service: males
age 18-49: 17,483 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 1,274
(2005 est.)
Military expenditures— percent of
GDP: NA','44553990f51b17e4db0649be59ceb3f43713aedf80b9ba12e06623a149d00163','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a64b6cb0811c6b845e1e11ce570977f142cb473cc05cd345c175d3c7fe2a55b4',2008,'GT','Guatemala','military-and-security',693,'Military — note: defense is the responsi¬
bility of the US
Military branches: Army, Navy (in¬
cludes Marines), Air Force
Military service age and obligation: all
male citizens between the ages of 18 and
50 are liable for military service; con¬
script service obligation varies from 12 to
24 months (2005)
Manpower available for military service:
males age 18-49: 2,429,033
females age 18-49: 2,503,482 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,911,412
females age 18-49: 2,070,806 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 134,032
females age 18-49: 130,641 (2005 est.)
Military expenditures— percent of
GDP: 0.4% (2006)','a899a94dacd90d23b14d671c34b0785a3acd881a4360c60cb1767ade927261aa','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a02aa2d4ce85645e36a7413aa72175ea71455a9167993938021ca25464bfd6c',2008,'GY','Guyana','military-and-security',715,'Military branches: People’s Revolu¬
tionary Armed Force (FARP): Army,
Navy, Air Force; paramilitary force
Military service age and obligation: 18
years of age for compulsory military
service (2001)
Manpower available for military service:
males age 18-49: 287,542
females age 18-49: 297,295 (2005 est.)
Manpower fit for military service:
males age 18-49: 152,681
females age 18-^9: 161,033 (2005 est.)
Military expenditures — percent of
GDP: 3.1% (2005 est.)
Military branches: Guyana Defense
Force: Army, Coast Guard, Air Corps
(2006)
Manpower available for military
service: males age 18-49: 206,098 (2005
est.)
Manpower fit for military service: males
age 18-49: 137,964 (2005 est.)
Military expenditures— percent of
GDP: 1.8% (2006)
Military branches: National Armed
Forces (Fuerzas Armadas Nacionales or
FAN): Ground Forces or Army (Fuerzas
Terrestres or Ejercito), Naval Forces
(Fuerzas Navales or Armada; includes
Marines, Coast Guard), Air Force
(Fuerzas Aereas or Aviacion), Armed
Forces of Cooperation or National Guard
(Fuerzas Armadas de Cooperacion or
Guardia Nacional)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 30 months; all citizens of military
service age (between 18 and 50 years
old) are obligated to register for military
service (2007)
Manpower available for military service:
males age 18-49: 6,236,012
females age 18—49: 6,137,622 (2005 est.)
Manpower fit for military service:
males age 18-49: 4,907,947
females age 18-49: 5,151,843 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 252,396
females age 18—49: 237,300 (2005 est.)
Military expenditures— percent of
GDP: 1.2% (2005 est.)
Military branches: People’s Armed
Forces: People’s Army of Vietnam
(PAVN) (includes People’s Navy
Command (with naval infantry, coast
guard), Air and Air Defense Force (Kon
Quan Nhan Dan), Border Defense
Command), People’s Public Security
Forces, Militia Force, Self-Defense
Forces (2005)
Military service age and obligation: 18
years of age (male) for compulsory mili¬
tary service; females may volunteer for
active duty military service; conscript
service obligation — 2 years (3 to 4 years
in the navy); 18-45 years of age (male)
or 18-40 years of age (female) for Militia
Force or Self Defense Forces (2006)
Manpower available for military service:
males age 18-49: 21,341,813
females age 18—49: 21,430,808 (2005 est.)
676
VIRGIN ISLANDS
Manpower fit for military service:
males age 18-49: 16,032,358
females age 18-49: 17,921,241 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 915,572
females age 18—4 9: 864,161 (2005 est.)
Military expenditures — percent of
GDP: 2.5% (2005 est.)
Military— note: defense is the responsi¬
bility of the US
Military — -note: defense is the responsi¬
bility of the US; the US Air Force is
responsible for overall administration
and operation of the island; the launch
support facility is administered by the US
Missile Defense Agency (MDA)','9dab68a0a143f287473ac3807cbb23a85e2c9579cceb3152dee966835ed5b63c','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8651876c5812544196986702a118478c8e848bda50d049044a21220d3b0420fb',2008,'HT','Haiti','military-and-security',725,'Military branches: no regular military
forces — small coast guard; the regular
Haitian Armed Forces (FAdH) — Army,
Navy, and Air Force — have been demo¬
bilized but still exist on paper unless they
are constitutionally abolished (2007)
Military service age and obligation: 18
years of age for voluntary recruitment
into the police force (2001)
Manpower available for military service:
males age 18-49: 1,626,491
females age 18—49: 1,637,657 (2005 est.)
Manpower fit for military service:
males age 18—49: 948,320
females age 18—49: 931,972 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 98,554
females age 18—4 9: 97,690 (2005 est.)
Military expenditures— percent of
GDP: 0.4% (2006)','c4b8ab2edfec2a004c11bf0fcdb603ba7f693683699fb37339106a825ba03726','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a1b429769e28536ea5abe01d8766b39f4a27299602d19b7132cb0eeb470d0b4',2008,'HM','Heard Island and McDonald Islands','military-and-security',733,'Military — note: defense is the responsi¬
bility of Australia; Australia conducts
fisheries patrols
Military branches: Pontifical Swiss
Guard (Corpo della Guardia Svizzera
Pontificia)
Military — note: defense is the responsi''
bility of Italy; ceremonial and limited
security duties performed by Pontifical
Swiss Guard','697638ae8214be3eaa4668912c22518787c308816141d1832839527f14647e4a','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('295adf3e9ea44e7232552e8571fc252f4f4659ba5a215f3b61de71579f99db6e',2008,'HN','Honduras','military-and-security',741,'Military branches: Army, Navy (includes
Naval Infantry7)) Honduran Air Force
(Fuerza Aerea Hondurena, FAH) (2007)
Military service age and obligation: 18
years of age for voluntary 2 to 3 -year mil¬
itary service (2004)
Manpower available for military service:
males age 18-49: 1,537,232
females age 18-49: 1,515,120 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,100,991
females age 18-49: 1,121,649 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 82,105
females age 18-49: 78,971 (2005 est.)
Military expenditures— percent of
GDP: 0.6% (2006 est.)','cf9fbeb4c13bc330c348d396992cdca57b09b31d84e3ce5ef3c7fa2e56616f3a','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4533f84e368ae0cd7e93604f28749dd98aa0bfe0b5b931de3d83dc6db0dea45e',2008,'HU','Hungary','military-and-security',751,'Military branches: no regular indige¬
nous military forces; Hong Kong garrison
of China’s People’s Liberation Army
(PLA) includes elements of Ground
Forces, Navy, and Air Force; these forces
are under the direct leadership of the
Central Military Commission in Beijing
and under administrative control of the
adjacent Guangzhou Military Region
Military service age and obligation: 18
years of age (2004)
Manpower available for military service:
males age 18-49: 1,743,972
females age 18-4 9: 1,904,967 (2005 est.)
Manpower fit for military service:
males age 1 8 — 49: 1,403,088
females age 18-49: 1,527,278 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 40,343
females age 18-49: 38,234 (2005 est.)
Military expenditures— percent of
GDP: NA
Military — note: defense is the responsi¬
bility of China
Military branches: Ground Forces,
Hungarian Air Force (Magyar Legiero,
ML) (2006)
Military service age and obligation: 18
years of age for voluntary military
service; conscription abolished in June
2004 (2004)
Manpower available for military service:
males age 18—49: 2,303,116
females age 18-49: 2,265,463 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,780,513
females age 18-49: 1,864,580 (2005 est.)
Manpower reaching military service
age annually:
males age i 8 — 49: 63,847
females age 18-49: 61,037 (2005 est.)
Military expenditures— percent of
GDP: 1.75% (2005 est.)
Military branches: no regular armed
forces; Icelandic National Police,
Icelandic Coast Guard (Islenska
Landhelgisgaeslan) subordinate to
Ministry of Justice, Icelandic Crisis
Response Unit (2006)
Manpower available for military
service: males age 18-49: 69,038 (2005
est.)
Manpower fit for military service: males
age 18-49: 56,777 (2005 est.)
Military expenditures — percent of
GDP: 0% (2005 est.)
Military— note: under a 1951 bilateral
agreement, Iceland’s defense was pro¬
vided by a US-manned Icelandic
Defense Force (IDF) headquartered in
Keflavik; in October 2006, all US mili¬
tary forces in Iceland were withdrawn;
nonetheless, the US and Iceland signed a
Joint Understanding to strengthen their
bilateral defense relationship, including
regular security consultations, military
communications in the event of national
emergencies, annual bilateral exercises
on Icelandic territory, and future bilat¬
eral and NATO support to four Iceland
Air Defense System (IADS) radar sites','e017f5bf2623f4df7c2321cdd7bb37a6592cd216bdaacaf6188fdbca8e581613','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72a6ff7479ff557151f26f2e792ef24a6938c2ec9040abc05998fdc6488c2c72',2008,'IE','Ireland','military-and-security',780,'Military branches: Irish Defense Forces
fOglaigh na h-Eireann): Army (includes
^v*l Service and Air Corps) (2006)
309
THE CIA WORLD FACTBOOK
Military service age and obligation-. 17
years of age for voluntary military service;
enlistees under the age of 17 can be
recruited for specialist positions (2001)
Manpower available for military service:
males age 17-49: 977,092
females age 17-49: 978,465 (2005 est.)
Manpower fit for military service:
males age 17-49: 814,768
females age ''17-49: 813,981 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 29,327
females age 17-49: 28,139 (2005 est.)
Military expenditures — percent of
GDP: 0.9% (2005 est.)','29a43b487230087ca379c178b93512d985f3c74df805cc419efe1e72e7246f1b','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcfb44288f79eeb34184989c5fe881017b085ff03cfeb2bb5d260a049771d589',2008,'JP','Japan','military-and-security',806,'- - -Xte* j • a*.
Military— note: defense is the responsi¬
bility of Norway
Military branches: Japanese Defense
Agency (JDA): Ground Self-Defense
Force (Rikujou Jietai, GSDF), Maritime
Self-Defense Force (Kaijou Jietai,
MSDF), Air Self-Defense Force (Nihon
Koku-Jieitai, ASDF) (2006)
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military service:
males age 18—49: 27,003,112
females age 18-49: 26,153,482 (2005
est.)
Manpower fit for military service:
males age i 8 — 49: 22,234,663
females age i 8 — 49: 21,494,947 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 683,147
females age 18-4 9: 650,157 (2005 est.)
Military expenditures— percent of
GDP: 0.8% (2006)
. . •• - . . ~ 7.','ce2319b9a78966078c1cc36acd28cc7e0026c24ac8f7c03946661fd04d5e59c0','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('721b843db3803c71fbefddb595b0fb507b0e3809150956c79e9a2be5fe0a2835',2008,'KE','Kenya','military-and-security',831,'Military branches: Ground Forces,
Naval Force, Air and Air Defense Forces,
Republican Guard
Military service age and obligation: 18
years of age for compulsory military
service; conscript service obligation — 2
years; minimum age for volunteers NA
(2004)
Manpower available for military service:
males age 18-49: 3,758,255
females age 18-49: 3,822,845 (2005 est.)
Manpower fit for military service:
males age 18-49: 2,473,529
females age 18-49: 3,168,048 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 173,129
females age 18-4 9: 168,697 (2005 est.)
Military expenditures — percent of
GDP: 0.9% (Ministry of Defense expen¬
ditures) (FY02)
Military branches: Kenyan Army,
Kenyan Navy, Kenyan Air Force (2007)
Military service age and obligation: 18
years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 7,303,153
females age 18-49: 7,083,726 (2005 est.)
Manpower fit for military service:
males age 18-49: 3,963,532
females age 18-49: 3,471,926 (2005 est.)
Military expenditures— percent of
GDP: 2.8% (2006)','f95a3f405ec06e3c87d878eae2eaa9e85f96b8996a1e98c405a24da4b93527a9','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60c036ec22502936221cd69c533b8b7dfd0cdf3cf9174bfd406bd189bd755972',2008,'KI','Kiribati','military-and-security',843,'Military branches: no regular military
forces; Police Force (carries out law
enforcement functions and paramilitary
duties; small police posts are on all
islands) (2007)
Manpower available for military service:
males age 18^9: 21,938 (2005 est.)
Manpower fit for military service: males
age 18-49: 14,231 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 1,128
(2005 est.)
Military expenditures — percent of
GDP: NA
Military — note: Kiribati does not have
military forces; defense assistance is pro¬
vided by Australia and NZ','ee1d1d67295911898489359e74ab55a85611d2c24fa886b944dc2ec094607167','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cd53203b5c237d3be46a7b1e1967e31366f57b3cb72bda17e46ad8321f8a36a',2008,'KW','Kuwait','military-and-security',854,'Military branches: Land Forces, Kuwaiti
Navy, Kuwaiti Air Force (ALQuwwat ah
Jawwiya al-Kuwaitiya), National Guard
(2007)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; 1 month annual training
to age 40; women have served in police
forces since 1999 (2001)
Manpower available for military service:
males age 18-49: 864,745
females age 18-49: 467,120 (2005 est.)
Manpower fit for military service:
males age 18-49: 737,292
females age 18-49: 405,207 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 18,743
females age 18-49: 20,065 (2005 est.)
Military expenditures — percent of
GDP: 5.3% (2006)','50140b9b6b3b1e192ea16c3010e3fefcb42b1b7a4afaf0ef8e4287ad99397a86','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0867b7c34ef5a529b6d11fdabb22b28372ee60b47ac89093365c4b75659f075b',2008,'KG','Kyrgyzstan','military-and-security',862,'Military branches: Army, Air Force,
National Guard (2005)
Military service age and obligation: 18
years of age for compulsory military
service (2001)
Manpower available tor military service:
males age 18-49: 1,193,529
females age 18-49: 1,219,080 (2005 est.)
Manpower fit for military service:
males age 18-49: 871,493
females age 18-49: 1,024,568 (2005 est.)
Manpower reaching military service
age annually:
males age 1 8-49 : 6 1 ,09 1
females age 18-49: 59,784 (2005 est.)
Military expenditures— percent of
GDP: 1.4% (2005 est.)','1307c0a121a83e4673eec8a9e733b7ed5bbd8758d9a97f735255cea594dea114','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('317b5dddcaccc767844c20658a1beb579e46454969e7c4c95d9a878e6e0cc2de',2008,'TH','Thailand','military-and-security',869,'Military branches: Lao Peoples Army
(LPA; includes Riverine Force), Air
Force
Military service age and obligation: 15
years of age for compulsory military
service; conscript service obligation —
minimum 18 months (2004)
Manpower available for military service:
males age 15-49: 1,500,625
females age 15-49: 1,521,116 (2005 est.)
Manpower fit for military service:
males age 15-49: 954,816
females age 15-49: 1,006,082 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 73,167
females age 15-49: 71,432 (2005 est.)
Military expenditures— percent of
GDP: 0.5% (2006)
Military — note: Laos is one of the
world’s least developed countries; the
Lao People’s Armed Forces are small,
poorly funded, and ineffectively re¬
sourced; there is little political will to
allocate sparse funding to the military,
and the armed forces’ gradual degrada¬
tion is likely to continue; the massive
drug production and trafficking industry
centered in the Golden Triangle makes
Laos an important narcotics transit
country, and armed Wa and Chinese
smugglers are active on the Lao- Burma
border (2005)
Military branches: Royal Thai Army
(RTA), Royal Thai Navy (RTN,
includes Royal Thai Marine Corps),
°ya Air F°rce (Knogtap Agard
Thai, RTAF) (2006)
Military service age and obligation: 21
years of age for compulsory military
service; males are registered at 18 years of
age; conscript service obligation— 2
years, 18 years of age for voluntary mili¬
tary service (2004)
616','fd2d88acb97d586a836a5c1171a77a787ae3af80e7d8b41f7cd69025b0c88724','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('724af4835305989839f628226e8647fe32961fbc843dae0b05fcacf3ead965af',2008,'SE','Sweden','military-and-security',881,'Military branches: Latvian Republic
Defense Force: Ground Forces, Navy, Air
Force, Border Guard, Home Guard
(Zemessardze) (2005)
Military service age and obligation: 19
years of age for compulsory military
service; conscript service obligation — 12
months; 18 years of age for volunteers;
plans are to phase out conscription, ten¬
tatively moving to an all-professional
force by 2007; under current law, every
citizen is entitled to serve in the armed
forces for life (2004)
Manpower available for military service:
males age 19-49: 517,713
females age 19-19: 519,631 (2005 est.)
Manpower fit for military service:
males age 19-49: 361,098
females age 19-19: 422,913 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 19,137
females age 19-49: 18,505 (2005 est.)
Military expenditures— percent of
GDP: 1.2% (2005 est.)
Military branches: Umbutfo Swaziland
Defense Force (USDF): Ground Force
(includes air wing), Royal Swaziland
Police Force (RSPF) (2005)
Military service age and obligation:
18-30 years of age for voluntary military
service; both sexes are eligible for mili¬
tary service (2005)
Manpower available for military
service: males age 18—49: 227,617 (2005
est.)
Manpower fit for military service: males
age 18-49: 89,609 (2005 est.)
Military expenditures— percent of
GDP: 4.7% (2006)
Military branches: Swedish Armed
Forces (Forsvarsmakten): Army
(Armen), Royal Swedish Navy
(Marinen), Swedish Air Force (Svenska
Flygvapnet) (2006)
Military service age and obligation: 19
years of age for compulsory military
service; conscript service obligation —
7-17 months depending on conscript
role; after completing initial service, sol¬
diers have a reserve commitment until
age of 47 (2004)
Manpower available for military service:
males age 19-49: 1,838,427
females age 19-49: 1,774,659 (2005 est.)
Manpower fit for military service:
males age 19-49: 1,493,668
females age 19-49: 1,441,257 (2005 est.)
Manpower reaching military service
age annually:
males age 18^*9: 58,724
females age 19-49: 55,954 (2005 est.)
Military expenditures — percent of
GDP: 1.5% (2005 est.)','84855d8fe4d2b5be2b94678013e368d8a1531a625e869a72f32f63bc749bfa04','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b47b894179766595d551fa63b43b46433ba97a5efd02300db307c991fe2390d9',2008,'LB','Lebanon','military-and-security',887,'Military branches: Lebanese Armed
Forces (LAF): Army, Navy, and Air
Force (2007)
Military service age and obligation:
18-30 years of age for compulsory and
voluntary military service; in May 2005,
conscript service obligation reduced
from 12 to 6 months over a 2-year
period; conscripts eligible to volunteer
for 5 years of military service upon com¬
pleting 6 months of conscript service;
Lebanon is moving toward a predomi¬
nantly professional armed forces (2005)
Manpower available for military service:
males age 18-49: 974,363
females age 18-49: 1,024,273 (2005 est.)
Manpower fit for military service:
males age 18-49: 821,762
females age 18-49: 865,770 (2005 est.)
Military expenditures— percent of
GDP: 3.1% (2005 est.)','7cbeb56ff3f065cda035c443406e3dae75e4d2437c9d0879c59143c3feb29e7b','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a2f8ba6f68c416ce06fad442f24acef2b5f4c169432179d1a6812ee668e7792',2008,'LR','Liberia','military-and-security',893,'Military branches: Lesotho Defense
Force (LDF): Army and Air Wing
Military service age and obligation: 18
years of age (est.); no conscription
(2001)
Manpower available for military service:
males age 18-49: 428,982
females age 18-49: 440,102 (2005 est.)
Manpower fit for military service:
males age 1 8—49 : 180,797
females age 18-4 9: 160,681 (2005 est.)
Military expenditures— percent of
GDP: 2.6% (2006)
Military — note: the Lesotho Govern¬
ment in 1999 began an open debate on
the future structure, size, and role of the
armed forces, especially considering the
Lesotho Defense Force’s (LDF) history of
intervening in political affairs
Military branches: Armed Forces of
Liberia (AFL): Army, Navy, Air Force
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2001)
Manpower available for military service:
males age 18-49: 575,384
females age 18—49: 588,780 (2005 est.)
Manpower fit for military service:
males age 18—49: 267,430
females age 18-49: 286,231 (2005 est.)
Military expenditures— percent of
GDP: 1.3% (2006 est.)','6aeb3955183717a35291e07f7bf95b024e623232e54814abb11b4d7c9504d543','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba2c3924b30db02cd1ff4582656babfade77a1c08186fe314a0cad2773dbf990',2008,'LI','Liechtenstein','military-and-security',906,'Military branches: Armed Peoples on
Duty (APOD, Army), Libyan Arab
Navy, Libyan Arab Air Force (Ah
Quwwat ahjawwiya al-Jamahiriya ah
Arabia al-Libyya, LAAF) (2007)
Military service age and obligation: 17
years of age (2004)
Manpower available for military service:
males age 17-49: 1,505,675
females age 17-49: 1,429,152 (2005 est.)
Manpower fit for military service:
males age 17-49: 1,291,624
females age 17-49: 1,230,824 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 62,034
females age 17-49: 59,533 (2005 est.)
Military expenditures— percent of
GDP: 3.9% (2005 est.)','dc8597b4f2b9ad3ef309863ec801b5bc4a9325ad8f6b73acbc3069f678042901','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('074ff0684b25b6d8cf8d1c7a61b344c32d090c1e15e7d19e2256d23ca74a7b57',2008,'LT','Lithuania','military-and-security',916,'Manpower available for military service:
males age 18-4 9: 7,736 (2005 est.)
Manpower fit for military service: males
age 18-4 9: 6,250 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 208
(2005 est.)
Military — note: defense is the responsi¬
bility of Switzerland','58c623eb88c66588948f6ac74c384f581e576cd606a013105ecdffb8789850e4','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a43fd3d0fc99ca63c72ac383a4a95e8b61e30809665a558e970392629d814e71',2008,'LU','Luxembourg','military-and-security',928,'Military branches: Army
Military service age and obligation: a
1967 law made the Army an all- volun¬
teer force; 17 years of age for voluntary
military service; soldiers under 18 are not
deployed into combat or with peace¬
keeping missions (2004)
Manpower available for military service:
males age 17—49: 110,867
females age 17-49: 108,758 (2005 est.)
Manpower fit for military service:
males age 17-49: 90,279
females age 17-49: 88,638 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 2,775
females age 17-49: 2,703 (2005 est.)
Military expenditures— percent of
GDP: 0.9% (2005 est.)','b9dba7841b3b3bdc7bae3234744310c31394a3ffb526f630eb5ba5bf936b749b','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12a6f7c7ba9ca572f095c121388c29ae746ed625e2066ff7e289dec83f241467',2008,'MG','Madagascar','military-and-security',932,'Military branches: Army of the
Republic of Macedonia (ARM): Joint
Operational Command, with subordi¬
nate Air Wing (Makedonsko Voeno
Vozduhoplovstvo, MW), Special
Operations Regiment (2007)
Military service age and obligation:
mandatory military service phased out by
mid-2006; 18 years of age for voluntary
military service (2007)
Manpower available for military service:
males age 18-49: 498,259
females age 18-49: 481,317 (2005 est.)
Manpower fit for military service:
males age 18-49: 411,156
females age 18-49: 397,839 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 16,686
females age 18^9: 15,664 (2005 est.)
Military expenditures — percent of
GDP: 6% (2005 est.)','2598f8aa23ee8b1cc627cad5f9a95c13e5fb2a745e037542e85c1963c4d53f44','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e18dc3782e7aa57277651fa0de8867d9298066f5338ed7ee84fe1b30353ea7ab',2008,'MV','Maldives','military-and-security',961,'Military branches: National Security
Service: Security Branch (ground
forces), Air Element, Coast Guard
Military service age and obligation: 18
years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 71,774
females age 18-49: 69,229 (2005 est.)
Manpower fit for military service:
males age 18-49: 56,687
females age 18-49: 54,454 (2005 est.)
Military expenditures— percent of
GDP: 5.5% (2005 est.)','5ff3e09255737e6553e6782f8d2d4635f442b7c8c81b2bd13bf35927b3d21830','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf2afee58f526f64bd12186997301897e638580de9ebf8d29a14d1fc8e771e82',2008,'MT','Malta','military-and-security',968,'Military branches: Malian Armed
Forces: Army, Republic of Mali Air Force
(Force Aerienne de la Republique du
Mali, FARM), National Guard (2007)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 2 years (2004)
Manpower available for military service:
males age 18-49: 2,094,432
females age 18-49: 2,027,352 (2005 est.)
Manpower fit for military service:
males age 18-4 9: 1,244,176
females age 18-49: 1,226,226 (2005 est.)
Military expenditures— percent of
GDP: 1.9% (2006)','200592498db63792e6f8947af428b1707b8ad9e20f6274ce9586e22980115974','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9d89c943fb9fcceaef52a2c4142f837cd595b0f39b88e733a35af0919824f9c',2008,'MH','Marshall Islands','military-and-security',976,'Military branches: Armed Forces of
Malta (AFM; includes air and maritime
elements) (2005)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2001)
Manpower available for military service:
males age 18-49: 90,651
females age 18-49: 87,047 (2005 est.)
Manpower fit for military service:
males age 18-49: 74,525
females age 18-49: 71,333 (2005 est.)
Military expenditures — percent of
GDP: 0.7% (2006 est.)
Military branches: no regular military
forces; Marshall Islands Police
Manpower available for military serv¬
ice: males age 18-49: 13,465 (2005 est.)
Manpower fit for military service: males
age 18-49: 10,792 (2005 est.)
Manpower reaching military service
age annually: males age 18^19: 726
(2005 est.)
Military expenditures— percent of
GDP: NA
Military — note: defense is the responsi¬
bility of the US','2eb6e9e0fa02e137d4b85dcf98eb5958d3e073b1bfff2f3ba26e711bd4855f74','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a2cde9caf14e42bde7060eefee12522990b4e690792ae0692a182dde5342fe0',2008,'MR','Mauritania','military-and-security',986,'Military branches: Mauritanian Armed
Forces: Army, Navy (Marine
Mauritanienne; includes naval infantry),
Air Force (Force Aerienne Islamique de
Mauritanie, FAIM) (2005)
Military service age and obligation: 18
years of age (est.); conscript service obli¬
gation— 2 years; majority of servicemen
believed to be volunteers; service in Air
Force and Navy is voluntary (2005)
Manpower available for military
service: males age 18-49: 606,463
females age i 8 — 49: 607,955 (2005 est.)
Manpower fit for military service: males
age 1 8—49: 370,513
females age 18-49: 384,269 (2005 est.)
Military expenditures— percent of
GDP: 5.5% (2006)
406','29bbc900c9db67ad5960f8766adc22eb8c7fb03bbde40b2446dd632f17ece45e','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c90d8a1cfe8bc050fc3591a0ba87a09fa2ccb6a60b5e4f21db52d91ddc96a2a',2008,'YT','Mayotte','military-and-security',993,'Military branches: no regular military
forces; National Police Force, Special
Mobile Force, National Coast Guard
(2007)
Manpower available for military
service: males age 18-49: 313,271 (2005
est.)
Military expenditures— percent of
GDP: 0.3% (2006 est.)','63f11d7fa1f4aefd875490a7b791f0a71b6a1fabc9dfafe50dbf16648842f7c8','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5f43ee90f291982b47d46cc0c4a3cd1d13158976c134921085a33c3228731c9',2008,'MX','Mexico','military-and-security',1005,'Military branches: Secretariat of
National Defense (Secretaria de Defensa
Nacional, Sedena): Army (Ejercito),
Mexican Air Force (Fuerza Aerea
Mexicana, FAM); Secretariat of the
Navy (Secretaria de Marina, Semar):
Mexican Navy (Armada de Mexico,
ARM, includes Naval Air Force (FAN)
and Marines) (2007)
Military service age and obligation: 18
years of age for compulsory military
service, conscript service obligation — 12
months; 16 years of age with consent for
voluntary enlistment; conscripts serve
only in the Army; Navy and Air Force
service is all voluntary (2007)
Manpower available for military service:
males age f 8 — 49 : 24,488,008
females age 18-49: 26,128,046 (2005
est.)
Manpower fit for military service:
males age 1 8 — 49 : 19,058,337
females age 18^-9: 21,966,796 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 1,063,233
females age 18-49: 1,043,816 (2005 est.)
Military expenditures— percent of
GDP: 0.5% (2006 est.)','f9d230e12000cbf3f15205475286a16cf25a1b56c4cd7c215f90ed53652c0f82','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('191913e9990523ad4d9fb75210570e9c0bbd96159bc0d8bb47eaf308e431885f',2008,'FM','Micronesia, Federated States of','military-and-security',1013,'Military branches: no ministry of
defense and no standing armed forces;
the paramilitary Maritime Wing, a small
maritime law enforcement unit, is
responsible to the Division of Maritime
Surveillance within the Office of the
Attorney General (2003)
Manpower available for military
service: males age 18-49: 23,816 (2005
est.)
Manpower fit for military service: males
age 18-49: 18,914 (2005 est.)
Manpower reaching military service
age annually: males age 18-49.- 1,305
(2005 est.)
Military — note: defense is the responsi¬
bility of the US','d6c7adcf494a69504b64f011ae3af501eb4092e15b34195800cd595941517ef0','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d5163b60e7080c6b89b8c84600940ab36195e6ac1523b050973914b21d72a59',2008,'RO','Romania','military-and-security',1018,'Military branches: National Army:
Ground Forces, Rapid Reaction Forces,
Air and Air Defense Forces (2006)
Military service age and obligation: 18
years of age for compulsory military
service; national service obligation — 12
months (2004)
Manpower available for military service:
males age 18-49: 1,066,459
females age 18-49: 1,117,070 (2005 est.)
Manpower fit for military service:
males age 18-49: 693,913
females age 18—49: 911,568 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 43,729
females age 1 8 — 49: 42,354 (2005 est.)
Military expenditures— percent of
GDP: 0.4% (2005 est.)
TRANSNATIONAL ISSUES 1
Disputes — international: Moldova and
Ukraine operate joint customs posts to
monitor the transit of people and com''
modities through Moldova’s break-away
Transnistria region, which remains under
OSCE supervision
Illicit drugs: limited cultivation of
opium poppy and cannabis, mostly for
CIS consumption; transshipment point
for illicit drugs from Southwest Asia via
Central Asia to Russia, Western Europe,
and possibly the US; widespread crime
and underground economic activity','6c1fdef585e87fd093f3b7d5db4c28f4f9cfba2490465fa6975a63d9ea291626','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0292d9f93750b24ebf183c1a6d9469094cc7b440c09427fd80392db3c07c9b73',2008,'MC','Monaco','military-and-security',1019,'Background: The Genoese built a
fortress on the site of present-day
Monaco in 1215. The current ruling
Grimaldi family secured control in the
late 13th century, and a principality was
established in 1338. Economic develop¬
ment was spurred in the late 19th cen¬
tury with a railroad linkup to France and
the opening of a casino. Since then, the
principality’s mild climate, splendid
scenery, and gambling facilities have
made Monaco world famous as a tourist
and recreation center.
Manpower available for military service:
males age 18-49: 6,256 (2005 est.)
Manpower fit for military service: males
age 18-49: 4,971 (2005 est.)
Manpower reaching military service
age annually: males age 18-4 9: 148
(2005 est.)
Military — note: defense is the responsi¬
bility of France; the Palace Guard per¬
forms ceremonial duties (2003)','36f55da16acc4ad10ba4ed5406ff66a2923f738b046fba1894077c2a59d84935','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdf71a00d381c577cc54dc426aea706e1c155ed6f7992078c476dbfd894d11c8',2008,'ME','Montenegro','military-and-security',1035,'Military branches: Mongolian People’s
Army (MPA), Mongolian People’s Air
Force (MPAF); there is no navy (2005)
Military service age and obligation:
18-25 years of age for compulsory mili¬
tary service; conscript service obliga¬
tion — 12 months in land or air defense
forces or police; a small portion of
Mongolian land forces (2.5 percent) is
comprised of contract soldiers; women
cannot be deployed overseas for military7
operations (2006)
Manpower available tor military service:
males age 18^9: 736,182
females age 18-49: 734,679 (2005 est.)
Manpower tit for military service:
males age 18-49: 570,435
females age 18-49: 607,918 (2005 est.)
Manpower reaching military service
age annually:
males age 18-4-9: 34,674
females age 18^19: 34,251 (2005 est.)
Military expenditures— percent of
GDP: 1.4% (2006)','7f698c06406d7c16bbdaa9cf8fbe2719890c6d4973b0a49c22592bf91c225ba8','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92029fc523309a91dd7c4e8a061954da5089ea48101634ef8d31cd4977a38c1e',2008,'MS','Montserrat','military-and-security',1045,'''''■v’ i . “ v~~ '' ? :y*
Military service age and obligation:
compulsory national military service
abolished August 2006
Military — note: Montenegrin plans call
for the establishment of a fully profes¬
sional armed forces','bbd09bc78266f782cc28e36c698040a113351c13c5a0d28ce5684331bfb68372','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc074d4487dc15ad11d15cfcce3d89bb2d5c1e3d49cd457097b19d748056b274',2008,'MA','Morocco','military-and-security',1053,'Military branches: no regular military
forces; Royal Montserrat Police Force
(2005)
Manpower available for military
service: males age 18-49: 2,298 (2005
est.)
Manpower fit for military service: males
age 18-49: 1,899 (2005 est.)
Manpower reaching military service
age annually: males age 18-A9-. 84 (2005
est.)
Military— note: defense is the responsi¬
bility of the UK
Military branches: Royal Armed Forces
(Forces Armees Royales, FAR): Royal
Moroccan Army (includes Air Defense),
Navy (includes Marines), Royal Moroc¬
can Air Force (Force Aerienne Royale
Marocaine) (2007)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 18 months (2004)
Manpower available for military service:
males age 18-49: 7,908,864
females age 18-49: 7,882,879 (2005 est.)
Manpower fit for military service:
males age 18-49: 6,484,787
females age 18-49: 6,675,729 (2005 est.)
Manpower reaching military service
age annually:
males age 18-4-9: 353,377
females age 1 8 — 49 : 341,677 (2005 est.)
Military expenditures— percent of
GDP: 5% (2003 est.)','10b5aed3d249cf8d779903d3b89acff84e7d7a9b680888f077e7fcb04512d69a','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ee43fef7149d65740b99cf5cbe27022b2716f8087ed473350d208c33422f7a0',2008,'NA','Namibia','military-and-security',1065,'Military branches: Namibian Defense
Force: Army, Navy, Air Wing (2006)
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military service:
males age 18-49: 441,293 (2005 est.)
Manpower fit for military service: males
age 18^9: 217,118 (2005 est.)
Military expenditures— percent of
GDP: 3.7% (2006)','8121440ca98e00bbe38a56bc1ec2011dfc5e803b6b8c0ae8a8e32b1892c8c8eb','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbf8587189bbfda5d529179454a09522fd559c70553223421ad50b155c8677e1',2008,'NP','Nepal','military-and-security',1079,'Military— note: defense is the responsi¬
bility of the US
Military branches: Royal Nepalese
Army (includes Royal Nepalese Army
Air Service); Nepalese Police Force
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military service:
males age 18-49: 6,107,091
females age 18-49: 5,744,989 (2005 est.)
Manpower fit for military service:
males age 18-49: 4-193 million
females age 18-4 9: 3,853,102 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 308,031
females age 18-49: 286,604 (2005 est.)
Military expenditures— percent of
GDP: 1.6% (2006)','9ca50bc56bd5845c954a4b71a3e144bdb5da0ce2624ac34f63d8273924eb35e2','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c3cb2a7371f3d60843caacbba34bae56779abc1dd92c8c8a21734356437f666',2008,'NL','Netherlands','military-and-security',1087,'Military branches: Royal Netherlands
Army, Royal Netherlands Navy (in¬
cludes Naval Air Service and Marine
Corps), Royal Netherlands Air Force
(Koninklijke Luchtmacht, KLu), Royal
Military Police, Defense Interservice
Command (DICO) (2006)
Military service age and obligation: 20
years of age for an all-volunteer force
(2004)
Manpower available for military service:
males age 20-49: 3,557,918
females age 20^9: 3,470,377 (2005 est.)
Manpower fit for military service:
males age 20-49: 2,856,691
females age 20-A 9: 2,786,495 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 99,934
females age 20^9: 95,818 (2005 est.)
Military expenditures — percent of
GDP: 1.6% (2005 est.)
Military branches: no regular military
forces; National Guard, Police Force
(2005)
Military service age and obligation: 16
years of age for National Guard recruit¬
ment; no conscription (2004)
Manpower available for military service:
males age 16-49: 54,200
females age 16-49: 56,868 (2005 est.)
449
THE CIA WORLD FACTBOOK
Manpower fit for military service:
males age 16-49: 45,273
females age 16-49: 47,166 (2005 est.)
Manpower reaching military service
age annually:
males age 18-4 9: 1,720
females age 16-49: 1,657 (2005 est.)
Military — note: defense is the responsi''
hility of the Kingdom of the Netherlands','965ef4af6e7607107bca158f52076ddf5492dfc088e3a291a466c116cc68b1bc','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fcc448b07909e6f4c6c4c00d9ea3867e16f9f404ec7ad6b3b812523f4a07836',2008,'NC','New Caledonia','military-and-security',1096,'Military branches: no regular indige-
nous military forces; French Armed
Forces (includes Army, Navy, Air Force,
Gendarmerie); Police Force
Manpower available for military service:
males age i 8 — 49; 50,874 (2005 est.)
Manpower fit for military service: males
age 18-49: 40,822 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 1,907
(2005 est.)
Military expenditures— percent of
GDP: NA
Military — note: defense is the responsi''
bility of France
Military— note: defense is the responsi¬
bility of France
GDP: NA
expenditures— percent of','dfb670e350a2f07eb80980c3108082469edc0899cd2c2904dcdd4465038c3087','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4953f34871e1deb23b1db36754259d42c9c2a9ee4d81e2bdc3d183616746572',2008,'NE','Niger','military-and-security',1116,'Military branches: Nigerien Armed
Forces (Forces Armees Nigeriennes,
FAN): Army, Niger Air Force (2007)
Military service age and obligation: 18
years of age for compulsory military
service; conscript service obligation — 2
years (2004)
Manpower available for military service:
males age 1 8 — 49 : 2,367,828
females age 18-4 9: 2,217,568 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,349,863
females age 18-49: 1,256,569 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 129,045
females age 18^-9: 121,230 (2005 est.)
Military expenditures— percent of
GDP: 1.3% (2006)','9ad2aa729b5b6c65aa62a2ea83dda1517afd426ae95c5a8f884037017b0589be','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3d2abe6a08d8010cf406afb2b10ab2b9ea1de48e3240e6fda4ae4469d054042',2008,'NG','Nigeria','military-and-security',1122,'Military branches: Nigerian Armed
Forces: Army, Navy, Air Force (2007)
Military service age and obligation: 18
years of age for voluntary military service
(2006)
Manpower available for military service:
males age 18-49: 26,802,678
females age 18-49: 25,668,446 (2005 est.)
Manpower fit for military service:
males age i 8 — 49 : 15,052,914
females age 18-49: 13,860,806 (2005
est.)
Manpower reaching military service
age annually:
males age 18-49: 1,353,180
females age 1 8 — 49: 1,329,267 (2005 est.)
Military expenditures— percent of
GDP: 1.5% (2006)','d6748e141c15376073ea445e2b86c99fb6ec28c1d5b13de6aa97f6c01c6133a8','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59a250502138a6602ba609ae373c67b29d71b82af28f9e367e70a016ded0f5ef',2008,'NO','Norway','military-and-security',1150,'Military branches: Norwegian Army
(Haeren), Royal Norwegian Navy
(Kongelige Norske Sjoeforsvaret, RNoN;
includes Coastal Rangers and Coast
Guard (Kystvakt)), Royal Norwegian
Air Force (Kongelige Norske Luft-
forsvaret, RNoAF), Home Guard (Hei-
mevernet, HV) (2006)
Military service age and obligation: 18
years of age for compulsory military
service; 16 years of age in wartime; 17
years of age for male volunteers; 18 years
of age for women; 16 years of age for vol¬
unteers to the Home Guard; conscript
service obligation — 12 months (2004) .
Manpower available for military service:
males age 18-49: 1,014,592
females age 18-4 9: 982,734 (2005 est.)
Manpower fit for military service:
males age 18-4 9: 827,016
females age 18-49: 801,358 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 29,179
females age 1 8 — 49 : 28,023 (2005 est.)
Military expenditures— percent of
GDP: 1.9% (2005 est.)','fcabcd78571748bc2e8b464578fc303a453bdb2a828525700db72e414a8ddb32','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1efa2cd268b80c583e6ba71a6a24dbc057737c3aa6a164bf919020b7cb660472',2008,'OM','Oman','military-and-security',1155,'Military branches: Royal Omani Armed
Forces: Royal Army of Oman, Royal
Navy of Oman, Royal Air Force of
Oman (Al-Quwwat al-Jawwiya al-
Sultanat Oman, RAFO) (2006)
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military service:
males age 1 8 — 49; 719,871
females age 1 8 — 49: 508,621 (2005 est.)
Manpower fit for military service:
males age 18-49: 581,444
females age 18-49: 435,107 (2005 est.)
Manpower reaching military service
age annually: males age 18-4 9: 26,391
females age 18-49: 25,466 (2005 est.)
Military expenditures— percent of
GDP: 11.4% (2005 est.)','35e47ca79ff54cef7aa67a3d02b55682fafbdad4244f837fe22a226be75c38d9','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78b7e95f1129ef3847a3212cab198640cd5f9bfda8e0db650ef8792fbf89bc54',2008,'PW','Palau','military-and-security',1166,'Military branches: Army (includes
National Guard), Navy (includes Marines
and Maritime Security Agency), Pakistan
Air Force (Pakistan Fiza’ya) (2007)
Military service age and obligation: 16
years of age for voluntary military
service; soldiers cannot be deployed for
combat until age of 18; the Pakistani Air
Force and Pakistani Navy have inducted
their first female pilots and sailors (2006)
Manpower available for military service:
males age 16—19: 39,028,014
females age 16-49: 36,779,584 (2005 est.)
Manpower fit for military service:
males age 16—19: 29,428,747
females age 16-49: 28,391,887 (2005 est.)
Manpower reaching military service
age annually:
males age 18-4 9: 1,969,055
females age 16-49: 1,849,254 (2005 est.)
Military expenditures — percent of
GDP: 3.2% (2006 est.)','1b7f79004c28c8660e6e114ef17a03013bcc8156372c64a5233fa66fb14cfc4b','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('250e6caaa48f99a625b50287c72952a14ee28d9ad5a49edc24b187041b56bd1f',2008,'GN','Guinea','military-and-security',1178,'Military branches: Papua New Guinea
Defense Force (includes Maritime
Operations Element, Air Operations
Element) (2007)
Military service age and obligation: 18
years of age (est.); no conscription
(2001)
Manpower available for military service:
males age 18-49: 1,264,728
females age 18^19: 1,167,188 (2005 est.)
Manpower fit for military service:
males age 1 8 — 49: 902,432
females age 18-49: 894,759 (2005 est.)
Military expenditures— percent of
GDP: 1.4% (2005 est.)','a2ab2232c0da33d8b9d9e5d18ab9f44a144f921c3bf70e43eddd7cc301a4be1c','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ca246fddd6a5ec8bb8d8c73803fd398e416af67e31d636fc144bb3fea9e744a',2008,'PY','Paraguay','military-and-security',1186,'Military — note: occupied by China
Military branches: Army, National
Navy (Armada Nacional, includes Naval
492','4c490abeb8bf92690c488bc7e777fa1313a2d24813763071bab0109d06b6e166','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b6af5bd8dc12a629fa90baf63bb7701c5f9427c4c5ffb2faf3aace970f9ec87',2008,'PE','Peru','military-and-security',1190,'Aviation, Marine Corps, General Naval
Prefecture), Air Force (Fuerza Aerea
Paraguay, FAP) (2006)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 12 months for Army, 24 months
for Navy (2006)
Manpower available for military service:
males age 18-49: 1,345,022
females age 18-49: 1,342,725 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,109,166
females age 18-4 9: 1,135,046 (2005 est.)
Manpower reaching military service
age annually:
males age 18-4 9: 63,058
females age 18-49: 62,217 (2005 est.)
Military expenditures— percent of
GDP: 1% (2006 est.)
Military branches: Peruvian Army
(Ejercito Peruano), Peruvian Navy
(Marina de Guerra del Peru; includes
naval air, naval infantry, and coast
guard), Peruvian Air Force (Fuerza
Aerea del Peru, FAP) (2007)
Military service age and obligation: 18
years of age for compulsory military
service (1999)
Manpower available for military service:
males age 18-4 9: 6,647,874
females age 18—49: 6,544,408 (2005 est.)
Manpower fit for military service:
males age 18-49: 4,938,417
females age 18—49: 5,278,511 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 277,105
females age 18-49: 269,799 (2005 est.)
Military expenditures— percent of
GDP: 1.5% (2006)','1bbe878d67d11cd2b637ef52ac4e7073e2b671f1108bb9128d970b763938be52','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9bcaaaf284ec459402be2dba347ecc1156258780478ac900cb8433b028341f6',2008,'PH','Philippines','military-and-security',1199,'Military branches: Armed Forces of the
Philippines (AFP): Army, Navy
(includes Marine Corps), Philippine Air
Force (Hukbomg Himpapawid ng
Pilipinas) (2006)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service (2001)
Manpower available for military service:
males age 18-49: 20,131,179
females age 18-49: 20,009,526 (2005 est.)
Manpower fit for military service:
males age 18-49: 15,170,096
females age 18-49: 16,931,191 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 907,542
females age 18-49: 878,712 (2005 est.)
Military expenditures— percent of
GDP: 0.9% (2005 est.)
Military — note: defense is the response
bility of the UK _','db61ee3f82351e012c6842a8900d35c96116d9ce664aac3fd7eebed74f2573ea','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ce9f82cd5d111cf0fc22ea3ac11cd2cba9b9146e7ccf763236db2214eface44',2008,'PT','Portugal','military-and-security',1209,'Military branches: Armed Forces of the
Polish Republic (Sily Zbrojne
Rzeczypospolitej Polskiej, SZRP): Land
Forces (includes Navy (Marynarka
Wojenna, MW)), Polish Air Force (Sily
Powietrzne Rzeczypospolitej Polskiej,
SPRP) (2006)
Military service age and obligation: 17
years of age for compulsory military
service after January 1st of the year of
18th birthday; 17 years of age for volun¬
tary military service; in 2005, Poland
plans to shorten the length of conscript
service obligation from 12 to 9 months;
by 2008, plans call for at least 60% of mil¬
itary personnel to be volunteers; only sol¬
diers who have completed their conscript
service are allowed to volunteer for pro¬
fessional service; as of April 2004, women
are only allowed to serve as officers and
noncommissioned officers (2004)
Manpower available for military
service:
males age 17-49: 9,681,703
females age 17-49: 9,480,641 (2005 est.)
Manpower fit for military service:
males age 17-49: 7,739,472
females age 7 7 — 49: 7,859,165 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 275,446
females age 17-49: 265,164 (2005 est.)
Military expenditures— percent of
GDP: 1.71% (2005 est.)
_ _
Military branches: Army, Navy
(Marinha Portuguesa; includes Marine
Corps), Air Force (Forca Aerea Portu-
guesa, FAP), National Republican Guard
(Guarda Nacional Republicana) (2005)
Military service age and obligation: 18
years of age for voluntary military
service; compulsory military service
ended in 2004; women serve in the
armed forces, on naval ships since 1993,
but are prohibited from serving in some
combatant specialties (2005)
Manpower available for military service:
males age 18-49: 2,435,042
females age 18-49: 2,405,816 (2005 est.)
Manpower fit for military service:
males age 18^9: 1,952,819
females age 18-49: 1,977,264 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 67,189
females age 18-49: 60,626 (2005 est.)
Military expenditures— percent of
GDP: 2.3% (2005 est.)','04118754e33d5db51934fd14e247d737b58bcecc3ae3298c75f83d9d334861cf','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44b220752f5a714159506b949c5a8d96a977f9606cf452d80ef9fbf6ceb43158',2008,'PR','Puerto Rico','military-and-security',1221,'Military branches: no regular indige¬
nous military forces; paramilitary
National Guard, Police Force
Military — note: defense is the responsi¬
bility of the US','acb6f7fd066f081d769e27d83add33c32b04fd14c24451e677b1555e41a8c2a3','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02bf5a618972a9c3df77a318f26bb9a1cce96e3f56389ea80c92bb490591a181',2008,'QA','Qatar','military-and-security',1229,'Military branches: Qatari Amiri Land
Force (QALF), Qatari Amiri Navy
(QAN), Qatari Amiri Air Force
(QAAF) (2007)
Military service age and obligation: 18
years of age for voluntary military
service; land forces enlisted personnel
are largely unprofessional foreign
nationals (2005)
Manpower available for military service:
males age 18—49: 302,873
females age 18-49: 137,856 (2005 est.)
Manpower fit for military service:
males age 18—49: 238,566
females age 18-49: 116,595 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 7,851
females age 18—49: 7,040 (2005 est.)
Military expenditures— percent of
GDP: 10% (2005 est.)','6fc2cf4c53e88b5c3a54022e97812a0d7aea4a3958f00ca3f3ab7bd5d64eb2ab','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ed7313872933ba0963b4f50a2548aca573773f59a2a0b653d253a3823374929',2008,'RW','Rwanda','military-and-security',1241,'Military branches: Rwandan Defense
Forces: Army, Air Force
Military service age and obligation: 16
years of age for voluntary military
service; no conscription (2001)
Manpower available for military
service:
males age 16—49: 2,004,750
females age 16-49: 1,990,935 (2005 est.)
Manpower fit for military service:
males age 16—49: 1,103,823
females age 16-49: 1,096,644 (2005 est.)
Military expenditures— percent of
GDP: 2.9% (2005 est.)','0cdf136aa82039400a173c622014e777053c04efef68b4113317ecaf2724330d','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a20480201c1319a6b9230f84d573c9c17b96be0423d8bcb26ae6f6afcfea39d1',2008,'LC','Saint Lucia','military-and-security',1252,'Military branches: Saint Kitts and Nevis
Defense Force (includes Coast Guard),
Royal Saint Kitts and Nevis Police Force
Military service age and obligation: 18
years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 9,196
females age 18-49: 9,236 (2005 est.)
Manpower fit for military service:
males age 18-49: 7,119
females age 1 8—49 : 7,645 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 357
females age 18-49: 347 (2005 est.)
Military expenditures— percent of
GDP: NA','43fac00009e7621c48aa156ca99748457dd09cb4a4ed8997d17d87c8864605b5','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b8a55784d62ba1ddaffe34f30cf456d3dd9d198137bbe5dab990ff09bf25d68',2008,'PM','Saint Pierre and Miquelon','military-and-security',1260,'Military branches: no regular military
forces; Royal Saint Lucia Police Force
(includes Special Service Unit, Coast
Guard) (2007)
Manpower available for military ser¬
vice: males age 18-49: 42,742 (2005 est.)
Manpower fit for military service: males
age 18-49: 33,539 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 1,651
(2005 est.)
Military expenditures — percent of
GDP: NA','b9aa2a7177405f3ef2b054688f0d9cdeafc04af8228ef133882de35dc2afb211','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d276fd4ee9e30e3b52ee861a57dc5974da748efd853c4f701286c98a0e690452',2008,'SM','San Marino','military-and-security',1284,'Military branches: no regular military
forces; Voluntary Military Force (Corpi
Militari Voluntar) performs ceremonial
duties and limited police functions
(2006)
Manpower available for military ser¬
vice: males age 18-49: 6,331 (2005 est. )
Manpower fit for military service: males
age 18-49: 5,107 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 135
(2005 est.)
Military expenditures — percent of
GDP: NA
Military— note: defense is the responsi¬
bility of Italy','f9ca0fedf5c939fc8103ac1a3ba5fe36e7a32002ce5f12662df74f7651441e92','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87a9f74bb2d896264ff4f4f04d23cd77338b364b3552de32982fd393900a32f2',2008,'SA','Saudi Arabia','military-and-security',1300,'Military branches: Land Forces (Army),
Navy, Air Force, Air Defense Force,
National Guard, Ministry of Interior
Forces (paramilitary)
Military service age and obligation: 18
years of age (est.); no conscription (2004)
Manpower available for military
service:
males age 18-49: 7,648,999
females age 18-49: 5,417,922 (2005 est.)
Manpower fit for military service:
males age 18-49: 6,592,709
females age 18—49: 4,659,347 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 247,334
females age 18-49: 234,500 (2005 est.)
Military expenditures— percent of
GDP: 10% (2005 est.)','16310ffffeb6c49962e7288c4e80b05841be5a9d2357abefc1f6ea70046fc691','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ac24884ea7238c4f59e1f780a70b24c989eb3e4a5767b002b0b94a062bc8e2e',2008,'SN','Senegal','military-and-security',1308,'Military branches: Army, Senegalese
Navy (Marine Senegalaise), Senegalese
Air Force (Armee de l’Air du Senegal)
(2007)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 2 years (2004)
Manpower available for military service:
males age 18—49: 2,443,840
females age 18-49: 2,461,939 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,558,175
females age 18-49: 1,642,533 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 129,331
females age 18-^49: 129,398 (2005 est.)
Military expenditures— percent of
GDP: 1.4% (2005 est.)','44902ff5535b9531643109f67678629ea58442dea2a62c4e3a058f66e33d0647','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1fc9b4f306bd62c48d766a464d6ef29c92c9dcd964c9bdb283ce552c892790f',2008,'RS','Serbia','military-and-security',1316,'Military branches: Serbian Armed
Forces (Vojska Srbije, VS): Land Forces
Command (includes Serbian naval force,
consisting of a river flotilla on the
Danube), Joint Operations Command,
Air and Air Defense Forces Command
(2007)
Military service age and obligation:
peacetime service obligation begins at
age 17 and lasts until age 60 for men and
50 for women; under a state of war or
impending war, the obligation can begin
at age 16 and be extended beyond 60;
conscription is to be abolished in 2010
(2007)','fd598fe93f19d96e54fa8590a6e892c4f0d2ba8b3326f327536af2aaad002a89','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a9601ef56dc4ac85dfc8da0b24e41efd8132dcbe0f215cb315f2f5132cb2d8f',2008,'SL','Sierra Leone','military-and-security',1325,'Military branches: Seychelles Defense
Force: Army, Coast Guard (includes
Naval Wing, Air Wing), National Guard
(2005)
Military service age and obligation: 18
years of age (est.); no conscription (2001)
Manpower available for military service:
males age 18-4 9: 21,612
females age 18-49: 22,459 (2005 est.)
Manpower fit for military service:
males age 18-49: 16,122
females age 18-49: 18,777 (2005 est.)
Military expenditures— percent of
GDP: 2% (2006 est.)','34df6dc0fb1c0b3b5b1a87f352b90726f5a00a5a2cf27d2292ef400d9670353b','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f613bc6c760571efaa0d86294c3c14ad7addaab44becbca4c6c059e01cb39fe',2008,'SG','Singapore','military-and-security',1334,'Military branches: Republic of Sierra
Leone Armed Forces (RSLAF): Army
(includes Air Wing, Maritime Wing)
(2007)
Military service age and obligation: 18
years of age (est.); no conscription
(2001)
Manpower available for military
service: males age 18-49: 1,086,091
(2005 est.)
Manpower fit for military service: males
age 18-49: 539,697 (2005 est.)
Military expenditures— percent of
GDP: 2.3% (2006)','c6f0ef2ac3f37e6b0d3ad7a23cdb6c9be90359534e86ea959ded6af034f68599','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14673aca562b2a6f5f018ee8970a007bba7b19cfce8ddf308844a93b1fcc4f1e',2008,'SI','Slovenia','military-and-security',1345,'Military branches: Armed Forces of the
Slovak Republic (Ozbrojene Sily
Slovenskej Republiky): Land Forces
(Pozemne Sily), Air Forces (Vzdusne
Sily), Training and Support Forces
(Vycviku a Podpory Sily) (2005)
Military service age and obligation:
complete transition to an all-volunteer
professional force went into effect at the
beginning of 2006; volunteers include
women, with minimum age of 17 years
(2005)
Manpower available for military service:
males age 18-49: 1,351,848
females age 1 8 — 49 : 1,322,647 (2005 est.)
Manpower fit for military service:
males age J 8 — 49; 1,089,645
females age 18-49: 1,093,077 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 41,544
females age 1 8 — 49: 40,183 (2005 est.)
Military expenditures — percent of
GDP: 1.87% (2005 est.)','ea9bcdef7d87fcc02c5df3fd09b426841a9f6ae5767bc8a42f6b97d31ceeb730','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ee47670341e6fb83cbd0457f99fca12686fa4928d30776c17b97db337a67d23',2008,'SB','Solomon Islands','military-and-security',1351,'Military branches: Slovenian Army
(includes air and naval forces)
Military service age and obligation: 17
years of age for voluntary military
service; conscription abolished in 2003
(2004)
Manpower available for military service:
males age 17-4 9: 496,929
females age 17-49: 483,959 (2005 est.)
Manpower fit for military service:
males age 17-49: 405,593
females age 17-49: 397,167 (2005 est.)
Manpower reaching military service
age annually:
males age 1 8-49 : 12,816
females age 17-49: 12,178 (2005 est.)
Military expenditures— percent of
GDP: 1.7% (2005 est.)','a4e68c32f0fb096d2343d3c7175a83d3031fc52c3531efe8570ab3d091aaa052','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c16e09fe1ceaaf53901c731947988ecfde11e861603c2adcc646f0293051562',2008,'SO','Somalia','military-and-security',1360,'Military branches: no regular military
forces; Royal Solomon Islands Police
(RSIP)
Manpower available for military serv¬
ice: males age 18-49: 114,253 (2005 est.)
Manpower fit for military service: males
age 1 8—49: 92,796 (2005 est.)
Manpower reaching military service
age annually: males age 18-49: 6,033
(2005 est.)
Military expenditures — percent of
GDP: 3% (2006)
Military branches: there are no national-
level armed forces; numerous factions and
clans maintain independent militias, and
the Somaliland and Puntland regional
governments maintain their own security
and police forces (2007)
Military service age and obligation: 18
years of age (est.) (2001)
Manpower available for military service:
males age 18-49: 1,787,727
females age 18-49: 1,714,792 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,022,360
females age 18—49: 1,038,697 (2005 est.)
Military expenditures— percent of
GDP: 0.9% (2005 est.)','d678eca38d3da13cd6f8fa2953ea713ccf55852f31021ed9dd0ae359093b2f3c','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08ae7cb5db083d11460f2c7132866cd7cd1c16f94f55beee4a4f3ceb3fb6f51e',2008,'GS','South Georgia and the South Sandwich Islands','military-and-security',1366,'Military branches: South African
National Defense Force (SANDF):
South African Army, South African
Navy (SAN), South African Air Force
(SAAF), Joint Operations Command,
Joint Support Command, Military
Intelligence, Military Health Service
(2007)
Military service age and obligation: 18
years of age for voluntary military
service; women have a long history of
military service in noncombat roles
dating back to World War I (2004)
Manpower available for military service:
males age 18-49: 10,354,769
females age 1 8 — 49 ; 10,626,550 (2005
est.)
Manpower fit for military service:
males age 18-49: 4,927,757
females age 18-49: 4,609,071 (2005 est.)
Manpower reaching military service
age annually:
males age i 8 — 49: 512,407
females age 18-49: 506,078 (2005 est.)
Military expenditures— percent of
GDP: 1.7% (2006)
Military — note: with the end of
apartheid and the establishment of
majority rule, former military, black
homelands forces, and ex-opposition
forces were integrated into the South
African National Defense Force
(SANDF); as of 2003 the integration
process was considered complete
Military note: defense is the responsi¬
bility of the UK','6fc81c6168179307c9a9600e141a86058797f24d95bf93271ad71a8a76235e69','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34e8e08f37180426aa81cf38d7dde90093a1458e1ae32f44ebe4763fbc2de726',2008,'ES','Spain','military-and-security',1381,'Military branches: Spanish Armed
Forces: Army (Ejercito de Tierra),
Spanish Navy (Armada Espanola, AE;
includes Marine Corps), Spanish Air
Force (Ejercito del Aire Espanola, EdA)
(2006)
Military service age and obligation: 20
years of age (2004)
Manpower available for military service:
males age 20-49: 9,366,588
females age 20-4 9: 9,155,057 (2005 est.)
Manpower fit for military service:
males age 20-49: 7,623,356
females age 20-49: 7,434,465 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 233,384
females age 20-49: 221,805 (2005 est.)
Military expenditures— percent of
GDP: 1.2% (2005 est.)
Military— note: Spratly Islands consist
of more than 100 small islands or reefs of
which about 45 are claimed and occu¬
pied by China, Malaysia, the Philippines,
Taiwan, and Vietnam
Military branches: Trinidad and Tobago
Defense Force: Ground Force, Coast
Guard (includes air wing) (2004)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2001)
Manpower available for military service:
males age 18-49: 290,715
females age 18-49: 258,410 (2005 est.)
Manpower fit for military service:
males age 18—49: 202,958
females age 18—49: 1 7 3,79 r (2005 est.)
Military expenditures — percent of
GDP: 0.3% (2006)','27bd55aa57819c481641821d31815a9f8dd52d5db939ee0f6b1cd36edf032a4e','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8548bb6d2c12c46c1a5c75be18d3320e07d44fe4180e396d2867b3f7ed953e7',2008,'SD','Sudan','military-and-security',1388,'Military branches: Sri Lankan Army, Sri
Lankan Navy, Sri Lankan Air Force
(2006)
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military service:
males age 18-A9: 4,933,217
females age 18-49: 5,153,597 (2005 est.)
Manpower fit for military service:
males age 18-4 9: 3,789,627
females age 18-49: 4,281,043 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 174,049
females age 18-49: 167,201 (2005 est.)
Military expenditures— percent of
GDP: 2.6% (2006)
Military branches: Sudanese People’s
Armed Forces (SPAF): Land Forces,
Navy, Air Force, Popular Defense Forces
(2007)
Military service age and obligation:
18-30 years of age for compulsory mili¬
tary service; conscript service obliga¬
tion — 3 years (2004)
Manpower available for military service:
males age 18-49: 8,291,695
females age 18-49: 8,135,683 (2005 est.)
Manpower fit for military service:
males age 18-49: 5,427,474
females age 18-49: 5,649,566 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 442,915
females age 18-49: 426,320 (2005 est.)
Military expenditures— percent of
GDP: 3% (2005 est.)','a7b57253f0797bc9bc8f3c489b34fdaf31593ba905657b5fb6b6c192645aa785','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e82693b439e43a1d94551b7b40bb9add3ce73a23959b0a3a47fb9e2f44d4bf9c',2008,'SR','Suriname','military-and-security',1398,'Military branches: National Army
(includes Naval Wing, Air Wing) (2007)
Military service age and obligation: 18
years of age (est.); no conscription
Manpower available for military service:
males age 18—49: 111,582
females age 1 8-49 : 1 03 , 7 69 (2005 est. )
Manpower fit for military service:
males age 1 8 — 49 ; 77,793
females age 18—49: 72,943 (2005 est.)
Military expenditures — percent of
GDP: 0.6% (2006 est.) _
Military — note: demilitarized by treaty
on 9 February 1920','ab061e80194c581964bc3f7023f62fbf348fe6a261347596564d4f61ff1d55ee','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('567ed4c938644dab0ac4c245d2ffd83d4a46a2589d09cace202eaf3a722df2cc',2008,'CH','Switzerland','military-and-security',1410,'Military branches: Swiss Armed Forces:
Land Forces, Swiss Air Force (Schweizer
Luftwaffe); Switzerland has no navy, but
maintains a fleet of military patrol boats
to patrol Swiss borders (2006)
Military service age and obligation: the
Swiss Constitution states that “every
Swiss male is obliged to do military
service”; every Swiss male has to serve
for at least 260 days in the armed forces;
19 years of age for compulsory military
service; 1 7 years of age for voluntary mil¬
itary service; conscripts receive 15 weeks
of compulsory training, followed by 10
intermittent recalls for training over the
next 22 years; women are accepted on a
voluntary basis but are not drafted
(2005)
Manpower available for military service:
males age 19-49: 1,707,694
females age 19-49: 1,662,099 (2005 est.)
Manpower fit for military service:
males age 19-49: 1,375,889
females age 19-49: 1,342,945 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 46,319
females age 19—49: 43,829 (2005 est.)
Military expenditures — percent of
GDP: 1% (2005 est.)
Military branches: Syrian Armed
orces. Syrian Arab Army (includes
606
SYRIA
Syrian Arab Navy), Syrian Arab Air and
Air Defense Force (includes Air Defense
Command) (2005)
Military service age and obligation: 18
years of age for compulsory military
service; conscript service obligation _ 30
months (18 months in the Syrian Arab
Navy); women are not conscripted but
may volunteer to serve (2004)
Manpower available for military service:
males age 18-4 9: 4,356,413
females age 18-49: 4,123,339 (2005 est.)
Manpower fit for military service:
males age 18-49: 3,453,888
females age 18-49: 3,421,558 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 225,113
females age 18-49: 211,829 (2005 est.)
Military expenditures— percent of
GDP: 5.9% (2005 est.)','e06cfd35e89c8c149fc534d7094bb62692b7fbf3342e1559a6bbc897d3bde064','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adad6a96554b9dfef345247b79eecf3fadf27287b699cfa3866e48870ddb9620',2008,'TJ','Tajikistan','military-and-security',1416,'Military branches: Ground Troops, Air
and Air Defense Troops, Mobile Troops
(2005)
Military service age and obligation: 18
years of age for compulsory military
service; conscript service obligation — 2
years (2004)
Manpower available for military service:
males age 18-4 9: 1,556,415
females age 18—4 9: 1,568,780 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,244,941
females age 18—4 9: 1,297,891 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 87,846
females age 18—49: 85,869 (2005 est.)
Military expenditures— percent of
GDP: 3.9% (2005 est.)
Military branches: Tanzanian People’s
Defense Force (Jeshi la Wananchi la
Tanzania, JWTZ): Army, Naval Wing
(includes Coast Guard), Air Defense
Command (includes Air Wing),
National Service (2007)
Military service age and obligation: 15
years of age for voluntary military
service; 18 years of age for compulsory
military service upon graduation from
secondary school; conscript service obli¬
gation — 2 years (2004)
Manpower available for military
service: males age 18-49: 7,422,869
(2005 est.)
Manpower fit for military service: males
age 18-49: 3,879,63 0 (2005 est.)
Military expenditures — percent of
GDP: 0.2% (2005 est.)','d2d75b55a0eddbf97554215f256b6951308ff756d7da8e324a951909e79f141d','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dc7af6c306894f594b8680cc22deff3bf9f1c4ddb65959fe4f4d252fd1e746a',2008,'TG','Togo','military-and-security',1420,'Manpower available for military service:
males age 21-4 9: 14,903,855
females age 21-49: 15,265,854 (2005 est.)
Manpower fit for military service:
males age 21-49: 10,396,032
females age 21-49: 11,487,690 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 526,276
females age 21-49: 514,396 (2005 est.)
Military expenditures— percent of
GDP: 1.8% (2005 est.)
Military branches: Togolese Armed
Forces (FAT): Army, Navy, Air Force,
Gendarmerie (2005)
Military service age and obligation: 18
years of age for voluntary and compulsory
military service (2001)
Manpower available for military service:
males age 18—49: 1,102,661
females age 18—49: 1,124,463 (2005 est.)
Manpower fit for military service:
males age 18—49: 696,933
females age 18—49: 707,821 (2005 est.)
Military expenditures— percent of
GDP: 1.6% (2005 est.)','dc00c237384f799007428311ef3a1c8138574146c5c4273370717e706809fef1','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05135179af2cd3bc3f9bfdeda7d54dbecba8b910f9458068a8f06e6116e30425',2008,'TT','Trinidad and Tobago','military-and-security',1435,'Military branches: Tonga Defense
Services: Land Force (Royal Guard),
Naval Force (includes Royal Marines,
Air Wing) (2006)
Military service age and obligation: 18
years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 25,420
females age 1 8 — 49 : 24,827 (2005 est.)
Manpower fit for military service:
males age 18-49: 19,840
females age 18-49: 21,342 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 1,586
females age 18-49: 1,538 (2005 est.)
Military expenditures— percent of
GDP: 0.9% (2006 est.)','c4ccf5e7a8302b9239d4d71f8f12fd90e8fb3f0eb07003def5e16ec9c8a0e1cd','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f454ebef65d528ad72d5ec4caea7471ca55b8253ed31f7a0e221ae5d2051a02',2008,'TN','Tunisia','military-and-security',1446,'Military branches: Army, Navy,
Republic of Tunisia Air Force (Al-
Quwwat al-Jawwiya al-Jamahiriyah
At’tunisia) (2007)
Military service age and obligation: 20
years of age for compulsory military
service; conscript service obligation — 12
months; 18 years of age for voluntary
military service (2006)
Manpower available for military service:
males age 20-49: 2,441,741
females age 20-49: 2,406,362 (2005 est.)
Manpower fit for military service:
males age 20—49: 2,035,431
females age 20-49: 2,000,757 (2005 est.)
Manpower reaching military service
age annually:
males age 18—49: 108,817
females age 20-49: 103,087 (2005 est.)
Military expenditures — percent of
GDP: 1.4% (2006)
Military branches: Turkish Armed
Forces (TSK): Land Forces, Turkish
Naval Forces (Turk Deniz Kuvvetleri,
TDK; includes naval air and naval
infantry), Turkish Air Force (Turk Hava
Kuvvetleri, THK) (2006)
Military service age and obligation: 20
years of age (2004)
Manpower available for military service:
males age 20-49: 16,756,323
females age 20-49: 16,051,706 (2005
est.)
Manpower fit for military service:
males age 20^19: 13,905,901
females age 20-49: 13,335,812 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 679,734
females age 20-A 9: 659,090 (2005 est.)
632','92f4e8ccd8f9a8e617550174168e21fbc82cdda927da0ffb084674459d6c0031','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67aae9101769b4e6e66ce1c07635322ecef66e18944d55161abf101ba963a616',2008,'UA','Ukraine','military-and-security',1470,'Military branches: Uganda Peoples
Defense Force (UPDF): Army (includes
Marine Unit), Air Force (2007)
Military service age and obligation: 18
years of age for compulsory and voluntary
military duty; the government has stated
that recruitment below that age could
occur with proper consent and that “no
person under the apparent age of 13 years
shall be enrolled in the armed forces”
Manpower available for military service:
males age 18-49: 5,012,620
females age 18-49: 4,855,858 (2005 est.)
Manpower fit for military service:
males age 18—49: 2,889,808
females age 18-49: 2,780,135 (2005 est.)
Military expenditures— percent of
GDP: 2.2% (2006)','389cb67a7193a7e3923f2aa277b104d1b076d805a8e4a97341e60253fdd2905c','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b62f094850274ca50d66f865f15ed153d98d682db8760dcb15db78f942b180bd',2008,'AE','United Arab Emirates','military-and-security',1476,'Military branches: Ground Forces,
Naval Forces, Air Forces (Viyskovo-
Povitryani Syly), Air Defense Forces
(2002)
Military service age and obligation:
18-25 years of age for compulsory and
voluntary military service; conscript
service obligation — 18 months for Army
and Air Force, 24 months for Navy
(2004)
Manpower available tor military service:
males age 18-49: 11,020,222
females age 18-4 9: 11,370,687 (2005 est.)
Manpower fit for military service:
males age 18—49: 7,376,050
females age 18-49: 9,313,385 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 382,751
females age 18-4 9: 365,599 (2005 est.)
Military expenditures — percent of
GDP: 1.4% (2005 est.)
Military branches: Army, Navy (in¬
cludes Marines and Coast Guard), Air
and Air Defense Force, paramilitary
forces (includes Federal Police Force)
Military service age and obligation: 18
years of age (est.); no conscription
(2001)
Manpower available for military service:
males age 18-49: 653,181
females age 18-49: 497,394 (includes
non-nationals; 2005 est.)
Manpower fit for military service:
males age i 8 — 49 : 526,671
females age 18—49: 419,975 (2005 est.)
Manpower reaching military service
age annually:
males: 30,706
females age 18-49: 29,617 (2005 est.)','c57c77ab750f49a702a4f81f9286bc356c2575c163c2a6ba6891a8ae7515a8d6','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b51850a2645cad1cb4fa0dd13104bb7fe2efad42d3da8ac9bfbf0feec8673f8',2008,'GB','United Kingdom','military-and-security',1482,'\\
the United Kingdom of Great Britain
and Ireland played a leading role in
developing parliamentary democracy
and in advancing literature and science.
Military expenditures— percent of
GDP: 3.1% (2005 est.)
Military branches: Army, Royal Navy
(includes Royal Marines), Royal Air Force
Military service age and obligation: 16
years of age for voluntary military service;
women serve in military services, but are
excluded from ground combat positions
and some naval postings (2004)
Manpower available for military service:
males age 16-49: 14,607,724
females age 16-49: 14,028,738 (2005 est.)
Manpower fit for military service:
males age 16—49: 12,046,268
females age 16-49: 11,555,893 (2005 est.)
Military expenditures— percent of
GDP: 2.4% (2005 est.)','68255f4d0eba6085082bb93d5ba7c9c59cf60a97b44ae62bc777be802e37ffe2','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10e3f792cda7012720059e557ea61228a22db604a08c6dc7cd57070ffc6b43cb',2008,'US','United States','military-and-security',1497,'Military branches: Army, Navy and
Marine Corps, Air Force, and Coast
Guard; note — Coast Guard administered
in peacetime by the Department of
Homeland Security, but in wartime
reports to the Department of the Navy
Military service age and obligation: 18
years of age; 17 years of age with written
parental consent (2006)
Manpower available for military service:
males age 18-49: 67,742,879
females age 18-49: 67,070,144 (2005 est.)
Manpower fit for military service:
males age 18-49: 54,609,050
females age 18-49: 54,696,706 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 2,143,873
females age 18-49: 2,036,201 (2005 est.)
Military expenditures — percent of
GDP: 4.06% (2005 est.)','05f1c15339fc68390b793b3d5aa77470e96d5755adabd96a6625c7e2882a92b6','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3dddcea52218bfc6a0df2fa2154a171a6fee91dfa6c67534d07909ba9a8c8aa',2008,'UY','Uruguay','military-and-security',1501,'Military — note: defense is the responsi¬
bility of the US
Military branches: Army, Navy (in''
eludes naval air arm, Marines, Maritime
Prefecture in wartime), Air Force (Fuerza
Aerea Uruguaya, FAU) (2006)
Military service age and obligation: 18
years of age for voluntary and compulsory
military service (2001)
Manpower available for military service:
males age 18-49: 764,408
females age 18-49: 760,341 (2005 est.)
Manpower fit for military service:
males age 18-49: 637,445
females age 18-49: 631,046 (2005 est.)
Military expenditures— percent of
GDP: 1.6% (2006)','bbc130d1809b789134c5a066c5bfb6e45b56a449b33ae429f41ff303f225bce5','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('accc5709e14e1c441756c03b47298918f6529d9fef4fbae449a914bce37e370c',2008,'UZ','Uzbekistan','military-and-security',1512,'Military branches: Army, Air and Air
Defense Forces, National Guard
Military service age and obligation: 18
years of age for compulsory military
service; conscript service obligation — 12
months (2004)
Manpower available for military
service:
males age 18-49: 6,340,22 0
females age 18—49: 6,432,072 (2005 est.)
Manpower fit for military service:
males age 18-49: 4,609,621
females age 18-49: 5,383,233 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 324,722
females age 18-49: 317,062 (2005 est.)
Military expenditures— percent of
GDP: 2% (2005 est.)','eb466e1a914f6b468268ef1acf4031fc31a73ec9a75d61689871c78b76cc92a6','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec5868d8ef695db88e511e4488d5e78a0875250b444140d11be4524333c9dfa1',2008,'VU','Vanuatu','military-and-security',1518,'Military branches: no regular military
forces; security forces comprise the
Vanuatu Police Force (VPF) and para¬
military Vanuatu Mobile Force (VMF),
which includes Vanuatu’s naval force,
known as the Police Maritime Wing
(PMW); border security in Vanuatu is
the joint responsibility of the Customs
and Inland Revenue Service, VPF, VMF,
and PMW (2003)
Manpower available for military serv¬
ice: males age 18-49: 50,221 (2005 est.)
Manpower fit for military service: males
age 18-49: 33,837 (2005 est.)
Military expenditures— percent of
GDP: NA','e632b753c6e6bf38b24370f566bc8961b46b693d68cc1624f284eaad83976757','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfcbe43d494052ce5b796f65a274f4cb3b86c69f3872e4f28fcb24040188c5c0',2008,'YE','Yemen','military-and-security',1531,'Military branches: Army (includes
Republican Guard), Navy (includes
Marines), Yemen Air Force (includes Air
Defense Force) (2007)
Military service age and obligation: in
May 2001, Yemen’s National Defense
Council abolished compulsory military
service and authorized a voluntary pro¬
gram for military service (2004)
Manpower available for military service:
males age 18-49: 4,058,223
females age 18-49: 3,868,112 (2005 est.)
Manpower fit for military service:
males age 18-49: 2,790,705
females age 18-49: 2,792,406 (2005 est.)
Manpower reaching military service
age annually:
males age 1 8-49 : 236,5 1 7
females age 18-49: 230,641 (2005 est.)
Military expenditures— percent of
GDP: 6.6% (2006)
Military — note: a Coast Guard was
established in 2002','fd294cb27c1c4be9f7e2661fe503c219135886579bba8831d64651c22a77de9f','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35d8af4a563bb1dea126af2b9b5e7f24953b58455a28f492aad1ee8397365030',2008,'ZM','Zambia','military-and-security',1537,'Military branches: Zambian National
Defense Force (ZNDF): Army, Air Force,
Police, National Service
Military service age and obligation: 18
years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 2,219,739
females age 18-49: 2,159,688 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,043,702
females age 18-49: 953,328 (2005 est.)
Military expenditures— percent of GDP:
1.8% (2005 est.)','e460f27f0e3745b265c47ea2511baabe347ba002929563067b124c1133bc0dfb','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba0c795eda2041e0948dad6f91a86dc4a25322c6c03e36e69b813f8ce8e4d8e0',2008,'ZW','Zimbabwe','military-and-security',1545,'Military branches: Zimbabwe Defense
Forces (ZDF): Zimbabwe National Army,
Air Force of Zimbabwe (AFZ),
Zimbabwe Republic Police (2005)
Military service age and obligation: 18
years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 2,778,404
females age 18-49: 2,681,531 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,304,424
females age 18-49: 1,115,096 (2005 est.)
Military expenditures— percent of
GDP: 3.8% (2006)
Military branches: Army, Navy (in¬
cludes Marine Corps), Air Force, Coast
Guard Administration, Armed Forces
Reserve Command, Combined Service
Forces Command, Armed Forces Police
Command
Military service age and obligation:
19-35 years of age for military service;
service obligation 16 months (to be
shortened to 14 months as of July 2007
and to 12 months in 2008); women in
Air Force service are restricted to non¬
combat roles (2007)
Manpower available for military service:
males age 19-49: 5,883,828
698
EUROPEAN UNION
females age 2 9—49; 5,680,773 (2005 est.)
Manpower fit for military service:
males age 19-49: 4,749,537
females age 19-4 9: 4,644,607 (2005 est.)
Manpower reaching military service
age annually:
males age 18-49: 174,173
females age 19-49: 163,683 (2005 est.)
Military expenditures-— percent of
GDP: 2.2% (2006; to increase to 2.85%
in 2007)
Military — note: In November 2004, the
EU heads of government signed a “Treaty
Establishing a Constitution for Europe”
that offers possibilities for increased
defense and security cooperation. If rati¬
fied, this treaty will give operational
effect to the European Security and
Defense Policy (ESDP), approved in the
2000 Nice Treaty. Despite limits of coop¬
eration for some EU members, develop¬
ment of a EU military planning unit is
likely to continue. The planning unit
will support the EU Rapid Fraction
Force, which EU ministers have said will
deploy 2 “battle groups” in January 2007.
France, Germany, Belgium, Netherlands,
Luxembourg, and Italy continue to press
for wider coordination. The 5 -nation
Eurocorps — created in 1992 by France,
Germany, Belgium, Spain, and
Luxembourg — has already deployed
troops and police on peacekeeping mis¬
sions to Bosnia-Herzegovina,
Macedonia, and the Democratic
Republic of the Congo and assumed
command of the ISAF in Afghanistan in
August 2004- Eurocorps directly com¬
mands the 5,000-man Franco-German
Brigade, the Multinational Command
Support Brigade, and EUFOR, which
took over from SFOR in Bosnia in
December 2004- Individual EU nations
made commitments to provide 67,100
troops following the December 1999 EU
summit in Helsinki. Some 56,000 troops
from EU member states were actually
deployed on various international opera¬
tions in 2003. In August 2004, the new
European Defense Agency, tasked with
promoting cooperative European defense
capabilities, began operations. In
November 2004, the EU Council of
Ministers formally committed to creating
13 1, 500-man battle groups by the end of
2007, to respond to international crises
on a rotating basis. Twenty-two of the
EU’s 25 nations have agreed to supply
702
EUROPEAN UNION
troops. France, Italy, and the UK formed
the first of 3 battle groups in 2005. In
May 2005, Norway, Sweden and Finland
agreed to establish one of the battle
groups, possibly to include Estonia forces.
The remaining 9 groups are to be formed
in 2007. A rapid-reaction naval EU
Maritime Task Group was stood up in
March 2007. (2005)','c0f8f73ddedc7444b58cb9850da2b573ea24d55eb8ad7c062007da18431f07b1','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c5db22720ebe0ef40b004e840a5bd9508734a25005163acb3f1ef79682f74e2',2008,'EH','Western Sahara','military-and-security',22,'Military branches
Military service age and obligation
Manpower available for militarily significant
males
females
Manpower fit for military service
males
females
Manpower reaching militarily significant
age annually
males
females
Military expenditures - percent of GDP
Military - note
Military expenditures - percent of GDP: roughly
2% of gross world product (2005 est.)','d65d6649782fbb0ee90718c5c2d75685fa80c22df35eab7fa1f2535e7262a001','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('171e994b3c05160f4c444b75bf97d53e4c5d5ce0c67e62f48ef994b29eba82ca',2008,'AF','Afghanistan','military-and-security',32,'Military branches: Afghan Armed Forces: Afghan
National Army (ANA, includes Afghan National Army
Air Corps) (2008)
Military service age and obligation: 22 years of
age; inductees are contracted into service for a 4-year
term (2005)
Manpower available for military service:
males age 16-49:7,431,147
females age 16-49: 7,004,819 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,234,180
females age 16-49: 3,946,685 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 371 ,451
females age 16-49: 351 ,295 (2008 est.)
Military expenditures - percent of GDP: 1 .9%
(2006 est.)
7
Afghanistan (continued)
Military - note: Akrotiri has a full RAF base,
Headquarters for British Forces on Cyprus, and
Episkopi Support Unit
8','fda57cb8c3e46b6a49f2dffe440dcd91ef9200b47d4b31f0417b2a79b647bf29','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d2ace007e413bde8f15cdfcb4f6d6b773b3c4554417121eddd2868a4bfdcdf7',2008,'AL','Albania','military-and-security',34,'Background: Albania declared its independence
from the Ottoman Empire in 1 91 2, but was conquered
by Italy in 1939. Communist partisans took over the
country in 1 944. Albania allied itself first with the
USSR (until 1960), and then with China (to 1978). In
the early 1990s, Albania ended 46 years of
xenophobic Communist rule and established a
multiparty democracy. The transition has proven
challenging as successive governments have tried to
deal with high unemployment, widespread corruption,
a dilapidated physical infrastructure, powerful
organized crime networks, and combative political
opponents. Albania has made progress in its
democratic development since first holding multiparty
elections in 1991, but deficiencies remain.
International observers judged elections to be largely
free and fair since the restoration of political stability
following the collapse of pyramid schemes in 1 997. In
the 2005 general elections, the Democratic Party and
its allies won a decisive victory on pledges of reducing
crime and corruption, promoting economic growth,
and decreasing the size of government. The election,
and particularly the orderly transition of power, was
considered an important step forward. Although
Albania’s economy continues to grow, the country is
still one of the poorest in Europe, hampered by a large
informal economy and an inadequate energy and
transportation infrastructure. Albania has played a
largely helpful role in managing inter-ethnic tensions
in southeastern Europe, and is continuing to work
toward joining NATO and the EU. Albania, with troops
in Iraq and Afghanistan, has been a strong supporter
of the global war on terrorism.
Military branches: Land Forces Command (Army),
Naval Forces Command, Air Defense Command,
General Staff Fleadquarters (includes Logistics
Command, Training and Doctrine Command) (2007)
Military service age and obligation: 1 9 years of
age (2004)
Manpower available for military service:
males age 16-49: 944,592
females age 16-49: 908,527 (2008 est.)
Manpower fit for military service:
males age 16-49: 798,454
females age 16-49: 767,143 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 36,340
females age 16-49: 33,077 (2008 est.)
Military expenditures - percent of GDP:
1.49% (2005 est.)','2adc07697dfa5132aff6d9b62708b298252ed1c834e69162c5fb6dffcf2f2706','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a534176635bfb981201abbc9e90f28d0342e56cd91f3ef808086e64d511a23d',2008,'DZ','Algeria','military-and-security',49,'Military branches: National Popular Army (ANP;
includes Land Forces), Algerian National Navy (MRA),
Air Force (QJJ), Territorial Air Defense Force (2005)
Military service age and obligation: 1 9-30 years of
age for compulsory military service; conscript service
obligation - 18 months (6 months basic training, 12
months civil projects) (2006)
Manpower available for military service:
males age 16-49: 9,736,757
females age 16-49: 9,590,978 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,141 ,864
females age 16-49: 8,215,895 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 374,365
females age 16-49: 360,942 (2008 est.)
Military expenditures - percent of GDP: 3.3%
(2006)
Military branches: Spanish Armed Forces: Army
(Ejercito de Tierra), Spanish Navy (Armada Espanola,
AE; includes Marine Corps), Spanish Air Force
(Ejercito del Aire Espanola, EdA) (2007)
Military service age and obligation: 20 years of
age (2004)
Manpower available for military service:
males age 16-49: 10,033,069
females age 16-49: 9,764,937 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,228,426
females age 16-49: 7,990,678 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 203,650
females age 16-49: 191,352 (2008 est.)
Military expenditures - percent of GDP: 1 .2%
(2005 est.)
Spratly Islands
Northeast Cay
Southwest Cay O''
West York
Island
Thitu Island Flat
.... Island
Loaita Nan^_ —Lankiam Cay
Sand Cay*. Loaita Island \\
Itu Aba Island ''Eldad Reef /\\y anshan
^ Nanny it island
Island
Fiery Cross
Reef
Sin Cowe —
Island
Mischief
Reef
Spratly
Island
Alison
Reef
Pigeon Reef
Half ^
Moon
Shoal
Amboyna
Cay
O 50 lOO km
0 50
100 mi
Military - note: Spratly Islands consist of more than
100 small islands or reefs of which about 45 are
claimed and occupied by China, Malaysia, the
Philippines, Taiwan, and Vietnam','3e5e5896e0c477812b40a9cd3c84a389ddf3fa7ffb2dad215b0d1c21faa8ce41','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4f3da6c7cbff5d519776339c136503e8dd00683e43a1eb750615d31d044cc8b',2008,'NZ','New Zealand','military-and-security',59,'Military - note: defense is the responsibility of the US
Military branches: no regular military forces;
National Police Department (2007)
Military - note: defense is the responsibility of New
Zealand, in consultation with the Cook Islands and at
its request
Military branches: New Zealand Defense Force
(NZDF): New Zealand Army, Royal New Zealand
Navy, Royal New Zealand Air Force (2008)
Military service age and obligation: 17 years of
age for voluntary military service; soldiers cannot be
deployed until the age of 18; no conscription (2008)
Manpower available for military service:
males age 16-49: 1,009,298
females age 16-49: 997,134 (2008 est.)
Manpower fit for military service:
males age 16-49: 833,073
females age 16-49: 822,807 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 31,834
females age 16-49: 30,243 (2008 est.)
Military expenditures - percent of GDP: 1%
(2005 est.)
Military branches: no regular military forces; Samoa
Police Force (2008)
Manpower available for military service:
males age 16-49: 53,417 (2008 est.)
Manpower fit for military service:
males age 16-49: 42,359 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 2,571 (2008 est.)
Military expenditures - percent of GDP: NA
Military - note: Samoa has no formal defense
structure or regular armed forces; informal defense
ties exist with NZ, which is required to consider any
Samoan request for assistance under the 1 962 T reaty
of Friendship
Military branches: Tonga Defense Services (TDS):
Land Force (Royal Guard), Naval Force (includes
Royal Marines, Air Wing) (2008)
Military service age and obligation: 1 8 years of
age (est.); no conscription (2008)
Manpower available for military service:
males age 16-49: 32,053
females age 16-49: 30,981 (2008 est.)
Manpower fit for military service:
males age 16-49: 25,520
females age 16-49: 26,893 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 ,464
females age 16-49: 1 ,412 (2008 est.)
Military expenditures - percent of GDP: 0.9%
(2006 est.)
Military - note: defense is the responsibility of','44a623ceb99d41e91aa3a21ac58f8f2f22129c96b13cc982f1b8da6de0ec5ddb','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ac45bc13dd024fc7e7e3935ecf2350df9ec86ebf9e0c9536698fee561e52c85',2008,'AD','Andorra','military-and-security',67,'Military branches: no regular military forces, Police
Service of Andorra
Manpower available for military service:
males age 16-49: 18,685 (2008 est.)
Manpower fit for military service:
males age 16-49: 14,976 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 372 (2008 est.)
Military - note: defense is the responsibility of
France and Spain','ef0e2f72ff2db3e19132b2310fc805d0276c3b084b7f8094e0e8e9f7ebd427dc','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc5a5cac0ff5d69aa7eff9b74a4b1b146159dfd7d335da1f7b4826ff446e9a60',2008,'AO','Angola','military-and-security',75,'Military branches: Angolan Armed Forces (FAA):
Army, Navy (Marinha de Guerra, MdG), Angolan
National Air Force (FANA) (2007)
Military service age and obligation: 1 7 years of
age for compulsory military service; conscript service
obligation - 2 years plus time for training (2001 )
Manpower available for military service:
males age 16-49: 2,856,492
females age 16-49: 2,755,864 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,430,658
females age 16-49: 1 ,371 ,689 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 142,791
females age 16-49: 139,539 (2008 est.)
Military expenditures - percent of GDP:
5.7% (2006)','d55546368c7db1aecf4a3402923f1f50c0ca2bdc51b3aa282355dfb6915bd859','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('212f1aa070924b85e35f1d10365d349a73c95533f9880089e9511c98bcb172b8',2008,'PR','Puerto Rico','military-and-security',85,'Manpower available for military service:
males age 16-49: 3,538 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,929 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 103 (2008 est.)
Military - note: defense is the responsibility of the
UK
Military branches: Portuguese Army (Exercito
Portugues), Portuguese Navy (Marinha Portuguesa;
includes Marine Corps), Portuguese Air Force (Forca
Aerea Portuguesa, FAP) (2008)
Military service age and obligation: 1 8 years of
age for voluntary military service; compulsory military
service ended in 2004; women serve in the armed
forces, on naval ships since 1993, but are prohibited
from serving in some combatant specialties (2005)
Manpower available for military service:
males age 16-49: 2,573,913
females age 16-49: 2,498,262 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,099,647
females age 16-49: 2,060,559 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 64,910
females age 16-49: 58,599 (2008 est.)
Military expenditures - percent of GDP: 2.3%
(2005 est.)
Military - note: defense is the responsibility of the US','234f3c171a3c36c81405b506f0f782852a01352b5239d6c0a0053f7ab5710acd','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c0b3c41dfb7cffc43ec4b54414e865775cdd1bf6340ef71ae719f00b3324dc4',2008,'AQ','Antarctica','military-and-security',95,'Military - note: the Antarctic Treaty prohibits any
measures of a military nature, such as the
establishment of military bases and fortifications, the
carrying out of military maneuvers, or the testing of
any type of weapon; it permits the use of military
personnel or equipment for scientific research or for
any other peaceful purposes','d38129c9330478dfaee85c66ef6a783804a8fd9f255b9fe12b862bff96282152','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9410460bcc504be93f0d3ed9f5b3776cf7a0268742473e91210e7602b914f36',2008,'AG','Antigua and Barbuda','military-and-security',104,'Military branches: Royal Antigua and Barbuda
Defense Force (2007)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
mates age 16-49: 19,560
females age 16-49: 18,977 (2008 est.)
Manpower fit for military service:
mates age 16-49: 15,591
females age 16-49: 15,542 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 627
females age 16-49: 609 (2008 est.)
Military expenditures - percent of GDP: NA','2897aca03564c0bba98f65d2e5dd8b3a2d8470f1d67cfcc4dbe41a9547c208fb','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18f7ca7e255e5f15e636ce5bbee226bc6ecd9e9084da09c5bba0297b48e81b2c',2008,'AR','Argentina','military-and-security',112,'Military branches: Argentine Army (Ejercito
Argentino), Navy of the Argentine Republic (Armada
Republica; includes naval aviation and naval
infantry), Argentine Air Force (Fuerza Aerea
Argentina, FAA) (2008)
Military service age and obligation: 1 8-24 years of
age for voluntary military service (18-21 requires
parental permission); no conscription (2001)
Manpower available for military service:
males age 16-49: 10,029,488
females age 16-49: 9,889,002 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,352,147
females age 16-49: 8,366,781 (2008 est.)
31
Argentina (continued)
Manpower reaching militarily significant age
annually:
males age 16-49: 350,040
females age 16-49: 334,830 (2008 est.)
Military expenditures - percent of GDP:
1.3% (2005 est.)
Military - note: the Argentine military is a
well-organized force constrained by the country’s
prolonged economic hardship; the country has
recently experienced a strong recovery, and the
military is implementing a modernization plan aimed at
making the ground forces lighter and more
responsive (2008)
Military branches: Army, National Navy (Armada
Nacional, includes Naval Aviation, Marine Corps,
General Naval Prefecture), Air Force (Fuerza Aerea
Paraguay, FAP) (2008)
Military service age and obligation: 1 8 years of
age for compulsory and voluntary military service;
conscript service obligation - 12 months for Army, 24
months for Navy (2006)
Manpower available for military service:
males age 16-49: 1,589,873
females age 16-49: 1,585,573 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,327,730
females age 16-49: 1,356,989 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 72,109
females age 16-49: 70,509 (2008 est.)
Military expenditures - percent of GDP: 1%
(2006 est.)','67eec15680b20998c86dd73720579a8238273de5935184c15f230ca76537bbb1','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('803d41476651773dec7f8032c833179c8d4b8fb3229bf88216e7eac25a2ec9dd',2008,'AM','Armenia','military-and-security',121,'Military branches: Armed Forces: Ground Forces,
Nagorno-Karabakh Self Defense Force (NKSDF), Air
Force and Air Defense (2008)
Military service age and obligation: 1 8-27 years of
age for compulsory military service; 18 years of age
for voluntary military service; 2-year conscript service
obligation (2006)
Manpower available for military service:
males age 16-49: 809,576
females age 16-49: 870,864 (2008 est.)
Manpower fit for military service:
males age 16-49: 637,776
females age 16-49: 729,846 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 30,548
females age 16-49: 29,1 70 (2008 est.)
Military expenditures - percent of GDP:
6.5% (FY01)
34
Armenia (continued)','0f22f046a8f68760e5456ad40f61d2d140a1046d7114682c410ac549c7f43498','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e1bf582a0fa619f3a43607f43ab1c3c68e3a63211f138d7eaa193fc472e93da',2008,'NL','Netherlands','military-and-security',131,'Military branches: no regular indigenous military
forces; the Netherlands maintains a detachment of
marines, a frigate, and an amphibious combat
detachment in the neighboring Netherlands Antilles
(2008)
Manpower available for military service:
males age 16-49: 24,585
females age 16-49: 25,742 (2008 est.)
Manpower fit for military service:
males age 16-49: 20,173
females age 16-49: 21 ,062 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 705
females age 16-49: 719 (2008 est.)
Military - note: defense is the responsibility of the
Kingdom of the Netherlands
Military branches: Royal Netherlands Army, Royal
Netherlands Navy (includes Naval Air Service and
Marine Corps), Royal Netherlands Air Force
(Koninklijke Luchtmacht, KLu), Royal Military Police
(2008)
Military service age and obligation: 20 years of
age for an all-volunteer force (2004)
Manpower available for military service:
males age 16-49: 3,950,825
females age 16-49: 3,850,800 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,233,773
females age 16-49: 3,150,790 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 105,735
females age 16-49: 100,747 (2008 est.)
Military expenditures - percent of GDP: 1 .6%
(2005 est.)
Military branches: no regular military forces;
National Guard (2008)
Military service age and obligation: 16 years of
age for National Guard recruitment; no conscription
(2004)
Manpower available for military service:
males age 16-49: 55,365
females age 16-49: 57,060 (2008 est.)
Manpower fit for military service:
males age 16-49: 46,102
females age 16-49: 47,219 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 ,855
females age 16-49: 1 ,760 (2008 est.)
Military - note: defense is the responsibility of the
Kingdom of the Netherlands','be47105de531ae9276a4605862ef262a44115b2a6dcc8b8f96a32eb0bc395bf5','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7fd1635b57e6705bc79ae90bbcacc71ccb7f6b0dfb7c71be6343cf7ac5b8374',2008,'AU','Australia','military-and-security',141,'Military - note: defense is the responsibility of
Australia; periodic visits by the Royal Australian Navy
and Royal Australian Air Force
Military - note: defense is the responsibility of
Military branches: Indonesian Armed Forces
(Tentara Nasional Indonesia, TNI): Army
(TNI-Angkatan Darat (TNI-AD)), Navy (TNI-Angkatan
Laut (TNI-AL); includes marines, naval air arm), Air
Force (TNI-Angkatan Udara (TNI-AU)), National Air
Defense Command (Kommando Pertahanan Udara
Nasional (Kohanudnas)) (2008)
Military service age and obligation: 18 years of
age for selective compulsory and voluntary military
service; 2-year conscript service obligation, with
reserve obligation to age 45 (2006)
Manpower available for military service:
males age 16-49: 63,800,825
females age 16-49: 61,729,717 (2008 est.)
277
Indonesia (continued)
Manpower fit for military service:
males age 16-49: 52,367,788
females age 16-49: 52,129,123 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 2,1 81 ,303
females age 16-49: 2,1 10,397 (2008 est.)
Military expenditures - percent of GDP: 3%
(2005 est.)
Military branches: Islamic Republic of Iran Regular
Forces (Artesh): Ground Forces, Navy, Air Force of
the Military of the Islamic Republic of Iran (Niru-ye
Hava’i-ye Artesh-e Jomhuri-ye Eslami-ye Iran;
includes air defense); Islamic Revolutionary Guard
Corps (Sepah-e Pasdaran-e Enqelab-e Eslami,
IRGC): Ground Forces, Navy, Air Force, Qods Force
(special operations), and Basij Force (Popular
Mobilization Army); Law Enforcement Forces (2008)
Military service age and obligation: 19 years of
age for compulsory military service; 16 years of age
for volunteers; 17 years of age for Law Enforcement
Forces; 15 years of age for Basij Forces (Popular
Mobilization Army); conscript military service
obligation - 18 months; women exempt from military
service (2008)
Manpower available for military service:
males age 16-49: 20,212,275
females age 16-49:19,638,751 (2008 est.)
Manpower fit for military service:
mates age 16-49: 17,416,126
females age 16-49: 16,928,226 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 766,668
females age 16-49: 727,654 (2008 est.)
Military expenditures - percent of GDP:
2.5% (2006)','fd2911efb2b25b4636e95b18150592c6ad6fe6282d137b02688f018f1763caaa','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5aa735e5ed9bfc514bce4608d1beb269cff089f1ed03052ab4b21734a7a28378',2008,'ID','Indonesia','military-and-security',149,'Military branches: Australian Defense Force
(ADF): Australian Army, Royal Australian Navy,
Royal Australian Air Force, Special Operations
Command (2006)
Military service age and obligation: 1 7 years of
age for voluntary military service (with parental
consent); no conscription; women allowed to serve in
Army combat units in non-combat support roles (2008)
Manpower available for military service:
males age 16-49: 4,999,988
females age 16-49: 4,870,043 (2008 est.)
Manpower fit for military service:
males age 16-49: 4, 1 37, 1 76
females age 16-49: 4,022,588 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 146,248
females age 16-49: 139,697 (2008 est.)
Military expenditures - percent of GDP:
2.4% (2006)
Military branches: no regular military forces
Manpower available for military service:
males age 16-49: 26,686 (2008 est.)
Manpower fit for military service:
males age 16-49: 21 ,748 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 ,310 (2008 est.)
Military - note: defense is the responsibility of the
US
Military branches: Papua New Guinea Defense
Force (PNGDF; includes Maritime Operations
Element, Air Operations Element) (2008)
Military service age and obligation: 1 6 years of
age for voluntary military service; no conscription
(2008)
Background: The Paracel Islands are surroi
by productive fishing grounds and by potential
gas reserves. In 1932, French Indochina anne:
islands and set up a weather station on Pattle
maintenance was continued by its successor,
Vietnam. China has occupied the Paracel Islai
since 1974, when its troops seized a South
Vietnamese garrison occupying the western is
China built a military installation on Mischief R
1999. The islands are claimed by Taiwan and
Vietnam.
Military branches: Armed Forces of the Philippines
(AFP): Army, Navy (includes Marine Corps and Coast
Guard), Air Force (2008)
Military service age and obligation: 18-25 years of
age (officers 21-29) for compulsory and voluntary
military service; applicants must be single male or
female Philippine citizens (2007)
Manpower available for military service:
males age 16-49: 23,547,252
females age 16-49: 23,177,487 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 8,232,050
females age 16-49: 19,827,538 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 ,003,836
females age 16-49: 968,845 (2008 est.)
Military expenditures - percent of GDP: 0.9%
(2005 est.)','d6d06ccd6d1c9a7e9244b62df05ee1a330ce826895cde30e61decd22528eadb8','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9fbdd2eedef2ced1d419d1cba6e27d1c2ffc62d7654876ec2854cf6faddf231',2008,'AT','Austria','military-and-security',157,'Military branches: Land Forces (KdoLdSK), Air
Forces (KdoLuSK)
Military service age and obligation: 1 8-35 years of
age for compulsory military service; 16 years of age
for male or female voluntary service; service
obligation 7 months of training, followed by an 8-year
reserve obligation (2006)
Manpower available for military service:
males age 16-49: 1 ,986,41 1
females age 16-49: 1 ,944,834 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,617,385
females age 16-49: 1 ,583,886 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 50,869
females age 16-49: 48,246 (2008 est.)
Military expenditures - percent of GDP: 0.9%
(2005 est.)','c8da0aee8d4f7ce58e9124d0b9b810a1def2924428ff35819e9c9b33008e724e','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ec5ceaf5c90d2ca01739fa9ee640813bb82601cb2f67ca03c7362959c66bcaa',2008,'AZ','Azerbaijan','military-and-security',165,'Military branches: Army, Navy, Air and Air Defense
Forces (2008)
Military service age and obligation: men between
18 and 35 are liable for military service; 18 years of
age for voluntary military service; length of military
service is 18 months and 12 months for university
graduates (2006)
Manpower available for military service:
males age 16-49: 2,278,888
females age 16-49: 2,291 ,770 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,696,167
females age 16-49: 1 ,923,556 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 94,402
females age 16-49: 89,686 (2008 est.)
Military expenditures - percent of GDP:
2.6% (2005 est.)','5e437f3747d04df805ddd09e9478d75803596d9e708979b0f8472bf0215853bc','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eccd0a0e3c0b071d7f02c5fd35a003003c966c6fc37228364cacd93035a8d10b',2008,'BS','Bahamas','military-and-security',175,'Military branches: Royal Bahamian Defense Force:
Land Force, Navy, Air Wing (2007)
Military service age and obligation: 1 8 years of
age (est.); no conscription (2008)
Manpower available for military service:
males age 16-49: 80,200 (2008 est.)
Manpower fit for military service:
males age 16-49: 50,282 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 3,016 (2008 est.)
Military expenditures - percent of GDP: 0.5%
(2006)','afc16264053440f5c89ef4771a2cf220de7caa30eed51e1bf9b323d876d53491','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3a0debddd37fe02854473d26216aae00ff64a02def9157ff6cb8f89ce4015d3',2008,'BH','Bahrain','military-and-security',185,'Military branches: Bahrain Defense Forces (BDF):
Ground Force (includes Air Defense), Naval Force, Air
Force, National Guard
Military service age and obligation: 17 years of
age for voluntary military service; 15 years of age for
NCOs, technicians, and cadets; no conscription (2008)
Manpower available for military service:
males age 16-49: 210,938
females age 16-49: 170,471 (2008 est.)
Manpower fit for military service:
males age 16-49: 171,536
females age 16-49: 142,714 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 6,543
females age 16-49: 6,429 (2008 est.)
Military expenditures - percent of GDP: 4.5%
(2006)','c1ed8824dd7b541df3c8423a8a8386b9262dd98e2ac785a18bb6278fbad4b85c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21b2a439a5a6546abcbf6b555ccca0513ba137f8240887e3ed919eb482b92283',2008,'BD','Bangladesh','military-and-security',194,'Military branches: Bangladesh Defense Force:
Bangladesh Army, Bangladesh Navy, Bangladesh Air
Force (Bangladesh Biman Bahini, BAF) (2008)
Military service age and obligation: 16 years of
age for voluntary military service; 17 years of age for
officers (both with parental consent); conscription
legally possible in emergency, but has never been
implemented (2008)
Manpower available for military service:
males age 16-49: 41 ,1 99,340 (2008 est.)
Manpower fit for military service:
males age 16-49: 31,968,168 (2008 est.)
Military expenditures - percent of GDP:
1.5% (2006)','83d6d7b49ef78ca8080588e39a8a35b4dc4e34cae0ef7ca1c57623d828eae257','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a9ad532c9ea622ebf1eb6c027c2286e4e91f8f75478c95f7a8c2056265780d5',2008,'BB','Barbados','military-and-security',203,'Military branches: Royal Barbados Defense Force:
Troops Command, Barbados Coast Guard (2007)
Military service age and obligation: 18 years of
age for voluntary military service (younger requires
parental consent); no conscription (2008)
Manpower available for military service:
males age 16-49: 75,265
females age 16-49: 75,389 (2008 est.)
Manpower fit for military service:
males age 16-49: 58,556
females age 16-49: 58,143 (2008 est.)
Military expenditures - percent of GDP: 0.5%
(2006 est.)
Military - note: the Royal Barbados Defense Force
includes a land-based Troop Command and a small
Coast Guard; the primary role of the land element is to
defend the island against external aggression; the
Command consists of a single, part-time battalion with
a small regular cadre that is deployed throughout the
island; it increasingly supports the police in patrolling
the coastline to prevent smuggling and other illicit
activities (2007)','02bd6d1d5cd08c1b6493daceddd8e3079d91b372ba2216f6bc85b21fe4fd96c2','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e16de575ca37c8eb1e29a2a5c2799feb930b8fdca192c8ab5e88459ab22ad66',2008,'BY','Belarus','military-and-security',212,'Military branches: Belarus Armed Forces: Land
Force, Air and Air Defense Force (2008)
Military service age and obligation: 1 8-27 years of
age for compulsory military service; conscript service
obligation - 18 months (2005)
Manpower available for military service:
males age 16-49: 2,491,643
females age 16-49: 2,528,779 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,727,974
females age 16-49: 2,093,106 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 64,232
females age 16-49: 60,788 (2008 est.)
Military expenditures - percent of GDP: 1.4%
(2005 est.)','95834ff55bdefb2825069a28fd7348c720651a4c10adda8bb11b06bb04e682ea','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f94d9c4d3c4ea849e6ca4129bfa5473cd9474dd0db9904e770535372582785b1',2008,'BE','Belgium','military-and-security',220,'Military branches: Belgian Armed Forces: Land
Operations Command, Naval Operations Command,
Air Operations Command (2008)
Military service age and obligation: 18 years of
age for voluntary military service; conscription
suspended (2008)
Manpower available for military service:
males age 76-49:2,407,128
females age 16-49: 2,340,039 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,973,167
females age 16-49: 1,915,990 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 64,659
females age 16-49: 61,881 (2008 est.)
Military expenditures - percent of GDP: 1 .3%
(2005 est.)','d2b524cdc252036c8b1e13f24a3bad2c83bc3452915c4bca45c1a82fb81490b1','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28451a3e4252e2c17a8cbdddbb4cefc8e2d45a972524f851f4382a9de6532ed1',2008,'BJ','Benin','military-and-security',229,'Military branches: Belize Defense Force (BDF):
Army, BDF Air Wing, BDF Volunteer Guard (2007)
Military service age and obligation: 18 years of
age for voluntary military service; laws allow for
conscription only if volunteers are insufficient;
conscription has never been implemented; volunteers
typically outnumber available positions by 3:1 (2008)
Manpower available for military service:
males age 16-49: 74,605
females age 16-49: 72,926 (2008 est.)
Manpower fit for military service:
males age 16-49 : 54,627
females age 16-49: 53,500 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 3,580
females age 16-49: 3,449 (2008 est.)
Military expenditures - percent of GDP: 1 .4%
(2006)
Background: Present day Benin was the site of
Dahomey, a prominent West African kingdom that
rose in the 15th century. The territory became a
French Colony in 1872 and achieved independence
on 1 August 1960, as the Republic of Benin. A
succession of military governments ended in 1 972
with the rise to power of Mathieu KEREKOU and the
establishment of a government based on
Marxist-Leninist principles. A move to representative
government began in 1989. Two years later, free
elections ushered in former Prime Minister Nicephore
SOGLO as president, marking the first successful
transfer of power in Africa from a dictatorship to a
democracy. KEREKOU was returned to power by
elections held in 1996 and 2001, though some
irregularities were alleged. KEREKOU stepped down
at the end of his second term in 2006 and was
succeeded by Thomas YAYI Boni, a political outsider
and independent. YAYI has begun a high profile fight
against corruption and has strongly promoted
accelerating Benin’s economic growth.
Military branches: Benin Armed Forces (FAB):
Army (I’Arme de Terre), Benin Navy (Forces Navales
Beninois, FNB), Benin People''s Air Force (Force
Aerienne Populaire de Benin, FAPB) (2008)
Military service age and obligation: 21 years of
age for compulsory and voluntary military service; in
practice, volunteers may be taken at the age of 18;
both sexes are eligible for military service; conscript
tour of duty - 18 months (2006)
68
Benin (continued)
Manpower available for military service:
males age 16-49: 1 ,908,457
females age 16-49: 1,882,421 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,173,742
females age 16-49: 1,162,1 13 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 96,230
females age 16-49: 94,436 (2008 est.)
Military expenditures - percent of GDP: 1 .7%
(2006)','aa0642bfdd0883e6efd266393e813d81ca0b4839d31a3d1be53769d97e957860','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('978ca78e3e560d8be4f4d270986b12b37204637e2ac5cafcbd0460e3e7eea84b',2008,'BM','Bermuda','military-and-security',244,'Military branches: Bermuda Regiment (2008)
Military service age and obligation: 18-23 years of
age; eligible men required to register for conscription
as needed into the Bermuda Regiment, which is
largely voluntary; term of service 39 months (2007)
Manpower available for military service:
males age 16-49: 15,623 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,682 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 426 (2008 est.)
Military expenditures - percent of GDP: 0.1 1%
(2005 est.)
Military - note: defense is the responsibility of the
UK','80e75d3b8f98cf3e8733b661f8297e3e662ff255bedffb8228fecee22eb93bea','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3e1c0c1e475ae735638a26dfa5e1f1cd2f814a2d236d6985241dd0160fa6266',2008,'BT','Bhutan','military-and-security',252,'Military branches: Royal Bhutan Army (includes
Royal Bodyguard and Royal Bhutan Police) (2008)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 190,104
females age 16-49: 167,289 (2008 est.)
Manpower fit for military service:
males age 16-49: 146,063
females age 16-49: 1 31 ,1 93 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 7,847
females age 16-49: 7,530 (2008 est.)
Military expenditures - percent of GDP: 1%
(2005 est.)','c13cf522fab6f2c9f9c465614d2908a9f20bc47b07dbc31bb8dbd26e21845f76','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('132e6ee5b8704e6522218727473ac33e3d8048322fd0fd6af81cb04469b20cdb',2008,'BR','Brazil','military-and-security',261,'Military branches: Bolivian Armed Forces: Bolivian
Army (Ejercito Boliviano), Bolivian Navy (Armada
Boliviana; includes marines), Bolivian Air Force
(Fuerza Aerea Boliviana, FAB) (2008)
Military service age and obligation: 1 8 years of
age for 12-month compulsory military service; when
annual number of volunteers falls short of goal,
compulsory recruitment is effected, including
conscription of boys as young as 14; 15-19 years of
age for voluntary premilitary service, provides
exemption from further military service (2008)
Manpower available for military service:
males age 16-49: 2,295,746
females age 16-49: 2,366,828 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,600,21 9
females age 16-49: 1,815,514 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 107,051
females age 16-49: 103,620 (2008 est.)
Military expenditures - percent of GDP: 1 .9%
(2006)
Military branches: Brazilian Army, Brazilian Navy
(Marinha do Brasil (MB), includes Naval Air and
Marine Corps (Corpo de Fuzileiros Navais)), Brazilian
Air Force (Forca Aerea Brasileira, FAB) (2008)
Military service age and obligation: 21 -45 years of
age for compulsory military service; conscript service
obligation - 9 to 12 months; 17-45 years of age for
voluntary service; an increasing percentage of the
ranks are "long-sen/ice" volunteer professionals;
women were allowed to serve in the armed forces
beginning in early 1980s when the Brazilian Army
became the first army in South America to accept
women into career ranks; women serve in Navy a
Air Force only in Women’s Reserve Corps (2001)
Manpower available for military service:
males age 16-49: 52,449,957
females age 16-49: 52,375,921 (2008 est.)
Manpower fit for military service:
males age 16-49: 39,263,710
females age 16-49: 44,109,056 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 ,668,722
females age 16-49: 1 ,609,437 (2008 est.)
Military expenditures - percent of GDP: 2.6%
(2006 est.)
Military - note: defense is the responsibility of the
UK; the US lease on Diego Garcia expires in 2016
Manpower available for military service:
males age 16-49: 7,101 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,921 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 185 (2008 est.)
Military - note: defense is the responsibility of the
UK
Military branches: Royal Brunei Armed Forces
(RBAF): Royal Brunei Land Forces, Royal Brunei
Navy, Royal Brunei Air Force (Tentera Udara Diraja
Brunei) (2008)
Military service age and obligation: 1 8 years of
age (est.) for voluntary military service; non-Malays
are ineligible to serve (2007)
Manpower available for military service:
males age 16-49: 108,356
females age 16-49: 1 10,153 (2008 est.)
Manpower fit for military service:
males age 16-49: 91,297
females age 16-49: 93,228 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 3,223
females age 16-49: 3,182 (2008 est.)
Military expenditures - percent of GDP: 4.5%
(2006)
Military branches: Uruguayan Armed Forces: Army,
Navy (includes naval air arm, Marines, Maritime
Prefecture in wartime), Air Force (Fuerza Aerea
Uruguaya, FAU) (2008)
Military service age and obligation: 1 8 years of
age for voluntary and compulsory military service;
enlistment is voluntary in peacetime, but the
government has the authority to conscript in
emergencies (2007)
Manpower available for military service:
males age 16-49: 837,252
females age 16-49: 824,096 (2008 est.)
Manpower fit for military service:
males age 16-49: 703,955
females age 16-49: 690,296 (2008 est.)
Military expenditures - percent of GDP: 1 .6% (2006)','cf4f6c2de8ec896f4efe056f8b9e9f3fbc6d86ebd908764d2d88be112a04d398','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2184611f8119c18d8b578670cb861fdad0828d074178b375baa8cca0202ad612',2008,'BA','Bosnia and Herzegovina','military-and-security',270,'Military branches: Bosnia and Herzegovina Armed
Forces (OSBiH): Army of Bosnia and Herzegovina, Air
and Air Defense Forces of Bosnia and Herzegovina
(Zrakoplovstvo i Protuzracna Obrana, ZPO) (2007)
Military service age and obligation: 17 years of
age for voluntary military service in the Federation and
in the Republika Srpska; conscription abolished
January 2006; 4-month service obligation (2006)
Manpower available for military service:
males age 16-49: 1,212,007
females age 16-49: 1 ,170,645 (2008 est.)
Bosnia and Herzegovina (continued)
Manpower fit for military service:
mates age 16-49: 996,225
females age 16-49: 962,927 (2008 est.)
Manpower reaching militarily significant age
annually:
mates age 16-49: 30,246
females age 16-49: 28,189 (2008 est.)
Military expenditures - percent of GDP: 4.5%
(2005 est.)','58f25b18b4c2ea1a1e61eaabf56a2e70c73a447e9d3ac3e3b9aa656fc6d3d215','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e683901420b094e62685a78bbbab96a99bd774493ccc5e2d213dec1213241ee6',2008,'BW','Botswana','military-and-security',278,'Military branches: Botswana Defense Force
(includes an air wing) (2008)
Military service age and obligation: 18 is the
apparent age of voluntary military service; the official
qualifications for determining minimum age are
unknown (2001)
Manpower available for military service:
males age 16-49: 487,853
females age 16-49: 464,278 (2008 est.)
Manpower fit for military service:
males age 16-49: 290,093
females age 16-49: 257,700 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 23,007
females age 16-49: 22,551 (2008 est.)
Military expenditures - percent of GDP: 3.3%
(2006)','bed5fa68c4bcb8eade2d96c8f10611e26859f93f4b3b02eb40b42e145e3e0b4b','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54f08260bba253482a2b2d51f402454f075e2e9fdc03445276f18f58bdc47e8a',2008,'BG','Bulgaria','military-and-security',293,'Military branches: Bulgarian Armed Forces:
Ground Forces, Naval Forces, Bulgarian Air Forces
(Bulgarski Voennovazdyshni Sily, BVVS) (2008)
Military service age and obligation: 1 8-27 years of
age for voluntary military service; conscript service
obligation - 9 months; as of May 2006, 67% of the
Bulgarian Army comprised of professional soldiers;
conscription ended as of 1 January 2008; Air and Air
Defense Forces and Naval Forces became fully
professional at the end of 2006 (2008)
Manpower available for military service:
males age 16-49: 1 ,701 ,979
females age 16-49: 1 ,691 ,092 (2008 est.)
94
Bulgaria (continued)
Manpower fit for military service:
males age 1 6-49: 1 ,364,029
females age 16-49: 1 ,401 ,348 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 39,477
females age 16-49: 37,339 (2008 est.)
Military expenditures - percent of GDP: 2.6%
(2005 est.)','de2754695c8f5fa22711cc0519922b132833961c26683e3725b3fc73bef595f5','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38e34c2376b5d1d0053e23d8e4c6ad6cb7d36b3e656bd4a78d22359ac01c12bd',2008,'BF','Burkina Faso','military-and-security',301,'Military branches: Army, Air Force of Burkina Faso
(Force Aerienne de Burkina Faso, FABF), National
Gendarmerie (2008)
Military service age and obligation: 1 8 years of
age for compulsory military service; 20 years of age
for voluntary military service (2001)
Manpower available for military service:
males age 16-49: 3,364,288 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,1 15,948 (2008 est.)
Military expenditures - percent of GDP: 1 .2%
(2006)
Military branches: Myanmar Armed Forces
(Tatmadaw): Army, Navy, Air Force (Tatmadaw Lay)
(2008)
Military service age and obligation: 18 years of
age for voluntary military service for both sexes;
forced conscription of children, although officially
prohibited, reportedly continues (2007)
Manpower available for military service:
males age 16-49: 13,402,788
females age 16-49: 13,437,042 (2008 est.)
Manpower fit for military service:
males age 16-49: 9,031 ,046
females age 16-49: 9,396,547 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 423,809
females age 16-49: 415,843 (2008 est.)
Military expenditures - percent of GDP: 2.1%
(2005 est.)','b6dfabd08f037f9677f5d66e1f9a50bfce266ddf12d2b495eed3716ace325117','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8d9ea7f0c0f2665293ac7e24eae0d27d0d69c05099e0159fdeb198f7c15deec',2008,'BI','Burundi','military-and-security',310,'Military branches: National Defense Force (Forces
de Defense Nationales, FDN): Army (includes Naval
Detachment and Air Wing) (2008)
Military service age and obligation: 16 years of
age for compulsory and voluntary military service;
children as young as 10 years of age have been
conscripted into the armed forces; the enrollment of
children is still not prohibited (2007)
Manpower available for military service:
males age 16-49: 1 ,878,544
females age 16-49: 1 ,851 ,676 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,083,899
females age 16-49: 1 ,062,488 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 98,105
females age 16-49: 98,533 (2008 est.)
Military expenditures - percent of GDP: 5.9%
(2006 est.)','6737e95d3e73f27ef84890cd92ab0dca9b040c6f13d66a8ff6a9b8671ec41c0c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('109c1cc297d38025e07e7c4e2294cfd23a3eea79315f93e428d1be2ec04d7949',2008,'KH','Cambodia','military-and-security',319,'Military branches: Royal Cambodian Armed
Forces: Royal Cambodian Army, Royal Khmer Navy,
Royal Cambodian Air Force (2008)
Military service age and obligation: conscription
law of October 2006 requires all males between 1 8-30
to register for military service; 18-month service
obligation (2006)
Manpower available for military service:
males age 16-49: 3,759,034
females age 16-49: 3,784,333 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,581,045
females age 16-49: 2,676,075 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 185,959
females age 16-49: 182,558 (2008 est.)
Military expenditures - percent of GDP: 3%
(2005 est.)
I','f4190d2e743504f8c916f868e0aba6558158b7056bbb82f54d7697deafafe503','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c62130e04fd38fd4bed6d1065a521507f803b3812f60ab2992887a1d3664f414',2008,'CM','Cameroon','military-and-security',327,'Military branches: Cameroon Armed Forces: Army,
Navy (includes naval infantry), Air Force (Armee de
I’Air du Cameroun, AAC) (2008)
Military service age and obligation: 1 8 years of
age for voluntary military service; no conscription; the
government makes periodic calls for
volunteers (2006)
Manpower available for military service:
males age 16-49: 4,321,175
females age 16-49: 4,228,625 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,567,428
females age 16-49: 2,498,990 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 212,205
females age 16-49: 207,545 (2008 est.)
Military expenditures - percent of GDP:
1.3% (2006)','9d98780d09005b954df31449ef1efe9830a5af22d8a8b2efb79b0c385c37e86a','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf5a7b8a4840425a1a680b9f9281aef22238e5dd66250314649de886dbe1781e',2008,'CA','Canada','military-and-security',335,'Military branches: Canadian Forces: Land Forces
Command (LFC), Maritime Command (MARCOM),
Air Command (AIRCOM), Canada Command
(homeland security) (2008)
Military service age and obligation: 1 6-34 years of
age for voluntary military service; women comprise
approximately 11% of Canada’s armed forces (2006)
Manpower available for military service:
males age 1 6-49: 8,072,010
females age 16-49: 7,813,462 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,646,281
females age 16-49: 6,417,924 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 227,435
females age 16-49: 21 5,556 (2008 est.)
Military expenditures - percent of GDP: 1.1%
(2005 est.)
Military branches: People’s Revolutionary Armed
Forces (FARP): Army, Coast Guard (includes
maritime air wing) (2007)
Military service age and obligation: 1 8 years of
age (est.) for selective compulsory military service;
14-month conscript service obligation (2006)
Manpower available for military service:
males age 16-49: 103,650
females age 16-49: 103,553 (2008 est.)
Manpower fit for military service:
males age 16-49: 83,082
females age 16-49: 88,832 (2008 est.)
Military expenditures - percent of GDP: 0.7%
(2005)
Military branches: no regular military forces
Manpower available for military service:
males age 16-49: 15,221 (2008 est.)
Manpower fit for military service:
males age 16-49: 10,739 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 509 (2008 est.)
Military - note: defense is the responsibility of','28507184fb792b36902b07fef55440055ddc51618b0a5da7ec961ac9a209f330','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3677e2d1311bd0350031f9d035b4a61d35f63fda58d5e0e4740638e2183bf607',2008,'JM','Jamaica','military-and-security',346,'Military branches: no regular military forces; Royal
Cayman Islands Police Force (2007)
Manpower available for military service:
males age 16-49: 1 1 ,790 (2008 est.)
Manpower fit for military service:
males age 16-49: 9,577 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 336 (2008 est.)
Military • note: defense is the responsibility of the
UK
Military branches: Jamaica Defense Force: Ground
Forces, Coast Guard, Air Wing (2007)
Military service age and obligation: 1 8 years of
age for voluntary military service; younger recruits
may be conscripted with parental consent (2001)
Manpower available for military service:
males age 16-49: 688,480
females age 16-49: 709,548 (2008 est.)
Manpower fit for military service:
males age 16-49: 566,477
females age 16-49: 583,075 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 32,000
females age 16-49: 31 ,428 (2008 est.)
Military expenditures - percent of GDP: 0.6%
(2006 est.)','a8768299404d6f69c5f0ed673dc2412c9449703e0597ac8a952f4a61ae882a2d','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c23c2c8e589f51db6e2934aa0b070cf41a4f5b4ea3e802e97dd0620093b7c80',2008,'CF','Central African Republic','military-and-security',355,'Military branches: Central African Armed Forces
(Forces Armees Centrafricaines, FACA): Ground
Forces, General Directorate of Gendarmerie
Inspection (DGIG), Military Air Service, National
Police (2008)
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
2-year conscript service obligation (2006)
Manpower available for military service:
males age 16-49: 1 ,032,828
females age 16-49: 999,330 (2008 est.)
Manpower fit for military service:
males age 16-49: 534,141
females age 16-49: 495,303 (2008 est.)
Military expenditures - percent of GDP: 1.1%
(2006 est.)','dbfff19648c6b6bb2178bee20ca48aef636259bdd6214baad80eb930ed780470','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('144821f0f4fef4b719c490e32e085f58682970559ba8f2a2f993d05bfd49aa29',2008,'TD','Chad','military-and-security',363,'Military branches: Armed Forces: Chadian National
Army (Armee Nationale du Tchad, ANT), Chadian Air
Force (Force Aerienne Tchadienne, FAT),
Gendarmerie (2008)
121
Chad (continued)
Military service age and obligation: 20 years of
age for conscripts, with 3-year service obligation; 18
years of age for volunteers; no minimum age
restriction for volunteers with consent from a guardian;
women are subject to 1 year of compulsory military or
civic service at age of 21 (2004)
Manpower available for military service:
males age 16-49: 1 ,906,545
females age 16-49: 2,258,758 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,066,565
females age 16-49: 1,279,318 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 16,824
females age 16-49: 117,831 (2008 est.)
Military expenditures - percent of GDP: 4.2%
(2006)','9d00300f85dd4763941510c595672717eec54c72ca814307bfdcd05faa53374c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('629a0b87640d31d7022d541e766745a65669eada3cec56d5bb1af3962550af1b',2008,'CL','Chile','military-and-security',372,'Military branches: Army of the Nation, Chilean Navy
(Armada de Chile, includes naval air, marine corps,
and Maritime Territory and Merchant Marine
Directorate (Directemar)), Chilean Air Force (Fuerza
Aerea de Chile, FACh), Carabineros Corps (Cuerpo
de Carabineros) (2008)
Military service age and obligation: 1 8-45 years of
age for voluntary male and female military service,
although the right to compulsory recruitment is
retained; service obligation - 12 months for Army,
22 months for Navy and Air Force (2008)
Manpower available for military service:
males age 16-49:4,242,912
females age 16-49: 4,182,509 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,542,448
females age 16-49: 3,500,059 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 147,518
females age 16-49: 141 ,139 (2008 est.)
Military expenditures - percent of GDP: 2.7%
(2006)','a412fe8968f941e07639e49432c552335ffbe94a5e09201f78942ef5d278184c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33d076aadab5c30b8adadc89ba7b5517c284c4e77856d141f01d9bfa44d7e3d2',2008,'JP','Japan','military-and-security',384,'Military branches: People''s Liberation Army (PLA):
Ground Forces, Navy (includes marines and naval
aviation), Air Force (includes airborne forces), and
Second Artillery Corps (strategic missile force);
People’s Armed Police (PAP); Reserve and Militia
Forces (2008)
Military service age and obligation: 1 8-22 years of
age for selective compulsory military service, with
24-month service obligation; no minimum age for
voluntary service (all officers are volunteers); 18-19
years of age for women high school graduates who
meet requirements for specific military jobs (2007)
Manpower available for military service:
males age 16-49: 375,009,345
females age 16-49: 354,314,328 (2008 est.)
Manpower fit for military service:
males age 16-49: 313,321 ,639
females age 16-49: 295,951 ,438 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 10,760,380
females age 16-49: 9,710,032 (2008 est.)
Military expenditures - percent of GDP: 4.3%
(2006)
Military branches: Japanese Ministry of Defense
(MOD): Ground Self-Defense Force (Rikujou Jietai,
GSDF), Maritime Self-Defense Force (Kaijou Jietai,
MSDF), Air Self-Defense Force (Koku Jieitai, ASDF)
(2008)
Military service age and obligation: 18 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 16-49: 27,819,804
females age 16-49: 26,863,794 (2008 est.)
Manpower fit for military service:
males age 16-49: 22.963 million
females age 16-49: 22,134,127 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 622,168
females age 16-49: 590,153 (2008 est.)
Military expenditures - percent of GDP: 0.8%
(2006)','f59eef7273fc94e493d587809558f8ac4c2001f47aaaadb31f89dd9ce47da503','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e94a5b1b1f7a0791297933f3db0a1b91dd1563d5b9d4fa7b161c3974c251e93',2008,'FR','France','military-and-security',397,'Military - note: defense is the responsibility of
Military branches: Army (includes Marines, Foreign
Legion, Army Light Aviation), Navy (Marine Nationale,
includes Naval Air), Air Force (Armee de I’Air, includes
air defense), National Gendarmerie (2008)
Military service age and obligation: 1 7-40 years of
age for male or female voluntary military service); no
conscription; 12-month service obligation; women
serve in noncombat military posts (2005)
Manpower available for military service:
males age 16-49: 14,646,427
females age 16-49: 14,379,630 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,110,718
females age 16-49: 1 1 ,849,988 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 401 ,379
females age 16-49: 382,409 (2008 est.)
Military expenditures - percent of GDP: 2.6%
(2005 est.)
Saint Helena
(overseas territory of the UK)
O 200 400 km
0 200
Ascension
St. Helena
JAMES!
TRISTAN DA CUNHA
Inacessible
Island — . Queen Mary''s Peak
'' A Tristan da Cunha
NIGHTINGALE
ISLANDS
Gough
Island
Military - note: defense is the responsibility
UK
Transnational Issue
Disputes - international: none
490
t Kitts and Nevis
0 _ 4 8 km
0 4 8 mi
Point
vn
m Mount
Liamuiga
„ . BASSETERRE
Saint m
Kitts
Nevis
Peak
A
Charlestown
Nevis
;|5','5f2d464ec0a1e34684714fcb9057ae4471710af3ad47582345af75b22360c993','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d516c18f0bd9a50bba3b2572d256c1634d1172e4b9909a788e145ee4e682c25b',2008,'CC','Cocos (Keeling) Islands','military-and-security',407,'Military - note: defense is the responsibility of
Australia; the territory has a five-person police force','c68db60f8ad36bfc8be57df815236bfde43ec48b5f75db74eb2e031c594854ff','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89298f87aa606bcf06b010fa3137107c3878e724fd9ced740c84a8dfbfa38e81',2008,'CO','Colombia','military-and-security',415,'Military branches: National Army (Ejercito
Nacional), National Navy (Armada Nacional, includes
Naval Aviation, Naval Infantry (Infanteria de Marina,
Colmar), and Coast Guard), Colombian Air Force
(Fuerza Aerea de Colombia, FAC) (2008)
Military service age and obligation: 1 8-24 years of
age for compulsory and voluntary military service;
service obligation - 18 months (2004)
Manpower available for military service:
males age 16-49: 11,478,109
females age 16-49: 1 1 ,809,279 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,056,336
females age 16-49: 9,91 9,952 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 442,403
females age 1 6-49: 433, 1 92 (2008 est.)
Military expenditures - percent of GDP: 3.4%
(2005 est.)','ccda1cc4ca427e994379dc40e7875a0f7b313bc9727f0a96b1ff701b78072608','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea1472d9e01d8e3fbd8ae3782453de8e2133f66e2da015dcb340e1db6d022846',2008,'YT','Mayotte','military-and-security',426,'Military branches: National Development Army
(AND): Comoran Security Force; Comoran Federal
Police (2008)
Manpower available for military service:
males age 16-49: 167,850
females age 16-49: 167,362 (2008 est.)
Manpower fit for military service:
males age 16-49: 121,550
females age 16-49: 131,015 (2008 est.)
Military expenditures - percent of GDP: 2.8%
(2006)
Military branches: People’s Armed Forces:
Intervention Force, Development Force, and
Aeronaval Force (navy and air); National
Gendarmerie
Military service age and obligation: 1 8-50 years of
age for compulsory military service; 18-month
conscript service obligation (either military or
equivalent civil service) (2006)
Manpower available for military service:
males age 16-49: 4,443,341
females age 76-49; 4,441 ,124 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,034,600
females age 16-49: 3,271 ,732 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 230,088
females age 16-49: 229,932 (2008 est.)
Military expenditures - percent of GDP: 1 %
(2006)','c2f2e5a2928302bc3389942c4a28280e56004b03ba2cab8f41bb8a3c71a21e4a','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87886b56cd1f3220eee5808b7cdb2de200440de0643565f80afeae79852b85ef',2008,'CG','Congo','military-and-security',431,'Military branches: Armed Forces of the Democratic
Republic of the Congo (FARDC): Army, Navy,
Congolese Air Force (Force Aerienne Congolaise,
FAC) (2008)
Military service age and obligation: 1 8-45 years of
age for military service
Manpower available for military service:
males age 16-49: 14,101,263 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,562,989 (2008 est.)
Military expenditures - percent of GDP: 2.5%
(2006)
Military branches: Congolese Armed Forces
, (Forces Armees Congolaises, FAC): Army, Navy,
Congolese Air Force (Armee de I''Air Congolaise),
Gendarmerie, Special Presidential Security Guard
(GSSP) (2008)
Military service age and obligation: 18 years of
age for voluntary military sen/ice; women allowed to
serve (2007)
Manpower available for military service:
males age 16-49: 842,771
females age 16-49: 833,624 (2008 est.)
Manpower fit for military service:
males age 16-49: 51 9,296
females age 16-49: 509,564 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 45,671
females age 16-49: 45,248 (2008 est.)
Military expenditures - percent of GDP: 3.1%
(2006)','d6972e113742c37700193af7960ea94b6e22cce1b6bce41ec2650ad11135ffb7','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22c68db9169def95c39236a5e678e6af8f53148f2d957375e9da96860310dcb4',2008,'CR','Costa Rica','military-and-security',447,'Military branches: no regular military forces; Ministry
of Public Security, Government, and Police (2008)
Manpower available for military service:
males age 16-49: 1,134,205
females age 16-49: 1 ,095,763 (2008 est.)
Manpower fit for military service:
males age 16-49: 958,013
females age 16-49: 925,727 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 40,767
females age 16-49: 38,899 (2008 est.)
Military expenditures - percent of GDP: 0.4%
(2006)
Military branches: Cote d’Ivoire Defense and
Security Forces (FDSC): Army, Navy, Air Force
(2006)
Military service age and obligation: 18 years of
age for compulsory and voluntary military service
(2008)
Manpower available for military service:
males age 16-49: 4,369,735
females age 16-49: 4,287,042 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,393,104
females age 16-49: 2,381 ,607 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 202,545
females age 16-49: 211,601 (2008 est.)
Military expenditures - percent of GDP: 1 .6%
(2005 est)','505d768291cc597046391cd329ee6441c4e3bad1bb9480a1dc118a7eb7210ac1','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c8acd2fe06ba94994c5cb2d9c3b6b382f364a9414953bf0ff4565ea18e2b3ec',2008,'SI','Slovenia','military-and-security',456,'Military branches: Armed Forces of the Republic of
Croatia (Oruzane Snage Republike Hrvatske, OSRH),
consists of five major commands directly subordinate
to a General Staff: Ground Forces (Hrvatska Kopnena
Vojska, HKoV), Naval Forces (Hrvatska Ratna
Mornarica, HRM), Air Force, Joint Education and
Training Command, Logistics Command; Military
Police Force supports each of the three Croatian
military forces (2007)
Military service age and obligation: 1 8-27 years of
age for compulsory military service; 16 years of age
with consent for voluntary service; 6-month conscript
service obligation; full conversion to professional
military service by 2010 (2006)
Manpower available for military service:
males age 16-49: 1 ,035,712
females age 16-49: 1 ,037,896 (2008 est.)
Manpower fit for military service:
males age 16-49: 771,323
females age 16-49: 855,937 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 27,500
females age 16-49: 25,893 (2008 est.)
Military expenditures - percent of GDP: 2.39%
(2005 est.)','2fd7fe8b699f4a4ed5558f6b68366008c3b51c9c352ef20283dd3cce79302a0c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd34d884ba9d781e30b897bf85991fe5d1c655914aef8bc47c126bfb0158565d',2008,'HT','Haiti','military-and-security',465,'Military branches: Revolutionary Armed Forces
(Fuerzas Armadas Revolucionarias, FAR):
Revolutionary Army (ER; includes Territorial Militia
Troops, MTT), Revolutionary Navy (Marina de Guerra
Revolucionaria, MGR; includes Marine Corps),
Revolutionary Air and Air Defense Force (DAAFAR),
Youth Labor Army (EJT) (2008)
Military service age and obligation: 1 7-28 years of
age for compulsory military service; 2-year service
obligation; both sexes subject to military service
(2006)
Manpower available for military service:
males age 16-49: 3,094,388
females age 16-49: 3,024,876 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,543,044
females age 16-49: 2,481 ,823 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 79,945
females age 16-49: 76,014 (2008 est.)
Military expenditures - percent of GDP: 3.8%
(2006 est.)
Military - note: the collapse of the Soviet Union
deprived the Cuban Army of its major economic and
logistic support, and had a significant impact on
equipment numbers and serviceability; the army
remains well trained and professional in nature; while
the lack of replacement parts for its existing
equipment and the current severe shortage of fuel
have increasingly affected operational capabilities,
Cuba remains able to offer considerable resistance to
any regional power (2008)
Military branches: Army, Navy, Air Force (Fuerza
Aerea Dominicana, FAD) (2007)
Military service age and obligation: 1 8 years of
age for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 2,440,203
females age 16-49: 2,326,694 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,020,490
females age 16-49: 1 ,883,875 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 96,971
females age 16-49: 93,1 16 (2008 est.)
Military expenditures - percent of GDP: 0.8%
(2006)','2fc092df47f3e40e89d8f742855937c53b8fc5a5d4814312c21ca49c5c23e6a2','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6ab74941489f425f36fc00c066dafad55e12fca6cbbe20a514bd5e1d40a4214',2008,'CY','Cyprus','military-and-security',474,'Military branches: Republic of Cyprus: Greek
Cypriot National Guard (Ethniki Forea, EF; includes
air and naval elements); northern Cyprus: Turkish
Cypriot Security Force (GKK) (2007)
Military service age and obligation: Greek Cypriot
National Guard (GCNG): 18-50 years of age for
compulsory military service for all Greek Cypriot
males; 17 years of age for voluntary service; females
are not conscripted; age of military eligibility 17 to 50;
length of normal service is 25 months with a minimum
of 3 months (2006)
Manpower available for military service:
Greek Cypriot National Guard (GCNG): males age
16-49:199,767
females age 16-49: 190,665 (2008 est.)
Manpower fit for military service:
Greek Cypriot National Guard (GCNG): males age
16-49: 165,042
females age 16-49: 158,869 (2008 est.)
Manpower reaching militarily significant age
annually:
Greek Cypriot National Guard (GCNG): males age
16-49: 6,482
females age 16-49: 6,208 (2008 est.)
Military expenditures - percent of GDP: 3.8%
(2005 est.)
Military branches: Army of the Czech Republic
(ACR): Joint Forces Command (includes Army and Air
Forces), Support and Training Forces Command
(2007)
Military service age and obligation: 1 8-28 years of
age for voluntary and 19-28 for compulsory military
service (2008)
Manpower available for military service:
males age 16-49: 2,522,383
females age 16-49: 2,425,095 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,1 00,789
females age 16-49: 2,018,101 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 63,124
females age 16-49: 59,786 (2008 est.)
Military expenditures - percent of GDP: 1 .46%
(2007 est.)','b001fdc7cc94b51dd587a111e0e616a1afbb2a05bdd425e5a0ff29f2e266c1f3','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('464918efecb6829515b5b8828ed26c5f15a12ea45f53f95bda5e2f2cbf094b54',2008,'FO','Faroe Islands','military-and-security',487,'Military branches: Defense Command: Army
Operational Command, Admiral Danish Fleet, Island
Command Greenland, Tactical Air Command, Home
Guard (2008)
Military service age and obligation: 1 8 years of
age for compulsory and voluntary military service;
conscripts serve an initial training period that varies
from 4 to 12 months according to specialization;
reservists are assigned to mobilization units following
completion of their conscript service; women eligible
to volunteer for military service (2004)
Manpower available for military service:
males age 16-49: 1 ,235,067
females age 16-49: 1,215,418 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,012,716
females age 16-49: 996,436 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 36,561
females age 16-49: 34,603 (2008 est.)
Military expenditures - percent of GDP: 1 .5%
(2006; 1.28% 2007 est.)
Military - note: includes Dhekelia Garrison and
Ayios Nikolaos Station connected by a roadway
Military branches: no regular military forces
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of the
UK','6c2e36f572d2d35cf34207c8414567a4805dec9a522b52ddb961ebe87aa18561','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b811479c615903643bac92f5c1769102a123afd0d282f8860c599bdaf32cedaf',2008,'DJ','Djibouti','military-and-security',498,'Military branches: Djibouti National Army (includes
Navy and Air Force)
Military service age and obligation: 1 8 years of
age for voluntary military service; 16-25 years of age
for voluntary military training; no conscription (2008)
Manpower available for military service:
males age 16-49: 1 1 1 ,274
females age 16-49: 105,168 (2008 est.)
Manpower fit for military service:
males age 16-49: 54,460
females age 16-49: 51 ,684 (2008 est.)
Military expenditures - percent of GDP: 3.8%
(2006)','a0edfc71d6f7f5508270209534197d4f39386801600304199af73af4eea889b0','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a74c191c9efa21e5e5579fea5620c815d949d310ffd7a47c30b3c3308950838',2008,'DM','Dominica','military-and-security',508,'Military branches: no regular military forces;
Commonwealth of Dominica Police Force (includes
Coast Guard) (2008)
Manpower available for military service:
males age 16-49: 18,584 (2008 est.)
Manpower fit for military service:
males age 16-49: 15,648 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 756 (2008 est.)
Military expenditures - percent of GDP: NA(2006)
172
Dominica (continued)','9c366cdb54d7f2ad0887c107d704770f7f6767fc4675c87ac53d8715ddae474a','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac03a6df46c55b2696ab8629ed2286f84df2a528cf0b888387148da48140feb6',2008,'EC','Ecuador','military-and-security',519,'Military branches: Army, Navy (includes Naval
Infantry, Naval Aviation, Coast Guard), Air Force
(Fuerza Aerea Ecuatoriana, FAE) (2007)
Military service age and obligation: 20 years of
age for selective conscript military service; 12-month
service obligation (2006)
Manpower available for military service:
males age 16-49: 3,536,602
females age 16-49: 3,559,188 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,030,664
females age 16-49: 3,037,892 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 144,821
females age 16-49: 139,091 (2008 est.)
Military expenditures - percent of GDP: 2.8%
(2006)','a0fec685d0bc25fb5bf00e23c55ee39d6e5174b48fc07f35eb8b6010a1e18f67','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7c3b733d293329a777eeab0c7c9214ca5894c90d9ae9656f65bb079f968934a',2008,'SD','Sudan','military-and-security',528,'Military branches: Army, Navy, Air Force, Air
Defense Command
Military service age and obligation: 1 8-30 years of
age for male conscript military service; service
obligation 12-36 months, followed by a 9-year reserve
obligation (2006)
Manpower available for military service:
males age 16-49: 21,247,777
females age 16-49: 20,406,408 (2008 est.)
Manpower fit for military service:
males age 16-49: 18,153,158
females age 16-49: 17,405,837 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 825,300
females age 16-49: 786,590 (2008 est.)
Military expenditures - percent of GDP: 3.4%
(2005 est.)
Military branches: Sudanese People''s Armed
Forces (SPAF): Land Forces, Navy, Air Force,
Popular Defense Forces; Sudan People’s Liberation
Army (SPLA): Land Forces (2008)
Military service age and obligation: 1 8-30 years of
age for compulsory military service; 2-year service
obligation (2006)
Manpower available for military service:
males age 16-49: 9,639,923
females age 16-49: 9,321,106 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,586,468
females age 16-49: 5,678,427 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 488,679
females age 16-49: 469,547 (2008 est.)
Military expenditures - percent of GDP: 3%
(2005 est.)','7dc8064c1053d354fc81925cc2bf68f0da45474218b81cf1c872952f0a30883a','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('324153ec0e5a575351c72eb2ad1631a7720a315a4dc88d32a5f976fb5b3cc989',2008,'SV','El Salvador','military-and-security',537,'Military branches: Salvadoran Army (ES),
Salvadoran Navy (FNES), Salvadoran Air Force
(Fuerza Aerea Salvadorena, FAS) (2008)
Military service age and obligation: 18 years of
age for selective compulsory military service; 1 6 years
of age for voluntary service; 12-month service
obligation (2006)
Manpower available for military service:
males age 16-49: 1,634,816
females age 16-49: 1,775,474 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,168,406
females age 16-49: 1 ,51 9,375 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 73,915
females age 16-49: 71 ,252 (2008 est.)
Military expenditures - percent of GDP: 5%
(2006)','e346773563b206e86fd7f4bd002687ed95364b6ab44bb94a4304ea68ec72c7ce','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27b564c47d1eb735b84d47f99b7866191dce4d0994fa8614a5a7b13a2768c71b',2008,'GA','Gabon','military-and-security',546,'Military branches: National Guard (Guardia
Nacional (Army), with Coast Guard (Navy) and Air
Wing) (2008)
Military service age and obligation: 1 8 years of
age (est.) for compulsory military service (2008)
Manpower available for military service:
males age 16-49: 136,725
females age 16-49: 138,018 (2008 est.)
Manpower fit for military service:
males age 16-49: 101,712
females age 16-49: 104,381 (2008 est.)
Military expenditures - percent of GDP: 0.1%
(2006 est.)','2bddf06e56fa3838c7ad3338978c9074ac9683166069a546b80607ace3876826','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a349847c36706ea9d966c2893cd3ef780344a9f3231c2ca11178eef2412ae4d',2008,'ER','Eritrea','military-and-security',555,'Military branches: Eritrean Armed Forces: Ground
Forces, Navy, Air Force (2008)
Military service age and obligation: 1 8-40 years of
age for male and female voluntary and compulsory
military service; 1 6-month conscript service obligation
(2006)
Manpower available for military service:
males age 16-49: 1 ,108,836
females age 16-49: 1,096,120 (2008 est.)
Manpower fit for military service:
males age 16-49: 715,531
females age 16-49: 731 ,51 1 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 62,504
females age 16-49: 62,153 (2008 est.)
Military expenditures - percent of GDP: 6.3%
(2006 est.)','15df0829368822f8758b548e928d1d59faf1e6755556f8e824fe85c2b67e20fc','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62ab6fdf725bc500b64ea48bb7b05d7b2c9141f06cef1031087720629513c931',2008,'EE','Estonia','military-and-security',564,'Military branches: Estonian Defense Forces: Land
Force, Navy, Air Force (Eesti Ohuvagi), Volunteer
Defense League (Kaitseliit, KL) (2008)
Military service age and obligation: compulsory
military service for men between 19 and 28;
conscription lasts 1 1 months for junior NCOs and
reserve platoon leaders; reserve officers and
designated specialists have a different conscript
service obligation; Estonia has committed to retaining
conscription for men up to 201 0 and, unlike Latvia and
Lithuania, has no plan to transition to a contract armed
forces; 17 years of age for volunteers; reserve
commitment up to the age of 60 (2006)
Manpower available for military service:
males age 16-49: 306,273
females age 16-49: 317,852 (2008 est.)
Manpower fit for military service:
males age 16-49: 218,448 (in 2004, 51% of the young
men called up for service were determined to be unfit;
main obstacles to conscription were psychiatric and
behavioral)
females age 16-49: 264,187 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 8,322
females age 16-49: 7,846 (2008 est.)
Military expenditures - percent of GDP: 2%
(2005 est.)','0287a20d77fc663b7557c56ffbbfb01fad55f7aa8327a11d75b0eb901d4754d9','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9381cc6ed4996c806c9b703cf22a18933fab0579df8d4d90dd1f6eb84a42d44d',2008,'SO','Somalia','military-and-security',572,'Military branches: Ethiopian National Defense
Force (ENDF): Ground Forces, Ethiopian Air Force
(ETAF) (2008)
note: Ethiopia is landlocked and has no navy;
following the secession of Eritrea, Ethiopian naval
facilities remained in Eritrean possession
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
theoretically, no compulsory military service, but the
military can conduct call-ups when necessary and
compliance is compulsory (2008)
Manpower available for military service:
males age 16-49: 17,666,967
females age 16-49: 17,530,211 (2008 est.)
Manpower fit for military service:
males age 16-49: 10,060,775
females age 16-49: 9,854,710 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 910,602
females age 16-49: 911,081 (2008 est.)
Military expenditures - percent of GDP: 3%
(2006)
Military branches: no national-level armed forces
(2008)
Manpower available for military service:
males age 16-49: 2,181,050
females age 16-49: 2,125,558 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,274,783
females age 16-49: 1,317,991 (2008 est.)
Military expenditures - percent of GDP: 0.9%
(2005 est.)','b20acd954251471a478f38c1160d9d64a56934c1c21a9da1812e5ff34865c3c0','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bfb07fc5987b15eb3e176c8aa8e34a60098339842217d49cd98362e2b565c50',2008,'JE','Jersey','military-and-security',586,'Military branches: no regular military forces
Manpower available for military service:
males age 16-49: 11,725 (2008 est.)
Manpower fit for military service:
males age 16-49: 9,735 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 400 (2008 est.)
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of
Military - note: defense is the responsibility of the
UK
Military branches: Land Forces, Kuwaiti Navy,
Kuwaiti Air Force (Al-Quwwat al-Jawwiya
al-Kuwaitiya), National Guard (2007)
Military service age and obligation: 1 8 years of
age for compulsory and voluntary military service;
reserve obligation to age 40 with 1 month annual
training; women have served in police forces since
1999 (2006)
Manpower available for military service:
males age 16-49: 1,032,408
females age 1 6-49: 568,657 (2008 est.)
Manpower fit for military service:
males age 16-49: 892,816
females age 16-49: 500,540 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 17,737
females age 16-49: 18,519 (2008 est.)
Military expenditures - percent of GDP: 5.3%
(2006)
325
Kuwait (continued)
Military branches: no regular indigenous military
forces; French Armed Forces (includes Army, Navy,
Air Force, Gendarmerie); Police Force
Manpower available for military service:
males age 16-49: 57,738 (2008 est.)
Manpower fit for military service:
males age 16-49: 47,342 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 2,202 (2008 est.)
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of
Military branches: Slovenian Army (includes air and
naval forces)
Military service age and obligation: 17 years of
age for voluntary military service; conscription
abolished in 2003 (2007)
Manpower available for military service:
males age 16-49: 494,496
females age 16-49: 481 ,1 80 (2008 est.)
Manpower fit for military service:
males age 16-49: 406,951
females age 16-49: 395,444 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 10,516
females age 16-49: 9,934 (2008 est.)
Military expenditures - percent of GDP: 1 .7%
(2005 est.)
Military branches: Umbutfo Swaziland Defense
Force (USDF): Ground Force (includes air wing)
(2008)
Military service age and obligation: 1 8-30 years of
age for male and female voluntary military service; no
conscription (2008)
Manpower available for military service:
males age 16-49: 266,31 1 (2008 est.)
Manpower fit for military service:
males age 16-49: 122,260 (2008 est.)
Military expenditures - percent of GDP: 4.7%
(2006)','8f28582d0ca3ba8ae26fa8bfd2165e439dd1a718ef17fe9573e8ef698576d637','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b575b631f031bd0d8a270f97cb7a6d154728485b8e247efc955f411bda9f338',2008,'DK','Denmark','military-and-security',592,'Military branches: Republic of Fiji Military Forces
(RFMF): Land Forces, Naval Forces (2008)
Military service age and obligation: 18 years of
age for voluntary military service; reserve obligation to
age 45 (2006)
Manpower available for military service:
males age 16-49: 242,567
females age 16-49: 238,556 (2008 est.)
Manpower fit for military service:
males age 16-49: 189,282
females age 16-49: 202,350 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 9,077
females age 16-49: 8,728 (2008 est.)
Military expenditures - percent of GDP: 2.2%
(2005 est.)','3305f51516166115adf4294c64a07db974574ac1d35cc0109bd8fea76b0f7c85','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26c5da108cc090fee526a4f50b73c299c5a0f25b223f9eb28eeef9957e324168',2008,'FI','Finland','military-and-security',600,'’ i
Military branches: Finnish Defense Forces (FDF): ''
Army, Navy (includes Coastal Defense Forces), Air
Force (Suomen llmavoimat) (2007)
Military service age and obligation: 18 years of
age for male voluntary and compulsory national
military and nonmilitary service; service obligation 3
6-12 months (2007)
Manpower available for military service:
males age 16-49: 1,169,910
females age 16-49: 1,121,187 (2008 est.)
Manpower fit for military service:
males age 16-49: 965,1 31
females age 16-49: 923,224 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 34,152
females age 16-49: 32,870 (2008 est.) ,
Military expenditures - percent of GDP: 2%
(2005 est.)','833847b2ab4fef4db792e96707b375be7ca2ac474eeea97016cedcef02a25d65','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e8db71f21105ce66e400ba6b9ec7767cb3e2277f50f2719f55815ff56bb6e95',2008,'KI','Kiribati','military-and-security',612,'Military branches: no regular military forces;
Gendarmerie and National Police Force (2007)
Manpower available for military service:
males age 16-49: 79,540 (2008 est.)
Manpower fit for military service:
males age 16-49: 64,287 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 2,699 (2008 est.)
Military - note: defense is the responsibility of','2b448957f06f4bd0688c0481b998240735ff06d4bd27c8f55c1e180e388a0e51','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83952af8388b7c4ccc89318d7fbf6abfccd62cecf0f2e7276ed0f967af12faa8',2008,'MU','Mauritius','military-and-security',620,'Military - note: defense is the responsibility of
Military branches: no regular military forces;
National Police Force, Special Mobile Force, National
Coast Guard (2007)
Manpower available for military service:
males age 16-49: 341 ,018 (2008 est.)
Military expenditures - percent of GDP: 0.3%
(2006 est.)','c27a15ea9f38e08ba77e9fc5d394222ae6928dff5480efaca4ec37b4ca882895','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f05a9c3ef266f603c12eb547e28db31b04b00a74c29836f12909ac601d5abefa',2008,'GN','Guinea','military-and-security',630,'Military branches: Army, Navy, Air Force, National
Gendarmerie, National Police
Military service age and obligation: 20 years of
age for compulsory and voluntary military sen/ice
(2007)
Manpower available for military service:
males age 16-49: 331,181
females age 16-49: 332,498 (2008 est.)
Manpower fit for military service:
males age 16-49: 192,717
females age 16-49: 188,539 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 16,558
females age 16-49: 16,577 (2008 est.)
Military expenditures - percent of GDP: 3.4%
(2005 est.)
Military branches: Office of the Chief of Defense:
Gambian National Army (National Guard, GNA),
Gambian Navy (GN) (2008)
Military service age and obligation: 1 8 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 379,668
females age 16-49: 384,438 (2008 est.)
Manpower fit for military service:
males age 16-49: 230,202
females age 16-49: 244,480 (2008 est.)
Military expenditures - percent of GDP: 0.5%
(2006)
Military branches: in accordance with the peace
agreement, the Palestinian Authority is not permitted
conventional military forces; there are, however,
public security forces (2008)
Manpower available for military service:
males age 16-49: 337,670 (2008 est.)
Manpower fit for military service:
males age 16-49: 291 ,467 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 19,567 (2008 est.)
Military expenditures - percent of GDP: NA
Military branches: Armed Forces: Army, Navy
(Marine Guineenne, includes Marines), Air Force,
Presidential Guard (2008)
248
Guinea (continued)
Military service age and obligation: 18 years of
age for compulsory military service; 2-year conscript
service obligation (2006)
Manpower available for military service:
males age 16-49: 2,230,049
females age 16-49: 2,193,236 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,268,193
females age 16-49: 1 ,259,913 (2008 est.)
Military expenditures - percent of GDP: 1 .7%
(2006)','9deb5dac56155106adfbb714ea9a3cdb48d4d26221f8e9d677411e8de4a71411','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ceab9e6006f13caa01caeccd7160cd82bd4858c7fb802098aeffcf5739345882',2008,'DE','Germany','military-and-security',634,'Military branches: Georgian Armed Forces: Land
Forces, Navy, Air and Air Defense Forces, National
Guard (2008)
Military service age and obligation: 18 to
34 years of age for compulsory and voluntary active
duty military service; conscript service obligation -
18 months (2005)
Manpower available for military service:
males age 16-49: 1,11 3,251
females age 16-49: 1,168,021 (2008 est.)
Manpower fit for military service:
males age 16-49: 91 0,720
females age 16-49: 967,566 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 35,917
females age 16-49: 34,566 (2008 est.)
Military expenditures - percent of GDP: 0.59%
(2005 est.)
Military - note: a CIS peacekeeping force of Russian
troops is deployed in the Abkhazia region of Georgia
together with a UN military observer group; a Russian
peacekeeping battalion is deployed in South Ossetia
Military branches: Federal Armed Forces
(Bundeswehr): Army (Heer), Navy (Deutsche Marine,
includes naval air arm), Air Force (Luftwaffe), Joint
Service Support Command (Streitkraeftebasis),
Central Medical Service (Zentraler Sanitaetsdienst)
(2006)
Military service age and obligation: 1 8 years of
age (conscripts serve a 9-month tour of compulsory
military service) (2004)
Manpower available for military service:
males age 16-49: 1 9,594,1 1 8
females age 16-49: 18,543,955 (2008 est.)
Manpower fit for military service:
males age 16-49: 15,906,930
females age 16-49: 15,051 ,183 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 442,972
females age 16-49: 420,801 (2008 est.)
Military expenditures - percent of GDP: 1 .5%
(2005 est.)
Military branches: Army (2007)
Military service age and obligation: 17-25 years of
age for male and female voluntary military service;
soldiers under 1 8 are not deployed into combat or with
peacekeeping missions; no conscription (2008)
Manpower available for military service:
males age 16-49: 116,305
females age 16-49: 1 14,566 (2008 est.)
Manpower fit for military service:
males age 16-49: 95,152
females age 16-49: 93,792 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 3,066
females age 16-49: 2,909 (2008 est.)
Military expenditures - percent of GDP: 0.9%
(2005 est.)
Military branches: no regular military forces
Manpower available for military service:
males age 16-49: 121 ,825 (2008 est.)
Manpower fit for military service:
males age 16-49: 100,826 (2008 est.)
Military - note: defense is the responsibility of China
Military branches: Army of the Republic of
Macedonia (ARM): Joint Operational Command, with
subordinate Air Wing (Makedonsko Voeno
Vozduhoplovstvo, MW), Special Operations
Regiment (2007)
Military service age and obligation: 18 years of
age for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 532,856
females age 16-49: 513,684 (2008 est.)
Manpower fit for military service:
males age 16-49: 444,693
females age 16-49: 428,341 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 15,141
females age 16-49: 14,434 (2008 est.)
Military expenditures - percent of GDP: 6%
(2005 est.)','9a6f95c78c7698e521ed8a33e22c5306bcf15cb0823fbeeb38c25744958d2cec','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29e2b04212806fce13028ce149ef92382f33c4e61831b5cd830bda501d742220',2008,'GH','Ghana','military-and-security',644,'Military branches: Ghanaian Army, Ghanaian
Navy, Ghanaian Air Force (2007)
Military service age and obligation: 1 8 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 5,802,096
females age 16-49: 5,729,939 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,737,481
females age 16-49: 3,729,699 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 273,265
females age 16-49: 267,204 (2008 est.)
Military expenditures - percent of GDP: 0.8%
(2006 est.)','0b9d951a04cdc732744e59792b362d9990cd14c15547368dc29ba1336aaae3bc','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f78327dbd764c1a5a16c551af20331f2f57ebd60ef7a76113949dc80063f9ce',2008,'ES','Spain','military-and-security',655,'Military branches: Royal Gibraltar Regiment
Manpower available for military service:
males age 16-49: 6,308 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,244 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 190 (2008 est.)
Military - note: defense is the responsibility of the
UK; the Royal Gibraltar Regiment replaced the last
British regular infantry forces in 1 992','06ed0509e05891a237691a396f4b1961801a50c424b8636bf6db6f71e0128e28','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34e10e6bb90ac091945d56ff22146f2c3e7bef93efe9d48cb89ee3d1f0db6514',2008,'GR','Greece','military-and-security',663,'Military branches: Hellenic Army (Ellinikos Stratos,
ES), Hellenic Navy (Ellinikos Polemiko Navtiko, EPN),
Hellenic Air Force (Elliniki Polimiki Aeroporia, EPA)
(2007)
Military service age and obligation: 18 years of
age for compulsory military service; during wartime
the law allows for recruitment beginning January of
the year of inductee’s 18th birthday, thus including 17
year olds; 17 years of age for volunteers; conscript
service obligation - 12 months for the Army, Air Force;
15 months for Navy; women are eligible for voluntary
military service (2007)
Manpower available for military service:
males age 16-49: 2,535,1 74
females age 16-49: 2,517,273 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,084,469
females age 16-49: 2,065,956 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 53,858
females age 16-49: 50,488 (2008 est.)
Military expenditures • percent of GDP: 4.3%
(2005 est.)','a67e58d7dddbfb98a47aa77587d6b5b87d9f2e8dee55d405ab96ac8a3ca073c1','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7453002e29c8efa77d5fee626df3e8390f50d31ea344cbc6eca3b8ae36e453c1',2008,'GD','Grenada','military-and-security',673,'Military branches: no regular military forces; Royal
Grenada Police Force (includes Coast Guard) (2007)
Manpower available for military service:
males age 16-49: 27,309 (2008 est.)
Manpower fit for military service:
males age 16-49: 20,249 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 ,034 (2008 est.)
Military expenditures - percent of GDP: NA
Military branches: National Armed Forces (Fuerza
Armada Nacionale, FAN): Ground Forces or Army
(Fuerzas Terrestres or Ejercito), Naval Forces
(Fuerzas Navales or Armada; includes Marines, Coast
Guard), Air Force (Fuerzas Aereas or Aviacion),
Armed Forces of Cooperation or National Guard
(Fuerzas Armadas de Cooperacion or Guardia
Nacional)
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscript service obligation - 30 months; all citizens of
military service age (between 1 8 and 50 years old) are
obligated to register for military service (2007)
Manpower available for military service:
males age 16-49: 6,647,124
females age 16-49: 6,801 ,1 33 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,280,974
females age 16-49: 5,768,814 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 275,323
females age 16-49: 274,106 (2008 est.)
Military expenditures - percent of GDP: 1 .2%
(2005 est.)
Military branches: People’s Armed Forces:
People’s Army of Vietnam (PAVN) (includes People’s
Navy Command (with naval infantry, coast guard), Air
and Air Defense Force (Kon Quan Nhan Dan), Border
Defense Command), People’s Public Security Forces,
Militia Force, Self-Defense Forces (2005)
Military service age and obligation: 18 years of
age (male) for compulsory military service; females
may volunteer for active duty military service;
conscript service obligation - 2 years (3 to 4 years in
the navy); 1 8-45 years of age (male) or 1 8-40 years of
aqe (female) for Militia Force or Self Defense Forces
(2006)
Manpower available for military service:
males age 16-49: 24,586,328
females age 16-49: 24,335,132 (2008 est.)
Vietnam (continued)
Manpower fit for military service:
males age 16-49: 18,849,274
females age 16-49: 20,575,884 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 903,734
females age 16-49: 845,306 (2008 est.)
Military expenditures - percent of GDP: 2.5%
(2005 est.)','743e77db04c356862a1904f2cf182d9b035e6a5e51113ce0f38441be0a2e390b','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8092199181f91d3f734bc4658f804023b6f6a3721fd92527a0586ccdec46c2af',2008,'BZ','Belize','military-and-security',685,'Military branches: Army, Navy (includes Marines),
Air Force
Military service age and obligation: all male
citizens between the ages of 18 and 50 are liable for
military service; conscript service obligation varies
from 1 2 to 24 months; women can serve as officers
(2007)
Manpower available for military service:
males age 16-49: 2,861 ,696
females age 16-49: 3,062,967 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,31 0,272
females age 16-49: 2,622,450 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 161,550
females age 16-49: 159,760 (2008 est.)
Military expenditures - percent of GDP: 0.4%
(2006)','df2f9f1239b7f3d7e7c1852d242b37b60b45a0a244d2344f3db049b2ab36e549','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99677d271de6a658602938e09385fc28e832d5b58d3c535c2cfd022e9fe8716b',2008,'GW','Guinea-Bissau','military-and-security',701,'Military branches: People’s Revolutionary Armed
Force (FARP): Army, Navy, Air Force; paramilitary
force
Military service age and obligation: 18 years of
age for selective compulsory military service (2006)
Manpower available for military service:
males age 16-49: 344,087
females age 16-49: 347,886 (2008 est.)
Manpower fit for military service:
males age 76-49: 1 88,605
females age 16-49: 195,429 (2008 est.)
Military expenditures - percent of GDP: 3.1 %
(2005 est.)','bfbbadfb6399d49c217df812f26bae00546ece6ecef9ef36d68cc048a9b6238c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('410ea256f60ec1821c6739e7b8bb1963dd5ccadd280924a42fe2a99d0e2efc5a',2008,'GY','Guyana','military-and-security',709,'Military branches: Guyana Defense Force: Army
(includes Coast Guard, Air Corps) (2007)
Military service age and obligation: 1 8 years of
age for voluntary military service; no conscription (2008)
Manpower available for military service:
males age 16-49: 220,797 (2008 est.)
Manpower fit for military service:
males age 16-49: 150,623 (2008 est.)
Military expenditures - percent of GDP: 1 .8%
(2006)
Guyana (continued)
Military branches: National Army (Nationaal Leger,
NL; includes Naval Wing, Air Wing) (2007)
Military service age and obligation: 1 8 years of
age (est.); no conscription
Manpower available for military service:
males age 16-49: 1 30,534
females age 16-49: 130,243 (2008 est.)
Manpower fit for military service:
males age 16-49: 105,770
females age 16-49: 109,666 (2008 est.)
Military expenditures - percent of GDP: 0.6%
(2006 est.)
Military branches: no regular military forces
Military - note: Svalbard is a territory of Norway,
demilitarized by treaty on 9 February 1920','75170eb70c7521df8dda854eb70ca578b4d5794c02c2b79b7df109045da1a5f5','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5e1b8fd3b00748b5ac887df356eaa0b27bb095ecfd8e1bf6c95d86b588a2529',2008,'CU','Cuba','military-and-security',713,'Military branches: no regular military forces - small
Coast Guard; the regular Haitian Armed Forces
(FAdH) - Army, Navy, and Air Force - have been
demobilized but still exist on paper unless they are
constitutionally abolished (2007)
Manpower available for military service:
males age 16-49: 2,047,083
females age 16-49: 2,047,953 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,303,743
females age 16-49: 1 ,332,316 (2008 est.)
256
Haiti (continued)
Manpower reaching militarily significant age
annually:
males age 16-49: 105,655
females age 16-49: 104,376 (2008 est.)
Military expenditures - percent of GDP: 0.4%
(2006)
Military - note: defense is the responsibility of
Australia; Australia conducts fisheries patrols
Military branches: Secretariat of National Defense
(Secretaria de Defensa Nacional, Sedena): Army
(Ejercito, includes Mexican Air Force (Fuerza Aerea
Mexicana, FAM)); Secretariat of the Navy (Secretaria
de Marina, Semar): Mexican Navy (Armada de
Mexico, ARM, includes Naval Air Force (FAN) and
naval infantry) (2008)
Military service age and obligation: 1 8 years of
age for compulsory military service, conscript service
obligation - 12 months; 16 years of age with consent for
voluntary enlistment; conscripts serve only in the Army;
Navy and Air Force service is all voluntary; women are
eligible for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 27,774,688
females age 16-49: 29,376,791 (2008 est.)
Manpower fit for military service:
males age 16-49: 22,188,284
females age 16-49: 24,884,614 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1,11 0,544
females age 16-49: 1 ,073,223 (2008 est.)
Military expenditures - percent of GDP: 0.5%
(2006 est.)
Military branches: Army, Royal Navy (includes
Royal Marines), Royal Air Force
Military service age and obligation: 16-33 years of
age (officers 17-28) for voluntary military service (with
parental consent under 18); women serve in military
services, but are excluded from ground combat
positions and some naval postings; must be citizen of
the UK, Commonwealth, or Republic of Ireland;
reservists serve a minimum of 3 years, to age 45 or
55; 16 years of age for voluntary military service by
Nepalese citizens in the Brigade of the Gurkhas;
1 6-34 years of age for voluntary military service by
Papua New Guinean citizens (2008)
Manpower available for military service:
males age 16-49: 14,729,500
females age 16-49: 14,125,600 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,121,602
females age 16-49: 1 1 ,616,582 (2008 est.)
Military expenditures - percent of GDP: 2.4%
(2005 est.)
Military branches: US Army, US Navy (includes
Marine Corps), US Air Force, US Coast Guard; note -
Coast Guard administered in peacetime by the
Department of Homeland Security, but in wartime
reports to the Department of the Navy (2008)
Military service age and obligation: 18 years of
age; 17 years of age with written parental consent
(2006)
Manpower available for military service:
males age 16-49: 72,715,332
females age 16-49: 71 ,638,785 (2008 est.)
Manpower fit for military service:
males age 16-49: 59,413,358
females age 16-49: 59,187,183 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 2,1 86,440
females age 16-49: 2,079,688 (2008 est.)
Military expenditures - percent of GDP: 4.06%
(2005 est.)','9ab471f145014a4bec571312844e6c86bce5b58ba4419742d0773b511e15bb26','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e728d6811f9d5528706bd2e09b5a487d771ae30f43e2cd8d09edacd5c470a791',2008,'IT','Italy','military-and-security',722,'Military branches: Pontifical Swiss Guard (Corpo
della Guardia Svizzera Pontificia) (2007)
Military - note: defense is the responsibility of Italy;
ceremonial and limited security duties performed by
Pontifical Swiss Guard
Military branches: Italian Army (Esercito Italiano,
El), Italian Navy (Marina Militare Italiana, MMI), Italian
Air Force (Aeronautica Militare Italiana, AMI),
Carabinieri Corps (Arma dei Carabinieri, CC) (2008)
Military service age and obligation: 18-27 year of
age for voluntary military service; conscription
abolished January 2005; women may serve in any
military branch; 10-month service obligation, with a
reserve obligation to age 45 (Army and Air Force) or
39 (Navy) (2006)
Manpower available for military service:
males age 16-49: 13,884,079
females age 16-49: 13,158,378 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 1 ,285,488
females age 16-49: 10,680,672 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 290,740
females age 16-49: 273,569 (2008 est.)
Military expenditures - percent of GDP: 1 .8%
(2005 est.)
Military branches: no regular military forces;
Voluntary Military Force (Corpi Militari Voluntar) performs
ceremonial duties and limited police functions (2006)
Military service age and obligation: 16-55 for
voluntary service in Voluntary Military Force (2006)
Manpower available for military service:
males age 16-49: 6,613 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,345 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 156 (2008 est.)
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of Italy
Military branches: Swiss Armed Forces: Land
Forces, Swiss Air Force (Schweizer Luftwaffe) (2007)
Military service age and obligation: 1 9 years of
age for male compulsory military service; 18 years of
age for voluntary male and female military service; the
Swiss Constitution states that "every Swiss male is
obliged to do military service"; every Swiss male has
to serve at least 260 days in the armed forces;
conscripts receive 18 weeks of mandatory training,
followed by seven 3-week intermittent recalls for
training during the next 10 years (2008)
Manpower available for military service:
males age 16-49: 1,852,580
females age 16-49:1, 807, 667 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,513,984
females age 16-49: 1,478,761 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 49,205
females age 16-49: 45,220 (2008 est.)
Military expenditures - percent of GDP: 1%
(2005 est.)
Military branches: Syrian Armed Forces: Syrian
Arab Army (includes Syrian Arab Navy), Syrian Arab
Air and Air Defense Force (includes Air Defense
Command) (2008)
Military service age and obligation: 18 years of
age for compulsory military service; conscript service
obligation - 30 months (18 months in the Syrian Arab
Navy); women are not conscripted but may volunteer
to serve (2004)
Manpower available for military service:
males age 16-49: 5,251 ,875
females age 16-49: 4,966,367 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,242,401
females age 16-49: 4,218,648 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 215,734
females age 16-49: 203,106 (2008 est.)
Military expenditures - percent of GDP: 5.9%
(2005 est.)','f64b9e2749971567d3c0c293192c7b30c267b4470b863131f9940afb1c32403e','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32a3a687d8e53087f50fa4d22a65bca10096053a28a140c193c2e7b3d6c3d1b5',2008,'HN','Honduras','military-and-security',730,'Military branches: Army, Navy (includes Naval
Infantry), Honduran Air Force (Fuerza Aerea
Hondurena, FAH) (2008)
Military service age and obligation: 1 8 years of
age for voluntary 2 to 3-year military service (2004)
Manpower available for military service:
males age 16-49: 1 ,868,940
females age 16-49: 1 ,825,770 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,359,406
females age 16-49: 1 ,371 ,418 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 90,876
females age 16-49: 87,292 (2008 est.)
Military expenditures - percent of GDP: 0.6%
(2006 est.)','df7e945810dd30de5e91123d620a690ceed3c492bfb84fa788e186ae2539b9e5','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('319c9156df13b24f45089bf3ffaf2fa314d6ad30008a156861e1d9c2db11d07c',2008,'HK','Hong Kong','military-and-security',739,'Military branches: no regular indigenous military
forces; Hong Kong garrison of China’s People’s
Liberation Army (PLA) includes elements of the PLA
Ground Forces, PLA Navy, and PLA Air Force; these
forces are under the direct leadership of the Central
Military Commission in Beijing and under
administrative control of the adjacent Guangzhou
Military Region (2007)
Manpower available for military service:
males age 16-49: 1,772,820
females age 16-49: 1 ,941 ,448 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,438,165
females age 16-49: 1 ,561 ,252 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 42,173
females age 16-49: 38,753 (2008 est.)
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of China','48dae9a2ea1307d9fa68ed7da46a2d0b80042d3889c78a8d7b64c71dce3ab43b','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3db1b5b86e00854fcddece11065bf9caf8a8546f50e19b0b9d2a7ca2f69bd780',2008,'HU','Hungary','military-and-security',747,'Military branches: Ground Forces, Hungarian Air
Force (Magyar Legiero, ML) (2008)
Military service age and obligation: 18 years of
age for voluntary military service; conscription
abolished in June 2004; 6-month service obligation,
with reserve obligation to age 50 (2006)
Manpower available for military service:
males age 16-49: 2,391 ,400
females age 16-49: 2,337,240 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,890,105
females age 16-49: 1 ,943,422 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 62,197
females age 16-49: 59,267 (2008 est.)
Military expenditures - percent of GDP: 1 .75%
(2005 est.)','77bd5b4e169a336a6d1acea83f7b0e9f2ea3d1f5e2d582bb7f1648920d91c02c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('887971987c7f9ac2f3387e31bd411a5d206a8f9ba74f04094c68c899962da5e2',2008,'IS','Iceland','military-and-security',755,'Military branches: no regular military forces;
Icelandic National Police (2008)
Manpower available for military service:
males age 16-49: 74,896 (2008 est.)
Manpower fit for military service:
males age 16-49: 62,342 (2008 est.)
Military expenditures - percent of GDP: 0%
(2005 est.)
Military - note: Iceland has no standing military
force; under a 1 951 bilateral agreement - still valid - its
defense was provided by the US-manned Icelandic
Defense Force (IDF) headquartered at Keflavik;
however, all US military forces in Iceland were
withdrawn as of October 2006; although wartime
defense of Iceland remains a NATO commitment, in
April 2007, Iceland and Norway signed a bilateral
agreement providing for Norwegian aerial surveillance
and defense of Icelandic airspace (2008)
Military - note: defense is the responsibility of','578ba5f57fb7019d6aa0196fe18cc87a978251948a98df3220b7b77bae0b3016','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b1d2dd9dd65a36811f0c59f4ef1eafc9d878003b5eebbc372b6ea22c0962ef8',2008,'IN','India','military-and-security',763,'Military branches: Army, Navy (includes naval air
arm), Air Force, Coast Guard (2008)
Military service age and obligation: 16 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
mates age 16-49: 301 ,094,084
females age 16-49: 283,047,141 (2008 est.)
Manpower fit for military service:
males age 16-49: 231,161,111
females age 16-49: 236,633,962 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 1 ,592,516
females age 16-49: 10,636,857 (2008 est.)
Military expenditures - percent of GDP: 2.5%
(2006)','79540c9204021140c4baa1e0d8e33dbbfc9027ff26797cdd659a42dd702e3a49','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b6a3a26e9773e10bb182206a75bd34b963cbfe2d225f26368272812ec183383',2008,'IQ','Iraq','military-and-security',774,'Military branches: Iraqi Armed Forces: Iraqi Army
(includes Iraqi Special Operations Force, Iraqi
Intervention Force), Iraqi Navy (former Iraqi Coastal
Defense Force), Iraqi Air Force (former Iraqi Army Air
Corps) (2005)
Military service age and obligation: 1 8-40 years of
age for voluntary military service (2006)
Manpower available for military service:
males age 16-49: 7,086,200
females age 16-49: 6,808,954 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,019,795
females age 16-49: 5,878,905 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 302,926
females age 16-49: 294,747 (2008 est.)
Military expenditures - percent of GDP: 8.6%
(2006)
284
Iraq (continued)','33d46dc45274a9e54604fc155b1b8d582b11e24156ce294e69c428d77169ba1e','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a2e0da5755788367e72806fb7b7815d9917cfca9c4185ae6a6928127055fe77',2008,'IE','Ireland','military-and-security',782,'Military branches: Irish Defense Forces (Oglaigh na
h-Eireann): Army (includes Naval Service and Air
Corps) (2008)
Military service age and obligation: 1 7-25 years of
age for voluntary military service; 1 6 years of age can
be recruited for apprentice specialist positions;
maximum obligation 12 years; 17-35 years of age for
the Reserve Defense Forces (2008)
Manpower available for military service:
males age 16-49: 1 ,024,635
females age 16-49: 1 ,024,276 (2008 est.)
Manpower fit for military service:
males age 16-49: 854,982
females age 16-49: 852,592 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 28,610
females age 16-49: 27,095 (2008 est.)
Military expenditures ■ percent of GDP: 0.9%
(2005 est.)','059fb94684a25dec878f7e599615319ff00a1e2f93dcc39882321ecc008c9b33','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93baff279850e6f608e4ba5281850bcc9c4975f3ff98f2ab323ba707b8d986d7',2008,'IL','Israel','military-and-security',794,'Military - note: defense is the responsibility of the
UK
Military branches: Israel Defense Forces (IDF),
Israel Naval Forces (INF), Israel Air Force (IAF)
(2007)
Military service age and obligation: 1 8 years of
age for compulsory (Jews, Druzes) and voluntary
(Christians, Muslims, Circassians) military service;
both sexes are obligated to military service; conscript
service obligation - 36 months for enlisted men, 21
months for enlisted women, 48 months for officers;
reserve obligation to age 41-51 (men), 24 (women)
(2008)
Manpower available for military service:
males age 16-49: 1 ,717,362
females age 16-49: 1 ,636,574 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,452,926
females age 16-49: 1,383,796 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 60,602
females age 16-49: 57,532 (2008 est.)
Military expenditures - percent of GDP: 7.3%
(2006)
Military expenditures - percent of GDP: NA','acb9364614c20cb95539087a2c7a4fd96ca2d071431331a9609dee5c62c3e85c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f92bc39a05bc5e3e9bd8a9500b22362b96b1849bd9d7eaa1df83a9c4d7d82893',2008,'JO','Jordan','military-and-security',815,'Military branches: Jordanian Armed Forces (JAF):
Royal Jordanian Land Force, Royal Jordanian Navy,
Royal Jordanian Air Force (Al-Quwwat al-Jawwiya
al-Malakiya al-Urduniya), Special Operations
Command (Socom); Public Security Directorate
(normally falls under Ministry of Interior, but comes
under JAF in wartime or crisis situations) (2006)
Military service age and obligation: 1 7 years of
age for voluntary military service; conscription at age
18 was suspended in 1999, although all males under
age 37 are required to register; women not subject to
conscription, but can volunteer to serve in non-combat
military positions (2004)
Manpower available for military service:
males age 16-49: 1 ,812,551
females age 16-49: 1,559,155 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,546,766
females age 16-49: 1 ,339,366 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 68,067
females age 16-49: 65,512 (2008 est.)
Military expenditures - percent of GDP: 8.6%
(2006)','8339f5a509b1dabd3f957deb7bc1eb7e88ab15cd700b5f1382d2c58a26b47f31','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9b7c59bc342a13fe315f2a69f329eec3719a7817c0d09e34e01cff1b78a3b2c',2008,'TM','Turkmenistan','military-and-security',828,'Military branches: Ground Forces, Naval Force, Air
and Air Defense Forces, Republican Guard
Military service age and obligation: 18 years of
age for compulsory military service; conscript service
obligation - 2 years; minimum age for volunteers NA
(2004)
Manpower available for military service:
males age 16-49: 4,176,731
females age 16-49: 4,219,636 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,871 ,205
females age 16-49: 3,551 ,032 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 145,495
females age 16-49: 140,149 (2008 est.)
Military expenditures - percent of GDP: 0.9%
(Ministry of Defense expenditures) (FY02)
309
Kazakhstan (continued)
Military branches: Ground Forces, Navy, Air and Air
Defense Forces (2007)
Military service age and obligation: 1 8-30 years of
age for compulsory military service; 2-year conscript
service obligation (2006)
Manpower available for military service:
males age 16-49: 1 ,316,698
females age 16-49: 1 ,331 ,005 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,064,965
females age 16-49: 1 ,1 36,553 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 57,615
females age 16-49: 55,426 (2008 est.)
Military expenditures - percent of GDP: 3.4%
(2005 est.)','8b8027c22766419fea33c7e4ca2a3910752dea123c1de9d470487863e270040f','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2786e7b25a8bb6c243130158879d10c8e91e783bd2296db8213d93eaf4801c97',2008,'KE','Kenya','military-and-security',836,'Military branches: Kenyan Army, Kenyan Navy,
Kenyan Air Force (2007)
Military service age and obligation: 18 years of
age (est.) for voluntary service, with a 9-year
obligation (2007)
Manpower available for military service:
males age 16-49: 9,044,685
females age 16-49: 8,805,736 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,688,259
females age 16-49: 5,396,166 (2008 est.)
Military expenditures - percent of GDP: 2.8%
(2006)','69fabc4a68d0181408b545e92813066606ce15ef355e6a5984f9366a45e319f4','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('217a26a02012e77e9714c6608ae9d58cd2ecf263f942765933bfcfde614bf855',2008,'CK','Cook Islands','military-and-security',845,'Military branches: no regular military forces
(constitutionally prohibited); Police Force (2008)
Manpower available for military service:
males age 16-49: 26,377 (2008 est.)
Manpower fit for military service:
males age 16-49: 17,577 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 ,247 (2008 est.)
Military expenditures - percent of GDP: NA
Military - note: Kiribati does not have military forces;
defense assistance is provided by Australia and NZ
Military branches: North Korean People’s Army:
Ground Forces, Navy, Air Force; civil security forces
(2005)
Military service age and obligation: 17 years of
age (2004)
Manpower available for military service:
males age 16-49: 6,225,747
females age 16-49: 6,188,270 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,141 ,240
females age 16-49: 5,139,447 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 199,628
females age 16-49: 192,388 (2008 est.)
Military expenditures - percent of GDP: NA
Military branches: Republic of Korea Army, Navy
(includes Marine Corps), Air Force (2008)
Military service age and obligation: 20-30 years o:
age for compulsory military service; conscript service
obligation - 24-28 months, depending on the military
branch involved (to be reduced to 1 8 months beginning
201 6); 1 8 years of age for voluntary military service;
women, in service since 1950, admitted to 7 service
branches, including infantry, but excluded from artillery
armor, anti-air, and chaplaincy corps; some 4,000
women serve as commissioned and noncommissionec
officers, approx. 2.3% of all officers (2007)
Manpower available for military service:
males age 16-49: 1 3,691 ,809
females age 16-49: 13,029,859 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 1 ,282,699
females age 16-49: 10,683,668 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 382,305
females age 16-49: 336,998 (2008 est.)
Military expenditures - percent of GDP:
2.7% (2006)
320
Korea, South (continued)
Military - note: defense is the responsibility of the
US','5fed4b1f7ec6add858fed4ea0c3678f11a84b46efe6821d3ea37d3ae69c5d3e6','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84460063cb5e1f08085413a0943d84413d0d441e6d133e24a7e0bf9438831a9c',2008,'KG','Kyrgyzstan','military-and-security',856,'Military branches: Army, Air Force, National Guard
(2005)
Military service age and obligation: 18 years of
age for compulsory military service (2001)
Manpower available for military service:
males age 16-49: 1 ,398,878
females age 16-49: 1 ,419,374 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,061 ,942
females age 16-49: 1 ,21 1 ,249 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 60,706
females age 16-49: 58,721 (2008 est.)
Military expenditures - percent of GDP: 1 .4%
(2005 est.)
Military branches: Lao People’s Armed Forces
(LPAF): Lao People''s Army (LPA; includes Riverine
Force), Air Force (2008)
Military service age and obligation: 15 years of
age for compulsory military service; minimum
18-month conscript service obligation (2006)
Manpower available for military service:
males age 16-49: 1,549,774
females age 16-49: 1 ,570,702 (2008 est.)
Manpower fit for military service:
males age 16-49: 993,162
females age 16-49: 1 ,052,053 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 73,973
females age 16-49: 72,758 (2008 est.)
Military expenditures - percent of GDP: 0.5%
(2006)
Military - note: serving one of the world’s least
developed countries, the Lao People’s Armed Forces
(LPAF) is small, poorly funded, and ineffectively
resourced; its mission focus is border and internal
security, primarily in countering ethnic Hmong
insurgent groups; together with the Lao People’s
Revolutionary Party and the government, the Lao
People’s Army (LPA) is the third pillar of state
machinery, and as such is expected to suppress
political and civil unrest and similar national
emergencies, but the LPA also has upgraded skills to
respond to avian influenza outbreaks; there is no
perceived external threat to the state and the LPA
maintains strong ties with the neighboring Vietnamese
military (2008)','288f57023755c173c473a365729fd131fdbae4c3cb0d680c3a7ea3493cb37870','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b48b36464b284c90feb3ae4f6b7453feb1f03086add26285fb862575e206b22',2008,'LV','Latvia','military-and-security',864,'Military branches: Latvian Republic Defense Force:
Ground Forces, Navy, Air Force (Latvijas Gaisa
Spelki), Border Guard, Latvian Home Guard (Latvijas
Zemessardze) (2007)
Military service age and obligation: 18 years of
age for voluntary military service; conscription
abolished January 2007; under current law, every
citizen is entitled to serve in the armed forces for life
(2006)
Manpower available for military service:
males age 16-49: 568,683
females age 16-49: 565,826 (2008 est.)
Manpower fit for military service:
males age 16-49: 412,849
females age 16-49: 468,827 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 14,506
females age 16-49: 13,982 (2008 est.)
Military expenditures - percent of GDP: 1 .2%
(2005 est.)','7e079f14f5367df1e7a3a8e09d7710a9986109d7e1816ccc81a2ff1788bce8c6','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f457b74e2d775b5aab41730deaca02eab5b169c04b870959345c3dd22caf01e',2008,'LB','Lebanon','military-and-security',873,'Military branches: Lebanese Armed Forces (LAF):
Army, Navy, and Air Force (2008)
Military service age and obligation: 1 8-30 years of
age for voluntary military service; no conscription
(2007)
Manpower available for military service:
males age 16-49: 1,106,879
females age 16-49: 1,122,595 (2008 est.)
Manpower fit for military service:
males age 16-49: 934,828
females age 16-49: 948,327 (2008 est.)
Military expenditures - percent of GDP: 3.1%
(2005 est.)','59209350f0361eaa1297b2b308c1d6c3008975d9e63a55c165c2d5dc54205f63','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26d2db127528c24a9a33cdab05a8d5d229b273d76f009d91520a3b08c98ba9d3',2008,'LS','Lesotho','military-and-security',882,'Military branches: Lesotho Defense Force (LDF):
Army (includes Air Wing) (2008)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 525,203
females age 16-49: 522,485 (2008 est.)
Manpower fit for military service:
males age 16-49: 262,101
females age 16-49: 238,350 (2008 est.)
Military expenditures - percent of GDP: 2.6%
(2006)
Military ■ note: Lesotho’s declared policy is
maintenance of its independent sovereignty and
preservation of internal security; in practice, external
security is guaranteed by South Africa; restructuring of
the Lesotho Defense Force (LDF) and Ministry of
Defense and Public Service over the past five years
has focused on subordinating the defense apparatus
to civilian control and restoring the LDF’s cohesion;
the restructuring has considerably improved
capabilities and professionalism, but the LDF is
disproportionately large for a small, poor country; the
government has outlined a reduction to a planned
1 ,500-man strength, but these plans have met with
vociferous resistance from the political opposition and
from inside the LDF (2008)','8d0c98dc71f46f7f6405a2068ea91f2112faa24f75cf14507ca672ad0930354b','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ccec5a3d6f88bb188c0be4b2a338ef402d20809fbcbdc94a861f9e4b600b554',2008,'LR','Liberia','military-and-security',890,'Military branches: Armed Forces of Liberia (AFL):
Army, Navy, Air Force
Military service age and obligation: 16 years of
aqe for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 729,813
females age 16-49: 741 ,223 (2008 est.)
Manpower fit for military service:
males age 16-49: 371 ,287
females age 16-49: 373,265 (2008 est.)
Military expenditures - percent of GDP: 1 .3%
(2006 est.)','10bb7df204bd24c14f0fc3417516308821db9303c51e851a934c6ef5c0ab513c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67ab5ce98b148ee0fef64a68ae63e941c5975c16eb0ca57614dd2612721b944e',2008,'LY','Libya','military-and-security',898,'Military branches: Armed Peoples on Duty (APOD,
Army), Libyan Arab Navy, Libyan Arab Air Force
(Al-Quwwat al-Jawwiya al-Jamahiriya al-Arabia
al-Libyya, LAAF) (2008)
Military service age and obligation: 17 years of
age (2004)
Manpower available for military service:
males age 16-49: 1 ,682,183
females age 16-49: 1 ,61 1 ,001 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,439,941
females age 16-49: 1 ,381 ,914 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 61,305
females age 16-49: 58,788 (2008 est.)
Military expenditures - percent of GDP: 3.9%
(2005 est.)','7422cb7dc73a397a8d717e8bb7a8edda699c229392cc571920469c508b2bd2c0','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d7c71ba14f270236cf552f71497265dcb4d66769870dbe8e3a1763b1ddff638',2008,'LI','Liechtenstein','military-and-security',907,'Military branches: no regular military forces
(constitutionally prohibited); Principality of
Liechtenstein National Police (Landespolizei, LP)
(2008)
Manpower available for military service:
males age 16-49: 8,102 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,584 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 202 (2008 est.)
Military - note: Liechtenstein has no military forces,
but is interested in European security policy and is an
active member of the Organization for Security and
Cooperation in Europe (OSCE)','fc2bda5b345b9de0ca3a9baf04bc1a4f1b7a8f63eea8ce1d36b7d8b4f4449d0f','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efa36fd0faf8db46cf017e7fffbb0d5eb2dcda9d607c12149a39d1dea6c0cce5',2008,'LT','Lithuania','military-and-security',915,'Military branches: Ground Forces, Naval Force,
Lithuanian Military Air Forces, National Defense
Volunteer Forces (2005)
Military service age and obligation: 1 9-45 years of
age for compulsory military service; 1 8 years of age
for volunteers; 12-month conscript service obligation
(2006)
Manpower available for military service:
males age 16-49: 915,187
females age 16-49: 906,097 (2008 est.)
Manpower fit for military service:
males age 16-49: 678,434
females age 16-49: 749,483 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 25,907
females age 16-49: 24,735 (2008 est.)
Military expenditures - percent of GDP: 1 .2%
(2006; 1.23% 2007 est.)','e4d5b0b00184a102d91b6f763fb2210dd020898d87d950e2e6f7cbaf7b379a22','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab114068d5ab53c2e652c09a3a73597f74858ce03409b7dd9d7e79b65e4de1cb',2008,'MW','Malawi','military-and-security',923,'Military branches: Malawi Armed Forces: Army
(includes Air Wing and Naval Detachment) (2007)
Military service age and obligation: 1 8 years of
age for voluntary military service; standard obligation
is 2 years of active duty and 5 years of reserve service
(2007)
Manpower available for military service:
males age 16-49: 3,050,444 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,676,117 (2008 est.)
Military expenditures - percent of GDP: 1 .3%
(2006)','fca11fe392b2c0bcd56e2fdc84f1f92c4d29f2adf150dcc087c6fca497d674de','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a7dcf7b581682fc502e3a7c18023e004f779cc820d4e61645f2ba7e6ac490db',2008,'MY','Malaysia','military-and-security',932,'Military branches: Malaysian Armed Forces
(Angkatan Tentera Malaysia, ATM): Malaysian Army
(Tentera Darat Malaysia), Royal Malaysian Navy
(Tentera Laut Diraja Malaysia, TLDM), Royal
Malaysian Air Force (Tentera Udara Diraja Malaysia,
TUDM) (2008)
Military service age and obligation: 1 8 years of
age for voluntary military service (2005)
Manpower available for military service:
males age 16-49: 6,440,338
females age 16-49: 6,280,826 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,374,006
females age 16-49: 5,316,865 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 260,725
females age 16-49: 247,309 (2008 est.)
Military expenditures - percent of GDP: 2.03%
(2005 est.)','dd96fb96badc38b6ee687e77fcbb19eedd5a9d4aa835f08ff80362c9ab861e80','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d63901c0786630164286087474bd7de5f24c24eba4292a2ac6fb5ae251180cc4',2008,'MV','Maldives','military-and-security',941,'Military branches: Maldives National Defense
Force (MNDF): Quick Reaction Force, Security
Protection Group, Coast Guard (2007)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 89,505
females age 16-49: 85,745 (2008 est.)
Manpower fit for military service:
males age 16-49: 72,150
females age 16-49: 69,058 (2008 est.)
Military expenditures - percent of GDP: 5.5%
(2005 est.)
Military - note: the Maldives National Defense Force
(MNDF), with its small size and with little serviceable
equipment, is inadequate to prevent external
aggression and is primarily tasked to reinforce the
Maldives Police Service (MPS) and ensure security in
the exclusive economic zone (2008)','183591b1f63cfef4863220c2456cc35a4e4e154e13c04804f4b58e70532e8762','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b4ab96771f7a997668ce668dcb35a0bae7a1291d76992e32dfa563d8a9a4a8d',2008,'ML','Mali','military-and-security',949,'Military branches: Malian Armed Forces: Army,
Republic of Mali Air Force (Force Aerienne de la
Republique du Mali, FARM), National Guard (2008)
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscript service obligation - 2 years (2008)
Manpower available for military service:
males age 16-49: 2,603,700
females age 16-49: 2,441 ,776 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,594,184
females age 16-49: 1 ,529,871 (2008 est.)
Military expenditures - percent of GDP: 1 .9%
(2006)','afe3ea90d1e50f74f7e967b3618f69be92e09972941920e2e127185962c62a41','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97355f3b3a19e7f97b7bf2d6b982639caac0523f66d1d4ae5124b335ab1b2475',2008,'MT','Malta','military-and-security',959,'Military branches: Armed Forces of Malta (AFM;
includes air and maritime elements) (2007)
Military service age and obligation: 1 7 years 6
months of age for voluntary military service; no
conscription (2008)
Manpower available for military service:
males age 16-49: 96,309
females age 16-49: 92,242 (2008 est.)
Manpower fit for military service:
mates age 16-49: 80,227
females age 16-49: 76,623 (2008 est.)
Military expenditures - percent of GDP: 0.7%
(2006 est.)','7ab022835b63c8a38989a3a617fc021a8610be618a8c6cc1a54d1379c0d4cdf0','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afc94336f3a45ad4fd347f54582962e55658637266850ebb8fcd273e751ac5d3',2008,'MH','Marshall Islands','military-and-security',968,'Military branches: no regular military forces; under
the 1 983 Compact of Free Association, the US has full
authority and responsibility for security and defense of
the Marshall Islands; Marshall Islands Police (2008)
Manpower available for military service:
males age 16-49: 15,708 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,864 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 512 (2008 est.)
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of
the US','01ebdc607caa3b94db5b55be5eaf48ff4f86c1548d32d274bdfc007894eabec5','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af26bcec82ce61a848eed986e5be76229820b11219bbbd440f680861794ac87b',2008,'MR','Mauritania','military-and-security',976,'Military branches: Mauritanian Armed Forces:
Army, Mauritanian Navy (Marine Mauritanienne;
includes naval infantry), Air Force (Force Aerienne
Islamique de Mauritanie, FAIM) (2008)
Military service age and obligation: 1 8 years of
age (est.); conscript service obligation - 2 years;
majority of servicemen believed to be volunteers;
service in Air Force and Navy is voluntary (2006)
Manpower available for military service:
males age 16-49: 740,675
females age 16-49: 744,709 (2008 est.)
Manpower fit for military service:
males age 16-49: 463,305
females age 16-49: 484,777 (2008 est.)
Military expenditures - percent of GDP: 5.5%
(2006)
Military branches: Army, Senegalese Navy (Marine
Senegalaise), Senegalese Air Force (Armee de I’Air
du Senegal) (2008)
Military service age and obligation: 1 8 years of
age for compulsory and voluntary military service;
conscript service obligation - 2 years (2004)
Manpower available for military service:
males age 16-49: 2,943,619
females age 16-49: 2,955,179 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,866,602
females age 16-49: 1 ,947,076 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 141,832
females age 16-49: 139,541 (2008 est.)
Military expenditures - percent of GDP: 1 .4%
(2005 est.)','849c1498ce78c7f90502e90deae915105f3bce15339737d97889e90dcd27b10f','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db40a4a55c780c519ba94d273ac9da9ac4d07987606cd66def8c6bebfe679d0a',2008,'KM','Comoros','military-and-security',981,'Military - note: defense is the responsibility of
France; a small contingent of French forces is
stationed on the island','e8699fcaf7977f97ec3299d0961013fd8a86aceb774463dbeb8751b444a45f60','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d040c92124e8c31101315e6247008f978c242cbf28a5ded50b1a1708800c428',2008,'US','United States','military-and-security',992,'Military branches: National Army: Ground Forces,
Rapid Reaction Forces, Air and Air Defense Forces
(2008)
Military service age and obligation: 18 years of
age for compulsory military service; 1 2-month service
obligation (2006)
Manpower available for military service:
males age 16-49: 1,161,924
females age 16-49: 1,187,771 (2008 est.)
Manpower fit for military service:
males age 16-49: 877,070
females age 16-49: 994,091 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 33,053
females age 16-49: 31,712 (2008 est.)
Military expenditures - percent of GDP: 0.4%
(2005 est.)
Military branches: no regular military forces;
Panamanian Public Forces or PPF includes the
Panamanian National Police (PNP), National Maritime
Service (NMS), and National Air Service (NAS) (2008)
Manpower available for military service:
males age 16-49: 851 ,044 (2008 est.)
Manpower fit for military service:
males age 16-49: 673,103 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 30,348 (2008 est.)
Military expenditures - percent of GDP: 1%
(2006)
Military - note: on 10 February 1990, the
government of then President ENDARA abolished
Panama’s military and reformed the security
apparatus by creating the Panamanian Public Forces;
in October 1994, Panama’s Legislative Assembly
approved a constitutional amendment prohibiting the
creation of a standing military force but allowing the
temporary establishment of special police units to
counter acts of "external aggression"','0885c33f65700bea23827d6b43270db248a4ca3777f472717853dfb0f1dbba8c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa3f107d870ce5fb10e2a1654f0f97ce7c28f233a34cf72221269e62f66cf094',2008,'MC','Monaco','military-and-security',1000,'Military branches: no regular military forces; the
Palace Guard performs ceremonial duties
Manpower available for military service:
males age 16-49: 6,687 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,376 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 191 (2008 est.)
Military - note: defense is the responsibility of','e3b62e1fb023a32a7ea57a9549c86c24919d3292b4b3eed8c121bf521eb6bde8','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c774c8d574e242b7d7e0799e938adbb4383a55f90f508cdaaae75529af14f9e2',2008,'MN','Mongolia','military-and-security',1008,'Military branches: Mongolian Armed Forces:
Mongolian Army, Mongolian Air Force; there is no
navy (2008)
Military service age and obligation: 18-25 years
of age for compulsory military service; conscript
service obligation - 12 months in land or air defense
forces or police; a small portion of Mongolian land
forces (2.5 percent) is comprised of contract
soldiers; women cannot be deployed overseas for
military operations (2006)
Manpower available for military service:
males age 16-49: 865,425
females age 16-49: 860,669 (2008 est.)
Manpower fit for military service:
males age 16-49: 696,652
females age 16-49: 731 ,480 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 29,990
females age 16-49: 29,256 (2008 est.)
Military expenditures - percent of GDP: 1 .4%
(2006)','79636ebea954ae1b0c10fa2df9855ae636b38d765d52bbfcc61e85feea790ccb','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea3bd094cd51f1ee3932e0587e838d1184108305732f3440993cb876dde9282e',2008,'ME','Montenegro','military-and-security',1016,'Military service age and obligation: compulsory
national military service abolished August 2006
Military - note: Montenegrin plans call for the
establishment of a fully professional armed forces','f9896df6eecb0e7411ab60ea0814b8226f4e46e0511ce5e8e3d6ea81e2cf52f4','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc922282997196c27eed59b60d101e26e343637cf5f3e788cb591102bd4f3e1c',2008,'MS','Montserrat','military-and-security',1025,'Military branches: no regular military forces; Royal
Montserrat Police Force (2008)
Manpower available for military service:
males age 16-49: 2,528 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,097 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 67 (2008 est.)
Military - note: defense is the responsibility of the
UK','4eb5ba796e8ba5e9f01120c9e593d8db2452ac67b980973370b05d589e5e967d','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ad9d221fef2842cb0d69422374777994df2b7cadac28bed3aa64f5db2d8a3a0',2008,'GI','Gibraltar','military-and-security',1033,'Military branches: Royal Armed Forces (Forces
Armees Royales, FAR): Royal Moroccan Army
(includes Air Defense), Navy (includes Marines),
Royal Moroccan Air Force (Al Quwwat al Jawyiya al
Malakiya Marakishiya; Force Aerienne Royale
Marocaine) (2008)
Military service age and obligation: 1 8 years of
age for compulsory and voluntary military service;
conscript service obligation - 18 months (2004)
Manpower available for military service:
males age 16-49: 9,152,580
females age 16-49: 9,080,830 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,627,988
females age 16-49: 7,754,873 (2008 est.)
Manpower reaching militarily significant age
annually: j
males age 16-49: 355,479
females age 16-49: 343,016 (2008 est.)
Military expenditures - percent of GDP: 5%
(2003 est.)','b687ffd70eb1d410a2eba46edb1ab30a02ec226668084598f8962d90327e589c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d9a60b08d1d9684ceb028b823f3eb4cf76328748fa972d8197685802daec16a',2008,'MZ','Mozambique','military-and-security',1041,'Military branches: Mozambique Armed Defense
Forces (FADM): Mozambique Army, Mozambique
Navy (Marinha Mocambique, MM), Mozambique Air
Force (Forca Aerea de Mocambique, FAM) (2006)
Military service age and obligation: 18-30 years of
age for compulsory military service; 2-year service
obligation (2006)
405
Manpower available for military service:
males age 16-49: 4,545,975 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,287,526 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 257,261 (2008 est.)
Military expenditures - percent of GDP: 0.8%
(2006)','cd0d0f0f50c2eb928f1113c6b9f38c7a972e3966c0eddd4a1c7fc5748e38fb6c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a8df65970931f8088f96095b559ab4ab234ca61b2d292f5452a1c4f57d065de',2008,'NA','Namibia','military-and-security',1049,'Military branches: Namibian Defense Force: Army,
Navy, Air Wing (2008)
Military service age and obligation: 1 8-25 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 527,948 (2008 est.)
Manpower fit for military service:
males age 16-49: 313,497 (2008 est.)
Military expenditures - percent of GDP: 3.7%
(2006)','ee759f9f6b9833df310d19b9bea58b1af879f3b477e1d7260dad6c03c8b6579e','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e686668c7a0a4f733497676854d4e0f61b9437be7c6d9f94429b4381c0a6afd7',2008,'NR','Nauru','military-and-security',1058,'Military branches: no regular military forces; Nauru
Police Force (2008)
Manpower available for military service:
males age 16-49: 3,470 (2008 est.)
Military expenditures - percent of GDP: NA
Military - note: Nauru maintains no defense forces;
under an informal agreement, defense is the
responsibility of Australia
Military - note: defense is the responsibility of the
US','4363703e0c5fad91afce4adcbfdff8ad891be9b9ccb05f16ce27dd93ca20f8ec','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7241d3974f0ad74795846e9214c6c274571a9560aa8116a1dbf06bcce5a2f4c2',2008,'CN','China','military-and-security',1067,'Military branches: Nepalese Army, Armed Police
Force (2008)
Military service age and obligation: 18 years of
age for voluntary military service; 15 years of age for
military training; no conscription (2008)
Manpower available for military service:
males age 16-49: 7,322,965
females age 16-49: 6,859,064 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,146,958
females age 16-49: 4,724,495 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 335,747
females age 16-49: 312,297 (2008 est.)
Military expenditures - percent of GDP: 1 .6%
(2006)
Military branches: Army, Navy (includes Marine
Corps), Air Force, Coast Guard Administration, Armed
Forces Reserve Command, Combined Service
Forces Command, Armed Forces Police Command
Military service age and obligation: 1 9-35 years of
age for male compulsory military service; service
obligation 1 6 months (to be shortened to 1 4 months as
of July 2007 and to 12 months in 2008); women may
enlist; women in Air Force service are restricted to
noncombat roles; resen/e obligation to age 30 (2007)
Manpower available for military service:
males age 16-49: 6,283,134
females age 16-49: 6,098,599 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,1 12,737
females age 16-49: 5,036,346 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 164,883
females age 16-49: 152,085 (2008 est.)
Military expenditures - percent of GDP: 2.2%
(2006)','fd0a8c78478c56391765a4158d8ab25be64b4342ec95fa736c1e14fc8ed2c917','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d73b047368a5af80b9df1f2d9590abd8177aa77ea8bcdaca17aca78e577a07bf',2008,'NI','Nicaragua','military-and-security',1082,'Military branches: National Army of Nicaragua
(ENN; includes Navy, Air Force) (2008)
Military service age and obligation: 17 years of
age for voluntary military service; tour of duty 1 8-36
months (2008)
Manpower available for military service:
males age 16-49: 1,513,312
females age 1 6-49: 1,507,999 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,235,400
females age 16-49: 1,302,318 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 72,689
females age 16-49: 70,452 (2008 est.)
Military expenditures - percent of GDP: 0.6%
(2006)','1b03ab2d5e97a3ab13ddd554b7f139a565d92eff2fe1b59287417bf77127d12b','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('991e5cd352ba0bcdfa74a72c72ed69f87c0ff680c2336531108389b76e3faba9',2008,'NE','Niger','military-and-security',1090,'Military branches: Nigerien Armed Forces (Forces
Armees Nigeriennes, FAN): Army, Niger Air Force
(2008)
Military service age and obligation: 1 8 years of
age for compulsory military service; 2-year conscript
service obligation (2006)
Manpower available for military service:
males age 16-49: 2,871 ,868
females age 16-49: 2,696,966 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,665,108
females age 16-49: 1 ,548,965 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 50,728
females age 16-49: 143,379 (2008 est.)
Military expenditures - percent of GDP: 1 .3%
(2006)','83d87da851aa1183974aa36e4bfa7cdb5388991bc259dcdb5da71b17610396ff','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d39e0034c8af8e67d893a8c1a194d80f27e0355bfadbcc1a3ecb62f5df799d0',2008,'NG','Nigeria','military-and-security',1098,'Military branches: Nigerian Armed Forces: Army,
Navy, Air Force (2008)
Military service age and obligation: 18 years of
age for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 31 ,929,204
females age 16-49: 30,638,979 (2008 est.)
Manpower fit for military service:
males age 16-49: 18,556,755
females age 16-49: 17,288,225 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 ,533,974
females age 16-49: 1,509,619 (2008 est.)
Military expenditures - percent of GDP: 1 .5%
(2006)','fc12d0d5a93c4718c9301469173462b49008761c58e5aadb06c17260dae26e57','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64fa39534bfcc63b2bfed6ef61a99514d246c1394c6d48dd8ca8fa3f67ab5e9b',2008,'NU','Niue','military-and-security',1108,'Military branches: no regular indigenous military
forces; Police Force
Military - note: defense is the responsibility of New
Zealand','06f4b1586217ae7267a31252b5dff0f342720d9dcaa39e0831399c4040e5bfc9','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b3a7760f6cc662ae0fa7511f5d2446ad2dfc3595d63a0d0136f383c460f2fc6',2008,'MP','Northern Mariana Islands','military-and-security',1125,'Military - note: defense is the responsibility of the
US
Military - note: defense is the responsibility of the
US; the US Air Force is responsible for overall
administration and operation of the island; the launch
support facility is administered by the US Missile
Defense Agency (MDA)','0fbbf27adc5cb23b8b24b183bcb6f4762b7cb0d5cf00d5bf6fe63d6e0c61b0d4','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f534a6b8f4436e53e7607a83be8bb8620ae488460fb9365d2f6da9b64b73066',2008,'NO','Norway','military-and-security',1132,'Military branches: Norwegian Army (Haeren),
Royal Norwegian Navy (Kongelige Norske
Sjoeforsvaret, RNoN; includes Coastal Rangers and
Coast Guard (Kystvakt)), Royal Norwegian Air Force
(Kongelige Norske Luftforsvaret, RNoAF), Home
Guard (Heimevernet, HV) (2007)
Military service age and obligation: 1 8-44 years of
age for male compulsory military service; 16 years of
age in wartime; 17 years of age for male volunteers;
18 years of age for women; 12-month service
obligation, in practice shortened to 8 to 9 months;
although all males between ages of 18 and 44 are
liable for service, in practice they are seldom called to
duty after age 30; reserve obligation to age 35-60; 16
years of age for volunteers to the Home Guard, who
serve 6-month duty tours (2006)
Manpower available for military service:
males age 16-49: 1,078,181
females age 16-49: 1,046,550 (2008 est.)
Manpower fit for military service:
males age 16-49: 888,101
females age 16-49: 862,159 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 32,185
females age 16-49: 30,683 (2008 est.)
Military expenditures - percent of GDP: 1 .9%
(2005 est.)','454d3e03dbe67fede52184a29569f30b01290a317feae400abe2d7a16d1b2842','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e666ce7c76002dc303ed84e5a1f436a74bd8066a78505cfc736f5af2269dc2b9',2008,'OM','Oman','military-and-security',1140,'Military branches: Sultan’s Armed Forces (SAF):
Royal Army of Oman, Royal Navy of Oman, Royal Air
Force of Oman (2008)
Military service age and obligation: 1 8-30 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 802,455
females age 16-49: 626,841 (2008 est.)
Manpower fit for military service:
males age 16-49: 663,881
females age 16-49: 543,410 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 34,238
females age 16-49: 33,139 (2008 est.)
Military expenditures - percent of GDP: 1 1 .4%
(2005 est.)','9c3c61f7f10569b7905fc5194c5950cc32372f9831bee170c4b889cd7e5e25b3','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ab96df9f7b8761e006aff96c458b32238f14fa39d6d35343507c5be359df45e',2008,'PK','Pakistan','military-and-security',1149,'Military branches: Army (includes National Guard),
Navy (includes Marines and Maritime Security
Agency), Pakistan Air Force (Pakistan Fiza''ya) (2008)
Military service age and obligation: 16 years of
age for voluntary military service; soldiers cannot be
deployed for combat until age of 18; the Pakistani Air
Force and Pakistani Navy have inducted their first
female pilots and sailors (2006)
Manpower available for military service:
males age 16-49: 42,633,765
females age 16-49: 40,1 14,017 (2008 est.)
Manpower fit for military service:
males age 16-49: 32,453,913
females age 16-49: 31 ,369,057 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1,976,444
females age 16-49: 1,856,505 (2008 est.)
Military expenditures - percent of GDP: 3%
(2007 est.)
Military branches: no regular military forces; P
National Police (2008)
Manpower available for military service:
males age 16-49: 5,973 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,397 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 179 (2008 est.)
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of
US; under a Compact of Free Association betwe
Palau and the US, the US military is granted acce
the islands for 50 years, but it has not stationed
military forces there (2008)','7156449cad7d5bf897984ee9bf6c87788e87ceb9c45a17cb2af21ecb0acca6ee','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3da395fb7a6295a9ac45ade4485982df526d0497613177ebf8e4cc5d4e363cc',2008,'PH','Philippines','military-and-security',1154,'y - note: occupied by China
ransnational Issues
tes - international: occupied by China, also
d by Taiwan and Vietnam','1bb3b9af108e1da189d8a857bf3eb5b1bb27eb7867660429e0b68d1c4812717e','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05e979176457647e720d3c8d2393c746f6a6b3ea6c9aec709d5ea23c32132efd',2008,'PY','Paraguay','military-and-security',1155,'Background: In the disastrous War of the T riple
Alliance (1865-70) - between Paraguay and Argentina,
Brazil, and Uruguay - Paraguay lost two-thirds of all
adult males and much of its territory. It stagnated
economically for the next half century. In the Chaco War
of 1932-35, Paraguay won large, economically
important areas from Bolivia. The 35-year military
dictatorship of Alfredo STROESSNER ended in 1989,
and, despite a marked increase in political infighting in
recent years, Paraguay has held relatively free and
regular presidential elections since then.','8ff86f4db2e35f84eb7ff6e9698e67795d01f486c8fd05bf2aa5ded8bfccf6e8','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2d81c81d05a386bee97c02600006b11f21f3cd7c6ecaedee267a78da3688af5',2008,'PE','Peru','military-and-security',1163,'Military branches: Peruvian Army (Ejercito
Peruano), Peruvian Navy (Marina de Guerra del Peru,
MGP (includes naval air, naval infantry, and coast
guard)), Peruvian Air Force (Fuerza Aerea del Peru,
FAP) (2008)
Military service age and obligation: 1 8-30 ye
age for voluntary male and female military servic
conscription (2008)
Manpower available for military service:
males age 16-49: 7,653,898
females age 16-49: 7,531,329 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,796,449
females age 16-49: 6,217,524 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 306,260
females age 16-49: 296,819 (2008 est.)
Military expenditures - percent of GDP: 1 .5°/
(2006)','1c1834e877cb6d9aac40c85599f2e0db404c0ff0ad3305a29eb571fe82f3109a','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9823b36dc78a067975ab9e6cdb2403db1936871f26499f8a63d5df7b92ea808c',2008,'MX','Mexico','military-and-security',1179,'Military branches: Polish Armed Forces: Land
Forces (includes Navy (Marynarka Wojenna, MW))
Polish Air Force (Sily Powietrzne Rzeczypospolitej
Polskiej, SPRP) (2008)
Military service age and obligation: 1 7 years of
age for male compulsory military service after Janue
1st of the year of 18th birthday; 17 years of age for
voluntary military service; conscript service obligate
shortened from 1 2 to 9 months in 2005; by 2008, pla
call for at least 60% of military personnel to be
volunteers; only soldiers who have completed their
conscript service are allowed to volunteer for
professional service; as of April 2004, women are or
allowed to serve as officers and noncommissioned
officers (2006)
468
Poland (continued)
Manpower available for military service:
males age 16-49: 9,741 ,508
females age 16-49: 9,514,843 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,937,840
females age 16-49: 7,949,677 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 257,605
females age 16-49: 245,832 (2008 est.)
Military expenditures - percent of GDP: 1 .71 %
(2005 est.)','68fcca09fac27610e79eed6a6feb044ed0ff96998229d4439e474f6ee491315e','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ac853607f0174e43821c20c2f01810606b9c10f595198eaaf7af76f630ac4cf',2008,'DO','Dominican Republic','military-and-security',1193,'Military branches: no regular indigenous military
forces; paramilitary National Guard, Police Force
Military - note: defense is the responsibility of the
US','40d94241fa74da21c3d6d212fe669b3b51ffca68d8fb7edd6576e40238a0785a','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f09752cc9d27850817b5697faa2b3b59449f6a6470076d3582eec51e136537c',2008,'QA','Qatar','military-and-security',1202,'Military branches: Qatari Amiri Land Force (QAl
Qatari Amiri Navy (QAN), Qatari Amiri Air Force
(QAAF) (2007)
Military service age and obligation: 1 8 years o
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 320,383
females age 16-49: 167,475 (2008 est.)
Manpower fit for military service:
males age 16-49: 258,159
females age 16-49: 143,999 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 7,539
females age 16-49: 7,022 (2008 est.)
Military expenditures - percent of GDP: 1 0%
(2005 est.)
476
itar (continued)
rransnational Issues
utes - international: none
icking in persons:
)nt situation: Qatar is a destination country for
and women from South and Southeast Asia who
ate willingly, but are subsequently trafficked into
untary servitude as domestic workers and
■ers, and, to a lesser extent, commercial sexual
station; the most common offense was forcing
ers to accept worse contract terms than those
ir which they were recruited; other conditions
de bonded labor, withholding of pay, restrictions
lovement, arbitrary detention, and physical,
tal, and sexual abuse
ating: Tier 3 - Qatar''s rating was downgraded to
3 in the 2007 report for continuing to detain and
>rt victims rather than providing them protection;
jovernment also failed to increase prosecutions
afficking in a meaningful way in 2006; workers
plaining of working conditions or non-payment of
3S were sometimes prosecuted under false
ges in retaliation','8c5e79856b774ee312bcd26584077bc97073b121eb42ab28305e7539b22964c4','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4449917bc12d76e3ab99140dfaff3f9af71e60b5cd98013276c6c44462525fcf',2008,'RO','Romania','military-and-security',1203,'Background: The principalities of Wallachia and
Moldavia - for centuries under the suzerainty of the
Turkish Ottoman Empire - secured their autonomy in
1 856; they united in 1 859 and a few years later adopted
the new name of Romania. The country gained
recognition of its independence in 1878. It joined the
Allied Powers in World War I and acquired new
territories - most notably Transylvania - following the
conflict. In 1940, Romania allied with the Axis powers
and participated in the 1941 German invasion of the
USSR. Three years later, overrun by the Soviets,
Romania signed an armistice. The post-war Soviet
occupation led to the formation of a Communist
"people’s republic" in 1947 and the abdication of the
king. The decades-long rule of dictator Nicolae
CEAUSESCU, who took power in 1965, and his
Securitate police state became increasingly oppressive
and draconian through the 1980s. CEAUSESCU was
overthrown and executed in late 1989. Former
Communists dominated the government until 1996
when they were swept from power. Romania joined
NATO in 2004 and the EU in 2007.','bf7b2ee2b523235ca0fbcf4c33d40b5dbe50ce4559440d1112b70170ea888390','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52d89fbe7323672bb6653553c7548c94e29c07f9069d84b769acc8393d6f83b6',2008,'UA','Ukraine','military-and-security',1210,'Military branches: Land Forces, Naval Forces,
Romanian Air Force (Fortele Aeriene Romane, FAR),
Special Operations (2008)
Military service age and obligation: 18 years of
age for voluntary military service; conscription
officially ended October 2006; all military inductees
(including women) contract for an initial 5-year term of
service; subsequent voluntary service contracts are
for successive 3-year terms until the age of 36 (2006)
Manpower available for military service:
males age 16-49: 5,682,299
females age 16-49: 5,557,098 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,572,01 7
females age 16-49: 4,644,474 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 127,706
females age 16-49: 121,852 (2008 est.)
Military expenditures - percent of GDP: 1 .9%
(2007 est.)','37f7be09cabb4a7fb4d99fa96624212c6f8c944f0042fb4635367c7e7bcc15de','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f607a7f041734046b589d22cd68aaac63946b504e9799f0e259c09cdfa373bc',2008,'KZ','Kazakhstan','military-and-security',1219,'Military branches: Ground Forces (SV), Navy
(VMF), Air Forces (Voyenno-Vozdushniye Sily, VVS);
Airborne Troops (VDV), Strategic Rocket Troops
(RVSN), and Space Troops (KV) are independent
"combat arms," not subordinate to any of the three
branches; Russian Ground Forces include the
following combat arms: motorized-rifle troops, tank
troops, missile and artillery troops, air defense of
ground troops (2007)
Military service age and obligation: 1 8-27 years of
age for compulsory or voluntary military service;
males are registered for the draft at 17 years of age;
service obligation - 1 year; reserve obligation to age
50; foreign citizens and dual-nationality Russians are
precluded from contract military service (2008)
Manpower available for military service:
males age 16-49: 36,219,908
females age 16-49: 37,019,853 (2008 est.)
Manpower fit for military service:
males age 16-49: 21 ,488,878
females age 16-49: 28,760,976 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 821,103
females age 16-49: 781 ,570 (2008 est.)
Military expenditures - percent of GDP: 3.9%
(2005)
Military branches: Rwandan Defense Forces:
Army, Air Force
Military service age and obligation: 1 8 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 2,430,469
females age 16-49: 2,392,933 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,404,066
females age 16-49: 1,403,700 (2008 est.)
Military expenditures - percent of GDP: 2.9%
(2006 est.)
Military - note: defense is the responsibility of','f93e95056aa4ed7a152b3c40237ce2a9fd6cc3927318c61215bea38e08002df1','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7583543ac1462c4ac194054840a3d23f73e23893e01c4654dbefc14018307b56',2008,'KN','Saint Kitts and Nevis','military-and-security',1224,'Military branches: Saint Kitts and Nevi
Force (includes Coast Guard), Royal Sai
Nevis Police Force
Military service age and obligation: 1
age for voluntary military service; no con
(2008)
Manpower available for military servic
males age 16-49: 10,095
females age 16-49: 10,081 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,064
females age 16-49: 8,464 (2008 est.)
Manpower reaching militarily signifies
annually:
males age 16-49: 366
females age 16-49: 354 (2008 est.)
Military expenditures - percent of GDF
Transnational Issi
Disputes - international: joins other Cc
states to counter Venezuela’s claim that
sustains human habitation, a criterion un
UNCLOS, which permits Venezuela to ex
continental shelf over a large portion of tl
Caribbean Sea
Illicit drugs: transshipment pointforSoi
drugs destined for the US and Europe; si
money-laundering activity
I
492
Lucia
8 km
1 8 mi
*Gros
Islet
''
. CASTRIES
Cul de Sac
Dennery.
Mount
^Gimie
Soufriere*
a Petit Piton
Micoud.
&Gros Piton
Hewanorra
International
Airport
Vieux Fort*
Military branches: no regular military forces;
Saint Lucia Police Force (includes Special Sen
Unit, Coast Guard) (2007)
Manpower available for military service:
males age 16-49: 48,358 (2008 est.)
Manpower fit for military service:
males age 16-49: 38,660 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1,706 (2008 est.)
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of','1b3c614a017935a2266db7755ee6b1ebc30b19e4b55926a315e239253af653ac','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d3bb1b978a5792312bd4f5c358a9b2b7a77f717144a416b66b3c25c108ee330',2008,'PM','Saint Pierre and Miquelon','military-and-security',1229,'(territorial overseas collectivity of France)
O 5 10 km
6 5 10 mi
Miquelon''
Miquelon
(Grande
Miquelon)
Langlade
lie Saint-Pierre
(Petite Miquelon)
*
SAINT-PIERRE
Military - note: defense is the responsibility of','884add0b9c8c35aeb5e5adaddd58d853ef76b091193cc1c581c18df43b3a7449','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a906a0d3fea591f0cf1a015735c7b4377b3e1a4ac5ca73a451cceb78f22854f5',2008,'TT','Trinidad and Tobago','military-and-security',1243,'Military branches: no regular military forces; Royal
Saint Vincent and the Grenadines Police Force, Coast
Guard (2007)
Manpower available for military service:
males age 16-49: 34,373 (2008 est.)
Manpower fit for military service:
males age 16-49: 28,518 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 ,224 (2008 est.)
Military expenditures - percent of GDP: NA
Military branches: Trinidad and Tobago Defense
Force: Ground Force, Coast Guard (includes air wing)
(2004)
Military service age and obligation: 18 years of
age for voluntary military service (16 years of age with
parental consent); no conscription (2008)
Manpower available for military service:
males age 16-49: 301 ,561
females age 16-49: 264,225 (2008 est.)
Manpower fit for military service:
males age 16-49: 21 5,310
females age 16-49: 180,526 (2008 est.)
Military expenditures - percent of GDP: 0.3%
(2006)','dee56f107e36d2df9f60580717cb131097989ad2cfdd809076da4ef49ad99fbd','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14b2ed90e9c05068b596b60031d90cef371f2ca08a912b92f221891d15761e3a',2008,'ET','Ethiopia','military-and-security',1256,'Military branches: Armed Forces of Sao Tome and
Principe (FASTP): Army, Coast Guard of Sao Tome e
Principe (Guarda Costeira de Sao Tome e Principe,
GCSTP), Presidential Guard (2007)
Military service age and obligation: 18 years of
age (est.) (2004)
Manpower available for military service:
males age 16-49: 42,340
females age 16-49: 43,781 (2008 est.)
Manpower fit for military service:
males age 16-49: 33,735
females age 16-49: 36,779 (2008 est.)
Military expenditures - percent of GDP: 0.8%
(2006)
Military - note: Sao Tome and Principe’s army is a
tiny force with almost no resources at its disposal and
would be wholly ineffective operating unilaterally;
infantry equipment is considered simple to operate
and maintain but may require refurbishment or
replacement after 25 years in tropical climates; poor
pay, working conditions, and alleged nepotism in the
promotion of officers have been problems in the past,
as reflected in the 1 995 and 2003 coups; these issues
are being addressed with foreign assistance aimed at
improving the army and its focus on realistic security
concerns; command is exercised from the president,
through the Minister of Defense, to the Chief of the
Armed Forces staff (2005)','354ce1cdb65b446b0c0dcc5dbf79a6aa4006c0a1d8492f62bb8ce775a43a992e','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d0c8ad4b54a5f528b1ba2105ad5af4e13fbfa4171a2739f30381a3268b28f57',2008,'SA','Saudi Arabia','military-and-security',1264,'Military branches: Land Forces (Army), Navy, Air
Force, Air Defense Force, National Guard, Ministry of
Interior Forces (paramilitary)
Military service age and obligation: 18 years of
age (est.); no conscription (2004)
Manpower available for military service:
males age 16-49: 8,547,441
females age 16-49: 6,381 ,098 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,398,417
females age 16-49: 5,525,357 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 272,046
females age 16-49: 261,991 (2008 est.)
Military expenditures - percent of GDP: 10%
(2005 est.)','f220588a9f21c6515c41af57684baba646f33cedf14283a8e2e738a45b43efa4','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c4f7fab1d0e40efe76186007b4f22aa640dcd671b82837212ba93c264319fef',2008,'RS','Serbia','military-and-security',1274,'Military branches: Serbian Armed Forces (Vojska
Srbije, VS): Land Forces Command (includes Serbian
naval force, consisting of a river flotilla on the
Danube), Joint Operations Command, Air and Air
Defense Forces Command (2007)
Military service age and obligation: 1 9-35 years of
age for compulsory military service; under a state of
war or impending war, conscription can begin at age
16; conscription is to be abolished in 2010; 9-month
service obligation, with a reserve obligation to age 60
for men and 50 for women (2007)','4645da2124557083bc299ea7e0c6bfca679a1cbc9b5e7e8f123921bc2c04571c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b85badc3f78d7a6060c5894ea23312c998d83fa3d91526c284c756fb615b402',2008,'MG','Madagascar','military-and-security',1283,'Military branches: Seychelles Defense Force:
Army, Coast Guard (includes Naval Wing, Air Wing),
National Guard (2005)
Military service age and obligation: 1 8 years of
age for voluntary military service (younger with
parental consent); no conscription (2008)
Manpower available for military service:
males age 16-49: 23,598
females age 16-49: 24,424 (2008 est.)
Manpower fit for military service:
males age 16-49: 17,942
females age 16-49: 20,436 (2008 est.)
Military expenditures - percent of GDP: 2%
(2006 est.)','d41eece467929bd008db24e4f4f5bfcd452794b00b4ae020ad1025e83430fe31','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a78e5297694b79db2588d157784345f5b6e579ac0a2c4c8a4a941fd2dc2984a7',2008,'SL','Sierra Leone','military-and-security',1291,'Military branches: Republic of Sierra Leone Armed
Forces (RSLAF): Army (includes Navy (Maritime
Wing), Air Wing) (2008)
Military service age and obligation: 17 years 6
months of age for voluntary military service (younger
with parental consent); no conscription (2008)
Manpower available for military service:
males age 16-49: 1 ,315,561 (2008 est.)
Manpower fit for military service:
males age 16-49: 671,418 (2008 est.)
Military expenditures - percent of GDP: 2.3%
(2006)','0d50996093f4772cee9382e5ec21260a71bbb2a7f14404b1e5b82d7d0a0076d5','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a49d2a99d1fe03eb5eeefadf8d8e7d1be8248994dc3e21b020a6e70189c18d8c',2008,'SG','Singapore','military-and-security',1299,'Military branches: Singapore Armed Forces: Army,
Navy, Air Force (includes Air Defense) (2008)
Military service age and obligation: 18 years of
age for male compulsory military service; 16 years of
age for volunteers; 2-year conscript service obligation,
with a reserve obligation to age 40 for enlisted or age
50 for officers (2007)
Manpower available for military service:
males age 16-49: 1 ,277,862 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,038,603 (2008 est.)
Military expenditures - percent of GDP: 4.9%
(2005 est.)','7c7e59f42035666093dd17416b46693a533b42fc403456d81dbdaf44ccaf6bf0','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7e9287747f3d24379375c2d3bac55622c731d481e78882af99bb5a8240def87',2008,'SK','Slovakia','military-and-security',1308,'Military branches: Armed Forces of the Slovak
Republic (Ozbrojene Sily Slovenskej Republiky): Land
Forces (Pozemne Sily), Air Forces (Vzdusne Sily)
(2005)
Military service age and obligation: 17-30 years of
age for voluntary military service; conscription
abolished in 2006; women are eligible to serve (2007)
Manpower available for military service:
males age 16-49: 1,420,966
females age 16-49: 1 ,386,259 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,1 66,833
females age 16-49: 1 ,156,874 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 38,183
females age 16-49: 36,388 (2008 est.)
Military expenditures - percent of GDP: 1 .87%
(2005 est.)','cf299bac8ac21937b2b7dedf683424c8564d7ae6fcf6a7f6a410e17065dd57c8','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb07d3bc3877d9cd1f2e3396f4479eebd5460f46ad251d42f0af5bf5b5d8fef6',2008,'VU','Vanuatu','military-and-security',1316,'Military branches: no regular military forces;
Solomon Islands Police Force (2008)
Manpower available for military service:
males age 16-49: 141,051 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 16,891 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 6,924 (2008 est.)
Military expenditures - percent of GDP: 3% (2006)
Military branches: no regular military forces;
Vanuatu Police Force (VPF), Vanuatu Mobile Force
(VMF; includes Police Maritime Wing (PMW)) (2008)
Manpower available for military service:
males age 16-49: 58,900 (2008 est.)
Manpower fit for military service:
males age 16-49: 40,577 (2008 est.)
Military expenditures - percent of GDP: NA','c2b3cfc997836f78faecd561d7771a6f94ebbea50a993f5097e44bfdeaba0051','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4a0b95703f644e2a1d7d07f80141cd6883adebe5e80d916e11ba7b54552de15',2008,'ZA','South Africa','military-and-security',1325,'Military branches: South African National Defense
Force (SANDF): South African Army, South African
Navy (SAN), South African Air Force (SAAF), Joint
Operations Command, Military Intelligence, Military
Health Service (2008)
Military service age and obligation: 1 8 years of
age for voluntary military service; women have a long
history of military service in noncombat roles dating
back to World War I (2004)
Manpower available for military service:
males age 16-49: 1 1 ,622,507
females age 16-49: 1 1 ,501 ,537 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,042,498
females age 1 6-49: 5,47 1 , 1 03 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 496,337
females age 16-49: 492,024 (2008 est.)
Military expenditures - percent of GDP: 1 .7%
(2006)
Military - note: with the end of apartheid and the
establishment of majority rule, former military, black
homelands forces, and ex-opposition forces were
integrated into the South African National Defense
Force (SANDF); as of 2003 the integration process
was considered complete
Military - note: defense is the responsibility of the
UK','8e18ef90f11833f541eb6f32b170242b4c0649f523d99b2ec6d380c79603d8d3','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d27bf8cf2c701b3906c3ee5b39fd8f7580d5c69538e1f32c88262cb620776a11',2008,'LK','Sri Lanka','military-and-security',1336,'Military branches: Sri Lanka Army, Sri Lanka Navy,
Sri Lanka Air Force (2008)
Military service age and obligation: 1 8 years of
age for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 5,458,720
females age 16-49: 5,594,006 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,477,437
females age 16-49: 4,683,716 (2008 est.)
I
Sri Lanka (continued)
Manpower reaching militarily significant age
annually:
males age 16-49: 174,065
females age 16-49: 168,593 (2008 est.)
Military expenditures - percent of GDP: 2.6%
(2006)','778df24835b6cfecdd316635ade10de79497d939d5ac4eedeaf1d0c77b588b79','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('979ef22af22cf01dc534e86f1216aec1ae2853272b39e1a04f4cabbf9ee41726',2008,'SE','Sweden','military-and-security',1347,'Military branches: Swedish Armed Forces
(Forsvarsmakten): Army (Armen), Royal Swedish
Navy (Marinen), Swedish Air Force (Svenska
Flygvapnet) (2007)
Military service age and obligation: 19 years of
age for compulsory military service; conscript service
obligation: 7-15 months (Navy), 8-12 months (Air
Force); after completing initial service, soldiers have a
reserve commitment until age 47 (2006)
Manpower available for military service:
males age 16-49: 2,052,890
females age 16-49: 1,980,550 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,699,1 1 5
females age 16-49: 1 ,637,868 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 64,605
females age 16-49: 61 ,1 10 (2008 est.)
Military expenditures - percent of GDP: 1 .5%
(2005 est.)','7cfebe83245e3fbd7f2f7c51d873dbb3fee66fd6bafccba59c67c804fc29afe0','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd7b4fa1217c3e54e14e06cbdaab333432f10c02b77e0c2dbd596a6c33decada',2008,'TJ','Tajikistan','military-and-security',1356,'Military branches: Ground Forces, Air and Air
Defense Forces, Mobile Force (2008)
Military service age and obligation: 18 years of
age for compulsory military service; 2-year conscript
sen/ice obligation (2006)
Manpower available for military service:
males age 16-49: 1,897,356
females age 16-49: 1 ,91 1 ,594 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,391 ,287
females age 16-49: 1 ,561 ,826 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 84,1 37
females age 16-49: 81 ,777 (2008 est.)
Military expenditures - percent of GDP: 3.9%
(2005 est.)
Military branches: Tanzanian People’s Defense
Force (Jeshi la Wananchi la Tanzania, JWTZ): Army,
Naval Wing (includes Coast Guard), Air Defense
Command (includes Air Wing), National Service
(2007)
Military service age and obligation: 1 8 years of
age for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 9,108,177 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,278,833 (2008 est.)
Military expenditures - percent of GDP: 0.2%
(2005 est.)','445a4349c4b363ef8d9fb06a3a06c5ec7f6932602c3ef29a1947fe62ea36c8bc','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c292a42fc88176e68829768ea3e17b6e62467a1e442c02856aed4af0553653a9',2008,'TH','Thailand','military-and-security',1365,'Military branches: Royal Thai Army (RTA), Royal
Thai Navy (RTN, includes Royal Thai Marine Corps),
Royal Thai Air Force (Knogtap Agard Thai, RTAF) (2008)
Military service age and obligation: 21 years of
age for compulsory military service; 18 years of age
for voluntary military sen/ice; males are registered at
18 years of age; 2-year conscript service obligation
(2006)
Manpower available for military service:
males age 16-49: 17,553,410
females age 16-49: 17,751 ,268 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,968,674
females age 16-49: 14,058,779 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 531,315
females age 16-49: 51 1 ,288 (2008 est.)
Military expenditures - percent of GDP: 1 .8%
(2005 est.)','c19e1cc0cac366125bb6e30a1af4b405f735b0d5a563d95a940eed08974dfac6','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ba63fcbe127c5e1fdeaf18c4876f8b309e28d84128398735a67176db59f30d0',2008,'TL','Timor-Leste','military-and-security',1370,'Military branches: Timor-Leste Defense Force
(Forcas de Defesa de Timor-L’este, Falintil (FDTL)):
Army, Navy (Armada) (2008)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 284,903
females age 16-49: 272,212 (2008 est.)
Manpower fit for military service:
mates age 16-49: 224,096
females age 16-49: 231,901 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 1 3,045
females age 16-49: 12,670 (2008 est.)
Military expenditures - percent of GDP: NA','f4ed85676964501b3f21d097c0ca988252ad25c4c655a78609fdc8ba4742532c','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6512583064bbdd26259694c22a98f70cac77f87b5675ce8f31e2badc86aa2d3',2008,'TG','Togo','military-and-security',1378,'Military branches: Togolese Armed Forces: Ground
Forces, Togolese Navy (Marine du Togo), Togolese
Air Force (Force Aerienne Togolaise, FAT), National
Gendarmerie (2008)
Military service age and obligation: 18 years of
age for selective compulsory and voluntary military
service; 2-year service obligation (2006)
Manpower available for military service:
males age 16-49: 1,365,505
females age 16-49: 1,374,993 (2008 est.)
Manpower fit for military service:
males age 16-49: 897,195
females age 16-49: 913,327 (2008 est.)
Military expenditures - percent of GDP: 1 .6%
(2005 est.)','b4ed8126dedb0f9c3db408e781d78342b512a806242bf6a31dad63b7e0d1e077','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08282e55978086b04ed251a58ed16a444176d9777b0531858a47639d208c3aa7',2008,'TN','Tunisia','military-and-security',1398,'Military branches: Army, Navy, Republic of Tunisia
Air Force (Al-Quwwat al-Jawwiya al-Jamahiriyah
At’tunisia) (2008)
Military service age and obligation: 20 years of
age for compulsory military service; conscript service
obligation - 12 months; 18 years of age for voluntary
military service (2007)
Manpower available for military service:
males age 16-49 : 2,992,249
females age 16-49:2,912,819 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,539,962
females age 16-49: 2,465,295 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 101,794
females age 16-49: 95,198 (2008 est.)
Military expenditures - percent of GDP: 1 .4%
(2006)
Military branches: Turkish Armed Forces (TSK):
Turkish Land Forces (Turk Kara Kuwetleri, TKK),
Turkish Naval Forces (Turk Deniz Kuwetleri, TDK;
includes naval air and naval infantry), Turkish Air
Force (Turk Hava Kuwetleri, THK) (2008)
Military service age and obligation: 20 years of
age (2004)
Manpower available for military service:
males age 76-49:20,213,205
females age 16-49: 19,432,688 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 7,01 1 ,635
females age 16-49: 16,433,364 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 660,452
females age 16-49: 638,527 (2008 est.)
Military expenditures - percent of GDP: 5.3%
(2005 est.)
Military - note: a "National Security Policy
Document" adopted in October 2005 increases the
Turkish Armed Forces (TSK) role in internal security,
augmenting the General Directorate of Security and
Gendarmerie General Command (Jandarma); the
TSK leadership continues to play a key role in politics
and considers itself guardian of Turkey’s secular
state; in April 2007, it warned the ruling party about
any pro-lslamic appointments; despite on-going
negotiations on EU accession since October 2005,
progress has been limited in establishing required
civilian supremacy over the military; primary domestic
threats are listed as fundamentalism (with the
definition in some dispute with the civilian
government), separatism (the Kurdish problem), and
the extreme left wing; Ankara strongly opposed
establishment of an autonomous Kurdish region; an
overhaul of the Turkish Land Forces Command
(TLFC) taking place under the "Force 2014" program
is to produce 20-30% smaller, more highly trained
forces characterized by greater mobility and firepower
and capable of joint and combined operations; the
TLFC has taken on increasing international
peacekeeping responsibilities, and took charge of a
NATO International Security Assistance Force (ISAF)
command in Afghanistan in April 2007; the Turkish
Navy is a regional naval power that wants to develop
the capability to project power beyond Turkey’s
coastal waters; the Navy is heavily involved in NATO,
multinational, and UN operations; its roles include
control of territorial waters and security for sea lines of
communications; the Turkish Air Force adopted an
"Aerospace and Missile Defense Concept" in 2002
and has initiated project work on an integrated missile
defense system; Air Force priorities include attaining a
modern deployable, survivable, and sustainable force
structure, and establishing a sustainable command
and control system (2008)','be9c9a845a5e7806941b973374052fed4933cec318e536756ee11873d4df0bfd','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18781499c94986b82ee38d40a4c8ff8046e1f68c004168919eb0f92883cc9fe6',2008,'TV','Tuvalu','military-and-security',1415,'Military branches: no regular military forces; Tuvalu
Police Force (2008)
Military expenditures - percent of GDP: NA','f9553575d46ca224ef17613755d403607ff8e91fc7a7643a989be5070f2829be','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74104fe1ac2af42ff49736b79d39d2baba11dffbc00eba17b27f93390ab9abda',2008,'UG','Uganda','military-and-security',1423,'Military branches: Uganda Peoples Defense Force
(UPDF): Army (includes Marine Unit), Air Force (2007)
Military service age and obligation: 1 8-26 years of
age for compulsory and voluntary military duty; 1 8-30
years of age for professionals; 9-year service
obligation; the government has stated that recruitment
below 1 8 years of age could occur with proper consent
and that "no person under the apparent age of 13
years shall be enrolled in the armed forces" (2007)
Manpower available for military service:
males age 16-49: 6,532,894
females age 16-49: 6,352,416 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,856,365
females age 16-49: 3,769,120 (2008 est.)
Military expenditures - percent of GDP: 2.2%
(2006)','861309e8c0b9c43b27cf061dfac75d0c540605380443993a067734d2e2b573d8','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acb2f9b6a2b3238404e5dddd09865505dfd2c72377a2f0dcebd9e9cc4cef693e',2008,'PL','Poland','military-and-security',1431,'Military branches: Ground Forces, Naval Forces,
Air Forces (Viyskovo-Povitryani Syly), Air Defense
Forces (2002)
Military service age and obligation: 1 8-25 years of
age for compulsory and voluntary military service;
conscript service obligation - 18 months for Army and
Air Force, 24 months for Navy (2004)
Manpower available for military service:
males age 16-49: 1 1 ,457,562
females age 16-49: 1 1 ,767,357 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,141,814
females age 16-49: 9,428,876 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 288,605
females age 16-49: 276,324 (2008 est.)
Military expenditures - percent of GDP: 1 .4%
(2005 est.)','b688cb43b021d8f3e25568b2cb7b312dcd70d3376d45945c13e5b524462670d5','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b816a01a15fd3047482a6d9626fad54ede5d305d77b4bd77fc52a33af0b20e5f',2008,'AE','United Arab Emirates','military-and-security',1439,'Military branches: United Arab Emirates Armed
Forces: Army, Navy (includes Marines), Air Force and
Air Defense, National Coast Guard (2008)
Military service age and obligation: 1 8 years of
age (est.) for voluntary military sen/ice; 18 years of
age for officers and women; no conscription (2008)
Manpower available for military service:
males age 16-49: 2,405,884 (includes non-nationals)
females age 16-49: 884,853 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,004,558
females age 16-49: 760,637 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 25,856
females age 16-49: 23,085 (2008 est.)
Military expenditures - percent of GDP: 3.1%
(2005 est.)','e20d88aa7110a35654e24809d1f838a6edd87a5bd2801932413ffb02804984ea','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a982026d13207fc0740956cfa7f1bc6f803d57d1b99628361d5f311a71584252',2008,'UZ','Uzbekistan','military-and-security',1449,'litary branches: Army, Air and Air Defense
rces, National Guard
litary service age and obligation: 18 years of
e for compulsory military service; conscript service
ligation - 12 months (2004)
inpower available for military service:
J les age 16-49: 7,480,484
nales age 16-49: 7,542,017 (2008 est.)
inpower fit for military service:
lies age 16-49: 5,684,540
nales age 16-49: 6,432,976 (2008 est.)
inpower reaching militarily significant age
nually:
lies age 16-49: 311,668
nales age 16-49: 301 ,994 (2008 est.)
itary expenditures • percent of GDP: 2%
105 est.)','4a8844e7f2482c6b87c79d386899de7cb257e426853b30b41f4a6a9e4a2b06ea','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af2c493201567d230bcf9cbb4db1bbc6cbce5d3b9f73d3c07a111ce119af50a3',2008,'YE','Yemen','military-and-security',1460,'Military branches: Army (includes Republican
Guard), Navy (includes Marines), Yemen Air Force (Al
Quwwat al Jawwiya al Jamahiriya al Yemeniya;
includes Air Defense Force) (2008)
Military service age and obligation: voluntary
military service program authorized in 2001; 2-year
service obligation (2006)
Manpower available for military service:
males age 16-49: 5,080,038
females age 16-49: 4,852,555 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,585,947
females age 16-49: 3,619,195 (2008 est.)
Manpower reaching militarily significant age
annually:
males age 16-49: 268,468
females age 16-49: 258,196 (2008 est.)
Military expenditures - percent of GDP: 6.6%
(2006)
Military - note: a Coast Guard was established in
2002','e95c0281d264a20eafb218aee2209c6e345f0e62fd5f86412b76164eb0f60265','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('415258c5089a01a0d2fdc19a2afdb05c4f77b7b291d6122bef4135548f10561f',2008,'ZM','Zambia','military-and-security',1468,'Military branches: Zambian National Defense
Force (ZNDF): Zambian Army, Zambian Air Force,
National Service (2008)
Military service age and obligation: 18 years of
age for voluntary military service (16 years of age with
parental consent); no conscription (2008)
Manpower available for military service:
males age 16-49: 2,678,668
females age 16-49: 2,567,433 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,329,343
females age 16-49: 1,218,114 (2008 est.)
Military expenditures - percent of GDP: 1 .8%
(2005 est.)','f599c39c0b1c4e567ff84816f2fb4f98873af7bf6e7de8c1f8a739e85051b8fa','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d7c967b9f571f9bba563ea2cffa9bf77683c72979ef5a6a4bf44a11874338bd',2008,'ZW','Zimbabwe','military-and-security',1476,'Military branches: Zimbabwe Defense Forces
(ZDF): Zimbabwe National Army, Air Force of
Zimbabwe (AFZ), Zimbabwe Republic Police (2005)
Military service age and obligation: 1 8-24 years of
age for compulsory military service; women are
eligible to serve (2007)
Manpower available for military service:
males age 16-49: 3,264,258
females age 16-49: 3,048,049 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,643,036
females age 16-49: 1,404,663 (2008 est.)
Military expenditures - percent of GDP: 3.8%
(2006)','5283d9eeaafb6463cb04cd2e0df75babf09921ac88ffb247366edcb96ac510fb','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('717f5e34c233fbfc73565e3d4fe7c0133646e715669c3220b1dd456204e0e0f6',2008,'LU','Luxembourg','military-and-security',1481,'Military - note: the five-nation Eurocorps - created in
1992 by France, Germany, Belgium, Spain, and
Luxembourg - has deployed troops and police on
peacekeeping missions to Bosnia-Herzegovina,
Macedonia, and the Democratic Republic of the
Congo and assumed command of the ISAF in
Afghanistan in August 2004; Eurocorps directly
commands the 5,000-man Franco-German Brigade,
the Multinational Command Support Brigade, and
EUFOR in Bosnia and Herzegovina; in November
2004, the EU Council of Ministers formally committed
to creating 13 1,500-man battle groups by the end of
2007, to respond to international crises on a rotating
basis; 22 of the EU’s 25 nations have agreed to supply
troops; France, Italy, and the UK formed the first of
three battle groups in 2005; Norway, Sweden,
Estonia, and Finland established the Nordic Battle
Group effective 1 January 2008; nine other groups are
to be formed; a rapid-reaction naval EU Maritime Task
Group was stood up in March 2007 (2007)','e4f3031d05ceeea4d69a9344c784c010176b679d89fa278f50af5599f8774627','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e6f2f7a6e8edaae3fec7e9f60b98ceaf248950927381349184a4221b68eec29',2008,'ZW','Zimbabwe','military-and-security',25,'Military expenditures - percent of GDP
Factbook fields with Rank Order pages are easily identified with a
small bar chart icon to the right of the data field title.
Not all Rank Order pages include the same number of entries because
information for a particular field is not available for all countries.
In addition, not all data fields are suitable for displaying as Rank
Order pages, such as those containing textual information. Textual
information is more readily viewed by clicking on the Field Listing
icon next to the Data field title. The other icon next to the data
field title provides the definition of the field.
All of the ''Rank Order'' pages can be downloaded as tab-delimited data
files and can be opened in other applications such as spreadsheets and
databases. To save a Rank Order page in a spreadsheet, first click on
the ''Download Datafile'' choice above the Rank Order page you selected;
then, at the top of your browser window, click on ''File'' and ''Save As''.
After saving the file, open the spreadsheet, find the saved file, and
''Open'' it.
Additional Rank Order pages being considered for future updates of the
Factbook Web site include:
Median age
Literacy
Population below the poverty line
This page was last updated on 20 November, 2008
=====================================================================
Appendixes
Appendix A - Abbreviations
Appendix B - International Organizations and Groups
Appendix C - Selected International Environmental Agreements
Appendix D - Cross-Reference list of Country Data Codes
Appendix E - Cross-Reference List of Hydrographic Data Codes
Appendix F - Cross-Reference List of Geographic Names
Appendix G - Weights and Measures
======================================================================
Notes and Definitions
In addition to the regular information updates, The World Factbook 2008
features several new additions. In the Geography category, two new
fields focus on the increasingly vital resource of water: "Total
renewable water resources" and "Freshwater withdrawal."
In the Economy category, the Factbook has added three fields: "Stock of
direct foreign investment - at home", "Stock of direct foreign
investment - abroad", and "Market value of publicly traded shares."
Additionally, the data for GDP at purchasing power parity (PPP) has
been rebased using new PPP conversion rates, benchmarked to the year
2005, which were released on 17 December 2007 by the International
Comparison Program (ICP). The 2005 PPP data replace previous estimates,
many from studies dating to 1993 or earlier. The preliminary ICP report
provides estimates of internationally comparable price levels and the
relative purchasing power of currencies for 146 countries. The 2005
benchmark revises downward the size of the world economy in PPP terms
from the previous estimates, and changes the relative sizes of many of
the world''s economies.
Concise descriptions of the major religions mentioned in the Factbook
have been added to the Notes and Definitions. France ''s redesignation
of some of its overseas possessions caused the five former Indian Ocean
island possessions making up Iles Eparses to be incorporated into the
French Southern and Antarctic Lands, while two new Caribbean entities,
St. Barthelemy and St. Martin, were created.
Revision of some individual country maps, first introduced in the 2001
edition, is continued in this edition. The revised maps include
elevation extremes and a partial geographic grid. Several regional maps
have also been updated to reflect boundary changes and place name
spelling changes.
Abbreviations: This information is included in Appendix A:
Abbreviations, which includes all abbreviations and acronyms used in
the Factbook, with their expansions.
Acronyms: An acronym is an abbreviation coined from the initial letter
of each successive word in a term or phrase. In general, an acronym
made up solely from the first letter of the major words in the expanded
form is rendered in all capital letters (NATO from North Atlantic
Treaty Organization; an exception would be ASEAN for Association of
Southeast Asian Nations). In general, an acronym made up of more than
the first letter of the major words in the expanded form is rendered
with only an initial capital letter (Comsat from Communications
Satellite Corporation; an exception would be NAM from Nonaligned
Movement). Hybrid forms are sometimes used to distinguish between
initially identical terms (ICC for International Chamber of Commerce
and ICCt for International Criminal Court).
Administrative divisions: This entry generally gives the numbers,
designatory terms, and first-order administrative divisions as approved
by the US Board on Geographic Names (BGN). Changes that have been
reported but not yet acted on by the BGN are noted.
Age structure: This entry provides the distribution of the population
according to age. Information is included by sex and age group (0-14
years, 15-64 years, 65 years and over). The age structure of a
population affects a nation''s key socioeconomic issues. Countries with
young populations (high percentage under age 15) need to invest more in
schools, while countries with older populations (high percentage ages
65 and over) need to invest more in the health sector. The age
structure can also be used to help predict potential political issues.
For example, the rapid growth of a young adult population unable to
find employment can lead to unrest.
Agriculture - products: This entry is an ordered listing of major
crops and products starting with the most important.
Airports: This entry gives the total number of airports or airfields
recognizable from the air. The runway(s) may be paved (concrete or
asphalt surfaces) or unpaved (grass, earth, sand, or gravel surfaces)
but may include closed or abandoned installations. Airports or
airfields that are no longer recognizable (overgrown, no facilities,
etc.) are not included. Note that not all airports have accommodations
for refueling, maintenance, or air traffic control.
Airports - with paved runways: This entry gives the total number of
airports with paved runways (concrete or asphalt surfaces) by length.
For airports with more than one runway, only the longest runway is
included according to the following five groups - (1) over 3,047 m, (2)
2,438 to 3,047 m, (3) 1,524 to 2,437 m, (4) 914 to 1,523 m, and (5)
under 914 m. Only airports with usable runways are included in this
listing. Not all airports have facilities for refueling, maintenance,
or air traffic control.
Airports - with unpaved runways: This entry gives the total number of
airports with unpaved runways (grass, dirt, sand, or gravel surfaces)
by length. For airports with more than one runway, only the longest
runway is included according to the following five groups - (1) over
3,047 m, (2) 2,438 to 3,047 m, (3) 1,524 to 2,437 m, (4) 914 to 1,523
m, and (5) under 914 m. Only airports with usable runways are included
in this listing. Not all airports have facilities for refueling,
maintenance, or air traffic control.
Appendixes: This section includes Factbook-related material by topic.
Area: This entry includes three subfields. Total area is the sum of
all land and water areas delimited by international boundaries and/or
coastlines. Land area is the aggregate of all surfaces delimited by
international boundaries and/or coastlines, excluding inland water
bodies (lakes, reservoirs, rivers). Water area is the sum of the
surfaces of all inland water bodies, such as lakes, reservoirs, or
rivers, as delimited by international boundaries and/or coastlines.
Area - comparative: This entry provides an area comparison based on
total area equivalents. Most entities are compared with the entire US
or one of the 50 states based on area measurements (1990 revised)
provided by the US Bureau of the Census. The smaller entities are
compared with Washington, DC (178 sq km, 69 sq mi) or The Mall in
Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Background: This entry usually highlights major historic events and
current issues and may include a statement about one or two key future
trends.
Birth rate: This entry gives the average annual number of births
during a year per 1,000 persons in the population at midyear; also
known as crude birth rate. The birth rate is usually the dominant
factor in determining the rate of population growth. It depends on both
the level of fertility and the age structure of the population.
Budget: This entry includes revenues, expenditures, and capital
expenditures. These figures are calculated on an exchange rate basis,
i.e., not in purchasing power parity (PPP) terms.
Capital: This entry gives the name of the seat of government, its
geographic coordinates, the time difference relative to Coordinated
Universal Time (UTC) and the time observed in Washington, DC, and, if
applicable, information on daylight saving time (DST). Where
appropriate, a special note has been added to highlight those countries
that have multiple time zones.
Central bank discount rate: This entry provides the annualized
interest rate a country''s central bank charges commercial, depository
banks for loans to meet temporary shortages of funds.
Climate: This entry includes a brief description of typical weather
regimes throughout the year.
Coastline: This entry gives the total length of the boundary between
the land area (including islands) and the sea.
Commercial bank prime lending rate: This entry provides a simple
average of annualized interest rates commercial banks charge on new
loans, denominated in the national currency, to their most credit-
worthy customers.
Communications: This category deals with the means of exchanging
information and includes the telephone, radio, television, and Internet
host entries.
Communications - note: This entry includes miscellaneous
communications information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions,
and major amendments.
Coordinated Universal Time (UTC): UTC is the international atomic time
scale that serves as the basis of timekeeping for most of the world.
The hours, minutes, and seconds expressed by UTC represent the time of
day at the Prime Meridian (0 deg. longitude) located near Greenwich,
England as reckoned from midnight. UTC is calculated by the Bureau
International des Poids et Measures (BIPM) in Sevres, France. The BIPM
averages data collected from more than 200 atomic time and frequency
standards located at about 50 laboratories worldwide. UTC is the basis
for all civil time with the Earth divided into time zones expressed as
positive or negative differences from UTC. UTC is also referred to as
"Zulu time." See the Standard Time Zones of the World map included with
the Reference Maps.
Country data codes: see Data codes.
Country map: Most versions of the Factbook provide a country map in
color. The maps were produced from the best information available at
the time of preparation. Names and/or boundaries may have changed
subsequently.
Country name: This entry includes all forms of the country''s name
approved by the US Board on Geographic Names (Italy is used as an
example): conventional long form (Italian Republic), conventional short
form (Italy), local long form (Repubblica Italiana), local short form
(Italia), former (Kingdom of Italy), as well as the abbreviation. Also
see the Terminology note.
Crude oil: See entry for oil.
Current account balance: This entry records a country''s net trade in
goods and services, plus net earnings from rents, interest, profits,
and dividends, and net transfer payments (such as pension funds and
worker remittances) to and from the rest of the world during the period
specified. These figures are calculated on an exchange rate basis,
i.e., not in purchasing power parity (PPP) terms.
Data codes: This information is presented in Appendix D: Cross-
Reference List of Country Data Codes and Appendix E: Cross-Reference
List of Hydrographic Data Codes.
Date of information: In general, information available as of 1 January
2007 was used in the preparation of this edition.
Daylight Saving Time (DST): This entry is included for those entities
that have adopted a policy of adjusting the official local time
forward, usually one hour, from Standard Time during summer months.
Such policies are most common in mid-latitude regions.
Death rate: This entry gives the average annual number of deaths
during a year per 1,000 population at midyear; also known as crude
death rate. The death rate, while only a rough indicator of the
mortality situation in a country, accurately indicates the current
mortality impact on population growth. This indicator is significantly
affected by age distribution, and most countries will eventually show a
rise in the overall death rate, in spite of continued decline in
mortality at all ages, as declining fertility results in an aging
population.
Debt - external: This entry gives the total public and private debt
owed to nonresidents repayable in foreign currency, goods, or services.
These figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms.
Dependency status: This entry describes the formal relationship
between a particular nonindependent entity and an independent state.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular
independent state.
Diplomatic representation: The US Government has diplomatic relations
with 189 independent states, including 187 of the 192 UN members
(excluded UN members are Bhutan, Cuba, Iran, North Korea, and the US
itself). In addition, the US has diplomatic relations with 2
independent states that are not in the UN, the Holy See and Kosovo, as
well as with the EU.
Diplomatic representation from the US: This entry includes the chief
of mission, embassy address, mailing address, telephone number, FAX
number, branch office locations, consulate general locations, and
consulate locations.
Diplomatic representation in the US: This entry includes the chief of
mission, chancery, telephone, FAX, consulate general locations, and
consulate locations.
Disputes - international: This entry includes a wide variety of
situations that range from traditional bilateral boundary disputes to
unilateral claims of one sort or another. Information regarding
disputes over international terrestrial and maritime boundaries has
been reviewed by the US Department of State. References to other
situations involving borders or frontiers may also be included, such as
resource disputes, geopolitical questions, or irredentist issues;
however, inclusion does not necessarily constitute official acceptance
or recognition by the US Government.
Distribution of family income - Gini index: This index measures the
degree of inequality in the distribution of family income in a country.
The index is calculated from the Lorenz curve, in which cumulative
family income is plotted against the number of families arranged from
the poorest to the richest. The index is the ratio of (a) the area
between a country''s Lorenz curve and the 45 degree helping line to (b)
the entire triangular area under the 45 degree line. The more nearly
equal a country''s income distribution, the closer its Lorenz curve to
the 45 degree line and the lower its Gini index, e.g., a Scandinavian
country with an index of 25. The more unequal a country''s income
distribution, the farther its Lorenz curve from the 45 degree line and
the higher its Gini index, e.g., a Sub-Saharan country with an index of
50. If income were distributed with perfect equality, the Lorenz curve
would coincide with the 45 degree line and the index would be zero; if
income were distributed with perfect inequality, the Lorenz curve would
coincide with the horizontal axis and the right vertical axis and the
index would be 100.
Economy: This category includes the entries dealing with the size,
development, and management of productive resources, i.e., land, labor,
and capital.
Economy - overview: This entry briefly describes the type of economy,
including the degree of market orientation, the level of economic
development, the most important natural resources, and the unique areas
of specialization. It also characterizes major economic events and
policy changes in the most recent 12 months and may include a statement
about one or two key future macroeconomic trends.
Education expenditures: This entry provides the public expenditure on
education as a percent of GDP
Electricity - consumption: This entry consists of total electricity
generated annually plus imports and minus exports, expressed in
kilowatt-hours. The discrepancy between the amount of electricity
generated and/or imported and the amount consumed and/or exported is
accounted for as loss in transmission and distribution.
Electricity - exports: This entry is the total exported electricity in
kilowatt-hours.
Electricity - imports: This entry is the total imported electricity in
kilowatt-hours.
Electricity - production: This entry is the annual electricity
generated expressed in kilowatt-hours. The discrepancy between the
amount of electricity generated and/or imported and the amount consumed
and/or exported is accounted for as loss in transmission and
distribution.
Elevation extremes: This entry includes both the highest point and the
lowest point.
Entities: Some of the independent states, dependencies, areas of
special sovereignty, and governments included in this publication are
not independent, and others are not officially recognized by the US
Government. "Independent state" refers to a people politically
organized into a sovereign state with a definite territory.
"Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an
independent state. "Country" names used in the table of contents or for
page headings are usually the short-form names as approved by the US
Board on Geographic Names and may include independent states,
dependencies, and areas of special sovereignty, or other geographic
entities. There are a total of 266 separate geographic entities in The
World Factbook that may be categorized as follows:
INDEPENDENT STATES
194 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy
See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kosovo, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal,
Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
OTHER
2 Taiwan, European Union
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
2 China - Hong Kong, Macau
2 Denmark - Faroe Islands, Greenland
9 France - Clipperton Island, French Polynesia, French Southern and
Antarctic Lands, Mayotte, New Caledonia, Saint Barthelemy, Saint
Martin, Saint Pierre and Miquelon, Wallis and Futuna
2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island, Jan Mayen, Svalbard
17 UK - Akrotiri, Anguilla, Bermuda, British Indian Ocean Territory,
British Virgin Islands, Cayman Islands, Dhekelia, Falkland Islands,
Gibraltar, Guernsey, Jersey, Isle of Man, Montserrat, Pitcairn Islands,
Saint Helena, South Georgia and the South Sandwich Islands, Turks and
Caicos Islands
14 US - American Samoa, Baker Island*, Guam, Howland Island*, Jarvis
Island*, Johnston Atoll*, Kingman Reef*, Midway Islands*, Navassa
Island, Northern Mariana Islands, Palmyra Atoll*, Puerto Rico, Virgin
Islands, Wake Island (* consolidated in United States Pacific Island
Wildlife Refuges entry)
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank,
Military branches:
Zimbabwe Defense Forces (ZDF): Zimbabwe National Army (ZNA), Air
Force of Zimbabwe (AFZ), Zimbabwe Republic Police (2008)
Military service age and obligation:
18-24 years of age for compulsory military service; women are
eligible to serve (2007)
Manpower available for military service:
males age 16-49: 3,264,258
females age 16-49: 3,048,049 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,643,036
females age 16-49: 1,404,663 (2008 est.)
Manpower reaching militarily significant age annually:
male: 144,601
female: 147,627 (2008 est.)
Military expenditures:
3.8% of GDP (2006)','6783833b0e27ce1ac4c7aa774c62888b4b35e863e2f94a94b4dc5ddd7d0afcd4','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdd7c714446ec9ca1083a4b5157577863ac4c40fe4bac1668f17bfe3b1a66c59',2008,'EH','Western Sahara','military-and-security',26,'OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean,
Southern Ocean
1 World
266 total
Environment - current issues: This entry lists the most pressing and
important environmental problems. The following terms and abbreviations
are used throughout the entry:
Acidification - the lowering of soil and water pH due to acid
precipitation and deposition usually through precipitation; this
process disrupts ecosystem nutrient flows and may kill freshwater fish
and plants dependent on more neutral or alkaline conditions (see acid
rain).
Acid rain - characterized as containing harmful levels of sulfur
dioxide or nitrogen oxide; acid rain is damaging and potentially deadly
to the earth''s fragile ecosystems; acidity is measured using the pH
scale where 7 is neutral, values greater than 7 are considered
alkaline, and values below 5.6 are considered acid precipitation; note
- a pH of 2.4 (the acidity of vinegar) has been measured in rainfall in
New England.
Aerosol - a collection of airborne particles dispersed in a gas, smoke,
or fog.
Afforestation - converting a bare or agricultural space by planting
trees and plants; reforestation involves replanting trees on areas that
have been cut or destroyed by fire.
Asbestos - a naturally occurring soft fibrous mineral commonly used in
fireproofing materials and considered to be highly carcinogenic in
particulate form.
Biodiversity - also biological diversity; the relative number of
species, diverse in form and function, at the genetic, organism,
community, and ecosystem level; loss of biodiversity reduces an
ecosystem''s ability to recover from natural or man-induced disruption.
Bio-indicators - a plant or animal species whose presence, abundance,
and health reveal the general condition of its habitat.
Biomass - the total weight or volume of living matter in a given area
or volume.
Carbon cycle - the term used to describe the exchange of carbon (in
various forms, e.g., as carbon dioxide) between the atmosphere, ocean,
terrestrial biosphere, and geological deposits.
Catchments - assemblages used to capture and retain rainwater and
runoff; an important water management technique in areas with limited
freshwater resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless
insecticide that has toxic effects on most animals; the use of DDT was
banned in the US in 1972.
Defoliants - chemicals which cause plants to lose their leaves
artificially; often used in agricultural practices for weed control,
and may have detrimental impacts on human and ecosystem health.
Deforestation - the destruction of vast areas of forest (e.g.,
unsustainable forestry practices, agricultural and range land clearing,
and the over exploitation of wood products for use as fuel) without
planting new growth.
Desertification - the spread of desert-like conditions in arid or semi-
arid areas, due to overgrazing, loss of agriculturally productive
soils, or climate change.
Dredging - the practice of deepening an existing waterway; also, a
technique used for collecting bottom-dwelling marine organisms (e.g.,
shellfish) or harvesting coral, often causing significant destruction
of reef and ocean-floor ecosystems.
Drift-net fishing - done with a net, miles in extent, that is generally
anchored to a boat and left to float with the tide; often results in an
over harvesting and waste of large populations of non-commercial marine
species (by-catch) by its effect of "sweeping the ocean clean."
Ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
Effluents - waste materials, such as smoke, sewage, or industrial waste
which are released into the environment, subsequently polluting it.
Endangered species - a species that is threatened with extinction
either by direct hunting or habitat destruction.
Freshwater - water with very low soluble mineral content; sources
include lakes, streams, rivers, glaciers, and underground aquifers.
Greenhouse gas - a gas that "traps" infrared radiation in the lower
atmosphere causing surface warming; water vapor, carbon dioxide,
nitrous oxide, methane, hydrofluorocarbons, and ozone are the primary
greenhouse gases in the Earth''s atmosphere.
Groundwater - water sources found below the surface of the earth often
in naturally occurring reservoirs in permeable rock strata; the source
for wells and natural springs.
Highlands Water Project - a series of dams constructed jointly by
Lesotho and South Africa to redirect Lesotho''s abundant water supply
into a rapidly growing area in South Africa; while it is the largest
infrastructure project in southern Africa, it is also the most costly
and controversial; objections to the project include claims that it
forces people from their homes, submerges farmlands, and squanders
economic resources.
Inuit Circumpolar Conference (ICC) - represents the 145,000 Inuits of
Russia, Alaska, Canada, and Greenland in international environmental
issues; a General Assembly convenes every three years to determine the
focus of the ICC; the most current concerns are long-range transport of
pollutants, sustainable development, and climate change.
Metallurgical plants - industries which specialize in the science,
technology, and processing of metals; these plants produce highly
concentrated and toxic wastes which can contribute to pollution of
ground water and air when not properly disposed.
Noxious substances - injurious, very harmful to living beings.
Overgrazing - the grazing of animals on plant material faster than it
can naturally regrow leading to the permanent loss of plant cover, a
common effect of too many animals grazing limited range land.
Ozone shield - a layer of the atmosphere composed of ozone gas (O3)
that resides approximately 25 miles above the Earth''s surface and
absorbs solar ultraviolet radiation that can be harmful to living
organisms.
Poaching - the illegal killing of animals or fish, a great concern with
respect to endangered or threatened species.
Pollution - the contamination of a healthy environment by man-made
waste.
Potable water - water that is drinkable, safe to be consumed.
Salination - the process through which fresh (drinkable) water becomes
salt (undrinkable) water; hence, desalination is the reverse process;
also involves the accumulation of salts in topsoil caused by
evaporation of excessive irrigation water, a process that can
eventually render soil incapable of supporting crops.
Siltation - occurs when water channels and reservoirs become clotted
with silt and mud, a side effect of deforestation and soil erosion.
Slash-and-burn agriculture - a rotating cultivation technique in which
trees are cut down and burned in order to clear land for temporary
agriculture; the land is used until its productivity declines at which
point a new plot is selected and the process repeats; this practice is
sustainable while population levels are low and time is permitted for
regrowth of natural vegetation; conversely, where these conditions do
not exist, the practice can have disastrous consequences for the
Manpower reaching militarily significant age annually:
male: 4,658
female: 4,545 (2008 est.)
World
Military expenditures:
roughly 2% of GDP of gross world product (2005 est.)','5c15e6c20630a8a29fefab546299de51621d4c17aa28cec758b2fd2726ba0d07','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d0cd9752c3d06f00dc9db6650bebcc98f89ac378ff01999a4571c56b359ffad',2008,'AF','Afghanistan','military-and-security',42,'Military branches:
Afghan Armed Forces: Afghan National Army (ANA, includes Afghan
National Army Air Corps) (2008)
Military service age and obligation:
22 years of age; inductees are contracted into service for a 4-year
term (2005)
Manpower available for military service:
males age 16-49: 7,431,147
females age 16-49: 7,004,819 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,234,180
females age 16-49: 3,946,685 (2008 est.)
Manpower reaching militarily significant age annually:
male: 371,451
female: 351,295 (2008 est.)
Military expenditures:
1.9% of GDP (2006 est.)
Akrotiri
Military - note:
Akrotiri has a full RAF base, Headquarters for British Forces on
Cyprus, and Episkopi Support Unit
This page was last updated on 18 December, 2008
======================================================================
@Albania','b65854c00345b7527936a0dcb611196523d0b76cc1f8fb4c6d629146d011292f','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('606f23c052307e7031b431407462b3962d6561bbeba95902e93ab0af55b8c2f0',2008,'AL','Albania','military-and-security',51,'Military branches:
Land Forces Command (Army), Naval Forces Command, Air Defense
Command, General Staff Headquarters (includes Logistics Command,
Training and Doctrine Command) (2007)
Military service age and obligation:
19 years of age (2004)
Manpower available for military service:
males age 16-49: 944,592
females age 16-49: 908,527 (2008 est.)
Manpower fit for military service:
males age 16-49: 798,454
females age 16-49: 767,143 (2008 est.)
Manpower reaching militarily significant age annually:
male: 36,340
female: 33,077 (2008 est.)
Military expenditures:
1.49% of GDP (2005 est.)','f933dbcfa7b90ceed20d2e8b213b26f539e20e26b937560d2248b56bc80775e1','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('571d3fdd7689c97a54f91b369874d3a51c151100330b73114e91174e5dd6fe34',2008,'DZ','Algeria','military-and-security',60,'Military branches:
National Popular Army (ANP; includes Land Forces), Algerian National
Navy (MRA), Air Force (QJJ), Territorial Air Defense Force (2005)
Military service age and obligation:
19-30 years of age for compulsory military service; conscript
service obligation - 18 months (6 months basic training, 12 months
civil projects) (2006)
Manpower available for military service:
males age 16-49: 9,736,757
females age 16-49: 9,590,978 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,141,864
females age 16-49: 8,215,895 (2008 est.)
Manpower reaching militarily significant age annually:
male: 374,365
female: 360,942 (2008 est.)
Military expenditures:
3.3% of GDP (2006)','50f094b21839dcdfd4ff06bde3dea05ed23254f7405b2d95d96c2a590079a76b','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0291ca5764eb26d6fe3118cc5ca1e338a983a60eb43cb36b52111ace203c358a',2008,'AS','American Samoa','military-and-security',69,'Manpower reaching militarily significant age annually:
male: 806
female: 781 (2008 est.)
Military - note:
defense is the responsibility of the US','98d8d6c69742af0b7ed1e5c17d9d6bf82eca73e1dfc54063d0407c285a53bb7b','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb806d81368f2769a96746a7b6e800131583fcdb408ed3843c64ad4e6db6ba74',2008,'AD','Andorra','military-and-security',78,'Military branches:
no regular military forces, Police Service of Andorra
Manpower available for military service:
males age 16-49: 18,685 (2008 est.)
Manpower fit for military service:
males age 16-49: 14,976 (2008 est.)
Manpower reaching militarily significant age annually:
male: 412
female: 395 (2008 est.)
Military - note:
defense is the responsibility of France and Spain','2354ef9df7a60232c4ce9ac1488c4ba045e43e69f54737400759b730f66ad8f9','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fee8ba9e9129b4ca3f90c81397c41df6a6b313868ad658f776016e0c5637c52',2008,'AO','Angola','military-and-security',87,'Military branches:
Angolan Armed Forces (FAA): Army, Navy (Marinha de Guerra, MdG),
Angolan National Air Force (FANA) (2007)
Military service age and obligation:
17 years of age for compulsory military service; conscript service
obligation - 2 years plus time for training (2001)
Manpower available for military service:
males age 16-49: 2,856,492
females age 16-49: 2,755,864 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,430,658
females age 16-49: 1,371,689 (2008 est.)
Manpower reaching militarily significant age annually:
male: 142,791
female: 139,539 (2008 est.)
Military expenditures:
5.7% of GDP (2006)','5caae320eac5af89f627eb4532da1ad4ddd55179daadd8333311f633f60c08cf','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c108e2cd02b114f20afccc64d77ad5c67bf2769fe5f689f56abbd80c583d668',2008,'AI','Anguilla','military-and-security',96,'Manpower available for military service:
males age 16-49: 3,538 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,929 (2008 est.)
Manpower reaching militarily significant age annually:
male: 103
female: 103 (2008 est.)
Military - note:
defense is the responsibility of the UK','d7109ca7600b1b20cec1d189e6298c3942d2ada80795c9fa0620506ba40b16d7','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f75391a765c5dee964521b6d20995b117f2e999110c28e55420df3634f6b01b',2008,'AQ','Antarctica','military-and-security',105,'Military - note:
the Antarctic Treaty prohibits any measures of a military nature,
such as the establishment of military bases and fortifications, the
carrying out of military maneuvers, or the testing of any type of
weapon; it permits the use of military personnel or equipment for
scientific research or for any other peaceful purposes','b6e1fc6fd696235d6946f8bf04e60498f9574dccd6c6304c25686a8322a6b729','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5103623b1b385436a08cdcefc5e7bdb0b374812d4e453c6227c234007d4d0de3',2008,'AG','Antigua and Barbuda','military-and-security',114,'Military branches:
Royal Antigua and Barbuda Defense Force (2007)
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 19,560
females age 16-49: 18,977 (2008 est.)
Manpower fit for military service:
males age 16-49: 15,591
females age 16-49: 15,542 (2008 est.)
Manpower reaching militarily significant age annually:
male: 744
female: 742 (2008 est.)
Military expenditures:
NA','7dadcd2f5226d58f6472c994b8c88ba69a795712f2dbbd3aab0554ebe231b162','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('541a5f283f5a2550230c8b2e35f58dd3029549c5028726d2dc353c28103bb9d5',2008,'AR','Argentina','military-and-security',123,'Military branches:
Argentine Army (Ejercito Argentino), Navy of the Argentine Republic
(Armada Republica; includes naval aviation and naval infantry),
Argentine Air Force (Fuerza Aerea Argentina, FAA) (2008)
Military service age and obligation:
18-24 years of age for voluntary military service (18-21 requires
parental permission); no conscription (2001)
Manpower available for military service:
males age 16-49: 10,029,488
females age 16-49: 9,889,002 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,352,147
females age 16-49: 8,366,781 (2008 est.)
Manpower reaching militarily significant age annually:
male: 348,310
female: 332,944 (2008 est.)
Military expenditures:
1.3% of GDP (2005 est.)
Military - note:
the Argentine military is a well-organized force constrained by the
country''s prolonged economic hardship; the country has recently
experienced a strong recovery, and the military is implementing a
modernization plan aimed at making the ground forces lighter and
more responsive (2008)','bd5ec243c67be322d3bb0d3f8252f087e48cff8f4f8958d51f1f3f20c7d18751','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('098026c30e4ac1018a5f08815df0e5a8169e11cb1d3f29a154d5567d848240d0',2008,'AM','Armenia','military-and-security',132,'Military branches:
Armed Forces: Ground Forces, Nagorno-Karabakh Self Defense Force
(NKSDF), Air Force and Air Defense (2008)
Military service age and obligation:
18-27 years of age for voluntary or compulsory military service;
2-year conscript service obligation (2007)
Manpower available for military service:
males age 16-49: 809,576
females age 16-49: 870,864 (2008 est.)
Manpower fit for military service:
males age 16-49: 637,776
females age 16-49: 729,846 (2008 est.)
Manpower reaching militarily significant age annually:
male: 30,548
female: 29,170 (2008 est.)
Military expenditures:
6.5% of GDP (FY01)','9ef0b8bb264ca948de4eca9bc54c4abd218ad0a808b653d4a6a5f24f8c190bdb','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7da6fd7819d7eded34d65465fa7327378263120fa77cd225490d9e8fc381536',2008,'AW','Aruba','military-and-security',141,'Military branches:
no regular indigenous military forces; the Netherlands maintains a
detachment of marines, a frigate, and an amphibious combat
detachment in the neighboring Netherlands Antilles (2008)
Manpower available for military service:
males age 16-49: 24,585
females age 16-49: 25,742 (2008 est.)
Manpower fit for military service:
males age 16-49: 20,173
females age 16-49: 21,062 (2008 est.)
Manpower reaching militarily significant age annually:
male: 705
female: 719 (2008 est.)
Military - note:
defense is the responsibility of the Kingdom of the Netherlands
Ashmore and Cartier Islands
Military - note:
defense is the responsibility of Australia; periodic visits by the
Royal Australian Navy and Royal Australian Air Force','0e0856eae6ce92ea554e6f0558f066dd6eb0998645d019786c697b4efb6b63e6','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da13a379d9facc9da4580f9abedefc6a94429e81e1e1645d3bfe567f2350128f',2008,'AU','Australia','military-and-security',150,'Military branches:
Australian Defense Force (ADF): Australian Army, Royal Australian
Navy, Royal Australian Air Force, Special Operations Command (2006)
Military service age and obligation:
17 years of age for voluntary military service (with parental
consent); no conscription; women allowed to serve in Army combat
units in non-combat support roles (2008)
Manpower available for military service:
males age 16-49: 4,999,988
females age 16-49: 4,870,043 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,137,176
females age 16-49: 4,022,588 (2008 est.)
Manpower reaching militarily significant age annually:
male: 144,934
female: 137,511 (2008 est.)
Military expenditures:
2.4% of GDP (2006)','4f2c3784d66cbe93330e81e15c915faf4f2e06be0fa5b63492c90e4b8dc48244','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25dd02d8894c4c3db1633ac18fc235cb70c7c01c0cfe45c567f8f8e4bca557c3',2008,'AT','Austria','military-and-security',159,'Military branches:
Land Forces (KdoLdSK), Air Forces (KdoLuSK)
Military service age and obligation:
18-35 years of age for compulsory military service; 16 years of age
for male or female voluntary service; service obligation 7 months of
training, followed by an 8-year reserve obligation (2006)
Manpower available for military service:
males age 16-49: 1,986,411
females age 16-49: 1,944,834 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,617,385
females age 16-49: 1,583,886 (2008 est.)
Manpower reaching militarily significant age annually:
male: 50,869
female: 48,246 (2008 est.)
Military expenditures:
0.9% of GDP (2005 est.)','14a6047980522b2e687f0f55cbc34be1f42787813d5c7dff7917591acf514ffc','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00629162adb9dc021f9bd646c7ca3fe607655fe45893ea6a5707b3e1300633c9',2008,'AZ','Azerbaijan','military-and-security',168,'Military branches:
Army, Navy, Air and Air Defense Forces (2008)
Military service age and obligation:
men between 18 and 35 are liable for military service; 18 years of
age for voluntary military service; length of military service is 18
months and 12 months for university graduates (2006)
Manpower available for military service:
males age 16-49: 2,278,888
females age 16-49: 2,291,770 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,696,167
females age 16-49: 1,923,556 (2008 est.)
Manpower reaching militarily significant age annually:
male: 94,402
female: 89,686 (2008 est.)
Military expenditures:
2.6% of GDP (2005 est.)
Bahamas, The
Military branches:
Royal Bahamian Defense Force: Land Force, Navy, Air Wing (2007)
Military service age and obligation:
18 years of age (est.); no conscription (2008)
Manpower available for military service:
males age 16-49: 80,200 (2008 est.)
Manpower fit for military service:
males age 16-49: 50,282 (2008 est.)
Manpower reaching militarily significant age annually:
male: 3,016
female: 3,024 (2008 est.)
Military expenditures:
0.5% of GDP (2006)','1159459746cf25bc3a74234347dc54a4800825cb12c5f04a105a1d2a672f28cc','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7598765345735209e84a21a7c4edb34857a1508416c60f276d2163024dae5c42',2008,'BH','Bahrain','military-and-security',177,'Military branches:
Bahrain Defense Forces (BDF): Ground Force (includes Air Defense),
Naval Force, Air Force, National Guard
Military service age and obligation:
17 years of age for voluntary military service; 15 years of age for
NCOs, technicians, and cadets; no conscription (2008)
Manpower available for military service:
males age 16-49: 210,938
females age 16-49: 170,471 (2008 est.)
Manpower fit for military service:
males age 16-49: 171,536
females age 16-49: 142,714 (2008 est.)
Manpower reaching militarily significant age annually:
male: 6,543
female: 6,429 (2008 est.)
Military expenditures:
4.5% of GDP (2006)','e919b0c2c97a5ff2b525fdd645b915f51da2e902ae14ce37947bc54129683152','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9169da1d8f29cb7fbd48cbc762528b3be79bccc65ee7ec002d249d4129311b47',2008,'BD','Bangladesh','military-and-security',186,'Military branches:
Bangladesh Defense Force: Bangladesh Army, Bangladesh Navy,
Bangladesh Air Force (Bangladesh Biman Bahini, BAF) (2008)
Military service age and obligation:
16 years of age for voluntary military service; 17 years of age for
officers (both with parental consent); conscription legally possible
in emergency, but has never been implemented (2008)
Manpower available for military service:
males age 16-49: 41,199,340 (2008 est.)
Manpower fit for military service:
males age 16-49: 31,968,168 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,311,850
female: 1,246,012 (2008 est.)
Military expenditures:
1.5% of GDP (2006)','7879d12e8b72458f6f3501afeadb6fd094ae6b9242e67001d40fe02d7b99d927','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d14c90f680ba91f35a23417401629f6c33d9ffcc03dbe9cf8bb7758520a14160',2008,'BB','Barbados','military-and-security',195,'Military branches:
Royal Barbados Defense Force: Troops Command, Barbados Coast Guard
(2007)
Military service age and obligation:
18 years of age for voluntary military service (younger requires
parental consent); no conscription (2008)
Manpower available for military service:
males age 16-49: 75,265
females age 16-49: 75,389 (2008 est.)
Manpower fit for military service:
males age 16-49: 58,556
females age 16-49: 58,143 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,157
female: 2,155 (2008 est.)
Military expenditures:
0.5% of GDP (2006 est.)
Military - note:
the Royal Barbados Defense Force includes a land-based Troop Command
and a small Coast Guard; the primary role of the land element is to
defend the island against external aggression; the Command consists
of a single, part-time battalion with a small regular cadre that is
deployed throughout the island; it increasingly supports the police
in patrolling the coastline to prevent smuggling and other illicit
activities (2007)','5f59c25096a7746c5168ea9013cb1d3128a94f9509d37fd634dba5401d6c0d00','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1dc95b5f32f513ba09a750025fc2219825adfbeafda73843146c9defd9057690',2008,'BY','Belarus','military-and-security',204,'Military branches:
Belarus Armed Forces: Land Force, Air and Air Defense Force (2008)
Military service age and obligation:
18-27 years of age for compulsory military service; conscript
service obligation - 18 months (2005)
Manpower available for military service:
males age 16-49: 2,491,643
females age 16-49: 2,528,779 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,727,974
females age 16-49: 2,093,106 (2008 est.)
Manpower reaching militarily significant age annually:
male: 64,232
female: 60,788 (2008 est.)
Military expenditures:
1.4% of GDP (2005 est.)','f79de4efdc771b3d22f497e4fe0b7d688ce22328378ab97921cc450f1194da79','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6569ebb6cc755f58156e3b4399bb33c6bd6ff2161960faca1fdda46e6635901',2008,'BE','Belgium','military-and-security',213,'Military branches:
Belgian Armed Forces: Land Operations Command, Naval Operations
Command, Air Operations Command (2008)
Military service age and obligation:
18 years of age for voluntary military service; conscription
suspended (2008)
Manpower available for military service:
males age 16-49: 2,407,128
females age 16-49: 2,340,039 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,973,167
females age 16-49: 1,915,990 (2008 est.)
Manpower reaching militarily significant age annually:
male: 64,659
female: 61,881 (2008 est.)
Military expenditures:
1.3% of GDP (2005 est.)','c13538da72c066ea2c4142f531c04964aeccb70fa353edb0f20813904b0078d5','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('925b99c2678caeaf6d50f96fe60d0c06a90b6cba0333a25761688513e3fb6f40',2008,'BZ','Belize','military-and-security',223,'Military branches:
Belize Defense Force (BDF): Army, BDF Air Wing, BDF Volunteer Guard
(2007)
Military service age and obligation:
18 years of age for voluntary military service; laws allow for
conscription only if volunteers are insufficient; conscription has
never been implemented; volunteers typically outnumber available
positions by 3:1 (2008)
Manpower available for military service:
males age 16-49: 74,605
females age 16-49: 72,926 (2008 est.)
Manpower fit for military service:
males age 16-49: 54,627
females age 16-49: 53,500 (2008 est.)
Manpower reaching militarily significant age annually:
male: 3,580
female: 3,449 (2008 est.)
Military expenditures:
1.4% of GDP (2006)','74ba854a4f352a5874f66a816689b9338d5209d816bef9231c6f8004369bfcf6','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c7c3e7e3253298a2a5239a576a17f8ec689b7f770383c5c1618fac010c52fa4',2008,'BJ','Benin','military-and-security',232,'Military branches:
Benin Armed Forces (FAB): Army (l''Arme de Terre), Benin Navy (Forces
Navales Beninois, FNB), Benin People''s Air Force (Force Aerienne
Populaire de Benin, FAPB) (2008)
Military service age and obligation:
21 years of age for compulsory and voluntary military service; in
practice, volunteers may be taken at the age of 18; both sexes are
eligible for military service; conscript tour of duty - 18 months
(2006)
Manpower available for military service:
males age 16-49: 1,908,457
females age 16-49: 1,882,421 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,173,742
females age 16-49: 1,162,113 (2008 est.)
Manpower reaching militarily significant age annually:
male: 97,543
female: 94,008 (2008 est.)
Military expenditures:
1.7% of GDP (2006)','9fb22b2acb14fd1e5cb994b794b6000aaa24a3760bc863f1a327a105660cd65b','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d2de2dc4e4afeada2f93a242ac5ef8b76bbd37484c2d88db108ad781c72a14a',2008,'BM','Bermuda','military-and-security',241,'Military branches:
Bermuda Regiment (2008)
Military service age and obligation:
18-23 years of age; eligible men required to register for
conscription as needed into the Bermuda Regiment, which is largely
voluntary; term of service 39 months (2007)
Manpower available for military service:
males age 16-49: 15,623 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,682 (2008 est.)
Manpower reaching militarily significant age annually:
male: 426
female: 445 (2008 est.)
Military expenditures:
0.11% of GDP (2005 est.)
Military - note:
defense is the responsibility of the UK','be8c300066f5562014acb0785386aa6f05adf71f7f394c9d1698828d6c7649c1','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a502318b2198dc321f9f60e2e95d9efb7667b80ded9980ffd7590bd6f675e6e',2008,'BT','Bhutan','military-and-security',250,'Military branches:
Royal Bhutan Army (includes Royal Bodyguard and Royal Bhutan Police)
(2008)
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 190,104
females age 16-49: 167,289 (2008 est.)
Manpower fit for military service:
males age 16-49: 146,063
females age 16-49: 131,193 (2008 est.)
Manpower reaching militarily significant age annually:
male: 7,847
female: 7,530 (2008 est.)
Military expenditures:
1% of GDP (2005 est.)
Bolivia
Military branches:
Bolivian Armed Forces: Bolivian Army (Ejercito Boliviano), Bolivian
Navy (Armada Boliviana; includes marines), Bolivian Air Force
(Fuerza Aerea Boliviana, FAB) (2008)
Military service age and obligation:
18 years of age for 12-month compulsory military service; when
annual number of volunteers falls short of goal, compulsory
recruitment is effected, including conscription of boys as young as
14; 15-19 years of age for voluntary premilitary service, provides
exemption from further military service (2008)
Manpower available for military service:
males age 16-49: 2,295,746
females age 16-49: 2,366,828 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,600,219
females age 16-49: 1,815,514 (2008 est.)
Manpower reaching militarily significant age annually:
male: 107,051
female: 103,620 (2008 est.)
Military expenditures:
1.9% of GDP (2006)','5572e9152730493ea2965bad38ec7f6cc6631e5220d69cfba0037b9160c4260c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c489650231a81065c1fdb3a42f00319581bcc3212ce5dcbc89fcc291b70aa85a',2008,'BA','Bosnia and Herzegovina','military-and-security',259,'Military branches:
Bosnia and Herzegovina Armed Forces (OSBiH): Army of Bosnia and
Herzegovina, Air and Air Defense Forces of Bosnia and Herzegovina
(Zrakoplovstvo i Protuzracna Obrana, ZPO) (2007)
Military service age and obligation:
17 years of age for voluntary military service in the Federation and
in the Republika Srpska; conscription abolished January 2006;
4-month service obligation (2006)
Manpower available for military service:
males age 16-49: 1,212,007
females age 16-49: 1,170,645 (2008 est.)
Manpower fit for military service:
males age 16-49: 996,225
females age 16-49: 962,927 (2008 est.)
Manpower reaching militarily significant age annually:
male: 30,246
female: 28,189 (2008 est.)
Military expenditures:
4.5% of GDP (2005 est.)','25730961edc1af76d5df7beb204105c1513f3ae18ca7d1442cc097154d46b6bc','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('505de4fbb25172a510dd077c0cc8b4a30aed2861ab139c7df453824ca1fe022e',2008,'BW','Botswana','military-and-security',268,'Military branches:
Botswana Defense Force: Ground Forces, Air Wing (2008)
Military service age and obligation:
18 is the apparent age of voluntary military service; the official
qualifications for determining minimum age are unknown (2001)
Manpower available for military service:
males age 16-49: 487,853
females age 16-49: 464,278 (2008 est.)
Manpower fit for military service:
males age 16-49: 290,093
females age 16-49: 257,700 (2008 est.)
Manpower reaching militarily significant age annually:
male: 23,007
female: 22,551 (2008 est.)
Military expenditures:
3.3% of GDP (2006)','d7f64b9e0a0a2057acaec44b2a2b15c0ca3dd61315b421e7fc1e05a2100e5038','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ac3359b48c5040bd275a725edd54067101ccd13290d6dc4f2da652691ad6d69',2008,'BR','Brazil','military-and-security',283,'Military branches:
Brazilian Army, Brazilian Navy (Marinha do Brasil (MB), includes
Naval Air and Marine Corps (Corpo de Fuzileiros Navais)), Brazilian
Air Force (Forca Aerea Brasileira, FAB) (2008)
Military service age and obligation:
21-45 years of age for compulsory military service; conscript
service obligation - 9 to 12 months; 17-45 years of age for
voluntary service; an increasing percentage of the ranks are
"long-service" volunteer professionals; women were allowed to serve
in the armed forces beginning in early 1980s when the Brazilian Army
became the first army in South America to accept women into career
ranks; women serve in Navy and Air Force only in Women''s Reserve
Corps (2001)
Manpower available for military service:
males age 16-49: 52,449,957
females age 16-49: 52,375,921 (2008 est.)
Manpower fit for military service:
males age 16-49: 39,263,710
females age 16-49: 44,109,056 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,666,791
female: 1,608,363 (2008 est.)
Military expenditures:
2.6% of GDP (2006 est.)','7be2ac16f84e9ddbc1b46d54af43c83ed3676092ffbb747019bc9bf55bc3c3c8','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('376444ca7d49e99b2a225c3b7f034df6fc6b839d625c532e0c4b0406a92ddb02',2008,'IO','British Indian Ocean Territory','military-and-security',292,'Military - note:
defense is the responsibility of the UK; the US lease on Diego
Garcia expires in 2016
British Virgin Islands
Manpower available for military service:
males age 16-49: 7,101 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,921 (2008 est.)
Manpower reaching militarily significant age annually:
male: 184
female: 179 (2008 est.)
Military - note:
defense is the responsibility of the UK
Brunei
Military branches:
Royal Brunei Armed Forces (RBAF): Royal Brunei Land Forces, Royal
Brunei Navy, Royal Brunei Air Force (Tentera Udara Diraja Brunei)
(2008)
Military service age and obligation:
18 years of age (est.) for voluntary military service; non-Malays
are ineligible to serve (2007)
Manpower available for military service:
males age 16-49: 108,356
females age 16-49: 110,153 (2008 est.)
Manpower fit for military service:
males age 16-49: 91,297
females age 16-49: 93,228 (2008 est.)
Manpower reaching militarily significant age annually:
male: 3,223
female: 3,182 (2008 est.)
Military expenditures:
4.5% of GDP (2006)','aa2c509bb03ada20b6012dcfd2a3ddefcb5918a28df9f29e06f1aadf6464c445','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45a9160908ca374b91ae57e071451a2c686d70840d0149ac65e73701f0343170',2008,'BG','Bulgaria','military-and-security',301,'Military branches:
Bulgarian Armed Forces: Ground Forces, Naval Forces, Bulgarian Air
Forces (Bulgarski Voennovazdyshni Sily, BVVS) (2008)
Military service age and obligation:
18-27 years of age for voluntary military service; conscript service
obligation - 9 months; as of May 2006, 67% of the Bulgarian Army
comprised of professional soldiers; conscription ended as of 1
January 2008; Air and Air Defense Forces and Naval Forces became
fully professional at the end of 2006 (2008)
Manpower available for military service:
males age 16-49: 1,701,979
females age 16-49: 1,691,092 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,364,029
females age 16-49: 1,401,348 (2008 est.)
Manpower reaching militarily significant age annually:
male: 39,477
female: 37,339 (2008 est.)
Military expenditures:
2.6% of GDP (2005 est.)','689c0cf547ee629c60e327d40595349220954a01b67070c79df14c12c16b9aba','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddc1bbf31da3de5496e0c1b5525af09b671b578577756271770ff442b92840e8',2008,'BF','Burkina Faso','military-and-security',310,'Military branches:
Army, Air Force of Burkina Faso (Force Aerienne de Burkina Faso,
FABF), National Gendarmerie (2008)
Military service age and obligation:
18 years of age for compulsory military service; 20 years of age for
voluntary military service (2001)
Manpower available for military service:
males age 16-49: 3,364,288 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,115,948 (2008 est.)
Manpower reaching militarily significant age annually:
male: 176,358
female: 173,856 (2008 est.)
Military expenditures:
1.2% of GDP (2006)
Burma
Military branches:
Myanmar Armed Forces (Tatmadaw): Army, Navy, Air Force (Tatmadaw
Lay) (2008)
Military service age and obligation:
18 years of age for voluntary military service for both sexes;
forced conscription of children, although officially prohibited,
reportedly continues (2007)
Manpower available for military service:
males age 16-49: 13,402,788
females age 16-49: 13,437,042 (2008 est.)
Manpower fit for military service:
males age 16-49: 9,031,046
females age 16-49: 9,396,547 (2008 est.)
Manpower reaching militarily significant age annually:
male: 423,809
female: 415,843 (2008 est.)
Military expenditures:
2.1% of GDP (2005 est.)','b941fbd8dfaebd14189bd7c10bc3c2d1e31ac9bc8714117166f51a6996532505','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3a6749a2588b7d264cd67eb5737a9243c7463195d9ed7a0de1c5cd4c36f499b',2008,'BI','Burundi','military-and-security',319,'Military branches:
National Defense Force (Forces de Defense Nationales, FDN): Army
(includes Naval Detachment and Air Wing), Gendarmerie (2008)
Military service age and obligation:
16 years of age for compulsory and voluntary military service;
children as young as 10 years of age have been conscripted into the
armed forces; the enrollment of children is still not prohibited
(2007)
Manpower available for military service:
males age 16-49: 1,878,544
females age 16-49: 1,851,676 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,083,899
females age 16-49: 1,062,488 (2008 est.)
Manpower reaching militarily significant age annually:
male: 98,105
female: 98,533 (2008 est.)
Military expenditures:
5.9% of GDP (2006 est.)','6d7a98e5c6e84226f2fa1f31d13699450311c974c03e39541765744dfd7dcdb8','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc47bf5b87b75e59e026b8d38d66040a74f1856b0221cbdbf7460d129a0b5fa4',2008,'KH','Cambodia','military-and-security',328,'Military branches:
Royal Cambodian Armed Forces: Royal Cambodian Army, Royal Khmer
Navy, Royal Cambodian Air Force (2008)
Military service age and obligation:
conscription law of October 2006 requires all males between 18-30 to
register for military service; 18-month service obligation (2006)
Manpower available for military service:
males age 16-49: 3,759,034
females age 16-49: 3,784,333 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,581,045
females age 16-49: 2,676,075 (2008 est.)
Manpower reaching militarily significant age annually:
male: 185,959
female: 182,558 (2008 est.)
Military expenditures:
3% of GDP (2005 est.)','bcd346943f3ef500fe25e747382bbe11f43a9b2e1950e1522412c49fcc9189b4','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f87b4c764b683fd319a24c569e741b17813d17e6f35a33744252913c55f70d4b',2008,'CM','Cameroon','military-and-security',337,'Military branches:
Cameroon Armed Forces: Army, Navy (includes naval infantry), Air
Force (Armee de l''Air du Cameroun, AAC) (2008)
Military service age and obligation:
18 years of age for voluntary military service; no conscription; the
government makes periodic calls for volunteers (2006)
Manpower available for military service:
males age 16-49: 4,321,175
females age 16-49: 4,228,625 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,567,428
females age 16-49: 2,498,990 (2008 est.)
Manpower reaching militarily significant age annually:
male: 212,205
female: 207,545 (2008 est.)
Military expenditures:
1.3% of GDP (2006)','a2c675f34525e073b61b10bd1552074d2fb0fe5bb95d8dff9657e96687ee6e31','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be74b0e482cc08ef3880633940564ce69c3127290408fc7b4f55bcc65ccb23d3',2008,'CA','Canada','military-and-security',346,'Military branches:
Canadian Forces: Land Forces Command (LFC), Maritime Command
(MARCOM), Air Command (AIRCOM), Canada Command (homeland security)
(2008)
Military service age and obligation:
17 years of age for male and female voluntary military service (with
parental consent); 16 years of age for reserve and military college
applicants; Canadian citizenship or permanent residence status
required; maximum 34 years of age; service obligation 3-9 years
(2008)
Manpower available for military service:
males age 16-49: 8,072,010
females age 16-49: 7,813,462 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,646,281
females age 16-49: 6,417,924 (2008 est.)
Manpower reaching militarily significant age annually:
male: 227,435
female: 215,556 (2008 est.)
Military expenditures:
1.1% of GDP (2005 est.)
Cape Verde
Military branches:
People''s Revolutionary Armed Forces (FARP): Army, Coast Guard
(includes maritime air wing) (2007)
Military service age and obligation:
18 years of age (est.) for selective compulsory military service;
14-month conscript service obligation (2006)
Manpower available for military service:
males age 16-49: 103,650
females age 16-49: 103,553 (2008 est.)
Manpower fit for military service:
males age 16-49: 83,082
females age 16-49: 88,832 (2008 est.)
Manpower reaching militarily significant age annually:
male: 5,566
female: 5,441 (2008 est.)
Military expenditures:
0.7% of GDP (2005)','67554a596f6ce421227c491b84c86e8b24ed58daecdea09d458d15f5b2adffb0','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e4d992ca4208e9dc11685dcafc7b7483ac08366952a9bd862562fbfc8a7ff33',2008,'KY','Cayman Islands','military-and-security',355,'Military branches:
no regular military forces; Royal Cayman Islands Police Force (2007)
Manpower available for military service:
males age 16-49: 11,790 (2008 est.)
Manpower fit for military service:
males age 16-49: 9,577 (2008 est.)
Manpower reaching militarily significant age annually:
male: 336
female: 336 (2008 est.)
Military - note:
defense is the responsibility of the UK','ae33e2ea46e394f552caa159edf2197d7de26982c94c3b227c7f3d2c157269d5','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4437d072b7d38e024997f84d6696e2b6080f5fb23ec3c9ffd839ac44c4ad6a50',2008,'CF','Central African Republic','military-and-security',364,'Military branches:
Central African Armed Forces (Forces Armees Centrafricaines, FACA):
Ground Forces, General Directorate of Gendarmerie Inspection (DGIG),
Military Air Service, National Police (2008)
Military service age and obligation:
18 years of age for compulsory and voluntary military service;
2-year conscript service obligation (2006)
Manpower available for military service:
males age 16-49: 1,032,828
females age 16-49: 999,330 (2008 est.)
Manpower fit for military service:
males age 16-49: 534,141
females age 16-49: 495,303 (2008 est.)
Manpower reaching militarily significant age annually:
male: 54,655
female: 54,420 (2008 est.)
Military expenditures:
1.1% of GDP (2006 est.)','a05911581cc54394fd5c62b47a40ece39d557b21fcd1f0039b8b0ced1e6bf530','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b40b093a6c1495082277efda9adc4959d18139f586198c938725346ff5a7367d',2008,'TD','Chad','military-and-security',373,'Military branches:
Armed Forces: Chadian National Army (Armee Nationale du Tchad, ANT),
Chadian Air Force (Force Aerienne Tchadienne, FAT), Gendarmerie
(2008)
Military service age and obligation:
20 years of age for conscripts, with 3-year service obligation; 18
years of age for volunteers; no minimum age restriction for
volunteers with consent from a guardian; women are subject to 1 year
of compulsory military or civic service at age of 21 (2004)
Manpower available for military service:
males age 16-49: 1,906,545
females age 16-49: 2,258,758 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,066,565
females age 16-49: 1,279,318 (2008 est.)
Manpower reaching militarily significant age annually:
male: 116,824
female: 117,831 (2008 est.)
Military expenditures:
4.2% of GDP (2006)','89c2310f9922c45bf9fd982ac95115b438df666dfe49edb67d5939c8aec0cce6','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b0562b36a435f5994d3de18fb30bd5b9678db6da04e7af1ad6ebedfbfa57c66',2008,'CL','Chile','military-and-security',382,'Military branches:
Army of the Nation, Chilean Navy (Armada de Chile, includes naval
air, marine corps, and Maritime Territory and Merchant Marine
Directorate (Directemar)), Chilean Air Force (Fuerza Aerea de Chile,
FACh), Carabineros Corps (Cuerpo de Carabineros) (2008)
Military service age and obligation:
18-45 years of age for voluntary male and female military service,
although the right to compulsory recruitment is retained; service
obligation - 12 months for Army, 22 months for Navy and Air Force
(2008)
Manpower available for military service:
males age 16-49: 4,242,912
females age 16-49: 4,182,509 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,542,448
females age 16-49: 3,500,059 (2008 est.)
Manpower reaching militarily significant age annually:
male: 147,518
female: 141,139 (2008 est.)
Military expenditures:
2.7% of GDP (2006)','a88fcf8aef87ad8c8f22f420dcf482a73c162130a35e3dc02ae62231cd625a3e','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aee63e94068b25b934858bfd19bac08e4f3612ad9f02a8540013aff550ee3166',2008,'CN','China','military-and-security',391,'Military branches:
People''s Liberation Army (PLA): Ground Forces, Navy (includes
marines and naval aviation), Air Force (includes airborne forces),
and Second Artillery Corps (strategic missile force); People''s Armed
Police (PAP); PLA Reserve Force (2008)
Military service age and obligation:
18-22 years of age for selective compulsory military service, with
24-month service obligation; no minimum age for voluntary service
(all officers are volunteers); 18-19 years of age for women high
school graduates who meet requirements for specific military jobs
(2007)
Manpower available for military service:
males age 16-49: 375,009,345
females age 16-49: 354,314,328 (2008 est.)
Manpower fit for military service:
males age 16-49: 313,321,639
females age 16-49: 295,951,438 (2008 est.)
Manpower reaching militarily significant age annually:
male: 10,760,380
female: 9,710,032 (2008 est.)
Military expenditures:
4.3% of GDP (2006)','d1eafbca233880cbc27ecc8b9fb37e8f990c56df93623fe9731f08ae1b8ee203','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('654e44e295c0dbfe4886fd7df7eca1d943224a9db0c8107a561137aba519dd4d',2008,'CX','Christmas Island','military-and-security',400,'Military - note:
defense is the responsibility of Australia
Clipperton Island
Military - note:
defense is the responsibility of France','467da69263199fbb96209f3d9054d948e03bcdc0328d97d89843779598626381','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8265da42d5f4c556bed56b6e0f32f516bea4b6125a1458456dded260fd59d1b',2008,'CC','Cocos (Keeling) Islands','military-and-security',409,'Military - note:
defense is the responsibility of Australia; the territory has a
five-person police force','8b3c97e0ca2dbefbc8e7c899fa2e22ead9cce4c862e1c525dae4020c9c126fe7','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c92041d0b67d3f107cc8544ce97ec35d61e32e76543537bbc8a440ef565dcc9',2008,'CO','Colombia','military-and-security',418,'Military branches:
National Army (Ejercito Nacional), National Navy (Armada Nacional,
includes Naval Aviation, Naval Infantry (Infanteria de Marina,
Colmar), and Coast Guard), Colombian Air Force (Fuerza Aerea de
Colombia, FAC) (2008)
Military service age and obligation:
18-24 years of age for compulsory and voluntary military service;
service obligation - 18 months (2004)
Manpower available for military service:
males age 16-49: 11,478,109
females age 16-49: 11,809,279 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,056,336
females age 16-49: 9,919,952 (2008 est.)
Manpower reaching militarily significant age annually:
male: 442,403
female: 433,192 (2008 est.)
Military expenditures:
3.4% of GDP (2005 est.)','64712f02e0768ec59f3d3005d5ef80a9de6bf0b41e95c02abe1ff173a15c2751','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80299f67dc019da367b302f4c0ee1f99136138eb894cbecb143ec8e2f567b540',2008,'KM','Comoros','military-and-security',428,'Military branches:
National Development Army (AND): Comoran Security Force; Comoran
Federal Police (2008)
Manpower available for military service:
males age 16-49: 167,850
females age 16-49: 167,362 (2008 est.)
Manpower fit for military service:
males age 16-49: 121,550
females age 16-49: 131,015 (2008 est.)
Manpower reaching militarily significant age annually:
male: 7,901
female: 7,894 (2008 est.)
Military expenditures:
2.8% of GDP (2006)
Congo, Democratic Republic of the
Military branches:
Armed Forces of the Democratic Republic of the Congo (Forces
d''Armees de la Republique Democratique du Congo, FARDC): Army,
National Navy (La Marine Nationale), Congolese Air Force (Force
Aerienne Congolaise, FAC) (2008)
Military service age and obligation:
18-45 years of age for military service
Manpower available for military service:
males age 16-49: 14,101,263 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,562,989 (2008 est.)
Manpower reaching militarily significant age annually:
male: 783,762
female: 780,922 (2008 est.)
Military expenditures:
2.5% of GDP (2006)
Congo, Republic of the
Military branches:
Congolese Armed Forces (Forces Armees Congolaises, FAC): Army, Navy,
Congolese Air Force (Armee de l''Air Congolaise), Gendarmerie,
Special Presidential Security Guard (GSSP) (2008)
Military service age and obligation:
18 years of age for voluntary military service; women allowed to
serve (2007)
Manpower available for military service:
males age 16-49: 842,771
females age 16-49: 833,624 (2008 est.)
Manpower fit for military service:
males age 16-49: 519,296
females age 16-49: 509,564 (2008 est.)
Manpower reaching militarily significant age annually:
male: 45,671
female: 45,248 (2008 est.)
Military expenditures:
3.1% of GDP (2006)','d6d2b9eccb47a2f96e868a0dbdbd7db4b8a4c0bed089c3cee81506ed9bb49bc8','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a017a0371b17d227519df3487e25f19ca2ee7cf6f78b1f5e9ab348f935275a55',2008,'CK','Cook Islands','military-and-security',437,'Military branches:
no regular military forces; National Police Department (2007)
Manpower reaching militarily significant age annually:
male: 157
female: 133 (2008 est.)
Military - note:
defense is the responsibility of New Zealand, in consultation with
the Cook Islands and at its request
Coral Sea Islands
Military - note:
defense is the responsibility of Australia','c0fc10d59beca59ad7a9fb59d658d057e87bd0f1ed95f673a7d100b1077dc811','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5400decab8a849a4f1b6eb02734510cc045342c70ca8694c9bb4760b8b57792c',2008,'CR','Costa Rica','military-and-security',446,'Military branches:
no regular military forces; Ministry of Public Security, Government,
and Police (2008)
Manpower available for military service:
males age 16-49: 1,134,205
females age 16-49: 1,095,763 (2008 est.)
Manpower fit for military service:
males age 16-49: 958,013
females age 16-49: 925,727 (2008 est.)
Manpower reaching militarily significant age annually:
male: 40,767
female: 38,899 (2008 est.)
Military expenditures:
0.4% of GDP (2006)
Cote d''Ivoire
Military branches:
Cote d''Ivoire Defense and Security Forces (FDSC): Army, Navy, Air
Force (2006)
Military service age and obligation:
18 years of age for compulsory and voluntary military service (2008)
Manpower available for military service:
males age 16-49: 4,369,735
females age 16-49: 4,287,042 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,393,104
females age 16-49: 2,381,607 (2008 est.)
Manpower reaching militarily significant age annually:
male: 234,032
female: 230,799 (2008 est.)
Military expenditures:
1.6% of GDP (2005 est)','a47bbb5bf2a21402272ae69de43b94a9f6cffa8e80f2c747712429a81cf76fea','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd1a39a22012a9a53dc7216f71d4e25dbd9607e15ef4bf34c63d6f94e0036cf6',2008,'HR','Croatia','military-and-security',455,'Military branches:
Armed Forces of the Republic of Croatia (Oruzane Snage Republike
Hrvatske, OSRH), consists of five major commands directly
subordinate to a General Staff: Ground Forces (Hrvatska Kopnena
Vojska, HKoV), Naval Forces (Hrvatska Ratna Mornarica, HRM), Air
Force (Hrvatsko Ratno Zrakoplovstvo, HRZ), Joint Education and
Training Command, Logistics Command; Military Police Force supports
each of the three Croatian military forces (2008)
Military service age and obligation:
18-27 years of age for compulsory military service; 16 years of age
with consent for voluntary service; 6-month conscript service
obligation; full conversion to professional military service by 2010
(2006)
Manpower available for military service:
males age 16-49: 1,035,712
females age 16-49: 1,037,896 (2008 est.)
Manpower fit for military service:
males age 16-49: 771,323
females age 16-49: 855,937 (2008 est.)
Manpower reaching militarily significant age annually:
male: 27,500
female: 25,893 (2008 est.)
Military expenditures:
2.39% of GDP (2005 est.)','1d1813d77b3e003a5bd48c69b3605579805d351aab11da1225f410d48c5049d0','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cb1c8e0dc71ef3f217ac4dcfe0f559537625ba8a4f2d6e57cc085351cf5bf4e',2008,'CU','Cuba','military-and-security',464,'Military branches:
Revolutionary Armed Forces (Fuerzas Armadas Revolucionarias, FAR):
Revolutionary Army (ER; includes Territorial Militia Troops, MTT),
Revolutionary Navy (Marina de Guerra Revolucionaria, MGR; includes
Marine Corps), Revolutionary Air and Air Defense Force (DAAFAR),
Youth Labor Army (EJT) (2008)
Military service age and obligation:
17-28 years of age for compulsory military service; 2-year service
obligation; both sexes subject to military service (2006)
Manpower available for military service:
males age 16-49: 3,094,388
females age 16-49: 3,024,876 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,543,044
females age 16-49: 2,481,823 (2008 est.)
Manpower reaching militarily significant age annually:
male: 79,945
female: 76,014 (2008 est.)
Military expenditures:
3.8% of GDP (2006 est.)
Military - note:
the collapse of the Soviet Union deprived the Cuban Army of its
major economic and logistic support, and had a significant impact on
equipment numbers and serviceability; the army remains well trained
and professional in nature; while the lack of replacement parts for
its existing equipment and the current severe shortage of fuel have
increasingly affected operational capabilities, Cuba remains able to
offer considerable resistance to any regional power (2008)','ec2416afdfcac1a0b20261deba311bc0df6f6a988b5d7cef8b2dfb3a5e4eaf89','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2cea45f9d6bc9bfc2e6db3855ea5a65edd3eac0c3271621e71e62fc611170ce',2008,'CY','Cyprus','military-and-security',474,'Military branches:
Republic of Cyprus: Greek Cypriot National Guard (Ethniki Forea, EF;
includes air and naval elements); northern Cyprus: Turkish Cypriot
Security Force (GKK) (2007)
Military service age and obligation:
Greek Cypriot National Guard (GCNG): 18-50 years of age for
compulsory military service for all Greek Cypriot males; 17 years of
age for voluntary service; females are not conscripted; age of
military eligibility 17 to 50; length of normal service is 25 months
with a minimum of 3 months (2006)
Manpower available for military service:
Greek Cypriot National Guard (GCNG):
males age 16-49: 199,767
females age 16-49: 190,665 (2008 est.)
Manpower fit for military service:
Greek Cypriot National Guard (GCNG):
males age 16-49: 165,042
females age 16-49: 158,869 (2008 est.)
Manpower reaching militarily significant age annually:
male: 6,482
female: 6,208 (2008 est.)
Military expenditures:
3.8% of GDP (2005 est.)
Czech Republic
Military branches:
Army of the Czech Republic (ACR): Joint Forces Command (includes
Army and Air Forces), Support and Training Forces Command (2008)
Military service age and obligation:
18-28 years of age for voluntary and 19-28 for compulsory military
service (2008)
Manpower available for military service:
males age 16-49: 2,522,383
females age 16-49: 2,425,095 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,100,789
females age 16-49: 2,018,101 (2008 est.)
Manpower reaching militarily significant age annually:
male: 63,124
female: 59,786 (2008 est.)
Military expenditures:
1.46% of GDP (2007 est.)','3e5f0886eadd114e466494803b83038cc9fe15e8f6e8b7f1c09145eec364b757','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26a33704c9a7764a6747deb792e95baeb8953e3037894242e7185e3391ebf987',2008,'DK','Denmark','military-and-security',484,'Military branches:
Defense Command: Army Operational Command, Admiral Danish Fleet,
Island Command Greenland, Tactical Air Command, Home Guard (2008)
Military service age and obligation:
18 years of age for compulsory and voluntary military service;
conscripts serve an initial training period that varies from 4 to 12
months according to specialization; reservists are assigned to
mobilization units following completion of their conscript service;
women eligible to volunteer for military service (2004)
Manpower available for military service:
males age 16-49: 1,235,067
females age 16-49: 1,215,418 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,012,716
females age 16-49: 996,436 (2008 est.)
Manpower reaching militarily significant age annually:
male: 36,561
female: 34,603 (2008 est.)
Military expenditures:
1.5% of GDP (2006; 1.28% 2007 est.)
Dhekelia
Military - note:
includes Dhekelia Garrison and Ayios Nikolaos Station connected by a
roadway
This page was last updated on 18 December, 2008
======================================================================
@Djibouti','1d35f45fdaf50937d38e582b45c25576f77c2614bc1d36ef82b4a870a0ca24ec','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d393ece96b0b6618eb0f4d371bf8d13493010f43e8d44d5368d3e95086baa01c',2008,'DJ','Djibouti','military-and-security',493,'Military branches:
Djibouti National Army (includes Navy and Air Force)
Military service age and obligation:
18 years of age for voluntary military service; 16-25 years of age
for voluntary military training; no conscription (2008)
Manpower available for military service:
males age 16-49: 111,274
females age 16-49: 105,168 (2008 est.)
Manpower fit for military service:
males age 16-49: 54,460
females age 16-49: 51,684 (2008 est.)
Manpower reaching militarily significant age annually:
male: 5,618
female: 5,609 (2008 est.)
Military expenditures:
3.8% of GDP (2006)','8b9c3159c14b96011208e716821c1e0e342dad0e8b0dc984447eb849c47fd04a','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c31c4b070b921ca1460afe2bc1c6380490d8f735c27df651e8e1f5e3b36b41e',2008,'DM','Dominica','military-and-security',502,'Military branches:
no regular military forces; Commonwealth of Dominica Police Force
(includes Coast Guard) (2008)
Manpower available for military service:
males age 16-49: 18,584 (2008 est.)
Manpower fit for military service:
males age 16-49: 15,648 (2008 est.)
Manpower reaching militarily significant age annually:
male: 756
female: 713 (2008 est.)
Military expenditures:
NA (2006)','835100ae474fe6f857b7ebf8c7dddf639e96e7e849e4e1f8f4624b16ced6c81c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee368ed4929f6714528e6be3df4b01a192c76389d4769effbf97f06d94aef8cf',2008,'DO','Dominican Republic','military-and-security',511,'Military branches:
Army, Navy, Air Force (Fuerza Aerea Dominicana, FAD) (2007)
Military service age and obligation:
18 years of age for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 2,440,203
females age 16-49: 2,326,694 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,020,490
females age 16-49: 1,883,875 (2008 est.)
Manpower reaching militarily significant age annually:
male: 96,971
female: 93,116 (2008 est.)
Military expenditures:
0.8% of GDP (2006)','e208b683118e59c9a5843f8fe1f838a50481179e9d6621c7d54d598f1f46b10c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8e4c9c7ef0333aa8ca76713f48117a7f627b682e604f2bd0df3b6bed5d557fb',2008,'EC','Ecuador','military-and-security',520,'Military branches:
Army, Navy (includes Naval Infantry, Naval Aviation, Coast Guard),
Air Force (Fuerza Aerea Ecuatoriana, FAE) (2007)
Military service age and obligation:
20 years of age for selective conscript military service; 12-month
service obligation (2008)
Manpower available for military service:
males age 16-49: 3,536,602
females age 16-49: 3,559,188 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,030,664
females age 16-49: 3,037,892 (2008 est.)
Manpower reaching militarily significant age annually:
male: 144,821
female: 139,091 (2008 est.)
Military expenditures:
2.8% of GDP (2006)','9dfe0fa5e7cb9e79fb5fd4f3251c576501ed1a36c553c89cd87d62348312ab8e','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be78b02eb0b43cebd6035c074d562c2859f5a3ae7c5a2be1e4a63a3b6692fdc7',2008,'EG','Egypt','military-and-security',529,'Military branches:
Army, Navy, Air Force, Air Defense Command
Military service age and obligation:
18-30 years of age for male conscript military service; service
obligation 12-36 months, followed by a 9-year reserve obligation
(2008)
Manpower available for military service:
males age 16-49: 21,247,777
females age 16-49: 20,406,408 (2008 est.)
Manpower fit for military service:
males age 16-49: 18,153,158
females age 16-49: 17,405,837 (2008 est.)
Manpower reaching militarily significant age annually:
male: 825,300
female: 786,590 (2008 est.)
Military expenditures:
3.4% of GDP (2005 est.)','1a1f52ab24984626ecf13176386a659355d51b208d76970f5ee981fce5f92923','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d84598f9d32ccb45b8eaab5991b783ae8db0068167dd37c916038cd8df6c96f',2008,'SV','El Salvador','military-and-security',538,'Military branches:
Salvadoran Army (ES), Salvadoran Navy (FNES), Salvadoran Air Force
(Fuerza Aerea Salvadorena, FAS) (2008)
Military service age and obligation:
18 years of age for selective compulsory military service; 16 years
of age for voluntary service; service obligation - 8 months, but 11
months for officers and NCOs (2008)
Manpower available for military service:
males age 16-49: 1,634,816
females age 16-49: 1,775,474 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,168,406
females age 16-49: 1,519,375 (2008 est.)
Manpower reaching militarily significant age annually:
male: 73,915
female: 71,252 (2008 est.)
Military expenditures:
5% of GDP (2006)','808cdfb26c6c675d3146d5f2a62cdd7dea71046b21fb9124860f04f66168eaba','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aabe1160f27a996b517a957225b4bbbaea0002507bf3c62bda53a728d9767a04',2008,'GQ','Equatorial Guinea','military-and-security',547,'Military branches:
National Guard (Guardia Nacional (Army), with Coast Guard (Navy) and
Air Wing) (2008)
Military service age and obligation:
18 years of age (est.) for compulsory military service (2008)
Manpower available for military service:
males age 16-49: 136,725
females age 16-49: 138,018 (2008 est.)
Manpower fit for military service:
males age 16-49: 101,712
females age 16-49: 104,381 (2008 est.)
Manpower reaching militarily significant age annually:
male: 6,784
female: 6,543 (2008 est.)
Military expenditures:
0.1% of GDP (2006 est.)','d2d9f5ddc93fbe40c8fd4f798f0975f42219e250b0ea56e1ddddb0c21ccd4b27','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3e6026c1329e808e963491853072559ef320447704dd5b4b4439e3170293e1b',2008,'ER','Eritrea','military-and-security',556,'Military branches:
Eritrean Armed Forces: Ground Forces, Navy, Air Force (2008)
Military service age and obligation:
18-40 years of age for male and female voluntary and compulsory
military service; 16-month conscript service obligation (2006)
Manpower available for military service:
males age 16-49: 1,108,836
females age 16-49: 1,096,120 (2008 est.)
Manpower fit for military service:
males age 16-49: 715,531
females age 16-49: 731,511 (2008 est.)
Manpower reaching militarily significant age annually:
male: 60,490
female: 60,639 (2008 est.)
Military expenditures:
6.3% of GDP (2006 est.)','5a4b09aa1ddde419b4efd4db8a55886b7fce03dadf6bf1fe3a076660ced18267','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39e1192b25b32ab861ed970b330c92ad6e2601bda97a4667f0bcd1e3add2b09b',2008,'EE','Estonia','military-and-security',565,'Military branches:
Estonian Defense Forces: Land Force, Navy, Air Force (Eesti
Ohuvagi), Volunteer Defense League (Kaitseliit, KL) (2008)
Military service age and obligation:
compulsory military service for men between 19 and 28; conscription
lasts 11 months for junior NCOs and reserve platoon leaders; reserve
officers and designated specialists have a different conscript
service obligation; Estonia has committed to retaining conscription
for men up to 2010 and, unlike Latvia and Lithuania, has no plan to
transition to a contract armed forces; 17 years of age for
volunteers; reserve commitment up to the age of 60 (2006)
Manpower available for military service:
males age 16-49: 306,273
females age 16-49: 317,852 (2008 est.)
Manpower fit for military service:
males age 16-49: 218,448
females age 16-49: 264,187 (2008 est.)
Manpower reaching militarily significant age annually:
male: 8,322
female: 7,846 (2008 est.)
Military expenditures:
2% of GDP (2005 est.)','136810d57ebb2757cf43b2ef1eee218906b0d5488379377f78ca579331549911','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('023329632a6bd37e574b68a556a3a77c9bc7f97b7b77c954322b877490a7050e',2008,'ET','Ethiopia','military-and-security',574,'Military branches:
Ethiopian National Defense Force (ENDF): Ground Forces, Ethiopian
Air Force (ETAF) (2008)
note: Ethiopia is landlocked and has no navy; following the
secession of Eritrea, Ethiopian naval facilities remained in
Eritrean possession
Military service age and obligation:
18 years of age for compulsory and voluntary military service;
theoretically, no compulsory military service, but the military can
conduct call-ups when necessary and compliance is compulsory (2008)
Manpower available for military service:
males age 16-49: 17,666,967
females age 16-49: 17,530,211 (2008 est.)
Manpower fit for military service:
males age 16-49: 10,060,775
females age 16-49: 9,854,710 (2008 est.)
Manpower reaching militarily significant age annually:
male: 887,061
female: 896,048 (2008 est.)
Military expenditures:
3% of GDP (2006)','42e54873ee4a58593daccc261b8c95ea1fd5bbc7fb28dd6e7512cc220fd2639a','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7db246a2743fc8045ea32a27370e96e157f999a0ffc631c503b00c60e2e8d701',2008,'LU','Luxembourg','military-and-security',582,'European Union
Military - note:
the five-nation Eurocorps - created in 1992 by France, Germany,
Belgium, Spain, and Luxembourg - has deployed troops and police on
peacekeeping missions to Bosnia-Herzegovina, Macedonia, and the
Democratic Republic of the Congo and assumed command of the ISAF in
Afghanistan in August 2004; Eurocorps directly commands the
5,000-man Franco-German Brigade, the Multinational Command Support
Brigade, and EUFOR in Bosnia and Herzegovina; in November 2004, the
EU Council of Ministers formally committed to creating 13 1,500-man
battle groups by the end of 2007, to respond to international crises
on a rotating basis; 22 of the EU''s 25 nations have agreed to supply
troops; France, Italy, and the UK formed the first of three battle
groups in 2005; Norway, Sweden, Estonia, and Finland established the
Nordic Battle Group effective 1 January 2008; nine other groups are
to be formed; a rapid-reaction naval EU Maritime Task Group was
stood up in March 2007 (2007)
Falkland Islands (Islas Malvinas)
Military branches:
no regular military forces
Military expenditures:
NA
Military - note:
defense is the responsibility of the UK
Military branches:
Army (2007)
Military service age and obligation:
17-25 years of age for male and female voluntary military service;
soldiers under 18 are not deployed into combat or with peacekeeping
missions; no conscription; Luxembourg citizen or EU citizen with
3-year residence in Luxembourg (2008)
Manpower available for military service:
males age 16-49: 116,305
females age 16-49: 114,566 (2008 est.)
Manpower fit for military service:
males age 16-49: 95,152
females age 16-49: 93,792 (2008 est.)
Manpower reaching militarily significant age annually:
male: 3,066
female: 2,909 (2008 est.)
Military expenditures:
0.9% of GDP (2005 est.)
Macau
Military branches:
no regular military forces; defense is the responsibility of China
(2008)
Manpower available for military service:
males age 16-49: 121,825 (2008 est.)
Manpower fit for military service:
males age 16-49: 100,826 (2008 est.)
Manpower reaching militarily significant age annually:
male: 4,601
female: 4,171 (2008 est.)
Military - note:
defense is the responsibility of China
Macedonia
Military branches:
Army of the Republic of Macedonia (ARM): Joint Operational Command,
with subordinate Air Wing (Makedonsko Voeno Vozduhoplovstvo, MVV),
Special Operations Regiment (2007)
Military service age and obligation:
18 years of age for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 532,856
females age 16-49: 513,684 (2008 est.)
Manpower fit for military service:
males age 16-49: 444,693
females age 16-49: 428,341 (2008 est.)
Manpower reaching militarily significant age annually:
male: 15,141
female: 14,434 (2008 est.)
Military expenditures:
6% of GDP (2005 est.)','644c52a7d0dca653f8651f19909ba87aa1385707c93b15510570858b6616d74d','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad58e57be9dae11c781995e9ba6973b749ead31ccdf0fbdb6bc898ae80d84f12',2008,'FO','Faroe Islands','military-and-security',594,'Military branches:
no regular military forces
Manpower available for military service:
males age 16-49: 11,725 (2008 est.)
Manpower fit for military service:
males age 16-49: 9,735 (2008 est.)
Manpower reaching militarily significant age annually:
male: 400
female: 387 (2008 est.)
Military expenditures:
NA
Military - note:
defense is the responsibility of Denmark','a6e46358aaf9a7f87d1aa4cf1b3e56b37ee2cf3af17b824c75c34a89bbbb979a','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e97295fdc46538f547a56b079a4f0a5ba33279b98ab77253f859e911b13c9679',2008,'FJ','Fiji','military-and-security',603,'Military branches:
Republic of Fiji Military Forces (RFMF): Land Forces, Naval Forces
(2008)
Military service age and obligation:
18 years of age for voluntary military service; reserve obligation
to age 45 (2006)
Manpower available for military service:
males age 16-49: 242,567
females age 16-49: 238,556 (2008 est.)
Manpower fit for military service:
males age 16-49: 189,282
females age 16-49: 202,350 (2008 est.)
Manpower reaching militarily significant age annually:
male: 9,077
female: 8,728 (2008 est.)
Military expenditures:
2.2% of GDP (2005 est.)','24d25dd9f38c947eb21b37424f9420905fb93deab01ef742cdfe53d7b90ad34e','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8df25708db24008997666d41f2240320aa456a24378d3eafde55c58b5e200009',2008,'FI','Finland','military-and-security',612,'Military branches:
Finnish Defense Forces (FDF): Army, Navy (includes Coastal Defense
Forces), Air Force (Suomen Ilmavoimat) (2007)
Military service age and obligation:
18 years of age for male voluntary and compulsory national military
and nonmilitary service; service obligation 6-12 months (2008)
Manpower available for military service:
males age 16-49: 1,169,910
females age 16-49: 1,121,187 (2008 est.)
Manpower fit for military service:
males age 16-49: 965,131
females age 16-49: 923,224 (2008 est.)
Manpower reaching militarily significant age annually:
male: 34,152
female: 32,870 (2008 est.)
Military expenditures:
2% of GDP (2005 est.)','16988dbb576e177d1a406d173faf6c836e8d0250eb1dd91ed8bae52a28c4e782','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e2087a885a5741b8fb47129573d4feb93795f81c618dbe8539b052088cdc9b4',2008,'FR','France','military-and-security',623,'Military branches:
Army (Armee de Terre; includes Marines, Foreign Legion, Army Light
Aviation), Navy (Marine Nationale, includes Naval Air), Air Force
(Armee de l''Air, includes Air Defense), National Gendarmerie (2008)
Military service age and obligation:
17-40 years of age for male or female voluntary military service);
no conscription; 12-month service obligation; women serve in
noncombat military posts (2005)
Manpower available for military service:
males age 16-49: 14,646,427
females age 16-49: 14,379,630 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,110,718
females age 16-49: 11,849,988 (2008 est.)
Manpower reaching militarily significant age annually:
male: 401,379
female: 382,409 (2008 est.)
Military expenditures:
2.6% of GDP (2005 est.)','9ac5425569f90fb44eccfe16ccac09ea8f5f489dfa5b66554f79c412c433be69','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47a2daa16bb4c8940e44b9cd45acedbbe46fde4c2abf5ed989ca4654cd4c96d1',2008,'PF','French Polynesia','military-and-security',633,'Military branches:
no regular military forces; Gendarmerie and National Police Force
(2007)
Manpower available for military service:
males age 16-49: 79,540 (2008 est.)
Manpower fit for military service:
males age 16-49: 64,287 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,699
female: 2,589 (2008 est.)
Military - note:
defense is the responsibility of France
French Southern and Antarctic Lands
Military - note:
defense is the responsibility of France','15b0f3fe1d4238bbbc3a7f113188117cde563451cd07204b79420dab09a627c7','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3c53314d3edf321dee7249688ae01e532b4dc90cee7432801f48df4f1a47ef1',2008,'GA','Gabon','military-and-security',641,'Military branches:
Army, Navy, Air Force, National Gendarmerie, National Police
Military service age and obligation:
20 years of age for compulsory and voluntary military service (2007)
Manpower available for military service:
males age 16-49: 331,181
females age 16-49: 332,498 (2008 est.)
Manpower fit for military service:
males age 16-49: 192,717
females age 16-49: 188,539 (2008 est.)
Manpower reaching militarily significant age annually:
male: 16,558
female: 16,577 (2008 est.)
Military expenditures:
3.4% of GDP (2005 est.)
Gambia, The
Military branches:
Office of the Chief of Defense: Gambian National Army (National
Guard, GNA), Gambian Navy (GN) (2008)
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 379,668
females age 16-49: 384,438 (2008 est.)
Manpower fit for military service:
males age 16-49: 230,202
females age 16-49: 244,480 (2008 est.)
Manpower reaching militarily significant age annually:
male: 19,650
female: 19,582 (2008 est.)
Military expenditures:
0.5% of GDP (2006)','2378160cb04540e486a39fc9b2e69b3dea31211a750a56b294b3fd96e0d1591f','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ea5631fd701c1c1fd582934b4f01f073bd171be67b7517d8927bf6835a02e31',2008,'IL','Israel','military-and-security',649,'Gaza Strip
Military branches:
in accordance with the peace agreement, the Palestinian Authority is
not permitted conventional military forces; there are, however,
public security forces (2008)
Manpower available for military service:
males age 16-49: 337,670 (2008 est.)
Manpower fit for military service:
males age 16-49: 291,467 (2008 est.)
Manpower reaching militarily significant age annually:
male: 19,275
female: 18,309 (2008 est.)
Military expenditures:
NA
Military branches:
Israel Defense Forces (IDF), Israel Naval Forces (INF), Israel Air
Force (IAF) (2007)
Military service age and obligation:
18 years of age for compulsory (Jews, Druzes) and voluntary
(Christians, Muslims, Circassians) military service; both sexes are
obligated to military service; conscript service obligation - 36
months for enlisted men, 21 months for enlisted women, 48 months for
officers; reserve obligation to age 41-51 (men), 24 (women) (2008)
Manpower available for military service:
males age 16-49: 1,717,362
females age 16-49: 1,636,574 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,452,926
females age 16-49: 1,383,796 (2008 est.)
Manpower reaching militarily significant age annually:
male: 60,602
female: 57,532 (2008 est.)
Military expenditures:
7.3% of GDP (2006)','af9b56fd259e99135cd91f0cb3c1ea77e8364490f8152e27378ee26c9df62c04','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e39131da49c79204b6ea01ca65d2d23201d7c9bd17069094475847e86daf6a3',2008,'GE','Georgia','military-and-security',658,'Military branches:
Georgian Armed Forces: Land Forces, Navy (includes coast guard), Air
and Air Defense Forces, National Guard (2008)
Military service age and obligation:
18 to 34 years of age for compulsory and voluntary active duty
military service; conscript service obligation - 18 months (2005)
Manpower available for military service:
males age 16-49: 1,113,251
females age 16-49: 1,168,021 (2008 est.)
Manpower fit for military service:
males age 16-49: 910,720
females age 16-49: 967,566 (2008 est.)
Manpower reaching militarily significant age annually:
male: 35,917
female: 34,566 (2008 est.)
Military expenditures:
0.59% of GDP (2005 est.)
Military - note:
a CIS peacekeeping force of Russian troops is deployed in the
Abkhazia region of Georgia together with a UN military observer
group; a Russian peacekeeping battalion is deployed in South Ossetia','d5254b335f1882ea010062ce58dfa4caae2927e93bc3d61a80947d94f4f07548','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b7a02a65364a3b8541415e4581f0893ca1fcaa780ca2057c06a133635ac547c',2008,'DE','Germany','military-and-security',667,'Military branches:
Federal Armed Forces (Bundeswehr): Army (Heer), Navy (Deutsche
Marine, includes naval air arm), Air Force (Luftwaffe), Central
Medical Service (Zentraler Sanitaetsdienst) (2008)
Military service age and obligation:
18 years of age (conscripts serve a 9-month tour of compulsory
military service) (2004)
Manpower available for military service:
males age 16-49: 19,594,118
females age 16-49: 18,543,955 (2008 est.)
Manpower fit for military service:
males age 16-49: 15,906,930
females age 16-49: 15,051,183 (2008 est.)
Manpower reaching militarily significant age annually:
male: 442,972
female: 420,801 (2008 est.)
Military expenditures:
1.5% of GDP (2005 est.)','e7dc82a8ed5d69ec40c544be5dc26fbc659442f1a2af3d02782c2c227a6b0a34','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64c97bad41778206c52e8f13f29762df58459b87ed005139b4950b509bd70be2',2008,'GH','Ghana','military-and-security',676,'Military branches:
Ghanaian Army, Ghanaian Navy, Ghanaian Air Force (2007)
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 5,802,096
females age 16-49: 5,729,939 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,737,481
females age 16-49: 3,729,699 (2008 est.)
Manpower reaching militarily significant age annually:
male: 273,265
female: 267,204 (2008 est.)
Military expenditures:
0.8% of GDP (2006 est.)','f3ca7cdff6b9259107c974a106a000f9e1c52c1fa49ea0486353bf43f8659ebb','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fce1a3654fde32acac07d868c92e63f3884728dda2028131ff800610cd7650b',2008,'GI','Gibraltar','military-and-security',685,'Military branches:
Royal Gibraltar Regiment
Manpower available for military service:
males age 16-49: 6,308 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,244 (2008 est.)
Manpower reaching militarily significant age annually:
male: 190
female: 185 (2008 est.)
Military - note:
defense is the responsibility of the UK; the Royal Gibraltar
Regiment replaced the last British regular infantry forces in 1992','737ac88456a71aa3a08ff08ea7fe97b4c365c297d2abffc69200b4e36fa6acbc','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9805ad9af355fe0129aaef74aa2b8d40311ac534d5fe39283caf72d0598fbd24',2008,'GR','Greece','military-and-security',694,'Military branches:
Hellenic Army (Ellinikos Stratos, ES), Hellenic Navy (Ellinikos
Polemiko Navtiko, EPN), Hellenic Air Force (Elliniki Polimiki
Aeroporia, EPA) (2007)
Military service age and obligation:
19-45 years of age for compulsory military service; during wartime
the law allows for recruitment beginning January of the year of
inductee''s 18th birthday, thus including 17 year olds; 17 years of
age for volunteers; conscript service obligation - 1 year for all
services; women are eligible for voluntary military service (2008)
Manpower available for military service:
males age 16-49: 2,535,174
females age 16-49: 2,517,273 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,084,469
females age 16-49: 2,065,956 (2008 est.)
Manpower reaching militarily significant age annually:
male: 53,858
female: 50,488 (2008 est.)
Military expenditures:
4.3% of GDP (2005 est.)','800a9e5cc8f749d064588f8b8c21c81816280c4cc7c0853ba3226957c7c186c1','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0da9c832959a116da13a31ba39660bb2f2ff264d7dbd629947c77045905842e0',2008,'GL','Greenland','military-and-security',702,'Military branches:
no regular military forces
Manpower available for military service:
males age 16-49: 15,221 (2008 est.)
Manpower fit for military service:
males age 16-49: 10,739 (2008 est.)
Manpower reaching militarily significant age annually:
male: 534
female: 503 (2008 est.)
Military - note:
defense is the responsibility of Denmark','67be695ed371ff736512ffeacb20ae746df759976e0cc90ed23cf79b30afcaae','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af12758c3ac50cd39645a0613f41c757f104502b09f25b2128896691bb23d3d4',2008,'GD','Grenada','military-and-security',711,'Military branches:
no regular military forces; Royal Grenada Police Force (includes
Coast Guard) (2007)
Manpower available for military service:
males age 16-49: 27,309 (2008 est.)
Manpower fit for military service:
males age 16-49: 20,249 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,034
female: 970 (2008 est.)
Military expenditures:
NA','898c9da1428bd44667b7ad35157f20b20d660631dc2a412a367ebc0eea8c4154','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26ce68d09dd7b7ab2d5af2c637005ff539354fe64d5ae8faeb846e133a5f5133',2008,'GU','Guam','military-and-security',720,'Manpower reaching militarily significant age annually:
male: 1,665
female: 1,547 (2008 est.)
Military - note:
defense is the responsibility of the US','486720dd4a3d9b16cc560e253e4bd2b50e462b7721357b988ae0b56f7b7df3d0','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdea25c2ed6bfd1c6917713790aa09b078cb9e16c90d8b1f2a0415a3cf176267',2008,'GT','Guatemala','military-and-security',728,'Military branches:
Army, Navy (includes Marines), Air Force
Military service age and obligation:
all male citizens between the ages of 18 and 50 are liable for
military service; conscript service obligation varies from 12 to 24
months; women can serve as officers (2007)
Manpower available for military service:
males age 16-49: 2,861,696
females age 16-49: 3,062,967 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,310,272
females age 16-49: 2,622,450 (2008 est.)
Manpower reaching militarily significant age annually:
male: 161,550
female: 159,760 (2008 est.)
Military expenditures:
0.4% of GDP (2006)','452c447f7b7c026229bcd100f7732becbe7524f40a7dcb4a3bdb71418334d826','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae2168c8fe1ba554084cb4327fb2306077efec1061483bc5c017da3dc706c81c',2008,'GG','Guernsey','military-and-security',737,'Manpower reaching militarily significant age annually:
male: 379
female: 353 (2008 est.)
Military - note:
defense is the responsibility of the UK','911797da1705d59e72d049f70b792c0acb5910082b11f10ab9e3ba7f60a12463','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e0755a54f198762d785f2c3300dfd236ad6f545e6ed5711fd3e6adc0da74ba1',2008,'GN','Guinea','military-and-security',746,'Military branches:
Armed Forces: Army, Navy (Marine Guineenne, includes Marines), Air
Force, Presidential Guard (2008)
Military service age and obligation:
18 years of age for compulsory military service; 2-year conscript
service obligation (2006)
Manpower available for military service:
males age 16-49: 2,230,049
females age 16-49: 2,193,236 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,268,193
females age 16-49: 1,259,913 (2008 est.)
Manpower reaching militarily significant age annually:
male: 106,967
female: 104,631 (2008 est.)
Military expenditures:
1.7% of GDP (2006)','d432aecff49f86c1da98cd475933ca0593fc0b8f9df92e5762d90e2418cabf7f','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9db81d2e9343caacdb94be780bd6362dcfca8b6fdd007ab669705f0fd99ecc25',2008,'GW','Guinea-Bissau','military-and-security',755,'Military branches:
People''s Revolutionary Armed Force (FARP): Army, Navy, Air Force;
paramilitary force
Military service age and obligation:
18 years of age for selective compulsory military service (2006)
Manpower available for military service:
males age 16-49: 344,087
females age 16-49: 347,886 (2008 est.)
Manpower fit for military service:
males age 16-49: 188,605
females age 16-49: 195,429 (2008 est.)
Manpower reaching militarily significant age annually:
male: 16,634
female: 16,841 (2008 est.)
Military expenditures:
3.1% of GDP (2005 est.)','34f7f4a6319d4fce1d972d37db9be04a552884b640385323af6bab75c2c4da8a','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62225901f3d746ae36dfeaa634dfb7c1d1df64932b8cb1291e5e3e1be43bf4e5',2008,'GY','Guyana','military-and-security',764,'Military branches:
Guyana Defense Force: Army (includes Coast Guard, Air Corps) (2007)
Military service age and obligation:
18-25 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 220,797 (2008 est.)
Manpower fit for military service:
males age 16-49: 150,623 (2008 est.)
Manpower reaching militarily significant age annually:
male: 6,713
female: 6,451 (2008 est.)
Military expenditures:
1.8% of GDP (2006)','b6bd3e8997ff8605c0c1fddc1d20e1b3e2aaa42ca81198471f4e533986f147ad','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41754d4b57324beda1b0ba0f6b4ce93036ea4dbf83688e91f3ff2421410f079a',2008,'HT','Haiti','military-and-security',773,'Military branches:
no regular military forces - small Coast Guard; the regular Haitian
Armed Forces (FAdH) - Army, Navy, and Air Force - have been
demobilized but still exist on paper unless they are
constitutionally abolished (2007)
Manpower available for military service:
males age 16-49: 2,047,083
females age 16-49: 2,047,953 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,303,743
females age 16-49: 1,332,316 (2008 est.)
Manpower reaching militarily significant age annually:
male: 105,655
female: 104,376 (2008 est.)
Military expenditures:
0.4% of GDP (2006)','b1b630fed12a30ffce614a20deac460e4b3c7f3514a654d18212028359dbb4ad','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ebfb8609dd8f71218f01b4e6235349a78c8f6606365eb7d79bff439277889c8',2008,'HM','Heard Island and McDonald Islands','military-and-security',781,'Military - note:
defense is the responsibility of Australia; Australia conducts
fisheries patrols
Holy See (Vatican City)
Military branches:
Pontifical Swiss Guard (Corpo della Guardia Svizzera Pontificia)
(2007)
Military - note:
defense is the responsibility of Italy; ceremonial and limited
security duties performed by Pontifical Swiss Guard','f98116605877b06f4afa0ad63cc0bc53e316a5a94dc1a64b0fb46e14a13d6a36','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f5bdcdd88f2a88149dcfd7001bb0515a962df20a32bce6f98dbafbeab66699e',2008,'HN','Honduras','military-and-security',790,'Military branches:
Army, Navy (includes Naval Infantry), Honduran Air Force (Fuerza
Aerea Hondurena, FAH) (2008)
Military service age and obligation:
18 years of age for voluntary 2 to 3-year military service (2004)
Manpower available for military service:
males age 16-49: 1,868,940
females age 16-49: 1,825,770 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,359,406
females age 16-49: 1,371,418 (2008 est.)
Manpower reaching militarily significant age annually:
male: 90,876
female: 87,292 (2008 est.)
Military expenditures:
0.6% of GDP (2006 est.)','005d8f31dccfb2de2960735344097ebd117ada7e7b1b2c8631c17bc29dbe5813','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61dda62a3c5051705c3a29e850f1968ab8f30fd6a4ebd415e3fef92dee7b3b80',2008,'HK','Hong Kong','military-and-security',799,'Military branches:
no regular indigenous military forces; Hong Kong garrison of China''s
People''s Liberation Army (PLA) includes elements of the PLA Ground
Forces, PLA Navy, and PLA Air Force; these forces are under the
direct leadership of the Central Military Commission in Beijing and
under administrative control of the adjacent Guangzhou Military
Region (2007)
Manpower available for military service:
males age 16-49: 1,772,820
females age 16-49: 1,941,448 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,438,165
females age 16-49: 1,561,252 (2008 est.)
Manpower reaching militarily significant age annually:
male: 42,173
female: 38,753 (2008 est.)
Military expenditures:
NA
Military - note:
defense is the responsibility of China','376fce0e71a38c28248fc85c286b7d9a2eeb031083b707f83eb5bf2ee29df890','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3e8e0f65503ab8563f4d0ce1b4066aef185415ac04db73adbaeca64d5bfcd20',2008,'HU','Hungary','military-and-security',808,'Military branches:
Ground Forces, Hungarian Air Force (Magyar Legiero, ML) (2008)
Military service age and obligation:
18 years of age for voluntary military service; conscription
abolished in June 2004; 6-month service obligation, with reserve
obligation to age 50 (2006)
Manpower available for military service:
males age 16-49: 2,391,400
females age 16-49: 2,337,240 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,890,105
females age 16-49: 1,943,422 (2008 est.)
Manpower reaching militarily significant age annually:
male: 62,197
female: 59,267 (2008 est.)
Military expenditures:
1.75% of GDP (2005 est.)','a7786ea9f23857460e088b8f5bcb692e9ff46a93da38be8062015dbf1ecbb693','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36ce6f6e2e9bed522c8796abda7ef84a53d23322bd85797cd5e2af39aad5b360',2008,'IS','Iceland','military-and-security',817,'Military branches:
no regular military forces; Icelandic National Police (2008)
Manpower available for military service:
males age 16-49: 74,896 (2008 est.)
Manpower fit for military service:
males age 16-49: 62,342 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,393
female: 2,317 (2008 est.)
Military expenditures:
0% of GDP (2005 est.)
Military - note:
Iceland has no standing military force; under a 1951 bilateral
agreement - still valid - its defense was provided by the US-manned
Icelandic Defense Force (IDF) headquartered at Keflavik; however,
all US military forces in Iceland were withdrawn as of October 2006;
although wartime defense of Iceland remains a NATO commitment, in
April 2007, Iceland and Norway signed a bilateral agreement
providing for Norwegian aerial surveillance and defense of Icelandic
airspace (2008)','bbde0d6440e11064478a987d98e9319f03cea0a7dc295bf4e59f26b4c895ca14','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64cec87562f0510065a95e54d105a6e99ef7c4aef8c7406a6936c9ddbf17da87',2008,'IN','India','military-and-security',826,'Military branches:
Army, Navy (includes naval air arm), Air Force (Bharatiya Vayu
Sena), Coast Guard (2008)
Military service age and obligation:
16 years of age for voluntary military service; no conscription;
women officers allowed in noncombat roles only (2008)
Manpower available for military service:
males age 16-49: 301,094,084
females age 16-49: 283,047,141 (2008 est.)
Manpower fit for military service:
males age 16-49: 231,161,111
females age 16-49: 236,633,962 (2008 est.)
Manpower reaching militarily significant age annually:
male: 11,592,516
female: 10,636,857 (2008 est.)
Military expenditures:
2.5% of GDP (2006)','a9ef2f2ae65eea30b13d8a4d2dc533926fe8d1fd6c011a9acaede8a8c2d06c66','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34c0919199b6c3203c78d803c43f5001695485aa8fcc45416638016d0b5597a1',2008,'ID','Indonesia','military-and-security',836,'Military branches:
Indonesian Armed Forces (Tentara Nasional Indonesia, TNI): Army
(TNI-Angkatan Darat (TNI-AD)), Navy (TNI-Angkatan Laut (TNI-AL);
includes marines, naval air arm), Air Force (TNI-Angkatan Udara
(TNI-AU)), National Air Defense Command (Kommando Pertahanan Udara
Nasional (Kohanudnas)) (2008)
Military service age and obligation:
18 years of age for selective compulsory and voluntary military
service; 2-year conscript service obligation, with reserve
obligation to age 45 (officers); Indonesian citizens only (2008)
Manpower available for military service:
males age 16-49: 63,800,825
females age 16-49: 61,729,717 (2008 est.)
Manpower fit for military service:
males age 16-49: 52,367,788
females age 16-49: 52,129,123 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,181,303
female: 2,110,397 (2008 est.)
Military expenditures:
3% of GDP (2005 est.)
Iran
Military branches:
Islamic Republic of Iran Regular Forces (Artesh): Ground Forces,
Navy, Air Force of the Military of the Islamic Republic of Iran
(Niru-ye Hava''i-ye Artesh-e Jomhuri-ye Eslami-ye Iran; includes air
defense); Islamic Revolutionary Guard Corps (Sepah-e Pasdaran-e
Enqelab-e Eslami, IRGC): Ground Forces, Navy, Air Force, Qods Force
(special operations), and Basij Force (Popular Mobilization Army);
Law Enforcement Forces (2008)
Military service age and obligation:
19 years of age for compulsory military service; 16 years of age for
volunteers; 17 years of age for Law Enforcement Forces; 15 years of
age for Basij Forces (Popular Mobilization Army); conscript military
service obligation - 18 months; women exempt from military service
(2008)
Manpower available for military service:
males age 16-49: 20,212,275
females age 16-49: 19,638,751 (2008 est.)
Manpower fit for military service:
males age 16-49: 17,416,126
females age 16-49: 16,928,226 (2008 est.)
Manpower reaching militarily significant age annually:
male: 766,668
female: 727,654 (2008 est.)
Military expenditures:
2.5% of GDP (2006)','363e50805853e008101f4b8a1d37d665a1f3417f99ad547c9cd3dcaa00e8e49c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50a8596eaf94f841cf118ddc1eee2d7c0aaaaae953c6a87d867a0f5b0c8455d7',2008,'IQ','Iraq','military-and-security',845,'Military branches:
Iraqi Armed Forces: Iraqi Army (includes Iraqi Special Operations
Force, Iraqi Intervention Force), Iraqi Navy (former Iraqi Coastal
Defense Force), Iraqi Air Force (former Iraqi Army Air Corps) (2005)
Military service age and obligation:
18-49 years of age for voluntary military service (2008)
Manpower available for military service:
males age 16-49: 7,086,200
females age 16-49: 6,808,954 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,019,795
females age 16-49: 5,878,905 (2008 est.)
Manpower reaching militarily significant age annually:
male: 302,926
female: 294,747 (2008 est.)
Military expenditures:
8.6% of GDP (2006)','82c347163489b7efb0d97a78d8cfb233b3a2337c0469136cc835556ca3d054b0','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bffad9e00f450bcf52e6051b76e345fc3ca38db72b1c99b777523bac207fe492',2008,'IE','Ireland','military-and-security',854,'Military branches:
Irish Defense Forces (Oglaigh na h-Eireann): Army (includes Naval
Service and Air Corps (Aer-Chor na h-Eireann)) (2008)
Military service age and obligation:
17-25 years of age for male or female voluntary military service
(17-27 years of age for the Naval Service); enlistees 16 years of
age can be recruited for apprentice specialist positions; maximum
obligation 12 years; 17-35 years of age for the Reserve Defense
Forces; EU citizenship or 5-year residence in Ireland required (2008)
Manpower available for military service:
males age 16-49: 1,024,635
females age 16-49: 1,024,276 (2008 est.)
Manpower fit for military service:
males age 16-49: 854,982
females age 16-49: 852,592 (2008 est.)
Manpower reaching militarily significant age annually:
male: 28,610
female: 27,095 (2008 est.)
Military expenditures:
0.9% of GDP (2005 est.)','a94d0f856833a75edd7cb005ac2c3b8a9667fe9b29f0e7221ee035b230bbade7','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2187402d11add878d9fa6baa2a5f7eb672918bb31d787a4928caa232c42b3c1c',2008,'IM','Isle of Man','military-and-security',862,'Manpower reaching militarily significant age annually:
male: 471
female: 447 (2008 est.)
Military - note:
defense is the responsibility of the UK','ed8563b1185c124fb5b57304a65fb02451bd4f9026afc8d97b460d51b034cbd7','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d65afaaf5416efefb6cb1e2e6dad3706a29fb1ac5159a404a3742a2603fbb336',2008,'IT','Italy','military-and-security',873,'Military branches:
Italian Army (Esercito Italiano, EI), Italian Navy (Marina Militare
Italiana, MMI), Italian Air Force (Aeronautica Militare Italiana,
AMI), Carabinieri Corps (Arma dei Carabinieri, CC) (2008)
Military service age and obligation:
18-27 year of age for voluntary military service; conscription
abolished January 2005; women may serve in any military branch;
10-month service obligation, with a reserve obligation to age 45
(Army and Air Force) or 39 (Navy) (2006)
Manpower available for military service:
males age 16-49: 13,884,079
females age 16-49: 13,158,378 (2008 est.)
Manpower fit for military service:
males age 16-49: 11,285,488
females age 16-49: 10,680,672 (2008 est.)
Manpower reaching militarily significant age annually:
male: 290,740
female: 273,569 (2008 est.)
Military expenditures:
1.8% of GDP (2005 est.)','9065dc2529b3af9c9722530b93d07855d22f2dc313562b423d164e88a9350db2','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f826e0117875db5cae17ddce3499fb003e44988cd3715b2f0d1024534bbf1ea',2008,'JM','Jamaica','military-and-security',882,'Military branches:
Jamaica Defense Force: Ground Forces, Coast Guard, Air Wing (2007)
Military service age and obligation:
18 years of age for voluntary military service; younger recruits may
be conscripted with parental consent (2001)
Manpower available for military service:
males age 16-49: 688,480
females age 16-49: 709,548 (2008 est.)
Manpower fit for military service:
males age 16-49: 566,477
females age 16-49: 583,075 (2008 est.)
Manpower reaching militarily significant age annually:
male: 32,000
female: 31,428 (2008 est.)
Military expenditures:
0.6% of GDP (2006 est.)
Jan Mayen
Military - note:
defense is the responsibility of Norway','161e95b644409e6adc40d95f62501a299fda35715bc8a03ab7216c1ae1b85dc8','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fc85420eaf06c45ca47f3253c7a5b1ea3998c050630d3e1622e48f39fc8d3c5',2008,'JP','Japan','military-and-security',891,'Military branches:
Japanese Ministry of Defense (MOD): Ground Self-Defense Force
(Rikujou Jietai, GSDF), Maritime Self-Defense Force (Kaijou Jietai,
MSDF), Air Self-Defense Force (Koku Jieitai, ASDF) (2008)
Military service age and obligation:
18 years of age for voluntary military service (2001)
Manpower available for military service:
males age 16-49: 27,819,804
females age 16-49: 26,863,794 (2008 est.)
Manpower fit for military service:
males age 16-49: 22.963 million
females age 16-49: 22,134,127 (2008 est.)
Manpower reaching militarily significant age annually:
male: 622,168
female: 590,153 (2008 est.)
Military expenditures:
0.8% of GDP (2006)','c21959ed0c2528344f7df8fceb269a6e0701abda4b446f626a486b0c6bcded55','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5037370a5cc4369d397af1609725c582c62cc37834d417e6aef308af70ab985',2008,'JE','Jersey','military-and-security',900,'Manpower reaching militarily significant age annually:
male: 587
female: 540 (2008 est.)
Military - note:
defense is the responsibility of the UK','9f43f4afed2e0cc1308df53f9907c9ada5187740af78e3c8c7f21af8464da00b','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29207331881a8670c725853f36c3bb58683c27db7cc8e85ca4362f1691684bd8',2008,'JO','Jordan','military-and-security',909,'Military branches:
Jordanian Armed Forces (JAF): Royal Jordanian Land Force, Royal
Jordanian Navy, Royal Jordanian Air Force (Al-Quwwat al-Jawwiya
al-Malakiya al-Urduniya, RJAF), Special Operations Command (Socom);
Public Security Directorate (normally falls under Ministry of
Interior, but comes under JAF in wartime or crisis) (2008)
Military service age and obligation:
17 years of age for voluntary military service; conscription at age
18 was suspended in 1999, although all males under age 37 are
required to register; women not subject to conscription, but can
volunteer to serve in non-combat military positions (2004)
Manpower available for military service:
males age 16-49: 1,812,551
females age 16-49: 1,559,155 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,546,766
females age 16-49: 1,339,366 (2008 est.)
Manpower reaching militarily significant age annually:
male: 68,067
female: 65,512 (2008 est.)
Military expenditures:
8.6% of GDP (2006)','1f3ed10af3e6d7e00e4477a9463cf9317db4b6590cdef6ceefbb4abc1969f838','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4626169aed2fb7ecf134724d19e0ed32fdc13c6a4dea316d6936c9f3d5d0e73f',2008,'KZ','Kazakhstan','military-and-security',918,'Military branches:
Ground Forces, Naval Force, Air and Air Defense Forces, Republican
Guard
Military service age and obligation:
18 years of age for compulsory military service; conscript service
obligation - 2 years; minimum age for volunteers NA (2004)
Manpower available for military service:
males age 16-49: 4,176,731
females age 16-49: 4,219,636 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,871,205
females age 16-49: 3,551,032 (2008 est.)
Manpower reaching militarily significant age annually:
male: 145,495
female: 140,149 (2008 est.)
Military expenditures:
0.9% of GDP (Ministry of Defense expenditures) (FY02)','e240c36fd04cf3d117d1951a6c6ab84429ad2dbcfd119ff88b01d79575a19c8c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('084e4901dd618dbb752378b96f446829dbb6655c91c8e5522383df825603bb04',2008,'KE','Kenya','military-and-security',927,'Military branches:
Kenyan Army, Kenyan Navy, Kenyan Air Force (2008)
Military service age and obligation:
18 years of age (est.) for voluntary service, with a 9-year
obligation (2007)
Manpower available for military service:
males age 16-49: 9,044,685
females age 16-49: 8,805,736 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,688,259
females age 16-49: 5,396,166 (2008 est.)
Manpower reaching militarily significant age annually:
male: 411,032
female: 406,794 (2008 est.)
Military expenditures:
2.8% of GDP (2006)','388341022ac136e2976ee3210a7105b62a14da8b6d0bc7f2cd3cb4bcb8bdd18e','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f28e1ef0f13de4fb32171a460ab6933a9f522e7793817bbdfed9636da6fcaeb3',2008,'KI','Kiribati','military-and-security',937,'Military branches:
no regular military forces (constitutionally prohibited); Police
Force (2008)
Manpower available for military service:
males age 16-49: 26,377 (2008 est.)
Manpower fit for military service:
males age 16-49: 17,577 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,247
female: 1,226 (2008 est.)
Military expenditures:
NA
Military - note:
Kiribati does not have military forces; defense assistance is
provided by Australia and NZ
Korea, North
Military branches:
North Korean People''s Army: Ground Forces, Navy, Air Force; civil
security forces (2005)
Military service age and obligation:
17 years of age (2004)
Manpower available for military service:
males age 16-49: 6,225,747
females age 16-49: 6,188,270 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,141,240
females age 16-49: 5,139,447 (2008 est.)
Manpower reaching militarily significant age annually:
male: 199,628
female: 192,388 (2008 est.)
Military expenditures:
NA
Korea, South
Military branches:
Republic of Korea Army, Navy (includes Marine Corps), Air Force
(2008)
Military service age and obligation:
20-30 years of age for compulsory military service, with middle
school education required; conscript service obligation - 24-28
months, depending on the military branch involved (to be reduced to
18 months beginning 2016); 18-26 years of age for voluntary military
service; women, in service since 1950, admitted to 7 service
branches, including infantry, but excluded from artillery, armor,
anti-air, and chaplaincy corps; some 4,000 women serve as
commissioned and noncommissioned officers, approx. 2.3% of all
officers (2008)
Manpower available for military service:
males age 16-49: 13,691,809
females age 16-49: 13,029,859 (2008 est.)
Manpower fit for military service:
males age 16-49: 11,282,699
females age 16-49: 10,683,668 (2008 est.)
Manpower reaching militarily significant age annually:
male: 371,108
female: 325,408 (2008 est.)
Military expenditures:
2.7% of GDP (2006)','e66546f02abfbff544a57011cd3869834889c5d68ac142a95d9133183d3a67f9','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebda91ad7309162f7e1996c8c54e9ad726a8e4e39a41c5f3de4510c917163038',2008,'KW','Kuwait','military-and-security',946,'Military branches:
Land Forces, Kuwaiti Navy, Kuwaiti Air Force (Al-Quwwat al-Jawwiya
al-Kuwaitiya), National Guard (2007)
Military service age and obligation:
18 years of age for compulsory and voluntary military service;
reserve obligation to age 40 with 1 month annual training; women
have served in police forces since 1999 (2006)
Manpower available for military service:
males age 16-49: 1,032,408
females age 16-49: 568,657 (2008 est.)
Manpower fit for military service:
males age 16-49: 892,816
females age 16-49: 500,540 (2008 est.)
Manpower reaching militarily significant age annually:
male: 17,737
female: 18,519 (2008 est.)
Military expenditures:
5.3% of GDP (2006)','eb798157c84c0c52f8f3cb71d28c399d244dc7bc9472648c1e5b4a1929dcf436','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba9570a17e8808ae9c1016617aba635c393710eee9f02bafb2e6dfee7005099c',2008,'KG','Kyrgyzstan','military-and-security',955,'Military branches:
Army, Air Force, National Guard (2005)
Military service age and obligation:
18 years of age for compulsory military service (2001)
Manpower available for military service:
males age 16-49: 1,398,878
females age 16-49: 1,419,374 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,061,942
females age 16-49: 1,211,249 (2008 est.)
Manpower reaching militarily significant age annually:
male: 60,706
female: 58,721 (2008 est.)
Military expenditures:
1.4% of GDP (2005 est.)','436dfe03953afa2b406f27bd364abeb47f4c2f4c991d3f2e63ad132f0591b178','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d8ea4b9d31b8af92c901b0ca5387e002c075c8e44f87a8bb0eb1b4e9631c9dd',2008,'TH','Thailand','military-and-security',962,'Laos
Military branches:
Lao People''s Armed Forces (LPAF): Lao People''s Army (LPA; includes
Riverine Force), Air Force (2008)
Military service age and obligation:
15 years of age for compulsory military service; minimum 18-month
conscript service obligation (2006)
Manpower available for military service:
males age 16-49: 1,549,774
females age 16-49: 1,570,702 (2008 est.)
Manpower fit for military service:
males age 16-49: 993,162
females age 16-49: 1,052,053 (2008 est.)
Manpower reaching militarily significant age annually:
male: 73,973
female: 72,758 (2008 est.)
Military expenditures:
0.5% of GDP (2006)
Military - note:
serving one of the world''s least developed countries, the Lao
People''s Armed Forces (LPAF) is small, poorly funded, and
ineffectively resourced; its mission focus is border and internal
security, primarily in countering ethnic Hmong insurgent groups;
together with the Lao People''s Revolutionary Party and the
government, the Lao People''s Army (LPA) is the third pillar of state
machinery, and as such is expected to suppress political and civil
unrest and similar national emergencies, but the LPA also has
upgraded skills to respond to avian influenza outbreaks; there is no
perceived external threat to the state and the LPA maintains strong
ties with the neighboring Vietnamese military (2008)
Military branches:
Royal Thai Army (RTA), Royal Thai Navy (RTN, includes Royal Thai
Marine Corps), Royal Thai Air Force (Knogtap Agard Thai, RTAF) (2008)
Military service age and obligation:
21 years of age for compulsory military service; 18 years of age for
voluntary military service; males are registered at 18 years of age;
2-year conscript service obligation (2006)
Manpower available for military service:
males age 16-49: 17,553,410
females age 16-49: 17,751,268 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,968,674
females age 16-49: 14,058,779 (2008 est.)
Manpower reaching militarily significant age annually:
male: 531,315
female: 511,288 (2008 est.)
Military expenditures:
1.8% of GDP (2005 est.)','537183719ce2a959886a2b94e32ebc8e60a803fc0e3b4653971e99759a7f7656','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('399f2fd38a43f05d33550dc1e252a528ad5346ed885a8e9f45a7c45bbaa75f4a',2008,'LV','Latvia','military-and-security',971,'Military branches:
National Armed Forces (Nacionalo Brunoto Speku): Ground Forces, Navy
(Latvijas Juras Speki; includes Coast Guard (Latvijas Kara Flotes)),
Latvian Air Force (Latvijas Gaisa Speki), Border Guard, Latvian Home
Guard (Latvijas Zemessardze) (2008)
Military service age and obligation:
18 years of age for voluntary military service; conscription
abolished January 2007; under current law, every citizen is entitled
to serve in the armed forces for life (2006)
Manpower available for military service:
males age 16-49: 568,683
females age 16-49: 565,826 (2008 est.)
Manpower fit for military service:
males age 16-49: 412,849
females age 16-49: 468,827 (2008 est.)
Manpower reaching militarily significant age annually:
male: 14,506
female: 13,982 (2008 est.)
Military expenditures:
1.2% of GDP (2005 est.)','ac7aaaa67ed290cd52018fff6a4215f1f174b169939d725184c308f54887a510','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75e0956f790c5680c4fa7a1a4f331e690719d9f992b6edcd154194e1e514a639',2008,'LB','Lebanon','military-and-security',979,'Military branches:
Lebanese Armed Forces (LAF): Army (includes Navy), Air Force (2008)
Military service age and obligation:
18-30 years of age for voluntary military service; no conscription
(2007)
Manpower available for military service:
males age 16-49: 1,106,879
females age 16-49: 1,122,595 (2008 est.)
Manpower fit for military service:
males age 16-49: 934,828
females age 16-49: 948,327 (2008 est.)
Manpower reaching militarily significant age annually:
male: 32,815
female: 31,610 (2008 est.)
Military expenditures:
3.1% of GDP (2005 est.)','907aac133ec370c4a43abf1ecaf9c6402f2a313502f5023622ab12107338b0e0','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce03f23dd79a3006d1e90ef0e2218154acc8d457aa206232f3efc2e77c5af83b',2008,'LS','Lesotho','military-and-security',989,'Military branches:
Lesotho Defense Force (LDF): Army (includes Air Wing) (2008)
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 525,203
females age 16-49: 522,485 (2008 est.)
Manpower fit for military service:
males age 16-49: 262,101
females age 16-49: 238,350 (2008 est.)
Manpower reaching militarily significant age annually:
male: 26,084
female: 26,006 (2008 est.)
Military expenditures:
2.6% of GDP (2006)
Military - note:
Lesotho''s declared policy is maintenance of its independent
sovereignty and preservation of internal security; in practice,
external security is guaranteed by South Africa; restructuring of
the Lesotho Defense Force (LDF) and Ministry of Defense and Public
Service over the past five years has focused on subordinating the
defense apparatus to civilian control and restoring the LDF''s
cohesion; the restructuring has considerably improved capabilities
and professionalism, but the LDF is disproportionately large for a
small, poor country; the government has outlined a reduction to a
planned 1,500-man strength, but these plans have met with vociferous
resistance from the political opposition and from inside the LDF
(2008)','3d498d2cdc0bc647c6aaf473db87e1b36fc78399ebdccd8075ad996582b68c66','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0a9536bb4c64b02b47824a2f17f4cd6beaeaf01cd7d90b234c4991eeb3daad2',2008,'LR','Liberia','military-and-security',998,'Military branches:
Armed Forces of Liberia (AFL): Army, Navy, Air Force
Military service age and obligation:
16 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 729,813
females age 16-49: 741,223 (2008 est.)
Manpower fit for military service:
males age 16-49: 371,287
females age 16-49: 373,265 (2008 est.)
Manpower reaching militarily significant age annually:
male: 30,448
female: 29,902 (2008 est.)
Military expenditures:
1.3% of GDP (2006 est.)','9e189190ef9e5900ac6866f73624f9a9e34431ce9e44ebf1b8c5a0f2ce0c73c3','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9038338631d9c557048fdc053aceb44cf3c94d195848b0ac6b61d259e06ab044',2008,'LY','Libya','military-and-security',1007,'Military branches:
Armed Peoples on Duty (APOD, Army), Libyan Arab Navy, Libyan Arab
Air Force (Al-Quwwat al-Jawwiya al-Jamahiriya al-Arabia al-Libyya,
LAAF) (2008)
Military service age and obligation:
17 years of age (2004)
Manpower available for military service:
males age 16-49: 1,682,183
females age 16-49: 1,611,001 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,439,941
females age 16-49: 1,381,914 (2008 est.)
Manpower reaching militarily significant age annually:
male: 61,305
female: 58,788 (2008 est.)
Military expenditures:
3.9% of GDP (2005 est.)','36c17b0cc405624d20d19261e4ccf827b4911eee6a4d0c165ca336b6eae2c382','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22299c89af7a538d1d4eed9ffef20d621847d6f910a8a7c8ff418593d6be360f',2008,'LI','Liechtenstein','military-and-security',1016,'Military branches:
no regular military forces (constitutionally prohibited);
Principality of Liechtenstein National Police (Landespolizei, LP)
(2008)
Manpower available for military service:
males age 16-49: 8,102 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,584 (2008 est.)
Manpower reaching militarily significant age annually:
male: 202
female: 222 (2008 est.)
Military - note:
Liechtenstein has no military forces, but is interested in European
security policy and is an active member of the Organization for
Security and Cooperation in Europe (OSCE)','a5dd3b3693ed999b205ac42bc2a9ad25d5cc51e0c8e5462398471d15f07ba87d','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b5667d2e93f446be62fd5be17b3d2f4a47f5401b0240a6580bb93434cc4017e',2008,'LT','Lithuania','military-and-security',1024,'Military branches:
Ground Forces, Naval Force, Lithuanian Military Air Forces, National
Defense Volunteer Forces (2005)
Military service age and obligation:
19-45 years of age for compulsory military service; 18 years of age
for volunteers; 12-month conscript service obligation (2006)
Manpower available for military service:
males age 16-49: 915,187
females age 16-49: 906,097 (2008 est.)
Manpower fit for military service:
males age 16-49: 678,434
females age 16-49: 749,483 (2008 est.)
Manpower reaching militarily significant age annually:
male: 25,907
female: 24,735 (2008 est.)
Military expenditures:
1.2% of GDP (2006; 1.23% 2007 est.)','4f7e436355d19030c7ecead3d629e2a12211f7de647d30a9c1e6ca62f8029ffd','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7692c6fb28c717dba52ec3318efcb2a5a03b20735b03f749289afdec4732e8e',2008,'MG','Madagascar','military-and-security',1032,'Military branches:
People''s Armed Forces: Intervention Force, Development Force, and
Aeronaval Force (navy and air); National Gendarmerie
Military service age and obligation:
18-25 years of age for male-only compulsory military service;
18-month conscript service obligation (either military or equivalent
civil service); 20-30 years of age for National Gendarmerie recruits
(35 years of age for those with military experience) (2008)
Manpower available for military service:
males age 16-49: 4,443,341
females age 16-49: 4,441,124 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,034,600
females age 16-49: 3,271,732 (2008 est.)
Manpower reaching militarily significant age annually:
male: 230,088
female: 229,932 (2008 est.)
Military expenditures:
1% of GDP (2006)','84304107f5281bc489fca1bb0baf12e7e5c5d0b8bc00966a27ed75d2ed42ca2d','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d2a043482f55f8ac68958b2cecae0800015d4656ed7b6725f11cf61e7cf3c97',2008,'MW','Malawi','military-and-security',1041,'Military branches:
Malawi Armed Forces: Army (includes Air Wing and Naval Detachment)
(2007)
Military service age and obligation:
18 years of age for voluntary military service; standard obligation
is 2 years of active duty and 5 years of reserve service (2007)
Manpower available for military service:
males age 16-49: 3,050,444 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,676,117 (2008 est.)
Manpower reaching militarily significant age annually:
male: 168,858
female: 168,946 (2008 est.)
Military expenditures:
1.3% of GDP (2006)','91d07dfe3ae212bc760214fe75244f43bcdc932da001047c937ee11a7e4c1a91','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77662dc7ad879ce47c7fa81304f6a23ba7ec62ca9dbde62c00fcb58680ede42a',2008,'MY','Malaysia','military-and-security',1050,'Military branches:
Malaysian Armed Forces (Angkatan Tentera Malaysia, ATM): Malaysian
Army (Tentera Darat Malaysia), Royal Malaysian Navy (Tentera Laut
Diraja Malaysia, TLDM), Royal Malaysian Air Force (Tentera Udara
Diraja Malaysia, TUDM) (2008)
Military service age and obligation:
18 years of age for voluntary military service (2005)
Manpower available for military service:
males age 16-49: 6,440,338
females age 16-49: 6,280,826 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,374,006
females age 16-49: 5,316,865 (2008 est.)
Manpower reaching militarily significant age annually:
male: 260,725
female: 247,309 (2008 est.)
Military expenditures:
2.03% of GDP (2005 est.)','27ddb9d72ed61799b22947c97a52b5ccb16739a2522d02440491452452af6d7c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ee61897d5f4a5a11a510da86fe41d07117dfbe3a98cec93e40d53e0ef4d622a',2008,'MV','Maldives','military-and-security',1059,'Military branches:
Maldives National Defense Force (MNDF): Quick Reaction Force,
Security Protection Group, Coast Guard (2007)
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 89,505
females age 16-49: 85,745 (2008 est.)
Manpower fit for military service:
males age 16-49: 72,150
females age 16-49: 69,058 (2008 est.)
Manpower reaching militarily significant age annually:
male: 4,749
female: 4,084 (2008 est.)
Military expenditures:
5.5% of GDP (2005 est.)
Military - note:
the Maldives National Defense Force (MNDF), with its small size and
with little serviceable equipment, is inadequate to prevent external
aggression and is primarily tasked to reinforce the Maldives Police
Service (MPS) and ensure security in the exclusive economic zone
(2008)','9e2b1fe43f18432132de0d5608f090d514ea9e433b7861537709bb7bf321419c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('024c0856d4732b22ef0aa1e7f54df3f9666732a6ac359a8597c18ce49b3a329d',2008,'ML','Mali','military-and-security',1068,'Military branches:
Malian Armed Forces: Army, Republic of Mali Air Force (Force
Aerienne de la Republique du Mali, FARM), National Guard (2008)
Military service age and obligation:
18 years of age for compulsory and voluntary military service;
conscript service obligation - 2 years (2008)
Manpower available for military service:
males age 16-49: 2,603,700
females age 16-49: 2,441,776 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,594,184
females age 16-49: 1,529,871 (2008 est.)
Manpower reaching militarily significant age annually:
male: 144,293
female: 136,381 (2008 est.)
Military expenditures:
1.9% of GDP (2006)','37c2ef8aefb6710e6033dbaad8a2b116441acaa80e1089f35ba46af71a353c9f','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2229d30bfa743c0ba59ebe064cd5aba642c7037bae1f91dc87efcc24c6e2386',2008,'MT','Malta','military-and-security',1077,'Military branches:
Armed Forces of Malta (AFM; includes air and maritime elements)
(2007)
Military service age and obligation:
17 years 6 months of age for voluntary military service; no
conscription (2008)
Manpower available for military service:
males age 16-49: 96,309
females age 16-49: 92,242 (2008 est.)
Manpower fit for military service:
males age 16-49: 80,227
females age 16-49: 76,623 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,815
female: 2,657 (2008 est.)
Military expenditures:
0.7% of GDP (2006 est.)','a8c51bee699a1e63bffdc54e50a0673e2fdaf2e36adb72de4fbc7f8459d4c5d5','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13674c36764ede360b9596d4891e0dc0f907fae48b014a1d349537a21b494f83',2008,'MH','Marshall Islands','military-and-security',1086,'Military branches:
no regular military forces; under the 1983 Compact of Free
Association, the US has full authority and responsibility for
security and defense of the Marshall Islands; Marshall Islands
Police (2008)
Manpower available for military service:
males age 16-49: 15,708 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,864 (2008 est.)
Manpower reaching militarily significant age annually:
male: 512
female: 494 (2008 est.)
Military expenditures:
NA
Military - note:
defense is the responsibility of the US
United States Pacific Island Wildlife Refuges
Military - note:
defense is the responsibility of the US','de27333d07aa054b723f103869d357b8ff3841582e68ef72f915ca1d9a266181','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82d88a9a50992f408b47dfd820ec03799671fe9ef04baecf3e3d24a7be4d859c',2008,'MR','Mauritania','military-and-security',1095,'Military branches:
Mauritanian Armed Forces: Army, Mauritanian Navy (Marine
Mauritanienne; includes naval infantry), Islamic Air Force of
Mauritania (Force Aerienne Islamique de Mauritanie, FAIM) (2008)
Military service age and obligation:
18 years of age (est.); conscript service obligation - 2 years;
majority of servicemen believed to be volunteers; service in Air
Force and Navy is voluntary (2006)
Manpower available for military service:
males age 16-49: 740,675
females age 16-49: 744,709 (2008 est.)
Manpower fit for military service:
males age 16-49: 463,305
females age 16-49: 484,777 (2008 est.)
Manpower reaching militarily significant age annually:
male: 38,191
female: 38,638 (2008 est.)
Military expenditures:
5.5% of GDP (2006)','7557ef94f5e16a63012b036ea7af15cce0bf91d7d9fc9afad13862c570da985c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d8d69a9cd5a96f3a00f09a1ed2852f14d4f9b1e63ad433524f6a944e274aa88',2008,'MU','Mauritius','military-and-security',1104,'Military branches:
no regular military forces; National Police Force, Special Mobile
Force, National Coast Guard (2008)
Manpower available for military service:
males age 16-49: 341,018 (2008 est.)
Manpower reaching militarily significant age annually:
male: 11,089
female: 10,843 (2008 est.)
Military expenditures:
0.3% of GDP (2006 est.)','cfb6dad8c4206c067ff6472b29e4a2b700d7579e31804c71fe09d605efdfa400','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9105319f36656ff8d9bef0db971d27746781233e44ae56784c72e5df47044f5',2008,'YT','Mayotte','military-and-security',1113,'Manpower reaching militarily significant age annually:
male: 2,407
female: 2,401 (2008 est.)
Military - note:
defense is the responsibility of France; a small contingent of
French forces is stationed on the island','c7d99ebc283cea16c039ecf3d3aa04b750e9e3c0f56a4d868478269ac6e54164','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbd7e1d463c243b885425e215b183b5b0b512bcc8fb695cd6bffc05662769568',2008,'MX','Mexico','military-and-security',1121,'Military branches:
Secretariat of National Defense (Secretaria de Defensa Nacional,
Sedena): Army (Ejercito, includes Mexican Air Force (Fuerza Aerea
Mexicana, FAM)); Secretariat of the Navy (Secretaria de Marina,
Semar): Mexican Navy (Armada de Mexico, ARM, includes Naval Air
Force (FAN) and naval infantry) (2008)
Military service age and obligation:
18 years of age for compulsory military service, conscript service
obligation - 12 months; 16 years of age with consent for voluntary
enlistment; conscripts serve only in the Army; Navy and Air Force
service is all voluntary; women are eligible for voluntary military
service (2007)
Manpower available for military service:
males age 16-49: 27,774,688
females age 16-49: 29,376,791 (2008 est.)
Manpower fit for military service:
males age 16-49: 22,188,284
females age 16-49: 24,884,614 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,110,544
female: 1,073,223 (2008 est.)
Military expenditures:
0.5% of GDP (2006 est.)','7bfaf1500453731b71732e659310e6c7828205eba7fea4cf7f6c2eeea8243961','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2199ae7c2913988aeab5f0db548801bb0a8df16d53ef1f5f63d93ba5de318454',2008,'FM','Micronesia, Federated States of','military-and-security',1130,'Military branches:
no regular military forces
Manpower available for military service:
males age 16-49: 26,686 (2008 est.)
Manpower fit for military service:
males age 16-49: 21,748 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,310
female: 1,262 (2008 est.)
Military - note:
defense is the responsibility of the US
Moldova
Military branches:
National Army: Ground Forces, Rapid Reaction Forces, Air and Air
Defense Forces (2008)
Military service age and obligation:
18 years of age for compulsory military service; 12-month service
obligation (2006)
Manpower available for military service:
males age 16-49: 1,161,924
females age 16-49: 1,187,771 (2008 est.)
Manpower fit for military service:
males age 16-49: 877,070
females age 16-49: 994,091 (2008 est.)
Manpower reaching militarily significant age annually:
male: 33,053
female: 31,712 (2008 est.)
Military expenditures:
0.4% of GDP (2005 est.)','f2959b12cadda3b46efbba4348043efc6b069f738244d2895653d91c86fbcd87','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b726487d47661a0469e095484c814bf79900bdefbc413720cda51d99a78dec4e',2008,'MC','Monaco','military-and-security',1139,'Military branches:
no regular military forces; the Palace Guard performs ceremonial
duties
Manpower available for military service:
males age 16-49: 6,687 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,376 (2008 est.)
Manpower reaching militarily significant age annually:
male: 191
female: 182 (2008 est.)
Military - note:
defense is the responsibility of France','2fef0d0882fb296ae964ab7a5d89fc1e0ca0e1d167ab309dd8b3535889c35afe','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3438dbc8f3d0f2e7aa1dac39e31fce24770d7acd74014644317492fda22ec353',2008,'MN','Mongolia','military-and-security',1148,'Military branches:
Mongolian Armed Forces: Mongolian Army, Mongolian Air Force; there
is no navy (2008)
Military service age and obligation:
18-25 years of age for compulsory military service; conscript
service obligation - 12 months in land or air defense forces or
police; a small portion of Mongolian land forces (2.5 percent) is
comprised of contract soldiers; women cannot be deployed overseas
for military operations (2006)
Manpower available for military service:
males age 16-49: 865,425
females age 16-49: 860,669 (2008 est.)
Manpower fit for military service:
males age 16-49: 696,652
females age 16-49: 731,480 (2008 est.)
Manpower reaching militarily significant age annually:
male: 29,990
female: 29,256 (2008 est.)
Military expenditures:
1.4% of GDP (2006)','3e12a4eccdc5e4e60d238306165488812117c52fc941c3cf65707767e2e1c119','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84013d4a87a1207346780a3fea477632c79bfa07b9f7c2daa9fbd153ea50e430',2008,'ME','Montenegro','military-and-security',1157,'Military branches:
Armed Forces of the Republic of Montenegro: Army, Navy (serves as
Coast Guard), Air Force (2008)
Military service age and obligation:
compulsory national military service abolished August 2006
Manpower reaching militarily significant age annually:
male: 4,426
female: 4,201 (2008 est.)
Military - note:
Montenegrin plans call for the establishment of a fully professional
armed forces','55778b3b729572f4981440c735676183d65922dc717c5c5806adc858c31c1050','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d08f8fb53d851ed958692eaab0569859afbe6569ae42500e703c841211a5e312',2008,'MS','Montserrat','military-and-security',1166,'Military branches:
no regular military forces; Royal Montserrat Police Force (2008)
Manpower available for military service:
males age 16-49: 2,528 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,097 (2008 est.)
Manpower reaching militarily significant age annually:
male: 31
female: 39 (2008 est.)
Military - note:
defense is the responsibility of the UK','8525936d01740d1022ade73e16355d3a06d1c34db9b21ec6a448cbced5b1fdb7','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fb77454681ad84baa20801c1f140e8df2bac9fdf117afc21979914465874668',2008,'MA','Morocco','military-and-security',1175,'Military branches:
Royal Armed Forces (Forces Armees Royales, FAR): Royal Moroccan Army
(includes Air Defense), Navy (includes Marines), Royal Moroccan Air
Force (Al Quwwat al Jawyiya al Malakiya Marakishiya; Force Aerienne
Royale Marocaine) (2008)
Military service age and obligation:
18 years of age for compulsory and voluntary military service;
conscript service obligation - 18 months (2004)
Manpower available for military service:
males age 16-49: 9,152,580
females age 16-49: 9,080,830 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,627,988
females age 16-49: 7,754,873 (2008 est.)
Manpower reaching militarily significant age annually:
male: 355,479
female: 343,016 (2008 est.)
Military expenditures:
5% of GDP (2003 est.)','0223c230a39e9809579ba90e208b849b29953bacfd93e111d54fd43fedbf70b5','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76ede7a40a8f67fa2a18ad70fc338e5dc66d90bdcfb840ff1e220363e59639ce',2008,'MZ','Mozambique','military-and-security',1184,'Military branches:
Mozambique Armed Defense Forces (FADM): Mozambique Army, Mozambique
Navy (Marinha Mocambique, MM), Mozambique Air Force (Forca Aerea de
Mocambique, FAM) (2006)
Military service age and obligation:
18-30 years of age for compulsory military service; 2-year service
obligation (2006)
Manpower available for military service:
males age 16-49: 4,545,975 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,287,526 (2008 est.)
Manpower reaching militarily significant age annually:
male: 257,261
female: 259,114 (2008 est.)
Military expenditures:
0.8% of GDP (2006)
Tanzania
Military branches:
Tanzanian People''s Defense Force (Jeshi la Wananchi la Tanzania,
JWTZ): Army, Naval Wing (includes Coast Guard), Air Defense Command
(includes Air Wing), National Service (2007)
Military service age and obligation:
18 years of age for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 9,108,177 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,278,833 (2008 est.)
Manpower reaching militarily significant age annually:
male: 478,812
female: 479,557 (2008 est.)
Military expenditures:
0.2% of GDP (2005 est.)','5d47cfb30c3a6948add5a8ea57c2fdcc191fad04cdf7e73218bf85275f7e6891','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89b7779c3c02f051b7d636436178aed8b19a2141cd58e79d34dfbc36f1191ab5',2008,'NA','Namibia','military-and-security',1193,'Military branches:
Namibian Defense Force: Army, Navy, Air Wing (2008)
Military service age and obligation:
18-25 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 527,948 (2008 est.)
Manpower fit for military service:
males age 16-49: 313,497 (2008 est.)
Manpower reaching militarily significant age annually:
male: 25,525
female: 25,182 (2008 est.)
Military expenditures:
3.7% of GDP (2006)','d22d6e40c58b68fb0f2ad7da859f3ed504ddd7e99b9157a6b948fdc0b9b87788','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8dda6183112b1a6e2962d6f02c1dc0219051d30c71f3054c65af91c5afbf26a',2008,'NR','Nauru','military-and-security',1202,'Military branches:
no regular military forces; Nauru Police Force (2008)
Manpower available for military service:
males age 16-49: 3,470 (2008 est.)
Manpower reaching militarily significant age annually:
male: 173
female: 159 (2008 est.)
Military expenditures:
NA
Military - note:
Nauru maintains no defense forces; under an informal agreement,
defense is the responsibility of Australia
Navassa Island
Military - note:
defense is the responsibility of the US','531f1377fa6b1f7debc937fdb2ab71034ef982d564cff1af27b9dbef967628ab','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7821f39a2b0c759942dccc1378d1c25996b4eff26a49f6c0ebf2715776de0274',2008,'NP','Nepal','military-and-security',1211,'Military branches:
Nepalese Army, Armed Police Force (2008)
Military service age and obligation:
18 years of age for voluntary military service; 15 years of age for
military training; no conscription (2008)
Manpower available for military service:
males age 16-49: 7,322,965
females age 16-49: 6,859,064 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,146,958
females age 16-49: 4,724,495 (2008 est.)
Manpower reaching militarily significant age annually:
male: 335,747
female: 312,297 (2008 est.)
Military expenditures:
1.6% of GDP (2006)','ba846c4c560de46ddcb0f9fb3c5cfae95bfdb02e5397ec13468fab12e76d0be9','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9ebe1a341f694423f86d5919b82cedd025fb72f0788ca45f8035370c7467a29',2008,'NL','Netherlands','military-and-security',1219,'Military branches:
Royal Netherlands Army, Royal Netherlands Navy (includes Naval Air
Service and Marine Corps), Royal Netherlands Air Force (Koninklijke
Luchtmacht, KLu), Royal Military Police (2008)
Military service age and obligation:
20 years of age for an all-volunteer force (2004)
Manpower available for military service:
males age 16-49: 3,950,825
females age 16-49: 3,850,800 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,233,773
females age 16-49: 3,150,790 (2008 est.)
Manpower reaching militarily significant age annually:
male: 105,735
female: 100,747 (2008 est.)
Military expenditures:
1.6% of GDP (2005 est.)
Netherlands Antilles
Military branches:
no regular military forces; National Guard (2008)
Military service age and obligation:
16 years of age for National Guard recruitment; no conscription
(2004)
Manpower available for military service:
males age 16-49: 55,365
females age 16-49: 57,060 (2008 est.)
Manpower fit for military service:
males age 16-49: 46,102
females age 16-49: 47,219 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,855
female: 1,760 (2008 est.)
Military - note:
defense is the responsibility of the Kingdom of the Netherlands','13a749847951bd45ec1ea93aeba1aadc506f3bb4b9d0894f7221d07d9e35ea6e','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43b05cbc309462a8203b8ab40fde5e84ea08cda8f288dc41f9a3c8cae952ced2',2008,'NC','New Caledonia','military-and-security',1228,'Military branches:
no regular indigenous military forces; French Armed Forces (includes
Army, Navy, Air Force, Gendarmerie); Police Force
Manpower available for military service:
males age 16-49: 57,738 (2008 est.)
Manpower fit for military service:
males age 16-49: 47,342 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,202
female: 2,121 (2008 est.)
Military expenditures:
NA
Military - note:
defense is the responsibility of France','855c310d1ebaa83b78421c4c1b67fde01098ef922fd5cd6a500dd8c6eebe10db','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c731df94a1d2a91e9816f72efab3d9713b4a3c89390c26f18ae62456cca7f3ba',2008,'NZ','New Zealand','military-and-security',1236,'Military branches:
New Zealand Defense Force (NZDF): New Zealand Army, Royal New
Zealand Navy, Royal New Zealand Air Force (2008)
Military service age and obligation:
17 years of age for voluntary military service; soldiers cannot be
deployed until the age of 18; no conscription (2008)
Manpower available for military service:
males age 16-49: 1,009,298
females age 16-49: 997,134 (2008 est.)
Manpower fit for military service:
males age 16-49: 833,073
females age 16-49: 822,807 (2008 est.)
Manpower reaching militarily significant age annually:
male: 31,834
female: 30,243 (2008 est.)
Military expenditures:
1% of GDP (2005 est.)','d6e7f5255ed8e23b64126a2458318a2ae94d999fb1c3edd10076f0955f0ce0fb','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5db5c45a8ccb0c9dbb5e5703976c94e796e8cf4cd65d3ccc3c639811b29ad27',2008,'NI','Nicaragua','military-and-security',1245,'Military branches:
National Army of Nicaragua (ENN; includes Navy, Air Force) (2008)
Military service age and obligation:
17 years of age for voluntary military service; tour of duty 18-36
months (2008)
Manpower available for military service:
males age 16-49: 1,513,312
females age 16-49: 1,507,999 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,235,400
females age 16-49: 1,302,318 (2008 est.)
Manpower reaching militarily significant age annually:
male: 72,689
female: 70,452 (2008 est.)
Military expenditures:
0.6% of GDP (2006)','ec3481d7c38f025d303cb66f86f43ae37cd45522938cdc3f3b360c10fb2e3434','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bab5a5561624337a5e1ec37333d34f25d3d38785c84851e4bc5110b00bb2a2c0',2008,'NE','Niger','military-and-security',1254,'Military branches:
Nigerien Armed Forces (Forces Armees Nigeriennes, FAN): Army, Niger
Air Force (Force Aerienne du Niger) (2008)
Military service age and obligation:
17-21 years of age for voluntary military service; 2-year service
term; women may serve in health care (2008)
Manpower available for military service:
males age 16-49: 2,871,868
females age 16-49: 2,696,966 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,665,108
females age 16-49: 1,548,965 (2008 est.)
Manpower reaching militarily significant age annually:
male: 150,728
female: 143,379 (2008 est.)
Military expenditures:
1.3% of GDP (2006)','1cbfd1a56dcbd316b89af0cc130616e5e34b2133f63800ea0fa8c45d52a14e06','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f95239f06203d1a1d42c1624971165ffc9df57052eb8744ced169cb8a8dbe28b',2008,'NG','Nigeria','military-and-security',1262,'Military branches:
Nigerian Armed Forces: Army, Navy, Air Force (2008)
Military service age and obligation:
18 years of age for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 31,929,204
females age 16-49: 30,638,979 (2008 est.)
Manpower fit for military service:
males age 16-49: 18,556,755
females age 16-49: 17,288,225 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,663,025
female: 1,585,224 (2008 est.)
Military expenditures:
1.5% of GDP (2006)','2abaeb3f71f68171e577fd7a3b9610c94ac755d35500c482ff3943016569bb84','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46e70e8f77151767c1eb2ad1bd50c4f67ef964a19ab97da8852ec1b5876a1cf4',2008,'NU','Niue','military-and-security',1271,'Military branches:
no regular indigenous military forces; Police Force
Military - note:
defense is the responsibility of New Zealand','709f59e07be3cb4d66df1a1280f1204709a9e6d215b5548629d0e03cb6a9543e','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5465c7edb83af2564ba77757abe082315a5bc85cd195c988beac72177688613',2008,'MP','Northern Mariana Islands','military-and-security',1288,'Manpower reaching militarily significant age annually:
male: 572
female: 594 (2008 est.)
Military - note:
defense is the responsibility of the US','4c726c4dab437fd6383ae22871f319fc65ccbda4be0589bb266bb7e4c3f8763d','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f2eb70b491cb94ab0672b74e2a1a5cbc7fc2ad8783c90f10cbb1922eb197033',2008,'NO','Norway','military-and-security',1297,'Military branches:
Norwegian Army (Haeren), Royal Norwegian Navy (Kongelige Norske
Sjoeforsvaret, RNoN; includes Coastal Rangers and Coast Guard
(Kystvakt)), Royal Norwegian Air Force (Kongelige Norske
Luftforsvaret, RNoAF), Home Guard (Heimevernet, HV) (2007)
Military service age and obligation:
18-44 years of age for male compulsory military service; 16 years of
age in wartime; 17 years of age for male volunteers; 18 years of age
for women; 12-month service obligation, in practice shortened to 8
to 9 months; although all males between ages of 18 and 44 are liable
for service, in practice they are seldom called to duty after age
30; reserve obligation to age 35-60; 16 years of age for volunteers
to the Home Guard, who serve 6-month duty tours (2006)
Manpower available for military service:
males age 16-49: 1,078,181
females age 16-49: 1,046,550 (2008 est.)
Manpower fit for military service:
males age 16-49: 888,101
females age 16-49: 862,159 (2008 est.)
Manpower reaching militarily significant age annually:
male: 32,185
female: 30,683 (2008 est.)
Military expenditures:
1.9% of GDP (2005 est.)','0fefe59556c1de01b789219f9b716779e6cb7abfe2de4dd863efca642587dce2','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e56e8acb2a7da9578a136c3994fd9aff654bdecb46329dad31822c7742265bc9',2008,'OM','Oman','military-and-security',1306,'Military branches:
Sultan''s Armed Forces (SAF): Royal Army of Oman, Royal Navy of Oman,
Royal Air Force of Oman (2008)
Military service age and obligation:
18-30 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 802,455
females age 16-49: 626,841 (2008 est.)
Manpower fit for military service:
males age 16-49: 663,881
females age 16-49: 543,410 (2008 est.)
Manpower reaching militarily significant age annually:
male: 34,238
female: 33,139 (2008 est.)
Military expenditures:
11.4% of GDP (2005 est.)','427337438b46e38c3ea0ab319dba367b7d19adfa7c4de7162875468f2f7753c7','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('623576d61bca19c5be3ec79d6d1357586712939a3997ca013ede38058e15bb69',2008,'PK','Pakistan','military-and-security',1315,'Military branches:
Army (includes National Guard), Navy (includes Marines and Maritime
Security Agency), Pakistan Air Force (Pakistan Fiza''ya) (2008)
Military service age and obligation:
16 years of age for voluntary military service; soldiers cannot be
deployed for combat until age of 18; the Pakistani Air Force and
Pakistani Navy have inducted their first female pilots and sailors
(2006)
Manpower available for military service:
males age 16-49: 42,633,765
females age 16-49: 40,114,017 (2008 est.)
Manpower fit for military service:
males age 16-49: 32,453,913
females age 16-49: 31,369,057 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,062,065
female: 1,936,916 (2008 est.)
Military expenditures:
3% of GDP (2007 est.)','8169abefb633b2644f3411f0c875b587feafa114298ce0f58f01e33cca9ea866','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cae7344203032a38a6bc2505de5e27aae0932b0f21d1e32b8d9ec67f18d60c0f',2008,'PW','Palau','military-and-security',1324,'Military branches:
no regular military forces; Palau National Police (2008)
Manpower available for military service:
males age 16-49: 5,973 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,397 (2008 est.)
Manpower reaching militarily significant age annually:
male: 179
female: 165 (2008 est.)
Military expenditures:
NA
Military - note:
defense is the responsibility of the US; under a Compact of Free
Association between Palau and the US, the US military is granted
access to the islands for 50 years, but it has not stationed any
military forces there (2008)','9b4ee7bdf83982a6727994603f5cd10a018ddc41bb36a9aff92b68ee5248e28c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19eb9e46d1ed108ec6bfb1a65d38e9614701757e21aa08e8a5a28f7235b79e2b',2008,'PA','Panama','military-and-security',1333,'Military branches:
no regular military forces; Panamanian Public Forces or PPF includes
the Panamanian National Police (PNP), National Maritime Service
(NMS), and National Air Service (NAS) (2008)
Manpower available for military service:
males age 16-49: 851,044 (2008 est.)
Manpower fit for military service:
males age 16-49: 673,103 (2008 est.)
Manpower reaching militarily significant age annually:
male: 31,042
female: 29,969 (2008 est.)
Military expenditures:
1% of GDP (2006)
Military - note:
on 10 February 1990, the government of then President ENDARA
abolished Panama''s military and reformed the security apparatus by
creating the Panamanian Public Forces; in October 1994, Panama''s
Legislative Assembly approved a constitutional amendment prohibiting
the creation of a standing military force but allowing the temporary
establishment of special police units to counter acts of "external
aggression"','3ff71a0409edad44ea7efecf165553ed0c25272cf18f7611a67fb577081cbb57','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62f9401706df312e4be405747f5f74dd3f834b91bdc628321f305e73d0253db2',2008,'PG','Papua New Guinea','military-and-security',1342,'Military branches:
Papua New Guinea Defense Force (PNGDF; includes Maritime Operations
Element, Air Operations Element) (2008)
Military service age and obligation:
16 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 1,481,417
females age 16-49: 1,385,040 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,080,466
females age 16-49: 1,092,040 (2008 est.)
Manpower reaching militarily significant age annually:
male: 62,865
female: 61,102 (2008 est.)
Military expenditures:
1.4% of GDP (2005 est.)
Paracel Islands
Military - note:
occupied by China','53bb69a5a3bf456a5837bcb770131f72505122b02fefd1758f6ced246f4dcfbd','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21faa8672d0727f1c38f082ae644c9aed13c27fe31ca9ab341330d87df7208a9',2008,'PY','Paraguay','military-and-security',1351,'Military branches:
Army, National Navy (Armada Nacional, includes Naval Aviation,
Marine Corps, General Naval Prefecture), Air Force (Fuerza Aerea
Paraguay, FAP) (2008)
Military service age and obligation:
18 years of age for compulsory and voluntary military service;
conscript service obligation - 12 months for Army, 24 months for
Navy (2006)
Manpower available for military service:
males age 16-49: 1,589,873
females age 16-49: 1,585,573 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,327,730
females age 16-49: 1,356,989 (2008 est.)
Manpower reaching militarily significant age annually:
male: 72,109
female: 70,509 (2008 est.)
Military expenditures:
1% of GDP (2006 est.)','b9ba489a14c63a8f873d0f2af3f0ab61db1226ed8c293201adacb044f3851667','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('848a7d13105e5ebfca5ecca4244f31d9e5877507f3c98ca754050f49371b8e86',2008,'PE','Peru','military-and-security',1360,'Military branches:
Army of Peru (Ejercito Peruano), Navy of Peru (Marina de Guerra del
Peru, MGP (includes naval air, naval infantry, and Coast Guard)),
Air Force of Peru (Fuerza Aerea del Peru, FAP) (2008)
Military service age and obligation:
18-30 years of age for voluntary male and female military service;
no conscription (2008)
Manpower available for military service:
males age 16-49: 7,653,898
females age 16-49: 7,531,329 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,796,449
females age 16-49: 6,217,524 (2008 est.)
Manpower reaching militarily significant age annually:
male: 306,260
female: 296,819 (2008 est.)
Military expenditures:
1.5% of GDP (2006)','469c4607cb7a9f2a810b8fdb3e8202670516e8d896c54d5636fc10074df75371','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('119922006e7e13fcff280396de97cb6b7e70163651d7d2f3ee508248153f6993',2008,'PH','Philippines','military-and-security',1369,'Military branches:
Armed Forces of the Philippines (AFP): Army, Navy (includes Marine
Corps), Air Force (2008)
Military service age and obligation:
18-25 years of age (officers 21-29) for compulsory and voluntary
military service; applicants must be single male or female
Philippine citizens (2007)
Manpower available for military service:
males age 16-49: 23,547,252
females age 16-49: 23,177,487 (2008 est.)
Manpower fit for military service:
males age 16-49: 18,232,050
females age 16-49: 19,827,538 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,012,779
female: 977,030 (2008 est.)
Military expenditures:
0.9% of GDP (2005 est.)
Pitcairn Islands
Military - note:
defense is the responsibility of the UK','e63f1bfd77e1a290c4744b95cf1ed9a6fb9fceafc1963523717e94f56f707a18','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59b0b81738b759886e3976011b4d5c7e8a6021b77d6d21da49624195a6f526d2',2008,'PL','Poland','military-and-security',1378,'Military branches:
Polish Armed Forces: Land Forces (includes Navy (Marynarka Wojenna,
MW)), Polish Air Force (Sily Powietrzne Rzeczypospolitej Polskiej,
SPRP) (2008)
Military service age and obligation:
17 years of age for male compulsory military service after January
1st of the year of 18th birthday; 17 years of age for voluntary
military service; conscript service obligation shortened from 12 to
9 months in 2005; by 2008, plans call for at least 60% of military
personnel to be volunteers; only soldiers who have completed their
conscript service are allowed to volunteer for professional service;
as of April 2004, women are only allowed to serve as officers and
noncommissioned officers (2006)
Manpower available for military service:
males age 16-49: 9,741,508
females age 16-49: 9,514,843 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,937,840
females age 16-49: 7,949,677 (2008 est.)
Manpower reaching militarily significant age annually:
male: 257,605
female: 245,832 (2008 est.)
Military expenditures:
1.71% of GDP (2005 est.)','4e96a74e08ad02d9b087912f8306d4f17be6f6ae147036207fc3e55a3fcaecb0','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f12c95c15e95d5a2351aca7dc67f51ca8d530ffa5bdd73cec880f54d1671af0',2008,'PT','Portugal','military-and-security',1387,'Military branches:
Portuguese Army (Exercito Portugues), Portuguese Navy (Marinha
Portuguesa; includes Marine Corps), Portuguese Air Force (Forca
Aerea Portuguesa, FAP) (2008)
Military service age and obligation:
18 years of age for voluntary military service; compulsory military
service ended in 2004; women serve in the armed forces, on naval
ships since 1993, but are prohibited from serving in some combatant
specialties; reserve obligation to age 35 (2007)
Manpower available for military service:
males age 16-49: 2,573,913
females age 16-49: 2,498,262 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,099,647
females age 16-49: 2,060,559 (2008 est.)
Manpower reaching militarily significant age annually:
male: 64,910
female: 58,599 (2008 est.)
Military expenditures:
2.3% of GDP (2005 est.)','c2dc93180eef2c99b7cddad4976970a6d5587b9622fbf4aa6bdfe5383085f9e6','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee7618d92bb159eb50ddfcfaae11ebd88a97dd051b42548dc7a8fe3f84b7364f',2008,'PR','Puerto Rico','military-and-security',1396,'Military branches:
no regular indigenous military forces; paramilitary National Guard,
Police Force
Manpower reaching militarily significant age annually:
male: 30,760
female: 29,469 (2008 est.)
Military - note:
defense is the responsibility of the US','93a366becdf0c6f5507c9dfa830a7313548d387aa43d28e669b58487985bdbd4','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cd1dd303c1d24c80d05bd18e46dbcd9545d83a76526f7928f4e1aefd317f504',2008,'QA','Qatar','military-and-security',1405,'Military branches:
Qatari Amiri Land Force (QALF), Qatari Amiri Navy (QAN), Qatari
Amiri Air Force (QAAF) (2007)
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 320,383
females age 16-49: 167,475 (2008 est.)
Manpower fit for military service:
males age 16-49: 258,159
females age 16-49: 143,999 (2008 est.)
Manpower reaching militarily significant age annually:
male: 6,224
female: 4,845 (2008 est.)
Military expenditures:
10% of GDP (2005 est.)','e8a29bca4fb4d3b713d2df207f0307f3f03d944c47533c2318831d0679d5b86e','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('209341ef6966dc8f6be54962d8c091a3f1222b37f991a8c73a55502d33494c36',2008,'RO','Romania','military-and-security',1416,'Military branches:
Land Forces, Naval Forces, Romanian Air Force (Fortele Aeriene
Romane, FAR), Special Operations (2008)
Military service age and obligation:
18 years of age for voluntary military service; conscription
officially ended October 2006; all military inductees (including
women) contract for an initial 5-year term of service; subsequent
voluntary service contracts are for successive 3-year terms until
the age of 36 (2006)
Manpower available for military service:
males age 16-49: 5,682,299
females age 16-49: 5,557,098 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,572,017
females age 16-49: 4,644,474 (2008 est.)
Manpower reaching militarily significant age annually:
male: 127,706
female: 121,852 (2008 est.)
Military expenditures:
1.9% of GDP (2007 est.)
Russia
Military branches:
Ground Forces (SV), Navy (VMF), Air Forces (Voyenno-Vozdushniye
Sily, VVS); Airborne Troops (VDV), Strategic Rocket Troops
(Raketnyye Voyska Strategicheskogo Naznacheniya, RVSN), and Space
Troops (KV) are independent "combat arms," not subordinate to any of
the three branches; Russian Ground Forces include the following
combat arms: motorized-rifle troops, tank troops, missile and
artillery troops, air defense of ground troops (2008)
Military service age and obligation:
18-27 years of age for compulsory or voluntary military service;
males are registered for the draft at 17 years of age; service
obligation - 1 year; reserve obligation to age 50; as of July 2008,
a draft military strategy called for the draft to continue up to the
year 2030 (2008)
Manpower available for military service:
males age 16-49: 36,219,908
females age 16-49: 37,019,853 (2008 est.)
Manpower fit for military service:
males age 16-49: 21,488,878
females age 16-49: 28,760,976 (2008 est.)
Manpower reaching militarily significant age annually:
male: 821,103
female: 781,570 (2008 est.)
Military expenditures:
3.9% of GDP (2005)','578f68f7e6785f7d6e197e24dc35fe566ee42b47c1339adc34e3a99113573674','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c1e4a4bf2c6810e5154792c7445d6d09ceaf1dc206282bd15d6745c632635f7',2008,'RW','Rwanda','military-and-security',1425,'Military branches:
Rwandan Defense Forces: Army, Air Force
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 2,430,469
females age 16-49: 2,392,933 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,404,066
females age 16-49: 1,403,700 (2008 est.)
Manpower reaching militarily significant age annually:
male: 111,791
female: 112,131 (2008 est.)
Military expenditures:
2.9% of GDP (2006 est.)
Saint Barthelemy
Manpower reaching militarily significant age annually:
male: 21
female: 20 (2008 est.)
Military - note:
defense is the responsibility of France
This page was last updated on 18 December, 2008
======================================================================
@Saint Helena
Saint Helena
Manpower reaching militarily significant age annually:
male: 47
female: 43 (2008 est.)
Military - note:
defense is the responsibility of the UK','dc7629eb393d08f4b8a8ac453438102e85f4c73c552bd08c1ed999a43e0c3147','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a52bcd23b765940700b7e89e696364a8380a4ee067946651f8ddedfc9b1c295',2008,'KN','Saint Kitts and Nevis','military-and-security',1434,'Military branches:
Saint Kitts and Nevis Defense Force (includes Coast Guard), Royal
Saint Kitts and Nevis Police Force
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 10,095
females age 16-49: 10,081 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,064
females age 16-49: 8,464 (2008 est.)
Manpower reaching militarily significant age annually:
male: 367
female: 352 (2008 est.)
Military expenditures:
NA','285ec060f821c9b6a8a29b84a4ceba3695856180f590b65c5f068ac2b62daae1','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c01ffb882d05a5af8c0d6af67172053456ec6c5b0257e6f46d6c06bfda37765e',2008,'LC','Saint Lucia','military-and-security',1443,'Military branches:
no regular military forces; Royal Saint Lucia Police Force (includes
Special Service Unit, Coast Guard) (2007)
Manpower available for military service:
males age 16-49: 48,358 (2008 est.)
Manpower fit for military service:
males age 16-49: 38,660 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,591
female: 1,504 (2008 est.)
Military expenditures:
NA
Saint Martin
Manpower reaching militarily significant age annually:
male: 186
female: 162 (2008 est.)
Military - note:
defense is the responsibility of France
This page was last updated on 18 December, 2008
======================================================================
@Saint Pierre and Miquelon','639997460545d78796301d255fe88b214a8d7e23b65a9d818459267b9fda9249','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('093b45d0262473b0fc38d53f7f07819f5a301fa5ccb6a2cd6bd2978fb6f84766',2008,'PM','Saint Pierre and Miquelon','military-and-security',1453,'Manpower reaching militarily significant age annually:
male: 61
female: 58 (2008 est.)
Military - note:
defense is the responsibility of France','6c31f12695272529c2c6617c58ae76e9838dfb16caadc04e7c656ad7514b6d29','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e680355fe6e9f563e16c67e95b6467cbe07f3037f2fc10a1e0dce5586c26ec35',2008,'VC','Saint Vincent and the Grenadines','military-and-security',1462,'Military branches:
no regular military forces; Royal Saint Vincent and the Grenadines
Police Force, Coast Guard (2007)
Manpower available for military service:
males age 16-49: 34,373 (2008 est.)
Manpower fit for military service:
males age 16-49: 28,518 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,224
female: 1,169 (2008 est.)
Military expenditures:
NA','01bb0e76ddc2fe7ab08dad62f28db33cc757365d6adf76e645daa9d22f2cec54','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d29654034cd92494315b5ced48de100d36adac58864f5b8275577e4ba780a33',2008,'WS','Samoa','military-and-security',1471,'Military branches:
no regular military forces; Samoa Police Force (2008)
Manpower available for military service:
males age 16-49: 53,417 (2008 est.)
Manpower fit for military service:
males age 16-49: 42,359 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,571
female: 2,454 (2008 est.)
Military expenditures:
NA
Military - note:
Samoa has no formal defense structure or regular armed forces;
informal defense ties exist with NZ, which is required to consider
any Samoan request for assistance under the 1962 Treaty of Friendship','9bedd4620f4e6b7871baa5619caeb9f5ce81b21a1f2fed2753f6426c17f96be2','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('115e6464714b3fdcd0d45a70fb6e36c9b5e289676e50c5b84dc239490ef01d20',2008,'SM','San Marino','military-and-security',1479,'Military branches:
no regular military forces; Voluntary Military Force (Corpi Militari
Voluntar) performs ceremonial duties and limited police support
functions (2008)
Military service age and obligation:
16-55 for voluntary service in Voluntary Military Force (2006)
Manpower available for military service:
males age 16-49: 6,613 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,345 (2008 est.)
Manpower reaching militarily significant age annually:
male: 156
female: 154 (2008 est.)
Military expenditures:
NA
Military - note:
defense is the responsibility of Italy','606ae10805187419218e892fb35ee17c1200f956b2b094cd68f98ad755c7d6e3','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b33ec84a7279284e2a059b82afae4ee74a9022b168494cdf4d921ef54a97dd6',2008,'ST','Sao Tome and Principe','military-and-security',1488,'Military branches:
Armed Forces of Sao Tome and Principe (FASTP): Army, Coast Guard of
Sao Tome e Principe (Guarda Costeira de Sao Tome e Principe, GCSTP),
Presidential Guard (2007)
Military service age and obligation:
18 years of age (est.) (2004)
Manpower available for military service:
males age 16-49: 42,340
females age 16-49: 43,781 (2008 est.)
Manpower fit for military service:
males age 16-49: 33,735
females age 16-49: 36,779 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,437
female: 2,394 (2008 est.)
Military expenditures:
0.8% of GDP (2006)
Military - note:
Sao Tome and Principe''s army is a tiny force with almost no
resources at its disposal and would be wholly ineffective operating
unilaterally; infantry equipment is considered simple to operate and
maintain but may require refurbishment or replacement after 25 years
in tropical climates; poor pay, working conditions, and alleged
nepotism in the promotion of officers have been problems in the
past, as reflected in the 1995 and 2003 coups; these issues are
being addressed with foreign assistance aimed at improving the army
and its focus on realistic security concerns; command is exercised
from the president, through the Minister of Defense, to the Chief of
the Armed Forces staff (2005)','e20e27fc345972c232d61c025ae43f7f53880feb9952ece8448a441885af384c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('920ed69e1f27dfefb284c949e5c4727f2ccf0ffdfa838aa90b1464e720c652dd',2008,'SA','Saudi Arabia','military-and-security',1497,'Military branches:
Land Forces (Army), Navy, Air Force, Air Defense Force, National
Guard, Ministry of Interior Forces (paramilitary)
Military service age and obligation:
18 years of age (est.); no conscription (2004)
Manpower available for military service:
males age 16-49: 8,547,441
females age 16-49: 6,381,098 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,398,417
females age 16-49: 5,525,357 (2008 est.)
Manpower reaching militarily significant age annually:
male: 271,905
female: 261,795 (2008 est.)
Military expenditures:
10% of GDP (2005 est.)','13410b13bd366d46379cecb875e8c028c22e20a54950171b70c9c745aa545873','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('269d65f08a046a563c525dc2a5cd5a15854c0ead3fa27ee9830f914700552c44',2008,'SN','Senegal','military-and-security',1506,'Military branches:
Army, Senegalese Navy (Marine Senegalaise), Senegalese Air Force
(Armee de l''Air du Senegal) (2008)
Military service age and obligation:
18 years of age for compulsory and voluntary military service;
conscript service obligation - 2 years (2004)
Manpower available for military service:
males age 16-49: 2,943,619
females age 16-49: 2,955,179 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,866,602
females age 16-49: 1,947,076 (2008 est.)
Manpower reaching militarily significant age annually:
male: 141,832
female: 139,541 (2008 est.)
Military expenditures:
1.4% of GDP (2005 est.)','ea2a299848c63c46ebfdcc08c8a097c041e4570335717965f75fbff0e0834725','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('959c74e3ea95d11382ed9022118a365e14f2c521a471c9302ebebf11ba4aba11',2008,'RS','Serbia','military-and-security',1515,'Military branches:
Serbian Armed Forces (Vojska Srbije, VS): Land Forces Command
(includes Riverine Component, consisting of a river flotilla on the
Danube), Joint Operations Command, Air and Air Defense Forces
Command (2008)
Military service age and obligation:
19-35 years of age for compulsory military service; under a state of
war or impending war, conscription can begin at age 16; conscription
is to be abolished in 2010; 9-month service obligation, with a
reserve obligation to age 60 for men and 50 for women (2007)
Manpower reaching militarily significant age annually:
male: 66,263
female: 62,165 (2008 est.)','c9bcd076df53edbeedb3d8d990e8e2161bbb8ca5028b2a8ad09353933eedac55','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92d580404bffa740aa59c69c9e84fbdd8a9899431be2b362e66312c24749ff9a',2008,'SC','Seychelles','military-and-security',1524,'Military branches:
Seychelles Defense Force: Army, Coast Guard (includes Naval Wing,
Air Wing), National Guard (2005)
Military service age and obligation:
18 years of age for voluntary military service (younger with
parental consent); no conscription (2008)
Manpower available for military service:
males age 16-49: 23,598
females age 16-49: 24,424 (2008 est.)
Manpower fit for military service:
males age 16-49: 17,942
females age 16-49: 20,436 (2008 est.)
Manpower reaching militarily significant age annually:
male: 770
female: 750 (2008 est.)
Military expenditures:
2% of GDP (2006 est.)','21140975c88d041323f8db76b220fad585559c4637d2c0d4a9fd1227ebba0429','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfd2b8c757fad4407acf894eaa9c8d2191505e3f89c8c9558b461317c2ee5280',2008,'SL','Sierra Leone','military-and-security',1533,'Military branches:
Republic of Sierra Leone Armed Forces (RSLAF): Army (includes Navy
(Maritime Wing), Air Wing) (2008)
Military service age and obligation:
17 years 6 months of age for voluntary military service (younger
with parental consent); no conscription (2008)
Manpower available for military service:
males age 16-49: 1,315,561 (2008 est.)
Manpower fit for military service:
males age 16-49: 671,418 (2008 est.)
Manpower reaching militarily significant age annually:
male: 70,068
female: 73,930 (2008 est.)
Military expenditures:
2.3% of GDP (2006)','8d8868af28e633bece3fcfffbea171cc86ec68e3fb5080064d7f5ad4accef202','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df16c3424617377c37fd952a28acb927b8fef25029567dff67b0581931210ce3',2008,'SG','Singapore','military-and-security',1542,'Military branches:
Singapore Armed Forces: Army, Navy, Air Force (includes Air Defense)
(2008)
Military service age and obligation:
18-21 years of age for male compulsory military service; 16 years of
age for volunteers; 2-year conscript service obligation, with a
reserve obligation to age 40 (enlisted) or age 50 (officers) (2008)
Manpower available for military service:
males age 16-49: 1,277,862 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,038,603 (2008 est.)
Manpower reaching militarily significant age annually:
male: 27,742
female: 26,325 (2008 est.)
Military expenditures:
4.9% of GDP (2005 est.)','4ffee752ee52befd8808d28bd06459e10068e1bb99c4d95855b9c0d62379d0b9','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f539df3bcd9d52ccb240f8cd3f6fc8771197f094f1c2ea626cdec77217192418',2008,'SK','Slovakia','military-and-security',1551,'Military branches:
Armed Forces of the Slovak Republic (Ozbrojene Sily Slovenskej
Republiky): Land Forces (Pozemne Sily), Air Forces (Vzdusne Sily)
(2008)
Military service age and obligation:
17-30 years of age for voluntary military service; conscription
abolished in 2006; women are eligible to serve (2007)
Manpower available for military service:
males age 16-49: 1,420,966
females age 16-49: 1,386,259 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,166,833
females age 16-49: 1,156,874 (2008 est.)
Manpower reaching militarily significant age annually:
male: 38,183
female: 36,388 (2008 est.)
Military expenditures:
1.87% of GDP (2005 est.)','fec7e76f512c82273338f14cddcf190f6c61a43dcf476dbc59d6886ebd77e873','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('973c54363cd6534cb13cff579350001e6dfe82e09e9748cee25671c9eefa622c',2008,'SI','Slovenia','military-and-security',1560,'Military branches:
Slovenian Army (includes air and naval forces)
Military service age and obligation:
17 years of age for voluntary military service; conscription
abolished in 2003 (2007)
Manpower available for military service:
males age 16-49: 494,496
females age 16-49: 481,180 (2008 est.)
Manpower fit for military service:
males age 16-49: 406,951
females age 16-49: 395,444 (2008 est.)
Manpower reaching militarily significant age annually:
male: 10,516
female: 9,934 (2008 est.)
Military expenditures:
1.7% of GDP (2005 est.)','24647936e6f494561da61f4982d50cf74a56f6fa73995fb45348beee9c5461cb','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad250d4b387962ea7ff8b027f2863f1e5c6c1be80a72c1556c140aee194b98a4',2008,'SB','Solomon Islands','military-and-security',1569,'Military branches:
no regular military forces; Solomon Islands Police Force (2008)
Manpower available for military service:
males age 16-49: 141,051 (2008 est.)
Manpower fit for military service:
males age 16-49: 116,891 (2008 est.)
Manpower reaching militarily significant age annually:
male: 6,924
female: 6,679 (2008 est.)
Military expenditures:
3% of GDP (2006)','baed6ec811e7ef08800f247d07b1e04aa4097b7904838a0f28af7610788f0747','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f217002ff585bfebe177c5add39d7ebf399c793290ae82d53590bb6278b30735',2008,'SO','Somalia','military-and-security',1578,'Military branches:
no national-level armed forces (2008)
Manpower available for military service:
males age 16-49: 2,181,050
females age 16-49: 2,125,558 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,274,783
females age 16-49: 1,317,991 (2008 est.)
Manpower reaching militarily significant age annually:
male: 95,446
female: 95,339 (2008 est.)
Military expenditures:
0.9% of GDP (2005 est.)','65732a78e333634b82b27ba75bc79d55fb5f56b088beffe0982012a774209a92','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5491d256e2e34c772465e5624c5f4a02063e686650ea1d36e7de9f964a626db',2008,'ZA','South Africa','military-and-security',1586,'Military branches:
South African National Defense Force (SANDF): South African Army,
South African Navy (SAN), South African Air Force (SAAF), Joint
Operations Command, Military Intelligence, Military Health Services
(2008)
Military service age and obligation:
18 years of age for voluntary military service; women have a long
history of military service in noncombat roles dating back to World
War I (2004)
Manpower available for military service:
males age 16-49: 11,622,507
females age 16-49: 11,501,537 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,042,498
females age 16-49: 5,471,103 (2008 est.)
Manpower reaching militarily significant age annually:
male: 529,201
female: 522,678 (2008 est.)
Military expenditures:
1.7% of GDP (2006)
Military - note:
with the end of apartheid and the establishment of majority rule,
former military, black homelands forces, and ex-opposition forces
were integrated into the South African National Defense Force
(SANDF); as of 2003 the integration process was considered complete','d55a4776f2a1ef983668314bccd59f874c985a6a48c9f1823796d83460728282','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c96c0679f23f49952f362dea8e09f696885623a9a5c7487f6eacc9e685df0ab',2008,'ES','Spain','military-and-security',1600,'Military branches:
Spanish Armed Forces: Army (Ejercito de Tierra), Spanish Navy
(Armada Espanola, AE; includes Marine Corps), Spanish Air Force
(Ejercito del Aire Espanola, EdA) (2007)
Military service age and obligation:
20 years of age (2004)
Manpower available for military service:
males age 16-49: 10,033,069
females age 16-49: 9,764,937 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,228,426
females age 16-49: 7,990,678 (2008 est.)
Manpower reaching militarily significant age annually:
male: 203,650
female: 191,352 (2008 est.)
Military expenditures:
1.2% of GDP (2005 est.)
Spratly Islands
Military - note:
Spratly Islands consist of more than 100 small islands or reefs of
which about 45 are claimed and occupied by China, Malaysia, the
Philippines, Taiwan, and Vietnam','570683788dbb01c08e0e1b5fde7ddf7b62b3d1f18415ad12e9b157c40a916f6c','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fb51398b5ef400f382bd106908dc9a8468e266e5e67324bc4987be602e864aa',2008,'LK','Sri Lanka','military-and-security',1609,'Military branches:
Sri Lanka Army, Sri Lanka Navy, Sri Lanka Air Force (2008)
Military service age and obligation:
18 years of age for voluntary military service (2007)
Manpower available for military service:
males age 16-49: 5,458,720
females age 16-49: 5,594,006 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,477,437
females age 16-49: 4,683,716 (2008 est.)
Manpower reaching militarily significant age annually:
male: 174,065
female: 168,593 (2008 est.)
Military expenditures:
2.6% of GDP (2006)','db4f97254d5696450c87aaa1b9d6d16f9e0ccf725b44f69c78233505b62b414b','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f1de7d834a3c693e010e248562c972fbd156f069e7bd329d51bd5a0e5b80337',2008,'SD','Sudan','military-and-security',1618,'Military branches:
Sudanese Armed Forces (SAF): Land Forces, Navy, Air Force, Popular
Defense Forces; Sudan People''s Liberation Army (SPLA): Land Forces
(2008)
Military service age and obligation:
18-30 years of age for compulsory military service; 2-year service
obligation (2006)
Manpower available for military service:
males age 16-49: 9,639,923
females age 16-49: 9,321,106 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,586,468
females age 16-49: 5,678,427 (2008 est.)
Manpower reaching militarily significant age annually:
male: 488,679
female: 469,547 (2008 est.)
Military expenditures:
3% of GDP (2005 est.)','2da1bcea7292146c7ef3eff84e71e9c822910e3f0f8bb48584f9b7faf49ca562','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55cc6d148edd3953d274e87828e23a3aeaf7debda0cabaefe2ae08acaf1acc1d',2008,'SR','Suriname','military-and-security',1627,'Military branches:
National Army (Nationaal Leger, NL; includes Naval Wing, Air Wing)
(2007)
Military service age and obligation:
18 years of age (est.); recruitment is voluntary, with personnel
drawn almost exclusively from the Creole community (2007)
Manpower available for military service:
males age 16-49: 130,534
females age 16-49: 130,243 (2008 est.)
Manpower fit for military service:
males age 16-49: 105,770
females age 16-49: 109,666 (2008 est.)
Manpower reaching militarily significant age annually:
male: 4,329
female: 4,350 (2008 est.)
Military expenditures:
0.6% of GDP (2006 est.)
Svalbard
Military branches:
no regular military forces
Military - note:
Svalbard is a territory of Norway, demilitarized by treaty on 9
February 1920
Swaziland
Military branches:
Umbutfo Swaziland Defense Force (USDF): Ground Force (includes air
wing) (2008)
Military service age and obligation:
18-30 years of age for male and female voluntary military service;
no conscription (2008)
Manpower available for military service:
males age 16-49: 266,311 (2008 est.)
Manpower fit for military service:
males age 16-49: 122,260 (2008 est.)
Manpower reaching militarily significant age annually:
male: 15,951
female: 15,728 (2008 est.)
Military expenditures:
4.7% of GDP (2006)','0249e4ba1d7e610be6b841db3a10974593b3c244c038b03392565640e1673332','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('127a1938ad6d0d017382f684140bad43ff0b07ce46f4d835f209ac893eafb272',2008,'SE','Sweden','military-and-security',1636,'Military branches:
Swedish Armed Forces (Forsvarsmakten): Army (Armen), Royal Swedish
Navy (Marinen), Swedish Air Force (Svenska Flygvapnet) (2008)
Military service age and obligation:
19 years of age for compulsory military service; conscript service
obligation: 7-15 months (Navy), 8-12 months (Air Force); after
completing initial service, soldiers have a reserve commitment until
age 47 (2006)
Manpower available for military service:
males age 16-49: 2,052,890
females age 16-49: 1,980,550 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,699,115
females age 16-49: 1,637,868 (2008 est.)
Manpower reaching militarily significant age annually:
male: 64,605
female: 61,110 (2008 est.)
Military expenditures:
1.5% of GDP (2005 est.)','bc8c3927fde760608cf5c085eda3e41f335685ace3b74c501c34458db9cba83d','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b2133ea1ff307b1156076ae760eaff523de4fdc29ab90b40f0bc1893d55c95b',2008,'CH','Switzerland','military-and-security',1646,'Military branches:
Swiss Armed Forces: Land Forces, Swiss Air Force (Schweizer
Luftwaffe) (2007)
Military service age and obligation:
19 years of age for male compulsory military service; 18 years of
age for voluntary male and female military service; the Swiss
Constitution states that "every Swiss male is obliged to do military
service"; every Swiss male has to serve at least 260 days in the
armed forces; conscripts receive 18 weeks of mandatory training,
followed by seven 3-week intermittent recalls for training during
the next 10 years (2008)
Manpower available for military service:
males age 16-49: 1,852,580
females age 16-49: 1,807,667 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,513,984
females age 16-49: 1,478,761 (2008 est.)
Manpower reaching militarily significant age annually:
male: 49,205
female: 45,220 (2008 est.)
Military expenditures:
1% of GDP (2005 est.)
Syria
Military branches:
Syrian Armed Forces: Syrian Arab Army, Syrian Arab Navy, Syrian Arab
Air and Air Defense Forces (includes Air Defense Command) (2008)
Military service age and obligation:
18 years of age for compulsory military service; conscript service
obligation - 30 months (18 months in the Syrian Arab Navy); women
are not conscripted but may volunteer to serve (2004)
Manpower available for military service:
males age 16-49: 5,251,875
females age 16-49: 4,966,367 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,242,401
females age 16-49: 4,218,648 (2008 est.)
Manpower reaching militarily significant age annually:
male: 215,734
female: 203,106 (2008 est.)
Military expenditures:
5.9% of GDP (2005 est.)
Taiwan
Military branches:
Army, Navy (includes Marine Corps), Air Force, Coast Guard
Administration, Armed Forces Reserve Command, Combined Service
Forces Command, Armed Forces Police Command
Military service age and obligation:
19-35 years of age for male compulsory military service; service
obligation 14 months (reducing to 1 year in 2009) year; women may
enlist; women in Air Force service are restricted to noncombat
roles; reserve obligation to age 30 (Army); the Ministry of Defense
has announced plans to implement an incremental voluntary enlistment
system beginning 2010, with 10% fewer conscripts each year
thereafter, although nonvolunteers will still be required to perform
alternative service or go through 3-4 months of military training
(2008)
Manpower available for military service:
males age 16-49: 6,283,134
females age 16-49: 6,098,599 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,112,737
females age 16-49: 5,036,346 (2008 est.)
Manpower reaching militarily significant age annually:
male: 164,883
female: 152,085 (2008 est.)
Military expenditures:
2.2% of GDP (2006)','9cc401ac8265c8fc8fcbee153ef35be92c89e09f69c37641014949d6ae2ad6cc','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('615fcc788cc4001f2e971bce7b52d51c488d9bf5450817f94c97cc6e92a74d44',2008,'TJ','Tajikistan','military-and-security',1655,'Military branches:
Ground Forces, Air and Air Defense Forces, Mobile Force (2008)
Military service age and obligation:
18 years of age for compulsory military service; 2-year conscript
service obligation (2007)
Manpower available for military service:
males age 16-49: 1,897,356
females age 16-49: 1,911,594 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,391,287
females age 16-49: 1,561,826 (2008 est.)
Manpower reaching militarily significant age annually:
male: 84,137
female: 81,777 (2008 est.)
Military expenditures:
3.9% of GDP (2005 est.)','53d070a081cd0777238e37b5d5c82b23cf7817ad54c85283d53b29d44d47f587','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7b1cafc0d7fc7a856ce97a045a4e2e0c89719be25b76c36a70af00e34895c34',2008,'TL','Timor-Leste','military-and-security',1666,'Military branches:
Timor-Leste Defense Force (Forcas de Defesa de Timor-L''este,
Falintil (FDTL)): Army, Navy (Armada) (2008)
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 284,903
females age 16-49: 272,212 (2008 est.)
Manpower fit for military service:
males age 16-49: 224,096
females age 16-49: 231,901 (2008 est.)
Manpower reaching militarily significant age annually:
male: 13,045
female: 12,670 (2008 est.)
Military expenditures:
NA','a7dbcc8ae42f45c08a4b4a724b188b0012f83cdeea032ca6b6970405c09696f0','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0abab534c9159e351305e59c6750b29b6ff429665fa2c16bc6927256716972bd',2008,'TG','Togo','military-and-security',1674,'Military branches:
Togolese Armed Forces: Ground Forces, Togolese Navy (Marine du
Togo), Togolese Air Force (Force Aerienne Togolaise, FAT), National
Gendarmerie (2008)
Military service age and obligation:
18 years of age for selective compulsory and voluntary military
service; 2-year service obligation (2006)
Manpower available for military service:
males age 16-49: 1,365,505
females age 16-49: 1,374,993 (2008 est.)
Manpower fit for military service:
males age 16-49: 897,195
females age 16-49: 913,327 (2008 est.)
Manpower reaching militarily significant age annually:
male: 69,156
female: 69,200 (2008 est.)
Military expenditures:
1.6% of GDP (2005 est.)','06a285c282cb3a6d64174928102ed97ad009fc925f0b6f27e3492f9c1fd1cdc1','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b035aab1a28572898976879de579274c0a6c6a92a84f9505c0f84d2d1378deb',2008,'TO','Tonga','military-and-security',1690,'Military branches:
Tonga Defense Services (TDS): Land Force (Royal Guard), Naval Force
(includes Royal Marines, Air Wing) (2008)
Military service age and obligation:
18 years of age (est.); no conscription (2008)
Manpower available for military service:
males age 16-49: 32,053
females age 16-49: 30,981 (2008 est.)
Manpower fit for military service:
males age 16-49: 25,520
females age 16-49: 26,893 (2008 est.)
Manpower reaching militarily significant age annually:
male: 1,464
female: 1,412 (2008 est.)
Military expenditures:
0.9% of GDP (2006 est.)','cd36ff0842737b7a67ad24a0426ce72a38cf9f019c93efe90497f5d9658c0d81','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90de3c21531e96554f4c7aad0914f8c7ff4297ad7ac7f114f9d86be8ea3d96b4',2008,'TT','Trinidad and Tobago','military-and-security',1699,'Military branches:
Trinidad and Tobago Defense Force (TTDF): Trinidad and Tobago
Regiment, Coast Guard, Air Guard (2008)
Military service age and obligation:
18 years of age for voluntary military service (16 years of age with
parental consent); no conscription (2008)
Manpower available for military service:
males age 16-49: 301,561
females age 16-49: 264,225 (2008 est.)
Manpower fit for military service:
males age 16-49: 215,310
females age 16-49: 180,526 (2008 est.)
Manpower reaching militarily significant age annually:
male: 8,671
female: 8,153 (2008 est.)
Military expenditures:
0.3% of GDP (2006)','6ca8e7e6709da011c5e03b05e49408d927ea6109462a438ecda967e9d97cfe03','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('350c9f5f265d5de65115bb7db755648681f008479742c42f97d3102e98221539',2008,'TN','Tunisia','military-and-security',1707,'Military branches:
Army, Navy, Republic of Tunisia Air Force (Al-Quwwat al-Jawwiya
al-Jamahiriyah At''tunisia) (2008)
Military service age and obligation:
20 years of age for compulsory military service; conscript service
obligation - 12 months; 18 years of age for voluntary military
service (2007)
Manpower available for military service:
males age 16-49: 2,992,249
females age 16-49: 2,912,819 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,539,962
females age 16-49: 2,465,295 (2008 est.)
Manpower reaching militarily significant age annually:
male: 101,794
female: 95,198 (2008 est.)
Military expenditures:
1.4% of GDP (2006)
Turkey
Military branches:
Turkish Armed Forces (TSK): Turkish Land Forces (Turk Kara
Kuvvetleri, TKK), Turkish Naval Forces (Turk Deniz Kuvvetleri, TDK;
includes naval air and naval infantry), Turkish Air Force (Turk Hava
Kuvvetleri, THK) (2008)
Military service age and obligation:
20 years of age (2004)
Manpower available for military service:
males age 16-49: 20,213,205
females age 16-49: 19,432,688 (2008 est.)
Manpower fit for military service:
males age 16-49: 17,011,635
females age 16-49: 16,433,364 (2008 est.)
Manpower reaching militarily significant age annually:
male: 660,452
female: 638,527 (2008 est.)
Military expenditures:
5.3% of GDP (2005 est.)
Military - note:
a "National Security Policy Document" adopted in October 2005
increases the Turkish Armed Forces (TSK) role in internal security,
augmenting the General Directorate of Security and Gendarmerie
General Command (Jandarma); the TSK leadership continues to play a
key role in politics and considers itself guardian of Turkey''s
secular state; in April 2007, it warned the ruling party about any
pro-Islamic appointments; despite on-going negotiations on EU
accession since October 2005, progress has been limited in
establishing required civilian supremacy over the military; primary
domestic threats are listed as fundamentalism (with the definition
in some dispute with the civilian government), separatism (the
Kurdish problem), and the extreme left wing; Ankara strongly opposed
establishment of an autonomous Kurdish region; an overhaul of the
Turkish Land Forces Command (TLFC) taking place under the "Force
2014" program is to produce 20-30% smaller, more highly trained
forces characterized by greater mobility and firepower and capable
of joint and combined operations; the TLFC has taken on increasing
international peacekeeping responsibilities, and took charge of a
NATO International Security Assistance Force (ISAF) command in
Afghanistan in April 2007; the Turkish Navy is a regional naval
power that wants to develop the capability to project power beyond
Turkey''s coastal waters; the Navy is heavily involved in NATO,
multinational, and UN operations; its roles include control of
territorial waters and security for sea lines of communications; the
Turkish Air Force adopted an "Aerospace and Missile Defense Concept"
in 2002 and has initiated project work on an integrated missile
defense system; Air Force priorities include attaining a modern
deployable, survivable, and sustainable force structure, and
establishing a sustainable command and control system (2008)','bf74b273e07ad5a07beb8ca95d66bb49a7f0e432aa8fe63b268a785428f165d7','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a5a94bae2cea94e468db7b8960ef7a8bf1a54364454a7a10fae5e89310b4fda',2008,'TM','Turkmenistan','military-and-security',1716,'Military branches:
Ground Forces, Navy, Air and Air Defense Forces (2007)
Military service age and obligation:
18-30 years of age for compulsory military service; 2-year conscript
service obligation (2007)
Manpower available for military service:
males age 16-49: 1,316,698
females age 16-49: 1,331,005 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,064,965
females age 16-49: 1,136,553 (2008 est.)
Manpower reaching militarily significant age annually:
male: 57,615
female: 55,426 (2008 est.)
Military expenditures:
3.4% of GDP (2005 est.)','749ac348d05ab8ab084b12f2ca14d411b9c4f89a9cf7e3cb349153345839e01f','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5785eb2a9695139a3cec41702f71bb7c3a81dcf8f76b93a09e4ffa5ef5c5213d',2008,'TC','Turks and Caicos Islands','military-and-security',1725,'Manpower reaching militarily significant age annually:
male: 222
female: 214 (2008 est.)
Military - note:
defense is the responsibility of the UK','3c755d34bb7f4fdacd5ca2a68589139bd567ddedcd4e9f240e53357e38f0fd19','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e00ed7cda6ffffd6ca78990fd837b114f6dde11e35d38e2e6ed71f7248db2187',2008,'TV','Tuvalu','military-and-security',1734,'Military branches:
no regular military forces; Tuvalu Police Force (2008)
Manpower reaching militarily significant age annually:
male: 128
female: 125 (2008 est.)
Military expenditures:
NA','6f59e17b44cbbd244d318561a28d630c3bfab4dc8bbb7c3479e48e1652b0151e','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7723d3e410058b439dfbadcfa8d615ae3752b8d8de85c797c3de58c73893c29d',2008,'UG','Uganda','military-and-security',1743,'Military branches:
Uganda Peoples Defense Force (UPDF): Army (includes Marine Unit),
Air Force (2007)
Military service age and obligation:
18-26 years of age for compulsory and voluntary military duty; 18-30
years of age for professionals; 9-year service obligation; the
government has stated that recruitment below 18 years of age could
occur with proper consent and that "no person under the apparent age
of 13 years shall be enrolled in the armed forces"; Ugandan
citizenship and secondary education required (2008)
Manpower available for military service:
males age 16-49: 6,532,894
females age 16-49: 6,352,416 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,856,365
females age 16-49: 3,769,120 (2008 est.)
Manpower reaching militarily significant age annually:
male: 384,638
female: 381,990 (2008 est.)
Military expenditures:
2.2% of GDP (2006)','b3a851645cb2d3f14501fa55cfeadfafee82f8fa2531d31d4312782f5d44fbde','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73d09320ec37748a39399cf67c38029bf6f76cb14be5b225aa01f4a585485d7d',2008,'UA','Ukraine','military-and-security',1751,'Military branches:
Ground Forces, Naval Forces, Air Forces (Viyskovo-Povitryani Syly),
Air Defense Forces (2002)
Military service age and obligation:
18-25 years of age for compulsory and voluntary military service;
conscript service obligation - 18 months for Army and Air Force, 24
months for Navy (2004)
Manpower available for military service:
males age 16-49: 11,457,562
females age 16-49: 11,767,357 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,141,814
females age 16-49: 9,428,876 (2008 est.)
Manpower reaching militarily significant age annually:
male: 288,605
female: 276,324 (2008 est.)
Military expenditures:
1.4% of GDP (2005 est.)','dac1855cbaee7945b1a212b54ace68935b31ae0e6f09b0ee534a8fba93639d49','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcc4a38c95ef03302e0b7d5bf983132530288cd69f7410e2112feae28cca9b90',2008,'AE','United Arab Emirates','military-and-security',1760,'Military branches:
United Arab Emirates Armed Forces: Army, Navy (includes Marines),
Air Force and Air Defense, National Coast Guard (2008)
Military service age and obligation:
18 years of age (est.) for voluntary military service; 18 years of
age for officers and women; no conscription (2008)
Manpower available for military service:
males age 16-49: 2,405,884 (includes non-nationals)
females age 16-49: 884,853 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,004,558
females age 16-49: 760,637 (2008 est.)
Manpower reaching militarily significant age annually:
male: 25,856
female: 23,085 (2008 est.)
Military expenditures:
3.1% of GDP (2005 est.)','56de67df332e2bd1283623293986876011bd0878acfce17fd7b240215371b969','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19291b652cb7dfe1ef418f9c22ae2e7c8471d7f18a296e0e425ceab2ad85ed3b',2008,'GB','United Kingdom','military-and-security',1769,'Military branches:
Army, Royal Navy (includes Royal Marines), Royal Air Force
Military service age and obligation:
16-33 years of age (officers 17-28) for voluntary military service
(with parental consent under 18); women serve in military services,
but are excluded from ground combat positions and some naval
postings; must be citizen of the UK, Commonwealth, or Republic of
Ireland; reservists serve a minimum of 3 years, to age 45 or 55; 16
years of age for voluntary military service by Nepalese citizens in
the Brigade of the Gurkhas; 16-34 years of age for voluntary
military service by Papua New Guinean citizens (2008)
Manpower available for military service:
males age 16-49: 14,729,500
females age 16-49: 14,125,600 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,121,602
females age 16-49: 11,616,582 (2008 est.)
Manpower reaching militarily significant age annually:
male: 400,927
female: 383,593 (2008 est.)
Military expenditures:
2.4% of GDP (2005 est.)','af17f76228b4b6fbe61b18de1d9955044f05a12a0735d77e4d1ab367e27aa7a2','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdc5f62ff9ce95b87ac403be729505a407983bbd72f90af47c6f3a9eb19628f6',2008,'US','United States','military-and-security',1778,'Military branches:
US Army, US Navy (includes Marine Corps), US Air Force, US Coast
Guard; note - Coast Guard administered in peacetime by the
Department of Homeland Security, but in wartime reports to the
Department of the Navy (2008)
Military service age and obligation:
18 years of age (17 years of age with parental consent) for male and
female voluntary service; maximum enlistment age 42 (Army), 27 (Air
Force), 34 (Navy), 28 (Marines); service obligation 8 years,
including 2-5 years active duty (Army), 2 years active (Navy), 4
years active (Air Force, Marines) (2008)
Manpower available for military service:
males age 16-49: 72,715,332
females age 16-49: 71,638,785 (2008 est.)
Manpower fit for military service:
males age 16-49: 59,413,358
females age 16-49: 59,187,183 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,186,440
female: 2,079,688 (2008 est.)
Military expenditures:
4.06% of GDP (2005 est.)','75112c11660627e9c317a5e89757d48e71c21f9c4615e390a69e1a41afa1ddf4','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d0e53c7099c238800446876779649d1363a2251fc7fb34c65f0ed2b58f8c199',2008,'UY','Uruguay','military-and-security',1787,'Military branches:
Uruguayan Armed Forces: Army (Ejercito), Navy (Armada Nacional;
includes naval air arm, Marines, Maritime Prefecture in wartime),
Air Force (Fuerza Aerea Uruguaya, FAU) (2008)
Military service age and obligation:
18 years of age for voluntary and compulsory military service;
enlistment is voluntary in peacetime, but the government has the
authority to conscript in emergencies (2007)
Manpower available for military service:
males age 16-49: 837,252
females age 16-49: 824,096 (2008 est.)
Manpower fit for military service:
males age 16-49: 703,955
females age 16-49: 690,296 (2008 est.)
Manpower reaching militarily significant age annually:
male: 27,082
female: 26,075 (2008 est.)
Military expenditures:
1.6% of GDP (2006)','ea8ff61289666168386571568046b5e89bbbd6b71ac0b650eb16c04a0a8bcd79','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e65ad2033a4d13907816e7634280d96238a3f78dbb286749f6bb8f43af00c06',2008,'UZ','Uzbekistan','military-and-security',1798,'Military branches:
Army, Air and Air Defense Forces, National Guard
Military service age and obligation:
18 years of age for compulsory military service; 1-year conscript
service obligation; moving toward a professional military, but
conscription will continue; the military cannot accommodate everyone
who wishes to enlist, and competition for entrance into the military
is similar to the competition for admission to universities (2007)
Manpower available for military service:
males age 16-49: 7,480,484
females age 16-49: 7,542,017 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,684,540
females age 16-49: 6,432,976 (2008 est.)
Manpower reaching militarily significant age annually:
male: 324,094
female: 323,923 (2008 est.)
Military expenditures:
2% of GDP (2005 est.)','b3f8d9eaf6201eaf4523f0048197e4001ec420e5b8e62da7b94bcdc747e92fe2','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77a0837c2dc232fadd859c4a1dde48d5211a5d490cbdb941215b1430c698f18a',2008,'VU','Vanuatu','military-and-security',1808,'Military branches:
no regular military forces; Vanuatu Police Force (VPF), Vanuatu
Mobile Force (VMF; includes Police Maritime Wing (PMW)) (2008)
Manpower available for military service:
males age 16-49: 58,900 (2008 est.)
Manpower fit for military service:
males age 16-49: 40,577 (2008 est.)
Manpower reaching militarily significant age annually:
male: 2,385
female: 2,290 (2008 est.)
Military expenditures:
NA
Venezuela
Military branches:
National Armed Forces (Fuerza Armada Nacionale, FAN): Ground Forces
or Army (Fuerzas Terrestres or Ejercito), Naval Forces (Fuerzas
Navales or Armada; includes Marines, Coast Guard), Air Force
(Fuerzas Aereas or Aviacion), Armed Forces of Cooperation or
National Guard (Fuerzas Armadas de Cooperacion or Guardia Nacional)
Military service age and obligation:
18-30 years of age for compulsory and voluntary military service;
30-month conscript service obligation - all citizens 18-50 years old
are obligated to register for military service (2008)
Manpower available for military service:
males age 16-49: 6,647,124
females age 16-49: 6,801,133 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,280,974
females age 16-49: 5,768,814 (2008 est.)
Manpower reaching militarily significant age annually:
male: 275,323
female: 274,106 (2008 est.)
Military expenditures:
1.2% of GDP (2005 est.)
Vietnam
Military branches:
People''s Armed Forces: People''s Army of Vietnam (PAVN) (includes
People''s Navy Command (with naval infantry, coast guard), Air and
Air Defense Force (Kon Quan Nhan Dan), Border Defense Command),
People''s Public Security Forces, Militia Force, Self-Defense Forces
(2005)
Military service age and obligation:
18 years of age (male) for compulsory military service; females may
volunteer for active duty military service; conscript service
obligation - 2 years (3 to 4 years in the navy); 18-45 years of age
(male) or 18-40 years of age (female) for Militia Force or Self
Defense Forces (2006)
Manpower available for military service:
males age 16-49: 24,586,328
females age 16-49: 24,335,132 (2008 est.)
Manpower fit for military service:
males age 16-49: 18,849,274
females age 16-49: 20,575,884 (2008 est.)
Manpower reaching militarily significant age annually:
male: 903,734
female: 845,306 (2008 est.)
Military expenditures:
2.5% of GDP (2005 est.)
Virgin Islands
Manpower reaching militarily significant age annually:
male: 861
female: 897 (2008 est.)
Military - note:
defense is the responsibility of the US
Wake Island
Military - note:
defense is the responsibility of the US; the US Air Force is
responsible for overall administration and operation of the island;
the launch support facility is administered by the US Missile
Defense Agency (MDA)','019ebb50900f42eb3abf8ab703f44364991b392202fdde305192c1e91a7fa01a','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c841a6c8c6fa12e98c168b11db000d67041a36305dabee7ff508ee7ca9adaee',2008,'WF','Wallis and Futuna','military-and-security',1816,'Manpower reaching militarily significant age annually:
male: 172
female: 170 (2008 est.)
Military - note:
defense is the responsibility of France
West Bank
Manpower reaching militarily significant age annually:
male: 29,866
female: 28,372 (2008 est.)
Military expenditures:
NA','e5241169e1c2635faa61a7a3d1dd5716193adf25a9b1da1258412d0ec71ce2ae','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca35601979b05608eb8d4979b3d6181503af02d4221390c12b1d3c845dc74008',2008,'YE','Yemen','military-and-security',1831,'Military branches:
Army (includes Republican Guard), Navy (includes Marines), Yemen Air
Force (Al Quwwat al Jawwiya al Jamahiriya al Yemeniya; includes Air
Defense Force) (2008)
Military service age and obligation:
voluntary military service program authorized in 2001; 2-year
service obligation (2006)
Manpower available for military service:
males age 16-49: 5,080,038
females age 16-49: 4,852,555 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,585,947
females age 16-49: 3,619,195 (2008 est.)
Manpower reaching militarily significant age annually:
male: 268,468
female: 258,196 (2008 est.)
Military expenditures:
6.6% of GDP (2006)
Military - note:
a Coast Guard was established in 2002','b91a5b68b58c392131e73218c5558dc0a3042e1f25d3a7c5727bf68c9e0bbc3b','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4dbf538f20966f14af15b389ae058dc4e04665b088fa83f80a9fe9c3088de34',2008,'ZM','Zambia','military-and-security',1840,'Military branches:
Zambian National Defense Force (ZNDF): Zambian Army, Zambian Air
Force, National Service (2008)
Military service age and obligation:
18 years of age for voluntary military service (16 years of age with
parental consent); no conscription (2008)
Manpower available for military service:
males age 16-49: 2,678,668
females age 16-49: 2,567,433 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,329,343
females age 16-49: 1,218,114 (2008 est.)
Manpower reaching militarily significant age annually:
male: 147,358
female: 146,771 (2008 est.)
Military expenditures:
1.8% of GDP (2005 est.)','9023bfa4c95f580b36538a3e1903347595bad6a51923da3389d3e29ca443e96a','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

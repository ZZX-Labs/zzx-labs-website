SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('822064906e5a8cfc75710da293661929cd6f23bb4072229ec422e049a1271385',1996,'TM','Turkmenistan','people-and-society',8,'Population: 22.664.136 uly 1996 est)
Age structure:
0-14 vears: 43% (male 4.972.469; temale
4.784.900)
15-64 vears: 54% (male 6.377.231: temale
5.916.954)
65 vears and over: 3% (male 325.808:
female 286.774) July 1996 est)
Population growth rate: 4.78) (1996 est)
Birth rate: 43.03 births/1.000 population
(1996 est.)
Death rate: 18.16 deaths/1.000 population
(1996 est.)
Net migration rate: 22.94 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/temale
under 15 years: 1.04 male(s)/temale
15-64 vears: 1.08 male(s)/female
65 vears and over, 1.14 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 149.7 deaths/!.000
tive births (1996 est.)
Life expectancy at birth:
total population: 45.85 years
male: 46.43 years
female; 45.24 years (1996 est.)
Total fertility rate: 6.14 children born/
woman (1996 est.)
Nationality:
noun: Atghan(s)
adjec live: Atghan
Ethnic divisions: Pashtun 38. Tapk 250.
Uzbek 6%. Hazara 19%, minor ethnic groups
Chahar Aimaks. Turkmen, Baloch. and
others)
Religions: Sunni Muslim 84. Shi''a
Muslim 15%. other 1%
Languages: Pashtu 35. Atghan Persian
(Dari) 50%, Turkic languages (primarily
Uzbek and Turkmen) 1147. 30 minor
languages (pranaaly Balochi and Pasha)
4. much bilingualism
Literacy: age 15 and over can read and
wr t2 (1995 est.)
total population: 31.5
male: 47.24
female: 15°','6a157165e4e0d192ed84d255379109f6391a7ea5d0e3fedc2387850c8da2436c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bbd854f8f82d27e2faf2cc91615ce027d9de4c93b45b0abc36ac06a50f7815a',1996,'AL','Albania','people-and-society',16,'Population: 3.249.) 46 cluly T
note: the IMP worku th Alt
Lover ment
pPopaulal nwas 3.)2¢
has tallen since 1990)
\\ge structure:
O-Js4 years: 34 (male (90
$29,147)
15-64 vears: OD (male YVIORT3. 4
1.049.662)
65 vears and over. 6 male ‘YY
110.677) luly 1996 est)
Population growth rate: | 645. (199
Birth rate: 22.2) births/1.000 po
(1996 est.)
Death rate: 7.64 deaths/1.000 populat
(1996 est.)
Net migration rate: -!0!) 7 micrantisy/ | 000
population (1996 est
Sex ratio:
at birth: 1.08 malets /temal
wider 1S years: 1OS mak
15-64 years: O87 maletsitemal
H5 vears and over: 0.7 males
all aves. 0.92 maleisVtemal 1Yyy
Infant mortality rate: 49 2 deat! (WH)
hive births (1996 est
Life expectancy at birth:
total populat HT U2 4
mele: 64.91 vears
female: TIAT veat YUT
Total fertility rate: 2.65 children born
woman (1) 996
Nationality:
noun. Albaniants)
Gdadjecihive Albania
Albania (continued)
bthnic divisions: Albanian 95‘7. Greeks
3 V lachs. Gypsies. Serbs. and
RB 4) esi
} ther estimates of the Greek
y ranged trom | official
host to 12 (from a Greek
Religions: Muslim 70 \\ibanian Orthode.
i ‘ }
~4 ‘ ial urches Were closed
T ind relrgnous observances prohibited
‘ ‘ OY) Albania hevanh allowing
'' onguages ont Tosko oo the official
‘
faiteracs ver can read and write
(,overnment
Name of country:
Zepublic of Albania
rs AT Dania
t iblika « SHYIPErise
4 ‘ pera
People , alist Repul lao aod
\\1)
Duta code: Al
Ivpe of government: emerging democracy
Capital: |
Administrative divisions: 26 distnct
! B t Dats
i } tr. Gstipokast ty st
K Art Kul |
| \\l Ninrdite. Per
‘ Shhkod SkraDa
Proy \\!
Have
Independence: 2S November 1912 (trom
National holiday: Independence Day. 2s
t onstitution: { Nastc law was
Prev Assembly on 29
} j + Ww rejected
i} tall f 19ud
''
legal system: not accepted compulsory
Sullrage: (> rf miversal and
Fvccutive branch:
President of the Republic Sab
BERISH % April 1992) was elected
vear ferm py ine People .
head of government: Prime Minister of the
Council of Ministers Aleksander Gabriel
MEKSI (since 10 April 1992) was appointed
by the president
cabmet: Council of Minister, was appointed
by the president
Legislative branch: unicameral
People’s Assembly (Kuvendt Popullor)
elections last held 22 March 1992: results
DP 62.297. ASP 25.57. SDP 4.33. RP
3.15%. UHP 2.92%. other 1.74%; seats
(140 total) DP 92. ASP 38. SDP 7. RP 1.
LHP 2
note. ax members of the Democratic Party
detected. making the present seating in the
Assembly DP 86. ASP 38. SDP 7. DAP 6.
RP 1. UHP 2
Judicial branch: Supreme Court. chairman
of the Supreme Court ts elected by the
People’s Assembly
Political parties and leaders: there are at
least 28 political parties: most prominent are
the Albanian Socialist Party (ASP: tormerly
the Albania Workers Party). Fatos NANO.
ltest secretary: Democratic Party (DP):
\\ibaman Republican Party (RP). Sabn
GODO: Omonta (Greek minority party)
Sotu QIRJAZATL. first secretary: Social
Democrat: Party (SDP). Skendet
GJINUSHE Democratic Alliance Party
(DAP). Neritian CEKA, chairman: Unity tor
Human Rights Party (CHP). Vasil MELO.
chairman: Ecology Party (EP). Namik HOTI.
chairman
International organization participation:
BSEC. CCC. CE. EBRD, ECE. EU
(applicant). FAO. TABEA. IBRD. ICAO.
ICRM. IDA. IDB. IFAD. TRC. TFRCS. ILO.
IMF. IMO. Intelsat (nonsignatory user)
Interpol, HOC, TOM. ISO. TTL. NACC, OIC,
OSCE. PEP. UN. UNCTAD. UNESCO.
UNIDO, UNOMIG. UPL. WETU. WHO
WIPO, WMO. WT0QO, WTrO capphicant)
Diplomatic representation in US:
Chief of misston. Ambassador Lublin DILJA
chancery. Suite (O00, TSTT KR Street NW
Washington, DC 20008
telephone. {1} (202) 223-4942. 8187
FAX: [1] (202) 628-7342
LS diplomatic representation:
Chief of mission. Ambassador Joseph t
LAKE
embassy: Rruga E. Labinote 103. Tirane
mailine address: PSC S89. Box 100 4A, APO
Ak 09624
telephone: |35§| (42) 328-78, 338-20
FAX: [SSS] (42) 322-22
Flag: red with a black two-headed eagle im
the cent
Population: sd YH est
Ave stoucture:
4 ‘ in?’ mal
_ “ 1y OM ten
Sid) ys
‘ ile STS OOS July INH est
. ‘ 1 4 . ]
Population growth rate: 2 2)5) (1996 est
Birth rate:
if
1 AWK) paulati oe
Death rate: ths/) O00 populations
Nel migration rate: NW nnvrantis/ 1.000
i)
Sew ratbo
il
cis femal
1YUG est)
Infant mortality rate: 48 7 deaths’ 1.000
Vile expectancs at birth:
y
Cth id) ( Wty st}
lotal fertility rate: 659 children born
woman (1996 est
Nationality:
mn: Algenant
adjective \\ Verial
Ethnic d: visions: Arab- Berber 09%:
-uropeat less than |
Religions: Sunni Muslim (state religion)
99° Christian and Jewish 1%
Languages: Arabic (offi tal). French. Berber
dialects
Literacy: age 15 and over can read and
4 WS evs
) ale fi ¢
e TW9
4
Population: 59.566 July 1996 est)
Age structure:
0-14 years: NA
15-64 years: NA
65 vears and over: NA
Population growth rate: 3.77 (1996 est.)
Birth rate: 35.75 births/1.000 sooulation
(1996 est.)
Death rate: 4.01 deaths/1.000 population
(1996 est)
Net migratica rate: 6 migrant(sy/ 1.000
population (1996 est.)
Sex ratio:
at urth: NA matletsiWtemale
under 15 vears: NA maletsWtemale
15-64 vears: A male(sWfiemale
65 vears and over’ NA male(sWfemale
all ages: NA maletsVtemale
Infant mortality rate: |8 78 deaths/!.000
live births (1996 est)
Life expectancy at birth:
total population 72.9] years
male. 71.03 years
female: 74.85 years (1996 est.)
Total fertility rate: 4.24 children born/
woman (1996 est.)
Nationality:
noun’ Amencan Samoanis)
adjective. American Samoan
Ethnic divisions: Samoan (Polynesian) 89%.
Caucasian 2%. Tongan 4%, other 5%
Religions: Christian Congregationalist 50%.
Roman Catholic 20%, Protestant
denominations and other 30%
Languages: Samoan (closely related to
Hawanan and other Polynesian languages).
English
note: Most people are bilingual
Literacy: age 15 and over can read and
write (1980 est.)
total population: 97%
male. ISG
female: 97%','bf37a48f5d3cb34a0af410dcfa2eecf5b1fe967554361f4ac402bf782cec81c1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d6ffffe15cf2534a328f5b0292f56e8a7dbf22ef25e201f6a134b32a43bc6be',1996,'ES','Spain','people-and-society',23,'Population: 10.342.899 (July 1996 est)
Age structure:
0-14 vears: 45 (male 2.340.804: temale
2.275.689)
15-64 vears: 53% (male 2.748.417: temale
2.706.295)
65 vears and over: 2% (male 128.067:
femate 143.627) (July 1996 est.)
Population growth rate: 2.68). (1996 est)
Birth rate: 44.58 births/!.000 population
(1996 est.)
Death rate: 17.66 deaths/1.000 population
(1996 est.)
Net migration rate: -0.14 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 vears: 1.03 maletsVtemale
15-64 vears: 1.02 male(si/female
65 years and over: O89 male(s)/female
all ages: 1.02 malet(si/female (1996 est.)
Infant mortality rate: 138.9 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 46.8 years
male: 44.65 years
female: 49.06 years (1996 est.)
Total fertility rate: 6.35 children born/
woman (1996 est.)
Nationality:
noun: Angolan(s)
Angola (continued)
dad ( An
“74
Ethnic divisions: Ovimbundu 3
Ki li 2S Bakengo 136. mestice
'' I
(MIA pean and Native Afmcan) 2%.
i Hi 1c. other 22%
Refigions: indigenous beliets 47°. Roman
> 5 ec
itholic 4s Protestant [oe fest)
: ‘ ° ) TTT 2 » far . ] sr
Languages: Portuguese totficial). Bantu and
Virccan languages
Literacy: ave 1S and over can read and
f,overnment
Name of country:
ig forme Republic of Angola
onal short form: Angola
nm ong forme Republica de Angola
} mn) Angola
ner People’s Republic of Angola
Data code: \\O
Pype of government: transitional
sernament nominally a multiparty
with a strong presidential system
Capital: | wanda
Administrative divisions: [1S provinces
(provineias, singular-—provineia). Benge.
Benguela. Bre. Cabinda
Cuanza Norte. Cuanza Sul. Cunene
Huambo. Huila. Luanda. Lunda Norte
Lunda Sul. Malanje. Moxico. Namibe. Cig
Avs
Cuando Cubanvgo
Independence: |) November 1975 (tron
‘> .
t fucal
National holiday: Independence Das
‘ pS
Constitution: Nove ie sed
S tt Auecust 1980. 6 Marcel
") % August 199
Leval svstem: based on Portuguese civil law
UsStomary iW. recent moditied
ohlitical pluralism and
Suffrage: |S vears of ave: universa
Executive branch:
x Eduardo DOS
since 21 September 1979) was
President Jo
ANTOS
nnally elected without Opposition under a
ne party system and stood for election in
\\ngcla’s first multiparty elections on 29-30
ptember 1992. DOS SANTOS received
V6 of the total vote. making a run-off
.
av
election necessary between him and second-
place Jonas SAVIMBE. the run-off was not
held and SAVIMBI’s National Union for the
Fotal Jadependence of Angola (UNITA)
12
disputed the results of the first election: the
civil war was resumed
head of government: Prime Minister
Marcolino Jose Carlos MOCO (since 2
December 1992) was appointed by the
president and is answerable to the Assembly
cabinet: Counst! of Ministers was appointed
by the president
Legislative branch: unicameral!
Nanonal Assembly (Assembleia Nacional)
elections last held 29-30 September 1992
(next to be held NA}. results (diyputed)
percentage of vote by party NA: seats (223
total) —seats by party NA
Judicial branch: Supreme Court (Tribunal!
da Relacao). judges of the Supreme Cour
are appointed by the president
Political parties and leaders: Popular
Movement tor the Liberation of Angola
(MPLA). led by Jose Eduardo DOS
SANTOS. ts the ruling party and has been in
power since 1975. National Union tor the
Fotal Independence of Angola (UNITA). led
by Jonas SAVIMBLE. ts a legal party despite
its history of armed resistance to the
government. five minor parties have small
numbers of seats in the National Assembly
Other political or pressure groups: Front
tor the Liberation of the Enclave of Cabinda
(FLEC). NZITA Tage. leader of largest
faction (FLEC-FAC)
note: FLEC is waging a small-scale. highly
fachonahzed. armed struggle tor the
mdependence of Cabinda Province
International organization participation:
ACP. AIDB. CCC, CEEAC (observer). ECA
FAO. G77. IBRD. ICAO, ICRMLIDA
IFAD. TEC. TFROS. ILO) IMF. IMO
Intelsat. Interpol. LOC.) TOM. ITU. NAM.
OAS (observer). OAL SADCLUN.,
UNCTAD. UNESCO. UNIDOL UPI
WETU. WHO, WIPO, WMO. WoO
Diplomatic representation in US:
WCL.
Chief of missions Ambassador Antonio dos
Santos FRANCA ~N''dalu’
embassy. S19 L Street NW. Suite 400,
Washington, DC 20036
telephone: |} (202) 785-1156
FAX. [1] (202) 785-1258
LS diplomatic representation:
chret of missions Ambassador Donald K
STEINBERG
embassy: No. 32 Rua Houan Boumedienne.
Miramar. Luanda
mailing address: CP. 6484, Luanda.
\\merican Embassy. Luanda. Department of
State. Washington, DC 20521-2550 (pouch)
telephone: (244) (2) 345-481, 346-418
FAN. 1244] (2) 346-924
Flag: two equal horizontal bands of red (top)
and black with a centered yellow emblem
consisting of a five-pomnted star within halt
a cogwheel crossed by a machete (in the
stvle of a hammer and sickle)
Population: 9.865.114 Gluly 1996 est.)
Age structure:
0-14 vears: 18% (male 888.157: female
843.309)
15-64 years: 68% (male 3.249.973: female
3.414.793)
65 vears and over: 14% (male 601.913:
female 866.969) (July 1996 est.)
Population growth rate: 0.02% (1996 est.)
Birth rate: 10.53 births/1.000 population
(1996 est.)
Death rate: 10.2 deaths/1.000 population
(1996 est.)
Net migration rate: -0.18 migrant(s)/1.000
population (1996 esi.)
Sex ratio:
at birth: 1.06 male(sVtemale
under 15 years: \\.0S maletsi/female
15-64 vears: 0.95 male(s)/female
65 vears and over: 0.69 male(sWfemale
all ages: 0.92 male(sVtemale (1996 est.)
Infant mortality rate: 7.6 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 75.31 years
male: 71.52 years
female: 79.31 years (1996 est.)
Total fertility rate: |.36 children born/
woman (1996 esl.)
Nationality:
noun; Portuguese (singular and plural)
adjective: Portuguese
Ethnic divisions: homogeneous
Mediterranean stock in mainland. Azores.
Madeira Islands; citizens of black African
descent who immigrated to mainland during
decolonization number less than 100.000
Religions: Roman Catholic 97%. Protestant
denominations 1%, other 2%
Languages: Portuguese
Literacy: age 15 and over can read and
write (1990 est.)
total population: 85%
male: 89%
feinale: 82%
Population: uninhabited','ac7237583bd82df5fb082d2abe112d9cff7f2f732c373943e138224a1be27778','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45cd61a58b4fa5534959d8b940b2cbb9c4ea34e4111ea2ef363db7ac67d99abc',1996,'BR','Brazil','people-and-society',30,'Povulation: |0.424 (luly 1996 est.)
\\ee structure:
4 vears: 28% (male 49}. female 1.450)
\\-64 vears: 646° (male 3.418: female
5)
S years a r Sor (mate 342: temale
its) «July 1996 ,
Population growth rate: 345° (1996 est)
Birth rate:
Hoty
| S4 births/ 1.000 population
Peeath rate: 5.66 deathy/].000 population
ALi
Net migration rate: 22.35 migrant(s)/ 1.000
QU t SI }
SeX rato:
toe sn ala
Mm MHidiet Sh female
Y rs. | O8 maletsiVtemale
j ad vera (4 malets/temale
65 years and ever, 0.76 maletstemale
2 maleisVtemale
Infant mortality rate: 23 deaths/1.000 live
births (1996
Life expectancy at birth:
foul 7 priate lian 767 Vedrs
late 73.75 vears
female 974 veaurs (1996 est.)
Total fertility rate: 204 Children born
oman (i996 est
Nationality:
nan Anguillants
Ne \\nguillan
Ethnic divisions: black Atmecan
Religions: Angiican 40%. Methodist 33!
Day Adventist 7%. Baptist 5
Roman Cathoh 7. other 12%
Languages: Enelish Cotiicial)
Literacy: ave 12 and ever can read and
'' s
{ mr YS
evn
(,overnment
Name of country:
On form. Tone
entional short form: Anguilla
Data code: A\\
Type of government: dependent territory of
the UK
Capital: The Valley
\\dministrative divisions: none (dependent
ritory of the UK)
Independence: none (dependent territory of
the UK)
National holiday: Anguilla Day, 30 May
i4
Constitution: Anguilla Constitutional Order
1 April 1982. amended 1990
Legal system: based on English common
law
Suffrage: 18 years of age: universal
Executive branch:
chief of state’ Queen ELIZABETH II isince
6 February 1952) ts a hereditary monarch
represented by Governor Alan HOOLE
since | November 1995)
head of government. Chiet Minister Hubert
HUGHES (since 16 March 1994) was
appointed by the governor trom members of
the House of Assembly
copmerh Executive Council was appointed by
the governor trom among the elected
members of the House of Assembly
! egislative branch: unicameral!
House of Assembly: elections last held 16
March 1994 (next to be held March 1999),
percent of vote by party NA:
seats—( 11 total. 7 elected) ANA 2. AUP 2.
ADP 2. independent |
Judicial branch: High Court. judge
provided by Eastern Caribbean Supreme
results
Court
Political parties end leaders: Anguilla
National Alliance (ANA), David CARFY:
Anguilla Umied Party (AUP). Hubert
HUGHES. Anguilla Democratic Party
(ADP). Victor BANKS
Internationa: organization participation:
Caricom ‘odserver). CDB. Interpol
iseboureau). OECS (associate)
Diplomatic representation in US: none
(dependent territory of the UK)
US diplomatic representation: none
(dependent territory of the UK}
Flag: blue with the flag of the UK tn the
upper hoist-side quadrant and the Anguillan
coat of arms centered in the outer half of the
Hag: the coat of arms depicts three orange
dolphins in an interlocking circular design on
a white background with blue wavy water
be lc mw','0935ef3adfdf36f795304c8e4cfaf6254186105492858d1cc59a62933ac52053','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c046b59096d0693e10c75e8d26b4b73bdc721645ecc64304b1496d407247c95',1996,'AQ','Antarctica','people-and-society',34,'Population: no indigenous inhabitants.
nove-—there are seasonally statted research
SLUTIONS
Summer (January) pr mulation. over 4.114
total. Argentina 207. Australia 268. Belgium
13. Brazil 80. Chile 256. China NA. Ecuador
NA. Finland 11. France 78. Germany 32
Greenpeace 12. India 60. Italy 210. Japan
SY. South Korea 14. Netherlands 10. NZ
264. Norway 23. Peru 39, Poland NA. South
\\trica 79, Spain 43. Sweden 10. UK 116
Uruguay NA. US 1.666. former USSR 565
(1989-90)
Winter (July) population. over 1.046 total
wrgentina 150. Australia 71. Brazil 12. Chile
73. China NA. France 33. Germany 19.
Greenpeace 5, India 1. Japan 38. South
Korea 14. NZ 11. Poland NA. South Africa
1s
Antarctica (continued)
> UK t'': i) NA, US 225. tormer
LSS s i}
ye mis. 42 total Argentina 6
\\ * Brazil |. Chile 5. China 2
I |. France |. Germanys India |
>. South Korea 1. NZ 1. Poland |
Vinca 3. UK S. Uruguay 1. US 3
i SSR ¢ you-ely-
over 38 total
\\ust : 3. Chile S. Germanys
| lonan 4. NZ 2. Norway
\\ Spain |. Swedet
tormer USSR S
lhsintegration of the
he status and
Wi
i;overnment
Yam ounirs:
4 ‘
\\
Data code
Tim i sernment
| \\! tall \\
’ ;* |
| if
4 wh
Ad IS
™
\\ o Tr
7 | i '' \\mo
i \\ hy
P ''
A is
Ih | S
'' \\ ! Te ry)
ih ~ I he
! ters
i hen al
" it)
Stulu while no date
iwinar Psy
C lannant nations are
brance. New
nd the CR. Nonclammant
Belgium. Brazil
C }y SS). Eeouador CTeYYO)
NY) OC) iny (LOST). India
i’ LUX” japan. South Korea
Netherland 990). Peru (1989)
} South Africa. Spain (1988)
4A ivuay (1988). the US and
K \\cceding ¢: onvoting) members. with
in parentheses, are
16
Austra (1987). Bulgana (1978). Canada
(1988). Colomoia (1988). Cuba (1984).
Czech Republic (1993). Denmark (1965).
Greece (1987). Guatemala (1991). Hungary
(1984). North Korea (1987), Papua New
Guinea (1981). Romania (1971). Slovakia
(1993). Switverland (1990). and Ukraine
(1992)
Article 1: ar2a to be used tor peacetul
purposes only: military activity, such as
weapons testing. rs prohibited. but milita’y
personnel and equipment may be used tor
scientific research or any other peacetul
purpose
Wrricle 2. treedom of scientific investigation
and cooperation shall continue
Wrucle 3: tree exchange of information and
personnel in cooperation with the UN and
other mternational agencies
Vicle 4) dees not recognize. dispute. or
establish terntorial clams and no new claims
shall be asserted while the treaty ts in force
Vile 5) prohibits nuclear explosions or
disposal of radioactive Wastes
Verde 6: includes under the treaty all land
and ice shelves south of 60 degrees (H)
minutes south
\\ ficise
access, including aenal observation, to any
treaty -staie observers have free
rea and may inspect all stations.
installations. and equipment: advance notice
of all activities and of the introduction of
mulitary personnel must be given
\\rticie 8S: allows tor jurisdiction over
observers and scientists by their own states
Irticle Y frequent consultative meetings take
place among member nations
\\rtle It
acuivities by any country in Antarctica that
treaty states will discourage
are contrary to the treaty
icle 17) disputes to be settled peacetulls
by the parties concerned or, ulumately. by
the 1C3
Vrricles 12, 73, 14° deal with upholding.
imerpreting. and amending the treaty among
involved nations
Other agreements: more than 170
recommendations adopted at treaty
consultative meetings and ratified by
yovernments include—Agreed Measures for
the Conservation of Antarctic Fauna and
Flora (1964): Convention for the
Conservation of Antarctic Seais (1972).
Convention on the Conservation of Antarctic
Marine Living Resources (1980). a mineral
resources agreement was signed in 1988 but
was subsequently reyected: in 1991 the
Protocol on Environmental Protection to the
Antarctic Treaty was signed and awatts
ratification, this agreement provides tor the
protection of the Antarctic environment
through five specific annexes on marine
pollution. fauna. and tlora, environmental
HMpact assessments, waste management. and
p:otected areas: it also prohibits all activities
relating to mineral resources except scientific
research: 21 parties have ratified Protocol as
of Apnl 1996
Legal system: US law. including certain
criminal offenses by or against US nationals,
such as murder. may apply to areas not
under jurisdiction of other countries. Some
US laws directly apply to Antarctica. For
example. the Antarctic Conservation Act. 16
U.S.C. section 2401 et seq.. provides civil
and criminal penalties for the tollowing
acuvities. unless authorized by regulation of
Statute: The taking of native mammals or
birds: the introduction of aonindigenous
plants and animals: entry into specially
protected or scientific areas. the discharge or
disposal of pollutants: and the importation
into the US of certain ttems from Antarctica
Violation of the Antarctic Conservation Act
carries penalties of up to $10,000 tn tines
and | year in prison. The Departments of
Treasury. Commerce. Transportation, and
biterior share enforcement responsibilities
Public Law 95-541. the US Antarctic
Conservation Act of 1978, requires
expeditions from the US to Antarctica to
notify. in advance. the Office of Oceans and
Polar Affairs, Room S801. Department of
State. Washington, DC 20820. which reports
such plans to other nations as required by
the Antarctic Treaty. For more information
contact Permit Otfice. Office of Polat
Programs, National Science Foundation.
Arlington, Virginia 22230 (703) 306-103)
Population: 34 672.997 (July 1996 est.)
Age structure:
0-14 years: 28% (male 4,904,380; female
4,707,293)
15-64 vears: 63% (male 10,851,004; female
10.834,593)
65 vears and over: 9% (male 1.414.412:
female 1.961.315) July 1996 est.)
Population growth rate: |.1°7 (1996 est.)
Birth rate: 19.41 births/1.000 population
(1996 est.)
Death rate: 8.62 deaths/1.000 population
(1996 est.)
Net migration rate: 0.18 migrani(s)/!.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(sWtemale
under 15 vears: 1.04 male(s)/female
15-64 vears: | male(sWtemale
65 veors and over: 0.72 male(s)/temale
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 28 3 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 71.66 years
male: 68.37 years
female: 75.12 years (1996 est.)
Total fertility rate: 2.62 children born/
woman (1996 est.)
Nationality:
noun. Argentinet(s)
adjective: Argentine
Ethnic divisions: white 8S. mestizo.
Indian. or other nonwhite groups 15%
Religions: nominally Roman Catholic 90%
(less than 20% practicing). Protestant 2%,
Jewish 2. other 6%
Languages: Spanish (official), English.
Italian, German. French
Vaieracy: age 15 and over can read and
write (1995 est.)
total population: 96.24
male: 96.2%
female: 96.2%
Covernment
Name of country:
conventional long form: Argentine Republic
conventional short form: Argentina
local long form: Republica Argentina
local short form: Argentina
Data code: AR
Type of government: republic
Capital: Buenos Aires
Administrative divisions: 23 provinces
(provincias, singular—provincia), and |
federal district® (distrito federal), Buenos
Aires, Catamarca, Chaco; Chubut: Cordoba;
Cornentes: Distrito Federal*: Entre Rios:
Formosa: Jujuy: La Pampa: La Rioja:
Mendoza: Misiones: Neuquen: Rio Negro:
Salta. San Juan: San Luis: Santa Cruz; Santa
Fe: Santiago del Estero: Tierra del Fuego.
Antartida e Islas del Atlantico Sur. Tucuman
AP
note: the US does not recognize any claims
to Antarctica or Argentina''s claims to the
Falkland Islands
Independence: © July 1816 (from Spain)
National holiday: Revolution Day. 25 May
(1810)
Constitution: | May 1853: revised August
1994
Legal system: mixture of US and West
European legal systems: has not accepted
compulsory ICJ jurisdiction
Suffrage: 18 years of age: universal
Executive branch:
chief of state and head of government:
President Carlos Saul MENEM (since 8 July
1989) was elected for a four-year term by
universal suffrage: election last held 14 May
1995 (next to be held May 1999): resultys—
Carlos Szul MENEM was reelected. Vice
President Carlos RUCKAUF
cabinet: Cabinet was appointed by the
president
Legislative branch: bicameral Nationa!
Congress (Congreso Nacional)
Senate. elections last held NA May 1995
(next to be held NA). results—percent of
vote by party NA: seats—(72 total) PJ 38.
others 34
Chamber of Deputies: one-halt ot the
members elected every two years to four-
year terms, elections last held 14 May 1995,
(next to be held NA 1997): results—percent
of vote by party NA: seats—( 257 total) PJ
132. UCR 68, Frepaso 26, other 31
Judicial branch: Supreme Court (Corte
Suprema). the nine Supreme Court judges
are appointed by the president with approval
of the Senate
Political parties and leaders: Justicialist
Party (PJ), Carlos Saul MENEM. Peronist
umbrella political organization, Radical Civic
Union (UCR), Rodolfo TERRAGNO,
moderately left-of-center party; Union of the
Democratic Center (UCD), conservative
party: Dignity and Independence Political
Party (MODIN), Aldo RICO, nght-wing
party: Grand Front (Frente Grande), Carlos
ALVAREZ, center-left coalition: Front for a
Country in Solidarity (Frepaso, a four party
coalition), leader Jose Octavio BORDON,
several provincial parties
Other political or pressure groups:
Peronist-dominated labor movement. General
Confederation of Labor (CGT), Peronist-
leaning umbrella labor organization,
Argentine Industrial Union (manufacturers
association): Argentine Rural Society (large
landowners’ association): business
organizations, students: the Roman Catholic
Church; the Armed Forces
International organization participation:
AfDB. AG (observer), Australia Group.
BCIE, CCC, ECLAC, FAO. G- 6, G-11, G-
15. G-19, G-24, G-77. IADB. IAEA, IBRD.
ICAO. ICC, ICFTU, ICRM. IDA, IFAD.
IFC. IFRCS, ILO, IMF, IMO, Inmarsat.
Intelsat, Interpol, LOC. 1OM, iSO, ITU.
LAES, LAIA, Mercosur. MINURSO.
MTCR, NSG (observer), OAS. OPANAL.
PCA, RG. UN, UN Security Council
(temporary). UNAMIR, UNAVEM IIL.
UNCRO, UNCTAD. UNESCO. UNFICYP.
UNHCR, UNIDO, UNIKOM. UNITAR.
UNMIH, UNTSO, UNU, UPL. WCL.
WETU, WHO, WIPO. WMO. WT0O. WTrO
Diplomatic representation in US:
chief of mission: Ambassador Rau! Enrique
GRANILLO OCAMPO
chancery: 1600 New Hampshire Avenue
NW. Washington, DC 20009
telephone: (1 (202) 939-6400 through 6403
consulate(s) general: Atlanta, Chicago.
Houston, Los Angeles. Miami. New Orleans
New York. San Francisco, and San Juan
(Puerto Rico)
US diplomatic representation:
chief of mission’ Ambassador James R
CHEEK
embassy. 4300 Colombia, 1425 Buenos
Aires
mailing address: Unit 4334, APO AA 34034
telephone. |54| (1) 777-4833, 4534
FAX: |S4] (1) 77740197
Flag: three equal honzontal bands of light
blue (top). white. and light blue. centered in
the white band ts a radiant yellow sun with
a human tace known as the Sun of May
Independence: !|& September |810 (from
Spain)
National holiday: Independence Day. 18
September (1810)
Constitution: 11 September 1980, effective
11 March 1$81: amended 30 July 1989
Legal system: based on Code of 1857
derived from Spanish law and subsequent
codes influenced by French and Austrian
law; judicial review of legislative acts in the
97
/06
Chile (continued)
Su e Court, does not accept compulsory
i rsalicie
Suffrage: |S years of age: universal and
sinaors\\
hvecutive branch:
ale and head ef government
i tduardo FREI Rutz-Tagle (since
) 1994) elected for 2 four-year term
ote: election last held 11
M93 (neat to be held NA
Eduardo FREI
97): results
PDC) SS. “urturo
ESSANDRI 24.49. other 17.6%
Cabinet appointed by the president
} evislative branch: bicameral National
‘ treso) Nacional)
Ne election last held 11
eA to he held NA
%y sults percent of vote by
NA . 6 total. 38 elected)
tion of Partes tor Democracy 21 (PDC
PS 4. PPD 3. PR 1). Union tor the
t Chile IS RN ELUDES. UCC
lependents 10
{ ” of Deputies (Camara de
held 11 December
held NA December 1997);
Pip election last
dition of Parties tor Democracy
43.05 PDC 27.16%. PS 12.01%. PPD
. PR 2 Uf Union tor the Progress
tc] a RN 18.25%. UDE 12.130,
Lc ) eats. (120 total) Coalition of
Part Democracy 70 ¢PDC 37, PPD 15,
PK 2 PS US. lett-wing independent 1).
on for the Progress of Chile 47 (RN 30).
LDP 1S. UCC 2). nght-wing independents 3
ludi. } branch: Supreme Court (Corte
udves are appoiated by the
he president of the Supreme Court
iby the 17-member court
Political parties and leaders: Coalition ot
Parties tor Democracy (CPD) consists
of. Christan Democratic Party
PDC). Alejandro FOXLEY: Socialist Party
PS). Camilo ESCALONA, Party for
Democracy (PPD). Jorge SCHAULSOHN,
Radical Party (PR). Union tor the Progress
f Chile COPP) consists mainly of three
parties) Natronal Renewal (RN). Andres
\\LLAMAND. Independent Democratic
Cimon (ODT. Joving NOVOA, Center
Center Union (UCCP). Francisco Javier
ERRAZURIZ
Other political or pressure groups:
vitalived university student federations at
United Labor
Central (CUT) includes trade umronists from
ii major universities: labor
the country’s five largest labor
confecerations. Roman Catholic Church
Inter ational organization participation:
APEC. CCC, ECLAC. FAO, G-11. G-77.
98
IADB. IAEA, IBRD, ICAO, ICFTU, ICRM.
IDA, IFAD. IFC, IFRCS, ILO, IMF, IMO,
Inmarsat, Intelsat, Interpol. LOC. IOM, ISO,
ITU, LAES, LALA, Mercosur (associate
member), NAM, OAS, OPANAL, PCA, RG.
UN, UNCTAD, UNESCO, UNIDO.
UNMOGIP. UNTSO. UNU, UPU, WCL.
WETU. WHO, WIPO. WMO, WTo0O, WTrO
Diplomatic representation in US:
chief of mission: Ambassador John BIEHL
del Rio
chancery: 1732 Massachusetts Avenue NW,
Washington. DC 20036
telephone: |1} (202) 785-1746
FAX: 11] (202) 887-5579
consulate(s) general: Chicago, Houston. Los
Angeles, Miami, New York, Philadelphia.
San F.ancisco, and San Juan (Puerto Rico)
US diplomatic represeutation:
Chief of mission: Ambassador Gab: tel
GUERRA-MONDRAGON
embassy; Avenida Andres Bello 2800,
Santiago
mailing address: use street address
telephone: {56} (2) 232-2600
FAX: [56] (2) 330-3710
Flag: two equal horizontal bands of white
(top) and red: there ts a blue square the same
height a. the white band at the hoist-side end
of the white band: the square bears a white
five-pointed star in the center: design was
based on the US flag','51d47ceedfe381844afca88e2cd3804368d01d8c6c248f4356dd3491fa8385de','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('813ba0df7c739b88989b94493f354ab2da5529f534d8e2f4f581bab5d2370447',1996,'AG','Antigua and Barbuda','people-and-society',41,'Population: 65.647 (J yur
Age structure:
4 ears: 25 x UN .
1-4 f <
». 5.44
eh uly 190
Population growth rate:
Birth rate: |5 53 bin
1 | UUE
Death rate:
(1996
Net migration rate:
mor if '' ; WUE
} a ataba
Sex ratio:
ad ; ; | 5 |
tris } Y oVe i? he
4 ‘ ‘ 4
ars and } 1s
mal f 200 yy
{Ves al
Infant mortality rate:
live births (1996 est
Life expec ancy at birth:
oaf , P
ddd Ppopita (? S04
Fiddit a Vea©rs
if male S_A4 Vedl Yr
lotal fertility rate: | 65 ch
woman (199 est
Nationality:
wm: Antiguants)
j ~ \\; -
(JOC Ti Ve Hivu
Barb 1
Barb an
Ethnic divisions: black. British. Port
| ebanese. Syrian
Religions: Anglican (predominant). other
Protestant sects. some Roman Cathol:
Languages: English (official). local d
Literacy: ave 15 and over ha np
five or more Vears of schooling (1960
gral \\
lolai Ppopuatanhor SY
male. YO
female SA','852c80d84d450f1f966a6f286a6a43ed9f4af41edcc77515a85e1bcabbae03f8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c83a46c0cec3892af6426e4d5be725342f0050823ee8ae32ede1872cc258a1e5',1996,'AW','Aruba','people-and-society',56,'Population: 67.794 (July 1996 est.)
Age structure:
0-14 vears: 22% (male 7.850: female 7,155)
15-64 vears: 69% (male 22.499: temale
24.596)
65 years and over: 9% (male 2.353: female
3.341) uly 1996 est.)
Population growth rate: 0.3167 (1996 est)
Birth rate: 14.62 births/1.000 population
(1996 est.)
Death rate: 6.24 deaths/! 000 population
(1996 est.)
Net migration rate: -5.3] migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 vears: 1.1 male(s)/female
15-64 vears: 0.92 maie(s)/temale
65 vears and over: 0.7 male(s)/female
all ages: 0.93 male(s)/female
Infant mortality rate: &.2 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 76.68 years
male: 73 years
female: 80.55 years (1996 est.)
Total fertility rate: |S) children born/
woman (1996 est.)
Nationality:
noun: Aruban(s)
adjective: Aruban
Ethnic divisions: mixed European/Carbbean
Indian 80%
Religions: Roman Catholic 82%. Protestant
8%. Htadu. Muslim, Contucian. Jewish
Languages: Dutch (official), Papiamento (a
Spanish, Portuguese. Dutch. English dialect).
English (widely spoken). Spanish
Literacy: NA
Population: no indigenous inhabitants:
note—there are only seasonal caretakers','55e350b92eb6eceb6c8870bcce87af66d711018cda4ba8a5e6aa31a3361667cc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('164836846c0866db330fb1dd7c555a5321c82eb82f01cb60f0d9bebe635909dd',1996,'AU','Australia','people-and-society',65,'Population: | 8.260.863 (July 1996 est.)
Age structure:
0-14 vears: VG (male 2.009.915; female
1.912.605)
15-64 vears: 66% (male 6.129.285; female
5.Y80.315)
65 vears and ever: 13% (male 967.291;
female 1.261.452) July 1996 est.)
Population growth rate: 0.99 (1996 est.)
Birth rate: 13.99 births/1.000 population
(1996 est.)
Deaih rate: 6.88 deaths/!.000 population
(1996 est.)
Net migration rate: 2.74 migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.05 niale(s)/female
under 1S vears: 1.05 male(sj/temale
15-64 vears: 1.02 male(s)/female
oS years and over: 0.77 malets)/temale
all ages: | male(s)/female (1996 est.)
Infant mortality rate: 5.5 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 79.39 years
male: 76.44 years
female: 82.5 years (1996 est.)
37
Total fertility rate: |.4 childre.: born/
woman (1996 est.)
Nationality:
noun: Austrahian(s)
adjective: Australian
Ethnic divisions: Caucasian 95°7. Asian 4%.
aboriginal and other 1%
Religions: Anglican 26.1‘, Roman Catholic
26%, other Christian 24.3%
languages: English, native languages
Literacy: age 15 and over can read and
write (1980 est.)
total population: \\OO%
male: 100%
female: 100%
Population: uninhabited','53feae7868f8270ab9be53f67cb460cb0a64186e640408dae597ec511cc133bc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bcc23ecd4dd6cd83cda0987922229c3a2e48445cefe5d50632be2ae08a014ec',1996,'AT','Austria','people-and-society',69,'Population: 5.023.244 uly 1996 est)
Age structure:
O14 vears) USS (male 720.696. temale
ONS TTY)
18-64 years: 67° (male 2.726.122: temale
2 OSY_THL +
(male 451.231.
female 780.854) duly 1996 est)
Population growth rate: 415) (1996 est)
Birth rate: 11019 births/ 1.000 population
(1996 est)
Death rate: 10.43 deaths/ 1.000 population
(19096 est)
AHS years and over, WG
Net migration rate: § 34 migrantisy/ 1.000
population (1996 est
Sex ratio:
at birth LOS maletsVtemale
wider TS vears: 10S maletsVtemale
''S.H4 years. 1. O2 maleisi/temale
65 years and over, OSS maletsitemale
all ages: 0.94 maletsVtemale (1996 est)
Infant mortality rate: 6 2 deaths 1.000 tive
births (1996 est.)
Life expectancy at birth:
total population: 76.53 years
male, 73.38 years
female. TY 84 vears (1996 est)
lotal fertility rate: 1.49 children born/
woman (1996 est.)
Nationality:
noun. Austriants)
adjective: Austrian
Ethnic divisions: German 99 4°. Croatian
0.3%. Slovene 0.2%. other 0.10
Religions: Roman Catholic 55“. Protestant
6°. other 9%
Languages: German
Literacy: age 15 and over can read and
write (1974 est.)
total population: 99%
male: NAG
female: NAG','c105a31dec1559546276e4540d195df9ba7a63a04baec9a97f7da421bacd3970','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f4f5121c94d93165d655828df6c0f8b9a7e6eb989e6e1818372c0c3983c66e7',1996,'AZ','Azerbaijan','people-and-society',73,'Population: 7.676.953 (July 1996 est)
Age structure:
0-14 vears: 32% (male 1.270.812. temale
1.215.781)
15-64 vears: O1% (male 2.293.688. female
2.423.222)
6S vears and over: 7% (male 179.048:
female 294.402) (July 1996 est.)
Population growth rate: 0.78% (1996 est)
Birth rate: 22.28 birthy/1.000 population
(1996 est.)
Death rate: &.69 deaths/1.000 population
(1996 est.)
Net migration rate: -S.8 migrantis)/) 000
population (1996 est.)
Sex ratio:
alt birth: 1.05 male(s/temale
under 15 vears: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 vears and over: 0.61 male(s)/female
all ages: 0.95 male(sWfemale (1996 est.)
Infant mortality rate: 74.5 deaths’! 000
live births (1996 est.)
Life expectancy at birth:
total population: 64.84 years
male: 60.13 years
female: 69.78 years (1996 esi
Total fertility rate: 2.04 chiidren >
woman (1996 est.)
Nationality:
noun: Azerbaiyjanits)
adjective. Azerbayan
Ethnic divisions: Aven 90’
Peoples 3.2. Russian 2.5!
a ane . .
2.3%. other 24 (1995S est)
. ’ ;
Dav Sian]
Armenian
note: almost all Armenians live in the
separatist, Nagorno-Karabakh region
Religions: Muslim 93.47. Russian Orthodox
2.5%. Armenian Orthodox 2.3%. other 1.8%
(1995 est.)
note: religrous affiliation is stl nomraal in
Azerbaijan: actual practicing adherents are
much lower
Languages: Aver 89%. Russian 3%.
Armenian 2°. other 6% (1995 est.)
Literacy: age 15 and over can read and
write (1989 est)
romtal population: 97%
male: 9%
female: 96%
C,overnment
Name of country:
conventional long form: Azerbayyani
Republic
conventional short form: Azerbanan
local long form: Azarbaycan Respubiikasi
local short form: none
former: Azerbayan Soviet Socialist Republic
Data code: AJ
lvpe of government: republic
Capital: Baku (Baki)
\\dministrative divisions: 59 rayons
(ravontar. rayon—singular). 11 cities
(saharlar. sahar - singular). | autonomous
republic * Gmuatar respublika): Abscron
Ravonu. Agcabadi Rayonu, Agdam Rayonu.
Agdas Rayonu. Agstala Rayonu, Agsu
Rayonu, AliBayramli Sahan*, Astara
Rayvonu. Baki Sahan*. Balakan Rayonu.,
Barda Rayonu. Beylagan Rayonu. Bilasuvar
Ravonu. Cabrayil Rayonu, Calilabad
Rayonu. Daskasan Ravonu. Davaci Rayonu.,
Fuzuli Ravonu. Gadaday Rayonu, Ganca
Sahan*. Goranboy Kayonu. Coycay Rayonu.,
Hacigabul Rayonu. Imish Rayonu. Ismayilli
Rayonu. Kalbacar Rayonu. Kurdamu
Rayonu. Lacin Rayonu. Lankaran Ravonu.
Lankaran Sahan*. Lertk Rayonu. Masalh
43
Azerbaijan (continued)
Rayonu. Mingacevir Sahan”. Naftalan
Sahar’. Naxcivan Muatar Respublikasi
Neflcca Ravonu. Oguz Rayonu. Qabala
R Qax Ravenu. Qazax Rayonu.
(obusian Ravonu. Qubs Rayonu, Qubadh
Kovonu. Qusar Rayonu. Saatli Rayonu.
birabad Rayonu. Saki Ravonu, Saki
Sahan’. Salyan Rayonu. Saniaxt Rayonu.
© Rayonu Samux Rayenu. Siyazan
Rav Sumygasit Sahari®. Susa Ravonu
Partar Rayenu. To uz Rayonu,
N\\acmaz Ravonu. Nankand:
Na Ravonu. Nizi Rayonu
\\ R Nocavand Rayonu. Yardimb
\\ » Ravonu. Yevlaxn Sahan
Rayonu, Zagatala Ravonu. Zardab
}
Independence: 4) \\ucusi 1991 (irom Soviet
National holiday: Independence Day. 28
a4
’
( onstitution: med 12 November 1995
beval system: civil law svstem
Sullrage . foavge. universa
Fvccutive branch:
lent Hesdar ALIYEN
MS) was elected by popula
, October 1993 (nent
YS) resull Hevadat
t ceat
Prime Minister Fuad
LINEN PO october 199.4). Fimst
}? \\] ters Abbas ABBASOYN
NAS SADY ROW tsince NAD.
VK TINIE DON tcince NA). Elect
PEENDIYVEN ¢ NA) were appointed by
‘dbv the Milk
{ , | Viinisters was appointed
!
iby the Meylis
fevistative branch:
hil) M elections
%) November 1998 (next to
. f vote Phy parts N \\
her ol seats by party
Judicial branch: Su ne’ Court
Political parties and leaders: Azerbaijan
PE). Eboltes ELCIBEY
\\] i Party. Isa GAMBAR
National Independence Party
NEAMEDON. chairman: Social
Part SDP). Araz ALIZADI
Cowie ust Parts Rami7
\\AHMEDON. Charman. People’s Freedom
Party. Y » OGUZ. chairman. Independent
1) ocratic Party. Ant YUNUSOVN
YUNOSOVA, cochairmen. New
i Party Hevdar ALIVEYN.
wn. Boz Gurd Party. Iskander
1] NTT \\ ct ryan \\Vverbanan
3M
Democratic Independence Party. Qabil
HUSEYNLI. chairman: Islamic Party of
Azverbayan. Ali Akram. chairman: Ana Veten
Party. Fazail AGAMALIYEV: Azerbaijan
Democratic Party. Sardar Jalaloglu
MAMEDOV.: Azerbaijan Democratic Party
of Proprietors (DPOP). Makhmud
MAMEDOV: Azerbayan Patriotic Solidarity
Party. Sabir RUSTAMHANLI. Azerbaijan
Republic Retorm Party. Fuad ASADOV:
Communist Party of Azerbaijan
junfegiered). Savad SAYADOV: Equality
of the Peoples Party. Faukhraddin
VYDAYEV: Independent Azerbayjan Party.
Nizami SULEYMANOV: Labor Party ot
Azerbaijan. Sabutai HAJTYEY: Liberal-
Democratic Party of Azerbaijan. Lyudmila
NIKOLAYEVNA: National Enlightenment
Party. Hayy Osman EFENDIYEV: National
Liberation Party. Panak SHAKHSEVEV:
Peasant Party. Firuz MUSTAFAYEV:
Radical Party of Azerbaijan. Malik
SHARIFOVN. United Azerbayan Party.
Kerrar ABILOV:. Vetan Adzhagy Party.
Jako TAGIYEN
(ther political or pressure groups: selt-
prochumed Armenian Nagorno-Karabakh
Republic: Talysh independence movement
International organization participation:
BSEC. CCC. CIS. EBRD. ECE. ECO.
ESC AP, FAO, IBRD. ICAO, IDA. IDB.
IFAD. IFRCS. ILO. IMF. IMO. Intelsat
Interpol, LOC. ITU. NACC, NAM (observer).
OIC, OSCE. PFPL UN. UNCTAD
UNESCO. UNIDO. UPL, WHO. WIPO
WMO. WTrO Cobserver)
Diplomatic representation in US:
Chiet of mission: Ambassador Hatiz Mar Jalal
PASHAYEN
chancery: Gemporary ) Surte 700,927 1Sth
Street NV. Washington, DC 20005
telephone: V1) (202) 842-000)
FAX: | 1) (002) 842-0004
US diplomatic representation:
chict of misstons Ambassador Richard D
KAUZLARICH
embassy. Azadlig Prospektr 83. Baku
mailing address. use embassy street address
telephone: (9) (9412) 96AW-19, OR-AR-37
YR 193-36, 93-64-80, 96-36-21
FAN: [9] (9412) 98-37-55
Flag: three equal horizontal bands of blue
(top). red. and green. a crescent and eight
pointed star in white are centered in red
hand
Econom)
Economic overview: Azerbaijan is less
developed industrially than ether Armenia or
Georgi. the other Transcaucasian states. It
resembles the Central Asian states in tts
majorty nominally Mushim population, high
Structural uremployment, and low standard
of living. The economy''s most prominent
products are oil, cotton, and gas. Production
from the Caspian oil and gas field has been
in decline for several years, but the
November 1994 ratification of the $7.5
billion oi! deal with a consortium of Western
companies should generate the funds needed
to spur future industrial development.
Azerbayan shares ail the formidable
problems of the ex Soviet republics in
making the transition from a command to a
market economy. but its considerable energy
resources brighten its long-term prospects.
Baku has only recently begun making
progress on economic reform. and old
economic ties and structures have yet to be
replaced. Whereas the economies of most of
the former Soviet republics had begun to
bottom out in 1995. Azerbaijan''s economy
continued to plummet because of its iate
Sart on economic reform
GDP: purchasing power parity —$11.5
billion (1995 estimate as extrapolated trom
World Bank estimate for 1994)
GDP real growth rate: -17° (1995 est.)
GDP per capita: $}.480 (1995 est)
GDP composition by sector:
agriculture: NAG
industry; NAG
services: NAG
Iniction rate (consumer prices): 85%
(1995 est.)
Labor force: 2.789 million
by occupation: agriculture and forestry 32%.
mdustry and construction 26%, other 42%
(1990)
Lnemployment rate: 2.3''> includes
officially registered unemployed: also large
numbers of unregistered unemployed and
underemployed workers (December 1995)
Budget:
revenues, S465 million
expenditures: SASS million, including capital
expenditures of SNA (1995 est.)
Industries: petroleum and aatural gas.
petroleum products. oilfield equipment, steel,
iron ore. cement: chemicals and
petrochemicals: textiles
Industrial production growth rate: -2|
(1995 est)
Electricity:
capacity, 4.900.000 KW
production: 17 tilhon kWh
consumption per capita: 2.200 KWh (1995
est.)
Agriculture: cotton, grain. rice. grapes. fruit,
vegetables, tea, tobacco: cattle. pigs. sheep,
goats
IMicit drugs: ihicit cultivator of cannabis
and opium poppy. mostly for CIS
consumption, limited government eradication
program, transshipment point for illicit drugs
to Western Europe
cco!
Exports: $549.9 million (f.0.b.. 1995)
commodities: oil and gas. chemicals, oilfield
equipment, textiles. cotton
partners: mostly CIS and European countries
Imports: $681.5 million (c.1.f.. 1995)
commodities: machinery and parts, consumer
durables, foodstuffs, textiles
partners: European countries
External debt: $100 million (of which $75
million to Russia)
Economic aid:
ret pient: ODA, $14 million (1993)
note: commitments, 1992-95, $1,000 million
($185 millon in disbursements): wheat from
Turkey
Currency: | manat = 100 gopik
Exchange rates: manais per US$1—4.375
(April 1996), 4.500 (April 1995), 4.168 (end
of December 1994)
Fiscal year: calendar year
Population: uninhabited: notle—American
lan: acuated in 1942 after Japanese aul
luring World War Il
by US military during World War
oned after the war: public entry
use permut only and generally
enuusts and educators: a
ind cemetery ruins are located neat
hddie of the west coust','0acd6e7f1cc963d74b5bf2c734f230261d540bb63f2d1db13a0cd1505ae056fa','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2361f5c64ebe2d105497145a9b5e22128a1192ac715fb95ffed5e74bf13af84b',1996,'BD','Bangladesh','people-and-society',80,'Population: | 23.062.800 uly 1996 est)
Age structure:
0-14 years) 39% (male 24.434.219: female
3.446.359)
15-64 years: SS (male 36.607.942. female
44. 603.628)
65 vears and over: 3% (male 2.175.017:
female 1.805.635) uly 1996 est.)
Population growth rate: |. 85° (1996 est.)
Birth rate: 30.5 births/1.000 population
(1996 est)
Death rate: |) 2!) deaths/1.000 population
(}996 est.)
Net migration rate: -0.78 migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.05 maletsi/temale
under 15 vears: 1.04 male(s)/female
15-64 years: 1.06 malets)/temale
65 vears and over: 1.2 maletsVtemale
all ages: 1.4% male(s)/female (1996 est.)
Infant mortality rate: 102.3 ¢ aths/1.000
live births (1996 est.)
Life expectancy at birth:
total population. SS.86 years
male: S602 years
female: 55.69 years (1996 est.)
Total fertility rate: 3.57 children born/
woman (1996 est.)
Nationality:
noun, Bangladeshis)
adjective: Bangladesh
Ethnic divisions: Bengali 98°. Biharis
250.000. tribals less than | million
Religions: Muslim 83%. Hindu 16%.
Buddhist. Christian. other
Languages: Bangla (official), English
Literacy: age 15 and over can read and
write (1995 est.)
total population: 38.1%
male: 49.4%
female: 26.1%','ebf7028a209a102c2f2b75e8426d49b2fc038c3ca889cf77bbeacec2089887a8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46b89648a64f07f5c1fcfc9c8afdf59cae87f22018f48afe3c2f98b9c5cf2cec',1996,'BB','Barbados','people-and-society',85,'Population: 257.030 (July 1996 est.)
Age structure:
0-14 years: 24% (male 31.263: female
29.822)
15-64 vears: 66% (male 83.565: female
86.697)
65 vears and over: 10% (male 9.929; temale
15,754) (July 1996 est.)
Population growth rate: 0.26 (1996 est.)
Birth rate: 15.29 births/!.000 population
(1996 est.)
Death rate: &.2] deaths/1.000 population
(1996 est.)
Net migration rate: -4.49 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 vears: 1.05 male(s)/temale
15-64 vears: 0.96 male(s)/female
65 vears and over: 0.63 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 18.7 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 74.35 years
male; 71.65 years
female: 77.25 years (1996 est.)
Total fertility rate: |.78 children born/
woman (1996 est.)
Nationality:
noun, Barbadian(s)
adjective: Barbadian
Ethnic divisions: Atrican 80. European
4%, other 16%
Religions: Protestant 67% (Anglican 4°.
Pentecostal 8%. Methodist 7%. other 12%).
Roman Catholic 47, none 17%, unknown
3%, other 9% (1980)
Languages: English
Literacy: age 15 and over has ever attended
school (1995 est.)
total population: 97.4%
male: 98%
female: 96.8%','13b81fdc9fac0ea878633460ae14b69f1e3ce097bf8bd06d4bcd50345adf37d6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93149f424e0fd4417633392d8b06108679ce392ceca8051a025b9a293775e26f',1996,'MG','Madagascar','people-and-society',91,'Population: uninhabited
Population: uninhabited
Covernment
Name of country:
ocal short form: Nes ¢
Data code: GO
I.pe of government: [i
siministered ry ( !
Republic. resident in Reun
Capital: »
Reunion
Independence:
Flag: the | i |
Lconomy
Lconomic overview:
Population: uninhabited
Population: Ni6.4
Age sructure:
Population growth rate:
Cirth rate: 19.02) birt!
) ’
Death rate: 9 6° ith
prar
Nel migration rate:
Sex ratio
Infant mortality rate:
Life expectancy at birth
; /
Lotal fertility rate
Nationalits
hk, "
K azah
Ethnic divisions: k
RR | h
ch |
Religions: Vii |
Languages: Kazak (Q
} La | }
RR | hl il) |
c*tiil maton) Ll. 1’
ise the twe
>the Aral Sc
i! Gmrvink
| ,
»
; ;
<j
WUfy ~!
(4: female
1)s'' Cl ¢
''
-
5 IU) ¢ )
peopl j
roy) ihn
ant 1.000)
’
‘
|
i\\ it
ur
i | (HH)
'' ;
t; ''
Cort} hoX
’ , ,
} | |
hire {
Kazakstan (continued)
literacy: a S al er can read and
t,overnment
Same of country:
Rept
N ks
Respubliikasy
A, 4 ‘ = Repub ,
Duta code: |
biype of government:
( apital
ii sive divisions y ooPilv stu
eT
} \\ln il
\\ “ ©) \\
‘ (his
) \\1 } ta
i " {) ysl mm GC PiVay
! } {) TUOIRT
i) {) i
) gstan
() |
r . ) ! C)iyivay
‘) borghay
vy ‘| javehan
Independence U1 (from th
\\ totaal hold i\\ Tt ( Da f)
onstitution sj . WR bey
) | \\ is!
Leval system
Surlrage
kvxecutive branch
| ‘\\ \\
RBAY \\ } ry tt)
\\ So 1
! voli
) } l iM
iy rechon
"y he held
\\ ] \\
VR] t\\ ) UnOp Dy 1, met
t NAZARBAYEV s term wa
THD by matron ice
r \\pri! yQUus
Prime Minister
kK A/SHEGELDIN (since 12 Octebes
Deputy Prime Ministers
95)
Nigmatzhan ISINGARIN (since 12 October
1994) were appointed by the president
cabmet: Council of Ministers was appointed
by the prime minister
note: Presadent NAZARBAYEV has
expanded his presidential powers by decree
only he can imitiate constitutional
amendments. appoint and dismiss the
government, dissolve parliament, call
referenda at hie discretion, and appoint
administrative heads of regions and cities
Legislative branch: bicameral Parliament
Senate: elections (indirect) last held 5
December 1995 (neat to be heid NA 1999)
results —percent of vole by party NA
secats—1 47 total) independent * State
officials 25. progovernment parties 11. other
2. vacamt Y¥ tof which 7 are to be
nomunated by the president}
Vayilis: elections last held 9 Decembes and
>3 December 1995 (next to be hela NA)
percent of vote by partly NA: sects +16
total) seats by party NA: note - 172
candidates were forwarded by partes and
~woctal organizations and 113 candidates were
independents
Judicial branch: Supreme Court
Political parties and leaders: AL ASH
party. People''s Unity Party (PUP. was Union
\\kKhan BIZHANOYN
chairman, Democratic Party. Tulegen
JZHUKEYEYV and Altyvabek
SARSENBAYEY. coctarmen.: Peop.. s
Congress of Av zakstan (PCR). Olvhas
SULL .MENOVY., chairman: Socialist Party
of Kazakstan (SPK. former Communist
Party). Petr SVOIK. chairman. Communist
Party. Bandabek TULEPBAYEYV: National
Democratic Party. Kamal ORMANTAYEN
\\ZAT party. Khasen KOZH
\\AHMET. chairman. Contederation of
Ir de Unions of the Republic of Kazakstan
Peasant Union of the Republic Kazakstan
KPI Slavic Movement LAD. Aleks: adra
DOKUCHAYEVA, chamnman: Party to.
Soctal Justice
of People s Unity)
charm
ind Economic Revival
lPagibat Social Democratic Party, Dos
KUSHIMOVYV., cochairman. People''s
Cooperative Party, Umirzak SARSENOVN
chairman, Organization of Veterans
Republican Party
(ther political or pressure groups:
Independent Trade Union Center, Leonid
SOLOMIN. president: Kazakstani-American
Bureau on Human Rights, Yes geniy
ZHOVTIS. executive director, Democratic
Committee on Human Rights, Independent
Miners Union
International organization participation:
ASDB. CCC, CIS. EBRD, ECE. ECO
ESCAP. IAEA, IBRD. ICAO. IDA, IDB
IFC. ILO. IMF. IMO. Intelsat. Interpol, 101
Itt. NAC, OIC, OSCE. PFP. UN
UNCTAD. UNESCO, UPU. WHO. WIPO.
WMO. WToO. WTrO (observer)
Diplomatic representation in US:
chief of mission: Ambassador Bolat
NURGALIYEV
chancery: (temporary) 3421 Massachusetts
Avenue. NW. Washington, DC 20008
telephone: |1| (202) 333-4504 through 4507
FAX: [1] (202) 333-4509
LS diplomatic representation:
chief of mission: Ambassador A. Elizabeth
JONES
embassy: 99/97 Furmanova Street. Almaty.
Republi of Kazakstan 480012
mailing address: use embassy street address
telephone: |7| (3272) 63-39-08, 63-13-75,
63-24-96
FAN |7] (3272) 63-29-42
¢ sag: shy blue background representing the
endless sky and a gold sun with 32 rays
soaring above a golden steppe eagle in the
center. on the hoist side ns a “national
ormamentation im vellow
Population: uninhabited
C,overnment
Name of country:
cntiemal lone torm: none
entiomal short tom Kingman Rect
Data code: KO
Ivpe of government: unincorporated
i the US admimmicred bw the US
‘\\ scver. ors awash the major, of
“) toes mot usable and ts
‘ apital: none. admunistered trov
VM ashington. 1X
Flag: the Sag of the US 1s used
Population: 80.919 uly 1996 est.)
Age structure:
0-14 vears’ NA
15-64 vears: NA
65 years and over: NA
Population growth rate: | 89° (1996 est)
Birth rate: 27.13 birthy/1.000 popusanen
(1996 est.)
Death rate: 79 deaths/!.000 population
(1996 esi.)
Net migration rate: 0.3) migrantis)/ 1.000
population (1996 est)
Sex ratio:
at birth: NA maleisWfemale
under 15 vears: NA meleisWtemale
15-64 vears: NA maleisvViemale
65 vears and over: NA ma''eisWtemale
all ages: NA maletsWilemale
Infant mortality rate: $2.9 deaths’) 000
live births (1996 esi)
Life expectancy at birth:
total population, 62.02 vears
male: GO.25S years
female: 64.03 years (1996 est.)
Total fertility rate: 3.2) children born
woman (1996 est.)
Nationality:
noun: 1-Karvbaty (singular and plural)
adjective: 1-Kantbati
Ethnic divisions: Micronesian
Religions: Roman Catholic $2.6
Protestamt (Congregational) 40.99 . Seventt
Day Adventist. Baha’). Church of God
Mormon 6° (TORS)
Languages: English (official). Gilbertese
Literacy: NA
eel
Population: 45.48-
Age structure:
{} /4 Vcodar,
)]
PSV X16 }
sh ( ws and ¢ ci fy
female 1.688.171) (Jul
Population growth rate:
Birth rate: 16.24 |
(1996
Death rate: 5 6¢
"
Net migration rate:
’ heli
Sex ratio:
j
Infant mortality rate
Life expectancy at birth
otal fertility rat
Nationality
''
"
Ethnic divisions
MM) ¢
Religions: (
(
the H
Languages: K
Literacy:
pollutse nin jay
4i0n trom the discha
arly
e (nang
ered Species, Environme
Modification. Hazardous W:
Pest Ban, Ozone Layer Prote
‘ \\
aid
Lil
Korea, South (continued) eats - (299 total) NKP 139. NCNP 79, ULD comparable with levels in the pooret
40. DP 15. independents 16 countnes of Africa and Asia. Today its GDP
Judicial branch: Supreme It, jUStICs per capita is nine times India’s, 14 times
ippointed by the president subject to the North Korea''s, and already up with the
sent of the Natronal Assembly lesser economies of the European Union
Political parties and leaders: Phis success has been achieved by a unique
j party: New 7 combination of authontuoan government
iovernment .
KIM Yong-sam preside yuidance of what ts at bottom an essentially
Name of countrys: atte
n- Unit beral Democratic Party entrepreneurial process. The government has
KIM Chong-p ‘il. presidet sponsored large-scale adoption of techno!
cratic Party (DP). KIM Won-ki and management trom Japan and other
nan and CHANG Ul-pyong. co modem nations: has successfully pushed the
in. National Cong: 0 . development of export industries while
Politics (NCNP). KIM) Tae-chung. presidet encouraging the import of machinery and
Other political or pressure groups: Korea wilerials at the expense of consumer goods
ind has pushed its labor force to a work
eHort seldom matched anywheie even in
wartime. Real GDP grew by an ave
IYS6-91. then paused to a
livisions: veational Council of thor Unions (992-93 only t nove back up 1
Korea 1994 and 9 |‘ With a mosh higher
of Korean standard of living and with a considerabl
ochation easing of authoritarian contro the work
International organization participation: pace has softened. Grow:
PEC. ASDB. CCC. CP. EBRD
FAO. G-77, TARA, IBRD. ICAO
ICFTU. ICRM. IDA. IFAD. TK
S.ILOL IME. isiO. Intelsat. Inter path
lOO. TOM. ISO. ITU. MINURSO. OAS GDP:
OSCE ¢partner). UN. UNCTAD Dillion
UNIDO. UNMOGIP. UNOMIG GDP real growth rate: 4
WHO. WIPO. WMO. WToO GDP per capita: S$) 3.000
(FDP composition by sector:
Independence
Nuthonal holidays
Diplomatic representation in US:
idor PAK K
)
Inflation rate (consumer prices)
;
Labor force:
ts diplomatn representation { nemploy ment rate
Budget
Industries
Industrial production growth rat
blectricity
Avriculture:
branch Lconomy
lé« 4 |
Kconomic overview: \\ it Exports
Dra | | \\
Imports: $135.1 bilivon (cif. 1995)
partners: US 19%, Japan 14%, EU 13°
f
commodities: machinery, electronics and
electronic equipment, oil, steel, transport
equipment. textiles, organic chemicals. grains
partners: Japan 24% , US 22%, EU 13°
;
External debt: $7
Economic aid: SNA
~
billion (1995 est)
Currency: | South Korean won (W) = 100
chun (theoretical)
Exchange rates: South Korean won (W) pet
USSi—787.27 (January 1996). 771.27
1995) 803.45 (1994). 802.67 (1993)
(1997) 733 38 (199])
Fiscal vear: calendar year
fransportation
Railways:
total: 3AOL km
vandard Vali , OX] All i 135 i Value
(S60) him electntied)
narrow gauge. ZO km 0.762-m eaug
Highways:
Wal. 61.296 km
paved: SVYIS km Gincluding 1.550 kn
CAPT SSWa\\S/)
unpaved. 9.378 km (1993)
Waterways: |.609 km. use restricted
small native craft
Pipelines: petroleum products 455 kn
Ports: Chinhae. Inch on. Kunsan. M
Mokpo Pohang. Pusan. Ulsan. ¥
Merchant marine:
128 ships (1.000 GRI
> YX1 GRT/YS OXY DWI
j noe bulb ; nye vl
I | | i")
\\irports
™~
Heliports: 2 Ws','272bae110b4acc318dc26f68116b6e820ac5a3ad9cef16bf83fe63f4ff218305','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d523ee8df029cb9f716975a3c04cb4b31b81a5f18fd27e00b8818ea9601322ad',1996,'BY','Belarus','people-and-society',98,'Population: 10.415 0°53 0) wt
Age structure:
hdd years: 2 le fy 49
, OVO_10]
,5 ih UK),
6H5 years and over : male 429.874
temale RSAS.740) (duly 1996 «
Population growth rate: 0. 90H ev
Birth rate: |2.15 births} .000 population
(1996 est.)
Death rate: | 3.64 deaths/ 1.000 population
(1996 est)
Net migration rate: 45) migrantis)/ 1.000
population (1996 est
Sex ratio:
at birtn, 1.08 malets)/temale
under 15 vears. 1.04 malets/temak
15-64 vears: 0.94 male(si/temale
65 vear. and over: O.AX8 maletsi/temale
all ages: WSY male(sViemale (1996 est)
Infant mortality rate: | 3.4 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population ON.S7 vears
male: 63.2 years
female: 74.21 years (1996 est.)
lotal fertility rate: | 69 Children born
woman (1996 est
Nationality:
noun: Belarusiant(s)
adjective: Belarusian
Ethnic divisions: Byelorussian 77.9"
Russian 13.20. Polish 4.10. Ukramian
29%. other 1.9
Religions: Eastern Orthodox 60 . other
Gncluding Roman Catholic and Muslim,
40% (early 199s
Languages: Byclorussian. Russian. other
Literacy: age 1S and over can read and
write (1989 est)
hntal population. 9S
male, 9
female: 97";
Population V4) duly P99
Avge Mructure
; } peers ''
4 st) ate
’ *
i { fyi)
| ] ™ } pio
Population growth rate: | Wy est
Birth rate: 1) sulation (1996
Ikauth rate OO ponulatron
Net migration rat ti) 1)
Sen rato
''
hal
ty esi
infant mortality rat } death 1 OOD hive
Life expectancy at birth:
js roe
lotal fertility rate OY children bom
by
Nationality:
‘ Bel
adjective: Belgian
Ethnic divisions: Fleming 55‘°. Walloon
33. mixed or other 124
Religions: Roman Catholic 75°¢. Protestant
or other 25%
Languages: Dutch S6‘c. French 32°.
German I‘. legally bilingual 11° (divided
along ethnic lines)
Literacy: age !5 and over can read and
write (1980 est.)
total population: 9
male: NAG
female: NAG
Covernment
Name of country:
conventional long form: Kingdom ot','b5a28f4e452f851e2a9bec72d61aea2a3018e626d908f30bb98d8b9c16bcb31d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('483958624ab72ace93daa80ed79c3463ef2be88cd23ea14175e7f57e7deb9de9',1996,'BE','Belgium','people-and-society',102,'conventional short form: Belgium
local long form: Royaume de Belgique
local short form: Belgujue
Data code: BI
Type of government, constitutional
monarchy
Capital: Brussels
Administrative divisions: 9 provinces
(French: provinces, singular—province:
Flemish: provincien, singular—provineie }.
Antwerpen, Brabant. Hainaut, Liege.
Lamburg. Luxembourg. Namur, Oost
Viaanderen. West-Viaanderen
note. constitutional retorms passed by
Parliament in 1993 increased the number of
provinces to 10 by splitting the province of
Brabant into two new provinces. Flemish
Brabant and Walloon Brabant
Independence: 4 October 1830 (from the
Netherlands)
National holiday: National Day. 21 July
(ascension of King LEOPOLD to the throne
m IN31)
Constitution:
14 July 1993) parhament approved a
_
February 1831. last revised
constitutional package creating a federal state
Legal system: civil law system influenced
by English constitutional theory: judicial
review of legislative acts, accepts
compulsory IC) yursdiction, with
resery allons
Suffrage: |8 years of age. universal and
compulsory
Executive branch:
chiel of state King ALBERT II (since 9
\\ugust 1993) 0s a constitutional monarch
head of government. Prime Minister Jean
Luc DEHAENE (since 6 March 1992) was
appornted by the king and then approved by
Parhament
cabinet: Cabinet ts appointed by the king
and approved by Parhament
Legistative branch: bicameral Parliament
Senate (Flemish—Senaat, F rench—Senat).
elections last held 21 May 1995 (next to be
held by the end of 1999): results—percent of
vote by party NA: seats—471 total. 40
directly elected: 31 will be indirectly elected
al a later date) CVP 7. SP 6. VLD 6. VU
2. AGALEV |. VB 3. PS 5. PRL 5. PSC 3.
ECOLO 2: note—betore the 1995 elections.
there were 184 seats
Chamber of Deputies Flemish—Kamer van
Volksvertegenwoordigers, French—Chambre
des Representants): elections last held 21
May 1995 (neat to be held by the end of
1999): results—CVP 17.2. PS 11.9%. SP
12.6%. VLD 13.1%, PRL 10.3%, PSC 7.7%,
VB 7.8%. VU 4.7%, ECOLO 4.0%.
AGALEV 4.4. FN 2.3%: seats—1 150 total)
CVP 29. PS 21. SP 20. VLD 21, PRL 18.
PSC 12. VB 11. VU 5. ECOLO 6,
AGALEV 5. FN 2: note—betore the 1995
elections, there were 212 seats
Judicial branch: Supreme Court of Justice
(Flemish—Hot van Cassatie, French—Cour
de Cassation). judges are appointed for life
by the Belgian monarch
Political parties and leaders: Flemish
Christian Democrats «CVP—Christian
People''s Party). Johan VAN HECKE.
president, Francophone Christian Democrats
(PSC —Social Christian Party), Gerard
DEPREZ. president: Flemish Socialist Party
(SP). Louis TOBBACK, president:
Francophone Socialist Party (PS). Philippe
BUSQUIN, president, Flemish Liberal
Democrats (VLD). Herman DE CROO.
president; Francophone Liberal Reformation
Party (PRL). Louis MICHEL. president:
Francophone Democratic Front (FDF).
Olivier MAINGAIN, president; Volksunie
(VU), Bert ANCIAUX, president: Vlaams
Blok (VB). Karel DILLEN, chairman:
National Front (FN), Daniel FERET.
president: AGALEV (Flemish Greens). no
president. ECOLO (Francophone Greens). no
president; other minor parties
Other political or pressure groups:
Christian and Socialist Trade Unions.
Federation of Belgian Industries: numerous
other associations representing bankers.
manutacturers, middle-class artisans, and the
legal and medical professions: various
organizations represent the cultural interests
of Flanders and Wallonia: various peace
groups such as the Flemish Action
Committee Against Nuclear Weapons and
Pax Christi
International organization participation:
ACCT, AfDB. AG (observer). AsDB
\\ustralia Group, Benelux. BIS. CCC. CE.
CERN. EBRD. ECE. EIB. ESA, EU. FAO.
G- 9. G-10, IADB. TIAEA, IBRD, ICAO.
ICC. ICETU, ICRM. IDA, TEA, IFAD. TPC.
IFRCS. ILO, IMF, IMO. inmarsat. Intelsat.
Interpol, LOC, TOM. ISO, ITU, MINURSO.
57
MTCR. NACC. NATO. NEA, NSG. OAS
(observer), OECD. OSCE. PCA, UN.
UNCRO,. UNCTAD. UNESCO. UNHCR.
UNIDO. UNITAR, UNMOGIP.
UNPROFOR. UNRWA, UNTSO. UPU
WCL. WEU. WHO. WIPO. WMO. WToO.
WTrd, ZC
Diplomatic representation in US:
chief of mission: Ambassador Andre ADAM
chancery: 3330 Gartield Street NW.
Washington. DC 20008
telephone: |1| 4202) 333-6900
FAX: {1} (202) 333-3079
consulate(s) general: Atlanta, Chicago. Los
Angeles. and New York
US diplomatic representation:
chief of mission: Ambassador Alan J
BLINKEN
embassy: 27 Boulevard du Regent. B- 10K)
Brussels
mailing address: APO AE 09724, PSC 82.
Box 002. Brussels
telephone: (32) (2) SO8-2111
FAX: 132] (2) St1-2725
Flag: three equal vertical bands of black
(howst side). yellow. and red: the design Was
based on the flag of France','cbbb41a371f24c14bac08a30563f11dd2bfc5177b0dda44bb17814ce61dec5b4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15df94b46d8b2c7031a3a6a941fa733706c51b1a99836a491652e631d04b4aba',1996,'BZ','Belize','people-and-society',108,'Population: 219.296 uly 1996 est.)
Age structure:
0-14 years: 48% (male 48.291; female
46.451)
15-64 vears: S¥% (male $9,132: female
$7,498)
65 vears and over: 4% (male 3.881. temale
4.043) uly 1996 est.)
Population growth rate: 242° (1996 est.)
Birth rate: 32.8 births/!.000 population
(1996 est.)
Death rate: $5.73 deaths/1.000 population
(1996 est.)
Net migration rate: -2.89 migrant(sy/ 1.000
population (1996 est.)
Sex ratio:
at jurth: 1.05 maletsWfemale
under 15 vears: 1.04 maletsViemale
15.64 years: 1.03 maleisWfemale
65 vears and over: 0.96 maleisifemale
all aves: 1.03 maletsWtemale (1996 est.)
Infant mortality rate: 43.9 deaths/).000
live births (1996 est.)
Life expectancy at birth:
total population, 68.53 years
mine? O68 years
female: 70.58 years (1996 est.)
Total fertility rate: 4.12 children born/
woman (1996 est.)
Nationality:
noun. Belizeanis)
adjective: Belizean
Ethnic divisions: mestizo 44%. Creole 30%.
Maya 11%. Gantuna 7%. other 8%
Religions: Roman Catholic 62%, Protestant
Wi (Anglican 12%. Methodist 6%.
Mennenite 4%, Seventh-Day Adventist 3%.
Pentecostal 2%. Jehovah''s Witnesses 1%.
other 2%). none 2%. other 6% (1980)
Languages: English (official). Spanish.
Mayan. Ganfuna (Canb)
Literacy: age 14 and over has ever attended
school (1991 est.)
total population: 70.3%
male: 70.3%
female: 70.3%
Gover wment
Name of country:
convencional long form: none
conventional short form: Belize
former: British Honduras
Data code: BH
Type of government: parliamentary
democracy
Capital: Belmopan
Administrative divisions: 6 districts, Belize.
Cayo, Corozal, Orange Walk. Stann Creek.
Toledo
Independence: 2! September 1981 (from
UK)
National holiday: Independence Day. 2!
Sc ptember (1981)
Constitution: 2! September 198!
Legal system: English la»
Suffrage: 18 years of age: universal
Executive branch:
chief of state Queen ELIZABETH II (since
6 February 1952). a hereditary monarch. ts
represemted by Governor General Sir Colville
YOUNG (since 17 Noveniber 1993). who,
according to the constitution, must be a
Belizean, was appointed by the queen
head of government: Prime Minister Manuel
ESQUIVEL (since July 1993) was appointed
by the governor general: Deputy Prime
Minister Dean BARROW (since NA 1993)
cabinet: Cabinet was appointed by the
governor general on the advice of the pnme
minister
Legislative branch: bicameral National
Assembly
Senate: consists of an erght-member
appointed body. five members are appointed
on the advice of the prime minister, two on
the advice of the leader of the opposition,
and one after consultation with the Belize
Advisory Council (this council! serves as an
independent body to advise the governor
general with respect to difficult decisions
such as granting pardons, commutations.
stays of execution, the removal of justices of
appeal who appear to be incompetent, etc.)
National Assembly: elections last held 30
June 1993 (neat to be held NA June 1998),
results - percent of vote by party NA;
seats—( 28 total) PUP 13 UDP 15
Judicial branch: Supreme Court. the chet
justice ts appointed by the governor general
on advice of the prime minister
Political parties and leaders: People''s
United Party (PUP). George PRICE.
Florencio MARIN. Said MUSA; United
Democratic Party (UDP). Manuel
ESQUIVEL. Dean LINDO. Dean
BARROW. National Alliance for Belizean
Rights, Philipp GOLDSON
Other political or pressure groups: Society
for the Promotion of Education and Research
(SPEAR), Assad SHOMAN, United Workers
Front, leader NA
International organization participation:
ACP. C. Cancom, CDB. ECLAC, FAO, G-
77, LADB. IBRD. ICAO, ICFTU, ICRM.,
IDA. IFAD, IFC, IFRCS, ILO, IMF, IMO.
Intelsat (nonsignatory user). Interpol. IOC.
1OM (observer), ITU, LAES. NAM, OAS.
OPANAL. UN, UNCTAD. UNESCO.
UNIDO, UNMIH. UPU, WCL. WHO,
WMO, WTrO
Diplomatic representation in US:
chief of m*‘on: Ambassador Dean R.
LINDO
chancery: 2535 Massachusetts Avenue NW.
Washington, DC 20008
telephone: |1} (202) 332-9636
FAX: [1] (202) 332-6888
consulate(s) general: Los Angeles
consulaie(s): New York
US diplomatic representation:
chief of mission: Ambassador George
Charles BRUNO
embassy; Gabourel Lane and Hutson Street,
Belize City
mailing address: P.O. Box 286, Belize City:
APO: Unit 7401. APO AA 34025
telephone: (S01 (2) 77161 through 77163
FAX: {S01} (2) 30802
Flag: blue with a narrow red stripe along the
top and the bottom edges: centered is a large
white disk bearing the coat of arms, the coat
of arms features a shield flanked by two
workers in front of a mahogany tree with the
related motto SUB UMBRA FLOREO (I
Flowrish in the Shade) on a scroll at the
bottom, all encircled by a green garland
al
Population: 5.709.529 (July 1996 est
Age structure:
0-14 vears: 48% Omale 1.476.531: temale
1.367.394
15-64 years: SO? (male 1.349.386: temale
| J80.5])
65 vears and over: 2% (male 60.030; temate
78.937) duly 1996 est)
Populaten growth rate: 332°) (1996 est)
Birth rate: 46.76 birthy/ 1.000 population
1996 est.)
Death rate: 13.53 deaths/1.000 population
1996 est)
Net migration rate: 0 migrant(s)/1) 000
population (1996 est.)
Sex ratio:
at birth. 1.038 maletsvtemale
muder 1) years: VOL maletsVtemale
15-64 years: O91 maletsVtemale
65 years and over, 0.79 male(sWVtemale
ail aves: OYS maletsWtemale (1996 est.)
Infant mortality rate: 105.) deaths/1.000
live births (1996 est.)
Life expectancy at birth:
tatal population: 52.69 years
male. S074 years
female: 54.7 vears (1996 est.)
Total fertility rate: 6.64 children born
woman (1996 est.)
Nationalitv:
noun. Beninese (singular and plural)
adjective: Beninese
Ethnic divisions: Airican 99° (42 ethnic
giowps. most important being Fon. Adja.
Yoruba, Barniba). Europeans 5.500
Religions: indigenous beliefs 70°. Muslim
IS, Christian 15%
Languages: French (official), Fon and
Yoruba (most common vernaculars in south).
tribal languages (at least six major Ones in
north)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 37%
niale: A8.7%
female: 25.8%
C;,overnment
Name of country:
conventional long form: Republic of Benin
conventional short form: Benin
local long form: Republique du Benin
local short form: Benin
former: Dahomey
Data code: BN
Type of government: republic under
multiparty democratic rule dropped
Marxism-Leninism December 1989:
democratic reforms adopted February 1990:
transition to multiparty system completed 4
\\pril 1991
Capital: Porto-Novo
Administrative divisions: 6 provinces.
Atakora, Atlantique. Borgou. Mono, Queme
Jou
Independence: | August 1960 (from France)
National holiday: National Day. | August
(990)
Constitution: 2 December 1990
Legal system: based on French civil law and
customary law: has not accepted compulsory
ICJ jurisdiction
Suffrage: |X years of age: universal
Evecautive branch:
chief of state and head of eovernment
President Matheu KEREKOU (since 4 April
1996) was elected for a five-yeer term by
popular vote: election last hig TS March
1996 (next to be held March 2001): results
Mathieu KEREKOU 52.49%. Nicephore
SOGLO 47.51%
cabinet: Executive Council, appointed oy the
president
Legisiative branch: unicameral!
Vational Assembly (Assemblee Nationale)
elections last held 28 March 1995 (next to
be held NA): results —percent of vote by
party NA: seats—183 total) Renaissance
Party and allies 20. PRD 19, FARD
\\LAFIA 10. PSD 7, NCC 3. RDI
VIVOTEN 3, Communist Pariy 2, Alliar:
Chameleon 1, RDP 1, ADP 1, other |:
Judicial branch: Supreme Court (Coui
Supreme )
Political parties and leaders: as of
February 1996. more than 80 political parties
were officially recognized: the following are
represented in the National Assembly:
Alliance of the National Party for
Democracy and Development (PNDD) and
the Democratic Renewal Party (PRD). Pascal
Chabi KAO: Action for Renewal and
Development (FARD-ALAFIA). Mathieu
KEREKOU: Alliance of the Social
Democratic Party (PSD) and the National
Union for Solidarity and Progress (UNSP).
Bruno AMOUSSOUL: Alliance Chameleon:
Alliance tor Democracy and Progress (ADP).
Adekpedjon AKINDES: Alliance tor Social
Democracy (ASD). Robert DOSSOU:
Assembly of Liberal Democrats tor National
Reconstruction (RDL) Severin ADJOVI:
Communist Party of Benin. Pascal
FATONDII. First Secretary: Our Common
Cause (NCC). Albert TEVOEDIJRE: Rally
for Democracy and Progress (RDP): The
Renaissance Party. Nicephore SOGLO
International organization participation:
ACCT. ACP, AIDB. ECA, ECOWAS.
Entente. FAO. FZ. G-77, IBRD. ICAO.
ICFTU, ICRM. IDA, IDB. IFAD. TFC.
IFRCS. ILO. IMF. IMO. Intelsat. Interpol.
IOC. ITU. NAM, OAU. OIC. UN,
UNCTAD. UNESCO, UNIDO. UNMIH.
UPL. WADB. WCL. WETU. WHO. WIPO.
WMO. WToO
Diplomatic representation in US:
chief of mission: Ambassador Lucien Edgar
TONOUKOUIN
chancery: 2737 Cathedral Avenue NW.
Washington, DC 20008
telephone: {1| (202) 232-6656. 6657. 6658
FAX: {1} (202) 265-1996
US diplomatic representation:
chief of mission: Ambassador John M
YATES
embassy: Rue Caporal Bernard Anan
Cotonou
mailing address: BP. 2012. Cotonou
telephone: (229) 30-06-50, 30-405-13, 30-17
y)
FAX: [229] 30-14-39, 30-19-74
Flag: two equal horizontal bands of yellow
(top) and red with a vertical green band on
the hoist side','12decfe514433d134e45d1c3df194b2a956e0f00413f3ebeac05efe30ba735af','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5fe0e74dbca6f6bc875fb2cde92c478d3ca95f14b4716af1b9c9ba0428ff849',1996,'BM','Bermuda','people-and-society',115,'Population: 62.099 (July 1996 est)
Age structure:
0-14 vears: NA
15-64 vears: NA
65 vears and over: NA
Population growth rate: 0.767 (1996 est.)
Birth rate: 15 births/1.000 population (1996
est.)
Death rate: 7.3 deaths/!.000 population
(1996 est.)
Net migration rate: -0.13 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: NA male(s Vtemale
under 15 vears: NA male(sW/temale
15-64 vears: NA maletsVtemale
65 vears and over: NA male(s)/female
all ages: MA malet(swtemale
Infant .nortality rate. | 3.16 deaths/!.000
live virths (1996 est.)
Life expectancy at bis iis:
total population: 75.03 years
male: 73.36 years
female: 76.97 years (1996 est.)
Total fertility rate: 1.8 children born/
woman (1996 est.)
Nationality:
noun: Bermudian(s)
adjective: Bermudian
Ethnic divisions: black 61°°. white and
other 39%
Religions: Anglican 37°7. Roman Catholic
14°, African Methodist Episcopal (Z10n)
10%. Methodist 6%. Seventh-Day Adventist
S$. other 28%
Languages: English
Literacy: age 15 and over can read and
write (1970 est.)
total population: 98%
male: IS
female: 9%
(,overnment
Name of country:
conventional lone form: none
conventional short form. Bermuda
’ uta code: BD
Type of government: dependent territory of
the UK
Capital: Hamilion
Administrative divisions: 9 parishes and 2
mumecipalities*, Devonshire. Hamilton
Hamilton*. Paget. Pembroke. Saint George’
Saint Georges. Sandys, Smiths
Southampton, Warwick
Independence: none (dependent ternitory of
the UK)
National holiday: Bermuda Day. 24 May
Constitution: 8 June 1968
Legal system: English law
Suffrage: 18 years of age: universal
Executive branch:
chief of state: Queen ELIZABETH II (of the
United Kingdom since 6 February 1952). a
hereditary monarch, is represented by
Governor Lord David WADDINGTON
(since 25 August 1992), who was appointed
by the queen
head of government: Premier David SAUL
(since 25 August 1995) was appointed by the
governor. Deputy Premier Jerome DILL
(since | September 1995)
cabinet: Cabinet was nominaied by the
premier. appointed by the governor
Legislative branch: bicameral Parliament
Senate: consists of an 1l-member body
appointed by the governor
House of Assembly: elections last held 5
October 1993 (next to be held by NA
October 1998); results——UBP 507, PLP
467. independents 47; seats—140 total)
UBP 22. PLP I8
Judicial branch: Supreme Court
Political parties and leaders: United
Bermuda Panty (UBP). David SAUL:
Progressive Labor Party (PLP), Frederick
WADE: National Liberal Party (NLP).
Gilbert DARRELL
Other political or pressure groups:
Bermuda Industrial Umon (BIU), Ottiwell
SiMMONS
International organization participation:
Caricom (observer), CCC. ICFTU. Interpol
(subbureau), 1OC
Diplomatic representation in US: none
(dependent territory of the UK)
US diplomatic representation:
chief of mission: Ambassador Robert A
FARMER
consulate general(s): Crown Hill, 16 Middle
Road. Devonshire. Hamilton
mailine address: P.O. Box HM325.
Hamilton HMBX, American Consulate
General Hamilton, Department of State
Washington, DC 20521-5300
telephone: \\\\\\ (441) 295-1342
FAX: [1] (441) 295-1592
Flag: red with the flag of the UK in the
upper hoist-side quadrant and the Bermudian
coat of arms (white and blue shield with a
red hon holding a scrolled shield showing
the sinking of the ship Sea Venture off
Bermuda in 1609) centered on the outer halt
of the flag','d400f7f54038834d1c6c8460bd9ce0f065d0a272cbe29e45e879f33444f6cffb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a53e5f800030deb2c09ac1ba30f3584769b36061a10214960b9aaf777bc39d8',1996,'BT','Bhutan','people-and-society',119,'Population: | 822.625 uly 1996 est)
note. other estimates range as low is
HOO OOD)
Age structure:
O-14 vears. 40% (male 378.407: temale
35] 146)
15-64 vears: S6% (male 524.972: temale
106.715)
f). ears
dda
SS.081) uly 1996 est)
Population growth rate: 23
Birth rate: 38.48 birthy 1.000 population
(1996 est)
Death rate: 15.28 deaths/1.000 population
19906 est
Net migration rate: 0 migrant(s)/1.000
population (1°96 est)
Sex ratio:
at birth: VAS maletsiVtemale
wader 1S vears: 1.08 maletsvtemale
18-64 vears: 1.06 maletsi/temale
65 years and over: 1.04 maletsiWtemale
dl aves: 1.06 malets/temale (1996 est.)
Infant mortality rate: | 16.3 deaths/1.000
live births (1996 est)
i.ife expectancy at birth:
My years
ital population: 5
male: S196 vears
female. SOYS vears (1996 est.)
Total fertility rate: 5 33 children born
woman (1996 est)
Nationality:
noun. Bhutanese (singular and plural)
adjective: Bhutanese
Lithnic divisions: Bhote 50%. ethni
Nepalese 3547. indigenous of migrant tribes
1S
Religions: Lamaistic Buddhism 75%. Indian
and Nepalese-intluenced Hinduism 25%
Languages: Dzongkha (otticial), Bhotes
ecak various Tibetan dialects. Nepalese
speak various Nepalese dialects
Literacy: age 15 and ever can read and
write (1995 est.)
total j™ mulation $2.25
male. S6.2''
female: I8AG
over, 4% (male 36.304: temale
32°) (1996 est)
Population: 7.165.257 Gluiy 1996 est.)
Age structure:
O-14 vears, 39%
1. 300. 8RS)
(male 1.422.313: temale
15-64 years: 56% (niale 1.959.989: female
2.042.135)
65 years and over, SY (male US3.111.
female 196.824) uly 1996 est.)
Population growth rate: |. 82° (1996 est)
Birth rate: 32.37 births/1.000 population
(1996 est.)
Death rate: 10.75 deaths/1.000 population
(1996 est.)
Net migration rate: -3.41 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at durth: 1.05 male(sVtemale
under 15 vears: 1.02 malets)/temale
15-64 vears: 0.96 malet(si/temale
65 years and over: 0.78 malet(sy/temale
all ages: 0.97 malet(sWtemale (1996 est.)
Infant mortality rate: (7.5 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: S981 years
male. S694 years
female: 62.82 years (1996 est.)
Total fertility rate: 4.25 children born/
woman (1996 est.)
Nationality:
noun. Boliviants)
adjective. Bolivian
Ethnic divisions: Quechua 30°. Aymara
25, mestizo (mixed European and Indian
ancestry) 25%-30%, European 5% -15%
Religions: Roman Catholic 95%. Protestant
(Evangelical Methodist)
Languages: Spanish (official). Quechua
(official), Aymara (official)
Literacy: age 15 and ovei can read and
write (1995 est.)
total population: 83.1%
male: YO.S%
female: 76%','7f307f300c2708a741f26156f5d5de1032dc95eb7569d34442216128800a010a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9fe03c505549eb370e3fa8f9495411e404e37c0e5b1855edd389594f2ea724e',1996,'BA','Bosnia and Herzegovina','people-and-society',127,'Population: 2.656.240 Gluly 1996 est
a
;
| i tl chats che mie VW ''
peoplatnon |
vive ct to considerable error because of th
dislocations caused by mulitary action and
ethnic cleansing
Age structure:
0-14 vears: 2% imale 276.530: temale
248.519)
15-64 vears: OR (male 892.807: temale
Y15_686)
65 veors and over: A2G% (male 133.08)
female 189.617) Uuly 1996 est)
Population growth rate: -2. 54° (1996 ex
Birth rate: 6.34 births 1.000 population
(1996 est)
Death rate: 15.92 deaths/1.000 populat
{1996 est)
Net migration rate: -| 8 52 mugrantis)
population (1996 est)
Sex ratio:
at birth: 1.407 maletisVtemale
under 15 vears: 1.11 maletsWtemake
15-64 vears. O.YS maletsVtemale
HS vears and over, 0.7 maleisWilemak
all ages: 0.96 maleisiWtemale (1996 ext
Infant mortality rate: 43.2 deathy) 000
ive births (1996 es
Life expectancy at birth:
Mart population. XO 1] veas
male: S116 vears
foemaic: 61.389 years (1996 est
Tota! fertility rate: | children born wou
1YUH est
Nationality:
noun: PRosmants). Herzego
Hective. Bosman. Herzegov ima
bihnic divisions: Serh 40 Muslim 3
Croat 22 c
Religions: Mustim 40% | Orthodos
C alholnm TS Protests j 7
Languages: Serbo-C rout
Literacy: \\\\
Covernment
(,overnment mote: thc US
Republi is ii 1}
bederat iB Hy
harmed by t Nu ( \\l
1004 rema the any
Name of countrs:
he Repub K
ml Het vn
oy me B ,
Het ‘
k mut 1A. Ki
Hercegovina
m Bosna i Hercegovina
« under The new comstitutloon mitted
Davtion. Odbw on?! Novenber 19095. thy
name of the comptes will be changed tron
Ry rly ng ivf Hy Shia ana Hi r7COVOVINA I
py Bosnia and Herzego vrna and wall be
! nk up ‘1 the Muslim real beck rath mh!
the Bosnian Serb entity now ileal
Rey ulyish _, a
ann)
Data code: BK
Type of government: emerging democt
Capital: Sarajes:
Administrative divisions: (0 J
gular —opstina) Banovics. B
Luka. Brhac. Bix
Dubica Bosanska Gradish i
Krupa. Bosanski Brod. Bosan ki N
fapystinas sen
8 Al Pel 6b hi
; ko Geral rat ior}
} Bus ( {
( ( rt DD
Dongs Vehat. | | (;
: rde. Cs Vab ( (
Grude. Han P h. J hot
Geugtarine N
Independence: \\\\ \\
5
National holiday: \\ \\
( onstitution:
aH) a ’ \\7
Leval svstem
Sullrave
bxvecutive branch
} \\
l/} Biine eae
byup GANK NAN
Niyay DURAKOVK NAF
M4) Shennan KLILIK NAO
ha | KONSIC N\\A f
1994) Mirko PEL IANOVK \\
(continued)
a? thane LIUJIC-MUATOVIC (since
NAD her 1992). the collective
is Clected trom among tie
‘\\ ii) Assembly with at least two
hers Crawn trom cach of the three matin
enermmen Pome Minister Hasna
SIL RATOVNK since M0 Januar
YUH) wos
ims the collective presidency and the
‘\\ \\
; ’ ti hans
’ ! Wh? ATC
the Muslim/Croat
i 1 and Herzegovina ts
‘AK vsunce 31 May 1994
i I (cs AN i(sifkee $] Nias
ih Presa dencs | Bosnia
ty the Presraers sy of the
Rey ha‘ \\ i take place between si
he eniry ho co
1) Avreenn 14 December 14005
Legislative branch: bicameral Natior
( Vu \\ Cyr
Ni t December 1990
NA " te hy
NA SDA 44. SDS
Hitt lit iL . 1) rats
(| HSS SPM) |]
{ ( \\ (
\\ mber- Dex '' I,v0
‘
» \\ SD, 48. SDS
; ) ‘ 7 } |
} } | KO) DSS ]
pyat |
‘\\ yous
i
third j
»’ thor
bh i
vinals
’ tone
re
! ite
1) mm” Agreement
ludwial branch: S ( 1
Political parties and leaders: Civn
) } (51) Ihrohon SPANK
Ports I Hans SILAIDZK
) tmonot Bh oD)
iL ATC in Peasants Party of
Bib ASS). Stanko STISKOVK
Trock | Serhan Democratic Party
PMODIK. Liberal Bosniak
62
Organization (LBO), Muhamed FILIPOVIC:
Liberal Party (LS). Rasim KADIC, president:
Mustim-Bosniac Organization (MBO), Adil
7ZULFIKARPASIC: Panty of Democratic
Acnon (SDA). Alua ZETBEGOVIC:
Repubucan Pan, of Bosnia and
Herzegovina, Syepan KLUJIC, Serb
Democratic Panty (SDS). Radovan
KARADZIC. president. Serbian Civic
Council (SGV). Mirko PEJANOVIC
Serbian Consultative Council, Lyubomia
BERBEROV K
iSDP—tormerly the Democratic Panty of
Socmdmts CDSS, Nouaz DURAKOVIC,
president: Socialist Party of Republika
Srpska. Ziv ko RADISIC. Union of Social
Democrats (SSDB). Salm BESLAGIC.
United Lett of the Bosnian Serb Republic
ULRS). Mile IVOSEVIC. Serman Renewal
Miovement (SPO), Milan TRIVUNCIC, note
this party participated in the 1990 elections.
Social Democratic Party
but may not exit now: Party of Democratic
Changes. leader NA. note —this party
partompated mn the 1990 elections, but may
not cmt mow. Alliance of Reforma Forces of
Yugoslavia tor Bosma and Herzegovina
(SRSJ Bilt). Dr Neted APCMANOVIC
president. note - this party participated in the
1990 elections, bul may not ext now
Democrats League of Greens (DSZ). Drazen
PETROVIC. note
the 1990 elections, bul may fot cust ow,
Yugoslav United Lett JUL), CAREVIC,
Serb Liberal Party. Miodrag ZIV ANOVIC
Serb Radical Party. Serb Patriotic Party
Slavko ZUPLIANIN, Serb Homeland Party
(ther political or pressure groups: NA
International organization participation:
Ch tguest). CEL ECE. FAO, ICAO. TFAD
ILO. IMO). Intelsat (nonsignatory user
Interpol, 1OC, 10M tobserver), ITU, NAM
rmuest), OSCE. UN, UNCTAD, UNESCO
LCNIDO. UPL. WHO. WIPO. WMO. WTo®
Diplomatic representation in US:
Ambassador Sven
this party participated in
ctnet of misspon
\\LKALAI
chancery. Surte 760, 1707 L Street NW
Washington, DC 20046
telephone: (1) (202) 833-4612, S618, MOIS
FAN. (1) 202) 833-206)
consulates) eencral, New York
LS diplomatic representation:
clnet of musston: Ambassador John K
MENZIES
4301 Dyure Diakovica. Sarapevo
moline address: use street address
| 387) 171) 648-992, 445.700
«mPa
"" le rodne whe
H#S4.74%
Flag: white with a large blue shield. the
shield contamns white fleurs-de-lis with a
white diagenal band ruaning trem the upper
houst commer to the lower outer side
Population: | 40s July 1996 est
\\yec structure
‘ SJ] Al ile
> lemiile
s
; | . female
Population growth rate fy YUH) ext
Kirth rats iL ulate"
Death rate ths 1 000) ponulation
Net migration rate: | "
Se’. fatto
''
’
Prk
ful ’ i
t; WUT)
Infant mortality rate ; cathe’ 1 O00
file expectancy al horth:
lotal fertihts rate '' | al nm way
Notronatity
14 “
| j But v na
hihmes divisions: 1 ivS Aulunga
! h | ; “ Pol
K lignons behets SO). Chistian
! myuayes by tik ''S ScTsS Ulla
i tteracs ’ ul ve read and
Wal population. O88
male: SOS%G
female: SW9G','6757050f5650a4970675c54a8c6c4f6b472e6120cf98e996a5f1696584ce33cb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c32b0ff717d8d1cf8814b5b690f78e89da3bf9cc57c78dbb4a2dff3205a915a',1996,'BV','Bouvet Island','people-and-society',137,'Population: uninhabited
6§
tf
Industries: petroleum, petroleum refining.
liquefied natural gas, construction
Industrial production growth rate: |2.9°
(1987)
Electricity:
capacity: 380.000 kW
production: 1.2 uitven kWh
consumption per capita. 3.971 kWh (1993)
Agriculture: rice. cas va (tapioca).
bananas: water bullalo. pigs
Exports: $2.4 billion (f.0.b., 1994 est)
commodities: crude oil, liquetied natural gas.
petroleum products
partners: Japan 50%, UK 19%, Thailand
10%, Singapore 9% (1994 est.)
Imports: $1.8 billion (c..1.. 1994 est)
commodities: Machinery and transport
equipment, manufactured goods, tood
chemicals
partners: Singapore 29% UK 19%. US
13%, Malaysia 9%, Japan SO (1994 est)
External debt: SO
Economic aid: SNA
Currency: | Bruneian dollar (BS) = 10
cents
Exchange rates: Bruneian dollars (BS) pe:
USSI-——1.4214 Ganuary 1996), 1.4174
(1995), 1.5274 (1994). 1.6158 (1993). 1.6290
(1992), 1.7276 (1991): note— the Bruneian
dollar ts at par with the Singape re dollar
Fiscal year: calendar year','e37ff771a22a03995f4418f658c8df66d2b86b2031a4d7c26a4a1796cb70d1f2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc546e6c8e38e3750ed6641e21702b719d255ca8b78df69abcdd9fc0c10a6bd0',1996,'BF','Burkina Faso','people-and-society',144,'Population: 10.623.323 Gluly 1996 est
\\ge structure:
J i }* & 2 StS female
‘ iW
. ly iJ 1#t) ; ile
* 4
48.479
, (Wis li MO ext
, 2 ,4 ip
Population growth rate: nn
Hirth rate: 40 OL birth LULE UL ule)
VU, ost
Death rate: }9 99 deat! L
Vit,
Net migration cate: L
" *% '' ‘ Mi
Se\\ rato
infant mortality rate .
Life expectancs at birth
lotal fertility rate
Natronalits
’
bthow divisions: VI
Religions j \\I
''
languages: |
" , Ut
Literacy: ave |S and
Covernment
Same of country:
cemnventional long form: none
conventional short form: Burkina Faso
ormer, Upper Volta
Data code: U\\
Type of government: parliamentary
Capital: Ouagadougou
Administrative divisions: 30 provinces
Bam. Bazega. Bougourthba. Boulgou
Boulkiemde, Ganzourgou, Gnagna, Gourma
Houct. Radiogo. KRenedougou. Komoc
Kosst, Kourttenga. Mouhoun, Namentenga
Naoun, Oubrtenga. Oudalan, Passore, Pom
Sanguic, Sanmatenga. Seno, Sissil, Soum
Sourou, Tapoa, Vatenga. Zoundweogo
Independence: 5 August 1960 (from France)
National holiday: Anniversary of the
Revolution, 4 August (1983)
Constitution: 2 June 199!
Legal svstem: based on French civil law
Mem ahd customary law
Suffrage: none
bxccutive branch:
choft state Presademt Captain Blars«
COMPAORE (sonce 18 October 148
, _ term by pop
\\ theld NA Tk hy ")
‘ INA LY
| \\I k
K ABORT ce NA March 1994 .
( \\1
lLevestative branch
\\i \\ \\
." \\
; , \\1 i Pr ’ ‘
} \\i
ludicial branch
Political parties and leaders
’ , \\7
‘ \\1 \\ '' ‘ (
>
; (i \\PPil . 7 Midi \\ \\
} \\ K
( TM ACH of \\ )
! Li} \\ \\I NANA
(Mher political or pressure groups
International organization participation:
ACCT. ACP. AIDB. COC, ECA, ECOWAS
Eniente, FAQ. FZ. G-77. IBRD. ICAO, ICC
CETL. ICRM, IDA, IDB. IFAD, TFC
8S
IFRCS, ILO, IMF. Intelsat, Interpol, 1OC
ITU, NAM, OAL, OIC, PCA, UN,
UNCTAD. UNESCO, UNIDO, UPU,
WADB, WCL. WETU. WHO. WIPO
WMO. WTo®, WTrO
Diplomatic representation in US:
chief of mission. Ambassador Gactan R
OUEDRAOGO
2340) Massachusetts Avenue NW
Washington, DC 20008
[1] ¢202) 332-5577, 6895
‘ hrcamne ery
telephone
US diplomatic representation:
chief of misseon: Ambassador Donald J
MCCONNELI
embassy: Avenue Raoul Follerau.
Ouagadougou
mailing address: O1 B. P. 35, Ouagadougou
telephone: (226) 306723 through 306725
FAX: {226} 303890
Flag: two equal honzontal bands of red (top)
and green with a yellow five-pomted star in
the center. uses the popular pan-Atnean
colors of | thropria','fdd44e52e52c0158796684f4323e08dd565d2cc3c3b808ba2ca70909bfe3aa44','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf7d13e2ab65ecd7e17805133063c68f44d2853b5f10d620cbb3ee084f62315f',1996,'TH','Thailand','people-and-society',150,'Population: 45.975.625 (July 1996 est.)
Age structure:
0-14 years: 37% (male 8.637.102: female
8.308.282)
5-64 vears: 59% (male 13.577.232: temale
13.571.312)
S years and over: 4% (male 853.403:
female 1.028.294) July 1996 est.)
Population growth rate: |.84°¢ (1996 est.)
Birth rate: 30.01 births/1.000 population
(1996 est.)
Death rate: | 1.66 deaths/1.000 population
(1996 est.)
Net migration rate: ( migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 1S years: 1.04 male(s)/female
15-64 vears: | male(s)/female
65 vears and over: 0.83 male(s)/female
a
=)
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 80.7 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 56.14 y 2ars
male: 54.46 years
female: 57.92 years (1996 est.)
Total fertility rate: 3.83 children born/
woman (1996 est.)
Nationality:
noun: Burmese (singular and plural)
adjective: Burmese
Ethnic divisions: Burman 68‘. Shan 9°.
Karen 77. Rakhine 4&7, Chinese 347. Mon
2%, Indian 2°, other 5%
Religions: Buddhist 89°. Christian 4%
(Baptist 3°, Roman Catholic 1), Muslim
4%. animist belrets 1°C, other 2%
Languages: Buimese. minority ethnic
groups have ther own languages
Literacy: age 15 and over can read and
write (1995 est.)
total population: 83.1%
male: 88.7%
female: 77.7%
Population: 58,851,357 (July 1996 est.)
Age structure:
0-14 years: 25% (male 7,627,916; female
7,351,264)
15-64 years: 69% (male 19,994,884; female
20,576,141)
65 years and over: 6% (male 1,468,814;
female 1,832,338) (July 1996 est.)
Population growth rate: |.03°% (1996 est.)
Birth rate: 17.29 births/i 000 population
(1996 est.)
Death rate: 7 deaths/1,000 population (1996
est.)
Net migration rate: 0 migrant(s)/1,000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.8 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infont mortality rate: 33.4 deaths/1,000
live births (1996 est.)
Life expectancy at birth:
total population: 68.6 years
male: 64.89 years
female: 72.49 years (1996 est.)
Total fertility rate: 1.89 children born/
woman (1996 est.)
Nationality:
noun: Thai (singular and plural)
adjective: Thai
Ethnic divisions: Thai 75%, Chinese 14%,
other 11%
Religions: Buddhism 95%. Muslim 3.8%.
Christianity 0.5%, Hinduism 0.1%, other
0.6% (1991)
Languages: Thai. English the secondary
language of the elite, ethnic and regional
dialects
Literacy: age 15 and over can read and
write (1995 est.)
total population: 93.8%
male: 96%
female: 91.6%','8db2da70396015a3e5898dcfaab863957d6c3286f5188d57127d48f615928f41','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a5a9790cc144144cb71e5d26abc3258d9ed80043ea4b25efaffeada3789f91d',1996,'BI','Burundi','people-and-society',158,'Population: 5.943.057 (July 1996 est.)
Age structure:
U-14 vears: 47% (male 1,404,375; female
1.398.228)
15-64 vears: 50° (male 1.454.545: temale
1.527.644)
65 vears and over: 3% (male 62.955; temale
95.310) July 1996 est.)
Population growth rate: |.54‘C (1996 est.)
Birth rate: 43.02 births/1.000 population
(1996 est.)
Death rate: 15.15 deaths/1.000 population
(1996 est.)
Net migration rate: -|2.47 migrant(s)/1.000
population (1995 est.)
note: in a number of waves since October
1993. hundreds of thousands of refugees
have fled the civil strife between the Hutu
and Tutsi factions in Burundi and crossed
into Rwanda, Tanzania, and Zaire: the
refugee flows are continuing in 1996 as the
ethnic violence persists
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: | male(s)/female
15-64 vears: 0.95 male(s)/female
65 vears and over: 0.66 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 102.2 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 49.33 years
male: 48.28 years
female: 50.42 years (1996 est.)
Total fertility rate: 6.55 children born/
woman (1996 est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic divisions:
Africans: Hutu (Bantu) 85%, Tutsi (Hamitic)
14°. Twa (Pygmy) 1%
non-Africans: Europeans 3,000, South Asians
2.000
Religions: Christian 67% (Roman Catholic
62%, Protestant 5‘). indigenous beliefs
32%, Muslim 1%
Languages: Kirundi (official). French
(official), Swahili (along Lake Tanganyika
and in the Bujumbura area)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 35.3%
male: 49.3%
female: 22.5%
Population: 6.854.359 (July 1996 est.)
note: genocide and civil war in 1994 killed
more than | million Rwandans and forced
more than 2 million to flee to neighboring
countries
Age structure:
0-14 vears: 46% (male 1.582.928: female
1.573.536)
18-64 vears: 51% (male 1.734.716: temale
1.772.722)
65 vears and over: 3% (male 78.854. female
110,603) uly 1996 est.)
Population growth rate: 16.49 (1996 est)
Birth rate: 38.83 births/1.000 population
(1996 est.)
Death rate: 20.33 deaths/!.000 population
(1996 est.)
Net migration rate: 146.43 migrantis)/1.000
population (1996 est.)
note; since April 1994, more than two
million refugees have fled the civil strife
between the Hutu and Tuts: factions in
Rwanda and crossed into Zaire. Burundi. and
Tanzania: close to 800,000 Rwandan Tutsis
who fled civil strife in earlier years have
returned to Rwanda. and 90,000 of the Hutu
refugees are going home despite the
perceived danger of doing so. the ethnic
violence continues and in 1996 could
produce further refugee flows as well as
discourage returns
Sex ratio:
at birth: 1.03 male(s/temale
under 15 vears: 1.01 male(s/female
15.64 vears: 0.98 maleisVtemale
6S vears and over: 0.71 male(s)/female
all ages: 0.98 male(sVfemale (1996 est.)
Infant mortality rate: | 18.8 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 40.12 years
male: 39.72 years
female: 40.53 years (1996 est.)
Total fertility rate: 5.99 children born/
woman (1996 est.)
Nationality:
noun: Rwandan(s)
adjective: Rwandan
Ethnic divisions: Hutu 80. Tutsi 19%,
Twa (Pygmoid) 1%
Religions: Roman Catholic 65%. Protestant
9%. Muslim 1‘, indigenous beliefs and
other 25%
Languages: Ki .yarwanda (official), French
(official), Kiswahili (Swahili) used in
commercial centers
Literacy: age 15 and over can read and
write (1995 est.)
total population: 60.5
male: 69 8%
female: 51.6%','ce33ab27a4e5182212f507b9904d578446873cd07e86fc40b36c6f81a063de4d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dd706860d9957b61afb1e6175194703902177c2a1090cda8f1ed28387fff278',1996,'CM','Cameroon','people-and-society',167,'Population: |4.261.557 (July 1996 est.)
Age structure:
0-14 vears: 46% (male 3.295.924: female
3.266.429)
15-64 vears: 51% {male 3.602.037; temale
3.627.625)
65 vears and over: 3% (male 213.176:
female 256.366) (July 1996 est.)
Population growth rate: 2.89°7 (1996 est.)
Birth rate: 42.49 births/1.000 population
(1996 est.)
Death rate: 13.56 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(sVtemale
under 15 vears: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 vears and over: 0.83 male(s)/female
all ages: } male(s)/female (1996 est.)
Infant mortality rate: 78.7 deaths/} 000
live births (1996 est.)
Life expectancy at birth:
total population: 52.6 years
male: 51.55 years
female: 53.68 years (1996 est.)
Total fertility rate: 5.99 children born/
woman (1996 est.)
Nationality:
noun, Cameroonian(s)
adjective: Cameroonian
Ethnic divisions: Cameroon Highlanders
31%, Equatorial Bantu 19%, Kirdi 11%,
Fulani 10%, Northwestern Bantu 8%,
Eastern Nigritic 7%. other African 13%,
non-African less than 1%
Religions: indigenous beliefs 51%, Christian
33%, Muslim 16%
Languages: 24 major African language
groups, English (official), French (official)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 63.4%
male: 75%
female: 52.1%
Population: 4°) 282 uly 1996 est)
Age structure:
l4 sears: 4¥ 0 «male 93.319: female
Od vears. 33) emale 108.706; temale
65 years and over 4% (male 7.235: female
Y 140) (duiv 1996 es)
Population growth rate: 2.58% (1996 est)
Birth rate: 99.77 births/1.000 population
(1Y96 est)
Death rate: 14.01 deaths/!.000 population
(1996 est)
Net migration rate: 0 micrantisy 1.000
population (1996 est)
Sex ratio:
at jurth: 1.038 maletsitemale
under 15 \\ears. 101 maletsWiemak
15.64 years: OY mateisWiemale
65 years and over: 0.79 maletsWiemale
all cees: 0.94 maleisVtemale (1996 est.)
Infant wertality rate: YS deaths 1.000 live
births (1996 est)
Life expectancy at birth:
diadtian S30] vcars
male SO.79% vears
© §$.29 years 11996 est)
lotal fertility rate: 5.17 Chuldren born/
1QUH ext)
Nationality:
mt guatoerial Gurneants) of
bauat Th
Pquatorial Guinean of
} j wurmcan
bihnic divisions: Bioko (onmantly Buby
| i,
'' | weit
Rio Mum (primarily
s than LOOO. mostly
Keligions: | Hiv Chnstian and
» Roman Catholic. pagan
Languages: Spanish (official). prdgin
ben by bane. Buh Tho
Literacy: ave 15 and over can read and
write pws est )
rile AY fy,
female GR 1,
Population: bid 1H est
\\ve Mructure:
4 \\ \\
; NA
NA
Population growth rate: 062’. VN)
Birth rate: \\\\ bert!
Death rate: \\ \\ deaths
Net migration rate: NA mugranticy | 000
(Mw) ™ pul iia
CAD pycoru lation
Sen ratio:
‘
» 4
Infant mortality rate: \\ \\ deat! MM)
1 ate espectancs at birth
‘
lotal fertility rate
Nauthonalits
b thee dis toes
Kelivnons
f,overnment
Name of country
Duta code: NI
Ivpe of yovernment
( apital: \\
\\dmunistrative divisions
independence: 19 Octot 74th
1! forritcy '' thant
\\ / { ) October 74
National holiday: Wantang: Day. 6 February
(1840) (Treaty of Wattangs established
British sovereignt) )
Constitution: 19 October 1974 (Niue
Constitution Act)
Legal system: Enwlish Common law
Suffrage: iS years of age: universal
Executive branch:
chief of sate. Queen ELIZABETH It the
UK since 6 February 1952) 0s a hereditary
noenarch, the queen and New Zealand are
represented by New Zealand High
Comnmusstoner Warren SEARELL (since NA
\\ugust 1993)
head of eovcrnment. Prenner Frank
bakaotimanava LUT (acting premier since
NA December 1992. premier since 12 March
1993) was reelected by the Legislative
Assembly. election last held 23 February
WG dest to be held NA March 1999)
dhinet) Cabinet consists of the prenuer and
Ihree ministers
Leyvistative branch: unicameral!
les ative Assemb elections bast held 23
bebruary 1996 inext to be held NA March
MO) results percent of vote NA. seats
total. 6 elected) NPP Y. independents |
Judicial branch: \\ppeal Court ot New
/caland. High Court
I ditical parties and leaders: Niue Peoples
Party (NPP) Y VINTAN
International organization participation:
PSC AP brat il i"
Spart SPC SPE UNESCOL WHO
Dipl matic representation in US:
\\
tS diplomatic representation
blay h
[kh
Foconomy
tconomic overview: |
\\ A
'' ’
| ‘\\ / | ! i |
/ , { rial mpl 1}
| \\ | mann
! | mdenmny. although son ish
if mown for export Industry consist
7 il it srl lactorte lo pre
ron trum. lame « Tit nd coconut
ream. The sale of postage stamps to foreign
Hectors ts ano imp rant source of revenuc
Ih land ans nt vears has sutfered a
serious loss of population because of Airports:
nmugration of Niuveans to New Zealand total: |
GDP: purchasing power parity—$2.4 million
(1993 est.)
GDP reali growth rate: NA“
GDP per capita: $1200 (1993 est)
GDP composition by sector:
agriculture: NAG
mdustrv: NAG
services: NAG
Inflation rate (consumer prices): 5“
(199?) domestic. single-line telephone system
Nortolk Island
(territory of Australia)
with paved runways 1,524 to 2.437 m: |
(1995 est)','e8970d55e9bcf6afae2d3295f66ebb73e6d81dfc7ed443deeecf95da7a37f4f3','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d18aed855142890a2dd7b9f315e254eede507a46723ef8b321433ec7792da388',1996,'CA','Canada','people-and-society',175,'Population: 28,820.67! Guly 1996 est.)
Age structure:
0-14 vears: 21% (male 3.032.458; female
2.889.603)
15-64 vears: 67% (male 9.663.955: female
Y 660.648)
65 vears and over: 12% (male 1.501.542:
female 2.072.465) Ululy 1996 est.)
Population growth rate: |.06° (1996 est.)
Birth rate: | 3.33 births/1.000 population
(1996 est.)
Death rate: 7.17 deaths/1.000 population
(1996 est.)
Net migration rate: 4.47 migrantis)/1.900
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 vears: 1.05 male(s)/female
15-64 vears: | male(s\\/female
65 vears and over: 0.72 male(sVfemale
all ages: 0.97 male(sVtemale (1996 est.)
Infant mortality rate: 6.1 deaths/!.000 live
hirths (1996 est.)
Life expectancy at birth:
total population: 79.0% years
male: 75.67 years
female: 82.65 years (1996 est.)
Total fertility rate: 1.81 children born/
woman (1996 est.)
Nationality:
noun: Canadianis)
adjective: Canadian
Ethnic divisions: Bnitisi Isles ongin 40%.
French ongin 27%. other European 20%.
indigenous Indian and Eskime 1.5%. other.
mostly Asian 11.5%
Religions: Roman Catholic 45%. Unned
Church 12‘°. Anglican 8%. other 35%
(1991)
Languages: English (official). French
(official)
Literacy: age 15 and over can read and
write (1986 est.)
total population: 97%
male: NAG
female: NAG
Population: 449.66 Uuly 1996 est.)
Age structure:
0-14 years: SO% (male 114.206: temale
110.276)
15-64 vears: 46% (male 90.593. female
117.485)
65 vears and over: 4% (male 6.450. female
10,056) uly 1996 est.)
Population growth rate: 2.93% (1996 est)
Birth rate: 44.31 births/1.000 population
(1996 est.)
Death rate: 8.29 deaths/1.000 population
(1996 est.)
Net migration rate: -6.68 migrant(s)/ 1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(sWtemale
under 15 years: 1.04 male(s\\/female
15-64 vears: 0.77 male(sWtemale
65 vears and over: 0.64 male(stemale
all ages: O89 maletsViemale (1996 est.)
Infant mortality rate: 54.3 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 63.39 years
male: 61.47 years
female: 65.41 years (1996 est.)
Total fertility rate: 6.12 children born/
woman (1996 est.)
Nationality:
noun: Cape Verdeanis)
adjective: Cape Verdean
Ethnic divisions: Creole (mulatto) 71%
African 28%, European 1%
Religions: Roman Catholicism fused with
indigenous beliefs
Languages: Portuguese. Crioulo. a blend of
Portuguese and West Afnncan words
Literacy: age 15 and over can read and
write (1995 est.)
total population: 71.6%
male: 81.4%
female: 63.8%','128df4d64a88d90331f2fb9795440a35eb1f6081cfd0c34e100bb48ea563d4fa','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('859358380d69e4d5fe3fe8b42905903b45d1ee7e19748332e57b3b2d01609b8b',1996,'KY','Cayman Islands','people-and-society',182,'Population: 34.646 Uuly 1996 est)
Age structure:
0-14 vears: NA
15-64 vears: NA
65 vears and over: NA
Population growth rate: 4.27% (1996 est.)
Birth rate: 14.52 births/1.000 population
(1996 est)
Death rate: 4.98 deaths/1.000 population
(1996 est.)
Net migration rate: 33.2 migrant(s)/!.000
population (1996 est.)
noie: major destination for Cubans trying to
migrate to the US
Sex ratio:
at birth: NA male(sVtemale
under 15 years: NA maleisj/female
15-64 vears: NA male(s)/female
65 vears and over: NA male(s\\/female
all ages: NA maleisVfemale
infant mortality rate: 8.4 deaths/1.000 live
births (1996 est.)
Life expectancy at birth:
total population: 77.1 years
male: 75.37 years
female: 78.81 vears (1996 est.)
Total fertility vate: 1.4 children born/
woman (1996 est.)
Nationality:
noun: Caymanian(s)
adjective: Caymaman
Ethnic divisions: mixed 40°. white 20%.
black 20%, expatriates of various ethnic
groups 20%
Rel’;-ions: United Church (Presbyterian and
Congregational), Anglican. Baptist, Roman
Catholic. Church of God. other Protestant
denominations
Languages: English
Literacy: age 15 and over has ever attended
whool (1970 est.)
total population: 9S
male: I%
female: YS
Covernment
Name of country:
conventional lone form: none
conventional short form: Cayman Islands
Data code: C)
Type of government: dependent territory of
the UK
Capital: George Town
Admunistrative divisions: & districts. Creek
Easiem. Midland. South Town. Spot Bay
Stake Bay, West End. Western
independence: none (cependent termtory of
the UK)
National holiday: Con: titution Day (first
Monday in July)
Constitution: 1959. revised 1972 and [99?
Legal system: British common law and local
salutes
Suffrage: 18 years of age: univers
Executive branch:
chief of state. Queen ELIZABETH
United Kingdom since 6 February 1952) is «
hereditary monarch
head of government: Governor and President
of the Executive Council John OWEN (since
15 September 1995)
cabinet: Executive Councii-—three members
are appointed by the governor, four members
are elected by the Legislative Assembly
Legislative branch: unicamera!
Legislative Assembly: election last held 18
November 1992 (next to be held NA
November 1996): results-—percent of vote by
party NA; seats—415 total. 12 elected)
independents | 2
Judicial branch: Grand Court: Cayman
Islands Court of Appeal
Political parties and lerders: no formal
political parties
International organization participation:
Cancom (observer). CDB. Interpol
(subbureau), [OC
Diplomatic representation in US: none
(dependent territory of the UK)
LS diplomatic representation: none
‘‘opendent territory of the UK)
Flag: blue. with the flag of the UK in the
upper horst-side quadrant and the Caymanian
coat of arms on a white disk centered on the
wuter hall of the flag: the coat of arms
mcludes a pineapple and tuitie wove a
shield with three stars (represent.ng the three
stands) and a scroll at the bottom bearing
the motto HE HATH FOUNDED IT UPON
THE SEAS','ade5031ce82d11b245679aff3635f2ce4d5a1656c2b467022feb7ce2344bdee0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('920c52698908f7c14f63824a3424ac4b68ef0e1bfe21e378b55a2fb5a0a2b44f',1996,'CF','Central African Republic','people-and-society',187,'Population: 3.274.426 (July 1996 est.)
Age structure:
0-14 vears: 44% (male 724.914: female
718,423)
15-64 vears: 52% (male 839,118: female
877,069)
65 vears and over: 4% (male 53.418: female
61.484) uly 1996 est.)
Population growth rate: 2.08 (1996 est.)
Birth rate: 39.97 births/!.000 population
(1996 est.)
Death rate: 17.64 deaths/!.000 population
(1996 est.)
Net migration rate: - 1.53 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 vears: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 vears and over: 0.87 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 111.7 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 45.86 years
male: 48.03 years
female; 46.71 years (1996 est )
Total fertility rate: 5.41 childrer. born/
woman (1996 est.)
Nationality:
noun; Central African(s)
adjective: Central African
Ethnic divisions: Baya 34%, Banda 27%.
Sara 10%, Mandyjia 21%, Mboum 4%.
M’Baka 4%. Europeans 6.500 (including
3.600 French)
Religions: indigenous beliefs 24°.
Protestant 25%, Roman Cathelic 25%.
Muslim 15%, other 11%
note; animistic beliefs and practices strongly
influence the Christian majority
Languages: French (official), Sangho
(lingua franca and national language).
Arabic. Hunsa, Swahili
Literacy: age 15 and over can read and
write (1995 est.)
total population: 60%
male: 68.5%
female: 52.4%','b0db0566538433e04114ee300b643c068deff3ca01b0297b05355f4c6ace3acc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba7cd0d68084f8f466bd5b0d08cb0c369fb3b619191b56df9c1b98d15ab5598a',1996,'CG','Congo','people-and-society',195,'Population: 6.976.845 (July 1996 est.)
Age structure:
0-14 vears: 44% (male 1.543.688: female
15-64 vears: 53% (male 1.807.361. female
1.881.930)
65 years and over; 3% (male 91.998; temale
116.139) (July 1996 est.)
Population growth rate: 2.68 (1996 est.)
Birth rate: 44.25 births/1.90 population
(1996 est.)
Death rate: 17.44 deaths/1.000 population
(1996 est.)
Net migration rate: ( migrant(s)/1.000
population (1996 est.)
Sex ratio:
a birth: 1.04 male(s)/female
under 15 years: | male(s)/female
15-64 vears: 0.96 male(s)/female
65 vears and over: 0.79 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: | 20.4 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 47.55 years
male: 45.18 years
female: 50.01 years (1996 est.)
Total fertility rate: 5.84 children born/
woman (1996 est.)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic divisions:
north and center: Muslims (Arabs, Toubou.
Hadjerai. Fulbe. Kotoko. Kanembou.
Baguirmi. Boulala, Zaghawa. and Maba)
south: non-Muslims (Sara, Ngambaye.
Mbaye. Goulaye. Moundang. Mousse.
Massa) nonindigenous 150.000. of whom
1.000 are French
Religions: Muslim S50. Christian 25.
indigenous beliefs (mostly animism) 25%
Languages: French (official). Arabic
(official), Sara and Sango (in south). more
than 100 different languages and dialects
Literacy: age 15 and over can read and
write in French or Arabic (1995 est.)
total population: 48.1%
male: 62.1%
female: 34.7%','b2f6e32d02cdddb1cde682a10f8804af912a3cd21fcd0a9ef1eb63f5ff391707','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('defdac475bceb1908ba9b70a33438bcc7b87e78ce5811065fa5b38fbfcfe8a0e',1996,'PE','Peru','people-and-society',201,'Population: 14,333,258 (uly 1996 est.)
Age structure:
0-14 vears: 29% (male 2.071.816; female
2.041.417)
15-64 vears: 65% (male 4,599,173; female
4.651.030)
65 vears and over: 6% (male 403,019:
female 566.803) (July 1996 est.)
Population growth rate: |.24 (1996 est.)
Birth rate: 18.09 births/1.000 population
(1994 esi.)
Death rate: 5.68 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/! 000
population (1996 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1.02 malets)/temale
15-64 vears: 0.99 male(s)/female
65 vears and ever: 0.71 maletsiV/temale
all ages: 0.97 maleis\\/temale (1996 esi
Infant mortality rate: {3.6 deaths).
live births (1996 est)
Life expectancy at birth:
total popuiation: 74.49 years
male: 71.26 years
female: 77.72 years | 1996 est)
Total fertility rate: 2 23 children born
woman (1996 est.)
Nationality:
noun, Chileanis)
adjective: Chilean
Ethnic divisions: European and Euroypean-
Indian 95. Indian 3% , other 2%
Religions: Roman Catholic 89°. Protestant
11. Jewish
Languages: Spanish
Literacy: age 15 and over can read and
write (1995 est.)
total population: 95.2%
male: 95.4%
female: 9S%
C,over.ment
Name of country:
conventional long form: Republic of Chile
conventional short form: Chile
local long form: Republica de Chile
local short form: Chile
Data code: Cl
Type of government: republic
Capital: Santiago
Administrative divisions: |3 regions
(regiones, singular—region): Aisen del
General Carlos Ibanez del Campo.
Antofagasta, Araucania, Atacama, Bio-Bio,
Coquimbo. Libertador General Bernardo
O''Higgins. Los Lagos. Magallanes y de la
Antartica Chilena, Maule. Region
Metropolitana, Tarapaca, Valparaiso
note: the US does not recognize claims to','50241db8433f4f1d3d2dbec7ecbeb3602b1434a9306fa6c571fdd49fbfb1beb0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ddf8aeec2de7f295c4a570180c13e383f17037ce587d83e351fdd101bc7636c',1996,'CN','China','people-and-society',204,'Population: | .210.004.956 uly 1996 est)
Ave structure:
‘} years. 26, (mate 167 448.148: female
IS} OO1L6OSO)
18-64 vears: 67°C (male 421.455.4118: female
OTT STO)
4S years and over, 7% (male 35.056.4089:
temale 40,529.821) uly 1996 est)
Ponulation growth rate: 0.98 (1996 est)
Birth rate: 17.0) births/1.000 population
(1996 est.)
Death rate: 6.92 deaths/1,000 population
(1996 est.)
Net migration rate: -0.34 migreatisy/! 000
population (1996 est.)
Sex ratio:
at birth: 1.11 male(sWfemale
under 15 years: 1.1 male(s)/female
15-64 vears: 1.07 male(s)/female
6» vears and over: 0.36 male(sVfemale
all ages: 1.06 male(sVfemale (1996 est.)
Infant mortality rate: 39.6 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 69.62 years
male: 68.33 years
female: 71.0% years (1996 est.)
Total fertility rate: 1.8! children born/
woman (1996 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic divisions: Han Chinese 91.9%.
Zhuang. Uygur. Hui, Yi. Tibetan, Miao,
Manchu, Mongol, Buyi. Korean, and other
nationaliues 8.1%
Religions: Daoism (Taoism), Buddhism.
Muslim 2%-3%, Christian 1% (est.)
note: otficially atherst, but traditionally
pragmatic and eclectic
Languages: Standard Chinese or Mandarin
(Putonghua, based on the Beijing dialect).
Yue (Cantonese). Wu (Shanghaiese), Minbei
(Fuzhou). Minnan (Hokkien-Taiwanese).
Xiang. Gan, Hakka dialects, minority
languages (see Ethnic divisions entry)
Literacy: age 15 and over can read and
write (1995 est.)
total populanon: 81.5%
male: 89.9%
female: 72.7%
Population: 21 .465,881 (July 1996 est.)
Age structure:
0-14 years: 23% (male 2,605,495; female
2,436,864)
15-64 years: 69% (male 7,505,344, female
7,252,188)
65 years and over: 8% (male 907,310;
female 758,680) (July 1996 est.)
Population growth rate: 0.89% (1996 est.)
Birth rate: 15.01 births/!,000 population
(1996 est.)
Death rate: 5.52 deaths/] 000 population
(1996 est.)
Net migration rate: -0.61 migrant(s)/i 000
population (1996 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years. 1.07 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: \\.2 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 7 deaths/!,000 live
oirths (1996 est.)
Life expectancy at birth:
total popuiation: 76.02 years
male: 73.43 yeats
female: 78.82 years (1996 est.)
Total fertility rate: 1.76 children born/
woman (1996 est.)
Nationality:
noun; Chinese (singular and plural)
adjective: Chinese
Ethnic divisions: Taiwanese 84%, mainland
Chinese 14%, aborigine 2%
Religions: mixture of Buddhist, Confucian.
and Taoist 93%, Christian 4.5%, other 2.5%
Languages: Mandarin Chinese (official),
Taiwanese (Min), Hakka dialects
Literacy: age 15 and over can read and
write (1980 est.)
total population: 86%
male: 93%
female: 79%
Administration
Name of country:
conventional long form: none
conventional short form: Taiwan
local long form: none
local short form: T ai-wan
Data code: TW
Type of government: multiparty democratic
regime; opposition political parties legalized
in March 1989
Capital: Taipe
Administrative divisions: some of the
ruling party in Taipei claim to be the
government of all China; in keeping with
that claim, the central administrative
divisions include 2 provinces (sheng.
singular and plural) and 2 municipalities”
(shih, singular and plural)—Fu-chien (some
20 offshore islands of Fujian Province
including Quemoy and Matsu), Kao-hsiung”.
T ai-pes*, and Taiwan (the island of Taiwan
and the Pescadores islands): note—the more
commonly referenced administrative
divisions are those of Taiwan Province—16
counties (hsien, singular and plural), 5
snunicipalities* (shih, singular and plural).
and 2 special municipalities** (chuan-shih,
singular and plural); Chang-hua, Chia-1,
Chia-i*, Chi-lung*. Hsin-chu, Hsin-chu*.
Hua-lien, I-lan, Kao-hsiung. Kao-hsiung**
Miao-li, Nan-t ou, P’eng -hu, Ping-tung.
T ai-chung, Tai-chung*, T’ar-nan, T ai-
nan*, T’ai-pei, T ai-pei**. Tai-tung. Tao
yuan, and Yun-lin: the provincial capital is at
Chung-hsing-hsin-ts un
note: Taiwan uses the Wade-Giles system
for roman.zation
National holiday: National Day, 10 October
(1911) (Anniversary of the Revolution)
Constitution: | January 1947, amended in
1992. presently undergoing revision
Legal system: based on civil law system:
accepts compulsory ICJ jurisdiction, with
reservations
Suffrage: 20 years of age; universal
Executive branch:
chief of state: President LI Teng-hu
(succeeded to the presidency following the
death of President CHIANG Ching-kuo 13
January 1988. elected by the National
Assembly 21 March 1990. reelected by
popular vote in the first-ever direct elections
for president 23 March 1996); election last
held 23 March 1996 (next to be held NA
2000), results—LI Teng-hui 54%, PENG
Ming-min 21%, LIN Yang-kang 15%, and
CHEN Li-an 10%; Vice President-elect
LIEN Chan (to be inaugurated 20 May 1996)
head of government: Premier (President of
the Executive Yuan) LIEN Chan (since 23
February 1993) and Vice Premier (Vice
President of the Executive Yuan) HSU Li-
teh (since 23 February 1993) were appointed
535
SH
Taiwan (continued)
by the president: note—LIEN Chan will
continue to serve as premier until 20 May
1996 when he will be inaugurated as vice
president, a new premier ts expected to be
appointed sometime in May 1996
cabinet: Executive Yuan was appointed by
the president
Legislative branch: unicameral Legisiative
Yuan and unicameral National Assembly
Legislative Yuan: elections last held 2
December 1995 (next to be held NA
December 1998). results—percent of vote by
party NA: seats—(164 total) KMT 85, DPP
54, CNP 21, independents 4; note—since the
election, there has been a change in the
distribution of seats—KMT 8&3, DPP 54,
CNP 21, independents 6
Vational Assembly: elections last held 23
March 1996 (next to be held NA 2000):
KMT 55%, DPP 30%, CNP 14%,
other 1%: seats—( 334 total) KMT 183. DPP
99 CNP 46. other 6
Judicial branch: Judicial Yuan, justices
nominated and appointed for nine-year terms
by the president
Political parties and leaders: Kuomintang
(KMT, Nationalist Party), LI Teng-hu,
chairman: Democratic Progressive Party
(DPP). leader NA; Chinese New Party
(CNP), leader NA. Labor Party (LP). leader
NA
Other political or pressure groups: Taiwan
independence movement, various
resuils -
environmental groups
note: debate on Taiwan independence has
become acceptable within the maitsiream of
domestic politics on Taiwan: political
liberalvzation and the increased
representation of the opposition Democratic
Progressive Party in Taiwan''s legislature
have opened public debate on the island''s
national identity; advocates of Taiwan
independence, both within the DPP and the
ruling Kuomintang, oppose the ruling party''s
traditional stand that the island will
eventually unify with mainland China, the
aims of the Tarwan independence movement
include establishing 4 sovereign nation on
Taiwan and entering the UN; other
organizations supporting Taiwan
independence include the World United
Formosans for Independence and the
Organization for Taiwan Nation Building
luternational organization participation:
APEC, AsDB. BCIE, ICC, 10C, WCL,
WTrO (applicant)
Diplomatic representation in US: none.
unofficial commercial and cultural relations
with the people of the US are maintained
through a private instrumentality, the Taipei
Economic and Cultural Representative Office
5
(TECRO) with headquarters in Taipei and
field offices in Washington and 10 other US
cities
US diplomatic representation: none:
unofficial commercial and cultural relations
with the people of Taiwan are maintained
through a private institution, the American
Institute in Taiwan (AIT), which has offices
in Taipei at #7, Lane 134, Hsin Yi Road,
Section 3, telephone [886] (2) 709-2000,
FAX [886] (2) 702-7675, and in Kao-hsiung
at #2 Chung Cheng 3d Road, telephone
[886] (7) 224-0154 through 0157, FAX [886]
(7) 223-8237, and the American Trade
Center at Room 3207 International Trade
Building. Taipei World Trade Center, 333
Keelung Road Section 1, Taipei 10548,
telephone [886] (2) 720-1550
Flag: red with a dark blve rectangle in the
upper hoist-side corer bearing a white sun
with 12 triangular rays','6eb0c48a8a2b98e7dfb74999a6b75a1f60f5d3785c4ea6d9ecac52ac98bc6994','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0009625b192142f06216bdcff51e629c9a83250a92d5f5cccd716208786dcfdf',1996,'CX','Christmas Island','people-and-society',209,'Population: 813 July 1996 est.)
Age structure:
0-14 vears: NA
15-64 vears: NA
65 vears and over: NA
Population growth rate: -§ 98% (1996 est.)
Birth rate: NA births/1.000 population
Death rate: NA deaths/1.000 population
Net migration rate: NA migrant(s)/!.000
population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(sVfemale
15-64 years: NA male(s)/female
65 vears and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: NA deaths/! 000 live
births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/
woman
Nationality:
noun: Christmas Islanderis)
adjective: Christmas Island
Ethnic divisions: Chinese 61%. Malay 25%.
European 11%, other 3%, no indigenous
population
Religions: Buddhist 55%. Christian 15%.
Muslim 10%, other 20% (1991)
Languages: English','abd70ad0733df0020f769ff0fce6ea6823ea59b5fc12190b6c1f76d94ced364a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('946f4320d1fe2ccb8ad3b22ab33617b55374f8194bc4cd2480a5290a73289227',1996,'CC','Cocos (Keeling) Islands','people-and-society',215,'Population: 609 July 1996 est.)
Age structure:
0-14 years: NA
15-64 vears: NA
65 vears and over: NA
Population growth rate: 0.94% (1996 est.)
Birth rate: NA births/!.000 population
Death rate: NA deaths/1.000 population
Net migration rate: NA migrant(s)/1,.000
population
Sex ratio:
at birth: NA male(sWfemale
under 15 years: NA male(s\\/femate
15-64 vears: NA male(s)/female
65 vears and over: NA male(s female
all ages: NA male(s)/female
Infant mortality rate: NA deaths/1.000 live
births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/
woman
Nationality:
noun: Cocos Islander(s)
adjective: Cocos Islander
Ethnic divisions:
West Island: Europeans
Home Island: Cocos Malays
Religions: Sunni Muslim 57%. Christian
22%. other 21% (1981 est.)
Languages: English
Name of country:
conventional long form: Territory of Cocos
(Keeling) Islands
conventional short form: Cocos (Keeling)
Islands
Data code: CK
Type of government: territory of Australia
Capital: West Island
Administrative divisions: none (territory of
Australia)
Independence: none (territory of Australia)
National holiday: NA
Constitution: Cocos (Keeling) Islands Act
of 1955
Legal system: based upon the laws of
Australia and local laws
Suffrage: NA
Executive branch:
chief of state: Queer ELIZABETH II (of the
United Kingdom since 6 February 1952) is a
hereditary monarch
head of government: Administrator John Bell
READ (since NA) was appointed by the
governor general of Australiz and represents
the queen and Avu*<*zalia
Legislative branch: unicameral Cocos
(Keeling) Islands Shire Council: President of
the Islands Council Ronald GRANT (since
NA)
Judicial branch: Supreme Court
Political parties and leaders: none
International organization participation:
WMO
Diplomatic representation in US: none
(territory of Australia)
US diplomatic representation: none
(territory of Australia)
Flag: the flag of Australia is used','b5fb9cd02f4afa392795e2aa2436793bfc678c6771fd6f5ef8bcf991abbf7c85','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6175220c43289ade8f6af2a16b1e1cccdf5d95d7642962ee3c29293e8413241e',1996,'CO','Colombia','people-and-society',220,'Population: 36.813.161 Wluly 1996 est.)
Age structure:
0-14 vears: 32% (male 5.948.599: temale
5.806.450)
15-64 vears: 64° (male 11.496.931;. female
1 1.890.875)
65 vears and over: 4% (male 741.788:
female 928.518) (July 1996 est.)
Population growth rate: |.66° (1996 est.)
Birth rate: 21.34 births/!.000 population
(1996 est.)
Death rate: 4.65 deaths/1.000 population
(1996 est.)
Net migration rate: -0.13 migrant(s)/) 000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/temale
under 15 years: 1.02 male(s)/female
15-64 years: 0.97 male(s)/female
65 vears and over: 0.8 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 25.8 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 72.81 years
male: 69.97 years
female: 75.73 years (1996 est.)
Total fertility rate: 2.35 children born/
woman (1996 est.)
Nationality:
noun. Colombian(s)
adjective: Colombian
Ethnic divisions: mestizo 58, white 20%,
mulatto 14%, black 4%, mixed black-Indian
3%, Indian 1%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy: age 15 and over can read and
write (1995 est.)
total population: 91.3%
male: 91.2%
female: 91.4%','9d9432d8394cc6a98682fc57d444ac1605b0e49ff593bd4db97e991ea80f34ee','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a622b40104483886d695363aa719ea546a25a3b3e43d98f6328c336de71fbb7',1996,'YT','Mayotte','people-and-society',227,'Population: 569.237 (July 1996 est.)
Age structure:
0-14 years: 48% (male 137,235: female
136,207)
15-64 years: 49% (male 138,447; female
142,058)
65 vears and over: 3% (male 7,242: female
8.048) (July 1996 est.)
Population growth rate: 3.55% (1996 est.)
Birth rate: 45.82 births/1.000 population
(1996 est.)
Death rate: 10.28 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 vears and over: 0.9 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 75.3 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 58.7 years
male: 56.43 years
female: 61.05 years (1996 est.)
Total fertility rate: 6.65 children born/
woman (1996 est.)
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic divisions: Antalote, Cafre, Makoa,
Oimatsaha, Sakalava
Religions: Sunni Muslim 86, Roman
Catholic 14%
Languages: Arabic (official), French
(official), Comoran (a blend of Swahili and
Arabic)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 57.3%
male: 64.2%
female: 50.4%','5fc681f1f62425b6ff12dfd0788e3b52b8a2b8a234a81faa3e072bab6cdf2a39','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1eab1d173b2e05e37fbfe98247c4e0f50eb9affc23adfb3afaa6a631eab5c2e',1996,'GA','Gabon','people-and-society',235,'Population: 2.527.841 (July 1996 est.)
Age structure:
0-14 vears: 43% (male 550.971; female
545.096)
15-64 years: 53% (male 657,035; female
688.441)
65 vears and over: 4% (male 34.973: temale
51.325) July 1996 est.)
Population growth rate: 2.19% (1996 est.)
Birth rate: 39.19 births/1.000 population
(1996 est.)
Death rate: 17.35 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 vears: 0.95 male(s)/female
65 vears and over: 0.68 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 108.1 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 45.77 yeurs
male: 44.21 years
female: 47.37 years (1996 est.)
Total fertility rate: 5.15 children born/
woman (1996 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic divisions:
south: Kongo 48%
north: Sangha 20%, M’Bochi 12%
center: Teke 17%, Europeans 8.509 (mostly
French)
Religions: Christian 50, animist 48.
Muslim 2%
Languages: French (official), African
languages (Linga''a and Kikongo are the
most widely used)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 74.9%
male: 83.1%
female: 67.2%','58e41e500c30f8dceb770fcbcc59e1f90359d3b58d7d1f35843563a029bd5f8f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd6d2345e5e183535c2b8e2a7228f79698b6b3de6a22d87b47cc3c4db117d85f',1996,'CK','Cook Islands','people-and-society',241,'Population: 19.561 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 vears: NA
65 vears and over: NA
Population growth rate: |.11% (1996 est.)
Birth rate: 22.87 births/1.000 population
(1996 est.)
Death rate: 5.2 deaths/1.000 population
(1996 est.)
Net migration rate: -6.58 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: NA male(s)/temale
under 15 years: NA male(sVtemale
15-64 vears: NA male(s)/female
65 vears and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 24.7 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 71.14 years
male: 69.2 years
female: 73.1 years (1996 est.)
Total fertility rate: 3.25 children born/
woman (1996 est.)
Nationality:
noun: Cook Islander(s)
adjective: Cook Islander
Ethnic divisions: Polynesian (full blood)
81.3%, Polynesian and European 7.7%.
Polynesian and non-European 7.7%.
European 2.4%. other 0.9%
Religions: Christian (majority of populace
members of Cook Islands Christian Church)
Languages: English (official), Maori
Literacy: NA
Population: no indigenous inhabitants:
note—there are three meteorologists','612f437c19bb998a44f9bf71a3d7e2446d69613d46ae054a6284f3533fe64a94','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da80b109de308b7649ac66a424c4e7687c431fa6b8b7ebe358ca2b5b43586c8c',1996,'NI','Nicaragua','people-and-society',248,'Population: 3.463.083 uly 1996 est)
Age structure:
0-14 years: 35% (male 612.624. female
582.566,
15-64 vears: 61% (male 1.061.703. temale
1.038.403)
6S vears and over: 4% (male 77.773. female
90.014) July 1996 est.)
Population growth rate: 2.06 (1996 est)
Birth rate: 23.84 births/!.000 population
(1996 est.)
Death rate: 4.14 deaths/1.000 population
(1996 est.)
Net migration rate: 0.92 migrant(s)/ 1.00%
population (1996 est.)
Sex ratio:
at birth: 1.05 maleis/temale
under 75 vears: 1.05 male(s\\temale
15-64 vears: 1.02 male(s\\/temale
65 years and over: 0.86 male(sVfemale
all ages: 1.02 male(s)/female (1996 est)
Infant mortality rate: | 3.5 deaths/!.000
uve births (1996 est.)
Life expectancy at birth:
total population: 75.72 years
male: 3.31 years
female: 78.24 years (i996 est.)
Total fertility rate: 2.9 children born/
woman (1996 est.)
Nationality:
noun: Costa Ricanis)
adjective: Costa Rican
Ethnic divisions: white (including mestizo)
96%. black 2%. Indian 1%, Chinese 1%
Religions: Roman Cativlic 95%
Languages: Spanish (official), English
spoken around Puerto Limon
Literacy: age 15 and over can read and
write (1995 est.)
total population: 94.8%
male: 94.7%
female: 98%
Population: 5.605.193 Guly 1996 est.)
Age structure:
0-14 vears: 43% (male 1,220,188: female
1.177.725)
15-64 vears: 54% (male 1.496.625. temale
1.520.918)
65 vears and over: 3% (male 91.126: female
98.611) uly 1996 est.)
Population growth rate 2.6% (1996 est.)
Birth rate: 33.38 births/:.000 population
(1996 est.)
Death rate: 5.83 deaths/!.000 population
(1996 est.)
Net migration rate: -1.53 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 vears: |.04 male(s)/female
15-64 vears: 0.98 male(s)/female
65 vears and over: 0.92 male(s)/female
all ages: | male(s)/female (1996 est.)
Infant mortality rate: 4).8 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 68.42 years
male: 66.01 years
female: 70.96 years (1996 est.)
Total fertility rate: 4.41 children born/
woman (1996 est.)
wg
Nationality:
noun: Honduran(s)
adjective: Honduran
Ethnic divisions: mestizo (mixed Indian and
European) 90%, Indian 7%, black 2%. white
1%
Religions: Roman Catholic 97%. Protestant
minority
Languages: Spanish. Indian dialects
Literacy: age 15 and over can read and
write (1995 est.
iotal population: 72.7%
male: 72.6%
female: 72.7%
conventional short form: Nearac
local long form: Republica de Nicara
local short term: Nywaragcua
Data code: NI
Ivpe of yovernment: repuh
Capital: Managus
\\dministrative divisions: |S Gepurt
idepartamentos. singular —deparnam
auUTOROTMOUS Peghon ifegvhons aul
wrgular- region aulonomista) B
C arazo. Chinandega. Chomtales. Este!
Granada. Jinetega Leen. Madnz. Manages
Masaya. Matagalpa. Nueva Segovis
Vilartinca Norte’. Athantn a Sur’. Rio S
luan Rivas
Independence: 15 September is)
Span)
National holiday: lndependcnec D
September (1821
Constitution: & hinuory [4s
Legal system: civil law synth ‘
Court mas revicw admuneestrat
Suffrage: |6 scars of age. univer
Executive branch:
duet ot State and head of eon crn
Presidemt Violeta Barrios de CHAMORRG)
ismee 28 April 1990) was elected (or a sin
vear term (amended to a tive-s tern
luly 1995S) by universal suffrage. Vic
President Julia MENA Rivera tsince 22
Octeber 1995) replaced Vorgilre GODOYS
whe resigned to fun tor the presidency
YH as required hy law. clectron last
2S bebruar
October 1996). results — Violeta Ban
CHAMORRO (UNO) S47) Duy
ORTEGA Saavedra (PSLN) 408
14,
caiynet Cabinet
Legislative branch: uni cam
lsandlea N
INS nest to be hel
National Asscmbrls
clections last held 25 February 1
be held NA October 1996) result. UNO
coalition $3.9
Lote. MUR LOG. seats-—19) total) UNO
comtion S34 (Center Group 9 UDC 6. PSD
S APCS. PLO S. PLES. PND & PAN
PNC 3. MBDYN 2. PCdeN
and Sandinista blog 89 (MRS 16, BUS
Sandietsta blac 40.8 rN\\¢
immicpomicnts 6
349
58
Nicaragua (continued)
Su la 4 ESLN OS. Sandinista Group of
K 1 SLN
ludiial branch: Supreme Court (Corte
niependents 2)
cu tea 4 si\\- Vear term
mon July 1995)
\\
Political parties and leaders:
( Panty «PLC;
EENEAN ive Popular
‘ \\I n ARGLUELLO
i + Nal i { \\
. LEPRRA Gs J
( \\ NI '' AT Ac
‘ \\ PON
lh
S | PSC woth the
‘ Port ;PhOD !
{ (hl
! Gal FRO Natronal Consens
Nd \\ \\itkouN
VIDL ARR
\\ '' MALI
'' \\ ( .
} t PRN) | ci \\D0 \\
| ‘) NI lent Lay
A NAV VRROD Naot
PRON \\ LMWAVO
\\ 1) atath Alliances
| Nit VIANYORGA
- ’ \\ Lib Party (PLN:
CASTHLOO Party tor Libera
’ ito uw MONTE ALEGRI
buctya Of VEVVORGA
Dennataty Une
| 1 | i} Got ZNEAN
\\ th Miowement (MIDN
Gai SNIAN OS i Dermat Part
std) \\ VROU IN, Noatvonal Justis
PIN, J PNAS Crus. Nateonal
PAN) DD » MONTIBI
} \\ Vieement (ADARD Pablo
ik Ni Sau ty Reno ate
1 NIRS). Ses RAMIREZ. Sou
( POS) brook RAMIREZ
1) \\ mn Porty (PAD). Eden
PASTOR | | vith Necaragua \\rriba
\\ \\ ROBELOL National
1) PND) Alfredo CESAR
Ports, of Necoracu
| N ] ‘ELE TIVEER ANNO) Pes
\\ Nl i) Leber uty brown
ORTEGA. Revoluthonars
Wont VIPREY Bont
MIKANDA. Poy Lotion Movement
Nlarvist- Len MEAP MIL. Isidn
PELL EZ. Necaraguan Socilist Pans oPSN)
Gustave TABLADA. Unidad Nacaraguense
de Obret ,
UNOCP). Resaloe GONZALEZ Urbina
Central Amencan Unronmt Party (PUC A)
Bianca ROJAS behaverry
( ATT IPM sinh \\ Pr fesponales
aS
note. the UNO coalmon that won the 1990
elections no longer exists: the different blocs
that formerly were united under the UNO
umiella and their opposition to the
Sandinistas now act and vole independently
(her political or pressure groups:
National Workers Front (ENT) is a
Sandine''ta umbrella group of exght labor
umons: Sandinsta Workers’ Central (CST).
Farm Workers Association (ATC). Health
Workers Federation (FETASALUD)
National Unmon of Employees (UNE.
Nathomal Assocation of Educators of
Na Wars | ANDEN). Unnen of Journalists of
Nicaragua (UPN). Heroes and Martyrs
Confederation of Protessronal Associations
(COONAPRO), and the Nanonal Union of
barmers and Ranchers (UNAG). Permanent
Congress of Workers (CPT) is an umbrella
roup of few, nen-Sandinmsta labor umons
Contederaion of Labor Unaiticaten (CUS)
\\utenemous Necaraguan Workers Central
C TN A). Independent General
( tederathon of Labor (CGT-1). and Labor
Kcthion aed Cots Central (CAUS).
Na oracuan Workers Central (CTN) is an
dependent labor umon. Supenor Council of
Private bnterprise (COSEP) ts a
contederation of business groups
International organization participation:
BOR. CACM. BCLAC. FAO. G77, IADB
IAB A IBRD. IC AQ ICETU. ICRMLIDA
‘HAD. TEC TERCS. ILO) IME. IMO
lotelsat. Interpol, 10K MON TTL. LARS
LATA cobserverns). NAM. OAS. OPANAT
MA UN UNCTAD. UNESCO, UNHCR
LNIDOO LPL WOCL. WETU. WHO. WIPO
WMO Wo Wied
Diplomatic representation in US:
net of maswon Ambassador Roberto
Genwre MAYORGA Cortes
ancery 1627 New Hampshire Avenue
NW. Woastheegten, DC 2009
clephome 1) 0) 8 SOS70
mselatets) eoncral, Houwsten, Los \\ngeles
Vian New Orleans. New Siork. San
branmcises
LS diplomatic representation:
chvet of mussion” Ambassador tohn |
MAISTO
cnthasss Kilometer 4.5 Canetera Sur
Nlanacua
waning address’ APO AA 34021
clophronn SOS] (2) 6660010 through fytott | 4
OHOOO1S throweh DS. G660026. 666027. Good?
through +4
FAN. S081 02) O98
Flag: three equal honzontal bands of blue
(top). white. and blue with the national coat
m arms centered on the white band. the coat
of arms teatures a tnangle encircled by the
words REPUBLICA Dk NICARAGUA on
the top and AMERICA CENTRAL on the
bottom. similar to the flag of El Salvador,
which features a round emblem encucled by
the words REPUBLICA DE EL
SALVADOR EN LA AMERICA CENTRAI
cemtered in the white band: also sinular to
the tlag of Honduras. which has five Dive
Mars arranged in an X pattern centered in the
white band','0f678718652bbcb255cdc64cff223d584e3d59efcd04d4ce0667daed54b2a630','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f81578131fc6ccc8a88f1b8c5e705c9dc2a31d937640a81fe6704449df5d5101',1996,'MX','Mexico','people-and-society',255,'Population: |4.762.145 July 1996 est)
Age structure:
0-14 vears: 48% (male 3.552.270: temale
3.462.462)
15-64 years: SY% (male 3.828.538: temale
3,§99 990)
65 vears and over: 2% (male 164.358
female 154.897) (July 1996 est)
Population growth rate: 292°) (1996 os
Birth rate: 42.48 births/!.000 population
(1996 est.)
Death rate: 15.7 deaths/ 1.000 population
(1996 est.)
Net migration rate: 243 migrants 1.000
population (1996 est.)
note. since 1989. over 350.000 refugees have
fled to Cote d''Ivoire to escape the civil war
in Liberia
Sex ratio:
at birth: 1.03 maletsWfemale
under 15 vears: 1.03 maleisWtemale
15-64 vears: 1.06 maletstemale
65 vears and over: 1.06 maleisVtemale
all ages: 1.04 maleisWfemale (1996 est.)
Infant mortality rate: 82.4 deaths/!.009
live births (1996 est.)
Life expectancy at birth:
total population: 46.73 years
male; 46.23 years
female: 47.25 years (1996 est.)
Total fertility rate: 6.15 children born
woman (1996 est.)
Nationality:
noun: Iworan(s)
adjective: Iworan
Ethnic divisions: Baoule 23. Bete |S.
Senoufou 18%, Malinke 11%. Agni. foreign
Afncans (mostly Burkinabe and Mahians.
about 3 million). non-Afincans 130,000 to
330,000 (French 30.000 and Lebanese
100.000 to 300.000)
Religions: indigenous 25%. Muslim 60%,
Christian 12%
117
Cote d’lvoire (continued)
Languages: French (official). 60 native
dialects with Dioula the most widely spoken
Literacy: age 15 and over can read and
write (1995 est)
ratal populatrion: AG
male. 499%
female MY,
Population: > i) duly [906
Ave structure
<4 bul UH est)
Population growth rate: | 87°" (1996 est
Birth rate: 26 24 birt!
pat
; thw population
Death rate: 1.000 populatior
ye
Net migration rate: 29° gugrant 1 (WW)
AYEY
sex rato:
''
; ,
+ Sareea’
, TOT AK
‘ ~} | ic]
4 ii PTOCals }YUYUH est
Infant mortality rate: 25 deaths/1) 000 tive
Life expectanes at birth:
sf \\ Cals
Oty «
lotal fertility rate: 6023 children born
tiptaf i}
Nationality:
Mexicants
VMexrcar
Ethnic divisions: mestuizo Undian- Spanish)
fy Vmeniadian or predominantly
\\ idan Af Caucasian of
lomimnantls Caucasian 9°. other
Religions: nominally Roman Catholic 89%
Pre tant ¢
Languages: Spanish, various Mayan dialects
316
Literacy: age $5 and over can read and
write (1995S est.)
total population SY 6%
male: YES
female: 87AG
Population. ¥/.120 (July 1996 est.)
note: West Indian (45% born in the Virgin
Islands and 29% born elsewhere in the West
Indies) 74%, US mainland 13%, Puerto
Rican 5%, other 8%
Age structure:
0-14 years: NA
15-64 years: NA
65 vears and over: NA
Population growth rate: -(.06% (1996 est.)
Birth rate: 17.57 births/1,000 population
(1996 est.)
Death rate: 5.2 deaths/1.000 population
(1996 est.)
Net migration rate: -|2.94 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s\\Vfemale
15-64 years: NA male(s)/femaie
65 vears and over: NA male(s)/female
all ages: NA male(s female
Infant mortality rate: 12.54 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 75.29 years
male: 73.6 years
female: 77.2 years (1996 est.)
Total fertility rate: 2.29 children born/
woman (1996 est.)
Nationality:
noun: Virgin Islander(s)
adjective. Virgin Islander
Ethnic divisions: black 80%. white 15%.
other 8%
Religions: Baptist 42%. Roman Catholic
34%, Episcopalian 17%, other 7%
Languages: English (official), Spanish,
Creole
Literacy: NA','746a2b07e76d9969805967c792c8e8f0691a31fcda5a3e2f02efd43c6443019a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b68ae1d497a84a1c92371c4e08f8a15e1c63c57397bbca13e3f877782a450d1',1996,'HU','Hungary','people-and-society',262,'Population: 5.004.) 12 uly 1996 est.)
Age structure:
O-/4 vears: 18% ¢male 453.142: temale
43) 118)
18-64 vears: 69% (male 1.731.200: female
| 716.824)
65 years and over: 13% (male 252.897:
iemale 418.931) uly 1996 est.)
Population growth rate: 0.58 (1996 est. i
Birth rate: 9.83 births/!.000 population
YY6 est.)
Death rate: 11.33 deaths/!.000 population
i }Y96 est.)
Net migration rate: 7.3) migrant(s)/1.000
population (1996 est.)
Sex ratio:
al birth: 116 male(s)/female
wider 15 vears: 1.05 male(s)/female
/S-64 vears: 1.0L male(s)/female
45 vears and ove~: 0.6 male(s)/female
all ages: O.YS maletsi/temale (1996 est.)
120
Infant mortality rate: |0.2 deaths/1!,000
live births (1996 est.)
Life expectancy at birth:
total population: 72.81 years
male: 69.13 years
female: 70.72 years (1996 est.)
Total fertility rate: |.4 children born/
woman (1996 est.)
Nationality:
noun: Croat(s)
adjective: Croatian
Ethnic divisions: Croat 78°. Serb 12%,
Muslim 0.9%, Hungarian 0.5, Slovenian
0.5%, vthers 8.1% (1991)
Religions: Catholic 76.5%. Orthodox 11.1%.
Slavic Muslim 1.2%, Protestant 0.4%, others
and unknown 10.8%
Languages: Serbo-Croatian 96%, other 4%
(includ.ag Italian, Hungarian, Czechoslovak,
and German)
Literacy: age 15 and over can read and
write (1991 est.)
total population: 97%
male: 99%
female: 95%
Population: 5 7.460.274 July 1996 est.)
Age structure:
0-14 vears: 1S (male 4.419.636; female
4.167.860)
15-64 vears
19.629.291)
65 vears and over: 17% (male 3.902.426:
female 5.684.515) uly 1996 est)
Population growth rate: 0.130 (1996 est)
Birth rate: 9.87 births/1.000 population
(1996 est.)
Death rate: 9.82 deaths/1.000 population
(1996 est.)
Net migration rate: |.25 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth
O8% (male 19.656.546: temale
1.06 male(s female
under 15 vears: 1.06 maletsVtemale
15-64 vears
65 vears and over
| male(s)/female
(1.69 male(sV/temale
all ages: 0.95 maletsVtemale (1996 est.)
Infant mortality rate: 6.9 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 78.06 years
male: 74.85 years
female: 81.48 years (1996 est.)
Total fertility rate: |.27 children born/
woman (1996 est.)
Nationality:
noun: ltahanis)
htahan
Ethnic divisions: Italian (includes smal!
adjective
clusters of German-. French-. and
Italians in the north and Albanian-hahans
and Greek-Italians in the south). Sicilians
Sardimians
Religions: Roman Catholiu YS. other 2
languages: lialian. Germar
Trentino-Alto Adige region are
parts of
predominantly German speaking). Fret
(small French-speaking minority in Valk
d Aosta region). Slovene (Slovene-speaku
minonty in the Tneste-Gonzia area
Literacy: age 15 and over can read and
write (1990 est)
total population. 97%
male: IS
female: 96"
Covernment
Name of country:
conventional lone torn
htalian Rem
Beals
Lal
conventional short forn
local long form: Repubblica Ita
lialia
former. Kingdom of Italy
Data code: [1
Type of government: repub!)
Capital: Rome
Administrative divisions: 20) regi
\\nrus7
Basilicata. Calabria. Campania. Eni
Romagna. Friuli-Venezia Giulia. |
Liguna. Lombardia. Marche Me
Piemonte, Pugha. Sardegna. Sicilia. Th
Adige. Umbna. Valle d A
hapa
local shert form
(regiont. singular—regione
Trentino- Alt
Veneto
Independence: |7 March 186! (Kingdom
"aly proclaimed)
National holiday: Anniversary of the
Republi
Constitution: | January |94s
Legal system: based on civil law syste
2 June (1946)
with ecclesiastical law influence. appx
treated as trials de novo: judicial revs
under certain conditions ia Constitutrona
Court: has not accepted compulsory IC)
jurisdiction
Suffrage: | 8 vears of ave
in senatorial elections. where minimum a
1S os
)
Executive branch:
chiet of state: President Oscar Louies
SCALFARO (since JS May 1992) was
elected for a seven-year term by an electo
college consisting of both houses of
Parliament and 58 regional representats<
head of government: Prime Minister
(referred to in Italy as the President of the
Council of Ministers) Romano PRODI ¢s
237
vwvene
universal (exces
1)
Ke
Italy fcont ued)
Minister) and » dent
the Republ;
Legislative branch: i) Parliames
held NA eT vote by party
NA. seals f)3 tal) Olrve Ts ’
Freedom Alli $6. Northern League 99
Retounded Comm i. 35. Soutl [vi
List 3. Autenon Lrst
Judicial branch: Constitut Court (Cort
Costitustonal mpaosed of [TS ves Cone
third appointed by the pr cl e-thud
elected bs Parliament. one-t lole doh
the ordinary and adi Palsy pre!
courts |
Political parties and leaders:
Olive Tree. Democratic Party of the Lett
(PDS). Ma D ALEMA. Greens. Cat
RIPA DI MEANA than Ronewal
Lamberto DINE S hern Tvrols Last
(German speak
’
Freedom \\ I tals CRD). Saly
BERLUSCONTE, Nathonal Alling \\N
Guantrance FIND, Chrstian Denworat
Cer CCD) P Ferdinande CASINI
1) I Antoni
MACCANICO
; | NL). Umbert
BOSSE | \\j nt. Pin
RAL TL R lat R¢
| REINOTEL. ta S tlist
| hil } | Network
| } () ( \\ palit
| R/SONTE PD { Pact tor
] | Ni. | Popular Party
} IANCO) I ,
PANNELLA, Christian
| Lnited Christian
Ct) R BL TTIGLIONI
Willer BORDON
. I bi Ratt
( umsts. Famine
\\NELEI T us List ta up
Social Movement- Tricolor
}
Other political or pressure groups: the
Roman Catholic Church: three mayor trade
union confederatiens (Contederazione
Generale ltaliana del Lavoro or CGIL which
is PDS-dominated. Contederazione Italiana
der Sindacath Lavoraton or CISL which ts
centrist, and Unione Italiana del Lavoro of
CIL which ts center-lett): Italian
munutacturers and merchants associations
(Contindusina. Contcommercio): organized
farm groups (Contcolty ator,
Contagnecoltura)
International organization participation:
\\IDB. AG (observer). ASDB. Australia
Group. BIS. CCC. CDB (non-regional). CE.
CEL. CERN. EBRD. ECE. ECLAC. EIB.
ESA. EU. FAO. G- 7, G-10. IADB. TAEA.
IBRD. ICAO. ICC, ICFTU. ICRM. IDA,
Ik A. TRAD. TEC. TFRCS. ILO. IMF. IMO.
Inmarsat. Intelsat. Interpol. LOC, IOM. ISO.
ITU. LALA (observer). MINURSO. MTCR.
NACC. NAM (guest). NATO. NEA. NSG.
OAS (observer). OECD. OSCE. PCA. UN.
UN Security Council Gemporary ).
UNCTAD. UNESCO. UNHCR, UNIDO.
UNITFIL. UNIKOM, UNITAR, UNMOGIP.
UNTSO. UPL. WCL. WEL. WHO. WIPO.
WMO. WT0O. WTrO. ZC
Diplomatic representation in US:
Chiet of aussions Ambassador Ferdinando
SALLEO
chancery: 1OOL Fuller Street NW.
Washington, DC 20009
elephone: (1) (202) 328-5500
PAN: (1) (202, 483-2187
i ¢ sate \\/ ecneral Boston ( hicage
Houston. Miamt New York. Los Angeles
Philadelphia. San Francisco
comsilatets): Detront and New Orleans
LS diplomatic representation:
Inet of mission. Ambassador Reginald
BARTHOLOMEW
Via Veneto 119/A, OO1T87-Rome
matlne address: PSC 89, Box 100, Rome
\\PO AR 09024
telephone 4116) 4674)
PAY {91 (6) 48R-267)
COIINMANS
onsulatets) Vere ral | lorem Cc Milan
N ples
Flag: three equal vertical bands of green
(homt side). white. and red: similar to the
flag of Ireland, which is longer and ts green
thomt side). white. and orange: also sumuilar
io the tlag of the Cote d''Ivoire. which has
the colors reversed—orange (homt side)
white. and green
kconomy
Economic overview: Since World War I
the Itahan economy has changed from one
hesed on agriculture into a ranking industrial
economy. with approximately the same total
and per capita output us France and the UK
The country is still divided into a developed
industrial north. dominated by private
companies, and an undeveloped agricultural
south. dominated by large public enterprises
Most raw maternais needed by industry and
over 75 of energy requirements must be
mmported. In the second half of 1992. Rome
became unsettled by the prospect of not
qualifying to participate in EU plans tor
economic and monetary union later in the
decade: thus. it finally began to address its
huge fiscal imbalances. Subsequently. the
government has adopted fairly stringent
budgets, abandoned its inflatienory wage
indexation system. and started to scale back
its generous social welfare programs,
including pension and health care benefits
Monetary officials were forced to withdraw
the lira trom the European monetary system
in September 1992. when it came under
eXtreme pressure in currency markets. For
the 1990s. Italy faces the problems ot
pushing ahead with fiscal reform.
returbishing a tottering communications
system. curbing pollution in mayor industrial
centers. and adjusting to the new competitive
forces accompanying the ongoing expansion
and economic integration of the EU
GDP: purchasing power parity—S$1 0886
trillion (1998S est.)
GDP real growth rate: 3.2%" (1995 est)
GDP per capita: $18,700 (1995 est)
GDP composition by sector:
agriculture: 2.9%
wudustry: 31.6%
vervices. OSSO (1994)
Inflation rate (consumer prices): 54°
(1995)
Labor force: 23.988 million
by occupation. services 38%, industry
32.2. agriculture 9.8% (1988)
Unemployment rate: |2.2°7 Ulanuary 1995)
Budget:
revenues. S339 billion
expenditures. S431 dillon, including capital
expenditures of SNA (1994 est.)
Industries: tourism. machinery. iron and
steel. chemicals. tood processing. textiles.
motor vehicles. clothing. footwear. ceramics
Industrial production growth rate: 5.5%
(1995 est.)
Electricity:
capacity. 61,630,000 kW
production: 209 billion kWh
consumption per capita, 4.033 kWh (1993)
Agriculture: fruits. vegetables. grapes.
potatoes, sugar beets, soybeans. gram. olives
meat and dairy products: fish catch of
525.000 metre tons in 1990
Micit drugs: important gateway country for
Latin American cocaine and Southwest
Asian heroin entering the European market
Exports: $190.8 billion (fo.b., 1994)
commodities: metals, textiles and clothing,
production machinery. motor vehicles.
transportation equipment, chemicals
partners: EU 53.4%, US 7.8%, OPEC 3.8%
(1994)
Imports: $168.7 billion (c.f. 1994)
commodities: industrial machinery.
chemicals, transport equipment. petroleum.
metals. food, agricultural products
partners: EU 56.3. OPEC 5.3%. US 4.6%
(1994)
External debt: $67 billion (1993 est.)
Economic aid:
donor: ODA, $3.043 billion (1993)
Currency: | Italian lira (Lit) = 100
cemlesimi
Exchange rates: Italian lire (Lit) per
USSI—1.583.8 Ganuary 1996). 1.629.6
(1995). t.612.4 (1994), 1.573.7 (1993).
1.232.4 (1992), 1.240.6 (1991)
Fiscal vear: calendar year','12cbf0474b0a47d04c023b181b273f862039b2c2782726a48b5943701b0c9f1b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb17e029554a4ee232c60f92fd32b69cca07880823c51dcb44a0ae979b99bd7b',1996,'CU','Cuba','people-and-society',268,'Population: |0.951.334 Vly 1996 est.)
Age structure:
0-14 vears: 22% (male 1.256.674. female
1.191.652)
15-64 vears: 68% (male 3.753.343: female
3.736.045)
65 vears ard over: 10% (male 478.630:
female 534.992) (July 1996 est.)
Population growth rate: 0.44 (1996 est.)
Birth rate 13.37 births/!.000 population
(1996 est.)
Death rate: 7 39 deaths/1.000 population
(1996 est.)
Net migration rate: -''.54 migrant(s)/1,000
population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 vears: 1.06 male(s)/female
15-64 years: | male(s)/female
65 vears ana over: 0.9 male(s)/female
all ages: | male(s)/female (1996 est.)
Infant mortality rate: 9 deaths/1.000 live
births (1996 esi )
Life expectancy at birth:
total population: 75.05 years
male: 72.71 years
female: 77.54 years (1996 est.)
Total fertility rate: |.52 children born/
woman (1996 est.)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic divisions: mulatto 51%. white 37%.
black 11%. Chinese 1%
Religions: nominall, Roman Catholic 85%
prior to CASTRO assuming power:
Protestants, Jehovah''s Witnesses, Jews, and
Santeria are also represented
Languages: Spanish
Literacy: age 15 and over can read and
write (1995 est.)
AY
to:al population: 95.7%
niale: 96.2%
female: 95.3%','873d9cd9d0af48323fda0b2964c4bf5eacc7682cb605aa2e3d63bea11dc5648e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f51dc4bdece8761fd239ec2f6bbf3b42a06eaa6cafca7540f2e9b8b5c9e990fa',1996,'CY','Cyprus','people-and-society',278,'Population: 744.609 (July 1996 est.)
Age structure:
0-14 vears: 25% (male 97,400; female
92.110)
15-64 vears: 64% (male 240,716: female
238.039)
65 vears and over: 11% (male 33.340:
female 43.004) (July 1996 est.)
Population growth rate: 1.11‘ (1996 est.)
Birth rate: 15.39 births/!.000 population
(1996 est.)
Death rate: 7.66 deaths/1.000 population
(1996 est.)
Net migration rate: 3.38 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 vears: 1.01 male(s)/female
65 vears and over: 0.78 male(s)/female
all ages: | male(s)/female (1996 est.)
Infant mortality rate: &.4 deaths/1.000 live
births (1996 est.)
Life expectancy at birth:
total population: 76.26 years
male: 74.11 years
female: 78.52 years (1996 est.)
Total fertility rate: 2.19 children born/
woman (1996 est.)
Nationality:
noun: Cypriot(s)
adjective: Cypriot
Ethnic divisions:
total: Greek 78% (99.5% of the Greeks live
in the Greek area; 0.5% of the Greeks live
in the Turkish area), Turkish 18% (1.3% of
the Turks live in the Greek area; 98.7% of
the Turks live in the Turkish area). other 4%
(99.2% of the other ethnic groups live in the
Greek area: 0.8% of the other ethnic groups
live in the Turkish area)
Religions: Greek Orthodox 78%. Muslim
18%, Maronite. Armenian Apostolic, and
other 4%
Languages: Greek, Turkish, English
Literacy: age 15 and over can read and
write (1987 est.)
total population: 94%
male: 98%
female: 91%
Population: 10.32) 120 luly 1996 est)
Age structure:
‘ ale YOS S61. temale
j*
fys nale 2.519.783. temale
le SI6H.841
N hay \\ My ost
Population growth rate: 1QUH est)
Birth rate: (0 89 births 100 population
Death rate: 1089 death 1 O00 population
Net ougration rate: () 24 nugcrantisy/ 1.000
Sew rato:
” iswvtematle
ieiswtematle
’ flermale (1996 est)
Infant mortality rate: 8 4 death 1.000 live
ver
it fe expectancy at birth:
rita, qe ; fy cars
"OOS years
h/S vear INU est)
foetal fertility rate: | 38 children born/
QUT a) oe
Nationality:
/ hea)
128
adjective: Czech
note: 300,000 Slovaks declared themselves
Czech citizens in 1994
Ethnic divisions: Czech 94.47. Slovak 3%.
Polish 0.6%. German 0.5%, Gypsy 0.3%,
Hungarian 0.2%, other 1%
Religions: atheist 39.8°7. Roman Catholic
39.2%, Protestant 4.6%. Orthodox 3%. other
13.4%
Languages: Czech. Slovak
Literacy: age NA and over can read and
write (est)
total population: 9%
male: NAG
female: NAG','cbd2db563d37ccc3a49d46c678f69ae8bf1c0f8ac44e2ea72bf376aae5e0ab08','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d25d7af3221d7764f8a3ab117f2af96b7145bd4a33fab896b20654ebad714fe',1996,'DK','Denmark','people-and-society',285,'Population: 5.249.632 (July 1996 est.)
Age structure:
0-14 vears: 17% (male 469.672. female
446,907)
15-64 vears: 67% (male 1.789.552: female
1.738.870)
65 years end over: 16% (male 330,396;
female 474,235) (July 1996 est.)
Population growth rate: 0.38 (1996 est)
Birth rate: | 2.24 births/1,000 population
(1996 est.)
Death rate: 10.42 deaths/1.000 population
(1996 est.)
Net migration rate: 2 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.06 male(s\\/temale
under 15 vears: 1.05 malet(sWtemale
15-64 vears: 1.03 male(sWfemale
65 years and over: 0.7 malet(sVtemale
all ages: 0.97 male(sWtemale (1996 est.)
Infant mortality rate: 4.8 deaths/!,000 live
births (1996 est.)
Life expectancy at birth:
total population: 77.3 years
male: 73.78 years
female: 81.01 years (1996 est.)
Total fertility rate: 1.67 children born/
woman (1996 est.)
Nationality:
noua: Dane(s)
adjective: Danish
Ethnic divisions: Scandinavian. Eskimo.
Faroese, German
Religions: Evangeiical Lutheran 91%, other
Protestant and Roman Catholic 2%. other 7%
(1988)
Languages: Danish, Faroese. Greenlandic
(an Eskimo dialect), German (small
minority )
Literacy: age 15 and over can read and
write (1980 est.)
total population: 99%
male: NAG
female: NA%','889aebb6e79bfd22e5233ff6609f1446c011a1313b07d2931abb4d0683327624','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fca9d22408609b9e8acbda3682a0cdfb1a7109ce84d1b495f9ecdec1af08ca5c',1996,'DM','Dominica','people-and-society',297,'Population: 82.926 (July 1996 est.)
Age structure:
0-14 vears: 28% (male 11.986: female
11.521)
15-64 vears: 64% (male 27.206; femule
25.841)
65 years and over: 8% (male 2.608: temale
3.764) uly 1996 est.)
Population growth rate: 0.38°C (1996 est.)
Birth rate: 18.38 births/i.Q00 population
(1996 est.)
Death rate: 5.31 deaths/1.000 population
(1996 est.)
Net migration rate: -9.32 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/temale
under 15 vears: 1.04 male(s)/female
15-64 vears: 1.05 male(s)/female
65 vears and over: 0.69 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 9.6 deaths/! 000 live
births (1996 est.)
Life expectancy at birth:
total population: 77.4 years
male: 74.55 years
female: 80.4 years (1996 est.)
Total fertility rate: |.93 children born/
woman (1996 est.)
Nationality:
noun, Dominicanis)
adjective: Dominican
Ethnic divisions: black. Carib Indians
Religions: Roman Catholic 77%. Protestant
1S% (Methodist 5%. Pentecostal 3%,
Seventh-Day Adventist 3%. Baptist 2%.
other 2%). none 2, unknown 1%, other 5%
Languages: English (official), French patois
Literacy: age 15 and over has ever attended
school (1970 est.)
total population: 94%
male; 9Y4AG%
female: 94%','12534d35c582f29e64ab9624de748009023f02b9c1301eaa1763a91f80da6b87','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3e10cdf4e87da8a8c61128aebd9505ee7977d0b552f4de1d92f2a948c0a7451',1996,'DO','Dominican Republic','people-and-society',303,'Population: *.OSS.881 July 1996 est)
Age structure:
O-/4 years. 34% (male 1.401.322. temale
1 358.530)
15-64 years: 62°% (male 2.541.356. temale
2.460 509)
65 years and over: 4 (male 196.238,
female 173.926) July 1996 est)
Population growth rate: | 73".
Birth rate: 23.51 birthy 1.000 population
(1996 est)
Death rate: 5.66 deaths/ 1.000 population
(1996 est.)
(1996 est.)
Net migration rate: -0.53 migrant(s)/ 1.000
population (1996 est)
Sex ratio:
al durth: LAS malets/temale
under 1S years: 1 O8 maletsi/temale
15-64 years. 1.038 maletsitemale
65 years and over’ OY maletsi/temale
all ages: 1.038 maletsWfemale (1996 est.)
Infant mortality rate: 47 7 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 69.06 years
male: 66.89 years
female. 71.34 years (1996 est.)
fotal fertility rate: 2.66 children born/
woman (1996 est.)
Nationality:
noun: Dominicanis)
adjective. Dominican
Ethnic divisions: white 16%. black 11%.
mixed 73%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy: age 15 and over can read and
write (1995 est.)
total population: 821%
male: 82%
female 2 2 ‘','fbb03c00cf922d92240d85032cf76a335d496371a8b38b3fdba03cccdb9c0585','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('337df68ffbebac90999d2d5dfcba85c829d1cd1c1e67a3f1d1fd1392f2f5afea',1996,'EC','Ecuador','people-and-society',309,'Population: | 1.466.291 (July 1996 est.)
Age structure:
0-14 years: 35% (male 2.062.468: female
1.996.679)
15 64 vears: 60% (male 3.403.197; temale
3.489.728)
65 vears and over: 5% (male 241,217:
female 273.002) (July 1996 est.)
Population growth rate: |.96° (1996 est.)
Birth rate: 25.06 births/1.000 population
(1996 est.)
Death rate: 5.5 deaths/!.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/! 000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/temale
under 1% vears: 1.03 male(s)/female
15-44 vears. OYR male(sWtemale
OS years and over: O88 male(s)/female
oll aves: O99 male(s)/female (1996 est.)
Infant mortality rate: 34.8 deaths/i 000
live births (1996 est.)
Life expectancy at birth:
total population: 71.09 years
male: 68.49 years
female: 73.82 years (1996 est.)
Total fertility rate: 2.89 children born/
woman (1996 est.)
Nationality:
noun: Ecuadorian(s)
adjective. Ecuadorian
Ethnic divisions: mestizo (mixed Indian and
Spanish) 55%, Indian 25%, Spanish 10%,
black 10%
Religions: Roman Catholic 95
Languages: Spanish (official). Indian
languages (especially Quechua)
Literacy: age 15 and over can read and
write (1995 est.)
total population: YO.A%
male: 92%
female: 88.2%
Population: 24.523 408 July 1996 est.)
“ge structure:
0-14 vears: 35° (male 4.360.379. temale
4.214.970)
15-64 vears: 61% (male 7.480.747
7.375.825)
lemaie
65 vears and over: 4% (male 497.775
female 593.712) (July 1996 est.)
Population growth rate: |.74° (1996 es)
Birth rate: 24.33 births/i.000 population
(1996 est.)
Death rate: 6.13 deaths/!.000 population
(1996 est.)
Net migration rate: -0.76 migrant’s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1 OS maleisWtfemale
under 15 years: 1.03 maleisWfemale
15-64 vears: 1.01 maleisWtemale
65 vears and over: O84 maletsViemale
all aees’ 1.01 maleisWiemale (1996 est.)
Infant n.ortality rate: 92 2 deaths’! .000
live births (1996 est.)
Life expectancy at birth:
total population: 69.13 years
male: 66.97 years
female: 71.39 years (1996 est.)
Total fertility rate: 3.04 children born/
woman (1996 est.)
Nationality:
noun: Peruvians)
adjective: Peruvian
Ethnic divisions: indian 45°. mestizo
(mixed Indian and European ancestry) 37%
white 15%. black. Japanese, Chinese. and
other 3%
Religions: Roman Catholic
Languages: Spanish (official), Quechua
(official), Aymara
Literacy: aze 15 and over can read and
write (1995 est.)
total porslation: 88.7%
male: 94.5%
emaie: S3*«
Covernment
Name of country:
conventional lone form Republic 4 Peru
conventional short form: Peru
local long form: Republica del Pes
local short form: Peru
Data code: PE
Type of government: republn
Capital: Lima
Administrative divisions: 24 department
(departamentos, singular—depanamento) ain
| constitutenal province” (provincia
constitucional). Amazonas. Ancash
Apurimac. Arequipa. Ayacucho. Cajamarca
(allaw’
Junin. La Urbertad. Lambayeque. Lima
Loreto. Madre de Dios Moqguegua Pasco
Piura. Puno. San Martin. Tacna. Tumbes
Ucavals
Cusco. Huancavelica. Huanuco. Ica
note: the 1979 constitution mandated the
creation of regions (regrenes, singular
region) to function eventually as autonomou
economic and administrative entities: so iar
12 regions have been constituted tron
the 24 departments - Amazonas (fro
Loreto). Andres Avelino Caceres (fron
Huanuce, Pasce. Junin). Arequipe (ft
Arequips). Chavin (trom Ancash), Gr
ifrom Tumbes. Piura). Inca (from Cus
Madre de Dios. Apurmmac), La Libertad
(irom La Libertad). Los Libertadores-H
from tea. Avacucho. Huancavelica
Manategu (from Moquecua. Tacna. P
Nor Onental del Maranon (from
Lamba eque Cywamarca Amazonas). Sat
Martin (from San Mart
Lcaval): formation of another regron has
{ Kall) ily 1!
heen Gelaved by the reluctance of the
constitutional province of Callao to merge
with the department of Lima: because of
inadequate funding trom the centra
cevernment and orgamzational and 3
difficulties. the regions have vet t
major responsibilities: the 1993 consti
retains the regrons but limits ther oth
the 1993 constitution also reaffirms th
of departmental and mumecipal governn
Independence: 28 July |S.
National holiday: Independen
July (1821)
Constitution: 4! December 19°
Legal system: based on civil law oyster
has not accepted compulsory 1CJ
Suffrage: 18 vears of ge. UNIVeETSa
Executive branch:
chief of state and head of eovernmeni
President Alberto Kenyo FUITMORI
Fujnnorn (since 28 July 1990) was elected
;
iryyt } Snore
for a five-year term by universal sutlrage
379
Peru (continued)
election last held 9 April 1995 (next to be
held NA 2000). results—Alberto FUJIMORI
64.42°¢. Javier PEREZ de CUELLAR
21.80%. Mercedes CABANILLAS 4.11%,
hinet: Cou Ministers was appointed
yy the president
note. Prime Ministe: Alt PANDOLFI
Arbuit c \\ 1996) does not
Aercise eX Ve Por this. power is in
the hands of the president
tide Peal LPG tbak . ul
Legislative branch: up:camera!
( eress: electi ist held 9 April 1995
t to be held NA Ap 2000): results
COO/NM 52.1%. UPP 14°. 11 other parties
tis—( 129 shen imstalled on
S July Ss CYD/NN UPP 17, APRA
$. FIM 6, (CODE!-Pais Posible 5. AP 4.
PP¢ Renovacion 3. [CU 2, OBRAS 2. MIA
RENATRAC FREPAP |
fudicial branch: Supreme Court of Justice
tc Suprem ie Justicia)
Med DV the Na mal Council of the
Judiciary
Political parties and leaders: Change 90-
New Marority (C90/NM). Alberto
FUJIMORI, Unio r Peru CUPP), Javier
PEREZ de CURLLAR: American Popular
Revolutionary Alliance «: APRA). Agustin
MANTILLA Campos. Independent
Moralizing Front (FIM). Fernando
OLIVERA Vega: Democratic Coordinator
(CODE)—Pais Posible. Jose BARBA
Caballero and Alejandro TOLEDO; Popular
Action Party (AP). Ranl DIEZ CANSECO:
Popular Christian Party (PPC), Luis
BEDOYA Reyes: Renovacion, Ratael REY
Rey: Civic Works Movement (OBRAS).
Ricardo BELMONT, United Lett dU).
\\sustin HAYA de la TORRE: Indepeident
\\eranan Movement (MIA). Rolando
SALN ATERRIE: Peru 2000-National Front
t Workers and Peasants (FRENATRACA).
Roger CACARES: Popular Agricultural
Front (FREPAP). Ezequiel ATAUCUSI
Other political or pressure groups: leitist
nelude Shining Path.
\\bimael GUZMAN Reynoso (imprisoned):
ruemila groups 1
Fupac Amaru Re\\ Nutionary Movement.
Nestor SERPA and Victor POLAY
iprisoned
international organization participation:
or
(;-24. G-77. IADB. [AEA, IBRD, ICAO,
(PTL. ICRM. IDA, IFAD, TFC. TIFRCS.
ib) IMB IMO. Intelsat. Interpol, IOC.
jOM. ISO (correspondent), ITU, LAES.,
\\EA. NAM. OAS, OPANAL, PCA, RG.
\\ UNCTAD. UNESCO, UNIDO. UPU,
WoL WEEL. WHO, WIPO. WMO, WToOQ,
W int)
380
ECLAC. FAQ, G-11, G-15, G-19.
Diplomatic representation in US:
chief of mission: Ambassador Ricardo V.
LUNA MENDOZA
chancery: 1700 Massachusetts Avenue NW,
Washington, DC 20036
telephone. {1] (202) 833-9860 through 9869
FAX: [1] (202) 659-8124
consulate(s) general: Chicago, Houston, Los
Angeles, Miami, New York, Paterson (New
Jersey), and San Francisco
US diplomatic representation:
chief of mission: Ambassador Alvin P
ADAMS. Jr.
embassy: Avenida Encalada, Cuadra 17,
Monternco, Lima
mailing address: P. O. Box 1995. Lima 1:
American Embassy (Lima), APO AA 34031
telephone: {51} (12) 21-1202
FAX: {51} (12) 21-3543
Flag: three equal. vertical bands of red (hoist
side). white, and red with the coat of arms
centered in the white band: the coat of arms
features a shield bearing a Ilama. cinchona
tree (the source of quinine), and a yellow
cormucopia spilling out gold coins, all framed
by a green wreath','4c16fb4854815d2107a7d75a04ef4ff3b363c8a170c4f165286fb57b34ee0208','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3a2c3dad8ac6f7466c671849d97a1e2f6ab3aab3eb91af3291e86cfdf726378',1996,'SD','Sudan','people-and-society',315,'Population: 63.575.107 uly 1996 est.)
Age structure:
0-14 vears: 37% (male 11,970,197; female
11.462,689)
15-64 vears: 60% «male 19,127,696: female
18,738,304)
65 vears and over: 3% (male 1,028,916;
female 1.247.305) Guly 1996 est.)
Population growth rate: 1.91% (1996 est.)
Birth rate: 28.18 births/1.000 population
(1996 est.)
Death rate: 8.7 deaths/1.000 population
(1996 est.)
Net migration rate: -0.35 migrant(s)/1.000
population (1996 est.)
Sex ratio:
ca birth: 1.05 male(sfemale
under 15 vears: \\.04 male(sVfemale
15-64 vears: 1.02 maleisVfemale
65 vears and over: 0.82 male(s\\/temale
al! ages: 1.02 maletsVfemale (1996 est.)
Infant mortality rate: 72.8 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 61.43 years
male: 59.51 years
female: 63.46 years (1996 est.)
Total fertility rate: 3.58 children born/
woman (1996 est.)
Nationality:
noun; Egyptian(s)
adjective: Egyptian
Ethnic divisions: Eastern Hamitic stock
(Egyptians, Bedouins. and Berbers) 99%.
Greek, Nubian, Armenian, other European
(primarily Italian and French) 1%
Religions: Muslim (mostly Sunni) 94%
(official estimate), Coptic Christian and other
6% (official estimate)
Languages: Arabic (official), English and
French widely understood by educated
classes
Literacy: age 15 and over can read and
write (1995 est.)
total population: 51.4%
male; 63.6%
female: 38.8%
Population: | 9.409.058 (July 1996 est)
Age structure:
4 wed +4 male 4 S Oh) temale
$103.62
Ad ve $4 nule 6.394 384: female
+ ‘ s,s
nd ¢ >) tmale 227.789:
CTTiile S (hs (daily 199G *sI )
Population growth rate: 345° (1996 est.)
Birth rate: 38 32 births’! .000 population
| Que
Death rate: 5 $6 deaths/1.000 population
iV) est
Net migration rate: | 55 migrants) 1.000
ney OH est )
Sen ratio:
rth, 1 OS maletsvtemale
a 1038 maletsVfemale
J vears. 151 maletsVtemale
re and ever, 1.06 maleisVtemale
7 maletsVtemale (1996 est.)
Infant mortality rate: 46.4 deaths/ 1.000
mths Oe
Life expectancy at birth:
"4 Ho
1) Rd isa (1 LOUGH ests
lotal fertility rate: 6 45 children born
woman (1996 est
Nationality:
un Saudis)
adjective. Saudi or Saudi Arabian
Ethnic divisions: Arab 90%. Atro-Asian
1O%
Religions: Mustim 100%
Languages: Arabic
Literacy: age |S and over can read and
“MrTite | {995 esi ’
418
toial population: 62.8%
male: 71.5%
female: 30.2%
Population: 31.547.543 uly 1996 est)
Age structure:
0-14 vears, 46° (male 7.389.616. temale
7 OR80.044)
15.64 vears
8.172.544)
465 vears and over: 2% tmale 387.961
female 298.298) uly 1996 est.)
Population growth rate: 348°" (1996 est)
Birth rate: 41.08 births/1.000 population
(1996 est.)
Death rate: | 1.46 deaths/1.000 population
(1996 est)
$2 imale 8.219.080: temale
Net migration rate: 5.17
population (1996 est.)
Sex ratio:
at durth
migrants) 1.000
105 maleisWiemale
under «5 vears: 1.04 maleisWiemale
15-64 years. 1.01 maleisWhemak
45 years and over, 1.43 mateisWiemak
all aves
Infant mortolity rate: 76 deaths 1.000 live
births (1996 est }
Life expectancy at birth:
$S$.12 vears
1.03 maletsWtemale (1996 est.)
total population
54 2 ycars
S60 vears (1996 est)
male
female
Total fertility rate: 5.89 children born
woman (1996 est.)
Nationality:
noen: Sudanese (singular and plural)
Sudanese
Ethnic divisions: black 52°
Bea 6%
Religions: “unm Muslim 70%
Christian 5%
adjective
Arab 390%
loreigners 2°. other 1%
(in north)
imiigenous behels 25%
(mostly m south and Khartoum)
Languages: Avabic (official). Nubian, Ta
Nilo
Bedawite. diverse dialects of Niloty
Hamitic, Sudamec languages. English
457
note: program of Arabization im process
Literacy: age 15 and over can read and
write (°°9S est.)
total population: 46.1%
male: 37.7%
female: 34.6%','08663f0f5f6bb362a806804a49c691a9d5cfeb1da8b78fd58af4349b959bc7e1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29f59132c7d201e205b4c2738b9afbf5d2e20b12ee1854b1f620262b23974736',1996,'HN','Honduras','people-and-society',322,'Population: 5.828.987 uly 1996 est)
Age structure:
0-14 vears: 38% (male 1.137.804. temale
1 (997.774)
15-64 vears: 57
1.716.261)
45 vears and over: 8%
‘~« (male 1.627.519: female
(male 115.973
female 133.656) (luly 1996 est.)
Population growth rate: |. 8!) (1996 est)
Birth rate: 28.3 births/1.000 population
(1996 est.)
Death rate: 5.81 deaths/1.000 population
(1996 est.)
Net migration rate: -4.4 migrantisy/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 mateisWtemale
under 15 vears: 1.04 maleisWtemale
15-64 vears: 0.95 maleisVfemale
45 vears and over: 0.87 male(sWiemale
all ages: 0.98 male(sWiemale (1996 est.)
Infant mortality rate: 31.9 deaths/ 1.000
hive births (1996 est.)
Life expectancy at birth:
total population: OSS years
male: 65.44 vears
female: 72.5 vears (1996 est.)
Total fertility rate: 3.2 children born/
woman (1996 est)
Nationality:
noun. Salvadorant.)
adjective: Salvadoran
Ethnic divisions: mestizvo 94%. Indian 8°
white 1%
Religions: Roman Catholic 75%
note: there is extensive activity by Protestant
groups throughout the country, by the end of
1992. there were an esumated | million
Protestant evangelicals in El Salvador
Languages: Spanish, Nahua (among some
Indians)
Literacy: age 15 and over can read and
write (1995 est.)
twital population: 71S
male: 7ASG
143
(SA
El Saivador (continued)
(,overnment
Name of country:
conventional long form Republic of El
Salvador
conventional short form: EL Salvador
local long form: Republica de El Salvador
local short form: EL Salvador
Data code: ES
Iype of government: republic
Capital: San Salvador
\\dministrative divisions: |4 departments
departamento):
\\huachapan, Cabanas, Chalatenango,
Cuscatian. La Libertad. La Paz. La Umon
Morazan, San Miguel. San Salvador, Santa
Ana. San Vicente, Sonsonate. Usulutan
Independence: |* September 1821] (from
lepartamentes, singular
Sp in)
National holiday: Independence Day. 15
Semtember (1821)
(Constitution: 20 December 19834
Legal svstem: based on civil and Roman
aw. with traces of Common law: judicial
review of legrslative acts in the Supreme
Court, accepts compulsory 1CJ runsdiction,
with rescrs ations
Suffrage: |* years of ave. universal
Executive branch:
chiet of Mate and head of eovernmen
President Armando CALDERON Sol (since
994) and Vice President Ennque
BORGO Bustamante (since | June 1994)
were clected tor tive-vear terms by universal
uftrage. clection last held 20 March 1994
held NA March 1999), results
\\rmando CALDERON SOL (ARENA)
O85. Ruben ZAMORA Rivas (CD
PMIEN/MNR) 24.099. Fidel CHAV]
Mena (PDC) 16.399
candidate received a mayorty, a run-off
clecthon was held 24 April 1994, results
Armando CALDERON SOL (ARENA)
OX 880) Ruben ZAMORA Rivas (CD/
PMELN/MNR) 41.65%
abinet’ Counct! of Manisters
1 Jur
Th \\! te) hy
Levistative branch: unicameral
\\vsombly (Asamblea Legislativa)
ons last held 20 March 1994 (next to
be held NA March 1997): results - ARENA
64°. EFMLN 28.0%, PDC 21.4%, PCN
(84 total) ARENA
‘09 EMLN 21. PDC 18, PCN 4, other 2
Judicial branch: Supreme Court (Corte
18%. other 2.4%. seats
Suprema), judges are selected by the
Legislative Assembly
Political parties and leaders: National
Republican Alliance (ARENA), Juan Jose
144
other 10.49%: because
DOMENECH. president; Farabundo Marti
National Liberation Front (FMLN), Salvador
SANCHEZ Ceren (aka Leonel
GONZALEZ). general coordinator, Chnstian
Democratic Party (PDC), Ronal UMANA,
secreiary general; National Conciliation Party
(PCN), Ciro CRUZ Zepeda, secretary
general; Democratic Convergence (CD), Juan
Jose MARTEL. secretary general; Unity
Movement. Jorge MARTINEZ Menendez.
president
note: newly tormed parties not yet officially
recognized by the Supreme Electoral
Tribunal: Liberal Democratic Party (PLD).
Kino Waldo SALGADO, founder, Social
Democratic Party (breakaway from FMLN).
Joaguin VILLALOBOS. founder: Social
Christian Renovation Movement (MRSC)
(breakaway from PDC). Abraham
RODRIGUEZ. founder
Other political or pressure groups:
labor oreanizations: Salvadoran Communal
Union (UCS), peasant association, General
Contederation of Workers (CGT). moderate:
United Workers Front (FUT)
business organizations: Productive Alliance
(AP), conservative: Na ional Federation of
Salvadoran Small Businessmen (FENAPES).
conservative
International organization participation:
BCIE, CACM, ECLAC, FAO, G-77, IADB,
IAEA, IBRD, ICAO, ICFTU, ICRM, IDA,
IFAD, IFC. IFRCS, ILO, IMF, IMO.
Intelsat. Interpol. IOC, IOM, ITU, LAES.
LAIA (observer), MINURSO, NAM
(observer), OAS, OPANAL. PCA, UN,
UNCTAD, UNESCO, UNIDO, UPU. WCL.
WETU, WHO, WIPO, WMO, WTo00, WTrO
Diplomatic representation in US:
chief of mission: Ambassador Ana Cristina
SOL
chancery: 2308 Calitornia Street NW,
Washington, DC 20008
telephone: |1| (202) 265-9671, 9672
consulate(s) general: Chicago, Dallas.
Houston, Los Angeles, Miami, New Orleans.
New York, and San Francisco
LS diplomatic representation:
chief of mission: Ambassador Alan H
FLANIGAN
embassy: Final Boulevard Santa Elena,
Station Antiguo Cuscatlan, San Salvador
mailing address: Unit 3116, APO AA 34023
telephone: |S03\\ 278-4444
FAX: (503) 278-6011
Flag: three equal horizontal bands of blue
(top). white. and blue with the national coat
of arms centered in the white band: the coat
of arms features a round emblem encircled
by the words REPUBLICA DE EL
SALVADOR EN LA AMERICA
CENTRAL. similar to the flag of Nicaragua.
which has a different coat of arms centered
in the white band—1t features a tnangle
encircled by the words REPUBLICA DE
NICARAGUA on top and AMERICA
CENTRAL on the bottom: also similar to the
flag of Honduras, which has five blue stars
arranged in an X pattern centered in the
white band','31bfb5cc1bbef0a8731016c2ef16222c382cca0608aa54cd66ed7ea65b8a50e8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee4ffb34ef005c785a6e8ddf54bb0feb1912e38a449ecc39c8bcdb536f2480b1',1996,'ER','Eritrea','people-and-society',329,'Population: 3.427.853 WJuly 1996 est)
\\ge structure:
14 male 755.417: female
imale 910.976: temale
(male 54.310: female
; 4
> yea agave s
SO. Sid) cluly INH) est)
Population growth rate: 2.79% (1996 est.)
Birth rate: 43
| APL aty
» 7
S. Dirtns
| AO pv ulation
Death rate: |5 44 deaths’) .000 population
| \\phor
Net migration rate: 0 micrantisy/1.000
199 est
stinsated that between 300.000
(MH) Eritrean refugees were still
Sudan at end of 1995: then
patriation is berg tacilitated bv the
NHCR
Sex ratio:
hil Viemale
»Wtemale
hid i | male(si/temale
LOS matctsWtemale
iA) nale(sWtemale (1996 est.)
infant mortality rate: 115.9 deaths/! 006
Hirth iV’ est)
Lite expectancy at birth:
wopulation: S031 vears
; / ~ ! :
eval i Vealrs
2 (1996 est.)
Fetal fertility rate: 6.5 children born/
woman (1996 est.)
Nationality:
noun. Enitreant
Eritrean
Ethnic divisions: ethnic Tigrinya 51>. Tigre
and Kunama 40%, Afar +%. Saho (Red Sea
coast dwellers) 3%
Religions: Muslim. Coptic Christian, Roman
Catholic. Protestant
Languages: Atar. Amiaric. Arabic, italian.
Tigre and Kunama. Tigrinya. minor tribal
languages','2854ce1356b923aa81f97d608bfa357d2a2d22d38ae42f4735964af4c3040689','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a46e0a26cfd80249c50a752fd6cc2b958c9cb2a8c51e1f54e3c34d96872dcc93',1996,'ET','Ethiopia','people-and-society',338,'Population: 57.171.662 July 1996 est)
Age structure:
0-14 vears: 46% (male 13,116,158: female
1 3.080.276)
15-64 vears: SV% (male 14.782.995: temale
14.624.779)
65 years and over: 3% (male 728.808;
female 838.646) uly 1996 est.)
Population growth rate: 2.72°7 (1996 est.)
Birth rate: 46.05 births/1.000 population
(1996 est.)
Death rate:
(1996 est.)
Net migration rate: -| 36 migrant(s)/1.000
population (1996 est.)
7.53 deaths/1.000 population
note: repatriation of Ethiopians who fled to
Sudan. Kenya and Somalia tor refuge trom
war and tamine in earher years, ts expected
to continue in 1996, entry into Ethiopia of
Sudanese and Somalis fleeing the tighting in
their own countries ts also continuing in
1996
Sex ratio:
at birth: 1.03 male(stemale
under 15 vears: | malets)/temale
15-64 vears
65 vears and over
1.01 malets)/temale
0.87 male(s/temale
all ages: | malets)/temale (1996 est.)
Infant mortality rate: |22.8 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 46.85 years
male: 45.71 years
female: 48.02 years (1996 est)
Total fertility rate: 7 children born/woman
(1996 est.)
Nationality:
noun: Ethropiants)
adjective: Ethvopian
Ethnic divisions: Oromo 40%, Amhara and
Tigrean 32%, Sidamo 9%, Shankella 6%.
Somali 6%, Afar 4%, Gurage 2%. other 1%
Religions: Muslim 45-50%. Ethiopian
Orthodox 35%-40%, animist 12%. other 5%
Languages: Amharic (official), Tigrinya.
Orominga, Guaraginga. Somali, Arabic.
English (major foreign language taught in
schools)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 35.5%
male: 45.5%
female: 25 3%
Population:
total population 10.614.558 (July 1996 est.)
Montenegro: 635.442 July 1996 est.)
Serbia: 9.979.116 uly 1996 est.)
Age structure:
Vonteneero—0-14 years: 22% (male 71.075:
female 67.402)
Vontenegro—15-64 years: 67% (male
215.889: female 213.290)
Vontenegro—6S vears and over: 11% (male
27.868: female 39.918) (July 1996 est.)
Serbia—0-14 vears: 21% (male 1,104,274:
female 1.026.994)
Serbia—15-64 vears: 66% (male 3.332.809:
female 3,293,788)
Serbia—6S years and over: 13% (male
515.001; female 706,250) July 1996 est.)
Population growth rate:
Montenegro: 0.39% (1996 est.)
Serbia: 0.39% (1996 est.)
Birth rate:
Montenegro: 11.86 births/1.000 population
(1996 est.)
Serbia: 13.98 births/1.000 population (1996
est.)
Death rate:
Montenegro: 7.76 deaths/1.000 population
(1996 est.)
Serbia: 10.25 deaths/1,000 population (1996
est.)
Net migration rate:
Montenegro: -0.2 migrant(s)/ 1.000
population (1996 est.)
Serbia: 0.12 migrant(s)/1.000 population
(1996 est.)
Sex ratio:
Montenegro—at birth: 1.05 male(s)/female
Montenegro—under 15 years: 1.05 male(s)/
female
Montenegro—15-64 vears: 1.01 maletsV
temale
Montenegro—S5 vears and over: 0.7
male(s)/female
Montenegro—all ages: 0.98 male(s)/female
(1996 est.)
Serbia—at birth: 1.08 male(s)/female
Serbia—under 15 years: 1.08 male(s)/female
Serbia—15-64 vears: 1.01 male(s)/female
Serbia—6S5 vears and over: 0.73 male(s)/
female
Serbia—all ages: 0.98 malet(s\\V/female (1996
est.)
Infant mortality rate:
Montenegro: 27.5 deaths/1.000 live births
(1996 est.)
Serbia: 22.9 deaths/1.000 live births (1996
est.)
Life expectancy at birth:
Montenegro—total population: 74.88 years
Montenegro male: 70.86 years
Montenegro—female: 79.11 years (1996 est.)
Serbia—total population: 71.98 years
Serbia—male: 68.97 years
Serbia—female: 75.22 years (1996 est.)
Total fertility rate:
Vonteneero: 1.53 children born/woman
(1996 est.)
Serbia: 2 children born/woman (1996 est.)
Nationality:
noun: Serbis) and Montenegrin(s)
adjective: Serbian and Montenegrin
Ethnic divisions: Serbs 63°. Albanians
14°, Montenegrins 6. Hungarians 4%,
other 13%
Religions: Orthodox 65%. Muslim 19%.
Roman Catholic 4% . Protestant 1%, other
11%
Languages: Serbo-Croatian 95%. Albanian
S%
Literacy: NA
Af3/
Population: 9.629.151 uly 1996 est)
note: this estimate was derived from an
official census taken tn 1987 by the Somali
Government with the cooperation of the UN
and the US Bureau of the Census: population
estimates are updated year by year between
census years by factoring growth rates into
them. and by taking account of refugee
movements. and of losses due to famine
lower estimates of Somalia''s population in
mid-1996 (on the order of 6.0 to 6.5 million)
have been made by aid and relielt agencies
based on the number of persons being ted
population counting in Somalia ts
complicated by the large numbers of nomads
and by refugee movements in response to
famine and clan wartar
Age structure:
0-14 years: 44% (male
2.139.104)
15-64 years: 82% (mak
> 387.620)
~
~
~
o
4S years and ove: Mm, in € ALYY
female 175.750) (July i 99e
Population growth rate: yn
Birth rate: 44.17 births) 000
4 1YVH est.)
Death rate: 13.22 deaths/1.000 popula
(1996 est
Net migration rate: 0 micrant 1000
population (1996 est
Sex ratio:
at birth: 1.038 maletsivte
-
under 15 years: | male femal
15-64 vears’ 1.09 mak Wlemalk
65 vears and over: 1.04 maletsitemak
all ages: 1.05 maletsWtema 1YUH est
Infant mortality rate: |}2!) | deaths/ 1.000
live births (1996 est)
Life expectancy at birth:
total population: 55.49 years
male: SSA® years
437
somalia (continued)
1Wur esl }
ial fertility rate: 7.01 children born/
at)
tromality:
‘5
Bantu. Arabs
'' : : > ° . 1. . ¢
tinmee Givestoms: Somalh od" «
Kebvions: Sunn: Muslim
} iViiaves: ‘otticial). Arabic.
aver cal read and
iovernment
tf countrs:
Data comle St)
Ivpe of government:
Cupital: MI
\\dminaistrative divisions: |S regrons
NAL si uw-—-gobolka): Awdal
ah K Ban. Bay. Galguduud
f H in. Jubbada Dhexe. Jubbada
t) e. Mudu Nucaal. Sanuag. Shabeellaha
[ dha Shabeecilaha Hoose. Sool, Togdheer
N j Cs.;)
lndepe ndence: luly 1960 (from a merges
Brit Som nd. which became
t the UK on 26 June 1960
land. which became
t trom the Haulaa-administered
luly, 1960. to torm the
Nutronal holiday: “NA
( onstitution: 2S Aucust 1979. presidential
¢ ul sastem: NA
Sullrage: MIVeTSal
baeccutive branch: Somalia has no
nt. the United Somali
1 \\ ithe regime of Mayor
Se)
SLAD Barre on
t political situation
p by interclan
hom irs
Legislal .¢ branch: unicameral People s
\\
People Lvsembly (Golaha Shachtea). nor
lunchoning
Judicial branch: Supreme Court (not
lunchhonimneg)
Political parties and leaders: the United
Somali Congress (USC) ousted the tormet
regim 7 January 1991: formerly the
438
only party was the Somali Revolutionary
Socialist Party (SRSP), headed by former
President and Commander in Chief of the
Army Major General Mohamed SIAD Barre
Other political or pressure groups:
numerous clan and subclan factions are
currently vying for power
International organization participation:
ACP. AfDB. AFESD, AL. AMF. CAEU.
ECA. FAO, G-77, IBRD. ICAO. ICRM.
IDA, IDB. IFAD. IFC. IFRCS. IGADD.
ILO IMF, IMO. Intelsat. Interpol. (OC, 1OM
(observer, ITU. NAM. OAU. OIC, UN.
UNCTAD, UNESCO, UNHCR. UNIDO.
UPU. WETU. WilO. WIPO. WMO. WTrO
(observer)
Diplomatic representation in US: Somalia
does not have an embassy in the US (ceased
operations on 8 May 1991)
US diplomatic representation: the US does
not have an embas-y in Somalia: US
interests are represented by the US Embassy
in Narrobi at Mor Avence and Haile Selassie
Avenue. mail address: P.O. Box 30137,
Unit 64100, Nairobi, APO AE 09831:
lelephone: |254] (2) 334141: FAX [254] (2)
2.40% 38
Flag: light blue with a large white five
pomted star in the center: design based on
the flag of the UN (italian Somaliland was
a UN trust territory)','96a1d6150ef9ca8fd948e0eed9717de8c7a009f868cacb4834bbdb146e55a00a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7fc46297f83b7d8e075383e3585db0b2492e59f946975b05978dc4792f4f1c8',1996,'AR','Argentina','people-and-society',345,'Population: 2.374 July 1996 est)
Age structure:
0-14 vears: NA
15-64 vears: NA
65 vears and over: NA
Population growth rate: 2.43% (1996 est)
Birth rate: NA births/1.000 population
Death rate: NA deathy/1.000 population
Net migration rate: NA migrant(s)/1.000
population
Sex ratio:
at birth: NA maleisWtemale
under 15 vears: SA male(sWtemale
15-64 vears: NA malei(sWtemale
65 vears and over: NA maleisVtemale
all ages: NA maleisWtemale
Infant mortality rate: NA deaths! 000 live
births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/
woman
Nationality:
noun. Falkland Islanderis)
adjective: Falkland Island
Ethnic divisions: British
Religions: primanly Anglican, Roman
Catholic. United Free Church. Evangelist
Church. Jehovah''s Witnesses. Lutheran
Seventh-Day Adventist
Languages: English
Population: 5.504.146 Guly 1996 est.)
Age structure:
0-14 vears: 41% (male 1.144.644: female
1.096.430)
15-64 vears: 5S% (male 1.518.661. female
1.513.577)
65 vears and over: 4% (male 106.121.
female 124,713) Gluly 1996 est.)
Population growth rate: 2.67 (1996 est.)
Birth rate: 30.97 births/1.000 population
(1996 est.)
Death rate: 4.3) deaths/!.000 population
(1996 est.)
Net migration rate: 0 migrantis)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(sWfemale
15-64 vears: | male(sWtemale
65 vears and over: O85 malets\\/temale
all ages: 1.0) maletsWfemale (1996 est.)
Infant mortality rate: 23.2 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population. 73.84 years
male; 72.33 years
female: 75.43 years (1996 est.)
Total fertility rate: 4.15 children born/
woman (1996 est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic divisions: mestizo (mixed Spanish
and Indian) 95%. whites plus Amerindians
5%
Religions: Roman Catholic 90%, Mennonite
and other Protestant denominations
Languages: Spanish (official), Guarani
Literacy: age 15 and over can read and
write (1995 est.)
total population: 92.1%
male: 93.5%
female: 90.6%','d5ddd6ba45a31afbd2f02605dd25ebfc085f6b5dfc6ec6eda74911f7bd7b4819','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25ea407fa7d4ac892e7e73a7d9bf6e359940c5afa50245f5146159037aada5ab',1996,'FO','Faroe Islands','people-and-society',352,'Population: 43.857 Ululy 1996 est)
Age structure:
0-14 vears: 24% (male $5,461. female $,.280)
15-64 vears: 62% (male 14.488, female
12.617)
65 vears and over: i4% (male 2.661. female
3.350) uly 1996 est.)
Population growth rate: -|. 8% (1996 est)
Birth rate: 13.9) births/1.000 population
(1996 est.)
Death rate: 8.69 death:/1.000 population
(1996 est.)
Net migration rate: -23.19 migrant(s)/ 1.000
population (1996 est.)
Sex ratio:
at birth: 0.99 malet(si/temale
under 15 vears: 1.03 male(sWfemale
15-64 vears: 1.15 maletsWtemale
65 vears and over: 0.79 maleisi/female
all ages: 1.06 maletsWfemale (1996 est.)
Infant mortality rate: 7 2 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 77.83 years
male: 74.75 years
female: 80.88 years (1996 est.)
Total fertility rate: 2.38 children born/
woman (1996 est.)
Nationality:
noun: Faroese (singular and plural)
adjective: Farvese
ethnic divisions: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old
Norse). Danish
Literacy: NA','a27002cd4e004784a24346333b78d734c28a03685a22034735c48fa0dd990980','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b375f34e07a751c6d26f4c19673a3786a4f9b077f9b3226ffeb3e22a77600865',1996,'JE','Jersey','people-and-society',357,'Population: 782.38) Ululy 1996 est)
Age structure:
0-14 vears: 38% (male 141.652: female
135.529)
15-64 vears: 62% (male 240,621. female
240,600)
65 vears and over: ¥% (male 11.235: temale
12.424) July 1996 est.)
Population growth rate: | 28° (1996 est)
Birth rate: 23.37 births/1.000 population
(1996 est.)
Death rate: 6.35 deaths/1.000 population
(1996 est.)
Net migration rate: -4 22 migraatisy/1.000
population (1996 est.)
Sex pets:
ve rth: 1.05 maleisWtemale
under 15 vears: 1.04 male(sViemale
15-4 vears: | maleisWiemale
65 vears and over: 0.9 maleisVtemale
all ages: 1.01 maletsWiemale (1996 est.)
Infant mortality rate: 17.4 deaths’) .000
live berths (1996 est.)
Life expectancy at birth:
ttal population: 68.71 years
male: 63.39 years
female: 68.14 years (1996 est.)
Total fertility rate: 2.83 children born/
woman (1996 est.)
Nationality :
noun: Fipants)
adjective: Fiyan
Ethnic divisions: Fiyian 49%. Indian 46%.
European, other Pacific Islanders, overseas
Chinese, and other 5%
Religions: Christian 52° (Methodist 37%
Roman Catholic 9°), Hindu 38%. Muslim
RY. other 2%
note: Fipans are mainly Christian, Indians
are Hindu, and there ts a Muslim minority
(1986)
Languages: English (official), Fipan.
Hindustan
Literacy: age 1S and over can read and
write (1995 est.)
total population: 91.6%
male. YAR
female: RY4AG
/67
Population: 5.421.995 (July 1996 est.)
note: includes 127.600 Israeli settlers in the
West Bank. 14.800 in the Istaeli-occupied
Golan Heights. 5.000 in the Gaza Stnp, and
153.700 in East Jerusalem (August 1995 est.)
Age structure:
0-14 years: 29% (male 793.712: temale
756.735)
15-64 years: 62% (male 1,670,082: temale
1.669.481)
65 vears and over: 9% (male 230,082:
female 301,903) July 1996 est.)
Population growth rate: 2.11 (1996 est:
Birth rate: 20.31 births/1.000 population
(1996 est.)
Death rate: 6.26 deaths/1.000 population
(1996 est.)
Net migration rate: 7.03 migrant(s)/!.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 vears: | male(s)/temale
65 vears and over: 0.76 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 8.5 deaths/1.000 live
births (1996 est.)
Life expectancy at birth:
total population: 78.01 years
male: 76.16 years
female: 79.96 years (1996 est.)
Total fertility rate: 2.77 children born/
woman (1996 est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
Ethnic divisions: Jewish 82% (Israel-born
50%. Europe/Americas/Oceania-born 20%,
Atrica-born 7%, Asia-born 5%), non-Jewish
18% (mostly Arab) (1993 est.)
Religions: Judaism 82%. Islam 14% (mostly
Sunm Muslim). Christian 2. Druze and
other 2%
Languages: Hebrew (official). Arabic used
officially for Arab minority. English most
commonly used foreign language
Literacy: age 15 and over can read and
write (1992 est.)
total population: 95%
male: 97%
fe male: 93%
Population: 87.545 July 1996 est)
Age structure:
_ Se eee —
4 rs} Maile ‘ female /s4)
f+ vears. OY" male 29 YS: female
2045
fy dnd over ta male S107: temiale
7 $47 July i VY csi
Population growth rate: 0 77°) (1996 est
Birth rate: | 2.93 birthy 1.000 population
lYY6H est
Death rate: 9 21 deathy/1.000 population
| ApUty
Net migration rate: 4.0) migrantisy 1.000
pulaion (1996 est
SeN ratio:
| ars. LO? maletstemale
malets Wtemaie
fy qdii ‘ i « ‘7 1) 7 Midic \\? female
ves OYS maletsi/female (1996 est)
Infant mortalbty rates 27 deaths/ 1.000 live
VU) ¢ -| }
Life expectancy at birth:
/ figos 7% fy Vel
( Si 89 veal
lotal fertiiity rate: | 5 chidien born
ot
Nationalits:
Channel | naderts)
Channel [slande:
Lthnic divisions: | K and Norman-French
Religions: Anglican. Roman Catholic
baptist. Congregational New Church
Me diet. Presbyterian
Languages: |) h cotticnaly. French
Norman-bren dialect Spoken In
literacy: \\ \\
(,overnment
Name of country:
rm. Bailiwick of Jerses
‘ j snort form. Jerses
Data code: JI
Ivpe of government: British crown
nabene \\
Capital: Saint Helier
\\dministrative divisions: none (British
wh dependences
Independence: none (British crown
WPCndgenes |
National holiday: Liberation Day. 9 May
pay)
Constitution: unwritten. partly statutes
partly common law and practice
Legal svstem: English law and local statute
Suffrage: NA years of age. universal adult
Executive branch:
Chief of State: Queen ELIZABETH II (ot
the United Kingdom since 6 February 1952)
is a hereditary monarch
Head of Government: Lieutenant Governor
and Commander in Chiet Sir Michael
WILKES (since NA 1995) and Bailitt Philip
Martin BAILHACHE (since NA 1995) were
appointed by the queen
caine: committees Were appointed by the
Assembly of the States
Legislative branch: unicameral!
issembly of the States: elections last held
NA tnexi to be held NA): results—no
percent of vote by party since all are
independents: seats—( 56 total. 52 elected)
mdependents $2
Judicial branch: Royal Court. judges
elected by an electoral college and the bailitt
Political parties and leaders: none. al!
independents
International organization participation:
hone
Diplomatic representation in US: none
(Brotish crown dependency )
US diplomatic representation: none
British crown dependency )
Flag: white with the diagonal red cross of
Sait Patnick (patron saint of Ireland)
evtending to the comers of the fag
Population: no indigenous inhabnants
note—there are 1.200 US military and
civilian contractor personnel uly 1996 est
Population: 187.784 uly 1996 est)
Age structure:
0-14 years: 30% (male 28.941: temale
27.929)
15-64 years: 64% (male 61.263: female
$9.673)
65 vears and over: 6% (male 4.750: temale
§.228) July 1996 est.)
Population growth rate: 1.72% (1996 est)
Birth rate: 21.75 births/1.000 population
(1996 est.)
Death rate: 4.88 deaths/1.000 population
(1996 est}
Net migration rate: 0 3) nyerantisy4 000
population (1996 est.)
Sex ratio:
at birth: 1.05 maletsVtemale
1.04 malets female
1.023 maletsWtemale
under 1s yvears
15-64 years
65 vears and over: O91 maletsiWtemale
all ages. 1.02 maletsWtemale (1996 est)
Infant mortality rate: | 3.8 deaths) 1.000
live births (1996 est.)
Life expectancy at birth:
total poy ulation: 74.35 years
male” 71.06 years
female: 77.8 years (1996 est)
Total fertility rate: 253 childr i born
woman (1996 est)
Nationality:
noun: New Caledoniants)
adjective. New Caledonian
Ethnic divisions: Melanesian 42.5‘
European 37.1. Waltusian 8 4%
TA. Indonesian 3.6%,
Polynesian
Vietnamese | 6%
other 4%
Religions: Roman Catholic 60%
wi. other LOG
Languages: French. 28 Melanesian
Polynesian dialects
Protestant
Literacy: age 1S and over can read and
write (1976 est)
total population, OV
mule: 92
female: 9O%
Population: $547 983 Guly 1996 est)
Age structure:
(} / 4 Leal y ;
AW TSY)
(male 420.900. temalk
15-64 years: OS) Cmale LAGOL S22. temak
1 154.546)
OHS years and over 12% tale 177.182
lemale 233.684) (duly 1996 est)
Population growth rate: | 125 (1996 est)
Birth rate: 15.78 births/).000 population
1YUH est
Death rate:
(199) est)
> deaths/ 1.000 peru lation
Net migration rate: 817 migranticy 1.000
population (1996 est)
SeX ratio:
at durth: 1 OS matletsiWtematle
waier §> years: 10S maletsVtemale
19-4 years LOY malets Wt male
f)° cars and over, 0.76 male(sWtlemale
all aves: O98 maletsVtemale (1996 est.)
Infant mortatity rate: 6.7 deaths/ 1.000 hive
births (1996 est)
Life expectancy at birth:
total population: 771 years
male 73.96 vears
female. SO.21 vears (1996 est)
Total fertility rate: 2.01 children born/
woman (1996 est)
Nationality:
noun. New Zealanderis)
adjectve: New Zealand
Ethnic divisions: Luropean 88°. Maon
8.9%. Pacitie Islander 2.9%. other 0.2%
Re‘igions: Anglican 24‘¢. Presbyterian 1X7.
Roman Catholic 15. Methodist 5“. Baptist
vv
337 (1YNO)
Languages: English (olticial), Maon
Literacy: age 1S and over can read and
write (1YSO est)
total population, 9','3e4b399d9ed66b641d9693de4914d8267529373dce2360d42a56dbd5808ab057','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86b8b141f3080a688ad30b402ac67ca751ad6c02775708c0b3779bf61b3b575e',1996,'EE','Estonia','people-and-society',363,'Population: $105.28) Uuly 1996 est)
Age structure:
0-14 vears: 19% (male 492.616. female
471.7%)
1S-H5 vears: 67% (male 1.725.113. female
1.687.974)
65 vears and over: 14% (male 278.927.
female 451.864) duly 1996 est.)
Population growth rate: 0.1 (1996 est)
Birth rate: | 1.32 births/!.000 population
(1996 est)
Death rate: 10.92 deaths/!.000 population
(1996 est.)
Net migration rate: 0.58 migrant(sy/1.000
population (1996 est.)
Sex ratio:
at Sirth: 1.04 maleisytcmale
under 15 years: | O04 male(sWiemale
15-64 years: 1.02 malei(sWiemale
6% vears and over: 0.61 maleisWfemale
all ages: 0.96 maleisWtiemale (1996 est.)
Infant mortality rate: 4.9 deaths/|.000 live
births (1996 est.)
Life expectancy at birth:
total population: 75.47 years
male: 73.82 years
female: 77.18 years (1996 est.)
Total fertility rate: |.65 children born/
woman (1996 est.)
Nationality:
noun: Finnis)
adjective: Finnish
Ethnic divisions: Finn. Swede. Lapp.
Gypsy. Tatar
Religions: Evangelical Lutheran 89%. Greek
Orthodo,. 1%, none 9%, other 1%
t_amguages: Finnish 93.5% (official).
Swedish 6.3% (official). small Lapp- and
Russian speaking minorities
Literacy: age 15 and over can read and
write (1980 est.)
total population: \\OO%
mal-: NAG
female: NAG
Covernment
Name of country:
conventional long form: Repebdlic of Finland
conventional short form. Finland
local lone form: Swomen Tasavalta
local short form: Sworm
Data code: Fl
Type of government: republic
Capital: Helsink:
Administrative divisions: |) provinces
(laanit. singular—laam): Ahvenanmaa.
Hame. Keski-Suomi, Kuopio, Kym. Lappi
Mikkeli. Oulu. Pohjots-Karjala. Turku ja
Pon. Uusimaa, Vaasa
Independence: 6 December 1917 (from
Soviet Union)
National holiday: Independence Day. 6
December (1917)
Constitution: 17 July 1919
! egal system: civil law system based on
»wedish law. Supreme Court may request
legislation interpreting or modifying laws.
accepts compulsory IC) jurisdiction, with
PESeTy ATO
Suffrage: 18 years of age: universal
Executive braoch:
chief of state: Presademt Marti AHTISAARI
isimoe | March 1994) was elected for a six
year term by popular vote: clection last held
31 January-6 February 1994 (next te be held
NA January 2000). results—Martu
AHTISAARI 54%. Elisabeth REHN 46%
head of eovernment: Prime Minister Paavo
LIPPONEN (since 13 April 1995) and
Deputy Prime Minister Sauli NIINISTO
(since 13 Apnl 1995) were appointec * *he
president
cabinet: Counct| of State (Valioncuvosto)
was appointed by the president. responsible
to Parliament
Legislative branch: unk ameral
"arliament ( Eduskunta): elections last held
19 March 1995 (ext to be held NA March
1999): results - ~ocial Democrauc Party
28.39. Center lait) 19.9%. National
Coalition (Conservative) Party 17.9%
Alhance (Commur’ .) 11.2%. Swedish
People''s Party 5.1%. Green I eague 6.5%
Ecology Pany 0.3%. Rural 1.3%. Finnish
Christian League 3.0°%., Liberal People''s
Party 0.6%. Young Finns 2.8%. seats 20)
total) Social Democratic Party 63. Center
Party 44. National Coalition (Conservative)
Party 39. Leftsst Alliance (Communist) 22
Swedish People’s Party ''\\. Green League 9
Ecology Party |. Rural 1. Finnish Christian
League 7. Young Finns 2. Aaland Islands ''
Judicial branch: Sworeme Court (Korkei
Oikeus). judges appoimed by the president
Political parties and leaders:
government coalition. Social Democrat~
Party. Paavo LIPPONEN, National Coalition
jconservative) Party. Saul: NIINISTO
Lett Alhance (Communrst) People’s
Letts
Democratic League and Democrat
Alternative. Claes ANDERSSON. Swedish
People''s Party, Johan) Ole NOP RBACK
Green League. Pekka HAAVISTO
other: Cemer Party. Esko AHO, Finnish
Christian League. Torm KANKAANNIEMI
Rural Party. Raamo VISTBACKA, Libera!
People''s Party. Tuulikki UKRKOLA,; Greens
Ecological Party (EPV). Young Finns. Risto
PENTTILAE
Other political or pressure groups: Finnish
Communit Party-Unity. Yroo HAKANEN
Constitutional Rightest Party: Finnish
Pensioners Party, Communist Workers Party
Timo LAHDENMAKI
International organization participation:
AIDS. AG (observer). AsDB. Australia
Group, BIS. CBSS, COC, CE. CERN
EBRD. BCE. EIB. ESA. EU. FAO. G- 9
IADB. IAEA, IBRD. ICAO. ICC. ICFT!
ICRM. IDA. TEA. IFAD. TRC, IFRCS, ILO
IMF. IMO. Inmarsat. Intelsat. Interpol, 10%
1OM. ISO. 1TU, MTCR. NACC. NAM
(gues), NC. NEA. NIB, NSG. OAS
tobserver) OECD. OSCE. PCA, PFP. UN
UNCRO. UNCTAD, UNESCO. UNFICYP
UNHCR, UNIDO. UNTFIL. UNIKOM
UNMOGIP. UNPREDEP, UNPROFOR
UNTSO., UPL. WEU Cobserver), WET!
WHO. WIPO. WMO. WTo®. WTrO. 7
161
representation in
promote stability. Ongoing speculation
resulting from a lack of confidence 1n the
government s policies forced Helsinki to
devalue the markka DY adoul 12%
November 1991 and to indefinitely break the
in
na in Sepiempe! 1992. The devaluations
have boosted the competitiveness of Finnish
exports. The recession bottomed out in 1993,
ind Finland participated in the general
-uropean upturn of 1994. Unemployment
whably will remain a serous problem
the next few vears: the maporty of
bins firms tace a weak domestic marke
bled German and Swedish expor
Acts. The Finns voted in an October i994
(,DPr SY? 4
(.DP real growth rate:
(.DP per capita ms
(.07 composition by sector
beet ’ " hi rsa prices
’ a? Teor ‘
L '' itmil il
''
'' nithom ¢ ath ott
; ,
ermoultur
lhincet drugs
v\\ i
haports: 529 7 | 4
; |
HSU 4 ny4
Imports: $23.2 billion (ct. 1994
partners: EU 44
commodities: toodstutts, petroleum and
petroleum products, chemicals. transport
eyguipment, iron and steel. machinery, textile
yarn and fabrics. fodder grains
(Germany 15‘°. UK
8.347). Sweden 10.4%, US 7.67. Japan
65°C. FSU 10.5
External debt: $30 billion (December 1993)
Economic aid:
donor: ODA, $355 million (1993)
Currency: | markka (FMk) or Finmark =
(1994)
100 pennia
Exchange rates: markkaa (FMk) per
U''SS1—4.4425 VGanuary 1996). 4.3667
1995). 5.2235 (1994). $.7123 (1993). 4.4794
1992), 40440 01991)
Fiscal vear: calendar year
Population: 2.468.982 (July 1996 est)
Age structure:
0-14 vears: MI (male 254.664: temale
244.502)
15-64 vears: 66° (male 775.690; female
848.128)
65 vears and over. 14% tmale LOS S14:
female 237.184) July 1996 est.)
Population growth rate: -| 39% (1996 est)
Birth rate: 10.94 births/! 000 population
(1996 est)
Death rate: 15.19 deaths/1.000 population
(1996 est.)
Net migration rate: -9.69 migrant(s)/i 000
population (1996 est.)
Sex ratio:
af birth: 1.05 malets/temaie
under 15 vears: 1.04 male(stemale
15-64 vears: 0.92 male(si/temale
65 years and over: 0.46 male(s)V/temale
all ages: O86 malets)/temale (1996 est.)
Infant mortality rate: 2) 2 deaths/ | 000
live births (1996 est.)
Life expectancy at birth:
total population: 66.91 vears
male: 60.84 years
female: 73.27 years (1996 est.)
Total fertility rate: |.62 children born/
woman (1996 est.)
Nationality:
noun: Latviants)
adjective: Latvian
Ethnic divisions: Latyein S1.8o°. Russian
33.87. Byelorussian 4.54. Ukrainian 3.4%.
Polish 2.3. other 4.2%
Religions: Lutheran. Roman Catholic
Russian Orthodox
Languages: Lettish (official). Lithuanian.
Russian, other
Literacy: age 15 and over can read and
Vrite (L989 est.)
total population: VOO%
male: LAO
female: 99%','9c78d45546ae08779ecb5819533bf7bbe8d1ba2eba5ad0c7c544dc14ee51165b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56cd06391a21d598a6043a1178fa757dbc1a99dd6c609bb9f3a676875577c04b',1996,'GF','French Guiana','people-and-society',376,'Population: 151.)87 uly 1996 est)
Avge structure:
> ,
cal 3) * (male 24.44 female
s}
4 vears: 68 (male 52.061. tematle
As j s 7 Jj ''
‘) Cais did Ove ( (male ‘ 4 female
9}; duly 1996 est)
Population growth rate: 3.865" (1996 est)
Birth rate: 24.68 binths/1.000 population
Le est.)
Death rate: 4.59 deaths/ 1.000 population
1YUH est)
Net migration rate: | S.52 migrants) 1.000
wihutlion (1996 est
Sex ratio:
; ws 4 hale hel i]
/ OS male female
; ‘ } 1 il s em ile
f ‘ } Vile ema
fel | yur I
Infant mortality rate: |}4.6 deat! (MM)
pipe
Life expectancy at birth:
+ ;
; par
lotal fertility rate
Nationality
i (;
Lthnw divisions
’ {
Religions '' ‘
languages: |
1 steracs
(,overnment
Name of country
)
j j } } neh Crutana
hon for Ceti athe
Data code: FG
Type of government: overseas department
of France
Capital: Cayenne
Administrative divisions: none (overseas
department of France)
Independence: none (overseas department of
France)
National holiday: National Day. Taking of
the Bastille. 14 July (1789)
Constitution: 28 September 1958 (French
Constitution)
Legal system: French legal system
Suffrage: |S ycars of age: universal
Executive branch:
chief of state: President (ot France) Jacques
CHIRAC (since 17 May 1995): represented
by Prefect Pierre DARTOUT who vas
appointed by the French Ministry of Interior
head of eovernment: President of the
General Council Stephan PHINERA-HORTH
(since March 1994)
Legislative branch: unicameral Genera!
Council and a unicameral Regional Council
Geacral Council: elections last heid NA
March 1994 (next to be held NA): results
percent of vote by party NA. seats—119
total) PSG &. RPR 2. UDF 1. other nght |
ihe
Regional Council: electvons last held 22
March 1992 (neat to be held NA): results
percent of vote by party NA: seats—4 41
PSG 16. FDG 10, RPR 2. independent
} \\ te elect last held 24
S NY (NEA he held S h
1s { party NA
PSG
} \\ \\
~\\ ")
NA 199% roent of vote |
\\\\ KPR
judicial branch: | vy
\\I
\\1 {
} (
Political parties and leaders
raii ) \\\\ ( ‘
LDF) R CHOW CHIN]
International organization participation:
7 WOOL. WEI
Diplomatic representation in US
i i epa4t i |
LS diplomatic representation:
is department of Fran
blag: the Haw ay bran i uj ed
Economy Economic aid: French Polvnesia
: . recynent: ODA, SNA (overse: ance
Economic overview: The economy ts tied —— arerangs tavviary ef Pounce)
Currency: | French franc (F) = 100
closely to that of France through subsidies
and imports. Besides the French space center CORMERES
at Kourou, fishing and forestry are the most Exchange rates: French francs (F) per
important economic activities, with exports USSI—5.0056 Ganuary 1996), 4.9915
oi fish and fish products (mostly shrimp) (1995), 5.5520 (1994), 5.6632 (1993), 5.2938
“~ «
accounting for more than 60° of total (1992), 5.6421 (1991)
revenue in 1992. The large reserves of Fiscal year: calendar year
tropical hardwoods, not fully exploited.
support an expanding sawmill industry that
provides sawn logs for export. Cultivation of
crops ts limited to the coastal area, where the Transportation
population ts largely concentrated. French Retways: () km (1995)
Guiana ts heavily dependent on imports of Highways:
flood and energy. Unemployment ts a serous - -
total: 1.817 km (national 432 km
problem, particularly among younget —
departmental 385 km. community 1.000 km)
paved: 727 km
unpaved 1 .Y0 kim (199S est
workers
GDP: purchasing power parity —S800
million (1993 est.)
GDP real growth rate: NA‘
GDP per capita: $6,000 (1993 est.)
Waterways: 460 km. navigable by small
. 4 . » . ;
oceangomg Vessels and river and coastal
. a ‘amers: 3.300 avigable by native
GDP composition by sector: Meamers. 35.00 km navigable by nati
NAG Ports: Cayenne. Degrad des C.
avericulture
NAG Laurent du Maron
dustry Geography
services: NAS% Merchant marine: none |
Location: Ocear
Pp tix ()
South America to Australia
‘ . “ae i Su) 1Qyues nuda pa cd Pidsind '' ;. |
Labor force: 46 (| pe Geographic coordinates: 15 00S. 140 00
Inflation rate (consumer prices): 25° \\irports:
(109), total: VO
by occupan services, government, anc Wn pared TUNWUNS lod... \\A
commerce 60.66 . industry 21.2’ Wali pa Wadys “ I Viap references: ©
agneculture 18.2% (1980) wih unpaved runways GI4 t v8 ’ \\rea
Lnemployment rate: 24 15) (1993 ¢ (1995 est
Budget:
/ ws. SUTSS million
lures: S284 million. including ca
of SNA (199? ev Communications
Industries: nstruction Winhip pre Felephones: t) in) Land boundaries:
forestry products. nr hd ( ousthine ‘4
lelephone system:
5
Industrial production growth rate: laritime claims
Flectricity:
International disputes
init 1 (Atlantic © ( limate
Radio broadcast stations: \\ ; lerrain
/
Avriculture
Radios: 79 00
iMicit drugs: lelevision broadcast stations
( .
I eles isions LL ”") Natural resources
|
Land use
hAports:
ii
Defense
Branches: |) h |
Me Man™ wer availability: Irrivated land
Imports: 4 million 7 1-4Y 484 bnvironment
7h "
petroleum Defense expenditures:
mariners i>. Germany It’
| eonbd m Defense note: deten
a | ti (
External debt: S| .2 billion C1988) irchipela Mal
Loy Ceeographic note:
‘rench Polynesia (continued)
| ic \\
t () | ttl
i) j j Ki nail na N\\
?
Population: ; ei
Age structure:
»
‘ i
7
Population growth rate: 2.19 ye
Birth rate My
1) rat
Net migration rat KM)
Ni 1
ear
Infant mortalits rate ny
Life expectancy at birth
lotal fertihts rate
‘ 1} ''
Litera
(,overnment
Nul tf countrys
by
I }?
}
168
local short form: Polynesie Francaise
Data code: FP
Type of government: overseas termiory of
France since 1946
Capital: Papecte
Administrative divisions: none (overseas
territory of Fran there are no ftirst-ordes
admunistratve divisions as defined by the US
Government, but there are 5 archipr agi
livisions named Archipel des Marquise
Archipel des Tuamotu, Archipel des Tubuas
les du Vent. and Iles Sous-le-Vent
we: Clipperton [sland ts administered by
France trom French Polynesia
Independence: none (overseas territory of
France)
National holiday: National Day
the Bastille
Cunstitution: 28 September 1958 (rrench
laking of
14 July C1789)
Constitution)
Legal system: based on French system
Suffrage: iS years of age: universal
Executive branch:
heel of State: President an nee) Jacques
CHIRAC (sin May 1995): represented
by High Commi ner cf the Republic Paul
RONCIERE (since & Auygust 1994) who was
ippointed by the French Ministry of Interior
head of eovernment: President of the
Permtorial Government of French Polynesia
Gaston FLOSSE (since 4 April 1991
Py lent of the Terrtornal Assembly
| mapa EBB (sunce NA)
Council of Ministers: president
1’ | | | nembel iy] tat lerrntor |
| evistative branch:
\\ t held
M i) (NA Marcel
by party NA
}? ke ’ }
sp
\\ |
. NA
.\\ . NA
|
\\ "
SAM —
NA Py k
kx (
judicial branch: Court of Appeal. | taf
| { tof Ad
Political parties and leaders: Peop!
} t Reput luhoeraa Hurraatira
Gaston FLOSSE.: Polynesian Union Par
| | | ind He Ara Party
lean JUVENTIN “« Fatherland Party
Via Ay bmile VERNAUDON
wWependent Party (la Mana Te Nunaa
lacgues DROLLET: Te Aratiua Ote Nunaa
linomana EBB; Haere 1 Mua, Alexandre
LEONTIEFF: other small parties
International organization participation:
ESCAP (associate), FZ, (CFTU, SPC, WMO
Diplomatic representation in US: none
(overseas territory of France)
US diplomatic representation: none
overseas territory of France)
Plag: two narrow red horizontal bands
encase 2 wide while band: centered on the
white band ts a disk with blue and white
wave patiern on the lower half and gold and
White ray pattern on the upper halt: a
stylized red. blue and white ship ndes on the
wave pattem: the French tag is used tor
official occaspons
kconomy)
Economic overview: Since 1962. when
France stationed military personnel in the
region. French Polynesia has changed trom a
subsistence economy to one min which a high
proportion of the work force is either
eirployed by the military or supports the
jourmt industry. Toursm accounts tor about
0% of GDP and ts a primary source of hard
currency earnings. The territory wall continuc
to benetit trom a tive-vear (1994-98)
development agreement with France aimed
principally at creating new jobs
GDP: purchasing power parity-—S1.76
billion (1998S est)
GDP real growth rate: NA
GDP per capita: S8.000 (1995 est
GDP composition by sector:
Inflation rate (consumer prices): | 5
aE |
Labor force: 76.630 employed (198%
Pahoa recuiul 14 Lit
\\) eTvicy {y* jy” “|
Lnemployment rate: \\ A’
Budyet:
Industries: tourtsm. pe
Industrial production growth rate: \\ A
bLlectricity:
SOOO KM
j ; ,4ian Wi
( cr capt SY KWh 1994
Agriculture: coconuts, vanilla. vevetabl
iltry. beet. dairy product
hxports: SU) million of } you
munod ullured pearls 41.6 coconul
oduct Neral py wl. vanitla. shark meat
ay
winers. Pra ‘4 US 100 (199)
(77
Imports: $912 million (cif, 1994)
commodities: tucls, toodstufts, equipment
partners: ECE 64 (France 45.4%). US
13.6%, Australia 6.9%, NZ 5.8%, Japan 5%
(1992)
External cebt: SNA
Economic aia:
recipient: ODA, >>. \\
Currency: | CFP tranc (CPF) = 100
centimes
Exchange rates: Comptoirs Francais du
Pacifique francs (CFPF) per USS1—91.00
(January 1996). 90.75 (1995). 190.94 (1994).
102.96 (1993), 96.24 (1992), 102.57 (1991).
note—linked at the rate of 18.18 to the
French trance
Fiscal year: calendar year
Population: no indigenous mhabitant
mve—there were 1445 619948) mosth
researchers who / m tf ! |
(July) to summer (January
Population: | 204.984 uly 1996 est)
Age structure:
0-14 vears: 46% (male 276.782: female
275.683)
15-64 vears: 51% (male 307.405; temale
312.736)
65 vears and over: ¥% (male 17.278: temale
15.100) uly 1996 est.)
Population growth rate: 3.55% (1996 est)
Birth rate: 44.44 births/!.000 population
(1996 est.)
Death rate: | 3.66 deaths/!.000 population
(1996 est.)
Net migration rate: 4.72 migrantisy/ 1.000
population (1996 est.)
Sex ratio:
al birth: 1.03 maleisVtemale
under 15 vears: | male(sWtemale
15-64 vears: OY maletsitemale
65 vears and over: 1.14 male(sWtemale
all ages: | maletsVWtemale (1996 est.)
Infant mortality rate: 80.5 deaths! 000
live Sirths (1996 est)
Life expectancy at birth:
rial population: 52.96 years
male SO.74 vears
female, 38.24 vears (1996 es.)
lotal fertility rate: 6.06 cluildren born
woman (1996 est)
Nationality:
noun. Gamhants)
adjective. Gamian
iMandienka
hola 10
Ethnic divisioms: African 99
i> Fula {8 Waolot 16
Serahul) ¥ mher 4
Religions: Muslim 9"
mn-Crambhion |
{ hristian y
imalive mys hx lets
Languages: Laglish (ottmal) Mandimka
Wolot) Fula. etaer mdigenous vernacular.
Literacy: ave |S and ran read and
write (14S est
paorragecal ian tk h
<r ‘ s','9ea0f93ed26e708595daac0f8b2e563fff8f4a1ac153046da0c941c27ae693a4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad8527764eff4d052fc8b109dbcad59f82720922423b17da677cd37b2d41fdc0',1996,'IL','Israel','people-and-society',382,'Population: 923.940 (July 1996 est.)
note: in addition, there are 5,000 Israeli
settlers in the Gaza Strip (August 1995 est.)
Age structure:
0-14 vears: 52% (male 244.026: female
231.9706)
15-64 vears: 46% (male 210.706: female
210.764)
65 vears and over: 2% (male 11.553: temale
14.915) July 1996 est.)
Population growth rate: 6.79% (1996 est.)
Birth rate: 50.67 births/1.000 population
(1996 est.)
Death rate: 4.4 deaths/1.000 population
(1996 est.)
Net migration rate: 21.65 migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 vears: 1.05 male(s)/female
15-64 vears: | male(s)/female
65 vears and over: 0.78 male(s)/female
all ages: 1.02 male(sWtemale (1996 est.)
Infant me tality rate: 27.5 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 71.98 years
male: 70.69 years
female: 73.34 years (1996 est.)
Total fertility rate: 7.79 children born/
woman (1996 est.)
Nationality:
noun: NA
adjectt\\ e: NA
Ethnic divisions: Palestinian Arab and other
99.4. Jewish 0.6%
Religions: Muslim (predominantly Sunni)
98.7. Christian 0.7°C, Jewish 0.6%
Languages: Arabic. Hebrew (spoken by
Israeli settlers). English (widely understood)
Literacy: NA','03dc3f106cf659aec5fe6b13c3f370e356ae877ba2f2e746002ed88ca78c2ae2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b029578b43861c7f998b11678f275781dd571b02b7ca5fd703de8da38a91b2e',1996,'GE','Georgia','people-and-society',389,'Population: 5.219.8!0 (July 1996 est.)
Age structure:
0-14 vears: 22% (male 595,524: female
$71.207)
15-64 vears: 66° (male 1.643.506; female
1.784.286)
65 vears and over: 12% (male 229.910;
female 395.377) (July 1996 est.)
Population growth rate: -!.02 (1996 est.)
Birth rate: 12.81 births/1.000 population
(1996 est.)
Death rate: 12.21 deaths/1.000 population
(1996 est.)
Net migration rate: -10.82 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 vears: 1.04 male(s)/female
15-64 vears: 0.92 male(s)/female
65 vears and over: 0.58 male(s)/femaie
all ages: 0.9 male(s)/female (1996 est.)
Infant mortality rate: 22.5 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 68.09 years
male: 63.43 years
female: 72.98 years (1996 est.)
Total fertility rate: 1.69 children born/
woman (1996 est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
135
Ethnic divisions: Georgian 70.1%,
Armenian 8.1%, Russian 6.3, Azer 5.7%,
Ossetian 3, Abkhaz 1.8%, other 5%
Religions: Christian Orthodox 75%
(Georgian Orthodox 65°C, Russian Orthodox
10%), Muslim 11, Armenian Apostolic
87, unknown 6%
Languages: Armenian 7°, Azeri 6%.
Georgian 71 (official), Russian 9%, other
7%
Literacy: age 15 and over can read and
write (1989 est.)
total population: 99%
male: \\OO%
female: 98@
Population: 9.019.687 (uly 1996 est.)
Age structure:
0-14 years: 34% (male 1,583,636; female
1.489.784)
15-64 years: 61% (male 2,738,013; female
2.719.998)
65 years and over: 5% (male 254,403;
female 233.853) (July 1996 est.)
Population growth rate: |.81% (1996 est.)
Birth rate: 24.03 births/1,000 population
(1996 est.)
Death rate: 5.18 deaths/!,000 population
(1996 est.)
Net migration rate: -0.74 migrant(s)/1,000
population (1996 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.91 male(s)/female
480
65 years and over: 1.09 male(s)/female
all ages: 1.03 male(s)/female (1996 est.)
Infant mortality rate: 35.1 deaths’! ,000
live births (1996 est.)
Life expectancy at birth:
total population: 72.6 years
male: 71.27 years
female: 74.03 years (1996 est.)
Total fertility rate: 2.92 children born/
woman (1996 est.)
Nationality:
noun: Tunisian(s)
adjective: Tunisian
Ethnic divisions: Arab-Berber 98%.
European 1%, Jewish less than 1%
Religions: Muslim 98%, Christian 1%,
Jewish 1%
Languages: Arabic (official and one of the
languages of commerce), French (commerce)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 66.7%
male: 78.6%
female: 54.6%
Population: 62,484,478 (July 1996 est.)
Age structure:
0-14 years: 32% (male 10,192,195; female
9.836.045)
18-64 years: 62% (male 19,859,717; female
19,187,769)
65 vears and over: 6% (male 1.571.451:
temale 1,837,301) (July 1996 est.)
Population growth rate: 1.67% (1996 est.)
Birth rate: 22.26 births/1!,000 population
(1996 est.)
Death rate: 5.52 deaths’! 00 population
(1996 est.)
Net migration rate: ) migrant(s)/!.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.86 male(s)/female
all ages: 1.02 malets\\/female (1996 est.)
Infant mortality rate: 43.2 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 71.92 years
male; 69.53 years
female: 74.43 years (1996 est.)
Total fertility rate: 2.58 children born/
woman (1996 est.)
Nationality:
noun: Turk(s)
adjective: Turkish
Ethnic divisions: Turkish 80%, Kurdish
20%
Religions: Muslim 99.8% (mostly Sunni),
other 0.2% (Christian and Jews)
Languages: Turkish (official), Kurdish,
Arabic
Literacy: age 15 and over can read and
write (1995 est.)
total population: 82.3%
male: 91.7%
female: 72.4%
Population: 4,149,283 (July 1996 est.)
Age structure:
0-14 years: 39% (male 826,637; fem |
804,385)
15-64 years: 56% (male 1,154,415; female
1,188,173)
65 years and over: 5% (male 65,447; femaie
110,226) (July 1996 est.)
Population growth rate: |.82% (1996 est.)
Birth rate: 29.12 births/1,000 population
(1996 est.)
Death rate: 8.89 deaths/!,000 peyulation
(1996 est.)
Net migration rate: -2.08 migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: \\.03 male(s)/female
15-64 years: 0.97 male(s)/female
65 vears and over: 0.59 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 81.6 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population. 61.48 years
male: 56.68 years
female: 66.52 years (1996 est.)
Total fertility rate: 3.62 children born/
woman (1996 est.)
Nationality:
noun: Turkmen(s)
adjective: Turkmen
Ethnic divisions: Turkmen 73.3%, Russian
9.8%, Uzbek 9%, Kazak 2%, other 5.9%
Religions: Muslim 87%, Eastern Orthodox
11%, unknown 2%
Languages: Turkmen 72%, Russian 12%,
Uzbek 9%, other 7%
Literacy: a‘e 15 and over can read and
write (1959 est.)
total population: 98%
male: 99%
female: 97%','a42f0d493d6b5a2daf94d7419b40ace876ed73ea82795d5a3607ab6324b7499d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bcfb761887a697ebc90c58ae05a97ee8a43022fd386c549abf7ede46e8229e3',1996,'DE','Germany','people-and-society',394,'Population: 83.536.115 July 1996 est.)
Age structure:
0-14 vears: 16.15% (male 6.928.750: female
6.563.026)
15-64 vears: 68.52% (male 29,339,780:
female 27,.902.549)
65 vears and over: 15.33% (male 4.658.014:
female 8.143.996) (July 1996 est.)
Population growth rate: 0.67 (1996 est.)
Birth rate: 9.66 births/1.000 population
(1996 est.)
Death rate: 12.21 deaths/1.000 population
(1996 est.)
Net migration rate: §.25 migrant(s)/1.000
population (195 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 vears: 1.06 male(s)/female
15-64 vears: 1.05 male(s)/female
65 vears and over: 0.57 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 6 deaths/1.000 live
births (1996 est.)
Life expectancy at birth:
total population: 75.95 year:
male; 72.8 years
female: 79.27 years (1996 est.)
Total fertility rate: 1.3 children born/
woman (1996 est.)
Nationality:
noun: German(s)
adjective: German
Ethnic divisions: German 95.1‘, Turkish
2.3%. Italians 0.7%, Greeks 0.4%, Poles
0.4%, other 1.1% (made up largely of people
fleeing the war in the former Yugoslavia)
Religions: Protestant 457, Roman Catholic
37%, unaftiliated or other 18%
Languages: German
Literacy: age 15 and over can read and
write (1977 est.)
total population: 99%
male: NAG%
female: NA“','1f31784a3956151bb49d768fb64228b59a8490486bcbb6fc62a41fff3bc4de0a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('309a027432b6fb02ec50d12039e9e89eb873cf9eae88835beab48dbece0713cb',1996,'GH','Ghana','people-and-society',399,'Population: 17.695.271 (luly 1996 est
Age structure:
(44 years. 43° «mak SS6.6 female
¥)U 946)
5-64 vears: SA male 4.658.142: temale
18140600
HS yea ’ ver. 3 male 262.159
female 287.291) (July 1996 est)
, yy
Population growth rate: -
Birth rate: 35 births) 1.000 population (1996
(1996 est.)
CAL)
Death rate: |) 15 ths/ 1.000 population
1OQUn ost
Net migration rate: 0.94 nv crantisy 1.000
pity
Sex ratio:
lofant mortality rate: SO 8 Gow (Mh)
/
Life expectanes at birth:
s/
/
Potal fertility rate: 459 wren born
\\ 4 ir
Nationality:
Gila
daite / ( er il
bthnic divisions: black At ny VW
r trim \\kan 44 Maoshi-Dag
f } we | 3 (; i
mmiba
Luropean and other
i)
Religions: indigenous beliets 38%. Muslim
My, tran 24
182
Languages: English (official). Afncan
languages (including Akan. Moshi-Dagomba.
Ewe. and Ga)
Literacy: age 15 and over can read and
write (1995 est)
htal population: 64.5%
male: 75.9%
se
femate: 335%','277989b6de855391b999803ca49442b6d3f8fb0255c9ecfdcccdd4eb881c3c01','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c819debbe55e824e648192f2d8fbb32a5f3d98b79e7ffe0bc91f0c553003164',1996,'GI','Gibraltar','people-and-society',406,'Population: 28.765 uly 1996 est)
Age sMructure’
Jvecurs: 2 tle 3.109: temale 2.728)
f ile 10.668: temal
| | . j
yr i+ nale 1S femaic
‘f } . pen s]
Population growth rate: 0.54%" (1996 est)
Birth rate: | 3.94 binhy 1.000 population
Death rate: 1 (WM) population
; .
Net migration rate: |) merantisV 1000
Se\\ ratio:
} 1¢ |
+ Whale Vtemale
; i female
j {) fy 1) “ female
S maletsiVftemale (1996 est.)
;
Infant mortality rate: 6.9 deaths’ 1.000 live
ne
Life expectancy at birth:
; . ‘ , n)
lotal fertility rate: tiuldren born
Nationality
Gil
( sit
Ethnic divisions: | n. knelish. Maltese
( ypat
Religions: Roman © at! j Protestant
(Church of | nd A ther 3¢0)
Ni , » lewsst m am other
} tps
Languages: Enelish cused in schools and tor
Hilal Purpose Spanish Itudrat
Portuguese. Russias
Literacy: “\\\\
(,overnment
Name of country:
cntional long form: none
entional shert form. Gibraltar
Data code: Gl
Type of government: dependent territory ot
the UK
Capital: Gibraltar
Administrative divisions: (one (dependent
termory of the UK)
independence: none (dependent terniory of
the UK)
Natienal holiday: Commonwealth Day
(second Monday of March)
Constitution: 4) May 1969
Legal system: English law
Suffrage: 1% years of age: universal. plus
Mher UK subjects resident six months of
howe
Executive branch:
ict of state: Queen ELIZABETH II (ot the
United Kingdom since 6 February 1952). a
hereditary monarch, ts represented by
Governor and Commander in Chief Field
Marshal Su John CHAPPLE (since NA
March 1993)
head of eovernmem: Chet Minister Joe
BOSSANO (since 25 March 1988) was
ippointed by the govemor
Gibraltar Council: advises the governor
alinet: Council of Ministers was appointed
from the elected members of the House of
Assembly by the governor in consultation
with the chief minister
Legislative branch: unicameral!
House of Assembly: clectons last held 16
January 1992 (next to be held NA January
1996): results—SL 73.29. SD 20.29. NP
47°). independents 1.8: seats-— (18 total.
1S elected) SL 8. SD 7
Judicial branch: Supreme Court. Court of
\\ppeal
Political parties and leaders: Gibraltar
Socialist Labor Party (SL). Joe BOSSANO.
Gibraltar Labor Party/Association for the
Advancement of Civil Rights (GCL/AACR).
leader Adolfo CANEPA, Gibraltar Social
Democrats (SD). Peter CARUANA
Gibraltar National Party (NP). Joe GARCIA
Other political or pressure groups:
Housewives Association: Chamber ot
Commerce. Gibraltar Representatives
Organization
International organization participation:
Interpol (subbureau)
Diplomatic representation in US: none
(deperitent terrtory of the UK)
US diplomatic representation: none
(dependent territory of the UK)
Flag: two honzontal bands of white (lop.
double width) and red with a three-towered
red castle in the center of the white band:
hanging from the castle gate ts a gold key
cemtered in the red band
Lconomy
Economic overview: Gibraltar benelits trom
an extensive shipping trade and offshore
banking. The British military presence has
been sharply reduced and now contributes
about 11% to the local economy. The
financial sector accounts for 15% of GDP:
jourism, shipping services fees. and duties on
consumer goods also generate revenue
Because more than 70% of the economy ts
in the public sector, changes in government
spending have a major impact on the level of
employment
GDP: purchasing power parity—S$205
million (1993 est.)
GDP real growth rate: NA“
GDP per capita: $6.600 (1993 est)
GDP composition by sector:
agriculture: NAG
industry; NAG
services. NAG
Inflation rate (consumer prices): NA‘
Labor force: 14.800 (including non
Gibraltar laborers)
note: UK military establishments and civil
government employ nearly SO; of the labor
horee
Unemployment rate: \\ A‘:
Budget:
revenues: S116 million
expenduures: $124 aullion, including capital
expenditures of SNA (1992-93)
Industries: tourism, banking and finance.
construction, commerce: support to large UK
naval and air bases: tobacco, mineral waters
beer. canned fish
industrial production growth rate: NAG
Electricity:
capacity: 47.000 KW
production: 9 millon kWh
consumption per capita: 2.539 kWh (1993)
Agriculture: none
Exports: $57 nullion (f.0.b., 1992)
commodities: (principally roexports)
petroleum 51%, manuta tured soods 41%
other 8%
partners: UK, Morocco, Portugal.
Netherlands, Spain, US. FRG
Imports: $420 million (c.1.1.. 1992)
commodities: fuels, manutactured goods, and
toodstulfs
partners, UK. Spain, Japan, Netherlands
External debt: $318 million (1987)
Economic aid:
recipient: ODA, SNA
Currency: | Gibraltar pound (4G) = 100
pence
Exchange rates: Gibraltar pounds (4G) pet
USS1—411.6535 Ganuary 1996). 0.6335
(1995). 0.6529 (1994), 0.6658 (1993), 0.5664
(1992). 0.56582 (1991). note—the Gibraltar
pound ts at par with the British pound
Fiscal vear: | July —30 June
/93','cc9d07267ab6d94d0ab582c7ef282f96b21341406001e32a45246d6fee0f2d94','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d760edbf1247cd7c1a9d447647acc47597a90065ad92a1586716c78ff285db5',1996,'GR','Greece','people-and-society',410,'Population: |0.538.594 uly 1996 est.)
Age structure:
O-14 veoars: 16%
R37 UR)
(male 899.029: temale
15-64 vears: ORG (male 3.571.918: female
t $4 55H)
65 years and over: 16% (male 736818:
female 990.965) (July 1996 es.)
Population growth rate: 0.425 (1996 est.)
Birth rate: 9.78 births/1.000 population
(1996 est.)
Death rate: 9 53 deathy 1.000 population
1YOH est
Net migration rate: 69S migrants 1.000
population (1996 est)
Sex ratio:
at burth: | O7 maletsWiemale
wider 18 years: 1.07 maletswWtemale
1S-H4 vears: 1.01 maletsiWtemale
45 years and over: 0.78 male(sVtemale
all ages: OY maletsViemale (1996 est.)
Infant mortality rate: 7.4 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
rrtal population: 78.1 years
mue: 75.6 years
female: 80.78 years (1996 est.)
Total fertility cate: |. 37 children born/
woman (1996 est.)
Nationality:
noun: Greckts)
adjective. Greek
Ethnic divisions: Greek YX. other 2
note: the Greek Goverament states there are
no ethnic divisions in Greece
Religions: Greek Orthodox 98%. Muslim
132%. other 0.79
Languages: Greek (official). English. French
Literacy: age 15 and over can read and
write (1991 est.)
total population: 9%
male: OX
female: 9G
Population: 58.203 (July 1996 est.)
Age structure:
0-14 vears: 27% (male 7.87
15-64 vears: O68 (male 21.
17.961)
65 vears and over, 5% (male 1.307: temale
1.586) (July 1996 est.)
Population growth rate: 16> (1996 est)
Birth rate: 17.96 births/i.000 population
(1996 est.)
Death rate: 7.11 deaths/!.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1.000
population (1996 est.)
temale 7.723)
—~--
;
55: female
Sex ratio:
at birth: | male(s)/female
under 15 years: 1.02 male(s)/female
15-64 vears: 1.21 male(s)/female
65 vears and over: 0.82 male(s)/female
all ages: 1.13 male(s)/female (1996 est.)
Infant mortality rate: 23.8 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 68.24 years
nuile: 63.97 years
female: 72.53 years (1996 est.)
Total fertility rate: 2.22 children born/
woman (1996 est.)
Nationality:
noun, Greenlander(s)
adjective. Greenlandic
Ethnic divisions: Greenlander 86‘
(Eskimos and Greenland-born whites).
Danish 14%
Religions: Evangelical Lutheran
Languages: Eskimo dialects. Danish
Literacy: NA
Population: Piss duly 1996 est)
\\] “’ ment census of
j ; ’ tian wal U4 millon.
Ave structure:
, j + Ss“) Miale
stu é
1.64 . *s OHO. temale
12 ¢
fh mate YO 3638
femal wi NS ; \\ ur Csi
Population growth rate: 0 465) (1996 est)
Birth rate: 000 population
(1 YO)
Death rate: > 100) population
19UG est
Net migration rat mtsw 1.000
population
Sex ratio:
a]
TT ( female
1S 64 Ve formals
OS years ¢ cry OSD maletsWtenrale
dl age LO) maletsiVtemale (1996 est
Infant mortality rate: 29 7 deoths/ | 000
live birth Wty
Life expectanes at birth:
ile Pyenvidiad yo
nal (yi Noy
; oe | i ;
homale {78 years (1996 est
lotal fertility rate: | 82 Children born
woman (1996 est
Nationality:
noun: Macedoniants)
adjective. Macedonian
Ethnic divisions: Macedonian 65 «
Purkish 4%. Serb 2%.
other -
Albanian 22%:
Gry psies 3 ‘
Muslim
Religions: } astern Or: who 67’;
407. other 4%
290)
Languages: Macedoman 70. Albanian
2c. Turkish 3%. other
,
sy
Serbo-Croatian 3.
Literacy: NA','ace278e833790fc4643f049894ff204c248bdbb84cf44adbbca6ff3188ce4fdd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3a5be5516b5b9d9440eebce0813d4aac588a3550edb012fecd016480c841f5f',1996,'GD','Grenada','people-and-society',418,'Population: 94.961 (July 1996 est.)
Age structure:
0-14 vears: 43% (male 20.975; temale
20,246)
15-64 vears: 52% (male 26.089: temale
23.068)
65 vears and over: 5% (male 2.112: temale
2.471) July 1996 est.)
Population growth rate: 0.55 (1996 est.)
Birth rate: 29.13 births/1.000 population
(1996 est.)
Death rate: 5.74 deaths/1.000 population
(1996 est.)
Net migration rate: -17.87 migrant(s)/}.000
population (1996 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1.04 male(s)/temale
15-64 vears: 1.13 male(s)/female
65 vears and over: 0.86 male(s)/female
all ages: 1.07 male(s)/female (1996 est.)
Infant mortality rate: | 1.9 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 70.89 years
male: 68.39 years
female: 73.44 years (1996 est.)
Total fertility rate: 3.78 children born/
woman (1996 est.)
Nationality:
noun: Grenadian(s)
adjective: Grenadian
Ethnic divisions: black Atrican
Religions: Roman Catholic, Anglican, other
Protestant sects
Languages: English (official), French patois
iteracy: age 15 and over can read and
write (1970 est.)
total population: 98%
male: 98%
female: 98%
Population: 407.768 (July 1996 est.)
Age structure:
0-14 years: 26% (male 53.118: female
51,219)
15-64 vears: 66% (male 132.846: female
136.147)
65 vears and over: 8% (maie 14.617: female
19.821) July 1996 est.)
Population growth rate: |.2°% (1996 est.)
Birth rate: 17.78 births/1.000 population
(1996 est.)
Death rate: 5.59 deaths/1.000 population
(1996 est.)
Net migration rate: -0.16 migrant(s)/1,000
population (1996 est.)
Sex ratio:
at birth: \\.05 male(s)/female
under 15 vears: 1.04 male(s)/female
15-64 vears: 0.98 male(s)/female
65 vears and over: 0.74 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 8.3 deaths/! 000 live
births (1996 est.)
Life expectancy at birth:
total population: 77.4 years
male: 74.37 years
female: 80.58 years (1996 est.)
Total fertility rate: 1.92 children born/
wonian (1996 est.)
Nationality:
noun: Guadeloupian(s)
adjective: Guadeloupe
Ethnic divisions: black or mulatto 90.
white 5%. East Indian, Lebanese, Chinese
less than 5%
Religions: Roman Catholic 95%, Hindu and
pagan African 4%, Protestant sects 1%
Languages: French (official) 99%, Creole
patois
Literacy: age 15 and over can read and
write (1982 est.)
total population: 9O%
male: 90%
female: 90%','2bca9b6734d3fca9ef9c0c55a7b3690d2451002be96187b62feecf0e9daa6316','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ce0de07b9f82ccf38403d9e4536e07273d2c26b1f5f7c7823f0ce6729ea3cd1',1996,'GP','Guadeloupe','people-and-society',426,'Population: 156.974 uly 1996 est.)
Age structure:
0-14 vears: NA
15-64 vears: NA
65 vears and over: NA
Population growth rate: 2.34 (1996 est.)
Birth rate: 24.24 births/1.000 population
(1996 est.)
Death rate: 3.86 deaths/1.000 population
(1996 est.)
Net migration rate: 3 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 vears: NA male(s)/female
15-64 years: NA male(s)/female
65 vears and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 15.17 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 74.29 years
male: 72.42 years
female: 76.13 years (1996 est.)
Total fertility rate: 2.25 children born/
woman (1996 est.)
Nationality:
noun: Guamanian(s)
acjective: Guamanian
Ethnic divisions: Chamorro 47°. Filipino
25%. white 10%. Chinese, Japanese. Korean.
and other 18%
Religions: Roman Catholic 98%. other 2%
Languages: English. Chamorro, Japanese
Literacy: age 15 and over can read and
write (1990 est.)
total population: 99%
male: 99%
female, SY
Covernment
Name of country:
conventional long form. Terrntory of Guam
conventional short form: Guam
Data code: GQ
Type of government: organized.
unincorporated territory of the US with
policy relations between Guam and the US
under the jurisdiction of the Office of
Terntonal and International Affairs. US
Department of the Interior
Capita!: Agana
Administrative divisions: none (territory of
the US)
Independence: none (territory cf the US)
National holiday: Guam Discovery Day
(first Monday 1a March) (1521): Liberation
Day, 21 July
Constitution: Organic Act of | August 1959
Legal system: modeled on US: federal laws
apply
Suffrage: 18 years of age: universal: US
citizens, but do not vote in US presidential
elections
Executive branch:
chief of state: President (ot the United
States) William Jefferson CLINTON (since
20 January 1993): Vice President Albert
GORE, Jr. (since 20 January 1993)
head of government: Governor Carl
GUTIERREZ (since 8 November 1994) and
Lieutenant Governor Mac -leine
BORDALLO (since 8 Nov smber 1994) were
elected for a four-year tern. by popular vote:
election last held & Novem der 1994 (next to
be held NA November 19/8): resultys—Cari
GUTIERREZ (Democrat) defeated Tommy
TANAKA (Republican) with 54.6 of the
vole
cabinet: executive departments: heads
appointed by the governor with the consent
of the Guam legislature
Legislative branch: unicameial
Legislature: elections last held & November
1994 (next to be held NA November 1996):
results—percent of vote by party NA:
seats—(21 total) Democrats 14. Republican 7
US House of Representatives: elections last
held & November 1994 (next to be held NA
November 1996), Guam elects one dclegate:
Robert UNDERWOOD was
(1 total)
results
reelected as delegate: seats
Democrat |
Judicial branch: Federal District Court.
judge ts appointed by the president:
Territorial Superior Court. judges appointed
for eight-year terms by the governor
Political parties and leaders: Democratic
Party (controls the legislature}: Republican
Party (party of the Governor)
International organization participation:
ESCAP (associate), LOC, SPC
Diplomatic representation in US: none
(territory of the US)
US diplomatic representation: none
(territory of the US)
Flag: territorial flag 1s dark blue with a
narrow red border on all tour sides: centered
1s a red-bordered. pointed, vertical ellipse
containing a beach scene, outrigger canoe
with sail, and a palm tree with the word
GUAM superimposed in bold red letters: US
flag 1s the national flag','171b5353dc21c15804ac9328a18fd0add4809cb524cb8ad0b47ad0e2bc304038','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8a5ddc45a2a2028327099e16451580fbf4066c21685591485a57cca5bcc2575',1996,'GT','Guatemala','people-and-society',430,'Population: | 1.277.614 uly 1996 est)
Age structure:
0-14 vears: 43% (male 2.464.498: temale
2.362.457)
15-64 vears: 54% (male 3.026.834: female
3,031,278)
6S years and over: ¥% (male 184.927;
female 207.620) Gluly 1996 est.)
Population growth rate: 2.48 (1996 est)
Birth rate: 33.96 births/1.000 population
(1996 est.)
Death rate: 7.15 deaths/1.000 population
(1996 est.)
Net migration rate: -) 98 migrantis)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s/temale
under 15 years: 1.04 male(s)/temale
15-64 vears: | male(s)/temale
65 vears and over: O8Y maletsy/female
all ages: 1.01 male(sWlemale (1996 est
Infant mortality rate: 50.7 deaths/).00''
live births (1996 est.)
Life expectancy at birth:
total population: 65.24 years
male: 62.64 years
female: 67.97 years (1996 est.)
Total fertility rate: 4.5 children born/
woman (1996 est.)
Nationality:
noun: Guatemalan(s)
adjective: Guatemalan
Ethnic divisions: Mestizo
Amerindian-Spanish ancestry (in local
Spanish called Ladino) 56%. Amerindian or
predominantly Amerindian 44%
Religions: Roman Catholic. Protestant.
traditional Mayan
mixed
Languages: Spanish 60%, Indian language
40% (23 Indian dialects, including Quiche.
Cakchiquel, Kekchi)
Literacy: age 15 and over: «
write (1995 est.)
total population: 55.6%
male: 62.5%
female: 48.6%
read and','0b3ea20c20fdfae46441947ebe92476656dc752ce386980fb294437bb24c5859','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ae88730d004293115917f7ec3e24a2aded32a83e7361f1f4447555e1ba71ff4',1996,'GG','Guernsey','people-and-society',436,'Population: 62.920 Guly 1996 est)
Age structure:
0-14 vears: 18% (male 5.592: female 5.439)
15-64 vears: 67% (male 20.636: temale
21.472)
65 vears and over: 15% (male 3,925. temale
5.856) uly 1996 est.)
Population growth rate: |.28°° (1996 est)
Birth rate: | 3.06 births/1.000 population
(1996 est.)
Death rate: 9.73 deaths/1.000 population
(1996 est.)
Net migration rate: 9.44 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/temale
under 15 years: 1.03 maletsfemale
15-64 vears: 0.96 male(s)/female
65 vears and over: 0.67 male(s)/female
all ages: 0.92 male(sVtemale (1996 est.)
Infant mortality rate: 9.2 deaths/1.000 live
births (1996 est.)
Life expectancy at birth:
total population: 78.22 years
male: 75.28 years
female: 81.27 years (1996 est.)
Total fertility rate: |.56 children born/
woman (1996 est.)
Nationality:
noun: Channel Islanderis)
adjective: Channel Islander
Ethnic divisions: UK and Norman-French
descent
Religions: Anglican. Roman Catholic.
Presbyterian. Baptist. Congregational.
Methodist
Languages: English. French, Norman-French
dialect spoken in country districts
Literacy: NA
Population: 7.411.981 Guly 1996 est)
Age structure:
0-14 years: 44% (male 1.632.414: female
1.637.007)
15-64 vears: S37 (male 1.928.586: temale
2.013.343)
65 vears and over: ¥7 (male 84.005. female
116.626) (July 1996 est.)
Population growth rate: |. 85° (1996 est)
Birth rate: 42.59 birthy/1.000 population
(1996 est)
Death rate: 18.7) deaths! .000 population
(1996 est)
Net migration rate: -5 4 migrantisy/1 000
population (1996 est.)
note. m prior years Guinea received several
hundred thousand refugees trom the civil
wars in Libera and Sierra Leone. many of
whom are now returning to their own
COUNTIES
Sex ratio:
at darth: 1.03 maletsytemale
wader 15 vears: | maleisWtemale
15-64 years: 0.96 maletsWiemale
45 years and over: 0.72 maleisWiemale
all ages. 0.97 maletsWViemale (1996 est.)
Infant mortality rate: | 34.) deaths/! 000
live births (1996 est.)
Life expectancy at birth:
‘tal population: 45.06 years
male: 42.73 years
female. 47.47 vears (1996 est)
Total fertility rate: 5.72 cinidren born’
woman (1996 est.)
Nationality:
noun: Come wits)
adjective: Gumzan
Ethnic divisions: Peuh! 40. Malinke 30%.
Soussou 20%, smaller tribes 10%
Religions: Muslim 85%. Christian 8%.
indigenous beliets 7%
Languages: French (official). each tribe has
its own language
Literacy: age 15 and over can read and
write (1995 «)
total population: 35.9%
male: 49.9%
female: 21.9%
Population: | 151.330 (July 1996 est.)
Age structure:
0-14 vears: 43% (male 247.471: female
246,725)
15-64 vears: 54% (male 295.132: female
329.681)
65 vears and over: 3% (male 15.603: temale
16.718) July 1996 est.)
Population growth rate: 2.356 (1996 est.)
Birth rate: 39.7 births/i.000 population
(]996 est.)
Death rate: 16.23 deaths/!.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.03 naale(s)/temale
under 15 vears: | male(s)/female
15-64 vears: 0.9 male(s)/female
65 vears and over: 0.93 maletsVtemale
all ages: 0.94 malets)/temale (1996 est.)
Infant mortality rate: 115.8 deaths/) 000
live births (1996 est.)
Life expectancy at birth:
total population: 48.28 years
male: 46.63 years
female: 49.99 years (1996 est.)
Total fertility rate: 5.34 children born/
woman (1996 est.)
Nationality:
noun: Guinea-Bissauan(s)
adjective: Guinea-Bissauan
Ethnic divisions: Airican 99% (Balanta
30%, Fula 20%, Manjaca 14°C, Mandinga
13°, Papel 7). European and mulatto less
than 1%
Religions: indigenous beliefs 65. Muslim
30%. Christian 5%
Languages: Portuguese (official). Criolo.
African languages
Literacy: age 15 and over car read and
write (1995 est.)
total population: 54.9%
male: 68%
female: 42.5%','09e040b52fe46858a2786d3c81ca6fe3d59c6e93920d965fd08bd1d14058d5b9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eda544cf8c3fb6ce41100bd069c07147dc441d1f08c100299a2ac5ceb4b5fef6',1996,'GY','Guyana','people-and-society',442,'Population: 7) 2.09! Gluly 1996 est)
Age structure:
0-74 years: 33% imale 118.796: female
114.327)
15-64 vears: 63% (male 224.219: temale
68 years and over: 4% (male 14.582: temale
17 605) (July 1996 est.)
Population growth rate: -0.9° (1996 est)
Birth rate: 19.03 births/1.000 population
(1996 est.)
Death rate: 9.55 deaths/1.000 population
(1996 est.)
Net migration rate: -|8 47 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth. 1 OS matletsitet tale
under 1S vears. 1 04 maletsi/temale
15-64 years’ 1OL maletsVtemale
4S vears and over ONS matletsVtemale
; aves LOL maletstemale (1996 est)
Infant mortality rate: 5) 4 deaths/).000
live births (1996 est
Life expectancy at birth:
; ,
fotal population fy) |
years
male. S?.SS vears
tesmale: 62.78 vears (1996 est.)
Total fertility rate: © 19 Children born
woman (1996 est)
Nationality:
noun. Guyanese (singular and plural)
adjective. Guyanese
Ethnic divisions: bast Indian SI. black
and mixed 43%, Amenndian 47, European
and Chinese 2%
Religions: Christian 57°¢. Hindu 33%
Muslim 9°. other 1%
Languages: English. Amerindian dialects
Literacy: age 15 and over has ever attended
school (1995 est.)
total population, 98.1%
male: YS.6%
female: 97.5%
Population: 21,983,188 (July 1996 est.)
Age structure:
0-14 years: 35% (male 3.946.196. female
3,704,561)
15-64 vears: 61% (male 6,702,404, female
6.666.626)
65 vears and over: 4% (male 442.659;
female $20,742) (July 1996 est.)
Population growth rate: |. 89° (1996 est.)
Birth rate: 24.39 birihs/1.000 popuiation
(1996 est.)
Death rate: 5.09 deaths/1,.000 population
(1996 est.)
Net migration rate: -0.36 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years’ 1.06 male(s)/female
15-64 vears: | male(s)/female
65 vears and over: 0.85 male(s)/female
all eges: 1.02 male(sV/female (1996 est.)
Infant mortality rate: 29.5 deaths/! 000
live births (1996 est.)
Life expectancy at tn. th:
total population: 72.09 years
male: 69.11 years
female: 75.29 years (1996 est.)
Total fertility rate: 2.87 children born/
woman (1996 est.)
Nationality:
noun: Venezuelanis)
adjective: Venezuelan
Ethnic divisions: mestizo 67%, white 21%,
black 10%, Amerindian 2%
Religions: nominally Roman Catholic 96%,
Protestant 2%
Languages: Spanish (official), native
dialects spoken by about 200,000
Amerindians in the remote interior
Literacy: age 15 and over can read and
write (1995 est.)
total population: 91.1%
mole: 91.8%
female: 90.3%','d1ed1176653bf2bc0c7cb34ae98f6e602a972e5c9d9960bfd5fe061f6dbbe15a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b9802cc59958e896598b145d0f1a500ea6fc195e77608ee0e8d9bab8e34ac0d',1996,'HT','Haiti','people-and-society',448,'Population: 6.731.539 (July 1996 est.)
Age structure:
0-14 years: 46% (male 1.568.943: temale
1.523.406}
15-64 vears: 50% (male 1.614.679: temale
1.758.388)
65 vears and over: 4% (male 132.460:
female 133.663) July 1996 est.)
Population growth rate: |.77°° (1996 est.)
Birth rate: 38.15 births/1.000 population
(1996 est.)
Death rate: 15.96 deaths/1.000 population
(1996 est.)
Net migration rate: -4.52 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 malets Vtemale
under 18 yvears: 1.03 malets)/temale
15-64 vears: 0.92 male(si/temale
65 vears and over: 0.99 male(s)/temale
ail ages: O.97 maletsVtemale (1996 est.)
Infant mortality rate: 103.8 deaths/1}.000
live births (1996 est.)
Life expectancy at birth:
total population: 49.26 years
male: 47.26 years
female: 51.35 years (1996 est.)
Total fertility rate: 5.69 children born/
woman (1996 est.)
Nationality:
noun: Haitian(s)
adjectve: Haitian
Ethnic divisions: black 95%. mulatto and
European 5%
Religions: Roman Catholic 80% (of which
an overwhelming majority alse practice
Voodoo), Protestant 16% (Buptist 10%,
Pentecostal 4%, Adventist 1%, other 1%).
none 1%, other 3% (1982)
Languages: French (official) 10% . Cieole
Literacy: age 15 and over can read and
write (1995 est.)
total population, 45%
male: 48%
female: 42.2%
Population: uninhabitec','152113f9fd849e523d3c2b25f19e24432880cbfc34d8b0737bfe4c615d119f37','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed5db907f38e8aa8868614c80257096b68319733682944f3c23aa7a4981a40d6',1996,'IT','Italy','people-and-society',455,'Population: 840 July 1996 est.)
Population growth rate: |.15° (1996 est)
Nationality:
noun, none
adjec live. none
Ethnic divisions: ltalians. Swiss
Religions: Roman Catholic
Languages: Italian, Latin. various other
languages
Covernment
Name of country:
conventional long form: The Holy See : State
of the Vatican City)
conventional short form: Holy See (Vatican
City)
local long form: Santa Sede (Stato della
Citta del Vaticano)
local short form: Santa Sede (Citta del
Vaticano)
Data code: VT
Type of government: monarchical-
sacerdotal state
Capital: Vatican City
Independence: || February 1929 (irom
Italy)
National holiday: Installation Day of the
Pope. 22 October (1978) John Paul I)
now Pope John Paul IT was elected on 16
October 1978
Constitution: Apostolic Constitution of 1967
(effective | March 1968)
Legal system: NA
Suffrage: limited to cardinals less than 80
years old
Executive branch:
chief of state: Pope JOHN PAUL HII (Karol
WOIJTYLA: since 16 October 1978) was
elected for life by the College of Cardinals:
election last held 16 October 1978 (next to
be held after the death of the current pope):
results—Karol WOJTYLA was elected tor
lite by the College of Cardinals
head of government: Secretary of State
Archbishop Angelo Cardinal SODANO
(since NA 1991) was appointed by the pope
cabinet: Pontifical Commission was
appointed by Pope
Legislative branch: unicameral Pontifical
Commission
Judicial branch: none: normally handled by
Political parties and leaders: none
Other political or pressure groups: none
(exclusive of influence exercised by church
otticers)
International organization participation:
IAEA, ICFTU. Intelsat. JOM (observer).
ITU. OAS (observer). OSCE. UN (observer).
UNCTAD. UNHCR. UPL. WIPO. WToO
(observer)
Diplomatic representation in US:
chief of mission: Apostolic Pro-Nunci
Archbishop Agostino CACCIAN
chancery: 3339 Massachusetts Avenue NW
Washington, DC 20008
lele phone 1} (202) 333-712
US diplomatic representation:
chief of mission’ Ambassador Raymond |
FLYNN
embassy: Villa Domiziana. Via Delle Terme
Deciane 26. Rome 00153
mating addr PSC SY, APO Ak 09624
telephone 34) (4) 46/74]
FAX 39] (6) 5758346. 57300682
Flag: two vertical bands of yellow th
side) and white with the crossed kevs
Saint Peter and the papal miter cent
the white band','0ae42cc085b4d1d17b81e761863577e59a544b419ddb84f25abf3e94508d9657','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0eb6672e8d3a147a6f98ae8d801776df308252c611d26cacc933336bccae86b',1996,'HK','Hong Kong','people-and-society',461,'Population: 6.305.413 uly 1996 est)
Age structure:
0-14 vears: 19% (male 609.493. female
593.687)
15-64 vears: 70% (male 2.312.141: female
2,094,156)
65 vears and over. \\V% (male 307.186:
female 388.750) July 1996 est.)
Population growth rate: |.77°) (1996 est)
Birth rate: 10.5 births/1.000 population
(1996 est.)
Death rate: 5.23 deaths/1.000 population
(1996 est.)
Net migration rate: | 2.42 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/temale
under 15 vears: 1.03 malet(sWtemale
15-64 vears. 1.1 male(s)/female
65 vears and over: 0.79 male(sV/temale
all ages: 1.05 male(s)/female (1996 est.)
Infant mortality rate: 5.1 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 82.19 years
male: 78.88 years
female: 85.71 years (1996 est.)
Total fertility rate: |.3 children born/
woman (1996 est.)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic divisions: Chinese 95. other 5%
Religions: eclectic mixture of local religions
90% , Christian 10%
Languages: Chinese (Cantonese), English
Literacy: age 15 and over has ever attended
school (1995 est.)
total population: 92.2%
male: 96%
female: 88.2%
Population: uninhabited: note—Amencan
civilians evacuated in 1942 after Japanese air
and naval attacks during World War II.
occupied by US military during World War
Il. but abandoned after the war: public entry
is by special-use permit only and generally
restricted to scientists and educators','09be8ea7556b446b2425138467a4ba11feadaa333ab0a0b19e0d2112a61f8d59','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('311fa03f0d158132f59342a10b4b8e8c37000b6b66a7f246e82d996d21e6ba05',1996,'RO','Romania','people-and-society',466,'Population: 10.002.541 (July 1996 est.)
Age structure:
0-14 vears: 18% (male 907.963. temale
867.536)
15-64 vears: 08% (male 3,325,529: female
3.464.588)
65 vears and over: 14% (male 538.106:
female 898.819) July 1996 est.)
Population growth rate: -0.68° (1996 est.)
Birth rate: 10.72 births/1.000 population
(1996 est.)
Death rate: 15.06 deaths/1.000 population
(1996 est.)
Net migration rate: -2. 48 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 1S vears: 1.05 nale(sV/temale
15-64 vears: 0.96 male(s)/female
65 years and over: 0.6 male(s)/female
all ages: 0.91 male(sV/temale (1996 est.)
Infant mortality rate: | 2.3 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 69.02 years
male: 64.23 years
female: 74.04 years (1996 est.)
Total fertility rate: |.5! children born/
woman (1996 est.)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Etanic divisions: Hungarian 89.9%, Gypsy
4°. German 2.6%, Serb 2%. Slovak O.8%,
Romanian 0.7%
Religions: Roman Catholic 67.5. Calvinist
20%, Lutheran 5%, atheist and other 7.5%
Languages: Hungarian 98.2. other 1.8%
Literacy: age 15 and over can read and
write (1980 est.)
total population: 99%
male: 99%
female: 98%
Population: 4.463.847 Ululy 1996 est)
Age structure:
0-14 vears: 26% (male 592.245: temale
§$73.452)
15-64 vears
1.496.428)
65 vears and over: 1O% (male 155.908.
temale 264.797) July 1996 est.)
Population growth rate: 0.18 (1996 est)
Birth rate: 16.3 births/1.000 population
(1996 est.)
Death rate: 11.75 deaths/1.000 population
(1996 est.)
Net migration rate: -2.77
population (1996 est.)
Sex ratio:
al burth
under 15 vears
64°) (male 1.381.017: temale
migrantis)/ 1.000
1.05 maleis/female
1.03 maletsWtemale
15-64 vears: 0.92 maleisVtemale
65 vears and over: 0.59 male(sWtemale
all ages: 0.91 male(sVtemale (1996 est.)
Infant mortality rate: 47.6 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 65.14 years
male: 60.77
female: 69.73 years (1996 est.)
Total fertility rate: 2.17 children bor,
woman (1996 est.)
Nationality:
Moldovants)
adjec ive
years
now
Moldoy an
Ethnic divisions: Moldayian/Romanian
64.5%. Ukrainian 13.8. Russian 13°.
Gagauz 3.5. Jewish 1.5%. Bulganan 2%
other 1.7% (1989 figures)
note: internal disputes with ethnic Russians
and Ukraimians in the Dniester region and
Gagauz Turks 1n the south
Religions: Eastern Orthodox Ys 5
1.5%. Bapust (only about 1.000 members)
(1991)
the large majority of churchgoers are
ethme Moldavian
Languages: Moldovan totticial. virtually t
same as the Romanian languag:
Gagauz (a Turkish dialect)
Literacy: age 15 ard over can read and
write (1989 est)
Jew ish
Nole
total population: 96" +
male. YS
female. 9A%
Population: 31.719 Guly 1996 est)
Age structure:
7) «male 2.737: temale 2.685)
cars. 63% «male 9.746: temale
4 eur i
cars and over: 20% (male 2.288: temale
4 July [YUH esl )
Vopulation growth rate: 0.59% (1996 est)
Hirth rate: 10.66 births/1.000 population
Death rate: |2 1) deaths/1.000 population
Wty ext )
Net migration rate: 7 48 migrants 1.000
pulat 1Y9Q est)
Sex ratio:
vhboth 1 OS maletsWtemale
wader 15 ears: 1 O2 maletsWtiemale
id sears. 094 maletsVtemaie
cars and over. OSS malets Wtemale
dl S7 maletsvtemale (1996 est)
Infant mortality rate: 69 deaths’ 1.000 live
rintt YUH est)
life expectancy at birth:
mulation: 78497 Vea4rs
138 veurs
red | 44 years (1996 est)
Fotal fertility rate: | 7 children born
woman (1996 est
Nationality:
} Mionacants if Mone gasquets)
VMonacan or Monegasque
Ethnic divisions: French 47° . Monegasque
ltalian Ie other 21%
Religions: Roman Catholic OSS
| aaguages: French totticual). English.
Mone gasque
literacy: NA
icovernoment
Nome of country:
wal long form. Principality ot
nomal short form: Monaco
long form) Poancipaute de Monaco
al short form. Mon.co
Data code: VIN
Type of government: constitutional
monarchy
Capital: Monaco
\\dministrative divisions: 4 quarters
(quarters, singular—quartier): Fontvietile. La
Condamine. Monaco-Ville. Monte-Carlo
324
Independence: |4/9 (rule by the House of
Gnmaldi)
National holiday: National Day. 19
November
Constitution: |7 December 1962
Legal system: based on French law: has not
accepted compulsory ICJ jurisdiction
Suffrage: 21) years of age: universal
Executive branch:
chiet of state: Pance RAINIER IIE (since
NA November 1949) ts a hereditary
monarch. Hew Apparent Prince ALBERT
Alexandre Lous Pierre (born 14 March
1YS8)
head of government. Minster of State Jaques
DUPONT (since NA 1995) was appointed
by the prince trom a list of three candidates
presented by the French Government
cabinet: Council of Government ts under the
authornty of the prince
Legislative branch: unicameral
National Council (Conseil National)
elections last held 24 and 31 January 1993
(next to be held NA). results - percent of
vote by party NA; seats—4 18 totaly Campora
List 15. Medecin List 2. independent |
Judicial branch: Supreme Tribunal
(Tribunal Supreme)
Political parties and leaders: National and
Democratic Union (UND). Campora Last.
\\nne-Mane CAMPORA: Medecin List.
Jean-Lowss MEDECIN
International organiz “tien participation:
ACCT. ECE. IAEA, ICAO. ICRM. TFRCS.
IMO. Inmarsat. Intelsat. Interpol. JOC, ITU,
OSCE. UN, UNCTAD, UNESCO. UPU,
WHO. WIPO
Diplomatic representation in US: Monaco
does not have an embassy in the US
consulatets): New York
honorary consulate(s) general: Boston.
Chicago. Los Angeles. New Orleans. San
Francisco, San Juan (Puerto Rico)
honorary consulate(s): Dallas, Palm Beach.
Philadelphia, and Washington, DC
US diplomatic representation: the US does
not have an embassy in Monaco: the US
Consul General in Marseille (France) ts
accredited to Monaco
Flag: two equal honzental bands of red (top)
and white. simelar to the flag of Indonesia
which ts longer and the flag of Poland which
is White (top) and red
Population: 21,657,162 (July 1996 est.)
Age structure:
0-14 years: 20% (male 2.180.023; female
2.088.496)
15-64 vears: 68% (male 7.261.160: female
7.393.531)
65 vears and over: 12% (male 1.138.583;
female 1.595.369) (July 1996 est.)
Population growth rate. -1.21 (1996 est.)
Birth rate: 9.77 births/1.000 population
(1996 est.)
Death rate: 12.27 deaths/1.000 population
(1996 est.)
Net migration rate: -9.6 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 vears and over: 0.71 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 23.2 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 69.42 years
male: 65.51 years
female: 73.57 years (1996 est.)
Total fertility rate: 1.25 children born/
woman (1996 est.)
Nationality:
noun: Romaman(s)
adjective: Romanian
Ethnic divisions: Romanian 89)‘.
Hungarian 8.9%, German 0.4%, Ukrainian
Serb, Croat, Russian. Turk. and Gypsy 1.6%
Religions: Romanian Orthodox 70%. Roman
Catholic 6% (of which 3% are Uniate)
Protestant 6°. unatfiliated 18%
Languages: Romanian. Hungarian. German
Literacy: age 15 and ower can read and
write (1992 est.)
total population: 97%
male: 98%
female: 9S%
Population: |48.178.487 (July 1996 est.)
Age structure:
0-14 vears
15.213.854)
15-64 vears
$1,125,902)
65 vears and over
female 12.497.413) July 1996 est.)
Population growth rate: -).07'':
Birth rate: 10.15 births/1.000 populauon
(1996 est.)
Death rate: 16.34 deaths/1,000 populatios
(1996 est.)
Net migration rate: 5.47 migrants)
population (1996 est.)
Sex ratio:
Gt birth: 1.05 maleis)/female
21% imale 15.792.573: temale
67% imale 48.145.679: female
| - ‘ -
12° (male $.403.066
(1996 est
1 (KM)
under 15 years: 1.04 maletsi/temale
15-614 vears
65 vears and over
0.94 malets/temale
0.43 malets)/female
all ages: O88 male(sWtemale (1996 est.)
Infant mortality rate: 24.7 deaths’! .000
live births (1996 est.)
Life expectancy at birth:
total population’ 63.24 years
male: 56.5) years
female: 70.31 years (1996 est)
Total fertility rate: | 42 children born
woman (1996 est.)
Nationality:
noun. Russiants)
adjective: Russian
Ethnic divisions: Russian 81.5 Tatar
3.8, Ukraiman 3°. Chuvash 1.2. Bashk:
0.9%, Byelorussian 0.8. Moldavian 0.7
other 8.1%
Religions: Russian Orthodox, Muslim
Languages: Russian. other
Literacy: ave 15 and over can read and
write (1989 est.)
ther
total population: 9X
LOO%
Q7¢
male
female','9a020b18c2829a767bf0acd5ba6f37cd5d5c2df0c3eb1a30ad38d1ec2fb8037c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c7c1670aa833086aab02438ca9b3509778e11f53776605ecfbd2ebb6156812c',1996,'IN','India','people-and-society',471,'Population: 952.107.694 (July 1996 est.)
Age structure:
0-14 vears: 34% (male 168,030,766: female
159.283.151)
15-64 vears: 62% (male 304,805,787; female
281.311.834)
65 vears and over: 4 (male 19,148,385:
female 19.527.771) (July 1996 est.)
Population growth rate: 1.64 (1996 est.)
Birth rate: 25.94 births/1.000 population
(1996 est.)
Death rate: 9.6! deaths/1.000 population
(1996 est.)
Net migration rate: 0.04 migrant(s /1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/temale
15-64 vears: 1.08 male(s)/female
65 vears and over: 0.98 male(s)/female
all aves: 1.07 male(s)/female (1996 est.)
Infant mortality rate: 71.1 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 59.71 years
male; 59.12 years
female: 60.32 years (1996 est.)
Total fertility rate: 3.2 children born/
woman (1996 est.)
Nationality:
noun: Indian(s)
adjective: Indian
Ethnic divisions: Indo-Aryan 72%.
Dravidian 25%, Mongoloid and other 3%
Religions: Hindu 80%. Muslim 14%.
Christian 2.4%, Sikh 2%. Buddhist 0.7.
Jains 0.5%, other 0.4%
Languages: English enjoys associate status
but is the most important language for
national, political, and commercial
communication, Hindi the national language
and primary tongue of 30% of the people.
Bengali (official), Telugu (official), Marathi
(official), Tamil (official), Urdu (official).
Gujarati (official), Malayalam (official).
Kannada (official), Oriya (official), Punjabi
(official), Assamese (official). Kashmin
(official). Sindhi (official). Sanskrit (official).
Hindustani a popular variant of Hindu/Urdu.
is spoken widely throughout northern India
note; 24 languages each spoken by a million
or more persons: numerous other languages
and dialects. for the most part mutually
unintelligible
Literacy: age 15 and over can read and
write (1995 est.)
total population: 52%
male: 65.5%
female: 37.7%','91af629e8c1d728aa02b0b2a1f4a4fd3770eae941a5af540bdabad31bcf2a34c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('828e386a4f53943b6680299dc8f983c27854765d223bcceb9d07d69fdd4d1053',1996,'ID','Indonesia','people-and-society',477,'Population: 206.61 1.600 (July 1996 est.)
Age structure:
0-14 vears: 32% (male 33,354,840; female
32.414.363)
15-64 vears: 64% (male 66.385.852: female
66.827.085)
65 vears and over: 4% (male 3.380.567.
female 4.248.893) July 1996 est.)
Population growth rate: |.53° (1996 est.)
Birth rate: 23.67 births/1.000 population
(1996 est.)
Death rate: 8.38 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 malets/temale
under 15 vears: 1.0» male(sVtemale
15-64 vears: 0.99 malets)/female
65 vears and over: O& maleisWtemale
all ages: 1 male(sVtemale (1996 est.)
Infant mortality rate: 63.1 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population, 61.64 years
male: S951 years
female: 63.88 years (1996 est.)
Total fertility rate: 2.7 chiidren born/
woman (1996 est.)
Nationality:
noun. Indonesian(s)
adjective: Indonesian
Ethnic divisions: Javanese 45° . Sundanese
14%. Madurese 7.5%, coastal Malays 7.5%.
other 26%
Religions: Muslim &87°¢. Protestant 6%
Roman Catholic 3%. Hindu 2%. Buddhist
1%. other 1% (1985)
Languages: Bahasa Indonesia (official.
modified form of Malay). English. Dutch.
local dialects the most widely spoken of
which is Javanese
Literacy: age 15 and over can read and
write (1995 est.)
total population: 83.8%
male: 89.6%
female: 78%
Population: 66.094 .264 uly 1996 es)
Age structure:
Os4 years: ASS
14.289 283)
imale 1S.166.1 41. female
18-4 vears: S2%o tmale 17
16.73) 470)
$26 38K. female
’ ——
HS vears and over Me (male 1.4. 1s
female 1.25. 274) luly 1996 est)
Population growth rate: 2.21% (1996 est.)
Birth rate: 33.67 births/1.000 population
(1996 est.)
Death rate: 661 deaths/!.000 population
(1996 est)
Net migration rate: -5 mugrant(s)/).000
population (1996 est)
Sex ratio:
at birth: 1.05 maletsWtemale
unader 15 vears. 14% maleisiWtemale
15-64 vears: 1.04 maleisiWtemale
65 vears and over: | 06 male(si/temale
all ages: 1.05 maletsvtemale (1996 est.)
Infant mortality rate: 527 deaths) !.000
live births (1996 est.)
Life expectancy at birth:
total population: 67.39 years
mate: 66.12 years
f- male: 68.72 years (1996 est)
Total fertility rate: 4.72 children born
woman (1996 est.)
Nationality:
noun. Iramants)
adjective: lranian
Ethnic divisions: Persian 5). Averbarnjanm
24°. Gilaki and Mazandaran 8. Kurd 7%.
Arab 36
other 1‘
Religions: Shia Muslim 89 Sunn
Mushim 10%. Zoroastrian. lewish. Christian
and Bahai I‘
Languages: Persian and Persian dialects
SX Turkic and Turkic dialects 26
KRerdish 9 Lun 2°. Baloch 1%. Arabic
Purkish Ie. other
Literacy: we 1S and over can read and
write (1994 est
Lur 2°. Baloch 2‘7. Turkmen 2
muile. 7S4
fe mraaile hs s
C,overnment
Name of countrs:
coMncnhiong LLL ” Ilan Reput
lran
mnentional short tory |
lencal long torm: Jombhurneve star |
local short form Tran
Data code: IR
Ivpe of government: theo cic repub
Capital: Tehran
Administrative divisions: 29 proving
fostanha. singular—astan). Ardalni
Avaroosyan-e Ghar. Azarbasjan-e Shara
Bushebr. Chahar Mahall va Bakhtus
bEestahan. Fars. Gilan. Hamadan. Hormos gan
llam. Kerman. Kermanshahan. Khorasan
Khuzestan. Kohkiluveh va Buyer Ahmadi
Kordestan. Lorestan. Markazi. Mazandaran
Semnan. Sistan va Baluchestan. Tehran
Vazd. Zanjan
Iran (continued)
Independence: | Apn! 1979 (Islamic
Republic of Iran proclaimed)
National holiday: Isiamic Republic Day. |!
Apnl (1979)
(Constitution: 2-3 December 1979. revised
1YSY to expand powers of the presidency
ind eliminate the prime ministership
Legal system: Ux. Constitutwn codifies
Islamic principles of government
Suffrage: |5 years of age. universal
Executive branch:
ipreme leader (rahbar-e moazam) and
functional chict of state: Leader of the
| 6 Revolution Ayatollah Al Hoseim
KHAMENEL (since 4 June 1989) was
pointed tor lite by Council of Experts
nornment. President Ali Akbar
Hashenn-RAFSANJANI (since 3 August
84) wos clected for a four-year term hy
itrage: First Vice President
im HABIBI (since NA August
won last held 11] June 1993 (next
1 NA May 1997). results—Ah
Khar Hashem-RAFSANJANIT was elected
{4 of the vote
Council of Ministers was selected
president with legislative approval
I. Leistative branch: unicameral
wie Consultative Assembly (Majles-«
Shura Eslami elections last held &
March and 19 April 1996 (next to be held
NA March 2000): results—percent of vote
by party NA. seats 1270 seats total) number
is DV put NA
judicial branch: Supreme Court
Political parties and leaders: th
f Patties, none a ‘
Most mpomani . oupy gs
| ran M int ¢ lergy Assocnition
1 NA. Milttant Clerntes Association
Vichd) MAHDAVEKARUBI and
Mobar id Asgar MUSAVI-KHOINTIHA
Servants of Reconstruction (G-6). leader NA
Other political or pressure groups: croups
that generally support the Islamic Republic
mclude Ansar-e Hizballah. Moyahedin of the
Islammece Resolutton, Mustim Students
Following the Lone of the Imam. and the
lsum Coalition Association: opposition
wy. include the Liberation Movement ot
iran and the Nation of tran party: armed
tical groups that have been almost
Netely repressed by the government
lude Mojahedin-e Khalg Organization
MEK). Peopl
Democratic Party of Iran. the Society tor the
Defense of Freedom
International organization participation:
COC, CP. ECO, ESCAP, FAO, G-19. G-24,
G77. LARA. IBRD. ICAO. ICC. 1CRM.
IDA IDB. IFAD. TRC. TFRCS, ILO. IMF.
s Fedaveen. Kurdish
IMO. Inmarsat, Intelsat. Interpol, IOC, IOM
(observer), ISO, ITU, NAM. OIC, OPEC.
PCA. UN, UNCTAD. UNESCO, UNHCR.
UNIDO, UPL. WCL. WFTL. WHO, WIPO.
WMO. WTo0O
Diplomatic representation in US: none:
note —tIran has an Interests Section in the
Pakistani Embassy, headed by Faramarz
FATH-NEJAD. address: Iranian Interests
Section. Pakistani Embassy. 2209 Wisconsin
Avenue NW. Washington, DC 20007,
telephone: [1] (202) 965-4990
LS diplomatic representation: none. note—
protecting power in Iran 1s Switzerland
Flag: three equal honzontal bands of green
(top). white. and red: the national emblem (a
stylized representaton of the word Allah) in
red 1s centered in the white band; ALLAH
AKBAR (God i Great) in white Arabic
sermpt rs repeated 1] times along the boitom
edge of the green band and || times along
the top edge of the red band
Population: $22,292 (July 1996 est.)
Age structure:
-]4 1s nale 5.179.240: temale
SUi4
1S-O4 Veal + male S.342.529: female
X X()
HH \\ PS cil ; (male 307.097.
ema! VE 4S83) (July 1996 est.)
Population growth rate: 3.69% (1996 est)
Birth rate: 43.07 births/1.000 popuiation
j0G ''
Death rate: 6.57 deaths/1.000 population
1906 est
Net migration rate: 0.37 migrant(s)/1.000
population ISH est)
Sex ratio:
LOS matlets/temale
wuler 1S vears: 1.03 maletsVtemale
cars, 1.02 maletsi/te:male
ars and over: OSS malets female
102 maletsViemale (1996 est.)
230
Infant mortality rate: 60 deaths/! 000 live
births (1996 est.)
Life expectancy at birth:
total population: 66.95 years
male: 65.92 years
tenvile’ OS OR years (1996 est)
Total fertility rate: 6.4! children born/
woman (1996 est.)
Nationality:
noun. Iraqgits)
adjective: Iraqi
Ethnic divisions: Arab 75‘: -80°. Kurdish
157-207, Turkoman. Assynan or other 5“
Religions: Muslim 97‘ (Shi''a 60°7-65°.
Sunni 32°¢-37°¢). Christian or other 3%
Languages: Arabic. Kurdish (official in
Kurdish regions). Assyrian. Armenian
Literacy: age 15 and over car read and
write (1995 est.)
total population: SS
male: 70.7%
female: 45%
Population: 19.962.893 uly 1996 est)
Age structure:
0-14 vears: 36% (male 3.684.510. female
2.483.893)
15-64 vears: O17 (male 5.996.369. temale
6.417.327)
65 years and over: 4% (male 342,742.
female 438,052) uly 1996 est.)
Population growth rate: 2.07 (1996 est)
Birth rate: 26 2 birthy/1.000 population
(1996 est)
Death rate: 5.49 deathy 1.000 population
(1996 est)
Net migration rate: () migrantis/ 1.000
population (1996 est.)
Sex ratio:
at durth: 1.07 maletsvtemale
wider 15 vears: 11% maleisWtemale
15-14 years: | maletstemale
45 vears and over: 0.78 maletsVtemale
all aves: 1.0) maletsivtemale (1996 est.)
Infant mortality rate: 24 deathy | .000 live
births (1996 est.)
Life expectancy at birth:
total population. 69.75 years
male. 66.82 years
fcmmale: 72.89 years (1996 est)
Total fertility rate: }.27 children born/
woman (1996 est.)
Nationality:
noun: Malaysians)
adjective: Malaysian
Ethnic divisions: Malay and other
indigenous SY. Chinese 32%. Indian 9%
Religions:
Peninsular Malaysia. Mustim (Malays).
Buddhist (Chinese). Hindu (Indians)
Sabah: Mushim 38%, Christian 17, other
48%
Sarawak: tribal religion 35%. Buddhist and
Confuciamst 24°7., Mushm 207. Christian
16%. other 5%
Languages:
Peninsular Malaysia: Malay (otticial).
English. Chinese dialects. Tamil
Sabah. English. Malay. numerous tbal
dialects, Chinese (Mandarin and Hakka
dialects predominate )
Sarawak: Englitsh. Malay. Mandarin.
numerous tnbal languages
Literacy. age 15 and over can read and
write (1995 est.)
total population, 83.5%
male: SYA
female: TRAG
Population: 4.394.537 dluly 1996 est)
Ave structure:
YOH 70% temale
4 years male 1.303.084: temale
years and over 3 (male 59.513: female
fy is) ly \\ 1 Yue es]
Population growth rate: 2.29% (1996 est.)
Birth rate: 32.93 birth 1.000 population
1UUh est
Death rate: 10.01 deaths/1.000 population
Wty
Net migration rate: 0 muigrantisy/ | 000
Thay] Wty est
Sev ratio:
OS maleisWtemak
1 1W mo emaic
ISH mallets Wlemuals
c Viale | YYH) csi
Infant mortality rate: 60.) deatiy | .000
ye
Life oxpectanes at birth:
—
'' }UUG, ¢
lotal fertility rate: 4.45 children born
ous
Nutionality:
Papua New Gurmeant(s)
Papua New Guinean
Ethnic divisions: Veclanesian. Papuan
VMicronesian, Polynesian
vr
Religions: Roman Catholic 220. Lutheran
Presby ternan/Methodist/Lendon
Visionary Socrety 8%. Anghcan 5%
374
Evangelical Alliance 4°. Seventh-Day
Adventist 1, other Protesiant sects 10%,
indigenous beliets 34%
Languages: English spoken by 17-2,
pidgin English widespread. Motu spoken in
Papua region
note: 715 indigenous languages
Literacy: age 15 and over can read and
write (1995 est)
total population: 72.26
male: SV
~
female 6? “4
Population: 4.480.848 (July 1996 est)
Age structure:
f4 years. SSX (male 1 4003. 784. female
21 YbR 259
43 years and over: 46 (male 1.165.810
female 1.429.908) (July 1996 est.)
Populatien grewth rate: 2.1 8°° (1996 est.)
Birth rate: 29.5i births/).000 population
(1996 est.)
Death rate: 6.66 deaths/1.000 population
(1996 est.)
Net migration rate: -1.06 migrant(s)/!.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.82 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 35.9 deaths/1 000
live births (1996 est.)
Life expectancy at birth:
total population: 65.91 years
male: 63.14 years
female: 68.83 years (1996 est.)
Total fertility rate: 3.69 children born/
woman (1996 est.)
Nationality:
noun: Filipinots)
adjective: Philippine
Ethnic divisions: Christian Malay 91.5%.
Muslim Malay 447. Chinese 1.5. other 3%
Religions: Roman Catholic 83°. Protestant
9. Muslim 3°7. Buddhist and other 3%
Languages: Pilipino (otficial, based on
Tagalog). English (official)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 94.6%
male: 954
; 4 2
fevaale Y4 s\\¢
Population: 3.396.924 (July 1996 est.)
Age structure:
0-14 years: 22% (male 379.076. temale
358.739)
15-64 vears: 72% (male 1.220.131: female
1.219.412)
65 vears and over: 6% (male 97.882: temale
121,684) (July 1996 est.)
Population growth rate: 1.9% (1996 est)
Birth rate: 16.28 births/!.000 population
(1996 est.)
Death rate: 4.56 deaths/1.000 population
(1996 est.)
Net migration rate: 7.29 migrant(s)/1,000
population (1996 est.)
Sex ratio:
at birth: 1.06 maletsWtemale
under 15 vears: 1.06 male(s\\/female
15-64 years: 1 male(s)/female
65 vears and over: 0.8 male(s)/female
all ages: | male(s\\/temale (1996 est.)
Infant mortality rate: 4.7 deaths/i.000 live
births (1996 est.)
Life expectancy at birth:
total population: 78.13 years
male: 75.07 years
female: 81.39 years (1996 est.)
Total fertility rate: 1.65 children born/
woman (1996 est.)
Nationality:
noun: Singaporean(s)
adjective: Singapore
Ethnic divisions: Chinese 76.4%. Malay
14.9%, Indian 6.4%, other 2.3%
Religions: Buddhist (Chinese). Muslim
(Malays), Christian, Hindu, Sikh, Taoist,
Contucianist
Languages: Chinese (official), Malay
(official and national), Tamil (official).
English (official)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 91%
male: 95.9%
female: 86.3%','259f1d5813d4cce76b9f84c76e650ad744f6564cd6123c1ae46c55ce13a94d84','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7c33ef0dc332e7da5c401f1efa858dd5cb7650a0a633693a14618fa4866f46b',1996,'IE','Ireland','people-and-society',484,'Population: 3.566.835 uly 1996 est
Ave structure:
U-14 vears 284 (male 424.588; temak
hi)? iM
1S-H4 years” OS male |.) 75.4 female
‘5 ty)
‘ . ihe ‘ |) male 173.180
female 234.720) cduly 1996 est
Population growth rate: 0 225) (1996 est)
Birth rate: | 4 22 birth’!
;YWUy si
(Mw) praopvu lation
Death rate: \\ 03
1VU6H est
leaths/ 1.000) population
Net migration rate: -6 46 mierantisy/ 1000
population (1996 est
Sex ratio:
tivrth 1 OF maletsVtemale
wuder | cars, | O06 maletsWtemale
LS-H4 vears: 1.02 maletsitemale
, and over, O74 matetsvtemale
haves. O99 maletsitemale (1996 est.)
Infant mortality rate: 6 4 deaths/} O00 live
hth, (1996 est)
Life expectancy at birth:
hoatal population. 75.58 vears
male. 7288 vears
female. 78 46 vears (1996 est)
lotal fertility rate: | 83 children born
woman (1996 est)
Nationality:
noun. Inshmantmen). Inshwomant men)
Irish (collective plural)
fe
Gadjeclirve
Irish
Ethnic divisions: Celtic. English
Religions: Roman Catholic 93. Anglican
‘
{7 none 17. unknown 2. other |
1UK]
Languages: Irish (Gaelic). spoken mainly in
areas located along the western seaboard,
English 1s the language generally used
Literacy: age 15 and over can read and
write (1981 est.)
total population: ISG
NA‘
NAG
male
female','4af9d8c46b55cbf6858850b5336cb40f564e7371371dcf4ee6d0f6c4fecc4b4f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1efc85d17cda92ad56c718134c43c1b10cab71705af24371d1473fc71f81ffa9',1996,'JM','Jamaica','people-and-society',494,'Y oulation: 2.595.275 uly 1996 est)
‘ve structure:
(male 430.609: temale
male 781.626. temale
er? male 77.725: temale
r MH ext
Population growth rate: OS (1996 esi)
lurth rate: v | ~ 1.000 population
Death rate: 550 V1.000 population
Net mrgration crate: SOS oygrantis/ 1.000
~*’ rate
rn) } . |
1YUH est)
lafant mortality rate: |S 6 death |.)
vi ''
Life expectancy at birth:
+ SS Veal
is (1996 est
lotal fertility. rate: 2 45 dren born
”~?
Natronalits
i thon divisions: Aincan 76 3 \\tro
Imhan and Atro-East
( hit SA and \\lro
Religions " SY (Church of God
\\ 1) j
\\ i Pentecostal
‘ | i¢ hu ty , "
} ( ‘ vt hie
} }URD)
languages: | (
literacy S and ittended
(,overnment
Name of countrs:
Data code: JM
Type of government: parliamentary
democracy
Capital: Kingston
Administrative divisions: |4 parishes.
Clarendon, Hanover. Kingston. Manchester.
Ponland. Saint Andrew. Saint Ann, Saint
Catherine. Saint Elizabeth. Saint James.
Saint Mary. Saint Thomas. Trelawny.
Westmoreland
Independence: 6 August 1962 (from UK)
National holiday: Independence Day (first
Monday in August) (1962)
Constitution: 6 August 1962
Legal system: based on English common
law: has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age: universal
Executive branch:
chief of state: Queen ELIZABETH II (since
6 February 1952). a hereditary monarch, 1s
represented by Governor General Sir Howard
COOKE ‘since | August 1991) who was
appointed by the queen on recommendation
of the prime minister
head of goverment: Prime Minister Percival
James PATTERSON (since 30 March 1992)
and the Depu.y Prime Minister Seymour
MULLINGS (since NA 1993) were
appointed by the governor general
cabinet: Cabinet was appointed by the
governor general on the advice of the prime
minister
Legislative branch: bicameral Parliament
Senate: consists of a 21l-member body
appointed by the governor general
House of Representatives: elections last held
4) March 1993 (next to be held by March
IYYS). results - percent of vote bs pa4ty NA:
seats—(60 totaly PNP S2. JLP 8
Judicial branch: Supreme Court. judges
appointed by the governor general on advice
of the prime minister
Political parties and leaders: People s
National Party (PNP). P. J. PATTERSON:
famanca Labor Party ULP). Edw od SEAGA
National Democratic Movement (NDM)
Bruce GOLDING
Other political or pressure groups:
Rastatanians (black religious/racial cultists
pan-Atncamsts), New Beginnings Movement
(NBM)
International organization participation:
ACP. C, Cancom. CCC, CDB, ECLAC
FAO. G-18, G-19. G-77, LADB. [AEA
IBRD. ICAO. ICFTU, ICRM. IFAD. TPC
IFRCS. iLO. IMF. IMO. Intelsat. Interpol
1OC, ISO. ITU, LAES. NAM. OAS.
OPANAL. UN, UNCTAD, UNESCO
UNIDO. UNTTAR, UNMIH, UPL, WCI
WETL. WHO, WIPO. WMO. WToO, WTrO
Diplomatic representation in US:
chiel of mission. Ambassador Richard
Leighton BERNAIT
chancery: 1520 New Hampshire Avenue
NW. Washington. DC 20036
telephone: |1| (202) 452-0660
FAX: {1} (202) 452-0081
consulate(s) general: Miami and New York
US diplomatic representation:
chief of mission: Ambassador J. Gary
COOPER
embassy: Jamaica Mutual Lite Center. 2
Oxtord Road, 3rd floor, Kingston
mailing address: use embassy street address
telephone: |1| (809) 929-4850 through 4859
FAX: {1} (809) 926-6743
Flag: diagonal yellow cross divides the flag
into tour tnangles—green (top and bottom)
and black (hoist side and outer side)
. |
Population habs
f,overnment
Same of countrys
MI
Data code: IN
Ivpe of government
Capital
Independence:
txvecutive branch:
\\ ‘
| .
}
t \\
1) ( \\
tlag: \\','39189f8407a40f830fdc876210850737dde303880790584d65d4b0b2d3b6e0a7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7fdb4f13e5a4ff4e90c8369ff4d00d692a902364aaa803b936ef3883744985b',1996,'JP','Japan','people-and-society',499,'Population: | 25.449.703 uly 1996 est)
Age structure:
(-14 wears: 16% (male 10.121.414. female
9 644,043)
15.64 vears: 6 (male 43,624,464. female
4%. 269.949)
6H5 years and over Wc Omale 7.737.781
female 10.9.7.58>) (duly 1996 est)
Population growth rate: 0.21% (1996 est)
Birth rate: 10.19 births/1.000 population
(1996 est)
Death rate: 7.7! deaths/1.000 population
(1996 est)
Net migration rate: -).4 mograntisy/ 1.000
sopulation (1996 est.)
Sew ratio:
at dneth: 1 OS maletsWtemak
wuder TS years: 10S matetsWtemak
1S.fd yvoars. 1.01 matletsWtemak
AS vours and over O71 maletsWilemak
all aecs. 096 maletsViemate (1996 est
Infant mortality rate: 4 4 death 1.000 live
borths (1996 est }
Life expectancy at birth:
otal population. 79 SS vears
srale: 76.57 vears
teymale: &2 68 vears (1996 est
Total fertility rate: | 46 cluldren born
woman (1996 est
Nationality :
noun: Japanese (singular and plucal)
adjective: Japanese
Ethnic divisions: Japanese 99 4%. other
0.6% imostly Korean)
Religions: observe both Shinto and Buddhist
84%. other 16° (including Christian 0.7%)
languages: Japanese
Literacy: age 15 and over can read and
write (1970 est.)
hntal population uN’
male: NA‘
female. NAG
Covernment
Name of country:
com.ennhonal lone torm: none
comentional sho form Japan
Data code: JA
[ype of government: Constituty
monarchy
Capital: Tokyo
Administrative divisions: 47 pret
Anh. Akita. Aomon. Chiba. Ehime. ub
Fukuoka. Fukushima. Gitu. Gumm
Hiroshima. Hot Lando. Hyogo. Tharak
Istukaw a. fwate. Kacawa. Kagos!
Kanagawa. Roch. Kumamoto, Avoto, Mix
Mivacr. Mivazaksi. Nagano. Nagasaki N
Nocata, Orta, Okayama. Okinawa, Osaka
Sava. Sartama. Shiga. Shimane. Shiruoka
Poche: Tokushoma. Tohso. Tot
lovama. Wakayama. Yamagata. Vamacuch
VY amanash
Independence: 660 BC (traditional foundry
by Emperor Jenn)
National holiday: Birthdon of the bn per
243 December 11933
Constitution: § May 1047
Legal system: modeled alter Europea
law svstem with Enelish- Amencan inftives
nahcial revica of legislative acts om the
Supreme Court: accepts compulsory 1C]
mrsdiction. with resers athons
Suffrage: 20) vears of age: unversal
Executive branch:
uel of tate. Emperor AKTHITO (sin
lanuary 1989) ts a Comstitutponal monan
lead of eovermment Pome Miniter Rvw
HASHIMOTO (since 1! January 1996) and
1 rity Pome Minster Wataru KUBO
1! January 1996) were designated hy th
Diet and appomnted by the empero
cabinet: Catinet was appointed by the p
minister
Legislatis * branch: bicameral Dret (Kokko
House of Councillors (Sane Pall cf thre
members clected every three vears to sy
vear terms: clecthons last held 2° July 199%
incest to be held NA 1998). results—percer
fw vote by parts NA.> seats 5” tal wot
126 up tor clecthion) LDP 110.149 newly
won). Shinshinto 596 (40 newis won: SDP
aK 16 new ly “Mom 1¢ ?? 13 «KK newly won)
Sakigate 3 (3 newly won). others 19 i4
newly won). independ-nts 12 16 newly won)
mue the distnbution tT sculls as oF March
} Ay is as bolhows ! DP
SDP 35. ICP 14. Sakigake 3 ers and
independents 19. vacancies |
memPe4:rs elected ever, fowr vears ic toe
vcar teTins: cieclhon im! Te : i | 1H)
i st tus hy } ki by | oO =
}’ ran 1 ! AL’ \\ \\ < ’
total) LDP 223. SDP
SHAICAAG | ihers 4 xT cnis MM)
! i ‘ Mu ! is | Marct
1996 is as follows-—LDP 207. Shinshunto
170. SDP 634. Sakreake 22. ICP 1S. other
4
‘ } ;*
remk Is Vaan |
ludicial branch: Supreme Court. ch
i} +} - ‘
A \\ mw Kall “l
Political parties and leaders: | yher
\\) wTate Party (LDP). Ryutas
HASHIMOTO. president and Korch: KATO
cretary general. Sox Democrat Party
SDP). Tomuch:i MURAY AMA, president
d Kanu SATO
Sal " Hartunger). M vast
TAKEMURA, chan nd Yub
HATOY AMA, secretary general. Shins! ''
New Fronter Party. NEP) Ichiro OZAWA
t LAL 1 Tab VYONEZAWA
ela lapan Communist Part
meP) | FLUWA, presxthwm chan
Ss] is | ed 1 nik
Ol bh t Sho it ] in)
Rerew Party. IRP) Komento (Clea
Convernment Party. COMP). Janan New Parts
INP) D tn Socralnt Party (DSP). and
cmuTys HemerAa mn i; wun
oO” Shonshinto and Romer menihs
AOMTK i croup formed from what remain
Komeno im the upper |
International organization participation:
IDB. AG tobserver), APEC. AsDB
Australia Group, BIS, COC, CP. EBRD
ESCAP. FAO G 2G. 8.G G&G
IADB. TARA. IBRD. ICAO. 10%
METLU. WORM. IDA. TEA. TRAD. Th
ROS. ILO. IME. IMO. ts 1 |
1x TOM. ISOOTTL. MTOR. NEAL NS
OAS cobwerner) OCT ONC)
POA, UN. UNCTAD. Lt NESOO) UNHCR
LNIDO. UNTTAR. UNRWALUNEL UP
WEIL. WHOL WIPO) WA) WI )
Wind J
liplomatic representation in US:
" n Amba lor Kunshyh
SALTO
soOM tts Aver NW
W nyt IM OVS
Japan (continued)
023 939-6704)
28-2187
i] ,
FAN {1} (202) 3
date(s’ general: Agana (Guam).
\\nchorage. Atlanta, Boston, Chicago.
Honolulu. Houston. Kansas City
Vissourt). Los Angeles. Miami, New
ins. New York. Portland (Oregon). San
and Seattle
date(s): Sapan (Northern Mariana
|S diplomatic representation:
Ambassador Walier |
NI \\LI
-S. Akasaka |-chome. Minato-ku
dress. Unit 48004. Box 258. APO
; f ‘ HMI!
‘| 3) 3294-S000
‘ \\ S05-1 862
es Naha (Okinawa)
iN Suppor
Fuku Ka. Nagoya
lag e wlll large red disk
sun without ravs) on the
Population: uninhabited: note— Millersville
settlement on western side of island
occasionally used as a Weather station trom
1935 until World War Li. when mt was
abandoned reoccupied in 1957 during the
International Geophysical Year by scientists
who left in 1958: public entry is by special
i
use permit only am
generally restricteG ik
> ’ 4
scientists and educators
Population: 6.782 July |yve
Age structure:
U-]4 years’ NA
15-4 sears. NA
65 vears and over’ NA
Population growth rate: 0) >| YUH est
Birth rate: 9 39 births 1.000 populatwo
(1996 est
Death rate: 6.33 death 1.000 population
(1996 est
Net migration rate: 0 micrant Mw)
population (1996 est
Sex ratio:
i furth NA maletsVtemal
mader i> \\ear NA maletswt
1S tid you NA male te
intel cr NA
NA malet(si/fema
Infant mortality rate: 65 |) 4 dew iL
ive Parths (1996 est
‘if t“7.e
Life expectancy at birth:
Mal popida 7 S §4 Veu;rs
=e @
halle Ss CA VCul
female I vear iIVUR ¢
Total fertility rate: |! 2 Chik
woman (1496 est
Nationality:
noun: Saamt Helenianis)
adective. Sam Helenian
Ethnic divisions: \\ A
Religions: Anglican imajornty). Baptist
Seventh-Day Adventist. Roman Cat!
Languages: English
Literacy: age 20 and over can
write (1987 est.)
total popnalatte y? >
mrale 9 /
female YR‘ Y','2c8670961a57c41b389cef0345c568a62e7f49e9c4689d35fa2a843251cd12ef','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c346fd7e8d535ee467aa61275aa761c07d4fb93982a432e86160ff179d2119f8',1996,'JO','Jordan','people-and-society',503,'Population: 4.212.152 uly 1996 est.)
Age structure:
0-14 years: 44% (male 949.822: female
YO3.043)
15-04 vears: 33% (male 1.153.360; female
1.091.416)
65 vears and over: 3% (male 57.783: temale
56.728) (July 1996 est.)
Population growth rate: 2.657 (1996 est.)
Birth rate: 36.67 births/1.000 population
(1996 est.)
Death rate: 3.95 deaths/1.000 population
(1996 est.)
Net migration rate: -6.2
population (1996 est.)
3 migrant(s)/ 1.000
Sex ratio:
ci poi 1.06 male(s)/female
under 15 years: 1.05 maletsWtemale
15-64 vears: 1.06 male(s)/temale
65 years and over: 1.02 maletsVtemale
all aves: 1.05 malets)/temale (1996 est.)
Infant mortality rate: 31.5 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population 72.48 years
male, 70.62 years
female: 74.45 years ( 1996 est.)
lotal fertility rate: 5.1 children born/
woman (1996 est.)
Nationality:
noun. Jordaniants)
adjective: Jordanian
Ethnic divisions: Arab YX’
Circassian i.
Armenian |
Religions: Sunni Muslim 92. Christian &%
Languages: Arabic (otticial). English widely
un
erstood among upper and middle classes
Literacy: ave 1S and over can read and
write (1995 esi.)
fotal population SHH:
male: YA4
female 79 }''','18233fa9f645c752c6b0592e3a9c5f4aec8ac62199baf5b553a6f486c0912153','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b507c5304a67433584b2c5c5bc121aef5152fd30066299641fd852d14096ebd',1996,'KW','Kuwait','people-and-society',508,', wee RAY 4) VH6-OS]7
Population Independence: |¥ J
LS diplomatic representation:
Ave structure National holiday: Nat , 3 . \\,
PeiiN Nia
Pw CROCKER
nbassada
( onstitution: I-Gar (opposite th
ant ‘ ‘7 ," -" ‘ ‘
\\ "
ntemmatvon tel). Kuwasnt City
Leval system: lem will i! ess: PO. Box 77. SAFAT
u 10] SAFAT. Kuwant: Unit 6900, APO Al
tPYSASNOD VON)
Sullrage
kconomy)
Executive branch icomomic overview: Ku
Levislative branch
with Western European incomes, Kuwait
provides its citizens with extensive health.
educational, and retirement benefits. Pet
capita military expenditure. are among the
highest in the world. The economy improved
moderately in 1994-95. with the growth in
industry and finance. The World Bank has
urged Kuwait to push ahead with
privatizauon, including in the oil industry
but the government will move slowly on this
front
GDP: purchasing power parity —$30.8
billion (1995 est.)
GDP real growth rate: 36° (1995 est)
GDP per capita: $17,000 (1995 est)
G;DP composition by sector:
agriculture. 4
industry, *S%
services: SG
Inflation rate (consumer prices): 5( (1994
est.)
Labor force: | millon (1994 est)
by occupation. wdustry and agriculture
25.0%, services 25.0%, government and
social services SOL0%
note: SOS of labor force non-Kuwaiti (1994
est.)
Unemployment rate: NEGL“
Budget:
TOVCHHES
{ 1y9) csi }
S97 billion
expenditures: $14.2 billion. including capital
expenditures of SNA (FY9S/96 est.)
Industries: petroleum. petrochemicals
desalination, food processing. construction
materials. salt, construction
Industrial production growth rate: |
(199S est)
Electricity:
770,000 KW
1) bilhon kWh
6.007 KWh (1993)
Capacity
production
consmnption per capita
Agriculture: practically no crops. extensive
fishing i territorial waters
Exports: S119 billion (thowb.. 1994)
commodities. onl
partners. US 23%
1%. UK 9%, France &%
Imports: $6.7 billion (hob
Japan 13). Germany
1994)
commodities. tood, construction materials
vehicles and parts. clothing
partners: US 14%
KY. UK 7%
External debt: SNA
Economic aid: SNA
Currency: | Kuwait: dinar (KD)
fils
Exchange rates: Kuwaiti dinars (KD) per
USS1T—4).2993 Glanuary 1996), 0.2984
(1995). 0.2976 (1994). O.3017 (1993). 0.290484
Japan 12°, Germany
France 6% (1994 est)
1 On)
(1997) 0. I843 ¢199])
Fiscal year: | July —30 June
male § reach mulitas Vy age
17,544 (1996 est.)
(singular—obhiast) and | city* (singular
— Population: 4.529.648 uly 1996 est) snaar}: Bishkek Shaary*. Chuy Oblasty
\\ge structure: (Bishkek). Jalal-Abad Oblasty. Naryn
#4 years: 37% (male 847.859: female Oblasty. Osh Oblasty. Talas Oblasty. Ysy''
NLS. SAY Kol Oblasty (Karakol)
S-O4 vears: 57% male 1.263.044; temale note. Names in parentheses are administrative
412.040 centers When name differs trom oblast name
6) vears and over: 6% (male 100.524 Independence: 3! August 1991 (from Soviet
female 177.292) uly 1996 est.) Union)
Population growth rate: 0.07% (1996 est) National holiday: National Day
Birth rate: 26.02 bithy/1.000 population December. Independence Day. 31 August
IYYH est) (1Y9})
_ Death rate: S83 deaths/1.000 population Constitution: adopted 5 May 1993
YH est.) notes amendment proposed by President
; Net migration rate: -16.5 migrantisy/ 1.000 ARAYEY and passed in a national
dinates: 4 PN id Nulution (1996 est relerendum on 10 February 1996
Sex ratio: significantly expands the powers of the
iL LOS maletsifemalk president at the expense of the legislaturc
\\ V1 ve 102 maletsWtemak Legal system: based on civil law system
* \\eu 1a HeisViemalk Suffrage: IS years of ave. universal
cor OST maletstemak Executive branch:
9S maletsWtemale ©1996 est) chict of state. President Askar AKAYEN
infant mortality rate: 77 8 deaths’) .000 (since 28 October 1990) was elected tor a
band boundarn ri YUH est Hive-year term by popular vote. elections last
Life expectancy at birth: held 24 Deceniber 1995 (next to be held
'' '' HINO veu NA). resulty—-Askar AKAYEV won election
Su Is with 7S ft vote with S6% of electorate
yoy '' Voling. mote clecthons were held earls
C custom lotal fertility rat lren bor Which gave the two opposition candidates
Nlaritime claims '' yon little ime to campaign, AKAYEYV may have
interna nal disput Nuthonalits orchestrated ti deregistration oof two
h ther candidates. one of whom was a mayor
A rivai
bthnic divisions: AK Rae head of crmmoent. Prime Ministet \\pas
| ih ‘ IVMEAGULON mce NA December 1993)
'' ipponted by the president and
Religions: \\I NA } () ppointed February 1996
Cabinet of Ministers was appomted
languages: } h ne pM em the recommendation of
’ | I it
h Legislative branch: bicameral Supn
| { ; rh h
" }
| ‘4 a
NA NN
literacy NA
!
! } NA
hy j NA
Government by | NA
Name of country ‘SS sculs w lilled at he
b k bel Mt, run-ott
K\\
n K Respublikasy | hl t mcameral tor
he S February 1995 elect
26h
Judicial branch: Supre.ne Court. judges are
appointed for a 10-year term by the
7hogorku Kenesh on recommendation of the
president, Constitutional Court: Higher Court
of Arbitration
Political parties and leaders: Social!
Democratic Party (SDP). Democratic
Movement of Kyrgyzstan (DDK). Jypar
JEKSHEYEV. chairman: National Unity:
Communist Panty of Kyrgyzstan (PCK)
\\bsamat MASALIYEV. chairman
Democratic Movement of Free Kyrgyzstan
(Erk). Tursunbay Bakir UULLI
Republican Popular Party of Kyrgyzstan.
Agranan Panty of Kyrgyzstan: Atu Meken
Party, Omurbeh TEKEBAYEV: ASABA
Other political or pressure groups:
National Unity Democratic Movement
chairman
Peasant Panty; Council of Free Trade
Umons: Union of Entrepreneurs: Agranan
Party
International organization participation:
ASDB. CIS. EBRD. ECE. ECO, ESCAP
FAD. IBRD. ICAO, IDA, IDB, TFAD, TFC
ILO. IMF. Intelsat. FOC, 10M (observer)
ITU. NACC, OFC, OSCE, PCA, PFP. UN
UNCTAD, UNESCO. UNIDO UPU, WHO
WIPO. WMO. WToO, WTrO (observer)
Diplomatic representation in US:
Acting Ambassador Almas
chief of mission
CHUKIN
chancery. (lemporary ) Sutte 706, 1511 #K
Street NW. Washington. DC 20005
: " > 5 * 292%
icleophoine 1P¢lOl) Ad s/ 4.
FAX. [14 (202) 347-3718
LS diplomatic representation:
nel of missu Ambassador Enleen A
MALLOY
prides Erkindisk Prospekt 466. Bishkek
“MHD?
” ‘ t if ki
P j ‘ \\ i}
f ;
PAN ‘.S
blag | ‘
, rT
hk ; ‘ , }
kw
™ ,
’ 4
;
kK }
kconomys
tconomic overview: AK
1] nl iT\\
[ ivi « my 4 |
‘A ite’ main ag uitura
product sports. Industrial export
ncluded gold. mercury. uramum., and
hydropower. Ayvrgyvzstan has been one of the
countries of the former
Soviet Union in carrying out market reforms
Following a successtul stabilization program
which has lowered inflation from 88% in
1994 to 32% tor 1995, attention is turning
toward simulating growth. About haif of
government stock im enterprises has been
sold. Drops in production have been severe
since the break up of the Soviet Union. but
by mid-1995 production began to level off as
exports began to increase. The level of
hardship tor pensioners. unemployed
workers, and government workers v oh
salanes arrears continues to be very high
Foreign assistance plays a substantial role 1
the country s budget. In early 1996. che
cconomys apparently is slowly beginning to
reMore previous levels of oulpul
GDP: purchasing power parity-—S$5.4 billion
(1995 estimate as extrapolated trom World
Bank estimate for 1994)
GDP real growth rate: -6
GDP per capita: $1,140 (1995 est)
GDP composition by sector:
agriulture: NA
madustry. NA
services: NA
Inflation rate (consumer prices):
t }VOS as | ;
1YYS est)
Labor force: | 846 million
by occupation. agneculture and torest sé
industry and construction 2 other 4]
i 1YO0)
Lnemplovment rate: 48%) rclud
Ohoally regiMered unemployed
numbers of regisMtered unemp!
underemployed workers (December 1995
Budget:
Industries
a
} ‘
Industrial production growth rate
>
blectricits
; nw) > Vv
*
j VA
Agriculture
’
ict drugs
‘
\\W rm | \\
Viera trom S thw \\
Exports: S380 | "5
TILL -_ tar), Wawel it Tae ¥he
“vid. mercury. uranium, hydropower
machoers shoe''s
partners: Russia, Ukraine. Uzbekistan
Kazakstan. Turkey. Cuba. and Germany
Imports: $439 million (1995
commodiies. grain. lumber. industrial
products. ferrous metals. fuel. machine
teAtiies. footw
parine? Russia Uzbekistas a/b
China. and UK
External debt: $480 m
mullon to Russia WYS ¢
Lconomic aid:
recipient. ODA. S56 milly "y
’ ‘ ri mutmcnt }¥y? us Ss )
S390) millnon disbursements
Currency: introduced national currency
som (10 Miay 1993
Exchange rates: soms por USS
Veare dl 1 YY ‘hf carend |Y94
Fiscal vear: calendar year
Pransporiation
Railways:
1
hoes I Ik
MMikkd CunNle ist » "|
Highways:
»* 400 4
Ww) ho
i TALL In }
Pipelines: na! |
Ports: Balyh Yavk-b }
Virports
C ommunications
Lelephones
lelephone sv stem
Radio broadca-t stations
“N\\A \\
Radios: * \\
‘ ‘7 : \\ q
is (Ma)
Kyrgyzstan (continued) Laos
lelesitsion broadcas stations:
bh he i ‘
‘ " .
fr L. Ma
lelevisions: S500)
Defense
Branches: \\ N Csuard, Securit, “a —
Vianpower availability: Kang
VIENTIANE ca a ag
e
expenditures
Population: 4.975.772 uly 1996 est.)
Age structure:
0-14 vears: 45% (male 1.142.825; female
1.114.628)
13-64 vears: 31% (male 1.237.660: female
1.316.591)
65 years and over: 4% (male 75.748: female
88.320) (July 1996 est.)
Population growth rate: 281° (1996 est)
Birth rate: 41.94 births/1.000 population
(1996 est)
Death rate: 13.83 deaths/1.000 population
(1996 est)
Net migration rate: (0 migrant(s)/ 1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 mate(sWtemale
under 15 vears: 1.02 maleisVtemale
15-4 vears: 0.94 maleisVtemale
4) vears and over, O86 maletsVtemale
all ages: O.YS maletsVtemale (1996 est.)
Infant mortality rate: 96.5 deaths 1.000
hive births (1996 est.)
Life expectancy at birth:
,
hal pupa SZ 69 vea@»rs
female. S431 vears (1996 est
lotal fertility rate: 587 children bon
'' 1 Wty ost
Nationality:
mf la
| ! | | neta
Ethnic divisions: | “wland) 6%
| | md) 2 | ,
H Vik
\\ \\I Vietna
Religions: | f '' ind ott
Languages: | tf French. Es
Literacy
Covernment
Name of country:
swerve viligwa ; | ry Lao Pe vic
Democrat Republi
nienlivnnl shorl tom law
local long form: Sathalanalat Paxathipatai
Paxaxon Lao
local short form: none
Data code: LA
Type of government: Communist state
Capital: Vientiane
Administrative divisions: |6 provinces
(khoueng, singular and plural) and |
municipality* (kampheng nakhon, singular
and plural): Attapu, Bokeo, Bolikhamxai.
Champasak, Houaphan. Khammouan.
Louangnamtha, Louangphabang. Oudomxai.
Phongsali. Salavan, Savannakhet.
Viangchan*, Viangchan. Xargnaboull.
Xekong. Xiangkhoang
Independence: 19 July 1949 (from France)
National holiday: National Day. 2
December (1975) (proclamation of the Lao
People’s Democratic Republic)
Constitution: promulgated 14 August 199!
Legal system: based on traditional customs,
French legal norms and procedures, and
Socialist practice
Suffrage: 18 years of age: universal
Executive branch:
chie} of state: President NOUHAK
PHOUMSAVAN (since 25 November 1992)
vas elected for a five-year term by the
National Assembly
head of eovernment. Prime Minster Gen
KHAMTAI SIPHANDON (since 15 August
1991) was appointed for a five-year term by
the president with the approval of the
National Assembly, Deputy Prime Minister
KHAMPHOUT KEOBOU ALAPHA (sine
NA)
cabinet; Council of Ministers was appointed
by the president, approved by the National
Assembly
Legislative branch: unicameral
Vational Assembly. members elected tor
five-year terms: elections last held 20
December 1992 (next to be held NA 1997)
results—percent of vote NA: seats—(85
total) LPRP &5
Judicial branch: People s Supreme Court
the president of the People''s Supreme Court
is clocted by the National Assembly on the
recommendation of the National Assembly
Standing Committee, the vice president of
ihe People’s Supreme Court and the judges
are appointed by the National Assembly
Standing Commiitee
Political parties and leaders: Lao People »
Revolutionary Party (LPRP). KHAMTAI
Siphandon, party president. other parties
pTcrsa ribed
Other political or pressure groups:
noncommunist political groups prosenbed
most opposition leaders fled the country im
1975
International organization participation:
ACCT, AsDB. ASEAN (observer), CP
ESCAP, FAO. G-77, IBRD, ICAO, ICRM
IDA. IFAD. IRC, IFRCS. ILO. IMF. Intelsat
(nonsignatory user). Interpol, IOC, IT
Mekong Group, NAM, PCA, UN, UNCTAD
UNESCO, UNIDO. UPU, WeTl. WHO.
WIPO. WMO. WToO, WTrO (observer)
Diplomatic representation in US:
chief of mission: Ambassador HIEM
PHOMMACHANH
chancery: 2222 S Street NW Washington.
DC 20008
telephone: |1\\ (202) 332-6416, 6417
FAX: [1] (202) 332-4923
US diplomatic representation:
chief of mission: Ambassador Victor I
TOMSETH
embassy: Rue Bartholonic, B.P. 114
Vientiane
mailing address: American Embassy. Box \\
APO AP 96546
telephone: (SS6| (21) 2ISKL, 2ISH2
212585
FAX: [856] (21) 212584
Flag: three honzontal bands of red (top)
bluc (double width). and red with a large
white disk centered im the blue band
Econom)
Economic overview: The government of
Laos—one of the few remaming of ficia
communist states— has been decentralizin
control and encouraging private enterpr
since 1986. The results. starting trom at
eviremely low base. have been stinking
growth has averaged 7‘
1988. Even so. Laos
TUN ue:
t lamdhachkea « nirs
with a primitive infrastructure ft!
railroads, a rudumentary road sv sten !
limited exte. nal and interna
tclecommunications Electncity ih
monk atew urban areas Sul
agneculture accounts tor halt of GDP
pros tes Mt} aft tifa mpolov ment |
predominant Crop rs The In mown-ch
Vcr 1 ers ms scll-sullicret
bul cach vear thood pests
drought cause shortag
the country. For the toresecah ''
coonems will continue to deper
frown the INI} ana ther internal
sources. aad trom the tormer | SSR/I
turope has been cut sharply A
ck Vcloping countnes. detorestat
crosson will hamper efforts to no
high cate of GDP erowth
GDP: purcha ny paw a | parity KS > ;
(1995 est)
GDP real growth rate: * 1995 es
GDP per capita: $! 100 (1995 est)
GDP composition by sector:
aernadture WY
wulustiry: 17
services, AMG (TONS)
~
Inflation rate (consumer prices): 20%
(1995 est.)
Lavor force: | million-1.5 million
by occupation: agriculture 8O% (1992 est.)
Unemployment rate: 2 |''
Budget:
revenues. SIYS millon
‘ }yy? esi ;
expenditures: S351 muallion, including cap
expend:‘tures of SNA (1994)
Industries: tin and EVPsum muning. limd<
electne power, agncultural process
construction
Industrial production growth rate: 7 *
(1992 est)
Electricity:
capacity: 260,000 KW
production: 870 millon kWh
consumption per capiia, +4 KWh «i998
Agriculture: sweet potatoes. vegetabk
com. coffee. sugarcane. Cotto “Maul
bultalo. r gs. cattle poultry
Iicit drugs: world s thord
producer (180 metric t
20.000 hectares m 199 Nhe
Li al . ;
HCTOIN PK }
bh
Exports: S278 9
geeenee
ar ti ut
‘\\
Imports: Sis
ry
pti 1} ’ { ’ | bey
baternal debt: S° by 1yys
tconomn aid
OD\\ SNA
Curt ney » kip INK ")
Fvachange rates: pew hips (NAY per USS
} ws wd , ,
\\l ” 1d by )
ym ry ri
bFiscal vear i) ! \\','9a24e9eb028f03c8becd38a47c550bb6f6fa87a012ab5fb3c70e2d6717793cf8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4179c825ed66ac34eb6b166159e7137555c90c1b87f832bddfcd57f4b9ae5ab5',1996,'LV','Latvia','people-and-society',517,'Population: 3.776.317 luly 1996 est.)
Age structure:
0-14 vears: 36% (male 687.631: temale
662.100)
15-64 vears: 59% (male 1.049.689; female
1.163.255)
65 vears and over: 3% (male 98.406; female
115.236) uly 1996 est.)
Population growth rate: 2.16% (1996 est.)
Birth rate: 27.93 births/1.000 population
(1996 est.)
Death rate: 6.35 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/temale
under 15 years: 1.04 male(s)/temale
15-64 vears: 0.9 male(s)/temale
65 vears and over: O85 malets)/temale
all ages: OYS malet(sVtemale (1996 est.)
Infant mortality rate: 36.7 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 69.99 years
male: 67.49 years
female: 72.62 years (1996 est.)
Total fertility rate: 3.24 children born/
woman (1996 est.)
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic divisions: Arab 95°. Armenian 4‘.
other 1%
Religions: Islam 70% (5 legally recognized
Islamic groups—Alawite or Nusayri. Druze.
Isma‘ilite. Shiva. Sunni). Christian 30° (11
legally recognized Christian groups-—4
Orthodox Christian, 6 Catholic. | Protestant).
Judaism NEGL
Languages: Arabic (official). French
(official), Armenian. English
Literacy: age 15 and over can read and
write (1995 est.)
total population: 92.4%
male: 94.7%
female: 90.3%
Population: § 646.4!) uly loo
Age structure:
O-d4 sears. 22 male 4(8)s lemaic
ss. »>,
15.H4 cars. 6 male | to hot tenmiale
| 244.108
> rans and one }) male |S4 Kh
female 299.0035) uly 1996 est)
Population growth rate: 1) 350 (1996 est
Birth rate: | 2.93 births/1.000 populanon
(1996 est)
Death rate: | 3.33 deaths/1.000 popuiation
(1996 est)
Net migration rate: 3.0% migrants) 000
population (1996 esi
Sex ratio:
at durth, 1.05 maleisWtemale
under 15 vears: 1.04 maietsivtemale
15-64 vears: 0.94 maletsWiemale
65 vears and over: OS2 maletsWtemale
all ages: O89 maletsiiemale (1996 est.)
Infant mortality rate: |7 deaths 1.000 Inve
births «1996 est)
Life expectancy at birth:
rital population: O8.O3 years
male: 6215 years
female: 74.21 vears (1996 est)
Total fertility rate: | 78 children born
woman (1996 est;
Nationality:
noun. Lithuamanis)
adjective. Liahwuaman
Ethnic divisions: Lithuaman 80.1%) Russ
86). Polish 7.75
21%
Religions: Roman Catholic. Lutheran, oth
Languages: Lithuanian (official), Polis!
Russian
Literacy: age 15 and over can read
write (1989 est.)
Byelorussian 1 8%. other
total population, ISG
male. I
female. IR%
Covernment
Name of country:
conventional long form: Republic ot','d395c8e810798e0c2a281edb7e17a9e9f4c17e4995e08bb4efed703d45765bc2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8c1407f54abf4a8bed12a098c853139ee91042dc39a36904595f5501afada8d',1996,'ZA','South Africa','people-and-society',523,'Population: 1.970.781 (July 1996 est.)
Age structure:
0-14 vears: 41% (male 404.733: female
402.813)
15-64 vears: 54% (male 519.493: temale
553.618)
65 vears and over: 5% (male 37.237: temale
52.887) (July 1996 est.)
Population growth rate: |.9° (1996 est.)
Birth rate: 32.7 births/1.000 population
(1996 est.)
Death rate: 13.74 deaths/!.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/ 1.000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: | male(s)/temale
15-64 vears: 0.94 male(s)/female
65 vears and over: 0.7 male(s)/female
all ages: 0.YS male(s)/female (1996 est.}
Infant mortality rate: 81.6 deaths/!.Q00
live births (1996 est.)
Life expectancy at birth:
total population: 52.08 years
male: 50.08 years
female: 54.14 years (1996 est.)
Total fertility rate: 4 32 children born/
woman (1996 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic divisions: Sotho 99.7°. Europeans
1.600. Asians 800
Religions: Christian 80%. rest indige 1ous
beliefs
Languages: Sesotho (southern Sotho).
English (official), Zulu, Xhosa
Literacy: age 15 and over can read and
write (1995 est.)
total population: 71.3%
male: 81.1%
female: 62.3%
Population: 2.109.789 Guly 1996 est)
Age structure:
0-14 vears: 45% (male 475.138) temale
470.970)
15-64 vears: 520 (male 357.855: temale
$32.143)
65 vears and over: 3% (ale 35.544. temale
38.139) uly 1996 est.)
Population growth rate: 2.13) (1996 est)
Birth rate: 42.72 births/1.000 population
(1996 est.)
Death rate: 11.95 deaths/1.000 population
(1996 est.)
Net migration rate: -9.48 migrantis)/ | .000
populadon (1996 est.)
note: until the Ghanaian-led peace
negotiations are successtul, many Liberian
refugees will be unable to return from exile
Sex ratio:
at birth. 1.03 male(s)/female
under 15 years: 1.01 maleisi/female
15-64 vears: 1.05 maletsytemale
65 vears and over. 0.93 male(s)/temale
all ages: 1.03 male(s)/femaie (1996 est.)
Infant mortality rate: 108.1 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population S859 years
male: 36.05 year
female: 61.22 years (1996 est)
Total fertility rate: 6 23 children born
woman (1996 est
Nationality:
noun. Libernants)
adjective: Liberian
Ethnic divisions: indigenous African tbs
9S‘7 “including Kpelle. Bassa, Gro. Kru
Giebo. Mano. Krahn. Gola. Ghead:. Lon
Kissi, Vas. and Bellajy. Ameneco-Liberias
Sc (descendants of former siave
Religions: traditional 70 | Musiim 20"
Christian 10
Languages: English 20% ¢othicnal) N
Congo language group about 24)
languages come from this grou
Literacy: age 15 and over can read
write (1998S est
total j™ riddle ta 3
male S308,
j 7 Fe
foniadit Ps > %
Population: 41.743.459 oi, i9ve
Age structure:
0-14 years: 246 1) S77 ¢ ‘
7.428.123
15 hd wars OFF trials “Nf <
12 $16,467)
65 vears and over: 4% (male 744.800
female 1.118.671) uly 1996 est
Population growth rate: | /¢ iYunH
Birth rate: 27.91 births/).000 populat
(1996 est
Death rate: 1032 deaths/!.00
(1996 est)
Net migration rate: 0 my:
population (1996 est
Sex ratio:
at durth: 1.038 maletsi/ten
wider 15 vears: 1.02 malet
15-Hd4 years: 0.99 maletsViem:
65 vears and over: 0.67 male
all aves: OYR maletsWtemale (1 99¢
infant mortality rate: 48.8 deat! (Wi
live births (1996 est.)
Life expectancy at birth:
total population: S947 year
male: 57 21 vears
female: 61.8 vears (1996 est)
Total fertility rate: 343 children bon
woman (1996 est.)
Nationality:
noun. South Atnecanis)
adjective. South Atnean
4359
YS
South Africa (continued)
Ethnic divisions: black 75.2
Indian 2.6%
Religions: Chnstian (most whites and
ind about 60° of blacks). Hindu
{ lored 4.6‘
4 foreds
of Indians). Muslim 2%
Languages: |! official languages, including
Vinskkaans. English. Ndebele. Peds. Sotho.
iswana Venda. Xhosa. Zulu
~ ;
Literacy: ave 1S and over can read and
i,overnment
a
‘ame of country:
form: Republic of South
orm. South Atrica
abbr tome RSA
Data code: S!
Ivpe of government: republic
Capital: Pretoria (administrative). Cape
Pown (legislative). Bloemfontein (udicial)
Administrative divisions: 9 provinces
Eastern ¢ Free State, Gauteng
KwaZulu-Natal. Mpumalanga. North-West,
Northern Cape. Northern Province, Western
( dpe
Independence: 3) May 1910 (from UR)
National holiday: Freedom Day. 27 April
(1994)
Constitution: 27 April 1994 Unterm
constitution, replacing the constitution of 3
Semtember 1984). note on & May 1996. the
( stituteonal Assembly voted 421 to two to
pal inew constitution which, alter
bs the Constitutional Court, wall
lly vo nto effect over a three-vear
[ dd and come into tull torce with the next
onal elections in April 1999
Legal svstem: based on Roman-Duteh law
nd English con iw: accept
mp ry IC dour | ith
reservation
Suffrage: |S years of ave. universal
Executive branch:
( ‘ f j ( ‘ crmnent
President Nelson MANDELA (since 10 May
Presidents Thabo
VibkaAl mce 10 May 1994) and Fredertk
W Dk: ALERK 11) May 1994) were
ted by the Natronal A
i dtlai tle
VQ Denuts by uli\\
sembly
pote nv teal party that wins 20° of
more of the Nathonal Assembly votes in a
seneral election ts entitled to name a deputy
executive president: moreover, any party that
wins 20 or more seats in the National
Assembly is entitled to become a member of
440)
r. white 13.6%.
the governing coalition: currently, the ANC,
the IFP. and the NP constitute a Government
of National Unity (GNU)
cabinet: Cabinet was appointed by the
president
Legislative branch: bicameral
National Assembly: elections last held 26-29
April 1994 (next to be held NA Apnil 1999);
results—ANC 62.6%, NP 20.4%. IFP 10.5.
FF 2.2%. DP 1.7%, PAC 1.2%, ACDP 0.5%,
other 0.9% seats—(406 total) ANC 252. NP
82. IFP 43. FF 9, DP 7, PAC 5, ACDP 2
Senate: the Senate 1s composed of members
who are nominated by the nine provincial
parliaments (which are elected in parallel!
with the National Assembly) and has special
powers to protect regional interests,
including the nght to limited self-
determination for ethnic minorities; seats
(9) total) ANC 61, NP 17, FF 4, IFP 5, DP
note: when the National Assembly meets in
joint session with the Senate to consider the
provisions of the constitution, the combined
group ts referred to as the Constitutional
\\ssembly
Judicial branch: Supreme Court
Political parties and leaders: African
National Congress (ANC), Nelson
MANDELA, president: National Party (NP).
Fredenk W. DE KLERK., president: Inkatha
Freedom Party (IFP). Mangosuthu
BUTHELEZI. president: Freedom Front
(FF), Constand VILJOEN, president:
Democratic Party (DP), Tony LEON,
president: Pan-Atricanist Congress (PAC).
Ciarence MAKWETL., president: African
Chinstian Democrat.c Party (ACDP).
Kenneth MESHOE, president
nove: wm addition to these seven parties which
received seats in the National Assembly, 11
other parties won votes in the national
elections in April 1994
Other political or pressure groups: NA
International organization participation:
BIS. C. CCC. ECA, FAO, G-77, IAEA.
IBRD, ICAO. ICC, ICRM, IDA, TFC.
IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat,
Interpol, LOC, ISO, ITU. MTCR, NAM.
OAL. SACU, SADC, UN, UNCTAD.
UNESCO, UPU. WEFTU, WHO, WIPO.
WMO. WTrO, ZC
Diplomatic representation in US:
chief of mission: Ambassador Franklir
SONN
chancery, 3051 Massachusetts Avenue NW,
Washington. DC 20008
{1} (202) 232-4400
consulate(s) general: Beverly Hills
tele phone
(Cahtornia), Chicago, and New York
US diplomatic representation:
chief of mission: Arcbassador James A
JOSEPH
embassy; 877 Pretorius St.. Arcadia 0083
mailing address: P.O. Box 9536, Pretoria
OOO!
telephone: {27 (12) 342-1048
FAX: [27] (12) 342-2244
consulate(s) general: Cape Town, Durban,
Johannesburg
Flag: two equal width horizontal bands of
red (top) and blue separated by a central
green band which splits into a horizontal Y,
the arms of which end at the corners of the
hoist side, embracing a black tsoceles
triangle from which the arms are separated
by narrow yellow bands: the red and blue
bands are separated from the green band and
its arms by narrow white stripes
note: prior to 26 April 1994, the flag was
actually four flags in one—three miniature
flags reproduced in the center of the white
band of the tormer flag of the Netherlands,
which has three equal horizontal bands ot
orange (top), white, and blue; the miniature
flags are a vertically hanging flag of the old
Orange Free State with a horizontal flag of
the UK adjoiming on the hoist side and a
horizontal flag of the old Transvaal Republic
adjoining on the other side
Population: 39.181.114 uly 1996 est)
Age structure:
0-14 vears
3.055.881)
i 5-4 vears
1 3.352.582)
65 years and over: 16% (male 2.866.728.
female 3,587,025) uly 1996 est)
Population growth rate: 0.16% (1996 esi)
Birth rate: 10.04 births/1.000 population
(1996 est.)
Death rate: 8.86 deaths/1.000 population
(1996 est.)
Net migration rate: 0.44 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.07 male(sVtemale
under 1° years: 1.06 malet(sWfemale
15-64 vears
65 vears and over
16% (male 3.237.942: temale
O87 (male 13,380,956: female
1 male(s)/female
0.72 malei(sWfemale
all ages: 0.96 male(sWtemale (1996 est.)
Infant mortality rate: 6.3 dceaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 78.26 years
male: 74.95 years
female: 81.81 years (1996 est)
Total fertility rate: |.26 children born/
woman (1996 est.)
Nationality:
noun: Spaniardis)
Spanish
Ethnic divisions: composite of
Mediterranean and Nordic types
Religions: Roman Catholic 99%. other sects
1%
Languages: Castilian Spanish. Catalan 17%
Gahan 7%, Basque 2%
Literacy: age 15 and over can read and
write (1986 est.)
adjex live
total population: 96%
YR‘
94
rrale
female
Population: no indigenous inhabitants.
nole—there are scattered garnsons','6abc76476d72f913fb5b506c2bc9936aaf65b9638e56f35b5de73e6569c8219b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5601fc8916d0fb1d12a43440bdc192d05986eaca951d5c7e9dac1cbbb83fd29',1996,'TN','Tunisia','people-and-society',529,'Population: 5.445.436 luly 1996 est)
Age structure:
0-14 years: 48° (male 1.319.696. temale
1.274.865)
15-64 vears: 49% (male 1.375.441. temak
1. 308.613)
65 vears and over’ ¥o (male 87.434. temak
79.587) July 1996 est)
Population growth rate: 3.67 (1996 est)
Birth rate: 44.42 birthy/1.000 population
(1996 est.)
Death rate: 7
(1996 est.)
Net migration rate: 0 migrantisy/).000
population (1996 est.)
Sex ratio:
at birth
deaths/1.000 population
1.05 male(sWtemale
under 15 vears. 1.04 maletsV.emale
15-64 vears
HS vars and ove
10S maletsWtemate
1.1 maletsi/fcmatle
all ages’ 1 O4 maletsViemale (1996 est)
Infant mortality rate: 59S deaths 1.000
live births (1996 est.)
Life expectancy at birth:
total population, 64.67 years
male: 62.48 years
female: 66.97 vears (1996 est)
Total fertility rate: 6 26 children born
woman (1996 est.)
Nationality:
noun: Libyants)
adjective: Libyan
Ethnic divisions: Berber and Arab 97:
Greeks. Maltese. Ttalians. Egyptians
Pakistanis, Turks, Indians. Tuntsians
Religions: Sunni Muslim 97%
Languages: Arabic. Italian. English. all are
widely understood in the mayor cities
279
AB
Libva (continued)
}
Literacy: 15 and over can read and
(,overnment
Name of country:
ai fone term: Socialist People’s
\\rub Jamahinva
I fore | inva
rn. Al Jumahinvah al Arabi ah
Vath al Ishtrrakis ah
yh ‘/
Data code: | \\
Iivpe of government: Jamahinya (a state of
tT? sors
governed by the
j iN) niat. a
Capital: |
\\dmuinistrative divisions: 25 municipalities
Hadivaty. Aplabiva
\\ Vif \\i Jubail al Akbar
| Vi Ab \\l Kutrah. An Nugat
Khe Ash Shoat Awhan Av Zawivah
Daurnah. OGhodauns. Ghar an.
Mistatan. Murvzug. Sabha. Sawtagyn. Surt
larabulus. Tarhanah. Tubrug. VYatran. Zlitan
Somuncipalitties may have been
40) Communes mm 1992
Independence: 2+ December 1951 ctrom
ftaly
National holiday: Revolution Day. |
September (1969)
Constitution: |) December .969. amended
March 19
i egal svstem: based on Ttalian cid law
Piston law. separate religious
Hora Provision how
i} legnshative acts: has not
‘ pulsars IC) purmsdiction
Suffrage: | \\ om age. umversal and
Lvccutive branch:
Revolutonary Leader Col
Viugmmar Abu Minvar al-QADHAFH isince
Semember 196%) was clected bv the
fooneral People''s Congress
ment. Secretary ot the
ral People s Committee (Premner) Abd
NMaapd al OA UD (since 29 January 1994)
cf General People s Committee was
tublished by the General People''s Congress
national elections are indirect through
i tnerarchy of peoples” committees
Legislative branch: unicameral
General Pe ope 8 Coneress national
elections are indirect through a hierarchy of
committees
''
peoples
280)
Judicial branch: Supreme Court
Political parties and leaders: none
Other political or pressure groups: \\ anous
Arab nationalist movements with almost
negligible memberships may be functioning
clandestinely. as well as some Islamic
elements
International organization participation:
ABEDA, AtDB. AFESD. AL. AMF. AMU.
CAEL. CCC, BCA, FAO. G-77, [Ar A,
IBRD. ICAO. ICRM. IDA, IDB. IFAD. TFC.
IFRCS. ILO. IMF. IMO. Intelsat. Interpol.
1OC. ISO. ITU. NAM. OAPEC. OAU, OIC.
OPEC, UN, UNCTAD. UNESCO, UNIDO.
UNITAR. UPU., WETU. WHO. WIPO.
WMO. WToO, WTrO (observer)
Diplomatic representation in US: Libya
does not have an embassy in the US
LS diplomatic representation: the US
suspended all embassy activities in Tripol:
on 2 May 1980
Flag: plain green. green ts the traditional!
color oft Islam (the state religron)','f5e97c7f8e00d524bd5413c94d49bcb4f5b185650f2c3f44afae56e740d31053','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40fc4bb502f17ec1b8077ab82957bdd45f8c7de18fef8d112ec0315741d113d4',1996,'LT','Lithuania','people-and-society',539,'283
+
Lithuania (continued)
‘form. Lithuania
ni. Lietuves Respublika
Lietuva
Lithuanian Soviet Socialist Republic
Data code: LH
iype of government: republic
Capital: Vilnius
\\dministrative divisions: 44 regions
i
Pistibtl Poijethiats tha
\\kKmenes Rajonas. Alytaus
Anvksciu Rajonas.
Birzu Raponas. Druskininka:
Raponas. Jonaves Raponas. Joniskie
yal Ko Raponas. Rapiadoru
Ma npoles Raponas. Kaunas
KRedaimiu Rajonas. Kelmes
K YU K | upedas Rajonas
Kupimskio Raponas.
f ts. Margampole*. Mazetkiu
\\I Rajonas. Nermga* Pakruoy
e710 R pons
Kagonas. Plunges
Ko Radvailiskio
as Rokishto
. sal-s » .
PHAN Rayon tS
S * Silales Rajonas.
Sit Rogonas. Shuode
’ R i AL
ie i i< . Pri Rago ts
Re tt Raponas. Varenos
Ki . h} Ragor wis Vorlmraus
Rau \\ . . Zarasu Raponas
Independence: © September 1991] (trom
\\
National hotiday: |) ndence Day. 16
Constitution: adopted 25 October [992
| eral SVSTEM: Duscd of AGE haw sySieh he
: ‘ rive CES
Suffrage: |S vears we. universal
Hvecutive branch:
Vierrdas My kolas
SK AS isince 25 November 1992
bay , ] sent YS
t bx Parhament 2
\\ } tod bk hore _
‘ ; LA try direct Voie
ected fora five
ttragve: election last
} er.eat ¢ } tee
MPs on S| pe held
, \\ ind is
'' SROAN Maus ¢ ‘cted: pet e’ntol vate
vovcrn Prenuer Mindaugas
1S February 1996;
President on IPPFOV al
Niinisters Was uppomted
othe nomination of the
my
Legislative branch: unicameral
lament). Clections last held 26
uid 25 November 1992 (next to be
284
held NA October 1996): results —LDDP
51. seats 141 total) LDDP 73.
Conservative Party 30. LKDP 17, LTS 8.
Farmers’ Union 4. LLS 4. Center Union 2.
others 3
Judicial branch: Supreme Court. judges
appointed by the Semmas: Court of Appeal.
judges appointed by the Seimas
Political parties and leaders: Christian
Democratic Party (LKDP). Algirdas
SAUDARGAS., chairman: Democratic Labor
Party of Lithuania (LDDP). Mindaugas
STANKEVICIUS | chairman: Lithuanian
Nationalist Union (LTS). Rimantas
SMETONA, chairman: Lithuanian Social
Democratic Party (LSDP). Aloyzas
SAKALAS. chairman: Farmers’ Union.
jonas CIULEVICIUS,. chairman: Center
Laion. Romualdas OZOLAS. chairman:
Homeland Union/Conservative Party.
\\Vvtuutas LANDSBERGIS. chairman:
Lithuanian Polish Union (LES). Rytardas
MACTIERIANIEC. chairman
Other political or pressure groups:
lathuamian Future Forum
international organization participation:
BIS. CBSS. CCC. Ck. EBRD. ECE. El
applicant). FAO. LAEA. IBRD. ICAO.
ICRM. TEC. TERCS. ILO. IME. Intelsat
(nensignatory user). Interpol, LOC. ISO
correspondent). ITU. NACC. OSCE. PEP.
UN UNCROL UNCTAD. UNESCO, UPL.
WEL tassociate partner). WHO. WIPO.
WMO. W110 (applicant)
Diplomatic representation in US:
Cet of misstons Ambassador Altonsas
KIDINTAS
chancer\\. 2622 Loth Street NW.
Washington, DC 20009
telephone. {1] (202) 234-5860, 2639
FAX: [1] (202) 328-0406
consilate(s) general: New York
US diplomatic representation:
chief of missions Ambassador James W
SWIHART. Ji
embassy: Akmenu 6. Vilnius 2600
mating address: PSC 78. Box V2 APO AR
(W723
telephone: {78} (8) 973-Q000, 227-224
FAX. |78] (8) 670-6084
Flag: three equal horizontal bands of yellow
(top), green. and red','8f18fc2e739111f655be503914509d0445a1258b480c980258cae592fd4258db','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81722c3f6af73cce50587ed1d18b5a7a23286e3cc7ae4075ecac58d4b454b77e',1996,'LU','Luxembourg','people-and-society',545,'Population luly 1996 est)
Vee structure
ale 39 199° temale
fy 42.394: temale
le D3. 118
Population growth rate: | 7 1996 est.)
Birth rat s.14 Tiss FRM pPulation
Tc pea
Death rate: s >. hs) 000) population
"Y
Net migration rate: rantisy/ } 000
ty ry ! a. ats
Sex ratio:
Tit
‘ » siVtematle
\\-f } si/temale
OS ve ‘ ''OS maletsivtemule
v7 rade male (1996 est)
Infant mortality rate: 47 deaths/1.000 live
Life expectanes at birth:
\\ is
ity |
botal fertility rate: | 76 children born
of,
Nationalits:
?
Ethnic divisions: Celtic base (with French
vend). Portuguese. Htalan. and
bury TS nd worker residents)
Religions: Ronin Catholr 97°. Protestant
languages: Luxembourgisch. German.
Prench. English
Literacy: age 1S and over can read and
write (19OSO est
total population” VOO%
marie. LOOT,
fe prhcile him,
286
Population: |.140.256 July 1996 est.)
Age structure:
0-14 vears: 27% (male 157.174. temale
152.980)
13-64 years: 67% (male 379.840: temale
65 years and over: 6° (male 27.429: temale
99.538) uly 1996 est.)
Population growth rate: |.23° (1996 est.)
Birth rate: }8.97 births/1.000 population
(1996 est.)
Death rate: 6.67 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1 000
population (1996 est.)
Sea ratio:
at birth: 1 maletsiv/tematle
under 15 vears: 1.03 maletsi/temale
13-64 years: 0.99 malets Vtemale
65 vears and over, 0.69 malets)/temale
Hf aves: OYS maletsVtemale (1996 est.)
Infant mortality rate: 17.2 deaths/).000
live births (1996 est)
Life expectancy at birth:
total population: 70.53 years
male. 66.72 years
female: 74.33 years (1996 est.)
Total fertility rate: 2.24 children born/
woman (1996 est.)
Nationality:
noun. Mauritiants)
adjective: Mauritian
Ethnic divisions: Indo-Mauritian 68°
Creole 27. Sino-Mauritian 347. Franco
Mauritian 2%
Religions: Hindu $2°7. Christian 28.3%
(Roman Catholic 26% , Protestant 2.3% ).
Muslim 16.6. other 3.1
Languages: English (official). Creole.
French. Hindi, Urdu. Hakka. Boypoor
Literacy: age 1S and over can read and
write (1995S est.)
total population: 82.9%
male: 87.1%
female: TR&%','121db3f9810c5128d17e027d62c8c8e8c476dc43f3fe26ef97bbad4f0ce3e9c3','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('447f111d12cd308ed810cd7f8bb1bd142762c86381a36158995f21fc75c9bdc9',1996,'ZW','Zimbabwe','people-and-society',555,'Population: 9.452.844 uly 1996 est)
Age structure:
0-14 vears: 46% (male 2.189.223. temale
2.168.317)
15-64 vears: 51% (male 2.371.518; temale
2.472.245)
65 vears and over: 3% (male 107.701,
female 143.840) July 1996 est.)
Population growth rate: |.71''% (1996 est.)
Birth rate: 41.56 births//.000 population
(1996 es.)
Death rate: 24.48 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrantis)/) 000
population (1996 est.)
note: the return of refugees to Mozambique
is apparently complete
Sex ratio:
at birth: 1 03 male(s)/female
under 15 years: 1.01 maleisViemale
15-64 vears: 0.96 maleisVtemale
65 vears and over: 0.75 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 139.9 deaths/!,000
live births (1996 est.)
Life expectancy at birth:
total population: 36.16 years
male: 35.87 years
female; 36.46 years (1996 est.)
803
Total fertility rate: 5.9! children born/
woman (1996 est.)
Nationality:
noun: Malawianis)
adjective: Malawian
Ethnic divisions: Chewa. Nyanja. Tumbuko.
Yao, Lomwe. Sena. Tonga. Ngoni. Ngonde.
Asian, European
Religions: Protestant 55%. Roman Catholic
20%. Muslim 207. traditional indigenous
beliefs
Languages: English (official). Chichewa
(official), other languages important
regionally
Literacy: age 15 and over can read and
write (1995 est.)
total population: 56.4%
male: 71.9%
female: 41.8%
Population: 9.159.072 Ululy 1996 est.)
Age structure:
0-14 vears: 49% (male 2.272.981; female
2,244,403)
15-64 vears: 48% (male 2,157,106: female
2.256.935)
65 years and over: 3% (male 110,433;
female 117.214) Uuly 1996 est.)
Population growth rate: 2.11% (1996 est.)
Birth rate: 44.73 births/1.000 population
(1996 est.)
Death rate: 23.65 deaths: i .000 population
(1996 est.)
Net migration rate: 0 migrant(sy/1 000
population (i 996 est.)
Sex ratio:
at birth: 1.03 male(sWfemale
under 15 vears: 1.01 male(sWfemale
15-64 vears: 0.96 maleisWfemale
65 vears and over: 0.94 male(s)/female
all ages: 0.98 maleisWfemale (1996 est.)
Infant mortality rate: 96.1 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 36.31 years
male: 36.15 years
female: 36.46 years (1996 est.)
Total fertility rate: 6.55 chodren born/
woman (1996 est.)
Nationality:
noun: Zambian(s)
adjective: Zambian
Ethnic divisions: African 98.7%, European
1.1%, other 0.2%
Religions: Christian 50%-75%. Muslim and
Hindu 24%-49%, indigenous beliefs 1%
Languages: English (official), major
vernaculars—Bemba, Kaonda, Lozi, Lunda,
Luvale, Nyanja, Tonga, and about 70 other
indigenous languages
Literacy: age 15 and over can read and
write in English (1995 est.)
total population: 78.2%
male: 85.6%
female: 71.3%','d9498da95728e867a24cf26a2f5f0c2be3b25c46a6e46d0ede32496720fc16c7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13950f1ebb559b3355805161fca16caef38cdb1dc7677f9b8cdc44a9d3d1a818',1996,'MV','Maldives','people-and-society',562,'Population: 270.758 July 1996 est)
Age structure:
0-14 vears: 477 (male 65.559: temale
62.399)
15-64 vears: 50% (male 69.071: temale
65.659)
65 vears and over: 3% (male 4.336: female
3.734) (July 1996 est.)
Population growth rate: 3.52% (1996 est)
Birth rate: 41.88 births/1.000 population
(1996 est.)
Death rate: 6.64 deaths/1.000 population
(1996 est.)
Net migration rate: ( migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.05 maleis/temale
under 15 vears: 1.05 male(si/temale
15-64 vears: 1.05 male(sitemale
65 vears and over: 1.16 male(s)/female
all ages: 1.05 male(sitemale (1996 est)
Infant mortality rate: 47 deaths/1.000 live
births (1996 est.)
Life expectancy at birth:
total population: 66.17 years
male: 64.6 years
female: 67.82 years (1996 est.)
Total fertility rate: 6.06 children born/
woman (1996 est.)
Nationality:
noun: Maldivian(s)
adjective: Maldivian
Ethnic divisions: Sinhalese. Dravidian.
Arab. Atrican
Religions: Sunni Muslim
Languages: Maldivian Divehi (dialect ot
Sinhala. script derived from Arabic). English
spoken by most government officials
Literacy: age 15 and over can read and
write (1995 est.)
total population, 93.2%
male. 93.34
female: 93%
(,overnment
Name of country:
conventional long form: Republic of
conventional short form: Maldives
Data code: MV
Type of government: republic
Capital: Male
Administrative divisions: |9 districts
(atolls): Alift. Baa. Daalu. Faatu. Gaatu
Alitt. Gaaiu Daalu. Haa Alift. Haa Daalu.
Kaatu. Laamu. Laviyani. Meemu. Naviyani.
Noonu. Raa. Seenu. Shaviyani. Thaa. Waavu
Independence: 26 July 1965 (rom UK)
National holiday: Independence Day. 26
July (1965)
Constitution: 4 June 196%
Legal system: based on Islamuc law with
admixtures of English common law primarily
in commercial matters. has not accepted
compulsory ICJ yursdiction
Suffrage: 2! years of age. universal
Executive branch:
chiet of state and head of government
President Maumoon Abdul GAYOOM (since
11 November 1978) was reelected tor a five-
year term by secret ballot of the Majlis:
election last held | October 1993 (next to be
held NA 1998). results— President Maumoon
\\bdul GAYOOM was reelected with 92.76%
of the vote
cabinet: Ministry of Atolls was appointed by
the president: note——need not be members ot
Mayilis
Legislative branch: unicameral: members
elected for five-vear terms or appointed by
the president
Cizens’ Council (Majlis): elections last held
2 December 1994 (next to be held NA
December 1999), resulis—percent of vote
NA. seats—148 total. 40 elected. & appointed
by the president) independents 40
Judicial branch: High Court
Political parties and leaders: although
political parties are not banned. none exist
International organization participation:
AsDB. C. CP. ESCAP. FAO. G-77, IBRD.
ICAO, IDA. IDB. TRAD. TFC, IMF. IMO.
Intelsat (nonsignatory user). Interpol, LOC.
ITU. NAM. OIC. SAARC. UN. UNCTAD.
UNESCO. UNIDO. UPL. WHO, WMO.
WT0O. WTrO
Diplomatic representation in US: Maldives
does not have an embassy in the US. but
does have a Permanent Mission to the UN in
New York. headed by Ahmed ZAKI
US diplomatic representation: the US does
not have an embassy in Maldives: the US
Ambassador to Sr Lanka ts accredited to
Maldives and makes periodic visits there
Flag: red with a large green rectangle im the
center bearing a Vertical white crescent: the
closed side of the crescent 1s on the hoist
side of the flag','135c0ec0e7232d28bd78bca1eadfe8199998d26900a8c7c7f66dec911628b66a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b251b6ca584426266e90eb2d5c166aeca3ccc05b55ddac3736b2d9653e7a6c91',1996,'DZ','Algeria','people-and-society',567,'Population: 9.653.261 (July 1996 est.)
Age structure:
0-14 vears: 48% (male 2.210.294: temale
2.308.941)
15-64 vears: 49% (male 2.231.244: temale
2.488.276)
65 vears and over: 3% (male 149.370:
female 165.136) July 1996 est.)
Population growth rate: 2.95 (1996 est)
Birth rate: 51.38 births/1.000 population
(1996 est.)
Death rate: 19.49 deaths/1.000 population
(1996 est.)
Net migration rate: -2 37 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 vears: | male(s)/female
15-64 years: 0.9 male(s)/female
65 vears and over: 0.9 male(s)/temale
ail ages: 0.94 male(s)/female (1996 est.)
Infant moriality rate: 102.7 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 46.84 years
male: 45.12 years
female: 48.6 years (1996 est.)
Total fertility rate: 7.25 children born/
woman (1996 est.)
Nationality:
noun: Matlian(s)
adjective: Mahan
Ethnic divisions: Mande 50° (Bambara.
Malinke. Sarakole). Peul 17%. Voltaic 12%.
Songhai 6%, Tuareg and Moor 10%, other
5%
Religions: Muslim 90%. indigenous beliefs
9%, Christian 1%
Languages: French (official). Bambara 80%.
numerous African languages
Literacy: age 15 and over can read and
write (1995 est)
toial population: 31%
male. 394%
female: 23.1%','6adeecc16ec6ba422f38035afb1eb0799be22cb81c3f399c7abd578a1dee273a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('550d4417de3899fdd8eecce030974a06d06cdb2eb3ed964639255f75b4c4b1fa',1996,'MT','Malta','people-and-society',573,'Population: 375.576 (July 1996 est.)
Age structure:
0-14 years: 22% (male 42.067; female
39.958)
15-64 years: 67% (male 126.179: female
125.321)
65 vears and over: 11% (male 17.766:
female 24.285) (July 1996 est.)
Population growth rate: 1.01 (1996 est.)
Birth rate: 14.79 births/1.000 population
(1996 est.)
Death rate: 6.83 deaths/1.000 population
(1996 est.)
Net migration rate: 2.12 migrantis)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/temale
under 15 vears: 1.05 male(s)/temale
15-64 vears: 1.01 male(s)/female
65 vears and over: 0.73 male(s)/female
all ages: 0.98 male(sy/female (1996 est.)
Infant mortality rate: 6.9 deaths/1.000 live
births (1996 est.)
Life expectancy at birth:
total population: 78.11 years
male: 75.77 years
female; 80.6 years (1996 est.)
Total fertility rate: 2.17 children born/
woman (1996 est.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic divisions: Arab. Sicilian, Norman.
Spanish, Italian, English
Religions: Roman Catholic 98%
Languages: Maltese (official). English
(official)
Literacy: age 15 and over can read and
write (1985 est.)
total population: 84%
male: 86%
female: 82%
Population: 73.837 July 1996 est)
Age structure:
0-14 vears: 18% (male 6.606; temale 6.348)
15-64 vears: 65% (male 23.917: female
23.R1S)
65 vears and over: 17% (male §,239: temale
7.912) Guly 1996 est.)
Population growth rate: 0.94 (1996 est.)
Birth rate: 12.43 births/1.G00 population
(1996 est.)
Death rate: | 2.09 deaths/!.000 population
(1996 est.)
Net migration rate: 9.02 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at bith: 1.05 male(stemale
under 15 years: 1.04 maie(sWfemale
15-64 vears: | male(sj/female
65 vears and over: 0.66 malet(sVtemale
all ages: 0.94 male(sVtemale (1996 est.)
infant mortality rate: 2.4 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 77.15 vears
male> 73.56 years
female: SO.91 years (1996 est.)
Total fertility rate: 1.68 children born
woman (1996 est.)
Nationality:
noun: Manxman, Manxwoman
adjective: Manx
Ethnic divisions: Manx (Norse-Celtic
descent). Briton
Religions: Anglican. Roman Catholic.
Methodist. Baptist. Presbyterian. Society of
Friends
Languages: English. Manx Gaelic
Literacy: NA','264679e80c4fab50138f492e1fe3fbceff1912911e224610bfc4835fb7ac042f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6d9e7a13a51ba20c9b9c2715ea6e04536ecb49273503b872aba85cb6ea47ddd',1996,'MH','Marshall Islands','people-and-society',579,'Population: 58.363 Gluly 1996 est)
Age structure:
O14 yoars: SV (male 15.044: temale
14.435)
13-4 yoars: 47
13. sy)
‘ «male 14.084: temale
65 years and over: 26 (male 657. temale
745) Duly 1996 est)
Population growth rate: 3.85% (1996 est)
Birth rate: 45.75 birthy 1.000 population
(1996 est.)
Death rate: 7 28 deathy/1.000 population
(1996 est.)
Net migration rate: 0 migrantisy/ 1.000
population (1996 est)
Sex ratio:
at birth LAOS matletsWiematle
14 malets
LOS maleisWtemale
(OSS maletsWtemale
1S years Viemale
15 hid ‘ears
hs yours and mer
anal }
all ages: 1.04 maletsWiemale (1996 est )
Infant mortality rate: 46 9 deaths 1.000
live births (1996 est)
Life expectancy at birth:
total population: 63.81 years
male, 62.25 years
female, OS.45 vears (1996 est)
Total fertility rate: 6.83 children born
woman (1996 est)
Nationality:
noun: Marshallese (singular and plural)
Marshallese
Ethnic divisions: Micronesian
Religions: Christian (mostly Protestant)
Languages: English (universally spoken and
ade clive
is the official language). two mayor
Marshallese dialects trom the Melayo
Polynesian tamaly. Japanese
Literacy: age 1S and over can read and
write (1980 est.)
total population: 9G
OWN
SA‘y
praile
female
Population: 399.151 Gluly 1996 est)
Age structure:
0-14 vears: 23% (male 46.851. temale
3
15-64 vears: 67% (male 132.161: female
|
65 vears ard over: 1O% (male 16.542:
temale 22.5°0) July 1996 est.)
Population growth rate: |)‘ (1996 est)
Birth rate: 16.92 births/1.000 population
(1996 est)
Death rate: 5.85 deaths/!.000 population
(1996 est.)
Net migration rate: -0.) migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.04 maletsVtemale
under 15 vears: 1.03 maletsVtemale
15-64 years: 0.97 malets Vtemale
65 vears and over: 0.73 malets/temale
all ages: 0.96 maletsVtemale (1996 est.)
Infant mortality rate: 7.'' deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 78.81 years
male: 76.07 years
female’ SL.OS years (1996 est)
Total fertility rate: | 8! children born/
woman (1996 est)
Nationality:
noun Martuiniqguars (singular and plural)
idjective. Martomquus
Ethnic divisions: Atmoan and Atncan-white
Indian mixture YO. white S&. East Indian.
Lebanese. Chinese less than S%
Religions: Roman Catholic 98° . Hindu and
pagan African S%
Languages: French. Creole pators
Literacy: age 15 and over can read and
write (1982 est.)
total population: 9X4
mile: 92%
femere: VAG','d441917ca497eab2b2acb01358f4dbdbd90325f8c4a492e001cb313121a89139','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('531be472ef2ab6262a669398a07e0b2130c3e8c30af621d7750dd297d581eb58',1996,'MS','Montserrat','people-and-society',604,'Population: !2.77! (luly 1996 est)
Age structure:
0-14 vears: NA
15-64 years: NA
65 vears and over: NA
Population growth rate: () 2>
Birth rate: 13.08 births) .0G0
i 1YUH est }
Death rate: 9 83 deaths/ 1.000 |
(}]996 est)
Net migration rate:
population (: 996 est
Sex ratio:
\\ A mal
under 1> \\vears’ NA
ears, NA male !
OH vears atid over: NA
all ave NA male
Infant mortality rate: 7S dl
live births (1996
al pyri
15-4
Lite expectancy at birth:
’ j <
wal paonidda 7 ~ / Vi if
/ 72 Oy ''
pial sv Cll
ha velaile 499 VC ie
Total fertility rate: | 0+
woman (1996 esi
Nationality:
nau Non ratian
adjective. Montserratiat
Ethnic divisions: black. burcy
Religiens: Anglican, Methodist. R
Catholic. Pent tal. Seventh-Da
Adventist. other Christian dene
Languages: |)
Literacy: age |> over has
school C1970) ¢
/, fg ‘
lolal pr adilta )
C,overnment
Name of country:
conventional lor horn. TOM,
conventional short form: Mon
Data code: \\ili
Ivpe of government: depend
ihe UK
Capital: Plymouth
Administrative divisions: ¢ po
\\nthons
Independence: none (depend
Saint Georges. Sart Pet
the UK)
National holiday: Celebraun
Birthday of the Queen tsecond §S
June)
Constitution: present consut
force 19 December | 989
Legal system: English common |
datute law
327
ma
Nlontserrat (continued)
43 ue : ‘ 74> ; .
Suilrage: |S vears of age: universal!
PE vecutive branch:
fe Queen ELIZABETH II (ot the
! Kingdom since 6 February 1952)
tbs Governor Frank SAVAGI
VA Februar 1993) was appointed by
Chiet Minister Reuben
ult 1} \\ \\ SO rer Del ‘ ny]
I \\ | sists of th
4 Nec tiie!
{ \\ era nad i
Lepishative branch: unica
'' fCCTHOMS La held s
xv held NA
party NA
1) NPP 4. NDP
judicial branch: | rm Canbbean
. Saint Luc
Political perties and leaders: Nau
way Rey |
, | nM
}?! Nu )
CDP) oR nd OSBORNE
International organization participation:
wm ECE socnate nh ICH I
ne S WC
Phplomatic representation in US:
h
(S diplomatic representation:
'' i
trikl
‘
b
rconeny
hconomic overview
’
Fevun
jUdite
Ihe 1 |
1 why
‘ i
'' ‘ |
’ 1?
Ii}
4 TY ''
?
} Ih { j i | Al
i my i repeated
Ml 1! | j Piy mor ih
'' ! i") } Ire a
i),) \\ i ull
1! Ay } iy ry pit j
sY\\
328
continued danger of an eruption dim the
prospects for rapid recovery in 1996
GDP: purchasing power parity $55.6
million (1994 est)
GDP real growth rate: 0.5 (1994 est)
(SDP per capita: $4.500 (1994 est)
GDP composition by sector:
j * 4
Chic ULNA +"
ff '' j 1/
Maditsil isSN.4 «
7 4
Sarid’ fy Nor | YU) est}
Inflation rate (consumer prices): 9 6''
(1904)
Labor force: 5.100
PY GCCUPalion COMMUDITN social. and
construction 13.5!
versonal services 405!
|
>)
sv’ 4
trade. restaurants. and hotels |
mutacturme [ON e. agriculture. forestry
ind tishing SOS mMher 144%) ©1983 est)
Unemployment rate: \\.\\
Budyet:
endures: SIS 6 millon mecluding capital
expenditures of SNA (1994
Industries: tourtsm. rum. teratiles. clectromny
ry
Industrial production growth rate: \\ \\
blectricits:
aap ! S77 ia \\A
dite Tha i onullion AWA
WD TLON Dek cg lt RWI OY 4
Agriculture: tomatoes. onions. peppers
‘
\\ f , 7
Exports: S244 ono Ud)
Why ! wns. Olasth
i | my p Wit il!
(S| Hy
Imports: Sst) ¢ | 1} '' { hy }y9?
hiners and transpertation
quip) lemndstutl manubactured goods
Nn i related miatertals
“NA
Evternal debt: S102 nuthon (December
a
Economic aid: S\\N \\
Currenes: | bC dollar chOS) = 100 cents
Evachange rates: bast Canbbean dollars
bCSi per USST 2 70 (tived rate since
74
Fiscal vear: Von! — 31 March','643e0b8c3bc7d89c56f6af9323856b2bd4d7005d6f2dc079af5f0ae6bbc4c0b9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('024d11faa4911bc921847436713259f06ba18fbef92b3499fa07038b6d7da166',1996,'MA','Morocco','people-and-society',609,'Population: 29.779.156 uly 1996 est)
Age structure:
0-14 vears: 38% (male 5.696.731. temale
§.$22.077)
15-64 vears: S8% (male 8.577.918: temale
8.700.521)
65 years and over, 4% (male 613.712:
female 668.197) (July 1996 est.)
Population growth rate: 2.05% (1996 est)
Birth rate: 27.39 births/1.000 population
(1996 est.)
Death rate: $5.77 deaths/1.000 population
(1996 est.)
Net migration rate: -! 08 migrant(s)/) 000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 vears: 1.03 maletsVtemale
15-64 years: 0.99 male(s)/temale
65 vears and over: 0.92 male(s)temale
all ages: | male(s)/female (1996 est.)
Infant mortality rate: 43.2 deaths/ 1.000
live births (1996 est.)
Life expectancy at birth:
total population: 69.52 years
male: 67.53 years
female: 71.61 years (1996 est.)
Total fertility rate: 3.58 children born/
woman (1996 est)
Nationality:
noun. Moroccants)
adjective: Moroccan
Ethnic divisions: Arab-Berber 99 1. other
0.7. Jewish 0.29
Religions: Muslim Ys 7%
Jewish 0.2%
Languages: Arabic (official). Berbe:
Christian 11
dialects. French often the language of
business, government. and diplomacy
Literacy: age 15 and over can read and
write (1995 est.)
total population: 43.7
male. 56.6%
female: 31%
Population: 214,384 (July 1996 est.)
er
Age structure:
0-14 years: 40% (male 43,540; female
42,185)
15-64 years: 56% (male 62,742: female
57,323)
65 years and over: 4% (male 4,089; female
4,505) (July 1996 est.)
Population growth rate: 2.37% (1996 est.)
Birth rate: 31.12 births/1,000 population
(1996 est.)
Death rate: 5.75 deaths/1,000 population
(1996 est.)
Net migration rate: -1.67 migrant(s)/1,000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.1 male(s)/female
65 years and over: 0.91 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 34.3 deaths/1,000
live births (1996 est.)
Life expectancy at birth:
total population: 68.73 years
male: 66.35 years
female: 71.24 years (1996 est.)
Total fertility rate: 3.93 children born/
woman (1996 est.)
Nationality:
noun: Western Samoan(s)
adjective: Western Samoan
Ethnic divisions: Samoan 92.6%,
Euronesians 7% (persons of European and
Polynesian blood), Europeans 0.4%
Religions: Christian 99.7% (about one-half
of population associated with the London
Missionary Society; includes Congregational,
Roman Catholic, Methodist, Latter-Day
Saints, Seventh-Day Adventist)
Languages: Samoan (Polynesian), English
Literacy: age 15 and over can read and
write (1971 est.)
total population: 97%
male: 97%
female: 97%
Population: 5.77 1.939.007 (July 1996 est.)
Age structure:
0-14 years: 31% (male 919,402,570; female
874,330,478)
15-64 vears: 62% (male 1.824,524,365:
female |.776,639,084)
65 vears and over: 7% (male 162,216,128:
female 213,712,993)
Population growth rate: |.4% (1996 est.)
Birth rate: 23 births/1,000 population (1996
est.)
Death rate: 9 deaths/1,000 population (1996
est.)
Sex ratio:
at birth: 1.06 male(sWfemale
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 vears and over: 0.76 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
533
Infant mortality rate: 60 deaths/!,000 live
births (1996 est.)
Life expectancy at birth:
total population: 62 years
male: 61 years
female: 64 years
Total fertility rate: 2.9 children born/
woman (1996 est.)','b6502d8672983d80d76cb39716b3f2a4dd6639cbbd4a78161360822d6cc1f06e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32c0151b7ba8d9e82988f456dc2e33a4e60726f694a315ce83cc582388f6d38d',1996,'MZ','Mozambique','people-and-society',614,'Population: S77.927 duly 1996 est
Ave structure:
O-d4 vears. 46 male 4.141 .99S. femal
LIS AYT)
1\\-64 yours: SV timale 4.324.102: temale
} Shs Sis
> yours Gnd Oves vy (mate iS4 Ot
female 243.595) (July 1996 est
Population growth rate: 265°) (1996 est
Birth rate: 45.5) births
{ YOR,
1AM) proopubatiar
’
Csi
Death rate: 18 97 deaths 1.000 populat
(| YUH est
Net migration rate: 0 mograntis)/ | 000
population (1996 est)
notes by the end of 1994. an estimates
nuithon Mozambiean retuvec i
Malawi. Zimbabwe. and South Atrica
earlier vears trom the civil war. |
returned. an estimated LOOLO00 ret
remain to be repatriated trom f
Sex ratio:
at birth: 1.038 matetsivtemal
under 1S vears: 1 Ol matetsyt
15-64 years: O89 m, fer
65 years and over O76 mal
all ages. 0.94 maleisVtemale (149
Infant mortality rate: 125 6 deaths 000
hive births (1996 est)
Al
Mozambique (continued)
Life exe ectaney at birth:
e 7 a | 7 >
die in +4 34 VOCUS
ie 6499 Vears (1996 est
otal fertility rate: 6.23 children born/
“Sty ost
Nathonality:
\\4
Pthate divistoms: nidigenous tribal groups
Chokwe. Manvika. Sena.
} UPOPe ans 06%. Euro
bred (Fis,
Religions digenous belbets SOG). Christian
4
hanguages: Portuguese totficial) indigenous
f iteraey: ae Sound over can read and
Hye
f,overnment
Name of countrs:
Vlocan uc
Data code: \\I/
Ivpe of government: republic
Capital: \\l
\\dministrative divisions: 10 provinces
provincia: Cabe
| mbane. Manica, Maputo
\\ i.» i fete. Zambesia
Independence: mS (irom
National holiday: Independence Dax. 25
( onstitution \\ ber 1W00)
Leval svstem Portuguese civil law
1
Sullrage: universal
Pavccutive branch:
hoaguim Alberto
NO) November 1986) was
mm by popular vote
Prime Minister Pascoal
NIK Ni} '' bye her 1004) was
Legistative branch: unica
; « Aepu ( Assembler de
at j mt i elected by
real. adult sulfrave on a secret
term of tive vears: election last
) October 1994 (next to be held
4342)
NA October 1999): results—percent vote by
party NA. seats (250 total) FRELIMO won
a slim majority
note: the presidential and legislative
elections took place as called for in the 1992
peace accords: RENAMO participated im the
elections
Judicial branch: Supreme Court. judges
appointed by the president and judges
elected by the Assembly
Political parties and leaders: bront tor the
Liberation of Mozambique (FRELIMQ).
Joaquim Alberto CHISSANO, chairman.
Mozambique National Resistance
(RENAMO). Atonso DHLAKAMA.,
president. Democratic Union (DU), Antone
PALANGE. General Secretary
International organization participation:
ACP. AtDB. CCC. ECA, FAO, G-77. IBRD.
IAQ. ICRM. IDA, IDB. IFAD. TEC.
IEFRCS. ILO. IMF. IMO. Inimarset. Intelsat
Imierpol, LOC, TOM (observer). ITU. NAM.
OAL. OIC, SADC, UN, UNCTAD.
UNESCO. UNIDO, UPL. WETU. WHO.
WMO. WTrO
Diplomatic representation in US:
hiet of mission. Ambassador Hipolito
Perera Zozimo PATRICIO
chancery: Suite 570. 1990 M Street NW,
Washington. DC 20036
telephone. | 1} ¢202) 293-7146
FAN. (1) 6202) 835-0245
US diplomatic representation:
chiet of mission. Ambassador Dennis
Coleman JETT
embassy. Avemda Kenneth Kuanda 193.
Maputo
mating address. P.O. Box 783. Maputo
telephone: (298) (1) 492797
FAX: {258] (4) 490114
Flag: three equal honzontal bands of green
(top). black. and vellow with a red tosceles
tnangle based on the hort side: the black
band is edged +n white: centered in the
trungle isa vellow tive-pomted star bearing
4 crossed ritle and hoe im black
upermposed on an open white book
Population: 29,058,470 (July 1996 est.)
Age structure:
0-14 years: 45% (male 6,536,911; female
6,576,752)
15-64 years: 52% (male 7,360,370; feraale
7,739,500)
65 years and over: 3% (male 396,128;
female 448,809) (July 1996 est.)
Population growth rate: 1.15% (1996 est.)
Birth rate: 41.31 births/1,000 population
(1996 est.)
Death rate: 19.47 deaths/1,000 population
(. 996 est.)
Net migration rate: -10.36 migrant(s)/1,000
population (1996 est.)
note: the total number of Rwandan and
Burundian refugees in Tanzania is about
750,000
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.88 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 105.9 deaths/1,000
live births (1996 est.)
Life expectancy at birth:
total population: 42.34 years
male; 40.95 years
female: 43.78 years (1996 est.)
Total fertility rate: 5.67 children born/
woman (1996 est.)
Nationality:
noun: Tanzanian(s)
adjective: Tanzanian
Ethnic divisions:
mainland: native African (95% Bantu,
consisting of well over 100 tribes) 99%,
Asian, European, and Arab 1%
Zanzibar: Arab, mixed Arab and native
African, native African
Religions:
mainland: Christian 45%, Muslim 35%,
indigenous beliefs 20%
Zanzibar: Muslim more than 99%
Languages: Kiswahili or Swahili (official),
Kiunguju (name for Swahili in Zanzibar),
English (official, primary language of
commerce, administration, and higher
education), Arabic (widely spoken in
Zanzibar), many local languages
note: Kiswahili (Swahili) is the mother
tongue of Bantu people living in Zanzibar
and nearby coastal Tanzania; although
Kiswahili is Bantu in structure and origin, its
vocabulary draws on a variety of sources,
including Arabic and English, and it has
become the lingua franca of central and
eastern Africa, the first language of most
people is one of the local languages
Literacy: age 15 and over can read and
write Kiswahili (Swahili), English, or Arabic
(1995 est.)
total population: 67.8%
male: 719.4%
female: 56.8%','7ca4aa862589416cadf2a4f762f97c80b4961fbb7a31aecf6f8c907b2cd3e6dc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c18c1ffbd76993977f8835d3dbbdbbf2d13342d0696babed8f0b82392137fad',1996,'NA','Namibia','people-and-society',623,'Population: 10.273 Gluly 1996 est)
\\ge Mructure:
ars NA
NA
cr NA
Vopulation growth rate: | 43°" (1996 est)
Birth rate: (S038 births’ 1.000 population
Death rate deaths 1.000) population
Net nagration rate: 0 4 mierantisv ha
i )
SeN rato
NA Lin
N“N\\ deisWtemal
NA ‘ Tomial
NA matets female
NA il Torvssic
Infant mortality rate: 40.6 death |) .000
Life expectancs at birth:
fo OS Vcars
‘ fy WM) ost}
lotal fertility rate: 2 O08 Children born
"y
Nautronality:
\\
\\ in
bihnic divistons: Nouruan SS‘. other
p 6°). Chinese So. European
Religions: (hos ian (two-therds Protestant
| aC atholn
languages: Nauruan toltiial. a distinct
! ‘uave?). koglish wadelsy
npoken, and used tor most
commercial purposes
f,overnment
Nume of countrs:
enteonal long form: Republic of Nauru
cntieonal short torm Nauru
rover Pleasant Island
Duta code: NR
Iype of government: republi
Capital: no offical capital, government
thees on Yaren District
3M
Administrative divisions: |4 districts:
Ameo. Anabar. Anetan. Anibare. Batti, Boe.
Buada, Demgomodu. Ewa. lpuw. Meneng.
Nibok. Uaboe. Yaren
Independence: 3! January 1965 (from the
\\ustralia-. New Zea’ and-. and UK-
administered UN trusteeship)
‘ational holiday: Independence Day. 31!
January (1968)
Constitution: 29 January 196%
Legal system: acts of the Nauru Parhament
and Botish common law
Suffrage: 20 years of age. universal and
compulsory
Executive branch:
chief of state and Aead of eovernme:''
President Lagumot HARRIS (since 22
November 1995) was elected by Parliament:
election last held 1S Nevember 1995 (next to
he held NA November 1998)
cabinet: Cabinet was appointed by the
preadent from among members of
Parliament
Legislative branch: unicameral!
Parhanment: election last held 1S November
1995 «next to be held NA November 1998).
results —percent of vote NA: seats—1 18
katal) independents 1X8
Judicial branch: Supreme Court
Political parties and leaders: none
International organization participation:
ASDB. C (special), ESCAP. ICAO. Intelsat
(nonsignatory user). Interpol, ITU. Sparteca.
SPC. SPE. UPL. WHO
Diplomatic representation in US: Nauru
dees not have ca embassy in the US
US diplomatic r-presentation: the US does
not have an embassy in Nauru. the US
Ambassador to Fipp rs accredited to Nauru
Flag: blue with a narrow. honzental, vellow
sinipe across the center and a large white 12
pointed star below the stripe on the hoist
vide. the star indicates the country’s location
in relation to the Equator (the vellow stripe)
and the 12 ports symbolize the 12 orginal
inbes of Nauru
Population: uninhabited. mete
Haitian tishermen and others camp.
provided via Australian facilities
domestic: NA
miernational. satelite earth sauon— |
Intelsat (Pacific Ocean)
Radio broadcast stations: AM |. FM 0)
shortwave 0
Radios: 4.000 (1993 est)
Television broadcast stations: () (1986 ext) Government
Televisions: NA
stand
Name of country:
evil howe torn
, entnonal sf wT fave Nua
Defense Data code: BY
Ivpe of government: woimcorp
Branches: no regular armed forces
. lcrrvters of the US admunmicred by the tS
Directorate of the Nauru Police Force
C oust Cran
Manpower availability: | Capital: none. administered trot
males age 15-49: NA Washington. DX
i tr rw >
males fit for military service: NA Geography Flag: the flag of the US is used
Defense expenditures: SNA. NAS of GDP
Location: Canbbhean. land on the Canbhean
Sea. about one-fourth of the was trom Hat
to Jamana','f0181de5c7c8486123f4afc03b4adac94331f07d6b1071c98789c64f73d19d6f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5feb96feebac7390f2ad3da706970e785875c8d2383686e2def7dd09af5ff52',1996,'NP','Nepal','people-and-society',626,'Population: 22.(994.033 uly 1996 est)
Age structure:
0-14 vears: 42% imale 4.776.245. female
4.563. 0000)
15-4 veaurs
$915. 626)
35% imale 6.172.821. temale
45 vears and over: 4% (male 320.350
female 315.991) uly 1996 est)
Population growth rate: 245) (1996 est)
Birth rate: 37 births 1.000 population (1996
cst}
Death rate: | 2.56 death 1.000) population
1YYH est)
Net migration rate: () migrantisy 1.000
population «1996 est)
Sex ratio:
tineth 1 OS matletsitemate
wuler 1S vears. LOS maleisvtiemale
13.4 sears 104 maletsWtemale
‘1S wears and over 101 maletsiWtemale
ws | iid rricabent s) termale { 1YUH esl }
74 deaths/ 1.000 live
Infant mortality rate:
hrths «1 9N6H est )
at birth:
S364 veurs
Life expectancy
reoprealaatiam
mile $3.34 sears
eomale S394 vears (1996 est)
lotal fertility rate:
woman +1996 est)
Nationality ;
S06 children born
noun. Nepalese (singular and plural)
cadjcr Te Nepales:
Lthnic divisions: Newars. Indians
Shura
Tibetans
Gurungs. Magars. Tamangs Rusts
Liambus. Sherpas
Religions: Hindu 90
Muslim +. other 2°;
only officral Hindu state mm world
Buddhist 5%
(198) )
hhevle
though mo sharp distinction between mam
Hindu and Buddhist groups
languages: Nepali iiiticial), 20 other
languages divided into numerous dialects
Literacy: age 15 and over can read and
write (1995S est)
hotal population: 27.8%
male 409%
female. 14%','6944a29bb4e58279424b18b1f4fe088783b62c9e9a920c791bb8fc831d976eae','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb33f2e6b7dde2668677cb6e06ffe2e2e5b8d00bc9a4de6b325662ac8211b63c',1996,'NL','Netherlands','people-and-society',631,'Population: |5.568.034 uly 1996 est.)
Age structure:
O-14 vears: 18% (male 1.457.694. temale
1.393.402)
15-64 years. OS (male $.412.402. female
$.228.579)
65 years and over: 14% (male &36.934;
female 1.239.023) uly 1996 est)
Population growth rate: 056% (1996 est)
Birth rate: | 2.08 births/1.000 population
(1996 est.)
Death rate: § 7 deaths/1.000 population
(1996 est)
Net migration rate: 2.25 migrants) 1.000
population (1996 est)
Sex ratio:
at birth: 1.05 maletsWtemale
wider 1) vears. 1 OS maletsVtematle
15-64 years. 1.04 maletsitemale
65 years and over, O68 maletsitemale
all aves, O9S maletsVtemale (1996 est)
Infant mortality rate: 4.9 deaths/).000 live
births (1996 est)
Life expectancy at birth:
total population: 77.73 sears
male. 7491 vears
female” SO.68 years (1996 est)
Total fertility rate: | 5!) children bory
woman (1996 est)
Nationality:
noun: Dutchmantmen)
Dutchwomani women)
adjective. Dutch
Ethnic divisions: Dutch 96°. Moroccans.
Turks. and other 4% ()9R8S)
Religions: Roman Catholic 347. Protestant
25%. Muslow 347. other 2%. wnattiliated
367 (1991)
Languages: Dutch
Literacy: age 15 and over can read and
write (1979 est.)
total population: 99%
male: NAG
female: NAG
Population: 208.968 Gluly 1996 est)
Age structure:
0-14 years: NA
15-64 vears: NA
65 years and over: NA
Population growth rate: |.03°° (1996 est)
Birth rate: 15.98 births/1.000 population
(1996 est.)
Death rate: 5.29 deaths/1.000 population
(1996 est.)
Net migration rate: -0. 37 migrant(s)/1.000
population (1996 est.)
Sex ratio:
al birth: 10S malets)/temale
under 15 vears: 1.05 maletsvtemale
15-64 years: 09S male(si/temale
65 vears and over: 0.72 maletsVtemale
all ages: 0.96 maletsWVtemale (1996 est.)
Infant mortality rate: &.9 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
tatal population: 77.06 years
male: 74.78 years
female: 79 46 years (1996 est.)
Nationality:
noun: Netherlands Antilleants)
adjective: Netherlands Antillean
Ethnic divisions: mixed Alncan 85. Carb
dian. European. Latin. Onental
Religions: Roman Catholic. Protestant,
Jewish. Seventh-Day Adventist
Languages: Dutch (official). Papiamento a
Spanish-Portuguese-Dutch-English dialect
* dominates, English widely spoken.
Spanish
Literacy: age 15 and over can read and
write (19ST est)
total population: 9S
male: OSG
fe mrale YU,
Ceovernment
Name of country:
conventional lone form: none
conventional short form. Netherlands
Antilles
local lone form: tone
local short form Nederlandse Antillen
Data code: NI
Type of government: part of the Dutch
realm: tull autonomy in internal affairs
granted in 1954
Capital: Willemstad
Administrative divisions: none (part of the
Dutch realm)
Independence: none (part of the Dutch
realm)
National holiday: Queen s Day. 30 April
(193s)
Constitution: 29 December 1954. Statute of
the Realm of the Netherlands. as amendec
Legal system: based on Dutch civil law
system. with some English common law
influence
Suffrage: 18 years of age: universal
Executive branch:
chief of state: Queen BEATRIX Wilhelmina
Armgard (ot the Netherlands since 30 April
1YSO) os a Constitutional monarch,
represented by Governor General Jaime
SALEH isince NA October 1989). who was
appointed for a six-year term by the queen
head of government: Prime Minister Miguel
POURITER (since 25 February 1994) was
appointed by the Staten
cabinet’ Council of Ministers was appointed
by the Staten
Legislative branch: unicameral
Staten: elections last held 25 February 1994
(next to be held NA March 1998). results
percent of vote by party NA: seats —123
total) PAR &. PNP 3. SPA 2. PDB 2. UPB
1. MAN 2. DP 1. WIPM 1. DP-Stk 1. DP
SuM 1. Nos Patria |
nate. the government of Prime Minister
Miguel POURIER ts a coalition of several
parties
Judicial branch: Joint Hich Court of Justice
Political parties and leaders: political
parties are indigenous to each island
Bonaire. Patnotic Union of Bonaire (UPB)
Rudy ELLIS. Democratic Party of Bonaire
(PDB). Broertwe JANJA
Curacao, Anttiean Restructuring Party
(PAR). Miguel POURTER: National People''s
Party (PNP). Maria LIBERIA-PETERS: New
Antilles Movement (MAN). Domenico Felip
Don MARTINA: Workers” Liberation Front
(FOL). Wilson (Papas GODETT: Socialist
Independent (SI). George HUECK and
Nelson MONTE: Democratic Party ot
Curacao (DP). Augustin DIAZ: Nos Patria
Chin BEHILIA
Saba: Windward Islands People’s Movement
(WIPM Saba). Ray HASSELL: Saba
Democratic Labor Movement. Steve
HASSELL: Saba Unity Party. Carmen
SIMMONDS
Sint Eustatius: Democratic Party of Sini
Eustatius (DP-Stk). Julian WOODLEY
Windward Islands People’s Movement
(WIPM): St. Eustatius Alliance (SEA)
Ingrid WHITFIELD
Sint Maarten: Democratic Panty of Sint
Maarten (DP-StM). Sarah WESTCOTI
WILLIAMS: Patnotic Movement of Sint |
Maarten (SPA). Vance JAMES: Serious |
Alternative People’s Panty (SAPP) Julian
ROLLOCKS
International organization participation:
Cancom (observer). ECLAC (associate
Interpol. LOC. UNESCO (associate). UPI
WMO. WTO (associate
Diplomatic representation in US: no
seli-governing pan of the Netherlu
US diplomatic representation:
chicf of musston-: Consul General James |
WILLIAMS
Consitlale Venlcrtait j I (;
Curacao
mailing address POB \\
( Uide de)
ie lephone SYY Y) f
FAX, [599; 09) 61-6489
Flag: white with a |
the center supenmposed
hand also centered: tive whit
tars are arranged in an oval |
center of the blue band
represent the tive mai ands of Be
Curacae. Sabu. Sint kusta P Sut |
Maarten
Lconomy
Economic overview: |
finance are tl
COONMOMN. WI ti
world 1 hic Tha | i fig
Hho thal a md
compared with other countri
igvron Vlimeost i in} ital pit
MOIS Ue TTPO with \\
US being the mapor supy rm Pi
Mudequate Water suppl mp
ci Velopimnc ntl avi |
GDP: purchasing power pal ‘ !
billion (1994 est)
GDP real growth rate: | > W4
GDP per capita: $1040) m4
GDP composition by sector:
TUR MLL ‘\\ \\''
mdusy NAS
vervices. NA‘
Inflation rate (consumer prices)
(1994 est)
Labor force: 89.000
PY occupant CoveTnmcnt f
and commerce 286 198
Unemployment rate:
Budyet:
revenues: S209 milli
( iponditune 6 SJ32 millior
expenditures of SS million (199
Industries: tourmin OC ura it Sant
Maarten). petroleum refining «
343
35a
Netherlands Antilles (continued) lelephone system: generally adequate New Caledonia
facilities (overseas territory of France)
....-a lata ( Loic Ste evlensive interisiand Marowave
Wiiitics ¢ Lif dy he?
nufacturine (Curacao idio relay links
fodustrial production growth rate: \\ A fernational 2 submarine cables: satellite
,
arth statrons— 2 Intelsat (Atlantic Ocean)
: tracts:
SOOO KW Radio broadcast stations: AVI Yo EM 4
Vintlion KW shortwave 0
hOSS OW 1YY 3 Radios: 205.000 ©1992 est
Vor ull re: . sorehum: neat ‘ * * 2 ati . t tate
ricullure: ronum. pea lelevision broadcast stations: |
lelevisions: 64.000 (1992 est
ti i drugs ma
‘ \\
’ is
Defense ihes
} port ”) yaut
. e ; wet LU ¢
: Branches: Royal Netherlands Navy. Marine oo hie —
} ( ‘ ( rs Roval Netherlands \\u Force New * True
;* i ; \\ ale wa
i! i} Catuard *olice wre?
ports '' tat ae _ Noumea” odes Pe
4 Defense note: defense ts the responsibility
\\ 1! Tid!
tS
il hf )','a724d48c5e25970a3a53cf25f96aabd32897c4945d186c133a429a71e6864285','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a565d98989fe131f6c8dfc1f1a4dae49d69f50735952861b6dbea8d4d16170a',1996,'TK','Tokelau','people-and-society',638,'Population: 4.272.352 uly 1996 es)
Ace structure:
0-14 vears: 44% (male 951.754. temale
YIK_SUD)
15-04 years. SMe imate 1.105.069, temale
1.164.144)
65 vears and mer Ve imate 49.027. temale
64.259) duly 1996 est)
Population growth rate: 2675. (1996 et)
Birth rate: 33.83 birth 1.000 population
(1996 est)
Death rate: 6.0!) deaths 1.000 population
(1996 est!
Net migration rate: -| |7
population (1996 est)
Sex ratio:
al durth, 1.04 maletsWtemale
nigrantis/ 11K)
under 1S vears: 1.01 maleisWtemale
15-4 vears. O0.9S males Wtemale
OS vears and over’ 0.76 maleisWtemale
all ages: 0.97 maleisWiemale (1 49 est)
Infant mortality rate: 45 8 deaths | .000
live births (1996 est)
Life expectancy at birth:
hital population: 68.72 years
male. O4.41 Vvears
fomale. OR14 years 11996 est)
Total fertility rate: 4.038 children born
woman (1996 est)
Nationality:
noun Nicaraguants)
adjective: Newaraguan
Ethnic divisions: mestizo (anved
Amenndian and white) 69%, white 17%
black 9°~. Indian S%
Religions: Roman Catholic 98%. Protestant
s%
Languages: Spanish (official)
note: English- and Indian-speaking
minorities on Atlante cceast
Literacy: ige 1S and over can read aud
write (1995 est)
wwital population. 65.7"
male 64.6%,
leomatic. Of t''.
Gor ernment
Name of cocmry:
comentional lone torm Republi val
Population: |.482 (July 1996 cst.)
Age structure:
0-14 vears: NA
15-64 vears: NA
65 vears and aver: NA
Population growth rate: -|.35% (1996 est.)
Birth rate: NA births’/1,000 population
Death rate: NA deaths/! 000 population
Net migration rate: NA migrant(sy/1,000
population
Sex ratio:
at birth: NA male(sy¥ftemale
under 15 years: NA male(s)/female
15-64 vears: NA male(s)/female
65 vears and over: NA male(sWfemale
all ages: NA male(syfemale
Infant mortality rate: NA deaths/!.000 live
births
Life expectancy at birth:
total popuiation: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/
woman
Nationality:
noun: Tokelauan(s)
adjective: Tokelauan
Ethnic divisions: Polynesian
Religions: Congregational Christian Church
70%. Roman Catholic 28%, other 2%
note; on Atafu, all Congregational Christian
Church of Samoa; on Nukunonu, all Roman
Catholic; on Fakaofo, both denominations,
with the Congregational Christian Church
predominant
Languages: Tokelauan (a Polynesian
language), English','9cc5e72563df11e78dbfba385350c94ea5fa145bb6c4c8ad6b4746762479ea8f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9ed974f89ffa682cd68834f30397c78a1a667a275c7721da8f70497e63a92c5',1996,'NO','Norway','people-and-society',647,'Population: 4.383.807 Gluly 1996 est)
Age structure:
O ds years: 19% Cmale 434.848. female
311 668)
13-64 years: G2 ¢ (male 1.446.746. tomate
| WH pS)
45 years and over, VW6% (male 288.789
tomate 405.606) uly 1996 est)
Population growth rate: 0 48% (1996 est)
Birth rate: 11.96 births/1.000 | opulation
(1996 est)
Death rate: 10.68 death 1.000 population
(1906 est)
Net migration rate: ) 57 migrantisy/ | 000
population (1996 est)
Sex ratio:
at darth. 1.06 maletsitemale
wader TS vears. 1.06 malets Vtemak
18-44 vears) 104 maletsViemale
HS years and over, O71 maletsWtemale
all ages. OY maletsWiemale (1996 est)
Infant mortality rave: 49 deaths 1.000 live
births (1996 est)
Life expectancy at birth:
totai population. 77. S34 years
male, 74.64 years
female: 80.61 years (1996 est.)
Total fertility rate: |.63 childrer born/
woman (1996 est.)
Nationality:
noun: Norwegians)
adjective: Norwegian
Ethnic divisions: Germanic (Nordic. Alpine.
Baltic), Lapps (Sami) 20.000
Religions: Evangelical Lutheran 87.8%
(state church). other Protestant and Roman
Cathet 38%. non 3.2%. unknown 5.2%
(1980)
Languages: Norwegian (otficial)
note: small Lapp cad Finnish-speaking
minorities
Literacy: age 15 and over can read and
write (1976 est)
total population: 9%
male: NA‘
female: NAG
November (1940
‘ wee Population: 2.)86.548 July 1996 es! Constitution: no
: \\ge structure: Legal system: based on |
dd \\cal?ls ify i male Si 1.064. temak i\\ il | tthe ta pita ‘ |
JU Wy, lun. has not accepted « pails Mo
“OUT: ‘ :
Ce graph: 1s hd yours 5] mace OY | ‘ femal | dict! )
Location: Middle bast. bordermy the $134? Suffrage:
Arabian Sea. Gult of Oman. and Persian HS years and over: % nale 26.6223. temal Executive branch:
Guilt, between Yemen and U Al > 2 Tp eluly 196 c4
rT; i mates: >) OO yin . ip HOM
Coen graphic coordinates ‘ ‘\\ im) | Population growth rate: \\>3 yh ‘ | \\1 p+] )
Vlup references: Middle | Hirth rate: 37 86 birt T '' iS
\\rea: poy
vex ’ 400) sab
Meath rate: 4 44 uM)
aful
. Y Levestlative branch
Net migration rat \\4
h
Land boundaries
. , al branch
Sen ratio ludici ram
\\ \\ i
\\} j 4 . xs i
Political parties and leaders
( asthe , ,
(Mher political or pressure grou |
Niartiome claims |
International organisation parth
’ } »
Infant mortality cate
International disputes Life expectancy at birth
\\! \\ |
( berveate
- lotal fertelity rate Itplomati representation in ts
lerram
Natromalits
‘1
|
Ncu~ral resources hihi Go etoms: = \\
‘4 > ''
LS diplomatic repres satiation
Land use Keliyions \\i ‘ \\
\\1 \\ \\1 ii , Ls
Languages: \\;.! : uN
S } }
Cun é‘ we K
‘ " j i} Alo {) \\%
mee Literacy: NA ‘
gulited 4 sf\\* f . .
Irrigated land: 410 sg kim (1989 ex LAY. (6x) 09
M3
j »
QOman ig ontinued) commodities: Machinery. transporiation
equipment, manutactured goods. food, ~_—
blag: T yontal bands of white (lop livestock. lubricants
anit! ed. and green (double width) partners. UAE 27% largely reexports). Branches: Army. Navy. Au Force.
al. red band on the how Japan 20% UR ISO. US So. Germany 4% paramilitary cincludes Royal Oman Police)
nbiem (a khanjar dagger (1993) Manpower availability:
ned on (wo saudi External debt: $3 billion (1993) males age 15-49: $32,113
white 1s centered at Economic aid: males fit for military service: 301,747 (1996
- recypent. ODA, S82 million (1993) st)
Currency: | Oman mal (RO) = 1.000 baiza Defense expenditures: exchange rate
Exchange rates: Oman nals (RO) per conversion—S1.8? billion. 13.7% of GDP
2 “ . * wn » a
USS] —47. 3845 ctined rate since [YS86) (1996)
Econom Fiscal vear: calendar year
bconomic overview: boonennc pertormance
Om ine on!
’ iy “Oy : . ati
or nearly 9) l ransportation
‘ of covermment
Railways: 0 kin
om GDP. Oman ;
Highways:
1 hiltnon barrels 9 48 k
fotal> CS YS4S km
ils ‘ ppl al th 7 ; "
\\ pavcd 4.930 km cncluding 413 km of
? vraculilure is
ia) CAPTEssWays,
ith 1h
mypurcd % GiS kimi }yy) est.)
muted
“ipelines: crude oi! 1.300 km: natural gas
ine piv ale .
| O30 bm
nl is «l
Ports: Matrah. Mina al Fabl. Mina’ Ravsut
tl
Vierchant marine:
tal 3 shops cL 000 GRT or over) totaling
c.DP . ‘ 1\\ a | : » : ~
ib. 6 GRT/S.210 DWI
eps hoy yyy Carve } rassenvet |
(DP real growth rate: *° > IVOS est -
j | pussenvel cargo 1c iV8S est
.DP per capita: > si) MS esi .
| \\irports:
GDP composition by sector: _ TT
;
eal ie ‘ ig? 3 4 ‘
t hi J . ;
‘ id ”
Inflation rate (consumer prices: 0 ee | lm ir
hay ‘
‘ a
Labor force: 454.000) ‘ dre > Zen Saad
, ‘ J . *
t nemplov ment rate: \\ \\ nr '' TP ‘
Kudyet ws
Heliperts: ")
\\
Industries
( onmmunications
lelephomes: | 5000F my
Industrial preduction growth rat lelephone system
blectrocnty ent
'' \\ \\A j rth it
* 4
4
\\ ihn mh
\\yvrhe iture ! ! . Miih SA ertl
. " viclliite carth Matne
I \\ports, . . 4 lyat | ly aj if) fhe it} and ! \\ ify il
Radw broadcast stations: AMI Oo EM 4
[ aA’ ‘J ’ \\l | WAVE
Pagyaat South ® Ba Radios: | 0438 nulloon (1992 est)
CSV ct . Phutand S 1yWO4 lelevision broadcast stations: 9
Imports: S4 Millon tc! 1994 est) Televisions: 1.195 millon (1992 est)
Location: body of water between Antarctica.
Asia. Australia, and the Western Hemisphere
Geographic coordinates: 0 00 N. 160 00 W
Map references: World
Area:
total area: 165.384 millon sq km
comparative arca, about 1S times the size of
the US. the largest ocean (followed by the
Atlaniic Ocean, the Indian Ocean. and the
Arctic Ocean), covers about one-third of the
global surtace. larger than the total land area
of the world
note. wmcludes Bali Sea, Bellingshausen Sea
Benng Sea. Bering Strat. Coral Sea. bast
China Sea. Flores Sea. Gulf of Alaska. Gull
mM Tonkin. Java Sea. Philippine Sea. Rows
Sea. Savu Sea. Sea of Janan. Sea ot
Okhotsk. South China Sea. Tasman Sea
Tame Sea. ard other tributary water bodies
(Coasting. | 45.665 kim
International disputes: snc martin
disputes (see littoral s’
Climate: planetar, on sure svstcems and
meullant wed poder cx ot remarkalhe
uniformed, om th. south amd cast. trade wonds
and s esterly wrnds are wcll developed
pattera.. meaditred by seas onal (huctuateowns
tropacal evchones (hurncanes) may form
south of Mesnco trom June te Ooteber and
alters Mexwcoo and Central Amerma
coy tinentai mors cause chimath
unitoruty to he cuuch less pronounced m
the casiem unc westem regroms at the son
latude on the North Paci Ooean. the
western Pacitic ts monsoonal—a nan
season occurs dunng the summer months
when momture-laden winds blow trom the
vcean over the land. and a dry season during
the winter months, when ary winds blow
from the Asian land nuass back to the ocean
tropical evelones (1) phoons) may strike
southeast and East Asia from May to
December
Terrain: surface currents in the nerthem
Pacific are dominated by a clockwise. warm-
water gyre (bread curcular system of
currents) and un the southern Pacific by a
counterclockwise, cool-water gyre. im the
nomherm Pacific. sea ce forms in the Bering
Sea and Sea of Okhotsk im winter. im the
southern Pacific, sea ice from Antarctica
reaches its northernmost extent yn October.
the ocean floor un the eastern Pacific 1s
dominated by the East Pacific Rise. while
the western Pacific 1s dissected by deep
trenches. including the Mananas Trench.
which ts the world’s deepest
lowest point: Mananas Trench -10.924 m
nghest point: sea level 0 m
Natural resources: oi! and gas fields.
polymetallc nodules, sand and gravel
aggregates, placer deposits, fish','60764429b7ca6149da9e27ce263b1fae7f3f645987a6af8129819728bfacf0a1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('323ea21877584ccfb9b68dc2368ae28724a902f269916e8f7bc7add857552876',1996,'PK','Pakistan','people-and-society',653,'Population: 129.275.6960 (luly 1996 esi.)
Age structure:
(44 years: 42% (male 28.286.823: temale
26.640.019)
15-64 vears: 53% (mele 35.396.281: female
33.733.798)
65 vears and ever: Me (male 2.621.721:
female 2.597.018) (duly 1996 est.)
Population growth rate: 2.24% (1996 est.)
Birth rate: 36.16 births/1.000 population
(1996 est.)
Death rate: || 22 deaths/1.000 population
(1996 est.)
Net migration rate: -2.6 migrant(s)/} 000
population (1996 est
Sex ratio:
at birth: 1. OS malets)/temale
under PS years: 1.06 male(s)/female
15-64 years: 1.05 male(s)/female
65 vears and over: 1.01 male(s)/female
all ages: 1.05 male(s)/female (1996 est.)
‘nfant mortality rate: 96.8 deaths/!.000
live births (1996 est )
Life expectancy at birth:
total population: 58.46 years
male: 57.7 years
female: 59.25 years (1996 est.)
Total fertility rate: 5.25 children born/
woman (1996 est.)
Nationality:
noun: Pakistani(s)
adjective: Pakistani
Ethnic divisions: Punjabi, Sindhi, Pashtun
(Pathan), Baloch, Muhajir Gmmigrants from
India and their descendants)
Religions: Muslim 97% (Sunni 77‘¢. Shi''a
20°C), Christian, Hindu, and other 3°%
Languages: Punjabi 487, Sindhi 12%.
Siratki (a Punjabi variant) 10°, Pashtu 8%,
Urdu (official) 8%, Balochi 3, Hindko 2“,
Brahui 1, English (official and lingua
franca of Pakistani elite and most
government ministries), Burushaski. and
other 8%
Literacy: age 15 and over can read and
write (1995 est.)
total population: 37.8%
male: SO%
female: 24.4%
other 14
total population 94%
male: 79.29
female: 79.9%
Population: 679.198 (July 1996 est.)
Age structure:
0-14 years: 32% (male 112.413: temale
107.187)
15-64 vears: 62% (male 207.386. female
214.308)
65 vears and over: 6% (male 15.610: temale
22.294) (July 1996 est.)
Population growth rate: |.93¢° (1996 est)
Birth rate: 24.01 births/1.000 population
(1996 est.)
Death rate: 4.75 deaths/}.000 population
(1996 est.)
Net migration rate: ( migrant(s)/!.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/temale
under 15 years: 1.05 male(s)/female
15-64 vears: 0.97 male(s)/female
65 vears and over: 0.7 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 7.5 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 74.77 years
male: 71.71 vears
female: 77.98 years (1996 est.)
Total fertitity rate: 2.72 children born/
woman (1996 est.)
Nationality:
noun: Reunionese (singular and plural)
adjective: Reunionese
Ethnic divisions: French. African.
Malagasy. Chinese. Pakistani. Indian
Religions: Roman Catholic 94°. Hindu.
Islam. Buddhist
Languages: French (official), Creole widely
used
Literacy: age 15 and over can read and
write (1982 est.)
total population: 79%
male: 76%
female: 80%','41f8921d72df4b03e1a82999abb0137f0f7c69514022ca91399c950c231ba5e4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18704c7c7518aa2010e37a8eb5b7168cfa77afecd01d8e152c612005dad3eaeb',1996,'PH','Philippines','people-and-society',661,'Population: 16.952 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 vears: NA
65 years and over: NA
Population growth rate: |. 71° (1996 est.)
Birth rate: 21.61 births/1.000 population
(1996 est.)
Death rate: 6.61 deaths/1.000 population
(1996 est.)
Net migration rate: 2.!2 migrant(s)/!.000
population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 vears: NA male(s)/female
15-64 vears: NA male(s)/female
65 vears and over: NA male(s)/female
all ages: NA male(s)/fteniale
Infant mortality rate: 25.07 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 71.01 years
male: 69.14 years
female: 73.02 years (1996 est.)
Total fertility rate: 2.79 children born/
woman (1996 est.)
Nationality:
noun: Palauan(s)
adjective: Palauan
Ethnic divisions: Palauans are a composite
of Polynesian, Malayan, and Melanesian
races
Religions: Christian (Catholics, Seventh-Day
Adventists, Jehovah''s Witnesses. the
Assembly of God. the Liebenzell Mission.
and Latter-Day Saints), Modekngei religion
(one-third of the population observes this
religion which is indigenous to Palau)
Languages: English (official in all of
Palau’s 16 states), Sonsorolese (official in
the state of Sonsoral), Angaur and Japanese
(in the state of Anguar), Tobi (in the state of
Tobi), Palauan (in the other 13 states)
Literacy: age 15 and over can read and
write (1980 est.)
total population: 92%
male: 93%
female: 90%
Population: unmhabited
Population: 56 (July 1996 est)
Age structure:
0-14 vears: NA
15-64 vears: NA
65 vears and over: NA
Population growth rate: 0 (1996 est.)
Birth rate: NA births/1.000 population
Death rate: NA deaths/!.000 population
Net migration rate: NA migrant(s)/1.000
population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 vears: NA male(s)/female
65 vears and over: NA male(sVftemale
all ages: NA male(s)/female
Infant mortality rate: NA deaths/!,000 live
births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/
woman
Nationality:
noun: Pitcairn tsiander(s)
adjective: Pitcairn Islander
Ethnic divisions: descendants of the Bounty
mutineers
Religions: Seventh-Day Adventist 100%
Languages: English (official), Tahitian/
English dialect
Population: 38.642.565 (July 1996 est.)
Age structure:
0-14 vears: 22% (male 4,399,649, female
4.188.824)
15-64 vears: 66% (male | 2.754.272; female
1 2.930.275)
65 vears and over: 12% (male 1.654.526:
female 2.715.019) (July 1996 est.)
Population growth rate: 0.14% (1996 est.)
Birth rate: 11.92 births/1.C90 population
(1996 est.)
Death rate: 10.08 deaths/1.000 population
(1996 est.)
Net migration rate: -0.4 migrant(s)/1.000
population (1996 est.
Sex ratio:
at birth: 1.06 male(s /te:nale
under 15 years: 1.05 male(s)/female
15-64 vears: 0.99 male(s)/female
65 vears and over: 0.61 male(s)/temale
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: | 2.4 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 72.1 years
male: 68.02 years
female: 76.41 years (1996 est.)
Total fertility rate: 1.69 children born/
woman (1996 est.)
Nationality:
noun: Polets)
adjes tive: Polish
Ethnic divisions: Polish 97.6. German
1.3%, Ukrainian 0.6%. Byelorussian 0.5%
(1990 est.)
Religions: Roman Catholic 95% (about 75%
practicing), Eastern Orthodox, Protestant. and
other 5%
Languages: Po'')-h
Literacy: age !}5 and over can read and
write (1978 est.)
fetal population: 99%
male: IW
female: 98%','fc6fa94db46cace5e48abc96dc12afaaba7590161058c480cbfe940e7f46b34a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6dd55c24a01bbd5df9d026f45b08b44af08270e73277eead14c9fe52bcef97a',1996,'PA','Panama','people-and-society',669,'Population: 2.655.094 (July 1996 est.)
Age structure:
0-14 vears: 33% (male 445.382: female
426.111)
15-64 vears: 62% (male 828.384; female
806.205)
65 vears and over: 5% (male 71.823: temate
77.189) (July 1996 est.)
Popuiation growth rate: 1.6407 (1996 est.)
Birth rate: 23.2 births/1.000 population
(1996 est.)
Death rate: 5.42 deaths/1.000 population
(1996 est.)
Net migration rate: -!.42 migrant(s)/}.000
population (1996 est
Sex ratio:
at birth: '' 04 male(s)/female
under 15 vears: 1.04 male(s)/temale
15-64 vears: 1.03 male(s)/female
65 years and over: 0.93 male(sVtemale
all ages: 1.03 male(stemale (1996 est
Infant mortality rate: 29.7 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
=
total population: 73.92 years
male, 74
19 years
female: 76.75 years (1996 est.)
Total fertility rate: 2.7) children born
woman (1996 est.)
Nationality:
noun: Panamanian(s)
adjective: Panamanian
Ethnic divisions: mestizo (mixed Indian and
European ancestry) 70°. West Indian 14%
white 10%. Indian 6%
Religions: Roman Catholic 8860. Protestant
15%
Languages: Spanish (official), English 140
note: many Panamanians bilingual
Literacy: age 15 and over can read and
write (1995 est.)
total population: V0.8
male: 91.4%
female: 90.2%
371
Panama (continued)
(,overnment
Name of country:
conventional long form: Republic of Panama
ennional short form: Panama
long form: Republica de Panama
form. Panama
Data code: PM
h<pe of government: constitutional republic
Capital: Panama
\\dministrative divisions: 9 provinces
singular—provinci) and |
ritory® (comaread: Bocas del Tore,
Chingut, Cocle. Colon, Danen, Herrera, Los
Panama. San Bias*. Veraguas
independence: 3 November 1903 (trom
Colombia, became independent from Spain
s November 1821)
National holiday: Independence Day. 3
November ()903
Constitution: |) October 1972: major
retorms adopted April 1983
Legal svstem: based on civil law system:
judicial review « rmistative acts in the
Sup eme Court of Justice accepts
compulsory ICI junsdiction, with
reservdalions
Suffrage: |: ye universal and
compulsory
Executive branch:
fol Stale l head o vovermmentl
kt
nesto PEREZ BALLADARES
Gonzalez Revilla (since | September 1994),
President
First Vice President Tomas Gabriel
ALTAMIRANO DUQUE (siace |
September 1994). Second Vice President
Felipe Aleyandro VIRZI Lopez (since |
September 1994) were elected for five-year
terms ty popular vote: election last held &
May 1994 (next to be held 9 May 1999);
results Emesto PEREZ BALLADARES
PRD) 33°. Mireva MOSCOSO DE
GRUBER (PA) 29°. Ruben BLADES
i(MPE) Rubea Danio CARLES
(MOLIRENA) 16%
cabinet, Cabinet Was appoinied by the
president
Legislative branch: unicameral
Legislative Assembly (Asamblea Legislativa)
legislators from outlying rural districts are
chosen on a plurality basis while districts
located in more populous towns and cities
elect multiple legislators by means of a
proportion-based formula: elections last held
& May 1994 (next to be held 9 May 1999),
results—percent of vote by party NA
seats—(72 total) PRD 32, PS 4. PALA 1,
PA 14, MPE 6. MOLIRENA 4, PLA 3, PRC
3, PL 2. PDC |. UDE 1. MORENA |
Judicial branch: Supreme Court of Justice
(Corte Suprema de Justicia), nine judges
372
appointed for 10-year terms; five superior
courts; three courts of appeal
Political parties and leaders:
governing coalition: Democratic
Revolutionary Party (PRD), Gerardo
GONZALEZ; Liberal Republican Party
(PLR). Rodolfo CHIARI, Labor Party
(PALA), Carlos Lopez GUEVARA
other parties: Solidarity Party (PS), Samuel
LEWIS GALINDO; Nationalist Republican
Liberal Movement (MOLIRENA), Delia
CARDENAS: Authentic Liberal Party
(PLA), Arnulfo ESCALONA: Arnulfista
Party (PA), Mireya MOSCOSO DE
GRUBER: Christiaa Democratic Party
(PDC). Ruben AROSEMENA; Liberal Party
(PL), Roberto ALEMAN Zubieta: Papa
Egoro Movement (MPE), Gloria YOUNG;
Civic Renewal Party (PRC), Tomas
HERRERA: National Unity Mission Party
(MUN). Jose Manuel PAREDES:
Independent Democratic Union (UDI),
Jacinto CARDENAS: National Renovation
Movement (MORENA), Pedro VALLERINO
Other political or pressure groups:
National Council of Organized Workers
(CONATO), National Council of Private
Enterprise (CONEP); Panamanian
Association of Business Executives
‘APEDE): National Civic Crusade; Chamber
of Commerce: Panamanian Industrialists
Society (SIP); Workers Confederation of the
Republic of Panama (CTRP)
International organization participation:
AG (associate), ECLAC, FAO, G-77. LADB.
IAEA, IBRD, ICAO, ICFTU, ICRM, IDA.
IFAD, IFC, IFRCS, ILO, IMF. IMO,
Intelsat. Interpol, LOC, IOM, ITU, LAES.,
LATA (observer), NAM, OAS, OPANAL.,
PCA, UN, UNCTAD, UNESCO, UNIDO.
UPU, WCL, WFTU, WHO, WIPO, WMO,
WT0O, WTrO (applicant)
Diplomatic representation in US:
chief of mission: Ambassador Ricardo
Alberto ARIAS
chancery: 2862 McGill Terrace NW,
Washington, DC 20008
telephone: |i] (202) 483-1407
consulate(s) general: Atlanta, Houston,
Miami, New Orleans, New York, San
Francisco, San Juan (Puerto Rico). Tampa
US diplomatic representation:
chief of mission: Ambassador William Johu
HUGHES
embassy: Avenida Balboa and Caile 38.
Apartado 6959, Panama City 5
mailing address: American Embassy
Panama, Unit 0945, APO AA 34002
telephone: [SQ7| 227-1377
FAX, [S07] 227-1964
Flag: divided into four, equal rectangles: the
top quadrants are white (hoist side) with a
biue five-pointed star in the center and plain
red, the bottom quadrants are plain blue
(hoist side) and white with a red five-pointed
Star in the center','2a12b246315c8391b9274226b82ee29498b40d17bc0aaa487b78928c5ec1bb62','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9932a0c9ae2b22b01814312b5a0c4ff5e39c791cf2a4ba162d81760b6ccb0bf',1996,'NZ','New Zealand','people-and-society',679,'Population: 0 indigenous inhabitants
note there ire scattered Chinese Qurrisoms
376','aabdd4d7dca4776bfcd98779b8ea26301436eb6a6682075836556a0067c6314a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c2e26ee73b17530f634f4c47e630e929f57659d8e321ba94d2631258f7eaeaa',1996,'PR','Puerto Rico','people-and-society',689,'Population: 3.819.023 uly 1996 est)
Age structure:
0-14 vears: 25% (male 484,038, female
461.175)
15-64 years: 65% (male 1.201.841: female
1.279.707)
65 vears and over: \\O% (male 174.274
female 217.988) (July 1996 est.)
Population growth rate: 0.18 (1996 est)
Birth rate: 15.56 birthy/1.000 population
(1996 est.)
Death rate: 7.46 deaths/1.000 population
(1996 est)
Net migration rate: -6.35 migrant(s)/ 1.000
population (1996 est.)
Sex ratio:
at birth: 1.06 maletsWiemale
under 15 vears: 1.05 maletsWviemale
15-64 years. 0.94 maleisWiemale
65 vears and over: OX maletsi/temale
all ages: 0.95 maletsvtemale (1996 est)
Infant mortality rate: | 24 deaths/!).000
live births (1996 est.)
Life expectancy at birth:
total population: 75.38 years
male: 71.13 years
female: 79.89 years (1996 est)
Total fertility rate: |.94 children born
woman (1996 est.)
Nationality:
noun: Puerto Ricanis) (US citizens)
adjective: Puerto Rican
Ethnic divisions: Hispank
Religions: Roman Catholic 88°7. Protestant
denominations and other 18%
Languages: Spanish. English
Literacy: age 1S and over can read and
write (}9S80 est.)
total population: 89%
male. 9OG
fe male AK,
Population: 3.238.952 uly 1996 est.)
Age structure:
0-14 vears: 24% (male 405,041: female
386,155)
15-64 years: 63% (male 1,004,089: female
1,035,336)
65 vears and over: \\¥% (male 170,109:
female 238.222) (July 1996 est.)
Population growth rate: (0.7% (1996 est.)
Birth rate: 17.02 births/1.000 population
(1996 est.)
Death rate: 9.05 deaths/!.000 population
(1996 est.)
Net migration rate: -0.99 migrantisW1.000
population (1996 est.)
Sex ratio:
at birth: 1.06 male(sWfemale
under 15 vears: 1.05 malei(sWfemale
15-64 years: 0.97 maleisVfemale
65 vears and over: 0.71 maleisWfemale
all ages: 0.95 maleisWfemale (1996 est.)
Infant mortality rate: 15.4 deaths/1.000
live births (1996 est.)
Life expectancy ai birth:
total population: 74.94 years
male: 71.8 vears
female: 78.25 years (1996 est.)
Total fertility rate: 2.32 children born/
woman (1996 est.)
Nationality:
noun: Uruguayan(s)
adjective: Uruguayan
503
lJruguay (continued)
Ethnic divisions: white 88%. mestizo 8%.
Hack 4%
teligions: Roman Catholic 66% (less than
tof the adult population attends
church regularly), Protestant 2%, Jewish 2%,
nonprolessing or other 30%
i_anguages: Spanish. Brazilero (Portuguese-
Spanish mux on the Brazilian frontier)
Literacy: age 15 and over can read and
srite (1995 est.)
Lt . r
otal population: 97.3%
96.9%
97.7%
elle
; orl
(EMU','5d8fb09ad2a50fcc558e9e718af57ff1350500b534e5662c3d2a9361f716cce4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce1ebf119a366ed0bfd299574deb25ab38b6749f7800b2dfdb90d72ce2b70266',1996,'BH','Bahrain','people-and-society',693,'Population: 547.761 Ululy 1996 est)
Age structure:
0-14 years: 30% (male &2.147. temale
R3.5§))
15-64 vears: O89 (male 263.107: temale
109.177)
65 wears and over: 7% (male 6.609. temale
3.169) (July 1996 est.)
Population growth rate: 2 30"
Birth rate: 21.03 births/1.000 population
{1996 est.)
Death rate: 3.6 deaths/1.000 population
{ 1996 est)
'' }U9UH csi ;
Net migration rate: 6.43 mierantisy | .000
population (1996 est.)
Sex ratio:
at birth: 0.96 maletsWtemale
under 15 vears: 0.98 maleisWiemale
15-64 vears
65 vears and over
2.41 malets female
2.09 maleisiWfemale
all ages: 1.8 maleisWtemale (1996 est.)
Infant mortality rate: 19.6 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 73.35 years
male: 70.75 years
female: 75.84 years (1996 est.)
Total fertility rate: 4.28 children born
woman (1996 est.)
Nationality:
noun: (Qatari s)
Qatan
Ethnic divisions: Arab +0
Indian 18%. Iranian 10
Religions: Musiim 95%
Languages: Arabic (official). English
commonly used as a second language
Literacy: age 15 and over can read as
write (1995 est.)
adjec live','f6f76b6a8902a91698b05357b8dfe228f219ca99d154223d109530444b2b6285','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('839567b6b006b490cd4cd7b95fee1b19e573abf95ed92a384f37134adfc4d03e',1996,'KN','Saint Kitts and Nevis','people-and-society',698,'Population: 41.369 July 1996 est)
Age structure:
0-14 years: 35% (male 7.371. female 7.026)
15-64 vears: S8% (male 12.090: temale
12.057)
6S vears and over: 7% (male 1.162: female
1.663) (July 1996 est.)
Population growth rate: (0.98 (1996 est.)
Birth rate: 23.28 births/1.000 population
(1996 est.)
Death rate: 9.21 deaths/1.000 population
(1996 est.)
Net migration rate: -4.28 migrantis)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.06 maleisWtemale
under 15 years: 1.05 maletsWtemale
15-64 vears: | male(s)/female
65 vears and over: 0.7 male(siWfemale
all ages: 0.99 male(sWtemale (1996 esi.)
Infant mortality rate: 18.9 deaths 1.000
live births (1996 est.)
Life expectancy at birth:
total population: 66.86 years
male: 63.84 years
female: 70.06 years (1996 est)
Total fertility rate: 2.52 children bor
woman (1996 est.)
Nationality:
noun: Kittsianis). Nevisian(s)
adjective. Kittsian. Nevisian
Ethnic divisions: black Atmean
Religions: Anglican other Protestant sects
Roman Catholic
Languages: English
Literacy: age 15 and over has ever attended
school (F980 est.)
total population: 97%
male: 97%
female. YR”','55d75e7e92164d7404c100ba695e58429a62beefced5b8727f6ef983a6115f9e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('497b4a1a421dcd362029b757fa9da22beb0e3cd1b8f55677dc15db1b4c17824c',1996,'LC','Saint Lucia','people-and-society',704,'Population: 157.862 (July 1996 est.)
Age structure:
0-14 years: 34% (male 27.068: female
26.491)
15-64 vears: 61% (male 47,470; female
48.612)
65 vears and over: 5% (male 3,136: female
5.085) (July 1996 est.)
Population growth rate: |.14°7 (1996 est.)
Birth rate: 22.03 births/1,000 population
(1996 est.)
Death rate: 6.02 deaths/!.000 population
(1996 est.)
Net migration rate: -4+.62 migrant(s)/} 000
population (1996 est.)
Sex ratio:
at birth: 1.07 male(s)/feniale
under 15 vears: 1.02 male(sVtemale
15-64 vears: 0.98 male(s)/female
65 vears and over: 0.62 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 20 deaths/1.000 live
births (1996 est.)
Life expectancy at birth:
total population: 70.09 vears
male: 66.52 years
female: 73.9) years (1996 est.)
Total fertility rate: 2.31 children born/
woman (1996 est.)
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic divisions: African descent 90.3%.
mixed 5.5. East Indian 3.2%. white 0.8%
Religions: Roman Catholic 90 , Protestant
7%, Anglican 3%
Languages: English (official). French patois
Literacy: age 15 and over has ever attended
school (1980 est.)
total population: 67%
male: 65%
female: 69%','14f2f676da2b2ddffe283fd1bc92d0de31714c5c2585e55a9918affa8feb2a8b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad5a0a7538a5182467852cc020c596232e56bd791d1ad556f1e4592217745611',1996,'PM','Saint Pierre and Miquelon','people-and-society',711,'Population: 6.809 (July 1996 est.)
Age structure:
0-14 vears: NA
15-64 vears: NA
65 years and over: NA
Population growth rate: 0.77 (1996 est.)
Birth rate: 12.82 births/1,000 population
(1996 est.)
Death rate: 5.7 deaths/1.000 population
(1996 est.)
Net migration rate: 0.59 migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 vears: NA male(s)/female
15-64 vears: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 9.95 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 76.34 years
male: 74.76 years
female: 78.25 years (1996 est.)
Total fertility rate: 1.65 children born/
woman (1996 est.)
Nationality:
noun: Frenchman(men).
Frenchwoman( women)
adjective: French
Ethnic divisions: Basques and Bretons
(French fishermen)
Religions: Roman Catholic 99%
Languages: French
Literacy: age 15 and over can read and
write (1982 est !
total population: 9I%
male: 99%
female: 99%
Population: | 18.344 July 1996 est.)
Age structure:
0-14 vears: 33% (male 19.742: female
19 106)
15-64 vears: 62% (male 36.576: female
3H.38])
65 vears and over: S% (male 2.702
3.837) (July 1996 est.)
Population growth rate: ().64° (1996 est.)
Birth rate: 19.36 births/!.000 population
1996 est.)
Death rate: 5.4 deaths/1.000 population
(]}996 est.)
- female
Net migration rate: -7.56 migrant(s)/1,000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(./temale
ander 15 vears: ''.O3 malet(sVtemale
15-64 vears: | male(sVtemale
6) years and over: 0.7 male(s)/female
all ages: 1 male(s)/temale (1996 est.)
Infant mortality rate: 16.8 deaths/).000
live births (1996 est.)
Life expectancy at birth:
fotal population: 72.94 years
male: 71.43 years
female: 74.49 years (1996 est.)
Total fertility rate: 2.04 children born/
woman (1996 est.)
Nationality:
noun. Samt Vincentiants) or Vincentian(s)
adjective: Samt Vincentian or Vincentian
Ethnic divisions: African descent. white.
East Indian, Carb Indian
Religions: Anglican, Methodist. Roman
Catholic, Seventh-Day Adventist
Languages: English, French patois
Literacy: age 15 and over has ever attended
school (1970 est.)
total population: 96%
male: 96%
female: 96%
Covernment
Name of country:
conventional lone form: none
conventional short form: Saint Vincent aud
the Grenadines
Data code: VC
Type of government: constitutional
monarchy
Capital: Kingstown
Administrative divisions: 6 parishes:
Charlotte, Grenadines, Saint Andrew, Saint
David, Saint George, Saint Patrick
Independence: 27 October 1979 (from UK)
National holiday: Independence Day, 27
October (1979)
Constitution: 27 October 1979
Legal system: based on English common
law
Suffrage: 18 years of age: universal
Executive branch:
chief of state: Queen ELIZABETH II (since
6 February 1952). a hereditary monarch,
represented by Governor General David
JACK (since 29 September 1989)
head of government: Prime Minister James
F. MITCHELL (since 30 July 1984): the
governor general appoints the leader of the
majority party to the position of prime
minister: Deputy Prime Minister Carlyle
DOUGAN (since 17 September 1995) was
appointed by the governor general on the
advice of the prime minister
cabinet: Cabinet was appointed by the
governor general on the advice of the prime
minister
Legislative branch: unicameral
House of Assembly: elections last held 21
February 1994 (next to be held NA July
1999): results—percent of vote by party NA;
seats—(21 total. 15 elected representatives
and 6 appointed senators) NDP 12, ULP 3
Judicial branch: Eastern Caribbean
Supreme Court (based on Saint Lucia)
Political parties and leaders: New
Democratic Party (NDP), James F.
MITCHELL: United People’s Movement
(UPM), Adrian SAUNDERS; National
Reform Party (NRP). Joel MIGUEL: Unity
Labor Party (ULP).Vincent BEACHE—
formed by the coalition of Saint Vincent
Labor Party (SVLP) and the Movement for
National Unity (MNU)
International organization participation:
ACP, C, Caricom, CDB, ECLAC, FAO, G-
77, IBRD, ICAO, ICFTU, ICRM, IDA,
IFAD. IFRCS,. ILO, IMF, IMO, Intelsat
(nonsignatory user). Interpol, LOC, ITU,
OAS, OECS, OPANAL, UN, UNCTAD,
NESCO, UNIDO, UPL, WCL. WFTU,
WHO. WTrO
Diplomatic representation in US:
chief of mission: Ambassador Kingsley C.A.
LAYNE
chancery: 1717 Massachusetts Avenue NW,
Suite 102. Washington, DC 20036
telephone: (1| (202) 462-7806, 7846
FAX: {1} (202) 462-7807
US diplomatic representation: the LS does
not have an embassy in Saint Vincent and
the Grenadines; the Ambassador to Saint
Vincent and the Grenadines resides in
Bridgetown (Barbados)
Flag: three vertical bands of blue (hoist
side), gold (double width), and green; the
gold band bears three green diamonds
arranged in a V pattern','a55f01485ae4c27b678d7b6663df22042f5e7d986075e87ea297352a14a5f64d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01887aa236a1340399ff1715a3feb278dd3b68422e02cf5c6b89bb37df989e16',1996,'SM','San Marino','people-and-society',718,'Population: 24.52) uly 1996 est)
Age structure:
0-14 years: 16% (male 1.978. temale 1.967)
15-64 vears: O8% (male 8.401; female
65 vears and ove) ¢ (male 1.648: temale
™
2.278) (July 1996 est.)
Population growth rate: 082° (1996 est.)
Birth rate: |}0.8i births/1.000 population
1996 est)
Death rate: 7.79 deaths/1.000 population
(1996 est.)
Net migration rate: 5.14 migrantis)/ 1.000
population (1996 est.)
Sex ratio:
al birth. | malets)/temale
wider 15 vears: \\.O1 malets)/temale
15-64 years: 1.02 malets/temale
65 years and over: 0.72 male(si/temale
all ages: 0.96 maletsWtemale (1996 est.)
Infant mortality rate: 5.5 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: &\\ 32 years
male: 77.34 vears
female: 85.3 years (1996 est.)
Total fertility rate: |.52 children born/
woman (1996 est.)
Nationality:
noun, Sammarinese (singular and plural)
adjective: Sammarinese
Ethnic divisions: Sammarinese. Htalian
Religions: Roman Catholic
Languages: Italian
Literacy: age 10 and over can read and
write (1976 est.)
total population: 96%
male: 97%
female: 9S%','431b2ddb14cf4293028f35a5bbe246024c4c3d7e6adeb9be4be7a726161a1778','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af9811c00a622b17a623ffd7b806613b3888c48b0826bf39fc07c9d43d54bf02',1996,'ST','Sao Tome and Principe','people-and-society',725,'Population: {44.12% (July 1996 est.)
\\uge structure:
+i) Miaic 29 JO8 iemale
‘§ male 39.749. temale
Piladikt
ip ‘4
Hy {
Population growth rate: 25s‘:
SY birth
Birth rate: 54 71.000 population
Death rate: 855 deaths/ 1.000 population
;
Net migration rate: © mugrantisy) 1] .000
Se rutio
Infant mortality rate: ¢ tf (MM)
Life cxpectanes at berth:
lotal fertility rate: 4 Neo
Nationalit:
thon divispons
Relivrons: | { }
l unguaves: |
J tteracs 1 amd
(,overnment
Naim of countrs:
Republica Democratica
416
> 973. temale
‘ i1Y9VH est.)
iC
local short form. Sao Tome e Principe
Vata code: TP
Type of government: republic
Capital: Sao Tome
Administrative divisions: 2 districts
(concelhos, singular—concelho): Principe.
Sao Tome
Independence: |2 July 1975 (from Portugal)
National holiday: Independence Day. |2
July (1975)
Constitution: approved March 1990:
etlective 10 September 1996
Legal system: based on Portuguese law
system and customary law: has not accepted
compulsory ICJ jurisdiction
Suffrage: |S years of age: universa!
Executive branch:
President Miguel
TRON OADA ‘since 4 April 1991) was
elected tor a five-year term by universal
sulfrave: election last held 3 March 199]
(neat to be held 30 June 1996): results
Miguel TROVOADA was elected without
opposition in Sao Tomes fiest multiparty
chiet of Siate
oresidential clecthon
Prime Minister
\\rnundo UAZ de ALMEIDA (since 29
December 1995) was appointed by the
fda OF Gonvenrnenl
president
cabmet. Council of Ministers was appormnted
hb, the president on the proposal of the prime
munisiel
Legislative branch: unicameral
Nunonal People s Assembly” (Assemble
Popular Nacronal) parliament dissolved by
President TROVOADA tn July 1994: early
slechions held 2 Ocvober 1994 Cheat to be
JNA) resulty - MLSTP 27%. PCD-GR
SS ADE 25 Sor: seats 455 total)
MILSTP 27. PCD-GR 14. ADI 14
Judicial branch: Supreme Court. judges are
ippoimted by the National Peoples Assembly
Political parties and leaders: Party tor
Democratic Comergence-Retlection Group
PCD-GR). Damel Lima Dos Santos DATO.
retary general. Movement tor the
Liberation of Sao Tome and Principe
MESTP). Carlos da GRACA, Christian
bront (FDC), Alphonse Dos
SANTOS. Democratic Opposition Coalition
CODO) leader NA. Independent
Democnitie Action (ADD). Patrice
PROVOADA, other small parties
International organization participation:
VCP. AIDB. CREEAC, ECA, FAO, G-77
IBRD. ICAO, ICRM. IDA. TFAD. TERCS
ILO] IME. IMO. Intelsat (nonsignatery user)
Interpol. FOC, TOM Cobserver). PTL. NAM
OAL UN. UNCTAD. UNESCO, UNIDO
UPL. WHO, WMO. WT0O, WTrO
(applicant)
Diplomatic representation in US: Sao
Tome and Principe does not have an
Democrats
embassy in the US. but does have a
Permanent Mission to the UN, headed by
First Secretary Domingos AUGUSTO
Ferreira. located at 122 East 42nd Street.
Suite 1604, New York. NY 10168. telephone
11} (212) 697-4211
US diplomatic representation: the US does
not have an embassy in Sao Tome and
Principe: the Ambassador to Gabon ts
accredited to Sao Tome and Principe on a
nonresident basis and makes periodic visits
to the islands
Flag: three horizontal bands of green (top).
yellow (double width), and green with two
black five-pomted stars placed side by side
in the center of the yellow band and a red
isosceles triangle based on the horst side:
uses the popular pan-Atncan colors of','6d16f50f75a77fd38b33dc81c2fe3ef11b535c3b545c99a8d47b9da76df79aff','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e79d5dccf1b4d61b57e8aedf837094d32e478f6981c0d0eb1ae22a01ec4caa92',1996,'SN','Senegal','people-and-society',732,'Population: 9.092.749 uly 1996 est)
\\ge structure:
0-14 vears: 48% (male 2.188.338: female
2.197 015)
15-64 vears: 49% (male 2.) 11.330; female
2.336.987)
465 vears and over: 4% (male 128.939.
female 130.140) duly 1996 est.)
Population growth rate: 3.37 (1996 est)
Birth rate: 45.46 births/!.000 population
(1996 est.)
Death rate: 11.76 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrantisy/ 1.000
population (1996 est.)
Sex ratio:
at birth: 1.03 matetsitemale
under 15 vears: | maleisWiemale
15-4 vears: 0.9 maleisiWtemale
45 vears and over: 0.99 maleisWtemale
all aves: O.YS maletsWiemale (1996 est.)
Infant mortality rate: 64 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: S649 years
mate: 53.75 years
female: 59.3 years (1996 est.)
Total fertility rate: 6.3) children born/
woman (1996 est.)
Nationality:
noun. Senegalese (singular and plural)
adjective: Senegalese
Ethnic divisions: Wolof 36. Fulam 179
Serer 17%. Toucouleur 9%, Diola 9%.
Mandingo 9%, European and Lebanese 1%.
other 2%
Religions: Muslim 927. indigenous beliefs
6%. Christian 2% (mostly Roman Catholic)
Languages: French (official), Wolof. Pulaar.
Diola, Mandingo
Literacy: age 15 and over can read and
write (1995 est.)
toial population: 33.1%
male: 43%
female: 23.2%','c8e4e7697bb07456d1a6b986051d40bf64cce4f62151e9bfce4157b729ceddb7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4c5580403661cced4c7c1a0eb1eae95250487decd3a9dcf9ff890e4b8bba7f0',1996,'SC','Seychelles','people-and-society',743,'Population: 77,575 (July 1996 est.)
Age structure:
0-14 years: 31% (male 12,005; female
11.835)
1S 64 vears: 63% (male 24,003, temale
24.946)
65 vears and over: 6% (male 1,669: temale
3.117) July 1996 est.)
Population growth rate: 0.76% (1996 est.)
Birth rate: 21.02 births/1.000 population
(1996 est.)
Death rate: 7.31 deaths/1.000 population
(1996 est.)
Net migration rate: -6.14 migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 vears: 0.96 maie(s)/female
65 vears and over: 0.54 male(s)/female
all ages: 0.94 matets)/female (1996 est.)
Infant mortality rate: 12.5 deaths/1!.000
live births ‘1996 est.)
Life expectancy at birth:
total population: 69.24 years
male: 64.23 years
female: 74.39 years (1996 est.)
Total fertility rate: 2.09 children born/
woman (1996 est.)
Nationality:
noun: Seychellois (singular and plural)
adjective: Seychelles
Ethnic divisions: Seychellois (mixture of
Asians, Africans, Europeans)
Religions: Roman Catholic 90%, Anglican
8%. other 2%
Languages: English (official), French
(official). Creole
Literacy: age 15 and over can read and
write (1971 est.)
total population: 58%
male: S6%
female: 60%','08e11eb7938beca6692be9438e640c9db5620ac9a55bd586b4a40d62b8b83d13','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98cd8fd1d6ea768e4ac7105b0d653d675670bb8c6c92bc5a4fcd2694b8caf0b0',1996,'LR','Liberia','people-and-society',749,'Population: 4,793.12! uly 1996 est.)
Age structure:
0-14 years: 45% (male 1.057.824: temale
1.092.291)
15-64 years: 52% (male 1.197.547: female
1.298.834)
65 vears and over: 3% (male 75.066. temale
71,559) (July 1996 est.)
Population growth rate: 4.14 (1996 est.)
Birth rate: 47.13 births/1.000 population
(1996 est.)
Death rate: 18.24 deaths/1.000 population
(1996 est.)
Net migration rate: |2.52 nugrant(s)/!.000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/temale
under 15 vears: 0.97 male(s)/female
15-64 vears: 0.92 male(s)/female
65 vears and over: 1.05 male(s)/temale
all ages: 0.95 male(sVtemale (1996 est.)
Infant mortality rate: | 35.6 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 47.47 years
male: 44.56 years
female: 50.47 years (1996 est.)
Total fertility rate: 6.36 children born/
woman (1996 est.)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic divisions: |3 native African tribes
99% (Temne 30%, Mende 30%, other 39%).
Creole, European, Lebanese. and Asian 1%
Religions: Muslim 60%. indigenous beliefs
30%, Christian 10%
Languages: English (official, regular use
limited to literate minority). Mende
(principal vernacular in the south). Temne
(principal vernacular in the north), Krio (the
language of the re-settled ex-slave population
of the Freetown area and is lingua franca)
Literacy: age 15 and over can read and
write in English, Mende. Temne,. or Arabic
(1995 est.)
total population: 3\\ 4%
male: 45.4%
female: 18.2%','88e69b12c5892522987373ad5cea86480e3be7966e81059da043a6aeb724accc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('089c2305b546dbcf5503ca880724859b13769c7bf565fd0bfdd7a6dd8f698877',1996,'SK','Slovakia','people-and-society',759,'Population: 5.374.262 Guly 1996 est)
Age structure:
0-14 years: 22% (male 605,379. female
$79,232)
15-64 vears: 67% (male 1.777.100. temale
1.812.555)
65 vears and over: {1% (male 234.377:
female 365,719) July 1996 est.)
Population growth rate: 0.34% (1996 est)
Birth rate: 12.62 births/1.000 population
(1996 est.)
Death rate: 9.35 deaths/!.000 population
(1996 est.)
Net migration rate: 0.12 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(sWtemale
under 15 vears: 1.04 maleisWtemale
15-64 vears: 0.98 maletsWtemale
65 vears and over: 0.64 maleisVtemale
all ages: 0.95 maleisWlemale (1996 est.)
Infant mortality rate: 10.7 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 73.01 years
male: 69.01 years
female: 77.21 years (1996 est.)
Total fertility rate: 1.65 children born/
woman (1996 est.)
Nationality:
noun: Slovaks)
adjec tive: Slovak
Ethnic divisions: Slovak 85.7. Hunganan
10.7%, Gypsy 1.5% (the 1992 census figures
underreport the Gypsy/Romany community.
which could reach 590.000 of more), Czech
1%, Rutheman 6.4, Ukramman 0.4%.
German 0.1%. Polish 0.1%. other 0.39
Religions: Roman Catholic 60.3%. atheist
979. Protestant 8.49. Orthodo. 4.1%. other
17.89%
Languages: Slovak (official), Hungarian
Literacy: NA','43d6f30ad649e4d15cc8066b31d3373483f74ad80d039657da604255b7da1e8b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe5a4960d5e15cda776f93af6af0e3d3f541fd388ea6b5e36eb4353bd5c1f834',1996,'GN','Guinea','people-and-society',767,'Population: 4/2902 uly 1996 ex
Age structure:
0-44 vears: 46°> (male 96.241. 1
g? 77?
15-64 vears SIG tmale 107.482. tem
104.293)
65 vears and mer Vc imale 6 » te
6.035) July 1996 est.)
Population growth rate: 6 (5°) «| 99
Birth rate: *”
(1996 est)
Death rate: 44) death | 000 »
(1996 est)
Net migration rate: 0 micron L.
population (1996 est)
Sea ratio:
at durth: 1 OS maletsWtemal«
] hurths/ | (AR) nopulal
under 15 vears 1 (}4 matlets
15-64 vears: 1 O8 maletsiWter
5 ears and over, | 02 males
all ages: 1043 maleisitemal: yr
Infant mortality rate: 25 8 des ")
live burths (1996 est
Life expectancy at birth:
total population, 71.14 years
male: GRO? vears
tomale: 73.74 vears (1996 ext
Total fertility rate: § 4) children bow
woman (1996 est
Nationality:
noun. Solomon Islanderis}
adjective. Solomon Island
Ethnic divisions: Velonc: )
Polynesian 4%. Micron
ORG. Chinese 0.3 thy
Religions: Anglican 4°-. R ‘
19%. Baptist 17. United (Met!
Presbyierian) || SeventhD \\
10%. other Protestant 8%. traditn
4%
languages: Melanesian pidgin im m
the CouUnITY 1 lingua rama by hist rhc
hy If ” ov popu Lativon
!
,
mote. 120 wmndieenous lancuages
Literacy: NA
Covernment
Name of country:
445
Solomon Islands (continued)
enventional short form: Solomon islands
former: Brotsh Solomon Islands
Data code: Bi
ype of government: parliamentary
Capital: Hortara
\\dministrative divisions: 7 provinces and |
Central. Guadalcanal, Hontara’
Makira. Malaita
\\ be two new provinces of
Laurus and Rennell/Bellona and
strative unit of Honiara may have
lfemotu. Western
trom UK)
National holiday: Independence Day. 7 July
iIndepende nee: luly 197%
(onstitution: 7 July 197s
Leval system: common law
Sullrage:
UlIVersdl
Faccutive branch:
() ELIZABETH II (since
Fel ir s hereditary, monarch
: General Moses
Pt] \\ k, \\A \\ ‘ | 1YVy4 “hk Wid
» by the queen
; ‘ P
a Minister
‘S MIAMALONI hk November
1Y9O4) \\ cle , and trom Parliament.
Danny PHILIP (since
NA Octot i> pponrite lL hy the
COVETI ! he wd the prime
minister | | en it , of
Parhiamet
el; Cat ppomted by the
ven the a the prime
mil mbers of
Par i
Legislative branch:
, Pas ! lust held 26
NAPSI §. SILP 4
judicial branch: High Cour
Political parties and leaders: Navona!
}. thon Group (GNUR)
VIAMALONI People \\lhance
Py N nal Action Party (NAPSI
Islands Labor Party
der NA. United Party (UP). leader
iz r Progress (NFP)
SORT. Labor Party (LP). Joses
NUKU: Christian Fellowship. leadet
International organization participation:
CP. ASDB. C. ESCAP. FAO. G-77, IBRD
AOL ICRM. IDA. IFAD. IFC. TEFRCS
INMIF. IMO. Intelsat (nonsignatory user)
ITU. Sy arteca. SPC. SPF. US
436
UNCTAD, UNESCO, UPU, WFTU. WHO.
WMO
Diplomatic representation in US: Solomon
Islands do pr xt have an embassy in the US:
the ambassador to the US traditionally
resides in Honiara (Solomon Islands)
US diplomatic representation: the US does
not have an embassy in Solomon Islands
(embassy closed July 1993): the ambassador
to Papua New Guinea ts accredited to the','f09e39ca7c74f95d63817c9efc46fd4e9a77a387c294054eb6fe78d35a705776','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c37b54447bf99d00e66d210298b1a7dfd98e01da5a890372b78b2a463f682e8',1996,'SB','Solomon Islands','people-and-society',768,'Flag: divided diagonally by a thin yellow
stripe from the lower hoist-side corner; the
upper triangle (hoist side) ts blue with five
white five-pemnted stars arranged in an X
pattern: the lower triangle ts green','2b4db5fdd822b7ebcecc23908a2caf710bf0f19fd8f324c783a6158600b3ad34','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('079be0d5213188d6fea01d956b100ba512b8ce8c59be7523bf08b6a840ffb956',1996,'LK','Sri Lanka','people-and-society',774,'Population: 18.553.074 uly 1996 est)
note. since the outbreak of hostilities
between the covernment and armed Tamil
separatists on the mid- 1980s. several hundred
thousand Tamil civilians have tled the
sland: as of late 1992. nearly 115 000 were
frised m ret
ivee Camps i soul: nda
mother 9S.000 Ived outside the Indian
camps, and more than 27.000 Tamils have
oucht political asvilum on the WW esl
Age structure:
,
4 wears: 28% (male 2.673.943. temale
» §Sy Soy
id years. 66 male 6.023.759. temale
fy 171 OBS)
ears and over 6% > tmale 554.940
male SGU_8090) (July 1996 est)
Population growth rate: | 14°" (1996 est)
Birth rate: 17.89 births 1.000 population
WOH ext
Death rate: 5.8 death 1.000 population
iYWYly est
Net migration rate: -) 7S ouerantsyWt.000
population (1996 est
Ses ratio:
hyoth, | OS maletsWtemale
dev 1) years: 1.04 matetsvtemale
h4 yoars, OYS maletsVremale
( cars and over O97 maletsWiemale
es. | maletsWiemale (1996 est)
Infant mortality rate: 20.8 deaths/ 1.000
hve berths (1996 est)
Life expectancy at birth:
taal pn yualation ‘S vears
heile (HY 7/7 vedas
fomale. 75.06 vears (1996 est)
Total fertility rate: 2.05 children born
woman (1996 est)
Nationality:
we So Lankanis)
ahective. Sa Lankan
bihnic divisions: Sinhalese 74°". Tamil
ix Moor Burgher. Malay. and Vedda
Religions: Buddhist 69% . Hindu 18%
(hrostian & Muslim §&
Languages: Sinhala (official and national
language) 74°7. Tamil (national language)
Is‘
nme: English ts commonly used in
government and ts spoken by about 10% of
the population
Literacy: age 15 and over can read and
write (1995 est)
~
J as”
total population
male: 9A.AG
female: 87.2%','96fbbda5ea143bee697f301e2557fc722e4cd12d818ed43c6d9ed2bca7908302','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('125dfe4f91a8dec0bc8c48f6ba8080b23a6f76003abcbf79462b68f806eaca9e',1996,'SR','Suriname','people-and-society',779,'Population: 436.4|>
Age structure:
0-14 vears: 349 (m
71.500
15-64 vears: 67''
8) 40)7)
years and over
11.335) cJuly 1996 est
Population growth rate:
Birth rate: 24.15 bint
Yt, est
Death rate: 5 84 deat!
WU, !
Net migration rate:
, yor
Sex ratio:
Infant mortality rats
1? pee
Life expectancy at birth
‘ .
lotal fertility rate:
eat
Nationality:
ii s Til iT)
( e. Surinan
Ethnic divisions: Hindu
northern India
part of the [9th century) 4
European and Afncan ancestry) 31‘
Javanese 15.3%
is ‘Bush Creole’’ whose ancestors were
brought to the country in the 17th and 18th
centuries as slaves) 10.3%. Amerindian
Bush Black’ (also known
Li
Religions: Hindu
Roman Cat!
(predominant
bh} ; oe
. » ewe
Languages: Dut
H
Literacy:
Population. 2
Age structure:
O-i4 vears NA
oe 4
i ft) eal VA
OS years nad aa | WA
Population growth rate:
Birth rate: “A by Thr
Death rate: A d
Net migration rate: \\A
| |
Sex ratio:
\\
Infant mortality rats
}
Life expectancy at birth
lotal fertility rate
bihnic divisions: |
‘
Languages: |
C,overnment
Name of country
Data code: S\\
Iype of government:
;dimunistere yy the Ministrn
Oslo thre ucn al 4 ‘c ! I
residing in | onvvearnp
453
(no trees and u
Svalbard (continued) paved: NA km
Swaziland
unpaved: NA km
» | irv 1920) sovereigntv was Ports: Barentsburg Longyearbyen Ny
¥ NOTW aN . \\lesund. Pyramiden
Capital: | yearb Merchant marine: none
Independence: none Uerniory of N
\\irports:
National holiday: NA
Legal svstem: \\A
5 , ‘ ie, ’
f Padiited THhnadys / Sf fq? +. hi i
} é 7
Executive branch: h paved runways uncer 9/4 m: % (1995
( t State: K HARALD \\ ; a
r | "J SCUTH va . °
AFRICA Mining N
a
/ =
\\ rn @ MBABANE =
Z
’ { . . * p—<
'' Communications tem, :
t \\ .sS partba ° Va m
''
p lelephones: NA
.“ «aya
Iclephone system: ;
'' onl.
\\ domestic: local telephone service rs
mernational: satelite earth station lot . .
in nal al orgamzation participation: L tune (fo mn ) ° SOUTH
ternational orgarmy fm particip tron NA Iyvpe (lor communication with AFRICA
Norwegian mainland only) .
“s ° ° . , a
bla Radio broadcast stations: AM |. FM |
repeaters 2). shortwave 0
fe there are tive meteorologieal/radio
Population: 998.730 (July 1996 est.)
Age structure:
0-14 years: 46% (male 227.634, female
229,129)
15-64 vears: 52% (male 247.156. temale
271.096)
65 vears and over: 2% (male 9.864. temale
13.851) uly 1996 est.)
Population growth rate: 3.24% (1996 est.)
Birth rate: 42.91 births/1.000 population
(1996 est.)
Death rate: 10.56 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.038 maietsVtemale
under 15 years: O.YY malet(sVtemak
15-64 vears: OYT maletsWtemale
45 years and over, 0.71 maletsVtemalk
aves. 0.94 maie si/temale (1996 ¢
infant mortality rate: SS 4 deaths! .000
mirths (1996 est
Life expectancy at birth:
lotal fertility rate: 6.05 children be
il | Ai
Nationality
‘/ SVU UZ!
Ethnic divisions: Afmcan 97°". Europea
Religions: Christian 60 indigenous beliet
ii)
Languages: English (ofticial, government
usin conducted in Englist Swatt
Literacy: age |S and over can read and
writ mS Ost.)
fy wahiol fy ‘
LLL .
female Sh','b657bb1abeb91e3dcf5eb8c44e935e7422fd69b3aac1b4209260a7c66bebfd1a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64a01de8304f0353d24309a6f05878271fd5067de2354d14e68f4ea8c77e7896',1996,'FI','Finland','people-and-society',782,'Population: &.900.954 (July 1996 est.)
Age structure:
O-34 years: ''9% (male 860.940. temak
815.967)
15-64 years: 64% (male 2.884.687. temale
> 794 594)
65 years and over: 17° (male 654,449
female 890.328) (July 1996 est.)
Population growth rate: 0.56% (1996 est)
Birth rate: 11.55 births/1.000 population
(1996 est.)
Death rate: 11.43 deaths/1.000 population
(1996 est.)
Net migration rate: 5.48 migrant(s)/ 1.000
population (1996 est.)
Sex ratio:
at birth: 145 maletsVtemale
under 15 years: 1.06 male(sVtemale
15-64 vears: 1.3 male(s)/temale
65 years and over: 0.74 maleis j/temale
all ages: 0.98 male(s\\/female (1996 est.)
Infant mortality rate: 4.5 deaths/!,000 live
births (1996 est.)
Life expectancy at birth:
total population: 78.06 years
male: 75.62 years
female: 80.63 years (1996 est.)
Total fertility rate: 1.72 children born/
woman (1996 est.)
Nationality:
noun, Swedet(s)
adjective. Swedish
Ethnic divisions: white. Lapp (Sami).
foreign-born of first-generation immigrants
2% (Finns, Yugoslavs, Dares. Norwegians
Greeks, Turks)
Religions: Evangelical Luineran 94%
Roman Catholic 1.5, Pentecostal 1. other
4.5% (1987)
Languages: Swedish
note: small Lapp- and Finnish-speaking
minorities
Literacy: age 15 and over can read and
write (1979 est.)
total population: 99%
male: NAG
female: NA“
Covernment
Name of couatry:
conventional lone form: Kingdom of Sweden
conventional short form: Sweden
local long form: Konungariket Sverige
local short form: Sverige
Data code: SW
Type of government: constitutional
monarchy
Capital: Stockholm
Administrative divisions: 24 provinces (lan
singular and plural). Alysborgs Lan
Blekinge Lan Gavleborgs Lan Canteborgs
och Bohus Lan, Gotlands Lan. Hallands Lan
lamtlands Lan. Jonkopings Lan. Kalmar Lan
Kopparbergs Lan. Kristianstads Lan
Kronobergs Lan. Malmohus Lan
Norrbottiens Lan, Orebro Lan, Ostergotiands
Lan. Skaraborgs Lan. Sodermanlands Lan
Stockholms Lan. Uppsala Lan. Varmilands
Lan, Vasterbottens Lan. Vasternorrlands Lan
Vastmanlands Lan
independence: 6 June 1523. Gustay VASA
was clected king. 6 June 1809 a
constitutional monarchy was established
National holiday: Day of the Swedish Flag
6 June
Constitution: | January 1975
Legal system: civil law system influenced
by customary law. accepts compulsory ICJ
jurisdiction, with reservations
Suffrage: 1% years of age: universal
Executive branch:
chief of state: King CARL XVI GUSTAI
(since 19 September 1973) ts a constitutional
monarch: Hew Apparent Princess
VICTORIA Ingrid Alice Desiree, daughter of
the King (born 14 July 1977)
head of government Prime Minister Goran
PERSSON (since 21 March 1996) wa
elected by the Riksdag
cabinet: Cabinet was appointed by the prime
wUniste!
Legislative branch: unicameral
Parliament (Riksdag) elections last held 1s
September 199- (next to be held NA
September 199K) Social Democrats
45.4%. Moderate Party (Conservatis
22.3%, Center Party Liberals 7
Lett Party 6.2 Gsreens 5.8 C hnistian
Democrats 4.1'' New Democracy Party
(349 total) Social Democrat:
162. Moderate Party (Conservatives) 80
Liberals 26. Lett Party
results
1.2%: seats
Center Party 27
Greens 18. Christian Democrats 14. not
the New Democracy Party did not rece:
cal because parties Fequire a muinimurn
4.0% of votes for a seat in parla
Judicial branch: Supreme Coun (i
Domstolen), judges are appointed by
revermment (prime minister and cal
olitical parties anc leaders: So
Democratic Party. Goran PERSSON
Moderate Party (conservat (
| iberal Pes pric s Part \\l i LEISSNES
Center Party. Olot JOHANSSON. ¢
Democratic Party. Alt SVENSSON. N
Democracy Party. Visianne FRANZEN
Party (VP. Communmst). Gudrus
SCHYMAN. Commu t Worke ;”
Rolf HAGEL. Green Party. n
bul party spokespersor ay SCHL ALG
International organization participation
VIDB. AG (observer). ASDB) A
Group, BIS. CESS. CCC. Ck. CERN
EBRD. FCk. LIB ESA FEL FAO G
SG. 9) G- 1 IADB. LARA IBRD
IC ICKTL. ICRM TDA TEA
IEFRCS, [LOW IMB. IMO
Interpol, LOC. TOM. ISOUTTL OM
NACC. NAM Couest) NOU NG
OECD. OSCE. PCA, PEFPD UN UNAVEM
Hl. UNCRO. UNCTAD. UNESCO
UNHCR, UNIDO.W UNTRKOM UNTT AL
UNMOGIP. UNOMIG. UNPREDEI
UNPROFOR, UNTSO) LPL WEI
(observer), WETU, WHO, WIPO) WM
WTrO. 7
Diplomatic representation in US:
Ambassador Carl H
Sihver LILJEGKEN
chancery: (SO) M Street NW. WasSu
DC” 20005
chiel of mission
tele phone lt] (0)>) lf “fy hh)
FAX: (1] (202) 467-2699
457
Sweden (continued)
general) Los Angeles and New
\\ i
tS diplomatic representation:
vinta hor Thomas |
SI} i}
\\ S AY
c
uM
tlay ‘
''
) ‘
bcomony
t coeaertiihke civ ctT sic \\ Kw
(.>9
(.0P real growth rate
(.DP per capita
(,00 composition by sector
i
458
inflation rate (comsunaer prices): 2.6%
(1995)
Labor force: 4.552 million (84% umonized
1992)
community, social and
PY occenpano
- ~_ -~. 3% 3 ’ j
personal services ©, Thinhine am
manulacturnin M 2) ’ ‘;. commerce. hotels. and
resiaurants 14.1°7, banking. insurance 9.0%,
,
commumecations 7.2%. construction 7.0%
,
wriculture, fishing. and forestry 3.2% (19%i)
i nemployment rate: 7 8° (December
i995) plus about 6° in traning programs
Budget:
$109.4 billion
fo varies
$146.1 billhon, mcluc ing
cise / ‘fey
capital expenditures of SNA cb 95/96)
Industries: ion and sicel, precision
eguipment (bearmnegs. radio and telephone
parts, armaments). wood pulp and paper
‘
‘ ;
} miuicts
processed toods. motor vehicles
industrial production growth rate: |) 7%
wud
Electricity:
43 Set) On VA
‘ / ; Mili KWh
i? ‘c/ 1kY! KLWh i loud)
Agriculture: Th uvar beets, potatoes
|
*
het drugs bay L pont for
1 Sa |
} a '' by }’
baports \\f } wal
LK
'' 5
Imports wd
i ‘4 A
! }
a
bvternal deht: * ny
Foonomen and
( urrency " Sk my
tachange rates , h
/ Me
M4 . 4 ”) _
‘ 7“?
Fiscal vear | ul '' ‘| Dp mitt
5 ! | im | rv | Jay]
1) Jur » 1YYS','fc27a0d201351cb4e2b188ee3733a94683cc4c84acb4856d73aafc558b976fab','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('903aac2885abf9488c97ed7c217bc9d84edf1c09c2429d1206a115fac44308e4',1996,'CH','Switzerland','people-and-society',784,'Population: 707.060 Gluly |9ye
Age structure:
fir Th WuUr 1
Population growth rate: 0 59% (1996 ost
Birth rate S| (XK) porn
pe
Death rate fy4 i>
n)
Net migration rat
Se. rato
Infant mortality rate
Bir expectancs at birth
fotal fertility rate
Nautronalit
} thon cin rhoens
Kelivions: |
languages: |
Literacy: 4
Switzerland (continued)
t,osvernument
mie of Coun
Swiss Contederation
7 Sw nzeriand
Schweizerische
Gsermhal Contederation
} { ravi SVi//eTa
ScnMe CGserman). Suisse
|
‘
1) I treet
ivpe of yovernment: tederal republic
\\dminnstrative divisions: 26 cantons
in French
i a
r ty an)
I Basel-Lardschatt
} Creneve Cslaru
kK j Luzem
‘ \\ 5 whurrn
\\ i \\ $
ind » dene \\ | ;
Nuthonal holiday
( ’
whtotbon ]
im
tira
} ‘ Tite brunch
, A
» ,
t \\
}
’
i egutative branch |
‘ i } lun
\\ bes lt
}
i ‘ ty, il \\! mic i
, id Etats, Halian
4o0
Consigho degh Stati}. electiwns last held
throughout 1995 (neat to be held NA 1999),
percent of vote by pa.ty NA;
seats—(46 total) PRD 17, PDC 17, UDC 4
PSS 3. LPS 3, LdU 1. Ticino League |!
Nationalrat
results
Nanonal Council: (German
brench—Conseil National, Italian—Consigho
Nazionale): elections last held 20 October
1995 (next to be held NA October 1999),
results percent of vote by party NA:
seats—( 200 total) PRD 45. PSS 54, PDC 34.
UDC 30. GPS &, LPS 7. FPS 6, LdU 6, SD
3. EVP 3. PdA 2. Ticino League 2
Judicial branch: Fedecal Supreme Court,
judges elected for six-year terms by the
Federal Assembly
Political parties and leaders: Radical Free
Democratic Party (PRD), Franz
STEINEGGER president, Social Democratx
Party (PSS), Peter BODENMANN.
president; Christian Democratic People’s
Party (PDC), Anton COTTIER, president
Swiss People’s Party (UDC), Hans
UHLMANN., president: Green Party (GPS)
Verena DIENER. president: Freedom Party
(FPS;. Poland BORER, Liberal Party (LPS)
Cinstoph EYMANN., president: Alliance of
Independents’ Party (LdU), Monica WEBER
president, Ticino League, Giuliano
BIGNASCA, president, and other minor
parties includisg Swiss Democratic Party
SD). Workers’ Party (PdA). and the
Evangelical People’s Panty (EVP). note - x
clecthon
International organization participation:
VIDB. AG (observer). ASDB. Austral
Group. BIS. CCC. Ck. CERN. EBRD, CT
LETA. ESA. FAO. G. &. GTO. LADB
LARA. IBRD. ICAO. ICC. ICETL. ICRM
IDA TEA. TRAD. TRC. TERCS. ILO. IMI
IMO). | | Interpol. (OC) 1OM
ISO) TTL. MCR, NAM at). NEA
WSO, OPAS } fr) OFCTD OSChE POA
iN LNAMIR, UNCTAD
NESCO. UNHCR. UNIDO. UNTTAR
MOT. UNOMIG. UNPREDEP
NPROPFOR UNTSOO UNL UCPL. WO]
VHO. VIPO WMO Wot Wired) Ze
Diplomatic representation in US
Amba ul (
IAGMETTI
WM) ¢ \\ NW
Wa DC 200
4)? 1S. 700)
PAY 8 /- 2564
P ; ones Atlanta Ci? i
Mouston. | Angeles. New York. Pay
Pave \\mencan Samoa), and San Francisco
US diplomatic representation:
ne? of mission. Ambassador (vacant)
embassy. Jubilaeumstrasse 93, 3005 Bern
address: use embassy street address
felepi me: (41) (31) 357 70 11
FAX: [41] (31) 387 73.44
ila fay “
onsulate(s) eeneral: Zurich
Flag: red square with a bold, equilateral
white cross in the center that does not extend
to the edges of the flag
Population: 15.608.648 (July 1996 est.)
note: in addition, there are 31,300 people
living in the Israeli-occupied Golan
Heights-—16,500 Arabs (15,000 Druze and
1,500 Alawites) and 14,800 Israeli settlers
(August 1995 est.)
Age structure:
0-14 vears: 47% (male 3,738,671: female
3,557,474)
15-64 vears: 50% (male 4.013.355: female
3.843.466)
65 years and over: 3% (male 227,249;
female 228.433) (July 1996 est.)
Population growth rate: 3.37 (1996 est.)
Birth rate: 39.56 births/!,000 population
(1996 est.)
Death rate: 5.86 deaths/1,000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: | male(s)/female
all ages: 1.05 male(s)/female (1996 est.)
Infani mortality rate: 40 deaths/1.000 live
births (1996 est.)
Life expectancy at birth:
total population: 67.13 years
male: 65.94 years
female: 68.38 years (1996 est.)
462
Total fertility rate: 5.91 children born/
woman (1996 est.)
Nationality:
noun: Syrian(s)
adjective: Syrian
Ethnic divisions: Arab 90.3%, Kurds,
Armenians, and other 9.7%
Religions: Sunni Muslim 74%, Alawite,
Druze, and cther Muslim sects 16%,
Christian (various sects) 10%, Jewish (tiny
communities 1) Damascus, Al Qamishli, and
Aleppo)
Languages: Arabic (official), Kurdish,
Armenian, Aramaic, Circassian, French
widely understood
Literacy: age i5 and over can read and
write (1995 est.)
total population: 70.8%
male: 85.7%
female: 55.8%','224877517ee8750a34805b1fad692e3b6f47c837caae155ec43f86ad2cb76711','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0de02ee0ee86deef95512adb92415d30934995f304739124e3f863a50eab7738',1996,'TJ','Tajikistan','people-and-society',789,'Population: 5,916,373 (July 1996 est.)
Age structure:
0-14 years: 43% (male 1,282.846; female
1,258,302)
15-64 years: 53% (male 1,546,264; female
1,566,365)
65 vears and over: 4% (male 110,705;
female 151,891) (July 1996 est.)
Population growth rate: 1.54% (1996 est.)
Birth rate: 33.78 births/1,000 population
(1996 est.)
Death rate: 8.43 deaths/1.000 population
(1996 est.)
Net migration rate: -9.93 migrant(s)/1,000
population (1996 esi.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 vears and over: 0.73 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: | 13.1 deaths/1,000
live births (1996 est.)
Life expectancy at birth:
total population: 64.45 years
male: 60.84 years
female: 68.24 years (1996 est.)
Total fertility rate: 4.38 children born/
woman (1996 est.)
Nationality:
noun: Tajik(s)
adjective: Tajik
Ethnic divisions: Tajik 64.9%, Uzbek 25%,
Russian 3.5% (declining because of
emigration), other 6.6%
Religions: Sunni Muslim 80%, Shi''a
Muslim 5%
Languages: Tajik (official), Russian widely
used in government and business
Literacy: age 15 and over can read and
write (1989 est.)
total population: 98%
male: 99%
female: 97%','566e8e9c4f1a4768f51ad5b5b45e7d8a43cbb8a0134592c8629f9be942f64eef','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bce452cdc9800d3c11f8dc8b32697ea9e3bdfd4823e5bfd5199762342f84d87',1996,'TT','Trinidad and Tobago','people-and-society',804,'Population: |.272.385 (July 1996 est.)
Age structure:
0-14 years: 30% (male 193,134; female
186,649)
15-64 years: 64% (male 413,426: female
404,175)
65 years and over: 6% (male 33,791; female
41,210) (July 1996 est.)
Population growth rate: 0.08% (1996 est.)
Birth rate: 16.25 births/1,000 population
(1996 est.)
Death rate: 6.9 deaths/!,000 population
(1996 est.)
Net migration rate: -8.58 migrant(s)/1,000
population (1996 est.)
Sex +*io:
at birth: 1.03 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.82 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 18.2 deaths/1,000
live births (1996 est.)
Life expectancy at birth:
total population: 70.3 years
male: 67.91 years
female: 72.77 years (1996 est.)
Total fertility rate: 1.99 children born/
woman (1996 est.)
Nationality:
noun: Trinidadian(s), Tobagonian(s)
adjective: Trinidadian, Tobagonian
Ethnic divisions: black 43%, East indian (a
local term—primarily immigrants from
northern India) 40%, mixed 14%, white 1%,
Chinese 1%, other 1%
Religions: Roman Catholic 32.2%, Hindu
24.3%, Anglican 14.4%, other Protestant
14%, Muslim 6%, none or unknown 9.1%
Languages: English (official), Hindi,
French, Spanish
Literacy: age 15 and over can read and
write (1995 est.)
total population: 97.9%
male: 98.8%
female: 97%','5e57b0e5ebb51a6c9073da0ca999a59c2dd390f01b923398bb812468e0aa3bb0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fb1ccda7264324e6bcae6917b55826f19255c7aba8c40b89b874c09d8a58171',1996,'BS','Bahamas','people-and-society',810,'Population: 14.302 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 vears and over: NA
Population growth rate: 2.14% (1996 est.)
Birth rate: 12.85 births/1,000 population
(1996 est.)
Death rate: 5.15 deaths/1,000 population
(1996 est.)
Net migration rate: |3.74 migrant(sj/i,000
population (1996 est.)
Sex ratio:
al birth: NA male(s female
under 15 years: NA male(sVtemale
15-64 vears: NA male(s)/female
65 vears and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 12.57 deaths/1,000
live births (1996 est.)
Life expectancy at birth:
total population: 75.4 years
male: 73.46 years
female: 77.07 years (1996 est.)
Total fertility rate: |.86 children born/
woman (1996 est.)
Nationality:
noun: none
adjective: none
Ethnic divisions: African
Religions: Baptist 41.2%, Methodist 18.9%,
Anglican 18.3%, Seventh-Day Adventist
1.7%, other 19.9% (1980)
Languages: English (official)
Literacy: age 15 and over has ever attended
school (1970 est.)
total population: 98%
male: 99%
female: 98%','c3fc2006b478da2a34744b2276d53f62f2f5da757980549ba494f6534cdc79ef','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65efb8391335b832db684dcff4c5f23647afb84cc070dc37119335c74a12efcd',1996,'TC','Turks and Caicos Islands','people-and-society',815,'Popuiation: 10.146 (July 1996 est.)
Age structure:
0-14 years: 36% (male 1,865; female 1,798)
15-64 years: 59% (male 2.831; female
3,162)
65 years and over: 5% (male 227; female
263) uly 1996 est.)
Population growth rate: |.51% (1996 est.)
Birth rate: 23.95 births/!,000 population
(1996 est.)
Death rate: 8.87 deaths/!,000 population
(1996 est.)
Net migration rate: ( migrant(s)/!,000
population (1996 est.)
Sex ratio:
at birth: \\.05 male(s)/female
under 15 years: 1.04 male(sWfemale
15-64 vears: 0.9 maleisWfemale
65 vears and over: 0.86 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 27.6 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 63.34 years
male: 62.15 years
female: 64.59 years (1996 ext.)
Total fertility rate: 3.11 children born/
woman (1996 est.)
Nationality:
noun: Tuvaluan(s)
adjective: Tuvaluan
Ethnic divisions: Polynesian 96%
Religions: Church of Tuvalu
(Congregationalist) 97%, Seventh-Day
Adventist 1.4%, Baha’i 1%, other 0.6%
Languages: Tuvaluan, English
Literacy: NA','3d9ac84ac332e927610e608420a9f88db7b0203ecd9a7f9092025a1af5a2be08','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f777d0bdaa4b992d7393d547628c4b1a76c6be597d65e7c2dcdaba55ff4f637f',1996,'UG','Uganda','people-and-society',820,'Population: 20,158,176 (July 1996 est.)
Age structure:
0-14 vears: 50% (male 5.006.615; female
4.972.831)
15-64 vears: 48% (male 4,842,908: female
4.874.471)
65 years and over: 2% (male 231,156;
temale 230,195) (July 1996 est.)
Population growth rate: 2.24% (1996 est.)
Birth rate: 45.92 births/1.000 population
(1996 est.)
Death rate: 20.72 deaths/!,000 population
(1996 est.)
Net migration rate: -2.8 migrant(s)/1.000
population (1996 est.)
note: Uganda is host to refugees from a
number of neighboring couniries, including
Zaire. Sudan, and Rwanda: probably in
excess of 100,000 southern Sudanese fled to
Uganda during the past year: many of the
8.000 Rwandans who took refuge in Uganda
have returned home
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 vears: 0.99 male(s)/female
65 vears and over: | male(s)/female
all ages: | male(s)/female (1996 est.)
Infant mortality rate: 99.4 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 40.29 years
male: 39.98 years
female: 40.6 years (1996 est.)
Total fertility rate: 6.61 children born/
woman (1996 est.)
Nationality:
noun; Ugandan(s)
adjective: Ugandan
Ethnic divisions: Baganda 17%.
Karamojong 12%, Basogo 8%, Iteso 8%,
Langi 6%. Rwanda 6%, Bagisu 5%, Acholi
4%, Lugbara 4%, Bunyoro 3%, Batobo 3%,
European, Asian, Arab 1%, other 23%
Religions: Roman Catholic 33%, Protestant
33%, Muslim 16%, indigenous beliefs 18%
Languages: English (official), Luganda,
Swahili, Bantu languages, Nilotic languages
Literacy: age 15 and over can read and
write (1995 est.)
total population: 61.8%
male: 73.7%
|
female: 50.2%','eae3b2294b03fe03f667bb9de6cf088a272ae61ac866ae16884baaf5a6953bc8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3810969f840fc9736d323557173d4b46c66da9476644e2fe232a241737d6b833',1996,'UA','Ukraine','people-and-society',827,'Population: 50.864.009 (July 1996 est.)
Age structure:
0-14 years: 20% (male 5,139,034; female
4.936.901)
15-64 vears: 66% (male 16,135,671; female
17,433,600)
65 vears and over: 14% (male 2.318.629;
female 4,900,174) (July 1996 est.)
Population growth rate: -0.4% (1996 est.)
Birth rate: 11.17 births/1,000 population
(1996 est.)
Death rate: 15.16 deaths/1,000 population
(1996 est.)
Net migration rate: 0.03 migrant(s)/1,000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 vears and over: 0.47 male(s)/female
all ages: 0.86 male(s)/female (1996 est.)
infant mortality rate: 22.5 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 66.8 years
male: 61.54 years
female: 72.32 years (1996 est.)
Total fertility rate: 1.6 children born/
woman (1996 est.)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic divisions: Ukrainian 73%, Russian
22%, Jewish 1%, other 4%
Religions: Ukrainian Orthodox—Moscow
Patriarchate, Ukrainian Orthodox—Kiev
Patriarchate, Ukrainian Autocephalous
Orthodox, Ukrainian Catholic (Uniate),
Protestant, Jewish
Languages: Ukrainian, Russian, Romanian,
Polish, Hungarian
Literacy: age 15 and over can read and
write (1989 est.)
total population: 98%
male: 100%
female: 97%','c83e2c708a796d64406f194381e8842c620d42c7d4e7147e11e50b9b95b226cf','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61665c935a9efe59b9bfdb5736415ff71f58bd5a61501735c19402adc21bc9ee',1996,'OM','Oman','people-and-society',833,'Population: 3.057.337 Ululy 1996 est.)
Age structure:
0-14 vears: 35% (male 542.848. female
519,952)
15-64 vears: 64% (male 1.277.829: female
683.282)
65 vears and over: 1% (male 22,246; female
11.180) Quly 1996 est.)
Population growth rate: 4.33% (1996 est.)
Birth rate: 26.43 births/1,000 population
(1996 est.)
Death rate: 3.03 deaths/1.000 population
(1996 est.)
Net migration rate: 19.91 migrant(s)/1,000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 vears: 1.87 male(s)/female
65 years and over: 1.99 male(s)/female
all ages: 1.52 male(s)/female (1996 est.)
Infant mortality rate: 20.4 deains/1,000
live births (1996 est.)
Life expectancy at birth:
total population: 72.74 years
male: 70.64 years
female: 74.94 years (1996 est.)
Total fertility rate: 4.46 children born/
woman (1996 est.)
Nationality:
noun: Emiri(s)
adjective: Emin
495','1d201836e4049cd3c22c7c3c4c4ddda189fc7ac6698088b53b57e561bf6dd525','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c95c493e1ce59a479a35dfbc358c185f5197df82b4a5ee94e85caa4b660c6d7f',1996,'AE','United Arab Emirates','people-and-society',834,'(continued)
Ethnic divisions: Emin 19%, other Arab
ind traman 23%, South Asian 50%, other
‘Aputriates (includes Westerners and East
4sans} 8% (1982)
less than 20% are UAE citizens (1982)
Religions: Muslim 96% (Shi''a 16%),
Chnstan, Hindu, aad other 4%
Languages: Arabic (official), Persian,
English. Hinds, Urdu
Literacy: age 15 and over can read and
write but definition of literacy not available
(1995S est.)
total population: 79.2%
male: TRYO%
=
female: JY 8%
Covernment
Name of country:
conventional ‘one form: United Arab
Emirates
conventional short form: none
local long form: A\\ Imarata al Arabiyah al
Muttahidah
local short form: none
former: Trucial States
abbreviation: UAE
Data code: TC
Type of government: federation with
specified powers delegated to the UAE
central government and other powers
reserved to member emirates
Capital: Abu Dhabi
Administrative divisions: 7 emirates
(imarat, siigular—imarah); Abu Zaby (Abu
Dhabi). “Ajman, Al Fujayrah, Ash Sharigah
(Sharjah), Dubayy (Dubai), Ra''s al
Khaymah, Umm al Qaywayn
Independence: 2 December 197! (from UK)
National holiday: National Day, 2
December (1971)
Constitution: 2 December 197!
(provisional)
Legal system: federal court system
introduced in 1971; all emirates except
Dubayy (Dubai) and Ra''s al Khaymih have
joined the federal system; all emirates have
secular and Islamic law tor civil, criminal,
and high courts
Suffrage: none
Fxecutive branch:
chief of state: President ZAY!D bin Sultan
Al Nuhayyan (since 2 December 1971), ruler
of Abu Zaby (Abu Dhabi) (since NA 1966)
and Vice President MAKTUM bin Rashid
al-Maktum (since 8 October 1990), ruler of
Dubayy (Dubai) were elected by the
Supreme Council of Rulers
496
head of government: Prime Minister
MAKTUM bin Rashid al-Maktum (since 8
October 1990), ruler of Dubayy (Dubai) and
Deputy Prime Minister SULTAN bin Zayid
Al Nuhayyan (since 20 November 1990)
were appointed by the president
Supreme Council of Rulers: composed of the
seven emirate rulers, the council 1s the
highest constitutional authority in the UAE;
establishes general policies and sanctions
federal legislation, Abu Zaby (Abu Dhabi)
and Dubayy (Dubai) rulers have effective
veto power; council meets four times a year
cabinet: Council of Ministers was appointed
by the president
Legislative branch: unicameral Federal
National Council (Majlis Watani Itihad); no
elections; reviews legislation, but cannot
change or veto
Judicial branch: Union Supreme Court,
judges appointed by the president
Political parties and leaders: none
Other political or pressure groups: NA
International organization participation:
ABEDA. AfDB, AFESD, AL. AMF, CAEL,
CCC, ESCWA, FAO, G-77, GCC, IAEA,
IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Intelsat, Interpol,
IOC, ISO (correspondent), ITU, NAM,
OAPEC, OIC, OPEC, UN, UNCTAD,
UNESCO, UNIDO, UPL, WHO, WIPO,
WMO, WToO
Diplomatic representation in US:
chief of mission: Ambassador Muhammad
bin Husayn al-SHAALI
chancery: Suite 600, 3000 K Street NW,
Washington, DC 20007
telephone: |1]| (202) 338-6500
US diplomatic representation:
chief of mission: Ambassador David C. LITT
embassy: Al-Sudan Street, Abu Dhabi
mailing address: P.O. Box 4009, Abu
Dhabi, American Embassy Abu Dhabi,
Department of State, Washington, DC
20521-6010 (pouch)
telephone: (971] (2) 436691, 436692
FAX: {971} (2) 434771
consulate{s) general: Dubai
Flag: three equal horizontal bands of green
(top), white, and black with a thicker vertical
red band on the hoist side
Population: 58,489,975 (July 1996 est.)
497
Sb
ce a, Ae ee eT
United Kingdom (continued)
Age structure:
0-14 vears: 20% (male 5.853.545, female
5,565,153)
15-64 vears: 65% (male 19,050,420, temale
18.797.406)
65 vears and over: 15% (male 3.753.361:
female 5.470.090) July 1996 est.)
Population growth rate: 0.22% (1996 est.)
Birth rate: 13.12 births/1.000 population
(1996 est.)
Death rate: 11.24 deaths/1,.000 population
(1996 est.)
Net migration rate: 0.3 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 vears: 1.08 male(s)/female
15-64 vears: 1.01 male(sW/female
65 years and over: 0.69 male(s female
all eves: 0.96 maleis¥female (1996 est.)
Infant mortality rate: 6.4 deaths/1.000 live
births (1996 est.)
Life expectancy at birth:
total population: 76.41 years
male: 73.78% years
female: 79.17 years (1996 est.)
Total fertility rate: |.82 children born/
woman (1996 est.)
Nationality:
noun: Briton(s). British (collective plural)
adjective: British
Ethnic divisions: English 81.5%, Scottish
9.6%. Insh 2.4%. Welsh 1.9%, Ulster 1.8%,
West Indian. Indian, Pakistani, and other
2.8%
Religions: Anglican 27 million, Roman
Catholic 9 million, Muslin | millon,
Presbyterian 800,00". Metrodist 760,000,
Sikh 400,000, Hindu 350,000, Jewish
300,000 (1991 est.)
note. the UK does not include a question on
religion in its census
Languages: English. Welsh (about 26% of
the population of Wales), Scottish form of
Gaelic (about 60,000 in Scotland)
Literacy: ave 15 and over has completed
five or more years of schooling (1978 est.)
total population, 99%
male: NA%
female: NA%','5ab4e7cb83f3eb3b5e645272efcc50f16083bcba1893dd492558ddcb00418733','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2b1db37c5f04f7708cf1077f1203d94fc71592a840a62f77e4a4c56b0054622',1996,'US','United States','people-and-society',843,'Population: 266,476,278 (July 1996 est.)
Age structure:
0-14 vears: 22% (male 29,718,390: female
28,335,934)
15-64 years: 65% (male 86,225,056; female
87,411,573)
07
65 years and over: 13% (male 13,850,234;
female 20,021,655) (July 1996 est.)
Population growth rate: 0.91% (1996 est.)
Birth rate: 14.8 births/1,000 population
(1996 est.)
Death rate: 8.8 deaths/!,000 population
(1996 est.)
Net migration rate: 3.1 migrant(s)/! 000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(sWtemale
15-64 years: 0.99 male(s)/female
65 years and over: 0.69 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 6.7 deaths/!.000 live
births (1996 est.)
Life expectancy at birth:
total population: 75.95 years
male: 72.65 years
female: 79.41 years (1996 est.)
Total fertility rate: 2.06 children born/
woman (1996 est.)
Nationality:
noun: American(s)
adjective: American
Ethnic divisions: white 83.4%. black 12.4%.
Asian 3.3%, Native American 0.8% (1992)
Religions: Protestant 56%. Roman Catholic
28%, Jewish 2%, other 4%, none 10%
(1989)
Languages: English. Spanish (spoken by a
sizable minority)
Literacy: age 15 and over can read and
write (1979 est.)
total population: 97%
male: 97%
female: 97%
Population: 14.659 (July 1996 est.)
Age structure:
0-14 vears: NA
15-64 years: NA
65 vears and over: NA
Population growth rate: |.1 1° (1996 est.)
Birth rate: 24.38 births/].000 population
(1996 est.)
Death rate: 5.02 deaths/1,000 population
(1°96 est.)
Net migration rate: -§ 23 migrant(s)/1.000
population (1996 est.)
Sex ratio:
at birth: NA male(s)/temale
under 15 vears: NA male(s)/female
15-64 vears: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 23.59 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 72.76 years
male: 72.16 years
female: 73.4 years (1996 est.)
Total fertility rate: 3 children born/woman
(1996 est.)
Nationality:
noan. Wallisian(s), Futunan(s), or Wallis and
Futuna Islanders
adjective: Wallisian, Futunan, or Wallis and
Futuna Islander
Ethnic divisions: Polynesian
Religions: Roman Catholic 100%
Languages: French, Wallisian (indigenous
Polynesian language)
Literacy: age 15 and over can reaa and
write (1969 est.)
tal population: SO%
male: SO%
remale: SO0%
518','1ee31530b39f5c836fcbb86665d4582e13b8c3e2d9a580c1386415e9ac6515a5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4c0dba6e4d0b3ace105697d8c459b53ae5a6dfc1b1debaae81e6355f55d78af',1996,'UZ','Uzbekistan','people-and-society',853,'Population: 23.418.381 (July 1996 est.)
Age structure:
0-14 vears: 40% (male 4.732.585: female
4.618.503)
15-64 vears: 55% (male 6,441,052: female
6.540.479)
65 vears and over: 5% (male 416,571:
female 669.191) (July 1996 est.)
Population growth rate: |.87° (1996 est.)
Birth rate: 29.86 births/1,000 population
(1996 est.)
Death rate: &.02 deaths/1,000 population
(1996 est.)
Net migration rate: -3.)3 migrant(s)/1,000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/femaie
15-64 vears: 0.98 male(s)/female
65 years and over: 0.62 male(s)/female
all ages: 0.98 maletsV/temale (1996 est.)
Infant mortality rate: 79.6 deaths/! 000
live births (1996 esi.)
Life expectancy at birth:
total population: 64.6 years
male: 60.44 years
female: 68.97 years (1996 est.)
Total fertility rate: 3.69 children born/
woman (1996 est.)
Nationality:
noun: Uzbek(s)
adjective: Uzbek
Ethnic divisions: Uzbek 71.4. Russian
8.3%. Tajik 4.7%, Kazak 4.1%, Tatar 2.4%,
Karakalpak 2.!°7, other 7%
Religions: Muslim 88‘ (mostly Sunnis),
Eastern Orthodox 9%, other 3%
Languages: Uzbek 74.3%, Russian 14.2%,
Tajik 4.4%. other 7.1%
Literacy: age 15 and over can read and
write (1989 est.)
total population: 97%
male: 98%
female: 96%
506','36eab40360842d3dc59277ad38185c63da0257c48d4333d3a79e7b459db13073','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6240b2f9ccc35a3d60792337e341012f964833b7acd17c3bf19548bb882de80c',1996,'VU','Vanuatu','people-and-society',860,'Population: | 77,504 (July 1996 est.)
Age structure:
0-14 vears: 40% (male 36.409. female
35.105)
15-64 vears: 57% (male 51.969; female
48.901)
65 vears and over: 3% (male 7,802; female
2.318) (July 1996 est.)
Population growth rate: 2.17% (1996 est.)
Birth rate: 30.57 births/1,000 population
(1996 est.)
Death rate: 5.84 deaths/1.000 population
(1996 est.)
Net migration rate: 0 migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: \\.04 male(s)/female
15-64 years: 1.06 male(s)/female
65 vears and over: 1.21 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 64.6 deaths/1 000
live births (1996 est.)
Life expectancy at birth:
total population: 60.13 years
male: 58.27 years
female: 62.09 years (1996 est.)
Total fertility rate: 4.01 children born/
woman (1996 est.)
Nationality:
noun: Ni-Vanuatu (singular and plural)
adjective: Ni-Vanvatu
Ethnic divisions: indigenous Melanesian
94%, French 4%, Vietnamese, Chinese,
Pacific Islanders
Religions: Presbyterian 36.7%, Anglican
15%, Catholic 15%, indigenous beliefs 7.6%,
Seventh-Day Adventist 6.2%, Church of
Christ 3.8%, other 15.7%
Languages: English (official), French
(official), pidgin (known as Bislama or
Bichelama)
Literacy: age 15 and over can read and
write (1979 est.)
total population: 53%
male: 57%
female: 48%','c5ec4b78dbc46275a63b0c6e9e07b7f5723009ae56718a59ecc98b698529415b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db6bd7dd1c72601a368cab7fcafc66a42bd5d017df7a60a84af4fe9360f483b3',1996,'FR','France','people-and-society',869,'Population: |.427.741 (July 1996 est.)
note: in addition, there are 127,600 Israeli
settlers in the West Bank and 153,700 in
East Jerusalem (August 1995 est.)
Age structure:
0-14 years: 45% (male 332.628; female
315,968)
15-64 years: 51% (male 368,180; female
362.880)
65 vears and over: 4% (male 20.495; temale
27.590) (July 1996 est.)
Population growth rate: 4.99% (1996 est.)
Birth rate: 38.78 births/!.000 population
(1996 est.)
Death rate: 4.66 deaths/1,000 population
(1996 est.)
Net migration rate: 15.76 migrant(s)/!.000
population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/femele
15-64 years: 1.02 male(s)/female
65 years and over: 0.74 male(s\\/female
all ages: 1.02 male(s)/female (1996 est.)
519
S38
se |
West Bank (continued)
Infant mortality rate: 28.6 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total popittaution: 71.76 3
male: 70.17 years
temale, 73.44 years (1996 est.)
Total fertility rate: 5.2 children born/
woman (1996 est.)
Nationality:
noun: NA
adjective: NA
Ethnic divisions: Palestinian Arab and other
83%. Jewish 17%
Religions: Muslim 75% (predominantly
Sunni). Jewish 17%, Christian and other 8%
Languages: Arabic. Hebrew (spoken by
Israeli settlers). English (widely understood)
Literacy: NA','3f00b05e3bb114dfd100ebdea05b6a4f509cb1b0b6142ecab15ebbde95e309e5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('153fb94b1dc1986da12ac20041a69667df78c011e028e386b7c775f008fcadb6',1996,'MR','Mauritania','people-and-society',874,'Population: 222.631 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 vears and over: NA
Population growth rate: 2.46% (1996 est.)
Birth rate: 46.51 births/1,000 population
(1996 est.)
Death rate: 18.02 deaths/1,000 population
(1996 est.)
Net migration rate: -3.94 migrant(s)/1 000
population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 145.82 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 47.01 yeers
male: 46 years
female: 48.34 years (1996 est.)
Total fertility rate: 6.85 children born/
woman (1996 est.)
Nationality:
noun: Sahrawi(s). Sahraoui(s)
adjective: Sahrawian, Sahraouian
Ethnic divisions: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan
Arabic
Literacy: NA','7585035c59e2b69718f2ed48104448ff7f28dba805e29b5dd4236243d7e7b6b8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05f23126f6ceece31d417323b758876e7b7112d47b0ae995bb8719f6bc19e5f5',1996,'AO','Angola','people-and-society',886,'Population: 46,498,539 (July 1996 est.)
Age structure:
0-14 vears: 48% (male 11,161,347; female
11,124,583)
15-44 vears: 49% (male 11,197,097, female
11,783,524)
6S vears and over: ¥% (male $39,775;
female 692,213) (July 1996 est.)
Population growth rate: |.67% (1996 est.)
Birth rate: 48.) births/!,000 population
(1996 est.)
Death rate: 16.9 deaths/!.000 population
(1996 est.)
Net migration rate: -14.56 migiant(s)/! 000
population (1996 est.)
note: in 1994, more than one million
refugees fled into Zaire to escape the
fighting between the Hutus and the Tutsis in
Rwanda and Burundi; a small number of
these returned to their homes in 1995 despite
fear of the ongoing violence; additionally.
Zaire is host to about 100,000 Angolan, and
about 100,000 Sudanese refugees
Sex ratio:
at birth: 1.03 male(sVfemale
under 15 years: | male(sWfemale
15-64 vears: 0.95 maleisWfemale
65 vears and over: 0.78 maiei(sWiemale
all ages: 0.97 malei(sVfemale (1996 est.)
infant mortality rate: 108 deaths’! 000 live
births (1996 est.)
Life expectancy at birth:
total pepulation: 46.7 years
maie: 44.97 years
female: 48.47 years (1996 est.)
Total fertility rate: 6.64 children born/
woman (1996 est.)
Nationality :
noun: Zairianis)
adjective: Zaman
Ethnic divisions: over 200 Afncan ethnic
groups. the majority are Bantu: four largest
trtbes—Mongo, Luba, Kongo (all Bantu).
and the Mangbetu-Azande (Hamitic) make
up about 45% of the population
Religions: Roman Catholic 50%. Protestant
20%. Kimbanguist 10%, Muslim 10%, other
syncretic sects and traditional beliefs 10%
Languages: French (official), Lingala (a
lingua franca trade language). Kingwana (a
dialect of Kiswahili or Swahili), Kikongo.
Tshiluba
Literacy: age 15 and over can read and
write in French, Lingala. Kingwana. or
Tshiluba (1995 est.)
total population: 77.3%
male: 86.6%
female: 67.7%
Name of country:
conventional long form: Republic of Zaire
conventional short form: Zaire
local long form: Kepublique du Zaire
local short form: Zaire
former: Belgian Congo Congo/Leopoldville
Congo/Kinshasa
Data code: CG
Type of government: republic with a strong
presidential system
Capital: Kinshasa
Administrative divisions: 10 regions
(regions, singular—region) and | town*
(ville): Bandundu, Bas-Zaire. Equateur.
Haut-Zaire, Kasai-Occidental, Kasai-Onental.
Kinshasa*, Maniema, Nord-Kivu, Shaba.
Sud-Kivu
independence: 40 June 1960 (from
Belgium)
National holiday: Anniversary of the
Regime (Second Republic), 24 November
(1965)
Constitution: 24 June 1967, amended
August 1974, revised 15 February 1978;
amended April 1°90. new transitional
constitution promulgated in April 1994
Legal system: based on Belgian civil law
system and tnbal law; has not accepted
compulsory ICJ jurisdiction
Suifrage: 18 years of age: universal and
compulsory
Executive branch:
chief of state: President Marshal MOBUTU
Sese Seko Kuku Ngbendu wa Za Banga
(since 24 November 1965) elected for a
seven-year term by popular vote: election
last held 29 July 1984 (next io be held by
9 July 1997), results—President MOBUTU
was reelected without opposition
head of zovernment: Prime Minister Leon
KENGO wa Dondo (since 14 June 1994)
elected by the High Council of the Republic
cabinet: National Executive Council.
appointed by mutual agreement of the
president and the prime minister
Legislative branch: unicameral
parliament: a single body consisting of the
High Council of the Republic and the
Parliament of the Transition with
membership equally divided between
presidental supporters and opponents
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders: sole legal
party until January 19° |—Popular
Movement of the Revolution (MPR). other
parties include Union fit Democracy and
Social Progress (UDPS), Evenne
TSHISEKEDI wa Mulumba; Democratic
Social Christian Party (PDSC): Union of
Federalists and Independent Republicans
(UFERI;: Unified Luiwambast Party (PALU).
Antoine GIZENGA, Union of Independent
Democrats (UDI), Leon KENGO wa Dondo
International organization participation:
ACCT, ACP, AfDB, CCC, CEEAC, CEPGL.
ECA. FAO, G-!9, G-24, G-77, LAEA, IBRD.
ICAO, ICC, ICRM, IDA, IFAD, IFC,
IFRCS, ILO, IMF, IMO. Intelsat, Interpol,
1OC, ITU, NAM, OAU, PCA, UN.
UNCTAD, UNESCO, UNHCR, UNIDO,
UPU, WCL, WFTU, WHO, WIPO, WMO.
WToO
Diplomatic representation in US:
chief of mission: Ambassador TATANENE
Manata
chancery: 1800 New Hampshire Avenue
NW. Washington, DC 20009
telephone: |\\\\ (202) 234-7690, 7691
US diplomatic representation:
chief of mission: Ambassador Danie! H
SIMPSON
embassy: 310 Avenue des Aviateurs.
Kinshasa
mailing address: Unit 31550, APO AE
(RIK
telephone: (243) (12) 21533 through 21535
FAX: [243] (88) 43805, ext. 2308 of 43467
Flag: light green with a yellow disk in the
center Dearing a black arm holding a red
529
Zaire (continued)
famung torch: the flames of the torch are
blowing away from the horst side: uses the
popular pan-Afncan colors of Ethiopia','9f808351ef91c312fe7ba1c8382fc7a0867c32e43f11151af871fac86ae94462','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d619f8f9aee27d8b3df401c9ed47879d3ae50084c5789f94d791275a33f91fb',1996,'BW','Botswana','people-and-society',892,'Population: |! .271.314 uly 1996 est.)
Age structure:
0-14 years: 44% (male 2.513.606; female
2.481.478)
15-64 years: 53% (male 2,935,188: female
3,030,270)
65 years and over: 3% (male 152,244;
female 158,528) July 1996 est.)
Population growth rate: |.41% (1996 est.)
Birth rate: 32.34 births/!,000 population
(1996 est.)
Death rate: 18.2 deaths/1,000 population
(1996 est.)
Net migration rate: NA migrant(s)/! 000
population (1996 est.)
note: there is a small but steady flow of
Zimbabweans into South Africa in search of
better paid employment
Sex ratio:
a birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.96 male(s)/female
ali ages: 0.99 male(sWfemale (1996 est.)
Infant mortality rate: 72.8 deaths/1.000
live births (1996 est.)
Life expectancy at birth:
total population: 41.85 years
male: 41.91 years
female: 41.78 years (1996 est.)
Total fertility rate: 4.09 children born/
woman (1996 est.)
Nationality:
noun: Zimbabwean(s)
adjective. Zimbabwean
Ethnic divisions: African 98% (Shona 71%,
Ndebele 16%, other 11%). white 1%, mixed
and Asian 1%
Religions: syncretic (part Christian, part
indigenous beliefs) 50%, Christian 25%,
indigenous beliefs 24%. Muslim and other
1%
Languages: English (official), Stior a,
Sindebele (the language oi the ‘Ndebele,
sometimes called Ndebele). numerous but
minor tribal dialects
Literacy: age !5 and over can read and
write in English (1995 est.)
total population: 85%
male: 9%
female: 80%','98994c8f50be2a9237edd94cc823d065ea24daa65ff0efbe4b047cabb9b10b12','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ce687bb9fc9d1d62bcda9ace231dd9c923f1a9ecc59e0c416832cc0545b5e02',1996,'ZW','Zimbabwe','people-and-society',5,'------
Population: 22,664,136 (July 1996 est.)
Age structure:
0-14 years: 43% (male 4,972,469; female 4,784,900)
15-64 years: 54% (male 6,377,231; female 5,916,954)
65 years and over: 3% (male 325,808; female 286,774) (July 1996 est.)
Population growth rate: 4.78% (1996 est.)
Birth rate: 43.03 births/1,000 population (1996 est.)
Death rate: 18.16 deaths/1,000 population (1996 est.)
Net migration rate: 22.94 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.08 male(s)/female
65 years and over: 1.14 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 149.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 45.85 years
male: 46.43 years
female: 45.24 years (1996 est.)
Total fertility rate: 6.14 children born/woman (1996 est.)
Nationality:
noun: Afghan(s)
adjective: Afghan
Ethnic divisions: Pashtun 38%, Tajik 25%, Uzbek 6%, Hazara 19%,
minor ethnic groups (Chahar Aimaks, Turkmen, Baloch, and others)
Religions: Sunni Muslim 84%, Shi''a Muslim 15%, other 1%
Languages: Pashtu 35%, Afghan Persian (Dari) 50%, Turkic languages
(primarily Uzbek and Turkmen) 11%, 30 minor languages (primarily
Balochi and Pashai) 4%, much bilingualism
Literacy: age 15 and over can read and write (1995 est.)
total population: 31.5%
male: 47.2%
female: 15%
------
Population: 3,249,136 (July 1996 est.)
note: the IMF, working with Albanian government figures, estimates
that the population was 3,120,000 in 1993 and that it has fallen
since 1990
Age structure:
0-14 years: 34% (male 570,978; female 529,147)
15-64 years: 60% (male 910,873; female 1,049,662)
65 years and over: 6% (male 77,799; female 110,677) (July 1996 est.)
Population growth rate: 1.34% (1996 est.)
Birth rate: 22.21 births/1,000 population (1996 est.)
Death rate: 7.64 deaths/1,000 population (1996 est.)
Net migration rate: -1.17 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 0.87 male(s)/female
65 years and over: 0.7 male(s)/female
all ages: 0.92 male(s)/female (1996 est.)
Infant mortality rate: 49.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 67.92 years
male: 64.91 years
female: 71.17 years (1996 est.)
Total fertility rate: 2.65 children born/woman (1996 est.)
Nationality:
noun: Albanian(s)
adjective: Albanian
Ethnic divisions: Albanian 95%, Greeks 3%, other 2% (Vlachs,
Gypsies, Serbs, and Bulgarians) (1989 est.)
note: in 1989, other estimates of the Greek population ranged from
1% (official Albanian statistics) to 12% (from a Greek organization)
Religions: Muslim 70%, Albanian Orthodox 20%, Roman Catholic 10%
note: all mosques and churches were closed in 1967 and religious
observances prohibited; in November 1990, Albania began allowing
private religious practice
Languages: Albanian (Tosk is the official dialect), Greek
Literacy: age 9 and over can read and write (1955 est.)
total population: 72%
male: 80%
female: 63%
------
Population: 29,183,032 (July 1996 est.)
Age structure:
0-14 years: 40% (male 5,910,543; female 5,701,647)
15-64 years: 56% (male 8,319,650; female 8,162,816)
65 years and over: 4% (male 510,308; female 578,068) (July 1996 est.)
Population growth rate: 2.21% (1996 est.)
Birth rate: 28.51 births/1,000 population (1996 est.)
Death rate: 5.9 deaths/1,000 population (1996 est.)
Net migration rate: -0.49 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.88 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 48.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.31 years
male: 67.22 years
female: 69.46 years (1996 est.)
Total fertility rate: 3.59 children born/woman (1996 est.)
Nationality:
noun: Algerian(s)
adjective: Algerian
Ethnic divisions: Arab-Berber 99%, European less than 1%
Religions: Sunni Muslim (state religion) 99%, Christian and Jewish
1%
Languages: Arabic (official), French, Berber dialects
Literacy: age 15 and over can read and write (1995 est.)
total population: 61.6%
male: 73.9%
female: 49%
------
Population: 59,566 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 3.77% (1996 est.)
Birth rate: 35.75 births/1,000 population (1996 est.)
Death rate: 4.01 deaths/1,000 population (1996 est.)
Net migration rate: 6 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 18.78 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.91 years
male: 71.03 years
female: 74.85 years (1996 est.)
Total fertility rate: 4.24 children born/woman (1996 est.)
Nationality:
noun: American Samoan(s)
adjective: American Samoan
Ethnic divisions: Samoan (Polynesian) 89%, Caucasian 2%, Tongan
4%, other 5%
Religions: Christian Congregationalist 50%, Roman Catholic 20%,
Protestant denominations and other 30%
Languages: Samoan (closely related to Hawaiian and other
Polynesian languages), English
note: most people are bilingual
Literacy: age 15 and over can read and write (1980 est.)
total population: 97%
male: 98%
female: 97%
------
Population: 72,766 (July 1996 est.)
Age structure:
0-14 years: 16% (male 5,829; female 5,851)
15-64 years: 73% (male 28,724; female 24,757)
65 years and over: 11% (male 3,718; female 3,887) (July 1996 est.)
Population growth rate: 2.96% (1996 est.)
Birth rate: 10.2 births/1,000 population (1996 est.)
Death rate: 2.9 deaths/1,000 population (1996 est.)
Net migration rate: 22.29 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 0.96 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.16 male(s)/female
65 years and over: 0.96 male(s)/female
all ages: 1.11 male(s)/female
Infant mortality rate: 2.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 90.94 years
male: 86.47 years
female: 95.2 years (1996 est.)
Total fertility rate: 1.14 children born/woman (1996 est.)
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic divisions: Spanish 61%, Andorran 30%, French 6%, other 3%
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castilian
Literacy: NA
------
Population: 10,342,899 (July 1996 est.)
Age structure:
0-14 years: 45% (male 2,340,804; female 2,275,689)
15-64 years: 53% (male 2,748,417; female 2,706,295)
65 years and over: 2% (male 128,067; female 143,627) (July 1996 est.)
Population growth rate: 2.68% (1996 est.)
Birth rate: 44.58 births/1,000 population (1996 est.)
Death rate: 17.66 deaths/1,000 population (1996 est.)
Net migration rate: -0.14 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.89 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 138.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 46.8 years
male: 44.65 years
female: 49.06 years (1996 est.)
Total fertility rate: 6.35 children born/woman (1996 est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic divisions: Ovimbundu 37%, Kimbundu 25%, Bakongo 13%,
mestico (mixed European and Native African) 2%, European 1%, other
22%
Religions: indigenous beliefs 47%, Roman Catholic 38%, Protestant
15% (est.)
Languages: Portuguese (official), Bantu and other African languages
Literacy: age 15 and over can read and write (1990 est.)
total population: 42%
male: 56%
female: 28%
------
Population: 10,424 (July 1996 est.)
Age structure:
0-14 years: 28% (male 1,491; female 1,450)
15-64 years: 64% (male 3,418; female 3,275)
65 years and over: 8% (male 342; female 448) (July 1996 est.)
Population growth rate: 3.45% (1996 est.)
Birth rate: 17.84 births/1,000 population (1996 est.)
Death rate: 5.66 deaths/1,000 population (1996 est.)
Net migration rate: 22.35 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.76 male(s)/female
all ages: 1.02 male(s)/female
Infant mortality rate: 23 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 76.7 years
male: 73.75 years
female: 79.74 years (1996 est.)
Total fertility rate: 2.04 children born/woman (1996 est.)
Nationality:
noun: Anguillan(s)
adjective: Anguillan
Ethnic divisions: black African
Religions: Anglican 40%, Methodist 33%, Seventh-Day Adventist 7%,
Baptist 5%, Roman Catholic 3%, other 12%
Languages: English (official)
Literacy: age 12 and over can read and write (1984 est.)
total population: 95%
male: 95%
female: 95%
------
Population: no indigenous inhabitants; note - there are seasonally
staffed research stations
Summer (January) population: over 4,115 total; Argentina 207,
Australia 268, Belgium 13, Brazil 80, Chile 256, China NA, Ecuador
NA, Finland 11, France 78, Germany 32, Greenpeace 12, India 60,
Italy 210, Japan 59, South Korea 14, Netherlands 10, NZ 264, Norway
23, Peru 39, Poland NA, South Africa 79, Spain 43, Sweden 10, UK
116, Uruguay NA, US 1,666, former USSR 565 (1989-90)
Winter (July) population: over 1,046 total; Argentina 150, Australia
71, Brazil 12, Chile 73, China NA, France 33, Germany 19, Greenpeace
5, India 1, Japan 38, South Korea 14, NZ 11, Poland NA, South Africa
12, UK 69, Uruguay NA, US 225, former USSR 313 (1989-90)
Year-round stations: 42 total; Argentina 6, Australia 3, Brazil 1,
Chile 3, China 2, Finland 1, France 1, Germany 1, India 1, Japan 2,
South Korea 1, NZ 1, Poland 1, South Africa 3, UK 5, Uruguay 1, US
3, former USSR 6 (1990-91)
Summer-only stations: over 38 total; Argentina 7, Australia 3, Chile
5, Germany 3, India 1, Italy 1, Japan 4, NZ 2, Norway 1, Peru 1,
South Africa 1, Spain 1, Sweden 2, UK 1, US numerous, former USSR 5
(1989-90); note - the disintegration of the former USSR has placed
the status and future of its Antarctic facilities in doubt; stations
may be subject to closings at any time because of ongoing economic
difficulties
------
Population: 65,647 (July 1996 est.)
Age structure:
0-14 years: 25% (male 8,386; female 8,043)
15-64 years: 69% (male 22,589; female 22,548)
65 years and over: 6% (male 1,820; female 2,261) (July 1996 est.)
Population growth rate: 0.76% (1996 est.)
Birth rate: 16.83 births/1,000 population (1996 est.)
Death rate: 5.32 deaths/1,000 population (1996 est.)
Net migration rate: -3.9 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.8 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 17.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 73.64 years
male: 71.55 years
female: 75.84 years (1996 est.)
Total fertility rate: 1.68 children born/woman (1996 est.)
Nationality:
noun: Antiguan(s), Barbudan(s)
adjective: Antiguan, Barbudan
Ethnic divisions: black, British, Portuguese, Lebanese, Syrian
Religions: Anglican (predominant), other Protestant sects, some
Roman Catholic
Languages: English (official), local dialects
Literacy: age 15 and over has completed five or more years of
schooling (1960 est.)
total population: 89%
male: 90%
female: 88%
------
Population: 34,672,997 (July 1996 est.)
Age structure:
0-14 years: 28% (male 4,904,380; female 4,707,293)
15-64 years: 63% (male 10,851,004; female 10,834,593)
65 years and over: 9% (male 1,414,412; female 1,961,315) (July 1996
est.)
Population growth rate: 1.1% (1996 est.)
Birth rate: 19.41 births/1,000 population (1996 est.)
Death rate: 8.62 deaths/1,000 population (1996 est.)
Net migration rate: 0.18 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.72 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 28.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71.66 years
male: 68.37 years
female: 75.12 years (1996 est.)
Total fertility rate: 2.62 children born/woman (1996 est.)
Nationality:
noun: Argentine(s)
adjective: Argentine
Ethnic divisions: white 85%, mestizo, Indian, or other nonwhite
groups 15%
Religions: nominally Roman Catholic 90% (less than 20%
practicing), Protestant 2%, Jewish 2%, other 6%
Languages: Spanish (official), English, Italian, German, French
Literacy: age 15 and over can read and write (1995 est.)
total population: 96.2%
male: 96.2%
female: 96.2%
------
Population: 3,463,574 (July 1996 est.)
Age structure:
0-14 years: 28% (male 497,461; female 476,649)
15-64 years: 64% (male 1,085,935; female 1,132,282)
65 years and over: 8% (male 111,661; female 159,586) (July 1996 est.)
Population growth rate: 0.02% (1996 est.)
Birth rate: 16.27 births/1,000 population (1996 est.)
Death rate: 7.73 deaths/1,000 population (1996 est.)
Net migration rate: -8.3 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.7 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 38.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.06 years
male: 64.44 years
female: 73.92 years (1996 est.)
Total fertility rate: 2.06 children born/woman (1996 est.)
Nationality:
noun: Armenian(s)
adjective: Armenian
Ethnic divisions: Armenian 93%, Azeri 3%, Russian 2%, other
(mostly Yezidi Kurds) 2% (1989)
note: as of the end of 1993, virtually all Azeris had emigrated from
======================================================================
@Aruba
-----
(part of the Dutch realm)
Map
---
Location: 12 30 N, 69 58 W -- Caribbean, island in the Caribbean
Sea, north of Venezuela
Flag
----
Description: blue with two narrow horizontal yellow stripes across
the lower portion and a red, four-pointed star outlined in white in
the upper hoist-side corner
------
Population: 67,794 (July 1996 est.)
Age structure:
0-14 years: 22% (male 7,850; female 7,155)
15-64 years: 69% (male 22,499; female 24,596)
65 years and over: 9% (male 2,353; female 3,341) (July 1996 est.)
Population growth rate: 0.31% (1996 est.)
Birth rate: 14.62 births/1,000 population (1996 est.)
Death rate: 6.24 deaths/1,000 population (1996 est.)
Net migration rate: -5.31 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.7 male(s)/female
all ages: 0.93 male(s)/female
Infant mortality rate: 8.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 76.68 years
male: 73 years
female: 80.55 years (1996 est.)
Total fertility rate: 1.81 children born/woman (1996 est.)
Nationality:
noun: Aruban(s)
adjective: Aruban
Ethnic divisions: mixed European/Caribbean Indian 80%
Religions: Roman Catholic 82%, Protestant 8%, Hindu, Muslim,
Confucian, Jewish
Languages: Dutch (official), Papiamento (a Spanish, Portuguese,
Dutch, English dialect), English (widely spoken), Spanish
Literacy: NA
------
Population: no indigenous inhabitants; note - there are only
seasonal caretakers
------
Population: 18,260,863 (July 1996 est.)
Age structure:
0-14 years: 21% (male 2,009,915; female 1,912,605)
15-64 years: 66% (male 6,129,285; female 5,980,315)
65 years and over: 13% (male 967,291; female 1,261,452) (July 1996
est.)
Population growth rate: 0.99% (1996 est.)
Birth rate: 13.99 births/1,000 population (1996 est.)
Death rate: 6.88 deaths/1,000 population (1996 est.)
Net migration rate: 2.74 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.77 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 5.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 79.39 years
male: 76.44 years
female: 82.5 years (1996 est.)
Total fertility rate: 1.84 children born/woman (1996 est.)
Nationality:
noun: Australian(s)
adjective: Australian
Ethnic divisions: Caucasian 95%, Asian 4%, aboriginal and other 1%
Religions: Anglican 26.1%, Roman Catholic 26%, other Christian
24.3%
Languages: English, native languages
Literacy: age 15 and over can read and write (1980 est.)
total population: 100%
male: 100%
female: 100%
------
Population: 8,023,244 (July 1996 est.)
Age structure:
0-14 years: 18% (male 720,696; female 685,179)
15-64 years: 67% (male 2,726,122; female 2,659,162)
65 years and over: 15% (male 451,231; female 780,854) (July 1996
est.)
Population growth rate: 0.41% (1996 est.)
Birth rate: 11.19 births/1,000 population (1996 est.)
Death rate: 10.43 deaths/1,000 population (1996 est.)
Net migration rate: 3.34 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.58 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 6.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 76.53 years
male: 73.38 years
female: 79.84 years (1996 est.)
Total fertility rate: 1.49 children born/woman (1996 est.)
Nationality:
noun: Austrian(s)
adjective: Austrian
Ethnic divisions: German 99.4%, Croatian 0.3%, Slovene 0.2%, other
0.1%
Religions: Roman Catholic 85%, Protestant 6%, other 9%
Languages: German
Literacy: age 15 and over can read and write (1974 est.)
total population: 99%
male: NA%
female: NA%
------
Population: 7,676,953 (July 1996 est.)
Age structure:
0-14 years: 32% (male 1,270,812; female 1,215,781)
15-64 years: 61% (male 2,293,688; female 2,423,222)
65 years and over: 7% (male 179,048; female 294,402) (July 1996 est.)
Population growth rate: 0.78% (1996 est.)
Birth rate: 22.28 births/1,000 population (1996 est.)
Death rate: 8.69 deaths/1,000 population (1996 est.)
Net migration rate: -5.8 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.61 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 74.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 64.84 years
male: 60.13 years
female: 69.78 years (1996 est.)
Total fertility rate: 2.64 children born/woman (1996 est.)
Nationality:
noun: Azerbaijani(s)
adjective: Azerbaijani
Ethnic divisions: Azeri 90%, Dagestani Peoples 3.2%, Russian 2.5%,
Armenian 2.3%, other 2% (1995 est.)
note: almost all Armenians live in the separatist Nagorno-Karabakh
region
Religions: Muslim 93.4%, Russian Orthodox 2.5%, Armenian Orthodox
2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan; actual
practicing adherents are much lower
Languages: Azeri 89%, Russian 3%, Armenian 2%, other 6% (1995 est.)
Literacy: age 15 and over can read and write (1989 est.)
total population: 97%
male: 99%
female: 96%','6e2b16bad439b26ea5b49a5877068d4501a1600a31ac04e0281a796845e23ccc','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d1381d2ff81138ac5d648dda27421b06cef9d42984ab6a5d8f760a523bac09d',1996,'SA','Saudi Arabia','people-and-society',15,'------
Population: 590,042 (July 1996 est.)
Age structure:
0-14 years: 31% (male 92,455; female 89,554)
15-64 years: 67% (male 236,048; female 156,556)
65 years and over: 2% (male 7,956; female 7,473) (July 1996 est.)
Population growth rate: 2.27% (1996 est.)
Birth rate: 23.58 births/1,000 population (1996 est.)
Death rate: 3.29 deaths/1,000 population (1996 est.)
Net migration rate: 2.42 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.51 male(s)/female
65 years and over: 1.06 male(s)/female
all ages: 1.33 male(s)/female (1996 est.)
Infant mortality rate: 17.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 74.27 years
male: 71.78 years
female: 76.83 years (1996 est.)
Total fertility rate: 3.08 children born/woman (1996 est.)
Nationality:
noun: Bahraini(s)
adjective: Bahraini
Ethnic divisions: Bahraini 63%, Asian 13%, other Arab 10%, Iranian
8%, other 6%
Religions: Shi''a Muslim 75%, Sunni Muslim 25%
Languages: Arabic, English, Farsi, Urdu
Literacy: age 15 and over can read and write (1995 est.)
total population: 85.2%
male: 89.1%
female: 79.4%
------
Population: uninhabited; note - American civilians evacuated in
1942 after Japanese air and naval attacks during World War II;
occupied by US military during World War II, but abandoned after the
war; public entry is by special-use permit only and generally
restricted to scientists and educators; a cemetery and cemetery
ruins are located near the middle of the west coast
------
Population: 123,062,800 (July 1996 est.)
Age structure:
0-14 years: 39% (male 24,434,219; female 23,436,359)
15-64 years: 58% (male 36,607,942; female 34,603,628)
65 years and over: 3% (male 2,175,017; female 1,805,635) (July 1996
est.)
Population growth rate: 1.85% (1996 est.)
Birth rate: 30.5 births/1,000 population (1996 est.)
Death rate: 11.21 deaths/1,000 population (1996 est.)
Net migration rate: -0.78 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.06 male(s)/female
65 years and over: 1.2 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 102.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 55.86 years
male: 56.02 years
female: 55.69 years (1996 est.)
Total fertility rate: 3.57 children born/woman (1996 est.)
Nationality:
noun: Bangladeshi(s)
adjective: Bangladesh
Ethnic divisions: Bengali 98%, Biharis 250,000, tribals less than
1 million
Religions: Muslim 83%, Hindu 16%, Buddhist, Christian, other
Languages: Bangla (official), English
Literacy: age 15 and over can read and write (1995 est.)
total population: 38.1%
male: 49.4%
female: 26.1%
------
Population: 257,030 (July 1996 est.)
Age structure:
0-14 years: 24% (male 31,263; female 29,822)
15-64 years: 66% (male 83,565; female 86,697)
65 years and over: 10% (male 9,929; female 15,754) (July 1996 est.)
Population growth rate: 0.26% (1996 est.)
Birth rate: 15.29 births/1,000 population (1996 est.)
Death rate: 8.21 deaths/1,000 population (1996 est.)
Net migration rate: -4.49 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.63 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 18.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 74.35 years
male: 71.65 years
female: 77.25 years (1996 est.)
Total fertility rate: 1.78 children born/woman (1996 est.)
Nationality:
noun: Barbadian(s)
adjective: Barbadian
Ethnic divisions: African 80%, European 4%, other 16%
Religions: Protestant 67% (Anglican 40%, Pentecostal 8%, Methodist
7%, other 12%), Roman Catholic 4%, none 17%, unknown 3%, other 9%
(1980)
Languages: English
Literacy: age 15 and over has ever attended school (1995 est.)
total population: 97.4%
male: 98%
female: 96.8%
------
Population: uninhabited
------
Population: 10,415,973 (July 1996 est.)
Age structure:
0-14 years: 21% (male 1,136,499; female 1,090,101)
15-64 years: 66% (male 3,334,077; female 3,536,982)
65 years and over: 13% (male 429,574; female 888,740) (July 1996
est.)
Population growth rate: 0.2% (1996 est.)
Birth rate: 12.15 births/1,000 population (1996 est.)
Death rate: 13.64 deaths/1,000 population (1996 est.)
Net migration rate: 3.51 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.48 male(s)/female
all ages: 0.89 male(s)/female (1996 est.)
Infant mortality rate: 13.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.57 years
male: 63.2 years
female: 74.21 years (1996 est.)
Total fertility rate: 1.69 children born/woman (1996 est.)
Nationality:
noun: Belarusian(s)
adjective: Belarusian
Ethnic divisions: Byelorussian 77.9%, Russian 13.2%, Polish 4.1%,
Ukrainian 2.9%, other 1.9%
Religions: Eastern Orthodox 60%, other (including Roman Catholic
and Muslim) 40% (early 1990''s)
Languages: Byelorussian, Russian, other
Literacy: age 15 and over can read and write (1989 est.)
total population: 98%
male: 99%
female: 97%
------
Population: 10,170,241 (July 1996 est.)
Age structure:
0-14 years: 18% (male 930,919; female 886,632)
15-64 years: 66% (male 3,380,105; female 3,326,853)
65 years and over: 16% (male 663,760; female 981,972) (July 1996
est.)
Population growth rate: 0.33% (1996 est.)
Birth rate: 12 births/1,000 population (1996 est.)
Death rate: 10.3 deaths/1,000 population (1996 est.)
Net migration rate: 1.63 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.68 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 6.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.09 years
male: 73.86 years
female: 80.51 years (1996 est.)
Total fertility rate: 1.69 children born/woman (1996 est.)
Nationality:
noun: Belgian(s)
adjective: Belgian
Ethnic divisions: Fleming 55%, Walloon 33%, mixed or other 12%
Religions: Roman Catholic 75%, Protestant or other 25%
Languages: Dutch 56%, French 32%, German 1%, legally bilingual 11%
(divided along ethnic lines)
Literacy: age 15 and over can read and write (1980 est.)
total population: 99%
male: NA%
female: NA%
------
Population: 219,296 (July 1996 est.)
Age structure:
0-14 years: 43% (male 48,291; female 46,451)
15-64 years: 53% (male 59,132; female 57,498)
65 years and over: 4% (male 3,881; female 4,043) (July 1996 est.)
Population growth rate: 2.42% (1996 est.)
Birth rate: 32.8 births/1,000 population (1996 est.)
Death rate: 5.73 deaths/1,000 population (1996 est.)
Net migration rate: -2.89 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.96 male(s)/female
all ages: 1.03 male(s)/female (1996 est.)
Infant mortality rate: 33.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.53 years
male: 66.58 years
female: 70.58 years (1996 est.)
Total fertility rate: 4.12 children born/woman (1996 est.)
Nationality:
noun: Belizean(s)
adjective: Belizean
Ethnic divisions: mestizo 44%, Creole 30%, Maya 11%, Garifuna 7%,
other 8%
Religions: Roman Catholic 62%, Protestant 30% (Anglican 12%,
Methodist 6%, Mennonite 4%, Seventh-Day Adventist 3%, Pentecostal
2%, Jehovah''s Witnesses 1%, other 2%), none 2%, other 6% (1980)
Languages: English (official), Spanish, Mayan, Garifuna (Carib)
Literacy: age 14 and over has ever attended school (1991 est.)
total population: 70.3%
male: 70.3%
female: 70.3%
------
Population: 5,709,529 (July 1996 est.)
Age structure:
0-14 years: 48% (male 1,376,531; female 1,367,394)
15-64 years: 50% (male 1,349,386; female 1,480,251)
65 years and over: 2% (male 60,030; female 75,937) (July 1996 est.)
Population growth rate: 3.32% (1996 est.)
Birth rate: 46.76 births/1,000 population (1996 est.)
Death rate: 13.53 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.79 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 105.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 52.69 years
male: 50.74 years
female: 54.7 years (1996 est.)
Total fertility rate: 6.64 children born/woman (1996 est.)
Nationality:
noun: Beninese (singular and plural)
adjective: Beninese
Ethnic divisions: African 99% (42 ethnic groups, most important
being Fon, Adja, Yoruba, Bariba), Europeans 5,500
Religions: indigenous beliefs 70%, Muslim 15%, Christian 15%
Languages: French (official), Fon and Yoruba (most common
vernaculars in south), tribal languages (at least six major ones in
north)
Literacy: age 15 and over can read and write (1995 est.)
total population: 37%
male: 48.7%
female: 25.8%
------
Population: 547,761 (July 1996 est.)
Age structure:
0-14 years: 30% (male 82,147; female 83,552)
15-64 years: 68% (male 263,107; female 109,177)
65 years and over: 2% (male 6,609; female 3,169) (July 1996 est.)
Population growth rate: 2.39% (1996 est.)
Birth rate: 21.03 births/1,000 population (1996 est.)
Death rate: 3.6 deaths/1,000 population (1996 est.)
Net migration rate: 6.43 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 0.96 male(s)/female
under 15 years: 0.98 male(s)/female
15-64 years: 2.41 male(s)/female
65 years and over: 2.09 male(s)/female
all ages: 1.8 male(s)/female (1996 est.)
Infant mortality rate: 19.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 73.35 years
male: 70.75 years
female: 75.84 years (1996 est.)
Total fertility rate: 4.28 children born/woman (1996 est.)
Nationality:
noun: Qatari(s)
adjective: Qatari
Ethnic divisions: Arab 40%, Pakistani 18%, Indian 18%, Iranian
10%, other 14%
Religions: Muslim 95%
Languages: Arabic (official), English commonly used as a second
language
Literacy: age 15 and over can read and write (1995 est.)
total population: 79.4%
male: 79.2%
female: 79.9%','bfb2261cfdffb392372f5852b8405554fbee6fcd71ca2ec67052b75d0fca3d1c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67915951037079b9ba0e51ad4428deb61b52b7d29a6538af7d753c97128222cd',1996,'HK','Hong Kong','people-and-society',27,'------
Population: 62,099 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.76% (1996 est.)
Birth rate: 15 births/1,000 population (1996 est.)
Death rate: 7.3 deaths/1,000 population (1996 est.)
Net migration rate: -0.13 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 13.16 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.03 years
male: 73.36 years
female: 76.97 years (1996 est.)
Total fertility rate: 1.8 children born/woman (1996 est.)
Nationality:
noun: Bermudian(s)
adjective: Bermudian
Ethnic divisions: black 61%, white and other 39%
Religions: Anglican 37%, Roman Catholic 14%, African Methodist
Episcopal (Zion) 10%, Methodist 6%, Seventh-Day Adventist 5%, other
28%
Languages: English
Literacy: age 15 and over can read and write (1970 est.)
total population: 98%
male: 98%
female: 99%','29699a8a5b479dd193929e4a692234a38a3aecc1177627e91defb0a85e9f0bab','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('762a4a3429cb54ae60f6fea9836a3caacd819d634e405ed10b9a8ff68e78b008',1996,'IN','India','people-and-society',32,'------
Population: 1,822,625 (July 1996 est.)
note: other estimates range as low as 600,000
Age structure:
0-14 years: 40% (male 378,407; female 351,146)
15-64 years: 56% (male 524,972; female 496,715)
65 years and over: 4% (male 36,304; female 35,081) (July 1996 est.)
Population growth rate: 2.32% (1996 est.)
Birth rate: 38.48 births/1,000 population (1996 est.)
Death rate: 15.28 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 1.06 male(s)/female
65 years and over: 1.04 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 116.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 51.46 years
male: 51.96 years
female: 50.93 years (1996 est.)
Total fertility rate: 5.33 children born/woman (1996 est.)
Nationality:
noun: Bhutanese (singular and plural)
adjective: Bhutanese
Ethnic divisions: Bhote 50%, ethnic Nepalese 35%, indigenous or
migrant tribes 15%
Religions: Lamaistic Buddhism 75%, Indian- and Nepalese-influenced
Hinduism 25%
Languages: Dzongkha (official), Bhotes speak various Tibetan
dialects, Nepalese speak various Nepalese dialects
Literacy: age 15 and over can read and write (1995 est.)
total population: 42.2%
male: 56.2%
female: 28.1%
------
Population: 270,758 (July 1996 est.)
Age structure:
0-14 years: 47% (male 65,559; female 62,399)
15-64 years: 50% (male 69,071; female 65,659)
65 years and over: 3% (male 4,336; female 3,734) (July 1996 est.)
Population growth rate: 3.52% (1996 est.)
Birth rate: 41.88 births/1,000 population (1996 est.)
Death rate: 6.64 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 1.16 male(s)/female
all ages: 1.05 male(s)/female (1996 est.)
Infant mortality rate: 47 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 66.17 years
male: 64.6 years
female: 67.82 years (1996 est.)
Total fertility rate: 6.06 children born/woman (1996 est.)
Nationality:
noun: Maldivian(s)
adjective: Maldivian
Ethnic divisions: Sinhalese, Dravidian, Arab, African
Religions: Sunni Muslim
Languages: Maldivian Divehi (dialect of Sinhala, script derived
from Arabic), English spoken by most government officials
Literacy: age 15 and over can read and write (1995 est.)
total population: 93.2%
male: 93.3%
female: 93%
------
Population: 9,653,261 (July 1996 est.)
Age structure:
0-14 years: 48% (male 2,310,294; female 2,308,941)
15-64 years: 49% (male 2,231,244; female 2,488,276)
65 years and over: 3% (male 149,370; female 165,136) (July 1996 est.)
Population growth rate: 2.95% (1996 est.)
Birth rate: 51.38 births/1,000 population (1996 est.)
Death rate: 19.49 deaths/1,000 population (1996 est.)
Net migration rate: -2.37 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.9 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 102.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 46.84 years
male: 45.12 years
female: 48.6 years (1996 est.)
Total fertility rate: 7.25 children born/woman (1996 est.)
Nationality:
noun: Malian(s)
adjective: Malian
Ethnic divisions: Mande 50% (Bambara, Malinke, Sarakole), Peul
17%, Voltaic 12%, Songhai 6%, Tuareg and Moor 10%, other 5%
Religions: Muslim 90%, indigenous beliefs 9%, Christian 1%
Languages: French (official), Bambara 80%, numerous African
languages
Literacy: age 15 and over can read and write (1995 est.)
total population: 31%
male: 39.4%
female: 23.1%
------
Population: 375,576 (July 1996 est.)
Age structure:
0-14 years: 22% (male 42,067; female 39,958)
15-64 years: 67% (male 126,179; female 125,321)
65 years and over: 11% (male 17,766; female 24,285) (July 1996 est.)
Population growth rate: 1.01% (1996 est.)
Birth rate: 14.79 births/1,000 population (1996 est.)
Death rate: 6.83 deaths/1,000 population (1996 est.)
Net migration rate: 2.12 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.73 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 6.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.11 years
male: 75.77 years
female: 80.6 years (1996 est.)
Total fertility rate: 2.17 children born/woman (1996 est.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic divisions: Arab, Sicilian, Norman, Spanish, Italian, English
Religions: Roman Catholic 98%
Languages: Maltese (official), English (official)
Literacy: age 15 and over can read and write (1985 est.)
total population: 84%
male: 86%
female: 82%
------
Population: 73,837 (July 1996 est.)
Age structure:
0-14 years: 18% (male 6,606; female 6,348)
15-64 years: 65% (male 23,917; female 23,815)
65 years and over: 17% (male 5,239; female 7,912) (July 1996 est.)
Population growth rate: 0.94% (1996 est.)
Birth rate: 12.43 births/1,000 population (1996 est.)
Death rate: 12.09 deaths/1,000 population (1996 est.)
Net migration rate: 9.02 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.66 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 2.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.15 years
male: 73.56 years
female: 80.91 years (1996 est.)
Total fertility rate: 1.68 children born/woman (1996 est.)
Nationality:
noun: Manxman, Manxwoman
adjective: Manx
Ethnic divisions: Manx (Norse-Celtic descent), Briton
Religions: Anglican, Roman Catholic, Methodist, Baptist,
Presbyterian, Society of Friends
Languages: English, Manx Gaelic
Literacy: NA
------
Population: 22,094,033 (July 1996 est.)
Age structure:
0-14 years: 42% (male 4,776,245; female 4,563,000)
15-64 years: 55% (male 6,172,821; female 5,945,626)
65 years and over: 3% (male 320,350; female 315,991) (July 1996 est.)
Population growth rate: 2.45% (1996 est.)
Birth rate: 37 births/1,000 population (1996 est.)
Death rate: 12.56 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 1.01 male(s)/female
all ages: 1.04 male(s)/female (1996 est.)
Infant mortality rate: 79 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 53.63 years
male: 53.35 years
female: 53.93 years (1996 est.)
Total fertility rate: 5.06 children born/woman (1996 est.)
Nationality:
noun: Nepalese (singular and plural)
adjective: Nepalese
Ethnic divisions: Newars, Indians, Tibetans, Gurungs, Magars,
Tamangs, Bhotias, Rais, Limbus, Sherpas
Religions: Hindu 90%, Buddhist 5%, Muslim 3%, other 2% (1981)
note: only official Hindu state in world, although no sharp
distinction between many Hindu and Buddhist groups
Languages: Nepali (official), 20 other languages divided into
numerous dialects
Literacy: age 15 and over can read and write (1995 est.)
total population: 27.5%
male: 40.9%
female: 14%
------
Population: 15,568,034 (July 1996 est.)
Age structure:
0-14 years: 18% (male 1,457,694; female 1,393,402)
15-64 years: 68% (male 5,412,402; female 5,228,579)
65 years and over: 14% (male 836,934; female 1,239,023) (July 1996
est.)
Population growth rate: 0.56% (1996 est.)
Birth rate: 12.08 births/1,000 population (1996 est.)
Death rate: 8.7 deaths/1,000 population (1996 est.)
Net migration rate: 2.25 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.68 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 4.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.73 years
male: 74.91 years
female: 80.68 years (1996 est.)
Total fertility rate: 1.51 children born/woman (1996 est.)
Nationality:
noun: Dutchman(men), Dutchwoman(women)
adjective: Dutch
Ethnic divisions: Dutch 96%, Moroccans, Turks, and other 4% (1988)
Religions: Roman Catholic 34%, Protestant 25%, Muslim 3%, other
2%, unaffiliated 36% (1991)
Languages: Dutch
Literacy: age 15 and over can read and write (1979 est.)
total population: 99%
male: NA%
female: NA%
------
Population: 208,968 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.03% (1996 est.)
Birth rate: 15.98 births/1,000 population (1996 est.)
Death rate: 5.29 deaths/1,000 population (1996 est.)
Net migration rate: -0.37 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.72 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 8.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.06 years
male: 74.78 years
female: 79.46 years (1996 est.)
Nationality:
noun: Netherlands Antillean(s)
adjective: Netherlands Antillean
Ethnic divisions: mixed African 85%, Carib Indian, European,
Latin, Oriental
Religions: Roman Catholic, Protestant, Jewish, Seventh-Day
Adventist
Languages: Dutch (official), Papiamento a
Spanish-Portuguese-Dutch-English dialect predominates, English
widely spoken, Spanish
Literacy: age 15 and over can read and write (1981 est.)
total population: 98%
male: 98%
female: 99%','87b2061e07600867db494aa3ee0c7dc18f07b81b2b3315a7cd8cdb522691e71a','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da4cd0cdb3b3c1a6b181c1b852ede211187f0960dd0b0d70298e41a5b355ebe9',1996,'BR','Brazil','people-and-society',39,'------
Population: 7,165,257 (July 1996 est.)
Age structure:
0-14 years: 39% (male 1,422,313; female 1,390,885)
15-64 years: 56% (male 1,959,989; female 2,042,135)
65 years and over: 5% (male 153,111; female 196,824) (July 1996 est.)
Population growth rate: 1.82% (1996 est.)
Birth rate: 32.37 births/1,000 population (1996 est.)
Death rate: 10.75 deaths/1,000 population (1996 est.)
Net migration rate: -3.41 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.78 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 67.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 59.81 years
male: 56.94 years
female: 62.82 years (1996 est.)
Total fertility rate: 4.25 children born/woman (1996 est.)
Nationality:
noun: Bolivian(s)
adjective: Bolivian
Ethnic divisions: Quechua 30%, Aymara 25%, mestizo (mixed European
and Indian ancestry) 25%-30%, European 5%-15%
Religions: Roman Catholic 95%, Protestant (Evangelical Methodist)
Languages: Spanish (official), Quechua (official), Aymara
(official)
Literacy: age 15 and over can read and write (1995 est.)
total population: 83.1%
male: 90.5%
female: 76%
------
Population: 5,504,146 (July 1996 est.)
Age structure:
0-14 years: 41% (male 1,144,644; female 1,096,430)
15-64 years: 55% (male 1,518,661; female 1,513,577)
65 years and over: 4% (male 106,121; female 124,713) (July 1996 est.)
Population growth rate: 2.67% (1996 est.)
Birth rate: 30.97 births/1,000 population (1996 est.)
Death rate: 4.31 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.85 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 23.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 73.84 years
male: 72.33 years
female: 75.43 years (1996 est.)
Total fertility rate: 4.15 children born/woman (1996 est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic divisions: mestizo (mixed Spanish and Indian) 95%, whites
plus Amerindians 5%
Religions: Roman Catholic 90%, Mennonite and other Protestant
denominations
Languages: Spanish (official), Guarani
Literacy: age 15 and over can read and write (1995 est.)
total population: 92.1%
male: 93.5%
female: 90.6%
------
Population: 24,523,408 (July 1996 est.)
Age structure:
0-14 years: 35% (male 4,360,379; female 4,214,970)
15-64 years: 61% (male 7,480,747; female 7,375,825)
65 years and over: 4% (male 497,775; female 593,712) (July 1996 est.)
Population growth rate: 1.74% (1996 est.)
Birth rate: 24.33 births/1,000 population (1996 est.)
Death rate: 6.13 deaths/1,000 population (1996 est.)
Net migration rate: -0.76 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.84 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 52.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.13 years
male: 66.97 years
female: 71.39 years (1996 est.)
Total fertility rate: 3.04 children born/woman (1996 est.)
Nationality:
noun: Peruvian(s)
adjective: Peruvian
Ethnic divisions: Indian 45%, mestizo (mixed Indian and European
ancestry) 37%, white 15%, black, Japanese, Chinese, and other 3%
Religions: Roman Catholic
Languages: Spanish (official), Quechua (official), Aymara
Literacy: age 15 and over can read and write (1995 est.)
total population: 88.7%
male: 94.5%
female: 83%
------
Population: 74,480,848 (July 1996 est.)
Age structure:
0-14 years: 38% (male 14,486,214; female 14,026,873)
15-64 years: 58% (male 21,403,784; female 21,968,259)
65 years and over: 4% (male 1,165,810; female 1,429,908) (July 1996
est.)
Population growth rate: 2.18% (1996 est.)
Birth rate: 29.51 births/1,000 population (1996 est.)
Death rate: 6.66 deaths/1,000 population (1996 est.)
Net migration rate: -1.06 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.82 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 35.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 65.91 years
male: 63.14 years
female: 68.83 years (1996 est.)
Total fertility rate: 3.69 children born/woman (1996 est.)
Nationality:
noun: Filipino(s)
adjective: Philippine
Ethnic divisions: Christian Malay 91.5%, Muslim Malay 4%, Chinese
1.5%, other 3%
Religions: Roman Catholic 83%, Protestant 9%, Muslim 5%, Buddhist
and other 3%
Languages: Pilipino (official, based on Tagalog), English
(official)
Literacy: age 15 and over can read and write (1995 est.)
total population: 94.6%
male: 95%
female: 94.3%
------
Population: 56 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0% (1996 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Pitcairn Islander(s)
adjective: Pitcairn Islander
Ethnic divisions: descendants of the Bounty mutineers
Religions: Seventh-Day Adventist 100%
Languages: English (official), Tahitian/English dialect
------
Population: 38,642,565 (July 1996 est.)
Age structure:
0-14 years: 22% (male 4,399,649; female 4,188,824)
15-64 years: 66% (male 12,754,272; female 12,930,275)
65 years and over: 12% (male 1,654,526; female 2,715,019) (July 1996
est.)
Population growth rate: 0.14% (1996 est.)
Birth rate: 11.92 births/1,000 population (1996 est.)
Death rate: 10.08 deaths/1,000 population (1996 est.)
Net migration rate: -0.4 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.61 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 12.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.1 years
male: 68.02 years
female: 76.41 years (1996 est.)
Total fertility rate: 1.69 children born/woman (1996 est.)
Nationality:
noun: Pole(s)
adjective: Polish
Ethnic divisions: Polish 97.6%, German 1.3%, Ukrainian 0.6%,
Byelorussian 0.5% (1990 est.)
Religions: Roman Catholic 95% (about 75% practicing), Eastern
Orthodox, Protestant, and other 5%
Languages: Polish
Literacy: age 15 and over can read and write (1978 est.)
total population: 99%
male: 99%
female: 98%
------
Population: 9,865,114 (July 1996 est.)
Age structure:
0-14 years: 18% (male 888,157; female 843,309)
15-64 years: 68% (male 3,249,973; female 3,414,793)
65 years and over: 14% (male 601,913; female 866,969) (July 1996
est.)
Population growth rate: 0.02% (1996 est.)
Birth rate: 10.53 births/1,000 population (1996 est.)
Death rate: 10.2 deaths/1,000 population (1996 est.)
Net migration rate: -0.18 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.69 male(s)/female
all ages: 0.92 male(s)/female (1996 est.)
Infant mortality rate: 7.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.31 years
male: 71.52 years
female: 79.31 years (1996 est.)
Total fertility rate: 1.36 children born/woman (1996 est.)
Nationality:
noun: Portuguese (singular and plural)
adjective: Portuguese
Ethnic divisions: homogeneous Mediterranean stock in mainland,
Azores, Madeira Islands; citizens of black African descent who
immigrated to mainland during decolonization number less than 100,000
Religions: Roman Catholic 97%, Protestant denominations 1%, other
2%
Languages: Portuguese
Literacy: age 15 and over can read and write (1990 est.)
total population: 85%
male: 89%
female: 82%
------
Population: 3,819,023 (July 1996 est.)
Age structure:
0-14 years: 25% (male 484,038; female 461,175)
15-64 years: 65% (male 1,201,841; female 1,279,707)
65 years and over: 10% (male 174,274; female 217,988) (July 1996
est.)
Population growth rate: 0.18% (1996 est.)
Birth rate: 15.56 births/1,000 population (1996 est.)
Death rate: 7.46 deaths/1,000 population (1996 est.)
Net migration rate: -6.35 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.8 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 12.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.38 years
male: 71.13 years
female: 79.89 years (1996 est.)
Total fertility rate: 1.94 children born/woman (1996 est.)
Nationality:
noun: Puerto Rican(s) (US citizens)
adjective: Puerto Rican
Ethnic divisions: Hispanic
Religions: Roman Catholic 85%, Protestant denominations and other
15%
Languages: Spanish, English
Literacy: age 15 and over can read and write (1980 est.)
total population: 89%
male: 90%
female: 88%','3359b1d0bb10a967b572f9a2def638b3810ad2004bc1c73b97b3eb6e0513731d','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c53f19c51b7ea5350ef2e8a0732f98476821b8e87efdc8a9f7bf0005c19971d',1996,'HR','Croatia','people-and-society',46,'------
Population: 2,656,240 (July 1996 est.)
note: all data dealing with population is subject to considerable
error because of the dislocations caused by military action and
ethnic cleansing
Age structure:
0-14 years: 20% (male 276,530; female 248,519)
15-64 years: 68% (male 892,807; female 915,686)
65 years and over: 12% (male 133,081; female 189,617) (July 1996
est.)
Population growth rate: -2.84% (1996 est.)
Birth rate: 6.34 births/1,000 population (1996 est.)
Death rate: 15.92 deaths/1,000 population (1996 est.)
Net migration rate: -18.82 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.11 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 43.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 56.11 years
male: 51.16 years
female: 61.39 years (1996 est.)
Total fertility rate: 1 children born/woman (1996 est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic divisions: Serb 40%, Muslim 38%, Croat 22% (est.)
Religions: Muslim 40%, Orthodox 31%, Catholic 15%, Protestant 4%,
other 10%
Languages: Serbo-Croatian 99%
Literacy: NA
------
Population: 1,477,630 (July 1996 est.)
Age structure:
0-14 years: 42% (male 317,254; female 309,617)
15-64 years: 54% (male 374,572; female 419,991)
65 years and over: 4% (male 22,314; female 33,882) (July 1996 est.)
Population growth rate: 1.63% (1996 est.)
Birth rate: 33.34 births/1,000 population (1996 est.)
Death rate: 17.01 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.89 male(s)/female
65 years and over: 0.66 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 54.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 46.01 years
male: 44.94 years
female: 47.11 years (1996 est.)
Total fertility rate: 4.26 children born/woman (1996 est.)
Nationality:
noun: Motswana (singular), Batswana (plural)
adjective: Motswana (singular), Batswana (plural)
Ethnic divisions: Batswana 95%, Kalanga, Basarwa, and Kgalagadi
4%, white 1%
Religions: indigenous beliefs 50%, Christian 50%
Languages: English (official), Setswana
Literacy: age 15 and over can read and write (1995 est.)
total population: 69.8%
male: 80.5%
female: 59.9%
------
Population: uninhabited
------
Population: 162,661,214 (July 1996 est.)
Age structure:
0-14 years: 31% (male 25,286,278; female 24,422,897)
15-64 years: 65% (male 52,232,435; female 53,094,724)
65 years and over: 4% (male 3,072,720; female 4,552,160) (July 1996
est.)
Population growth rate: 1.16% (1996 est.)
Birth rate: 20.8 births/1,000 population (1996 est.)
Death rate: 9.19 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.68 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 55.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 61.62 years
male: 56.67 years
female: 66.81 years (1996 est.)
Total fertility rate: 2.34 children born/woman (1996 est.)
Nationality:
noun: Brazilian(s)
adjective: Brazilian
Ethnic divisions: white (includes Portuguese, German, Italian,
Spanish, Polish) 55%, mixed white and African 38%, African 6%, other
(includes Japanese, Arab, Amerindian) 1%
Religions: Roman Catholic (nominal) 70%
Languages: Portuguese (official), Spanish, English, French
Literacy: age 15 and over can read and write (1995 est.)
total population: 83.3%
male: 83.3%
female: 83.2%','ff4fa2b73fd5289873d974360e6b66ebdf4d953826a08a72ae128fdb3ed6176d','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f9bbe9c210b0007486cd0d27b642b862e5dcdbd0487b6493b059bf0c26c08db',1996,'MU','Mauritius','people-and-society',53,'------
Population: no indigenous inhabitants
note: there are UK-US military personnel and civilian contractors;
civilian inhabitants, known as the Ilois, evacuated to Mauritius
before construction of UK-US military facilities','95f138a6b876398a3eaa6128a56630d448730554a15f42a83275a62739e5825e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15847881b115d5d143ede53f693fb3332b7b928aebb9d2bd33fb51152c5f392d',1996,'PR','Puerto Rico','people-and-society',58,'------
Population: 13,195 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.29% (1996 est.)
Birth rate: 20.19 births/1,000 population (1996 est.)
Death rate: 6.05 deaths/1,000 population (1996 est.)
Net migration rate: -1.2 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 19.16 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.78 years
male: 70.93 years
female: 74.75 years (1996 est.)
Total fertility rate: 2.26 children born/woman (1996 est.)
Nationality:
noun: British Virgin Islander(s)
adjective: British Virgin Islander
Ethnic divisions: black 90%, white, Asian
Religions: Protestant 86% (Methodist 45%, Anglican 21%, Church of
God 7%, Seventh-Day Adventist 5%, Baptist 4%, Jehovah''s Witnesses
2%, other 2%), Roman Catholic 6%, none 2%, other 6% (1981)
Languages: English (official)
Literacy: age 15 and over can read and write (1991 est.)
total population: 97.8%
male: NA%
female: NA%
------
Population: 12,771 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.28% (1996 est.)
Birth rate: 15.08 births/1,000 population (1996 est.)
Death rate: 9.83 deaths/1,000 population (1996 est.)
Net migration rate: -2.47 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 11.78 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.65 years
male: 73.89 years
female: 77.46 years (1996 est.)
Total fertility rate: 1.93 children born/woman (1996 est.)
Nationality:
noun: Montserratian(s)
adjective: Montserratian
Ethnic divisions: black, Europeans
Religions: Anglican, Methodist, Roman Catholic, Pentecostal,
Seventh-Day Adventist, other Christian denominations
Languages: English
Literacy: age 15 and over has ever attended school (1970 est.)
total population: 97%
male: 97%
female: 97%','49097a853f5b6900e791d054c4e6dd4a90bbcebc5c2fdd24d1302d3fe0d44c8b','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93ae5d99d3842e1761e0b421fa851611ac5be1311f7931496dedc41b40282173',1996,'MY','Malaysia','people-and-society',66,'------
Population: 299,939 (July 1996 est.)
Age structure:
0-14 years: 33% (male 51,266; female 49,194)
15-64 years: 62% (male 98,806; female 88,323)
65 years and over: 5% (male 6,843; female 5,507) (July 1996 est.)
Population growth rate: 2.56% (1996 est.)
Birth rate: 25.5 births/1,000 population (1996 est.)
Death rate: 5.1 deaths/1,000 population (1996 est.)
Net migration rate: 5.18 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.12 male(s)/female
65 years and over: 1.24 male(s)/female
all ages: 1.1 male(s)/female (1996 est.)
Infant mortality rate: 24.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71.39 years
male: 69.82 years
female: 73.04 years (1996 est.)
Total fertility rate: 3.39 children born/woman (1996 est.)
Nationality:
noun: Bruneian(s)
adjective: Bruneian
Ethnic divisions: Malay 64%, Chinese 20%, other 16%
Religions: Muslim (official) 63%, Buddhism 14%, Christian 8%,
indigenous beliefs and other 15% (1981)
Languages: Malay (official), English, Chinese
Literacy: age 15 and over can read and write (1995 est.)
total population: 88.2%
male: 92.6%
female: 83.4%
------
Population: 8,612,757 (July 1996 est.)
Age structure:
0-14 years: 17% (male 769,025; female 732,119)
15-64 years: 68% (male 2,891,197; female 2,923,440)
65 years and over: 15% (male 561,944; female 735,032) (July 1996
est.)
Population growth rate: 0.46% (1996 est.)
Birth rate: 8.33 births/1,000 population (1996 est.)
Death rate: 13.55 deaths/1,000 population (1996 est.)
Net migration rate: 9.81 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.76 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 15.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71 years
male: 67.07 years
female: 75.12 years (1996 est.)
Total fertility rate: 1.17 children born/woman (1996 est.)
Nationality:
noun: Bulgarian(s)
adjective: Bulgarian
Ethnic divisions: Bulgarian 85.3%, Turk 8.5%, Gypsy 2.6%,
Macedonian 2.5%, Armenian 0.3%, Russian 0.2%, other 0.6%
Religions: Bulgarian Orthodox 85%, Muslim 13%, Jewish 0.8%, Roman
Catholic 0.5%, Uniate Catholic 0.2%, Protestant, Gregorian-Armenian,
and other 0.5%
Languages: Bulgarian, secondary languages closely correspond to
ethnic breakdown
Literacy: age 15 and over can read and write (1992 est.)
total population: 98%
male: 99%
female: 97%','f675a48dd3283346f7f88dfea6129f71d6b1fa04969e56246e3f3f55e0a7d36b','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e4dd2caef49cefc7e18bfa53a1c2d65a1e503dd9f81b6dec440eea11441d0b4',1996,'NE','Niger','people-and-society',73,'------
Population: 10,623,323 (July 1996 est.)
Age structure:
0-14 years: 48% (male 2,569,806; female 2,537,106)
15-64 years: 49% (male 2,444,601; female 2,738,726)
65 years and over: 3% (male 145,479; female 187,605) (July 1996 est.)
Population growth rate: 2.53% (1996 est.)
Birth rate: 47.02 births/1,000 population (1996 est.)
Death rate: 19.99 deaths/1,000 population (1996 est.)
Net migration rate: -1.74 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.89 male(s)/female
65 years and over: 0.78 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 117.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 43.21 years
male: 43.46 years
female: 42.95 years (1996 est.)
Total fertility rate: 6.8 children born/woman (1996 est.)
Nationality:
noun: Burkinabe (singular and plural)
adjective: Burkinabe
Ethnic divisions: Mossi about 24%, Gurunsi, Senufo, Lobi, Bobo,
Mande, Fulani
Religions: indigenous beliefs 40%, Muslim 50%, Christian (mainly
Roman Catholic) 10%
Languages: French (official), tribal languages belonging to
Sudanic family, spoken by 90% of the population
Literacy: age 15 and over can read and write (1995 est.)
total population: 19.2%
male: 29.5%
female: 9.2%
------
Population: 45,975,625 (July 1996 est.)
Age structure:
0-14 years: 37% (male 8,637,102; female 8,308,282)
15-64 years: 59% (male 13,577,232; female 13,571,312)
65 years and over: 4% (male 853,403; female 1,028,294) (July 1996
est.)
Population growth rate: 1.84% (1996 est.)
Birth rate: 30.01 births/1,000 population (1996 est.)
Death rate: 11.66 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.83 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 80.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 56.14 years
male: 54.46 years
female: 57.92 years (1996 est.)
Total fertility rate: 3.83 children born/woman (1996 est.)
Nationality:
noun: Burmese (singular and plural)
adjective: Burmese
Ethnic divisions: Burman 68%, Shan 9%, Karen 7%, Rakhine 4%,
Chinese 3%, Mon 2%, Indian 2%, other 5%
Religions: Buddhist 89%, Christian 4% (Baptist 3%, Roman Catholic
1%), Muslim 4%, animist beliefs 1%, other 2%
Languages: Burmese, minority ethnic groups have their own languages
Literacy: age 15 and over can read and write (1995 est.)
total population: 83.1%
male: 88.7%
female: 77.7%
------
Population: 5,943,057 (July 1996 est.)
Age structure:
0-14 years: 47% (male 1,404,375; female 1,398,228)
15-64 years: 50% (male 1,454,545; female 1,527,644)
65 years and over: 3% (male 62,955; female 95,310) (July 1996 est.)
Population growth rate: 1.54% (1996 est.)
Birth rate: 43.02 births/1,000 population (1996 est.)
Death rate: 15.15 deaths/1,000 population (1996 est.)
Net migration rate: -12.47 migrant(s)/1,000 population (1996 est.)
note: in a number of waves since October 1993, hundreds of thousands
of refugees have fled the civil strife between the Hutu and Tutsi
factions in Burundi and crossed into Rwanda, Tanzania, and Zaire;
the refugee flows are continuing in 1996 as the ethnic violence
persists
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.66 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 102.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 49.33 years
male: 48.28 years
female: 50.42 years (1996 est.)
Total fertility rate: 6.55 children born/woman (1996 est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic divisions:
Africans: Hutu (Bantu) 85%, Tutsi (Hamitic) 14%, Twa (Pygmy) 1%
non-Africans: Europeans 3,000, South Asians 2,000
Religions: Christian 67% (Roman Catholic 62%, Protestant 5%),
indigenous beliefs 32%, Muslim 1%
Languages: Kirundi (official), French (official), Swahili (along
Lake Tanganyika and in the Bujumbura area)
Literacy: age 15 and over can read and write (1995 est.)
total population: 35.3%
male: 49.3%
female: 22.5%
------
Population: 10,861,218 (July 1996 est.)
Age structure:
0-14 years: 45% (male 2,505,998; female 2,432,620)
15-64 years: 51% (male 2,579,986; female 3,007,838)
65 years and over: 4% (male 143,759; female 191,017) (July 1996 est.)
Population growth rate: 2.77% (1996 est.)
Birth rate: 43.5 births/1,000 population (1996 est.)
Death rate: 15.78 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.86 male(s)/female
65 years and over: 0.75 male(s)/female
all ages: 0.93 male(s)/female (1996 est.)
Infant mortality rate: 107.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 49.86 years
male: 48.39 years
female: 51.39 years (1996 est.)
Total fertility rate: 5.81 children born/woman (1996 est.)
Nationality:
noun: Cambodian(s)
adjective: Cambodian
Ethnic divisions: Khmer 90%, Vietnamese 5%, Chinese 1%, other 4%
Religions: Theravada Buddhism 95%, other 5%
Languages: Khmer (official), French
Literacy: age 15 and over can read and write (1990 est.)
total population: 35%
male: 48%
female: 22%
------
Population: 14,261,557 (July 1996 est.)
Age structure:
0-14 years: 46% (male 3,295,924; female 3,266,429)
15-64 years: 51% (male 3,602,037; female 3,627,625)
65 years and over: 3% (male 213,176; female 256,366) (July 1996 est.)
Population growth rate: 2.89% (1996 est.)
Birth rate: 42.49 births/1,000 population (1996 est.)
Death rate: 13.56 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.83 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 78.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 52.6 years
male: 51.55 years
female: 53.68 years (1996 est.)
Total fertility rate: 5.99 children born/woman (1996 est.)
Nationality:
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic divisions: Cameroon Highlanders 31%, Equatorial Bantu 19%,
Kirdi 11%, Fulani 10%, Northwestern Bantu 8%, Eastern Nigritic 7%,
other African 13%, non-African less than 1%
Religions: indigenous beliefs 51%, Christian 33%, Muslim 16%
Languages: 24 major African language groups, English (official),
French (official)
Literacy: age 15 and over can read and write (1995 est.)
total population: 63.4%
male: 75%
female: 52.1%
------
Population: 28,820,671 (July 1996 est.)
Age structure:
0-14 years: 21% (male 3,032,458; female 2,889,603)
15-64 years: 67% (male 9,663,955; female 9,660,648)
65 years and over: 12% (male 1,501,542; female 2,072,465) (July 1996
est.)
Population growth rate: 1.06% (1996 est.)
Birth rate: 13.33 births/1,000 population (1996 est.)
Death rate: 7.17 deaths/1,000 population (1996 est.)
Net migration rate: 4.47 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.72 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 6.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 79.07 years
male: 75.67 years
female: 82.65 years (1996 est.)
Total fertility rate: 1.81 children born/woman (1996 est.)
Nationality:
noun: Canadian(s)
adjective: Canadian
Ethnic divisions: British Isles origin 40%, French origin 27%,
other European 20%, indigenous Indian and Eskimo 1.5%, other, mostly
Asian 11.5%
Religions: Roman Catholic 45%, United Church 12%, Anglican 8%,
other 35% (1991)
Languages: English (official), French (official)
Literacy: age 15 and over can read and write (1986 est.)
total population: 97%
male: NA%
female: NA%
------
Population: 449,066 (July 1996 est.)
Age structure:
0-14 years: 50% (male 114,206; female 110,276)
15-64 years: 46% (male 90,593; female 117,485)
65 years and over: 4% (male 6,450; female 10,056) (July 1996 est.)
Population growth rate: 2.93% (1996 est.)
Birth rate: 44.31 births/1,000 population (1996 est.)
Death rate: 8.29 deaths/1,000 population (1996 est.)
Net migration rate: -6.68 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.77 male(s)/female
65 years and over: 0.64 male(s)/female
all ages: 0.89 male(s)/female (1996 est.)
Infant mortality rate: 54.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 63.39 years
male: 61.47 years
female: 65.41 years (1996 est.)
Total fertility rate: 6.12 children born/woman (1996 est.)
Nationality:
noun: Cape Verdean(s)
adjective: Cape Verdean
Ethnic divisions: Creole (mulatto) 71%, African 28%, European 1%
Religions: Roman Catholicism fused with indigenous beliefs
Languages: Portuguese, Crioulo, a blend of Portuguese and West
African words
Literacy: age 15 and over can read and write (1995 est.)
total population: 71.6%
male: 81.4%
female: 63.8%
------
Population: 34,646 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 4.27% (1996 est.)
Birth rate: 14.52 births/1,000 population (1996 est.)
Death rate: 4.98 deaths/1,000 population (1996 est.)
Net migration rate: 33.2 migrant(s)/1,000 population (1996 est.)
note: major destination for Cubans trying to migrate to the US
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 8.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.1 years
male: 75.37 years
female: 78.81 years (1996 est.)
Total fertility rate: 1.4 children born/woman (1996 est.)
Nationality:
noun: Caymanian(s)
adjective: Caymanian
Ethnic divisions: mixed 40%, white 20%, black 20%, expatriates of
various ethnic groups 20%
Religions: United Church (Presbyterian and Congregational),
Anglican, Baptist, Roman Catholic, Church of God, other Protestant
denominations
Languages: English
Literacy: age 15 and over has ever attended school (1970 est.)
total population: 98%
male: 98%
female: 98%
------
Population: 3,274,426 (July 1996 est.)
Age structure:
0-14 years: 44% (male 724,914; female 718,423)
15-64 years: 52% (male 839,118; female 877,069)
65 years and over: 4% (male 53,418; female 61,484) (July 1996 est.)
Population growth rate: 2.08% (1996 est.)
Birth rate: 39.97 births/1,000 population (1996 est.)
Death rate: 17.64 deaths/1,000 population (1996 est.)
Net migration rate: -1.53 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.87 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 111.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 45.86 years
male: 45.03 years
female: 46.71 years (1996 est.)
Total fertility rate: 5.41 children born/woman (1996 est.)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic divisions: Baya 34%, Banda 27%, Sara 10%, Mandjia 21%,
Mboum 4%, M''Baka 4%, Europeans 6,500 (including 3,600 French)
Religions: indigenous beliefs 24%, Protestant 25%, Roman Catholic
25%, Muslim 15%, other 11%
note: animistic beliefs and practices strongly influence the
Christian majority
Languages: French (official), Sangho (lingua franca and national
language), Arabic, Hunsa, Swahili
Literacy: age 15 and over can read and write (1995 est.)
total population: 60%
male: 68.5%
female: 52.4%','ba79e37c2e9319218292d4e7176cf801229affd95785bf017a26b22c075e1782','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92f1fbe1ecd9d1ab14b6fac6ee27a8c308101304c3d6c794dbbd71eb6e652bc7',1996,'NG','Nigeria','people-and-society',86,'------
Population: 6,976,845 (July 1996 est.)
Age structure:
0-14 years: 44% (male 1,543,688; female 1,535,729)
15-64 years: 53% (male 1,807,361; female 1,881,930)
65 years and over: 3% (male 91,998; female 116,139) (July 1996 est.)
Population growth rate: 2.68% (1996 est.)
Birth rate: 44.25 births/1,000 population (1996 est.)
Death rate: 17.44 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.79 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 120.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 47.55 years
male: 45.18 years
female: 50.01 years (1996 est.)
Total fertility rate: 5.84 children born/woman (1996 est.)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic divisions: nonindigenous 150,000, of whom 1,000 are French
north and center: Muslims (Arabs, Toubou, Hadjerai, Fulbe, Kotoko,
Kanembou, Baguirmi, Boulala, Zaghawa, and Maba)
south: non-Muslims (Sara, Ngambaye, Mbaye, Goulaye, Moundang,
Moussei, Massa)
Religions: Muslim 50%, Christian 25%, indigenous beliefs (mostly
animism) 25%
Languages: French (official), Arabic (official), Sara and Sango
(in south), more than 100 different languages and dialects
Literacy: age 15 and over can read and write in French or Arabic
(1995 est.)
total population: 48.1%
male: 62.1%
female: 34.7%','bbb0289cb185a43cd23f2e2277e97704589755006634fe5a1e9bea0674ddf5ab','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e809716ad89e82409ac9c964dfa2c8309fa8455ac36795a491393faf98602c74',1996,'FR','France','people-and-society',93,'------
Population: 14,333,258 (July 1996 est.)
Age structure:
0-14 years: 29% (male 2,071,816; female 2,041,417)
15-64 years: 65% (male 4,599,173; female 4,651,030)
65 years and over: 6% (male 403,019; female 566,803) (July 1996 est.)
Population growth rate: 1.24% (1996 est.)
Birth rate: 18.09 births/1,000 population (1996 est.)
Death rate: 5.68 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 13.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 74.49 years
male: 71.26 years
female: 77.72 years (1996 est.)
Total fertility rate: 2.23 children born/woman (1996 est.)
Nationality:
noun: Chilean(s)
adjective: Chilean
Ethnic divisions: European and European-Indian 95%, Indian 3%,
other 2%
Religions: Roman Catholic 89%, Protestant 11%, Jewish
Languages: Spanish
Literacy: age 15 and over can read and write (1995 est.)
total population: 95.2%
male: 95.4%
female: 95%
------
Population: 1,210,004,956 (July 1996 est.)
Age structure:
0-14 years: 26% (male 167,448,148; female 151,601,650)
15-64 years: 67% (male 421,455,418; female 393,913,510)
65 years and over: 7% (male 35,056,409; female 40,529,821) (July
1996 est.)
Population growth rate: 0.98% (1996 est.)
Birth rate: 17.01 births/1,000 population (1996 est.)
Death rate: 6.92 deaths/1,000 population (1996 est.)
Net migration rate: -0.34 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.11 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 1.07 male(s)/female
65 years and over: 0.86 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 39.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.62 years
male: 68.33 years
female: 71.06 years (1996 est.)
Total fertility rate: 1.81 children born/woman (1996 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic divisions: Han Chinese 91.9%, Zhuang, Uygur, Hui, Yi,
Tibetan, Miao, Manchu, Mongol, Buyi, Korean, and other nationalities
8.1%
Religions: Daoism (Taoism), Buddhism, Muslim 2%-3%, Christian 1%
(est.)
note: officially atheist, but traditionally pragmatic and eclectic
Languages: Standard Chinese or Mandarin (Putonghua, based on the
Beijing dialect), Yue (Cantonese), Wu (Shanghaiese), Minbei
(Fuzhou), Minnan (Hokkien-Taiwanese), Xiang, Gan, Hakka dialects,
minority languages (see Ethnic divisions entry)
Literacy: age 15 and over can read and write (1995 est.)
total population: 81.5%
male: 89.9%
female: 72.7%','3b77189dbe6c60fe067318ba518b9113913a0023bfa152ac352b58f2127e41a9','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99ebc415210a0a06f499f8e0275a1c51bb0a5c10bf2678cf94da2715667e6604',1996,'ID','Indonesia','people-and-society',97,'------
Population: 813 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -8.98% (1996 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Christmas Islander(s)
adjective: Christmas Island
Ethnic divisions: Chinese 61%, Malay 25%, European 11%, other 3%,
no indigenous population
Religions: Buddhist 55%, Christian 15%, Muslim 10%, other 20%
(1991)
Languages: English
------
Population: 125,377 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: 35% (est.)
65 years and over: NA
Population growth rate: 3.34% (1996 est.)
Birth rate: 27.94 births/1,000 population (1996 est.)
Death rate: 6.22 deaths/1,000 population (1996 est.)
Net migration rate: 11.65 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 35.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 67.99 years
male: 66.02 years
female: 69.99 years (1996 est.)
Total fertility rate: 3.96 children born/woman (1996 est.)
Nationality:
noun: Micronesian(s)
adjective: Micronesian; Kosrae(s), Pohnpeian(s), Trukese, Yapese
Ethnic divisions: nine ethnic Micronesian and Polynesian groups
Religions: Roman Catholic 50%, Protestant 47%, other and none 3%
Languages: English (official and common language), Trukese,
Pohnpeian, Yapese, Kosrean
Literacy: age 15 and over can read and write (1980 est.)
total population: 89%
male: 91%
female: 88%
------
Population: no indigenous inhabitants; note - there are 453 US
military personnel (July 1995 est.)
------
Population: 4,463,847 (July 1996 est.)
Age structure:
0-14 years: 26% (male 592,245; female 573,452)
15-64 years: 64% (male 1,381,017; female 1,496,428)
65 years and over: 10% (male 155,908; female 264,797) (July 1996
est.)
Population growth rate: 0.18% (1996 est.)
Birth rate: 16.3 births/1,000 population (1996 est.)
Death rate: 11.75 deaths/1,000 population (1996 est.)
Net migration rate: -2.77 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.59 male(s)/female
all ages: 0.91 male(s)/female (1996 est.)
Infant mortality rate: 47.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 65.14 years
male: 60.77 years
female: 69.73 years (1996 est.)
Total fertility rate: 2.17 children born/woman (1996 est.)
Nationality:
noun: Moldovan(s)
adjective: Moldovan
Ethnic divisions: Moldavian/Romanian 64.5%, Ukrainian 13.8%,
Russian 13%, Gagauz 3.5%, Jewish 1.5%, Bulgarian 2%, other 1.7%
(1989 figures)
note: internal disputes with ethnic Russians and Ukrainians in the
Dniester region and Gagauz Turks in the south
Religions: Eastern Orthodox 98.5%, Jewish 1.5%, Baptist (only
about 1,000 members) (1991)
note: the large majority of churchgoers are ethnic Moldavian
Languages: Moldovan (official, virtually the same as the Romanian
language), Russian, Gagauz (a Turkish dialect)
Literacy: age 15 and over can read and write (1989 est.)
total population: 96%
male: 99%
female: 94%
------
Population: 31,719 (July 1996 est.)
Age structure:
0-14 years: 17% (male 2,737; female 2,685)
15-64 years: 63% (male 9,746; female 10,318)
65 years and over: 20% (male 2,288; female 3,945) (July 1996 est.)
Population growth rate: 0.59% (1996 est.)
Birth rate: 10.66 births/1,000 population (1996 est.)
Death rate: 12.11 deaths/1,000 population (1996 est.)
Net migration rate: 7.38 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.58 male(s)/female
all ages: 0.87 male(s)/female (1996 est.)
Infant mortality rate: 6.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.07 years
male: 74.38 years
female: 81.93 years (1996 est.)
Total fertility rate: 1.7 children born/woman (1996 est.)
Nationality:
noun: Monacan(s) or Monegasque(s)
adjective: Monacan or Monegasque
Ethnic divisions: French 47%, Monegasque 16%, Italian 16%, other
21%
Religions: Roman Catholic 95%
Languages: French (official), English, Italian, Monegasque
Literacy: NA
------
Population: 2,496,617 (July 1996 est.)
Age structure:
0-14 years: 38% (male 486,321; female 471,931)
15-64 years: 58% (male 722,485; female 723,065)
65 years and over: 4% (male 39,704; female 53,111) (July 1996 est.)
Population growth rate: 1.69% (1996 est.)
Birth rate: 25.55 births/1,000 population (1996 est.)
Death rate: 8.65 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.75 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 69.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 60.75 years
male: 58.8 years
female: 62.8 years (1996 est.)
Total fertility rate: 3.04 children born/woman (1996 est.)
Nationality:
noun: Mongolian(s)
adjective: Mongolian
Ethnic divisions: Mongol 90%, Kazak 4%, Chinese 2%, Russian 2%,
other 2%
Religions: predominantly Tibetan Buddhist, Muslim 4%
note: previously limited religious activity because of communist
regime
Languages: Khalkha Mongol 90%, Turkic, Russian, Chinese
Literacy: age 15 and over can read and write (1988 est.)
total population: 82.9%
male: 88.6%
female: 77.2%','cfe20250c6cbd87567ae65f8c3ddf6c80d8d469fcaa103da3f644daf1b832f97','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('697569c4abd4f2c8bfd6f93b297445f9b61c1dc61e9382ca6f62e6945b02b851',1996,'AU','Australia','people-and-society',107,'------
Population: uninhabited
------
Population: 609 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.94% (1996 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Cocos Islander(s)
adjective: Cocos Islander
Ethnic divisions:
West Island: Europeans
Home Island: Cocos Malays
Religions: Sunni Muslim 57%, Christian 22%, other 21% (1981 est.)
Languages: English
------
Population: 36,813,161 (July 1996 est.)
Age structure:
0-14 years: 32% (male 5,948,599; female 5,806,450)
15-64 years: 64% (male 11,496,931; female 11,890,875)
65 years and over: 4% (male 741,788; female 928,518) (July 1996 est.)
Population growth rate: 1.66% (1996 est.)
Birth rate: 21.34 births/1,000 population (1996 est.)
Death rate: 4.65 deaths/1,000 population (1996 est.)
Net migration rate: -0.13 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.8 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 25.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.81 years
male: 69.97 years
female: 75.73 years (1996 est.)
Total fertility rate: 2.35 children born/woman (1996 est.)
Nationality:
noun: Colombian(s)
adjective: Colombian
Ethnic divisions: mestizo 58%, white 20%, mulatto 14%, black 4%,
mixed black-Indian 3%, Indian 1%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy: age 15 and over can read and write (1995 est.)
total population: 91.3%
male: 91.2%
female: 91.4%
------
Population: 569,237 (July 1996 est.)
Age structure:
0-14 years: 48% (male 137,235; female 136,207)
15-64 years: 49% (male 138,447; female 142,058)
65 years and over: 3% (male 7,242; female 8,048) (July 1996 est.)
Population growth rate: 3.55% (1996 est.)
Birth rate: 45.82 births/1,000 population (1996 est.)
Death rate: 10.28 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.9 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 75.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 58.7 years
male: 56.43 years
female: 61.05 years (1996 est.)
Total fertility rate: 6.65 children born/woman (1996 est.)
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic divisions: Antalote, Cafre, Makoa, Oimatsaha, Sakalava
Religions: Sunni Muslim 86%, Roman Catholic 14%
Languages: Arabic (official), French (official), Comoran (a blend
of Swahili and Arabic)
Literacy: age 15 and over can read and write (1995 est.)
total population: 57.3%
male: 64.2%
female: 50.4%
------
Population: 2,527,841 (July 1996 est.)
Age structure:
0-14 years: 43% (male 550,971; female 545,096)
15-64 years: 53% (male 657,035; female 688,441)
65 years and over: 4% (male 34,973; female 51,325) (July 1996 est.)
Population growth rate: 2.19% (1996 est.)
Birth rate: 39.19 births/1,000 population (1996 est.)
Death rate: 17.35 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.68 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 108.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 45.77 years
male: 44.21 years
female: 47.37 years (1996 est.)
Total fertility rate: 5.15 children born/woman (1996 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic divisions:
south: Kongo 48%
north: Sangha 20%, M''Bochi 12%
center: Teke 17%, Europeans 8,500 (mostly French)
Religions: Christian 50%, animist 48%, Muslim 2%
Languages: French (official), African languages (Lingala and
Kikongo are the most widely used)
Literacy: age 15 and over can read and write (1995 est.)
total population: 74.9%
male: 83.1%
female: 67.2%
------
Population: 19,561 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.11% (1996 est.)
Birth rate: 22.87 births/1,000 population (1996 est.)
Death rate: 5.2 deaths/1,000 population (1996 est.)
Net migration rate: -6.58 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 24.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71.14 years
male: 69.2 years
female: 73.1 years (1996 est.)
Total fertility rate: 3.25 children born/woman (1996 est.)
Nationality:
noun: Cook Islander(s)
adjective: Cook Islander
Ethnic divisions: Polynesian (full blood) 81.3%, Polynesian and
European 7.7%, Polynesian and non-European 7.7%, European 2.4%,
other 0.9%
Religions: Christian (majority of populace members of Cook Islands
Christian Church)
Languages: English (official), Maori
Literacy: NA
------
Population: no indigenous inhabitants; note - there are three
meteorologists
------
Population: 206,611,600 (July 1996 est.)
Age structure:
0-14 years: 32% (male 33,354,840; female 32,414,363)
15-64 years: 64% (male 66,385,852; female 66,827,085)
65 years and over: 4% (male 3,380,567; female 4,248,893) (July 1996
est.)
Population growth rate: 1.53% (1996 est.)
Birth rate: 23.67 births/1,000 population (1996 est.)
Death rate: 8.38 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.8 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 63.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 61.64 years
male: 59.51 years
female: 63.88 years (1996 est.)
Total fertility rate: 2.7 children born/woman (1996 est.)
Nationality:
noun: Indonesian(s)
adjective: Indonesian
Ethnic divisions: Javanese 45%, Sundanese 14%, Madurese 7.5%,
coastal Malays 7.5%, other 26%
Religions: Muslim 87%, Protestant 6%, Roman Catholic 3%, Hindu 2%,
Buddhist 1%, other 1% (1985)
Languages: Bahasa Indonesia (official, modified form of Malay),
English, Dutch, local dialects the most widely spoken of which is
Javanese
Literacy: age 15 and over can read and write (1995 est.)
total population: 83.8%
male: 89.6%
female: 78%
------
Population: 187,784 (July 1996 est.)
Age structure:
0-14 years: 30% (male 28,941; female 27,929)
15-64 years: 64% (male 61,263; female 59,673)
65 years and over: 6% (male 4,750; female 5,228) (July 1996 est.)
Population growth rate: 1.72% (1996 est.)
Birth rate: 21.75 births/1,000 population (1996 est.)
Death rate: 4.88 deaths/1,000 population (1996 est.)
Net migration rate: 0.31 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.91 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 13.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 74.35 years
male: 71.06 years
female: 77.8 years (1996 est.)
Total fertility rate: 2.53 children born/woman (1996 est.)
Nationality:
noun: New Caledonian(s)
adjective: New Caledonian
Ethnic divisions: Melanesian 42.5%, European 37.1%, Wallisian
8.4%, Polynesian 3.8%, Indonesian 3.6%, Vietnamese 1.6%, other 3%
Religions: Roman Catholic 60%, Protestant 30%, other 10%
Languages: French, 28 Melanesian-Polynesian dialects
Literacy: age 15 and over can read and write (1976 est.)
total population: 91%
male: 92%
female: 90%
------
Population: 3,547,983 (July 1996 est.)
Age structure:
0-14 years: 23% (male 420,900; female 400,159)
15-64 years: 65% (male 1,161,522; female 1,154,536)
65 years and over: 12% (male 177,182; female 233,684) (July 1996
est.)
Population growth rate: 1.12% (1996 est.)
Birth rate: 15.78 births/1,000 population (1996 est.)
Death rate: 7.72 deaths/1,000 population (1996 est.)
Net migration rate: 3.17 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.76 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 6.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.01 years
male: 73.96 years
female: 80.21 years (1996 est.)
Total fertility rate: 2.01 children born/woman (1996 est.)
Nationality:
noun: New Zealander(s)
adjective: New Zealand
Ethnic divisions: European 88%, Maori 8.9%, Pacific Islander 2.9%,
other 0.2%
Religions: Anglican 24%, Presbyterian 18%, Roman Catholic 15%,
Methodist 5%, Baptist 2%, other Protestant 3%, unspecified or none
33% (1986)
Languages: English (official), Maori
Literacy: age 15 and over can read and write (1980 est.)
total population: 99%
------
Population: 2,209 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -0.68% (1996 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Norfolk Islander(s)
adjective: Norfolk Islander(s)
Ethnic divisions: descendants of the Bounty mutineers, Australian,
New Zealander
Religions: Anglican 39%, Roman Catholic 11.7%, Uniting Church in
Australia 16.4%, Seventh-Day Adventist 4.4%, none 9.2%, unknown
16.9%, other 2.4% (1986)
Languages: English (official), Norfolk a mixture of 18th century
English and ancient Tahitian
------
Population: 10,146 (July 1996 est.)
Age structure:
0-14 years: 36% (male 1,865; female 1,798)
15-64 years: 59% (male 2,831; female 3,162)
65 years and over: 5% (male 227; female 263) (July 1996 est.)
Population growth rate: 1.51% (1996 est.)
Birth rate: 23.95 births/1,000 population (1996 est.)
Death rate: 8.87 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.86 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 27.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 63.34 years
male: 62.15 years
female: 64.59 years (1996 est.)
Total fertility rate: 3.11 children born/woman (1996 est.)
Nationality:
noun: Tuvaluan(s)
adjective: Tuvaluan
Ethnic divisions: Polynesian 96%
Religions: Church of Tuvalu (Congregationalist) 97%, Seventh-Day
Adventist 1.4%, Baha''i 1%, other 0.6%
Languages: Tuvaluan, English
Literacy: NA
------
Population: 20,158,176 (July 1996 est.)
Age structure:
0-14 years: 50% (male 5,006,615; female 4,972,831)
15-64 years: 48% (male 4,842,908; female 4,874,471)
65 years and over: 2% (male 231,156; female 230,195) (July 1996 est.)
Population growth rate: 2.24% (1996 est.)
Birth rate: 45.92 births/1,000 population (1996 est.)
Death rate: 20.72 deaths/1,000 population (1996 est.)
Net migration rate: -2.8 migrant(s)/1,000 population (1996 est.)
note: Uganda is host to refugees from a number of neighboring
countries, including Zaire, Sudan, and Rwanda; probably in excess of
100,000 southern Sudanese fled to Uganda during the past year; many
of the 8,000 Rwandans who took refuge in Uganda have returned home
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 1 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 99.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 40.29 years
male: 39.98 years
female: 40.6 years (1996 est.)
Total fertility rate: 6.61 children born/woman (1996 est.)
Nationality:
noun: Ugandan(s)
adjective: Ugandan
Ethnic divisions: Baganda 17%, Karamojong 12%, Basogo 8%, Iteso
8%, Langi 6%, Rwanda 6%, Bagisu 5%, Acholi 4%, Lugbara 4%, Bunyoro
3%, Batobo 3%, European, Asian, Arab 1%, other 23%
Religions: Roman Catholic 33%, Protestant 33%, Muslim 16%,
indigenous beliefs 18%
Languages: English (official), Luganda, Swahili, Bantu languages,
Nilotic languages
Literacy: age 15 and over can read and write (1995 est.)
total population: 61.8%
male: 73.7%
female: 50.2%
------
Population: 50,864,009 (July 1996 est.)
Age structure:
0-14 years: 20% (male 5,139,034; female 4,936,901)
15-64 years: 66% (male 16,135,671; female 17,433,600)
65 years and over: 14% (male 2,318,629; female 4,900,174) (July 1996
est.)
Population growth rate: -0.4% (1996 est.)
Birth rate: 11.17 births/1,000 population (1996 est.)
Death rate: 15.16 deaths/1,000 population (1996 est.)
Net migration rate: 0.03 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.47 male(s)/female
all ages: 0.86 male(s)/female (1996 est.)
Infant mortality rate: 22.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 66.8 years
male: 61.54 years
female: 72.32 years (1996 est.)
Total fertility rate: 1.6 children born/woman (1996 est.)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic divisions: Ukrainian 73%, Russian 22%, Jewish 1%, other 4%
Religions: Ukrainian Orthodox - Moscow Patriarchate, Ukrainian
Orthodox - Kiev Patriarchate, Ukrainian Autocephalous Orthodox,
Ukrainian Catholic (Uniate), Protestant, Jewish
Languages: Ukrainian, Russian, Romanian, Polish, Hungarian
Literacy: age 15 and over can read and write (1989 est.)
total population: 98%
male: 100%
female: 97%
------
Population: 3,057,337 (July 1996 est.)
Age structure:
0-14 years: 35% (male 542,848; female 519,952)
15-64 years: 64% (male 1,277,829; female 683,282)
65 years and over: 1% (male 22,246; female 11,180) (July 1996 est.)
Population growth rate: 4.33% (1996 est.)
Birth rate: 26.43 births/1,000 population (1996 est.)
Death rate: 3.03 deaths/1,000 population (1996 est.)
Net migration rate: 19.91 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.87 male(s)/female
65 years and over: 1.99 male(s)/female
all ages: 1.52 male(s)/female (1996 est.)
Infant mortality rate: 20.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.74 years
male: 70.64 years
female: 74.94 years (1996 est.)
Total fertility rate: 4.46 children born/woman (1996 est.)
Nationality:
noun: Emiri(s)
adjective: Emiri
Ethnic divisions: Emiri 19%, other Arab and Iranian 23%, South
Asian 50%, other expatriates (includes Westerners and East Asians)
8% (1982)
note: less than 20% are UAE citizens (1982)
Religions: Muslim 96% (Shi''a 16%), Christian, Hindu, and other 4%
Languages: Arabic (official), Persian, English, Hindi, Urdu
Literacy: age 15 and over can read and write but definition of
literacy not available (1995 est.)
total population: 79.2%
male: 78.9%
female: 79.8%
------
Population: 58,489,975 (July 1996 est.)
Age structure:
0-14 years: 20% (male 5,853,545; female 5,565,153)
15-64 years: 65% (male 19,050,420; female 18,797,406)
65 years and over: 15% (male 3,753,361; female 5,470,090) (July 1996
est.)
Population growth rate: 0.22% (1996 est.)
Birth rate: 13.12 births/1,000 population (1996 est.)
Death rate: 11.24 deaths/1,000 population (1996 est.)
Net migration rate: 0.3 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.69 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 6.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 76.41 years
male: 73.78 years
female: 79.17 years (1996 est.)
Total fertility rate: 1.82 children born/woman (1996 est.)
Nationality:
noun: Briton(s), British (collective plural)
adjective: British
Ethnic divisions: English 81.5%, Scottish 9.6%, Irish 2.4%, Welsh
1.9%, Ulster 1.8%, West Indian, Indian, Pakistani, and other 2.8%
Religions: Anglican 27 million, Roman Catholic 9 million, Muslim 1
million, Presbyterian 800,000, Methodist 760,000, Sikh 400,000,
Hindu 350,000, Jewish 300,000 (1991 est.)
note: the UK does not include a question on religion in its census
Languages: English, Welsh (about 26% of the population of Wales),
Scottish form of Gaelic (about 60,000 in Scotland)
Literacy: age 15 and over has completed five or more years of
schooling (1978 est.)
total population: 99%
male: NA%
female: NA%','66ec18fb81ce394e63d96a2d0369ede0b7dda1fb78aa14f566b37da276218752','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb9237b3acbcd1418c125ee774a00327f6c07e846418b4b58206f4df8d460d8e',1996,'PA','Panama','people-and-society',111,'------
Population: 3,463,083 (July 1996 est.)
Age structure:
0-14 years: 35% (male 612,624; female 582,566)
15-64 years: 61% (male 1,061,703; female 1,038,403)
65 years and over: 4% (male 77,773; female 90,014) (July 1996 est.)
Population growth rate: 2.06% (1996 est.)
Birth rate: 23.84 births/1,000 population (1996 est.)
Death rate: 4.14 deaths/1,000 population (1996 est.)
Net migration rate: 0.92 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.86 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 13.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.72 years
male: 73.31 years
female: 78.24 years (1996 est.)
Total fertility rate: 2.9 children born/woman (1996 est.)
Nationality:
noun: Costa Rican(s)
adjective: Costa Rican
Ethnic divisions: white (including mestizo) 96%, black 2%, Indian
1%, Chinese 1%
Religions: Roman Catholic 95%
Languages: Spanish (official), English spoken around Puerto Limon
Literacy: age 15 and over can read and write (1995 est.)
total population: 94.8%
male: 94.7%
female: 95%
------
Population: 14,762,445 (July 1996 est.)
Age structure:
0-14 years: 48% (male 3,552,270; female 3,462,462)
15-64 years: 50% (male 3,828,538; female 3,599,920)
65 years and over: 2% (male 164,358; female 154,897) (July 1996 est.)
Population growth rate: 2.92% (1996 est.)
Birth rate: 42.48 births/1,000 population (1996 est.)
Death rate: 15.7 deaths/1,000 population (1996 est.)
Net migration rate: 2.43 migrant(s)/1,000 population (1996 est.)
note: since 1989, over 350,000 refugees have fled to Cote d''Ivoire
to escape the civil war in Liberia
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.06 male(s)/female
65 years and over: 1.06 male(s)/female
all ages: 1.04 male(s)/female (1996 est.)
Infant mortality rate: 82.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 46.73 years
male: 46.23 years
female: 47.25 years (1996 est.)
Total fertility rate: 6.15 children born/woman (1996 est.)
Nationality:
noun: Ivorian(s)
adjective: Ivorian
Ethnic divisions: Baoule 23%, Bete 18%, Senoufou 15%, Malinke 11%,
Agni, foreign Africans (mostly Burkinabe and Malians, about 3
million), non-Africans 130,000 to 330,000 (French 30,000 and
Lebanese 100,000 to 300,000)
Religions: indigenous 25%, Muslim 60%, Christian 12%
Languages: French (official), 60 native dialects with Dioula the
most widely spoken
Literacy: age 15 and over can read and write (1995 est.)
total population: 40.1%
male: 49.9%
female: 30%
------
Population: 5,004,112 (July 1996 est.)
Age structure:
0-14 years: 18% (male 453,142; female 431,118)
15-64 years: 69% (male 1,731,200; female 1,716,824)
65 years and over: 13% (male 252,897; female 418,931) (July 1996
est.)
Population growth rate: 0.58% (1996 est.)
Birth rate: 9.83 births/1,000 population (1996 est.)
Death rate: 11.33 deaths/1,000 population (1996 est.)
Net migration rate: 7.31 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.6 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 10.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.81 years
male: 69.13 years
female: 76.72 years (1996 est.)
Total fertility rate: 1.4 children born/woman (1996 est.)
Nationality:
noun: Croat(s)
adjective: Croatian
Ethnic divisions: Croat 78%, Serb 12%, Muslim 0.9%, Hungarian
0.5%, Slovenian 0.5%, others 8.1% (1991)
Religions: Catholic 76.5%, Orthodox 11.1%, Slavic Muslim 1.2%,
Protestant 0.4%, others and unknown 10.8%
Languages: Serbo-Croatian 96%, other 4% (including Italian,
Hungarian, Czechoslovak, and German)
Literacy: age 15 and over can read and write (1991 est.)
total population: 97%
male: 99%
female: 95%
------
Population: 10,951,334 (July 1996 est.)
Age structure:
0-14 years: 22% (male 1,256,674; female 1,191,652)
15-64 years: 68% (male 3,753,343; female 3,736,043)
65 years and over: 10% (male 478,630; female 534,992) (July 1996
est.)
Population growth rate: 0.44% (1996 est.)
Birth rate: 13.37 births/1,000 population (1996 est.)
Death rate: 7.39 deaths/1,000 population (1996 est.)
Net migration rate: -1.54 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.9 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.05 years
male: 72.71 years
female: 77.54 years (1996 est.)
Total fertility rate: 1.52 children born/woman (1996 est.)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic divisions: mulatto 51%, white 37%, black 11%, Chinese 1%
Religions: nominally Roman Catholic 85% prior to CASTRO assuming
power; Protestants, Jehovah''s Witnesses, Jews, and Santeria are also
represented
Languages: Spanish
Literacy: age 15 and over can read and write (1995 est.)
total population: 95.7%
male: 96.2%
female: 95.3%
------
Population: 744,609 (July 1996 est.)
Age structure:
0-14 years: 25% (male 97,400; female 92,110)
15-64 years: 64% (male 240,716; female 238,039)
65 years and over: 11% (male 33,340; female 43,004) (July 1996 est.)
Population growth rate: 1.11% (1996 est.)
Birth rate: 15.39 births/1,000 population (1996 est.)
Death rate: 7.66 deaths/1,000 population (1996 est.)
Net migration rate: 3.38 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.78 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 8.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 76.26 years
male: 74.11 years
female: 78.52 years (1996 est.)
Total fertility rate: 2.19 children born/woman (1996 est.)
Nationality:
noun: Cypriot(s)
adjective: Cypriot
Ethnic divisions:
total: Greek 78% (99.5% of the Greeks live in the Greek area; 0.5%
of the Greeks live in the Turkish area), Turkish 18% (1.3% of the
Turks live in the Greek area; 98.7% of the Turks live in the Turkish
area), other 4% (99.2% of the other ethnic groups live in the Greek
area; 0.8% of the other ethnic groups live in the Turkish area)
Religions: Greek Orthodox 78%, Muslim 18%, Maronite, Armenian
Apostolic, and other 4%
Languages: Greek, Turkish, English
Literacy: age 15 and over can read and write (1987 est.)
total population: 94%
male: 98%
female: 91%
------
Population: 10,321,120 (July 1996 est.)
Age structure:
0-14 years: 18% (male 965,861; female 918,745)
15-64 years: 68% (male 3,519,753; female 3,524,913)
65 years and over: 14% (male 526,841; female 865,007) (July 1996
est.)
Population growth rate: -0.03% (1996 est.)
Birth rate: 10.39 births/1,000 population (1996 est.)
Death rate: 10.89 deaths/1,000 population (1996 est.)
Net migration rate: 0.24 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.61 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 8.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 73.76 years
male: 70.08 years
female: 77.65 years (1996 est.)
Total fertility rate: 1.38 children born/woman (1996 est.)
Nationality:
noun: Czech(s)
adjective: Czech
note: 300,000 Slovaks declared themselves Czech citizens in 1994
Ethnic divisions: Czech 94.4%, Slovak 3%, Polish 0.6%, German
0.5%, Gypsy 0.3%, Hungarian 0.2%, other 1%
Religions: atheist 39.8%, Roman Catholic 39.2%, Protestant 4.6%,
Orthodox 3%, other 13.4%
Languages: Czech, Slovak
Literacy: age NA and over can read and write (est.)
total population: 99%
male: NA%
female: NA%
------
Population: 5,249,632 (July 1996 est.)
Age structure:
0-14 years: 17% (male 469,672; female 446,907)
15-64 years: 67% (male 1,789,552; female 1,738,870)
65 years and over: 16% (male 330,396; female 474,235) (July 1996
est.)
Population growth rate: 0.38% (1996 est.)
Birth rate: 12.24 births/1,000 population (1996 est.)
Death rate: 10.42 deaths/1,000 population (1996 est.)
Net migration rate: 2 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.7 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 4.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.3 years
male: 73.78 years
female: 81.01 years (1996 est.)
Total fertility rate: 1.67 children born/woman (1996 est.)
Nationality:
noun: Dane(s)
adjective: Danish
Ethnic divisions: Scandinavian, Eskimo, Faroese, German
Religions: Evangelical Lutheran 91%, other Protestant and Roman
Catholic 2%, other 7% (1988)
Languages: Danish, Faroese, Greenlandic (an Eskimo dialect),
German (small minority)
Literacy: age 15 and over can read and write (1980 est.)
total population: 99%
male: NA%
female: NA%
------
Population: 427,642 (July 1996 est.)
Age structure:
0-14 years: 43% (male 91,687; female 91,242)
15-64 years: 55% (male 123,699; female 110,530)
65 years and over: 2% (male 5,389; female 5,095) (July 1996 est.)
Population growth rate: 1.5% (1996 est.)
Birth rate: 42.5 births/1,000 population (1996 est.)
Death rate: 15.26 deaths/1,000 population (1996 est.)
Net migration rate: -12.28 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.12 male(s)/female
65 years and over: 1.06 male(s)/female
all ages: 1.07 male(s)/female (1996 est.)
Infant mortality rate: 106.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 50.15 years
male: 48.24 years
female: 52.12 years (1996 est.)
Total fertility rate: 6.08 children born/woman (1996 est.)
Nationality:
noun: Djiboutian(s)
adjective: Djiboutian
Ethnic divisions: Somali 60%, Afar 35%, French, Arab, Ethiopian,
and Italian 5%
Religions: Muslim 94%, Christian 6%
Languages: French (official), Arabic (official), Somali, Afar
Literacy: age 15 and over can read and write (1995 est.)
total population: 46.2%
male: 60.3%
female: 32.7%','61e92e68c54e84775eb99844f6f9f404f3962981f11134ef0f4a441be9e510b6','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d78614bbd70410db1d539111e041197bc5b41ed1e582fcf0c0f029fc0eb3924d',1996,'TT','Trinidad and Tobago','people-and-society',119,'------
Population: 82,926 (July 1996 est.)
Age structure:
0-14 years: 28% (male 11,986; female 11,521)
15-64 years: 64% (male 27,206; female 25,841)
65 years and over: 8% (male 2,608; female 3,764) (July 1996 est.)
Population growth rate: 0.38% (1996 est.)
Birth rate: 18.38 births/1,000 population (1996 est.)
Death rate: 5.31 deaths/1,000 population (1996 est.)
Net migration rate: -9.32 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.69 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 9.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.4 years
male: 74.55 years
female: 80.4 years (1996 est.)
Total fertility rate: 1.93 children born/woman (1996 est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic divisions: black, Carib Indians
Religions: Roman Catholic 77%, Protestant 15% (Methodist 5%,
Pentecostal 3%, Seventh-Day Adventist 3%, Baptist 2%, other 2%),
none 2%, unknown 1%, other 5%
Languages: English (official), French patois
Literacy: age 15 and over has ever attended school (1970 est.)
total population: 94%
male: 94%
female: 94%
------
Population: 8,088,881 (July 1996 est.)
Age structure:
0-14 years: 34% (male 1,401,322; female 1,355,530)
15-64 years: 62% (male 2,541,356; female 2,460,509)
65 years and over: 4% (male 156,238; female 173,926) (July 1996 est.)
Population growth rate: 1.73% (1996 est.)
Birth rate: 23.51 births/1,000 population (1996 est.)
Death rate: 5.66 deaths/1,000 population (1996 est.)
Net migration rate: -0.53 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.9 male(s)/female
all ages: 1.03 male(s)/female (1996 est.)
Infant mortality rate: 47.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.06 years
male: 66.89 years
female: 71.34 years (1996 est.)
Total fertility rate: 2.66 children born/woman (1996 est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic divisions: white 16%, black 11%, mixed 73%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy: age 15 and over can read and write (1995 est.)
total population: 82.1%
male: 82%
female: 82.2%
------
Population: 11,466,291 (July 1996 est.)
Age structure:
0-14 years: 35% (male 2,062,468; female 1,996,679)
15-64 years: 60% (male 3,403,197; female 3,489,728)
65 years and over: 5% (male 241,217; female 273,002) (July 1996 est.)
Population growth rate: 1.96% (1996 est.)
Birth rate: 25.06 births/1,000 population (1996 est.)
Death rate: 5.5 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.88 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 34.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71.09 years
male: 68.49 years
female: 73.82 years (1996 est.)
Total fertility rate: 2.89 children born/woman (1996 est.)
Nationality:
noun: Ecuadorian(s)
adjective: Ecuadorian
Ethnic divisions: mestizo (mixed Indian and Spanish) 55%, Indian
25%, Spanish 10%, black 10%
Religions: Roman Catholic 95%
Languages: Spanish (official), Indian languages (especially
Quechua)
Literacy: age 15 and over can read and write (1995 est.)
total population: 90.1%
male: 92%
female: 88.2%
------
Population: 94,961 (July 1996 est.)
Age structure:
0-14 years: 43% (male 20,975; female 20,246)
15-64 years: 52% (male 26,089; female 23,068)
65 years and over: 5% (male 2,112; female 2,471) (July 1996 est.)
Population growth rate: 0.55% (1996 est.)
Birth rate: 29.13 births/1,000 population (1996 est.)
Death rate: 5.74 deaths/1,000 population (1996 est.)
Net migration rate: -17.87 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.13 male(s)/female
65 years and over: 0.86 male(s)/female
all ages: 1.07 male(s)/female (1996 est.)
Infant mortality rate: 11.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 70.89 years
male: 68.39 years
female: 73.44 years (1996 est.)
Total fertility rate: 3.78 children born/woman (1996 est.)
Nationality:
noun: Grenadian(s)
adjective: Grenadian
Ethnic divisions: black African
Religions: Roman Catholic, Anglican, other Protestant sects
Languages: English (official), French patois
Literacy: age 15 and over can read and write (1970 est.)
total population: 98%
male: 98%
female: 98%
------
Population: 407,768 (July 1996 est.)
Age structure:
0-14 years: 26% (male 53,118; female 51,219)
15-64 years: 66% (male 132,846; female 136,147)
65 years and over: 8% (male 14,617; female 19,821) (July 1996 est.)
Population growth rate: 1.2% (1996 est.)
Birth rate: 17.78 births/1,000 population (1996 est.)
Death rate: 5.59 deaths/1,000 population (1996 est.)
Net migration rate: -0.16 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.74 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 8.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.4 years
male: 74.37 years
female: 80.58 years (1996 est.)
Total fertility rate: 1.92 children born/woman (1996 est.)
Nationality:
noun: Guadeloupian(s)
adjective: Guadeloupe
Ethnic divisions: black or mulatto 90%, white 5%, East Indian,
Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan African 4%,
Protestant sects 1%
Languages: French (official) 99%, Creole patois
Literacy: age 15 and over can read and write (1982 est.)
total population: 90%
male: 90%
female: 90%
------
Population: 399,151 (July 1996 est.)
Age structure:
0-14 years: 23% (male 46,851; female 45,300)
15-64 years: 67% (male 132,161; female 135,707)
65 years and over: 10% (male 16,542; female 22,590) (July 1996 est.)
Population growth rate: 1.1% (1996 est.)
Birth rate: 16.92 births/1,000 population (1996 est.)
Death rate: 5.85 deaths/1,000 population (1996 est.)
Net migration rate: -0.1 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.73 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 7.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.81 years
male: 76.07 years
female: 81.68 years (1996 est.)
Total fertility rate: 1.81 children born/woman (1996 est.)
Nationality:
noun: Martiniquais (singular and plural)
adjective: Martiniquais
Ethnic divisions: African and African-white-Indian mixture 90%,
white 5%, East Indian, Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan African 5%
Languages: French, Creole patois
Literacy: age 15 and over can read and write (1982 est.)
total population: 93%
male: 92%
female: 93%
------
Population: 157,862 (July 1996 est.)
Age structure:
0-14 years: 34% (male 27,068; female 26,491)
15-64 years: 61% (male 47,470; female 48,612)
65 years and over: 5% (male 3,136; female 5,085) (July 1996 est.)
Population growth rate: 1.14% (1996 est.)
Birth rate: 22.03 births/1,000 population (1996 est.)
Death rate: 6.02 deaths/1,000 population (1996 est.)
Net migration rate: -4.62 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.62 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 20 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 70.09 years
male: 66.52 years
female: 73.91 years (1996 est.)
Total fertility rate: 2.31 children born/woman (1996 est.)
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic divisions: African descent 90.3%, mixed 5.5%, East Indian
3.2%, white 0.8%
Religions: Roman Catholic 90%, Protestant 7%, Anglican 3%
Languages: English (official), French patois
Literacy: age 15 and over has ever attended school (1980 est.)
total population: 67%
male: 65%
female: 69%
------
Population: 6,809 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.77% (1996 est.)
Birth rate: 12.82 births/1,000 population (1996 est.)
Death rate: 5.7 deaths/1,000 population (1996 est.)
Net migration rate: 0.59 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 9.95 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 76.34 years
male: 74.76 years
female: 78.25 years (1996 est.)
Total fertility rate: 1.65 children born/woman (1996 est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic divisions: Basques and Bretons (French fishermen)
Religions: Roman Catholic 99%
Languages: French
Literacy: age 15 and over can read and write (1982 est.)
total population: 99%
male: 99%
female: 99%
------
Population: 118,344 (July 1996 est.)
Age structure:
0-14 years: 33% (male 19,742; female 19,106)
15-64 years: 62% (male 36,576; female 36,381)
65 years and over: 5% (male 2,702; female 3,837) (July 1996 est.)
Population growth rate: 0.64% (1996 est.)
Birth rate: 19.36 births/1,000 population (1996 est.)
Death rate: 5.4 deaths/1,000 population (1996 est.)
Net migration rate: -7.56 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 16.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.94 years
male: 71.43 years
female: 74.49 years (1996 est.)
Total fertility rate: 2.04 children born/woman (1996 est.)
Nationality:
noun: Saint Vincentian(s) or Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic divisions: African descent, white, East Indian, Carib Indian
Religions: Anglican, Methodist, Roman Catholic, Seventh-Day
Adventist
Languages: English, French patois
Literacy: age 15 and over has ever attended school (1970 est.)
total population: 96%
male: 96%
female: 96%
------
Population: 24,521 (July 1996 est.)
Age structure:
0-14 years: 16% (male 1,978; female 1,967)
15-64 years: 68% (male 8,401; female 8,249)
65 years and over: 16% (male 1,648; female 2,278) (July 1996 est.)
Population growth rate: 0.82% (1996 est.)
Birth rate: 10.81 births/1,000 population (1996 est.)
Death rate: 7.79 deaths/1,000 population (1996 est.)
Net migration rate: 5.14 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.72 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 5.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 81.32 years
male: 77.34 years
female: 85.3 years (1996 est.)
Total fertility rate: 1.52 children born/woman (1996 est.)
Nationality:
noun: Sammarinese (singular and plural)
adjective: Sammarinese
Ethnic divisions: Sammarinese, Italian
Religions: Roman Catholic
Languages: Italian
Literacy: age 10 and over can read and write (1976 est.)
total population: 96%
male: 97%
female: 95%','cf6d10bc1689b361ff94b47b5195890949887b62d1d964608a272c462e13dc7b','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f2dc4159f0c12362618d914d26b95a19e81bfaf7522d1ec581027e5625015b0',1996,'MX','Mexico','people-and-society',127,'------
Population: 63,575,107 (July 1996 est.)
Age structure:
0-14 years: 37% (male 11,970,197; female 11,462,689)
15-64 years: 60% (male 19,127,696; female 18,738,304)
65 years and over: 3% (male 1,028,916; female 1,247,305) (July 1996
est.)
Population growth rate: 1.91% (1996 est.)
Birth rate: 28.18 births/1,000 population (1996 est.)
Death rate: 8.7 deaths/1,000 population (1996 est.)
Net migration rate: -0.35 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.82 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 72.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 61.43 years
male: 59.51 years
female: 63.46 years (1996 est.)
Total fertility rate: 3.58 children born/woman (1996 est.)
Nationality:
noun: Egyptian(s)
adjective: Egyptian
Ethnic divisions: Eastern Hamitic stock (Egyptians, Bedouins, and
Berbers) 99%, Greek, Nubian, Armenian, other European (primarily
Italian and French) 1%
Religions: Muslim (mostly Sunni) 94% (official estimate), Coptic
Christian and other 6% (official estimate)
Languages: Arabic (official), English and French widely understood
by educated classes
Literacy: age 15 and over can read and write (1995 est.)
total population: 51.4%
male: 63.6%
female: 38.8%
------
Population: 5,828,987 (July 1996 est.)
Age structure:
0-14 years: 38% (male 1,137,804; female 1,097,774)
15-64 years: 57% (male 1,627,519; female 1,716,261)
65 years and over: 5% (male 115,973; female 133,656) (July 1996 est.)
Population growth rate: 1.81% (1996 est.)
Birth rate: 28.3 births/1,000 population (1996 est.)
Death rate: 5.81 deaths/1,000 population (1996 est.)
Net migration rate: -4.4 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.87 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 31.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.88 years
male: 65.44 years
female: 72.5 years (1996 est.)
Total fertility rate: 3.2 children born/woman (1996 est.)
Nationality:
noun: Salvadoran(s)
adjective: Salvadoran
Ethnic divisions: mestizo 94%, Indian 5%, white 1%
Religions: Roman Catholic 75%
note: there is extensive activity by Protestant groups throughout
the country; by the end of 1992, there were an estimated 1 million
Protestant evangelicals in El Salvador
Languages: Spanish, Nahua (among some Indians)
Literacy: age 15 and over can read and write (1995 est.)
total population: 71.5%
male: 73.5%
female: 69.8%
------
Population: 431,282 (July 1996 est.)
Age structure:
0-14 years: 43% (male 93,319; female 92,753)
15-64 years: 53% (male 108,706; female 120,129)
65 years and over: 4% (male 7,235; female 9,140) (July 1996 est.)
Population growth rate: 2.58% (1996 est.)
Birth rate: 39.77 births/1,000 population (1996 est.)
Death rate: 14.01 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.79 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 98 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 53.01 years
male: 50.79 years
female: 55.29 years (1996 est.)
Total fertility rate: 5.17 children born/woman (1996 est.)
Nationality:
noun: Equatorial Guinean(s) or Equatoguinean(s)
adjective: Equatorial Guinean or Equatoguinean
Ethnic divisions: Bioko (primarily Bubi, some Fernandinos), Rio
Muni (primarily Fang), Europeans less than 1,000, mostly Spanish
Religions: nominally Christian and predominantly Roman Catholic,
pagan practices
Languages: Spanish (official), pidgin English, Fang, Bubi, Ibo
Literacy: age 15 and over can read and write (1995 est.)
total population: 78.5%
male: 89.6%
female: 68.1%
------
Population: 2,336,048 (July 1996 est.)
Age structure:
0-14 years: 48% (male 568,828; female 562,342)
15-64 years: 49% (male 560,540; female 592,914)
65 years and over: 3% (male 21,753; female 29,671) (July 1996 est.)
Population growth rate: 3.17% (1996 est.)
Birth rate: 46.92 births/1,000 population (1996 est.)
Death rate: 15.24 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.73 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 81.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 49.01 years
male: 46.09 years
female: 52.06 years (1996 est.)
Total fertility rate: 6.84 children born/woman (1996 est.)
Nationality:
noun: Mauritanian(s)
adjective: Mauritanian
Ethnic divisions: mixed Maur/black 40%, Maur 30%, black 30%
Religions: Muslim 100%
Languages: Hasaniya Arabic (official), Pular, Soninke, Wolof
(official)
Literacy: age 15 and over can read and write (1995 est.)
total population: 37.7%
male: 49.6%
female: 26.3%
------
Population: 266,476,278 (July 1996 est.)
Age structure:
0-14 years: 22% (male 29,718,390; female 28,335,934)
15-64 years: 65% (male 86,225,056; female 87,411,573)
65 years and over: 13% (male 13,850,234; female 20,021,655) (July
1996 est.)
Population growth rate: 0.91% (1996 est.)
Birth rate: 14.8 births/1,000 population (1996 est.)
Death rate: 8.8 deaths/1,000 population (1996 est.)
Net migration rate: 3.1 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.69 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 6.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.95 years
male: 72.65 years
female: 79.41 years (1996 est.)
Total fertility rate: 2.06 children born/woman (1996 est.)
Nationality:
noun: American(s)
adjective: American
Ethnic divisions: white 83.4%, black 12.4%, Asian 3.3%, Native
American 0.8% (1992)
Religions: Protestant 56%, Roman Catholic 28%, Jewish 2%, other
4%, none 10% (1989)
Languages: English, Spanish (spoken by a sizable minority)
Literacy: age 15 and over can read and write (1979 est.)
total population: 97%
male: 97%
female: 97%
------
Population: 3,238,952 (July 1996 est.)
Age structure:
0-14 years: 24% (male 405,041; female 386,155)
15-64 years: 63% (male 1,004,089; female 1,035,336)
65 years and over: 13% (male 170,109; female 238,222) (July 1996
est.)
Population growth rate: 0.7% (1996 est.)
Birth rate: 17.02 births/1,000 population (1996 est.)
Death rate: 9.05 deaths/1,000 population (1996 est.)
Net migration rate: -0.99 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.71 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 15.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 74.94 years
male: 71.8 years
female: 78.25 years (1996 est.)
Total fertility rate: 2.32 children born/woman (1996 est.)
Nationality:
noun: Uruguayan(s)
adjective: Uruguayan
Ethnic divisions: white 88%, mestizo 8%, black 4%
Religions: Roman Catholic 66% (less than one-half of the adult
population attends church regularly), Protestant 2%, Jewish 2%,
nonprofessing or other 30%
Languages: Spanish, Brazilero (Portuguese-Spanish mix on the
Brazilian frontier)
Literacy: age 15 and over can read and write (1995 est.)
total population: 97.3%
male: 96.9%
female: 97.7%
------
Population: 23,418,381 (July 1996 est.)
Age structure:
0-14 years: 40% (male 4,732,585; female 4,618,503)
15-64 years: 55% (male 6,441,052; female 6,540,479)
65 years and over: 5% (male 416,571; female 669,191) (July 1996 est.)
Population growth rate: 1.87% (1996 est.)
Birth rate: 29.86 births/1,000 population (1996 est.)
Death rate: 8.02 deaths/1,000 population (1996 est.)
Net migration rate: -3.13 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.62 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 79.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 64.6 years
male: 60.44 years
female: 68.97 years (1996 est.)
Total fertility rate: 3.69 children born/woman (1996 est.)
Nationality:
noun: Uzbek(s)
adjective: Uzbek
Ethnic divisions: Uzbek 71.4%, Russian 8.3%, Tajik 4.7%, Kazak
4.1%, Tatar 2.4%, Karakalpak 2.1%, other 7%
Religions: Muslim 88% (mostly Sunnis), Eastern Orthodox 9%, other
3%
Languages: Uzbek 74.3%, Russian 14.2%, Tajik 4.4%, other 7.1%
Literacy: age 15 and over can read and write (1989 est.)
total population: 97%
male: 98%
female: 96%','6bb59710f5764a27910c7a46e39ded20933638c37977495a4b044c25904c0586','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46b9581968875f0a50e9d405acc6b42acd75789af359674bafc54ddcde3cf899',1996,'CM','Cameroon','people-and-society',139,'------
Population: 3,427,883 (July 1996 est.)
Age structure:
0-14 years: 44% (male 755,417; female 743,135)
15-64 years: 53% (male 910,976; female 913,531)
65 years and over: 3% (male 54,310; female 50,514) (July 1996 est.)
Population growth rate: 2.79% (1996 est.)
Birth rate: 43.32 births/1,000 population (1996 est.)
Death rate: 15.44 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
note: it is estimated that between 300,000 and 500,000 Eritrean
refugees were still living in Sudan at the end of 1995; their
repatriation is being facilitated by the UNHCR
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1.08 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 118.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 50.31 years
male: 48.57 years
female: 52.1 years (1996 est.)
Total fertility rate: 6.5 children born/woman (1996 est.)
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic divisions: ethnic Tigrinya 50%, Tigre and Kunama 40%, Afar
4%, Saho (Red Sea coast dwellers) 3%
Religions: Muslim, Coptic Christian, Roman Catholic, Protestant
Languages: Afar, Amharic, Arabic, Italian, Tigre and Kunama,
Tigrinya, minor tribal languages
------
Population: 1,459,428 (July 1996 est.)
Age structure:
0-14 years: 20% (male 148,683; female 143,563)
15-64 years: 66% (male 467,759; female 501,519)
65 years and over: 14% (male 63,976; female 133,928) (July 1996 est.)
Population growth rate: -1.13% (1996 est.)
Birth rate: 10.74 births/1,000 population (1996 est.)
Death rate: 14.12 deaths/1,000 population (1996 est.)
Net migration rate: -7.96 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.48 male(s)/female
all ages: 0.87 male(s)/female (1996 est.)
Infant mortality rate: 17.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.13 years
male: 62.5 years
female: 74.05 years (1996 est.)
Total fertility rate: 1.55 children born/woman (1996 est.)
Nationality:
noun: Estonian(s)
adjective: Estonian
Ethnic divisions: Estonian 61.5%, Russian 30.3%, Ukrainian 3.2%,
Byelorussian 1.8%, Finn 1.1%, other 2.1% (1989)
Religions: Lutheran, Orthodox Christian
Languages: Estonian (official), Latvian, Lithuanian, Russian, other
Literacy: age 15 and over can read and write (1989 est.)
total population: 100%
male: 100%
female: 100%
------
Population: 57,171,662 (July 1996 est.)
Age structure:
0-14 years: 46% (male 13,116,158; female 13,080,276)
15-64 years: 51% (male 14,782,995; female 14,624,779)
65 years and over: 3% (male 728,808; female 838,646) (July 1996 est.)
Population growth rate: 2.72% (1996 est.)
Birth rate: 46.05 births/1,000 population (1996 est.)
Death rate: 17.53 deaths/1,000 population (1996 est.)
Net migration rate: -1.36 migrant(s)/1,000 population (1996 est.)
note: repatriation of Ethiopians who fled to Sudan, Kenya and
Somalia for refuge from war and famine in earlier years, is expected
to continue in 1996; entry into Ethiopia of Sudanese and Somalis
fleeing the fighting in their own countries is also continuing in
1996
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.87 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 122.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 46.85 years
male: 45.71 years
female: 48.02 years (1996 est.)
Total fertility rate: 7 children born/woman (1996 est.)
Nationality:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic divisions: Oromo 40%, Amhara and Tigrean 32%, Sidamo 9%,
Shankella 6%, Somali 6%, Afar 4%, Gurage 2%, other 1%
Religions: Muslim 45%-50%, Ethiopian Orthodox 35%-40%, animist
12%, other 5%
Languages: Amharic (official), Tigrinya, Orominga, Guaraginga,
Somali, Arabic, English (major foreign language taught in schools)
Literacy: age 15 and over can read and write (1995 est.)
total population: 35.5%
male: 45.5%
female: 25.3%
------
Population: uninhabited','e78c7bfa8f70087b9b16c80476a0fd0ec20b3c7a9ded1f967caaecbf1a094611','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca979c6043f5595d7312b2f53fa30f663b2df062049019e46ba127655bdf238e',1996,'AR','Argentina','people-and-society',142,'------
Population: 2,374 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 2.43% (1996 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Falkland Islander(s)
adjective: Falkland Island
Ethnic divisions: British
Religions: primarily Anglican, Roman Catholic, United Free Church,
Evangelist Church, Jehovah''s Witnesses, Lutheran, Seventh-Day
Adventist
Languages: English
------
Population: 43,857 (July 1996 est.)
Age structure:
0-14 years: 24% (male 5,461; female 5,280)
15-64 years: 62% (male 14,488; female 12,617)
65 years and over: 14% (male 2,661; female 3,350) (July 1996 est.)
Population growth rate: -1.8% (1996 est.)
Birth rate: 13.91 births/1,000 population (1996 est.)
Death rate: 8.69 deaths/1,000 population (1996 est.)
Net migration rate: -23.19 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 0.99 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.15 male(s)/female
65 years and over: 0.79 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 7.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.83 years
male: 74.75 years
female: 80.88 years (1996 est.)
Total fertility rate: 2.38 children born/woman (1996 est.)
Nationality:
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic divisions: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old Norse), Danish
Literacy: NA
------
Population: 782,381 (July 1996 est.)
Age structure:
0-14 years: 35% (male 141,652; female 135,829)
15-64 years: 62% (male 240,621; female 240,620)
65 years and over: 3% (male 11,235; female 12,424) (July 1996 est.)
Population growth rate: 1.28% (1996 est.)
Birth rate: 23.37 births/1,000 population (1996 est.)
Death rate: 6.35 deaths/1,000 population (1996 est.)
Net migration rate: -4.22 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.9 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 17.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 65.71 years
male: 63.39 years
female: 68.14 years (1996 est.)
Total fertility rate: 2.83 children born/woman (1996 est.)
Nationality:
noun: Fijian(s)
adjective: Fijian
Ethnic divisions: Fijian 49%, Indian 46%, European, other Pacific
Islanders, overseas Chinese, and other 5%
Religions: Christian 52% (Methodist 37%, Roman Catholic 9%), Hindu
38%, Muslim 8%, other 2%
note: Fijians are mainly Christian, Indians are Hindu, and there is
a Muslim minority (1986)
Languages: English (official), Fijian, Hindustani
Literacy: age 15 and over can read and write (1995 est.)
total population: 91.6%
male: 93.8%
female: 89.3%
------
Population: 5,105,230 (July 1996 est.)
Age structure:
0-14 years: 19% (male 492,616; female 471,736)
15-64 years: 67% (male 1,725,113; female 1,687,974)
65 years and over: 14% (male 275,927; female 451,864) (July 1996
est.)
Population growth rate: 0.1% (1996 est.)
Birth rate: 11.32 births/1,000 population (1996 est.)
Death rate: 10.92 deaths/1,000 population (1996 est.)
Net migration rate: 0.58 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.61 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 4.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.47 years
male: 73.82 years
female: 77.18 years (1996 est.)
Total fertility rate: 1.68 children born/woman (1996 est.)
Nationality:
noun: Finn(s)
adjective: Finnish
Ethnic divisions: Finn, Swede, Lapp, Gypsy, Tatar
Religions: Evangelical Lutheran 89%, Greek Orthodox 1%, none 9%,
other 1%
Languages: Finnish 93.5% (official), Swedish 6.3% (official),
small Lapp- and Russian-speaking minorities
Literacy: age 15 and over can read and write (1980 est.)
total population: 100%
male: NA%
female: NA%
------
Population: 58,317,450 (July 1996 est.)
Age structure:
0-14 years: 19.04% (male 5,688,505; female 5,417,355)
15-64 years: 65.62% (male 19,147,369; female 19,120,935)
65 years and over: 15.34% (male 3,589,100; female 5,354,186) (July
1996 est.)
Population growth rate: 0.34% (1996 est.)
Birth rate: 10.82 births/1,000 population (1996 est.)
Death rate: 9.27 deaths/1,000 population (1996 est.)
Net migration rate: 1.88 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.67 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 5.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.93 years
male: 73.98 years
female: 82.11 years (1996 est.)
Total fertility rate: 1.49 children born/woman (1996 est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic divisions: Celtic and Latin with Teutonic, Slavic, North
African, Indochinese, Basque minorities
Religions: Roman Catholic 90%, Protestant 2%, Jewish 1%, Muslim
(North African workers) 1%, unaffiliated 6%
Languages: French 100%, rapidly declining regional dialects and
languages (Provencal, Breton, Alsatian, Corsican, Catalan, Basque,
Flemish)
Literacy: age 15 and over can read and write (1980 est.)
total population: 99%
male: NA%
female: NA%
------
Population: 151,187 (July 1996 est.)
Age structure:
0-14 years: 32% (male 24,447; female 23,378)
15-64 years: 63% (male 52,061; female 43,726)
65 years and over: 5% (male 3,784; female 3,791) (July 1996 est.)
Population growth rate: 3.86% (1996 est.)
Birth rate: 24.68 births/1,000 population (1996 est.)
Death rate: 4.59 deaths/1,000 population (1996 est.)
Net migration rate: 18.52 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.19 male(s)/female
65 years and over: 1 male(s)/female
all ages: 1.13 male(s)/female (1996 est.)
Infant mortality rate: 14.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.79 years
male: 72.55 years
female: 79.19 years (1996 est.)
Total fertility rate: 3.42 children born/woman (1996 est.)
Nationality:
noun: French Guianese (singular and plural)
adjective: French Guianese
Ethnic divisions: black or mulatto 66%, white 12%, East Indian,
Chinese, Amerindian 12%, other 10%
Religions: Roman Catholic
Languages: French
Literacy: age 15 and over can read and write (1982 est.)
total population: 83%
male: 84%
female: 82%
------
Population: no indigenous population; there is a small military
garrison on South Georgia, and the British Antarctic Survey has a
biological station on Bird Island; the South Sandwich Islands are
uninhabited','9961d5afba800419a8ebc54be72b0034808eb6ecd6497bb39187e17b934593ea','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5726e6ba6029f6257810f31db06a92a197cc5b0080207e791c222034c88903da',1996,'NR','Nauru','people-and-society',147,'------
Population: 224,911 (July 1996 est.)
Age structure:
0-14 years: 35% (male 40,450; female 39,038)
15-64 years: 61% (male 70,506; female 65,620)
65 years and over: 4% (male 4,636; female 4,661) (July 1996 est.)
Population growth rate: 2.19% (1996 est.)
Birth rate: 27.15 births/1,000 population (1996 est.)
Death rate: 5.27 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.07 male(s)/female
65 years and over: 1 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 14.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 70.94 years
male: 68.49 years
female: 73.5 years (1996 est.)
Total fertility rate: 3.26 children born/woman (1996 est.)
Nationality:
noun: French Polynesian(s)
adjective: French Polynesian
Ethnic divisions: Polynesian 78%, Chinese 12%, local French 6%,
metropolitan French 4%
Religions: Protestant 54%, Roman Catholic 30%, other 16%
Languages: French (official), Tahitian (official)
Literacy: age 14 and over can read and write, but definition of
literacy not available (1977 est.)
total population: 98%
male: 98%
female: 98%
------
Population: no indigenous inhabitants; note - there were 145
(1995) mostly researchers whose numbers vary from winter (July) to
summer (January)
------
Population: 1,172,798 (July 1996 est.)
Age structure:
0-14 years: 34% (male 197,188; female 196,562)
15-64 years: 61% (male 364,033; female 353,451)
65 years and over: 5% (male 30,270; female 31,294) (July 1996 est.)
Population growth rate: 1.47% (1996 est.)
Birth rate: 28.22 births/1,000 population (1996 est.)
Death rate: 13.56 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.97 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 90.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 55.59 years
male: 52.72 years
female: 58.56 years (1996 est.)
Total fertility rate: 3.89 children born/woman (1996 est.)
Nationality:
noun: Gabonese (singular and plural)
adjective: Gabonese
Ethnic divisions: Bantu tribes including four major tribal
groupings (Fang, Eshira, Bapounou, Bateke), other Africans and
Europeans 100,000, including 27,000 French
Religions: Christian 55%-75%, Muslim less than 1%, animist
Languages: French (official), Fang, Myene, Bateke,
Bapounou/Eschira, Bandjabi
Literacy: age 15 and over can read and write (1995 est.)
total population: 63.2%
male: 73.7%
female: 53.3%
------
Population: 923,940 (July 1996 est.)
note: in addition, there are 5,000 Israeli settlers in the Gaza
Strip (August 1995 est.)
Age structure:
0-14 years: 52% (male 244,026; female 231,976)
15-64 years: 46% (male 210,706; female 210,764)
65 years and over: 2% (male 11,553; female 14,915) (July 1996 est.)
Population growth rate: 6.79% (1996 est.)
Birth rate: 50.67 births/1,000 population (1996 est.)
Death rate: 4.4 deaths/1,000 population (1996 est.)
Net migration rate: 21.65 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.78 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 27.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71.98 years
male: 70.69 years
female: 73.34 years (1996 est.)
Total fertility rate: 7.79 children born/woman (1996 est.)
Nationality:
noun: NA
adjective: NA
Ethnic divisions: Palestinian Arab and other 99.4%, Jewish 0.6%
Religions: Muslim (predominantly Sunni) 98.7%, Christian 0.7%,
Jewish 0.6%
Languages: Arabic, Hebrew (spoken by Israeli settlers), English
(widely understood)
Literacy: NA
------
Population: 5,219,810 (July 1996 est.)
Age structure:
0-14 years: 22% (male 595,524; female 571,207)
15-64 years: 66% (male 1,643,506; female 1,784,286)
65 years and over: 12% (male 229,910; female 395,377) (July 1996
est.)
Population growth rate: -1.02% (1996 est.)
Birth rate: 12.81 births/1,000 population (1996 est.)
Death rate: 12.21 deaths/1,000 population (1996 est.)
Net migration rate: -10.82 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.58 male(s)/female
all ages: 0.9 male(s)/female (1996 est.)
Infant mortality rate: 22.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.09 years
male: 63.43 years
female: 72.98 years (1996 est.)
Total fertility rate: 1.69 children born/woman (1996 est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
Ethnic divisions: Georgian 70.1%, Armenian 8.1%, Russian 6.3%,
Azeri 5.7%, Ossetian 3%, Abkhaz 1.8%, other 5%
Religions: Christian Orthodox 75% (Georgian Orthodox 65%, Russian
Orthodox 10%), Muslim 11%, Armenian Apostolic 8%, unknown 6%
Languages: Armenian 7%, Azeri 6%, Georgian 71% (official), Russian
9%, other 7%
Literacy: age 15 and over can read and write (1989 est.)
total population: 99%
male: 100%
female: 98%','e2cd5acb166e9162b84c4ffda8ce2aeb1624565aec4731a35de3d0a72d45e632','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2202a99aea916b1fae43779f9700c907cf07a55e9c3f8e1fa99dead52c95ff9',1996,'DK','Denmark','people-and-society',157,'------
Population: 83,536,115 (July 1996 est.)
Age structure:
0-14 years: 16.15% (male 6,928,750; female 6,563,026)
15-64 years: 68.52% (male 29,339,780; female 27,902,549)
65 years and over: 15.33% (male 4,658,014; female 8,143,996) (July
1996 est.)
Population growth rate: 0.67% (1996 est.)
Birth rate: 9.66 births/1,000 population (1996 est.)
Death rate: 12.21 deaths/1,000 population (1996 est.)
Net migration rate: 8.25 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.57 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.95 years
male: 72.8 years
female: 79.27 years (1996 est.)
Total fertility rate: 1.3 children born/woman (1996 est.)
Nationality:
noun: German(s)
adjective: German
Ethnic divisions: German 95.1%, Turkish 2.3%, Italians 0.7%,
Greeks 0.4%, Poles 0.4%, other 1.1% (made up largely of people
fleeing the war in the former Yugoslavia)
Religions: Protestant 45%, Roman Catholic 37%, unaffiliated or
other 18%
Languages: German
Literacy: age 15 and over can read and write (1977 est.)
total population: 99%
male: NA%
female: NA%
------
Population: 17,698,271 (July 1996 est.)
Age structure:
0-14 years: 43% (male 3,856,673; female 3,819,946)
15-64 years: 54% (male 4,658,142; female 4,814,060)
65 years and over: 3% (male 262,159; female 287,291) (July 1996 est.)
Population growth rate: 2.29% (1996 est.)
Birth rate: 35 births/1,000 population (1996 est.)
Death rate: 11.15 deaths/1,000 population (1996 est.)
Net migration rate: -0.94 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.91 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 80.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 56.17 years
male: 54.18 years
female: 58.22 years (1996 est.)
Total fertility rate: 4.59 children born/woman (1996 est.)
Nationality:
noun: Ghanaian(s)
adjective: Ghanaian
Ethnic divisions: black African 99.8% (major tribes - Akan 44%,
Moshi-Dagomba 16%, Ewe 13%, Ga 8%), European and other 0.2%
Religions: indigenous beliefs 38%, Muslim 30%, Christian 24%,
other 8%
Languages: English (official), African languages (including Akan,
Moshi-Dagomba, Ewe, and Ga)
Literacy: age 15 and over can read and write (1995 est.)
total population: 64.5%
male: 75.9%
female: 53.5%
------
Population: 28,765 (July 1996 est.)
Age structure:
0-14 years: 20% (male 3,109; female 2,728)
15-64 years: 66% (male 10,668; female 8,292)
65 years and over: 14% (male 1,582; female 2,386) (July 1996 est.)
Population growth rate: 0.54% (1996 est.)
Birth rate: 13.94 births/1,000 population (1996 est.)
Death rate: 8.73 deaths/1,000 population (1996 est.)
Net migration rate: 0.21 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.14 male(s)/female
15-64 years: 1.29 male(s)/female
65 years and over: 0.66 male(s)/female
all ages: 1.15 male(s)/female (1996 est.)
Infant mortality rate: 6.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.83 years
male: 74.5 years
female: 81.31 years (1996 est.)
Total fertility rate: 2.26 children born/woman (1996 est.)
Nationality:
noun: Gibraltarian(s)
adjective: Gibraltar
Ethnic divisions: Italian, English, Maltese, Portuguese, Spanish
Religions: Roman Catholic 74%, Protestant 11% (Church of England
8%, other 3%), Muslim 8%, Jewish 2%, none or other 5% (1981)
Languages: English (used in schools and for official purposes),
Spanish, Italian, Portuguese, Russian
Literacy: NA
------
Population: uninhabited
------
Population: 10,538,594 (July 1996 est.)
Age structure:
0-14 years: 16% (male 899,029; female 837,308)
15-64 years: 68% (male 3,571,918; female 3,542,556)
65 years and over: 16% (male 736,818; female 950,965) (July 1996
est.)
Population growth rate: 0.42% (1996 est.)
Birth rate: 9.78 births/1,000 population (1996 est.)
Death rate: 9.53 deaths/1,000 population (1996 est.)
Net migration rate: 3.98 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.78 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 7.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.1 years
male: 75.6 years
female: 80.78 years (1996 est.)
Total fertility rate: 1.37 children born/woman (1996 est.)
Nationality:
noun: Greek(s)
adjective: Greek
Ethnic divisions: Greek 98%, other 2%
note: the Greek Government states there are no ethnic divisions in
======================================================================
@Greenland
---------
(part of the Danish realm)
Map
---
Location: 72 00 N, 40 00 W -- Northern North America, island
between the Arctic Ocean and the North Atlantic Ocean, northeast of','3d15fb39856ed084fa57f9459c9c24d306f83f3106e5c1de0f24b263fba2f743','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deafd2302e84f46801a85e88efe0c8992f3dd972f2740089a2163b19a6b4d67e',1996,'CA','Canada','people-and-society',161,'Flag
----
Description: two equal horizontal bands of white (top) and red
with a large disk slightly to the hoist side of center - the top
half of the disk is red, the bottom half is white
------
Population: 58,203 (July 1996 est.)
Age structure:
0-14 years: 27% (male 7,871; female 7,723)
15-64 years: 68% (male 21,755; female 17,961)
65 years and over: 5% (male 1,307; female 1,586) (July 1996 est.)
Population growth rate: 1% (1996 est.)
Birth rate: 17.06 births/1,000 population (1996 est.)
Death rate: 7.11 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1.21 male(s)/female
65 years and over: 0.82 male(s)/female
all ages: 1.13 male(s)/female (1996 est.)
Infant mortality rate: 23.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.24 years
male: 63.97 years
female: 72.53 years (1996 est.)
Total fertility rate: 2.22 children born/woman (1996 est.)
Nationality:
noun: Greenlander(s)
adjective: Greenlandic
Ethnic divisions: Greenlander 86% (Eskimos and Greenland-born
whites), Danish 14%
Religions: Evangelical Lutheran
Languages: Eskimo dialects, Danish
Literacy: NA','9116a84a7e37fb2cf091501e84f2c575abb47e1121fdfed0a36e87f2aa0a5f89','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0730a11a6e4ef38a51578399c85bda5db8bd34ddc7bd645ee011358ee8f72d5',1996,'PH','Philippines','people-and-society',172,'------
Population: 156,974 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 2.34% (1996 est.)
Birth rate: 24.24 births/1,000 population (1996 est.)
Death rate: 3.86 deaths/1,000 population (1996 est.)
Net migration rate: 3 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 15.17 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 74.29 years
male: 72.42 years
female: 76.13 years (1996 est.)
Total fertility rate: 2.25 children born/woman (1996 est.)
Nationality:
noun: Guamanian(s)
adjective: Guamanian
Ethnic divisions: Chamorro 47%, Filipino 25%, white 10%, Chinese,
Japanese, Korean, and other 18%
Religions: Roman Catholic 98%, other 2%
Languages: English, Chamorro, Japanese
Literacy: age 15 and over can read and write (1990 est.)
total population: 99%
male: 99%
female: 99%
------
Population: 11,277,614 (July 1996 est.)
Age structure:
0-14 years: 43% (male 2,464,498; female 2,362,457)
15-64 years: 54% (male 3,026,834; female 3,031,278)
65 years and over: 3% (male 184,927; female 207,620) (July 1996 est.)
Population growth rate: 2.48% (1996 est.)
Birth rate: 33.96 births/1,000 population (1996 est.)
Death rate: 7.15 deaths/1,000 population (1996 est.)
Net migration rate: -1.98 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.89 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 50.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 65.24 years
male: 62.64 years
female: 67.97 years (1996 est.)
Total fertility rate: 4.5 children born/woman (1996 est.)
Nationality:
noun: Guatemalan(s)
adjective: Guatemalan
Ethnic divisions: Mestizo - mixed Amerindian-Spanish ancestry (in
local Spanish called Ladino) 56%, Amerindian or predominantly
Amerindian 44%
Religions: Roman Catholic, Protestant, traditional Mayan
Languages: Spanish 60%, Indian language 40% (23 Indian dialects,
including Quiche, Cakchiquel, Kekchi)
Literacy: age 15 and over can read and write (1995 est.)
total population: 55.6%
male: 62.5%
female: 48.6%
------
Population: 62,920 (July 1996 est.)
Age structure:
0-14 years: 18% (male 5,592; female 5,439)
15-64 years: 67% (male 20,636; female 21,472)
65 years and over: 15% (male 3,925; female 5,856) (July 1996 est.)
Population growth rate: 1.28% (1996 est.)
Birth rate: 13.06 births/1,000 population (1996 est.)
Death rate: 9.73 deaths/1,000 population (1996 est.)
Net migration rate: 9.44 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.67 male(s)/female
all ages: 0.92 male(s)/female (1996 est.)
Infant mortality rate: 9.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.22 years
male: 75.28 years
female: 81.27 years (1996 est.)
Total fertility rate: 1.56 children born/woman (1996 est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic divisions: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Presbyterian, Baptist,
Congregational, Methodist
Languages: English, French, Norman-French dialect spoken in
country districts
Literacy: NA
------
Population: 7,411,981 (July 1996 est.)
Age structure:
0-14 years: 44% (male 1,632,414; female 1,637,007)
15-64 years: 53% (male 1,928,586; female 2,013,343)
65 years and over: 3% (male 84,005; female 116,626) (July 1996 est.)
Population growth rate: 1.85% (1996 est.)
Birth rate: 42.59 births/1,000 population (1996 est.)
Death rate: 18.71 deaths/1,000 population (1996 est.)
Net migration rate: -5.4 migrant(s)/1,000 population (1996 est.)
note: in prior years Guinea received several hundred thousand
refugees from the civil wars in Liberia and Sierra Leone, many of
whom are now returning to their own countries
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.72 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 134.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 45.06 years
male: 42.73 years
female: 47.47 years (1996 est.)
Total fertility rate: 5.72 children born/woman (1996 est.)
Nationality:
noun: Guinean(s)
adjective: Guinean
Ethnic divisions: Peuhl 40%, Malinke 30%, Soussou 20%, smaller
tribes 10%
Religions: Muslim 85%, Christian 8%, indigenous beliefs 7%
Languages: French (official), each tribe has its own language
Literacy: age 15 and over can read and write (1995 est.)
total population: 35.9%
male: 49.9%
female: 21.9%
------
Population: 1,151,330 (July 1996 est.)
Age structure:
0-14 years: 43% (male 247,471; female 246,725)
15-64 years: 54% (male 295,132; female 329,681)
65 years and over: 3% (male 15,603; female 16,718) (July 1996 est.)
Population growth rate: 2.35% (1996 est.)
Birth rate: 39.7 births/1,000 population (1996 est.)
Death rate: 16.23 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.93 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 115.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 48.28 years
male: 46.63 years
female: 49.99 years (1996 est.)
Total fertility rate: 5.34 children born/woman (1996 est.)
Nationality:
noun: Guinea-Bissauan(s)
adjective: Guinea-Bissauan
Ethnic divisions: African 99% (Balanta 30%, Fula 20%, Manjaca 14%,
Mandinga 13%, Papel 7%), European and mulatto less than 1%
Religions: indigenous beliefs 65%, Muslim 30%, Christian 5%
Languages: Portuguese (official), Criolo, African languages
Literacy: age 15 and over can read and write (1995 est.)
total population: 54.9%
male: 68%
female: 42.5%
------
Population: 712,091 (July 1996 est.)
Age structure:
0-14 years: 33% (male 118,796; female 114,327)
15-64 years: 63% (male 224,219; female 222,562)
65 years and over: 4% (male 14,582; female 17,605) (July 1996 est.)
Population growth rate: -0.9% (1996 est.)
Birth rate: 19.03 births/1,000 population (1996 est.)
Death rate: 9.55 deaths/1,000 population (1996 est.)
Net migration rate: -18.47 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.83 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 51.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 60.1 years
male: 57.55 years
female: 62.78 years (1996 est.)
Total fertility rate: 2.19 children born/woman (1996 est.)
Nationality:
noun: Guyanese (singular and plural)
adjective: Guyanese
Ethnic divisions: East Indian 51%, black and mixed 43%, Amerindian
4%, European and Chinese 2%
Religions: Christian 57%, Hindu 33%, Muslim 9%, other 1%
Languages: English, Amerindian dialects
Literacy: age 15 and over has ever attended school (1995 est.)
total population: 98.1%
male: 98.6%
female: 97.5%
------
Population: 6,731,539 (July 1996 est.)
Age structure:
0-14 years: 46% (male 1,568,943; female 1,523,406)
15-64 years: 50% (male 1,614,679; female 1,758,388)
65 years and over: 4% (male 132,460; female 133,663) (July 1996 est.)
Population growth rate: 1.77% (1996 est.)
Birth rate: 38.15 births/1,000 population (1996 est.)
Death rate: 15.96 deaths/1,000 population (1996 est.)
Net migration rate: -4.52 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.99 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 103.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 49.26 years
male: 47.26 years
female: 51.35 years (1996 est.)
Total fertility rate: 5.69 children born/woman (1996 est.)
Nationality:
noun: Haitian(s)
adjective: Haitian
Ethnic divisions: black 95%, mulatto and European 5%
Religions: Roman Catholic 80% (of which an overwhelming majority
also practice Voodoo), Protestant 16% (Baptist 10%, Pentecostal 4%,
Adventist 1%, other 1%), none 1%, other 3% (1982)
Languages: French (official) 10%, Creole
Literacy: age 15 and over can read and write (1995 est.)
total population: 45%
male: 48%
female: 42.2%
------
Population: 52,284 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 3.04% (1996 est.)
Birth rate: 33.05 births/1,000 population (1996 est.)
Death rate: 4.61 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 37.96 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 67.43 years
male: 65.53 years
female: 69.48 years (1996 est.)
Total fertility rate: 2.69 children born/woman (1996 est.)
Nationality:
noun: NA
adjective: NA
Ethnic divisions: Chamorro, Carolinians and other Micronesians,
Caucasian, Japanese, Chinese, Korean
Religions: Christian (Roman Catholic majority, although
traditional beliefs and taboos may still be found)
Languages: English, Chamorro, Carolinian
note: 86% of population speaks a language other than English at home
Literacy: age 15 and over can read and write (1980 est.)
total population: 97%
male: 97%
female: 96%
------
Population: 4,383,807 (July 1996 est.)
Age structure:
0-14 years: 19% (male 434,848; female 411,668)
15-64 years: 65% (male 1,446,746; female 1,396,150)
65 years and over: 16% (male 288,789; female 405,606) (July 1996
est.)
Population growth rate: 0.48% (1996 est.)
Birth rate: 11.96 births/1,000 population (1996 est.)
Death rate: 10.68 deaths/1,000 population (1996 est.)
Net migration rate: 3.57 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.71 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 4.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.53 years
male: 74.63 years
female: 80.61 years (1996 est.)
Total fertility rate: 1.63 children born/woman (1996 est.)
Nationality:
noun: Norwegian(s)
adjective: Norwegian
Ethnic divisions: Germanic (Nordic, Alpine, Baltic), Lapps (Sami)
20,000
Religions: Evangelical Lutheran 87.8% (state church), other
Protestant and Roman Catholic 3.8%, none 3.2%, unknown 5.2% (1980)
Languages: Norwegian (official)
note: small Lapp- and Finnish-speaking minorities
Literacy: age 15 and over can read and write (1976 est.)
total population: 99%
male: NA%
female: NA%
------
Population: 2,186,548 (July 1996 est.)
Age structure:
0-14 years: 46% (male 511,664; female 493,369)
15-64 years: 51% (male 609,423; female 513,042)
65 years and over: 3% (male 26,623; female 32,427) (July 1996 est.)
Population growth rate: 3.53% (1996 est.)
Birth rate: 37.86 births/1,000 population (1996 est.)
Death rate: 4.44 deaths/1,000 population (1996 est.)
Net migration rate: 1.84 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.19 male(s)/female
65 years and over: 0.82 male(s)/female
all ages: 1.1 male(s)/female (1996 est.)
Infant mortality rate: 27.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 70.53 years
male: 68.59 years
female: 72.57 years (1996 est.)
Total fertility rate: 6.09 children born/woman (1996 est.)
Nationality:
noun: Omani(s)
adjective: Omani
Ethnic divisions: Arab, Baluchi, South Asian (Indian, Pakistani,
Sri Lankan, Bangladeshi), African
Religions: Ibadhi Muslim 75%, Sunni Muslim, Shi''a Muslim, Hindu
Languages: Arabic (official), English, Baluchi, Urdu, Indian
dialects
Literacy: NA
------
Population: 129,275,660 (July 1996 est.)
Age structure:
0-14 years: 42% (male 28,286,823; female 26,640,019)
15-64 years: 53% (male 35,396,281; female 33,733,798)
65 years and over: 5% (male 2,621,721; female 2,597,018) (July 1996
est.)
Population growth rate: 2.24% (1996 est.)
Birth rate: 36.16 births/1,000 population (1996 est.)
Death rate: 11.22 deaths/1,000 population (1996 est.)
Net migration rate: -2.6 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 1.01 male(s)/female
all ages: 1.05 male(s)/female (1996 est.)
Infant mortality rate: 96.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 58.46 years
male: 57.7 years
female: 59.25 years (1996 est.)
Total fertility rate: 5.25 children born/woman (1996 est.)
Nationality:
noun: Pakistani(s)
adjective: Pakistani
Ethnic divisions: Punjabi, Sindhi, Pashtun (Pathan), Baloch,
Muhajir (immigrants from India and their descendants)
Religions: Muslim 97% (Sunni 77%, Shi''a 20%), Christian, Hindu,
and other 3%
Languages: Punjabi 48%, Sindhi 12%, Siraiki (a Punjabi variant)
10%, Pashtu 8%, Urdu (official) 8%, Balochi 3%, Hindko 2%, Brahui
1%, English (official and lingua franca of Pakistani elite and most
government ministries), Burushaski, and other 8%
Literacy: age 15 and over can read and write (1995 est.)
total population: 37.8%
male: 50%
female: 24.4%
------
Population: 16,952 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.71% (1996 est.)
Birth rate: 21.61 births/1,000 population (1996 est.)
Death rate: 6.61 deaths/1,000 population (1996 est.)
Net migration rate: 2.12 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 25.07 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71.01 years
male: 69.14 years
female: 73.02 years (1996 est.)
Total fertility rate: 2.79 children born/woman (1996 est.)
Nationality:
noun: Palauan(s)
adjective: Palauan
Ethnic divisions: Palauans are a composite of Polynesian, Malayan,
and Melanesian races
Religions: Christian (Catholics, Seventh-Day Adventists, Jehovah''s
Witnesses, the Assembly of God, the Liebenzell Mission, and
Latter-Day Saints), Modekngei religion (one-third of the population
observes this religion which is indigenous to Palau)
Languages: English (official in all of Palau''s 16 states),
Sonsorolese (official in the state of Sonsoral), Angaur and Japanese
(in the state of Anguar), Tobi (in the state of Tobi), Palauan (in
the other 13 states)
Literacy: age 15 and over can read and write (1980 est.)
total population: 92%
male: 93%
female: 90%
------
Population: uninhabited','ac79608245ff73a6023bdb80f4994b6e18a7fd8550099b1ee6dd41ce0a729756','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14583614085cf980499344bd43a74a58f762a9692e6fca6770094b8a1c86284e',1996,'AQ','Antarctica','people-and-society',181,'------
Population: uninhabited
------
Population: 840 (July 1996 est.)
Population growth rate: 1.15% (1996 est.)
Nationality:
noun: none
adjective: none
Ethnic divisions: Italians, Swiss
Religions: Roman Catholic
Languages: Italian, Latin, various other languages
------
Population: 5,605,193 (July 1996 est.)
Age structure:
0-14 years: 43% (male 1,220,188; female 1,177,725)
15-64 years: 54% (male 1,496,625; female 1,520,918)
65 years and over: 3% (male 91,126; female 98,611) (July 1996 est.)
Population growth rate: 2.6% (1996 est.)
Birth rate: 33.38 births/1,000 population (1996 est.)
Death rate: 5.83 deaths/1,000 population (1996 est.)
Net migration rate: -1.53 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.92 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 41.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.42 years
male: 66.01 years
female: 70.96 years (1996 est.)
Total fertility rate: 4.41 children born/woman (1996 est.)
Nationality:
noun: Honduran(s)
adjective: Honduran
Ethnic divisions: mestizo (mixed Indian and European) 90%, Indian
7%, black 2%, white 1%
Religions: Roman Catholic 97%, Protestant minority
Languages: Spanish, Indian dialects
Literacy: age 15 and over can read and write (1995 est.)
total population: 72.7%
male: 72.6%
female: 72.7%
------
Population: 6,305,413 (July 1996 est.)
Age structure:
0-14 years: 19% (male 609,493; female 593,687)
15-64 years: 70% (male 2,312,141; female 2,094,156)
65 years and over: 11% (male 307,186; female 388,750) (July 1996
est.)
Population growth rate: 1.77% (1996 est.)
Birth rate: 10.5 births/1,000 population (1996 est.)
Death rate: 5.23 deaths/1,000 population (1996 est.)
Net migration rate: 12.42 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.1 male(s)/female
65 years and over: 0.79 male(s)/female
all ages: 1.05 male(s)/female (1996 est.)
Infant mortality rate: 5.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 82.19 years
male: 78.88 years
female: 85.71 years (1996 est.)
Total fertility rate: 1.3 children born/woman (1996 est.)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic divisions: Chinese 95%, other 5%
Religions: eclectic mixture of local religions 90%, Christian 10%
Languages: Chinese (Cantonese), English
Literacy: age 15 and over has ever attended school (1995 est.)
total population: 92.2%
male: 96%
female: 88.2%
------
Population: uninhabited; note - American civilians evacuated in
1942 after Japanese air and naval attacks during World War II;
occupied by US military during World War II, but abandoned after the
war; public entry is by special-use permit only and generally
restricted to scientists and educators
------
Population: 10,002,541 (July 1996 est.)
Age structure:
0-14 years: 18% (male 907,963; female 867,536)
15-64 years: 68% (male 3,325,529; female 3,464,588)
65 years and over: 14% (male 538,106; female 898,819) (July 1996
est.)
Population growth rate: -0.68% (1996 est.)
Birth rate: 10.72 births/1,000 population (1996 est.)
Death rate: 15.06 deaths/1,000 population (1996 est.)
Net migration rate: -2.48 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.6 male(s)/female
all ages: 0.91 male(s)/female (1996 est.)
Infant mortality rate: 12.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.02 years
male: 64.23 years
female: 74.04 years (1996 est.)
Total fertility rate: 1.51 children born/woman (1996 est.)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Ethnic divisions: Hungarian 89.9%, Gypsy 4%, German 2.6%, Serb 2%,
Slovak 0.8%, Romanian 0.7%
Religions: Roman Catholic 67.5%, Calvinist 20%, Lutheran 5%,
atheist and other 7.5%
Languages: Hungarian 98.2%, other 1.8%
Literacy: age 15 and over can read and write (1980 est.)
total population: 99%
male: 99%
female: 98%
------
Population: 270,292 (July 1996 est.)
note: population data estimates based on average growth rate may
differ slightly from official population data because of volatile
migration rates
Age structure:
0-14 years: 24% (male 33,605; female 31,933)
15-64 years: 64% (male 88,064; female 85,724)
65 years and over: 12% (male 13,916; female 17,050) (July 1996 est.)
Population growth rate: 0.83% (1996 est.)
Birth rate: 16.94 births/1,000 population (1996 est.)
Death rate: 6.17 deaths/1,000 population (1996 est.)
Net migration rate: -2.5 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.82 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 4.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 80.08 years
male: 77.68 years
female: 82.6 years (1996 est.)
Total fertility rate: 2.24 children born/woman (1996 est.)
Nationality:
noun: Icelander(s)
adjective: Icelandic
Ethnic divisions: homogeneous mixture of descendants of Norwegians
and Celts
Religions: Evangelical Lutheran 96%, other Protestant and Roman
Catholic 3%, none 1% (1988)
Languages: Icelandic
Literacy: age 15 and over can read and write (1976 est.)
total population: 100%
male: NA%
female: NA%
------
Population: 952,107,694 (July 1996 est.)
Age structure:
0-14 years: 34% (male 168,030,766; female 159,283,151)
15-64 years: 62% (male 304,805,787; female 281,311,834)
65 years and over: 4% (male 19,148,385; female 19,527,771) (July
1996 est.)
Population growth rate: 1.64% (1996 est.)
Birth rate: 25.94 births/1,000 population (1996 est.)
Death rate: 9.61 deaths/1,000 population (1996 est.)
Net migration rate: 0.04 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.08 male(s)/female
65 years and over: 0.98 male(s)/female
all ages: 1.07 male(s)/female (1996 est.)
Infant mortality rate: 71.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 59.71 years
male: 59.12 years
female: 60.32 years (1996 est.)
Total fertility rate: 3.2 children born/woman (1996 est.)
Nationality:
noun: Indian(s)
adjective: Indian
Ethnic divisions: Indo-Aryan 72%, Dravidian 25%, Mongoloid and
other 3%
Religions: Hindu 80%, Muslim 14%, Christian 2.4%, Sikh 2%,
Buddhist 0.7%, Jains 0.5%, other 0.4%
Languages: English enjoys associate status but is the most
important language for national, political, and commercial
communication, Hindi the national language and primary tongue of 30%
of the people, Bengali (official), Telugu (official), Marathi
(official), Tamil (official), Urdu (official), Gujarati (official),
Malayalam (official), Kannada (official), Oriya (official), Punjabi
(official), Assamese (official), Kashmiri (official), Sindhi
(official), Sanskrit (official), Hindustani a popular variant of
Hindu/Urdu, is spoken widely throughout northern India
note: 24 languages each spoken by a million or more persons;
numerous other languages and dialects, for the most part mutually
unintelligible
Literacy: age 15 and over can read and write (1995 est.)
total population: 52%
male: 65.5%
female: 37.7%','0736a8be2ece184082bf92b3de724596067897515cd3f40c2d5f94f8db3189a9','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a93ff7f856103b4da4815bd9e6ee003e93628c576b7072cc7615b0d178bf464',1996,'AF','Afghanistan','people-and-society',189,'------
Population: 66,094,264 (July 1996 est.)
Age structure:
0-14 years: 45% (male 15,166,131; female 14,289,283)
15-64 years: 52% (male 17,326,388; female 16,731,470)
65 years and over: 3% (male 1,327,718; female 1,253,274) (July 1996
est.)
Population growth rate: 2.21% (1996 est.)
Birth rate: 33.67 births/1,000 population (1996 est.)
Death rate: 6.61 deaths/1,000 population (1996 est.)
Net migration rate: -5 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 1.06 male(s)/female
all ages: 1.05 male(s)/female (1996 est.)
Infant mortality rate: 52.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 67.39 years
male: 66.12 years
female: 68.72 years (1996 est.)
Total fertility rate: 4.72 children born/woman (1996 est.)
Nationality:
noun: Iranian(s)
adjective: Iranian
Ethnic divisions: Persian 51%, Azerbaijani 24%, Gilaki and
Mazandarani 8%, Kurd 7%, Arab 3%, Lur 2%, Baloch 2%, Turkmen 2%,
other 1%
Religions: Shi''a Muslim 89%, Sunni Muslim 10%, Zoroastrian,
Jewish, Christian, and Baha''i 1%
Languages: Persian and Persian dialects 58%, Turkic and Turkic
dialects 26%, Kurdish 9%, Luri 2%, Baloch 1%, Arabic 1%, Turkish 1%,
other 2%
Literacy: age 15 and over can read and write (1994 est.)
total population: 72.1%
male: 78.4%
female: 65.8%
------
Population: 21,422,292 (July 1996 est.)
Age structure:
0-14 years: 48% (male 5,179,240; female 5,014,141)
15-64 years: 49% (male 5,342,529; female 5,228,802)
65 years and over: 3% (male 307,097; female 350,483) (July 1996 est.)
Population growth rate: 3.69% (1996 est.)
Birth rate: 43.07 births/1,000 population (1996 est.)
Death rate: 6.57 deaths/1,000 population (1996 est.)
Net migration rate: 0.37 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.88 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 60 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 66.95 years
male: 65.92 years
female: 68.03 years (1996 est.)
Total fertility rate: 6.41 children born/woman (1996 est.)
Nationality:
noun: Iraqi(s)
adjective: Iraqi
Ethnic divisions: Arab 75%-80%, Kurdish 15%-20%, Turkoman,
Assyrian or other 5%
Religions: Muslim 97% (Shi''a 60%-65%, Sunni 32%-37%), Christian or
other 3%
Languages: Arabic, Kurdish (official in Kurdish regions),
Assyrian, Armenian
Literacy: age 15 and over can read and write (1995 est.)
total population: 58%
male: 70.7%
female: 45%
------
Population: 3,566,833 (July 1996 est.)
Age structure:
0-14 years: 23% (male 424,558; female 402,062)
15-64 years: 65% (male 1,175,383; female 1,157,960)
65 years and over: 12% (male 173,150; female 233,720) (July 1996
est.)
Population growth rate: -0.22% (1996 est.)
Birth rate: 13.22 births/1,000 population (1996 est.)
Death rate: 8.93 deaths/1,000 population (1996 est.)
Net migration rate: -6.46 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.74 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 6.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.58 years
male: 72.88 years
female: 78.46 years (1996 est.)
Total fertility rate: 1.83 children born/woman (1996 est.)
Nationality:
noun: Irishman(men), Irishwoman(men), Irish (collective plural)
adjective: Irish
Ethnic divisions: Celtic, English
Religions: Roman Catholic 93%, Anglican 3%, none 1%, unknown 2%,
other 1% (1981)
Languages: Irish (Gaelic), spoken mainly in areas located along
the western seaboard, English is the language generally used
Literacy: age 15 and over can read and write (1981 est.)
total population: 98%
male: NA%
female: NA%
------
Population: 5,421,995 (July 1996 est.)
note: includes 127,600 Israeli settlers in the West Bank, 14,800 in
the Israeli-occupied Golan Heights, 5,000 in the Gaza Strip, and
153,700 in East Jerusalem (August 1995 est.)
Age structure:
0-14 years: 29% (male 793,712; female 756,735)
15-64 years: 62% (male 1,670,082; female 1,669,481)
65 years and over: 9% (male 230,082; female 301,903) (July 1996 est.)
Population growth rate: 2.11% (1996 est.)
Birth rate: 20.31 births/1,000 population (1996 est.)
Death rate: 6.26 deaths/1,000 population (1996 est.)
Net migration rate: 7.03 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 8.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.01 years
male: 76.16 years
female: 79.96 years (1996 est.)
Total fertility rate: 2.77 children born/woman (1996 est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
Ethnic divisions: Jewish 82% (Israel-born 50%,
Europe/Americas/Oceania-born 20%, Africa-born 7%, Asia-born 5%),
non-Jewish 18% (mostly Arab) (1993 est.)
Religions: Judaism 82%, Islam 14% (mostly Sunni Muslim), Christian
2%, Druze and other 2%
Languages: Hebrew (official), Arabic used officially for Arab
minority, English most commonly used foreign language
Literacy: age 15 and over can read and write (1992 est.)
total population: 95%
male: 97%
female: 93%
------
Population: 57,460,274 (July 1996 est.)
Age structure:
0-14 years: 15% (male 4,419,636; female 4,167,860)
15-64 years: 68% (male 19,656,546; female 19,629,291)
65 years and over: 17% (male 3,902,426; female 5,684,515) (July 1996
est.)
Population growth rate: 0.13% (1996 est.)
Birth rate: 9.87 births/1,000 population (1996 est.)
Death rate: 9.82 deaths/1,000 population (1996 est.)
Net migration rate: 1.25 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.69 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 6.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.06 years
male: 74.85 years
female: 81.48 years (1996 est.)
Total fertility rate: 1.27 children born/woman (1996 est.)
Nationality:
noun: Italian(s)
adjective: Italian
Ethnic divisions: Italian (includes small clusters of German-,
French-, and Slovene-Italians in the north and Albanian-Italians and
Greek-Italians in the south), Sicilians, Sardinians
Religions: Roman Catholic 98%, other 2%
Languages: Italian, German (parts of Trentino-Alto Adige region
are predominantly German speaking), French (small French-speaking
minority in Valle d''Aosta region), Slovene (Slovene-speaking
minority in the Trieste-Gorizia area)
Literacy: age 15 and over can read and write (1990 est.)
total population: 97%
male: 98%
female: 96%
------
Population: 2,595,275 (July 1996 est.)
Age structure:
0-14 years: 32% (male 430,609; female 411,966)
15-64 years: 61% (male 781,626; female 795,808)
65 years and over: 7% (male 77,725; female 97,541) (July 1996 est.)
Population growth rate: 0.8% (1996 est.)
Birth rate: 22.19 births/1,000 population (1996 est.)
Death rate: 5.57 deaths/1,000 population (1996 est.)
Net migration rate: -8.58 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.8 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 15.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 74.88 years
male: 72.6 years
female: 77.29 years (1996 est.)
Total fertility rate: 2.45 children born/woman (1996 est.)
Nationality:
noun: Jamaican(s)
adjective: Jamaican
Ethnic divisions: African 76.3%, Afro-European 15.1%, East Indian
and Afro-East Indian 3%, white 3.2%, Chinese and Afro-Chinese 1.2%,
other 1.2%
Religions: Protestant 55.9% (Church of God 18.4%, Baptist 10%,
Anglican 7.1%, Seventh-Day Adventist 6.9%, Pentecostal 5.2%,
Methodist 3.1%, United Church 2.7%, other 2.5%), Roman Catholic 5%,
other, including some spiritual cults 39.1% (1982)
Languages: English, Creole
Literacy: age 15 and over has ever attended school (1995 est.)
total population: 85%
male: 80.8%
female: 89.1%
------
Population: no permanent inhabitants; note - there are personnel
who man the Long Range Navigation (LORAN) C base and the weather and
coastal services radio station
------
Population: 125,449,703 (July 1996 est.)
Age structure:
0-14 years: 16% (male 10,121,414; female 9,644,243)
15-64 years: 69% (male 43,624,464; female 43,359,249)
65 years and over: 15% (male 7,737,781; female 10,962,552) (July
1996 est.)
Population growth rate: 0.21% (1996 est.)
Birth rate: 10.19 births/1,000 population (1996 est.)
Death rate: 7.71 deaths/1,000 population (1996 est.)
Net migration rate: -0.4 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.71 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 4.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 79.55 years
male: 76.57 years
female: 82.68 years (1996 est.)
Total fertility rate: 1.46 children born/woman (1996 est.)
Nationality:
noun: Japanese (singular and plural)
adjective: Japanese
Ethnic divisions: Japanese 99.4%, other 0.6% (mostly Korean)
Religions: observe both Shinto and Buddhist 84%, other 16%
(including Christian 0.7%)
Languages: Japanese
Literacy: age 15 and over can read and write (1970 est.)
total population: 99%
male: NA%
female: NA%
------
Population: uninhabited; note - Millersville settlement on western
side of island occasionally used as a weather station from 1935
until World War II, when it was abandoned; reoccupied in 1957 during
the International Geophysical Year by scientists who left in 1958;
public entry is by special-use permit only and generally restricted
to scientists and educators
------
Population: 87,848 (July 1996 est.)
Age structure:
0-14 years: 17% (male 7,787; female 7,284)
15-64 years: 69% (male 29,928; female 30,395)
65 years and over: 14% (male 5,107; female 7,347) (July 1996 est.)
Population growth rate: 0.77% (1996 est.)
Birth rate: 12.93 births/1,000 population (1996 est.)
Death rate: 9.21 deaths/1,000 population (1996 est.)
Net migration rate: 4.01 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.11 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 2.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.36 years
male: 75.63 years
female: 81.39 years (1996 est.)
Total fertility rate: 1.5 children born/woman (1996 est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic divisions: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Baptist, Congregational New
Church, Methodist, Presbyterian
Languages: English (official), French (official), Norman-French
dialect spoken in country districts
Literacy: NA
------
Population: no indigenous inhabitants; note - there are 1,200 US
military and civilian contractor personnel (July 1996 est.)
------
Population: 4,212,152 (July 1996 est.)
Age structure:
0-14 years: 44% (male 949,822; female 903,043)
15-64 years: 53% (male 1,153,360; female 1,091,416)
65 years and over: 3% (male 57,783; female 56,728) (July 1996 est.)
Population growth rate: 2.65% (1996 est.)
Birth rate: 36.67 births/1,000 population (1996 est.)
Death rate: 3.95 deaths/1,000 population (1996 est.)
Net migration rate: -6.23 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.06 male(s)/female
65 years and over: 1.02 male(s)/female
all ages: 1.05 male(s)/female (1996 est.)
Infant mortality rate: 31.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.48 years
male: 70.62 years
female: 74.45 years (1996 est.)
Total fertility rate: 5.1 children born/woman (1996 est.)
Nationality:
noun: Jordanian(s)
adjective: Jordanian
Ethnic divisions: Arab 98%, Circassian 1%, Armenian 1%
Religions: Sunni Muslim 92%, Christian 8%
Languages: Arabic (official), English widely understood among
upper and middle classes
Literacy: age 15 and over can read and write (1995 est.)
total population: 86.6%
male: 93.4%
female: 79.4%
------
Population: uninhabited
------
Population: 16,916,463 (July 1996 est.)
Age structure:
0-14 years: 30% (male 2,576,204; female 2,486,937)
15-64 years: 63% (male 5,203,035; female 5,451,404)
65 years and over: 7% (male 384,341; female 814,542) (July 1996 est.)
Population growth rate: -0.15% (1996 est.)
Birth rate: 19.02 births/1,000 population (1996 est.)
Death rate: 9.65 deaths/1,000 population (1996 est.)
Net migration rate: -10.88 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.47 male(s)/female
all ages: 0.93 male(s)/female (1996 est.)
Infant mortality rate: 63.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 64.09 years
male: 58.56 years
female: 69.9 years (1996 est.)
Total fertility rate: 2.36 children born/woman (1996 est.)
Nationality:
noun: Kazakstani(s)
adjective: Kazakstani
Ethnic divisions: Kazak (Qazaq) 41.9%, Russian 37%, Ukrainian
5.2%, German 4.7%, Uzbek 2.1%, Tatar 2%, other 7.1% (1991 official
data)
Religions: Muslim 47%, Russian Orthodox 44%, Protestant 2%, other
7%
Languages: Kazak (Qazaqz) official language spoken by over 40% of
population, Russian (language of interethnic communication) spoken
by two-thirds of population and used in everyday business
Literacy: age 15 and over can read and write (1989 est.)
total population: 98%
male: 99%
female: 96%
------
Population: 28,176,686 (July 1996 est.)
Age structure:
0-14 years: 45% (male 6,362,160; female 6,226,333)
15-64 years: 53% (male 7,413,876; female 7,448,733)
65 years and over: 2% (male 328,649; female 396,935) (July 1996 est.)
Population growth rate: 2.27% (1996 est.)
Birth rate: 33.38 births/1,000 population (1996 est.)
Death rate: 10.3 deaths/1,000 population (1996 est.)
Net migration rate: -0.35 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.83 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 55.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 55.61 years
male: 55.53 years
female: 55.69 years (1996 est.)
Total fertility rate: 4.45 children born/woman (1996 est.)
Nationality:
noun: Kenyan(s)
adjective: Kenyan
Ethnic divisions: Kikuyu 22%, Luhya 14%, Luo 13%, Kalenjin 12%,
Kamba 11%, Kisii 6%, Meru 6%, Asian, European, and Arab 1%, other 15%
Religions: Protestant (including Anglican) 38%, Roman Catholic
28%, indigenous beliefs 26%, other 8%
Languages: English (official), Swahili (official), numerous
indigenous languages
Literacy: age 15 and over can read and write (1995 est.)
total population: 78.1%
male: 86.3%
female: 70%
------
Population: uninhabited
------
Population: 80,919 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.89% (1996 est.)
Birth rate: 27.13 births/1,000 population (1996 est.)
Death rate: 7.9 deaths/1,000 population (1996 est.)
Net migration rate: -0.31 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 52.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 62.02 years
male: 60.25 years
female: 64.03 years (1996 est.)
Total fertility rate: 3.21 children born/woman (1996 est.)
Nationality:
noun: I-Kiribati (singular and plural)
adjective: I-Kiribati
Ethnic divisions: Micronesian
Religions: Roman Catholic 52.6%, Protestant (Congregational)
40.9%, Seventh-Day Adventist, Baha''i, Church of God, Mormon 6% (1985)
Languages: English (official), Gilbertese
Literacy: NA
------
Population: 23,904,124 (July 1996 est.)
Age structure:
0-14 years: 30% (male 3,605,972; female 3,465,038)
15-64 years: 66% (male 7,871,783; female 7,956,935)
65 years and over: 4% (male 355,284; female 649,112) (July 1996 est.)
Population growth rate: 1.74% (1996 est.)
Birth rate: 22.86 births/1,000 population (1996 est.)
Death rate: 5.45 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.55 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 25.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 70.32 years
male: 67.23 years
female: 73.57 years (1996 est.)
Total fertility rate: 2.31 children born/woman (1996 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic divisions: racially homogeneous
Religions: Buddhism and Confucianism, some Christianity and
syncretic Chondogyo
note: autonomous religious activities now almost nonexistent;
government-sponsored religious groups exist to provide illusion of
religious freedom
Languages: Korean
Literacy: age 15 and over can read and write Korean (1990 est.)
total population: 99%
male: 99%
female: 99%
------
Population: 45,482,291 (July 1996 est.)
Age structure:
0-14 years: 23% (male 5,531,032; female 4,962,915)
15-64 years: 71% (male 16,374,678; female 15,910,846)
65 years and over: 6% (male 1,014,649; female 1,688,171) (July 1996
est.)
Population growth rate: 1.02% (1996 est.)
Birth rate: 16.24 births/1,000 population (1996 est.)
Death rate: 5.66 deaths/1,000 population (1996 est.)
Net migration rate: -0.35 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.14 male(s)/female
under 15 years: 1.11 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.6 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 8.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 73.26 years
male: 69.65 years
female: 77.39 years (1996 est.)
Total fertility rate: 1.77 children born/woman (1996 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic divisions: homogeneous (except for about 20,000 Chinese)
Religions: Christianity 48.6%, Buddhism 47.4%, Confucianism 3%,
pervasive folk religion (shamanism), Chondogyo (Religion of the
Heavenly Way) 0.2%
Languages: Korean, English widely taught in high school
Literacy: age 15 and over can read and write (1995 est.)
total population: 98%
male: 99.3%
female: 96.7%
------
Population: 1,950,047 (July 1996 est.)
Age structure:
0-14 years: 33% (male 334,778; female 317,241)
15-64 years: 65% (male 757,535; female 507,064)
65 years and over: 2% (male 18,459; female 14,970) (July 1996 est.)
Population growth rate: 6.65% (1996 est.)
note: this rate reflects the continued post-Gulf crisis return of
nationals and expatriates
Birth rate: 20.28 births/1,000 population (1996 est.)
Death rate: 2.2 deaths/1,000 population (1996 est.)
Net migration rate: 48.46 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.49 male(s)/female
65 years and over: 1.23 male(s)/female
all ages: 1.32 male(s)/female (1996 est.)
Infant mortality rate: 11.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.92 years
male: 73.59 years
female: 78.38 years (1996 est.)
Total fertility rate: 2.82 children born/woman (1996 est.)
Nationality:
noun: Kuwaiti(s)
adjective: Kuwaiti
Ethnic divisions: Kuwaiti 45%, other Arab 35%, South Asian 9%,
Iranian 4%, other 7%
Religions: Muslim 85% (Shi''a 30%, Sunni 45%, other 10%),
Christian, Hindu, Parsi, and other 15%
Languages: Arabic (official), English widely spoken
Literacy: age 15 and over can read and write (1995 est.)
total population: 78.6%
male: 82.2%
female: 74.9%
------
Population: 4,529,648 (July 1996 est.)
Age structure:
0-14 years: 37% (male 847,859; female 828,889)
15-64 years: 57% (male 1,263,044; female 1,312,040)
65 years and over: 6% (male 100,524; female 177,292) (July 1996 est.)
Population growth rate: 0.07% (1996 est.)
Birth rate: 26.02 births/1,000 population (1996 est.)
Death rate: 8.83 deaths/1,000 population (1996 est.)
Net migration rate: -16.5 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.57 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 77.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 63.86 years
male: 59.18 years
female: 68.77 years (1996 est.)
Total fertility rate: 3.22 children born/woman (1996 est.)
Nationality:
noun: Kyrgyz(s)
adjective: Kyrgyz
Ethnic divisions: Kirghiz 52.4%, Russian 21.5%, Uzbek 12.9%,
Ukrainian 2.5%, German 2.4%, other 8.3%
Religions: Muslim NA%, Russian Orthodox NA%
Languages: Kirghiz (Kyrgyz) - official language, Russian -
official language
note: in March 1996, the Kyrgyz legislature amended the constitution
to make Russian an official language, along with Kyrgyz, in
territories and work places where Russian-speaking citizens
predominate
Literacy: age 15 and over can read and write (1989 est.)
total population: 97%
male: 99%
female: 96%','b3c16aa160d8cc635829746b71a65d7664eaef1026ccf9dc93c8fb4164944fb0','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4554ae6e91f38aaba2d23d83be5421e5f80cac488ed2c96c084d85934c4aa0a2',1996,'TH','Thailand','people-and-society',204,'------
Population: 4,975,772 (July 1996 est.)
Age structure:
0-14 years: 45% (male 1,142,825; female 1,114,628)
15-64 years: 51% (male 1,237,660; female 1,316,591)
65 years and over: 4% (male 75,748; female 88,320) (July 1996 est.)
Population growth rate: 2.81% (1996 est.)
Birth rate: 41.94 births/1,000 population (1996 est.)
Death rate: 13.83 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.86 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 96.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 52.69 years
male: 51.14 years
female: 54.31 years (1996 est.)
Total fertility rate: 5.87 children born/woman (1996 est.)
Nationality:
noun: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic divisions: Lao Loum (lowland) 68%, Lao Theung (upland) 22%,
Lao Soung (highland) including the Hmong ("Meo") and the Yao (Mien)
9%, ethnic Vietnamese/Chinese 1%
Religions: Buddhist 60%, animist and other 40%
Languages: Lao (official), French, English, and various ethnic
languages
Literacy: age 15 and over can read and write (1995 est.)
total population: 56.6%
male: 69.4%
female: 44.4%
------
Population: 2,468,982 (July 1996 est.)
Age structure:
0-14 years: 20% (male 254,664; female 244,502)
15-64 years: 66% (male 775,690; female 848,128)
65 years and over: 14% (male 108,814; female 237,184) (July 1996
est.)
Population growth rate: -1.39% (1996 est.)
Birth rate: 10.94 births/1,000 population (1996 est.)
Death rate: 15.19 deaths/1,000 population (1996 est.)
Net migration rate: -9.69 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.46 male(s)/female
all ages: 0.86 male(s)/female (1996 est.)
Infant mortality rate: 21.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 66.91 years
male: 60.84 years
female: 73.27 years (1996 est.)
Total fertility rate: 1.62 children born/woman (1996 est.)
Nationality:
noun: Latvian(s)
adjective: Latvian
Ethnic divisions: Latvian 51.8%, Russian 33.8%, Byelorussian 4.5%,
Ukrainian 3.4%, Polish 2.3%, other 4.2%
Religions: Lutheran, Roman Catholic, Russian Orthodox
Languages: Lettish (official), Lithuanian, Russian, other
Literacy: age 15 and over can read and write (1989 est.)
total population: 100%
male: 100%
female: 99%
------
Population: 3,776,317 (July 1996 est.)
Age structure:
0-14 years: 36% (male 687,631; female 662,100)
15-64 years: 59% (male 1,049,689; female 1,163,255)
65 years and over: 5% (male 98,406; female 115,236) (July 1996 est.)
Population growth rate: 2.16% (1996 est.)
Birth rate: 27.93 births/1,000 population (1996 est.)
Death rate: 6.35 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.85 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 36.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.99 years
male: 67.49 years
female: 72.62 years (1996 est.)
Total fertility rate: 3.24 children born/woman (1996 est.)
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic divisions: Arab 95%, Armenian 4%, other 1%
Religions: Islam 70% (5 legally recognized Islamic groups -
Alawite or Nusayri, Druze, Isma''ilite, Shi''a, Sunni), Christian 30%
(11 legally recognized Christian groups - 4 Orthodox Christian, 6
Catholic, 1 Protestant), Judaism NEGL%
Languages: Arabic (official), French (official), Armenian, English
Literacy: age 15 and over can read and write (1995 est.)
total population: 92.4%
male: 94.7%
female: 90.3%
------
Population: 1,970,781 (July 1996 est.)
Age structure:
0-14 years: 41% (male 404,733; female 402,813)
15-64 years: 54% (male 519,493; female 553,618)
65 years and over: 5% (male 37,237; female 52,887) (July 1996 est.)
Population growth rate: 1.9% (1996 est.)
Birth rate: 32.7 births/1,000 population (1996 est.)
Death rate: 13.74 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.7 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 81.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 52.08 years
male: 50.08 years
female: 54.14 years (1996 est.)
Total fertility rate: 4.32 children born/woman (1996 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic divisions: Sotho 99.7%, Europeans 1,600, Asians 800
Religions: Christian 80%, rest indigenous beliefs
Languages: Sesotho (southern Sotho), English (official), Zulu,
Xhosa
Literacy: age 15 and over can read and write (1995 est.)
total population: 71.3%
male: 81.1%
female: 62.3%','9711af6f17af9723b2c2e78ce7e81aebe48ea6e93141c4c20826c8d723498337','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12dbb4891273815facff786926526a59412b397c8db7a2ea89f298bd2d02de61',1996,'ZA','South Africa','people-and-society',213,'------
Population: 2,109,789 (July 1996 est.)
Age structure:
0-14 years: 45% (male 475,138; female 470,970)
15-64 years: 52% (male 557,855; female 532,143)
65 years and over: 3% (male 35,544; female 38,139) (July 1996 est.)
Population growth rate: 2.13% (1996 est.)
Birth rate: 42.72 births/1,000 population (1996 est.)
Death rate: 11.95 deaths/1,000 population (1996 est.)
Net migration rate: -9.48 migrant(s)/1,000 population (1996 est.)
note: until the Ghanaian-led peace negotiations are successful, many
Liberian refugees will be unable to return from exile
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.93 male(s)/female
all ages: 1.03 male(s)/female (1996 est.)
Infant mortality rate: 108.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 58.59 years
male: 56.05 years
female: 61.22 years (1996 est.)
Total fertility rate: 6.23 children born/woman (1996 est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic divisions: indigenous African tribes 95% (including Kpelle,
Bassa, Gio, Kru, Grebo, Mano, Krahn, Gola, Gbandi, Loma, Kissi, Vai,
and Bella), Americo-Liberians 5% (descendants of former slaves)
Religions: traditional 70%, Muslim 20%, Christian 10%
Languages: English 20% (official), Niger-Congo language group
about 20 local languages come from this group
Literacy: age 15 and over can read and write (1995 est.)
total population: 38.3%
male: 53.9%
female: 22.4%
------
Population: 5,445,436 (July 1996 est.)
Age structure:
0-14 years: 48% (male 1,319,696; female 1,274,865)
15-64 years: 49% (male 1,375,441; female 1,308,613)
65 years and over: 3% (male 87,434; female 79,387) (July 1996 est.)
Population growth rate: 3.67% (1996 est.)
Birth rate: 44.42 births/1,000 population (1996 est.)
Death rate: 7.7 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 1.1 male(s)/female
all ages: 1.04 male(s)/female (1996 est.)
Infant mortality rate: 59.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 64.67 years
male: 62.48 years
female: 66.97 years (1996 est.)
Total fertility rate: 6.26 children born/woman (1996 est.)
Nationality:
noun: Libyan(s)
adjective: Libyan
Ethnic divisions: Berber and Arab 97%, Greeks, Maltese, Italians,
Egyptians, Pakistanis, Turks, Indians, Tunisians
Religions: Sunni Muslim 97%
Languages: Arabic, Italian, English, all are widely understood in
the major cities
Literacy: age 15 and over can read and write (1995 est.)
total population: 76.2%
male: 87.9%
female: 63%','34c1a5f32207fbcd978c7bbdea5be1d440f3d8a1a813bd723983651f907da697','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16102dcb9b5b7d19aa1a93d6211991ce085a5f401fdede31ab1c2b822835fdc1',1996,'CH','Switzerland','people-and-society',218,'------
Population: 31,122 (July 1996 est.)
Age structure:
0-14 years: 19% (male 2,961; female 2,871)
15-64 years: 70% (male 10,775; female 11,113)
65 years and over: 11% (male 1,366; female 2,036) (July 1996 est.)
Population growth rate: 1.08% (1996 est.)
Birth rate: 11.47 births/1,000 population (1996 est.)
Death rate: 6.81 deaths/1,000 population (1996 est.)
Net migration rate: 6.11 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.14 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.67 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 5.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.84 years
male: 75.92 years
female: 82.17 years (1996 est.)
Total fertility rate: 1.37 children born/woman (1996 est.)
Nationality:
noun: Liechtensteiner(s)
adjective: Liechtenstein
Ethnic divisions: Alemannic 95%, Italian and other 5%
Religions: Roman Catholic 87.3%, Protestant 8.3%, unknown 1.6%,
other 2.8% (1988)
Languages: German (official), Alemannic dialect
Literacy: age 10 and over can read and write (1981 est.)
total population: 100%
male: 100%
female: 100%
------
Population: 3,646,041 (July 1996 est.)
Age structure:
0-14 years: 22% (male 400,823; female 384,592)
15-64 years: 66% (male 1,162,626; female 1,244,103)
65 years and over: 12% (male 154,862; female 299,035) (July 1996
est.)
Population growth rate: -0.35% (1996 est.)
Birth rate: 12.93 births/1,000 population (1996 est.)
Death rate: 13.33 deaths/1,000 population (1996 est.)
Net migration rate: -3.09 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.52 male(s)/female
all ages: 0.89 male(s)/female (1996 est.)
Infant mortality rate: 17 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.03 years
male: 62.15 years
female: 74.21 years (1996 est.)
Total fertility rate: 1.78 children born/woman (1996 est.)
Nationality:
noun: Lithuanian(s)
adjective: Lithuanian
Ethnic divisions: Lithuanian 80.1%, Russian 8.6%, Polish 7.7%,
Byelorussian 1.5%, other 2.1%
Religions: Roman Catholic, Lutheran, other
Languages: Lithuanian (official), Polish, Russian
Literacy: age 15 and over can read and write (1989 est.)
total population: 98%
male: 99%
female: 98%','0c6c612aba9bb92f5ef49ac5636a6e7c5ffd5adb573f9c0225fec657e02ac3f0','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('830adf911ff7a5d702f06af651f138df55c42778f1ec90523124174420e4dd5d',1996,'DE','Germany','people-and-society',224,'------
Population: 415,870 (July 1996 est.)
Age structure:
0-14 years: 18% (male 39,199; female 37,239)
15-64 years: 68% (male 142,394; female 138,349)
65 years and over: 14% (male 23,118; female 35,571) (July 1996 est.)
Population growth rate: 1.57% (1996 est.)
Birth rate: 13.14 births/1,000 population (1996 est.)
Death rate: 8.32 deaths/1,000 population (1996 est.)
Net migration rate: 10.93 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.09 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.65 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 4.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.26 years
male: 75.24 years
female: 81.56 years (1996 est.)
Total fertility rate: 1.76 children born/woman (1996 est.)
Nationality:
noun: Luxembourger(s)
adjective: Luxembourg
Ethnic divisions: Celtic base (with French and German blend),
Portuguese, Italian, and European (guest and worker residents)
Religions: Roman Catholic 97%, Protestant and Jewish 3%
Languages: Luxembourgisch, German, French, English
Literacy: age 15 and over can read and write (1980 est.)
total population: 100%
male: 100%
female: 100%
------
Population: 496,837 (July 1996 est.)
Age structure:
0-14 years: 24% (male 60,709; female 57,004)
15-64 years: 68% (male 167,466; female 169,486)
65 years and over: 8% (male 17,569; female 24,603) (July 1996 est.)
Population growth rate: 1.15% (1996 est.)
Birth rate: 14.16 births/1,000 population (1996 est.)
Death rate: 4.31 deaths/1,000 population (1996 est.)
Net migration rate: 1.66 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 5.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 79.95 years
male: 77.49 years
female: 82.54 years (1996 est.)
Total fertility rate: 1.51 children born/woman (1996 est.)
Nationality:
noun: Macanese (singular and plural)
adjective: Macau
Ethnic divisions: Chinese 95%, Portuguese 3%, other 2%
Religions: Buddhist 45%, Roman Catholic 7%, Protestant 1%, none
45.8%, other 1.2% (1981)
Languages: Portuguese (official) 4%, Chinese (Cantonese) is the
language of commerce
Literacy: age 15 and over can read and write (1981 est.)
total population: 90%
male: 93%
female: 86%
------
Population: 2,104,035 (July 1996 est.)
note: the Macedonian government census of July 1994 put the
population at 1.94 million, but ethnic allocations were likely
undercounted
Age structure:
0-14 years: 22% (male 242,593; female 228,563)
15-64 years: 68% (male 728,969; female 703,665)
65 years and over: 10% (male 90,363; female 109,882) (July 1996 est.)
Population growth rate: 0.46% (1996 est.)
Birth rate: 13.31 births/1,000 population (1996 est.)
Death rate: 8.47 deaths/1,000 population (1996 est.)
Net migration rate: -0.2 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.82 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 29.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71.94 years
male: 69.86 years
female: 74.18 years (1996 est.)
Total fertility rate: 1.82 children born/woman (1996 est.)
Nationality:
noun: Macedonian(s)
adjective: Macedonian
Ethnic divisions: Macedonian 65%, Albanian 22%, Turkish 4%, Serb
2%, Gypsies 3%, other 4%
Religions: Eastern Orthodox 67%, Muslim 30%, other 3%
Languages: Macedonian 70%, Albanian 21%, Turkish 3%,
Serbo-Croatian 3%, other 3%
Literacy: NA','4fafb07bf0b71b31637c12b552e2b7217d524bf93b47b7702fd111cbf18133fc','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fbcabf092d34d189c07131a6bf7da7e683a4704418eab9f1f04bb7c4edae6d2',1996,'MZ','Mozambique','people-and-society',231,'------
Population: 13,670,507 (July 1996 est.)
Age structure:
0-14 years: 45% (male 3,105,958; female 3,034,279)
15-64 years: 52% (male 3,499,021; female 3,573,052)
65 years and over: 3% (male 224,710; female 233,487) (July 1996 est.)
Population growth rate: 2.83% (1996 est.)
Birth rate: 42.63 births/1,000 population (1996 est.)
Death rate: 14.38 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.96 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 93.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 52.19 years
male: 51.11 years
female: 53.3 years (1996 est.)
Total fertility rate: 5.89 children born/woman (1996 est.)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic divisions: Malayo-Indonesian (Merina and related Betsileo),
Cotiers (mixed African, Malayo-Indonesian, and Arab ancestry -
Betsimisaraka, Tsimihety, Antaisaka, Sakalava), French, Indian,
Creole, Comoran
Religions: indigenous beliefs 52%, Christian 41%, Muslim 7%
Languages: French (official), Malagasy (official)
Literacy: age 15 and over can read and write (1990 est.)
total population: 80%
male: 88%
female: 73%
------
Population: 9,452,844 (July 1996 est.)
Age structure:
0-14 years: 46% (male 2,189,223; female 2,168,317)
15-64 years: 51% (male 2,371,518; female 2,472,245)
65 years and over: 3% (male 107,701; female 143,840) (July 1996 est.)
Population growth rate: 1.71% (1996 est.)
Birth rate: 41.56 births/1,000 population (1996 est.)
Death rate: 24.48 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
note: the return of refugees to Mozambique is apparently complete
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.75 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 139.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 36.16 years
male: 35.87 years
female: 36.46 years (1996 est.)
Total fertility rate: 5.91 children born/woman (1996 est.)
Nationality:
noun: Malawian(s)
adjective: Malawian
Ethnic divisions: Chewa, Nyanja, Tumbuko, Yao, Lomwe, Sena, Tonga,
Ngoni, Ngonde, Asian, European
Religions: Protestant 55%, Roman Catholic 20%, Muslim 20%,
traditional indigenous beliefs
Languages: English (official), Chichewa (official), other
languages important regionally
Literacy: age 15 and over can read and write (1995 est.)
total population: 56.4%
male: 71.9%
female: 41.8%
------
Population: 19,962,893 (July 1996 est.)
Age structure:
0-14 years: 36% (male 3,684,510; female 3,483,893)
15-64 years: 60% (male 5,996,369; female 6,017,327)
65 years and over: 4% (male 342,742; female 438,052) (July 1996 est.)
Population growth rate: 2.07% (1996 est.)
Birth rate: 26.2 births/1,000 population (1996 est.)
Death rate: 5.49 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.78 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 24 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.75 years
male: 66.82 years
female: 72.89 years (1996 est.)
Total fertility rate: 3.27 children born/woman (1996 est.)
Nationality:
noun: Malaysian(s)
adjective: Malaysian
Ethnic divisions: Malay and other indigenous 59%, Chinese 32%,
Indian 9%
Religions:
Peninsular Malaysia: Muslim (Malays), Buddhist (Chinese), Hindu
(Indians)
Sabah: Muslim 38%, Christian 17%, other 45%
Sarawak: tribal religion 35%, Buddhist and Confucianist 24%, Muslim
20%, Christian 16%, other 5%
Languages:
Peninsular Malaysia: Malay (official), English, Chinese dialects,
Tamil
Sabah: English, Malay, numerous tribal dialects, Chinese (Mandarin
and Hakka dialects predominate)
Sarawak: English, Malay, Mandarin, numerous tribal languages
Literacy: age 15 and over can read and write (1995 est.)
total population: 83.5%
male: 89.1%
female: 78.1%','359977eaaff136f582ea9651e374f5b9a464637ec270b3f84196f826f866ad65','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d263f416a87805e97e5692e3594438eba6ab10115cb9afb5043e1f991333f5a',1996,'PG','Papua New Guinea','people-and-society',239,'------
Population: 58,363 (July 1996 est.)
Age structure:
0-14 years: 51% (male 15,043; female 14,435)
15-64 years: 47% (male 14,084; female 13,399)
65 years and over: 2% (male 657; female 745) (July 1996 est.)
Population growth rate: 3.85% (1996 est.)
Birth rate: 45.75 births/1,000 population (1996 est.)
Death rate: 7.28 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.88 male(s)/female
all ages: 1.04 male(s)/female (1996 est.)
Infant mortality rate: 46.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 63.81 years
male: 62.25 years
female: 65.45 years (1996 est.)
Total fertility rate: 6.83 children born/woman (1996 est.)
Nationality:
noun: Marshallese (singular and plural)
adjective: Marshallese
Ethnic divisions: Micronesian
Religions: Christian (mostly Protestant)
Languages: English (universally spoken and is the official
language), two major Marshallese dialects from the Malayo-Polynesian
family, Japanese
Literacy: age 15 and over can read and write (1980 est.)
total population: 93%
male: 100%
female: 88%','90aa0d697559525f61c202741c536ec9cf34ebf4a6cd1b815c2f90284b35b9ca','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5893176d9b2d37d67593b6740da273eea4388eca1bfb2309be7523bdc56f147',1996,'MG','Madagascar','people-and-society',245,'------
Population: 1,140,256 (July 1996 est.)
Age structure:
0-14 years: 27% (male 157,174; female 152,980)
15-64 years: 67% (male 379,840; female 383,295)
65 years and over: 6% (male 27,429; female 39,538) (July 1996 est.)
Population growth rate: 1.23% (1996 est.)
Birth rate: 18.97 births/1,000 population (1996 est.)
Death rate: 6.67 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.69 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 17.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 70.53 years
male: 66.72 years
female: 74.33 years (1996 est.)
Total fertility rate: 2.24 children born/woman (1996 est.)
Nationality:
noun: Mauritian(s)
adjective: Mauritian
Ethnic divisions: Indo-Mauritian 68%, Creole 27%, Sino-Mauritian
3%, Franco-Mauritian 2%
Religions: Hindu 52%, Christian 28.3% (Roman Catholic 26%,
Protestant 2.3%), Muslim 16.6%, other 3.1%
Languages: English (official), Creole, French, Hindi, Urdu, Hakka,
Bojpoori
Literacy: age 15 and over can read and write (1995 est.)
total population: 82.9%
male: 87.1%
female: 78.8%
------
Population: 100,838 (July 1996 est.)
Age structure:
0-14 years: 50% (male 25,099; female 24,881)
15-64 years: 48% (male 24,790; female 23,727)
65 years and over: 2% (male 1,152; female 1,189) (July 1996 est.)
Population growth rate: 3.78% (1996 est.)
Birth rate: 47.93 births/1,000 population (1996 est.)
Death rate: 10.12 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.97 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 75.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 58.7 years
male: 56.43 years
female: 61.05 years (1996 est.)
Total fertility rate: 6.63 children born/woman (1996 est.)
Nationality:
noun: Mahorais (singular and plural)
adjective: Mahoran
Ethnic divisions: NA
Religions: Muslim 99%, Christian (mostly Roman Catholic)
Languages: Mahorian (a Swahili dialect), French
Literacy: NA
------
Population: 95,772,462 (July 1996 est.)
Age structure:
0-14 years: 36% (male 17,732,725; female 17,125,562)
15-64 years: 59% (male 27,562,285; female 29,165,138)
65 years and over: 5% (male 1,911,968; female 2,274,784) (July 1996
est.)
Population growth rate: 1.87% (1996 est.)
Birth rate: 26.24 births/1,000 population (1996 est.)
Death rate: 4.58 deaths/1,000 population (1996 est.)
Net migration rate: -2.97 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.84 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 25 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 73.67 years
male: 70.07 years
female: 77.45 years (1996 est.)
Total fertility rate: 3.03 children born/woman (1996 est.)
Nationality:
noun: Mexican(s)
adjective: Mexican
Ethnic divisions: mestizo (Indian-Spanish) 60%, Amerindian or
predominantly Amerindian 30%, Caucasian or predominantly Caucasian
9%, other 1%
Religions: nominally Roman Catholic 89%, Protestant 6%
Languages: Spanish, various Mayan dialects
Literacy: age 15 and over can read and write (1995 est.)
total population: 89.6%
male: 91.8%
female: 87.4%
------
Population: 679,198 (July 1996 est.)
Age structure:
0-14 years: 32% (male 112,413; female 107,187)
15-64 years: 62% (male 207,386; female 214,308)
65 years and over: 6% (male 15,610; female 22,294) (July 1996 est.)
Population growth rate: 1.93% (1996 est.)
Birth rate: 24.01 births/1,000 population (1996 est.)
Death rate: 4.75 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.7 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 7.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 74.77 years
male: 71.71 years
female: 77.98 years (1996 est.)
Total fertility rate: 2.72 children born/woman (1996 est.)
Nationality:
noun: Reunionese (singular and plural)
adjective: Reunionese
Ethnic divisions: French, African, Malagasy, Chinese, Pakistani,
Indian
Religions: Roman Catholic 94%, Hindu, Islam, Buddhist
Languages: French (official), Creole widely used
Literacy: age 15 and over can read and write (1982 est.)
total population: 79%
male: 76%
female: 80%
------
Population: 21,657,162 (July 1996 est.)
Age structure:
0-14 years: 20% (male 2,180,023; female 2,088,496)
15-64 years: 68% (male 7,261,160; female 7,393,531)
65 years and over: 12% (male 1,138,583; female 1,595,369) (July 1996
est.)
Population growth rate: -1.21% (1996 est.)
Birth rate: 9.77 births/1,000 population (1996 est.)
Death rate: 12.27 deaths/1,000 population (1996 est.)
Net migration rate: -9.6 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 23.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.42 years
male: 65.51 years
female: 73.57 years (1996 est.)
Total fertility rate: 1.25 children born/woman (1996 est.)
Nationality:
noun: Romanian(s)
adjective: Romanian
Ethnic divisions: Romanian 89.1%, Hungarian 8.9%, German 0.4%,
Ukrainian, Serb, Croat, Russian, Turk, and Gypsy 1.6%
Religions: Romanian Orthodox 70%, Roman Catholic 6% (of which 3%
are Uniate), Protestant 6%, unaffiliated 18%
Languages: Romanian, Hungarian, German
Literacy: age 15 and over can read and write (1992 est.)
total population: 97%
male: 98%
female: 95%
------
Population: 148,178,487 (July 1996 est.)
Age structure:
0-14 years: 21% (male 15,792,573; female 15,213,854)
15-64 years: 67% (male 48,145,679; female 51,125,902)
65 years and over: 12% (male 5,403,066; female 12,497,413) (July
1996 est.)
Population growth rate: -0.07% (1996 est.)
Birth rate: 10.15 births/1,000 population (1996 est.)
Death rate: 16.34 deaths/1,000 population (1996 est.)
Net migration rate: 5.47 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.43 male(s)/female
all ages: 0.88 male(s)/female (1996 est.)
Infant mortality rate: 24.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 63.24 years
male: 56.51 years
female: 70.31 years (1996 est.)
Total fertility rate: 1.42 children born/woman (1996 est.)
Nationality:
noun: Russian(s)
adjective: Russian
Ethnic divisions: Russian 81.5%, Tatar 3.8%, Ukrainian 3%, Chuvash
1.2%, Bashkir 0.9%, Byelorussian 0.8%, Moldavian 0.7%, other 8.1%
Religions: Russian Orthodox, Muslim, other
Languages: Russian, other
Literacy: age 15 and over can read and write (1989 est.)
total population: 98%
male: 100%
female: 97%
------
Population: 6,853,359 (July 1996 est.)
note: genocide and civil war in 1994 killed more than 1 million
Rwandans and forced more than 2 million to flee to neighboring
countries
Age structure:
0-14 years: 46% (male 1,582,928; female 1,573,536)
15-64 years: 51% (male 1,734,716; female 1,772,722)
65 years and over: 3% (male 78,854; female 110,603) (July 1996 est.)
Population growth rate: 16.49% (1996 est.)
Birth rate: 38.83 births/1,000 population (1996 est.)
Death rate: 20.33 deaths/1,000 population (1996 est.)
Net migration rate: 146.43 migrant(s)/1,000 population (1996 est.)
note: since April 1994, more than two million refugees have fled the
civil strife between the Hutu and Tutsi factions in Rwanda and
crossed into Zaire, Burundi, and Tanzania; close to 800,000 Rwandan
Tutsis who fled civil strife in earlier years have returned to
Rwanda, and 90,000 of the Hutu refugees are going home despite the
perceived danger of doing so; the ethnic violence continues and in
1996 could produce further refugee flows as well as discourage
returns
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 118.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 40.12 years
male: 39.72 years
female: 40.53 years (1996 est.)
Total fertility rate: 5.99 children born/woman (1996 est.)
Nationality:
noun: Rwandan(s)
adjective: Rwandan
Ethnic divisions: Hutu 80%, Tutsi 19%, Twa (Pygmoid) 1%
Religions: Roman Catholic 65%, Protestant 9%, Muslim 1%,
indigenous beliefs and other 25%
Languages: Kinyarwanda (official), French (official), Kiswahili
(Swahili) used in commercial centers
Literacy: age 15 and over can read and write (1995 est.)
total population: 60.5%
male: 69.8%
female: 51.6%
------
Population: 6,782 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.31% (1996 est.)
Birth rate: 9.39 births/1,000 population (1996 est.)
Death rate: 6.33 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 35.14 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.34 years
male: 73.28 years
female: 77.16 years (1996 est.)
Total fertility rate: 1.12 children born/woman (1996 est.)
Nationality:
noun: Saint Helenian(s)
adjective: Saint Helenian
Ethnic divisions: NA
Religions: Anglican (majority), Baptist, Seventh-Day Adventist,
Roman Catholic
Languages: English
Literacy: age 20 and over can read and write (1987 est.)
total population: 97%
male: 97%
female: 98%
------
Population: 41,369 (July 1996 est.)
Age structure:
0-14 years: 35% (male 7,371; female 7,026)
15-64 years: 58% (male 12,090; female 12,057)
65 years and over: 7% (male 1,162; female 1,663) (July 1996 est.)
Population growth rate: 0.98% (1996 est.)
Birth rate: 23.28 births/1,000 population (1996 est.)
Death rate: 9.21 deaths/1,000 population (1996 est.)
Net migration rate: -4.28 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 18.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 66.86 years
male: 63.84 years
female: 70.06 years (1996 est.)
Total fertility rate: 2.52 children born/woman (1996 est.)
Nationality:
noun: Kittsian(s), Nevisian(s)
adjective: Kittsian, Nevisian
Ethnic divisions: black African
Religions: Anglican, other Protestant sects, Roman Catholic
Languages: English
Literacy: age 15 and over has ever attended school (1980 est.)
total population: 97%
male: 97%
female: 98%','c5fdda85f6f445f12fe0b8c66760f259feccf47c811a384d44277aba4228a723','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7547dbb6a8ba2a791286e36b41512a209db2ae148dd5426aea359a1c4bb1be52',1996,'EH','Western Sahara','people-and-society',259,'------
Population: 29,779,156 (July 1996 est.)
Age structure:
0-14 years: 38% (male 5,696,731; female 5,522,077)
15-64 years: 58% (male 8,577,918; female 8,700,521)
65 years and over: 4% (male 613,712; female 668,197) (July 1996 est.)
Population growth rate: 2.05% (1996 est.)
Birth rate: 27.39 births/1,000 population (1996 est.)
Death rate: 5.77 deaths/1,000 population (1996 est.)
Net migration rate: -1.08 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.92 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 43.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.52 years
male: 67.53 years
female: 71.61 years (1996 est.)
Total fertility rate: 3.58 children born/woman (1996 est.)
Nationality:
noun: Moroccan(s)
adjective: Moroccan
Ethnic divisions: Arab-Berber 99.1%, other 0.7%, Jewish 0.2%
Religions: Muslim 98.7%, Christian 1.1%, Jewish 0.2%
Languages: Arabic (official), Berber dialects, French often the
language of business, government, and diplomacy
Literacy: age 15 and over can read and write (1995 est.)
total population: 43.7%
male: 56.6%
female: 31%
------
Population: 17,877,927 (July 1996 est.)
Age structure:
0-14 years: 46% (male 4,141,915; female 4,115,191)
15-64 years: 51% (male 4,324,102; female 4,868,518)
65 years and over: 3% (male 184,606; female 243,595) (July 1996 est.)
Population growth rate: 2.65% (1996 est.)
Birth rate: 45.51 births/1,000 population (1996 est.)
Death rate: 18.97 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
note: by the end of 1994, an estimated 1.6 million Mozambican
refugees, who fled to Malawi, Zimbabwe, and South Africa in earlier
years from the civil war, had returned; an estimated 100,000
refugees remain to be repatriated from those countries
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.89 male(s)/female
65 years and over: 0.76 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 125.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 44.34 years
male: 43.21 years
female: 45.5 years (1996 est.)
Total fertility rate: 6.23 children born/woman (1996 est.)
Nationality:
noun: Mozambican(s)
adjective: Mozambican
Ethnic divisions: indigenous tribal groups 99.66% (Shangaan,
Chokwe, Manyika, Sena, Makua, and others), Europeans 0.06%,
Euro-Africans 0.2%, Indians 0.08%
Religions: indigenous beliefs 50%, Christian 30%, Muslim 20%
Languages: Portuguese (official), indigenous dialects
Literacy: age 15 and over can read and write (1995 est.)
total population: 40.1%
male: 57.7%
female: 23.3%
------
Population: 1,677,243 (July 1996 est.)
Age structure:
0-14 years: 44% (male 370,090; female 362,185)
15-64 years: 52% (male 428,488; female 449,726)
65 years and over: 4% (male 28,599; female 38,155) (July 1996 est.)
Population growth rate: 2.93% (1996 est.)
Birth rate: 37.29 births/1,000 population (1996 est.)
Death rate: 7.98 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.75 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 47.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 64.48 years
male: 62.85 years
female: 66.16 years (1996 est.)
Total fertility rate: 5.1 children born/woman (1996 est.)
Nationality:
noun: Namibian(s)
adjective: Namibian
Ethnic divisions: black 86%, white 6.6%, mixed 7.4%
note: about 50% of the population belong to the Ovambo tribe and 9%
to the Kavangos tribe; other ethnic groups are: Herero 7%, Damara
7%, Nama 5%, Caprivian 4%, Bushmen 3%, Baster 2%, Tswana 0.5%
Religions: Christian 80% to 90%, Lutheran 50% at least, other
Christian denominations 30%, native religions 10% to 20%
Languages: English 7% (official), Afrikaans common language of
most of the population and about 60% of the white population, German
32%, indigenous languages: Oshivambo, Herero, Nama
Literacy: age 15 and over can read and write (1960 est.)
total population: 38%
male: 45%
female: 31%','a0e67d85d3539bc1cd92a67c90983666558cbb47098b8946b003a9a17dee2dc9','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae3498ddf706d2b8df416a7a66cd7e7544afbd24ecee779f52f6121a2eb6fa13',1996,'MH','Marshall Islands','people-and-society',265,'------
Population: 10,273 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.33% (1996 est.)
Birth rate: 18.03 births/1,000 population (1996 est.)
Death rate: 5.1 deaths/1,000 population (1996 est.)
Net migration rate: 0.4 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 40.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 66.68 years
male: 64.3 years
female: 69.18 years (1996 est.)
Total fertility rate: 2.08 children born/woman (1996 est.)
Nationality:
noun: Nauruan(s)
adjective: Nauruan
Ethnic divisions: Nauruan 58%, other Pacific Islander 26%, Chinese
8%, European 8%
Religions: Christian (two-thirds Protestant, one-third Roman
Catholic)
Languages: Nauruan (official, a distinct Pacific Island language),
English widely understood, spoken, and used for most government and
commercial purposes
Literacy: NA
------
Population: uninhabited; note - transient Haitian fishermen and
others camp on the island','3e6ceaff9d3626e830450a2f861a8f1e646592ba0b508587cb25f5a01be5baa8','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0966b0b381f711901f1f1e8289475ce05f121abad1077459ab5d1cd2c05b62c9',1996,'HN','Honduras','people-and-society',273,'------
Population: 4,272,352 (July 1996 est.)
Age structure:
0-14 years: 44% (male 951,254; female 938,599)
15-64 years: 53% (male 1,105,069; female 1,164,144)
65 years and over: 3% (male 49,027; female 64,259) (July 1996 est.)
Population growth rate: 2.67% (1996 est.)
Birth rate: 33.83 births/1,000 population (1996 est.)
Death rate: 6.01 deaths/1,000 population (1996 est.)
Net migration rate: -1.17 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.76 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 45.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 65.72 years
male: 63.41 years
female: 68.13 years (1996 est.)
Total fertility rate: 4.03 children born/woman (1996 est.)
Nationality:
noun: Nicaraguan(s)
adjective: Nicaraguan
Ethnic divisions: mestizo (mixed Amerindian and white) 69%, white
17%, black 9%, Indian 5%
Religions: Roman Catholic 95%, Protestant 5%
Languages: Spanish (official)
note: English- and Indian-speaking minorities on Atlantic coast
Literacy: age 15 and over can read and write (1995 est.)
total population: 65.7%
male: 64.6%
female: 66.6%
------
Population: 9,113,001 (July 1996 est.)
Age structure:
0-14 years: 48% (male 2,233,157; female 2,138,096)
15-64 years: 50% (male 2,202,413; female 2,317,188)
65 years and over: 2% (male 117,337; female 104,810) (July 1996 est.)
Population growth rate: 2.99% (1996 est.)
Birth rate: 54.46 births/1,000 population (1996 est.)
Death rate: 24.57 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 1.12 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 117.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 40.66 years
male: 41.05 years
female: 40.25 years (1996 est.)
Total fertility rate: 7.44 children born/woman (1996 est.)
Nationality:
noun: Nigerien(s)
adjective: Nigerien
Ethnic divisions: Hausa 56%, Djerma 22%, Fula 8.5%, Tuareg 8%,
Beri Beri (Kanouri) 4.3%, Arab, Toubou, and Gourmantche 1.2%, about
4,000 French expatriates
Religions: Muslim 80%, remainder indigenous beliefs and Christians
Languages: French (official), Hausa, Djerma
Literacy: age 15 and over can read and write (1995 est.)
total population: 13.6%
male: 20.9%
female: 6.6%
------
Population: 103,912,489 (July 1996 est.)
Age structure:
0-14 years: 45% (male 23,455,266; female 23,245,099)
15-64 years: 52% (male 27,645,106; female 26,553,135)
65 years and over: 3% (male 1,522,862; female 1,491,021) (July 1996
est.)
Population growth rate: 3.05% (1996 est.)
Birth rate: 42.89 births/1,000 population (1996 est.)
Death rate: 12.71 deaths/1,000 population (1996 est.)
Net migration rate: 0.34 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 1.02 male(s)/female
all ages: 1.03 male(s)/female (1996 est.)
Infant mortality rate: 72.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 54.34 years
male: 53.06 years
female: 55.65 years (1996 est.)
Total fertility rate: 6.24 children born/woman (1996 est.)
Nationality:
noun: Nigerian(s)
adjective: Nigerian
Ethnic divisions: non-Africans 27,000
north: Hausa and Fulani
note: Hausa and Fulani, Yoruba, and Ibos together make up 65% of
population
southwest: Yoruba
southeast: Ibos
Religions: Muslim 50%, Christian 40%, indigenous beliefs 10%
Languages: English (official), Hausa, Yoruba, Ibo, Fulani
Literacy: age 15 and over can read and write (1995 est.)
total population: 57.1%
male: 67.3%
female: 47.3%
------
Population: 2,174 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -0.62% (1996 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Niuean(s)
adjective: Niuean
Ethnic divisions: Polynesian (with some 200 Europeans, Samoans,
and Tongans)
Religions: Ekalesia Nieue (Niuean Church) 75% - a Protestant
church closely related to the London Missionary Society, Morman 10%,
other 15% (mostly Roman Catholic, Jehovah''s Witnesses, Seventh-Day
Adventist)
Languages: Polynesian closely related to Tongan and Samoan, English','dc1ef2a94043191c2835ab3e3180292ff31f5e8b84471b8baed63f8d434fca31','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d62b958a6820f2ab9a90c6dfebb39de1de421cb20163dc5967386b2a8315cbb',1996,'CR','Costa Rica','people-and-society',280,'------
Population: 2,655,094 (July 1996 est.)
Age structure:
0-14 years: 33% (male 445,382; female 426,111)
15-64 years: 62% (male 828,384; female 806,205)
65 years and over: 5% (male 71,823; female 77,189) (July 1996 est.)
Population growth rate: 1.64% (1996 est.)
Birth rate: 23.2 births/1,000 population (1996 est.)
Death rate: 5.42 deaths/1,000 population (1996 est.)
Net migration rate: -1.42 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.93 male(s)/female
all ages: 1.03 male(s)/female (1996 est.)
Infant mortality rate: 29.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 73.92 years
male: 71.19 years
female: 76.75 years (1996 est.)
Total fertility rate: 2.71 children born/woman (1996 est.)
Nationality:
noun: Panamanian(s)
adjective: Panamanian
Ethnic divisions: mestizo (mixed Indian and European ancestry)
70%, West Indian 14%, white 10%, Indian 6%
Religions: Roman Catholic 85%, Protestant 15%
Languages: Spanish (official), English 14%
note: many Panamanians bilingual
Literacy: age 15 and over can read and write (1995 est.)
total population: 90.8%
male: 91.4%
female: 90.2%
------
Population: 4,394,537 (July 1996 est.)
Age structure:
0-14 years: 40% (male 906,709; female 860,534)
15-64 years: 57% (male 1,303,084; female 1,195,245)
65 years and over: 3% (male 59,513; female 69,452) (July 1996 est.)
Population growth rate: 2.29% (1996 est.)
Birth rate: 32.93 births/1,000 population (1996 est.)
Death rate: 10.01 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.09 male(s)/female
65 years and over: 0.86 male(s)/female
all ages: 1.07 male(s)/female (1996 est.)
Infant mortality rate: 60.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 57.25 years
male: 56.4 years
female: 58.15 years (1996 est.)
Total fertility rate: 4.45 children born/woman (1996 est.)
Nationality:
noun: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic divisions: Melanesian, Papuan, Negrito, Micronesian,
Polynesian
Religions: Roman Catholic 22%, Lutheran 16%,
Presbyterian/Methodist/London Missionary Society 8%, Anglican 5%,
Evangelical Alliance 4%, Seventh-Day Adventist 1%, other Protestant
sects 10%, indigenous beliefs 34%
Languages: English spoken by 1%-2%, pidgin English widespread,
Motu spoken in Papua region
note: 715 indigenous languages
Literacy: age 15 and over can read and write (1995 est.)
total population: 72.2%
male: 81%
female: 62.7%
------
Population: no indigenous inhabitants; note - there are scattered
Chinese garrisons','21b6debab555e8aa58b622d251ee9875b8faf8054a4b125b4d54bb0616bcb06e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90d3bdd4d1e7cd8d6932a8eda1652a596c775655b20d92ab8af62f082bfbf0f2',1996,'ET','Ethiopia','people-and-society',286,'------
Population: 144,128 (July 1996 est.)
Age structure:
0-14 years: 40% (male 29,103; female 28,633)
15-64 years: 55% (male 39,749; female 39,960)
65 years and over: 5% (male 2,973; female 3,710) (July 1996 est.)
Population growth rate: 2.58% (1996 est.)
Birth rate: 34.39 births/1,000 population (1996 est.)
Death rate: 8.55 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.8 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 61.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 63.87 years
male: 61.95 years
female: 65.83 years (1996 est.)
Total fertility rate: 4.33 children born/woman (1996 est.)
Nationality:
noun: Sao Tomean(s)
adjective: Sao Tomean
Ethnic divisions: mestico, angolares (descendants of Angolan
slaves), forros (descendants of freed slaves), servicais (contract
laborers from Angola, Mozambique, and Cape Verde), tongas (children
of servicais born on the islands), Europeans (primarily Portuguese)
Religions: Roman Catholic, Evangelical Protestant, Seventh-Day
Adventist
Languages: Portuguese (official)
Literacy: age 15 and over can read and write (1991 est.)
total population: 73%
male: 85%
female: 62%
------
Population: 19,409,058 (July 1996 est.)
Age structure:
0-14 years: 43% (male 4,228,660; female 4,103,622)
15-64 years: 55% (male 6,393,384; female 4,240,535)
65 years and over: 2% (male 227,789; female 215,068) (July 1996 est.)
Population growth rate: 3.45% (1996 est.)
Birth rate: 38.32 births/1,000 population (1996 est.)
Death rate: 5.36 deaths/1,000 population (1996 est.)
Net migration rate: 1.55 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.51 male(s)/female
65 years and over: 1.06 male(s)/female
all ages: 1.27 male(s)/female (1996 est.)
Infant mortality rate: 46.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69 years
male: 67.25 years
female: 70.84 years (1996 est.)
Total fertility rate: 6.45 children born/woman (1996 est.)
Nationality:
noun: Saudi(s)
adjective: Saudi or Saudi Arabian
Ethnic divisions: Arab 90%, Afro-Asian 10%
Religions: Muslim 100%
Languages: Arabic
Literacy: age 15 and over can read and write (1995 est.)
total population: 62.8%
male: 71.5%
female: 50.2%
------
Population: 9,092,749 (July 1996 est.)
Age structure:
0-14 years: 48% (male 2,188,338; female 2,197,015)
15-64 years: 49% (male 2,111,330; female 2,336,987)
65 years and over: 3% (male 128,939; female 130,140) (July 1996 est.)
Population growth rate: 3.37% (1996 est.)
Birth rate: 45.46 births/1,000 population (1996 est.)
Death rate: 11.76 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.99 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 64 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 56.49 years
male: 53.75 years
female: 59.3 years (1996 est.)
Total fertility rate: 6.31 children born/woman (1996 est.)
Nationality:
noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic divisions: Wolof 36%, Fulani 17%, Serer 17%, Toucouleur 9%,
Diola 9%, Mandingo 9%, European and Lebanese 1%, other 2%
Religions: Muslim 92%, indigenous beliefs 6%, Christian 2% (mostly
Roman Catholic)
Languages: French (official), Wolof, Pulaar, Diola, Mandingo
Literacy: age 15 and over can read and write (1995 est.)
total population: 33.1%
male: 43%
female: 23.2%
------
Population:
total population: 10,614,558 (July 1996 est.)
Montenegro: 635,442 (July 1996 est.)
Serbia: 9,979,116 (July 1996 est.)
Age structure:
Montenegro - 0-14 years: 22% (male 71,075; female 67,402)
Montenegro - 15-64 years: 67% (male 215,889; female 213,290)
Montenegro - 65 years and over: 11% (male 27,868; female 39.918)
(July 1996 est.)
Serbia - 0-14 years: 21% (male 1,104,274; female 1,026,994)
Serbia - 15-64 years: 66% (male 3,332,809; female 3,293,788)
Serbia - 65 years and over: 13% (male 515,001; female 706,250) (July
1996 est.)
Population growth rate:
Montenegro: 0.39% (1996 est.)
Serbia: 0.39% (1996 est.)
Birth rate:
Montenegro: 11.86 births/1,000 population (1996 est.)
Serbia: 13.98 births/1,000 population (1996 est.)
Death rate:
Montenegro: 7.76 deaths/1,000 population (1996 est.)
Serbia: 10.25 deaths/1,000 population (1996 est.)
Net migration rate:
Montenegro: -0.2 migrant(s)/1,000 population (1996 est.)
Serbia: 0.12 migrant(s)/1,000 population (1996 est.)
Sex ratio:
Montenegro - at birth: 1.05 male(s)/female
Montenegro - under 15 years: 1.05 male(s)/female
Montenegro - 15-64 years: 1.01 male(s)/female
Montenegro - 65 years and over: 0.7 male(s)/female
Montenegro - all ages: 0.98 male(s)/female (1996 est.)
Serbia - at birth: 1.08 male(s)/female
Serbia - under 15 years: 1.08 male(s)/female
Serbia - 15-64 years: 1.01 male(s)/female
Serbia - 65 years and over: 0.73 male(s)/female
Serbia - all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate:
Montenegro: 27.5 deaths/1,000 live births (1996 est.)
Serbia: 22.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
Montenegro - total population: 74.88 years
Montenegro - male: 70.86 years
Montenegro - female: 79.11 years (1996 est.)
Serbia - total population: 71.98 years
Serbia - male: 68.97 years
Serbia - female: 75.22 years (1996 est.)
Total fertility rate:
Montenegro: 1.53 children born/woman (1996 est.)
Serbia: 2 children born/woman (1996 est.)
Nationality:
noun: Serb(s) and Montenegrin(s)
adjective: Serbian and Montenegrin
Ethnic divisions: Serbs 63%, Albanians 14%, Montenegrins 6%,
Hungarians 4%, other 13%
Religions: Orthodox 65%, Muslim 19%, Roman Catholic 4%, Protestant
1%, other 11%
Languages: Serbo-Croatian 95%, Albanian 5%
Literacy: NA
------
Population: 77,575 (July 1996 est.)
Age structure:
0-14 years: 31% (male 12,005; female 11,835)
15-64 years: 63% (male 24,003; female 24,946)
65 years and over: 6% (male 1,669; female 3,117) (July 1996 est.)
Population growth rate: 0.76% (1996 est.)
Birth rate: 21.02 births/1,000 population (1996 est.)
Death rate: 7.31 deaths/1,000 population (1996 est.)
Net migration rate: -6.14 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.54 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 12.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.24 years
male: 64.23 years
female: 74.39 years (1996 est.)
Total fertility rate: 2.09 children born/woman (1996 est.)
Nationality:
noun: Seychellois (singular and plural)
adjective: Seychelles
Ethnic divisions: Seychellois (mixture of Asians, Africans,
Europeans)
Religions: Roman Catholic 90%, Anglican 8%, other 2%
Languages: English (official), French (official), Creole
Literacy: age 15 and over can read and write (1971 est.)
total population: 58%
male: 56%
female: 60%
------
Population: 4,793,121 (July 1996 est.)
Age structure:
0-14 years: 45% (male 1,057,824; female 1,092,291)
15-64 years: 52% (male 1,197,547; female 1,298,834)
65 years and over: 3% (male 75,066; female 71,559) (July 1996 est.)
Population growth rate: 4.14% (1996 est.)
Birth rate: 47.13 births/1,000 population (1996 est.)
Death rate: 18.24 deaths/1,000 population (1996 est.)
Net migration rate: 12.52 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.97 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 1.05 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 135.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 47.47 years
male: 44.56 years
female: 50.47 years (1996 est.)
Total fertility rate: 6.36 children born/woman (1996 est.)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic divisions: 13 native African tribes 99% (Temne 30%, Mende
30%, other 39%), Creole, European, Lebanese, and Asian 1%
Religions: Muslim 60%, indigenous beliefs 30%, Christian 10%
Languages: English (official, regular use limited to literate
minority), Mende (principal vernacular in the south), Temne
(principal vernacular in the north), Krio (the language of the
re-settled ex-slave population of the Freetown area and is lingua
franca)
Literacy: age 15 and over can read and write in English, Mende,
Temne, or Arabic (1995 est.)
total population: 31.4%
male: 45.4%
female: 18.2%
------
Population: 3,396,924 (July 1996 est.)
Age structure:
0-14 years: 22% (male 379,076; female 358,739)
15-64 years: 72% (male 1,220,131; female 1,219,412)
65 years and over: 6% (male 97,882; female 121,684) (July 1996 est.)
Population growth rate: 1.9% (1996 est.)
Birth rate: 16.28 births/1,000 population (1996 est.)
Death rate: 4.56 deaths/1,000 population (1996 est.)
Net migration rate: 7.29 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.8 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 4.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.13 years
male: 75.07 years
female: 81.39 years (1996 est.)
Total fertility rate: 1.65 children born/woman (1996 est.)
Nationality:
noun: Singaporean(s)
adjective: Singapore
Ethnic divisions: Chinese 76.4%, Malay 14.9%, Indian 6.4%, other
2.3%
Religions: Buddhist (Chinese), Muslim (Malays), Christian, Hindu,
Sikh, Taoist, Confucianist
Languages: Chinese (official), Malay (official and national),
Tamil (official), English (official)
Literacy: age 15 and over can read and write (1995 est.)
total population: 91.1%
male: 95.9%
female: 86.3%
------
Population: 5,374,362 (July 1996 est.)
Age structure:
0-14 years: 22% (male 605,379; female 579,232)
15-64 years: 67% (male 1,777,100; female 1,812,555)
65 years and over: 11% (male 234,377; female 365,719) (July 1996
est.)
Population growth rate: 0.34% (1996 est.)
Birth rate: 12.62 births/1,000 population (1996 est.)
Death rate: 9.35 deaths/1,000 population (1996 est.)
Net migration rate: 0.12 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.64 male(s)/female
all ages: 0.95 male(s)/female (1996 est.)
Infant mortality rate: 10.7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 73.01 years
male: 69.01 years
female: 77.21 years (1996 est.)
Total fertility rate: 1.65 children born/woman (1996 est.)
Nationality:
noun: Slovak(s)
adjective: Slovak
Ethnic divisions: Slovak 85.7%, Hungarian 10.7%, Gypsy 1.5% (the
1992 census figures underreport the Gypsy/Romany community, which
could reach 500,000 or more), Czech 1%, Ruthenian 0.3%, Ukrainian
0.3%, German 0.1%, Polish 0.1%, other 0.3%
Religions: Roman Catholic 60.3%, atheist 9.7%, Protestant 8.4%,
Orthodox 4.1%, other 17.5%
Languages: Slovak (official), Hungarian
Literacy: NA
------
Population: 1,951,443 (July 1996 est.)
Age structure:
0-14 years: 17% (male 172,778; female 163,695)
15-64 years: 70% (male 682,501; female 678,781)
65 years and over: 13% (male 91,819; female 161,869) (July 1996 est.)
Population growth rate: -0.27% (1996 est.)
Birth rate: 8.27 births/1,000 population (1996 est.)
Death rate: 9.4 deaths/1,000 population (1996 est.)
Net migration rate: -1.57 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.57 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 7.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.09 years
male: 71.4 years
female: 79 years (1996 est.)
Total fertility rate: 1.13 children born/woman (1996 est.)
Nationality:
noun: Slovene(s)
adjective: Slovenian
Ethnic divisions: Slovene 91%, Croat 3%, Serb 2%, Muslim 1%, other
3%
Religions: Roman Catholic 96% (including 2% Uniate), Muslim 1%,
other 3%
Languages: Slovenian 91%, Serbo-Croatian 7%, other 2%
Literacy: NA
------
Population: 412,902 (July 1996 est.)
Age structure:
0-14 years: 46% (male 96,241; female 92,722)
15-64 years: 51% (male 107,482; female 104,293)
65 years and over: 3% (male 6,129; female 6,035) (July 1996 est.)
Population growth rate: 3.35% (1996 est.)
Birth rate: 37.91 births/1,000 population (1996 est.)
Death rate: 4.41 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 1.02 male(s)/female
all ages: 1.03 male(s)/female (1996 est.)
Infant mortality rate: 25.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71.14 years
male: 68.67 years
female: 73.74 years (1996 est.)
Total fertility rate: 5.43 children born/woman (1996 est.)
Nationality:
noun: Solomon Islander(s)
adjective: Solomon Islander
Ethnic divisions: Melanesian 93%, Polynesian 4%, Micronesian 1.5%,
European 0.8%, Chinese 0.3%, other 0.4%
Religions: Anglican 34%, Roman Catholic 19%, Baptist 17%, United
(Methodist/Presbyterian) 11%, Seventh-Day Adventist 10%, other
Protestant 5%, traditional beliefs 4%
Languages: Melanesian pidgin in much of the country is lingua
franca, English spoken by 1%-2% of population
note: 120 indigenous languages
Literacy: NA
------
Population: 9,639,151 (July 1996 est.)
note: this estimate was derived from an official census taken in
1987 by the Somali Government with the cooperation of the UN and the
US Bureau of the Census; population estimates are updated year by
year between census years by factoring growth rates into them, and
by taking account of refugee movements, and of losses due to famine;
lower estimates of Somalia''s population in mid-1996 (on the order of
6.0 to 6.5 million) have been made by aid and relief agencies, based
on the number of persons being fed; population counting in Somalia
is complicated by the large numbers of nomads and by refugee
movements in response to famine and clan warfare
Age structure:
0-14 years: 44% (male 2,143,775; female 2,139,104)
15-64 years: 52% (male 2,609,911; female 2,387,620)
65 years and over: 4% (male 182,991; female 175,750) (July 1996 est.)
Population growth rate: 3.1% (1996 est.)
Birth rate: 44.17 births/1,000 population (1996 est.)
Death rate: 13.22 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.09 male(s)/female
65 years and over: 1.04 male(s)/female
all ages: 1.05 male(s)/female (1996 est.)
Infant mortality rate: 121.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 55.49 years
male: 55.18 years
female: 55.8 years (1996 est.)
Total fertility rate: 7.01 children born/woman (1996 est.)
Nationality:
noun: Somali(s)
adjective: Somali
Ethnic divisions: Somali 85%, Bantu, Arabs 30,000
Religions: Sunni Muslim
Languages: Somali (official), Arabic, Italian, English
Literacy: age 15 and over can read and write (1990 est.)
total population: 24%
male: 36%
female: 14%
------
Population: 41,743,459 (July 1996 est.)
Age structure:
0-14 years: 36% (male 7,578,639; female 7,428,123)
15-64 years: 60% (male 12,356,753; female 12,516,467)
65 years and over: 4% (male 744,806; female 1,118,671) (July 1996
est.)
Population growth rate: 1.76% (1996 est.)
Birth rate: 27.91 births/1,000 population (1996 est.)
Death rate: 10.32 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 48.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 59.47 years
male: 57.21 years
female: 61.8 years (1996 est.)
Total fertility rate: 3.43 children born/woman (1996 est.)
Nationality:
noun: South African(s)
adjective: South African
Ethnic divisions: black 75.2%, white 13.6%, Colored 8.6%, Indian
2.6%
Religions: Christian (most whites and Coloreds and about 60% of
blacks), Hindu (60% of Indians), Muslim 2%
Languages: 11 official languages, including Afrikaans, English,
Ndebele, Pedi, Sotho, Swazi, Tsonga, Tswana, Venda, Xhosa, Zulu
Literacy: age 15 and over can read and write (1995 est.)
total population: 81.8%
male: 81.9%
female: 81.7%
------
Population: 9,159,072 (July 1996 est.)
Age structure:
0-14 years: 49% (male 2,272,981; female 2,244,403)
15-64 years: 48% (male 2,157,106; female 2,256,935)
65 years and over: 3% (male 110,433; female 117,214) (July 1996 est.)
Population growth rate: 2.11% (1996 est.)
Birth rate: 44.73 births/1,000 population (1996 est.)
Death rate: 23.65 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.94 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 96.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 36.31 years
male: 36.15 years
female: 36.46 years (1996 est.)
Total fertility rate: 6.55 children born/woman (1996 est.)
Nationality:
noun: Zambian(s)
adjective: Zambian
Ethnic divisions: African 98.7%, European 1.1%, other 0.2%
Religions: Christian 50%-75%, Muslim and Hindu 24%-49%, indigenous
beliefs 1%
Languages: English (official), major vernaculars - Bemba, Kaonda,
Lozi, Lunda, Luvale, Nyanja, Tonga, and about 70 other indigenous
languages
Literacy: age 15 and over can read and write in English (1995 est.)
total population: 78.2%
male: 85.6%
female: 71.3%','4261842132b39b315953f3ef6006c51fe26d88ada992d9fd629d3b334d216d28','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bb9938a5531dfed45f436499038bb74424d8c3a34f6a87102b3726eaab80bb9',1996,'GI','Gibraltar','people-and-society',295,'------
Population: 39,181,114 (July 1996 est.)
Age structure:
0-14 years: 16% (male 3,237,942; female 3,055,881)
15-64 years: 68% (male 13,380,956; female 13,352,582)
65 years and over: 16% (male 2,566,728; female 3,587,025) (July 1996
est.)
Population growth rate: 0.16% (1996 est.)
Birth rate: 10.04 births/1,000 population (1996 est.)
Death rate: 8.86 deaths/1,000 population (1996 est.)
Net migration rate: 0.44 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.72 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 6.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.26 years
male: 74.95 years
female: 81.81 years (1996 est.)
Total fertility rate: 1.26 children born/woman (1996 est.)
Nationality:
noun: Spaniard(s)
adjective: Spanish
Ethnic divisions: composite of Mediterranean and Nordic types
Religions: Roman Catholic 99%, other sects 1%
Languages: Castilian Spanish, Catalan 17%, Galician 7%, Basque 2%
Literacy: age 15 and over can read and write (1986 est.)
total population: 96%
male: 98%
female: 94%
------
Population: no indigenous inhabitants; note - there are scattered
garrisons
------
Population: 18,553,074 (July 1996 est.)
note: since the outbreak of hostilities between the government and
armed Tamil separatists in the mid-1980s, several hundred thousand
Tamil civilians have fled the island; as of late 1992, nearly
115,000 were housed in refugee camps in south India, another 95,000
lived outside the Indian camps, and more than 200,000 Tamils have
sought political asylum in the West
Age structure:
0-14 years: 28% (male 2,673,943; female 2,559,569)
15-64 years: 66% (male 6,023,759; female 6,171,964)
65 years and over: 6% (male 553,940; female 569,899) (July 1996 est.)
Population growth rate: 1.13% (1996 est.)
Birth rate: 17.89 births/1,000 population (1996 est.)
Death rate: 5.8 deaths/1,000 population (1996 est.)
Net migration rate: -0.78 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.97 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 20.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.35 years
male: 69.77 years
female: 75.06 years (1996 est.)
Total fertility rate: 2.05 children born/woman (1996 est.)
Nationality:
noun: Sri Lankan(s)
adjective: Sri Lankan
Ethnic divisions: Sinhalese 74%, Tamil 18%, Moor 7%, Burgher,
Malay, and Vedda 1%
Religions: Buddhist 69%, Hindu 15%, Christian 8%, Muslim 8%
Languages: Sinhala (official and national language) 74%, Tamil
(national language) 18%
note: English is commonly used in government and is spoken by about
10% of the population
Literacy: age 15 and over can read and write (1995 est.)
total population: 90.2%
male: 93.4%
female: 87.2%
------
Population: 31,547,543 (July 1996 est.)
Age structure:
0-14 years: 46% (male 7,389,616; female 7,080,044)
15-64 years: 52% (male 8,219,080; female 8,172,544)
65 years and over: 2% (male 387,961; female 298,298) (July 1996 est.)
Population growth rate: 3.48% (1996 est.)
Birth rate: 41.08 births/1,000 population (1996 est.)
Death rate: 11.46 deaths/1,000 population (1996 est.)
Net migration rate: 5.17 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 1.3 male(s)/female
all ages: 1.03 male(s)/female (1996 est.)
Infant mortality rate: 76 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 55.12 years
male: 54.2 years
female: 56.09 years (1996 est.)
Total fertility rate: 5.89 children born/woman (1996 est.)
Nationality:
noun: Sudanese (singular and plural)
adjective: Sudanese
Ethnic divisions: black 52%, Arab 39%, Beja 6%, foreigners 2%,
other 1%
Religions: Sunni Muslim 70% (in north), indigenous beliefs 25%,
Christian 5% (mostly in south and Khartoum)
Languages: Arabic (official), Nubian, Ta Bedawie, diverse dialects
of Nilotic, Nilo-Hamitic, Sudanic languages, English
note: program of Arabization in process
Literacy: age 15 and over can read and write (1995 est.)
total population: 46.1%
male: 57.7%
female: 34.6%
------
Population: 436,418 (July 1996 est.)
Age structure:
0-14 years: 34% (male 74,959; female 71,500)
15-64 years: 62% (male 136,287; female 132,407)
65 years and over: 4% (male 9,930; female 11,335) (July 1996 est.)
Population growth rate: 1.6% (1996 est.)
Birth rate: 24.15 births/1,000 population (1996 est.)
Death rate: 5.84 deaths/1,000 population (1996 est.)
Net migration rate: -2.36 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.88 male(s)/female
all ages: 1.03 male(s)/female (1996 est.)
Infant mortality rate: 29.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 70.04 years
male: 67.51 years
female: 72.7 years (1996 est.)
Total fertility rate: 2.68 children born/woman (1996 est.)
Nationality:
noun: Surinamer(s)
adjective: Surinamese
Ethnic divisions: Hindustani (also known locally as "East"
Indians; their ancestors emigrated from northern India in the latter
part of the 19th century) 37%, Creole (mixed European and African
ancestry) 31%, Javanese 15.3%, "Bush Black" (also known as "Bush
Creole" whose ancestors were brought to the country in the 17th and
18th centuries as slaves) 10.3%, Amerindian 2.6%, Chinese 1.7%,
Europeans 1%, other 1.1%
Religions: Hindu 27.4%, Muslim 19.6%, Roman Catholic 22.8%,
Protestant 25.2% (predominantly Moravian), indigenous beliefs 5%
Languages: Dutch (official), English (widely spoken), Sranang
Tongo (Surinamese, sometimes called Taki-Taki, is native language of
Creoles and much of the younger population and is lingua franca
among others), Hindustani (a dialect of Hindi), Javanese
Literacy: age 15 and over can read and write (1995 est.)
total population: 93%
male: 95.1%
female: 91%
------
Population: 2,715 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -4.01% (1996 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Ethnic divisions: Russian and Ukrainian 62%, Norwegian 38%, other
NEGL% (1994)
Languages: Russian, Norwegian
------
Population: 998,730 (July 1996 est.)
Age structure:
0-14 years: 46% (male 227,634; female 229,129)
15-64 years: 52% (male 247,156; female 271,096)
65 years and over: 2% (male 9,864; female 13,851) (July 1996 est.)
Population growth rate: 3.24% (1996 est.)
Birth rate: 42.91 births/1,000 population (1996 est.)
Death rate: 10.56 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.71 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 88.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 57.26 years
male: 53.25 years
female: 61.4 years (1996 est.)
Total fertility rate: 6.05 children born/woman (1996 est.)
Nationality:
noun: Swazi(s)
adjective: Swazi
Ethnic divisions: African 97%, European 3%
Religions: Christian 60%, indigenous beliefs 40%
Languages: English (official, government business conducted in
English), siSwati (official)
Literacy: age 15 and over can read and write (1995 est.)
total population: 76.7%
male: 78%
female: 75.6%','a096e6eae8583819b66b0d980a9377630909788383d0993d23371092c3411a7e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bee6963dac6ec23f9d293b11a5fe2586f7741d3c9d4fa8f10838095accbb843',1996,'NO','Norway','people-and-society',303,'------
Population: 8,900,954 (July 1996 est.)
Age structure:
0-14 years: 19% (male 860,940; female 815,967)
15-64 years: 64% (male 2,884,687; female 2,794,593)
65 years and over: 17% (male 654,439; female 890,328) (July 1996
est.)
Population growth rate: 0.56% (1996 est.)
Birth rate: 11.55 births/1,000 population (1996 est.)
Death rate: 11.43 deaths/1,000 population (1996 est.)
Net migration rate: 5.48 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.74 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 4.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 78.06 years
male: 75.62 years
female: 80.63 years (1996 est.)
Total fertility rate: 1.72 children born/woman (1996 est.)
Nationality:
noun: Swede(s)
adjective: Swedish
Ethnic divisions: white, Lapp (Sami), foreign-born or
first-generation immigrants 12% (Finns, Yugoslavs, Danes,
Norwegians, Greeks, Turks)
Religions: Evangelical Lutheran 94%, Roman Catholic 1.5%,
Pentecostal 1%, other 3.5% (1987)
Languages: Swedish
note: small Lapp- and Finnish-speaking minorities
Literacy: age 15 and over can read and write (1979 est.)
total population: 99%
male: NA%
female: NA%
------
Population: 7,207,060 (July 1996 est.)
Age structure:
0-14 years: 17% (male 638,728; female 610,546)
15-64 years: 68% (male 2,495,325; female 2,405,226)
65 years and over: 15% (male 424,394; female 632,841) (July 1996
est.)
Population growth rate: 0.59% (1996 est.)
Birth rate: 11.35 births/1,000 population (1996 est.)
Death rate: 9.64 deaths/1,000 population (1996 est.)
Net migration rate: 4.2 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.67 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 5.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 77.62 years
male: 74.58 years
female: 80.82 years (1996 est.)
Total fertility rate: 1.47 children born/woman (1996 est.)
Nationality:
noun: Swiss (singular and plural)
adjective: Swiss
Ethnic divisions:
total population: German 65%, French 18%, Italian 10%, Romansch 1%,
other 6%
Swiss nationals: German 74%, French 20%, Italian 4%, Romansch 1%,
other 1%
Religions: Roman Catholic 47.6%, Protestant 44.3%, other 8.1%
(1980)
Languages: German 65%, French 18%, Italian 12%, Romansch 1%, other
4%
note: figures for Swiss nationals only: German 74%, French 20%,
Italian 4%, Romansch 1%, other 1%
Literacy: age 15 and over can read and write (1980 est.)
total population: 99%
male: NA%
female: NA%
------
Population: 15,608,648 (July 1996 est.)
note: in addition, there are 31,300 people living in the
Israeli-occupied Golan Heights - 16,500 Arabs (15,000 Druze and
1,500 Alawites) and 14,800 Israeli settlers (August 1995 est.)
Age structure:
0-14 years: 47% (male 3,738,671; female 3,557,474)
15-64 years: 50% (male 4,013,355; female 3,843,466)
65 years and over: 3% (male 227,249; female 228,433) (July 1996 est.)
Population growth rate: 3.37% (1996 est.)
Birth rate: 39.56 births/1,000 population (1996 est.)
Death rate: 5.86 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 1 male(s)/female
all ages: 1.05 male(s)/female (1996 est.)
Infant mortality rate: 40 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 67.13 years
male: 65.94 years
female: 68.38 years (1996 est.)
Total fertility rate: 5.91 children born/woman (1996 est.)
Nationality:
noun: Syrian(s)
adjective: Syrian
Ethnic divisions: Arab 90.3%, Kurds, Armenians, and other 9.7%
Religions: Sunni Muslim 74%, Alawite, Druze, and other Muslim
sects 16%, Christian (various sects) 10%, Jewish (tiny communities
in Damascus, Al Qamishli, and Aleppo)
Languages: Arabic (official), Kurdish, Armenian, Aramaic,
Circassian, French widely understood
Literacy: age 15 and over can read and write (1995 est.)
total population: 70.8%
male: 85.7%
female: 55.8%
------
Population: 21,465,881 (July 1996 est.)
Age structure:
0-14 years: 23% (male 2,605,495; female 2,436,864)
15-64 years: 69% (male 7,505,344; female 7,252,188)
65 years and over: 8% (male 907,310; female 758,680) (July 1996 est.)
Population growth rate: 0.89% (1996 est.)
Birth rate: 15.01 births/1,000 population (1996 est.)
Death rate: 5.52 deaths/1,000 population (1996 est.)
Net migration rate: -0.61 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 1.2 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 7 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 76.02 years
male: 73.43 years
female: 78.82 years (1996 est.)
Total fertility rate: 1.76 children born/woman (1996 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic divisions: Taiwanese 84%, mainland Chinese 14%, aborigine 2%
Religions: mixture of Buddhist, Confucian, and Taoist 93%,
Christian 4.5%, other 2.5%
Languages: Mandarin Chinese (official), Taiwanese (Min), Hakka
dialects
Literacy: age 15 and over can read and write (1980 est.)
total population: 86%
male: 93%
female: 79%
------
Population: 5,916,373 (July 1996 est.)
Age structure:
0-14 years: 43% (male 1,282,846; female 1,258,302)
15-64 years: 53% (male 1,546,264; female 1,566,365)
65 years and over: 4% (male 110,705; female 151,891) (July 1996 est.)
Population growth rate: 1.54% (1996 est.)
Birth rate: 33.78 births/1,000 population (1996 est.)
Death rate: 8.43 deaths/1,000 population (1996 est.)
Net migration rate: -9.93 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.73 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 113.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 64.45 years
male: 60.84 years
female: 68.24 years (1996 est.)
Total fertility rate: 4.38 children born/woman (1996 est.)
Nationality:
noun: Tajik(s)
adjective: Tajik
Ethnic divisions: Tajik 64.9%, Uzbek 25%, Russian 3.5% (declining
because of emigration), other 6.6%
Religions: Sunni Muslim 80%, Shi''a Muslim 5%
Languages: Tajik (official), Russian widely used in government and
business
Literacy: age 15 and over can read and write (1989 est.)
total population: 98%
male: 99%
female: 97%
------
Population: 29,058,470 (July 1996 est.)
Age structure:
0-14 years: 45% (male 6,536,911; female 6,576,752)
15-64 years: 52% (male 7,360,370; female 7,739,500)
65 years and over: 3% (male 396,128; female 448,809) (July 1996 est.)
Population growth rate: 1.15% (1996 est.)
Birth rate: 41.31 births/1,000 population (1996 est.)
Death rate: 19.47 deaths/1,000 population (1996 est.)
Net migration rate: -10.36 migrant(s)/1,000 population (1996 est.)
note: the total number of Rwandan and Burundian refugees in Tanzania
is about 750,000
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.88 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 105.9 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 42.34 years
male: 40.95 years
female: 43.78 years (1996 est.)
Total fertility rate: 5.67 children born/woman (1996 est.)
Nationality:
noun: Tanzanian(s)
adjective: Tanzanian
Ethnic divisions:
mainland: native African (95% Bantu, consisting of well over 100
tribes) 99%, Asian, European, and Arab 1%
Zanzibar: Arab, mixed Arab and native African, native African
Religions:
mainland: Christian 45%, Muslim 35%, indigenous beliefs 20%
Zanzibar: Muslim more than 99%
Languages: Kiswahili or Swahili (official), Kiunguju (name for
Swahili in Zanzibar), English (official, primary language of
commerce, administration, and higher education), Arabic (widely
spoken in Zanzibar), many local languages
note: Kiswahili (Swahili) is the mother tongue of Bantu people
living in Zanzibar and nearby coastal Tanzania; although Kiswahili
is Bantu in structure and origin, its vocabulary draws on a variety
of sources, including Arabic and English, and it has become the
lingua franca of central and eastern Africa; the first language of
most people is one of the local languages
Literacy: age 15 and over can read and write Kiswahili (Swahili),
English, or Arabic (1995 est.)
total population: 67.8%
male: 79.4%
female: 56.8%
------
Population: 58,851,357 (July 1996 est.)
Age structure:
0-14 years: 25% (male 7,627,916; female 7,351,264)
15-64 years: 69% (male 19,994,884; female 20,576,141)
65 years and over: 6% (male 1,468,814; female 1,832,338) (July 1996
est.)
Population growth rate: 1.03% (1996 est.)
Birth rate: 17.29 births/1,000 population (1996 est.)
Death rate: 7 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.8 male(s)/female
all ages: 0.98 male(s)/female (1996 est.)
Infant mortality rate: 33.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.6 years
male: 64.89 years
female: 72.49 years (1996 est.)
Total fertility rate: 1.89 children born/woman (1996 est.)
Nationality:
noun: Thai (singular and plural)
adjective: Thai
Ethnic divisions: Thai 75%, Chinese 14%, other 11%
Religions: Buddhism 95%, Muslim 3.8%, Christianity 0.5%, Hinduism
0.1%, other 0.6% (1991)
Languages: Thai, English the secondary language of the elite,
ethnic and regional dialects
Literacy: age 15 and over can read and write (1995 est.)
total population: 93.8%
male: 96%
female: 91.6%
------
Population: 259,367 (July 1996 est.)
Age structure:
0-14 years: 28% (male 36,331; female 35,771)
15-64 years: 67% (male 84,107; female 89,193)
65 years and over: 5% (male 5,449; female 8,516) (July 1996 est.)
Population growth rate: 1.05% (1996 est.)
Birth rate: 18.73 births/1,000 population (1996 est.)
Death rate: 5.74 deaths/1,000 population (1996 est.)
Net migration rate: -2.54 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.64 male(s)/female
all ages: 0.94 male(s)/female (1996 est.)
Infant mortality rate: 23.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.53 years
male: 67.98 years
female: 77.16 years (1996 est.)
Total fertility rate: 1.97 children born/woman (1996 est.)
Nationality:
noun: Bahamian(s)
adjective: Bahamian
Ethnic divisions: black 85%, white 15%
Religions: Baptist 32%, Anglican 20%, Roman Catholic 19%,
Methodist 6%, Church of God 6%, other Protestant 12%, none or
unknown 3%, other 2%
Languages: English, Creole (among Haitian immigrants)
Literacy: age 15 and over can read and write but definition of
literacy not available (1995 est.)
total population: 98.2%
male: 98.5%
female: 98%','28f7a82652d033d12e58816c474e63d61e90b89ed61e56dcdea37ddfa057917d','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25ed8e183d9a616bc6a4c84832af9f9bb373d62a3a67d807ed74a39f8945e44b',1996,'SN','Senegal','people-and-society',310,'------
Population: 1,204,984 (July 1996 est.)
Age structure:
0-14 years: 46% (male 276,782; female 275,683)
15-64 years: 51% (male 307,405; female 312,736)
65 years and over: 3% (male 17,278; female 15,100) (July 1996 est.)
Population growth rate: 3.55% (1996 est.)
Birth rate: 44.44 births/1,000 population (1996 est.)
Death rate: 13.66 deaths/1,000 population (1996 est.)
Net migration rate: 4.72 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1.14 male(s)/female
all ages: 1 male(s)/female (1996 est.)
Infant mortality rate: 80.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 52.96 years
male: 50.74 years
female: 55.24 years (1996 est.)
Total fertility rate: 6.06 children born/woman (1996 est.)
Nationality:
noun: Gambian(s)
adjective: Gambian
Ethnic divisions: African 99% (Mandinka 42%, Fula 18%, Wolof 16%,
Jola 10%, Serahuli 9%, other 4%), non-Gambian 1%
Religions: Muslim 90%, Christian 9%, indigenous beliefs 1%
Languages: English (official), Mandinka, Wolof, Fula, other
indigenous vernaculars
Literacy: age 15 and over can read and write (1995 est.)
total population: 38.6%
male: 52.8%
female: 24.9%
------
Population: 4,570,530 (July 1996 est.)
Age structure:
0-14 years: 49% (male 1,116,030; female 1,105,957)
15-64 years: 49% (male 1,085,774; female 1,163,374)
65 years and over: 2% (male 46,089; female 53,306) (July 1996 est.)
Population growth rate: 3.56% (1996 est.)
Birth rate: 46.23 births/1,000 population (1996 est.)
Death rate: 10.66 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.86 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 84.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 57.87 years
male: 55.7 years
female: 60.1 years (1996 est.)
Total fertility rate: 6.75 children born/woman (1996 est.)
Nationality:
noun: Togolese (singular and plural)
adjective: Togolese
Ethnic divisions: native African (37 tribes; largest and most
important are Ewe, Mina, and Kabre) 99%, European and
Syrian-Lebanese less than 1%
Religions: indigenous beliefs 70%, Christian 20%, Muslim 10%
Languages: French (official and the language of commerce), Ewe and
Mina (the two major African languages in the south), Dagomba and
Kabye (sometimes spelled Kabiye; the two major African languages in
the north)
Literacy: age 15 and over can read and write (1995 est.)
total population: 51.7%
male: 67%
female: 37%
------
Population: 1,482 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -1.35% (1996 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Tokelauan(s)
adjective: Tokelauan
Ethnic divisions: Polynesian
Religions: Congregational Christian Church 70%, Roman Catholic
28%, other 2%
note: on Atafu, all Congregational Christian Church of Samoa; on
Nukunonu, all Roman Catholic; on Fakaofo, both denominations, with
the Congregational Christian Church predominant
Languages: Tokelauan (a Polynesian language), English','44d3e5da2cdc9f36cde82c88f04f24676fcebc686c8f9b2fd4c88deb9ecee2e4','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3e625834088432e8d3e31e43772f5d0159ec33b745ec6eef3d5502d58ce6998',1996,'NZ','New Zealand','people-and-society',321,'------
Population: 106,466 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.82% (1996 est.)
Birth rate: 27.33 births/1,000 population (1996 est.)
Death rate: 6.26 deaths/1,000 population (1996 est.)
Net migration rate: -1.29 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 40.26 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 69.04 years
male: 67.03 years
female: 71.4 years (1996 est.)
Total fertility rate: 3.75 children born/woman (1996 est.)
Nationality:
noun: Tongan(s)
adjective: Tongan
Ethnic divisions: Polynesian, Europeans about 300
Religions: Christian (Free Wesleyan Church claims over 30,000
adherents)
Languages: Tongan, English
Literacy: age 15 and over can read and write a simple message in
Tongan or English (1976 est.)
total population: 100%
male: 100%
female: 100%
------
Population: 1,272,385 (July 1996 est.)
Age structure:
0-14 years: 30% (male 193,134; female 186,649)
15-64 years: 64% (male 413,426; female 404,175)
65 years and over: 6% (male 33,791; female 41,210) (July 1996 est.)
Population growth rate: 0.08% (1996 est.)
Birth rate: 16.25 births/1,000 population (1996 est.)
Death rate: 6.9 deaths/1,000 population (1996 est.)
Net migration rate: -8.58 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.82 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 18.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 70.3 years
male: 67.91 years
female: 72.77 years (1996 est.)
Total fertility rate: 1.99 children born/woman (1996 est.)
Nationality:
noun: Trinidadian(s), Tobagonian(s)
adjective: Trinidadian, Tobagonian
Ethnic divisions: black 43%, East Indian (a local term - primarily
immigrants from northern India) 40%, mixed 14%, white 1%, Chinese
1%, other 1%
Religions: Roman Catholic 32.2%, Hindu 24.3%, Anglican 14.4%,
other Protestant 14%, Muslim 6%, none or unknown 9.1%
Languages: English (official), Hindi, French, Spanish
Literacy: age 15 and over can read and write (1995 est.)
total population: 97.9%
male: 98.8%
female: 97%','e5906bc27550ec9ae7f94fca9cec12674c16788632f5b5b79bee6b82f441463f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87ecfe8da8017afbe68c8612b2c426171caac86f824e478d7be72f072a615f8c',1996,'SC','Seychelles','people-and-society',324,'------
Population: uninhabited
------
Population: 9,019,687 (July 1996 est.)
Age structure:
0-14 years: 34% (male 1,583,636; female 1,489,784)
15-64 years: 61% (male 2,738,013; female 2,719,998)
65 years and over: 5% (male 254,403; female 233,853) (July 1996 est.)
Population growth rate: 1.81% (1996 est.)
Birth rate: 24.03 births/1,000 population (1996 est.)
Death rate: 5.18 deaths/1,000 population (1996 est.)
Net migration rate: -0.74 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 1.09 male(s)/female
all ages: 1.03 male(s)/female (1996 est.)
Infant mortality rate: 35.1 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.6 years
male: 71.27 years
female: 74.03 years (1996 est.)
Total fertility rate: 2.92 children born/woman (1996 est.)
Nationality:
noun: Tunisian(s)
adjective: Tunisian
Ethnic divisions: Arab-Berber 98%, European 1%, Jewish less than 1%
Religions: Muslim 98%, Christian 1%, Jewish 1%
Languages: Arabic (official and one of the languages of commerce),
French (commerce)
Literacy: age 15 and over can read and write (1995 est.)
total population: 66.7%
male: 78.6%
female: 54.6%
------
Population: 62,484,478 (July 1996 est.)
Age structure:
0-14 years: 32% (male 10,192,195; female 9,836,045)
15-64 years: 62% (male 19,859,717; female 19,187,769)
65 years and over: 6% (male 1,571,451; female 1,837,301) (July 1996
est.)
Population growth rate: 1.67% (1996 est.)
Birth rate: 22.26 births/1,000 population (1996 est.)
Death rate: 5.52 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.86 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 43.2 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71.92 years
male: 69.53 years
female: 74.43 years (1996 est.)
Total fertility rate: 2.58 children born/woman (1996 est.)
Nationality:
noun: Turk(s)
adjective: Turkish
Ethnic divisions: Turkish 80%, Kurdish 20%
Religions: Muslim 99.8% (mostly Sunni), other 0.2% (Christian and
Jews)
Languages: Turkish (official), Kurdish, Arabic
Literacy: age 15 and over can read and write (1995 est.)
total population: 82.3%
male: 91.7%
female: 72.4%
------
Population: 4,149,283 (July 1996 est.)
Age structure:
0-14 years: 39% (male 826,637; female 804,385)
15-64 years: 56% (male 1,154,415; female 1,188,173)
65 years and over: 5% (male 65,447; female 110,226) (July 1996 est.)
Population growth rate: 1.82% (1996 est.)
Birth rate: 29.12 births/1,000 population (1996 est.)
Death rate: 8.89 deaths/1,000 population (1996 est.)
Net migration rate: -2.08 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.59 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 81.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 61.48 years
male: 56.68 years
female: 66.52 years (1996 est.)
Total fertility rate: 3.62 children born/woman (1996 est.)
Nationality:
noun: Turkmen(s)
adjective: Turkmen
Ethnic divisions: Turkmen 73.3%, Russian 9.8%, Uzbek 9%, Kazak 2%,
other 5.9%
Religions: Muslim 87%, Eastern Orthodox 11%, unknown 2%
Languages: Turkmen 72%, Russian 12%, Uzbek 9%, other 7%
Literacy: age 15 and over can read and write (1989 est.)
total population: 98%
male: 99%
female: 97%
------
Population: 14,302 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 2.14% (1996 est.)
Birth rate: 12.85 births/1,000 population (1996 est.)
Death rate: 5.15 deaths/1,000 population (1996 est.)
Net migration rate: 13.74 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 12.57 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.4 years
male: 73.46 years
female: 77.07 years (1996 est.)
Total fertility rate: 1.86 children born/woman (1996 est.)
Nationality:
noun: none
adjective: none
Ethnic divisions: African
Religions: Baptist 41.2%, Methodist 18.9%, Anglican 18.3%,
Seventh-Day Adventist 1.7%, other 19.9% (1980)
Languages: English (official)
Literacy: age 15 and over has ever attended school (1970 est.)
total population: 98%
male: 99%
female: 98%','0b94666837d4579191d26f1b82779b352e76ece3b569a8ec774a238879c5954c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47413e2ed8402c4a2993f0c5c87c8649881ba453438ec061eb19aae2d6a2b72d',1996,'NC','New Caledonia','people-and-society',335,'------
Population: 177,504 (July 1996 est.)
Age structure:
0-14 years: 40% (male 36,409; female 35,105)
15-64 years: 57% (male 51,969; female 48,901)
65 years and over: 3% (male 2,802; female 2,318) (July 1996 est.)
Population growth rate: 2.17% (1996 est.)
Birth rate: 30.57 births/1,000 population (1996 est.)
Death rate: 8.84 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.06 male(s)/female
65 years and over: 1.21 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 64.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 60.13 years
male: 58.27 years
female: 62.09 years (1996 est.)
Total fertility rate: 4.01 children born/woman (1996 est.)
Nationality:
noun: Ni-Vanuatu (singular and plural)
adjective: Ni-Vanuatu
Ethnic divisions: indigenous Melanesian 94%, French 4%,
Vietnamese, Chinese, Pacific Islanders
Religions: Presbyterian 36.7%, Anglican 15%, Catholic 15%,
indigenous beliefs 7.6%, Seventh-Day Adventist 6.2%, Church of
Christ 3.8%, other 15.7%
Languages: English (official), French (official), pidgin (known as
Bislama or Bichelama)
Literacy: age 15 and over can read and write (1979 est.)
total population: 53%
male: 57%
female: 48%','12a6edd6dc4f0839cf40dfd04122141d5c744c54871fd5212a19323734b49615','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d88d51b3b8d79bc5e1024b2873b575ea5173be8d55df3cc19d8604a5641b98ab',1996,'GY','Guyana','people-and-society',343,'------
Population: 73,976,973 (July 1996 est.)
Age structure:
0-14 years: 36% (male 13,739,304; female 12,988,929)
15-64 years: 59% (male 20,956,735; female 22,448,944)
65 years and over: 5% (male 1,548,513; female 2,294,548) (July 1996
est.)
Population growth rate: 1.57% (1996 est.)
Birth rate: 23 births/1,000 population (1996 est.)
Death rate: 6.95 deaths/1,000 population (1996 est.)
Net migration rate: -0.35 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.68 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 38.4 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 67.02 years
male: 64.69 years
female: 69.48 years (1996 est.)
Total fertility rate: 2.69 children born/woman (1996 est.)
Nationality:
noun: Vietnamese (singular and plural)
adjective: Vietnamese
Ethnic divisions: Vietnamese 85%-90%, Chinese 3%, Muong, Thai,
Meo, Khmer, Man, Cham
Religions: Buddhist, Taoist, Roman Catholic, indigenous beliefs,
Islam, Protestant
Languages: Vietnamese (official), French, Chinese, English, Khmer,
tribal languages (Mon-Khmer and Malayo-Polynesian)
Literacy: age 15 and over can read and write (1995 est.)
total population: 93.7%
male: 96.5%
female: 91.2%
------
Population: 97,120 (July 1996 est.)
note: West Indian (45% born in the Virgin Islands and 29% born
elsewhere in the West Indies) 74%, US mainland 13%, Puerto Rican 5%,
other 8%
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -0.06% (1996 est.)
Birth rate: 17.57 births/1,000 population (1996 est.)
Death rate: 5.2 deaths/1,000 population (1996 est.)
Net migration rate: -12.94 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 12.54 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 75.29 years
male: 73.6 years
female: 77.2 years (1996 est.)
Total fertility rate: 2.29 children born/woman (1996 est.)
Nationality:
noun: Virgin Islander(s)
adjective: Virgin Islander
Ethnic divisions: black 80%, white 15%, other 5%
Religions: Baptist 42%, Roman Catholic 34%, Episcopalian 17%,
other 7%
Languages: English (official), Spanish, Creole
Literacy: NA','43c45a71f1617b786aac6a7d7cca326de08a07726abee6c0049e6160fd1c1ecc','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef5d8968a419755e3be33caeb00464e51923eabae7325ea754d3a26b6560083e',1996,'MP','Northern Mariana Islands','people-and-society',350,'------
Population: no indigenous inhabitants; there are 302 US military
and contract personnel (July 1995 est.)
Population growth rate: 0% (1996 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
------
Population: 14,659 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.11% (1996 est.)
Birth rate: 24.38 births/1,000 population (1996 est.)
Death rate: 5.02 deaths/1,000 population (1996 est.)
Net migration rate: -8.23 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 23.59 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 72.76 years
male: 72.16 years
female: 73.4 years (1996 est.)
Total fertility rate: 3 children born/woman (1996 est.)
Nationality:
noun: Wallisian(s), Futunan(s), or Wallis and Futuna Islanders
adjective: Wallisian, Futunan, or Wallis and Futuna Islander
Ethnic divisions: Polynesian
Religions: Roman Catholic 100%
Languages: French, Wallisian (indigenous Polynesian language)
Literacy: age 15 and over can read and write (1969 est.)
total population: 50%
male: 50%
female: 50%
------
Population: 1,427,741 (July 1996 est.)
note: in addition, there are 127,600 Israeli settlers in the West
Bank and 153,700 in East Jerusalem (August 1995 est.)
Age structure:
0-14 years: 45% (male 332,628; female 315,968)
15-64 years: 51% (male 368,180; female 362,880)
65 years and over: 4% (male 20,495; female 27,590) (July 1996 est.)
Population growth rate: 4.99% (1996 est.)
Birth rate: 38.78 births/1,000 population (1996 est.)
Death rate: 4.66 deaths/1,000 population (1996 est.)
Net migration rate: 15.76 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.74 male(s)/female
all ages: 1.02 male(s)/female (1996 est.)
Infant mortality rate: 28.6 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 71.76 years
male: 70.17 years
female: 73.44 years (1996 est.)
Total fertility rate: 5.2 children born/woman (1996 est.)
Nationality:
noun: NA
adjective: NA
Ethnic divisions: Palestinian Arab and other 83%, Jewish 17%
Religions: Muslim 75% (predominantly Sunni), Jewish 17%, Christian
and other 8%
Languages: Arabic, Hebrew (spoken by Israeli settlers), English
(widely understood)
Literacy: NA
------
Population: 222,631 (July 1996 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 2.46% (1996 est.)
Birth rate: 46.51 births/1,000 population (1996 est.)
Death rate: 18.02 deaths/1,000 population (1996 est.)
Net migration rate: -3.94 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s)/female
Infant mortality rate: 145.82 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 47.01 years
male: 46 years
female: 48.34 years (1996 est.)
Total fertility rate: 6.85 children born/woman (1996 est.)
Nationality:
noun: Sahrawi(s), Sahraoui(s)
adjective: Sahrawian, Sahraouian
Ethnic divisions: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan Arabic
Literacy: NA
------
Population: 214,384 (July 1996 est.)
Age structure:
0-14 years: 40% (male 43,540; female 42,185)
15-64 years: 56% (male 62,742; female 57,323)
65 years and over: 4% (male 4,089; female 4,505) (July 1996 est.)
Population growth rate: 2.37% (1996 est.)
Birth rate: 31.12 births/1,000 population (1996 est.)
Death rate: 5.75 deaths/1,000 population (1996 est.)
Net migration rate: -1.67 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.1 male(s)/female
65 years and over: 0.91 male(s)/female
all ages: 1.06 male(s)/female (1996 est.)
Infant mortality rate: 34.3 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 68.73 years
male: 66.35 years
female: 71.24 years (1996 est.)
Total fertility rate: 3.93 children born/woman (1996 est.)
Nationality:
noun: Western Samoan(s)
adjective: Western Samoan
Ethnic divisions: Samoan 92.6%, Euronesians 7% (persons of
European and Polynesian blood), Europeans 0.4%
Religions: Christian 99.7% (about one-half of population
associated with the London Missionary Society; includes
Congregational, Roman Catholic, Methodist, Latter-Day Saints,
Seventh-Day Adventist)
Languages: Samoan (Polynesian), English
Literacy: age 15 and over can read and write (1971 est.)
total population: 97%
male: 97%
female: 97%
------
Population: 5,771,939,007 (July 1996 est.)
Age structure:
0-14 years: 31% (male 919,402,570; female 874,330,478)
15-64 years: 62% (male 1,824,524,365; female 1,776,639,084)
65 years and over: 7% (male 162,216,128; female 213,712,993)
Population growth rate: 1.4% (1996 est.)
Birth rate: 23 births/1,000 population (1996 est.)
Death rate: 9 deaths/1,000 population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.76 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 60 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 62 years
male: 61 years
female: 64 years
Total fertility rate: 2.9 children born/woman (1996 est.)
------
Population: 13,483,178 (July 1996 est.)
Age structure:
0-14 years: 48% (male 3,302,489; female 3,122,246)
15-64 years: 50% (male 3,327,682; female 3,364,787)
65 years and over: 2% (male 158,018; female 207,956) (July 1996 est.)
Population growth rate: 3.56% (1996 est.)
Birth rate: 45.22 births/1,000 population (1996 est.)
Death rate: 9.59 deaths/1,000 population (1996 est.)
Net migration rate: 0 migrant(s)/1,000 population (1996 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.76 male(s)/female
all ages: 1.01 male(s)/female (1996 est.)
Infant mortality rate: 71.5 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 59.58 years
male: 58.23 years
female: 60.99 years (1996 est.)
Total fertility rate: 7.29 children born/woman (1996 est.)
Nationality:
noun: Yemeni(s)
adjective: Yemeni
Ethnic divisions: predominantly Arab; Afro-Arab concentrations in
western coastal locations; South Asians in southern regions; small
European communities in major metropolitan areas
Religions: Muslim including Sha''fi (Sunni) and Zaydi (Shi''a),
small numbers of Jewish, Christian, and Hindu
Languages: Arabic
Literacy: age 15 and over can read and write (1990 est.)
total population: 38%
male: 53%
female: 26%
------
Population: 46,498,539 (July 1996 est.)
Age structure:
0-14 years: 48% (male 11,161,347; female 11,124,583)
15-64 years: 49% (male 11,197,097; female 11,783,524)
65 years and over: 3% (male 539,775; female 692,213) (July 1996 est.)
Population growth rate: 1.67% (1996 est.)
Birth rate: 48.1 births/1,000 population (1996 est.)
Death rate: 16.9 deaths/1,000 population (1996 est.)
Net migration rate: -14.56 migrant(s)/1,000 population (1996 est.)
note: in 1994, more than one million refugees fled into Zaire to
escape the fighting between the Hutus and the Tutsis in Rwanda and
Burundi; a small number of these returned to their homes in 1995
despite fear of the ongoing violence; additionally, Zaire is host to
about 100,000 Angolan, and about 100,000 Sudanese refugees
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.78 male(s)/female
all ages: 0.97 male(s)/female (1996 est.)
Infant mortality rate: 108 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 46.7 years
male: 44.97 years
female: 48.47 years (1996 est.)
Total fertility rate: 6.64 children born/woman (1996 est.)
Nationality:
noun: Zairian(s)
adjective: Zairian
Ethnic divisions: over 200 African ethnic groups, the majority are
Bantu; four largest tribes - Mongo, Luba, Kongo (all Bantu), and the
Mangbetu-Azande (Hamitic) make up about 45% of the population
Religions: Roman Catholic 50%, Protestant 20%, Kimbanguist 10%,
Muslim 10%, other syncretic sects and traditional beliefs 10%
Languages: French (official), Lingala (a lingua franca trade
language), Kingwana (a dialect of Kiswahili or Swahili), Kikongo,
Tshiluba
Literacy: age 15 and over can read and write in French, Lingala,
Kingwana, or Tshiluba (1995 est.)
total population: 77.3%
male: 86.6%
female: 67.7%','b4de997638a97c377b48277c38cc04916de0f6d325dad41b9997950c7f1000b0','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ef0698cce2af73c943e2ab8291ec4f4979cfb7aa62d02a7c76f362a5e8ced99',1996,'BW','Botswana','people-and-society',357,'------
Population: 11,271,314 (July 1996 est.)
Age structure:
0-14 years: 44% (male 2,513,606; female 2,481,478)
15-64 years: 53% (male 2,935,188; female 3,030,270)
65 years and over: 3% (male 152,244; female 158,528) (July 1996 est.)
Population growth rate: 1.41% (1996 est.)
Birth rate: 32.34 births/1,000 population (1996 est.)
Death rate: 18.2 deaths/1,000 population (1996 est.)
Net migration rate: NA migrant(s)/1,000 population (1996 est.)
note: there is a small but steady flow of Zimbabweans into South
Africa in search of better paid employment
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.96 male(s)/female
all ages: 0.99 male(s)/female (1996 est.)
Infant mortality rate: 72.8 deaths/1,000 live births (1996 est.)
Life expectancy at birth:
total population: 41.85 years
male: 41.91 years
female: 41.78 years (1996 est.)
Total fertility rate: 4.09 children born/woman (1996 est.)
Nationality:
noun: Zimbabwean(s)
adjective: Zimbabwean
Ethnic divisions: African 98% (Shona 71%, Ndebele 16%, other 11%),
white 1%, mixed and Asian 1%
Religions: syncretic (part Christian, part indigenous beliefs)
50%, Christian 25%, indigenous beliefs 24%, Muslim and other 1%
Languages: English (official), Shona, Sindebele (the language of
the Ndebele, sometimes called Ndebele), numerous but minor tribal
dialects
Literacy: age 15 and over can read and write in English (1995 est.)
total population: 85%
male: 90%
female: 80%','cf96bb85e2b897d76ee83d42eaa246cbce4bf3a6c06289795e778682c97fafd0','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

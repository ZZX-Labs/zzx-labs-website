SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a652b255fe80445ecf70c0785cd626d24f1f0f9e45b78356cdf3f931a20c7a14',1996,'TM','Turkmenistan','geography',6,'Location: Southern Asia. north of Pakistan
Geographic coordinates: 33 00 N. 65 00 E
Map references: Asia
Area:
total area: 647.500 sq km
land area, 647,500 sq km
comparative area: slightly smaller than
Texas
Land boundaries:
total: 5.529 km
border countries: China 76 km, Iran 936 km.
Pakistan 2.430 km. Tajikistan 1,206 km.
Turkmenistan 744 km, Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: periodic disputes
with Iran over Helmand water nghts: Iran
supports clients in country. private Pakistani
and Saudi sources also are active: power
Struggles among various groups for control
of Kabul, regional rivalries among emerging
warlords, traditional tribal disputes continue:
support to Islamic fighters in Tayikistan’s
civil war: border dispute with Pakistan
(Durand Line): support to Islamic militants
worldwide by some factions
Climate: arid to semiarid: cold winters and
hot summers
Terrain: mostiy rugged mountains: plains in
north and southwest
lowest point: Amu Darya 258 m
highest point: Nowshak 7.485 m
Natural resources: natural gas. pe‘roleum,
coal, copper. talc. barites, sulfur, lead, zine.
iron ore, salt. precious and semiprecious
Stones
Land use:
arable land: 12%
(
permanent crops: O%
meadows and pastures: 46%
forest and woodland: 3%
other: 39%
irrigated land: 26.600 sq km (1989 est.)','e42bba16888fd640f551e61f206b1992330634d7a96bf0278f1e4370825b846b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0234d82992a89c22369ba247537d322df7120185ed6fd7c70dd7da48de697acf',1996,'AL','Albania','geography',14,'Location: Southeastern Europe. bordering
the Adnatic Sea and lonian Sea. betwen
Greece and Serbia and Montenegro
Geographic coordinates: 4) 00) \\
Map references: Europe
Area:
total area: 28.750 sq km
land area: 27.400 sq km
comparative area: slightly larger than
Mary land
Land boundaries:
total: 720 km
border countries: Greece 28> km. The
nO]
Formet Yugoslay Republic of Macedonia
1S) km. Serbia and Montenegro 287 km
(114 km with Serbia. 173 km wath
Montenegro)
Coastline: 362 km
Maritime claims:
continental shelf, 200-m depth or to the
depth of exploitation
lerriiorial seas 12 nm
International disputes: the Alba
Government supports protection ot the rights
of ethnic Albanians outside of its borders
Albanian majority in Kosovo seeks
independence trom Serbian Republi
Albaaians in Macedonia claim discrimination
in education, access to public-sector yobs and
representation in government. Albania ts
involved in negotiations with Greece ove:
border demarcation. the treatment ot
Albania s ethnic Greek minority. and migrant
Albanian workers in Greece
Climate: mild temperate. cool. cloudy. wet
winters: hot. clear, dry summers: interior ts
cooler and wetter
Terrain: mostly mountains and hills: small
plains along coast
lowest pou Adnatic Sea 0 m
point Maja e Korabit 2.753 m
highest |
Natural resources: petrojeum. natural gas.
coal, chromium, copper. umber. nickel
Land use:
arable iand: 2
f rnanens ory }
;* ‘ i { j —-
i |
clie?
Irrigated land: 4.. ykn SY
Location: Northern Ainca. border
Mediterranean Sea. between Mor
Punisia
Geographic coordinates: 25 00 \\ Md |
Map references: Airco
Area:
total area 381.740 sg km
,
land area? 2.381.740 sa km
comparanve area slightly less tha
tumes the size of Texas
Land boundaries:
total: 6.343 km
horder countries. Liabwa YS2 km. Mali 1.37¢
km. Mauritania 463 km. Morocco 1.4859 kn
Niger 956 km. Tunisia 965 km. Western
Sahara 42 km
Coastline: 998 km
Maritime claims:
ervclusive fishing cone: 32-5. nm
rerriuorial sea. \\2nm
International disputes: part of southeastern
region clamed by Libva: land boundary
dispute with Tunisia settled in 1992
Climate: and to semiand: nuld. wet winte;
with hot. dry summers along coast: din
with cold winters and hot summers
plateau sirecce moa hot. dust/sand-lacdk
wind especially common tn summ
lerrain: mostly high plateau and «
some ro qantas: narrow, discontin
coastal plan
lowest point: Chott Mearhir -40 1
highest point: Tahat 3.0038 m
Natural resources: petroleum. natural cus
iron ore, phosphates. uranium, lead. 71
Land use:
arable land Vy
permanent crops:
ile adow § and puisiure 4 yy
/4h
Algeria (continued)
7
Irrivated land: +360) su kn YN? Osi
Location: Oceana. group of islands in the
South Pacithe Ocean. about one-half of the
was from Hewan to New Zealand
Ceographi: coordinates: |4 20 8. 170.00
“
Map references: Occanis
\\rea:
Hal areca: 199 sq km
; ''
ana adtca ivy ~ kim
commarative arca. stiehtly larger than
W msfhnction 1
mecludes Row
Land houndaries: () km
Coastline: | 16 km
Maritime claims:
sii Cowon cle aH) ne
)
,
7 ‘eal i. THN
International disputes: none
Climate: tropical marine. moderated by
Island and Swarms Island
witheast trade winds. annual ramtall
averages 124 inches: rainy season trom
Noveraber to April. dry season trom May to
October. lithe seasonal temperature vanation
Perrain: five volcame islands with rugged
peaks and linuted coasal plains two coral
(Rose Island, Swains Island)
owest point. Pacitte Ocean 0 m
highest pot: Lata 966 m
Land use:
wahle land: 1\\OG
permancntl crops 8G
meadows and pustures (yy
forest and woodland: 78%
olnet 1iy,
Irrigated land: NA sg km
Natural resources: punnice, pumicite
Location: Southwestern Europe. between
France and Spain
Geographic coordinates: 42 40 N. | {0 F
Map references: Europe
Area:
total area: 450 sy km
land area: 450 sq km
comparative area: 2.5 mes the size ot
Washington. DC
Land boundaries:
total: 125 km
vorder countries: France 60 km. Spain 65
km
Coastline: 0 km (landlocked)
Maritime ciaires: none (landlocked)
International disputes: nonc
Climate: temperaie: snowy. cold winters and
warm, dry summers
Terrain: rugged mountains dissected by
narrow valleys
lowest point: Row Valira 840 m
highest point: Coma Pedrosa 2.946 m
Natural resources: hydropower. mineral
water, timber. iron ore, lead
Land use:
arable land: 2*
permanent crops: Os
meadows and pastures: S6''4
forest and woodland: 22%
other: 20%
Irrigated land: NA sy km','b47736cb0436330dac04f649a8c987fd938a5d10e4df050dd5f39ff5c60f73fd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1177521e94edf5365beae0db310513ea74ccecc4f80f6bfc6d8916a609bea68f',1996,'ES','Spain','geography',21,'Location: Southern Atrica, bordering the
South Atlantic Ocean, between Namibia and
Zaire
Geographic coordinates: |2 30S. 18 30E
Map references: Africa
Area:
total area: 1,246,700 sq km
land area: 1.246.700 sq km
comparative area: slightly less than twice
the size of Texas
Land boundaries:
total: SA98 km
border countries: Congo 201 km. Namibia
1.376 km, Zaire 2.511) km. Zambia 1.110 km
Coastline: |.600 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 20 nm
International disputes: none
Climate: semiarid in south and along coast
to Luanda: north has cool. dry season (May
to October) and hot. rainy season (November
to April)
Terrain: narrow coastal plain rises abruptly
to vast interior plateau
lowest point: Atlantic Ocean 0 m
highest point: Moro de Moco 2,620 m
Natural resources: petroleum, diamonds,
iron ore. phosphates, copper. feldspar, gold,
bauxite, uranium
Land use:
arable land: 2%
permanent crops: O%
meadows and pastures: 23%
forest and woodland: 43%
other, 32°
Irrigated land: NA sy km
Location: Suuthwestern Europe. bordering
the North Atlantic Ocean. west of Spain
(,eographic coordinates: 39 30 N. 8 00 W
Map references: Europe
\\rea:
total area: 92.4080 sq km
land area: 91.640 sq km
comparative area: slightly smaller than
Indiana
note: mecludes Azores and Madeira Islands
Land boundaries:
htal: 1.214 km
horder country: Spain 1.214 km
Coastline: |.793 km
Viaritime claims:
continental shelf: 200-m depth or to the
depth of exploitation
exclusive economic cone: 200 am
territorial sea |}? nim
International disputes: sovereignty over
Timor Timur (East Timor Province) disputed
with Indonesia and not recognized by th
UN
Climate: maritime temperate: cool and rainy
in north, warmer and drier in south
Terrain: mountainous north of the Tagus,
rolling plains in south
iowest point: Atlantic Ocean 0 m
highest point: Ponta do Pico in Azores 2.351
m
Natural resources: fish, forests (cork).
tungsten, iron ore, uranium ore, marble
Land use:
arable land: 32%
permanent crops: 6%
meadows and pastures: 6%
forest and woodland: 40%
other: 16%
Irrigated land: 6.340 sg km (1989 est)
Location: Southern Africa, island in the
Indian Ocean, east of Madagascar
Geographic coordinates: 15 52 S. 54 25 E
Map references: Africa
Area:
total area: | sq km
land area: | sq km
comparative area: about 1.7 times the size
of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 3.7 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to the
depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by
Madagascar, Mauritius, and Seychelles
Climate: tropical
Terrain: sandy
lowest point: Indian Ocean 0 m
highest point: unnamed location 7 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (scattered bushes)
Irrigated land: 0 sq km','b7a8aedb652341230bcd5ef9d5b5ffd20416bf6acc333e2f66d2a94b285c11af','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a54616b9c0ccf1f934d4d0182ff9d4caf8a5004c198ff95ac2b7ef9256b7bf3b',1996,'BR','Brazil','geography',28,'Location: Caribbean. island in the Caribbean
Sea, east of Puerto Rico
Geographic coordinates: [8 15 N63 10 \\
Map references: Central America and the
Canbbean
Area:
total area: 91 sq km
land area: 91 sq km
comparative area: about halt the size of
Washington. DC
Land boundaries: () km
Coastline: 61 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical: moderated by northeast
trade winds
Terrain: flat and low-lying island of coral
and limestone
lowest point: Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt. fish. lobster
Land use:
arable land: NAG
permanent crops: NAG
meadows and pastures: NAG
forest and woodland: NAG
other: NA% (mostly rock with sparse scrub
oak. few trees. some Commercial salt ponds
Irrigated land: NA sq km','be5626a0e1377c4bf3c59308244f6a51d4908b4d2cabbb2354f0df6e1d8c9ada','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26b88a9280bb9eb04518077461870fb94160962db867e9052f22052579232912',1996,'AQ','Antarctica','geography',32,'Location: continent mostly south of the
Antarctic Circle
Geographic coordinates: 90 00 S.0 00 E
Map references: Antarctic Region
Area:
total area: 14 million sq km Cest.)
land area: 14 millon sg km (est)
comparative area: slightly less than 1.5
limes the size of the US
note; second-smallest continent (alter
Australia)
Land boundaries: 0 km
note, see entry on International disputes
Coastline: 17.968 kin
Maritime claims: none. but see entry on
International disputes
International disputes: Antarctic Treaty
defers claims (see Antarctic Treaty Summary
below). sections (some overlapping) clarined
by Argentina. Australia. Chile. France
(Adelie Land). New Zealand (Ross
Dependency). Norway (Queen Maud Land
and UK: the US and most other nations d
not recognize the territorial claims of othe:
nations and have made no claims themsels es
(the US reserves the nght to do so). no
formal claims have been made in the sector
between 90 degrees west and 150 degrees
west
Climate: severe low temperatures vary with
latitude. elevation. and distance trom the
ocean: East Antarctica 1s colder than West
Antarctica because of its higher elevation
Antarctic Peninsula has the most moderate
climate: higher temperatures occur in
January aloag the coast and average slightly
below freezing
Terrain: about 98% thick continental ice
sheet and 2% barren rock. with average
elevations between 2.000 and 4.000 meters:
mountain ranges up to about 5.000 meters:
ice-free Coastal areas include parts of
southern Victoria Land, Wilkes Land. the
Antarctic Peninsula area, and parts of Ross
Island on McMurdo Sound: glaciers form ice
Shelves along about half of the coastline. and
floating ice shelves constitute 11% of the
area of the continent
lowest point: Indian Ocean 0 m
highest point: Vinson Massit 3.440 m
Natural resources: none presently exploited:
iron ore. chromium. copper. gold
platinum and other mincrals
hydrocarbons have been found
uncommercial quant tic
Land use:
arable land: 0
permane fai yes {}
meadow . dnd paslit )
/ , J. ‘
lores! Ghd woodland
other: (OOW Uce Ys barren rock
Irrigated land: ©) su kn','ad22c03533f9151301507aab5737db1b51e8e74e04c6e7693c31fb01449d1317','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56beb4ac4c92cd79d73498eedac40d6c539517c53cce25ea7c439092a71e7b80',1996,'AG','Antigua and Barbuda','geography',39,'Location: Caribbean. islands between the
Canbbean Sea and the North Adantic Ocean
easi-southeast of Puerto Rico
Geographic coordinates: |7 04 N. 6) 45 W
Map references: Central America and the
Canbbean
Area:
total area: 440 sq km
lund area: 440 sq km
comparanve area
Washington, DC
note: includes Redonda
Land boundaries: 0 km
Coastline: 153 kin
Maritime claims:
oe |
+nm
2.5 tumes the size of
CONTIQUOUS TONE
continental shelf: 200 nm or to the edge ot
the continental margin
exclusive economic zone: 200 nm
12 nm
International disputes: none
Climate: tropical marine: little seasonal
territorial sea
temperature variation
Terrain: mostly low-lying limestone and
coral islands with some higher volcanic areas
lowest point: Caribbean Sea 0 m
highest poimt Bogyy Peak 402 m
Natural resources: negligible. pleasant
climate fosters tourism
Land use:
arable land: (18%
permanent crops: 0%
meadows and pastures: 7°
forest and woodland: \\6%
other: SYG%
irrigated land: NA sg km
Location: body of water mostly north of the
Arctic Circle
Ceographic coordinates: 90 00 N_0.001
Map references: Arctic Region
Area:
total area: 14.056 million sq km
comparative area: siightly more than 1.5
tumes the size of the US. smallest of the
world''s tour oceans (alter Pacific Ocean
Atlantic Ocean. and Indian Ocean)
vote. includes Battin Bay. Barents Sea
Beautort Sea. Chukchi Sea. East Srbernan
Sea. Greenland Sea. Hudson Bay. Hudson
Strat. Kara Sea. Laptey Sea. Northwest
Passage. and other tributary water bodies
Coastline: 45.389 km
International disputes: s
disputes (see littoral states)
LIP eLetiil
Svalbard is the
locus of a maritime boundary dispute
between Norway and Russia
Climate: polar climate characterized by
persistent cold and relatively narrow annual
temperature ranges. winters characterized by
continuous darkness. cold and stable weather
conditions, and clear skies. summers
characterized by continuous daylight. damp
and foggy weather. and weak evclones with
rain or snow
Terrain: central surtace covered by a
perennial drifting polar icepack that averages
about 3 meters in thickness, although
pressure ridges may be three times that size
clockwise dnft pattern in the Beautort Gyral
S''ream. but pearly straight line movement
from the New Siberian Islands (Russia) to
Denmark Strait (between Greenland and
Iceland). the icepack 1s surrounded by open
seas during the summer. but more than
doubles in size during the winter and extends
to the encircling land masses: the ocean floor
Is about SO continental shelf (highest
percentage of any ocean) with the remainder
a central basin interrupted by three
submarine ndges (Alpha Cordillera, Nansen
Cordillera. and Lomonsoy Ridge
lowest point: Fram Basin -4.665 m
lughest point: sea level O m
Natural resour: es: sand and grave!
aggregates. placer deposits. poly metallic
’ ’
nodules. onl and gas tields. fish. marine
mammals (seals and wi','3cd8ce4991c7beba5d0ffda878ef34b8b1fd4a88b03d7ed8f7009cc5a8b4caa2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b64e8ca6013e529402cfe18731ee5a827347f1de759251c1c6275fb1a4c96bea',1996,'AZ','Azerbaijan','geography',49,'Location: Southwestern Asia. east of Turkey
Geographic coordinates: 40 00 N. 45 00. F
Map references: Commonwealth of
Independent States
Area:
total area: 29.800 sq km
land area: 28.400 sq km
comparative area: sightly larger than
Mary land
Land boundaries:
total: 1.254 km
border countries: Azerbaiyan-proper S66 km.
Averbayan-Naxcivan exclave 221 km.
Georgia 164 km. Iran 35 km. Turkey 268
km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: supports ethnic
Armenians in Nagorno-Karabakh in their
separatist conflict against the Azerbaijani
Government, traditional demands on former
Armeman lands in Turkey have subsided
Climate: highland continental. hot sunamers
cold winters
Terrain: high Armenian Plateau with
mountains: little forest land: fast flowing
rivers, good soil in Aras River valley
lowest point: Debed River 400 m
highest point: Aragats Lerr 4.095 m
Natural resources: smal! deposits of gold.
copper, molybdenum, zinc, alumina
Land use:
arable land: 17%
permanent crops: 3%
meadows and pastures: 20%
forest and woodland: 0%
other 6
Irrigated land: 3.050 sq km (1990)
Location: Southwestern Asia. bordering the
Caspian Sea. between Tran and Russia
Geographic coordinates: 40 30 N. 47 30 E
Map references: Commonwealth of
Independent States
\\rea:
total area. 86.600 sq km
land areas 86.1900 sq km
comparative area: slightly larger than Maine
note. mecludes the exclave of Naxcivan
Autonomous Republic and the Nagorno-
Karabakh region, the region''s autonomy Was
abolished by Azerbayjant Supreme Soviet on
26 November 1991
Land boundaries:
rmital: 2.013 km
border countries. Armenia (with Azerbaiyan-
proper) S66 km. Armenia (with Averbaijan-
Naxcivan exclave) 221 km. Georgia 322 km.
Iran (with Azerbaijan-proper) 432 km. Iran
with Averbanan-Naxcivan exclave) 179 km.
Russia 284 km. Turkey 9 km
Coastline: 0 km Gandlocked)
note: Azerbaijan borders the Caspian Sea
(800 km, est.)
Maritime claims: none (landlocked)
International disputes: violent and
longstanding dispute with ethnic Armenians
of Nagorno-Karabakh over its status:
Caspian Sea boundaries are not yet
determined
Climate: dry. semiarid steppe
Terrain: large. flat Kur-Araz Lowland
(much of it below sea level) with Great
Caucasus Mountains to the north, Qarabag
(Karabakh) Upland in west: Baku lies on
Abseron (Apsheron) Peninsula that juts into
Caspian Sea
lowest point: Caspian Sea -2% m
highest point: Bazarduzu Dagi 4.485 m
Natural resources: petroleum. natura! gas.
iron ore, nonferrous metals. alumina
Land use:
arable land: \\8%
permanent crops: 4%
meadows and pastures. 23%
forest and woodland: Wi
other: 33%
Irrigated land: 14.010 sy km (1990)
Location: Canbbean. chain of islands in the
North Atlantic Ocean. southeast of Flonda
(,eographic coordinates: 24 15 No 76 00 W
Map references: Central Amenca ond the
Canbbean
Area:
wal area, VA 940 sq km
lund area 10.070 sy km
comparative areca. stightly larger thar
Connecticut
Land boundaries: 0) km
Coastline: 3.542 km
Maritime claims:
minental shelf) 200-m depth or to th
depth of exploitation
cvclusive fishine cone: 200 am
erruonal sea’ 2 nm
International disputes: non
Climate: tropical marine: moderated by
warm waters of Gull Strean
Terrain: jong. flat coral format os wit
some low rounded hills
lowest pout. Atlant Oeeat
lignes! point Mount Alverma 63
Natural resources: salt araconnk
Land use:
arable land: \\''
pennant craps. OU
meadows and pastures. UV
forest and woodland 42
other 6&7
Irrigated land: ‘\\\\ sy AT
Location: Middle East. archipelago im the
Persian Gulf, east of Saudi Arabia
Ceographic coordinates: 26 00 N. 50 33 E
Map references: Middle East
Area:
total area: 6:20 sq km
land area: 620 sq km
comparative area. 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 16) km
Maritime claims:
comiguous cone: 24 am
continental shelf: extending to boundaries to
he determined
wrritorial sea: 12 am
International disputes: termiona! dispute
with Qatar ect the Hawar Islands: maritime
boundary with Qatar
Climate: and. mild. pleasant winters: very
hot. humid summers
Terrain: mosily low desert plain msing
gently to low central escarpment
lowest point: Persian Gulf 0 m
Ingest point: Jabal ad Dukhan 122 m
Natural resources, o1). associated and
nonassociated natural gas. tish
Land use:
arable land
yr reine ns « Farr
meadows and pastures. 6%%
forest and woodland. O%
other: YO
Irrigated land: 10) sg kim (1989 est)
Transportation Location: Oceania. atoll in the North P
Railwavs: 0 km Ocean, about one-half of the way f1
Highways: Hawan to Australia
total: 2.671 km Geographic coordinates: () |3.N. 176 "
paved: 2.011 km Map references: Ocew
unpaved: 660 km (1991 est.) Area:
Pipelines: crude oil 56 km: petroleum total area: 1.4 sq kin
products 16 km: natural gas 32 km land area: 1.4 sq km
Ports: Manama. Mina’ Salman. Sitrah comparative area. about 2S times t
Merchant marine: of The Mall in Washington 1
total: 6 ships (1.000 GRT or over) totaling Land boundaries: () kin
117,060 GRT/194.061 DWT Coastline: 4.8 km
ships by type: bulk 1. cargo 3, chemical Maritime claims:
tanker |. oi] tanker 1 (1995 est.) exclusive economic cone: 200 nm
Airports: territorial sea: 12 nm
total: 3 International disputes: )onc
with paved runways over 3,047 m: 2 Climate: equatonal: scant raintall, constant
with unpaved runways 1,524 to 2,437 m: | wind. burning sun
(1995 est.) Terrain: low. nearly level coral stand
Heliports: | (1995 est.) surrounded by a narrow tringing reef
lowest pot: Pactite Ocean 0 m
highest point: unnamed location 8 m
Natural resources: guano (deposits worked
Communications until [ROD
Telephones: 73.552 (1987 est.) Land use:
Telephone system: modern system: good arable land: O%
domestic services and excellent international permanent crops: O%
connections meadows and pastures. 0
domestic: NA forest and woodland: 0%
international: tropospheric scatter to Qatar other: WOO%
and UAE; microwave radio relay to Saudi Irrigated land: 0 sy kin
Arabia; submarine cable to Qatar, UAE. and Environment:
Saudi Arabia; satellite earth stations - 2 current issues: no natural tresh water
Intelsat (1 Atlantic Ocean and | jadian resources
Ocean) and | Arabsat natural hazards: the narrow tringing reel
Radio broadcast stations: AM 2. FM 3. surrounding the island can be a maritime
shortwave 0 hazard
39
of
Baker Island (continued)
international agreements: NA
Geographic note: treeless. sparse. and
scalfered Vezelation Consisting Of grasses
prostrate vines, and low growing shrubs:
infy a nesting. roosting, and foraging
tat tor seabirds. shorebirds, and marine
\\itdhife','eee158dd6614c85300c72678fad56725c38d21e53d66102afb98cd23ed546b1c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93b04f5c97f586eaa77b18c02983d67de6d342adb357419de352de109381ccb5',1996,'AW','Aruba','geography',54,'Location: Caribbean, island in the Caribbean
Sea. north of Venezuela
Geographic coordinates: |2 30) N. 69 58 W
Map references: Central America and the
Caribbean
Area:
total area: 193 sq km
land area: 193 sq km
comparative area: slightly larger than
Washington, DC
Land boundaries: () km
Coastline: 68.5 km
Maritime claims:
territorial sea: 12 nm
International disputes: none
Climate: tropical marine: little seasonal
temperature variation
Terrain: flat with a few hills: scant
vegetation
lowest point: Caribbean Sev 0 m
highest point: Mount Jamanota 188 m
Natural resources: negligible: white sandy
beaches
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 1OO%
Irrigated land: NA sg km','89acb9305683e3d70b4e692a8d1e6189f82697885fd2fb72ce009ec61dabbc5f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b899c0127a4356695822cab0fe1dc19d80e241def7cec14d3f0405f5f7120749',1996,'AU','Australia','geography',62,'Location: body of water between Africa.
Europe. Antarctica, 2nd the Western
Hemisphere
Geographic coordinates: () 00 N. 25 00 W
Map references: World
Area:
total area: 82.217 million sq km
comparative area: slightly less than nine
times the size of the US: second-largest of
the world’s four oceans (after the Pacific
Ocean, but larger than Indian Ocean o1
Arctic Ocean)
note: includes Baltic Sea, Black Sea.
Caribbean Sea. Davis Strait. Denmark Strait.
Drake Passage. Gulf of Mexico.
Mediterranean Sea, North Sea. Norwegian
Sea. Scotia Sea. Wedde!l Sea. and other
tributary water bodies
Coastline: | 11.866 km
International disputes: some maritime
disputes (see littoral states)
Climate: tropical cyclones (hurricanes)
develop off the coast of Africa near Cape
Verde and move westward into the
Caribbean Sea: hurricanes can occur from
May to December. but are most frequent
from August to November
Terrain: surface usually covered with sea
ice In Labrador Sea, Denmark Strait, and
Baltic Sea from October to June: clockwise
warm water gyre (broad, circular system of
currents) in the northern Atlantic.
counterclockwise warm water gyre in the
southern Atlantic: the ocean floor ts
dominated by the Mid-Atlantic Ridge. a
rugged north-south centerline for the entire
Atlantic basin
lowest point: Puerto Rico Trench -8.605 m
highest point: sea level 0 m
Natural resources: oi! and gas fields. fish.
marine mammals (seals and whales). sand
and gravel aggregates, placer deposits.
polymetallic nodules, precicus stones
Location: Oceania. continent between the
Indian Ocean and the South Pacific Ocean
Geographic coordinates: 27 00.5, 133 00 EF
Map references: Oceania
\\rea:
total area: 7.686.850 sq km
lund area, 7.617.990 sg km
comparative area: slightly smatier than the
US
note. wcludes Mac quarie Island
Land boundaries: () km
Coastline: 25.760 km
Maritime claims:
contiguous zone, 24 nm
continental shelf: 200 nm or to the edge ot
the continental margin
exclusive economic zone: 200 nm
territorial sea: V2nm
International disputes: territorial claim in
Antarctica (Australian Antarctic Territory )
Climate: generally arid to semiarid
temperate in south and east: tropical in north
Terrain: mostly low plateau with deserts:
fertile plain in southeast
lowest pont: Lake Eyre -15 m
highest point: Mount Kosciusko 2,229 m
Natural resources: bauxite. coal, iron ore.
copper, tin, silver, uranium, nickel. tungsten,
mineral sands, lead. zine. diamonds. natural
gas, petroleum
Land use:
arable land: 6%
permanent crops: O&%
meadows and pastures: S&“
forest and woodland: 14%
other: 22%
Irrigated land: 18.200 sg km (1989 est.
—
Location: Middle America. atoll on the
North Pacithe Ocean. 1.120 km southwest of
Men ’
Ceographic coordinates: 10) 17 N. 109 1?
WW
Map references: World
Area:
wtal area: 7 sa km
littl aires “ ATI
comparative areca, about 12 mes the size of
The Mall in Washington, Dt
Land boundaries: 0 km
Coastline: |!) km
Maritime claims:
j ee why one. Akhhbam
ea: lJ om
International disputes: claimed by Mexico
Climate: tropical. humid. average
perature 20-32 degrees C. rains May
October
lerrain: il atoll
mt Paco Ocean 0 m
m- Rocher Ciipperton 21 m
Natural resources: none
Land use
rons: 4
pastures, O%
guliand: (V4
yr TOWN Call coral)
Irrigated land: 0) sq km','95c245c039c9a6f8e215c68c95609afc2e88b08ae0683e03a66f4585668b1c30','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3e8a2188110ffed5f6418d46b425a9707b6150104931782b1fcec9d35aa9d67',1996,'AT','Austria','geography',67,'Location: Central Europe. north of Italy
Ceographic coordinates: 47 20 N. 13 201
Map references: Europe
Area:
total area. S3.850 sq km
land area. 82.780 sy kin
comparative area. siightly smaller than
Mayne
Land boundaries:
rotal. 2558 kin
border countries. Czech Republic 362 km.
Germany 784 km. Hungary 366 km. Italy
$4) kim. Liechtenstein 37 kim. Slovakia 91
km. Slovenia 324 km. Swatzerland 164 km
Coastline: 0 km Gandlocked)
Maritime claims: none Clandiocked)
International disputes: none
Climate: temperate. continental. cloudy
cold winters with frequent rain in low lands
and snow tn mountains: cool summers with
occasional showers
Terrain: in the west and outh mostly
mountains (Alps): along the eastern and
northern margins mostly flat or gently
sloping
lowest poml Neustedler See 115 m
”
highest pou Grossglocknet Y7 m
Natural resources: tron ore. oil, timber
magnesite. lead, coal. lignite. Copper
hydropower
Land use:
arable land: 17%
permanent crops.
meadows and pastures 24%
forest and woodland, 39%
other: (YG
Irrigated band: 40 sy km (1989)','137c2ac97c56b9a7caf4b532ecba4b7d27952aab2a29c55cfc3eb1951dae6498','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92bbfbb1ccfa6c66698c53e691d076267e31cfe70a150d1d6c66e12be9d06181',1996,'BD','Bangladesh','geography',78,'Location: Southern Asia. bordering the Bay
of Bengal. between Burma and India
Geographic coordinates: 24 00 N_ 90 00 f
Map references: Asia
Area:
total area’ 144.000 sy kin
land area, 133.910 sg km
comparative area sightl smatler than
Wisconsin
Land boundaries:
total: 4.246 km
horder countries. Burma 1938 kom. India
1053 km
Coastline: 580 kin
Maritime claims:
contiguous cone. Sonam
continental shelf, up to the outer limits of
the continental margin
evclusive economic cone: 200 am
terruiortial sea: 120m
International disputes: a portron of the
houndary with India in dispute. water
sharing problems with upstream mpanan
India over the Ganges
Climate: tropical: cool, dry winter (October
to March): hot. humid summer (March to
June). cool. rainy monsoon une to October)
Terrain: mostly flat alluvial plam., hilly in
southeast
lowest powmt: Indian Ocean 0 m
highest pomt. Reng Tlang 957 m
Natural resources: natural gas. arable land.
timber
Land use:
arable land: 67%
permanent crops: 2%
meadows and pastures: 4%
forest and woodland: \\6%
other: AVG
Irrigated land: 27.380 sq km (1989)','1db6faee2c63ce7c2a0bbd19b85b876a18ab0881d3d7792a933b4e18aa48bff9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb37aeb5500c2c054bdc77878880e7a849dd07c7ddf03dd644770bdf4fb81ee9',1996,'BB','Barbados','geography',83,'Location: Caribbean. island between the
Caribbean Sea and tre North Atlantic Ocean.
northeast of Venezuela
Geographic coordinates: 13 10 N. 59 32 W
Map references: Central America and the
Carnbbean
Area:
total area: 430 sq km
land area: 430 sq km
comparative area. 2.5 times the size ot
Washington, DC
Land boundaries: () km
Coastline: 97 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: one
Climate: tropical: rainy season (June to
October)
Terrain: relatively flat: rises gently to
central highland region
lowest point: Atlantic Ocean 0 m
highest point: Mount Hllaby 336 m
Natural resources: petroleum. fish, natural
gas
Land use:
arable land: 77%
permanent crops: O%
meadows and pastures: 9%
forest and woodland: 0%
other: 14%
Irrigated land: NA sy km
Location: Southern Africa, islands in the
southern Mozambique Channel. about one
halt of the way from Madagascar to','54b92774777314f8881a89ceefac8e9d4f4891ffafda50631df449b87225d4a6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdb8c4facf409f9ddf2df511a46d44419247b47d4ba1e357011532ac5658b967',1996,'MZ','Mozambique','geography',88,'Geographic coordinates: 2! 30S. 39 SOF
Map references: Atrica
Area:
total area: 0.2 sq km
land area: 0.2 sq km
comparative area: about one-third the size ot
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 35.2 kin
Maritime claims.
exclusive economic zone: 200 nm
territorial sea: 120m
International disputes: claimed by
Location: Southern Atrica. bordermy the
Mozambique Channel. between South Atrica
and Tanzania
Geographic coordinates: |8 15 5.35 00 1
Map references: Alrica
Area:
total areas SOLS9O sg kn
lund area: 784.090 sq kin
comparative area. slightly less than twice
the size of California
Land boundaries:
total: 4.571 km
border countries: Malawt 1.569 kim. South
\\trica 491 kim. Swaziland 1OS km. Tanzania
756 km. Zambia 419 km. Zimbabwe 1.231
AM
Coastline: 2.470 km
Maritime claims:
exclusive economic cone, 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical to subtropical
Terrain: mostly coastal lowlands. uplands in
center, high plateaus in northwest. mountains
In West
lowest pou. Indian Ocean O m
highest point: Monte Binga 2.436 m
Natural resources: coal. Utanium. natural
pas
Land use:
arable land. AS
Permanenl craps (}''4
meaddows and pastures: SOC
lores!’ and woodland: V4
othe, YI),
Irrigated land: {150 sg km (IYSY est)
Geographic coordinates: 6 00 S, *5 00 E
Map references: Africa
Area:
total area: 945,090 sq km
land area: 886,040 sq km
comparative area: slightly larger than twice
the size of California
note: includes the islands of Mafia, Pemba,
and Zanzibar
Land boundaries:
total: 3,402 km
border countries: Burundi 451 km, Kenya
769 km, Malawi 475 km, Mozambique 756
km, Rwanda 217 km, Uganda 396 km,
Zambia 338 km
Coastline: | 424 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: boundary dispute
with Malawi in Lake Nyasa; Tanzania-Zaire-
Zambia tripoint in Lake Tanganyika may no
longer be indefinite since it has been
informally reported that the indefinite section
of the Zaire-Zambia boundary has been
settled
Climate: varies from tropical along coast to
temperate in highlands
Terrain: plains along coast; central plateau:
highlands in north, south
lowest point: Indian Ocean 0 m
highest point: Kilimanjaro 5,895 m
Natural resources: hydropower potential,
tin, phosphates, iron ore, coal, diamonds,
gemstones, gold, natural gas, nickel
~ wage.»
Land use:
arable land: 5%
permanent crops: 1%
meadows and pastures: 40%
forest and woodland: 47%
other: 71%
Irrigated land: | 530 sq km (1989 est.)','fcdc4b00163aec080e356cce67da9ff2a01cd8e7b6ee2db24cb4f47da554a993','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c448ae460050ee6b29d75a0008f2646d112fdd00dd382d524b51717d869c914e',1996,'MG','Madagascar','geography',89,'Climate: tropical
Ferrain: a volcanic rock 2.4 meters high
lowest powmt: Indian Ocean 0 m
Inghest point: unnamed location 3 m
Natural resources: pone
Land use:
arable land: 0%
permanent craps: O%
meadows and pastures: O%
forest and woodland: O%
other: WOO call rock)
Irrigated land: () sq kin
Location: Southern South America. islands
in the South Atlantic Ocean, cast of southern
Geographic coordinates: || 40 S. 47 20 1
Map references: Atrica
\\rea:
total area: S sq km
land areca: S sq km
comparative areca, about eight times the siz
of The Mall :n Washington, Dt
note. mecludes Ile Glorieuse. Tle du Lys
Verte Rocks, Wreck Rock. and South Rock
Land boundaries: 0 km
Coastline: 45.2 km
Maritime claims:
exclusive economic cone. 200 am
territorial sea: 12 am
International disputes: claimed by
Climate: tropical
Terrain: NA
lowest point: Indian Ocean 0 m *
highest point: unnamed location 12 n
Natural resources: guano. Coconuts
Land use:
arable land:
permanent crops, Os
meadows and pastures: O%
forest and woodland:
other: 1\\OO% Call bush vegetation and cocom
palms)
Irrigated land: © sy kin
Climate: tropical
lerrain: \\A
lowest powt. Indian Ocean 0 m
ehest pom. unnamed location LO m
Natural resources: guano deposits and other
fertilizers
Land use:
arable land:
PocmManenl crops {}''
meadows and pastures, Vs
lores and woodland: WW
oles 1)
Irrigated land: 0 sy km
Location: Central Asia. northwest ot Ch
Ceographic coordinates: 48 00 N. 6s 00 |
Map references: Commonwealt!
Independent States
\\rea:
totaie area: 2.717300 vu ks
hid area ObOHY SOO sa bh
compa adliiteg armed sun |
umes the size of Texas
Land boundaries:
hatal: ALON km
border countries. China 1.533 ka
Ayresvzsan LOST km. Russia 6.846 }
Purkmenmian 379 km. Usbekostas ke
Coastline: 0 kin Gandlocked
note. Kazakstan borders the Aral Sea i}
hin) and the ¢ aspian Sea 1 SYS ki
Nlaritime claims: none (landlocked
International disputes: Caspian Sx
houndarnes are not vet determined
Climate: continental. cold winters and bh
summers, and and sennand
Verrain: extends trom the Volga to the Alt
Mountains and trom the PLAINS I We m
Siberia to oasis and desert in ( nita \\
fonues punni Vpadina Kaunds
Zheng Shingy 7.439
Natural resources: major depo
iehest pou
petroleum, coal. iron ore, Mangan
chrome ore, nicke:. cobalt. copper
nels bdenum. lead. zinc. bauxit ’
uranium
Land use:
arable hand 1s!
porman nre¢ ropy NI |
meadows and pastures. »
fares: and woodland: 4''
ches 24
Irrigated land: 23.080 sg km (1990
Location: Oceania. group of rstands in the
Pacitte Ocean, straddling the equator and the
international Date Line. about one-half of the
was trom Hawan to Australia
(,eographic coordinates: | 25 N. 173 001
Map references: Oceania
Area:
total area: 717 sq km
land area: 717 sq km
comparative arca. tour mes the size ol
Washington, Dt
we. mcludes three island groups—Gilben
islands. Line Islands. Phoenix Islands
Land boundaries: 0 km
Coastline: |.143 km
Maritime claims:
cuclasive economic son 200) nm
wrritorial sea. 12 am
International disputes: none
Climate: tropical: marine. hot and humid
maxderated by trade winds
Terrain: mostly low-lying coral atolls
surrounded by extensive reets
west pont: Pactle Ocean 0 m
ghest pont: unnamed location on Banaba
a1 om
Natural resources: phosphate (production
discontinued in 1979)
Land use:
rable land: WG
wrmanent crops, SV
meadows and pastures:
west and woodland: VG
her 46%
Irrigated land: NA sq km
Location: Eastern Asia. southern half of the
Korean Peninsula bordering the Sea of Japan
and the Yellow Sea. south of North Korea
Ceographic coordinates: 37 00 N. 127 30
I
Map references: Asia
Area:
total area: YSR.4ARO sy Am
land area: YRANYOO sg kim
COMPATAUVE ACE sty 4a}
Indiana
Land boundaries:
SS Kn
hordes wnt
(oastline: 2.4
Meritime claims:
; (
Seraie
International disputes: D
North K |
}
Climate:
ierrain:
Ha
Natural resources:
molvbdenun lead
Land use:
af land
permanent crops
meadows and pasture ‘
fovesi and woodland: 679%
one LO”
Irrigated land: 4) sq km (1989)','74807cc44f135d2c9f61ee1cc40d515f7a2b46fd65d60983a465ddd83903accf','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56f5630d6dee8da0338fbe9b19b2d5eb10373620c69b56af2193e848e05e97ed',1996,'BY','Belarus','geography',96,'Location: Eastern Europe. east of Poland
Geographic coordinates: 53.00 N. 2s 00
Map references: Commonwealth ot
Independent States
Area:
total area: 207.600 sq km
land area: 207.600 sq km
comparative area: slightly smaller than
Kansas
Land boundaries:
total: 3.098 km
border countries’ Latvia 141 km. Lithuania
502 km. Poland 605 km. Russia 959 km
Ukraine 891 km
Coastline: 0 km Candlocked)
Maritime claims: none (landlocked)
International disputes: one
Climate: cold winters, cool and moist
summers: transitional between continental
and maritime
Terrain: generally flat and contains much
marshland
lowest powt: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: forests, peat deposits
small quantities of oil and natural gas
Land use:
arable land: 29%
permanent crops: VG
meadows and pastures: (S%
forest and woodland, 0%
other, SSG
Irrigated land: |.490 sy km (1990)','8dc9754010665ba9d4cc406017fe34069e826b40ccf938cbc5bec9e2bae888a9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f9b64015134aa792e02936195a52c73f7274f1140876a78ca313ed3a1dfb32e',1996,'BZ','Belize','geography',106,'!
Location: \\iiddle
Can oheu Scull
Viewn
America. bordering the
hetween Guatemala and
(seographic coordinates: |7 15 N. 8s 45 W
Map references: Central America and the
Canbhe at
\\rea:
ca. 22800 sa km
and area: 22.800 vy Kn
mparative arca sightt, larger tl
VMiass nwhusetts
land boundaries:
t Sig kn
hordcr ome os Guatemala 266 km
Mexico 240 kn
(Coastline: 886 kn
\\iaritime claims:
nie cone. 2000 am
> om om the north, § am om
tryory the FT cuth at the
. iN Rat na Cav. Belize s
woording to Belize''s
\\I \\ Vel )” the Purprrse oi
vide a framework for
fa detimtive agreement on
rences with Guatemala
International disputes: border with
(juatermala on diseute: talks to resolve the
C imate: tromecar. vers bot and humid: ramy
eason (May to February)
Ferrain: flat. swampy coastal plain: low
mountamns im sou
owes! pow: Canbh aa Sea Om
Victoria Peak 1.160 m
Natural resources: arable land potential
‘7 ln ‘/ puns j
tuber, tish
Land use:
arable lana Z
50
permanent crops: O%
meadows and pastures: 2%
forest and woodland: 44%
other: 52%
Irrigated land: 20) sq km (1989 est.)','e12c26aa30e64b5b29d3120e4fafa20305b0674497f1620f1127186354f76a13','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('774f527f9aabb8f11fad2c24fce82728f39726a8ee67b17dea36008fb670385a',1996,'BM','Bermuda','geography',113,'Location: North America. group of islands
inthe North Atlantic Ocean. east of North
Carolina (US)
Ceographic coordinates: 342 20 N.64 45 W
Map references: North America
Area:
total areas SO sg km
land area: XO sq km
comparative areca about 0.3 times the size
of Washington, DC
Land boundaries: (0 km
Coastline: 103 km
Maritime claims:
erclusive fishing cone: 200 nm
rerruorial sea: 12 nm
International disputes: none
Climate: subtropical: mild. humid: gales
strong winds common in winter
Terrain: low hills separated by tertile
depressions
lowest pout: Atlantic Ocean 0 m
highest point: Town Hill 76 m
Natural resources: limestone. pleasant
climate fostering tourism
Land use:
arable land:
permanent crops. Oe
meadows and pastures:
forest and woodland: 20%
other, SOG
Irrigated land: NA sy km','29982ac7f084585047fc529726b41f326eeb6b928651ff920bd6cb38a5b303dc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dd35ebecdaf9d055ab61f20007ff06ed3ec81a1c4d4bbd775d26e33c2122ca6',1996,'BT','Bhutan','geography',121,'Location: Central South Amenca. southwest
rR
Geographic coordinates: | 7 005.65 00 W
Map references: South America
\\rea:
ails F ’ SAt) ATT)
ind ‘ ‘ Wy sg km
ompal ( | ly | than thre
wi itn iM mat
Land boundaries:
H 43h
hordes wily \\l rp Xalk Brasil
then: ( SO} him. Paraguay 750)km
pPioy Win) |}
{ coastline kin (landlocked
Niarttime claims: non mndlocked
International disputes: has wanted a
| ‘ 1! ? it
ver if Was lost to
h Chile over Rio
© gipsiate 1 1) nud ma
lerram Mountains with a
wo). halls. lowland
j
} | i\\ Ay my)
i i HAS MH
‘A rab resources mura is
nh. antimony. silver
Irrigated land: | 690 sq wm C1989 est)','0aa51593f1bf9d6dfe36a54b5a3339b05180f0a1d94d6d4fd2ef40cac0d21b82','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9200a12e444d47f087986b7c4ce71c3bb93368c951de563e80dad898dbb621c8',1996,'BA','Bosnia and Herzegovina','geography',125,'Location: Southeastern Eurone. borden
\\driati Sea and ( ha
(,eographic coordinates: 44 00 N18 001
Map references: Bosnia and
I
\\rea:
land area: 31.233 sg km
comparative area: sightly smaller than West
Virginia
Land boundaries:
fatal: | 459 km
border countries: Croatia 932 km. Serbia
and Montenegro 527 km (312 km with
Serbia. 215 km wath Montenegro)
Coastline: 20 km
Maritime claims: \\ A
International disputes: nonce
Climate: hot summers and cold winters
areas of high elevation have short, cool
summers and long. severe winters, mild
rainy winters along coas
Terrain: mountains and valleys
lowest pont: Adnatic Sea 0 m
highest point: Maghe 2.386 m
Natural resources: coal. won bauxite
manganese, forests. copper, chromium, lead
7im’w
Land use:
arable land: AY:
permanent « rans
meadows and pastures
lores and wuoodiand.
other, 17
Irrigated land: \\A\\ sy kin','d3ecf1cbbb72227ac9974250abb882b4dca2bb789a05b27636c2f873c539cecc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76254daffe9a342bad3311b8742ceeb1e6a3d176d684b107dbe4b85756d7f078',1996,'BV','Bouvet Island','geography',135,'Location: Sewhern Africa. land in the
South Atlautn Ocean. south-southwest of th
Cape of Good Hope (South Atnca)
(,cographic coordinates: 54 26 8. 3) 241
Map references: Aniarctn Region
\\rea:
total area: SS sq km
land area: SS sq km
comparative area: about 0.4 tomes th
of Washington, DC
Land boundaries: () inn
Coastline: 29.6 km
Maritime claims:
lerritonal sea: 4 am
International disputes: none
Climate: antarcty
Terrain: volcamec: maximum elevation about
SOO) meters; coaM ts mostly maccessiblc
Milantice Ocean 0 m
unnamed hoxton TSO om
lowest pownl
highest point
Natural resources: none
Land use:
arable iand: (Vy
permarent crops. OU
meadow s ¢
md pastures,
forest and woodland: 0
1 Call we)
Irrigated land: 0 sq km','838ce42b821652ebbcca09a41f5e389c588fad9208e6f7f64198a9efaea088dd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0aa7c45462391114bddcc3d4e04b92407404d0174c8083e8f92a9ac480650efd',1996,'BG','Bulgaria','geography',140,'Location: Sout !
Bly a ''
Geographic coortinates: 4 \\
Map references: |
Area:
7
A
land boundaries
Sis ib
Pade ‘
| er Yu | \\I
( oustline: 454 4
Nluritime claim
International disputes
C limmate
|
i
lerrain:
Af
Natural res vurces
Land use:
Pile ‘ /
PONT ¢
Ovnes it)
Irrigated land: 10 su ky RY
Bulgaria (continued) Religions: Bulganan Orthod». 85 Muslim Judicial branch: Supreme Court, charrman
1s Jewrsh OS Roman Catholic 0.5 appointed for a seven-year term by the
a Umate Catholie 0.20. Protestam, Gregoran president. Constitutional Court, 12 justices
. , Ammen, and other 05 appointed of elected tor a nine-year term
Languages: Bulcanan. secondary languages Political parties and leaders: Bulganan
scly correspond to ethnic breakdown Sociulmt Party (BSP). Zhan VIDENOYN
I ieracy sage 1S and over can read and charman. Union cf Democratic Forces
1W9? est (UDF—an alliance of pro-Democratx
nilatim. YS parties). Ivan KOSTOWV: People’s Union
WwW (Pt). Stefan SAVOY. ''dovement tor Rights
’ 4 and Freedoms (mainly ethnic Turkish party)
MRE). Ahmed DOGAN, Bulganan
4 ‘
\\ ‘ '' Busing ss bien (BBR) Leundce (; ANG Hil \\
(ther political or pressure groups:
Covernment Democrats Alliance tor the Republic
) < . 4) 4) . i
Nome of country: DAR). New Union tor Democracy (NUD)
ree: Re hhc of booglasnest: Podkrepa Labor Contederation
'' . batherland Umon: Bulganan Communist
\\ | boet Gwe: Rulers Party (BCP). Contederaiion of Independent
Hate codes ft lrade Umons of Bulgana (KNSB)
’ sulvan, Tran ation. ’ te
[ype of government: emerging democracy Bulvanan Agranan National Union—Unrted
Capital: S B/NS). Bulganan Democratic Centes
a . | Nikola Pethov > Bulgarian Agra:
Geographic not \\dministrative divisions: 9 provinces 1 Petho.” Bulganan Agranan
National Unnen. Internal Macedonian
, ; Revoluthonary Oreanzaton——Umon of
VMiacedoman Soceties (IMRO-UMS)
| Sal \\ na
numerous regional, ethnic. and national
Independence Seprember 1908 (trot — uM. ethntc. and natwona
; interes groups with varhous agendas
I]
cope '' | : P ‘ sb peata P ae °
nternational organization participation:
National holiday: | deme Dus. 4 K '' ''
Population - — \\OCT. BIS. BSEC. OCC. Ck. EBRD. ECT
\\ve structur ‘a prin mt. FAO] G- & TARA IBRD
( onstitution | ”"
MAO. ICETU. IORM. TEC) TEROS. ILO
l eval svstem \\
INTE. IMIO>. Tnmmarset. Intelsat Cnonspenators
; Interpe!, 1O, TOME ISO. TTL NACE
NAS. ceeesthn NSG. OSCE. PCA. PEPOUN
Sullrage
LNAVEM TUL UNCTAD. UNESCO
LNEDO UNNMOT UPL. WEI ssc halle
bFaccutive bram th
Posppanbatices '' ! ef A ry) WEI 4h) WIPO) WAT)
Mirth '' \\A | {) WW | {) i} Teri J{
Diplomatic representation in US:
Amb nha S
\\) BOT! SEHIAROYWN \\
; \\ \\W
; \\\\ i HHI
i} }
. LS diplomatic representation
‘ Ss
PO) Al
. Lat ;
r
Ei
H\\ ARON
. Flay
lL evistative branch rot eh
Nat diel i } j hy » ribyiy
) ) ‘ iN ‘
t Sib th a ils hs tims K } rian Stal
> ; | ) 4 | .
BSI DI tablished) and 1944 (liberation trom Navi
Ethan divistons . h Nik] '' BBB 4? SCS (240) trol
\\ BSI L DE 69 PL Ts. MIR]
74
83
Economy) Imports: $4 billon (cat. 1994)
; 7" oe commodities: tucts. minerals. and raw : ——
Economic overview: Onc of the poorest aia na Communications
matenals 30.1°. machinery and equipment
countnes of central Europe. Bulgaria has
23.6%: textiles and apparel 11.6% Felephones: 2.773.293 (1993 est)
continued the difficull process of moving
agncultural products 10.8%: metals and ones Telephone system: almost two-thirds of the
trom its old command cconomy to a modem ; '' 123 , 4
6.S8°o. chemicals 12.5 mer 4.4''« lines are tosndential. ¢ >
market-onented coonomy. GDP rose a EM
uiriners: tormer ¢ A countries 4004 houschelds have telephe ‘ her 1YKS
moderate 24% om 1995. inflaon was down J .
OECD 48.9 (EU 34.1%) Arab countries
sharply. and unemployment tell trom an 2 7
> | « het 9 7 4 whe 7+ }
esMimated 16‘. toe 12% Despite this progress . eVien :
External debt: $10.4 million yw" i1ansmissnom svatem /
SMructural retorms necessary to underpin ‘ ss
COROT Ab ::
macrocconomuc stabilization were not , Wide ''
Moment: ODA, S89 millon C1995
pursucd vigorously Mass privatization of . atv
mate. S/U0 anuilon om balance of payments
Mate-owned industry continued to move '' nile
support trom Western natrons (1994 ,
Slowly. although privatization of small-scale Mm Helle can fir \\
Currency: | les (hy) = 100 stotenk se
mdusiry. particularly mm the retail and service : \\ wn Ocean |
tLachange rates: leva (hs) per US as
sectors, accelerated. The Bulganan COOROTHS R | tl uch a Csrect
(December 1995). $4.2 61994). 27 1 (1998
will continue to grow in 1996, bul economic Radio broadcast stations: AVI 20. FM IS
23.3 41992), 18.4 CIDVITE note fhowty
relorms will remain polrtically difficult as hawt
exhange rate since February 199
the population has become weary of the Radio: \\*
Fiscal vear: calendar yeu .
lelevision broadcast stations: 24 (Russio
prin css
,
GDP: purchast. -s power party —S43.2
billion (1995S est.)
" ‘ Ny
lelevisions: Nia rn
GDP real growth rate: 245 (1995 est)','68bb0be3e2655797c9c945e1b9a404f598b712234cf308bdfbb88ab1d81bbb3c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16d7db157e5b747a78e16f77fe9163f9e3079d820a13a950b244c71f8d626958',1996,'BI','Burundi','geography',156,'Location: Central Africa, east of Zaire
Geographic coordinates: 3 30 S. 30 00 EF
Map references: Atrica
Area:
total area: 27.330 sq km
land area: 25.650 sq km
comparative area: slightly larger than
Maryland
Land buundaries:
total: 974 km
border countries: Rwanda 290 km, Tanzania
451 km. Zaire 233 km
Coastline: 0 km (landlocked)
Maritime claims: pone (landlocked)
International disputes: none
Climate: temperate: warm: occasional frost
in uplands: dry season trom June to
September
Terrain: hilly and mountainous, dropping to
a plateau in easi, some plains
lowest point’ Lake Tanganyika 772 m
highest point’ Mount Heha 2.760 m
Natural resources: nickel. uranium, rare
earth oxides. peat, cobalt, copper. platinum
(not yet exploited), vanadium
Land use:
arable land: 43%
permanent crops: 8%
meadows and pastures: 35%
forest and woodland: 2%
other: 12%
Irrigated land: 720 sq km (1989 est.)
Location: Central Africa, east of Zaire
Geographic coordinates: 2 00 S. 30 00 E
Map references: Atrica
Area:
total area: 26.340 sq km
land area: 24.950 sq km
comparative area: slightly smaller than
Maryland
Land boundaries:
total: 893 km
border countries: Burundi 290 km, Tanzania
217 km, Uganda 169 km, Zaire 217 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: temperate: two rainy seasons
(February to April, November to January):
mild in mountains with frost and snow
possible
Terrain: mostly grassy uplands and hills:
relief is mountainous with altitude declining
from west to east
lowest point; Rusizi River 950 m
highest point: Volcan Karisimbi 4.519 m
Natural resources: gold, cassit-rite (tin ore).
wolframite (tungsten oic¢). natural gas,
hydropower
Land use:
arable land: 29%
permanent crops. 1V%
meadows and pastures: 18%
forest and woodland: 1\\O%
other: 32%
irrigated land: 40 sq km (1989 est.)','3aa9ba35bd84a854edf4b34723d20555387447233bd9b29bc77e3dfd8e855990','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('909fd98949b9883146913e36797608c832fb9a3d3caa957e06981b9ecc50ca2f',1996,'CM','Cameroon','geography',165,'Location: Western Atnca. bordering the
North Atlantic Ocean, between Equatorial
Guinea and Nigeria
Geographic coordinates: 6 00 N. 12 00 E
Map references: Africa
Area:
total area: 475,440 sq km
land area: 469.440 sq km
comparative area: slightly larger than
Calitornia
Land boundaries:
total: 4.591 km
border countries: Central Atrican Republic
797 km, Chad 1.094 km, Congo 523 km,
Equatorial Guinea 189 km, Gabon 298 km.
Nigeria 1.690 km
Coastline: 402 km
Maritime claims:
territorial sea: SO nm
International disputes: demarcation ot
international boundaries in vicinity of Lake
Chad. the lack of which led to border
incidents in the past. 1s completed and awaits
ratification by Cameroon, Chad. Niger. and
Nigeria. dispute with Nigeria over land and
maritime boundartes in the vicinity of the
Bakasi Peninsu''a has been referred to the
International Court of Justice
Climate: varies with terrain, from tropical
along coast to semiand and hot in north
Terrain: diverse. with coastal plain in
southwest, dissected plateau in center.
mountains in west, plains in north
lowest point: Atlantic Ocean 0 m
highest point: Fako 4.095 m
Natural tesources: petroleum. bauxite. iron
ore, timber. hydropower potential
Land use:
arable land: 13%
93
permanent crops: 2%
meadows and pastures: 18%
forest and woodland: 54%
other: 13%
Irrigated land: 28‘) sq km (1989 est.)
Location: Western Africa. bordering th
North Atlantic Ocean. between Cameroon
and Gabon
Geographic coordinates: 2 00 N10 00!
Map references: Alnca
Area:
total area. ISAO sq km
land area: 28.050 sq km
comparative areca. slightly larger that
Mary land
Land boundaries:
wital, S39 km
horder countrres. Cameroon 189 km. Gabon
380 hin
Coastline: 296 km
Maritime claims:
exclusive economic cone: 200 am
territonal sea: 12 nm
International disputes: maritime boundary
dispute with Gabon because of disputed
sovereignty over islands mm Cornsco Bay
Climate: tropical. always hot, burmid
Terrain: coastal plains Tise to mntervor hills
islands are volcank
lowest point: Atlantic Ocean 0 m
ighest point: Mount Malabo 3.008 m
Natural resources: timber. petroleum. smal!
une xploited deposits om gold. manganes«
uranium
Land use:
arable land. &%
permanent crops: 4
meadows and pastures. 4°
forest and woodland: SVG
other, ASG
Irrigated land: NA sq km','1caedf6287c593ebf322f32228ae2c3162323f08ca974e424a71c41c47587ea8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f68efbb83e3ec59284acbc50f57fc86a0f1d7b61e4bff7431653f99ca385314c',1996,'CA','Canada','geography',173,'Location: Northern North America.
bordering the North Atlantic Ocean and
North Pacitic Ocean. north of the
conterminous US
Geographic coordinates: 60 00 N.95 00 W
Map references: North America
Area:
total area: 9.976140 sq km
land area: 9.220.970 sq km
comparative area: slightly larger than US
Land boundaries:
total: 8.893 km
border country: US 8.893 km (includes
2.477 km with Alaska)
Coastline: 243.791 km
Maritime claims:
continental shelf: 200 nm or to the edge of
the continental margin
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: maritime boundary
disputes with the US: Saint Pierre and
Miquelon is focus of maritime boundary
dispute between Canada and France
Climate: varies from temperate in south to
subarctic and arctic in north
Terrain: mostly plains with mountains in
west and lowlands in southeast
lowest point: Atlantic Ocean 0 m
highest point: Mount Logan 5.950 m
Natural resources: nickel. zinc, copper.
gold, lead, molybdenum, potash, silver. fish.
timber, wildlife. coal. petroleum. natural gas
Land use:
arable land: 9%
permanent crops: O%
meadows and pastures: 3%
forest and woodland: 45%
other: 43%
Irrigated land: 8.400 sq km (1989 est.)
Location: Western Africa. group of Islands
in the North Atlantic Ocean, west of Senegal
Geographic coordinates: 16 00 N. 24 00 W
Map references: World
Area:
total area: 4.030 sq km
land area: 4.030 sq km
comparative area: slightly larger than Rhode
Island
Land boundaries: () km
Coastline: 965 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 nm
territorial sea; 12 am
International disputes: nonce
Climate: temperate: warm, dry summer:
precipitation meager and very erratic
Terrain: steep. rugged. rocky. volcanic
lowest point: Atlantic Ocean 0 m
highest point: Pico 2.829 m
Natural resources: salt, basalt rock.
pozzolana, limestone. kaolin, fish
Land use:
arable land: 9%
permanent crops: O%
meadows and pastures: 6%
forest and woodland: O%
other: 85%
Irrigated land: 20 sq kim (1989 est.)','d57a3319bd1a465be207e01c420301d5a40499bf5f11575e53081197dc48a670','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d780cbe9a28e60524914a302f8cbdd2740e53b435a925a71c26a5c81f55f6987',1996,'KY','Cayman Islands','geography',180,'Location: Caribbe xn. island group in
Canbbean Sea, nearly one-half of the way
from Cuba to Honduras
Geographic coordinates: 19 30 N. 80 30 W
Map references: Central America and the
Canbbean
Area:
total area: 260 sq km
land area: 260 sq km
comparative area: 1.5 times the size of
Washington, DC
Land boundaries: () km
Coastline: 160 km
Maritime claims:
exclusive fishine zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical manne: warm. rainy
summers (May to October) and coc!,
relatively dry winters (November to Apnil)
Terrain: low-lying limestone base
surrounded by cora! reefs
lowest point; Caribbean Sca 0 m
highest point: The Bluff 43 m
Natural resources: fish. climate and beaches
that foster tourism
Land use:
arable land: 0%
permanent crops: O%
meadows and pastures: 8%
forest and woodland: 24%
other: 69%
Irrigated land: NA sq kin','c460d8b4b641c403efe438dcc3d49171479524a5416dd4083b1bdf6e7a072fe5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9a077a07675820c7e6008613aa6f97d6b76c32faaa050840dd99aad8962fc1e',1996,'CF','Central African Republic','geography',185,'Location: Central Africa. north of Zaire
Geographic coordinates: 7 00 N. 21] OO E
Map references: Atrica
Area:
total area: 622.980 sq km
land area: 622.980 sq km
comparative area: slightly smaller than
Texas
Land boundaries:
total: 5.203 km
border countries: Cameroon 797 km. Chad
1.197 km. Congo 467 km. Sudan 1.165 km.
Zaire 1.577 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: tropical: hot. dry winters: mild to
hot, wet summers
Terrain: vast, flat to rolling, monotonous
plateau; scattered hills in northeast and
southwest
lowest point: Oubangui River 335 m
highest point: Mount Gaou 1.420 m
Natural resources: diamonds. uranium.
timber, gold, oil
Land use:
arable land: 3%
permanent crops: 0%
meadows and pastures: 5%
forest and woodland: 64%
other? 28%
Irrigated land: NA sy km','114d825cfbea1192195be219629f1ef834e5cae7bb09acd2fb91830fcb447399','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31cc490c76b9168c4e8bf9a72aea79f051a94e0ffef083957cb3846abd2aec84',1996,'CG','Congo','geography',193,'Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N. 19 OO E
Map references: Africa
Area:
total area: 1.284 million sq km
land area: 1.259.200 sq km
comparative area: slightly more than three
times the size of Califorra
Land boundaries:
total: 5968 km
border countries: Cameroon 1.094 km,
Central Afrean Republic 1.197 kin, Libya
1.055 km. Niger 1.175 km, Nigeria 87 km.
Sudan 1.360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: the International
Court of Justice (ICJ) ruled in February 1994
that the 100,000 sq km Aozou Strip between
Chad and Libya belongs to Chad and that
/03
Libya must withdraw from it by 31 May
1994: Libya has withdrawn some of its
forces in response to the ICJ ruling, but still
maintains part of the airfield and a small
military presence at the airfield’s water
supply located in Chad; demarcation of
international boundaries in vicinity of Lak-
Chad, the lack of which has led to border
incidents in the past, is completed and
awaiting ratification by Cameroon. Chad.
Niger, and Nigeria
Climate: tropical in south, desert in north
Terrain: broad, ard plains in center, desert
in north, mountains in northwest, lowlands in
south
lowest point: Djourat’ Depression 175 m
highest point: Emi Koussi 3.415 m
Natural resources: petroleum (unexploited
but exploration under way), uranium, natron,
kaolin, fish (Lake Chad)
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 36%
forest and woodland: 11%
other: 31%
Irrigated land: 100 sg km (1989 est.)','e36d6e82a5398c7b8e444e253998a96b0cbd6719a74ff07deafc6a2b64321b15','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('688f054649badf5eff2c34b1ee0508314b4f3504a3e8c9cca767296c2a26a708',1996,'PE','Peru','geography',199,'Location: Southern South America.
bordering the South Atlantic Ocean and
South Pacific Ocean, between Argentina and
Geographic coordinates: 30 00 S. 71 00 W
Map references: South America
Area:
total area: 756.950 sq km
land area: 748.800 sq km
comparative area: slightly smaller than twice
the size of Montana
note: includes Isla de Pascua (Easter Island)
and Isla Sala y Gomez
Land boundaries:
total: 6.171 km
border countries: Argentina 5,150 km.
Bolivia 861 km, Peru 160 km
Coastline: 6.435 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: shor section of the
southern boundary with Argeniina is
indefinite; Bolivia has wanted a sovereign
corndor to the South Pacific Ocean since the
Atacama area was lost to Chile in 1884;
dispute with Bolivia over Rio Lauca water
rights; territorial claim in Antarctica (Chilean
Antarctic Territory) partially overlaps
Argentine and British claims
Climate: temperate: desert in north: cool and
damp 1. south
Terrain: low coastal mountains; fertile
central valley: rugged Andes iii east
lowest point: Pacific Ocean 0 m
highest point: Cerro Aconcagua 6.962 m
Natural resources: copper, timber. iron ore.
nitrates, precious metals, molybdenum
Land use:
arable land: 7%
permanent crops: 0%
meadows and pastures: 16%
forest and woodland: 21%
other: 56%
Irrigated land: 12.650 sy km (1989 est.)
Location: Western South America. bordering
the South Pacific Ocean, between Chile and','e4bc7693320f0bd161ffcfdcb09706b762c227afcfc95e0301ad7a065d093e18','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e6aa4c645d718df63273fa49b9e4632a3bfcf7be149f41c4ddfe77642be5367',1996,'CX','Christmas Island','geography',207,'Locatica: Southeastern Asia, island in the
Indian Ocean, south of Indonesia
Geographic coordinates: 10 30 S. 105 40 E
Map references: Southeast Asia
Area:
total area: 135 sq km
land area: 135 sq kin
comparative area: about 0.7 times the size
of Washington, DC
Land boundaries: (0 km
Coastline: 138.9 km
Maritime claims:
contiguous zone: 12 nm
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes none
Climate: tropical; heat and humidity
moderated by trade winds
Terrain: steep cliffs along coast rise
abruptly to central plateau
lowest point: Indian Ocean 0 m
highest point: Murray Hill 361 m
Natural resources: phosphate
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km','79a4b18cd683c80e53f9690fd1a4004ae21ef806c90759a86c65570531e66403','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b502ff8dfd26e618078f79b69af61308ba18062579cc6ed382d9ac56f7df0e8b',1996,'CC','Cocos (Keeling) Islands','geography',213,'Location: Southeastern Asia. group of
islands im the Indian Ocean. south of
indonesia, about one-half ef the way from
Australia to Sn Lanka
Geographic coordinates: |2 30 S. 96 SOE
Map references: Southeast Asia
Area:
total area: 14 sq km
land area: 14 sq km
comparative area: about 24 umes the size of
The Mall in Washington, DC
note: includes the two main islands of West
Island and Home Island
Land boundaries: () km
Coastline: 2.6 km
Maritime claims:
exclusive fishine sone: 200 nm
territorial sea: 3 am
International disputes: none
Climate: pleasant. moditied by the southeast
trade wind for about nine months of the
year, moderate rainfall
Terrain: flat, low-lying coral atolls
lowest point: Indian Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: NA%
permanent crops: NAG
meadows and pastures: NAG
fores’ and woodland: NAG
other: NAG
Irrigated land: NA sq km','12ab6c558fa326c2a8aae0aa3df2364f0ccd23bf834e919d82d72461529d7c3c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7db77c58f06f23946aa3c0cef8551ef94e1c72c39bc7d77153c4de7530491797',1996,'YT','Mayotte','geography',225,'Location: Southern Africa, group of islands
in the Mozambique Channel. about two-
thirds of the way between northern
Madagascar and northern Mozambique
Geographic coordinates: |2 10S. 44 IS E
Map references: Atrica
Area:
total area: 2.170 sq km
land area: 2.170 sq km
comparative area: slightly more than 12
times the size of Washington, DC
Land boundaries: () km
Coastline: 340 km
Maritime claims:
ervclusive economic zone: 200 nm
12 nm
International disputes: claiis French-
administered Mayotte
Climate: tropical marine. rainy season
(November to May)
Terrain: volcanic islands, interiors vary
from steep mountains to low hills
lowest point: Indian Ocean 0 m
highest point: Mount Kartala 2.360 m
Natural resources: negligible
Land use:
arable land: 35%
permanent crops: 8%
territorial sea
meadows and pastures: 7%
forest and woodland: 16%
other: 34%
Irrigated land: NA sq km','62af424714059e14728a04f4384d4e958a13c34e65176fb6acafedf72209c900','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b0a7d57fd9c66ae65355385ed4aaed2c127b8ce1ac641198cbab84ec816ccf6',1996,'GA','Gabon','geography',233,'Location: \\ estern Africa. bordering the
South Atlantic Ocean, between Angola and
Geographic coordinates: | 00 S. 15 00 E
Map references: Africa
Area:
total area: 342.000 sq km
land area: 341.500 sq km
comparative area: slightly smaller than
Montana
Land boundaries:
total: 5,504 km
horder countries: Angola 201 km, Cameroon
523 km, Central Atrican Republic 467 km.
Gabon 1.903 km, Zaire 2.410 km
Coastline: 169 km
Maritime claims:
200 nm
Internationai disputes: long segment of
boundary with Zatre along the Congo River
is indefinite (no division of the river or its
islands has been made)
Clima «: tropical; rainy season (March to
June). dry season (June *e Octe oer):
consiantly high temperatures and humidity:
particularly enervating climate astride the
Equator
Terrain: coastal plain. soutiesn basin,
central plateau, northern basin
lowest point: Atlantic Ocean 0 m
highest point: Mount Berongou 903 =,
Natural resources: petroleum, timber.
potash, lead, zinc, uranium, copper,
phosphates, natural gas
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 29%
territorial sea:
forest and woodland: 62%
19
other: 7%
Irrigated land: 40 sq km (1989)','8a568a24b9de63bdac4b9e730ca95d0c7b3a31cd914dcd7900939b35351921a9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf7746d84d22d3858fb915590a7ff6bfe67c01789022ec3e5bb780e008e68c8f',1996,'CK','Cook Islands','geography',239,'Location: Oceania, group of islands in the
South Pacific Ocean, about one-half of the
way from Hawaii to New Zealand
Geographic coordinates: 2! 14 S. 159 46
W
Map references: Oceania
Area:
total area: 240 sq km
land area: 240 sq km
comparative area: slightly more than one
times the size of Washington, DC
Land boundaries: 0 km
Coastline: |20 km
Maritime claims:
continental shelf: 200 nm or to the edge of
the continental margin
exclusive economic zone: 200 nm
territorial sea: i2 em
International disputes: none
Climate: tropical: moderated by trade winds
Terrain: low coral atolls in north: volcanic.
hilly islands in south
lowest point: Pacitic Ocean 0 m
highest point: Te Manga 652 m
Natural resources: negligible
Land use:
arable land: 4%
permanent crops: 22%
meadows and pastures: 0%
forest and woodland: 0%
other: 74%
Irrigated land: NA sq km
Location: Oceania. islands in the Coral Sea.
northeast of Australia
Geographic coordinates: 18 00S. 152 00 E
Map references: Oceania
Area:
total area: less than 3 sq km
land area: \\ess than 3 sq km
comparative area: NA
note: includes numerous small islands and
reefs scattered over a sea area of about |
million sq km, with Willis Islets the most
important
Land boundaries: (0 km
Coastline: 3.095 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical
Terrain: sand and coral reefs and islands (or
cays)
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Cato
Island 6 m
Natural resources: necligible
Land use:
arable land: 0%
permanent crops: O%
meadows and pastures; 0%
forest and woodland: 0%
other: 100% (mostly grass or scrub cover)
fvvigated land: 0 sq km','45e148b08ebfa8503c023ec673d54e55177d2511b361c8627da441e5b6c1e386','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('414f62e9a30b274c7a5c70c6e505923172aa457692e08a58ef67d1911e2e0c73',1996,'NI','Nicaragua','geography',246,'Location: Middle America. borderiag both
the Canbbean Sea and the North Pacific
Ocean, between Nicaragua and Panama
Geographic coordinates: 10 00 N. 84 00 W
Map references’ Central America and the
Caribbean
Area:
total area: 51100 sq km
land area: 90.660 sq km
comparative area: slightly smaller than West
Virginia
note; includes Isla del Coco
Land boundaries:
total: 639 km
border countries: Nicaragua 309 km.
Panama 330 km
Coastline: |.290 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical: dry season (December to
April): rainy season (May to November)
Terrain: coastal plains separated by rugged
mountains
lowest point: Pacific Ocean 0 m
highest point: Cerro Chirripo 3.810 m
Natural resources: hydropower potential
Land use:
arable land: 6%
permanent crops: 7%
meadows and pastures: 45%
forest and woodland: 34%
other: &%
Irrigated land: |.) 80 sq km (1989 est.)
Location: Western Africa. bordering the
North Atlantic Ocean. between Ghana and
Location: Middle America. bordering the
Caribbean Sea. between Guatemala and
Nicaragua and bordering the North Pacific
Ocean. between El Salvador and Nicaragua
Geographic coordinates: 15 00 N. 86 30 W
Map references: Central America and the
Caribbean
\\rea:
total areas VA2.090 sq km
lund area’ (11.890 sq km
comparative area: slightly larger than
lennessee
Land boundaries:
total: 1.S20 km
border countries: Guatemal. 256 km, El
Salvador 342 km. Nicaragua 922 km
Coastline: 820 km
Maritime claims:
contiguous zone: 24 nr
continental shelf: natural extension of
territory or te 200 ia
exclusive economic zone; 200 nm
territorial sea: 12 nm
International disputes: land boundary
dispute with El Salvador mostly resolved by
11 September 1992 International Court of
Justice (ICJ) decision: with respect to the
maritime boundary in the Golfo de Fonseca.
IC} reterred to an earlier agreement in this
century and advised that some tripartite
resolution among El Salvador. Honduras, and
Nicaragua likely would be required:
maritime boundary dispute with Nicaragua
Climate: subtropical in lowlands, temperate
in mountains
Terrain: mostly mountains in interior,
narrow coastal plains
lowest point: Caribbean Sea 0 m
highest point: Cerro Las Minas 2.870 m
Natural resources: timber. gold. silver.
copper, lead. zinc. iron ore, antimony. coal,
fish
Land use:
arable land: \\4%
permanent crops: 2%
meadows and pastures: 30%
forest and woodland: 34%
other: 2%
Irrigated land: 900 sg km (1989 est.)','aa5bd549c6a1783981ddbae91bc142b6ec68cf39fced8826d054e07fff785759','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('143ec77fafa73c4feef37e5f97e645a319b54cbc70116fbabc65e08dac8ac0d3',1996,'LR','Liberia','geography',252,'Ceographic coordinates: § 00 N. 5 00 W
Map references: Africa
Area:
total area: 322.460 sq km
land area: 318.000 sq km
comparative area: slightly larger than New
Geographic coordinates: &§ 30 N. 11) 30 W
Map references: Alrica
Area:
total area: 71.740 SY km
land area: 71.620 sq km
comparative area: slightly smaller than
South Carolina
Land boundaries:
total: 9S km
border countries: Guinea 682 km. Liberia
306 km
Coasiline: 402 km
Maritime claims:
territorial sea: 200 nm
continental shelf: 200-m depth or to the
depth of exploitation
International disputes: none
Climate: tropical: hot, humid: summer rainy
season (May to December): winter dry
season (December to April)
Terrain: coastal belt of mangrove swamps.
wooded hill country, upland plateau.
mountains im east
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani)
1.948 m
Natural resources: diamonds. titanium ore.
bauxite. iron ore, gold. chromite
Land use:
arable land: 25%
permanent crops: 2%
meadows ond pastures: 31%
forest and woodland: 29%
other: 13%
Irrigated land: 340 sg km (1989 est.)
<3','d1946b49089baa2af59d9ebb812be387c9f4c36c9cd570e30cfe4fc503891b64','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27c8fb6a30395c675efa0fe934f40f8becce1f0533882cbcae3995ee919c5602',1996,'MX','Mexico','geography',253,'Land boundaries:
total: 3.110 km
border countries: Burkina Faso 584 km.
Ghana 668 km, Guinea 610 km. Liberia 716
km, Mali 532 km
Coastline: 515 km
Maritime claims:
continental shelf; 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical along coast. semiarid in far
north: three seasons—warm and dry
(November to March). hot and dry (March to
May). hot and wet (June to October)
Terrain: mostly flat to undulating plains.
mountains in northwest
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1,752 m
Natural resources: petroleum. diamonds.
manganese. iron ore, cobalt, bauxite. copper
Land use:
arable land: 9%
permanent crops: 4%
meadows and pastures: 9%
forest and woodland: 26%
other: 52%
Irrigated land: 620 sq km (1989 est.)
Land boundaries:
> 669 km
-_ >
cp Vidm 2
34 0 D487 me: |
, »¥I/4 40 T3223 m 14
( ommunications
lclephones: 43.10% ss
I clephone system: total
horder counties” Bruner 381 kim. Indonesia
1.782 km. Thailand $06 km
Coastline: 4.675 km (Peninsular Malaysia
2.068 km. East Malayssa 2.607 kim)
Maritime claims:
continental shelf 200-m depth on to the
open-wire lines.
lay links. and
nde Tribe the nulicathws Statens
on nal satelite earth statrons
Intelsul | Indian Ocew and | Athantn
()
. depth of exploitation: specitied boundary in
Radio broadcast stations: AME 10. FM |
the South China Sea
crclasinve fishine cone: 200 am
;
acters { " non «19S;
Radiv ervlasine cconome cone 200 am
, - ati * (TORT ext
Television broadcast stations: 0 (1980 est wrritorial sea: (12 am
International disputes: involved im a
complex dispute over the Spratly Islands
leles ions: N\\A
with China, Philippines. Taiwan. Vietnam.
and possibly Brunet. State of Sabah claimed
Defense by the Philippines: Brune: may wish to
Branches: A: ules Aur Wine and purchase the Malaysian sabbent that divides
Nasal Det Police cincludes Brune: inte two parts: two islands in diypute
Mobile Force Unit with Singapore, two islands in dispute with
Location: Middle America. bordering the
Carnbbean Sea and the Gulf of Mexico
between Belize and the US and bordermneg
the North Pacific Ocean. between Guatemala
and the US
Geographic coordinates: 23 00 N. 102 00
W
Map references: North America
Area:
fotal area: | Y72 S550 Y KM
land aree
comparalive area. siightly less than three
times the size of Texcas
Land boundaries:
total: 4.838 km
border countrics’ Belize 250 kim. Guatemala
962 km. US 3.326 kn
Coastline: 9.330 kn
Maritime claims:
CONN MOUS LOM finn
Comluiental site iM) nm or to the edge of
the continental margin
F
CACTUSIVG COOMOMML Cele OO nm
International disputes: Claims Clipperton
Island (French possessio
Climate: vanes trom tropical to desert
ferrain: high. rugged mountain OW
\\ ist | pia } "1 | pebait ! |
4 j ; | Ml Su ; }
hest pont: Volcan Proo de Onzaba $700
ai
Natural resources: petroloum. silver
‘ , !
opper. gol Te tural gas
Land use:
adahie falda
Pernaich! ovo}
MNCAUdONS Gild Da
forest and woodland. 24
other: 4%
Irrigated land: 51.500 sg kimi (1989 est
Land boundaries:
total; 3.818 km
border countries: Cambodia 982 km, China
1.281 km, Laos 1,555 km
Coastline: 3.444 km (excludes islands)
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of
the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
international disputes: maritime boundary
with Cambodia not defined; involved in a
complex dispute over the Spratly Islands in
the South China Sea with China, Malaysia,
Philippines, Taiwan, and possibly Brunei:
unresolved maritime boundary with
Thailand; maritime boundary dispute with
China in the Gulf of Tonkin; Paracel Islands
in the South China Sea occupied by China
but claimed by Vietnam and Taiwan;
offshore islands and sections of boundary
with Cambodia are in dispute
Climate: topical in south; monsoonal in
north with hot, rainy season (mid-May to
mid-September) and warm, dry season (mid-
October to mid-March)
Terrain: low, flat delta in south and north;
central highlands; hilly, mountainous in far
north and northwest
lowest point: South China Sea 0 m
highesi point: Ngoc Linh 3,143 m
Natural resources: phosphates. coal.
manganese, bauxite, chromate, offshore oil
deposits, forests
Land use:
arable land: 22%
permanent crops: 2%
meadows and pastures: 1%
forest and woodland: 40%
other: 35%
Irrigated Jand: 18.300 sq km (1989 est.)','bf6c727a928f98ef20dc2c8a4b806743d6aaa823457f4ec6cb96510a144ec517','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21a702e00b23e0b38507953a9c8483df6ce8498ae77f76f19e47b4bc066d6895',1996,'HU','Hungary','geography',261,'Location: Southeastern Europe. bordering
the Adriatic Sea, between Bosnia and
Herzegovina and Slovenia
Geographic coordinates: 45 10 N. 15 30 E
Map references: Europe
Area:
total area: 56,538 sq km
land area: 56410 sq km
comparative area: slightly smaller than West
Virginia
Land boundaries:
total: 2.073 km
border countries: Bosma and Herzegovina
932 km. Hungary 329 km. Serbia and
Montenegro 266 km (241 km with Serbia:
25 km with Montenego). Slovenia 546 km
Coastline: 5.790 km (mainland 1.778 km.
islands 4.012 km)
Maritime claims:
continental shelf’ 200-m depth or to the
depth of exploitation
International disputes: Eastern Slavonia.
which was held by ethnic Serbs during the
war. is currently being overseen by the UN
Transitional Administration for Eastern
Slavonia: reintegration of Eastern Slavonia
into Croatia will occur in 1997, although
Croatia does not recognize the **Federal
Republic of Yugoslavia.” both countries
have agreed to open consular sections in
each other''s capitals; Croatia and Italy have
not resolved a bilateral issue dating thom
WWII over property and ethnic minonty
nghts: a border dispute with Slovenia ts
unresolved
Climate: Mediterranean and continental:
continental climate predominant with bot
summers and cold winters: mild winters. dry
summers along coast
119
/A8
(reatia (continued)
ferraim: ccocraphically diverse: flat plains
jopsanan border. low mountains and
rear Adriatic coast. coastline. and
wnt Admatic Sea 0 m
Dinara 1.830 m
Natural resources: oil, some coal. bauxite,
ron ere, calcium, natural asphalt.
nica. Clays. salt
taund use:
~y
ps: 20%
nd pastures: 18%
noodland: 1S
irrigated land: NA sq km
bE nvironment:
rent issues. air pollution (from
taliurgical plants) and resulting acid rain
damaging the forests: coastal pollution
trom mdustrial and domestic waste:
widespread casualties and destruction of
infrastructure in border areas affected by
cma strife
natural hazards: trequent and destiuctive
earthquakes
mlemational agreements: party to—Alr
Pollution Hazardous Wastes, Marine
Dumping. Nuclear Test Ban, Ozone Laver
Protection. Ship Pollution, Wetlands: signed.
but not ratitied—-Air Pollution-Sulphur 94.
Biodiversity, Climate Change.
Desertification, Law of the Sea
Ceographic note: controls most land routes
trom Western Europe to Aegean Sea and
tT 1 °
Purkish Straits
Location: Central Europe. northwest of
Location: Southern Europe. a peninsula
extending into the central Mediterranean Sea.
northeast of Tuntsia
Geographic coordinates: 42 50 N. 12 50E
Map references: Europe
Area:
total area: 301.230 sq km
land area: 294.020 sq km
comparative area: slightly larger than
Arizona
note: meludes Sardinia and Sicily
Land boundaries:
total: 1,935.2 km
border countries: Austria 430 km. France
488 km. Holy See (Vatican City) 3.2 km.
San Marino 39 km. Slovenia 235 km.
Switzerland 740 km
Coastline: 7.600 km
Maritime claims:
continental shelf: 200-m depth or to the
depth of exploitation
territorial sea 12 nm
International disputes: [aly 1s negotiating
with Slovenia over property and minority
rights issues dating from World War Il
Climate: predominantly Mediterranean:
Alpine in far north: hot, dry in south
Terrain: mostly rugged and mountainous:
some plains, coastal lowlands
lowest point: Mediterranean Sea 0 m
highest point: Mont Blane 4.807 m
Natural resources: mercury. potash, marble.
sulfur. dwindling natural gas and crude oil
reserves, fish, coal
Land use:
arable land: 32%
permanent crops: 10%
meadows and pastures. 17%
forest and woodland: 22%
other: 19%
Irrigated land: 31.000 sg km (1989 est.)','6349772aa2746b6789257737f65b1536e100ede770efb9059636ccfcf0654d47','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d2c467a8e6155d4f3c825a1fea865f58067a3f34cfc7bd3cfb3c0dc5465e7de',1996,'CU','Cuba','geography',266,'Location: Caribbean, island between the
Caribbean Sea and the North Atlantic Ocean.
south of Florida
C;eographic coordinates: 2! 30 N. 80 00 W
Map references: Central America and the
Caribbean
Area:
total area: 110.860 sq km
land area: 10.860 sq km
comparative area: slightly smaller than
Pennsylvania
Land boundaries:
total: 29 km
border country: US Naval Base at
Guantanamo Bay 29 km
note: Guantanamo Naval Base ts leased by
the US and thus remains part of Cuba
Coastline: 3.735 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: US Naval Base at
Guantanamo Bay is leased to US and only
mutual agreement or US abandonment of the
area can terminate the lease
Climate: tropical: moderated by trade winds:
dry season (November to April): rainy
season (May to October)
Terrain: mostly flat to roiling plains with
rugged hills and mountains in the southeast
lowest point: Caribbean Sea 0 m
highest point: Pico Turquino 2.005 m
Natural resources: cobalt. nickel, iron ore.
copper, manganese, salt, timber, silica.
petroleum
Land use:
arable land: 23%
permanent cops: 6%
meadows and pastures: 23%
forest and woodland: 17%
other: 3V%
Irrigated land: 8.960 sq km (1989)','a6fe0e72e964092d3408dae2aeaa6120fd41fa600d83611e2bfc727d363a30eb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('facf8c911ee4a93b5952278df3fac3d9c4a1c19ec1ae52527f456283572da9a4',1996,'CY','Cyprus','geography',276,'Location: Middle East. island in the
Mediterranean Sea, south of Turkey
Geographic coordinates: 35 00 N. 33 00 E
Map references: Middle East
Area:
total area: 9.250 sq km (note—3.355 sq km
are in the Turkish area)
land area: 9,240 sq km
comparative area: about 0.7 times the size
of Connecticut
Land boundaries: () km
Coastiine: 648 km
Maritime claims:
continental shelf: 200-m depth or to the
depth of exploitation
territorial sea: 12 nm
International disputes: 1974 hostilities
divided the island into two de facto
autonomous areas, a Greek area controlled
by the Cypriot Government (59% of the
island''s land area) and a Turkish-Cypriot
area (37% of the island), that are separated
by a UN buffer zone (4% of the tsland):
there are two UK sovereign base areas
within the Greek Cypriot portion of the
island
Climate: temperate. Mediterranean with hot.
dry summers and cool, wet winters
Terrain: central plain with mountaius to
north and south; scattered but significant
plains along southern coast
lowest point: Mediterranean Sea 0 m
highest point: Olympus 1.952 m
Natural resources: copper. pyrites. asbestos,
gypsum, timber, salt. marble. clay earth
pigment
Land use:
arable land: 40%
permanent crops: 7%
meadows and pastures: 1O%
forest and woodland: \\8&%
other: 25%
Irrigated land: 350 sq km (1989)
/33
Location: Central Europe. southeast of
Germaul
CGeograp tic coordinates: 49 45 No 15 40 |
Map reierences: Europe
Area:
total area? 78.7038 sq km
land area: 78.645 sq km
comparative area’ sightly smatiler than
South Carolina
Land boundaries:
otal, TL SSO km
horder countries. Austria 362 km. Germany
646 km. Poland 658 km. Slovakia 214 km
Coastline: 0 kt. landlocked)
Maritime claims: none (landlocked)
International disputes: Liechtenstem claims
restitution tor 1.600 sq km of Czech terntory
confiscated trom its roval family in 1918
Sudeten German claims tor restitution of
property contiscated in connection with thei
expulsion after World War IT versus the
Cvech Republic claims that restitution does
not precede February 1948 when the
Communisis seized power: unresolved
property issues with Slovakia over
redistribution of property of the tormer
Cvechoslovak tederal government
Climate: temperate, cool summers. cold.
cloudy. hunnd winters
Ferrain: Bohemia in the west consist. of
rolling plains. hills. and plateaus survounded
by low mountains: Moravia io the east
consists of very hilly country
lowest pomt: Elbe River 11S m
lnghest pow. Snezka 1.602 m
Natural resources: hard coal. soft coa!
kaolin, clay. graphite
Land use:
arable land. NAG
127
Czech Republic (continued)
nea crops: NAG
/ pastures: NAG
i woodland: NAG
NA‘
irrigated land: NA sy km
i avironment:
wrent issues. air and water pollution in
~ of gorthwest Bohemia and im northern
Moravia around Ostrava present health risks:
fain damaging forests
NA
iercements: party to—Au
\\ir Pollution-Nutrogen Oxides, Atr
Sulphur 8S. Antarctic Treaty,
Climate Change. Endangered
vironmental Modification,
is Wastes. Nuclear Test Ban. Ozone
Protection, Ship Pollution, Wetlands:
Air Pollution
phur Y4. Antarctie-Environmental
Law of the Sea
wil not ratified
Geographic note: landlocked. strategically
ft oldest and most
lest Europe: Moravian
litury corndor
Cyl i traditional pr,
North buropean Plain and tive
i I urope','a0f9431da62ce2fc0e16dc5badaa21cf739a63bd04d7518a951e2dde4a3d4ad9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8675ba7b7ad66708948b65c5937e8d545488e039ff581dab8bd21cca5cc925ec',1996,'DK','Denmark','geography',283,'Location: Northern Europe. bordering the
Baltic Sea and the North Sea. on a peninsula
nornh of Germany
Geographic coordinates: 56 00 N. 10 00F
Map references: Europe
\\rea:
( rea. AB ATO sg Am
j has 274) su Am
woparatie arca. sieht! more than twice
the size of Massachusetts
note. mecludes the ihand of Bornholm in the
Baltic Sea and the rest of metropolitan
De iT} | ludes the Faroe Islands and
“ai ] i j
land boundaries:
) r carers Cc THT itiy fs Amn
(Coastline: 0379 kin
Viaritime clains:
elf 200-m depth or to the
‘ tishing cone: 200 am
erriorial seas 3 nm
International disputes: Rockall continental
t dispute involving Iceland, treland, and
the UK Creland and the UK have signed a
ndary agreement mn the Rockall area)
Climate: temperate. humid and overcast:
| winds winters and cool summers
|
Ferrain: tory and flat to gently rolling plains
ef pow: Lammetyord -7 m
vhest pomt: Eyer Bavneho; 173 m
Natural resources: petroleum. natural gas.
lish. salt. lpmestone
Land use:
arable land: 61''
vrmanent crops, O%
meadows and pastures: 6%
130
forest and woodland: 12%
other: 2G
Irrigated land: 4.300 sq km (1989 est.)','dbf22285d695247d338e9b88dcbbe0967ccf31210403513eb4df9b0a639a3817','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75ae7a0dff550ec945f89da49bb589f99de6c45b88c7cdbd251af6fbce05b54a',1996,'SO','Somalia','geography',290,'Location: Eastern Afnca. bordering the Gulf
of Aden and the Red Sea, between Eritrea
and Somalia
C,eographic coordinates: || 30 N. 43 00E
Map references: Africa
Area:
total area: 22.000 sq km
land area: 21.980 sq km
comparative ar’a’ slightly larger than
Massachusetts
Land boundaries:
total: SOR km
border countries: Entrea 113 km, Ethiopia
337 km, Somalia 58 km
(Coastline: 314 km
Maritime claims:
contiguous sone: 24 am
exclusive economic zone: 200 am
territorial sea: 12 om
International disputes: none
Climate: desert. tornd, dry
Terrain: coastal plain and plateau separated
by central mountains
lowest point: Asal -155 m
highest point: Mousa Alli 2.028 m
Natural resources: geothermal areas
Land use:
arable land: O%
permanent crops: O%
meadows and pastures: 9%
forest and woodland: (%
other: 9%
Irrigated land: NA sq km','db3ac914e29c2573a251f185570e2cce56fba31bdeba8972999b7fde1fa62f44','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a1263cec3c4b0d8b5a441e1c316596699331abac95364afa6c7ed9c5f410029',1996,'DM','Dominica','geography',295,'Location: Caribbean. island between the
Caribbean Sea and (ie North Atlantic Ocean,
about one-half of the way trom Puerto Rico
to Trinidad and Tobago
Geographic coordinates: 13 30 N. 61 20 W
Map references: Central America and the
Caribbean
Area:
total area: 750 sq km
land area: 70 sq km
comparative area: more than tour times the
size of Washington. DC
Land boundaries: 0 km
Coastline: 148 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 am
International disputes: none
Climate: tropical: moderated by northeast
trade winds. heavy rainfall
Terrain: rugged mountains of volcanic
origin
lowest point: Canbbean Sea 0 m
highest point: Morne Diablatins 1.447 m
Natural resources: timber
Land use:
arable land: 9%
permanent crops: 13%
meadows and pastures: 3%
forest and woodland: 41%
other: 34%
Irrigated land: NA sq km','4384a216e6005c6e4045ce762111e00e53f15a0947d80e73ba53c0d99feaa228','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0254ed4154684d37367d29caf379276906d31ee7867b147d0bb86879f329ed9a',1996,'DO','Dominican Republic','geography',301,'Location: C anbh eastern two-thirds of
the island of Hispaniola. between the
Canbbean Sea and the North Atlantic Ocean.
baat
Geographic coordinates: 19 00 N70 40 W
Map references: Central America and the
Canhb
\\rea:
F fiel 4
comparative area. steht! more than twice
the size of New Hampshin
Land boundaries:
~- L sy
, Al
qeery Harty 7S kn
Coastline: | OSS }
\\iaritime claims:
ny One sonm
cif; 200 nm or to the edge of
( ( ow LLL YWOam
cure iy j fy nor
International disputes: nonc
{ limate: Top wal MLAPieyic little seasonal
iemperature Variation
scasonal Varnlation mn
lerrain: rugved highlands and mountains
‘hile vallevs interspersed
Lage Ennquillo -46 m
hest pom: Proo Duarte 3.175 m
Natural resources: nickel. bauxite. gold
Land use:
eailhvie Le:
permanent Crops
mvAdOWS ANd Pastures 13°,
; j >ri
f dihid nwoodland | v4
thes 14
Irrigated land: 2.250 sq km (1989)
136','fa116913893a68de686b6d91e727b7ab15a64269430e64e4d55cb506fd72cb6e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ebb3a18b159a8d6267f02e3ab4368f465704e490b2445356d330628ebb471f2',1996,'EC','Ecuador','geography',307,'Location: Western South America. bordering
the Pacttic Ocean at the Equator. between
Colombia and Peru
Geographic coordinates: 2 00S. 77 30 W
Map references: South America
\\rea:
total area: 283.560 SY km
land area: 276.840 sq km
comparative area: slightly smatier than
Nevada
note: meludes Galapagos Islands
Land boundaries:
taal, 2.030 km
horder countries: Colombia 590 km. Peru
1.420 km
Coastline: 2.237 km
Maritime claims:
comimental shelf: clams continental shelt
between mainland and Galapagos Islands
territorial sea: 200 nm
International disputes: three sections of the
boundary with Peru are in dispute
Climate: tropical along coast becoming
cooler intand
Perrain: coastal plain (costa), inter-Andean
central highlands (sierra). and flat to rolling
eastern jungle (oriente)
lowest point: Pacitic Ocean 0 m
highest point: Chimborazo 6.267 m
Natural resources: petroleum. fish, timber
Land use:
arable land: 6%
permanent crops: 3%
meadows and pastures: 17%
forest and woodland: 51%
other: 230%
Irrigated land: 5.500 sq km (1989 est.)
Geographic coordinates: 10 00S. 76.00 W
Map references: South America
Area:
total area: 1.285.220 sq km
land area: 1.28 muiivon sq km
comparative area. slightly smaller than
Alaska
Land boundaries:
romtal: 6.940 km
border countries: Bolivia 900 km, Brazil
1.560 km. Chile 160 km. Colombia 2.900
km. Ecuador 1.420 km
Coastline: 2.414 km
Maritime claims:
comtinental shelf: 200 am
territorial sea: 200 nm
International disputes: three sections of the
boundary with Ecuador are in dispute
Climate: varies from tropical in east to dry
desert in west
Terrain: western coastal plain (costa). high
and rugged Andes in center (sierra). eastern
lowland jungle of Amazon Basin (selva)
lowest point: Pacitic Ocean 0 m
highest point: Nevado Huascaran 6.768 m
Natural resources: copper. silver. gold.
petroleum. timber, fish. iron ore, coal,
phosphate, potash
Land use:
arable land: 3%
permanent crops: O%
meadows and pastures: 21%
forest and woodland: SS%
other: 2VG
irrigated land: | 2.500 sq km (1989 est.)','edd554db44aaa0df642fc210af3eca2b08d937942c461e47d746494729acd3a2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dcb7954e3fc0d7bd773a03183085be813759542155753f9734de73d9990192a',1996,'SD','Sudan','geography',313,'Location: Northern Africa, bordering the
Mediterranean Sea. between Libya and the
Gaza Strip
Geographic coordinates: 27 00 N. 30 00 E
Map references: Africa
Area:
total area: 1,001,450 sq km
iand area: 995 ASO SY km
comparative area: slightly more than three
times the size of New Mexico
Land boundaries:
total. 2.689 km
border countries: Gaza Strip 11 km, Israel
255 km, Libya 1.150 km, Sudan 1.273 km
Coastline: 2.450 km
Maritime claims:
contiguous cone: 24 nm
continental self; 200-m depth or to the
depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: administrative
boundary with Sudan does not coincide with
international boundary creating the “*Hala ‘tb
Triangle.” a barren area of 20,580 sq km.
tensions over this disputed area began to
escalate in 1992 and remain high
Climate: desert; hot, dry summers with
moderate winters
Terrain: vast desert plateau interrupted by
Nile valley and delta
iowest point: Qattara Depression -133 m
highest point: Mount Catherine 2.629 m
Natural resources: petroleum, natural gas.
iron ore, phosphates, manganese, limestone,
gypsum, talc, asbestos, lead, zinc
Land use:
arable land: 3%
v
permanent crops: 2%
49
meadows and pastures: 0%
forest and woodland: 0%
other: 95%
Irrigated land: 25.850 sq km (1989 est.)
Location: Middle East. bordering the Persian
Cult and the Red Sea. north of Yemen
Geographic coordinates: 25 00 N. 45 OO E
Map references: Middle East
Area:
total area: 1.960.582 sq km
land area: 1.960.582 sq km
comparative area: slightly less than one
fourth the size of the US
Land boundaries:
total: 4.415 km
border countries: Irag 814 kin, Jordan 728
km. Kuwait 222 km. Oman 676 km. Qatar
60 km, UAE 457 km. Yemen 1.458 km
Coastline: 2.640 km
Maritime claims:
contiguous cone: 1S nm
continental shelf: not specitied
territorial sea: 12 am
International dispiices: large section of
boundary with Yemen not detined: locatior
and status of boundary with CAE 1s not
final, detacto boundary reflects 1974
agreement, Kuwaiti ownership of Qaruh and
Umm al Maradim islands ts disputed by
Saudi Arabia, 1965 boundary with Qatar
renegotiated and revised in 1992. but no
—
Official depiction
Climate: harsh. dry desert with great
extremes of temperature
Terrain: mostly uninhabited, sandy desert
lowest point: Persian Gult 0 m
highest point: Jabal Sawda’ 3.133 m
Natural resources: petroleum, natural gas
iron ore, gold, copper
Land use:
arable jand: 1%
permanent crops: O%
meadows and pastures: 39%
417
Saudi Arabia (continued)
ind woe nlland | %
irrigat.4 land: 4.350 sq km (1989 esi.)
itnvironment:
é ; M ‘Vite 4
desertification: depletion of
lerground water resources: the lack of
al rivers or permanent water bodies
mpted the development of extensive
water desalination faciliues; coastal
from oil spells
hazards: trequent sand a | dust
nai agreements purty to—Climate
Hazardous Wastes. Ozone I ayer
} tection. signed, but not ratified—Law of
(,cographic note: extensive coastlines on
Gaull and Red Sea provide great
hipming (especially crude ol)
Persian Gult and Suez Canal
Location: Northern Alnmca. bordering the
Red Seca. between f gym and Eritrea
eographic coordinates: 15 00 N. 30 00 fT
Map references: Ainca
\\rea:
mal area: 2505810 sa km
land area 376 millon sq km
mparative arca, sightl, more than one
quarter the size of the US
Land boundaries:
total: 7.687 km
border countries: Central Atncan Republi
16S kra. Chad 1.360 km. Egypt 1.273 km
Eritrea OOS km. Ethopia 1.606 ku. Kenya
"32> kom. Libwa 483 km. Uganda 445 km
Jarre 628 km
(Coastline: 853 km
Maritime claims:
contienous cone: 1S om
continental shelf, 200m depth ot to tie
depth of explottation
territorial sea: i2 am
International disputes: admunisiratys
houndary with Kenva does nm commode with
micrnathonal boundary. admunistrative
boundar with Egypt does not comcwe with
memational boundar, creating the “‘Hala ib
Inangle. a barren area of 20.580 sg kim
tenspoms over this disputed area began to
escalate m 1992 and remaim high
Climate: tropical in south, and desert in
north, ray season (April to October)
Terrain: generally flat. featureless plain
mountains m cast and west
Red Sea 0 m
Kinveti 3.187 m
Natural resources: petroleum. smal!
lmew pon
nivite VT purini
chromium ore
reserves of ITO OTe Coppel
nme. tungsten, mica. silver, gold
Land use:
arable land: 5%
permanent crops: O''s
meadows and pastures: 24%
forest and woodland: 20%
other: S19
Irrigated land: 18.900 sg km (1989 est)','45c999fafb67c78923b393af971f07fe7ae82da99bb2e3500ee42c9c4896b598','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13aca661ac5b9e5fcbf4de1d8f68c275b6b442742184f49c4f1ad6b17753f2b8',1996,'ER','Eritrea','geography',328,'Location: Eastern Airnica. bordering the Red
Sea. between Dytouti and Sudan
Ceographic coordinates: 15 00 N. 39 00 E
Map references: Afnca
Area:
wial area: W2N 320 sg km
land area, 121.320 sq km
comparative arca. slightly larger than
Pennsylvama
Land boundaries:
hial: 1.630 km
border countries: Dybout: 113 kim. Ethiopia
912 km. Sudan 605 km
Coastline: 1.151 km (land and island
coaMime ts 2.234 km)
Maritime claims: \\\\ A
International disputes: a dispute with
Yemen over sovereignty of the Hanish
Islands in the southern Red Sea has been
submitted to arbitration under the auspices of
the 1CJ
Climate: hot. dry desert sinp along Red Sea
coast; cooler and wetter in the central
hightonds (up to 61 cm of rainfall annually):
semiand im western hills and lowlands
rainfall heaviest during June-September
cvcept on coastal desert
Terrain: dominated by eviension of
kihhopiar north-south trending highlands
descending on the cast to a coastal desert
plan. on the northwest to hilly terrain and
on the southwest to flat-to-rolling plains
lowest point: Kobar Sink -75 m
highest point: Soura 3.013 m
Natural resources: gold. notash. zinc
copper. sali. probably oil (petroleum
geologists are prospecting for it). fish
Land use:
arable land: 4%
147
Eritrea (continued)
rmanem crops: 2% (coffee)
s and pastures: 40%
wud woodland: 4%
SO
tcrigated land: NA sg km
invironment:
“urren issues: famine: detoresiation:
Utication, soil erosion, overgrazing: loss
structure from civil wartare
wail hazards: trequeni droughts
rye mal agreements. pa4ty to
jlangerest Species: signed, but not
Chmate Change. Desertification
(,cographic note: strategic geopolitical
on along world’s busiest shipping
Enitrea retamed the entire coastline of
bihhopia slong the Red Sea upon de jure
ndependence trom Ethiopia on 27 Apnil
(99','8f10295fcaac5e6cf767873f5998059aec8ad77eb850f3f765404f2856400e83','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1ef602c2571d2f261cd16bd7fddddc3ce613b4c8b92979ea1fe5cb58b011861',1996,'FI','Finland','geography',333,'Location: Eastern Europe. bordering
Baltic Sea and Gulf of Finland. between
Latvia and Russia
Geographic coordinates: 59 00 N. 26 00 |}
Map references: Europe
Area:
total area: 45.100 sy km
land area: 43.200 sq km
comparative area. slightly larger than New
Hampshire and Vermont combined
note: mecludes 1.520 islands in the Baltic Se:
Land boundaries:
total: SS7 km
horder countnes. Latvia 267 km. Russia 290
km
Coastline: |}.395 km
Maritime claims:
exclusive economic cone: limits to be fixed
In coordination with neighboring states
territorial sea: \\2 nm
International disputes: claims over 2.000 sq
km of Russian territory in the Narva and
based on boundas
Treat
Pechora regrons
eMablished under the 1921 Peace
Tartu: disputes maritime border with
Latvia—primary concern ts fishing nght
moderate
around Ruhne Island in the Gult
Climate: maritime. wet
cool summers
Terrain: marshy. lowland
Baltic Sea 0 m
highest point: Suur Munamagi 318 o
Natural resources: shale o1|. peat
phosphorite. amber
Land use:
arab "¢ land 22%
winters
lowe v/ poml
permanent crops. 0
meadows and pastures: VV"
forest and woodland: 4\\%
149
1S8
Estonia (continued)
irrigated land: 110 sy km (1990)
Location: N
cn Fanland an
Ceographic coordinates: 62 00 N
Map references: Europ
\\rea:
u AI
hivhtly smaller
C ahtomia
and boundaries:
> 205 km
rder countries. Finland S86 km
6H19 km
oastline: 3.218 km
Viaritime claims:
continental shelf: 200-m depth or to the
depth of exploration
CACIMSIVEG CCcOonomKn one avreed boundaries
or midline
ferruorial sea: 12 nm
International disputes: none
Climate: temperate in south with cold,
cloudy winters and cool, partly cloudy
summers; subarctic in north
Terrain: mostly flat or gently rolling
lowlands; mountains in west
lowest point: Baltic Sex 0 m
highest point: Kebnekaise 2.111 m
Natural resources: zinc, iron ore, lead,
copper, silver, umber, uranium, hydropower
potential
Land use:
arable land: 7%
permanent crops: O%
meadows and pastures: 2%
forest and woodland: 64%
other: 27%
irrigated land: |.) 20 sg km (1989 est)','7666c3c8b1f3959fadaae2e06f12c96f29e07702b7f6576a18ee44d2971f99ad','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d1fd49204444b240f10a65750cd2fa4669bf5ac94d7f511661e7759cdb42786',1996,'AR','Argentina','geography',343,'Geographic coordinates: 5) 45 5.59 00 W
Map references: South America
Area:
total area: 12.170 sq km
land area: 12.170 sy km
comparative area: slightly smaller than
Connecticut
note: wmecludes the two main islands of East
and West Falkland and about 200 small
islands
Land boundaries: |) km
Coastline: |.288 kn
Maritime claims:
commnental shel{, 200 am
ervclusive fishing cone: 200 nm
territorial sea: 12 am
International disputes: administered by the
UK. clamed by Argentina
Climate: cold manne. strong westerly winds.
cloudy, humid: rain occurs on more than halt
of days im year: occasional snow all year.
except in January and February. but does not
a cumulate
Ferrain: rocky. hilly, mountainous with
some boggy. undulating plains
lowest point: Atlantic Ocean 0 m
nighest point: Mount Usborne 70S m
Natural resources: lish. wildlile
Land use:
arable land: O%
permanent crops: O%
meadows and pastures: 99%
forest and woodland: O%
other: 1%
Irrigated land: NA sg km
Location: Centra! South America, northeast
of Argentina
Geographic coordinates: 23.00 S. 58 00 W
Map references: South America
Area:
total area: 406.750 sq km
land area: 397 300 sq km
comparative area: slightly smaller than
Calitornia
Land boundaries:
total: 3.920 km
border countries: Argentina | 880 km.
Bolivia 750 km, Brazil 1.290 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: short section of the
boindary with Brazil, just west of Salto del
Guaira (Guaira Falls) on the Rio Parana, has
not been determined
Climate: subtropical; substantial rainfall in
the easter portions, becoming semiarid in
the sar west
Terrain: grassy plains and wooded hills east
of Rio Paraguay: Gran Chaco region west of
Rio Paraguay mostly low, marshy plain near
the river. and dry forest and thorny scrub
elsewhere
lowest point: yanction of Rio Paraguay and
Rio Parana 46 m
highest point: Cerro San Ratael 850 m
Natural resources: hydropower. timber. iron
ore. manganese, limestone
Land use:
arable land: 20%
permanent crops: \\&%
meadows and pastures: 39%
forest and woodland: 35%
other: S%
Irrigated land: 670 sq km (1989 est
—','a8ada755e589e65871e08d8c399dacac7a03da62e775872405fbe4c22b96e732','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5be35776bb9c7770b979dc4c71e0d98bff1ae526d26a0a957844667fa2aadb53',1996,'FO','Faroe Islands','geography',350,'Location: Northern Europe, island group
between the Norweg''an Sea and the north
Atlantic Ocean, about ene-hall of the way
trom Iceland to Norway
Ceographic coordinates: 62 00 N. 7 00 W
Map references: Europe
Area:
twtal area: | A0O sq km
land area: 1400 sq km
comparanve area eight times the size of
Washington, DC
Land boundaries: () km
Coastline: 764 km
Maritime claims:
exclusive fishing cone: 206 um
terruorial sea: 3m
International disputes: nonce
Climate: mild winters, cool summers.
usually overcast, foggy. windy
Terrain: rugged. rocky. some low peaks:
clits along most of coast
lowest point: Atlantic Ocean 0 m
lughest point: Slaettaratindur 882 m
Natural resources: fish
Land use:
orable land: 2%
permanent crops: O%
meadows and pastures: O%
forest and woodland: 0%
other: Y8G
Irrigated land: NA sy km
Location: Gceama. «and group in the South
Pactixc Ocean, ainan two-thirds of the way
from Hawan to New Zealand
Ceographic coordinates: 18 00.5. 175 00 F
Map references: Oceania
Area:
otal area: 18.270 sq kim
land area: 18.270 sq km
comparative area: sightly smaller than New','47040ba356bf85b2ea295f50fecd9a1bf52710463ea88c4cec47ed4ed5249f7e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c5a30d96f3089f2577d0f72ff004933156f369147ff8a309e7537f3ef7f237e',1996,'JE','Jersey','geography',355,'Land boundaries: 0) km
Coastline: |.) 29 km
Maritime claims: measured trom clanmed
archipelagre baselines
comimental shelf: 200-m depth or to the
depth of exploitation, rectilinear shelf clam
added
eiclasinve economic cone, 2000 am
kvritonal sea: 12 am
International disputes: none
Climate: tropical marine, only slight
scasonal temperature Variation
Terrain: mostly mountains of volcan
ong
lowest pot: Pacthe Ocean 0 m
highest pont: Toman 1.324 m
Natural resources: timber. fish. gold
copper, offshore oil potential
Land wee:
arable land: 8%
permanent crops, Ss
meadows and pastures: XG
ores and woodlard: 68%
her: WW
Irrigated land: 10 sg km (1989 est)
Land poundaries:
total: 1,006 km
border countries: Egypt 255 km. Gaza Strip
51 km. Jordan 238 km, Lebanon 79 km,
Syna 76 km, West Bank 307 km
Coastline: 273 km
Maritime claims:
continental shelf: to depth of exploitation
territorial sea: 12 nm
International disputes: West Bank and
Gaza Strip are Israeli occupied with current
Status subject to the [sraeli-Palestinian
Interim Agreement—permanent status to be
determined thiough further negotiation:
Golan Heights ts Israeli occupied: Isracis
troops in southern Lebanon since June 1982
Climate: temperate: hot and dry in southern
and eastern desert areas
Terrain: Negev desert in the south: low
coastal plain: central mountains: Jordan Rift
Valley
lowest point: Dead Sea -408 m
highest point: Her Meron 1.208 m
Natural resources: copper. phosphates.
bromide. potash, clay, sand. sulfur, asphalt.
manganese. small amounts of natural gas and
crude oil
Land use:
arable land | 7
(
permanent crops: 5%
meadows and pasiures: 40%
ferest and woodland: 6%
ther: 32°
Irrigated land: 2.140 sy km (1989)
Location: \\\\
1 { j
Geographic coordinates
Map references: |
Area:
\\\\ r
Land boundaries
( oasthine:
VMiaritime claims
International disputes
Climate:
lerrain:
Natural resources:
Land us«
irrigated land: \\ \\
Lnvironment
Geographic note:
t Channel |
246
Location: Oceania. atoll in the North Paciti
Ocean. about one-third of the way trom
Hawan to the Marshall Islands
Geographic coordinates: 16 45 N. 169 30
W
Map references: Oceania
Area:
total area: 2.8 sq km
land area: 28% sq km
comparative area: about 4.7 umes the size
of The Mall in Washington. DC
Land boundaries: 0) km
Coastline: 10 km
Maritime claims:
exclusive economic cone: 200 nim
territorial sea: 12 nm
International disputes: none
Ciisiate: tropical. but generally dry
consistent northeast trade winds with litle
seasonal temperature variation
Terrain: mostly flat
lowest point: Pacitic Ocean 0 m
highest point: Summit Peak 5S m
Natural resources: NA: guano deposits
worked until depletion about 1890
Land use:
arable land: O%
permanent crops, OM
meadows and pastures, O%
forest and woodland: O%
other: 10%
Irrigated lang: 0 sy km
Land boundaries: 0 kin
Pransportation Coastline: 2.254 kin
_ Maritime claims:
Railw i\\
C1rchisiive ccoonont "iy a) nim
Hivhways in ,
horrioral scas t2nm
International disputes: \\latthew and Hunter
Islands clammed by France and Vanuatu
: (Climate: tropical, modified by southeast
! \\
trade winds: hot. hunud
rehiant marke ;
Cr Perrain: coastal plains with intertor
Muna.
. 1y\\\\
‘4 AJEILLES Pacitn Qcean Om
highest pout Mont Pame L.628 m
Natural resources: gicke!l. chrome. iron
yialt_ TAP Lil silver vol lead Coppel
Land use:
; r {)}
wey ; j ry t}
rport
meadows and pastures, 14
JEL. (ithe nanwndland S|!
jie a,»
Irrigated land: NA sy kin
Lnvironment:
wre sine NA
ane hacards Ly phcnnns host Ireque ni
trom November to March
Communications Mlernational agreements: NA
lelephones: NA
M44
Location: Oceania. itands im the South
}’ Mccan. southeast of Australi
|
(,eographic coordinates: 4) 008.174 001
Map references: Occani
\\rea:
eye NI “y kin)
re’ ‘ry fy sg kin
, ‘ res out the size |
( Tl
\\uckland
Is. Bounty Islands, Campbell [stan
mad Kermadec Islands
Land boundaries: 0 kim
© mclud \\ntipodes [stands
( ham | lana
Coastline: 15.544 hin
Viaritime claims:
ental shelf) 2000 nm or to the edge of
Winental miarem
MELLLLLLLL nie 1) nn
ortal seas Voawm
International disputes: terrmtoral claim on
Vntarctica (Ross Dependency)
Climate: teraperate with sharp regional
onirast
Terrain: predominately mountainous with
some large coastal plains
lowest pom Pacitic Ocean 0 m
lighest pot: Mount Cook 3.764 m
Natural resources: natural gas. ion ore.
sand, coal. timber. hydropower. gold.
limestone
Land use:
arable land: 4
permanent crops. Fe
meadows and pastures sv
'' j
(we adhd woodland SA‘ 4
oles TW
Irrigated land: 2.8010 sy hm (IYSY est)','0b0b032a254df2c79ce6536a833774e4cfd69962eeba3e56145ab1d006145f41','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57eb1e8741f5be19ed6ac17405141db0453c3b121749c893a19bbbed9560ee98',1996,'EE','Estonia','geography',361,'Location: Northern Europe. bordering the
Baluc See Gull of Bothnia. and Gulf of
Finland, setween Sweden and Russia
(,eographic coordinates: 64 00 N. 26 001
Map references: Europe
Area:
total area: 337.058) sq km
land area’ ¥0S.A70 sq km
comparative area slightly smaller than
Montana
Land boundaries:
tial: 2.628% km
horder countries: Notway 729 km. Sweden
S86 km. Russia 1.313 km
Coastline: 1.126 km (excludes islands and
coaMal indentations)
Maritime claims:
contiguous sone: 6 nm
comtinental shelf: 200-m depth or to the
depth of exploitation
/69
exclusive fishing zone: |2 am
territorial sea: 4 am
international disputes: nonc
Climate: cold temperate. potentially
subarctic, but comparatively mild because of
moderating influence of the North Atlantic
Current, Baltic Sea. and more than 60,000
lakes
Terrain: mostly low. flat to rolling plains
imterspersed with lakes and low hills
lowest point: Baluc Sea 0 m
highest point: Haluatuntun | 328 m
Natural resources: timber. copper. zinc.
iron ore, silver
Land use:
arable land: 8%
permanent crops, O%
meadows and pastures: 0%
forest and woodland: 76%
other: 16%
Irrigated land: 620 sq km (1989 est)','235ff687bd1d492ce2acf365f0caf01757c3404e01de3344112831c5e9cb873e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20ebd806545e321379df852db3f2866f0e1227b5428a743cad88597d141d4ef8',1996,'FR','France','geography',367,'Location: Western Europe. b
Bay of Biscay and English Chan:
Belgium and Spam southeast LK
bordering the Mediterrineas b
lialy and Spain
Ceographic coordinates: 46 00 \\
Map references: Lurop
\\rea:
‘ S47 040 ‘
LL 40.9) i +
1
(
Land houndaries:
\\ rr
| ( "
| . km. M
f * bk ‘ b
( oasthin : ,
( cee
Maritime claims
, iy
international disputes: Vlad
Bassas da India. | |
nds. Juan de Nova | ft
Island: Comero lars May Ma
chams Tromelin Island: Ses
lromelin Island: Surinam \\
French Guiana, Mexico claims Clipperton
“sland: terntonal clam m Antarctra (Ad
Land): Saint Pierre and Miquelon 1
mantime houndary dispute b
end,
and france: claams Matthew
Islands east of New Caledo
Climate: generally cool wi
im Cr ’ A iT
aiong the Meduterran
Terrain: mostly flat ;
Posiis a7
mou! r
Alps
esl pr Rhone |
highest point: Mont B
Natural resources:
Land use:
, ;
Y nce (
Irrigated land: | 4.550 xq }
Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 IS E
Map references: Middle East
Area:
total area: 5.860 sq km
land area: 5,640 sq km
comparative area: slightly smaller than
Delaware
note: includes West Bank, Latrun Salient,
and the northwest quarter of the Dead Sea,
but exc''udes Mt. Scopus; East Jerusalem and
Jerusalem No Man’s Land are also included
only as a means of depicting the entire area
occupied by Israel in 1967
Land boundaries:
total: 404 km
border countries: Israel 307 km, Jordan 97
km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked;
International disputes: West Bank and
Gaza Strip are Israeli occupied with current
Status subject to the Israeli-Palestinian
interim Agreement—permanent status to he
determined through further negotiation
Climate: temperate. temperature and
precipitation vary with altitude, warm to hot
summers, cool to muld winters
Terrain: mostly rugged dissected upland.
some vegetation in west, but barren in east
lowest point: Dead Sea -408 m
highest point: Tall Asur 1.022 m
Natural resources: NEGL
Land use:
arable land: 27%
permanent crops: 0%
meadows and pastures: 32%
forest and woodland: \\%
other: 40%
Irrigated land: NA sq km','9aa4f70d1619c0a30fdbba9977eb9615f6dbf61a2976debc4f8f2660b39dac41','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a3147f0fab6fe47d0a6fa31efa674779b18862aa15a41a9af1378aa7df6708f',1996,'GF','French Guiana','geography',374,'Location
''}
C,eouraphic coordinates ‘\\ WwW
\\Miap references
Are i
| if 1} i ti
’
AL
; ''
Irrigated land: N\\A
Location: Southern Afmca. islands in the
southern Indian Ocean, about equidistant
between Afnea, Antarctica. and Australia
note—French Southern and Antarctic Lands
includes He Amsterdam. He Saimt-Paul, Hes
Crozet. and Hes Kerguelen in the southern
Indian Ocean. along with the French-claimed
Adelie Land’. the US
does not recogmze the French claim to
Adelie Land
Geographic coordinates: 43 005.67 001
Map references: Antarctic Region
Area:
sector of Antarctica
7.781 sa kim
7.781 sq km
comparative arcas stathtly less than 15
lolal area
land adica
times the size of Delaware
note. weludes He Amsterdam. He Saint-Paul
Hes Crozet and Hes Kerguelen. exclud
Adele Land
cham of about SOO OOD .
“
hmm Antarctica that ws not recognized by
the US
Land boundaries: 0 kin
Coastline: |.232) kn
Maritime claims:
CACHING CCONOMIG “ON “HM nm fiom Hes
Rereuclen only
ferrueival sea. oon
Adelie Land
clam in Antarctica ts not recognized by the
US
Climate: antarcii
lerrain: volcan
International disputes:
lowest powmt Indian Ocean Om
hier s/ pout Mont Ross on Kerguel 1
1&SO m
Natural resources: fish. crayfish
Land use:
arable land: 0%
permanent crops. O''s
meadows and pastures. OV
forest and woodiand:
other: \\OO%
Irrigated land: 0 sy km
Location: Western Atria, bordering the
North Atlantic Ocean and Senegal
Ccographic coordinates: |4 28 N. 16 2) W
Map references: Africa
Area:
wal areas VO sg km
and areca, VOA00 sg km
omparative area. shetty more than tw
the size of Delow are
Land boundaries:
HAN
(Coastline: SO ki
Maritime claims:
/ /
International disputes
( timate
‘\\ ‘\\
\\1
terram }
Natural resources
land use
irrivated land " KY','fcb44849f1513a167f7cb2b9a9340c49bd470b8111b55ddaba70f6d32fffc87c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ac839705821363ac7293f52a11638e8379e642f125d08030bec69ebd6a2f3f3',1996,'IL','Israel','geography',380,'Location: Middle East. bordering the
Mediterranean Sea, between Egypt and Israel
Geographic coordinates: 31 25 N. 34 20 E
Map references: Middle East
Area:
total area: 360 sq km
land area: 360 sq km
comparative area: slightly more than twice
the size of Washington, DC
Land boundaries:
total: 62 km
border countries: Egypt 11 km, Israel 51 km
Coastline: 40 kini
Maritime claims: Israeli occupied with
current status subject to the Israeli-
Palestinian Interim Agreement—permanent
status to be determined through further
negotiation
International disputes: West Bank and
Gaza Strip are Israeli occupied with current
Status subject to the Israeli-Palestinian
Interim Agreement—permanent status to be
determined through further negotiation
Climate: temperate. mild winters, dry and
warm to hot summers
Terrain: flat to rolling. sand- and dune-
covered coastai plain
lowest point: Mediterranean Sea 0 m
highest point: Abu “Awdah (Joz Abu *Auda)
105 m
Natural resources: NEGL
Land use:
arable land: 13%
permanent crops: 32%
meadows and pastures: 0%
/33
forest and woodland: 0%
ather: SS%
Irrigated land: 115 sq km (1992 est.)
Location: Middle East, bordering the
Mediterranean Sea, between Egypt and','7d0c03cb8e43853662c788cf36cbec6c1b7d896995e1543cb31aedcd6b8c0b74','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b98f8d9e0041e37c3e2ee97a7c1431ceafdbbf2d62f281af8dd86778e50cc32f',1996,'GE','Georgia','geography',387,'Location: Southwestern Asia. bordering the
Black Sea. between Turkey and Russia
Geographic coordinates: 42 00 N. 43 30 E
Map references: Commonwealth ot!
Independent States
\\rea:
total area: 69.700 SY km
land area: 69.700 sq km
comparative area: slightly larger than South
Carolina
Land boundaries:
total: 1.461 km
border countries: Armema 164 km.
\\verbayjan 322 km. Russia 723 km. Turkey
252 km
Coastline: 310 km
Maritime claims: NA
International disputes: none
Climate: warm and pleasant: Mediterranean-
like on Black Sea coast
Terrain: large!y mountainous with Great
Caucasus Mountains in the north and Lesser
Caucasus Mountains in the south: Kolkhida
Lowland opens to the Black Sea in the west:
Mitkvart River Basin in the east: good soils
in river Valley tlood plains, foothills of
Kolkhida Lowland
lowest point: Black Sea 0 m
highest point: Mta Mainvartsven (Gora
Kazbek) 5.048 m
Natural resources: forests, hydropower,
manganese deposits, iron ore, copper, minor
coal and oil deposits: coastal climate and
soils allow tor important tea and citrus
growth
Land use:
arable land: 11
permanent crops: 4%
meadows and pastures: 29%
forest and woodland: 38%
other: US%
Irrigated land: 4.660 sq km (1990)
Land boundaries:
total: 1.424 km
border countries: Algeria 965 km, Libya 459
km
Coastline: 1,148 km
Maritime claims:
contiguous zone: 24 nm
territorial sea: 12 nm
International disputes: maritime boundary
dispute with Libya: land boundary dispute
479
4/88
Tunisia (continued)
with Algeria settled in 1993; Malta and
Tunisia are discussing the commercial
exploitation of the continental shelf between
their countries, particularly for oil
exploration
Climate: temperate in north with mild, rainy
winters and hot, dry summers: desert in
south
Terrain: mountains in north; hot, dry central
plain: semiarid south merges into the Sahara
lowest point: Shatt al Gharsah -''7 m
highest point: Jabal ash Shanabi 1,544 m
Natural resources: petroleum, phosphates,
iron ore, lead, zinc, salt
Land use:
arable land: 20%
permanent crops: 10%
meadows and pastures: \\9%
forest and woodland: 4%
other: 47%
Irrigated land: 2.750 sq km (1989)
Location: Southwestern Asia (that part west
of the Bosporus is sometimes included with
Europe). bordering the Black Sea, between
Bulgaria and Georgia, and bordering the
Aegean Sca and the Mediterranean Sea,
between Greece and Syna
Geographic cvordinates: 39 00 N, 35 OO E
Map references: Middle East
Area:
total area: TS8OS80 sy km
land area: 770.760 sq km
comparative areca: slightly larger than Texas
Land boundaries:
total; 2.627 km
border countries: Armenia 268 km,
Azerbaijan 9 km. Bulgaria 240 km, Georgia
252 km. Greece 206 km, Iran 499 km, Irag
331 km. Syria 822 km
Coastline: 7.200 km
Maritime claims:
exclusive economic zone: mn Black Sea
only— to the maritime boundary agreed upon
with the former USSR
territorial sea: 6 nm in the Aegean Sea,; 12
nm in the Black Sea and in the
Mediterranean Sea
International disputes: complex maritime,
air and territorial disputes with Greece in
Aegean Sea: Cyprus question; Hatay
question with Syria: dispute with
downstream nparians (Syria and Iraq) over
water development plans for the Tigris and
Euphrates Rivers
Climate: temperate. hot, dry summers with
mild, wet winters: harsher in interior
Terrain: mostly mountains: narrow coastal
plain; high central plateau (Anatolia)
lowest point: Mediterranean Sea 0 m
highest point: Mount Ararat 5,166 m
Natural resources: antimony, coal,
chromium, mercury. copper, borate, sulfur.
iron ore
Land use:
arable land: 30%
permanent crops: 4%
482
meadows and pastures: 12%
forest and woodland: 26%
other: 28%
Irrigated land: 22.200 sq km (1989 est.)
Location: Central Asia, bordering the
Caspian Sea, between Iran and Kazakstan
Geographic coordinates: 40 00 N, 60 00 E
Map references: Commonwealth of
Independent States
Area:
total area: 488,100 sq km
land area: 488,100 sq km
comparative area: slightly larger than
California
Land boundaries:
total: 3,736 km
border countries: Afghanistan 744 km, Iran
992 km, Kazakstan 379 km, Uzbekistan
1,621 km
Coastline: 0 km
note: Turkmenistan borders the Caspian Sea
(1,768 km)
Maritime claims: none (landlocked)
International disputes: Caspian Sea
boundaries are not yet determined
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with
dunes rising to mountains in the south: low
mountains along border with Iran; borders
Caspian Sea in west
lowest point: Sarygamysh Koli -110 m
highest point: Ayrybaba 3,139 m
Natural resources: petroleum, natural gas,
coal, sulfur, salt
Land use:
arable land: 2%
permanent crops: O%
meadows and pastures: 69%
forest and woodland: 0%
other: 29%
Irrigated land: 12.450 sq km (1990)','132f2a3af2eb2942ae7f66edb317547e4681bfd3d8d2015b76f3b5bf7b5526be','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63440612f9a01550aa5b5c17816029b6902eea982fb3ecb2fc2f53c37f861b7d',1996,'DE','Germany','geography',392,'Location: Central Europe. bordering the
Baltic Sea and the North Sea, between the
Netherlands and Poland, south of Denmark
Geographic coordinates: 51 00 N. 9 00.E
Map references: Europe
Area:
total area: 356.910 sq km
iand area: 349,520 sq km
comparative area: slightly smaller than
Montana
note: includes the formerly separate Federai
Republic of Germany, the German
Democratic Republic. and Beriin, following
formal urification on 3 October 1990
Land boundarivs:
total: 3.621 km
border countries: Austria 784 km, Belgium
167 km. Czech Republic 646 km, Denmark
68 km, France 451 km, Luxembourg 138
km. Netherlands 57, km, Poland 456 km,
Switzerland 334 km
Coastline: 2.389 km
Maritime claims:
continental shelf: 200-m depth or to the
depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: temperate and marine: cool,
cloudy, wet winters and summers; occasional
warm, tropical foehn wind: high relative
humidity
Terrain: lowlands in north, uplands in
center. Bavarian Alps in south
lowest point: Freepsum Lake -2 m
highest point: Zugspitze 2.962 m
Natural resources: iron ore, coal, potash,
timber, lignite, uranium, copper, natural gas,
salt, nickel
($7
Land use:
arable land: 34%
permanent crops: \\%
meadows and pastures: 16%
forest and woodland: 30%
other: 19%
Irrigated land: 4.800 sq km (1989 est.)','3dcc23aa1dc71e278d665c37743b28be6e2510bbc0113c07b091cdbdfc9193ef','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbe8a6c113c1b17ffc492d6c4a4ab5d8e5ea1f47ad47d314adba2fbf60efb1b3',1996,'GH','Ghana','geography',397,'Location: Western Atmea. borden
North Lhanty (cea! Nel AEN ( 4 |
ind | ”
Geographic coordinates: § 00 N02 00 \\W
Map references: Atrica
\\rea:
hea 238.540 su kn
Ah r 230.020) sg kn
omparative area’ slightly smaller thar
( rego
Land boundaries:
|
total, 2.093 km
border countries. Burkina Faso S48 km
Cote dIvoire 668 km logo S77 km
Coastline: 539 kim
Maritime claims:
CONTRUOUS TONE Jd nim
comtinental shelf; 200 nm
exclusive e-onomic cone: 200 nm
territorial sea: 12nm
International disputes: none
Climate: tropical: warm and comparatiy:
dry along southeast coast: hot and hamid
southwest: hot and drv in nortl
Terrain: mostly low plains with dissected
plateau in south-central area
lowest point: Atlantic Ocenia O m
highest point: Mount Afadjato S80 m
Natural resources: gold. timber. industn
diamonds, bauatte.
Land use:
arable land: SG
permanent crops: 7%
meadows and pastures: 15°
forest and woodland: 37%
other: 26%
Irrigated land: 80 sg km (1989)
Is!
manganese, tish. rubber
’
/90
Ghana (continued)','c8452174621058fe2a1a5cac0f0fba0114c126e6ecb1ceb060267f62e2258b80','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8da529085eec860f1d5df7590dcaee3e23027a4b5d9b094b9276550a30705c0',1996,'GI','Gibraltar','geography',404,'Location: Southwestern Europe. bordering
the Strat of Gibraltar. which links the
Mediterranean Sea and the North Atlantx
Ocean, on the southern coast of Spain
(,eographic coordinates: 36 || \\. 5 2) \\
Map references: Europe
\\rea:
total areca: 9.5 sq km
land area: 6.5 sg km
comparative area, about V1 times the size ot
The Mall in Washington, DC
Land boundaries:
hital: 1.2 km
horder country: Spain 1.2 km
Coastline: |2 km
Maritime claims:
territorial seas 3 wm
International disputes: sour,
between Spain and the UK
Of irictre''n
Climate: Medtterraman with mild winter
and warm summers
Terrain: a narrow coastal lowland bordes
the Rock of Gibraltar
lowest point: Mediterranean Sea 0
hrivhe / pom Rock ot Gibraltar 426 n
Natural resources: NEG!
Land use:
arable land: 0%
permanent crops {)*
meadows and pastures 0
forest and woodland:
other, 1\\OO0G
Irrigated land: NA sy km
Location: Southern Afnca. croup of islands
in the Indian Ocean. northwest of','a435e3861d5e0e6ed56220510e54a7ee2c5823358b464441aeb96eff45467845','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('225ef904b7c4a557bccb310aad990ed01feede084ecbee17f42cf7df7e0e59c9',1996,'GR','Greece','geography',414,'Location: Northern North America. island
between the Arctic Ocean and the North
\\thantic Ocean + ortheast of Canada
Geographic coordinates: 72 00 N. 40 00 W
Map references: Arctic Region
Area:
fetal areas 2.175.600 sq km
land area, 383.600 sq kin (ce tree)
comparative area. slightly more than three
umes the size of Texas
Land boundaries: 0) km
Coastline: 44.087 km
Maritime claims:
exclusive fishing sone: 200 nm
rerruorial sea: 3am
International disputes: none
Climate: arctic to subarctic: cool summers.
cold winters
Terrain: flat to gradually sloping icecap
covers all but a narrow. mountainous, barren.
rocky Coast
lowest point. Atlantic Ocean 0 m
highest point: Gunnbjorn 3.700 m
Natural resources: zinc. lead. iron ore. coal.
molybdenum, cryolite, uranium, fish
Land use:
arable land: O%
permanent crops: O%
meadows and pastures: 1%
forest and woodland. O%
other: 99%
Irrigated land: {) sy km
Geographic coordinates: 4) 50 \\. 20 00}
Map references: Europ.
Area:
total area. 25.333 sg km
land area: 24.856 sq km
comparative area. slightly larger than
Vermont
Land boundaries:
total: 748 km
border countries: Albama 15) km. Bulgar
148 km. Greece 228 km. Serbia and
Montenegro 221 km (all with Serbia)
Coastline: 0 km (landlocked)
Maritime claims: none (andlocked)
International disputes: dispute with Greece
over name. in September 1995. Skopje and
Athens signed an interim accord resolving
their dispute over symbols and certain
constitutional provisions: Athens also lifted
its economic embargo on the Forme:
Yugoslav Republic of Macedonia
Climate: hot. dry summers and autumns ai
relatively cold winters with heavy snow
Terrain: mountainous territory covered
deep basins and valleys: there are three large
lakes. each divided by a frontier tine
country bisected by the Vardar River
lowest point: Vardar River SO m
highest point: Korab 2.753 m
Natural resources: chronuum. lead. 7in
Manganese, tungsten. nickel. low-grade tro
ore. asbestos, sulfur, timber
Land use:
arable land: 5%
pernianent crops: S%
mec dows and pastures: 20%
289
Macedonia, The Former
Yugoslay Republic of
*. '' j
OMT
=. » A >
Irrigated land: \\.\\ sg km
bnvironment
Ste TISKS
party to—-Law of
ty Lim
feographie note: locked. major
‘trom Western and
\\evean Sea and Southern
\\ | Y','4b85594f7039e23408912532b578fcb7b109445e924380b63fd1db1562ffdab6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('524110f74a38e88a3d3399bca5eb5ac4124fb63cef024f5a38e3eec3dc51b55b',1996,'GD','Grenada','geography',416,'Location: Canbbean. island in the Caribbean
Sea, north of Trinidad and Tobago
Geographic coordinates: |2 07 N. 61 40 W
Map references: Central America and the
Canbbean
Area:
total area: 340 sg km
land area: 340 sq km
comparative area: twice the size of
Washington, DC
Land boundaries: 0) km
Coastline: 121 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical: tempered by northeast
trade winds
Terrain: volcanic in origin with central
mountains
lowest point: Caribbean Sea 0 m
highest point: Mount Saint Catherine 840 m
Natural resources: tiniber. tropical fruit,
deepwater harbors
Land use:
arable land: 15%
permanent crops: 269
meadows and pastures: 3%
forest and woodland: 9%
other: 47%
irrigated land: NA sy km
Location: Canbbean, islands in the eastern
Caribbean Sea. southeast of Puerto Rico
Geographic coordinates: 16 15 N. 61 35 W
Map references: Central America and the
Caribbean
Area:
total area: 1.780 Sg km
land area: 1.706 sq km
comparative area: 1O times the size of
Washington, De
note: Guadeloupe ts an archipelago of nine
inhabited islands. of which Basse-Terre.
Grande-Terre. and Marie-Galante are the
three larvest
Land ooundaries: 0 kin
Coastline: 306 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: subtropical tempered by trade
winds: moderately high humidity
Terrain: Basse-Terre is volcanic in origin
with interior mountains: Grand- Terre ts low
limestone formation: most of the seven other
islands are volcanic in origin
lowest point: Canbbean Sea 0 m
highest point: Soutriere 1.467 m
Natural resources: cultivable land. beaches
and climate that foster tourism
Land use:
arable land: VW8%
permanent crops: S%
meadows and pastures: 13%
forest and woodland: 40%
other: 249%
Irrigated land: 30 sq km (1989 est.)','444bfb22b0dd5c4a8f44a70c0660a12d5e09f3034ebceb3e8c9c60ad575657db','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7c8131de49ee8435ad88d3abaf9babda9866556f1890cecc39d085f85c87c76',1996,'GP','Guadeloupe','geography',424,'Location: Oceania, island in the North
Pacific Ocean, about three-quarters of the
way from Hawat to the Philippines
Geographic coordinates: |3 28 N. 144 47
E
Map references: Oceania
Area:
total area: 541.3 sq km
land area: 541.3 sq km
comparative area: three times the size of
Washington, DC
Land boundaries: () km
Coastline: 125.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical marine: generally warm
and humid, moderated by northeast trade
winds: dry season from January to June,
rainy season from July to December; little
seasonal temperature variation
Terrain: volcanic origin, surrounded by
coral reets: relatively flat coralline lime tone
plateau (source of most fresh water) with
Steep coastal CHIPS aid arrow coastal plans
in north, low-rising hills in center, mountains
in south
lowest pou Pacific Ocean 0 m
highest point; Mount Lamlam 406 m
Natural resources: fishing (largely
undeveloped). tourism (especially from
Japan)
Land use:
arable land (VG
permanent crops: 1%
meadows and pastures: i5%
forest and woodland: (8%
other: 48%
irrigated land: NA sg km','a767f25705e544dbece1ea97c92338283c2f3dbced974d4732789e359afa7226','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4bf33f268756cd968546681eaf0af8a0d545b741c523a377d3b02a1e4f0babc',1996,'GT','Guatemala','geography',428,'Location: Middle America. bordering the
Canbbean Sea. between Honduras and Belize
and bordering the North Pacific Ocean.
between El Salvador and Mexico
Geographic coordinates: 15 30 N. 90 15 W
Map references: Central America and the
Canbbean
Area:
total area: VO8.890 sq km
108.430 sq km
comparative area, siightly smaller than
land are
Tennessee
Land boundaries:
total: 1.687 km
horder countries: Belize 266 km. El
Salvador 203 km. Honduras 256 km. Mexico
962 km
Coastline: 400 km
Maritime claims:
continental shelf: 200-m depth or to the
depth of exploitation
exclusive economic zone: 200 nie
territorial seas 12 am
International disputes: border with Belize
in dispute: talks to resolve the dispute are
Stalled
Climate: tropical: hot. humid in lowlands:
cooler in highlands
Terrain: mostly mountains with narrow
coastal plains and rolling limestone plateau
(Peten)
lowest point: Pacitic Occan 0 m
highest point: Volcan Tayumuleo 4.211 m
Natural resources: petroleum. nickel. rare
woods, fish. chicle
Land use:
arable land 12%
permanent crops: 4%
meadows and pastures: 12‘
t
forest and woodland: 40%
other: 32%
Irrigated land: 780 sq km (1989 est.)','8a45dabcb31143ccfadca9e325e6c4403a734e43d9be0fae97e877caecfaa7d5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b9c96b2b3dc92ae965275dfec089d280e6ded235a9de95b65de4d34fa4ab4c1',1996,'GG','Guernsey','geography',434,'Location: Western Europe. islands in the
English C Sannel. northwest of France
Geographic coordinates: 49 28 N. 2 35 W
Map references: Europe
Area:
total area, 194 sq km
lund area: 194 sq km
comparative area: slightly larger than
Washington, DC
note. includes Alderney. Guernsey. Herm.
Sark. and some other smaller islands
Land boundaries: () km
Coastline: 50 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 3 am
International disputes: none
Climate: temperate with mild winters and
cool summers, about 50 of days are
overcast
Terrain: mostly level with low hills in
southwest
lowest point: Atlantic Ocean 0 m
highest point: unnamed location on Sark 114
m
Natural resources: cropland
Land use:
arable land: NAG
permanent crops: NAG
meadows and pastures: NAG%
forest and woodland: NAG
other: NAG
Irrigated land: NA sq km
Location: We tern Atnca. bordenng the
a Kanth Ocean. between Guinea
id Srerra Leone
Ceographic coordinates: |) OO \\. 1OO0O W
Map references: Alrica
Area:
3S SOO) sg km
hay r IS 860 so km
ompul ¢ urea. stightly smaller than
(yy
Land boundarivs:
+ 499 i
ruler « ¢ ’ Cstuiim Biss. j 386 km
Cote d bore 610 km. Libers 463 km. Mah
ASS h Sen ,Wi km. Seerra Leone 682
ht
(Coastline: 620 ky
Viaritime claims:
‘ ” ~H) np
Pig ‘i
International disputes: nm
Climate: cenerally bot and bund
rrr i-ivpe ramy « n (June t
Novemb ty thy ry \\, cl iry
1) 1} r te Mia h
it \\ harmattan wind
lerrain: cenerally flat coastal plain. hilly to
i! T} j rite
foo’: Athunti Ocean O m
bro " t Mont Numba 1.752 m
Natural resources: bauste. ron ore
fold. urantum, hydropower, tish
Land use:
er. 40)
Irrigated fond: 240 sg km (1989 est)
20)
Location: Western Africa. bordering the
North Adantic Ocean. between Guinea and
Geographic coordinates: |2.00 N15 00 W
Map references: Africa
\\rea:
hota! a 46.120 sq km
"SOOO sy km
omparative area” slightly less than three
times the size of Connecticut
Land boundaries:
ol thn
per) mises. Guinea 386 km, Senegal
t2e Ly
Coastline: 350 km
Nlaritime claims:
ne: 200 nm
International disputes: none
Climate -enerally hot and humid:
“ny season (June to
ithwesterly winds: dry
ber to May) with
miattun winds
ram ti A astal plain rising to
\\thantie Ocean O m
{ focation in the
try, 400 m
Natural resources: phosp! haute,
¥troleum. tish.
Land use
Irrigated ''and: \\.A sq kn
202','e913fce3895bb46868642bb6542be1c60780cc74a0c667e25687e02f636193d9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('957f09b9ee88dd89a3e203f244493d0535985273c37ca51e7ec1616208915171',1996,'HT','Haiti','geography',446,'Location: Canbbean. western one-third of
the island of Hispaniola, between the
Caribbean Sea and the North Atlantic Ocean.
west of the Dominican Republic
Geographic coordinates: }9 00 No 72 25 W
Map references: Central Amerca and the
Canbbean
Area:
total areas 27.730 sq kin
land area 27. S60 SY km
comparative area. Sightly larger than
Mar \\ land
Land boundaries:
~
total: 275 km
border country: Domimean Repubhe 275 km
Coastline: |.77) kn
Maritime claims:
newous cone. 24 nm
lepth of exploitation
lusive econon one: 200 nm
territorial ved Vonm
International disputes: claims US
administered Navassa Island
Climate: tropical. semiarid where mountains
mo east cut off trade winds
Ferrain: mostly rough and mountainous
lowest point: Canbbean Sea 0 m
highest point. Chane de la Selle 2.680 m
Natural resources: bauxite
Land use:
arable land 20%
permanent crops: Wa
meadows and pastures: WS“
forest and woodland: 4%
other: 450
Irrigated land: 750 sq km (1989 est.)
Location: Southern Africa. islands in the
Indian Ocean, about two-thirds of the way
trom Madagascar to Antarctica
Geographic coordinates: 53.06 S.72 31 E
Map references: Antarctic Region
\\rea:
total area: 412 sq km
land area: 412 sq km
comparative area 1.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 101.9 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 am
International disputes: none
Climate: antarctic
Terrain: Heard Island—bleak and
mountainous, with a quiescent volcano:
McDonald Islands—small and rocky
lowest point: indian Ocean 0 m
highest point: Big Ben 2.745 m
Natural resources: none
Land use:
arable land: O%
permanent crops: O%
meadows and pastures; 0%
forest and woodland: 0%
other: LONG
Irrigated land: 0 sg km','56469a34196aa91d7b7c18158395b31840766355fdee6a86f2523ce60cd58ec8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6c0ec41cfc8d21259f3a459bc8b773f17b016c0cd05329e208903dcfe7943b9',1996,'IT','Italy','geography',453,'~
-
-—-
Location: Southern Europe. an enclave
Rome (Italy)
Geographic coordinates: 4) 54 N. 12 27 E
Map references: Europe
Area:
otal area: 0.44 sq km
land area: 0.44 sq km
comparative area: about 0.7 times the size
of The Mall in Washington, DC
Land boundaries:
total: 3.2 km
border country: Waly 3.2 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: temperate, mild. rainy winters
(September to mid-May) with hot, dry
summers (May to September)
Terrain: low hill
lowest point: unnamed location 19 m
highest point: unnamed location 75 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: O%
meadows and pastures: O%
forest and woodland: O%
other: (OO%G
Irrigated land: sg km','58048130386dc045675d42757a3e82d46d34c0a6a061f6b92b8b020c758068c5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a6230ec4f6712883336e911790b969f47110830a15091646523cc9906e5d466',1996,'HK','Hong Kong','geography',459,'Location: Eastern Asia, bordering the South
China Sea and China
Geographic coordinates: 22 15 N. 114 10
2
Map references: Southeast Asia
Area:
total area: 1040 sg km
land area: 990 sq km
comparative area: six times the size of
Washington, DC
Land boundaries:
total: 30 km
horder country: China 30 km
Coastline: 733 km
Maritime claims:
territorial sea: 3 nm
International disputes: none
Climate: tropical monsoon, cool and humid
in winter, hot and rainy from spring through
summer, warm and sunny tn tall
Terrain: hitly to mountainous with steep
slopes: lowlands in north
lowest point: South China Sea 0 m
highest point: Tai Mo Shan 958 m
Natural resources: outstanding deepwater
harbor, feldspar
Land use:
arable land: 7%
permanent crops: VG
meadows and pastures: 1%
forest and woodland: 124
other: 19%
Irrigated land: 20 sy km (1989)
Location: Oceania. island in the North
Pacific Ocean, about one-half of the way
from Hawai to Australia
Geographic coordinates: () 48 N. 176 38 W
Map references: Oceania
Area:
total area: 1.6 sq km
land area: 1.6 sq km
comparative area: about three times the size
of The Mail in Washington, DC
Land boundaries: () kin
Coastline: 6.4 km
Maritime claims:
exclusive economic cone: 200 nm
territorial sea: 12 1m
International disputes: none
Climate: equatorial: scant rainfall, constant
wind, burning sun
Terrain: low-lying. nearly level. sandy.
coral island surrounded by a narrow fringing
reel: depressed central area
lowest point: Pacitic Ocean 0 m
highest point: unnamed location 3 m
Natural resources: guano (deposits worked
until late TSO0s)
Land use:
arable land: 0%
permanent crops: O%
meadows and pastures: O%
forest and woodland: S%
other: 9S%
Irrigated land: (0) sq km
Location: Southeastern Europe. nor','b044004515a9c95d7227d8ba65a6586d2ed0f7b2fbf81555e51e80984d9704cb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d29a862456e2ddf1964d10de34d7dedefc9e7dcae0c67b2d42acc2672b823a41',1996,'RO','Romania','geography',464,'Geographic coordinates: 47 00 N, 20 00 E
Map references: Europe
\\rea:
iotal area: 93.030 sq km
land area: 92.340 sq km
comparative area. slightly smaller than
Indiana
Land boundaries:
total: 2.009 km
border countries: Austria 366 km. Croatia
329 km, Romania 442 km. Serbia and
Montenegro 15] km (all with Serbia).
Slovakia 515 km. Slovenia 102 km. Ukraine
103 km
Coastline: 0 kim (landlocked)
Maritime claims: none (landiocked)
International disputes: Gabcikovo Dam
dispute with Slovakia
Climate: temperate: cold. cloudy, humid
winters: Warm sunimers
Terrain: mostly Mai to rolling plains: hills
and low mountains on the Slovakian border
lowest pot: Tisza River 78 m
highest point. Kekes 1.014 m
Natural resources: bauxite. Coal. natural
gas, fertile sotls
Land use:
arable land: 51%
permanent crops: 6%
meadows and pastures: 13%
forest and woodland: (8%
other: 12%
Irrigated land: |.750 sy km (1989)
Location: Eastern Europe. northeast of
Geographic coordinates: 47 00 N. 29 00 F
Map references: Commonwealth ot
Independent States
Area:
total area: 33.700 sy km
33.700 sy km
comparative area: slightly more than twice
land arca
the size of Hawan
Land boundaries:
total: 1.389 km
horder countries
99 km
Coastline: 0 km Candlocked)
Maritime claims: none (landlocked)
International disputes: certain territory of
Moldova and Ukrarae—including Bessarabia
and Northern Bukovina
Bucharest as historically a part of Romania:
Romana 450 km. Ukraine
are considered by
this territory was incorporated into the
former Soviet Union following the Molotov-
Ribbentrop Pact in 1940
Climate: moderate winters. warm summers
Terrain: rolling steppe. graduai slope south
to Black Sea
lowest point: Nistru River 2 m
highest point: Mount Balaneshty 420 m
Natural resources: lignite. phosphortes.
gypsum
Land use:
arable land: 30%
permanent crops: (3%
meadows and pastures: 9%
forest and woodland: O%
other: IS%
Irrigated land: 2.920 sy km (1990)
Location: Southeastern Europe. bordering
the Black Sea. between Bulgaria and Ukraine
Geographic coordinates: 46 00 N. 25 00 EF
Map references: Europe
\\rea:
total areas 237. 500 sq km
230.340 sq km
comparative area’ sightly smaller than
land area
Oregon
Land boundaries:
total) 2.508 km
horder countries. Bulgaria 608 km, Hungary
443 km. Moldova 450 km. Serbia and
Montenegro 476 km (all with Serbia).
Ukraine (north) 362 km, Ukraine (south) 169
km
Coastline: 225 km
Maritime claims:
24 nm
continental shelf: 200-m depth or to the
depth of exploitation
CONNQUOUS TONE
exclusive economic zene: 200 nm
territorial seas 12 nm
International disputes: certain territory of
Moldova and Ukraine—including Bessarabia
and Northern Bukovina—are considered by
Bucharest as historically a part of Romania:
this territory was incorporated into the
former Soviet Union following the Molotov-
Ribbentrop Pact in 1940
Climate: temperate. cold, cloudy winters
with frequent snow and fog: sueny summers
with frequent showers and thunderstorms
Terrain: central Transylvanian Basin js
separated from the Plain of Moldavia on the
east by the Carpathian Mountains and
separated trom the Walachian Plain on the
south by the Transylvanian Alps
lowest point: Black Sea 0 m
HOS
highest point: Moldoveanu 2,544 m
Natural resources: petroleum (reserves
declining), timber, natural gas, coal, iron ore.
salt
Land use:
arable land: 43%
permanent crops: 3%
meadows and pastures: 19%
forest and woodland: 28%
other: 1%
Irrigated land: 34.500 sq km (1989 est.)','2da52bc097f0c136e710378d71149d1e72cbbdd5db619230ff676472e09f6323','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ea983d4d4110e26cd19659f79a821c103bd30fea057fff4eaf37412c3c8c78a',1996,'IN','India','geography',469,'Location: Southern Asia, bordering the
Arabian Sea and the Bay of Bengal. between
Burma and Pakistan
Geographic coordinates: 20 00 N. 77 OO E
Map references: Asia
Area:
total area: 3.287.589 sq km
land area: 2.973.190 sq km
comparative area: slightly mere than one-
third the size of the US
Land boundaries:
total: 14.103 km
border countries: Bangladesh 4.053 km,
Bhutan 605 km. Burma 1.463 km. China
3.380 km. Nepal 1.690 km. Pakistan 2.912
km
Coastiine: 7.000 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of
the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: boundaries with
Bangladesh and China in dispute: status of
Kashmir with Pakistan: water-share.¢
problems with downstream riparian.
Bangladesh over the Ganges and Pakisiwn
over the Indus (Wular Barrage)
Climate: varies from tropical monsoon in
south to temperate in north
Terrain: upland plain (Deccan Plateau) in
south, flat to rolling plain along the Ganges.
deserts in west. Himalayas in north
lowest point: Indian Ocean 0 m
highest point: Kanchenjunga 8.598 m
Natural resources: coal (fourth-larzest
reserves in the world), iron ore, manganese.
o8b7
mica, bauxite, titamum ore, chromic. natural
gas, diamonds, petroleum, !imestone
Land use:
arable land: 55%
permanent crops: \\%
meadows and pastures: 4%
forest and woodland: 23%
other: 17%
Irrigated land: 430.390 sq km (1989)
Location: body of wat
Antarctica, Asia. and At
C,eographic coordinates:
Map references: World
\\rea:
ala fod Hi
,? ii
ric’sS the | is
il ! Pac Th {)
but lurger than the A
j ‘ i k ‘ \\r ‘
Malacca. and other
€ oastline: 66.526 4
International disputes: .
disputes (see littoral stat
Climate: northeast '')
\\pril ithwe
Nias lun mad Gktol \\
northern Incl ()
im the souther ly {)
lerrain: sur
COUNTETECIOCAW
Ocean LP tague
the northern Indian ©
Pressure OVC ulfiw \\
TIsdPe. SUT GAT Te
monsoon and southw.
and currents, while high os
northern Asta trom cold
nomheast-t uthwest w
ocean tloor ims dominated
Ocean Ridge and subdry
Southeast Indian Ocean Ru
Indian Ocean Ridge. and Ny
lowes! powl lava Trench
highest! pont. sea les On
993
-—
Indian Ocean (continued)
Natural resources: oi! and gas fields. fish.
shrimp. sand and gravel aggregates. placer
leposits. polymetallic nodules','6626b662a8a8c4b21de00adb922e4ef4d1fb5677645f7c4518d1b9e7fb57ca07','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbed1209e93a64edb3b60be4360f827f9f32599944ab5b19ed729862985b1c42',1996,'ID','Indonesia','geography',475,'Location: Southeastern Asia. archipelago
between the Indian Ocean and the Pacific
Ocean
Gevgraphic coordinates: 5 00 S. 120 00.F
Mar references: Southeast Asia
Area:
total area: 1.919.440 sq km
land area. 1.826.440 sy km
comparative area: slightly less than three
times the size of Texas
Land boundaries:
total; 2.602 km
border countries: Malaysia 1.782 km. Papua
New Guinea 820 km
Coastline: 54.716 km
Maritime claims: measured trom cl umed
chipelagic baselines
erclusive economic zone, 200 nm
terriiorial sea: 12 am
International disputes: sovereignty over
Timor Timur (East Timor Province) disputed
with Portugal and not recognized by the UN:
two istands in dispute with Malaysia
Climate: tropical: hot, humid. more
moderate in highlands
Terrain: mostly coastal lowlands, larget
islands have interior mountains
lowest pomt: Indian Ocean O m
highest point: Puncak Jaya $.030 m
Natural resources: petroleum. tin. natural
gas. nickel. timber. bauxite. copper. fertile
soils, coal, gold silver
Land use:
arable land: 8%
f
permanent crops ey
ae kf
meadows and pastures (
forest and woodland: 67%
other: WG
Irrigated land: 75.500 sg km (1989 est.)
Location: Middle East. bordering the Gult
of Oman, the Persian Gull. and the Caspian
Sea. between Irag and Pakistan
Geographic coordinates: 32 00 N. 53 00.6
Map references: Middle East
Area.
total area: 1.648 million sq km
land area: 1.636 million sq km
comparative area: sightly larger than Alaska
Land boundaries:
total: $440 km
border countries: Atghamstan 936 km
Armenia 35 km. Azerbaiyjan-proper 432 km
\\verbanjan-Naxcivan exclave 179 km. Irag
1.458 km. Pakistan 909 km. Turkey 499 km
Turkmenistan 992 km
Coastline: 2.440 km
note. Iran also borders the Caspian Sea 0740
km)
Maritime claims:
contiguous cone: 24 0m
continental shelf: natural prolongation
craclusive economic cone. bilateral
agreements, or median lines in the Persian
Gull
territorial sea: 12 0m
International disputes: Trin and tray
restored diplomatic relations in 1990 but are
sull trying to work out written agreements
settling outstanding disputes from their enght
yea. War concerning border demarcation
prisoners-<t-war, and freedom of navigation
and sovereignty over the Shatt al-Arab
waterway. Iran occupies two islands in the
Persian Gult claimed by the CAE. Lesser
Tunb (called Tunb as Sughra ia Arabic by
UAE and Jazireh-ye Tonb-e Kuchek in
Persian by Iran) and Greater Tunb (called
Tunb al Kubra in Arabic by UAE and
Jazireh-ye Tonb-e Bozorg in Persian by
Iran). 1t jointly administers with the UAE an
island in the Persian Gulf claimed by the
UAE (called Abu Musa in Arabic by UAE
and Jazireh-ye Abu Musa in Persian by
Iran): in 1992 the dispute over Abu Musa
and the Tunb islands became more acute
when Iran unslateraliy tied to control the
entry of third country nationals into the UAE
portion of Abu Musa island. Tehran
subsequentiy backed off in the face of
significant diplomatic support for the UAE
in the region, but in 1994 i increased its
military presence on the disputed islands:
periodic disputes with Afghanistan over
Helmand water nghts: Caspian Sea
boundanes are not yet determined: support to
clients in Afghanistan
Climate: mostly and or semiand. subtropical
along Caspian coasi
derrain: rugged. mountainous mm: high
central basin with deserts, mountains: small.
discontinuous plains along both coasts
lowes! pou Caspian Sea -28 m
lighest point: Qoileh-ye Damavand 5.671 m
Natural resources: petroleum. natural gas
coal, chromium. copper. iron ore. lead
manganese, zinc. sulfur
Land use:
arable land: 8%
permanent crops: Ve
meadows and pastures
forest and woodland: VV
other: SAS
Irrigated land: $7,500 sy km (1989 est)
Location: Middle East hordering the Pers
Gult. between Iran and Kuwart
C,eographic coordinates: 44.00 \\. 44.001
Map references: Middle bast
Area:
otal area: 437.4172 sa ka
land areca’ 432.162 sq km
comparative arca: sightly more than tw
ihe size of Idaho
Land boundaries:
otal. AOAL km
horder counties: Iran 1458 hum. Jord
km. Kuwait 242 km. Saudi Arabia 814 ki
Syria O©OS km. Turkey 331 kn
Coastline: Ss kn
Maritime claims:
continental sheit: not Sper ited
“oriorial va |> ni
International disputes: bran and box
resiowes: diplomaire relations im 199
ull trvine to work out written acreemet
settling outmanding disputes trom theur «
vear War concermng border demart
Prisoners if-war, and treedom of nas
and soverengms over the Shatt al Ars
waterway. in November 1994, Irag tk
accepied the | N demar ted border w
Kuwart which had been spelled «
Security Counci! Resolutions 68 "
773 (1994), and 8R3(199%) th
ends carer claims to Kuwait a H
and Warbah islands. dispute over w
development plans by Turkey for the 7
and Euphrates Rivers
Climate’ mostly desert: nuld to cool went
with drv. wot. cloudless summers. north:
MOoUnTLAITONU | regions alon, lraman amd
i)
Turkish borders experience id winters with
occamoonally heavy snows which melt om
229
33
Irag (continued)
euriy spring. sometimes causing extensive
flooding in central and southern [rag
Terrain: mostly broad plains: reedy marshes
along iranian border in south: mountains
along borders with Iran and Turkey
lowest pow: Persian Gulf Om
highest point: Gundah Zhur 3.608 m
Natural resources: petroleum. natural gas.
phosphates. sulfur
Land use:
arable land
Permanent Crops- |
j
MCUdOWS Ghd Pauslitres }
fore Y dild woodland 4
one Ss!
Irrigated land: ~5.500 sy kim (1989 est)
Climate: tropical, annual southwest (Apmil to
October) and northeast (October to February )
Nanpower availability:
jv > 106.905
y mulitary senvice” LAVIG TSS
Ton soons
iain Terrain: coastal plains msing to hills and
Defense expenditures: exchange rate
, Mountains
oe $10.4 millon. NAG of GON lowest pot: Indian Ocean 0 m
Dial highest pot: Mount Kinabalu 4.100 m
Natural resources: tin. petroleum. timber
copper, iron ore. natural gas, bauxite
Land use:
arable land: 3%
permanent crops: \\O%
2%
meadows and pastures: W%
jorest and woodland: 63%
other: 240
Irrigated land: 3.420) sy km (1989 est)
Geographic coordinates: 6 00 S
Map references: Oceania
147 OOF
Area:
total area: 461.690 sg km
land area: 451.710 sq km
comparative area: sightly larger than
Calitormia
Land boundaries:
total; 820 km
border country: Indonesia 820 kin
Coastline: 5.152 kin
Maritime claims: measured trom clarmed
archipelagic baselines
continental shelf: 200-m depth or to the
depth of exploitation
exclusive fishing zone: 200 nm
territorial seas 12 nm
International disputes: none
Climate: tropical: northwest monsoo
(December to March). southeast monsoon
(May to October): slight seasonal
iemperature Variation
Terrain: mostly mountains wih coastal
lowlands and rolling foothills
lowest point: Pacific Ocean 0 m
highest point: Mount Wilhelm 4.509 1m
Natural resources: gold. copper. silver
natural gas, timber, oi) potential
Land use:
arable land: 0%
permanent crops: 1
meadows and pastures: 0%
forest and woodland: 71%
other: 28%
373
352
’apua New Guinea (continued)
irrigated land: NA sg km
invironment:
is. Tain foresl subject lo
as a result of growing
ercial demand tor tropical timoes
lullion irom mining proyects
Wal hazards: actwe volcanism: situated
ng the Pacific “"Rim of Fire’. the country
s subject to frequent and sometimes severe
wthguakes: mud slides
ml agreements Party th
Treaty Biodiversity Climate
inge. Endangered Species. Environmental
Modication. Marine Dumping. Nuclear Test
Ban. Ovene Laver Protection. Ship Pollutio..
lieber 83. Wetlands signed, but
i— Hazardous Wastes. Law of the
Sea. Tropical Timber 94
Geographic note: shares island of New
indonesia, one of world’s
long southwest coast
Telephones: 779.306 (1990 est.)
Telephone system: adequate for most
requirements
domestic: nationwide microwave radio relay
system and a domestic satellite system with
12 earth stations
international: satellite earth stations—2
Location: Southeastern Asia. archipelago
between the Philippine Sea and the South
China Sea, east of Vietnam
Geographic coordinates: 13 00 N. }22 00
}-
Map references: Southeast Asia
Intelsat (Atlantic Ocean) Area:
Radio broadcast stations: AM 273. FM 0. total area: 300.000 sq km
shortwave 144 land area: 298.170 sq km
Radios: 5.7 million (1992 est.) comparative area: slightly larger than
Television broadcast stations: | 40 Arizona
Televisions: 2 million (1993 est.) Land boundaries: () km
Coastline: 36.289 km
_ : —_— : Maritime claims: measured from claimed
archipelagic baselines
one continental shelf: to depth ot exploitation
Branches: Army (Ejercito Peruano), Navy exclusive economic cone: 200 am
(Marina de Guerra del Peru; includes Naval territorial sea: wregular polygon extending
Air. Marines. and Coast Guard), Air Force up to 100 nm from coastline as detined by
(Fuerza Aerea del Peru), National Police 1898 treaty: since late 1970s has also
381
Philippines (continued)
poly gonal-shaped area in South
hina Sea up to 285 nm in breadth
international disputes: involved in a
ite over the Spratly Islands
China. Malaysia. Tarwan, Vietnam. and
ner: clams Malaysian sta of
( imate: tropical marine: northeast monsoon
Non ve \\pril). southwest monsoon
\\ Octeb
berrain: mountains with narrow to
Philippine Sea 0 m
Mount Apo 2.954 m
‘ t
Natural resources: timber. petroleum.
Rel. CODA. silver, gold. salt Coppel
land use:
vy
a ,
fie +
i
Irrigated land: 16.200 sq km (1989 est)
Location: Southeastern Asia. islands
between Malaysia and Indonesia
Geographic coordinates: | 22 N. 103 48 E
Map references: Southeast Asia
Area:
total area: 632.6 sq km
land area: 622.6 sq km
comparative area: slightly more than three
times the size of Washington, DC
Land boundaries: (0) km
Coastline: 193 km
Maritime claims:
exclusive fishing zone, within and beyond
territorial sea, as defined in treaties and
practice
territorial sea: 3 nm
International disputes: two islands in
dispute with Malaysia
Climate: tropical: hot, humid, rainy: no
pronounced rainy or dry seasons,
thunderstorms occur on 40% of all days
(67% of days in April)
Terrain: lowland: gently undulating central
plateau contains water catchment area and
nature preserve
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 166 m
Natural resources: fish. deepwater ports
Land use:
arable land: 4%
permanent crops: 7%
meadows and pastures: O%
forest and woodland: 8%
other: 84%
Irrigated land: NA sg km','4cabfa63ea0a7d015811f6fe4ac9a7116358b0e0fd6ba8560d2db8a36b05ae2c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d7de4cee8fc605385862d8e1dd1ac3105b350e8fbe47fa8140a19ed0f0b3b67',1996,'IE','Ireland','geography',482,'Location: \\W rm kurope. occupy
| dl N
on Worst Cy il Rritan
(,eographic coordinates: 53.00 Nos 00 \\W
Niap references: buroy
Area:
0.280 sg kn
fy~ wh) | kh
Coa sighth larger than West
\\
Land boundaries:
'' IK imi}
(Coastline:
\\laritime claims:
LK. Roch
1) irk re nil
(Kil lthe UK \\ “
| Rockall at )
Climate: te martime. moditied by
North A ( t. mud Wintel Cen
'' '' \\ in ! ih ul
lerrain: to rolling imteror
! | ! } i! dl WA
{ { ist
\\thantic Qeean O m
Caurrauntoohill! 104) m
Natural resources: sinc. lead. natural gas
tr in. barit opper. gv psum
mmeston lolomite. peat. silver
Land use:
; ; ; {}
Liki j ire 7
iv
-
tw
forest and woodland: \\%
other, (OG
Irrigated land: NA sg km','f7f2e39e0e1dfae058153ce483bfabc3ef38a218a71e0abfacb672d42c4069c3','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f6bdf3ce853809fb2c8e6bda9bbb32a5ab63a614c3a260b17dc1c5a082534bd',1996,'LB','Lebanon','geography',487,'Geographic coordinates: 3) 30 N. 34 45 &
Map references: Middle East
Area:
total area: 20,770 sq km
land area: *0.330 sq km
comparative area: slightl, larger chan New','4be25e6f9ddd24ede1a2f39c674c0129d4e54d1372ae44e121f5a5d55683b256','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1bf5cf3c8d3bc7513c2bed95509af010477717bbfaee2d971576145540c4166',1996,'JM','Jamaica','geography',492,'Lo ‘Aion: Canbbean. isiand in the Canbbean
Sea. south of Cuba
Ceographic coordinates: |8 1S \\. 77 30 W
Map references: Central Amenca and the
Canbbean
\\rea:
tital area: 10.990 sq km
land area: \\O.830 sg km
comparative area. sightly smaller than
C onnecticul
Land boundaries: 0 kin
Coastline: |.022 km
Maritime claims:
continental shelf: 200-m depth or to the
depth of exploration
eraclusive economic cone. 200 am
territorial sea. 12 am
International disputes: none
Climate: tropical: hot. humid: temperate
inter
Terrain: mostly mountains with narrow
discontinuous coastal plam
Loavest pout: Caribbean Sea 0 m
vhest point: Blue Mountain Peak 2.256 m
Natural resources: bauxite. gypsum
hry
himestone
Land use:
arate iand i
je rmanan vey fy",
lauds } dine hanes s
herw sl i wy dia x‘
cited ”)
Irrigated land: $50 so km (1989 est)','839e2a6b5386b9dfb12c2f44a21ec6272fd96b4b09828627a4efed074fbd6aba','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4ad18c224f36d19b65afc592bcb07ce751255321d50e71d4e2c35c86857f0bd',1996,'JP','Japan','geography',497,'Location: Eastern Asia. island chain
between the North Pacific Ocean and the Sea
om Japan. east of the Korean Peninsula
C,eographic coordinates: 6) 00 N_ 14s 00
I
Slap references: Asia
\\rea:
area. 377 835 sq km
and area: 374.744 sq km
omparative area. stvehtl smaller than
( ahtorm
© meludes Bonm Islands (Ogasawara
nie). Darto-shote. Maenami-pma. Okimoton
stoma. Ryukyu Islands (Nansei-shoto), and
Volcano Islands (Kazan-retto)
Land boundaries: () kin
Coastline: 29.75!) km
Maritime claims:
‘ sie fisinne “one 0) am
wrnitonal sea’ |2 am. 4 nm on the
micrnational strats La Perouse of Sova
leucaru. Osunn. and Eastern and Western
Channels of the Korea of Tsushima Strant
International disputes: islands of Btorotu
Kunashin. Shikotan. and the Haboma: en up
scuped by the Sovict Lnnon m 1945. now
Kninnamtered hy Russi i clammed hy jap in
Liancourt Rocks di puted with South Korea
Senkaku-shoto (Senkaku Islands) clanmed by
China and Taman
Climate: vanes from t mcal im south |
i temperate m north
lerrain: mostly rugged and mountarmnou
c.l pow Hachiro-cata sm
hivhest pom. tunvama 3.776 n
Natural resources: neglicrblc auneral
rOMMITCS fish
Land use:
reiniac te ; 4
yr rae nl rops |‘
meadows and pastures: VG
forest and woodland: 6749
other 1k
Irrigated land: 28.680 sy km (1989)
Location: Oceania. island in the South
Pacific Ocean. about one-half of the way
from Hawan to the Cook Islands
Geographic coordinates: () 22S. 160.03 W
Map references: Oceania
Area:
wtal area: 4.5 SY km
land area: 4.5 sq km
COMPAaTane areca about eight times the size
of The Mall in Washington, UC
Land boundaries: 0 kin
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: nonc
Climate: tropical: scant raintall, constant
wind. burning sun
Terrain: sandy. coral island surrounded by a
narrow fringing reel
lowest point: Pacitic Ocean 0 m
highest point: unnamed location 23 m
Natural resources: guano (deposits worked
until late TSO0s)
Land use:
arable land: 0%
permanent crops: O%
meadows and pastures: 0%
forest and woodland: 0%
other: 1OOG
Irrigated land: 0) sy km
Location: Southern Africa. island in the
South Atlantic Ocean. west of Angola. about
two-thirds of the way trom South Amenca to
Atrnca
Ceographic coordinates: |S 565.5 42
Map references: Atrica
Area:
total area: 410 sq km
land area: 410 sq km
comparative area: neatly two times the size
of Washington. DC
note; includes Ascension. Gough Island
Inaccessible Island. Nightingale Island. and
Tristan da Cunha
Land boundaries: () km
Coastline: 60 km
Maritime claims:
exclusive fishing cone: 200 nm
territorial sea: 12 am
international disputes: none
Climate: tropical: marine. mild. tempered by
trade winds
Terrain: rugged. volcanic: small scattered
plateaus and plains
lowest point: Atlantic Ocean 0 m
highest point: Queen Mary''s Peak 2.060 m
Natural resources: fish
Land use:
arable land: 7%
permanent crops: O%
meadows and pastures
forest and woodland: 3%
other: 83%
Irrigated land: NA sq km','96393f4bc2c41181309a255c7723843572b02b3aa67a2c38100e8f753258ae7f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21c9fd0c5dc824632d1eb89e81d9d47c4cc9acffee3fb92e6419044023dd898a',1996,'JO','Jordan','geography',501,'Location: Middle East. northwest of Saudi
\\rabia
(:eographic coordinates: 3) 00 N. 36 00 |
Mi p references: Middle East
\\rea:
al area. 89.213 sq km
and areca: SS.S884 sq kn
nparative area” Shehtl smaller than
Land boundaries:
H19 km
Irag IST km. Israel 238
kim. Saudi Arabha 728 km. Svria 375 km
West Bunk 97 km
Coastline: 26 km
\\laritime claims:
errutorial sea. 3am
International disputes: non
Climate: mostly and desert: rainy season in
west (November to April)
Ferrain: mostly desert platesu in east
highland area in west. Great Raitt Valles
eparates East and West Banks of the Jordan
mes poml Dead Sea -408 m
livhest point: Jabal Ram 1.754 m
‘Natural resources: phosphates. potash. shale
i
Land use:
aranis land |
menrmnanent crops, OS
/ /
meacows and Pastures
forest and woodland: OS
other: 94
Irrigated land: 570 sy km (1989 est)
Location: Southern Atrica. island in the
Defense Mozambique Channel. about one-third ef the
wa’ between Madagascar and Mozambique
Ceeographic coordinates: |7 03S. 42 45 1
] k / rda 1.t] | a } na 4 ) il
Map references: Atrica
\\ i\\ | a R | Jon i! i
— ‘” \\ Area:
TEE Nlioistry of th nicrior < Publ ,;
} ‘ ‘ | Ik Pu tr rotal area j } sg km
7 ‘ Tis ty . rey lore 4 LW
YeCUl ''\\ be -_ _ ECTReN f 1At nl '' hdlldd adicd } } sq kim
ITM OF CLISTS SITUATIONS comparative area. about seven times the sizc
Manpower availability: of The Mall in Washiagton. D6
males ave 15-49° LALLSSS8 Land boundaries: 0 km
( ry ry service >) 400 Coastline: 24.) km
eacl a © (18) annuall Maritime claims:
Ss
1S Jy QOH et) CONTIQMOUS OME |. nim
Defense expenditures: exchange rate continental shelf: 200-m depth or wo depth
version—_8$89 millon. 82% of GDP the of exploitation
sane cuclusive CCOnNONTK ie 200 nim
rerrioril sea: 12 am
International disputes: ¢ aimed by','5c6ffc07092ae5b3c6f6e19f771f4458c098c3689142ba808ac2529097ced94e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('daa486ab31607d29f7d2bac7ead523eaf5be145a14538c487e483b07cb4e4169',1996,'KW','Kuwait','geography',507,'Location: \\
(
C,eog! aphic coordinates
\\lap references
\\rea:
Land boundaries
( ousthline
Nlaritime claim
international disput
( timats
ferrain
\\ Lath i resenirces
mcd use
Kuwait (continued) Ethnic divisions: Kuwaiti 45°¢. other Arab National Assembly (Majlis al-umma): elected
3S“, South Asian 9°, Iranian 4, other 7 members serve four-year terms: elections last
Religions: Muslim 85 (Shi''a 30%. Sunni held 5 October 1992 (next to be held NA
$5%c. other 10 Christian. Hindu, Pars September 1996), results—percent of vote
Irrigated land:
Pnvironment: ; : 5
other 15 NA, seats - (SO total) independents VO
Languages: Arabic (official). English widely note—all cabinet ministers are also ex
poken officio members of the National Assembly
Literacy: agc and over can read and judicial branch: Hizh Court of Appeal
Political parties and leaders: none
Other political or pressure groups: several
political groups act as de facto parties
Bedouins, merchants, Sunni and Shi''a
activists. and secular leftists and nationalists
International organization participation:
ABEDA, AIDB. AFESD. AL, AMI
(,overnment BDEAC, CAEU. CCC, ESCWA, FAO. G
GCC. IAEA, IBRD. ICAO, ICC, ICRM
IDA. IDB. IFAD. IFC. IFRCS, ILO, IMI
IMO. Inmarsat. Intelsat. Interpol, LOC, ISO
correspondent), ITU. NAM. OAPEC,. Ol
OPEC, UN. UNCTAD, UNESCO, UNIDO
UPL, WETU. WHO. WMO. WT0O, WTrO
Diplomatic representation in US:
chief of mission. Amba
MUHAMMAD ba
SABAH
Name of country:
State of Kuwart
4 \\/ are
Data code: Kk!
ype of government: non
Capital: Kuw
\\drunistrative divisions: 5
i if Pilabbadls i " 5
\\l J
MMOS
) (20))) 966-0702
Location: Southeastern Asia. northeast of
Ihaland
Geographic coordinates: |S 00 .N. 10S 00
I
Map references: Southeast Asia
\\rea:
avea 46.800 sg km
l arca 30.800 sg km
whtly larger than Utah
peor ryil ‘ rr
land boundaries:
\\ "
‘ ’ a
( oastline: 0 | locked
Varitime claims: Hoch
International disputes: |
|
( imate
\\1 \\ 1)
\\
Natural resources
land use
Irrivat od lar c SS xg |b No
I nvironment
268
mernational agreemenis: patty to-
Environmental Modification, Nuclear Test
Ban. signed, but not ratrfied—Clhmate
Change. Desertification, Law of the Sea
Geographic note: landlocked','582cc78e88da0b644e9dad5aa59766ee47643a3c437806e94c927748cf7fcebc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9f8da0759f6abe2ef1eb09d4a1973a133b3b0856ca18f345ebe03c7ad69972a',1996,'LV','Latvia','geography',515,'Location: Middle East. bordering the
Mediterranean Sea. between Israel and Syria
Geographic coordinates: 33 50 N, 35 50 &
Map references: Middle East
Area:
tote! area: 10400 sq km
land area: 10.230 sq km
AS /
comparative area: about 0.8 times the size
of Connecticut
Land boundaries:
total: 454 km
border countries: Israel 79 km. Syria 375
km
Coastline: 225 km
Maritime claims:
terriiorial sea: 12 nm
International disputes: [sacl troops in
southern Lebanon since June 1982: Synan
troops in northern. central, and eastern
Lebanon since October 1976
Climate: Mediterranean: mild to cool, wet
Winters with hot. dry summers: Lebanon
mountains experience heavy winter snows
Terrain: narrow coastal plain: Al Biga’
(Bekaa Valley) separates Lebanon and Anti-
Lebanon Mountains
lowesi poini: Mediterranean Sea 0 m
highest point: Jabal al Makmal 3.087 m
Natural resources: limestone. iron ore. salt,
Water-surplus state in a Water-deticit region
Land use:
arable land: 21%
permanent crops: 9%
meadows and pastures: V%
forest and woodland. &%
other. 01%
Irrigated land: 860 sy km (1990 est.)
Location: Eastern Europe. bordering the
Baitic Sea. bx tween Latvia and Russia
Ceographic coordinates: 56 00. 24 00 E
Map references: Europe
Area:
total area: 65.200 sq km
land area: 65.200 sq km
comparative area’ sightly larger than West
Virgima
Land boundaries:
total: A273 km
border countries: Belarus S02 km. Latvia
453 km. Poland 91 km. Russia (Kaliningrad)
227 km
Coastline: }08 km
Maritime claims:
territorial sea: 12 am
International disputes: dispute with Russia
(Kaliningrad Oblast) over the position of the
Nemunas (Nemen) River border presently
located on the Lithuanian bank and not in
mdniver as bv international standards
a sputes maritime border with Latvia
iprimary concer ts oil exploration mghts)
treaty with Belarus defining the border
awaits ratification
Climate: maritime. wet. moderate winters
and summers
Terrain: lowland. many scattered small
lakes. fertile soul
lowest point: Baltwe Sea 0 m
highest point: Juozapine Kainas 292 m
Natural resources: peat
Land use:
arable land: 49%
permanent crops: O%
meadows and pastures: 22%
forest and woodland: \\6%
other ASG
irrigated land: 44) ~ km | 194','90ead2f60690b6e97377b8cba780f3ded8766e110685395b80c93dbc637887da','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c11cd3a9025c1ce34cf57e8bb2a776ae5d78472ce2ec0cbbc7daa1789a819269',1996,'ZA','South Africa','geography',521,'Location: Southern Africa, an enclave of
Geographic coordinates: 29 30 S. 28 30 E
Map references: Airica
Area:
tuial area: 30.350 sq km
land arca: 30.350 sq km
comparative area: slightly larger than
Maryland
Land boundaries:
total: 909 km
border country: South Atrica 909 kin
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: temperate: cool to cold. dry
winters: hot, wet summers
Terrain: mostly highland with plateaus.
hills, and mountains
lowest point: yanction of the Orange and
Makhaleng Rivers 1.400 m
highest pot: Mount Thabana Nilenyana
3.482 m
Natural resources: water. agricultural and
grazing land, some diamonds and other
minerals
Land use:
arable land: \\O%
permanent crops: O%
meadows and pastures: 66%
forest and woodland: 0%
other: 24%
Irrigated land: NA sg km
Location: Western Africa, bordenng the
North Atlantic Ocean. between Cote d''Ivoire
and Sierra Leone
Geographic coordinates: 6 30. N.9 30 W
Map references: Africa
Area:
total area: WVAB70 sq km
land area: 96.320 sq km
comparative area: slightly larger than
Tennessee
Land boundaries:
total: 1.585 km
horder countries: Guinea 563 km, Cote
d''Ivoire 716 km, Sterra Leone 306 km
Coastline: 579 km
Maritime claims:
territorial sea: 200 am
International disputes: none
Climate: tropical: hot. humid: dry winters
with hot days and cool to cold nights: wet.
cloudy summers with fiequent heavy
showers
Terrain: mosily flat to rolling coastal plains
nsing to rolling plateau and iow mountains
in northeast
lowest point: Atlantic Ocean & m
highest point: Mount Wuteve !.380 m
Natural resources: tron ore. Umber.
diamonds, gold
Land use:
arable land: V
‘
permanent crops: 3%
meddows and pastures: 2%
forest and woodland: 39%
other: 35%
Irrigated land: 20) sg km (1989 est.)
Location: Southern Africa. at the southern
tip of the continent of Africa
Geographic coordinates: 29 00 S. 24 00 E
Map references: Africa
Area:
total area: 1.219.912 sq km
land area: 1.219.912 sq km
comparative area: slightly less than twice
the size of Texas
note: weoludes Prince Edward Islands
(Marion Island and Prince Edward Island)
Land boundaries:
total: 4.750 km
border countries: Botswana 1.840 km.
Lesotho 909 km. Mozambique 491 km
Namibia 855 km. Swaziland 430 km.
Zinbabwe 225 km
Coastline: 2.798 km
Maritime claims:
continental shelf; 200-m depth or to the
depth of exploitation
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: Swaziland has asked
South Africa to open negotiations on
reimcorporating some nearby South African
lernitones that are populated by ethnic
Swazis or that were long ago part of the
Swazi Kingdom
Climate: mostly semiarid: subtropical along
east coast: sunny days. cool nights
Terrain: vast interior plateau rimmed by
rugged hills and narrow coastal plain
lowest poml Atlantic Ocean 0 m
highest point: Nyesuthi 3.408 m
Natural resources: gold, chromium
antimony, coal, ifon ore, manganese. nickel
phosphates. tin, uranium, gem diamonds
platinum, copper, vanadium, salt, natural gas
Land use:
arable land: \\O%
permanent crops ie
meadows and pastures: 65''
forest and woodland: 3%
other: IAG
Irrigated land: | 1.280 sy km (1989 <
Location: Southern South America, islands
in the South Atiantice Ocean, cast of the tip
of South America
Geographic coordinates: 54 30S. 37 00 W
Map references: Antarctic Region
Area:
total area, 4.066 sq km
land area: 4.066 sq kin
comparative area. slightly larger than Rhode
Island
note. mcludes Shag Rocks. Clerke Rock:
Bird Island
Land boundaries: () km
Coastline: NA km
Maritime claims:
exclusive fishing cone: 200 0m
territorial sea: 12 nm
International disputes: administered by the
UK, clamed by Argentina
Climate: variable. with mostly westocls
winds throughout the year. witerspersed
periods of calm: nearly all precipitatios
as SNOW
Terrain: most of the islands, rising steeply
from the sea. are rugged and mountainou
South Georgia is largely barren and has
Steep. glacter-covered mourtains. the South
Sandwich Islands are of volcanic origin with
some active volcanoes
lowest point: Atiantic Ocean 0 m
|
highest pom Mount Paget 2915S m
Natural resources: fish
Land use:
arable land: O%
permanent crop. O%
meadows and posiures: 0%
441
South Georgia and the South Econom) Spain
Sandwich Islands (continued) Fconomic overview: Some fishing takes
place mm adjacent waters. There ts a petential &.
source of income from harvesting fin fish
vely covered by permanent and knll. The islands rece:ve income from
me sparse vegetation postage stamps produced in the UK
s. and lichen) Budget:
rivated land: u Am revenues: 8$291.777
havirenment: expenditures: $451,000. including capital FRANCE
NA AWMPRGIO" Santana
" expenditures of SNA (1YRS est.) a Coruna B Cac a ANDORRA
South 7 dwich Islands Electricity: “ve “sats Pasaes PirenQme
beings " ns =~ _ capacity: YOO KW — “vores a - - <
, — “SPR production: 2 million kWh i; paghernotay ¥
ov consumption per capa: NA kWh (1992) oo maome _
. vaerce®
; NA ‘ ; aa
‘,cographtc note: the th coum of South ail, soba, saan: A cave
‘ hy ° * Seviia
- _ — Transportation ree
cindeer, imtroduces sora ta 2
n South Georg. Highways: Ye 3 . ALGERIA
tataly NA km MOROCCO > - ; saeeneneas
paved: NA km
unpaved: NA km ;
Peoph Ports: Grytviken Geography
Population nopulation: there Airports: non Location: Southwestern Europe. bordering
: South the Bay of Biscay. Mediterranean Sea. and
British Antarctic Surves North Atlantic Ocean, southwest of France
on Bird Island. th: Geographic coordinates: 40 00 N. 4.00 W
| re yninhabited Communications Map references: Europe
\\rea’
lelephones: \\A total area: 504.750 sq km
lelephone system: land area: 499.400 sq kin
domestic. NA , : >
Government compara areca: slightly more than twice
mermaional, coastal radiotelephone station the size o. Oregon
Name of country: i Grytviken note. mecludes Balearic Islands, Canary
m: South Georgia and Radio broadcast stations: AM 0. FM 0 Islands. and five places of sovereignty
. hortwave 0 (plazas de soberania) on and off the coast of
we. A Radios: NA Morocco —Ceuta, Mellila, Islas Chatarmnas
Data code: S\\ lelevision broadcast stations: (0 Penon de Alhucemas. and Penon de Velez de
ape SF Hevereemeen: Sey senem msneeny Se lelevisions: NA la Gomera
Land boundaries:
( apital Cavtviken on South Georgia total: 180482 km
Lowy horder countries: Andorra 65 km, Franes
\\dministrative divisions: none (dependent Defense 623 km. Gebraltar 1.2 km, Portugal 1.214 km
he wK note: excludes the length of the boundary
Independence | dependent territory of Defense note: defense is the responsibility between the places of sovereignty and
of the UK Morocco
National holiday: | iber iy. 14 June Coastline: 4.964 kin
Maritime claims:
( onstitution ) exclusive economic cone. 200 nm
feval svstem: f1 non daw tervuiorial seas 12 nm
- vecutive branch: International disputes: Gibraltar question
() ELIZABETH TE Got the with UK: Spain controls five places of
, ’ 6 February 19592). 2 sovercrgnty (plazas de soberama) on and off
wesented ty the coast of Morocco—ihe coastal enclaves
Everard TATHAM of Ceuta and Melilla. which Morocco
4) dent at Stanles contests, as well as the islands of Penon de
athland Island \\lhucemas. Penon de Velez de la Gomera,
Legislative branch: | lon and Islas Chatarinas
ludicial branch: non Climate: temperate. clear, hot summers in
Flas: the flag of the UK is usec inferior, more moderate and cloudy along
coast, cloudy, cold winters in interior, partly
cloudy and cool along coast
Y5/
Terrain: !arge. flat to dissected plateau
surrounded by rugged hills: Pyrenees in
north
lowest point: Atlantic Ocean 0 m
highest point: Pico de Teide on Canary
Islands 3.718 m
Natural resources: coal. lignite. iron ore.
uranium, mercury, pyrites, fuorspar.
gypsum, zinc, lead. tungsten, copper, kaolin,
potash, hydropower
Land use:
arable land: 31%
permanent crops: 1O%
neadows and pastures: 21%
forest and woodland: 31%
other: 7%
Irrigated land: 33.600 sq km (1989 est.)
Location: Southeastern Asia. group of reefs
in the South China Sea. about two-thirds of
the way trom southern Vietnam to the
southern Philippines
Geographic coordinates: § 38 N_ 111 55
Map references: Southeast Asia
Area:
total area: NA sq km but less than S$ sq km
land area: less than 5 sq km
comparative area: NA
note: mcludes 100 of so itets. coral reefs
and sea mounts scattered over the South
China Sea
sand boundaries: 0 km
Coastline: 926 km
Maritime claims: NA
International disputes: al! of the Spratly
Islands are claimed by China. Tarwan. and
Vietnam, parts of them are claimed by
Malaysia and the Philippines: in 1984
Brune: established an exclusive economic
zone, which encompasses Lounsa Reet, bu
has not publicly clanmed the istand
Climate: tropical
Terrain: flat
lowest point: South China Sea 0 m
highest point: unnamed location on
Southwest Cay 4m
Natural resources: fish, guano
undetermined oil and natural gas potential
Land use:
arable land: O%
permanent crops, O''s
meadows and pastures, O%
forest and woodland: W%
other: 1OO%G
Irrigated land: 0 sy km
Eavironment:
current issues: NA
natural hazards. typhoons. serous maritime
hazard because of numerous reefs and shoals
ternational agreements: NA
Geographic note: strategically located near
several primary shipping lanes in the central
South China Sea: includes numerous small
islands, atolls. shoals. and coral reefs','d2b23f6dfaaf604ea75b65791d6f52be346acfd622647d899be40698fca5aba1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c74a5396420517a12f5c1e0fe837901acc69c9577cb570387fbdbbc646ca11f',1996,'LY','Libya','geography',526,'Location: Northern Africa. bordering the
Mediterranean Sea. between Egypt and
Geographic coordinates: 34 00 N, 9 00 E
Map references: Africa
Area:
total area: 163,610 sq km
land area: 155,360 sq km
comparative area: slightly larger than','60e2fbeeab0929868c541a5be84f09c4fcf401837b7f0455b8a97bebd708d15f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93eff5ec08ccbeb9237f40702eb3b3b31fa8789f7ff269ddaaddadfeeae13921',1996,'TN','Tunisia','geography',527,'f,eographic coordinates: 25 00 N. 17 OOF
Map references: Atrica
Area:
total area: 1.759.540 so km
land area: 1,759,540 sq km
comparative area: slightly larger than Alaska
Land boundaries:
total: 4.383 km
border countries: Algeria 982 km. Chad
1.055 km. Egypt 1.150 km. Niger 354 km.
Sudan 383 km. Tunisia 459 km
Coastline: |.770 km
Maritime claims:
territorial sea: 12 nm
Gulf of Sidra clesing line: 32 degrees
minutes north
International disputes: the International
Court of Justice (ICJ) ruled in February 1994
that the 100,000 sq km Aozou Strip between
Chad and Libya belongs to Chad and that
Libya must withdraw from it by 31 May
1994, Libya has withdrawn some of its
forces in response to the ICJ ruling. but still
maintains part of the airfield and a small
military presence at the airfield’s water
supply located in Chad: maritime boundary
dispute with Tunisia. claims part of northern
Niger and part of southeastern Algeria
Climate: Mediterranean along coast: dry.
extreme desert interior
Terrain: mostly barren. flat to undulating
plains. plateaus, depressions
lowest point: Sabkhat Ghuzayyil -47 m
highest point. Bikku Bitti 2.267 m
Natural resources: petroleum. natural gas.
gypsum
Land use:
arable land: 2%
permanent crops. UW «
meadows and pastures. &%
forest and woodland.
other: YOO
Irrigated land: 2421) sy km (1989 est)','64f3586140a7209c6d2fe066e7231faf430606b9a576ebc02ce13b332a64ed40','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('472edac6128e191ff39bc1e04db1aafa260e3292d3814e709f4c3f7e3c768041',1996,'LI','Liechtenstein','geography',534,'Location: Central Europe. between A
mad Switzerland
(,cographic coordinates: 47 10 \\ 9 4}
Map references: Europ
\\rea:
wiai area, Te su hi
land area. | sy |
of Washington, Dt
Land boundaries:
ola Sh
Porder countries \\ustria 40 +
4) kin
Coastline: © kin clondhocks
Maritime claims: pone (landiocs
International disputes: .
hilometers of Czech territos
from its roval famul IYIS. the (
Republi msists that resut
back betore Fcehruars 1948
communists served pow
Climate: continental. col
with frequent snow or ran
moderately warm. clouds. hus
Terrain: mostly mountarmous «A
Rhine Valley m western third
lowest point, Ruggletler Roet 4
Inghest point’ Grauspity 2.599 |
Natural resources: hy droclew
Land use:
arable land: 25
permanent crops. OF
meadows and pastures, >
forest and woodland. |9
othe IN
Irrigated land: NA so ki','e508ff43eb931571f97a3f3fda64e782c5143bc82e5b2af05b9d80a6741563ee','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea4212de9360ebb340388b96b1601b01da9e1dcbcfdfa958099574d7af4b2e6c',1996,'LU','Luxembourg','geography',543,'Location: Western Europe. between Fi
and Germans
Geographic coordinates: 49 45 \\_ 6
Map references: Europ:
Area:
seater as 1 §& .
MOlal dled. co. f) sy AI
! y ‘ . ,
lagna atcoas CAS SU kn
(OMParahre area siivnl iti
Rhode Island
Land boundaries:
total. 389 kin
border countries’ Belgium 148 kim. bra
73. km. Germany 138 km
Coastline: 0 kin landlocked
Maritime claims: none (landlocked)
International disputes: jon
Climate: moditied continent.
Winmlers. COOL summers
Terrain: mostly gently rolling uplands wi
. °
broad. shallow vallevs: uplands to light
mountamous mn the north: steep slope
to Moselle Hoodplaim In the southeast
lowest pont: Moselle River 132
highest point: Burgplatz S59 m
Natural resources: tron ore (yo lone
exploned)
Land use:
arable land: 24%
permanent crops: Ve
meadows and pastures. 20
forest and woodland: 21
other: 34S
Irrigated land: NA sg ko
Location: Southern Aimea. iiand in the
(y tot Madavaseas
(,couraphic coordinates: 20 17 S. S7 331
XI p references: Worl
\\Vrea
fand boundartes:
( ousthine:
Niuritime chamms:
international disputes: claims the tsiand ot
t K-adminismtered British
Ferntory: claims French
i i if Is] nd
€ timate: toy i! moditied by southeast
irs wo ter (May t
\\ hun sum mel
\\1
Perrain: i plan cying to
ns encircling central
fdoecan 0) }
Pit la Petite Riviere
‘
Natural resources: arable jand. fish
land use:
ae Fi
other: 7%
Irrigated land: 170 sq km (1989 est.)','a639ae72f130356b8d794ce086007896d95f07492eebd54fec8c22946e6a37d9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66285f0863ea81a421454eb8b3f4627146301045c035e8085737c55a713d83d2',1996,'CN','China','geography',549,'Location: Eastern Asia. bordering the South
China Sea and China
Geographic coordinates: 22 10 N. 113 33
Ee
Map references: Southeast Asia
Area:
total area. V6 sq kin
land area: 16 sq km
comparative area. about O.1 times the size
of Washington. DC
Land boundaries:
total: 0.34 km
horder country: China 0.34 kin
Coastline: 40 kin
Maritime claims: not specified
International disputes: none
Climate: subtropical: marine with coo!
winters, Warm summers
Terrain: generally tat
287
He
Niacau (continued)
South China Sea O m
‘ Coloane Alto 174 m
Natural resources: NEGI
fund use:
irrigated land: NA sg km
Pravironment:
NA
SA
‘ 1) t ) {) ‘
ed tt Portuga
iaeorgraphie note: csseatiaily urban. ot
| ptt & tne at
land
i?
re Cell
l
! ‘ hal
|
a?
f HO. female
. ma S6Y> temale
fy
Population growth rate: 5 iUU6 est)
Birt! e: $4.16 birt 100) population
Deut! te: (Mv) population
Ne! ration rate: | 660 migrantés)/] O00
pune
SCY hha:
Of maletsVfemale
dale female
O71 maleisVtemiate
maletsVtemale (1996 est
infunt mortality rate: 5.3 deaths/1.000 live
life oxpectanes at birth:
'' ye
Petal fortelity rate: | 9) child:
.
vatronalits
MUAY
\\4
fthnic divisions: Chinese o>
hy
Religions: Buddhist 45%. Roman Catholic
r Pre tunt 17. none 45.8 ther 1.2%
1GNty
Languages: Portuguese (official) 4
Chinese (Cantonese! is the linguage wt
rth)
. i ~ ie
288
Literacy: age 15 and over can read and
write (19X81 est.)
total population: 9%
male. 93%
temale: SOAS
Geographic coordinates: 23 30 N, 121 00
E
Map references: Southeast Asia
Area:
total area: 35,980 sq km
land area: 32,260 sq km
comparative area: slightly smaller than
Maryland and Delaware combined
note: includes the Pescadores, Matsu. and
Quemoy
Land boundaries: (0 km
Coastline: |.448 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: involved in complex
dispute over the Spratly Islands with China,
Malaysia, Philippines, Vietnam, and possibly
Brunei: Paracel Islands occupied by China,
but claimed by Vietnam and Taiwan;
Japanese-administered Senkaku-sheto
(Senkaku Islands/Diaoyu Tai) claimed by
China and Taiwan
Climate: tropical; marine; rainy season
during southwest monsoon (June to August):
cloudiness is persistent and extensive all year
Terrain: eastern two-thirds mostly rugged
mountains; flat to gently iolling plains in
west
lowest point: South China Sea 0 m
highest ;int: Yu Shan 3.997 m
Natural cesources: small deposits of coal,
natural gas, limestone, marble, and asbestos
Land use:
arable land: 24%
permanent crops: \\%
meadows and pastures: 5%
forest and woodland: 85%
other: 15%
Irrigated land: NA sq km','eb1fcbed5e042f4876292ede2b23a1ef13a8d31b013a21294cc0ce6de3218e80','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('202db3f36296c5d37af32d5c85efc52439792f94e2bf07e2be563aa888e0a5b3',1996,'ZW','Zimbabwe','geography',558,'yr + 0)4 ” }
y S37 mI Location: Southeastern Asia. peninsula and
, ap 1 northern one-third of the land of Borneo.
4? j 4 is i -.” Ml
bordering Indenesia and the South China
Sea. south of Vietnam
(,eographic coordinates: 2 30 N. 112 30 &
Map references: Southeast: \\sia
\\rea:
mal area. 329 7590 sg km
land area: 328.550 sq km
cmparalve area slightly larger than New
Location: Eastern Asia, islands bordering
the East China Sea, Philippine Sea, South
China Sea, and Taiwan Strait, north of the
Philippines, off the southeastern coast of','ebc2f4d9b1c6d88e626861cc7304d0867aa29fae51bce11ab29ad596d4724dc9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a6a3180b9a7ef7c6a8883c816b17aa726e76c9b6f50912c3289cc91dd7b4659',1996,'MV','Maldives','geography',560,'Location: Southern Asia. group of atolls in
the Indian Ocean. south-southwest of India
Geographic coordinates: 3 15 N. 73 00 E
Map references: Asia
Area:
total area: 300 sq km
lund area: 300 sq km
comparative area: nearly twice the size ot
Washington, DC
Land boundaries: () kn
Coastline: 644 km
Maritime claims:
exclusive economic zone: 35-310 nm as
detined by geographic coordinates: segment
of zone comeides with maritime boundary
with India
territorial sea: 12 nm
International disputes: none
Climate: tropical: hot, humid: dry. northeast
monsoon (November to March): rainy.
southwest monsoon (June to August)
Terrain: ‘lat
lowest pomt: "dian Ocean 0 m
highest point: unnamed location on Wilingth
24m
Natural resources: fish
Land use:
arable land: \\O%
permanent crops: 0%
meadows and pastures: 3%
forest and woodland: 3%
other: 84%
Irrigated land: NA sq km','9b9a888d241b5e3bc91d17652fffe90af8867b08bcbca35e7450b608f5aaa6ab','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c8970931b3b4a938c19fa43e0006e6f6433878e1022bd35bcc65c74552221c4',1996,'MT','Malta','geography',571,'Location: Southern Europe. islands in the
Mediterranean Sea. south of Sicily (taly)
Geographic coordinates: 35 50 N. 14 35 E
Map references: Europe
Area:
total area: 320 sq km
land area: 320 sq km
comparative area less than twice the size of
Washington, DC
Land boundaries: () km
Coastline: 140 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the
depth of exploitation
exclusive fishing zone: 25 nm
territorial sea: 12 nm
International disputes: Malta and Tunisia
are discussing the commercial exploitation of
the continental shelf between their countries.
particularly for oil exploration
Climate: Mediterranean with mild. rainy
winters and hot, dry summers
Terrain: mostly low, rocky. flat to dissected
plains: many coastal cliffs
lowest point: Mediterranean Sea 0 m
highest point: Dingli Clifts 245 m
Natural resources: limestone, salt
Land use:
arable land: 38%
permanent crops: 3%
meadows and pastures: 0%
foresi and woodland: 0%
other: 59%
Irrigated land: |(0 sy km (1989)
Location: Western Europe. island in the
Irish Sea. between Great Britain and Ireland
Geographic coordinates: 54 15 N.4 30 W
Map references: Europe
Area:
total areca, S88 sq km
land area: S88 sq km
comparative area. slightly more than three
times the size of Washington, DC
Land boundaries: 0 km
Coastline: | 13 km
Maritime claims:
erclusive fishing zone: 12 nm
territorial seas 12 nm
International disputes: none
Climate: cool summers and mild winters:
humid: overcast about half the time
Terrain: hills in north and south bisected by
central valley
lowest point: Insh Sea Om
highest point: Snaetell 620 m
Natural resources: lead. iron ore
Land use:
arable land: NAG
permanent crops. NAG
meadows and pastures: NAG
forest and woodland: NAG
other: NAG (extensive arable land and
iorests)
Irrigated land: NA sy km','3efbca736909442c4cc7ca834f1a55d3d6b26dd24239cfe856a7e6909fa7d806','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c0624bbdfe163fc38a28c6ad5b33de2784cfad13122036e1091f90e66569faf',1996,'MH','Marshall Islands','geography',577,'Location: Oceania group of atolls and reets
in the North Paci:
the way trom Hawan to Papua New Guinea
Ceographic coordinates: 9 00 N. 168 00.6
Map references: Oceania
\\rea:
woatal aired
Ocean. about one-hall of
I‘y] 3 sq km
IN}.3 sq km
about the size of
lana aved
comparative arca
Washington, DC
note. mecludes the atolls of Brhini, Enewetak
and Kwajalein
Land boundaries: © km
Coastline: 370.4 km
Maritime claims:
24 nm
COMMHOUS TON
; ,
clolmsne economic conc. COO am
rerriorial seas 12am
International disputes: claims US territory
of Wake Island
Cliniate: wet season May to November. hot
and humid. islands border typhoon belt
Ferrain: low coral limestone and sand
islands
lowest pomt: Paciiie Ocean Om
hig.est pom): unnamed location on Likiep
Om
Natural resources: phosphate deposits.
marine products, deep seabed minerals
Land use:
arable land: VW
permanent crops. OO
meadows and pastures. O%
forest and woodland:
other: 40
Irrigated land: NA sy kin','30359aa297474fe1b037ab92689088555f48fc89071dada16542a30a6ea30ec1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11d48ced8ef7a819451260abd88f606105da6af718123ee8a6b577973bf843d1',1996,'MS','Montserrat','geography',602,'Location: Canbbean. island im the Canbbean
Sea. southeast of Puerto Rico
Ceographic coordinates: 16 45 \\.62 12 \\W
Map references: Central America and the
Canbbean
Area:
total area: VOO sg km
100 sy km
comparative area. about 0.6 times the size
of Washington. DC
Land boundaries: 0 km
Coastline: 40 km
Maritime claims:
cvclusive fishing zone
land area
200 nm
3 nm
International disputes: pone
Climate: tropical: little daily or seasonal
lemperature Variation
Terrain: volcanic islands. mostly
terriiorial sea
mountainous. with small coastal lowland
lowest poml Caribbean Sea 0 m
highest point: Chances Peak 914 m
Natural resources: NEGI
Land use:
arable land 20
permanent crops: O%
meadows and pastures: \\O%
forest and woodland: 4G
other: 3O%
Irrigated land: NA sy km','b0980f4624749fb510987f680a70c989b5ba0425b2de21bcb7b30f5c12f79d8b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1927f9d6090d43e3c566a2b7e18a01e46d6078c396b3ea93c858447be43fe76a',1996,'MA','Morocco','geography',607,'Location: Northern Africa. bordering the
North Atlantic Ocean and the Mediterranean
Sea. between Algeria and Western Sahara
Geographic coordinates: 32 00 N.5 00 W
Map references: Atrica
Area:
total area: 446.550 sg km
land area: 446.300 sq km
comparative area: slightly larger than
Calitornia
Land boundaries:
total: 2.002 km
horder countries: Algeria 1.559 km. Western
Su va 443 km
note: excludes the length of the boundary
between the places of sovereignty and
Coastline: |.835 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the
depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12am
International disputes: claims and
administers Western Sahara. but sovereignty
is unresolved and the UN ts attempting to
hold a referendum on the issue: the UN-
administered cease-fire has been in effect
since September 1991: Spain controls five
places of sovereignty (plazas de soberania)
on and off the coast of Morocco—the coastal
enclaves of Ceuta and Melilla which
Morocco contests as well as the islands of
Penon de Alhucemas. Penon de Velez de la
Gomera, and Islas Chafarinas
Climate: Mediterranean. becoming more
extreme in the interior
Terrain: northern coast and interior are
mountainous with large areas of bordering
plateaus, intermontane valleys, and rch
coastal plains
lowest point: Sebkha Tah -55 m
highest poini: Jebel Toubkal 4.165 m
Natural resources: phosphates. iron ore
manganese. lead. zinc, fish, salt
Land use:
arable land: W8%
permanent crops: 1
meadows and pastures: 28
forest and woodland: 12%
other: AVG
Irrigated land: 12.650 sy km (1989 est)
Location: Oceania, group of islands in the
South Pacific Ocean, about one-half of the
way from Hawaii to New Zealand
Geographic coordinates: 13 35 S, 172 20
W
Map references: Oceania
Area:
total area: 2,860 sq km
land area: 2,850 sq km
comparative area: slightly smaller than
Rhode Island
Land boundaries: 0 km
Coastline: 403 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; rainy season (October to
March), dry season (May to October)
Terrain: narrow coastal plain with volcanic,
rocky, rugged mountains in interior
lowest point: Pacific Ocean 0 m
highest point: Mauga Silisili 1.857 m
Natural resources: hardwood forests, fish
Land use:
arable land: \\9%
permanent crops: 24%
meadows and pastures: 0%
forest and woodland: 47%
other: 10%
Irrigated land: NA sq km
Map references: World. Time Zones
Area:
total area: 510.072 million sq km
land area: 148.94 million sq km
water area: 361.132 million sq km
comparative area: land area about 15 times
the size of the US
note: 70.8% of the world is water, 29.2% 1s
land
Land boundaries: the land boundaries in
the world total 250,883.64 km (not counting
Shared boundaries twice)
Coastline: 356,000 km
Maritime claims:
contiguous zone: 24 nm claimed by most but
can vary
continental shelf: 200-m depth claimed by
most or to depth of exploitation, others claim
200 nm or to the edge of the continental
margin
exclusive fishing zone: 200 nm claimed by
most but can vary
exclusive economic zone: 200 nm claimed by
most but can vary
territorial sea: 12 nm claimed by most but
can vary
note; boundary situations with neighboring
States prevent many countries from extending
their fishing or economic zones to a full 200
nm; 43 nations and other areas that are
landlocked include Afghanistan, Andorra,
Armenia, Austria, Azerbaijan, Belarus,
Bhutan, Bolivia, Botswana, Burkina Faso,
Burundi, Central African Republic, Chad,
Czech Republic, Ethiopia, Holy See (Vatican
City), Hungary, Kazakstan, Kyrgyzstan,
Laos, Lesotho, Liechtenstein, Luxembourg,
Malawi. Mali, Moldova, Mongolia, Nepal.
Niger, Paraguay, Rwanda, San Marino,
Slovakia, Swaziland, Switzerland, Tajikistan,
The Former Yugoslav Republic of
Macedonia, Turkmenistan, Uganda,
Uzbekistan, West Bank, Zambia, Zimbabwe
Climate: two large areas of polar climates
separated by two rather narrow temperate
zones from a wide equatorial band of
tropical to subtropical climates
Terrain: the greatest ocean depth is the
Marianas Trench at 10,924 m in the Pacific
Ocean
lowest point: Dead Sea -408 m
highest point: Mount Everest 8,848 m
Natural resources: the rapid using up of
nonrenewabie mineral resources, the
depletion of forest areas and wetlands, the
extinction of animal and plant species, and
the detenoration in air and water quality
(especially in Eastern Europe and the former
USSR) pose serious long-term problems that
governments and peoples are only beginning
to address
Land usc:
arable land: 10%
permanent crops: 1%
meadows and pastures: 24%
forest and woodland: 31%
other: 34%
Irrigated land: NA sq km','489f1f6e579201ac01aa76f6ee96381e03c815199e7d12687906408a3b84cee9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('829934b323e2725593d1c2447b9f61810e4098b81c2b3d3d9c0e9bb5e8f5ccc5',1996,'NA','Namibia','geography',620,'Location: Southern Ati.
South Atlantre Ocean. betwee
South Atma
Geographic coordinates: >>
Map references: Atr
\\rea:
aii dite SOS 41N8 sg km
KIS +1 sy AN
the «ize of Alash
Land boundaries:
total, AS24 4
Porder COMME \\nvgola
Botswana }.460)}km. S
Jamba 233 kin
Coastline, | 572 ki
Maritime claims:
CUTS COONOMTIG SOM
erriorial sea. Voonn
International disputes:
houndary watt Bot Wilh
guadnpomt with Botswan
/unbabwe won disagreenn
J K b ‘
Botswana over unmnhabit
Island in Lanvants (Chobs
unresolved in December
partes agreed to refer th
Climate: desert: hot. div
erratic
Ferrain: mostly high plates
i )
\\irica SSS 4
alony cous Kal than 1 SCT ! i
lowest pomt: Atlantrye Occ
luvhest pot. Kongstein 2
Natural resources: dian
uranium, gold. lead. tr
ving. salt. vanadium. natur:
suspected deposits fia!
Won ore
ll
° Namibia (continued) Religions: Chnstian 80% to 90%. Lutheran (termerly Democratic Turnhalle Alliance)
Sif) ai least. other Chistian denominations (DTA). Mishake MUYONGO., United
Sail aie We native religrons Le to 20% Democratic Front (UDF). Justus GAROEB
languages: English 7 Cotticial. Atmkaans Federal Convention of Namibia (FCN).
munen Language of most of the population Keiphas CONRADIE. Monitor Action Group
nd about 606 of the white population IMAG). Koste PRETORIUS. Workers
German 32 mdigenous languages Revolutionary Party (WRP). Southwest
Oshivambe. Herero. Nama Vincan National Union (SWANU). Hotes
Literacy: ace 1S and over can read and VEIL. Democratic Coalition of Namibia
shhcnaiasioes | | write (1960 est (DCN). Moses K KATHUONGU A:
Pas tronic otal population 8 National Patnotec Front (NPE) Moses K
male 45 KATIHULONGUA
cmale 34 (ther political or pressure groups: \\ \\
International organization participation:
ACP. AIDB. C. CCC, ECA, FAQ, G-7?
Gove IAEA. IBRD. ICAO. ICRM. IFAD. TEC
| suvernment IFRCS. ILO, IMF. IMO. Intelsat. Interpol
Name of countrys: 1OC. TOM wobserver). ITU. NAM. OAU,
tonal long form. Republic ot SACL. SADC. UN. UNCTAD. UNESCO
Nanub UNHCR, UNIDO. UPL. WCL. WHO
cntronal short form. Nanuta WIPO, WMO. WTr?
Data code: WA Diplomatic representation in US:
Iyvpe of government: republ oduct of musion- Ambassador Tulhamen
People Capital: Windhoek KALOMOH
Population \\dministrative divisions: | 3 regions chancery: \\OOS New Hampshire Avenue
Ave structur bronge. Hardap. Karas. Khomas. Kunenc NW. Washington, DC 20009
Canny: (Liambesn), Ohangacaa, Ohavango telephone. (1) 6202) YS6-41840
Omabeke. Omusau. Oshana. Oshrkoto FAN. {1} (202) G8o443
Onjovondyupa LS diplomatic representation:
Independence: >) March 1990 (from South net of passion” Ambassador Muarshall t
\\irican mandate MICCALLII
National holiday: Independence Day. 2! embassy” Ausplan Building. 14 Lossen St
peiidadieia anit Ke 7 March (1990 | Windhoek
(Constitution: ratiticd & bebruary 1990 mailing address: Private Bag 12029
Birth rats < , :
11\\ larch (O90) \\usspannplatz. Windhoes
Legal system: based on Roman Dutch law clephone: |264) 61) 22160)
Death rate ’ \\ | ’
mn) Liluitne PAN. 1264] 064) 22979)
Suffrage: |> ws . ra Flag: a large blue tnangle with a vellow
Net migration )
tveccutive branch: unburst tills the upper lett section. and an
Cue med equal green triangle (sold) tills the lower
wen '' t Sam NOE VOMA csr | Maret nvht sechon. the trangles are separated by a
Hn) cled tor a tive-vear term hy red stripe that ps contrasted by two narrow
, fir } /-s white-cdve borders
1) } VOI ine he held NA
} sbyyes PIU) or ! Sam NO FONMA
man tol | nient. percent of vote NA
the members of Natronal Assembly Economic oversiew: The coonomy ts
[al pec tan io burth Levistative branch. bicameral restatug heavily dependent on the extraction and
Nut Council elections last held processing of mumerals for export, Mining
November. 4 December 1992 cnext to be held ncounts for almost 256 of GDP. Namibia ts
December 1YUR) | Lee tat val the tourth-largest ¢ porter of no luc!
beial fertihty ot by party NA. seat 6H total) SWAPO TY minerals in Atrica and the world’s titth
DIAG UDI large producer of uramum. Rich alluvial
Nauthonalits National Assemb lecthoms last held 7-8 diamond deposits make Nanubia a primary
December 1994 (next to be held NA ~wource for gem-quality diamonds. Nanubia
December 1999). results — percent of vote by also produces large quantities of lead. 71%
bthnic divisions '' iy ¢ party NA. seat (7 totals SWAPO 83 tun. silver. and tungsten. More than half the
DIA IS. UDF 2 MAG 1. DCN | population depends on agnculture largely
Judicial branch: Supreme Cour subsistence agnculture) tor its livelyhood
() h Political parties and leaders: South West Nanubia must import some of its food
Hore Vinca People s Orgamzation (SWAPO) GDP: purchasing power party—SS.8 billion
( anna Sam NUJOMA: SWAPO) tor Justice (1994 est)
Mswana 04 Zachara NIOMBA,: DTA of Namibia GDP real growth rate: 665 (1994 est)
a4
HB
GDP per capita: $3.600 (1994 est)
GDP composition by sector:
avruulture. NA‘
mdustry. NAS
wnies, NAS
Inflation rate (consumer prices):
(1994)
Labor force: SOO.)
agnculture 60. industry and
PY cnc upalun
commence 19% services Sor. government
(. Wuning 6° CIYST est)
Unemployment rate: $5). in urban areas
(19903 ext)
Budget:
rovenucs SYS) mullron
cyrnditures: STOS billvon. including capital
expendiures of SIS7 million (FY9 94)
Industries: meat packing. fish processing
dairy prodects. mining (diamond, lead. 71m
ln. silver. tungsten. uranium. copper)
Industrial production growth rate: |.
(1994)
hiectricits:
capacity 406,000 KW
129 blhon KWh
per capita, OSS AWh Ol99h)
pronation
CONST O
Agriculture: millet. sorghum, peanuts
livestock. fish catch potential of over |
Hiilon metre tons no bemg tulfilled
Exports: S13 billion (fob. 1993)
commoditics. dranvonds. ca ppt gold. 71%
lead. uranium, cattle. processed tish, harakul
NS Slik
parthers. Switzerland, South Atnea
Germons, UK
Imports, S! 2 billion chob
commnnditics lomlstutts. pet eleum products
1yu4,
nd fuel. machimers and equipment
partners. South Atria. Germany. US. Japan
External debt: about S885 millon (1994
est)
Economic aid:
reynonmt ODA SNA
Currency: | South Afmean rand (R) = 100
aCT.*
Exchange rates: South Atmcan rand (R) rer
LSS] $6417 Clanuary 1996" 3 6266
99S) 2 S400 E1994) 2 2HAH ELON) 2 R407
(1069) 2 TaS4 TOOT)
biscal vear: | Apnl 4t March
Location: Ocean. island in the Sout
Paciic Ocean. south of the Murshall Islands
(,eographic coordinates: ()
Map references: Occani
\\rea:
Wiaashu 1
Land boundaries: © bk:
(Coastline:
Maritime claims
ecwcl ‘ j MMi my
International disputes:
Climate: tropa
November to Fe wus
lerrain: sands beac!
round faisead tal f ! si] 1} DL
plateau rim
Natural resources: p!
Land use:
otined hin)
Irrigated land: \\ \\ "','d956829f36bea41ef45d96ff90f083ad309d4a3f16566bfe4e8abfa377ab9fd8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2482ba736f80e2a673dae9446ae8f02f9f5cec07ad074cb908d5a9fc17cd07e',1996,'NL','Netherlands','geography',630,'Location: Western Furope. bordering the
North Sea. between Belgium and Germany
C,eographic coordinates: 52 40 N.5 45 &
Map references: Europe
\\rea:
wtal area, 47.330 sy hin
and areca, AA YQ ~ kin
comparative arca. siightly less than twice
the size of New Jerse
Land boundaries:
al 1.027 km
Paordat’ (COUNT
$77 km
(oustline: 45! km
Maritime claims:
Belgium 450 kim, Germans
luasice sohine cone, 200 nm
hovitorial sea. 1am
International disputes: none
Climate: temperate. manne. cool summers
and mid winter
Perrain: mostly coastal lowland and
eclammed land (poiders). some hills in
southeast
lowest pant: Pons Alexanderpolder -7 m
lnvhest pot. Vaalserberg 321 m
Natural resources: natural gas. petroleum
fertik sisal
Land use:
arable laid t''s
permanent crops. VW
meadows and pastures: 32%
forest and woodland. 9%
thy ;
Irrigated land: 5.500 sg him (1989 est)
Ens.conment:
wrent sues. Water pollution sn the form of
heavy metals. organic compounds. and
nutrients such as nitrates and phosphates: air
pollution from vehicles anc refining
activities: acid rain
natural hazards: the extensive system of
dikes and dams. protects nearly one-half of
the total area irom being flooded
uuernational agreements. party to-—Aw
Pollution. Air Pollution-Nitrogen Oxides. Air
Pollution-Sulphur 85. Air Pollution- Volatile
Organic Compounds. Antaretic-
Environmental Protocol, Antarctic Treaty.
Biodiversity. Climate Change. Endangered
Species. Environmental Modification.
Hazardous Wastes. Marine Dumping. Marine
Lite Conservation, Nuclear Test Ban. Ozone
Layer Protection, Ship Pollution, Tropical
limber 83. Wetlands. Whaling: signed. but
not ratitied—Aur Polluton-Sulphur 94.
Biodiversity. Desertification, Law of the Sea.
tropical Timber 94
Geographic note: located at mouths of three
major European rivers (Rhine. Maas or
Meuse. and Schelde)
} Tilhe nd
Location: Oceania, iiands in the South
F* saan Pacthe Ocean, east of Australia
Geographic coordinates: 2) 30S. 165 30 6
be chuage rat Map references: Oceania
'' \\rea:
f tal ared 1Y.060 sy kim
liad areca, YS.S7S
Mineral - ii i i" SY kin
COMPpPUTATING adicad Slight! smaller than Net','126b5041c6e64d93ee16d47d4a61a078382cef780ff94f3401b741f2f5ef9fc5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccefea1db166c37118893bbd51095ff77bdf1b08a6679737329aa189bf4a03f2',1996,'TK','Tokelau','geography',636,'Location: Middle America, bordering both
the Canbbean Sea and the North Pacitic
Ocean. between Costa Rica and Honduras
Geographic coordinates: |) 00 N85 00 .W
Map references: Central Amernca and the
Canbbean
Area:
tial area’ 129494 sq kn
land area: 120.254 sq kim
comparative area. sightly larger than New
York State
Land boundaries:
tial: W231 km
border countries: Costa Rica 308 kin
Honduras 922 km
Coastline: 910 km
Maritime claims:
comtienous sone: 25-nm security zone
continental shelf natural prolongation
territorial seas 200 am
International disputes: terrmtoral disputes
with Colombia over the Archipelago de San
Andres 5 Providencia and Quita Sueno
Bank. with respect to the maritime boundary
question in the Golto de Fonseca, the
international Court of Justice ICI) referred
the disputants to an earher agreement i this
century and advised that some tripartite
resolution among El Salvador, Honduras. and
Nicaragua bhely would be required
mantime boundary dispute with Honduras
Climate: tropical in lowlands, cooler in
highlands
Terrain: eviensive Atlantic coastal plains
nsing to central menor mountains, narrow
Pacitic coastal plain interrupted by volcanoes
lowest pomt: Pacitye Ocean 0 m
lighest point’ Mogoton 2.438 m
Natural resources: gold. silver. copper.
tungsten, lead. zinc, timber. fish
Land use:
arable land: 9%
permanent crops. V%
meadows and pastures: 45%
forest and woodland: 3%
other, AIG
Irrigated land: &S0 sy km (i989 est)
Location: Oceania, group of islands in the
South Pacific Ocean, about one-half of the
way trom Hawan to New Zealand
Geographic coordinates: 9 00 S. 172 00 W
Map references: Oceania
Area:
total area: 10 sq km
land area: 10 sq km
comparative area: about 17 times the size of
The Mall in Washington, DC
Land boundaries: ( km
Coastline: 10) km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; moderated by trade winds
(Apri! to November)
Terrain: coral atolls enclosing large lagoons
lowest point: Pacific Ocean ( a
highest point: unnamed locaton 5 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures; 0%
forest and woodland: 0%
other: 100%
irrigated land: NA sq km','ffe83b079818d4d177d67f6006953bc8fcb38a0a95da07d45e49d5ac0d800852','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9abffd6d743bc39afabf7053904157e0a1c158cf83b820b0ed59d653ce4cfad2',1996,'DZ','Algeria','geography',639,'Leographic coordinates: (6 00 Nos OOF
Map references: \\tnvo
\\rea:
hetal area | 267 mllon sq ks
. .
aif site fy (eH) ~y 4
‘ i? rr / ‘ t* x! ni ‘
in Sivt if | Ma
boundaries:
land
bested ae Ar
iwitede vy comeplrn \\ ria Wh & hl
kim. Burkona base 628 km. Chey 1178 4
Libva §54 kom. Mal) S82? kom Nowe j
AT
( eastline: 0 km Clondiocked
Maritime claims: nome landlocks
International disputes: Lihyo clo h
''Y 440) sg kim oon northera Newer. demarcot
mM miematon houndares im Lake Chix
wh of whech has bed to border mc odents
the past. Nieted and awaiting
ratitncateen hy Cameroon. Chad. New
NX vena. Burky base and Miali an
prmvccding with pouralarn demarcal
mchadng the Lapwat with Niger
Climate: desert. mostly bet. dn. dus
troical in extreme south
lerrain: predominately desert plas
sam! dunes. tlat to rolling plan
hills on north
lowest pow Niget River SU
highest pom! Mont Grebous 44
Natural resources: ui aniun
tin, Phosphates
Land use:
arable land: *
Permninent crops Us
rele adow 5 aithal puisture ‘
MSI
Niger (continued)
Irrigated land: 320) sy km (IYSY ost
tovnenment:
sul Crosson
~<Thin atm, wildiite
ephant. hippopelamus
Jause of poaching and
Surnng droughts
remy vrs PMarts Th
Chmate Change. kndangered
'' tal Miewlitacate
Ho C7. | wet Pavticcthm
1 Mut mat tatiticd
Luw of the S
Lcographn nete: dhe he
‘i ople
Populetien nr
\\ve sMracture
! »
; | 7
’ ”
Population growth rate "y Loe
arth rate ie HWY ov ‘A jlathuen
ih ath rate: _ Cattis (Hh) ‘Lh be slheent
Nel mteration rate: | wrantis! ) A
Sek fale
The
The
" ab i}
, | (pug .
Infant mortality rate 17 6 deathw TOO
life expectancs at birth:
'' ''
how
lotal bertilets rate: s4 iron her’
Nationality
»
.*
tthow divistonms: |! . Deerma J?
| ‘ ‘ Hor He Kuru)
\\ | , ( norris Iie
, ..000 Preach expatriates
Relignons: Ni 1 * iarmbes
14 hrestians
languages: brench cottoial) Hausa. Dperma
Literacy S und over can read and
>
AS?
ital population” 13.6%
male 9G
female: O65 «
Location: Northern Africa, bordering the
Mediterranean Sea. between Algeria and','56cb9efc96b9d0c3e9cfeb3ff7502f48b06d5299e8a2b93c31d56723c5916402','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b49932c67307df9f324b2c4ad80c1f1f7cc6e39cd299d910aa1b4fe66567bf86',1996,'NO','Norway','geography',645,'Location: Northern Europe. bordenng the
Noth Sea and the North Atlantic Ocean
west of Sweden
Geographic coordinates: 62 00 N. 1000 |
Map references: Europ:
\\rea:
ared. 4°4.220 “y kim
farca. 407 S60 sq kin
Mew
Lend boundaries:
‘ LEE, } i | a Su |
f i Ri) } f a
Coastline: 95 kn wludes ma
,41N kN i mh va +h
, ,
14) it}
entha Mires b
Nlaritime ciaims
| f
; j j (hh
‘
International disputes
\\ {) \\1 |
kk
i S
( limmate | litiedl |
North A ( older inter
ii |
lerrain Hed: mostly h plat
! broken by tf
liered phan thiy lee]
1 | | dl rel tumdira 1) |
‘ out. Norwe mn Sea Oy
} hest pout: Glhittertinden 2.472 m
Natural resources: petroleum. copper
natural gas, pyrite nickel, ron ore. 71M
lead, fish, timber, hydropower
Land use:
arable land: 3%
permanent crops: O%%
meadows and pastures: O%
forest and woodland: 27%
other: TO
Irrigated land: 950 sy km (1989)','1e5991333a8dfc8468a48cdba6d1fb7abca3c52b511e93ba4a47a42351c1b51c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('677b83d716d3a6091309d3e9d168282c0aaf7be20e1dca93cd015c7db536b648',1996,'PK','Pakistan','geography',651,'bocation: Asia. bordering the
(,cographic coordinates: 30 00 N. 70 00 |
\\ lap references: As:
\\rea:
, SU A
Pi > SS than Wice
ne Sivec ? € aliton
Land boundaries:
TE \\ighanistan 2.430 km.
China 5323 kn. India 2.912 kim. Tran 909 km
Coasthme: | O46 ki
Nlaritime claims:
{ | { Cut ‘
| TYIY}
International disputes: status of
4 }2 } ''
Chimate: vot. dry desert: temperate 1
et)
Perrain: tlat Ind sain in east: mounta
Ves Bal nist { |
j {) {
, nN Mi Cy } Aus n
‘ fy
Natural resourecs: !and. extensive natural
MiteGg petroleum. poor Quality
pper, Salt. limestone
Lund use:
366
meadows and pastures: 6%
forest and woodland: 4%
other: 67% (1993)
Irrigated land: 170.000 sq km (1992)
Location: Southern Africa. island in the
Indian Ocean, east of Madagascar
Geographic coordinates: 21 06 S. 55 36 E
Map references: World
Area:
total area: 2.510 sq km
2.500 sq km
comparative area: slightly smaller than
Rhode Island
Land boundaries: () kin
Coastline: 20) km
Maritime claims:
exclusive economic zone: 200 nm
land area.
territorial sea: 12 nm
International disputes: none
Climate: tropical, but moderates with
elevation: cool and dry from May to
November, hot and rainy trom November to
April
Terrain: mostly rugged and mountainous:
fertile lowlands along coast
lowest point: Indian Ocean 0 m
highest point: Piton des Neiges 3.069 m
Natural resources: fish. arable land
Land use:
arable land: 160%
permanent crops: 3%
meadows and pastures: 5%
forest and woodland: 35%
other: 41% (1993)
Irrigated land: 60 sg km (1989 est.)','3cb7dcf54219b65693d310be230a801a7861a67ec629a61e9d5d6a75b2e386ea','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51e734a2a84a47eeb599c9a1103c3967b7fd6fe8c8c4e7156c6986730b0411ea',1996,'PW','Palau','geography',658,'Location: Oceania, group of islands in the
North Pacific Ocean, southeast of the','ff2f010df617e6b8eb3144a25229cf9818bddf4d69287ba57c888227dda03a26','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e5a4ea2b959545b3dfd8b280645e2c76647d220afa019b8110b82872d4af776',1996,'PH','Philippines','geography',659,'Geographic coordinates: 7 30 N. 134 30E
Map references: Oceania
Area:
total area: 458 sq km
land area: 458 sq km
comparative area: slightly more than 2.5
times the size of Washington, DC
Land boundaries: 0 km
Coastline: 1.519 km
Maritime claims:
continental shelf: 200-m depth or to the
depth of exploitation
exclusive fishing zone: 12 nm
extended fishing zone: 200 nm
teritorial sea: 3 nm
International disputes: none
Climate: wet season May to November: hot
and humid
Terrain: varying geologically from the high.
mountainous main island of Babelthuap to
low, coral islands usually fringed by large
barrier reefs
lowest point: Pacitic Ocean 0 m
highest point: Mount Ngerchelchauus 242 m
Natural resources: forests. minerals
(especially gold), marine products, deep-
seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
Location: Oceania, atoll in the North Pacific
Ocean, about one-half of the way from
Hawai to American Samoa
Geographic coordinates: 5 52 N, 162 06 W
Map references: Oceania
Area:
total area: VAS sq km
land area: 11.9 sq km
comparative area: about 20 times the size ot
The Mall in Washington, DC
Land boundaries: () km
Coastline: 14.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: equatorial, not, and very rainy
Terrain: very low
lowest point: Pacific Ocean 0 m
highest point: unnamed location 2 m
Natural resources: jone
Land use:
arable land: 0%
permanent crops: O%
meadows and pastures: 0%
forest and woodlend: \\OO%
other: O%
Irrigited land: 0 sg km
Location: Oceania. islands in the South
Pacific Ocean, about one-half of the way
trom Peru to New Zealand
Geographic coordinates: 25 04S. 130 06
W
Map references: Oceania
\\rea:
total area: 47 sq km
land area: 47 sq km
comparative area: about 0.3 times the size
of Washington, DC
Land boundaries: 0 km
Coastline: 51 km
Maritime claims:
exclusive fishing zone: 200 nm
exclusive economic zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical. hot, humid, modified by
southeast trade winds; rainy season
(November to March)
Terrain: rugged volcanic formation: rocky
oastline with cliffs
vest point: Pacific Ocean 0 m
hest point: Pawala Valley Ridge 347 m
tural resources: miro trees (used for
dicrafts). fish
nd use:
arable «and: NAG%
permanent crops: NAG
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sg km
384
[ avironment:
current issues: detorestation (only a small
portion of the orginal forest remains because
of burning and clearing for settlement)
natural hazards: typhoons (especially
November to March)
international agreements: NA
Location: Central Europe. east of Germany
Ceographic coordinates: 52 00 N. 20 00.&
Viap references: Europe
\\rea:
_ AX La
nal 4 tho { KI
mnpParalNve are iwhtly smaller than New
Mec Al
Land boundaries:
fota;,, 2 SSS km
horder countrte Belurus 60S
Republic 658 km. Ger
Lithuania 9} km. Rus “
Oblast) 6 km. Slovah
i>
4+ ki
Coastline: 49} kn
Nlaritime claims:
ilf ( ) Li
! Caulk
crit See ~ hi
International disputes: none
Climate: (emperat » cold. cloudy
eTalely s¢ winters With trequent
n: nuld summers with trequent
mdershowers
Perrain Iy flat plain: mountains along
Rauczki Elblaskie -2 m
Ryvsv 2.499 m
Natural resources; coal. sulfur, copper
Land use:
Irrigated land: |.000 sg km (1989 est.)
386','54ae8cf65e553b394141d88ebedd756bfeeec21343c9c42128ac740c933ca8c0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66aaa9d3c624e3865d33cd48bb1a0a3e33e4930643680d6f7c154fe1c33fd936',1996,'PA','Panama','geography',667,'Location: Middie America, bordering both
the Caribbean Sea and the North Pacific
Ocean. between Colombia and Costa Rica
Geographic coordinates: 9 00 N. 80 00 W
Map references: Central America and the
Caribbean
Area:
total area: 78.200 sg km
land area: 75.990 sq km
comparative area: slightly smaller than
South Carolina
Land boundaries:
total: 555 km
border countries: Colombia 225 km, Costa
Rica 330 km
Coastline: 2.490 km
Maritime claims:
territorial sea: 200 nm
International disputes: none
Climate: tropical: hot. humid. cloudy:
prolonged rainy season (May to January).
short dry season (January to May)
Terrain: interior mostly steep. rugged
mountains and dissected, upland plains:
coastal areas largely plains and rolling hills
lowest point: Pacitic Ocean 0 m
highest point: Volcan de Chiriqui 3.475 m
Natural resources: copper. mahogany
forests, shrimp
Land use:
arable land: 6%
permanent crops: 2%
meadows and pastures: 15%
forest and woodland: 54%
other: 23%
Irrigated land: 320 sq km (1989 est.)','7b4f1b5dd6683402838d0e87c30364c29aecb7abc0f28f98f1b2f1d6df511983','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c3608ea5d6b6b5196e02a176908ac02dca61b9aa6e3e33ab29ef36ee4334e83',1996,'PG','Papua New Guinea','geography',673,'Location: Southeastern Asia. group of
islands including the eastern half of the
island of New Guinea between the Coral Sea
and the South Pacific Ocean. east ot','70defde2a9fba973bdc88734a8adeaf4b1769884a4dc5a1cba723b68139f9642','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01f3bf55ea021be446b2350a74855d42f21a30c07da641f544fc93f394cace93',1996,'PR','Puerto Rico','geography',687,'Location: Caribbean. island between the
Canbbean Sea and the North Atlantic Ocean.
east of the Domimecan Republic
Geographic coordinates: |8 15 N. 66 30 W
Map references: Central America and the
Canbbean
Area:
total area: 9104 sq km
land area: 8.959 sq km
comparative area: slightly less than three
times the size of Rhode Island
Land boundaries: () km
Coastline: 50! km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical marine. mild. little
seasonal temperature variation
Terrain: mostly mountains with coastal
plain belt in north, mountains precipitous to
sea on west coast; sandy beaches along most
coastal areas
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1.338 m
Natural resources: some copper and nickel!
potential for onshore and offshore onl
Land use:
arable land: 8%
permanent crops. 9%
meadows and pastures: 41%
forest and woodland: 20%
other: 22%
Irrigated land: 390 sq km (1989 est)','615ad30011ab814c1a1c05a23838d02d28e9b4e0256aa3186b3cb5c94ca1a4be','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35b872f549399190265c3ef22bba4d2e799473213e145c9c0ead46bdc2ae8cfe',1996,'BH','Bahrain','geography',691,'Location: Middle East
the Persian Gulf and Saudi Arabia
Geographic coordinates: 25 3) N. 5) IS E
Map references: Middle East
Area:
total area: LAO sq kin
11.000 sq km
comparative area. sightly smaller than
land area
Connecticut
Land boundaries:
wial: OO km
Saudi Arama 60 km
Coastline: 563 km
Maritime claims:
24 nm
horde rcounr,
CONTIRHMOUS TONE
exclusive economic cone: 200 am
12 nm
International disputes: terriot.al dispute
with Bahrain over the Hawar Islends.:
territorial sea
maritime bourdary with Bahram, 1965
mounsula bordering
boundary with Saudi Arabia. renegotiated
and revised in 1992. but not official
depiction
Climate: desert: hut. dry: humid and sultry
in summer
Terrain: mostly flat and barren desert
covered with loose sand and gravel
lowest point: Persian Gulf 0 m
highest point: Qurayn Aba al Baw! 103 m
Natural resources: petroleum. natural gas
fish
Land use:
arable land: 0%
permanent crops: O%
meadows and pastures: S%
forest and woodland: O%
other: 9%
Irrigated land: NA so km','78b8db05009e96200b34865529b53d9f6473a3214da65464201ee27db5e10a42','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e91674d3e945115dff09301cbfee1a2d613b4303bad32945d74f88c7fc9c89bd',1996,'KN','Saint Kitts and Nevis','geography',696,'Location: Caribbean. islands in the
Canbbean Sea. about one-third of the way
from Puerto Rico to Trinidad and Tobago
Geographic coordinates: 17 20 N. 62 45 W
Map references: Centra! America and the
Carnbbean
Area:
total area: 269 sq km
land area: 269 sq km
comparative area: twice the size ot
Washington, DC
Land boundaries: () km
Coastline: 135 km
Maritime claims:
comtiguous cone: 24 nm
exclusive economic zone: 200 nm or to the
edge of the continental margin
territorial sea: 12 am
International disputes: none
Climate: subtropical tempered by constant
sea breezes. little seasonal temperature
variation, rainy season (May to November)
Terrain: volcanic with mountainous interiors
lowest point: Canbbean Sea 0 m
highest point: Mount Liamuiga 1.156 m
Natural resources: NEGL
Land use:
arable land: 22%
permanent crops: ATG
meadows and pasiures: X%
forest and woodland: 17%
other: 41%
Irrigated land: NA sq km','e04ed363edf166c47cdf4f1f5dc076ba1e7de50ba6d9c929de5c49c6f602e36e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('715717800d613028d0d18e6d275794fcbb037cf85303a224bc47da262ccddc72',1996,'LC','Saint Lucia','geography',702,'Location: Caribbean, island in the Caribbean
Sea. north ot Trinidad and Tobago
Geographic coordinates: |3 53 N. 60 68 W
Map references: Central America and the
Canbbean
Area:
total area: 620 sq km
land area: 610 sq km
comparative area: 3.5 times the size of
Washington, DC
Land boundaries: () km
Coastline: 158 km
Maritime claims:
contiguous zone: 24 nm
200 nm or to the
edge of the continental margin
exclusive economic zone
territorial sea: 12 nm
International disputes: none
Climate: tropical, moderated by northeast
trade winds: dry season trom January to
April. rainy season trom May to August
Terrain: volcanic and mountainous with
some broad, fertile valleys
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Natural resources: forests. sandy beaches.
minerals (pumice). mineral springs.
geothermal potential
Land use:
arable land: 8%
permanent crops: 20%
meadows and pastures: 5%
forest and woodland: (3%
other: 54%
Irrigated land: |() sy km (1989 est.)','f5b8812e2c43f359b162f9f7bde90ce9fe2eb48649e319f79eb6220cdca98a82','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85cbc35862f594713a3d5006e813a3f6d70139d82553e13cf8edaebce8c4034d',1996,'PM','Saint Pierre and Miquelon','geography',709,'Location: Northern North America, islands
in the North Atlantic Ocean. south of
Newfoundland (Canada)
Geographic coordinates: 46 50 N. 56 20 E
Map references: North America
Area:
total area: 242 SY km
land area: 242 sq km
comparative area: 1.5 times the size of
Washington. DC
note: includes eight small ‘stands in the
Saint Pierre and the Miquelon groups
Land boundaries: 0 km
Coastline: | 20 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: focus of maritime
boundary dispute between Canada and
France: in 1992 an arbitration panel awarded
the islands an exclusive economic zone area
of 12.348 sq km to settle the dispute
Climate: cold and wet. with much mist and
fog: spring and autumn are windy
Terrain: mostly barren rock
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande Montagne
240 m
Natural resources: fish. deepwater ports
Land use:
arable land: 13%
permanent crops: O%
meadows and pastures: O%
forest and woodland: 4%
other: B3%
Irrigated land: NA sq km
Location: Canbbean. islands in the
\\ hpean Sea. north of Prnidad and Fobago
(,eographic coordinates: (3 1S N61 12 W
Map references: Central America and the
Caribbean
\\rea:
( reas 340 sq km
favea. 449 sg km
mparaive area: twice the size ot
Washingtor. Dt
Land boundaries: () km
Coastline: S4 kin
Viaritime claims:
LL mie? 200 nm
nny
international disputes: non
Climate: tropical, little seasonal temperature
“ny season (Mav to November)
ferrain: INtAIMOUS
j ( hheun Sea Om
Soutnere 1.234 m
Natural resources: NEGI
Land use
Irrigated land: |() sg km (1989 est.)','57acf343d335e2ac081f156b779f91a808d50501e8f09cf1ff4db7d68a071edd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efce5cd52341654884b968e7438fedb176de57ed863ff9b6fb8379f86a8ecc04',1996,'SM','San Marino','geography',716,'Location: Southern Eur inenclave in
ib dtu
Ceeographic coordinates: 44 46 N. 12 25 1
Map references: |
\\rea:
total area MM) sy h
lana Pag fyf) i i
CM PLT j e ed bout \\} ; Limes the Si7e
of Washington, Df
Land boundaries:
total: 39 km
border count ltuly 49 km
Coastline: © km Clandlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: Mediterranean: mild to cool
Wan MAY summer,
Ferrain: rugged mountains
nt; kkume Ausa SS m
hest pout: Monte Titaco 749 m
Natural resources: building stone
Land use:
irrigated land: NA sa km','5d044c3d821e5b48d842bc66ca2695c56d2cd78cf6eb8e87d12dfd6122d7ede2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52889a6dead83291c15b5133984f6f3279361c75c71486fffc71064f385de041',1996,'ST','Sao Tome and Principe','geography',723,'Location: Western Africa. island in the
Atlante Ocean. straddling the Equator. west
of Gabo
Geographic coordinates: | 00 N. 7 001
Map references: Africa
Area:
fatal area, YOO sq kin
land ated Yt) “U km
more than tive times the
size of Washington 1M
Land boundaries: 0 km
Coastline: 209 kn
Maritime claims: measured trom clammed
comparal be teu
archipelagic baselines
exclusive economn cone 20000m
territorial sea. 12 nm
International disputes: none
Climate: tropical. hot. humid. one rainy
season (October to May)
Terrain: volcanic. mountainous
lowest powmt) Atlantic Ocean 0 1
highest point: Pro de Sao Tome 2.024 m
Natural resources: [)sh
Land use:
arable land: |
permanent crops “)
meadows and pastures
forest and woodland 7%
other, 4G
Irrigated land: NA sy ko','c1ab8e2ce966e3046f5cce4fe0a50bb601a7c0daa99da8951c1a76e539d49225','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ec41676936e34f289253150f94aed9cb71e6077e58dd93395a997b40733be8f',1996,'ET','Ethiopia','geography',734,'Location: Southeastern Europe. bordering
\\driatic Sea. between Albania and
Bosnia and Herzecovina
Geographic coordinates: 44 00 N. 21 00 E
Map references: burope
\\rea:
wal area. VW2.350 sq km
02.136 sq km
ares slightly larger than
Ax WKS
Serbia has a total area and a land area
4 . naking if slightly larget
Maine. Mors ilenegre Nas a total area of
PSS sg AM and a4 land area of 13.724 SU
‘ | '' | |
'' ,Y ; ‘ Water sat
iAGl i’ eri ee. wii tan
Land boundaries:
» 4»
> KM
é airic Albama 287 km (114 km
Serbia. 173 km with Montenegro).
md Herzegovina $27 km (312 km
Serbia. 215 km with Montenegro).
kin. Croatia (north) 241 km.
1 (south) 2S km. Hungary 151 km.
Former Yugoslav Republic of
Romania 476 km
ndarv between
lomia 22) km
he ternal Kyat
Ni negro and Serbia is 211 km
Cvastline: 199 km (Montenegro 199 km.
a Okn
Viaritime claims: NA
international disputes: disputes with Bosnia
and Herzegovina and Croatia over Serbian
nopulated areas: Albanian majority in
422
Kosovo seeks independence trom Serbian
republic
Climate: in the north, continental climate
(cold winter and hot, humid summers with
well distributed rainfall): central portion.
continenial and Mediterranean climaic. io the
south, Adnatic climate along the coast, hot.
dry summers and autumns and relatively
cold winters with heavy snowfall inland
Terrain: extremely varied: to the north, rich
fertile plains: to the east. limestone ranges
and basins: to the southeast. ancient
mountain and hills: to the southwest.
extremely high shoreline with no islands off
the coast
lowest point: Adnatic Sea 0 m
highest point: Daravica 2.656 m
Natural resources: oil. gas. coal. antimony.
copper. lead. zinc. nickel. gold. pynte.
chrome
Land use:
arable land: 30%
permanent crops: 3°
meadows and pastures: 20%
forest and woodland: 25%
ether: 20%
Irrigated land: NA sq km
Geographic coordinates: 10 00 N. 49 00 &
Map references: Africa
Area:
total area: 637,660 sq km
land area: 627,340 sq km
comparative area: slightly smaller than
Texas
Land boundaries:
total: 2.366 km
border countries: Djibouti 58 km. Ethiopia
1.626 km. Kenya 682 km
Coastline: 3.025 km
Maritime claims:
territorial sea: 200 nm
International disputes: southern halt of
boundary with Ethiopia is a Provisional
Administrative Line: territorial dispute with
Ethiopia over the Ogaden
Climate: principally desert. December to
February—northeast monsoon. moderate
temperatures in north and very hot im south
May to October—southwest monsoon. torrid
in the north and hot in the south, irregular
raintall, hot and humid pernods (tangambili)
between monsoons
Terrain: mostly flat to undulating plateau
rising to hills in north
lowest point: Indian Ocean 0 m
highest point: Shimbiris 2.450 m
Natural resources: uranium and largely
unexploited reserves of iron ore. tin, gypsum.
bauxite, copper, sali
Land use:
arable land: 2%
permanent crops: O%
meadows and pastures 46%
forest and woodland: 14%
other: 38%
Irrigated land: 1.600 sq km (1989 est.)','6adff948235830b22519b14db37c18150dbaed4d216cf72bfbf532c02502af45','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b135618cdc04982a6554fee83c2a8aab48a8505807f9aa59e00591ef50044c5a',1996,'SC','Seychelles','geography',741,'Location: Eastern Atrica. group of islands in
the Indian Ocean, northeast of Madagascar
Geographic coordinates: 4 35 8.55 40 EF
Map references: Africa
Area:
total area’ 455 sq km
lund area’ 455 sq km
comparative area. 2.5 times the size of
Washington. DC
Land boundaries: () km
Coastline: 49! km
Maritime claims:
continental shelf/> 200 nm or to the edge of
the continental margin
exclusive economic zone: 200 nm
territorial seas 12 am
International disputes: claims Tromelin
Island
{‘limate: tropical marine: humid: cooler
season during southeast monsoon (late May
to September). warmer season during
northwest monsoon (March to May)
Terrain: Mahe Group ts granitic, narrow
coastal strip. rocky. hilly: others are coral,
flat. elevated reets
lowest pot: Indian Ocean 0 m
highest point: Morne Seychellois 9OS m
Natural resources: fish. copra. cinnamon
trees
Land use:
arable land: 4%
permanent crops. VS%
meadows and pastures: 0%
forest and woodland: (S%
other: GOOG
Irrigated land: NA sy km','5fb808b2f1d43bb4253df89f4b92ae882c76441e93251d871beafcdf1007f847','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ecc8a4fa354175ef98be11b37a902ee29aab9ffb84ba2c2555d2d970db5fc88',1996,'SL','Sierra Leone','geography',747,'Location: Western Af:ica. bordering the
North Atlantic Ocean, between Guinea and','04f3150bb60730d2b0fdc1b15ff5f4c2947b80bbf39c2833039effa75389c9b3','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07e8a057c8a85271676f20d29b7d2f43c0ef222fa82a49a3fcf23621660ccf94',1996,'SK','Slovakia','geography',757,'Location: Central Europe. south of Poland
Geographic coordinates: 48 40 N. 19 JOE
Map references: Europe
Area:
total area: 48.3845 sq km
land area: 48.800 sq km
comparative area: about twice the size of
New Hampshire
Land boundaries:
total: 1.355 km
border countries: Austna 91 km, Czech
Republic 215 km. Hungary 515 km. Poland
444 km, Ukraine 90 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: Gabcikhovo Dam
dispute with Hungary: unresolved property
issues with Czech Republic over
redistnbutson of dormer Czechoslovak federal
property
Climate: temperate; cool summers, cold,
cloudy. humid winters
Terrain: rugged mountains in the central
and northern part and lowlands in the south
Bodrok River 94 m
hiehest point: Gerlachovka 2.655 m
imowes! poml
Natural resources: brown coal and lignite:
small amounts of iron ore, copper and
manganese ore. salt
Land use:
arable land: NAG
permanent crops: NAG
meadows and pastures: NAG
forest and woodland: NAG
NAG
Irrigated land: NA sy km','533c61e4c618fb6fc5cd8f652e14e08f2c2cbbc340e1556854228269d15b2640','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0924cad012218b8bf55befd6f3b504740ec75f4cad79bf5b933ca96f0457373',1996,'SB','Solomon Islands','geography',764,'Location: Oceania. group of islands in the
South Pacific Ocean, east of Papua New','a7007636cc5d197eb32f62199ac1068b6a58e00a503ef6ecb15edfd0b70bbac5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac7f0fa1c5bc300235d4ebec92867fd4389479832a560e55351956cda1e88b2e',1996,'GN','Guinea','geography',765,'Geographic coordinates: 8 00S. 159 00 F
Map references: Oceania
Area:
tial area; 23.ASO sq km
land area: 27. 540 sq km
comparative area. sighily larger than
Mary land
Land boundaries: () km
Coastline: 5.313 km
Maritime claims: measured trom claimec
archipelagic baselines
continental shelf: 200 am
exclusive economic cone: 200 am
territorial sea: 12 nm
Internationa! disputes: nonce
Climate: tropical monsoon; few extremes of
lemperature and weathe:
Ferrain: mostly rugged mountains with
some low coral atolls
lowest point: Pacitic Ocean 0 m
highest point: Mount Makarakomburu 2.447
m
Natural resources: fish. forests. gold
bauxite. phosphates. lead, zinc, nickel
Land use:
arable land: (1G
permanent crops: Va
meadows and pastures: 1%
forest and woodland: 9¥%
other: 4%
Irrigated land: NA sy km','3520f8cb333874804b68db8643ff4628783ff4425dbef240e4ecab0c59f3981a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('656cf4cd5448a7872dba42c37aeb2f94a6258fabbcc8d23abc54a6c1b2c3f2ea',1996,'KE','Kenya','geography',771,'Location: Eastern Africa. bordering the Gulf
of Aden and the Indian Ocean. east of','0dc685a45be76c80d95d2b218425e2a59814ed71bd7ecfc96a5993109c354126','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4913aef5d88637572375161fd4e5f53c2a90d9114145b896b0bd2245c3af9833',1996,'SR','Suriname','geography',777,'Location: Northern South America
bordering the North Atlantic Oc«
French Guiana and Guyana
Geographic coordinates: 4.00 N. 56 00 W
Map references: South America
\\rea:
land houndarie
( coastline sf
\\Nlaritime claims
International disputes
( limats
lerrain
j Wilh
Natural resources: tin
pi iinum
Land use:
arable land: NEGI
permanent crops {)'',
meadows and pastures
~
forest and woodland: 97%
other: 3%
Irrigated land: 590 sg km (1989 est)
Location: Northern Europe. islands between
the Arctic Ocean. Barents Sea. Greenlan
Sea. and Norwegian Sea. north of Norway
Geographic coordinates: 7s 00 N. 20 0
Map references: Arctic Region
Area:
total area
j
land area
qi paral
Land bou4aries: ( }
Coastline. ?S87 ky
Naritime claims:
Ferrain: wild. rugged mount
high land ice covered, we
abuut one halt of the ye
and north coasts
lowest pomt: Arctic Ocean 0 m
highest point: Newtontoppen 1.717 n
Natural resources: coal, copper, iron
phosphate, zinc, wildlife, fish
ore
Land use:
arable land: O%
permane nil « rops
meadow § diid pa
j
forest and woodiand. V
Other. VOU!
are crowberry and cloudberry
Irrigated land: NA sy km
Lconomy s ;
Radios: NA
EK conomi verview Location: Southern Alnca. between
‘? ’ ; ‘ ‘)
elevisio oadcast stations: Mozambique and South Atrmea
lelevision broadcast station Mozambig nd South At
'' lelevisions: NA (,eographic coordinates: 26 30S. 3) 401
Map references: Atrica
\\rea:
, i) ia sil cj KI
Defense ‘ “M) i
yy j ‘ ‘ nity i |
Defense note: c turized by 1 y pre , New
Land boundaries:
\\ +b
\\1 \\
\\! vib
( oustline: I \\
\\iaritime claims b
International disputes ;
; st 4 ‘ oi ‘
4
ride ‘
K
; , i» ;
( limmate
lerrain
; be
} } “T,
j
Natural resources
rite. |
Land use:
Prac rrvidiiie ; j NEC;
lransportation moad and pastures: ¢
Railways: 0 ki fored and wood ad
Highways: other: 20%
NA} Irrigated land: 640 sy km (1993 est.)
454','e57d513da19d346831350a810174430969f09dd6eafd155d387bcbd7575421e6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acc7282ae05e6a876c5e64af10db1cdd1b08daa814d301c0273944976cf743db',1996,'CH','Switzerland','geography',783,'Location: Central Europe. east of France
Ceograpacc coordinates: 47 00 Nos 001
Map references: Europe
Area:
total area, 41.290 sg kin
lund area: 39.770 sq km
comparative area: sightly more than tw
the size of New Jersey
Lund boundaries:
hota 8S) km
faomdios 7 4 |
’ All Ital Hi) 4 | '' 1) i
Caermans + th
Coastline: © km Candlock
Maritime claims: | Henk
International disputes
Climate: |
lerram
Nats tal resources
Land us
Irrwated land ;
lt nvironment
evan Feathial
Pollution \\u Pollution Noitr ’ 1 Oy
Pollutwon-Sulphur 85, Au Pollution-\\
Orgamic Compounds, Antarctic Treaty
Biodiversity, Climate Change, Endangerex
—
Species. Environmental Modification
Hazardous Wastes. Manne Dumping. Marine
Nuclear Test Ban. Oz
Laver Protection. Ship Pollution, Tropica
Dimber &3. Wetlands. Whalu ened, t
mu catiticd—Auw P on-Sulphur 94
Antarciic-Envir tal P
Desertification, Law of the § f
lim
Ceeographic note: landloct
i ile Conservation
r Vo
ea
-
northern and southern | e. along W
woutheastern France and norther lta
cotttamns the highest elevation |','42029299ffa2e282210e35606efbc579ebe478a864385ddc550e4d3125b937fa','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a01f9c4e7cdf64bb0a9cf3a76a559afeb4d0ef9ab44f7bf92a29b52ce0626fb',1996,'TJ','Tajikistan','geography',787,'Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 OO E
Map references: Commonwealth of
Independent States
Area:
total area: 143,10) sq km
land area: 142,700 sq km
comparative area: slightly smaller than
Wisconsin
Land boundaries:
total: 3,651 km
border countries: Afghanistan 1,206 km,
China 414 km, Kyrgyzstan 870 km,
Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: boundary with
China in dispute; territorial dispute with
Kyrgyzstan on northern boundary in Isfara
Valley area; Afghanistan''s and other foreign
support to Islamic fighters in Tajikistan’s
civil war based in northern Afghanistan
Climate: midlatitude continental, hot
summers, mild winters; semiarid to polar in
Pamir Mountains
Terrain: Pamir and Altai Mountains
dominate landscape; western Fergana Valley
in north, Kofarnihon and Vakhsh Valleys in
southwest
lowest point: Syrdariya 300 m
highest point: Quilai Kommunizm 7,495 m
Natural resources: significant hydropower
potential, some petroleum, uranium, mercury,
brown coal, lead, zinc, antimony, tungsten
Land use:
arable land: 6%
permanent crops: 0%
meadows and pastures: 23%
forest and woodland: 0%
other: 71%
Irrigated land: 6,940 sq km (1990)
Location: Eastern Africa, bordering the
Indian Ocean, between Kenya and','bff593e3b2db74a954305643ce5edb799589360c5425e293c0c03b813eaacace','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('919b6884f7ceaf8d9e7537575802af6147f9a92d43cc5650376fd3a53239f95c',1996,'TH','Thailand','geography',794,'Location: Southeastern Asia, bordering the
Andaman Sea and the Gulf of Thailand,
southeast of Burma
Geographic coordinates: 15 00 N, 100 00
E
Map references: Southeast Asia
Area:
total area: 514,000 sq km
land area: 511,770 sq km
comparative area: slightly more than twice
the size of Wyoming
Land boundaries:
toial: 4,863 km
border countries: Burma 1,800 km,
Cambodia 803 km, Laos !,754 km, Malaysia
506 km
Coastline: 3,219 km
Maritime claims:
continental shelf: 200-m depth or to the
depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: boundary dispute
with Laos; unresolved mantime boundary
with Vietnam; parts of border with
Cambodia in dispute; maritime boundary
with Cambodia not clearly defined
Climate: iropical; rainy, warm, cloudy
southwest monsoon (mid-May to
September); dry, cool northeast monsoon
(November to mid-March); southern isthmus
always hot and humid
Terrain: central plain: Khorat Plateau in the
east; mountains elsewhere
lowest point: Gulf of Thailand 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural gas.
tungsten, tantalum, timber, lead, fish,
gypsum, lignite, fluorite
Land use:
arable land: 34%
permanent crops: 4%
meadows and pastures: \\%
forest and woodland: 30%
other: 31%
Irrigated land: 42,300 sq km (1989 est.)
Location: Western Africa, bordering the
North Atlantic Ocean, between Benin and
Chana
Geographic coordinates: 8 00 N. | 10 E
Map references: Africa
Area:
total area: 56,790 sq km
land area: 54,390 sq kan
comparative area: slightly smaller than West
Virginia
Land boundaries:
total: 1.647 km
border countries: Benin 644 km, Burkina
Faso 126 km, Ghana 877 km
Coastline: 56 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 30 nm
International disputes: none
471
Tego (continued)
Climate: tropical, hot, humid in south:
semiand in north
Terrain: gently rolling savanna in north:
central hills: southern plateau; low coastal
plain with extensive lagoons and marshes
lowest point: Atlantic Ocean 0 m
highest point: Pic Baumann 986 m
Natural resources: phosphates, limestone.
marble
Land use:
arable land: 25%
permanent crops: \\%
meadows and pastures: 4%
forest and woodland: 28%
other: 42%
Irrigated land: 70 sq km (1989 est.)','fc30ff679f1252d06a8169e13f69a1add4b8123cf8a0cf8417e8a33741e72de7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cf542f4def0face2e0a95e0f6d6c37a6c4c9a6d7fc104109773ff360ab0c1cd',1996,'TT','Trinidad and Tobago','geography',802,'Locatien: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean.
northeast of Venezuela
Geographic coordinates: |1 00 N, 61 00 W
Map references: Central America and the
Caribbean
Area:
total area: 5,130 sq km
land area: 5,130 sq km
comparative area: slightly smaller than
Delaware
Land boundaries: ( km
Coastline: 362 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the outer
edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; rainy season (June to
December)
Terrain: mostly plains with some hills and
low mountains
lowest point: Caribbean Sea 0 m
highest point: E\\ Cerro del Aripo 940 m
Natural resources: petroleum, natural gas,
asphalt
Land use:
arable land: 14%
permanent crops: 17%
meadows and pastures: 2%
forest and woodland: 44%
other: 23%
Irrigated land: 220 sq km (1989 est.)','67c9bc6f46519fbb962bc916f0242f0c90b851c80dbb934bc6b9e9eabd976963','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca74919b495c19d173afdf4e076c17d05c66ffba7a0f421f22c4f3bf1846d2d8',1996,'TC','Turks and Caicos Islands','geography',807,'Location: Caribbean. two island groups in
the North Atlantic Ocean, southeast of The
Location: Oceania, island group consisting
of nine coral atolls in the South Pacific
Ocean, about one-half of the way from
Hawaii to Australia
Geographic coordinates: 8 00 S. 178 OO E
Map references: Oceania
Area:
total area: 26 sq km
land area: 26 sq km
comparative area: 0.1 times the size of
Washington, DC
Land boundaries: () km
Coastline: 24 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 am
International disputes: none
Climate: tropical; moderated by easterly
trade winds (March to November); westerly
gales and heavy rain (November to March)
Terrain: very low-lying and narrow coral
atolls
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: O%
meadow’s and pastures: 0%
forest and woodland: 0%
other: 100%
note: Tuvalu’s nine coral atolls have enough
soil to grow coconuts and support
subsistence agnculture
Irrigated land: NA sq km','dbcab5cd341e01dbf469752eea32bfad577b93ae5e1e292fc5169319e85bd0ac','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80833d65cf67a73ea5ddb1529a0f4918aa4b6cbd25e2d5d0a77f4e8d377b232d',1996,'BS','Bahamas','geography',808,'Geographic coordinates: 2) 45 N. 71 35 W
Map references: Central America and the
Caribbean
Area:
total area: 430 sq km
land area: 430 sq km
comparative area: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 389 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; marine, moderated by
trade winds; sunny and relatively dry
Terrain: low, flat limestone; extensive
marshes and mangrove swamps
lowest point: Caribbean Sea 0 m
highest point: Blue Hills 49 m
Natural resources: spiny lobster, conch
Land use:
arable land: 2%
permanent crops: O%
meadows and pastures: 0%
forest and woodland: 0%
other: 98%
Irrigated land: NA sq km','5ce3c239219ea3728fb3052c19965d891b6fdad9e525d7b7f0961e6142db00d1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee21024deff98c7d812c75410414a8b11b14cd9247371005ff252eb208181a46',1996,'UG','Uganda','geography',818,'Location: Eastern Africa, west of Kenya
Geographic coordinates: | 00 N, 32 OO E
Map references: Africa
Area:
total area: 236.040 sq km
land area: 199.710 sq km
comparative area: slightly sinaller than
Oregon
Land boundaries:
total: 2,698 km
border countries: Kenya 933 km, Rwanda
169 km, Sudan 435 km, Tanzania 396 km,
Zaire 765 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: tropical: generally rainy with two
dry seasons (December to February, June to
August): semiarid in northeast
Terrain: mostly plateau with rim of
mountains
lowest point: Lake Albert 621 m
highest point: Margherita (Mount Stanley)
5.110 m
Natural resources: copper. cobalt.
limestone, salt
Land use:
arabie land: 23%
permanent crops: 9%
meadows and pastures: 25%
forest and woodiand: 30%
other: 13%
Irrigated land: 90 sq km (1989 est.)','0f2592913fb4cad77d528c270b63ee2499a752f18a155c1f2a4c986aa4514887','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38626cbca98c1b2deb2fdc7c56f841a7449e08fe0485089d5e1086bc9be1dbcb',1996,'UA','Ukraine','geography',825,'Location: Eastern Europe, bordering the
Black Sea, between Poland and Russia
Geographic coordinates: 49 00 N. 32 OO E
Map references: Commonwealth of
Independent States
Area:
total area: 603,700 sq km
land area: 603.700 sq km
comparative area: slightly smaller than
Texas
Land boundaries:
total: 4.558 km
border countries: Belarus 891 km, Hungary
103 km. Moldova 939 km, Poland 428 km,
Romania (southwesi) 169 km, Romania
(west) 362 km. Russia 1.576 km. Slovakia
90 km
Coastline: 2.782 km
Maritime claims:
continental shelf: 200-m or to the depth of
exploitation
exclusive economic zone: undefined
territorial sea: 12 nm
International disputes: certain territory of
Moldova and Ukraine—including Bessarabia
and Northern Bukovina—are considered by
Bucharest as histoncally a part of Romania:
this territory was incorporated into the
former Soviet Union following the Molotov-
Ribbentrop Pact in 1940; dispute with
Romania over continental shelf of the Black
Sea under which signifcant gas and oil
deposits may exist, potential dispute with
Russia over Crimea: has made no territorial
claim in Antarctica (but has reserved the
right to do so) and does not recognize the
claims of any other nation
Climate: temperate continental:
Mediterranean only on the southern Crimean
coast, precipitation disproportionately
distributed, highest in west and north, lesser
in east and southeast; wimers vary from cool
along the Black Sea to cold farther iniznd;
summers are warm across the greater part of
the country, hot in the south
Terrain: most of Ukraine consists of fertile
plains (steppes) and plateaux, mountains
being found only in the west (the
Carpathians), and in the Crimean Peninsula
in the extreme south
lowest point: Black Sea 0 m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal,
manganese, natural gas, oil, salt, sulfur,
graphite, titanium, magnesium, kaolin,
nickel, mercury. timber
Land use:
arable land: 56%
permanent crops: 2%
meadows and pastures: 12%
forest and woodland: 0%
other: 30%
Irrigated land: 26,000 sq km (1990)','b3aa5620d720895b93cea4f7e9f3fb03fcc74066519f4add26428de6ea9969d0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2f3f89766c41c72593ca8025f088e22f0d0aacff9e77f9f341a576d6fb0c0bd',1996,'OM','Oman','geography',831,'Location: Middle East, bordering the Gulf
of Oman and the Persian Gulf, between
Oman and Saudi Arabia
Geographic coordinates: 24 00 N. 54 00 E
Map references: Middle East
Area:
total area: 75,581 sq km
land area: 75,581 sq km
comparative area: slightly smaller than
Maine
Land boundaries:
total: 867 km
border countries: Oman 410 km, Saudi
Arabia 457 km
Coastline: 1.318 km
Maritime claims:
contiguous zone: 24 1m
continental shelf: 200 nm or to the edge of
the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: location and status
of boundary with Saudi Arabia is not final,
defacto boundary reflects 1974 agreement:
no defined boundary with most of Oman, but
Administrative Line in far north; claims two
islands in the Persian Gulf occupied by Iran:
Lesser Tunb (called Tunb as Sughra in
Arabic by UAE and Jazireh-ye Tonb-e
Kuchek in Persian by Iran) and Greater Tunb
(called Tunb al Kubra in Arabic by UAE
and Jazireh-ye Tonb-e Bozorg in Persian by
Iran); claims island in the Persian Gulf
jointly administered with Iran (called Abu
Musa in Arabic by UAE and Jazireh-ye Abu
Musa in Persian by Iran); in 1992, the
dispute over Abu Musa and the Tunb islands
became more acute when Iran unilaterally
tried to control the entry of third country
nationals into the UAE portion of Abu Musa
island, Tehran subsequently backed off in the
face of significant diplomatic support for the
UAE in the region
Climate: desert; cooler in eastern mountains
Terrain: flat, barren coastal plain merging
into rolling sand dunes of vast desert
wasteland: mountains in east
lowest point: Persian Gulf 0 m
highest point: Jabal Yibir 1,527 m
Natural resources: petroleum, natural gas
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 2%
forest and woodland: 0%
other: 98%
Irrigated land: 50 sq km (1989 est.)','3b62902f314063cdab2def5baf7c8dec2beab62112e44d1ba47a90e4d58f34aa','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('309056af91965270bb94347a43da1b21a3659e8426c981a69c713664d53775b2',1996,'AE','United Arab Emirates','geography',837,'Location: Western Europe, islands including
the northern one-sixth of the island of
Ireland between the North Atlantic Ocean
and the North Sea, northwest of France
Geographic coordinates: 54 00 N, 2 00 W
Map references: Europe
Area:
total area; 244,820 sq km
land area: 241,590 sq km
comporative area: slightly smaller than
Oregon
note: includes Rockall and Shetland Islands
Land boundaries:
total: 360 km
border country: Ireland 360 km
Coastline: 12.429 km
Maritime claims:
continental shelf: as defined in continental
shelf orders or in accordance with agreed
upon boundaries
exclusive fishing zone: 200 nm
territorial sea: 12 am
International disputes: Northern Ireland
question with Ireland; Gibraltar question
with Spain: Argentina claims Falkland
Islands (Islas Malvinas); Argentina claims
South Georgia and the South Sandwich
Islands; Mauritius claims island of Diego
Garcia in British Indian Ocean Terntory:
Rockall continental shelf dispute involving
Denmark, iceland, and Ireland (Ireland and
the UK have signed a boundary agreement in
the Rockall area): territorial claim in
Antarctica (British Antarctic Terntory)
Climate: temperate; moderated by prevailing
southwest winds over the North Atlantic
Current; more than one-half of the days are
overcast
Terrain: mostly rugged hills and low
mountains; level to rolling plains in east and
southeast
lowest point: Fenland -4 m
highest point: Ben Nevis 1.343 m
Natural resources: coal, petroleum, natural
gas, tin, limestone, iron ore, salt. clay, chalk.
gypsum, lead, silica
Land use:
arable land: 29%
permanent crops: 0%
meadows and pastures; 48%
other: 14%
Irrigated land: |.570 sq km (1989)','6dc44248d5bec90b65ebddf9d679a66223407badc9ffb6ddf89558c79a177680','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2844c9c48ba0591b91c93a920f51763e28051527220ba2d29251673d8692247',1996,'US','United States','geography',841,'Location: North America, bordering both the
Nornh Atlantic Ocean and the North Pacific
Ocean, between Canada and Mexico
Geographic coordinates: 38 00 N, 97 00 W
Map references: North America
Area:
total area: 9,372,610 sq km
land area: 9.166.600 sq km
comparative area: about one-half the size of
Russia: about three-tenths the size of Africa;
about one-half the size of South America (or
slightly larger than Brazil); slightly smaller
than China: about two and one-half times the
size of Western Europe
note: includes only the 50 states and District
of Columbia
Land boundaries:
total: 12.248 km
border countries: Canada 8,893 km
(including 2.477 km with Alaska), Cuba 29
km (US Naval Base at Guantanamo Bay).
Mexico 3,326 km
note: Guantanamo Naval Base is leased by
the US and thus remains part of Cuba
Coastline: 19.924 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: not specified
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: maritime boundary
disputes with Canada (Dixon Entrance,
Beaufort Sea, Strait of Juan de Fuca,
Machias Seal Island); US Naval Base at
Guantanamo Bay is leased from Cuba and
only mutual agreement or US abandonment
of the area can terminate the lease; Haiti
claims Navassa Island; US has made no
territorial claim in Antarctica (but has
reserved ihe right to do so) and does not
recognize the claims of any other nation:
Republic of Marshall Islands claims Wake
Island
Climate: mostly temperate, but tropical in
Hawaii and Florida and arctic in Alaska
semiarid in the great plains west of the
Mississippi River and arid in the Great Basin
of the southwest; low winter temperatures in
the northwest are ameliorated occasionally in
January and February by warm chinook
winds from the eastern slopes of the Rocky
Mountains
Terrain: vast central plain, mountains in
west, hills and low mountains in east; rugged
mountains and broad river valleys in Alaska;
rugged, volcanic topography in Hawaii
lowest point: Death Valley -86 m
highest point: Mount McKinley 6,194 m
Natural resources: coal, copper, lead,
molybdenum, phosphates, uranium, bauxite,
gold, iron, mercury, nickel, potash, silver,
tungsten, zinc, petroleum, natural gas, timber
Land use:
arable land: 20%
permanent crops: 0%
meadows and pastures: 26%
forest and woodland: 29%
other: 25%
Irrigated land: 181.020 sq km (1989 est.)
Location: Oceania, island in the North
Pacific Ocean, about two-thirds of the way
from Hawaii to the North m Mariana Islands
Geographic coordinates: 19 17 N. 166 36
E
Map references: Oceania
Area:
total area: 6.5 sq km
land area: 6.5 sq km
comparative area: about 11 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 19.3 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by the
Republic of the Marshall Islands
Climate: tropical
Terrain: atoll of three coral islands built up
on an underwater volcano; central lagoon is
former crater, islands are part of the rim
lowest point: Pacific Ocean 0 m
highest point: unnamed location 6 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0) sq km
Location: Oceania. islands in the South
Pacific Ocean, about two-thirds of the way
from Hawaii to New Zealand
Geographic coordinates: |3 18 S. 176 !2
Ww
Map references: Oceania
Area:
total area: 274 sq km
land area: 274 sq km
comparative area: slightly larger than
Washington, DC
note: includes lle Uvea (Wallis Island). Te
Futuna (Futuna Island). Ie Alofi, and 20
islets
Land boundaries: () km
Coastline: 129 km
Maritime claims:
exclusive economic cone 200 am
territorial sea: \\2 am
International disputes: monc
Climate: tropical; hot. rainy season
(November to April), cool, dry season (May
to October), rains 2500-3000 mm per year
(80% humidity). average temperature 26 6
degrees C
Terrain: volcanic ongin. low hills
lowest point: Pacific Ocean 0 m
highest point: Mount Singavi 765 m
Natural resources: NEGI
Land use:
arable land: S%
permanent crops: 20%
meadows and pastures: (%
forest and woodland: 0%
other: 75%
Irrigated land: NA sq km
$17
®g
Wallis and Futuna (continued)','cb52d4ed0fc7d44773cfde89a27a70835231f239f9f25c1bbf80d3d41c951d25','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea7142968c1dd8bdf73676fe3e537986a8608e68cf51b238d9b6d71542cdd7c6',1996,'UZ','Uzbekistan','geography',851,'*
Location: Ce1.‘ral Asia, north of Afghanistan
Geographic coordinates: 4] 00 N, 64 00 E
Map references: Commonwealth of
Independent States
Area:
total area: 447,400 sq km
land area: 425,400 sq km
comparative area: slightly larger than
California
Land boundaries:
total: 6,221 km
border countries: Afghanistan 137 km.
Kazakstan 2,203 km, Kyrgyzstan 1,099 km,
Tajikistan 1,161 km, Turkmenistan 1.62! km
Coastline: 0 km
note; Uzbekistan borders the Aral Sea (420
km)
Maritime claims: none (landlocked)
International disputes: none
Climate: mostly midlatitude desert, long, hot
summers, mild winters; semiarid grassland in
east
Terrain: mostly flat-to-rolling sandy desert
with dunes; broad, flat intensely irrigated
river valleys along course of Amu Darya and
Sirdaryo; Fergana Valley in east surrounded
by mountainous Tajikistan and Kyrgyzstan;
shrinking Aral Sea in west
lowest point: Sarygamish Kuli -12 m
highest point: Adelunga Toghi 4.301 m
Natural resources: natural gas, petroleum.
coal, gold, uranium, silver, copper, lead and
zinc, tungsten, molybdenum
Land use:
arable land: 10%
permanent crops: \\%
meadows and pastures: 47%
forest and woodland: 0%
other: 42%
Irrigated land: 41.550 sq km (1990)','f5a6618f09ea37867a9381afe62c79956e3bcf33340bb2881206f0559077c8b8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ed2db12a2f27fd80731d72898834cb219516d3e658e31f8a6c73867d185f357',1996,'VU','Vanuatu','geography',858,'Location: Oceania, group of islands 1n the
South Pacific Ocean, about three-quarters of
the way from Hawai to Australia
Geographic coordinates: 16 00 S, 167 0OE
Map references: Oceania
Area:
total area: 14.760 sq km
land area: 14.760 sq km
comparative area: slightly ''arger than
Connecticut
note: includes more than SU islands
Land boundaries: {) km
Coastline: 2.528 km
Maritime claims: measured from claimed
archipelagic baselines
contiguous zene: 24 nm
continental shelf: 200 nm or to the edge of
the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims Matthew and
Hunter Islands east of New Caledonia
Climate: tropical; moderated by southeast
trade winds
Te: rain: mostly mountains of volcanic
origin; narrow coastal plains
lowest point: Pacific Ocean 0 m
highest point: Mount Tabwemasana 1,877 m
Natural resources: manganese, hardwood
forests, fish
Land use:
arable land: \\%
permanent crops: 5%
meadows and pastures: 2%
forest and woodiand: 1%
other: 91%
Irrigated land: NA sq km','52178c8ec3a54b314853702da4644b3b06f75c279ac2b3659964f48ce8e19644','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c8eb6a64f653de4f7e07de802ed190a73330d7f0a0faede802a9d64682fde8c',1996,'CO','Colombia','geography',864,'Location: Northern South: America.
bordering the Caribbean Sea and the North
Atlantic Ocean, between Colombia and','e1e97c9af8bc43e54442e8af4923154859ac36bf2e338c1c7ae5625837c6b15d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75e34fb014b5737d9446f789aa731934251c4abb6149e1d1e5a7320b11930f95',1996,'GY','Guyana','geography',865,'Geographic coordinates: & 00 N. 66 00 W
Map references: South America
Area:
total area: 912.050 sq km
land area: 882,050 sq km
comparative area: slightly more than twice
the size of California
Land boundaries:
total: 4.993 km
border countries: Brazil 2.200 km, Colombia
2.050 km, Guyana 743 km
Coastline: 2.800 km
Maritime claims:
contiguous zone: 1S nm
continental shelf: 200-m depth or to the
depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes of
Guyana west of the Esscqe: «> iver:
maritime boundary dispute with Colombia in
the Gull of Venezuela
Climate: tropical, hot, humid, more
moderate in highlands
Terrain: Andes Mountains and Maracaibo
Lowlands in northwest: central plains
(anos); Guiana Highlands in southeast
lowest point: Caribbean Sea 0 m
highest point: Pico Bolivar (La Columna)
5.007 m
Natural resources: detroleum, natural gas.
iron ore gold, bauxite, other minerals,
hydropower, diamonds
Land use:
arable land: 3%
510
permanent crops: \\%
meadows and pastures: 20%
forest and woodland: 39%
other: 37%
Irrigated land: 2.640 sq km (1989 est.)
Location: Southeastern Asia, bordering the
Gult of Thailand, Gulf of Tonkin, and South
China Sea. between China and Cambodia
Geographic coordinates: 16 00 N, 106 00
bE
Map references: Southeast Asia
Area:
total area: 329,560 sq km
land area: 325,360 sq km
comparative area: slightly larger than New','b72d5b6e975aac75d90f38d5c3cfc20ea9023a6a2f30bcf65688143fe5dbc1ef','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2df7980a1b84d4a8dc2a18d37bf4e3eba90356dceda0b67c9d3a75f402a69ec3',1996,'MR','Mauritania','geography',872,'Location: Northern Africa, bordering the
North Atlantic Ocean, between Mauritania
and Morocco
Geographic coordinates: 24 30 N, 13 00 W
Map references: Africa
Area:
total area: 266,000 sq km
land area: 266,000 sq km
comparative area: about the size of
Colorado
Land boundaries:
total: 2,046 km
border countries: Algeria 42 km, Mauritania
1.561 km, Morocco 443 km
Coastline: 1.110 km
Maritime claims: contingent upon resolution
of sovereignty issue
International disputes: claimed and
administered by Morocco, but so. ereignty is
unresolved and the UN is attempting to hold
a referendum on the issue; the UN-
administered cease-fire has been in effect
since September 199]
Climate: hot, dry desert; rain is rare; cold
offshore air currents produce fog and heavy
dew
Terrain: mostly low, flat desert with large
areas of rocky or sandy surfaces rising to
small mountains in south and northeast
lowest point: Sebjet Tah -55 m
highest point: unnamed location 463 m
Natural resources: phosphates, iron ore
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 19%
forest and woodland: 0%
other: 81%
Irrigated land: NA sq km','73311c0473e4a470d9a44ec5ef7ab5d0c024d6c3861acaea7ceb15354b7cca37','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ba5fb9c94ea2265ca0696c79e057786924cdad9f18b0a1c2e63744d02c3b92a',1996,'YE','Yemen','geography',879,'Location: Middle East. bordering the
Arabian Sea, Gulf of Aden, and Red Sea,
between Oman and Saudi Arabia
Geographic coordinates: 15 00 N, 48 00 E
Map references: Middle East
Area:
total area: 527,970 sq km
land area: 527.970 sq km
comparative area. slghtly larger than twice
the size of Wyoming
note: includes Perm, Socotra, the former
Yemen Arab Republic (YAR or North
Yemen), and the former People’s Democratic
Republic of Yemen (PDRY or South
Yemen)
Land boundaries:
total: 1.746 km
border countries; Oman 288 km, Saudi
Arabia 1.458 km
Coastline: |.906 km
Maritime claims:
contiguous zone: 18 nm in the North; 24 nam
in the South
continental shelf: 200 nm or to the edge of
the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 am
International disputes: large section of
boundary with Saudi Arabia not defined: a
dispute with Entrea over sovereignty of the
Hanish Islands in the southern Red Sea has
been submitted to arbitration under the
auspices of the International Court of Justice
Climate: mostly desert; hot and humid along
west coast, temperate in western mountains
affected by seasonal monsoon,
extraordinarily hot, dry, harsh desert in east
Terrain: narrow coastal plain backed by
flat-topped tills and rugged mountains;
dissected upland desert plains in center slope
into the desert interior of the Arabian
Peninsula
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu’ayb 3,760
m
Natural resources: petroleum, fish, rock
salt, marble, small deposits of coal, gold,
lead, nickel, and copper, fertile soil in west
Land use:
arable land: 6%
permanent crops: 0%
meadows and pastures: 30%
forest and woodland: 7%
other: 57%
Irrigated land: 3.100 sq km (1989 est.)','edeb4587d1a5f610f09a16a090fa98581cdd924ea462b4000d294e01e57522df','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d52bf0af94932796ef95f3532dbb5b293b2709d32ce5361b182c1b8f30269b28',1996,'BW','Botswana','geography',890,'Location: Southern Africa. northeast of
Geographic coordinates: 20 00 S, 30 00 E
Map references: Africa
Area:
total area: 390,580 sq km
land area: 386,670 sq km
comparative area: slightly larger than
Montana
? end boundaries:
total: 3,066 km
border countries: Botswana 813 km,
Mozambique 1.231 km, South Africa 225
km, Zambia 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: quadripoint with
Botswana, Namibia, and Zambia is in
disagreement
Climate: tropical; moderated by altitude:
rainy season (November to March)
Terrain: mostly high plateau with higher
central plateau (high veld); mountains in east
lowest point: junction of the Lundi and Savi
rivers 162 m
highest point: Inyangani 2.592 m
Natural resources: coal, chromium ore.
asbestos, gold, nickel, copper, iron ore.
vanadium, lithium, tin, platinum group
metals
Land use:
arable land: 7%
permanent crops: NEGL (coffee)
meadows and pastures: 13%
forest and woodland: 49%
other: 31%
Irrigated land: 2.250 sq km (1993 est.)','ebb797bc9b50f5b822680cfc2636601b89bf2f22aac8246a807150cc2c090e33','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d58e3ffc1dee681aae1bbed8716139cfca009647d90e0e190f7b6d5dcc995bae',1996,'ZW','Zimbabwe','geography',3,'---------
Location: Southern Asia, north of Pakistan
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area:
total area: 647,500 sq km
land area: 647,500 sq km
comparative area: slightly smaller than Texas
Land boundaries:
total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan 2,430 km,
Tajikistan 1,206 km, Turkmenistan 744 km, Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: periodic disputes with Iran over Helmand
water rights; Iran supports clients in country, private Pakistani
and Saudi sources also are active; power struggles among various
groups for control of Kabul, regional rivalries among emerging
warlords, traditional tribal disputes continue; support to Islamic
fighters in Tajikistan''s civil war; border dispute with Pakistan
(Durand Line); support to Islamic militants worldwide by some
factions
Climate: arid to semiarid; cold winters and hot summers
Terrain: mostly rugged mountains; plains in north and southwest
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal, copper, talc,
barites, sulfur, lead, zinc, iron ore, salt, precious and
semiprecious stones
Land use:
arable land: 12%
permanent crops: 0%
meadows and pastures: 46%
forest and woodland: 3%
other: 39%
Irrigated land: 26,600 sq km (1989 est.)
---------
Location: Southeastern Europe, bordering the Adriatic Sea and
Ionian Sea, between Greece and Serbia and Montenegro
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe
Area:
total area: 28,750 sq km
land area: 27,400 sq km
comparative area: slightly larger than Maryland
Land boundaries:
total: 720 km
border countries: Greece 282 km, The Former Yugoslav Republic of
Macedonia 151 km, Serbia and Montenegro 287 km (114 km with Serbia,
173 km with Montenegro)
Coastline: 362 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 12 nm
International disputes: the Albanian Government supports
protection of the rights of ethnic Albanians outside of its borders;
Albanian majority in Kosovo seeks independence from Serbian
Republic; Albanians in Macedonia claim discrimination in education,
access to public-sector jobs and representation in government;
Albania is involved in negotiations with Greece over border
demarcation, the treatment of Albania''s ethnic Greek minority, and
migrant Albanian workers in Greece
Climate: mild temperate; cool, cloudy, wet winters; hot, clear,
dry summers; interior is cooler and wetter
Terrain: mostly mountains and hills; small plains along coast
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit 2,753 m
Natural resources: petroleum, natural gas, coal, chromium, copper,
timber, nickel
Land use:
arable land: 21%
permanent crops: 4%
meadows and pastures: 15%
forest and woodland: 38%
other: 22%
Irrigated land: 4,230 sq km (1989)
---------
Location: Northern Africa, bordering the Mediterranean Sea,
between Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00 E
Map references: Africa
Area:
total area: 2,381,740 sq km
land area: 2,381,740 sq km
comparative area: slightly less than 3.5 times the size of Texas
Land boundaries:
total: 6,343 km
border countries: Libya 982 km, Mali 1,376 km, Mauritania 463 km,
Morocco 1,559 km, Niger 956 km, Tunisia 965 km, Western Sahara 42 km
Coastline: 998 km
Maritime claims:
exclusive fishing zone: 32-52 nm
territorial sea: 12 nm
International disputes: part of southeastern region claimed by
Libya; land boundary dispute with Tunisia settled in 1993
Climate: arid to semiarid; mild, wet winters with hot, dry summers
along coast; drier with cold winters and hot summers on high
plateau; sirocco is a hot, dust/sand-laden wind especially common in
summer
Terrain: mostly high plateau and desert; some mountains; narrow,
discontinuous coastal plain
lowest point: Chott Melrhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas, iron ore, phosphates,
uranium, lead, zinc
Land use:
arable land: 3%
permanent crops: 0%
meadows and pastures: 13%
forest and woodland: 2%
other: 82%
Irrigated land: 3,360 sq km (1989 est.)
---------
Location: Oceania, group of islands in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Geographic coordinates: 14 20 S, 170 00 W
Map references: Oceania
Area:
total area: 199 sq km
land area: 199 sq km
comparative area: slightly larger than Washington, DC
note: includes Rose Island and Swains Island
Land boundaries: 0 km
Coastline: 116 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical marine, moderated by southeast trade winds;
annual rainfall averages 124 inches; rainy season from November to
April, dry season from May to October; little seasonal temperature
variation
Terrain: five volcanic islands with rugged peaks and limited
coastal plains, two coral atolls (Rose Island, Swains Island)
lowest point: Pacific Ocean 0 m
highest point: Lata 966 m
Natural resources: pumice, pumicite
Land use:
arable land: 10%
permanent crops: 5%
meadows and pastures: 0%
forest and woodland: 75%
other: 10%
Irrigated land: NA sq km
---------
Location: Southwestern Europe, between France and Spain
Geographic coordinates: 42 30 N, 1 30 E
Map references: Europe
Area:
total area: 450 sq km
land area: 450 sq km
comparative area: 2.5 times the size of Washington, DC
Land boundaries:
total: 125 km
border countries: France 60 km, Spain 65 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: temperate; snowy, cold winters and warm, dry summers
Terrain: rugged mountains dissected by narrow valleys
lowest point: Riu Valira 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral water, timber, iron ore,
lead
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 56%
forest and woodland: 22%
other: 20%
Irrigated land: NA sq km
---------
Location: Southern Africa, bordering the South Atlantic Ocean,
between Namibia and Zaire
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area:
total area: 1,246,700 sq km
land area: 1,246,700 sq km
comparative area: slightly less than twice the size of Texas
Land boundaries:
total: 5,198 km
border countries: Congo 201 km, Namibia 1,376 km, Zaire 2,511 km,
Zambia 1,110 km
Coastline: 1,600 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 20 nm
International disputes: none
Climate: semiarid in south and along coast to Luanda; north has
cool, dry season (May to October) and hot, rainy season (November to
April)
Terrain: narrow coastal plain rises abruptly to vast interior
plateau
lowest point: Atlantic Ocean 0 m
highest point: Moro de Moco 2,620 m
Natural resources: petroleum, diamonds, iron ore, phosphates,
copper, feldspar, gold, bauxite, uranium
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 23%
forest and woodland: 43%
other: 32%
Irrigated land: NA sq km
---------
Location: Caribbean, island in the Caribbean Sea, east of Puerto
Rico
Geographic coordinates: 18 15 N, 63 10 W
Map references: Central America and the Caribbean
Area:
total area: 91 sq km
land area: 91 sq km
comparative area: about half the size of Washington, DC
Land boundaries: 0 km
Coastline: 61 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical; moderated by northeast trade winds
Terrain: flat and low-lying island of coral and limestone
lowest point: Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt, fish, lobster
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA% (mostly rock with sparse scrub oak, few trees, some
commercial salt ponds)
Irrigated land: NA sq km
---------
Location: continent mostly south of the Antarctic Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area:
total area: 14 million sq km (est.)
land area: 14 million sq km (est.)
comparative area: slightly less than 1.5 times the size of the US
note: second-smallest continent (after Australia)
Land boundaries: 0 km
note: see entry on International disputes
Coastline: 17,968 km
Maritime claims: none, but see entry on International disputes
International disputes: Antarctic Treaty defers claims (see
Antarctic Treaty Summary below); sections (some overlapping) claimed
by Argentina, Australia, Chile, France (Adelie Land), New Zealand
(Ross Dependency), Norway (Queen Maud Land), and UK; the US and most
other nations do not recognize the territorial claims of other
nations and have made no claims themselves (the US reserves the
right to do so); no formal claims have been made in the sector
between 90 degrees west and 150 degrees west
Climate: severe low temperatures vary with latitude, elevation,
and distance from the ocean; East Antarctica is colder than West
Antarctica because of its higher elevation; Antarctic Peninsula has
the most moderate climate; higher temperatures occur in January
along the coast and average slightly below freezing
Terrain: about 98% thick continental ice sheet and 2% barren rock,
with average elevations between 2,000 and 4,000 meters; mountain
ranges up to about 5,000 meters; ice-free coastal areas include
parts of southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo Sound; glaciers
form ice shelves along about half of the coastline, and floating ice
shelves constitute 11% of the area of the continent
lowest point: Indian Ocean 0 m
highest point: Vinson Massif 5,140 m
Natural resources: none presently exploited; iron ore, chromium,
copper, gold, nickel, platinum and other minerals, and coal and
hydrocarbons have been found in small, uncommercial quantities
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (ice 98%, barren rock 2%)
Irrigated land: 0 sq km
---------
Location: Caribbean, islands between the Caribbean Sea and the
North Atlantic Ocean, east-southeast of Puerto Rico
Geographic coordinates: 17 03 N, 61 48 W
Map references: Central America and the Caribbean
Area:
total area: 440 sq km
land area: 440 sq km
comparative area: 2.5 times the size of Washington, DC
note: includes Redonda
Land boundaries: 0 km
Coastline: 153 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical marine; little seasonal temperature variation
Terrain: mostly low-lying limestone and coral islands with some
higher volcanic areas
lowest point: Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: negligible; pleasant climate fosters tourism
Land use:
arable land: 18%
permanent crops: 0%
meadows and pastures: 7%
forest and woodland: 16%
other: 59%
Irrigated land: NA sq km
---------
Location: body of water mostly north of the Arctic Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic Region
Area:
total area: 14.056 million sq km
comparative area: slightly more than 1.5 times the size of the US;
smallest of the world''s four oceans (after Pacific Ocean, Atlantic
Ocean, and Indian Ocean)
note: includes Baffin Bay, Barents Sea, Beaufort Sea, Chukchi Sea,
East Siberian Sea, Greenland Sea, Hudson Bay, Hudson Strait, Kara
Sea, Laptev Sea, Northwest Passage, and other tributary water bodies
Coastline: 45,389 km
International disputes: some maritime disputes (see littoral
states); Svalbard is the focus of a maritime boundary dispute
between Norway and Russia
Climate: polar climate characterized by persistent cold and
relatively narrow annual temperature ranges; winters characterized
by continuous darkness, cold and stable weather conditions, and
clear skies; summers characterized by continuous daylight, damp and
foggy weather, and weak cyclones with rain or snow
Terrain: central surface covered by a perennial drifting polar
icepack that averages about 3 meters in thickness, although pressure
ridges may be three times that size; clockwise drift pattern in the
Beaufort Gyral Stream, but nearly straight line movement from the
New Siberian Islands (Russia) to Denmark Strait (between Greenland
and Iceland); the icepack is surrounded by open seas during the
summer, but more than doubles in size during the winter and extends
to the encircling land masses; the ocean floor is about 50%
continental shelf (highest percentage of any ocean) with the
remainder a central basin interrupted by three submarine ridges
(Alpha Cordillera, Nansen Cordillera, and Lomonsov Ridge)
lowest point: Fram Basin -4,665 m
highest point: sea level 0 m
Natural resources: sand and gravel aggregates, placer deposits,
polymetallic nodules, oil and gas fields, fish, marine mammals
(seals and whales)
---------
Location: Southern South America, bordering the South Atlantic
Ocean, between Chile and Uruguay
Geographic coordinates: 34 00 S, 64 00 W
Map references: South America
Area:
total area: 2,766,890 sq km
land area: 2,736,690 sq km
comparative area: slightly less than three-tenths the size of the US
Land boundaries:
total: 9,665 km
border countries: Bolivia 832 km, Brazil 1,224 km, Chile 5,150 km,
Paraguay 1,880 km, Uruguay 579 km
Coastline: 4,989 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: short section of the boundary with Uruguay
is in dispute; short section of the boundary with Chile is
indefinite; claims British-administered Falkland Islands (Islas
Malvinas); claims British-administered South Georgia and the South
Sandwich Islands; territorial claim in Antarctica
Climate: mostly temperate; arid in southeast; subantarctic in
southwest
Terrain: rich plains of the Pampas in northern half, flat to
rolling plateau of Patagonia in south, rugged Andes along western
border
lowest point: Salinas Chicas -40 m
highest point: Cerro Aconcagua 6,962 m
Natural resources: fertile plains of the pampas, lead, zinc, tin,
copper, iron ore, manganese, petroleum, uranium
Land use:
arable land: 9%
permanent crops: 4%
meadows and pastures: 52%
forest and woodland: 22%
other: 13%
Irrigated land: 17,600 sq km (1989 est.)
---------
Location: Southwestern Asia, east of Turkey
Geographic coordinates: 40 00 N, 45 00 E
Map references: Commonwealth of Independent States
Area:
total area: 29,800 sq km
land area: 28,400 sq km
comparative area: slightly larger than Maryland
Land boundaries:
total: 1,254 km
border countries: Azerbaijan-proper 566 km, Azerbaijan-Naxcivan
exclave 221 km, Georgia 164 km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: supports ethnic Armenians in
Nagorno-Karabakh in their separatist conflict against the
Azerbaijani Government; traditional demands on former Armenian lands
in Turkey have subsided
Climate: highland continental, hot summers, cold winters
Terrain: high Armenian Plateau with mountains; little forest land;
fast flowing rivers; good soil in Aras River valley
lowest point: Debed River 400 m
highest point: Aragats Lerr 4,095 m
Natural resources: small deposits of gold, copper, molybdenum,
zinc, alumina
Land use:
arable land: 17%
permanent crops: 3%
meadows and pastures: 20%
forest and woodland: 0%
other: 60%
Irrigated land: 3,050 sq km (1990)
---------
Location: Caribbean, island in the Caribbean Sea, north of
Venezuela
Geographic coordinates: 12 30 N, 69 58 W
Map references: Central America and the Caribbean
Area:
total area: 193 sq km
land area: 193 sq km
comparative area: slightly larger than Washington, DC
Land boundaries: 0 km
Coastline: 68.5 km
Maritime claims:
territorial sea: 12 nm
International disputes: none
Climate: tropical marine; little seasonal temperature variation
Terrain: flat with a few hills; scant vegetation
lowest point: Caribbean Sea 0 m
highest point: Mount Jamanota 188 m
Natural resources: negligible; white sandy beaches
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km
---------
Location: Southeastern Asia, islands in the Indian Ocean,
northwest of Australia
Geographic coordinates: 12 14 S, 123 05 E
Map references: Southeast Asia
Area:
total area: 5 sq km
land area: 5 sq km
comparative area: about eight times the size of The Mall in
Washington, DC
note: includes Ashmore Reef (West, Middle, and East Islets) and
Cartier Island
Land boundaries: 0 km
Coastline: 74.1 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical
Terrain: low with sand and coral
lowest point: Indian Ocean 0 m
highest point: unnamed location 3 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (all grass and sand)
Irrigated land: 0 sq km
---------
Location: body of water between Africa, Europe, Antarctica, and
the Western Hemisphere
Geographic coordinates: 0 00 N, 25 00 W
Map references: World
Area:
total area: 82.217 million sq km
comparative area: slightly less than nine times the size of the US;
second-largest of the world''s four oceans (after the Pacific Ocean,
but larger than Indian Ocean or Arctic Ocean)
note: includes Baltic Sea, Black Sea, Caribbean Sea, Davis Strait,
Denmark Strait, Drake Passage, Gulf of Mexico, Mediterranean Sea,
North Sea, Norwegian Sea, Scotia Sea, Weddell Sea, and other
tributary water bodies
Coastline: 111,866 km
International disputes: some maritime disputes (see littoral
states)
Climate: tropical cyclones (hurricanes) develop off the coast of
Africa near Cape Verde and move westward into the Caribbean Sea;
hurricanes can occur from May to December, but are most frequent
from August to November
Terrain: surface usually covered with sea ice in Labrador Sea,
Denmark Strait, and Baltic Sea from October to June; clockwise warm
water gyre (broad, circular system of currents) in the northern
Atlantic, counterclockwise warm water gyre in the southern Atlantic;
the ocean floor is dominated by the Mid-Atlantic Ridge, a rugged
north-south centerline for the entire Atlantic basin
lowest point: Puerto Rico Trench -8,605 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, marine mammals (seals
and whales), sand and gravel aggregates, placer deposits,
polymetallic nodules, precious stones
---------
Location: Oceania, continent between the Indian Ocean and the
South Pacific Ocean
Geographic coordinates: 27 00 S, 133 00 E
Map references: Oceania
Area:
total area: 7,686,850 sq km
land area: 7,617,930 sq km
comparative area: slightly smaller than the US
note: includes Macquarie Island
Land boundaries: 0 km
Coastline: 25,760 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: territorial claim in Antarctica
(Australian Antarctic Territory)
Climate: generally arid to semiarid; temperate in south and east;
tropical in north
Terrain: mostly low plateau with deserts; fertile plain in
southeast
lowest point: Lake Eyre -15 m
highest point: Mount Kosciusko 2,229 m
Natural resources: bauxite, coal, iron ore, copper, tin, silver,
uranium, nickel, tungsten, mineral sands, lead, zinc, diamonds,
natural gas, petroleum
Land use:
arable land: 6%
permanent crops: 0%
meadows and pastures: 58%
forest and woodland: 14%
other: 22%
Irrigated land: 18,800 sq km (1989 est.)
---------
Location: Central Europe, north of Italy
Geographic coordinates: 47 20 N, 13 20 E
Map references: Europe
Area:
total area: 83,850 sq km
land area: 82,730 sq km
comparative area: slightly smaller than Maine
Land boundaries:
total: 2,558 km
border countries: Czech Republic 362 km, Germany 784 km, Hungary 366
km, Italy 430 km, Liechtenstein 37 km, Slovakia 91 km, Slovenia 324
km, Switzerland 164 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: temperate; continental, cloudy; cold winters with
frequent rain in lowlands and snow in mountains; cool summers with
occasional showers
Terrain: in the west and south mostly mountains (Alps); along the
eastern and northern margins mostly flat or gently sloping
lowest point: Neusiedler See 115 m
highest point: Grossglockner 3,797 m
Natural resources: iron ore, oil, timber, magnesite, lead, coal,
lignite, copper, hydropower
Land use:
arable land: 17%
permanent crops: 1%
meadows and pastures: 24%
forest and woodland: 39%
other: 19%
Irrigated land: 40 sq km (1989)
---------
Location: Southwestern Asia, bordering the Caspian Sea, between
Iran and Russia
Geographic coordinates: 40 30 N, 47 30 E
Map references: Commonwealth of Independent States
Area:
total area: 86,600 sq km
land area: 86,100 sq km
comparative area: slightly larger than Maine
note: includes the exclave of Naxcivan Autonomous Republic and the
Nagorno-Karabakh region; the region''s autonomy was abolished by
Azerbaijani Supreme Soviet on 26 November 1991
Land boundaries:
total: 2,013 km
border countries: Armenia (with Azerbaijan-proper) 566 km, Armenia
(with Azerbaijan-Naxcivan exclave) 221 km, Georgia 322 km, Iran
(with Azerbaijan-proper) 432 km, Iran (with Azerbaijan-Naxcivan
exclave) 179 km, Russia 284 km, Turkey 9 km
Coastline: 0 km (landlocked)
note: Azerbaijan borders the Caspian Sea (800 km, est.)
Maritime claims: none (landlocked)
International disputes: violent and longstanding dispute with
ethnic Armenians of Nagorno-Karabakh over its status; Caspian Sea
boundaries are not yet determined
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Lowland (much of it below sea level)
with Great Caucasus Mountains to the north, Qarabag (Karabakh)
Upland in west; Baku lies on Abseron (Apsheron) Peninsula that juts
into Caspian Sea
lowest point: Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural gas, iron ore, nonferrous
metals, alumina
Land use:
arable land: 18%
permanent crops: 4%
meadows and pastures: 25%
forest and woodland: 0%
other: 53%
Irrigated land: 14,010 sq km (1990)
---------
Location: Middle East, archipelago in the Persian Gulf, east of','19dce52ee2b2016a7fecbb2cfe15edd0082ce192c14bbdf794efd2aa504cde60','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7774b76cdefb6cedc57da7fb9784b8bf3996c553a4fd91dab1f072bcddec81fb',1996,'SA','Saudi Arabia','geography',13,'Geographic coordinates: 26 00 N, 50 33 E
Map references: Middle East
Area:
total area: 620 sq km
land area: 620 sq km
comparative area: 3.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 161 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: extending to boundaries to be determined
territorial sea: 12 nm
International disputes: territorial dispute with Qatar over the
Hawar Islands; maritime boundary with Qatar
Climate: arid; mild, pleasant winters; very hot, humid summers
Terrain: mostly low desert plain rising gently to low central
escarpment
lowest point: Persian Gulf 0 m
highest point: Jabal ad Dukhan 122 m
Natural resources: oil, associated and nonassociated natural gas,
fish
Land use:
arable land: 2%
permanent crops: 2%
meadows and pastures: 6%
forest and woodland: 0%
other: 90%
Irrigated land: 10 sq km (1989 est.)
---------
Location: Oceania, atoll in the North Pacific Ocean, about
one-half of the way from Hawaii to Australia
Geographic coordinates: 0 13 N, 176 31 W
Map references: Oceania
Area:
total area: 1.4 sq km
land area: 1.4 sq km
comparative area: about 2.5 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 4.8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: equatorial; scant rainfall, constant wind, burning sun
Terrain: low, nearly level coral island surrounded by a narrow
fringing reef
lowest point: Pacific Ocean 0 m
highest point: unnamed location 8 m
Natural resources: guano (deposits worked until 1891)
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Southern Asia, bordering the Bay of Bengal, between
Burma and India
Geographic coordinates: 24 00 N, 90 00 E
Map references: Asia
Area:
total area: 144,000 sq km
land area: 133,910 sq km
comparative area: slightly smaller than Wisconsin
Land boundaries:
total: 4,246 km
border countries: Burma 193 km, India 4,053 km
Coastline: 580 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: up to the outer limits of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: a portion of the boundary with India in
dispute; water-sharing problems with upstream riparian India over
the Ganges
Climate: tropical; cool, dry winter (October to March); hot, humid
summer (March to June); cool, rainy monsoon (June to October)
Terrain: mostly flat alluvial plain; hilly in southeast
lowest point: Indian Ocean 0 m
highest point: Reng Tlang 957 m
Natural resources: natural gas, arable land, timber
Land use:
arable land: 67%
permanent crops: 2%
meadows and pastures: 4%
forest and woodland: 16%
other: 11%
Irrigated land: 27,380 sq km (1989)
---------
Location: Caribbean, island between the Caribbean Sea and the
North Atlantic Ocean, northeast of Venezuela
Geographic coordinates: 13 10 N, 59 32 W
Map references: Central America and the Caribbean
Area:
total area: 430 sq km
land area: 430 sq km
comparative area: 2.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 97 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; rainy season (June to October)
Terrain: relatively flat; rises gently to central highland region
lowest point: Atlantic Ocean 0 m
highest point: Mount Hillaby 336 m
Natural resources: petroleum, fish, natural gas
Land use:
arable land: 77%
permanent crops: 0%
meadows and pastures: 9%
forest and woodland: 0%
other: 14%
Irrigated land: NA sq km
---------
Location: Southern Africa, islands in the southern Mozambique
Channel, about one-half of the way from Madagascar to Mozambique
Geographic coordinates: 21 30 S, 39 50 E
Map references: Africa
Area:
total area: 0.2 sq km
land area: 0.2 sq km
comparative area: about one-third the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by Madagascar
Climate: tropical
Terrain: a volcanic rock 2.4 meters high
lowest point: Indian Ocean 0 m
highest point: unnamed location 3 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (all rock)
Irrigated land: 0 sq km
---------
Location: Eastern Europe, east of Poland
Geographic coordinates: 53 00 N, 28 00 E
Map references: Commonwealth of Independent States
Area:
total area: 207,600 sq km
land area: 207,600 sq km
comparative area: slightly smaller than Kansas
Land boundaries:
total: 3,098 km
border countries: Latvia 141 km, Lithuania 502 km, Poland 605 km,
Russia 959 km, Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: cold winters, cool and moist summers; transitional
between continental and maritime
Terrain: generally flat and contains much marshland
lowest point: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: forests, peat deposits, small quantities of oil
and natural gas
Land use:
arable land: 29%
permanent crops: 1%
meadows and pastures: 15%
forest and woodland: 0%
other: 55%
Irrigated land: 1,490 sq km (1990)
---------
Location: Western Europe, bordering the North Sea, between France
and the Netherlands
Geographic coordinates: 50 50 N, 4 00 E
Map references: Europe
Area:
total area: 30,510 sq km
land area: 30,230 sq km
comparative area: slightly larger than Maryland
Land boundaries:
total: 1,385 km
border countries: France 620 km, Germany 167 km, Luxembourg 148 km,
Netherlands 450 km
Coastline: 64 km
Maritime claims:
continental shelf: median line with neighbors
exclusive fishing zone: median line with neighbors (extends about 68
km from coast)
territorial sea: 12 nm
International disputes: none
Climate: temperate; mild winters, cool summers; rainy, humid,
cloudy
Terrain: flat coastal plains in northwest, central rolling hills,
rugged mountains of Ardennes Forest in southeast
lowest point: North Sea 0 m
highest point: Signal de Botrange 694 m
Natural resources: coal, natural gas
Land use:
arable land: 24%
permanent crops: 1%
meadows and pastures: 20%
forest and woodland: 21%
other: 34%
Irrigated land: 10 sq km (1989 est.)
---------
Location: Middle America, bordering the Caribbean Sea, between
Guatemala and Mexico
Geographic coordinates: 17 15 N, 88 45 W
Map references: Central America and the Caribbean
Area:
total area: 22,960 sq km
land area: 22,800 sq km
comparative area: slightly larger than Massachusetts
Land boundaries:
total: 516 km
border countries: Guatemala 266 km, Mexico 250 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm in the north, 3 nm in the south; note - from
the mouth of the Sarstoon River to Ranguana Cay, Belize''s
territorial sea is 3 nm; according to Belize''s Maritime Areas Act,
1992, the purpose of this limitation is to provide a framework for
the negotiation of a definitive agreement on territorial differences
with Guatemala
International disputes: border with Guatemala in dispute; talks to
resolve the dispute are stalled
Climate: tropical; very hot and humid; rainy season (May to
February)
Terrain: flat, swampy coastal plain; low mountains in south
lowest point: Caribbean Sea 0 m
highest point: Victoria Peak 1,160 m
Natural resources: arable land potential, timber, fish
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 2%
forest and woodland: 44%
other: 52%
Irrigated land: 20 sq km (1989 est.)
---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Nigeria and Togo
Geographic coordinates: 9 30 N, 2 15 E
Map references: Africa
Area:
total area: 112,620 sq km
land area: 110,620 sq km
comparative area: slightly smaller than Pennsylvania
Land boundaries:
total: 1,989 km
border countries: Burkina Faso 306 km, Niger 266 km, Nigeria 773 km,
Togo 644 km
Coastline: 121 km
Maritime claims:
territorial sea: 200 nm
International disputes: none
Climate: tropical; hot, humid in south; semiarid in north
Terrain: mostly flat to undulating plain; some hills and low
mountains
lowest point: Atlantic Ocean 0 m
highest point: Mount Tanekas 641 m
Natural resources: small offshore oil deposits, limestone, marble,
timber
Land use:
arable land: 12%
permanent crops: 4%
meadows and pastures: 4%
forest and woodland: 35%
other: 45%
Irrigated land: 60 sq km (1989 est.)
Geographic coordinates: 25 30 N, 51 15 E
Map references: Middle East
Area:
total area: 11,000 sq km
land area: 11,000 sq km
comparative area: slightly smaller than Connecticut
Land boundaries:
total: 60 km
border country: Saudi Arabia 60 km
Coastline: 563 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: territorial dispute with Bahrain over the
Hawar Islands; maritime boundary with Bahrain; 1965 boundary with
Saudi Arabia, renegotiated and revised in 1992, but not official
depiction
Climate: desert; hot, dry; humid and sultry in summer
Terrain: mostly flat and barren desert covered with loose sand and
gravel
lowest point: Persian Gulf 0 m
highest point: Qurayn Aba al Bawl 103 m
Natural resources: petroleum, natural gas, fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 5%
forest and woodland: 0%
other: 95%
Irrigated land: NA sq km
---------
Location: Southern Africa, island in the Indian Ocean, east of','669d6d6027756274b7c4e7c87809d4c3a8d54d7545e67f3f21239ed2b5a60afc','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d421583bdb4028ccfd0772fd5406783d373a9d87b02cde4ee9cd3680545f6ca',1996,'HK','Hong Kong','geography',25,'---------
Location: North America, group of islands in the North Atlantic
Ocean, east of North Carolina (US)
Geographic coordinates: 32 20 N, 64 45 W
Map references: North America
Area:
total area: 50 sq km
land area: 50 sq km
comparative area: about 0.3 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 103 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: subtropical; mild, humid; gales, strong winds common in
winter
Terrain: low hills separated by fertile depressions
lowest point: Atlantic Ocean 0 m
highest point: Town Hill 76 m
Natural resources: limestone, pleasant climate fostering tourism
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 20%
other: 80%
Irrigated land: NA sq km','4828a4405083009f8d859d20473f4d1d23bf49b822dd8db4c856505c70f3bf16','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03cbc0245026ce081d7abaa3cead935efa1bd9718c4957402efc03bef6c945ac',1996,'IN','India','geography',30,'---------
Location: Southern Asia, between China and India
Geographic coordinates: 27 30 N, 90 30 E
Map references: Asia
Area:
total area: 47,000 sq km
land area: 47,000 sq km
comparative area: slightly more than half the size of Indiana
Land boundaries:
total: 1,075 km
border countries: China 470 km, India 605 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: varies; tropical in southern plains; cool winters and hot
summers in central valleys; severe winters and cool summers in
Himalayas
Terrain: mostly mountainous with some fertile valleys and savanna
lowest point: Dangme Chu 97 m
highest point: Khula Kangri I 7,553 m
Natural resources: timber, hydropower, gypsum, calcium carbide
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 5%
forest and woodland: 70%
other: 23%
Irrigated land: 340 sq km (1989 est.)
territorial sea: 12 nm
International disputes: none
Climate: tropical; hot, humid; dry, northeast monsoon (November to
March); rainy, southwest monsoon (June to August)
Terrain: flat
lowest point: Indian Ocean 0 m
highest point: unnamed location on Wilingili 24 m
Natural resources: fish
Land use:
arable land: 10%
permanent crops: 0%
meadows and pastures: 3%
forest and woodland: 3%
other: 84%
Irrigated land: NA sq km
---------
Location: Western Africa, southwest of Algeria
Geographic coordinates: 17 00 N, 4 00 W
Map references: Africa
Area:
total area: 1.24 million sq km
land area: 1.22 million sq km
comparative area: slightly less than twice the size of Texas
Land boundaries:
total: 7,243 km
border countries: Algeria 1,376 km, Burkina Faso 1,000 km, Guinea
858 km, Cote d''Ivoire 532 km, Mauritania 2,237 km, Niger 821 km,
Senegal 419 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: the disputed international boundary
between Burkina Faso and Mali was submitted to the International
Court of Justice (ICJ) in October 1983 and the ICJ issued its final
ruling in December 1986, which both sides agreed to accept; Burkina
Faso and Mali are proceeding with boundary demarcation, including
the tripoint with Niger
Climate: subtropical to arid; hot and dry February to June; rainy,
humid, and mild June to November; cool and dry November to February
Terrain: mostly flat to rolling northern plains covered by sand;
savanna in south, rugged hills in northeast
lowest point: Senegal River 23 m
highest point: Hombori Tondo 1,155 m
Natural resources: gold, phosphates, kaolin, salt, limestone,
uranium, bauxite, iron ore, manganese, tin, and copper deposits are
known but not exploited
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 25%
forest and woodland: 7%
other: 66%
Irrigated land: 50 sq km (1989 est.)
---------
Location: Southern Europe, islands in the Mediterranean Sea, south
of Sicily (Italy)
Geographic coordinates: 35 50 N, 14 35 E
Map references: Europe
Area:
total area: 320 sq km
land area: 320 sq km
comparative area: less than twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 140 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 25 nm
territorial sea: 12 nm
International disputes: Malta and Tunisia are discussing the
commercial exploitation of the continental shelf between their
countries, particularly for oil exploration
Climate: Mediterranean with mild, rainy winters and hot, dry
summers
Terrain: mostly low, rocky, flat to dissected plains; many coastal
cliffs
lowest point: Mediterranean Sea 0 m
highest point: Dingli Cliffs 245 m
Natural resources: limestone, salt
Land use:
arable land: 38%
permanent crops: 3%
meadows and pastures: 0%
forest and woodland: 0%
other: 59%
Irrigated land: 10 sq km (1989)
---------
Location: Western Europe, island in the Irish Sea, between Great
Britain and Ireland
Geographic coordinates: 54 15 N, 4 30 W
Map references: Europe
Area:
total area: 588 sq km
land area: 588 sq km
comparative area: slightly more than three times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 113 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 12 nm
International disputes: none
Climate: cool summers and mild winters; humid; overcast about half
the time
Terrain: hills in north and south bisected by central valley
lowest point: Irish Sea 0 m
highest point: Snaefell 620 m
Natural resources: lead, iron ore
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA% (extensive arable land and forests)
Irrigated land: NA sq km
---------
Location: Southern Asia, between China and India
Geographic coordinates: 28 00 N, 84 00 E
Map references: Asia
Area:
total area: 140,800 sq km
land area: 136,800 sq km
comparative area: slightly larger than Arkansas
Land boundaries:
total: 2,926 km
border countries: China 1,236 km, India 1,690 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: varies from cool summers and severe winters in north to
subtropical summers and mild winters in south
Terrain: Terai or flat river plain of the Ganges in south, central
hill region, rugged Himalayas in north
lowest point: Kanchan Kalan 70 m
highest point: Mount Everest 8,848 m
Natural resources: quartz, water, timber, hydropower potential,
scenic beauty, small deposits of lignite, copper, cobalt, iron ore
Land use:
arable land: 17%
permanent crops: 0%
meadows and pastures: 13%
forest and woodland: 33%
other: 37%
Irrigated land: 9,430 sq km (1989)
---------
Location: Western Europe, bordering the North Sea, between Belgium
and Germany
Geographic coordinates: 52 30 N, 5 45 E
Map references: Europe
Area:
total area: 37,330 sq km
land area: 33,920 sq km
comparative area: slightly less than twice the size of New Jersey
Land boundaries:
total: 1,027 km
border countries: Belgium 450 km, Germany 577 km
Coastline: 451 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: temperate; marine; cool summers and mild winters
Terrain: mostly coastal lowland and reclaimed land (polders); some
hills in southeast
lowest point: Prins Alexanderpolder -7 m
highest point: Vaalserberg 321 m
Natural resources: natural gas, petroleum, fertile soil
Land use:
arable land: 26%
permanent crops: 1%
meadows and pastures: 32%
forest and woodland: 9%
other: 32%
Irrigated land: 5,500 sq km (1989 est.)
---------
Location: Caribbean, two island groups in the Caribbean Sea - one
includes Curacao and Bonaire north of Venezuela and the other is
east of the Virgin Islands
Geographic coordinates: 12 15 N, 68 45 W
Map references: Central America and the Caribbean
Area:
total area: 960 sq km
land area: 960 sq km
comparative area: more than five times the size of Washington, DC
note: includes Bonaire, Curacao, Saba, Sint Eustatius, and Sint
Maarten (Dutch part of the island of Saint Martin)
Land boundaries: 0 km
Coastline: 364 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; ameliorated by northeast trade winds
Terrain: generally hilly, volcanic interiors
lowest point: Caribbean Sea 0 m
highest point: Mount Scenery 862 m
Natural resources: phosphates (Curacao only), salt (Bonaire only)
Land use:
arable land: 8%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 92%
Irrigated land: NA sq km
---------
Location: Oceania, islands in the South Pacific Ocean, east of','1e1b159f7fd0e6c167970cfe5d11c9a5b890f6f015e180b56d5fa34cb189eaa1','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('639dcbdc1435e7d7dcef9d63a8f6aa0ecb5f6783d4ef5dddf3ecd4043f680924',1996,'BR','Brazil','geography',37,'---------
Location: Central South America, southwest of Brazil
Geographic coordinates: 17 00 S, 65 00 W
Map references: South America
Area:
total area: 1,098,580 sq km
land area: 1,084,390 sq km
comparative area: slightly less than three times the size of Montana
Land boundaries:
total: 6,743 km
border countries: Argentina 832 km, Brazil 3,400 km, Chile 861 km,
Paraguay 750 km, Peru 900 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: has wanted a sovereign corridor to the
South Pacific Ocean since the Atacama area was lost to Chile in
1884; dispute with Chile over Rio Lauca water rights
Climate: varies with altitude; humid and tropical to cold and
semiarid
Terrain: rugged Andes Mountains with a highland plateau
(Altiplano), hills, lowland plains of the Amazon Basin
lowest point: Rio Paraguay 90 m
highest point: Cerro Illimani 6,882 m
Natural resources: tin, natural gas, petroleum, zinc, tungsten,
antimony, silver, iron, lead, gold, timber
Land use:
arable land: 3%
permanent crops: 0%
meadows and pastures: 25%
forest and woodland: 52%
other: 20%
Irrigated land: 1,650 sq km (1989 est.)
---------
Location: Southeastern Europe, bordering the Adriatic Sea and
---------
Location: Western South America, bordering the South Pacific
Ocean, between Chile and Ecuador
Geographic coordinates: 10 00 S, 76 00 W
Map references: South America
Area:
total area: 1,285,220 sq km
land area: 1.28 million sq km
comparative area: slightly smaller than Alaska
Land boundaries:
total: 6,940 km
border countries: Bolivia 900 km, Brazil 1,560 km, Chile 160 km,
Colombia 2,900 km, Ecuador 1,420 km
Coastline: 2,414 km
Maritime claims:
continental shelf: 200 nm
territorial sea: 200 nm
International disputes: three sections of the boundary with
Ecuador are in dispute
Climate: varies from tropical in east to dry desert in west
Terrain: western coastal plain (costa), high and rugged Andes in
center (sierra), eastern lowland jungle of Amazon Basin (selva)
lowest point: Pacific Ocean 0 m
highest point: Nevado Huascaran 6,768 m
Natural resources: copper, silver, gold, petroleum, timber, fish,
iron ore, coal, phosphate, potash
Land use:
arable land: 3%
permanent crops: 0%
meadows and pastures: 21%
forest and woodland: 55%
other: 21%
Irrigated land: 12,500 sq km (1989 est.)
---------
Location: Southeastern Asia, archipelago between the Philippine
Sea and the South China Sea, east of Vietnam
Geographic coordinates: 13 00 N, 122 00 E
Map references: Southeast Asia
Area:
total area: 300,000 sq km
land area: 298,170 sq km
comparative area: slightly larger than Arizona
Land boundaries: 0 km
Coastline: 36,289 km
Maritime claims: measured from claimed archipelagic baselines
continental shelf: to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: irregular polygon extending up to 100 nm from
coastline as defined by 1898 treaty; since late 1970s has also
claimed polygonal-shaped area in South China Sea up to 285 nm in
breadth
International disputes: involved in a complex dispute over the
Spratly Islands with China, Malaysia, Taiwan, Vietnam, and possibly
Brunei; claims Malaysian state of Sabah
Climate: tropical marine; northeast monsoon (November to April);
southwest monsoon (May to October)
Terrain: mostly mountains with narrow to extensive coastal lowlands
lowest point: Philippine Sea 0 m
highest point: Mount Apo 2,954 m
Natural resources: timber, petroleum, nickel, cobalt, silver,
gold, salt, copper
Land use:
arable land: 26%
permanent crops: 11%
meadows and pastures: 4%
forest and woodland: 40%
other: 19%
Irrigated land: 16,200 sq km (1989 est.)
---------
Location: Oceania, islands in the South Pacific Ocean, about
one-half of the way from Peru to New Zealand
Geographic coordinates: 25 04 S, 130 06 W
Map references: Oceania
Area:
total area: 47 sq km
land area: 47 sq km
comparative area: about 0.3 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 51 km
Maritime claims:
exclusive fishing zone: 200 nm
exclusive economic zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical, hot, humid, modified by southeast trade winds;
rainy season (November to March)
Terrain: rugged volcanic formation; rocky coastline with cliffs
lowest point: Pacific Ocean 0 m
highest point: Pawala Valley Ridge 347 m
Natural resources: miro trees (used for handicrafts), fish
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
---------
Location: Central Europe, east of Germany
Geographic coordinates: 52 00 N, 20 00 E
Map references: Europe
Area:
total area: 312,683 sq km
land area: 304,510 sq km
comparative area: slightly smaller than New Mexico
Land boundaries:
total: 2,888 km
border countries: Belarus 605 km, Czech Republic 658 km, Germany 456
km, Lithuania 91 km, Russia (Kaliningrad Oblast) 206 km, Slovakia
444 km, Ukraine 428 km
Coastline: 491 km
Maritime claims:
exclusive economic zone: defined by international treaties
territorial sea: 12 nm
International disputes: none
Climate: temperate with cold, cloudy, moderately severe winters
with frequent precipitation; mild summers with frequent showers and
thundershowers
Terrain: mostly flat plain; mountains along southern border
lowest point: Raczki Elblaskie -2 m
highest point: Rysy 2,499 m
Natural resources: coal, sulfur, copper, natural gas, silver,
lead, salt
Land use:
arable land: 48%
permanent crops: 0%
meadows and pastures: 13%
forest and woodland: 29%
other: 10% (1992)
Irrigated land: 1,000 sq km (1989 est.)
---------
Location: Southwestern Europe, bordering the North Atlantic Ocean,
west of Spain
Geographic coordinates: 39 30 N, 8 00 W
Map references: Europe
Area:
total area: 92,080 sq km
land area: 91,640 sq km
comparative area: slightly smaller than Indiana
note: includes Azores and Madeira Islands
Land boundaries:
total: 1,214 km
border country: Spain 1,214 km
Coastline: 1,793 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: sovereignty over Timor Timur (East Timor
Province) disputed with Indonesia and not recognized by the UN
Climate: maritime temperate; cool and rainy in north, warmer and
drier in south
Terrain: mountainous north of the Tagus, rolling plains in south
lowest point: Atlantic Ocean 0 m
highest point: Ponta do Pico in Azores 2,351 m
Natural resources: fish, forests (cork), tungsten, iron ore,
uranium ore, marble
Land use:
arable land: 32%
permanent crops: 6%
meadows and pastures: 6%
forest and woodland: 40%
other: 16%
Irrigated land: 6,340 sq km (1989 est.)
---------
Location: Caribbean, island between the Caribbean Sea and the
North Atlantic Ocean, east of the Dominican Republic
Geographic coordinates: 18 15 N, 66 30 W
Map references: Central America and the Caribbean
Area:
total area: 9,104 sq km
land area: 8,959 sq km
comparative area: slightly less than three times the size of Rhode
Island
Land boundaries: 0 km
Coastline: 501 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical marine, mild, little seasonal temperature
variation
Terrain: mostly mountains with coastal plain belt in north;
mountains precipitous to sea on west coast; sandy beaches along most
coastal areas
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1,338 m
Natural resources: some copper and nickel, potential for onshore
and offshore oil
Land use:
arable land: 8%
permanent crops: 9%
meadows and pastures: 41%
forest and woodland: 20%
other: 22%
Irrigated land: 390 sq km (1989 est.)
---------
Location: Middle East, peninsula bordering the Persian Gulf and','de3a969014eaaf20c3fdfe27f08c423c612746e8747fc5299db3a36802004ef4','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b33f03aca06a724809d74955f997c55ebec47195f417097f4f3b4e3b7e032e8',1996,'HR','Croatia','geography',44,'Geographic coordinates: 44 00 N, 18 00 E
Map references: Bosnia and Herzegovina, Europe
Area:
total area: 51,233 sq km
land area: 51,233 sq km
comparative area: slightly smaller than West Virginia
Land boundaries:
total: 1,459 km
border countries: Croatia 932 km, Serbia and Montenegro 527 km (312
km with Serbia, 215 km with Montenegro)
Coastline: 20 km
Maritime claims: NA
International disputes: none
Climate: hot summers and cold winters; areas of high elevation
have short, cool summers and long, severe winters; mild, rainy
winters along coast
Terrain: mountains and valleys
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron, bauxite, manganese, forests,
copper, chromium, lead, zinc
Land use:
arable land: 20%
permanent crops: 2%
meadows and pastures: 25%
forest and woodland: 36%
other: 17%
Irrigated land: NA sq km
---------
Location: Southern Africa, north of South Africa
Geographic coordinates: 22 00 S, 24 00 E
Map references: Africa
Area:
total area: 600,370 sq km
land area: 585,370 sq km
comparative area: slightly smaller than Texas
Land boundaries:
total: 4,013 km
border countries: Namibia 1,360 km, South Africa 1,840 km, Zimbabwe
813 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: short section of boundary with Namibia is
indefinite; quadripoint with Namibia, Zambia, and Zimbabwe is in
disagreement; dispute with Namibia over uninhabited Kasikili
(Sidudu) Island in Linyanti (Chobe) River remained unresolved in
January 1996 and the parties have agreed to refer the matter to the
ICJ
Climate: semiarid; warm winters and hot summers
Terrain: predominately flat to gently rolling tableland; Kalahari
Desert in southwest
lowest point: junction of the Limpopo and Shashe Rivers 513 m
highest point: Tsodilo Hill 1,489 m
Natural resources: diamonds, copper, nickel, salt, soda ash,
potash, coal, iron ore, silver
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 75%
forest and woodland: 2%
other: 21%
Irrigated land: 20 sq km (1989 est.)
---------
Location: Southern Africa, island in the South Atlantic Ocean,
south-southwest of the Cape of Good Hope (South Africa)
Geographic coordinates: 54 26 S, 3 24 E
Map references: Antarctic Region
Area:
total area: 58 sq km
land area: 58 sq km
comparative area: about 0.3 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 29.6 km
Maritime claims:
territorial sea: 4 nm
International disputes: none
Climate: antarctic
Terrain: volcanic; maximum elevation about 800 meters; coast is
mostly inaccessible
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 780 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (all ice)
Irrigated land: 0 sq km
---------
Location: Eastern South America, bordering the Atlantic Ocean
Geographic coordinates: 10 00 S, 55 00 W
Map references: South America
Area:
total area: 8,511,965 sq km
land area: 8,456,510 sq km
comparative area: slightly smaller than the US
note: includes Arquipelago de Fernando de Noronha, Atol das Rocas,
Ilha da Trindade, Ilhas Martin Vaz, and Penedos de Sao Pedro e Sao
Paulo
Land boundaries:
total: 14,691 km
border countries: Argentina 1,224 km, Bolivia 3,400 km, Colombia
1,643 km, French Guiana 673 km, Guyana 1,119 km, Paraguay 1,290 km,
Peru 1,560 km, Suriname 597 km, Uruguay 985 km, Venezuela 2,200 km
Coastline: 7,491 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: short section of the boundary with
Paraguay, just west of Salto das Sete Quedas (Guaira Falls) on the
Rio Parana, is in dispute; two short sections of boundary with
Uruguay are in dispute - Arroio Invernada (Arroyo de la Invernada)
area of the Rio Quarai (Rio Cuareim) and the islands at the
confluence of the Rio Quarai and the Uruguay River
Climate: mostly tropical, but temperate in south
Terrain: mostly flat to rolling lowlands in north; some plains,
hills, mountains, and narrow coastal belt
lowest point: Atlantic Ocean 0 m
highest point: Pico da Neblina 3,014 m
Natural resources: bauxite, gold, iron ore, manganese, nickel,
phosphates, platinum, tin, uranium, petroleum, hydropower, timber
Land use:
arable land: 7%
permanent crops: 1%
meadows and pastures: 19%
forest and woodland: 67%
other: 6%
Irrigated land: 27,000 sq km (1989 est.)
---------
Location: Southern Asia, archipelago in the Indian Ocean, about
one-half the way from Africa to Indonesia
Geographic coordinates: 6 00 S, 71 30 E
Map references: World
Area:
total area: 60 sq km
land area: 60 sq km
comparative area: about 0.5 times the size of Washington, DC
note: includes the entire Chagos Archipelago
Land boundaries: 0 km
Coastline: 698 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: the island of Diego Garcia is claimed by','67b0540a4c980b4b9cbe70652288237bd6702f76e1db3956c6a2eececbde943c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a38f6c8ccad3c2a64a6606db81274f2e6a57c3ee176cbe5feab03ebbc66bee8',1996,'MU','Mauritius','geography',51,'Climate: tropical marine; hot, humid, moderated by trade winds
Terrain: flat and low (up to four meters in elevation)
lowest point: Indian Ocean 0 m
highest point: unnamed location on Diego Garcia 15 m
Natural resources: coconuts, fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Caribbean, between the Caribbean Sea and the North
Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 18 30 N, 64 30 W
Map references: Central America and the Caribbean
Area:
total area: 150 sq km
land area: 150 sq km
comparative area: about 0.9 times the size of Washington, DC
note: includes the island of Anegada
Land boundaries: 0 km
Coastline: 80 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: subtropical; humid; temperatures moderated by trade winds
Terrain: coral islands relatively flat; volcanic islands steep,
hilly
lowest point: Caribbean Sea 0 m
highest point: Mount Sage 521 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 7%
meadows and pastures: 33%
forest and woodland: 7%
other: 33%
Irrigated land: NA sq km','6b403cf9922b9019c8f12a29d2f4e016c32c14564c490ba723ce44273b5ff92d','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61f91fa84d8b59323724fe86f425627d176263500f16a23da7ceecfd605563d5',1996,'PR','Puerto Rico','geography',63,'---------
Location: Southeastern Asia, bordering the South China Sea and
Geographic coordinates: 16 45 N, 62 12 W
Map references: Central America and the Caribbean
Area:
total area: 100 sq km
land area: 100 sq km
comparative area: about 0.6 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 40 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical; little daily or seasonal temperature variation
Terrain: volcanic islands, mostly mountainous, with small coastal
lowland
lowest point: Caribbean Sea 0 m
highest point: Chances Peak 914 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 0%
meadows and pastures: 10%
forest and woodland: 40%
other: 30%
Irrigated land: NA sq km','160dfc17d524ae46de89bffb4d09eb2ec56cd58b4b59740d916ed359d34e4f6a','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79b5619b3d584e8536529ccbfa4108ff7d37bdf2a8108badc55bfb6633f6da8f',1996,'MY','Malaysia','geography',64,'Geographic coordinates: 4 30 N, 114 40 E
Map references: Southeast Asia
Area:
total area: 5,770 sq km
land area: 5,270 sq km
comparative area: slightly larger than Delaware
Land boundaries:
total: 381 km
border country: Malaysia 381 km
Coastline: 161 km
Maritime claims:
exclusive economic zone: 200 nm or to median line
territorial sea: 12 nm
International disputes: may wish to purchase the Malaysian salient
that divides the country; all of the Spratly Islands are claimed by
China, Taiwan, and Vietnam; parts of them are claimed by Malaysia
and the Philippines; in 1984, Brunei established an exclusive
fishing zone that encompasses Louisa Reef, but has not publicly
claimed the island
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to mountains in east; hilly
lowland in west
lowest point: South China Sea 0 m
highest point: Bukit Pagon 1,850 m
Natural resources: petroleum, natural gas, timber
Land use:
arable land: 1%
permanent crops: 1%
meadows and pastures: 1%
forest and woodland: 79%
other: 18%
Irrigated land: 10 sq km (1989 est.)
---------
Location: Southeastern Europe, bordering the Black Sea, between
Romania and Turkey
Geographic coordinates: 43 00 N, 25 00 E
Map references: Europe
Area:
total area: 110,910 sq km
land area: 110,550 sq km
comparative area: slightly larger than Tennessee
Land boundaries:
total: 1,808 km
border countries: Greece 494 km, The Former Yugoslav Republic of
Macedonia 148 km, Romania 608 km, Serbia and Montenegro 318 km (all
with Serbia), Turkey 240 km
Coastline: 354 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: temperate; cold, damp winters; hot, dry summers
Terrain: mostly mountains with lowlands in north and southeast
lowest point: Black Sea 0 m
highest point: Musala 2,925 m
Natural resources: bauxite, copper, lead, zinc, coal, timber,
arable land
Land use:
arable land: 34%
permanent crops: 3%
meadows and pastures: 18%
forest and woodland: 35%
other: 10%
Irrigated land: 10 sq km (1989 est.)
---------
Location: Western Africa, north of Ghana
Geographic coordinates: 13 00 N, 2 00 W
Map references: Africa
Area:
total area: 274,200 sq km
land area: 273,800 sq km
comparative area: slightly larger than Colorado
Land boundaries:
total: 3,192 km
border countries: Benin 306 km, Ghana 548 km, Cote d''Ivoire 584 km,
Mali 1,000 km, Niger 628 km, Togo 126 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: following mutual acceptance of an
International Court of Justice (ICJ) ruling in December 1986 on
their international boundary dispute, Burkina Faso and Mali are
proceeding with boundary demarcation, including the tripoint with','207b65c850e1c6ff697b4d08c09291f971faf7e09370c35cd8fd7b868808f46b','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91194b0bc2d4ae6fe5ffcafba3621fe5b485de348b37120fb03be548ccc793b3',1996,'NE','Niger','geography',71,'Climate: tropical; warm, dry winters; hot, wet summers
Terrain: mostly flat to dissected, undulating plains; hills in
west and southeast
lowest point: Black Volta River 200 m
highest point: Tena Kourou 749 m
Natural resources: manganese, limestone, marble; small deposits of
gold, antimony, copper, nickel, bauxite, lead, phosphates, zinc,
silver
Land use:
arable land: 10%
permanent crops: 0%
meadows and pastures: 37%
forest and woodland: 26%
other: 27%
Irrigated land: 160 sq km (1989 est.)
---------
Location: Southeastern Asia, bordering the Andaman Sea and the Bay
of Bengal, between Bangladesh and Thailand
Geographic coordinates: 22 00 N, 98 00 E
Map references: Southeast Asia
Area:
total area: 678,500 sq km
land area: 657,740 sq km
comparative area: slightly smaller than Texas
Land boundaries:
total: 5,876 km
border countries: Bangladesh 193 km, China 2,185 km, India 1,463 km,
Laos 235 km, Thailand 1,800 km
Coastline: 1,930 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical monsoon; cloudy, rainy, hot, humid summers
(southwest monsoon, June to September); less cloudy, scant rainfall,
mild temperatures, lower humidity during winter (northeast monsoon,
December to April)
Terrain: central lowlands ringed by steep, rugged highlands
lowest point: Andaman Sea 0 m
highest point: Hkakabo Razi 5,881 m
Natural resources: petroleum, timber, tin, antimony, zinc, copper,
tungsten, lead, coal, some marble, limestone, precious stones,
natural gas
Land use:
arable land: 15%
permanent crops: 1%
meadows and pastures: 1%
forest and woodland: 49%
other: 34%
Irrigated land: 10,180 sq km (1989)
---------
Location: Central Africa, east of Zaire
Geographic coordinates: 3 30 S, 30 00 E
Map references: Africa
Area:
total area: 27,830 sq km
land area: 25,650 sq km
comparative area: slightly larger than Maryland
Land boundaries:
total: 974 km
border countries: Rwanda 290 km, Tanzania 451 km, Zaire 233 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: temperate; warm; occasional frost in uplands; dry season
from June to September
Terrain: hilly and mountainous, dropping to a plateau in east,
some plains
lowest point: Lake Tanganyika 772 m
highest point: Mount Heha 2,760 m
Natural resources: nickel, uranium, rare earth oxides, peat,
cobalt, copper, platinum (not yet exploited), vanadium
Land use:
arable land: 43%
permanent crops: 8%
meadows and pastures: 35%
forest and woodland: 2%
other: 12%
Irrigated land: 720 sq km (1989 est.)
---------
Location: Southeastern Asia, bordering the Gulf of Thailand,
between Thailand and Vietnam
Geographic coordinates: 13 00 N, 105 00 E
Map references: Southeast Asia
Area:
total area: 181,040 sq km
land area: 176,520 sq km
comparative area: slightly smaller than Oklahoma
Land boundaries:
total: 2,572 km
border countries: Laos 541 km, Thailand 803 km, Vietnam 1,228 km
Coastline: 443 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: offshore islands and sections of the
boundary with Vietnam are in dispute; maritime boundary with Vietnam
not defined; parts of border with Thailand in dispute; maritime
boundary with Thailand not clearly defined
Climate: tropical; rainy, monsoon season (May to November); dry
season (December to April); little seasonal temperature variation
Terrain: mostly low, flat plains; mountains in southwest and north
lowest point: Gulf of Thailand 0 m
highest point: Phnum Aoral 1,810 m
Natural resources: timber, gemstones, some iron ore, manganese,
phosphates, hydropower potential
Land use:
arable land: 16%
permanent crops: 1%
meadows and pastures: 3%
forest and woodland: 76%
other: 4%
Irrigated land: 920 sq km (1989 est.)
---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Equatorial Guinea and Nigeria
Geographic coordinates: 6 00 N, 12 00 E
Map references: Africa
Area:
total area: 475,440 sq km
land area: 469,440 sq km
comparative area: slightly larger than California
Land boundaries:
total: 4,591 km
border countries: Central African Republic 797 km, Chad 1,094 km,
Congo 523 km, Equatorial Guinea 189 km, Gabon 298 km, Nigeria 1,690
km
Coastline: 402 km
Maritime claims:
territorial sea: 50 nm
International disputes: demarcation of international boundaries in
vicinity of Lake Chad, the lack of which led to border incidents in
the past, is completed and awaits ratification by Cameroon, Chad,
Niger, and Nigeria; dispute with Nigeria over land and maritime
boundaries in the vicinity of the Bakasi Peninsula has been referred
to the International Court of Justice
Climate: varies with terrain, from tropical along coast to
semiarid and hot in north
Terrain: diverse, with coastal plain in southwest, dissected
plateau in center, mountains in west, plains in north
lowest point: Atlantic Ocean 0 m
highest point: Fako 4,095 m
Natural resources: petroleum, bauxite, iron ore, timber,
hydropower potential
Land use:
arable land: 13%
permanent crops: 2%
meadows and pastures: 18%
forest and woodland: 54%
other: 13%
Irrigated land: 280 sq km (1989 est.)
---------
Location: Northern North America, bordering the North Atlantic
Ocean and North Pacific Ocean, north of the conterminous US
Geographic coordinates: 60 00 N, 95 00 W
Map references: North America
Area:
total area: 9,976,140 sq km
land area: 9,220,970 sq km
comparative area: slightly larger than US
Land boundaries:
total: 8,893 km
border country: US 8,893 km (includes 2,477 km with Alaska)
Coastline: 243,791 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: maritime boundary disputes with the US;
Saint Pierre and Miquelon is focus of maritime boundary dispute
between Canada and France
Climate: varies from temperate in south to subarctic and arctic in
north
Terrain: mostly plains with mountains in west and lowlands in
southeast
lowest point: Atlantic Ocean 0 m
highest point: Mount Logan 5,950 m
Natural resources: nickel, zinc, copper, gold, lead, molybdenum,
potash, silver, fish, timber, wildlife, coal, petroleum, natural gas
Land use:
arable land: 9%
permanent crops: 0%
meadows and pastures: 3%
forest and woodland: 45%
other: 43%
Irrigated land: 8,400 sq km (1989 est.)
---------
Location: Western Africa, group of Islands in the North Atlantic
Ocean, west of Senegal
Geographic coordinates: 16 00 N, 24 00 W
Map references: World
Area:
total area: 4,030 sq km
land area: 4,030 sq km
comparative area: slightly larger than Rhode Island
Land boundaries: 0 km
Coastline: 965 km
Maritime claims: measured from claimed archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: temperate; warm, dry summer; precipitation meager and
very erratic
Terrain: steep, rugged, rocky, volcanic
lowest point: Atlantic Ocean 0 m
highest point: Pico 2,829 m
Natural resources: salt, basalt rock, pozzolana, limestone,
kaolin, fish
Land use:
arable land: 9%
permanent crops: 0%
meadows and pastures: 6%
forest and woodland: 0%
other: 85%
Irrigated land: 20 sq km (1989 est.)
---------
Location: Caribbean, island group in Caribbean Sea, nearly
one-half of the way from Cuba to Honduras
Geographic coordinates: 19 30 N, 80 30 W
Map references: Central America and the Caribbean
Area:
total area: 260 sq km
land area: 260 sq km
comparative area: 1.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical marine; warm, rainy summers (May to October) and
cool, relatively dry winters (November to April)
Terrain: low-lying limestone base surrounded by coral reefs
lowest point: Caribbean Sea 0 m
highest point: The Bluff 43 m
Natural resources: fish, climate and beaches that foster tourism
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 8%
forest and woodland: 23%
other: 69%
Irrigated land: NA sq km
---------
Location: Central Africa, north of Zaire
Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area:
total area: 622,980 sq km
land area: 622,980 sq km
comparative area: slightly smaller than Texas
Land boundaries:
total: 5,203 km
border countries: Cameroon 797 km, Chad 1,197 km, Congo 467 km,
Sudan 1,165 km, Zaire 1,577 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: tropical; hot, dry winters; mild to hot, wet summers
Terrain: vast, flat to rolling, monotonous plateau; scattered
hills in northeast and southwest
lowest point: Oubangui River 335 m
highest point: Mount Gaou 1,420 m
Natural resources: diamonds, uranium, timber, gold, oil
Land use:
arable land: 3%
permanent crops: 0%
meadows and pastures: 5%
forest and woodland: 64%
other: 28%
Irrigated land: NA sq km','c47893611ba35acaefce4c4ccd7f9e71989c5c253f7d86c38fcf00c5e92dddbb','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb0ddcbf6c1d66b772acc6f8b5ddeb10cf528d3dcad23f1e8b83b44b45967255',1996,'NA','Namibia','geography',83,'---------
Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00 E
Map references: Africa
Area:
total area: 1.284 million sq km
land area: 1,259,200 sq km
comparative area: slightly more than three times the size of
California
Land boundaries:
total: 5,968 km
border countries: Cameroon 1,094 km, Central African Republic 1,197
km, Libya 1,055 km, Niger 1,175 km, Nigeria 87 km, Sudan 1,360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: the International Court of Justice (ICJ)
ruled in February 1994 that the 100,000 sq km Aozou Strip between
Chad and Libya belongs to Chad and that Libya must withdraw from it
by 31 May 1994; Libya has withdrawn some of its forces in response
to the ICJ ruling, but still maintains part of the airfield and a
small military presence at the airfield''s water supply located in
Chad; demarcation of international boundaries in vicinity of Lake
Chad, the lack of which has led to border incidents in the past, is
completed and awaiting ratification by Cameroon, Chad, Niger, and','608a660a2ed5ce39e4819d6b8a0b40178ef30111c7ad6e9fcd9966d93371d66c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39600ee822d26ddbb726fe2f5fc518a612b6e77cbc78429ee48bd802a5488237',1996,'NG','Nigeria','geography',84,'Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in north, mountains
in northwest, lowlands in south
lowest point: Djourab Depression 175 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum (unexploited but exploration under
way), uranium, natron, kaolin, fish (Lake Chad)
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 36%
forest and woodland: 11%
other: 51%
Irrigated land: 100 sq km (1989 est.)','d4fd64138a2dabb2ef690b7654d0e64e1b0220d0815fcbca0ca760d17c0cff96','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6db552c490fbed8ca158dcb880d9bb10bb075c21385d89dcd9c44b171c09dbb',1996,'FR','France','geography',91,'---------
Location: Southern South America, bordering the South Atlantic
Ocean and South Pacific Ocean, between Argentina and Peru
Geographic coordinates: 30 00 S, 71 00 W
Map references: South America
Area:
total area: 756,950 sq km
land area: 748,800 sq km
comparative area: slightly smaller than twice the size of Montana
note: includes Isla de Pascua (Easter Island) and Isla Sala y Gomez
Land boundaries:
total: 6,171 km
border countries: Argentina 5,150 km, Bolivia 861 km, Peru 160 km
Coastline: 6,435 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: short section of the southern boundary
with Argentina is indefinite; Bolivia has wanted a sovereign
corridor to the South Pacific Ocean since the Atacama area was lost
to Chile in 1884; dispute with Bolivia over Rio Lauca water rights;
territorial claim in Antarctica (Chilean Antarctic Territory)
partially overlaps Argentine and British claims
Climate: temperate; desert in north; cool and damp in south
Terrain: low coastal mountains; fertile central valley; rugged
Andes in east
lowest point: Pacific Ocean 0 m
highest point: Cerro Aconcagua 6,962 m
Natural resources: copper, timber, iron ore, nitrates, precious
metals, molybdenum
Land use:
arable land: 7%
permanent crops: 0%
meadows and pastures: 16%
forest and woodland: 21%
other: 56%
Irrigated land: 12,650 sq km (1989 est.)
---------
Location: Eastern Asia, bordering the East China Sea, Korea Bay,
Yellow Sea, and South China Sea, between North Korea and Vietnam
Geographic coordinates: 35 00 N, 105 00 E
Map references: Asia
Area:
total area: 9,596,960 sq km
land area: 9,326,410 sq km
comparative area: slightly larger than the US
Land boundaries:
total: 22,143.34 km
border countries: Afghanistan 76 km, Bhutan 470 km, Burma 2,185 km,
Hong Kong 30 km, India 3,380 km, Kazakstan 1,533 km, North Korea
1,416 km, Kyrgyzstan 858 km, Laos 423 km, Macau 0.34 km, Mongolia
4,673 km, Nepal 1,236 km, Pakistan 523 km, Russia (northeast) 3,605
km, Russia (northwest) 40 km, Tajikistan 414 km, Vietnam 1,281 km
Coastline: 14,500 km
Maritime claims:
continental shelf: claim to shallow areas of East China Sea and
Yellow Sea
territorial sea: 12 nm
International disputes: boundary with India in dispute; disputed
sections of the boundary with Russia remain to be settled; boundary
with Tajikistan in dispute; short section of the boundary with North
Korea is indefinite; involved in a complex dispute over the Spratly
Islands with Malaysia, Philippines, Taiwan, Vietnam, and possibly
Brunei; maritime boundary dispute with Vietnam in the Gulf of
Tonkin; Paracel Islands occupied by China, but claimed by Vietnam
and Taiwan; claims Japanese-administered Senkaku-shoto (Senkaku
Islands/Diaoyu Tai), as does Taiwan
Climate: extremely diverse; tropical in south to subarctic in north
Terrain: mostly mountains, high plateaus, deserts in west; plains,
deltas, and hills in east
lowest point: Turpan Pendi -154 m
highest point: Mount Everest 8,848 m
Natural resources: coal, iron ore, petroleum, mercury, tin,
tungsten, antimony, manganese, molybdenum, vanadium, magnetite,
aluminum, lead, zinc, uranium, hydropower potential (world''s largest)
Land use:
arable land: 10%
permanent crops: 0%
meadows and pastures: 31%
forest and woodland: 14%
other: 45%
Irrigated land: 478,220 sq km (1991)
---------
Location: Southeastern Asia, island in the Indian Ocean, south of','b55daeede07d03337a0434a962e9481c20397c0398206bacf31df79edc48292c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e55b6a63fa1a02046abb791d34949a2e3f76d2b89c7a4eab9e32f44235c651b',1996,'ID','Indonesia','geography',95,'Geographic coordinates: 10 30 S, 105 40 E
Map references: Southeast Asia
Area:
total area: 135 sq km
land area: 135 sq km
comparative area: about 0.7 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 138.9 km
Maritime claims:
contiguous zone: 12 nm
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical; heat and humidity moderated by trade winds
Terrain: steep cliffs along coast rise abruptly to central plateau
lowest point: Indian Ocean 0 m
highest point: Murray Hill 361 m
Natural resources: phosphate
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km
---------
Location: Oceania, island group in the North Pacific Ocean, about
three-quarters of the way from Hawaii to Indonesia
Geographic coordinates: 6 55 N, 158 15 E
Map references: Oceania
Area:
total area: 702 sq km
land area: 702 sq km
comparative area: four times the size of Washington, DC
note: includes Pohnpei (Ponape), Truk (Chuuk) Islands, Yap Islands,
and Kosrae
Land boundaries: 0 km
Coastline: 6,112 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; heavy year-round rainfall, especially in the
eastern islands; located on southern edge of the typhoon belt with
occasional severe damage
Terrain: islands vary geologically from high mountainous islands
to low, coral atolls; volcanic outcroppings on Pohnpei, Kosrae, and
Truk
lowest point: Pacific Ocean 0 m
highest point: Totolom 791 m
Natural resources: forests, marine products, deep-seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
---------
Location: Oceania, atoll in the North Pacific Ocean, about
one-third of the way from Honolulu to Tokyo
Geographic coordinates: 28 13 N, 177 22 W
Map references: Oceania
Area:
total area: 5.2 sq km
land area: 5.2 sq km
comparative area: about nine times the size of The Mall in
Washington, DC
note: includes Eastern Island and Sand Island
Land boundaries: 0 km
Coastline: 15 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical, but moderated by prevailing easterly winds
Terrain: low, nearly level
lowest point: Pacific Ocean 0 m
highest point: unnamed location 4 m
Natural resources: fish, wildlife
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Eastern Europe, northeast of Romania
Geographic coordinates: 47 00 N, 29 00 E
Map references: Commonwealth of Independent States
Area:
total area: 33,700 sq km
land area: 33,700 sq km
comparative area: slightly more than twice the size of Hawaii
Land boundaries:
total: 1,389 km
border countries: Romania 450 km, Ukraine 939 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: certain territory of Moldova and Ukraine -
including Bessarabia and Northern Bukovina - are considered by
Bucharest as historically a part of Romania; this territory was
incorporated into the former Soviet Union following the
Molotov-Ribbentrop Pact in 1940
Climate: moderate winters, warm summers
Terrain: rolling steppe, gradual slope south to Black Sea
lowest point: Nistru River 2 m
highest point: Mount Balaneshty 430 m
Natural resources: lignite, phosphorites, gypsum
Land use:
arable land: 50%
permanent crops: 13%
meadows and pastures: 9%
forest and woodland: 0%
other: 28%
Irrigated land: 2,920 sq km (1990)
---------
Location: Western Europe, bordering the Mediterranean Sea, on the
southern coast of France, near the border with Italy
Geographic coordinates: 43 44 N, 7 24 E
Map references: Europe
Area:
total area: 1.9 sq km
land area: 1.9 sq km
comparative area: about three times the size of The Mall in
Washington, DC
Land boundaries:
total: 4.4 km
border country: France 4.4 km
Coastline: 4.1 km
Maritime claims:
territorial sea: 12 nm
International disputes: none
Climate: Mediterranean with mild, wet winters and hot, dry summers
Terrain: hilly, rugged, rocky
lowest point: Mediterranean Sea 0 m
highest point: Mont Agel 140 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km
---------
Location: Northern Asia, between China and Russia
Geographic coordinates: 46 00 N, 105 00 E
Map references: Asia
Area:
total area: 1.565 million sq km
land area: 1.565 million sq km
comparative area: slightly larger than Alaska
Land boundaries:
total: 8,114 km
border countries: China 4,673 km, Russia 3,441 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: desert; continental (large daily and seasonal temperature
ranges)
Terrain: vast semidesert and desert plains; mountains in west and
southwest; Gobi Desert in southeast
lowest point: Hoh Nuur 518 m
highest point: Nayramadlin Orgil 4,374 m
Natural resources: oil, coal, copper, molybdenum, tungsten,
phosphates, tin, nickel, zinc, wolfram, fluorspar, gold
Land use:
arable land: 1%
permanent crops: 0%
meadows and pastures: 79%
forest and woodland: 10%
other: 10%
Irrigated land: 770 sq km (1989)
---------
Location: Caribbean, island in the Caribbean Sea, southeast of','2fac3d1dcef6649a93ee8ff81ef77117a918ae476d5743363f9cdc1135576f99','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ec08a6995cb901382818a60338d964ab03b12674917000089cfa50af667a444',1996,'AU','Australia','geography',105,'---------
Location: Middle America, atoll in the North Pacific Ocean, 1,120
km southwest of Mexico
Geographic coordinates: 10 17 N, 109 13 W
Map references: World
Area:
total area: 7 sq km
land area: 7 sq km
comparative area: about 12 times the size of The Mall in Washington,
DC
Land boundaries: 0 km
Coastline: 11.1 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by Mexico
Climate: tropical, humid, average temperature 20-32 degrees C,
rains May-October
Terrain: coral atoll
lowest point: Pacific Ocean 0 m
highest point: Rocher Clipperton 21 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (all coral)
Irrigated land: 0 sq km
---------
Location: Southeastern Asia, group of islands in the Indian Ocean,
south of Indonesia, about one-half of the way from Australia to Sri
Lanka
Geographic coordinates: 12 30 S, 96 50 E
Map references: Southeast Asia
Area:
total area: 14 sq km
land area: 14 sq km
comparative area: about 24 times the size of The Mall in Washington,
DC
note: includes the two main islands of West Island and Home Island
Land boundaries: 0 km
Coastline: 2.6 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: pleasant, modified by the southeast trade wind for about
nine months of the year; moderate rainfall
Terrain: flat, low-lying coral atolls
lowest point: Indian Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
---------
Location: Northern South America, bordering the Caribbean Sea,
between Panama and Venezuela, and bordering the North Pacific Ocean,
between Ecuador and Panama
Geographic coordinates: 4 00 N, 72 00 W
Map references: South America
Area:
total area: 1,138,910 sq km
land area: 1,038,700 sq km
comparative area: slightly less than three times the size of Montana
note: includes Isla de Malpelo, Roncador Cay, Serrana Bank, and
Serranilla Bank
Land boundaries:
total: 7,408 km
border countries: Brazil 1,643 km, Ecuador 590 km, Panama 225 km,
Peru 2,900 km, Venezuela 2,050 km
Coastline: 3,208 km (Caribbean Sea 1,760 km, North Pacific Ocean
1,448 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: maritime boundary dispute with Venezuela
in the Gulf of Venezuela; territorial dispute with Nicaragua over
Archipelago de San Andres y Providencia and Quita Sueno Bank
Climate: tropical along coast and eastern plains; cooler in
highlands
Terrain: flat coastal lowlands, central highlands, high Andes
Mountains, eastern lowland plains
lowest point: Pacific Ocean 0 m
highest point: Nevado del Huila 5,750 m
Natural resources: petroleum, natural gas, coal, iron ore, nickel,
gold, copper, emeralds
Land use:
arable land: 4%
permanent crops: 2%
meadows and pastures: 29%
forest and woodland: 49%
other: 16%
Irrigated land: 5,150 sq km (1989 est.)
---------
Location: Southern Africa, group of islands in the Mozambique
Channel, about two-thirds of the way between northern Madagascar and
northern Mozambique
Geographic coordinates: 12 10 S, 44 15 E
Map references: Africa
Area:
total area: 2,170 sq km
land area: 2,170 sq km
comparative area: slightly more than 12 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 340 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims French-administered Mayotte
Climate: tropical marine; rainy season (November to May)
Terrain: volcanic islands, interiors vary from steep mountains to
low hills
lowest point: Indian Ocean 0 m
highest point: Mount Kartala 2,360 m
Natural resources: negligible
Land use:
arable land: 35%
permanent crops: 8%
meadows and pastures: 7%
forest and woodland: 16%
other: 34%
Irrigated land: NA sq km
---------
Location: Western Africa, bordering the South Atlantic Ocean,
between Angola and Gabon
Geographic coordinates: 1 00 S, 15 00 E
Map references: Africa
Area:
total area: 342,000 sq km
land area: 341,500 sq km
comparative area: slightly smaller than Montana
Land boundaries:
total: 5,504 km
border countries: Angola 201 km, Cameroon 523 km, Central African
Republic 467 km, Gabon 1,903 km, Zaire 2,410 km
Coastline: 169 km
Maritime claims:
territorial sea: 200 nm
International disputes: long segment of boundary with Zaire along
the Congo River is indefinite (no division of the river or its
islands has been made)
Climate: tropical; rainy season (March to June); dry season (June
to October); constantly high temperatures and humidity; particularly
enervating climate astride the Equator
Terrain: coastal plain, southern basin, central plateau, northern
basin
lowest point: Atlantic Ocean 0 m
highest point: Mount Berongou 903 m
Natural resources: petroleum, timber, potash, lead, zinc, uranium,
copper, phosphates, natural gas
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 29%
forest and woodland: 62%
other: 7%
Irrigated land: 40 sq km (1989)
---------
Location: Oceania, group of islands in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Geographic coordinates: 21 14 S, 159 46 W
Map references: Oceania
Area:
total area: 240 sq km
land area: 240 sq km
comparative area: slightly more than one times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; moderated by trade winds
Terrain: low coral atolls in north; volcanic, hilly islands in
south
lowest point: Pacific Ocean 0 m
highest point: Te Manga 652 m
Natural resources: negligible
Land use:
arable land: 4%
permanent crops: 22%
meadows and pastures: 0%
forest and woodland: 0%
other: 74%
Irrigated land: NA sq km
---------
Location: Oceania, islands in the Coral Sea, northeast of Australia
Geographic coordinates: 18 00 S, 152 00 E
Map references: Oceania
Area:
total area: less than 3 sq km
land area: less than 3 sq km
comparative area: NA
note: includes numerous small islands and reefs scattered over a sea
area of about 1 million sq km, with Willis Islets the most important
Land boundaries: 0 km
Coastline: 3,095 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical
Terrain: sand and coral reefs and islands (or cays)
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Cato Island 6 m
Natural resources: negligible
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (mostly grass or scrub cover)
Irrigated land: 0 sq km
---------
Location: Oceania, archipelago in the South Pacific Ocean, about
one-half of the way from South America to Australia
Geographic coordinates: 15 00 S, 140 00 W
Map references: Oceania
Area:
total area: 4,167 sq km (118 islands and atolls)
land area: 3,660 sq km
comparative area: slightly less than one-third the size of
Connecticut
Land boundaries: 0 km
Coastline: 2,525 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical, but moderate
Terrain: mixture of rugged high islands and low islands with reefs
lowest point: Pacific Ocean 0 m
highest point: Mount Orohena 2,241 m
Natural resources: timber, fish, cobalt
Land use:
arable land: 1%
permanent crops: 19%
meadows and pastures: 5%
forest and woodland: 31%
other: 44%
Irrigated land: NA sq km
Geographic coordinates: 30 00 S, 80 00 E
Map references: World
Area:
total area: 73.6 million sq km
comparative area: slightly less than eight times the size of the US;
third-largest ocean (after the Pacific Ocean and Atlantic Ocean, but
larger than the Arctic Ocean)
note: includes Arabian Sea, Bass Straight, Bay of Bengal, Great
Australian Bight, Gulf of Oman, Persian Gulf, Red Sea, Strait of
Malacca, and other tributary water bodies
Coastline: 66,526 km
International disputes: some maritime disputes (see littoral
states)
Climate: northeast monsoon (December to April), southwest monsoon
(June to October); tropical cyclones occur during May/June and
October/November in the northern Indian Ocean and January/February
in the southern Indian Ocean
Terrain: surface dominated by counterclockwise gyre (broad,
circular system of currents) in the southern Indian Ocean; unique
reversal of surface currents in the northern Indian Ocean; low
atmospheric pressure over southwest Asia from hot, rising, summer
air results in the southwest monsoon and southwest-to-northeast
winds and currents, while high pressure over northern Asia from
cold, falling, winter air results in the northeast monsoon and
northeast-to-southwest winds and currents; ocean floor is dominated
by the Mid-Indian Ocean Ridge and subdivided by the Southeast Indian
Ocean Ridge, Southwest Indian Ocean Ridge, and Ninety East Ridge
lowest point: Java Trench -7,258 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, shrimp, sand and
gravel aggregates, placer deposits, polymetallic nodules
---------
Location: Southeastern Asia, archipelago between the Indian Ocean
and the Pacific Ocean
Geographic coordinates: 5 00 S, 120 00 E
Map references: Southeast Asia
Area:
total area: 1,919,440 sq km
land area: 1,826,440 sq km
comparative area: slightly less than three times the size of Texas
Land boundaries:
total: 2,602 km
border countries: Malaysia 1,782 km, Papua New Guinea 820 km
Coastline: 54,716 km
Maritime claims: measured from claimed archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: sovereignty over Timor Timur (East Timor
Province) disputed with Portugal and not recognized by the UN; two
islands in dispute with Malaysia
Climate: tropical; hot, humid; more moderate in highlands
Terrain: mostly coastal lowlands; larger islands have interior
mountains
lowest point: Indian Ocean 0 m
highest point: Puncak Jaya 5,030 m
Natural resources: petroleum, tin, natural gas, nickel, timber,
bauxite, copper, fertile soils, coal, gold, silver
Land use:
arable land: 8%
permanent crops: 3%
meadows and pastures: 7%
forest and woodland: 67%
other: 15%
Irrigated land: 75,500 sq km (1989 est.)
Geographic coordinates: 21 30 S, 165 30 E
Map references: Oceania
Area:
total area: 19,060 sq km
land area: 18,575 sq km
comparative area: slightly smaller than New Jersey
Land boundaries: 0 km
Coastline: 2,254 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: Matthew and Hunter Islands claimed by
France and Vanuatu
Climate: tropical; modified by southeast trade winds; hot, humid
Terrain: coastal plains with interior mountains
lowest point: Pacific Ocean 0 m
highest point: Mont Panie 1,628 m
Natural resources: nickel, chrome, iron, cobalt, manganese,
silver, gold, lead, copper
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 14%
forest and woodland: 51%
other: 35%
Irrigated land: NA sq km
---------
Location: Oceania, islands in the South Pacific Ocean, southeast
of Australia
Geographic coordinates: 41 00 S, 174 00 E
Map references: Oceania
Area:
total area: 268,680 sq km
land area: 268,670 sq km
comparative area: about the size of Colorado
note: includes Antipodes Islands, Auckland Islands, Bounty Islands,
Campbell Island, Chatham Islands, and Kermadec Islands
Land boundaries: 0 km
Coastline: 15,134 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: territorial claim in Antarctica (Ross
Dependency)
Climate: temperate with sharp regional contrasts
Terrain: predominately mountainous with some large coastal plains
lowest point: Pacific Ocean 0 m
highest point: Mount Cook 3,764 m
Natural resources: natural gas, iron ore, sand, coal, timber,
hydropower, gold, limestone
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 53%
forest and woodland: 38%
other: 7%
Irrigated land: 2,800 sq km (1989 est.)
Geographic coordinates: 29 02 S, 167 57 E
Map references: Oceania
Area:
total area: 34.6 sq km
land area: 34.6 sq km
comparative area: about 0.2 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 32 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: subtropical, mild, little seasonal temperature variation
Terrain: volcanic formation with mostly rolling plains
lowest point: Pacific Ocean 0 m
highest point: Mount Bates 319 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 25%
forest and woodland: 0%
other: 75%
Irrigated land: NA sq km
Geographic coordinates: 8 00 S, 178 00 E
Map references: Oceania
Area:
total area: 26 sq km
land area: 26 sq km
comparative area: 0.1 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 24 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; moderated by easterly trade winds (March to
November); westerly gales and heavy rain (November to March)
Terrain: very low-lying and narrow coral atolls
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
note: Tuvalu''s nine coral atolls have enough soil to grow coconuts
and support subsistence agriculture
Irrigated land: NA sq km
---------
Location: Eastern Africa, west of Kenya
Geographic coordinates: 1 00 N, 32 00 E
Map references: Africa
Area:
total area: 236,040 sq km
land area: 199,710 sq km
comparative area: slightly smaller than Oregon
Land boundaries:
total: 2,698 km
border countries: Kenya 933 km, Rwanda 169 km, Sudan 435 km,
Tanzania 396 km, Zaire 765 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: tropical; generally rainy with two dry seasons (December
to February, June to August); semiarid in northeast
Terrain: mostly plateau with rim of mountains
lowest point: Lake Albert 621 m
highest point: Margherita (Mount Stanley) 5,110 m
Natural resources: copper, cobalt, limestone, salt
Land use:
arable land: 23%
permanent crops: 9%
meadows and pastures: 25%
forest and woodland: 30%
other: 13%
Irrigated land: 90 sq km (1989 est.)
---------
Location: Eastern Europe, bordering the Black Sea, between Poland
and Russia
Geographic coordinates: 49 00 N, 32 00 E
Map references: Commonwealth of Independent States
Area:
total area: 603,700 sq km
land area: 603,700 sq km
comparative area: slightly smaller than Texas
Land boundaries:
total: 4,558 km
border countries: Belarus 891 km, Hungary 103 km, Moldova 939 km,
Poland 428 km, Romania (southwest) 169 km, Romania (west) 362 km,
Russia 1,576 km, Slovakia 90 km
Coastline: 2,782 km
Maritime claims:
continental shelf: 200-m or to the depth of exploitation
exclusive economic zone: undefined
territorial sea: 12 nm
International disputes: certain territory of Moldova and Ukraine -
including Bessarabia and Northern Bukovina - are considered by
Bucharest as historically a part of Romania; this territory was
incorporated into the former Soviet Union following the
Molotov-Ribbentrop Pact in 1940; dispute with Romania over
continental shelf of the Black Sea under which signifcant gas and
oil deposits may exist; potential dispute with Russia over Crimea;
has made no territorial claim in Antarctica (but has reserved the
right to do so) and does not recognize the claims of any other nation
Climate: temperate continental; Mediterranean only on the southern
Crimean coast; precipitation disproportionately distributed, highest
in west and north, lesser in east and southeast; winters vary from
cool along the Black Sea to cold farther inland; summers are warm
across the greater part of the country, hot in the south
Terrain: most of Ukraine consists of fertile plains (steppes) and
plateaux, mountains being found only in the west (the Carpathians),
and in the Crimean Peninsula in the extreme south
lowest point: Black Sea 0 m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal, manganese, natural gas, oil,
salt, sulfur, graphite, titanium, magnesium, kaolin, nickel,
mercury, timber
Land use:
arable land: 56%
permanent crops: 2%
meadows and pastures: 12%
forest and woodland: 0%
other: 30%
Irrigated land: 26,000 sq km (1990)
---------
Location: Middle East, bordering the Gulf of Oman and the Persian
Gulf, between Oman and Saudi Arabia
Geographic coordinates: 24 00 N, 54 00 E
Map references: Middle East
Area:
total area: 75,581 sq km
land area: 75,581 sq km
comparative area: slightly smaller than Maine
Land boundaries:
total: 867 km
border countries: Oman 410 km, Saudi Arabia 457 km
Coastline: 1,318 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: location and status of boundary with Saudi
Arabia is not final, defacto boundary reflects 1974 agreement; no
defined boundary with most of Oman, but Administrative Line in far
north; claims two islands in the Persian Gulf occupied by Iran:
Lesser Tunb (called Tunb as Sughra in Arabic by UAE and Jazireh-ye
Tonb-e Kuchek in Persian by Iran) and Greater Tunb (called Tunb al
Kubra in Arabic by UAE and Jazireh-ye Tonb-e Bozorg in Persian by
Iran); claims island in the Persian Gulf jointly administered with
Iran (called Abu Musa in Arabic by UAE and Jazireh-ye Abu Musa in
Persian by Iran); in 1992, the dispute over Abu Musa and the Tunb
islands became more acute when Iran unilaterally tried to control
the entry of third country nationals into the UAE portion of Abu
Musa island, Tehran subsequently backed off in the face of
significant diplomatic support for the UAE in the region
Climate: desert; cooler in eastern mountains
Terrain: flat, barren coastal plain merging into rolling sand
dunes of vast desert wasteland; mountains in east
lowest point: Persian Gulf 0 m
highest point: Jabal Yibir 1,527 m
Natural resources: petroleum, natural gas
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 2%
forest and woodland: 0%
other: 98%
Irrigated land: 50 sq km (1989 est.)
---------
Location: Western Europe, islands including the northern one-sixth
of the island of Ireland between the North Atlantic Ocean and the
North Sea, northwest of France
Geographic coordinates: 54 00 N, 2 00 W
Map references: Europe
Area:
total area: 244,820 sq km
land area: 241,590 sq km
comparative area: slightly smaller than Oregon
note: includes Rockall and Shetland Islands
Land boundaries:
total: 360 km
border country: Ireland 360 km
Coastline: 12,429 km
Maritime claims:
continental shelf: as defined in continental shelf orders or in
accordance with agreed upon boundaries
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: Northern Ireland question with Ireland;
Gibraltar question with Spain; Argentina claims Falkland Islands
(Islas Malvinas); Argentina claims South Georgia and the South
Sandwich Islands; Mauritius claims island of Diego Garcia in British
Indian Ocean Territory; Rockall continental shelf dispute involving
Denmark, Iceland, and Ireland (Ireland and the UK have signed a
boundary agreement in the Rockall area); territorial claim in
Antarctica (British Antarctic Territory)
Climate: temperate; moderated by prevailing southwest winds over
the North Atlantic Current; more than one-half of the days are
overcast
Terrain: mostly rugged hills and low mountains; level to rolling
plains in east and southeast
lowest point: Fenland -4 m
highest point: Ben Nevis 1,343 m
Natural resources: coal, petroleum, natural gas, tin, limestone,
iron ore, salt, clay, chalk, gypsum, lead, silica
Land use:
arable land: 29%
permanent crops: 0%
meadows and pastures: 48%
forest and woodland: 9%
other: 14%
Irrigated land: 1,570 sq km (1989)
---------
Location: Oceania, group of islands in the South Pacific Ocean,
about three-quarters of the way from Hawaii to Australia
Geographic coordinates: 16 00 S, 167 00 E
Map references: Oceania
Area:
total area: 14,760 sq km
land area: 14,760 sq km
comparative area: slightly larger than Connecticut
note: includes more than 80 islands
Land boundaries: 0 km
Coastline: 2,528 km
Maritime claims: measured from claimed archipelagic baselines
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims Matthew and Hunter Islands east of','8dbba7d93b0482612de0ce8721d8407f87e296d381436fd4328b3c404d8967ce','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ec93c9bc6c1d99853032fc03678bd5fb1dd6e3305ad59c97bf13161f3c17e85',1996,'PA','Panama','geography',109,'---------
Location: Middle America, bordering both the Caribbean Sea and the
North Pacific Ocean, between Nicaragua and Panama
Geographic coordinates: 10 00 N, 84 00 W
Map references: Central America and the Caribbean
Area:
total area: 51,100 sq km
land area: 50,660 sq km
comparative area: slightly smaller than West Virginia
note: includes Isla del Coco
Land boundaries:
total: 639 km
border countries: Nicaragua 309 km, Panama 330 km
Coastline: 1,290 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; dry season (December to April); rainy season
(May to November)
Terrain: coastal plains separated by rugged mountains
lowest point: Pacific Ocean 0 m
highest point: Cerro Chirripo 3,810 m
Natural resources: hydropower potential
Land use:
arable land: 6%
permanent crops: 7%
meadows and pastures: 45%
forest and woodland: 34%
other: 8%
Irrigated land: 1,180 sq km (1989 est.)
---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Ghana and Liberia
Geographic coordinates: 8 00 N, 5 00 W
Map references: Africa
Area:
total area: 322,460 sq km
land area: 318,000 sq km
comparative area: slightly larger than New Mexico
Land boundaries:
total: 3,110 km
border countries: Burkina Faso 584 km, Ghana 668 km, Guinea 610 km,
Liberia 716 km, Mali 532 km
Coastline: 515 km
Maritime claims:
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical along coast, semiarid in far north; three
seasons - warm and dry (November to March), hot and dry (March to
May), hot and wet (June to October)
Terrain: mostly flat to undulating plains; mountains in northwest
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1,752 m
Natural resources: petroleum, diamonds, manganese, iron ore,
cobalt, bauxite, copper
Land use:
arable land: 9%
permanent crops: 4%
meadows and pastures: 9%
forest and woodland: 26%
other: 52%
Irrigated land: 620 sq km (1989 est.)
---------
Location: Southeastern Europe, bordering the Adriatic Sea, between
Bosnia and Herzegovina and Slovenia
Geographic coordinates: 45 10 N, 15 30 E
Map references: Europe
Area:
total area: 56,538 sq km
land area: 56,410 sq km
comparative area: slightly smaller than West Virginia
Land boundaries:
total: 2,073 km
border countries: Bosnia and Herzegovina 932 km, Hungary 329 km,
Serbia and Montenegro 266 km (241 km with Serbia; 25 km with
Montenego), Slovenia 546 km
Coastline: 5,790 km (mainland 1,778 km, islands 4,012 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
International disputes: Eastern Slavonia, which was held by ethnic
Serbs during the war, is currently being overseen by the UN
Transitional Administration for Eastern Slavonia; reintegration of
Eastern Slavonia into Croatia will occur in 1997; although Croatia
does not recognize the "Federal Republic of Yugoslavia," both
countries have agreed to open consular sections in each other''s
capitals; Croatia and Italy have not resolved a bilateral issue
dating from WWII over property and ethnic minority rights; a border
dispute with Slovenia is unresolved
Climate: Mediterranean and continental; continental climate
predominant with hot summers and cold winters; mild winters, dry
summers along coast
Terrain: geographically diverse; flat plains along Hungarian
border, low mountains and highlands near Adriatic coast, coastline,
and islands
lowest point: Adriatic Sea 0 m
highest point: Dinara 1,830 m
Natural resources: oil, some coal, bauxite, low-grade iron ore,
calcium, natural asphalt, silica, mica, clays, salt
Land use:
arable land: 32%
permanent crops: 20%
meadows and pastures: 18%
forest and woodland: 15%
other: 15%
Irrigated land: NA sq km
---------
Location: Caribbean, island between the Caribbean Sea and the
North Atlantic Ocean, south of Florida
Geographic coordinates: 21 30 N, 80 00 W
Map references: Central America and the Caribbean
Area:
total area: 110,860 sq km
land area: 110,860 sq km
comparative area: slightly smaller than Pennsylvania
Land boundaries:
total: 29 km
border country: US Naval Base at Guantanamo Bay 29 km
note: Guantanamo Naval Base is leased by the US and thus remains
part of Cuba
Coastline: 3,735 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: US Naval Base at Guantanamo Bay is leased
to US and only mutual agreement or US abandonment of the area can
terminate the lease
Climate: tropical; moderated by trade winds; dry season (November
to April); rainy season (May to October)
Terrain: mostly flat to rolling plains with rugged hills and
mountains in the southeast
lowest point: Caribbean Sea 0 m
highest point: Pico Turquino 2,005 m
Natural resources: cobalt, nickel, iron ore, copper, manganese,
salt, timber, silica, petroleum
Land use:
arable land: 23%
permanent crops: 6%
meadows and pastures: 23%
forest and woodland: 17%
other: 31%
Irrigated land: 8,960 sq km (1989)
---------
Location: Middle East, island in the Mediterranean Sea, south of
Turkey
Geographic coordinates: 35 00 N, 33 00 E
Map references: Middle East
Area:
total area: 9,250 sq km (note - 3,355 sq km are in the Turkish area)
land area: 9,240 sq km
comparative area: about 0.7 times the size of Connecticut
Land boundaries: 0 km
Coastline: 648 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 12 nm
International disputes: 1974 hostilities divided the island into
two de facto autonomous areas, a Greek area controlled by the
Cypriot Government (59% of the island''s land area) and a
Turkish-Cypriot area (37% of the island), that are separated by a UN
buffer zone (4% of the island); there are two UK sovereign base
areas within the Greek Cypriot portion of the island
Climate: temperate, Mediterranean with hot, dry summers and cool,
wet winters
Terrain: central plain with mountains to north and south;
scattered but significant plains along southern coast
lowest point: Mediterranean Sea 0 m
highest point: Olympus 1,952 m
Natural resources: copper, pyrites, asbestos, gypsum, timber,
salt, marble, clay earth pigment
Land use:
arable land: 40%
permanent crops: 7%
meadows and pastures: 10%
forest and woodland: 18%
other: 25%
Irrigated land: 350 sq km (1989)
---------
Location: Central Europe, southeast of Germany
Geographic coordinates: 49 45 N, 15 30 E
Map references: Europe
Area:
total area: 78,703 sq km
land area: 78,645 sq km
comparative area: slightly smaller than South Carolina
Land boundaries:
total: 1,880 km
border countries: Austria 362 km, Germany 646 km, Poland 658 km,
Slovakia 214 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: Liechtenstein claims restitution for 1,600
sq km of Czech territory confiscated from its royal family in 1918;
Sudeten German claims for restitution of property confiscated in
connection with their expulsion after World War II versus the Czech
Republic claims that restitution does not precede February 1948 when
the Communists seized power; unresolved property issues with
Slovakia over redistribution of property of the former Czechoslovak
federal government
Climate: temperate; cool summers; cold, cloudy, humid winters
Terrain: Bohemia in the west consists of rolling plains, hills,
and plateaus surrounded by low mountains; Moravia in the east
consists of very hilly country
lowest point: Elbe River 115 m
highest point: Snezka 1,602 m
Natural resources: hard coal, soft coal, kaolin, clay, graphite
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
---------
Location: Northern Europe, bordering the Baltic Sea and the North
Sea, on a peninsula north of Germany
Geographic coordinates: 56 00 N, 10 00 E
Map references: Europe
Area:
total area: 43,070 sq km
land area: 42,370 sq km
comparative area: slightly more than twice the size of Massachusetts
note: includes the island of Bornholm in the Baltic Sea and the rest
of metropolitan Denmark, but excludes the Faroe Islands and Greenland
Land boundaries:
total: 68 km
border country: Germany 68 km
Coastline: 3,379 km
Maritime claims:
contiguous zone: 4 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: Rockall continental shelf dispute
involving Iceland, Ireland, and the UK (Ireland and the UK have
signed a boundary agreement in the Rockall area)
Climate: temperate; humid and overcast; mild, windy winters and
cool summers
Terrain: low and flat to gently rolling plains
lowest point: Lammefjord -7 m
highest point: Ejer Bavnehoj 173 m
Natural resources: petroleum, natural gas, fish, salt, limestone
Land use:
arable land: 61%
permanent crops: 0%
meadows and pastures: 6%
forest and woodland: 12%
other: 21%
Irrigated land: 4,300 sq km (1989 est.)
---------
Location: Eastern Africa, bordering the Gulf of Aden and the Red
Sea, between Eritrea and Somalia
Geographic coordinates: 11 30 N, 43 00 E
Map references: Africa
Area:
total area: 22,000 sq km
land area: 21,980 sq km
comparative area: slightly larger than Massachusetts
Land boundaries:
total: 508 km
border countries: Eritrea 113 km, Ethiopia 337 km, Somalia 58 km
Coastline: 314 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: desert; torrid, dry
Terrain: coastal plain and plateau separated by central mountains
lowest point: Asal -155 m
highest point: Mousa Alli 2,028 m
Natural resources: geothermal areas
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 9%
forest and woodland: 0%
other: 91%
Irrigated land: NA sq km
---------
Location: Caribbean, island between the Caribbean Sea and the
North Atlantic Ocean, about one-half of the way from Puerto Rico to','12ae7c85ea9375c2ab2017f58ba1a5a083da15fb5d97ab1cfd1e86cdb804dbfb','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('948f96a8e8f95d4feb334bb17cfa3243a906642f4794d1bc62b7d5969cf02a81',1996,'TT','Trinidad and Tobago','geography',117,'Geographic coordinates: 13 30 N, 61 20 W
Map references: Central America and the Caribbean
Area:
total area: 750 sq km
land area: 750 sq km
comparative area: more than four times the size of Washington, DC
Land boundaries: 0 km
Coastline: 148 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; moderated by northeast trade winds; heavy
rainfall
Terrain: rugged mountains of volcanic origin
lowest point: Caribbean Sea 0 m
highest point: Morne Diablatins 1,447 m
Natural resources: timber
Land use:
arable land: 9%
permanent crops: 13%
meadows and pastures: 3%
forest and woodland: 41%
other: 34%
Irrigated land: NA sq km
---------
Location: Caribbean, eastern two-thirds of the island of
Hispaniola, between the Caribbean Sea and the North Atlantic Ocean,
east of Haiti
Geographic coordinates: 19 00 N, 70 40 W
Map references: Central America and the Caribbean
Area:
total area: 48,730 sq km
land area: 48,380 sq km
comparative area: slightly more than twice the size of New Hampshire
Land boundaries:
total: 275 km
border country: Haiti 275 km
Coastline: 1,288 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 6 nm
International disputes: none
Climate: tropical maritime; little seasonal temperature variation;
seasonal variation in rainfall
Terrain: rugged highlands and mountains with fertile valleys
interspersed
lowest point: Lago Enriquillo -46 m
highest point: Pico Duarte 3,175 m
Natural resources: nickel, bauxite, gold, silver
Land use:
arable land: 23%
permanent crops: 7%
meadows and pastures: 43%
forest and woodland: 13%
other: 14%
Irrigated land: 2,250 sq km (1989)
---------
Location: Western South America, bordering the Pacific Ocean at
the Equator, between Colombia and Peru
Geographic coordinates: 2 00 S, 77 30 W
Map references: South America
Area:
total area: 283,560 sq km
land area: 276,840 sq km
comparative area: slightly smaller than Nevada
note: includes Galapagos Islands
Land boundaries:
total: 2,010 km
border countries: Colombia 590 km, Peru 1,420 km
Coastline: 2,237 km
Maritime claims:
continental shelf: claims continental shelf between mainland and
Galapagos Islands
territorial sea: 200 nm
International disputes: three sections of the boundary with Peru
are in dispute
Climate: tropical along coast becoming cooler inland
Terrain: coastal plain (costa), inter-Andean central highlands
(sierra), and flat to rolling eastern jungle (oriente)
lowest point: Pacific Ocean 0 m
highest point: Chimborazo 6,267 m
Natural resources: petroleum, fish, timber
Land use:
arable land: 6%
permanent crops: 3%
meadows and pastures: 17%
forest and woodland: 51%
other: 23%
Irrigated land: 5,500 sq km (1989 est.)
---------
Location: Northern Africa, bordering the Mediterranean Sea,
between Libya and the Gaza Strip
Geographic coordinates: 27 00 N, 30 00 E
Map references: Africa
Area:
total area: 1,001,450 sq km
land area: 995,450 sq km
comparative area: slightly more than three times the size of New
Geographic coordinates: 12 07 N, 61 40 W
Map references: Central America and the Caribbean
Area:
total area: 340 sq km
land area: 340 sq km
comparative area: twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 121 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; tempered by northeast trade winds
Terrain: volcanic in origin with central mountains
lowest point: Caribbean Sea 0 m
highest point: Mount Saint Catherine 840 m
Natural resources: timber, tropical fruit, deepwater harbors
Land use:
arable land: 15%
permanent crops: 26%
meadows and pastures: 3%
forest and woodland: 9%
other: 47%
Irrigated land: NA sq km
---------
Location: Caribbean, islands in the eastern Caribbean Sea,
southeast of Puerto Rico
Geographic coordinates: 16 15 N, 61 35 W
Map references: Central America and the Caribbean
Area:
total area: 1,780 sq km
land area: 1,706 sq km
comparative area: 10 times the size of Washington, DC
note: Guadeloupe is an archipelago of nine inhabited islands, of
which Basse-Terre, Grande-Terre, and Marie-Galante are the three
largest
Land boundaries: 0 km
Coastline: 306 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: subtropical tempered by trade winds; moderately high
humidity
Terrain: Basse-Terre is volcanic in origin with interior
mountains; Grand-Terre is low limestone formation; most of the seven
other islands are volcanic in origin
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1,467 m
Natural resources: cultivable land, beaches and climate that
foster tourism
Land use:
arable land: 18%
permanent crops: 5%
meadows and pastures: 13%
forest and woodland: 40%
other: 24%
Irrigated land: 30 sq km (1989 est.)
Geographic coordinates: 14 40 N, 61 00 W
Map references: Central America and the Caribbean
Area:
total area: 1,100 sq km
land area: 1,060 sq km
comparative area: slightly more than six times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; moderated by trade winds; rainy season (June to
October); vulnerable to devastating cyclones (hurricanes) every
eight years on average; average temperature 17.3 degrees C; humid
Terrain: mountainous with indented coastline; dormant volcano
lowest point: Caribbean Sea 0 m
highest point: Montagne Pelee 1,397 m
Natural resources: coastal scenery and beaches, cultivable land
Land use:
arable land: 10%
permanent crops: 8%
meadows and pastures: 30%
forest and woodland: 26%
other: 26%
Irrigated land: 60 sq km (1989 est.)
---------
Location: Northern Africa, bordering the North Atlantic Ocean,
between Senegal and Western Sahara
Geographic coordinates: 20 00 N, 12 00 W
Map references: Africa
Area:
total area: 1,030,700 sq km
land area: 1,030,400 sq km
comparative area: slightly larger than three times the size of New
Geographic coordinates: 13 53 N, 60 68 W
Map references: Central America and the Caribbean
Area:
total area: 620 sq km
land area: 610 sq km
comparative area: 3.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 158 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm or to the edge of the continental
margin
territorial sea: 12 nm
International disputes: none
Climate: tropical, moderated by northeast trade winds; dry season
from January to April, rainy season from May to August
Terrain: volcanic and mountainous with some broad, fertile valleys
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Natural resources: forests, sandy beaches, minerals (pumice),
mineral springs, geothermal potential
Land use:
arable land: 8%
permanent crops: 20%
meadows and pastures: 5%
forest and woodland: 13%
other: 54%
Irrigated land: 10 sq km (1989 est.)
---------
Location: Northern North America, islands in the North Atlantic
Ocean, south of Newfoundland (Canada)
Geographic coordinates: 46 50 N, 56 20 E
Map references: North America
Area:
total area: 242 sq km
land area: 242 sq km
comparative area: 1.5 times the size of Washington, DC
note: includes eight small islands in the Saint Pierre and the
Miquelon groups
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: focus of maritime boundary dispute between
Canada and France; in 1992 an arbitration panel awarded the islands
an exclusive economic zone area of 12,348 sq km to settle the dispute
Climate: cold and wet, with much mist and fog; spring and autumn
are windy
Terrain: mostly barren rock
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande Montagne 240 m
Natural resources: fish, deepwater ports
Land use:
arable land: 13%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 4%
other: 83%
Irrigated land: NA sq km
---------
Location: Caribbean, islands in the Caribbean Sea, north of
Geographic coordinates: 13 15 N, 61 12 W
Map references: Central America and the Caribbean
Area:
total area: 340 sq km
land area: 340 sq km
comparative area: twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 84 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; little seasonal temperature variation; rainy
season (May to November)
Terrain: volcanic, mountainous
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1,234 m
Natural resources: NEGL
Land use:
arable land: 38%
permanent crops: 12%
meadows and pastures: 6%
forest and woodland: 41%
other: 3%
Irrigated land: 10 sq km (1989 est.)
---------
Location: Southern Europe, an enclave in central Italy
Geographic coordinates: 43 46 N, 12 25 E
Map references: Europe
Area:
total area: 60 sq km
land area: 60 sq km
comparative area: about 0.3 times the size of Washington, DC
Land boundaries:
total: 39 km
border country: Italy 39 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: Mediterranean; mild to cool winters; warm, sunny summers
Terrain: rugged mountains
lowest point: Fiume Ausa 55 m
highest point: Monte Titano 749 m
Natural resources: building stone
Land use:
arable land: 17%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 83%
Irrigated land: NA sq km','d474ee7e84f4c82f49fac352263c25e1e95718d50d7743b80d16a1915d3b63a3','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21aa78517183cc51b13dca2e7b6d5e302a7a4514515863f33fe8ee546ba1e8ec',1996,'MX','Mexico','geography',125,'Land boundaries:
total: 2,689 km
border countries: Gaza Strip 11 km, Israel 255 km, Libya 1,150 km,
Sudan 1,273 km
Coastline: 2,450 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: administrative boundary with Sudan does
not coincide with international boundary creating the "Hala''ib
Triangle," a barren area of 20,580 sq km, tensions over this
disputed area began to escalate in 1992 and remain high
Climate: desert; hot, dry summers with moderate winters
Terrain: vast desert plateau interrupted by Nile valley and delta
lowest point: Qattara Depression -133 m
highest point: Mount Catherine 2,629 m
Natural resources: petroleum, natural gas, iron ore, phosphates,
manganese, limestone, gypsum, talc, asbestos, lead, zinc
Land use:
arable land: 3%
permanent crops: 2%
meadows and pastures: 0%
forest and woodland: 0%
other: 95%
Irrigated land: 25,850 sq km (1989 est.)
---------
Location: Middle America, bordering the North Pacific Ocean,
between Guatemala and Honduras
Geographic coordinates: 13 50 N, 88 55 W
Map references: Central America and the Caribbean
Area:
total area: 21,040 sq km
land area: 20,720 sq km
comparative area: slightly smaller than Massachusetts
Land boundaries:
total: 545 km
border countries: Guatemala 203 km, Honduras 342 km
Coastline: 307 km
Maritime claims:
territorial sea: 200 nm
International disputes: land boundary dispute with Honduras mostly
resolved by 11 September 1992 International Court of Justice (ICJ)
decision; with respect to the maritime boundary in the Golfo de
Fonseca, ICJ referred to an earlier agreement in this century and
advised that some tripartite resolution among El Salvador, Honduras
and Nicaragua likely would be required
Climate: tropical; rainy season (May to October); dry season
(November to April)
Terrain: mostly mountains with narrow coastal belt and central
plateau
lowest point: Pacific Ocean 0 m
highest point: Cerro El Pital 2,730 m
Natural resources: hydropower, geothermal power, petroleum
Land use:
arable land: 27%
permanent crops: 8%
meadows and pastures: 29%
forest and woodland: 6%
other: 30%
Irrigated land: 1,200 sq km (1989)
---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Cameroon and Gabon
Geographic coordinates: 2 00 N, 10 00 E
Map references: Africa
Area:
total area: 28,050 sq km
land area: 28,050 sq km
comparative area: slightly larger than Maryland
Land boundaries:
total: 539 km
border countries: Cameroon 189 km, Gabon 350 km
Coastline: 296 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: maritime boundary dispute with Gabon
because of disputed sovereignty over islands in Corisco Bay
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills; islands are
volcanic
lowest point: Atlantic Ocean 0 m
highest point: Mount Malabo 3,008 m
Natural resources: timber, petroleum, small unexploited deposits
of gold, manganese, uranium
Land use:
arable land: 8%
permanent crops: 4%
meadows and pastures: 4%
forest and woodland: 51%
other: 33%
Irrigated land: NA sq km
Land boundaries:
total: 5,074 km
border countries: Algeria 463 km, Mali 2,237 km, Senegal 813 km,
Western Sahara 1,561 km
Coastline: 754 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: boundary with Senegal in dispute
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the Sahara; some central
hills
lowest point: Sebkha de Ndrhamcha -3 m
highest point: Kediet Ijill 910 m
Natural resources: iron ore, gypsum, fish, copper, phosphate
Land use:
arable land: 1%
permanent crops: 0%
meadows and pastures: 38%
forest and woodland: 5%
other: 56%
Irrigated land: 120 sq km (1989 est.)
---------
Location: Southern Africa, island in the Indian Ocean, east of
---------
Location: North America, bordering both the North Atlantic Ocean
and the North Pacific Ocean, between Canada and Mexico
Geographic coordinates: 38 00 N, 97 00 W
Map references: North America
Area:
total area: 9,372,610 sq km
land area: 9,166,600 sq km
comparative area: about one-half the size of Russia; about
three-tenths the size of Africa; about one-half the size of South
America (or slightly larger than Brazil); slightly smaller than
China; about two and one-half times the size of Western Europe
note: includes only the 50 states and District of Columbia
Land boundaries:
total: 12,248 km
border countries: Canada 8,893 km (including 2,477 km with Alaska),
Cuba 29 km (US Naval Base at Guantanamo Bay), Mexico 3,326 km
note: Guantanamo Naval Base is leased by the US and thus remains
part of Cuba
Coastline: 19,924 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: not specified
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: maritime boundary disputes with Canada
(Dixon Entrance, Beaufort Sea, Strait of Juan de Fuca, Machias Seal
Island); US Naval Base at Guantanamo Bay is leased from Cuba and
only mutual agreement or US abandonment of the area can terminate
the lease; Haiti claims Navassa Island; US has made no territorial
claim in Antarctica (but has reserved the right to do so) and does
not recognize the claims of any other nation; Republic of Marshall
Islands claims Wake Island
Climate: mostly temperate, but tropical in Hawaii and Florida and
arctic in Alaska, semiarid in the great plains west of the
Mississippi River and arid in the Great Basin of the southwest; low
winter temperatures in the northwest are ameliorated occasionally in
January and February by warm chinook winds from the eastern slopes
of the Rocky Mountains
Terrain: vast central plain, mountains in west, hills and low
mountains in east; rugged mountains and broad river valleys in
Alaska; rugged, volcanic topography in Hawaii
lowest point: Death Valley -86 m
highest point: Mount McKinley 6,194 m
Natural resources: coal, copper, lead, molybdenum, phosphates,
uranium, bauxite, gold, iron, mercury, nickel, potash, silver,
tungsten, zinc, petroleum, natural gas, timber
Land use:
arable land: 20%
permanent crops: 0%
meadows and pastures: 26%
forest and woodland: 29%
other: 25%
Irrigated land: 181,020 sq km (1989 est.)
---------
Location: Southern South America, bordering the South Atlantic
Ocean, between Argentina and Brazil
Geographic coordinates: 33 00 S, 56 00 W
Map references: South America
Area:
total area: 176,220 sq km
land area: 173,620 sq km
comparative area: slightly smaller than Washington State
Land boundaries:
total: 1,564 km
border countries: Argentina 579 km, Brazil 985 km
Coastline: 660 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 200 nm; overflight and navigation guaranteed beyond
12 nm
International disputes: short section of boundary with Argentina
is in dispute; two short sections of the boundary with Brazil are in
dispute - Arroyo de la Invernada (Arroio Invernada) area of the Rio
Cuareim (Rio Quarai) and the islands at the confluence of the Rio
Cuareim (Rio Quarai) and the Uruguay River
Climate: warm temperate; freezing temperatures almost unknown
Terrain: mostly rolling plains and low hills; fertile coastal
lowland
lowest point: Atlantic Ocean 0 m
highest point: Cerro Catedral 514 m
Natural resources: fertile soil, hydropower potential, minor
minerals
Land use:
arable land: 8%
permanent crops: 0%
meadows and pastures: 78%
forest and woodland: 4%
other: 10%
Irrigated land: 1,100 sq km (1989 est.)
---------
Location: Central Asia, north of Afghanistan
Geographic coordinates: 41 00 N, 64 00 E
Map references: Commonwealth of Independent States
Area:
total area: 447,400 sq km
land area: 425,400 sq km
comparative area: slightly larger than California
Land boundaries:
total: 6,221 km
border countries: Afghanistan 137 km, Kazakstan 2,203 km, Kyrgyzstan
1,099 km, Tajikistan 1,161 km, Turkmenistan 1,621 km
Coastline: 0 km
note: Uzbekistan borders the Aral Sea (420 km)
Maritime claims: none (landlocked)
International disputes: none
Climate: mostly midlatitude desert, long, hot summers, mild
winters; semiarid grassland in east
Terrain: mostly flat-to-rolling sandy desert with dunes; broad,
flat intensely irrigated river valleys along course of Amu Darya and
Sirdaryo; Fergana Valley in east surrounded by mountainous
Tajikistan and Kyrgyzstan; shrinking Aral Sea in west
lowest point: Saryqamish Kuli -12 m
highest point: Adelunga Toghi 4,301 m
Natural resources: natural gas, petroleum, coal, gold, uranium,
silver, copper, lead and zinc, tungsten, molybdenum
Land use:
arable land: 10%
permanent crops: 1%
meadows and pastures: 47%
forest and woodland: 0%
other: 42%
Irrigated land: 41,550 sq km (1990)','2891d22fb87d7418660df33e34930e4feece98ff8625e51ba58a8396bb422ac6','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd6c97469865a577854fed7282b3add45bfafa414d6da8e4afeb02cd1c074cea',1996,'CM','Cameroon','geography',137,'---------
Location: Eastern Africa, bordering the Red Sea, between Djibouti
and Sudan
Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
Area:
total area: 121,320 sq km
land area: 121,320 sq km
comparative area: slightly larger than Pennsylvania
Land boundaries:
total: 1,630 km
border countries: Djibouti 113 km, Ethiopia 912 km, Sudan 605 km
Coastline: 1,151 km (land and island coastline is 2,234 km)
Maritime claims: NA
International disputes: a dispute with Yemen over sovereignty of
the Hanish Islands in the southern Red Sea has been submitted to
arbitration under the auspices of the ICJ
Climate: hot, dry desert strip along Red Sea coast; cooler and
wetter in the central highlands (up to 61 cm of rainfall annually);
semiarid in western hills and lowlands; rainfall heaviest during
June-September except on coastal desert
Terrain: dominated by extension of Ethiopian north-south trending
highlands, descending on the east to a coastal desert plain, on the
northwest to hilly terrain and on the southwest to flat-to-rolling
plains
lowest point: Kobar Sink -75 m
highest point: Soira 3,013 m
Natural resources: gold, potash, zinc, copper, salt, probably oil
(petroleum geologists are prospecting for it), fish
Land use:
arable land: 3%
permanent crops: 2% (coffee)
meadows and pastures: 40%
forest and woodland: 5%
other: 50%
Irrigated land: NA sq km
---------
Location: Eastern Europe, bordering the Baltic Sea and Gulf of
Finland, between Latvia and Russia
Geographic coordinates: 59 00 N, 26 00 E
Map references: Europe
Area:
total area: 45,100 sq km
land area: 43,200 sq km
comparative area: slightly larger than New Hampshire and Vermont
combined
note: includes 1,520 islands in the Baltic Sea
Land boundaries:
total: 557 km
border countries: Latvia 267 km, Russia 290 km
Coastline: 1,393 km
Maritime claims:
exclusive economic zone: limits to be fixed in coordination with
neighboring states
territorial sea: 12 nm
International disputes: claims over 2,000 sq km of Russian
territory in the Narva and Pechora regions - based on boundary
established under the 1921 Peace Treaty of Tartu; disputes maritime
border with Latvia - primary concern is fishing rights around Ruhne
Island in the Gulf of Riga
Climate: maritime, wet, moderate winters, cool summers
Terrain: marshy, lowlands
lowest point: Baltic Sea 0 m
highest point: Suur Munamagi 318 m
Natural resources: shale oil, peat, phosphorite, amber
Land use:
arable land: 22%
permanent crops: 0%
meadows and pastures: 11%
forest and woodland: 31%
other: 36%
Irrigated land: 110 sq km (1990)
---------
Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N, 38 00 E
Map references: Africa
Area:
total area: 1,127,127 sq km
land area: 1,119,683 sq km
comparative area: slightly less than twice the size of Texas
Land boundaries:
total: 5,311 km
border countries: Djibouti 337 km, Eritrea 912 km, Kenya 830 km,
Somalia 1,626 km, Sudan 1,606 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: southern half of the boundary with Somalia
is a Provisional Administrative Line; territorial dispute with
Somalia over the Ogaden
Climate: tropical monsoon with wide topographic-induced variation
Terrain: high plateau with central mountain range divided by Great
Rift Valley
lowest point: Denakil -125 m
highest point: Ras Dashen Terara 4,620 m
Natural resources: small reserves of gold, platinum, copper, potash
Land use:
arable land: 12%
permanent crops: 1%
meadows and pastures: 41%
forest and woodland: 24%
other: 22%
Irrigated land: 1,620 sq km (1989 est.)
---------
Location: Southern Africa, island in the Mozambique Channel, about
one-half of the way from southern Madagascar to southern Mozambique
Geographic coordinates: 22 20 S, 40 22 E
Map references: Africa
Area:
total area: 28 sq km
land area: 28 sq km
comparative area: about 0.1 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 22.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by Madagascar
Climate: tropical
Terrain: NA
lowest point: Indian Ocean 0 m
highest point: unnamed location 24 m
Natural resources: negligible
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA% (heavily wooded)
other: NA%
Irrigated land: 0 sq km
---------
Location: Southern South America, islands in the South Atlantic
Ocean, east of southern Argentina
Geographic coordinates: 51 45 S, 59 00 W
Map references: South America
Area:
total area: 12,170 sq km
land area: 12,170 sq km
comparative area: slightly smaller than Connecticut
note: includes the two main islands of East and West Falkland and
about 200 small islands
Land boundaries: 0 km
Coastline: 1,288 km
Maritime claims:
continental shelf: 200 nm
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: administered by the UK, claimed by','cb09da9261067b23794372592ca43ae03df07ed8d82fc7b69a6daaac96e28d88','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5cd41cd07a64a6c64b5a1fa3f1345eb843c74c0380381a6ea09f622a935e728',1996,'AR','Argentina','geography',140,'Climate: cold marine; strong westerly winds, cloudy, humid; rain
occurs on more than half of days in year; occasional snow all year,
except in January and February, but does not accumulate
Terrain: rocky, hilly, mountainous with some boggy, undulating
plains
lowest point: Atlantic Ocean 0 m
highest point: Mount Usborne 705 m
Natural resources: fish, wildlife
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 99%
forest and woodland: 0%
other: 1%
Irrigated land: NA sq km
---------
Location: Northern Europe, island group between the Norwegian Sea
and the north Atlantic Ocean, about one-half of the way from Iceland
to Norway
Geographic coordinates: 62 00 N, 7 00 W
Map references: Europe
Area:
total area: 1,400 sq km
land area: 1,400 sq km
comparative area: eight times the size of Washington, DC
Land boundaries: 0 km
Coastline: 764 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: mild winters, cool summers; usually overcast; foggy, windy
Terrain: rugged, rocky, some low peaks; cliffs along most of coast
lowest point: Atlantic Ocean 0 m
highest point: Slaettaratindur 882 m
Natural resources: fish
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 98%
Irrigated land: NA sq km
---------
Location: Oceania, island group in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
Geographic coordinates: 18 00 S, 175 00 E
Map references: Oceania
Area:
total area: 18,270 sq km
land area: 18,270 sq km
comparative area: slightly smaller than New Jersey
Land boundaries: 0 km
Coastline: 1,129 km
Maritime claims: measured from claimed archipelagic baselines
continental shelf: 200-m depth or to the depth of exploitation;
rectilinear shelf claim added
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical marine; only slight seasonal temperature
variation
Terrain: mostly mountains of volcanic origin
lowest point: Pacific Ocean 0 m
highest point: Tomanivi 1,324 m
Natural resources: timber, fish, gold, copper, offshore oil
potential
Land use:
arable land: 8%
permanent crops: 5%
meadows and pastures: 3%
forest and woodland: 65%
other: 19%
Irrigated land: 10 sq km (1989 est.)
---------
Location: Northern Europe, bordering the Baltic Sea, Gulf of
Bothnia, and Gulf of Finland, between Sweden and Russia
Geographic coordinates: 64 00 N, 26 00 E
Map references: Europe
Area:
total area: 337,030 sq km
land area: 305,470 sq km
comparative area: slightly smaller than Montana
Land boundaries:
total: 2,628 km
border countries: Norway 729 km, Sweden 586 km, Russia 1,313 km
Coastline: 1,126 km (excludes islands and coastal indentations)
Maritime claims:
contiguous zone: 6 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 12 nm
territorial sea: 4 nm
International disputes: none
Climate: cold temperate; potentially subarctic, but comparatively
mild because of moderating influence of the North Atlantic Current,
Baltic Sea, and more than 60,000 lakes
Terrain: mostly low, flat to rolling plains interspersed with
lakes and low hills
lowest point: Baltic Sea 0 m
highest point: Haltiatunturi 1,328 m
Natural resources: timber, copper, zinc, iron ore, silver
Land use:
arable land: 8%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 76%
other: 16%
Irrigated land: 620 sq km (1989 est.)
---------
Location: Western Europe, bordering the Bay of Biscay and English
Channel, between Belgium and Spain southeast of the UK; bordering
the Mediterranean Sea, between Italy and Spain
Geographic coordinates: 46 00 N, 2 00 E
Map references: Europe
Area:
total area: 547,030 sq km
land area: 545,630 sq km
comparative area: slightly more than twice the size of Colorado
note: includes only metropolitan France (which includes Corsica),
but excludes the overseas administrative divisions
Land boundaries:
total: 2,892.4 km
border countries: Andorra 60 km, Belgium 620 km, Germany 451 km,
Italy 488 km, Luxembourg 73 km, Monaco 4.4 km, Spain 623 km,
Switzerland 573 km
Coastline: 3,427 km (mainland 2,783 km, Corsica 644 km)
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: Madagascar claims Bassas da India, Europa
Island, Glorioso Islands, Juan de Nova Island, and Tromelin Island;
Comoros claims Mayotte; Mauritius claims Tromelin Island; Seychelles
claims Tromelin Island; Suriname claims part of French Guiana;
Mexico claims Clipperton Island; territorial claim in Antarctica
(Adelie Land); Saint Pierre and Miquelon is focus of maritime
boundary dispute between Canada and France; claims Matthew and
Hunter Islands east of New Caledonia
Climate: generally cool winters and mild summers, but mild winters
and hot summers along the Mediterranean
Terrain: mostly flat plains or gently rolling hills in north and
west; remainder is mountainous, especially Pyrenees in south, Alps
in east
lowest point: Rhone River delta -2 m
highest point: Mont Blanc 4,807 m
Natural resources: coal, iron ore, bauxite, fish, timber, zinc,
potash
Land use:
arable land: 32%
permanent crops: 2%
meadows and pastures: 23%
forest and woodland: 27%
other: 16%
note: includes Corsica
Irrigated land: 14,850 sq km (1993 est.); note - includes Corsica
---------
Location: Northern South America, bordering the North Atlantic
Ocean, between Brazil and Suriname
Geographic coordinates: 4 00 N, 53 00 W
Map references: South America
Area:
total area: 91,000 sq km
land area: 89,150 sq km
comparative area: slightly smaller than Indiana
Land boundaries:
total: 1,183 km
border countries: Brazil 673 km, Suriname 510 km
Coastline: 378 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: Suriname claims area between Riviere
Litani and Riviere Marouini (both headwaters of the Lawa)
Climate: tropical; hot, humid; little seasonal temperature
variation
Terrain: low-lying coastal plains rising to hills and small
mountains
lowest point: Atlantic Ocean 0 m
highest point: Bellevue de l''Inini 851 m
Natural resources: bauxite, timber, gold (widely scattered),
cinnabar, kaolin, fish
Land use:
arable land: NEGL%
permanent crops: NEGL%
meadows and pastures: NEGL%
forest and woodland: 88%
other: 12% (1992)
Irrigated land: NA sq km
---------
Location: Central South America, northeast of Argentina
Geographic coordinates: 23 00 S, 58 00 W
Map references: South America
Area:
total area: 406,750 sq km
land area: 397,300 sq km
comparative area: slightly smaller than California
Land boundaries:
total: 3,920 km
border countries: Argentina 1,880 km, Bolivia 750 km, Brazil 1,290 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: short section of the boundary with Brazil,
just west of Salto del Guaira (Guaira Falls) on the Rio Parana, has
not been determined
Climate: subtropical; substantial rainfall in the eastern
portions, becoming semiarid in the far west
Terrain: grassy plains and wooded hills east of Rio Paraguay; Gran
Chaco region west of Rio Paraguay mostly low, marshy plain near the
river, and dry forest and thorny scrub elsewhere
lowest point: junction of Rio Paraguay and Rio Parana 46 m
highest point: Cerro San Rafael 850 m
Natural resources: hydropower, timber, iron ore, manganese,
limestone
Land use:
arable land: 20%
permanent crops: 1%
meadows and pastures: 39%
forest and woodland: 35%
other: 5%
Irrigated land: 670 sq km (1989 est.)
Climate: variable, with mostly westerly winds throughout the year,
interspersed with periods of calm; nearly all precipitation falls as
snow
Terrain: most of the islands, rising steeply from the sea, are
rugged and mountainous; South Georgia is largely barren and has
steep, glacier-covered mountains; the South Sandwich Islands are of
volcanic origin with some active volcanoes
lowest point: Atlantic Ocean 0 m
highest point: Mount Paget 2,915 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (largely covered by permanent ice and snow with some
sparse vegetation consisting of grass, moss, and lichen)
Irrigated land: 0 sq km','430feca3b8a6b8ce26c6d595c37e6213186214ed38037adf08e88e20b9c69533','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e027ee20440eced1f86072ebc504ea71fa9589072c4bfa889499948c9c902fd9',1996,'NR','Nauru','geography',152,'---------
Location: Southern Africa, islands in the southern Indian Ocean,
about equidistant between Africa, Antarctica, and Australia; note -
French Southern and Antarctic Lands includes Ile Amsterdam, Ile
Saint-Paul, Iles Crozet, and Iles Kerguelen in the southern Indian
Ocean, along with the French-claimed sector of Antarctica, "Adelie
Land"; the US does not recognize the French claim to "Adelie Land"
Geographic coordinates: 43 00 S, 67 00 E
Map references: Antarctic Region
Area:
total area: 7,781 sq km
land area: 7,781 sq km
comparative area: slightly less than 1.5 times the size of Delaware
note: includes Ile Amsterdam, Ile Saint-Paul, Iles Crozet and Iles
Kerguelen; excludes "Adelie Land" claim of about 500,000 sq km in
Antarctica that is not recognized by the US
Land boundaries: 0 km
Coastline: 1,232 km
Maritime claims:
exclusive economic zone: 200 nm from Iles Kerguelen only
territorial sea: 12 nm
International disputes: "Adelie Land" claim in Antarctica is not
recognized by the US
Climate: antarctic
Terrain: volcanic
lowest point: Indian Ocean 0 m
highest point: Mont Ross on Kerguelen 1,850 m
Natural resources: fish, crayfish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Western Africa, bordering the Atlantic Ocean at the
Equator, between Congo and Equatorial Guinea
Geographic coordinates: 1 00 S, 11 45 E
Map references: Africa
Area:
total area: 267,670 sq km
land area: 257,670 sq km
comparative area: slightly smaller than Colorado
Land boundaries:
total: 2,551 km
border countries: Cameroon 298 km, Congo 1,903 km, Equatorial Guinea
350 km
Coastline: 885 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: maritime boundary dispute with Equatorial
Guinea because of disputed sovereignty over islands in Corisco Bay
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly interior; savanna in east and
south
lowest point: Atlantic Ocean 0 m
highest point: Mont Iboundji 1,575 m
Natural resources: petroleum, manganese, uranium, gold, timber,
iron ore
Land use:
arable land: 1%
permanent crops: 1%
meadows and pastures: 18%
forest and woodland: 78%
other: 2%
Irrigated land: NA sq km
---------
Location: Middle East, bordering the Mediterranean Sea, between
Egypt and Israel
Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area:
total area: 360 sq km
land area: 360 sq km
comparative area: slightly more than twice the size of Washington, DC
Land boundaries:
total: 62 km
border countries: Egypt 11 km, Israel 51 km
Coastline: 40 km
Maritime claims: Israeli occupied with current status subject to
the Israeli-Palestinian Interim Agreement - permanent status to be
determined through further negotiation
International disputes: West Bank and Gaza Strip are Israeli
occupied with current status subject to the Israeli-Palestinian
Interim Agreement - permanent status to be determined through
further negotiation
Climate: temperate, mild winters, dry and warm to hot summers
Terrain: flat to rolling, sand- and dune-covered coastal plain
lowest point: Mediterranean Sea 0 m
highest point: Abu ''Awdah (Joz Abu ''Auda) 105 m
Natural resources: NEGL
Land use:
arable land: 13%
permanent crops: 32%
meadows and pastures: 0%
forest and woodland: 0%
other: 55%
Irrigated land: 115 sq km (1992 est.)
---------
Location: Southwestern Asia, bordering the Black Sea, between
Turkey and Russia
Geographic coordinates: 42 00 N, 43 30 E
Map references: Commonwealth of Independent States
Area:
total area: 69,700 sq km
land area: 69,700 sq km
comparative area: slightly larger than South Carolina
Land boundaries:
total: 1,461 km
border countries: Armenia 164 km, Azerbaijan 322 km, Russia 723 km,
Turkey 252 km
Coastline: 310 km
Maritime claims: NA
International disputes: none
Climate: warm and pleasant; Mediterranean-like on Black Sea coast
Terrain: largely mountainous with Great Caucasus Mountains in the
north and Lesser Caucasus Mountains in the south; Kolkhida Lowland
opens to the Black Sea in the west; Mtkvari River Basin in the east;
good soils in river valley flood plains, foothills of Kolkhida
Lowland
lowest point: Black Sea 0 m
highest point: Mt''a Mqinvartsveri (Gora Kazbek) 5,048 m
Natural resources: forests, hydropower, manganese deposits, iron
ore, copper, minor coal and oil deposits; coastal climate and soils
allow for important tea and citrus growth
Land use:
arable land: 11%
permanent crops: 4%
meadows and pastures: 29%
forest and woodland: 38%
other: 18%
Irrigated land: 4,660 sq km (1990)','a7c4fc25b3dcfb9a9b9391d2f980b466f4afe35c33601e593bcdf8a4192173a0','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c50fa20e4d48016073883f81b05d92b9051eaed84717cff45364e062a9b78a8c',1996,'DK','Denmark','geography',155,'---------
Location: Central Europe, bordering the Baltic Sea and the North
Sea, between the Netherlands and Poland, south of Denmark
Geographic coordinates: 51 00 N, 9 00 E
Map references: Europe
Area:
total area: 356,910 sq km
land area: 349,520 sq km
comparative area: slightly smaller than Montana
note: includes the formerly separate Federal Republic of Germany,
the German Democratic Republic, and Berlin, following formal
unification on 3 October 1990
Land boundaries:
total: 3,621 km
border countries: Austria 784 km, Belgium 167 km, Czech Republic 646
km, Denmark 68 km, France 451 km, Luxembourg 138 km, Netherlands 577
km, Poland 456 km, Switzerland 334 km
Coastline: 2,389 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: temperate and marine; cool, cloudy, wet winters and
summers; occasional warm, tropical foehn wind; high relative humidity
Terrain: lowlands in north, uplands in center, Bavarian Alps in
south
lowest point: Freepsum Lake -2 m
highest point: Zugspitze 2,962 m
Natural resources: iron ore, coal, potash, timber, lignite,
uranium, copper, natural gas, salt, nickel
Land use:
arable land: 34%
permanent crops: 1%
meadows and pastures: 16%
forest and woodland: 30%
other: 19%
Irrigated land: 4,800 sq km (1989 est.)
---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Cote d''Ivoire and Togo
Geographic coordinates: 8 00 N, 2 00 W
Map references: Africa
Area:
total area: 238,540 sq km
land area: 230,020 sq km
comparative area: slightly smaller than Oregon
Land boundaries:
total: 2,093 km
border countries: Burkina Faso 548 km, Cote d''Ivoire 668 km, Togo
877 km
Coastline: 539 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; warm and comparatively dry along southeast
coast; hot and humid in southwest; hot and dry in north
Terrain: mostly low plains with dissected plateau in south-central
area
lowest point: Atlantic Ocean 0 m
highest point: Mount Afadjato 880 m
Natural resources: gold, timber, industrial diamonds, bauxite,
manganese, fish, rubber
Land use:
arable land: 5%
permanent crops: 7%
meadows and pastures: 15%
forest and woodland: 37%
other: 36%
Irrigated land: 80 sq km (1989)
---------
Location: Southwestern Europe, bordering the Strait of Gibraltar,
which links the Mediterranean Sea and the North Atlantic Ocean, on
the southern coast of Spain
Geographic coordinates: 36 11 N, 5 22 W
Map references: Europe
Area:
total area: 6.5 sq km
land area: 6.5 sq km
comparative area: about 11 times the size of The Mall in Washington,
DC
Land boundaries:
total: 1.2 km
border country: Spain 1.2 km
Coastline: 12 km
Maritime claims:
territorial sea: 3 nm
International disputes: source of friction between Spain and the UK
Climate: Mediterranean with mild winters and warm summers
Terrain: a narrow coastal lowland borders the Rock of Gibraltar
lowest point: Mediterranean Sea 0 m
highest point: Rock of Gibraltar 426 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km
---------
Location: Southern Africa, group of islands in the Indian Ocean,
northwest of Madagascar
Geographic coordinates: 11 30 S, 47 20 E
Map references: Africa
Area:
total area: 5 sq km
land area: 5 sq km
comparative area: about eight times the size of The Mall in
Washington, DC
note: includes Ile Glorieuse, Ile du Lys, Verte Rocks, Wreck Rock,
and South Rock
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by Madagascar
Climate: tropical
Terrain: NA
lowest point: Indian Ocean 0 m
highest point: unnamed location 12 m
Natural resources: guano, coconuts
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (all lush vegetation and coconut palms)
Irrigated land: 0 sq km
---------
Location: Southern Europe, bordering the Aegean Sea, Ionian Sea,
and the Mediterranean Sea, between Albania and Turkey
Geographic coordinates: 39 00 N, 22 00 E
Map references: Europe
Area:
total area: 131,940 sq km
land area: 130,800 sq km
comparative area: slightly smaller than Alabama
Land boundaries:
total: 1,210 km
border countries: Albania 282 km, Bulgaria 494 km, Turkey 206 km,
The Former Yugoslav Republic of Macedonia 228 km
Coastline: 13,676 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 6 nm
International disputes: complex maritime, air, and territorial
disputes with Turkey in Aegean Sea; Cyprus question; dispute with
The Former Yugoslav Republic of Macedonia over name; border
demarcation with Albania, the treatment of Albania''s ethnic Greek
minority, and migrant Albanian workers in Greece remain unresolved
issues
Climate: temperate; mild, wet winters; hot, dry summers
Terrain: mostly mountains with ranges extending into sea as
peninsulas or chains of islands
lowest point: Mediterranean Sea 0 m
highest point: Mount Olympus 2,917 m
Natural resources: bauxite, lignite, magnesite, petroleum, marble
Land use:
arable land: 23%
permanent crops: 8%
meadows and pastures: 40%
forest and woodland: 20%
other: 9%
Irrigated land: 11,900 sq km (1989 est.)','f3e5d9359e71d6a2e04c57607ccba47564c06181a9e1efb59672944f9b3f638d','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18fcbe2572a25207d0f7c10f9190b00a10ca24eb1d323c499df3e220ac67fd03',1996,'CA','Canada','geography',162,'---------
Location: Northern North America, island between the Arctic Ocean
and the North Atlantic Ocean, northeast of Canada
Geographic coordinates: 72 00 N, 40 00 W
Map references: Arctic Region
Area:
total area: 2,175,600 sq km
land area: 383,600 sq km (ice free)
comparative area: slightly more than three times the size of Texas
Land boundaries: 0 km
Coastline: 44,087 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: arctic to subarctic; cool summers, cold winters
Terrain: flat to gradually sloping icecap covers all but a narrow,
mountainous, barren, rocky coast
lowest point: Atlantic Ocean 0 m
highest point: Gunnbjorn 3,700 m
Natural resources: zinc, lead, iron ore, coal, molybdenum,
cryolite, uranium, fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 1%
forest and woodland: 0%
other: 99%
Irrigated land: 0 sq km
---------
Location: Caribbean, island in the Caribbean Sea, north of','c557c387364f55c289df1c365d33ed1f767903b62ca87662c48713bfcbe068e7','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1564399b8214945d3b6f882c63126a0223bef37250513a880a7056a40d28b2e5',1996,'PH','Philippines','geography',170,'---------
Location: Oceania, island in the North Pacific Ocean, about
three-quarters of the way from Hawaii to the Philippines
Geographic coordinates: 13 28 N, 144 47 E
Map references: Oceania
Area:
total area: 541.3 sq km
land area: 541.3 sq km
comparative area: three times the size of Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical marine; generally warm and humid, moderated by
northeast trade winds; dry season from January to June, rainy season
from July to December; little seasonal temperature variation
Terrain: volcanic origin, surrounded by coral reefs; relatively
flat coralline limestone plateau (source of most fresh water) with
steep coastal cliffs and narrow coastal plains in north, low-rising
hills in center, mountains in south
lowest point: Pacific Ocean 0 m
highest point: Mount Lamlam 406 m
Natural resources: fishing (largely undeveloped), tourism
(especially from Japan)
Land use:
arable land: 11%
permanent crops: 11%
meadows and pastures: 15%
forest and woodland: 18%
other: 45%
Irrigated land: NA sq km
---------
Location: Middle America, bordering the Caribbean Sea, between
Honduras and Belize and bordering the North Pacific Ocean, between
El Salvador and Mexico
Geographic coordinates: 15 30 N, 90 15 W
Map references: Central America and the Caribbean
Area:
total area: 108,890 sq km
land area: 108,430 sq km
comparative area: slightly smaller than Tennessee
Land boundaries:
total: 1,687 km
border countries: Belize 266 km, El Salvador 203 km, Honduras 256
km, Mexico 962 km
Coastline: 400 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: border with Belize in dispute; talks to
resolve the dispute are stalled
Climate: tropical; hot, humid in lowlands; cooler in highlands
Terrain: mostly mountains with narrow coastal plains and rolling
limestone plateau (Peten)
lowest point: Pacific Ocean 0 m
highest point: Volcan Tajumulco 4,211 m
Natural resources: petroleum, nickel, rare woods, fish, chicle
Land use:
arable land: 12%
permanent crops: 4%
meadows and pastures: 12%
forest and woodland: 40%
other: 32%
Irrigated land: 780 sq km (1989 est.)
---------
Location: Western Europe, islands in the English Channel,
northwest of France
Geographic coordinates: 49 28 N, 2 35 W
Map references: Europe
Area:
total area: 194 sq km
land area: 194 sq km
comparative area: slightly larger than Washington, DC
note: includes Alderney, Guernsey, Herm, Sark, and some other
smaller islands
Land boundaries: 0 km
Coastline: 50 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 3 nm
International disputes: none
Climate: temperate with mild winters and cool summers; about 50%
of days are overcast
Terrain: mostly level with low hills in southwest
lowest point: Atlantic Ocean 0 m
highest point: unnamed location on Sark 114 m
Natural resources: cropland
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Guinea-Bissau and Sierra Leone
Geographic coordinates: 11 00 N, 10 00 W
Map references: Africa
Area:
total area: 245,860 sq km
land area: 245,860 sq km
comparative area: slightly smaller than Oregon
Land boundaries:
total: 3,399 km
border countries: Guinea-Bissau 386 km, Cote d''Ivoire 610 km,
Liberia 563 km, Mali 858 km, Senegal 330 km, Sierra Leone 652 km
Coastline: 320 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: generally hot and humid; monsoonal-type rainy season
(June to November) with southwesterly winds; dry season (December to
May) with northeasterly harmattan winds
Terrain: generally flat coastal plain, hilly to mountainous
interior
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1,752 m
Natural resources: bauxite, iron ore, diamonds, gold, uranium,
hydropower, fish
Land use:
arable land: 6%
permanent crops: 0%
meadows and pastures: 12%
forest and woodland: 42%
other: 40%
Irrigated land: 240 sq km (1989 est.)
---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Guinea and Senegal
Geographic coordinates: 12 00 N, 15 00 W
Map references: Africa
Area:
total area: 36,120 sq km
land area: 28,000 sq km
comparative area: slightly less than three times the size of
Connecticut
Land boundaries:
total: 724 km
border countries: Guinea 386 km, Senegal 338 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; generally hot and humid; monsoonal-type rainy
season (June to November) with southwesterly winds; dry season
(December to May) with northeasterly harmattan winds
Terrain: mostly low coastal plain rising to savanna in east
lowest point: Atlantic Ocean 0 m
highest point: unnamed location in the northeast corner of the
country 300 m
Natural resources: phosphates, bauxite, unexploited deposits of
petroleum, fish, timber
Land use:
arable land: 11%
permanent crops: 1%
meadows and pastures: 43%
forest and woodland: 38%
other: 7%
Irrigated land: NA sq km
---------
Location: Northern South America, bordering the North Atlantic
Ocean, between Suriname and Venezuela
Geographic coordinates: 5 00 N, 59 00 W
Map references: South America
Area:
total area: 214,970 sq km
land area: 196,850 sq km
comparative area: slightly smaller than Idaho
Land boundaries:
total: 2,462 km
border countries: Brazil 1,119 km, Suriname 600 km, Venezuela 743 km
Coastline: 459 km
Maritime claims:
continental shelf: 200 nm or to the outer edge of the continental
margin
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: all of the area west of the Essequibo
River claimed by Venezuela; Suriname claims area between New (Upper
Courantyne) and Courantyne/Kutari Rivers (all headwaters of the
Courantyne)
Climate: tropical; hot, humid, moderated by northeast trade winds;
two rainy seasons (May to mid-August, mid-November to mid-January)
Terrain: mostly rolling highlands; low coastal plain; savanna in
south
lowest point: Atlantic Ocean 0 m
highest point: Mount Roraima 2,835 m
Natural resources: bauxite, gold, diamonds, hardwood timber,
shrimp, fish
Land use:
arable land: 3%
permanent crops: 0%
meadows and pastures: 6%
forest and woodland: 83%
other: 8%
Irrigated land: 1,300 sq km (1989 est.)
---------
Location: Caribbean, western one-third of the island of
Hispaniola, between the Caribbean Sea and the North Atlantic Ocean,
west of the Dominican Republic
Geographic coordinates: 19 00 N, 72 25 W
Map references: Central America and the Caribbean
Area:
total area: 27,750 sq km
land area: 27,560 sq km
comparative area: slightly larger than Maryland
Land boundaries:
total: 275 km
border country: Dominican Republic 275 km
Coastline: 1,771 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims US-administered Navassa Island
Climate: tropical; semiarid where mountains in east cut off trade
winds
Terrain: mostly rough and mountainous
lowest point: Caribbean Sea 0 m
highest point: Chaine de la Selle 2,680 m
Natural resources: bauxite
Land use:
arable land: 20%
permanent crops: 13%
meadows and pastures: 18%
forest and woodland: 4%
other: 45%
Irrigated land: 750 sq km (1989 est.)
---------
Location: Oceania, islands in the North Pacific Ocean, about
three-quarters of the way from Hawaii to the Philippines
Geographic coordinates: 15 12 N, 145 45 E
Map references: Oceania
Area:
total area: 477 sq km
land area: 477 sq km
comparative area: 2.5 times the size of Washington, DC
note: includes 14 islands including Saipan, Rota, and Tinian
Land boundaries: 0 km
Coastline: 1,482 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical marine; moderated by northeast trade winds,
little seasonal temperature variation; dry season December to June,
rainy season July to October
Terrain: southern islands are limestone with level terraces and
fringing coral reefs; northern islands are volcanic
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Agrihan 965 m
Natural resources: arable land, fish
Land use:
arable land: 5% on Saipan
permanent crops: NA%
meadows and pastures: 19%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
---------
Location: Northern Europe, bordering the North Sea and the North
Atlantic Ocean, west of Sweden
Geographic coordinates: 62 00 N, 10 00 E
Map references: Europe
Area:
total area: 324,220 sq km
land area: 307,860 sq km
comparative area: slightly larger than New Mexico
Land boundaries:
total: 2,515 km
border countries: Finland 729 km, Sweden 1,619 km, Russia 167 km
Coastline: 21,925 km (includes mainland 3,419 km, large islands
2,413 km, long fjords, numerous small islands, and minor
indentations 16,093 km)
Maritime claims:
contiguous zone: 10 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 4 nm
International disputes: territorial claim in Antarctica (Queen
Maud Land); maritime boundary dispute with Russia over portion of
Barents Sea
Climate: temperate along coast, modified by North Atlantic
Current; colder interior; rainy year-round on west coast
Terrain: glaciated; mostly high plateaus and rugged mountains
broken by fertile valleys; small, scattered plains; coastline deeply
indented by fjords; arctic tundra in north
lowest point: Norwegian Sea 0 m
highest point: Glittertinden 2,472 m
Natural resources: petroleum, copper, natural gas, pyrites,
nickel, iron ore, zinc, lead, fish, timber, hydropower
Land use:
arable land: 3%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 27%
other: 70%
Irrigated land: 950 sq km (1989)
---------
Location: Middle East, bordering the Arabian Sea, Gulf of Oman,
and Persian Gulf, between Yemen and UAE
Geographic coordinates: 21 00 N, 57 00 E
Map references: Middle East
Area:
total area: 212,460 sq km
land area: 212,460 sq km
comparative area: slightly smaller than Kansas
Land boundaries:
total: 1,374 km
border countries: Saudi Arabia 676 km, UAE 410 km, Yemen 288 km
Coastline: 2,092 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: no defined boundary with most of UAE, but
Administrative Line in far north
Climate: dry desert; hot, humid along coast; hot, dry interior;
strong southwest summer monsoon (May to September) in far south
Terrain: vast central desert plain, rugged mountains in north and
south
lowest point: Arabian Sea 0 m
highest point: Jabal ash Sham 2,980 m
Natural resources: petroleum, copper, asbestos, some marble,
limestone, chromium, gypsum, natural gas
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 5%
forest and woodland: 0%
other: 93%
Irrigated land: 410 sq km (1989 est.)
---------
Location: body of water between Antarctica, Asia, Australia, and
the Western Hemisphere
Geographic coordinates: 0 00 N, 160 00 W
Map references: World
Area:
total area: 165.384 million sq km
comparative area: about 18 times the size of the US; the largest
ocean (followed by the Atlantic Ocean, the Indian Ocean, and the
Arctic Ocean); covers about one-third of the global surface; larger
than the total land area of the world
note: includes Bali Sea, Bellingshausen Sea, Bering Sea, Bering
Strait, Coral Sea, East China Sea, Flores Sea, Gulf of Alaska, Gulf
of Tonkin, Java Sea, Philippine Sea, Ross Sea, Savu Sea, Sea of
Japan, Sea of Okhotsk, South China Sea, Tasman Sea, Timor Sea, and
other tributary water bodies
Coastline: 135,663 km
International disputes: some maritime disputes (see littoral
states)
Climate: planetary air pressure systems and resultant wind
patterns exhibit remarkable uniformity in the south and east; trade
winds and westerly winds are well-developed patterns, modified by
seasonal fluctuations; tropical cyclones (hurricanes) may form south
of Mexico from June to October and affect Mexico and Central
America; continental influences cause climatic uniformity to be much
less pronounced in the eastern and western regions at the same
latitude in the North Pacific Ocean; the western Pacific is
monsoonal - a rainy season occurs during the summer months, when
moisture-laden winds blow from the ocean over the land, and a dry
season during the winter months, when dry winds blow from the Asian
land mass back to the ocean; tropical cyclones (typhoons) may strike
southeast and East Asia from May to December
Terrain: surface currents in the northern Pacific are dominated by
a clockwise, warm-water gyre (broad circular system of currents) and
in the southern Pacific by a counterclockwise, cool-water gyre; in
the northern Pacific, sea ice forms in the Bering Sea and Sea of
Okhotsk in winter; in the southern Pacific, sea ice from Antarctica
reaches its northernmost extent in October; the ocean floor in the
eastern Pacific is dominated by the East Pacific Rise, while the
western Pacific is dissected by deep trenches, including the
Marianas Trench, which is the world''s deepest
lowest point: Marianas Trench -10,924 m
highest point: sea level 0 m
Natural resources: oil and gas fields, polymetallic nodules, sand
and gravel aggregates, placer deposits, fish
---------
Location: Southern Asia, bordering the Arabian Sea, between India
and Iran
Geographic coordinates: 30 00 N, 70 00 E
Map references: Asia
Area:
total area: 803,940 sq km
land area: 778,720 sq km
comparative area: slightly less than twice the size of California
Land boundaries:
total: 6,774 km
border countries: Afghanistan 2,430 km, China 523 km, India 2,912
km, Iran 909 km
Coastline: 1,046 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: status of Kashmir with India; border
dispute with Afghanistan (Durand Line); water-sharing problems over
the Indus (Wular Barrage) with upstream riparian India
Climate: mostly hot, dry desert; temperate in northwest; arctic in
north
Terrain: flat Indus plain in east; mountains in north and
northwest; Balochistan plateau in west
lowest point: Indian Ocean 0 m
highest point: K2 (Mt. Godwin-Austen) 8,611 m
Natural resources: land, extensive natural gas reserves, limited
petroleum, poor quality coal, iron ore, copper, salt, limestone
Land use:
arable land: 23%
permanent crops: 0%
meadows and pastures: 6%
forest and woodland: 4%
other: 67% (1993)
Irrigated land: 170,000 sq km (1992)
---------
Location: Oceania, group of islands in the North Pacific Ocean,
southeast of the Philippines
Geographic coordinates: 7 30 N, 134 30 E
Map references: Oceania
Area:
total area: 458 sq km
land area: 458 sq km
comparative area: slightly more than 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,519 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 12 nm
extended fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: wet season May to November; hot and humid
Terrain: varying geologically from the high, mountainous main
island of Babelthuap to low, coral islands usually fringed by large
barrier reefs
lowest point: Pacific Ocean 0 m
highest point: Mount Ngerchelchauus 242 m
Natural resources: forests, minerals (especially gold), marine
products, deep-seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
---------
Location: Oceania, atoll in the North Pacific Ocean, about
one-half of the way from Hawaii to American Samoa
Geographic coordinates: 5 52 N, 162 06 W
Map references: Oceania
Area:
total area: 11.9 sq km
land area: 11.9 sq km
comparative area: about 20 times the size of The Mall in Washington,
DC
Land boundaries: 0 km
Coastline: 14.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: equatorial, hot, and very rainy
Terrain: very low
lowest point: Pacific Ocean 0 m
highest point: unnamed location 2 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 100%
other: 0%
Irrigated land: 0 sq km','3d37f68fa7f6d6d036769852123be54fc347e68625c407e24f449ec1fc636570','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eff545e80471a4a0a3ad4a4efe2011db07c5e8ad41612e03bca230efffdf722f',1996,'AQ','Antarctica','geography',179,'---------
Location: Southern Africa, islands in the Indian Ocean, about
two-thirds of the way from Madagascar to Antarctica
Geographic coordinates: 53 06 S, 72 31 E
Map references: Antarctic Region
Area:
total area: 412 sq km
land area: 412 sq km
comparative area: 1.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 101.9 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: antarctic
Terrain: Heard Island - bleak and mountainous, with a quiescent
volcano; McDonald Islands - small and rocky
lowest point: Indian Ocean 0 m
highest point: Big Ben 2,745 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Southern Europe, an enclave of Rome (Italy)
Geographic coordinates: 41 54 N, 12 27 E
Map references: Europe
Area:
total area: 0.44 sq km
land area: 0.44 sq km
comparative area: about 0.7 times the size of The Mall in
Washington, DC
Land boundaries:
total: 3.2 km
border country: Italy 3.2 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: temperate; mild, rainy winters (September to mid-May)
with hot, dry summers (May to September)
Terrain: low hill
lowest point: unnamed location 19 m
highest point: unnamed location 75 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Middle America, bordering the Caribbean Sea, between
Guatemala and Nicaragua and bordering the North Pacific Ocean,
between El Salvador and Nicaragua
Geographic coordinates: 15 00 N, 86 30 W
Map references: Central America and the Caribbean
Area:
total area: 112,090 sq km
land area: 111,890 sq km
comparative area: slightly larger than Tennessee
Land boundaries:
total: 1,520 km
border countries: Guatemala 256 km, El Salvador 342 km, Nicaragua
922 km
Coastline: 820 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: natural extension of territory or to 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: land boundary dispute with El Salvador
mostly resolved by 11 September 1992 International Court of Justice
(ICJ) decision; with respect to the maritime boundary in the Golfo
de Fonseca, ICJ referred to an earlier agreement in this century and
advised that some tripartite resolution among El Salvador, Honduras,
and Nicaragua likely would be required; maritime boundary dispute
with Nicaragua
Climate: subtropical in lowlands, temperate in mountains
Terrain: mostly mountains in interior, narrow coastal plains
lowest point: Caribbean Sea 0 m
highest point: Cerro Las Minas 2,870 m
Natural resources: timber, gold, silver, copper, lead, zinc, iron
ore, antimony, coal, fish
Land use:
arable land: 14%
permanent crops: 2%
meadows and pastures: 30%
forest and woodland: 34%
other: 20%
Irrigated land: 900 sq km (1989 est.)
---------
Location: Eastern Asia, bordering the South China Sea and China
Geographic coordinates: 22 15 N, 114 10 E
Map references: Southeast Asia
Area:
total area: 1,040 sq km
land area: 990 sq km
comparative area: six times the size of Washington, DC
Land boundaries:
total: 30 km
border country: China 30 km
Coastline: 733 km
Maritime claims:
territorial sea: 3 nm
International disputes: none
Climate: tropical monsoon; cool and humid in winter, hot and rainy
from spring through summer, warm and sunny in fall
Terrain: hilly to mountainous with steep slopes; lowlands in north
lowest point: South China Sea 0 m
highest point: Tai Mo Shan 958 m
Natural resources: outstanding deepwater harbor, feldspar
Land use:
arable land: 7%
permanent crops: 1%
meadows and pastures: 1%
forest and woodland: 12%
other: 79%
Irrigated land: 20 sq km (1989)
---------
Location: Oceania, island in the North Pacific Ocean, about
one-half of the way from Hawaii to Australia
Geographic coordinates: 0 48 N, 176 38 W
Map references: Oceania
Area:
total area: 1.6 sq km
land area: 1.6 sq km
comparative area: about three times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 6.4 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: equatorial; scant rainfall, constant wind, burning sun
Terrain: low-lying, nearly level, sandy, coral island surrounded
by a narrow fringing reef; depressed central area
lowest point: Pacific Ocean 0 m
highest point: unnamed location 3 m
Natural resources: guano (deposits worked until late 1800s)
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 5%
other: 95%
Irrigated land: 0 sq km
---------
Location: Central Europe, northwest of Romania
Geographic coordinates: 47 00 N, 20 00 E
Map references: Europe
Area:
total area: 93,030 sq km
land area: 92,340 sq km
comparative area: slightly smaller than Indiana
Land boundaries:
total: 2,009 km
border countries: Austria 366 km, Croatia 329 km, Romania 443 km,
Serbia and Montenegro 151 km (all with Serbia), Slovakia 515 km,
Slovenia 102 km, Ukraine 103 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: Gabcikovo Dam dispute with Slovakia
Climate: temperate; cold, cloudy, humid winters; warm summers
Terrain: mostly flat to rolling plains; hills and low mountains on
the Slovakian border
lowest point: Tisza River 78 m
highest point: Kekes 1,014 m
Natural resources: bauxite, coal, natural gas, fertile soils
Land use:
arable land: 51%
permanent crops: 6%
meadows and pastures: 13%
forest and woodland: 18%
other: 12%
Irrigated land: 1,750 sq km (1989)
---------
Location: Northern Europe, island between the Greenland Sea and
the North Atlantic Ocean, northwest of the UK
Geographic coordinates: 65 00 N, 18 00 W
Map references: Arctic Region
Area:
total area: 103,000 sq km
land area: 100,250 sq km
comparative area: slightly smaller than Kentucky
Land boundaries: 0 km
Coastline: 4,988 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: Rockall continental shelf dispute
involving Denmark, Ireland, and the UK (Ireland and the UK have
signed a boundary agreement in the Rockall area)
Climate: temperate; moderated by North Atlantic Current; mild,
windy winters; damp, cool summers
Terrain: mostly plateau interspersed with mountain peaks,
icefields; coast deeply indented by bays and fiords
lowest point: Atlantic Ocean 0 m
highest point: Hvannadalshnukur 2,119 m
Natural resources: fish, hydropower, geothermal power, diatomite
Land use:
arable land: 1%
permanent crops: 0%
meadows and pastures: 20%
forest and woodland: 1%
other: 78%
Irrigated land: NA sq km
---------
Location: Southern Asia, bordering the Arabian Sea and the Bay of
Bengal, between Burma and Pakistan
Geographic coordinates: 20 00 N, 77 00 E
Map references: Asia
Area:
total area: 3,287,590 sq km
land area: 2,973,190 sq km
comparative area: slightly more than one-third the size of the US
Land boundaries:
total: 14,103 km
border countries: Bangladesh 4,053 km, Bhutan 605 km, Burma 1,463
km, China 3,380 km, Nepal 1,690 km, Pakistan 2,912 km
Coastline: 7,000 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: boundaries with Bangladesh and China in
dispute; status of Kashmir with Pakistan; water-sharing problems
with downstream riparians, Bangladesh over the Ganges and Pakistan
over the Indus (Wular Barrage)
Climate: varies from tropical monsoon in south to temperate in
north
Terrain: upland plain (Deccan Plateau) in south, flat to rolling
plain along the Ganges, deserts in west, Himalayas in north
lowest point: Indian Ocean 0 m
highest point: Kanchenjunga 8,598 m
Natural resources: coal (fourth-largest reserves in the world),
iron ore, manganese, mica, bauxite, titanium ore, chromite, natural
gas, diamonds, petroleum, limestone
Land use:
arable land: 55%
permanent crops: 1%
meadows and pastures: 4%
forest and woodland: 23%
other: 17%
Irrigated land: 430,390 sq km (1989)
---------
Location: body of water between Africa, Antarctica, Asia, and','27e8412d437f06ccd67f15d4a70c84aa8417104d53fdfc7ca0469dee89da2a77','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd5148353eaaec2f77fdc5552b28aab7d892ac9d5cbd40e6bb15f9041683ccf7',1996,'PK','Pakistan','geography',186,'---------
Location: Middle East, bordering the Gulf of Oman, the Persian
Gulf, and the Caspian Sea, between Iraq and Pakistan
Geographic coordinates: 32 00 N, 53 00 E
Map references: Middle East
Area:
total area: 1.648 million sq km
land area: 1.636 million sq km
comparative area: slightly larger than Alaska
Land boundaries:
total: 5,440 km
border countries: Afghanistan 936 km, Armenia 35 km,
Azerbaijan-proper 432 km, Azerbaijan-Naxcivan exclave 179 km, Iraq
1,458 km, Pakistan 909 km, Turkey 499 km, Turkmenistan 992 km
Coastline: 2,440 km
note: Iran also borders the Caspian Sea (740 km)
Maritime claims:
contiguous zone: 24 nm
continental shelf: natural prolongation
exclusive economic zone: bilateral agreements, or median lines in
the Persian Gulf
territorial sea: 12 nm
International disputes: Iran and Iraq restored diplomatic
relations in 1990 but are still trying to work out written
agreements settling outstanding disputes from their eight-year war
concerning border demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shatt al-Arab waterway; Iran
occupies two islands in the Persian Gulf claimed by the UAE: Lesser
Tunb (called Tunb as Sughra in Arabic by UAE and Jazireh-ye Tonb-e
Kuchek in Persian by Iran) and Greater Tunb (called Tunb al Kubra in
Arabic by UAE and Jazireh-ye Tonb-e Bozorg in Persian by Iran); it
jointly administers with the UAE an island in the Persian Gulf
claimed by the UAE (called Abu Musa in Arabic by UAE and Jazireh-ye
Abu Musa in Persian by Iran); in 1992 the dispute over Abu Musa and
the Tunb islands became more acute when Iran unilaterally tried to
control the entry of third country nationals into the UAE portion of
Abu Musa island, Tehran subsequently backed off in the face of
significant diplomatic support for the UAE in the region, but in
1994 it increased its military presence on the disputed islands;
periodic disputes with Afghanistan over Helmand water rights;
Caspian Sea boundaries are not yet determined; support to clients in','8e647ad71b630fa9538bfe085ba866d43b83e133fc4d9e01df3e5989be1a0737','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5765538dc3d880c7e18e9e0b98499399038e536c1212604a10f965bd98464347',1996,'AF','Afghanistan','geography',187,'Climate: mostly arid or semiarid, subtropical along Caspian coast
Terrain: rugged, mountainous rim; high, central basin with
deserts, mountains; small, discontinuous plains along both coasts
lowest point: Caspian Sea -28 m
highest point: Qolleh-ye Damavand 5,671 m
Natural resources: petroleum, natural gas, coal, chromium, copper,
iron ore, lead, manganese, zinc, sulfur
Land use:
arable land: 8%
permanent crops: 0%
meadows and pastures: 27%
forest and woodland: 11%
other: 54%
Irrigated land: 57,500 sq km (1989 est.)
---------
Location: Middle East, bordering the Persian Gulf, between Iran
and Kuwait
Geographic coordinates: 33 00 N, 44 00 E
Map references: Middle East
Area:
total area: 437,072 sq km
land area: 432,162 sq km
comparative area: slightly more than twice the size of Idaho
Land boundaries:
total: 3,631 km
border countries: Iran 1,458 km, Jordan 181 km, Kuwait 242 km, Saudi
Arabia 814 km, Syria 605 km, Turkey 331 km
Coastline: 58 km
Maritime claims:
continental shelf: not specified
territorial sea: 12 nm
International disputes: Iran and Iraq restored diplomatic
relations in 1990 but are still trying to work out written
agreements settling outstanding disputes from their eight-year war
concerning border demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shatt al Arab waterway; in
November 1994, Iraq formally accepted the UN-demarcated border with
Kuwait which had been spelled out in Security Council Resolutions
687 (1991), 773 (1993), and 883 (1993); this formally ends earlier
claims to Kuwait and to Bubiyan and Warbah islands; dispute over
water development plans by Turkey for the Tigris and Euphrates Rivers
Climate: mostly desert; mild to cool winters with dry, hot,
cloudless summers; northern mountainous regions along Iranian and
Turkish borders experience cold winters with occasionally heavy
snows which melt in early spring, sometimes causing extensive
flooding in central and southern Iraq
Terrain: mostly broad plains; reedy marshes along Iranian border
in south; mountains along borders with Iran and Turkey
lowest point: Persian Gulf 0 m
highest point: Gundah Zhur 3,608 m
Natural resources: petroleum, natural gas, phosphates, sulfur
Land use:
arable land: 12%
permanent crops: 1%
meadows and pastures: 9%
forest and woodland: 3%
other: 75%
Irrigated land: 25,500 sq km (1989 est.)
---------
Location: Western Europe, occupying five-sixths of the island of
Ireland in the North Atlantic Ocean, west of Great Britain
Geographic coordinates: 53 00 N, 8 00 W
Map references: Europe
Area:
total area: 70,280 sq km
land area: 68,890 sq km
comparative area: slightly larger than West Virginia
Land boundaries:
total: 360 km
border country: UK 360 km
Coastline: 1,448 km
Maritime claims:
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: Northern Ireland question with the UK;
Rockall continental shelf dispute involving Denmark, Iceland, and
the UK (Ireland and the UK have signed a boundary agreement in the
Rockall area)
Climate: temperate maritime; modified by North Atlantic Current;
mild winters, cool summers; consistently humid; overcast about half
the time
Terrain: mostly level to rolling interior plain surrounded by
rugged hills and low mountains; sea cliffs on west coast
lowest point: Atlantic Ocean 0 m
highest point: Carrauntoohill 1,041 m
Natural resources: zinc, lead, natural gas, petroleum, barite,
copper, gypsum, limestone, dolomite, peat, silver
Land use:
arable land: 14%
permanent crops: 0%
meadows and pastures: 71%
forest and woodland: 5%
other: 10%
Irrigated land: NA sq km
---------
Location: Middle East, bordering the Mediterranean Sea, between
Egypt and Lebanon
Geographic coordinates: 31 30 N, 34 45 E
Map references: Middle East
Area:
total area: 20,770 sq km
land area: 20,330 sq km
comparative area: slightly larger than New Jersey
Land boundaries:
total: 1,006 km
border countries: Egypt 255 km, Gaza Strip 51 km, Jordan 238 km,
Lebanon 79 km, Syria 76 km, West Bank 307 km
Coastline: 273 km
Maritime claims:
continental shelf: to depth of exploitation
territorial sea: 12 nm
International disputes: West Bank and Gaza Strip are Israeli
occupied with current status subject to the Israeli-Palestinian
Interim Agreement - permanent status to be determined through
further negotiation; Golan Heights is Israeli occupied; Israeli
troops in southern Lebanon since June 1982
Climate: temperate; hot and dry in southern and eastern desert
areas
Terrain: Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley
lowest point: Dead Sea -408 m
highest point: Har Meron 1,208 m
Natural resources: copper, phosphates, bromide, potash, clay,
sand, sulfur, asphalt, manganese, small amounts of natural gas and
crude oil
Land use:
arable land: 17%
permanent crops: 5%
meadows and pastures: 40%
forest and woodland: 6%
other: 32%
Irrigated land: 2,140 sq km (1989)
---------
Location: Southern Europe, a peninsula extending into the central
Mediterranean Sea, northeast of Tunisia
Geographic coordinates: 42 50 N, 12 50 E
Map references: Europe
Area:
total area: 301,230 sq km
land area: 294,020 sq km
comparative area: slightly larger than Arizona
note: includes Sardinia and Sicily
Land boundaries:
total: 1,935.2 km
border countries: Austria 430 km, France 488 km, Holy See (Vatican
City) 3.2 km, San Marino 39 km, Slovenia 235 km, Switzerland 740 km
Coastline: 7,600 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 12 nm
International disputes: Italy is negotiating with Slovenia over
property and minority rights issues dating from World War II
Climate: predominantly Mediterranean; Alpine in far north; hot,
dry in south
Terrain: mostly rugged and mountainous; some plains, coastal
lowlands
lowest point: Mediterranean Sea 0 m
highest point: Mont Blanc 4,807 m
Natural resources: mercury, potash, marble, sulfur, dwindling
natural gas and crude oil reserves, fish, coal
Land use:
arable land: 32%
permanent crops: 10%
meadows and pastures: 17%
forest and woodland: 22%
other: 19%
Irrigated land: 31,000 sq km (1989 est.)
---------
Location: Caribbean, island in the Caribbean Sea, south of Cuba
Geographic coordinates: 18 15 N, 77 30 W
Map references: Central America and the Caribbean
Area:
total area: 10,990 sq km
land area: 10,830 sq km
comparative area: slightly smaller than Connecticut
Land boundaries: 0 km
Coastline: 1,022 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; hot, humid; temperate interior
Terrain: mostly mountains with narrow, discontinuous coastal plain
lowest point: Caribbean Sea 0 m
highest point: Blue Mountain Peak 2,256 m
Natural resources: bauxite, gypsum, limestone
Land use:
arable land: 19%
permanent crops: 6%
meadows and pastures: 18%
forest and woodland: 28%
other: 29%
Irrigated land: 350 sq km (1989 est.)
---------
Location: Northern Europe, island between the Greenland Sea and
the Norwegian Sea, northeast of Iceland
Geographic coordinates: 71 00 N, 8 00 W
Map references: Arctic Region
Area:
total area: 373 sq km
land area: 373 sq km
comparative area: slightly more than twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 124.1 km
Maritime claims:
contiguous zone: 10 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 4 nm
International disputes: none
Climate: arctic maritime with frequent storms and persistent fog
Terrain: volcanic island, partly covered by glaciers
lowest point: Norwegian Sea 0 m
highest point: Haakon VII Toppen (Beerenberg) 2,277 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Eastern Asia, island chain between the North Pacific
Ocean and the Sea of Japan, east of the Korean Peninsula
Geographic coordinates: 36 00 N, 138 00 E
Map references: Asia
Area:
total area: 377,835 sq km
land area: 374,744 sq km
comparative area: slightly smaller than California
note: includes Bonin Islands (Ogasawara-gunto), Daito-shoto,
Minami-jima, Okinotori-shima, Ryukyu Islands (Nansei-shoto), and
Volcano Islands (Kazan-retto)
Land boundaries: 0 km
Coastline: 29,751 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm; 3 nm in the international straits - La
Perouse or Soya, Tsugaru, Osumi, and Eastern and Western Channels of
the Korea or Tsushima Strait
International disputes: islands of Etorofu, Kunashiri, Shikotan,
and the Habomai group occupied by the Soviet Union in 1945, now
administered by Russia, claimed by Japan; Liancourt Rocks disputed
with South Korea; Senkaku-shoto (Senkaku Islands) claimed by China
and Taiwan
Climate: varies from tropical in south to cool temperate in north
Terrain: mostly rugged and mountainous
lowest point: Hachiro-gata -4 m
highest point: Fujiyama 3,776 m
Natural resources: negligible mineral resources, fish
Land use:
arable land: 13%
permanent crops: 1%
meadows and pastures: 1%
forest and woodland: 67%
other: 18%
Irrigated land: 28,680 sq km (1989)
---------
Location: Oceania, island in the South Pacific Ocean, about
one-half of the way from Hawaii to the Cook Islands
Geographic coordinates: 0 22 S, 160 03 W
Map references: Oceania
Area:
total area: 4.5 sq km
land area: 4.5 sq km
comparative area: about eight times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; scant rainfall, constant wind, burning sun
Terrain: sandy, coral island surrounded by a narrow fringing reef
lowest point: Pacific Ocean 0 m
highest point: unnamed location 23 m
Natural resources: guano (deposits worked until late 1800s)
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Western Europe, island in the English Channel, northwest
of France
Geographic coordinates: 49 15 N, 2 10 W
Map references: Europe
Area:
total area: 117 sq km
land area: 117 sq km
comparative area: about 0.7 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 3 nm
International disputes: none
Climate: temperate; mild winters and cool summers
Terrain: gently rolling plain with low, rugged hills along north
coast
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 143 m
Natural resources: agricultural land
Land use:
arable land: 57%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
---------
Location: Oceania, atoll in the North Pacific Ocean, about
one-third of the way from Hawaii to the Marshall Islands
Geographic coordinates: 16 45 N, 169 30 W
Map references: Oceania
Area:
total area: 2.8 sq km
land area: 2.8 sq km
comparative area: about 4.7 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 10 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical, but generally dry; consistent northeast trade
winds with little seasonal temperature variation
Terrain: mostly flat
lowest point: Pacific Ocean 0 m
highest point: Summit Peak 5 m
Natural resources: NA; guano deposits worked until depletion about
1890
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Middle East, northwest of Saudi Arabia
Geographic coordinates: 31 00 N, 36 00 E
Map references: Middle East
Area:
total area: 89,213 sq km
land area: 88,884 sq km
comparative area: slightly smaller than Indiana
Land boundaries:
total: 1,619 km
border countries: Iraq 181 km, Israel 238 km, Saudi Arabia 728 km,
Syria 375 km, West Bank 97 km
Coastline: 26 km
Maritime claims:
territorial sea: 3 nm
International disputes: none
Climate: mostly arid desert; rainy season in west (November to
April)
Terrain: mostly desert plateau in east, highland area in west;
Great Rift Valley separates East and West Banks of the Jordan River
lowest point: Dead Sea -408 m
highest point: Jabal Ram 1,754 m
Natural resources: phosphates, potash, shale oil
Land use:
arable land: 4%
permanent crops: 0.5%
meadows and pastures: 1%
forest and woodland: 0.5%
other: 94%
Irrigated land: 570 sq km (1989 est.)
---------
Location: Southern Africa, island in the Mozambique Channel, about
one-third of the way between Madagascar and Mozambique
Geographic coordinates: 17 03 S, 42 45 E
Map references: Africa
Area:
total area: 4.4 sq km
land area: 4.4 sq km
comparative area: about seven times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 24.1 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to depth the of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by Madagascar
Climate: tropical
Terrain: NA
lowest point: Indian Ocean 0 m
highest point: unnamed location 10 m
Natural resources: guano deposits and other fertilizers
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 90%
other: 10%
Irrigated land: 0 sq km
---------
Location: Central Asia, northwest of China
Geographic coordinates: 48 00 N, 68 00 E
Map references: Commonwealth of Independent States
Area:
total area: 2,717,300 sq km
land area: 2,669,800 sq km
comparative area: slightly less than four times the size of Texas
Land boundaries:
total: 12,012 km
border countries: China 1,533 km, Kyrgyzstan 1,051 km, Russia 6,846
km, Turkmenistan 379 km, Uzbekistan 2,203 km
Coastline: 0 km (landlocked)
note: Kazakstan borders the Aral Sea (1,015 km) and the Caspian Sea
(1,894 km)
Maritime claims: none (landlocked)
International disputes: Caspian Sea boundaries are not yet
determined
Climate: continental, cold winters and hot summers, arid and
semiarid
Terrain: extends from the Volga to the Altai Mountains and from
the plains in western Siberia to oasis and desert in Central Asia
lowest point: Vpadina Kaundy -132 m
highest point: Zhengis Shingy 7,439 m
Natural resources: major deposits of petroleum, coal, iron ore,
manganese, chrome ore, nickel, cobalt, copper, molybdenum, lead,
zinc, bauxite, gold, uranium
Land use:
arable land: 15%
permanent crops: NEGL%
meadows and pastures: 57%
forest and woodland: 4%
other: 24%
Irrigated land: 23,080 sq km (1990)
---------
Location: Eastern Africa, bordering the Indian Ocean, between
Somalia and Tanzania
Geographic coordinates: 1 00 N, 38 00 E
Map references: Africa
Area:
total area: 582,650 sq km
land area: 569,250 sq km
comparative area: slightly more than twice the size of Nevada
Land boundaries:
total: 3,446 km
border countries: Ethiopia 830 km, Somalia 682 km, Sudan 232 km,
Tanzania 769 km, Uganda 933 km
Coastline: 536 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: administrative boundary with Sudan does
not coincide with international boundary; possible claim by Somalia
based on unification of ethnic Somalis
Climate: varies from tropical along coast to arid in interior
Terrain: low plains rise to central highlands bisected by Great
Rift Valley; fertile plateau in west
lowest point: Indian Ocean 0 m
highest point: Mount Kenya 5,199 m
Natural resources: gold, limestone, soda ash, salt barytes,
rubies, fluorspar, garnets, wildlife
Land use:
arable land: 3%
permanent crops: 1%
meadows and pastures: 7%
forest and woodland: 4%
other: 85%
Irrigated land: 520 sq km (1989)
---------
Location: Oceania, reef in the North Pacific Ocean, about one-half
of the way from Hawaii to American Samoa
Geographic coordinates: 6 24 N, 162 24 W
Map references: Oceania
Area:
total area: 1 sq km
land area: 1 sq km
comparative area: about 1.7 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 3 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical, but moderated by prevailing winds
Terrain: low and nearly level
lowest point: Pacific Ocean 0 m
highest point: unnamed location 1 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Oceania, group of islands in the Pacific Ocean,
straddling the equator and the International Date Line, about
one-half of the way from Hawaii to Australia
Geographic coordinates: 1 25 N, 173 00 E
Map references: Oceania
Area:
total area: 717 sq km
land area: 717 sq km
comparative area: four times the size of Washington, DC
note: includes three island groups - Gilbert Islands, Line Islands,
Phoenix Islands
Land boundaries: 0 km
Coastline: 1,143 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; marine, hot and humid, moderated by trade winds
Terrain: mostly low-lying coral atolls surrounded by extensive
reefs
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Banaba 81 m
Natural resources: phosphate (production discontinued in 1979)
Land use:
arable land: 0%
permanent crops: 51%
meadows and pastures: 0%
forest and woodland: 3%
other: 46%
Irrigated land: NA sq km
---------
Location: Eastern Asia, northern half of the Korean Peninsula
bordering the Korea Bay and the Sea of Japan, between China and
South Korea
Geographic coordinates: 40 00 N, 127 00 E
Map references: Asia
Area:
total area: 120,540 sq km
land area: 120,410 sq km
comparative area: slightly smaller than Mississippi
Land boundaries:
total: 1,673 km
border countries: China 1,416 km, South Korea 238 km, Russia 19 km
Coastline: 2,495 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
military boundary line: 50 nm in the Sea of Japan and the exclusive
economic zone limit in the Yellow Sea where all foreign vessels and
aircraft without permission are banned
International disputes: short section of boundary with China is
indefinite; Demarcation Line with South Korea
Climate: temperate with rainfall concentrated in summer
Terrain: mostly hills and mountains separated by deep, narrow
valleys; coastal plains wide in west, discontinuous in east
lowest point: Sea of Japan 0 m
highest point: Paektu-san 2,744 m
Natural resources: coal, lead, tungsten, zinc, graphite,
magnesite, iron ore, copper, gold, pyrites, salt, fluorspar,
hydropower
Land use:
arable land: 18%
permanent crops: 1%
meadows and pastures: 0%
forest and woodland: 74%
other: 7%
Irrigated land: 14,000 sq km (1989)
---------
Location: Eastern Asia, southern half of the Korean Peninsula
bordering the Sea of Japan and the Yellow Sea, south of North Korea
Geographic coordinates: 37 00 N, 127 30 E
Map references: Asia
Area:
total area: 98,480 sq km
land area: 98,190 sq km
comparative area: slightly larger than Indiana
Land boundaries:
total: 238 km
border country: North Korea 238 km
Coastline: 2,413 km
Maritime claims:
continental shelf: not specified
territorial sea: 12 nm; 3 nm in the Korea Strait
International disputes: Demarcation Line with North Korea;
Liancourt Rocks claimed by Japan
Climate: temperate, with rainfall heavier in summer than winter
Terrain: mostly hills and mountains; wide coastal plains in west
and south
lowest point: Sea of Japan 0 m
highest point: Halla-san 1,950 m
Natural resources: coal, tungsten, graphite, molybdenum, lead,
hydropower
Land use:
arable land: 21%
permanent crops: 1%
meadows and pastures: 1%
forest and woodland: 67%
other: 10%
Irrigated land: 13,530 sq km (1989)
---------
Location: Middle East, bordering the Persian Gulf, between Iraq
and Saudi Arabia
Geographic coordinates: 29 30 N, 45 45 E
Map references: Middle East
Area:
total area: 17,820 sq km
land area: 17,820 sq km
comparative area: slightly smaller than New Jersey
Land boundaries:
total: 464 km
border countries: Iraq 242 km, Saudi Arabia 222 km
Coastline: 499 km
Maritime claims:
territorial sea: 12 nm
International disputes: in November 1994, Iraq formally accepted
the UN-demarcated border with Kuwait which had been spelled out in
Security Council Resolutions 687 (1991), 773 (1993), and 883 (1993);
this formally ends earlier claims to Kuwait and to Bubiyan and
Warbah islands; ownership of Qaruh and Umm al Maradim islands
disputed by Saudi Arabia
Climate: dry desert; intensely hot summers; short, cool winters
Terrain: flat to slightly undulating desert plain
lowest point: Persian Gulf 0 m
highest point: unnamed location 306 m
Natural resources: petroleum, fish, shrimp, natural gas
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 8%
forest and woodland: 0%
other: 92%
Irrigated land: 20 sq km (1989 est.)
---------
Location: Central Asia, west of China
Geographic coordinates: 41 00 N, 75 00 E
Map references: Commonwealth of Independent States
Area:
total area: 198,500 sq km
land area: 191,300 sq km
comparative area: slightly smaller than South Dakota
Land boundaries:
total: 3,878 km
border countries: China 858 km, Kazakstan 1,051 km, Tajikistan 870
km, Uzbekistan 1,099 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: territorial dispute with Tajikistan on
southwestern boundary in Isfara Valley area
Climate: dry continental to polar in high Tien Shan; subtropical
in southwest (Fergana Valley); temperate in northern foothill zone
Terrain: peaks of Tien Shan and associated valleys and basins
encompass entire nation
lowest point: Kara-Daryya 132 m
highest point: Jengish Chokusu 7,439 m
Natural resources: abundant hydroelectric potential; significant
deposits of gold and rare earth metals; locally exploitable coal,
oil, and natural gas; other deposits of nepheline, mercury, bismuth,
lead, and zinc
Land use:
arable land: 7%
permanent crops: NEGL%
meadows and pastures: 42%
forest and woodland: 0%
other: 51%
Irrigated land: 10,320 sq km (1990)','671e7bc06b9e1993f7d3e3aeff1b9b4694d3e12ac9f0c62ea84a90e8ed5f5778','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eee3725769b90b486eaeedbcc3cf40ff1e86a13898c4315cf326dc6f69f4864d',1996,'TH','Thailand','geography',202,'---------
Location: Southeastern Asia, northeast of Thailand
Geographic coordinates: 18 00 N, 105 00 E
Map references: Southeast Asia
Area:
total area: 236,800 sq km
land area: 230,800 sq km
comparative area: slightly larger than Utah
Land boundaries:
total: 5,083 km
border countries: Burma 235 km, Cambodia 541 km, China 423 km,
Thailand 1,754 km, Vietnam 2,130 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: boundary dispute with Thailand
Climate: tropical monsoon; rainy season (May to November); dry
season (December to April)
Terrain: mostly rugged mountains; some plains and plateaus
lowest point: Mekong River 70 m
highest point: Phou Bia 2,817 m
Natural resources: timber, hydropower, gypsum, tin, gold, gemstones
Land use:
arable land: 4%
permanent crops: 0%
meadows and pastures: 3%
forest and woodland: 58%
other: 35%
Irrigated land: 1,554 sq km (1992 est.)
---------
Location: Eastern Europe, bordering the Baltic Sea, between
Estonia and Lithuania
Geographic coordinates: 57 00 N, 25 00 E
Map references: Europe
Area:
total area: 64,100 sq km
land area: 64,100 sq km
comparative area: slightly larger than West Virginia
Land boundaries:
total: 1,078 km
border countries: Belarus 141 km, Estonia 267 km, Lithuania 453 km,
Russia 217 km
Coastline: 531 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
continental shelf: 200-m depth or to the depth of exploitation
International disputes: the Abrene/Pytalovo section of border
ceded by the Latvian Soviet Socialist Republic to Russia in 1944;
the maritime borders with Lithuania and Estonia
Climate: maritime; wet, moderate winters
Terrain: low plain
lowest point: Baltic Sea 0 m
highest point: Gaizinkalns 312 m
Natural resources: minimal; amber, peat, limestone, dolomite
Land use:
arable land: 27%
permanent crops: 0%
meadows and pastures: 13%
forest and woodland: 39%
other: 21%
Irrigated land: 160 sq km (1990)
---------
Location: Middle East, bordering the Mediterranean Sea, between
Israel and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
Area:
total area: 10,400 sq km
land area: 10,230 sq km
comparative area: about 0.8 times the size of Connecticut
Land boundaries:
total: 454 km
border countries: Israel 79 km, Syria 375 km
Coastline: 225 km
Maritime claims:
territorial sea: 12 nm
International disputes: Israeli troops in southern Lebanon since
June 1982; Syrian troops in northern, central, and eastern Lebanon
since October 1976
Climate: Mediterranean; mild to cool, wet winters with hot, dry
summers; Lebanon mountains experience heavy winter snows
Terrain: narrow coastal plain; Al Biqa'' (Bekaa Valley) separates
Lebanon and Anti-Lebanon Mountains
lowest point: Mediterranean Sea 0 m
highest point: Jabal al Makmal 3,087 m
Natural resources: limestone, iron ore, salt, water-surplus state
in a water-deficit region
Land use:
arable land: 21%
permanent crops: 9%
meadows and pastures: 1%
forest and woodland: 8%
other: 61%
Irrigated land: 860 sq km (1990 est.)
---------
Location: Southern Africa, an enclave of South Africa
Geographic coordinates: 29 30 S, 28 30 E
Map references: Africa
Area:
total area: 30,350 sq km
land area: 30,350 sq km
comparative area: slightly larger than Maryland
Land boundaries:
total: 909 km
border country: South Africa 909 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: temperate; cool to cold, dry winters; hot, wet summers
Terrain: mostly highland with plateaus, hills, and mountains
lowest point: junction of the Orange and Makhaleng Rivers 1,400 m
highest point: Mount Thabana Ntlenyana 3,482 m
Natural resources: water, agricultural and grazing land, some
diamonds and other minerals
Land use:
arable land: 10%
permanent crops: 0%
meadows and pastures: 66%
forest and woodland: 0%
other: 24%
Irrigated land: NA sq km','9b6d55c9eb7269fea4baea3f998b54c93e0d36f06a7b0a1354512b3f56ade715','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e96079b196a1abf535b444cfc0f6400dde2d7cda15be711b7966fede11f18fb8',1996,'ZA','South Africa','geography',211,'---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Cote d''Ivoire and Sierra Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area:
total area: 111,370 sq km
land area: 96,320 sq km
comparative area: slightly larger than Tennessee
Land boundaries:
total: 1,585 km
border countries: Guinea 563 km, Cote d''Ivoire 716 km, Sierra Leone
306 km
Coastline: 579 km
Maritime claims:
territorial sea: 200 nm
International disputes: none
Climate: tropical; hot, humid; dry winters with hot days and cool
to cold nights; wet, cloudy summers with frequent heavy showers
Terrain: mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
lowest point: Atlantic Ocean 0 m
highest point: Mount Wuteve 1,380 m
Natural resources: iron ore, timber, diamonds, gold
Land use:
arable land: 1%
permanent crops: 3%
meadows and pastures: 2%
forest and woodland: 39%
other: 55%
Irrigated land: 20 sq km (1989 est.)
---------
Location: Northern Africa, bordering the Mediterranean Sea,
between Egypt and Tunisia
Geographic coordinates: 25 00 N, 17 00 E
Map references: Africa
Area:
total area: 1,759,540 sq km
land area: 1,759,540 sq km
comparative area: slightly larger than Alaska
Land boundaries:
total: 4,383 km
border countries: Algeria 982 km, Chad 1,055 km, Egypt 1,150 km,
Niger 354 km, Sudan 383 km, Tunisia 459 km
Coastline: 1,770 km
Maritime claims:
territorial sea: 12 nm
Gulf of Sidra closing line: 32 degrees 30 minutes north
International disputes: the International Court of Justice (ICJ)
ruled in February 1994 that the 100,000 sq km Aozou Strip between
Chad and Libya belongs to Chad and that Libya must withdraw from it
by 31 May 1994; Libya has withdrawn some of its forces in response
to the ICJ ruling, but still maintains part of the airfield and a
small military presence at the airfield''s water supply located in
Chad; maritime boundary dispute with Tunisia; claims part of
northern Niger and part of southeastern Algeria
Climate: Mediterranean along coast; dry, extreme desert interior
Terrain: mostly barren, flat to undulating plains, plateaus,
depressions
lowest point: Sabkhat Ghuzayyil -47 m
highest point: Bikku Bitti 2,267 m
Natural resources: petroleum, natural gas, gypsum
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 8%
forest and woodland: 0%
other: 90%
Irrigated land: 2,420 sq km (1989 est.)','a2e58ff39b55b84eb9caf78593829f80b71e8ef19e2990838594f765af6721ba','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ef499bd58cc268f504d6277f6502d5d7fae6074b3afe3fd25d211b7c8096c79',1996,'CH','Switzerland','geography',216,'---------
Location: Central Europe, between Austria and Switzerland
Geographic coordinates: 47 10 N, 9 32 E
Map references: Europe
Area:
total area: 160 sq km
land area: 160 sq km
comparative area: about 0.9 times the size of Washington, DC
Land boundaries:
total: 78 km
border countries: Austria 37 km, Switzerland 41 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: claims 1,600 square kilometers of Czech
territory confiscated from its royal family in 1918; the Czech
Republic insists that restitution does not go back before February
1948, when the communists seized power
Climate: continental; cold, cloudy winters with frequent snow or
rain; cool to moderately warm, cloudy, humid summers
Terrain: mostly mountainous (Alps) with Rhine Valley in western
third
lowest point: Ruggleller Riet 430 m
highest point: Grauspitz 2,599 m
Natural resources: hydroelectric potential
Land use:
arable land: 25%
permanent crops: 0%
meadows and pastures: 38%
forest and woodland: 19%
other: 18%
Irrigated land: NA sq km
---------
Location: Eastern Europe, bordering the Baltic Sea, between Latvia
and Russia
Geographic coordinates: 56 00 N, 24 00 E
Map references: Europe
Area:
total area: 65,200 sq km
land area: 65,200 sq km
comparative area: slightly larger than West Virginia
Land boundaries:
total: 1,273 km
border countries: Belarus 502 km, Latvia 453 km, Poland 91 km,
Russia (Kaliningrad) 227 km
Coastline: 108 km
Maritime claims:
territorial sea: 12 nm
International disputes: dispute with Russia (Kaliningrad Oblast)
over the position of the Nemunas (Nemen) River border presently
located on the Lithuanian bank and not in midriver as by
international standards; disputes maritime border with Latvia
(primary concern is oil exploration rights); treaty with Belarus
defining the border awaits ratification
Climate: maritime; wet, moderate winters and summers
Terrain: lowland, many scattered small lakes, fertile soil
lowest point: Baltic Sea 0 m
highest point: Juozapine Kalnas 292 m
Natural resources: peat
Land use:
arable land: 49%
permanent crops: 0%
meadows and pastures: 22%
forest and woodland: 16%
other: 13%
Irrigated land: 430 sq km (1990)','3aa7e66d097da4c6e162e7019e0865b10c2590430db4e0f7c105f62bb8b267a1','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56e5ea3928564c13dc97228ae2fe2b461c2e2e909fc581f1f7b7dd2b9e9f7614',1996,'DE','Germany','geography',222,'---------
Location: Western Europe, between France and Germany
Geographic coordinates: 49 45 N, 6 10 E
Map references: Europe
Area:
total area: 2,586 sq km
land area: 2,586 sq km
comparative area: slightly smaller than Rhode Island
Land boundaries:
total: 359 km
border countries: Belgium 148 km, France 73 km, Germany 138 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: modified continental with mild winters, cool summers
Terrain: mostly gently rolling uplands with broad, shallow
valleys; uplands to slightly mountainous in the north; steep slope
down to Moselle floodplain in the southeast
lowest point: Moselle River 133 m
highest point: Burgplatz 559 m
Natural resources: iron ore (no longer exploited)
Land use:
arable land: 24%
permanent crops: 1%
meadows and pastures: 20%
forest and woodland: 21%
other: 34%
Irrigated land: NA sq km
---------
Location: Eastern Asia, bordering the South China Sea and China
Geographic coordinates: 22 10 N, 113 33 E
Map references: Southeast Asia
Area:
total area: 16 sq km
land area: 16 sq km
comparative area: about 0.1 times the size of Washington, DC
Land boundaries:
total: 0.34 km
border country: China 0.34 km
Coastline: 40 km
Maritime claims: not specified
International disputes: none
Climate: subtropical; marine with cool winters, warm summers
Terrain: generally flat
lowest point: South China Sea 0 m
highest point: Coloane Alto 174 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km
---------
Location: Southeastern Europe, north of Greece
Geographic coordinates: 41 50 N, 22 00 E
Map references: Europe
Area:
total area: 25,333 sq km
land area: 24,856 sq km
comparative area: slightly larger than Vermont
Land boundaries:
total: 748 km
border countries: Albania 151 km, Bulgaria 148 km, Greece 228 km,
Serbia and Montenegro 221 km (all with Serbia)
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: dispute with Greece over name; in
September 1995, Skopje and Athens signed an interim accord resolving
their dispute over symbols and certain constitutional provisions;
Athens also lifted its economic embargo on the Former Yugoslav
Republic of Macedonia
Climate: hot, dry summers and autumns and relatively cold winters
with heavy snowfall
Terrain: mountainous territory covered with deep basins and
valleys; there are three large lakes, each divided by a frontier
line; country bisected by the Vardar River
lowest point: Vardar River 50 m
highest point: Korab 2,753 m
Natural resources: chromium, lead, zinc, manganese, tungsten,
nickel, low-grade iron ore, asbestos, sulfur, timber
Land use:
arable land: 5%
permanent crops: 5%
meadows and pastures: 20%
forest and woodland: 30%
other: 40%
Irrigated land: NA sq km','39479ed865e61e65ab979e5d08b72c4d259e13966867dfbcf640644a25d2835c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfdb96ffa5c7a614e6797a8dfb828f6bad5c38b101a2a75a405b292a3e453c80',1996,'MZ','Mozambique','geography',229,'Geographic coordinates: 20 00 S, 47 00 E
Map references: Africa
Area:
total area: 587,040 sq km
land area: 581,540 sq km
comparative area: slightly less than twice the size of Arizona
Land boundaries: 0 km
Coastline: 4,828 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or 100 nm from the 2,500-m isobath
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims Bassas da India, Europa Island,
Glorioso Islands, Juan de Nova Island, and Tromelin Island (all
administered by France)
Climate: tropical along coast, temperate inland, arid in south
Terrain: narrow coastal plain, high plateau and mountains in center
lowest point: Indian Ocean 0 m
highest point: Maromokotro 2,876 m
Natural resources: graphite, chromite, coal, bauxite, salt,
quartz, tar sands, semiprecious stones, mica, fish
Land use:
arable land: 4%
permanent crops: 1%
meadows and pastures: 58%
forest and woodland: 26%
other: 11%
Irrigated land: 9,000 sq km (1989 est.)
---------
Location: Southern Africa, east of Zambia
Geographic coordinates: 13 30 S, 34 00 E
Map references: Africa
Area:
total area: 118,480 sq km
land area: 94,080 sq km
comparative area: slightly larger than Pennsylvania
Land boundaries:
total: 2,881 km
border countries: Mozambique 1,569 km, Tanzania 475 km, Zambia 837 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: dispute with Tanzania over the boundary in
Lake Nyasa (Lake Malawi)
Climate: tropical; rainy season (November to May); dry season (May
to November)
Terrain: narrow elongated plateau with rolling plains, rounded
hills, some mountains
lowest point: junction of the Shire River and international boundary
with Mozambique 37 m
highest point: Mount Mlanje Sapitwa 3,002 m
Natural resources: limestone, unexploited deposits of uranium,
coal, and bauxite
Land use:
arable land: 25%
permanent crops: 0%
meadows and pastures: 20%
forest and woodland: 50%
other: 5%
Irrigated land: 200 sq km (1989 est.)
---------
Location: Southeastern Asia, peninsula and northern one-third of
the island of Borneo, bordering Indonesia and the South China Sea,
south of Vietnam
Geographic coordinates: 2 30 N, 112 30 E
Map references: Southeast Asia
Area:
total area: 329,750 sq km
land area: 328,550 sq km
comparative area: slightly larger than New Mexico
Land boundaries:
total: 2,669 km
border countries: Brunei 381 km, Indonesia 1,782 km, Thailand 506 km
Coastline: 4,675 km (Peninsular Malaysia 2,068 km, East Malaysia
2,607 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation;
specified boundary in the South China Sea
exclusive fishing zone: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: involved in a complex dispute over the
Spratly Islands with China, Philippines, Taiwan, Vietnam, and
possibly Brunei; State of Sabah claimed by the Philippines; Brunei
may wish to purchase the Malaysian salient that divides Brunei into
two parts; two islands in dispute with Singapore; two islands in
dispute with Indonesia
Climate: tropical; annual southwest (April to October) and
northeast (October to February) monsoons
Terrain: coastal plains rising to hills and mountains
lowest point: Indian Ocean 0 m
highest point: Mount Kinabalu 4,100 m
Natural resources: tin, petroleum, timber, copper, iron ore,
natural gas, bauxite
Land use:
arable land: 3%
permanent crops: 10%
meadows and pastures: 0%
forest and woodland: 63%
other: 24%
Irrigated land: 3,420 sq km (1989 est.)
---------
Location: Southern Asia, group of atolls in the Indian Ocean,
south-southwest of India
Geographic coordinates: 3 15 N, 73 00 E
Map references: Asia
Area:
total area: 300 sq km
land area: 300 sq km
comparative area: nearly twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 644 km
Maritime claims:
exclusive economic zone: 35-310 nm as defined by geographic
coordinates; segment of zone coincides with maritime boundary with','49564ba565b187ec1a4a21a0a547f7a90aab70810f7bf2505ff94967ba94bf0a','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('823d4edb5d346ed0dd93a9e2eed9e1bca633cd221396a32b1614f471c9884544',1996,'PG','Papua New Guinea','geography',237,'---------
Location: Oceania, group of atolls and reefs in the North Pacific
Ocean, about one-half of the way from Hawaii to Papua New Guinea
Geographic coordinates: 9 00 N, 168 00 E
Map references: Oceania
Area:
total area: 181.3 sq km
land area: 181.3 sq km
comparative area: about the size of Washington, DC
note: includes the atolls of Bikini, Enewetak, and Kwajalein
Land boundaries: 0 km
Coastline: 370.4 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims US territory of Wake Island
Climate: wet season May to November; hot and humid; islands border
typhoon belt
Terrain: low coral limestone and sand islands
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Likiep 10 m
Natural resources: phosphate deposits, marine products, deep
seabed minerals
Land use:
arable land: 0%
permanent crops: 60%
meadows and pastures: 0%
forest and woodland: 0%
other: 40%
Irrigated land: NA sq km
---------
Location: Caribbean, island in the Caribbean Sea, north of','6e933d6b449968191e1366804295fab96de48747ed2777515a28d84517be7485','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92723dd387bf2af65c43634d84e0e08ad144b8ed5c0074c6cbb618f0486fc072',1996,'MG','Madagascar','geography',243,'Geographic coordinates: 20 17 S, 57 33 E
Map references: World
Area:
total area: 1,860 sq km
land area: 1,850 sq km
comparative area: almost 11 times the size of Washington, DC
note: includes Agalega Islands, Cargados Carajos Shoals (Saint
Brandon), and Rodrigues
Land boundaries: 0 km
Coastline: 177 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims the island of Diego Garcia in
UK-administered British Indian Ocean Territory; claims
French-administered Tromelin Island
Climate: tropical, modified by southeast trade winds; warm, dry
winter (May to November); hot, wet, humid summer (November to May)
Terrain: small coastal plain rising to discontinuous mountains
encircling central plateau
lowest point: Indian Ocean 0 m
highest point: Piton de la Petite Riviere Noire 828 m
Natural resources: arable land, fish
Land use:
arable land: 54%
permanent crops: 4%
meadows and pastures: 4%
forest and woodland: 31%
other: 7%
Irrigated land: 170 sq km (1989 est.)
---------
Location: Southern Africa, island in the Mozambique Channel, about
one-half of the way from northern Madagascar to northern Mozambique
Geographic coordinates: 12 50 S, 45 10 E
Map references: Africa
Area:
total area: 375 sq km
land area: 375 sq km
comparative area: slightly more than twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 185.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by Comoros
Climate: tropical; marine; hot, humid, rainy season during
northeastern monsoon (November to May); dry season is cooler (May to
November)
Terrain: generally undulating, with deep ravines and ancient
volcanic peaks
lowest point: Indian Ocean 0 m
highest point: Benara 660 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
---------
Location: Middle America, bordering the Caribbean Sea and the Gulf
of Mexico, between Belize and the US and bordering the North Pacific
Ocean, between Guatemala and the US
Geographic coordinates: 23 00 N, 102 00 W
Map references: North America
Area:
total area: 1,972,550 sq km
land area: 1,923,040 sq km
comparative area: slightly less than three times the size of Texas
Land boundaries:
total: 4,538 km
border countries: Belize 250 km, Guatemala 962 km, US 3,326 km
Coastline: 9,330 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims Clipperton Island (French
possession)
Climate: varies from tropical to desert
Terrain: high, rugged mountains, low coastal plains, high
plateaus, and desert
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba 5,700 m
Natural resources: petroleum, silver, copper, gold, lead, zinc,
natural gas, timber
Land use:
arable land: 12%
permanent crops: 1%
meadows and pastures: 39%
forest and woodland: 24%
other: 24%
Irrigated land: 51,500 sq km (1989 est.)
Geographic coordinates: 21 06 S, 55 36 E
Map references: World
Area:
total area: 2,510 sq km
land area: 2,500 sq km
comparative area: slightly smaller than Rhode Island
Land boundaries: 0 km
Coastline: 201 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical, but moderates with elevation; cool and dry from
May to November, hot and rainy from November to April
Terrain: mostly rugged and mountainous; fertile lowlands along
coast
lowest point: Indian Ocean 0 m
highest point: Piton des Neiges 3,069 m
Natural resources: fish, arable land
Land use:
arable land: 16%
permanent crops: 3%
meadows and pastures: 5%
forest and woodland: 35%
other: 41% (1993)
Irrigated land: 60 sq km (1989 est.)
---------
Location: Southeastern Europe, bordering the Black Sea, between
Bulgaria and Ukraine
Geographic coordinates: 46 00 N, 25 00 E
Map references: Europe
Area:
total area: 237,500 sq km
land area: 230,340 sq km
comparative area: slightly smaller than Oregon
Land boundaries:
total: 2,508 km
border countries: Bulgaria 608 km, Hungary 443 km, Moldova 450 km,
Serbia and Montenegro 476 km (all with Serbia), Ukraine (north) 362
km, Ukraine (south) 169 km
Coastline: 225 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: certain territory of Moldova and Ukraine -
including Bessarabia and Northern Bukovina - are considered by
Bucharest as historically a part of Romania; this territory was
incorporated into the former Soviet Union following the
Molotov-Ribbentrop Pact in 1940
Climate: temperate; cold, cloudy winters with frequent snow and
fog; sunny summers with frequent showers and thunderstorms
Terrain: central Transylvanian Basin is separated from the Plain
of Moldavia on the east by the Carpathian Mountains and separated
from the Walachian Plain on the south by the Transylvanian Alps
lowest point: Black Sea 0 m
highest point: Moldoveanu 2,544 m
Natural resources: petroleum (reserves declining), timber, natural
gas, coal, iron ore, salt
Land use:
arable land: 43%
permanent crops: 3%
meadows and pastures: 19%
forest and woodland: 28%
other: 7%
Irrigated land: 34,500 sq km (1989 est.)
---------
Location: Northern Asia (that part west of the Urals is sometimes
included with Europe), bordering the Arctic Ocean, between Europe
and the North Pacific Ocean
Geographic coordinates: 60 00 N, 100 00 E
Map references: Asia
Area:
total area: 17,075,200 sq km
land area: 16,995,800 sq km
comparative area: slightly more than 1.8 times the size of the US
Land boundaries:
total: 19,913 km
border countries: Azerbaijan 284 km, Belarus 959 km, China
(southeast) 3,605 km, China (south) 40 km, Estonia 290 km, Finland
1,313 km, Georgia 723 km, Kazakstan 6,846 km, North Korea 19 km,
Latvia 217 km, Lithuania (Kaliningrad Oblast) 227 km, Mongolia 3,441
km, Norway 167 km, Poland (Kaliningrad Oblast) 206 km, Ukraine 1,576
km
Coastline: 37,653 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: inherited disputes from former USSR
including sections of the boundary with China; islands of Etorofu,
Kunashiri, and Shikotan and the Habomai group occupied by the Soviet
Union in 1945, administered by Russia, claimed by Japan; maritime
dispute with Norway over portion of the Barents Sea; Caspian Sea
boundaries are not yet determined; potential dispute with Ukraine
over Crimea; Estonia claims over 2,000 sq km of Russian territory in
the Narva and Pechora regions; the Abrene section of the border
ceded by the Latvian Soviet Socialist Republic to Russia in 1944;
has made no territorial claim in Antarctica (but has reserved the
right to do so) and does not recognize the claims of any other nation
Climate: ranges from steppes in the south through humid
continental in much of European Russia; subarctic in Siberia to
tundra climate in the polar north; winters vary from cool along
Black Sea coast to frigid in Siberia; summers vary from warm in the
steppes to cool along Arctic coast
Terrain: broad plain with low hills west of Urals; vast coniferous
forest and tundra in Siberia; uplands and mountains along southern
border regions
lowest point: Caspian Sea -28 m
highest point: Mount El''brus 5,633 m
Natural resources: wide natural resource base including major
deposits of oil, natural gas, coal, and many strategic minerals,
timber
note: formidable obstacles of climate, terrain, and distance hinder
exploitation of natural resources
Land use:
arable land: 8%
permanent crops: NEGL%
meadows and pastures: 5%
forest and woodland: 45%
other: 42%
Irrigated land: 56,000 sq km (1992)
---------
Location: Central Africa, east of Zaire
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total area: 26,340 sq km
land area: 24,950 sq km
comparative area: slightly smaller than Maryland
Land boundaries:
total: 893 km
border countries: Burundi 290 km, Tanzania 217 km, Uganda 169 km,
Zaire 217 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: temperate; two rainy seasons (February to April, November
to January); mild in mountains with frost and snow possible
Terrain: mostly grassy uplands and hills; relief is mountainous
with altitude declining from west to east
lowest point: Rusizi River 950 m
highest point: Volcan Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin ore), wolframite
(tungsten ore), natural gas, hydropower
Land use:
arable land: 29%
permanent crops: 11%
meadows and pastures: 18%
forest and woodland: 10%
other: 32%
Irrigated land: 40 sq km (1989 est.)
---------
Location: Southern Africa, island in the South Atlantic Ocean,
west of Angola, about two-thirds of the way from South America to
Africa
Geographic coordinates: 15 56 S, 5 42 W
Map references: Africa
Area:
total area: 410 sq km
land area: 410 sq km
comparative area: nearly two times the size of Washington, DC
note: includes Ascension, Gough Island, Inaccessible Island,
Nightingale Island, and Tristan da Cunha
Land boundaries: 0 km
Coastline: 60 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; marine; mild, tempered by trade winds
Terrain: rugged, volcanic; small scattered plateaus and plains
lowest point: Atlantic Ocean 0 m
highest point: Queen Mary''s Peak 2,060 m
Natural resources: fish
Land use:
arable land: 7%
permanent crops: 0%
meadows and pastures: 7%
forest and woodland: 3%
other: 83%
Irrigated land: NA sq km
---------
Location: Caribbean, islands in the Caribbean Sea, about one-third
of the way from Puerto Rico to Trinidad and Tobago
Geographic coordinates: 17 20 N, 62 45 W
Map references: Central America and the Caribbean
Area:
total area: 269 sq km
land area: 269 sq km
comparative area: twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 135 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm or to the edge of the continental
margin
territorial sea: 12 nm
International disputes: none
Climate: subtropical tempered by constant sea breezes; little
seasonal temperature variation; rainy season (May to November)
Terrain: volcanic with mountainous interiors
lowest point: Caribbean Sea 0 m
highest point: Mount Liamuiga 1,156 m
Natural resources: NEGL
Land use:
arable land: 22%
permanent crops: 17%
meadows and pastures: 3%
forest and woodland: 17%
other: 41%
Irrigated land: NA sq km
---------
Location: Caribbean, island in the Caribbean Sea, north of
Geographic coordinates: 15 52 S, 54 25 E
Map references: Africa
Area:
total area: 1 sq km
land area: 1 sq km
comparative area: about 1.7 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 3.7 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by Madagascar, Mauritius, and','5034fefaba188b2462e9ba8bc591441cf4e3b4856bafe0fa1999c89260a1def4','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec8fb0882bbe9742a3c9cf96908e189dbb461a57414bb528142e0091818d123a',1996,'EH','Western Sahara','geography',257,'---------
Location: Northern Africa, bordering the North Atlantic Ocean and
the Mediterranean Sea, between Algeria and Western Sahara
Geographic coordinates: 32 00 N, 5 00 W
Map references: Africa
Area:
total area: 446,550 sq km
land area: 446,300 sq km
comparative area: slightly larger than California
Land boundaries:
total: 2,002 km
border countries: Algeria 1,559 km, Western Sahara 443 km
note: excludes the length of the boundary between the places of
sovereignty and Morocco
Coastline: 1,835 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims and administers Western Sahara, but
sovereignty is unresolved and the UN is attempting to hold a
referendum on the issue; the UN-administered cease-fire has been in
effect since September 1991; Spain controls five places of
sovereignty (plazas de soberania) on and off the coast of Morocco -
the coastal enclaves of Ceuta and Melilla which Morocco contests as
well as the islands of Penon de Alhucemas, Penon de Velez de la
Gomera, and Islas Chafarinas
Climate: Mediterranean, becoming more extreme in the interior
Terrain: northern coast and interior are mountainous with large
areas of bordering plateaus, intermontane valleys, and rich coastal
plains
lowest point: Sebkha Tah -55 m
highest point: Jebel Toubkal 4,165 m
Natural resources: phosphates, iron ore, manganese, lead, zinc,
fish, salt
Land use:
arable land: 18%
permanent crops: 1%
meadows and pastures: 28%
forest and woodland: 12%
other: 41%
Irrigated land: 12,650 sq km (1989 est.)
---------
Location: Southern Africa, bordering the Mozambique Channel,
between South Africa and Tanzania
Geographic coordinates: 18 15 S, 35 00 E
Map references: Africa
Area:
total area: 801,590 sq km
land area: 784,090 sq km
comparative area: slightly less than twice the size of California
Land boundaries:
total: 4,571 km
border countries: Malawi 1,569 km, South Africa 491 km, Swaziland
105 km, Tanzania 756 km, Zambia 419 km, Zimbabwe 1,231 km
Coastline: 2,470 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands in center, high plateaus
in northwest, mountains in west
lowest point: Indian Ocean 0 m
highest point: Monte Binga 2,436 m
Natural resources: coal, titanium, natural gas
Land use:
arable land: 4%
permanent crops: 0%
meadows and pastures: 56%
forest and woodland: 20%
other: 20%
Irrigated land: 1,150 sq km (1989 est.)
---------
Location: Southern Africa, bordering the South Atlantic Ocean,
between Angola and South Africa
Geographic coordinates: 22 00 S, 17 00 E
Map references: Africa
Area:
total area: 825,418 sq km
land area: 825,418 sq km
comparative area: slightly more than half the size of Alaska
Land boundaries:
total: 3,824 km
border countries: Angola 1,376 km, Botswana 1,360 km, South Africa
855 km, Zambia 233 km
Coastline: 1,572 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: short section of boundary with Botswana is
indefinite; quadripoint with Botswana, Zambia, and Zimbabwe is in
disagreement; dispute with Botswana over uninhabited Kasikili
(Sidudu) Island in Linyanti (Chobe) River remained unresolved in
December 1995, and the parties agreed to refer the matter to the ICJ
Climate: desert; hot, dry; rainfall sparse and erratic
Terrain: mostly high plateau; Namib Desert along coast; Kalahari
Desert in east
lowest point: Atlantic Ocean 0 m
highest point: Konigstein 2,606 m
Natural resources: diamonds, copper, uranium, gold, lead, tin,
lithium, cadmium, zinc, salt, vanadium, natural gas, fish; suspected
deposits of oil, natural gas, coal, iron ore
Land use:
arable land: 1%
permanent crops: 0%
meadows and pastures: 64%
forest and woodland: 22%
other: 13%
Irrigated land: 40 sq km (1989 est.)
---------
Location: Oceania, island in the South Pacific Ocean, south of the','add3e183b81ae0292bbeab89985d440a9678f3c9cccd5a2bd8cfa51c3b006ee3','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d73d7f52041e5f72fbeafad0fbd326041fa9c34195b334131361d2ad0d3b4d9',1996,'MH','Marshall Islands','geography',263,'Geographic coordinates: 0 32 S, 166 55 E
Map references: Oceania
Area:
total area: 21 sq km
land area: 21 sq km
comparative area: about 0.1 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 30 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; monsoonal; rainy season (November to February)
Terrain: sandy beach rises to fertile ring around raised coral
reefs with phosphate plateau in center
lowest point: Pacific Ocean 0 m
highest point: unnamed location along plateau rim 61 m
Natural resources: phosphates
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km
---------
Location: Caribbean, island in the Caribbean Sea, about one-fourth
of the way from Haiti to Jamaica
Geographic coordinates: 18 25 N, 75 02 W
Map references: Central America and the Caribbean
Area:
total area: 5.2 sq km
land area: 5.2 sq km
comparative area: about nine times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by Haiti
Climate: marine, tropical
Terrain: raised coral and limestone plateau, flat to undulating;
ringed by vertical white cliffs (9 to 15 meters high)
lowest point: Caribbean Sea 0 m
highest point: unnamed location on southwest side 77 m
Natural resources: guano
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 10%
forest and woodland: 0%
other: 90%
Irrigated land: 0 sq km','e934b94564c4427695e59817b70ab26a4bbdeaa64f5ca29ec430c7b28f928c95','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ec7e699f19a434a7b762e18428fbf8d292f0dce6ab7657cdad00a6b20e59aee',1996,'HN','Honduras','geography',271,'---------
Location: Middle America, bordering both the Caribbean Sea and the
North Pacific Ocean, between Costa Rica and Honduras
Geographic coordinates: 13 00 N, 85 00 W
Map references: Central America and the Caribbean
Area:
total area: 129,494 sq km
land area: 120,254 sq km
comparative area: slightly larger than New York State
Land boundaries:
total: 1,231 km
border countries: Costa Rica 309 km, Honduras 922 km
Coastline: 910 km
Maritime claims:
contiguous zone: 25-nm security zone
continental shelf: natural prolongation
territorial sea: 200 nm
International disputes: territorial disputes with Colombia over
the Archipelago de San Andres y Providencia and Quita Sueno Bank;
with respect to the maritime boundary question in the Golfo de
Fonseca, the International Court of Justice (ICJ) referred the
disputants to an earlier agreement in this century and advised that
some tripartite resolution among El Salvador, Honduras, and
Nicaragua likely would be required; maritime boundary dispute with
Climate: tropical in lowlands, cooler in highlands
Terrain: extensive Atlantic coastal plains rising to central
interior mountains; narrow Pacific coastal plain interrupted by
volcanoes
lowest point: Pacific Ocean 0 m
highest point: Mogoton 2,438 m
Natural resources: gold, silver, copper, tungsten, lead, zinc,
timber, fish
Land use:
arable land: 9%
permanent crops: 1%
meadows and pastures: 43%
forest and woodland: 35%
other: 12%
Irrigated land: 850 sq km (1989 est.)
---------
Location: Western Africa, southeast of Algeria
Geographic coordinates: 16 00 N, 8 00 E
Map references: Africa
Area:
total area: 1.267 million sq km
land area: 1,266,700 sq km
comparative area: slightly less than twice the size of Texas
Land boundaries:
total: 5,697 km
border countries: Algeria 956 km, Benin 266 km, Burkina Faso 628 km,
Chad 1,175 km, Libya 354 km, Mali 821 km, Nigeria 1,497 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: Libya claims about 19,400 sq km in
northern Niger; demarcation of international boundaries in Lake
Chad, the lack of which has led to border incidents in the past, is
completed and awaiting ratification by Cameroon, Chad, Niger, and
Nigeria; Burkina Faso and Mali are proceeding with boundary
demarcation, including the tripoint with Niger
Climate: desert; mostly hot, dry, dusty; tropical in extreme south
Terrain: predominately desert plains and sand dunes; flat to
rolling plains in south; hills in north
lowest point: Niger River 200 m
highest point: Mont Greboun 1,944 m
Natural resources: uranium, coal, iron ore, tin, phosphates
Land use:
arable land: 3%
permanent crops: 0%
meadows and pastures: 7%
forest and woodland: 2%
other: 88%
Irrigated land: 320 sq km (1989 est.)
---------
Location: Western Africa, bordering the Gulf of Guinea, between
Benin and Cameroon
Geographic coordinates: 10 00 N, 8 00 E
Map references: Africa
Area:
total area: 923,770 sq km
land area: 910,770 sq km
comparative area: slightly more than twice the size of California
Land boundaries:
total: 4,047 km
border countries: Benin 773 km, Cameroon 1,690 km, Chad 87 km, Niger
1,497 km
Coastline: 853 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 30 nm
International disputes: demarcation of international boundaries in
vicinity of Lake Chad, the lack of which led to border incidents in
the past, is completed and awaits ratification by Cameroon, Chad,
Niger, and Nigeria; dispute with Cameroon over land and maritime
boundaries in the vicinity of the Bakasi Peninsula has been referred
to the ICJ
Climate: varies; equatorial in south, tropical in center, arid in
north
Terrain: southern lowlands merge into central hills and plateaus;
mountains in southeast, plains in north
lowest point: Atlantic Ocean 0 m
highest point: Chappal Waddi 2,419 m
Natural resources: petroleum, tin, columbite, iron ore, coal,
limestone, lead, zinc, natural gas
Land use:
arable land: 31%
permanent crops: 3%
meadows and pastures: 23%
forest and woodland: 15%
other: 28%
Irrigated land: 8,650 sq km (1989 est.)
---------
Location: Oceania, island in the South Pacific Ocean, east of Tonga
Geographic coordinates: 19 02 S, 169 52 W
Map references: Oceania
Area:
total area: 260 sq km
land area: 260 sq km
comparative area: 1.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 64 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; modified by southeast trade winds
Terrain: steep limestone cliffs along coast, central plateau
lowest point: Pacific Ocean 0 m
highest point: unnamed location near Mutalau settlement 68 m
Natural resources: fish, arable land
Land use:
arable land: 61%
permanent crops: 4%
meadows and pastures: 4%
forest and woodland: 19%
other: 12%
Irrigated land: NA sq km
---------
Location: Oceania, island in the South Pacific Ocean, east of','62603ca5fa569066f4bc85c3cac3ee54ec80bf55f570d4fb1830bb65b07ff8e6','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ae67cbe6c6eaf0f412504d83417b8e06fc23331d2531ba8c4dee11633c311af',1996,'CR','Costa Rica','geography',278,'---------
Location: Middle America, bordering both the Caribbean Sea and the
North Pacific Ocean, between Colombia and Costa Rica
Geographic coordinates: 9 00 N, 80 00 W
Map references: Central America and the Caribbean
Area:
total area: 78,200 sq km
land area: 75,990 sq km
comparative area: slightly smaller than South Carolina
Land boundaries:
total: 555 km
border countries: Colombia 225 km, Costa Rica 330 km
Coastline: 2,490 km
Maritime claims:
territorial sea: 200 nm
International disputes: none
Climate: tropical; hot, humid, cloudy; prolonged rainy season (May
to January), short dry season (January to May)
Terrain: interior mostly steep, rugged mountains and dissected,
upland plains; coastal areas largely plains and rolling hills
lowest point: Pacific Ocean 0 m
highest point: Volcan de Chiriqui 3,475 m
Natural resources: copper, mahogany forests, shrimp
Land use:
arable land: 6%
permanent crops: 2%
meadows and pastures: 15%
forest and woodland: 54%
other: 23%
Irrigated land: 320 sq km (1989 est.)
---------
Location: Southeastern Asia, group of islands including the
eastern half of the island of New Guinea between the Coral Sea and
the South Pacific Ocean, east of Indonesia
Geographic coordinates: 6 00 S, 147 00 E
Map references: Oceania
Area:
total area: 461,690 sq km
land area: 451,710 sq km
comparative area: slightly larger than California
Land boundaries:
total: 820 km
border country: Indonesia 820 km
Coastline: 5,152 km
Maritime claims: measured from claimed archipelagic baselines
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; northwest monsoon (December to March),
southeast monsoon (May to October); slight seasonal temperature
variation
Terrain: mostly mountains with coastal lowlands and rolling
foothills
lowest point: Pacific Ocean 0 m
highest point: Mount Wilhelm 4,509 m
Natural resources: gold, copper, silver, natural gas, timber, oil
potential
Land use:
arable land: 0%
permanent crops: 1%
meadows and pastures: 0%
forest and woodland: 71%
other: 28%
Irrigated land: NA sq km
---------
Location: Southeastern Asia, group of small islands and reefs in
the South China Sea, about one-third of the way from central Vietnam
to the northern Philippines
Geographic coordinates: 16 30 N, 112 00 E
Map references: Southeast Asia
Area:
total area: NA sq km
land area: NA sq km
comparative area: NA
Land boundaries: 0 km
Coastline: 518 km
Maritime claims: NA
International disputes: occupied by China, but claimed by Taiwan
and Vietnam
Climate: tropical
Terrain: NA
lowest point: South China Sea 0 m
highest point: unnamed location on Rocky Island 14 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km','e9a40ba04a9d1570daa554f3a0caac18889fb040bd147ec57b21744630054e52','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ed5e939c972f28a161142ddacab1d24c761307aab3feff363abf3f9051eeac5',1996,'ET','Ethiopia','geography',284,'---------
Location: Western Africa, island in the Atlantic Ocean, straddling
the Equator, west of Gabon
Geographic coordinates: 1 00 N, 7 00 E
Map references: Africa
Area:
total area: 960 sq km
land area: 960 sq km
comparative area: more than five times the size of Washington, DC
Land boundaries: 0 km
Coastline: 209 km
Maritime claims: measured from claimed archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; hot, humid; one rainy season (October to May)
Terrain: volcanic, mountainous
lowest point: Atlantic Ocean 0 m
highest point: Pico de Sao Tome 2,024 m
Natural resources: fish
Land use:
arable land: 1%
permanent crops: 20%
meadows and pastures: 1%
forest and woodland: 75%
other: 3%
Irrigated land: NA sq km
---------
Location: Middle East, bordering the Persian Gulf and the Red Sea,
north of Yemen
Geographic coordinates: 25 00 N, 45 00 E
Map references: Middle East
Area:
total area: 1,960,582 sq km
land area: 1,960,582 sq km
comparative area: slightly less than one-fourth the size of the US
Land boundaries:
total: 4,415 km
border countries: Iraq 814 km, Jordan 728 km, Kuwait 222 km, Oman
676 km, Qatar 60 km, UAE 457 km, Yemen 1,458 km
Coastline: 2,640 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: not specified
territorial sea: 12 nm
International disputes: large section of boundary with Yemen not
defined; location and status of boundary with UAE is not final,
defacto boundary reflects 1974 agreement; Kuwaiti ownership of Qaruh
and Umm al Maradim islands is disputed by Saudi Arabia; 1965
boundary with Qatar, renegotiated and revised in 1992, but not
official depiction
Climate: harsh, dry desert with great extremes of temperature
Terrain: mostly uninhabited, sandy desert
lowest point: Persian Gulf 0 m
highest point: Jabal Sawda'' 3,133 m
Natural resources: petroleum, natural gas, iron ore, gold, copper
Land use:
arable land: 1%
permanent crops: 0%
meadows and pastures: 39%
forest and woodland: 1%
other: 59%
Irrigated land: 4,350 sq km (1989 est.)
---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Guinea-Bissau and Mauritania
Geographic coordinates: 14 00 N, 14 00 W
Map references: Africa
Area:
total area: 196,190 sq km
land area: 192,000 sq km
comparative area: slightly smaller than South Dakota
Land boundaries:
total: 2,640 km
border countries: The Gambia 740 km, Guinea 330 km, Guinea-Bissau
338 km, Mali 419 km, Mauritania 813 km
Coastline: 531 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: short section of the boundary with The
Gambia is indefinite; boundary with Mauritania in dispute
Climate: tropical; hot, humid; rainy season (December to April)
has strong southeast winds; dry season (May to November) dominated
by hot, dry, harmattan wind
Terrain: generally low, rolling, plains rising to foothills in
southeast
lowest point: Atlantic Ocean 0 m
highest point: unnamed location in the Futa Jaldon foothills 581 m
Natural resources: fish, phosphates, iron ore
Land use:
arable land: 27%
permanent crops: 0%
meadows and pastures: 30%
forest and woodland: 31%
other: 12%
Irrigated land: 1,800 sq km (1989 est.)
---------
Location: Southeastern Europe, bordering the Adriatic Sea, between
Albania and Bosnia and Herzegovina
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area:
total area: 102,350 sq km
land area: 102,136 sq km
comparative area: slightly larger than Kentucky
note: Serbia has a total area and a land area of 88,412 sq km making
it slightly larger than Maine; Montenegro has a total area of 13,938
sq km and a land area of 13,724 sq km making it slightly larger than
Connecticut
Land boundaries:
total: 2,246 km
border countries: Albania 287 km (114 km with Serbia, 173 km with
Montenegro), Bosnia and Herzegovina 527 km (312 km with Serbia, 215
km with Montenegro), Bulgaria 318 km, Croatia (north) 241 km,
Croatia (south) 25 km, Hungary 151 km, The Former Yugoslav Republic
of Macedonia 221 km, Romania 476 km
note: the internal boundary between Montenegro and Serbia is 211 km
Coastline: 199 km (Montenegro 199 km, Serbia 0 km)
Maritime claims: NA
International disputes: disputes with Bosnia and Herzegovina and
Croatia over Serbian populated areas; Albanian majority in Kosovo
seeks independence from Serbian republic
Climate: in the north, continental climate (cold winter and hot,
humid summers with well distributed rainfall); central portion,
continental and Mediterranean climate; to the south, Adriatic
climate along the coast, hot, dry summers and autumns and relatively
cold winters with heavy snowfall inland
Terrain: extremely varied; to the north, rich fertile plains; to
the east, limestone ranges and basins; to the southeast, ancient
mountain and hills; to the southwest, extremely high shoreline with
no islands off the coast
lowest point: Adriatic Sea 0 m
highest point: Daravica 2,656 m
Natural resources: oil, gas, coal, antimony, copper, lead, zinc,
nickel, gold, pyrite, chrome
Land use:
arable land: 30%
permanent crops: 5%
meadows and pastures: 20%
forest and woodland: 25%
other: 20%
Irrigated land: NA sq km
---------
Location: Eastern Africa, group of islands in the Indian Ocean,
northeast of Madagascar
Geographic coordinates: 4 35 S, 55 40 E
Map references: Africa
Area:
total area: 455 sq km
land area: 455 sq km
comparative area: 2.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 491 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims Tromelin Island
Climate: tropical marine; humid; cooler season during southeast
monsoon (late May to September); warmer season during northwest
monsoon (March to May)
Terrain: Mahe Group is granitic, narrow coastal strip, rocky,
hilly; others are coral, flat, elevated reefs
lowest point: Indian Ocean 0 m
highest point: Morne Seychellois 905 m
Natural resources: fish, copra, cinnamon trees
Land use:
arable land: 4%
permanent crops: 18%
meadows and pastures: 0%
forest and woodland: 18%
other: 60%
Irrigated land: NA sq km
---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Guinea and Liberia
Geographic coordinates: 8 30 N, 11 30 W
Map references: Africa
Area:
total area: 71,740 sq km
land area: 71,620 sq km
comparative area: slightly smaller than South Carolina
Land boundaries:
total: 958 km
border countries: Guinea 652 km, Liberia 306 km
Coastline: 402 km
Maritime claims:
territorial sea: 200 nm
continental shelf: 200-m depth or to the depth of exploitation
International disputes: none
Climate: tropical; hot, humid; summer rainy season (May to
December); winter dry season (December to April)
Terrain: coastal belt of mangrove swamps, wooded hill country,
upland plateau, mountains in east
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani) 1,948 m
Natural resources: diamonds, titanium ore, bauxite, iron ore,
gold, chromite
Land use:
arable land: 25%
permanent crops: 2%
meadows and pastures: 31%
forest and woodland: 29%
other: 13%
Irrigated land: 340 sq km (1989 est.)
---------
Location: Southeastern Asia, islands between Malaysia and Indonesia
Geographic coordinates: 1 22 N, 103 48 E
Map references: Southeast Asia
Area:
total area: 632.6 sq km
land area: 622.6 sq km
comparative area: slightly more than three times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 193 km
Maritime claims:
exclusive fishing zone: within and beyond territorial sea, as
defined in treaties and practice
territorial sea: 3 nm
International disputes: two islands in dispute with Malaysia
Climate: tropical; hot, humid, rainy; no pronounced rainy or dry
seasons; thunderstorms occur on 40% of all days (67% of days in
April)
Terrain: lowland; gently undulating central plateau contains water
catchment area and nature preserve
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 166 m
Natural resources: fish, deepwater ports
Land use:
arable land: 4%
permanent crops: 7%
meadows and pastures: 0%
forest and woodland: 5%
other: 84%
Irrigated land: NA sq km
---------
Location: Central Europe, south of Poland
Geographic coordinates: 48 40 N, 19 30 E
Map references: Europe
Area:
total area: 48,845 sq km
land area: 48,800 sq km
comparative area: about twice the size of New Hampshire
Land boundaries:
total: 1,355 km
border countries: Austria 91 km, Czech Republic 215 km, Hungary 515
km, Poland 444 km, Ukraine 90 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: Gabcikovo Dam dispute with Hungary;
unresolved property issues with Czech Republic over redistribution
of former Czechoslovak federal property
Climate: temperate; cool summers; cold, cloudy, humid winters
Terrain: rugged mountains in the central and northern part and
lowlands in the south
lowest point: Bodrok River 94 m
highest point: Gerlachovka 2,655 m
Natural resources: brown coal and lignite; small amounts of iron
ore, copper and manganese ore; salt
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
---------
Location: Southeastern Europe, bordering the Adriatic Sea, between
Croatia and Italy
Geographic coordinates: 46 00 N, 15 00 E
Map references: Europe
Area:
total area: 20,256 sq km
land area: 20,256 sq km
comparative area: slightly larger than New Jersey
Land boundaries:
total: 1,207 km
border countries: Austria 324 km, Croatia 546 km, Italy 235 km,
Hungary 102 km
Coastline: 46.6 km
Maritime claims: NA
International disputes: maritime border dispute with Croatia over
direct access to the sea in the Adriatic; the border issue is
currently under negotiation
Climate: Mediterranean climate on the coast, continental climate
with mild to hot summers and cold winters in the plateaus and
valleys to the east
Terrain: a short coastal strip on the Adriatic, an alpine mountain
region adjacent to Italy, mixed mountain and valleys with numerous
rivers to the east
lowest point: Adriatic Sea 0 m
highest point: Triglav 2,864 m
Natural resources: lignite coal, lead, zinc, mercury, uranium,
silver
Land use:
arable land: 10%
permanent crops: 2%
meadows and pastures: 20%
forest and woodland: 45%
other: 23%
Irrigated land: NA sq km
---------
Location: Oceania, group of islands in the South Pacific Ocean,
east of Papua New Guinea
Geographic coordinates: 8 00 S, 159 00 E
Map references: Oceania
Area:
total area: 28,450 sq km
land area: 27,540 sq km
comparative area: slightly larger than Maryland
Land boundaries: 0 km
Coastline: 5,313 km
Maritime claims: measured from claimed archipelagic baselines
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical monsoon; few extremes of temperature and weather
Terrain: mostly rugged mountains with some low coral atolls
lowest point: Pacific Ocean 0 m
highest point: Mount Makarakomburu 2,447 m
Natural resources: fish, forests, gold, bauxite, phosphates, lead,
zinc, nickel
Land use:
arable land: 1%
permanent crops: 1%
meadows and pastures: 1%
forest and woodland: 93%
other: 4%
Irrigated land: NA sq km
---------
Location: Eastern Africa, bordering the Gulf of Aden and the
Indian Ocean, east of Ethiopia
Geographic coordinates: 10 00 N, 49 00 E
Map references: Africa
Area:
total area: 637,660 sq km
land area: 627,340 sq km
comparative area: slightly smaller than Texas
Land boundaries:
total: 2,366 km
border countries: Djibouti 58 km, Ethiopia 1,626 km, Kenya 682 km
Coastline: 3,025 km
Maritime claims:
territorial sea: 200 nm
International disputes: southern half of boundary with Ethiopia is
a Provisional Administrative Line; territorial dispute with Ethiopia
over the Ogaden
Climate: principally desert; December to February - northeast
monsoon, moderate temperatures in north and very hot in south; May
to October - southwest monsoon, torrid in the north and hot in the
south, irregular rainfall, hot and humid periods (tangambili)
between monsoons
Terrain: mostly flat to undulating plateau rising to hills in north
lowest point: Indian Ocean 0 m
highest point: Shimbiris 2,450 m
Natural resources: uranium and largely unexploited reserves of
iron ore, tin, gypsum, bauxite, copper, salt
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 46%
forest and woodland: 14%
other: 38%
Irrigated land: 1,600 sq km (1989 est.)
---------
Location: Southern Africa, at the southern tip of the continent of
Africa
Geographic coordinates: 29 00 S, 24 00 E
Map references: Africa
Area:
total area: 1,219,912 sq km
land area: 1,219,912 sq km
comparative area: slightly less than twice the size of Texas
note: includes Prince Edward Islands (Marion Island and Prince
Edward Island)
Land boundaries:
total: 4,750 km
border countries: Botswana 1,840 km, Lesotho 909 km, Mozambique 491
km, Namibia 855 km, Swaziland 430 km, Zimbabwe 225 km
Coastline: 2,798 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: Swaziland has asked South Africa to open
negotiations on reincorporating some nearby South African
territories that are populated by ethnic Swazis or that were long
ago part of the Swazi Kingdom
Climate: mostly semiarid; subtropical along east coast; sunny
days, cool nights
Terrain: vast interior plateau rimmed by rugged hills and narrow
coastal plain
lowest point: Atlantic Ocean 0 m
highest point: Njesuthi 3,408 m
Natural resources: gold, chromium, antimony, coal, iron ore,
manganese, nickel, phosphates, tin, uranium, gem diamonds, platinum,
copper, vanadium, salt, natural gas
Land use:
arable land: 10%
permanent crops: 1%
meadows and pastures: 65%
forest and woodland: 3%
other: 21%
Irrigated land: 11,280 sq km (1989 est.)
---------
Location: Southern South America, islands in the South Atlantic
Ocean, east of the tip of South America
Geographic coordinates: 54 30 S, 37 00 W
Map references: Antarctic Region
Area:
total area: 4,066 sq km
land area: 4,066 sq km
comparative area: slightly larger than Rhode Island
note: includes Shag Rocks, Clerke Rocks, Bird Island
Land boundaries: 0 km
Coastline: NA km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: administered by the UK, claimed by
---------
Location: Southern Africa, east of Angola
Geographic coordinates: 15 00 S, 30 00 E
Map references: Africa
Area:
total area: 752,610 sq km
land area: 740,720 sq km
comparative area: slightly larger than Texas
Land boundaries:
total: 5,664 km
border countries: Angola 1,110 km, Malawi 837 km, Mozambique 419 km,
Namibia 233 km, Tanzania 338 km, Zaire 1,930 km, Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: quadripoint with Botswana, Namibia, and
Zimbabwe is in disagreement; Tanzania-Zaire-Zambia tripoint in Lake
Tanganyika may no longer be indefinite since it has been informally
reported that the indefinite section of the Zaire-Zambia boundary
has been settled
Climate: tropical; modified by altitude; rainy season (October to
April)
Terrain: mostly high plateau with some hills and mountains
lowest point: Zambezi river 329 m
highest point: in Mafinga Hills 2,301 m
Natural resources: copper, cobalt, zinc, lead, coal, emeralds,
gold, silver, uranium, hydropower potential
Land use:
arable land: 7%
permanent crops: 0%
meadows and pastures: 47%
forest and woodland: 27%
other: 19%
Irrigated land: 320 sq km (1989 est.)','b9222eca96cb1b716a880f63bc7a45c604f52e4368407b3a1935f05f7b076918','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ea18ad25b8c988417fa9d16d9c0d80198b2a002caa8f96a54ff0ac48d3fd71d',1996,'GI','Gibraltar','geography',293,'---------
Location: Southwestern Europe, bordering the Bay of Biscay,
Mediterranean Sea, and North Atlantic Ocean, southwest of France
Geographic coordinates: 40 00 N, 4 00 W
Map references: Europe
Area:
total area: 504,750 sq km
land area: 499,400 sq km
comparative area: slightly more than twice the size of Oregon
note: includes Balearic Islands, Canary Islands, and five places of
sovereignty (plazas de soberania) on and off the coast of Morocco -
Ceuta, Mellila, Islas Chafarinas, Penon de Alhucemas, and Penon de
Velez de la Gomera
Land boundaries:
total: 1,903.2 km
border countries: Andorra 65 km, France 623 km, Gibraltar 1.2 km,
Portugal 1,214 km
note: excludes the length of the boundary between the places of
sovereignty and Morocco
Coastline: 4,964 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: Gibraltar question with UK; Spain controls
five places of sovereignty (plazas de soberania) on and off the
coast of Morocco - the coastal enclaves of Ceuta and Melilla, which
Morocco contests, as well as the islands of Penon de Alhucemas,
Penon de Velez de la Gomera, and Islas Chafarinas
Climate: temperate; clear, hot summers in interior, more moderate
and cloudy along coast; cloudy, cold winters in interior, partly
cloudy and cool along coast
Terrain: large, flat to dissected plateau surrounded by rugged
hills; Pyrenees in north
lowest point: Atlantic Ocean 0 m
highest point: Pico de Teide on Canary Islands 3,718 m
Natural resources: coal, lignite, iron ore, uranium, mercury,
pyrites, fluorspar, gypsum, zinc, lead, tungsten, copper, kaolin,
potash, hydropower
Land use:
arable land: 31%
permanent crops: 10%
meadows and pastures: 21%
forest and woodland: 31%
other: 7%
Irrigated land: 33,600 sq km (1989 est.)
---------
Location: Southeastern Asia, group of reefs in the South China
Sea, about two-thirds of the way from southern Vietnam to the
southern Philippines
Geographic coordinates: 8 38 N, 111 55 E
Map references: Southeast Asia
Area:
total area: NA sq km but less than 5 sq km
land area: less than 5 sq km
comparative area: NA
note: includes 100 or so islets, coral reefs, and sea mounts
scattered over the South China Sea
Land boundaries: 0 km
Coastline: 926 km
Maritime claims: NA
International disputes: all of the Spratly Islands are claimed by
China, Taiwan, and Vietnam; parts of them are claimed by Malaysia
and the Philippines; in 1984, Brunei established an exclusive
economic zone, which encompasses Louisa Reef, but has not publicly
claimed the island
Climate: tropical
Terrain: flat
lowest point: South China Sea 0 m
highest point: unnamed location on Southwest Cay 4 m
Natural resources: fish, guano, undetermined oil and natural gas
potential
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Southern Asia, island in the Indian Ocean, south of India
Geographic coordinates: 7 00 N, 81 00 E
Map references: Asia
Area:
total area: 65,610 sq km
land area: 64,740 sq km
comparative area: slightly larger than West Virginia
Land boundaries: 0 km
Coastline: 1,340 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical monsoon; northeast monsoon (December to March);
southwest monsoon (June to October)
Terrain: mostly low, flat to rolling plain; mountains in
south-central interior
lowest point: Indian Ocean 0 m
highest point: Pidurutalagala 2,524 m
Natural resources: limestone, graphite, mineral sands, gems,
phosphates, clay
Land use:
arable land: 16%
permanent crops: 17%
meadows and pastures: 7%
forest and woodland: 37%
other: 23%
Irrigated land: 5,600 sq km (1989 est.)
---------
Location: Northern Africa, bordering the Red Sea, between Egypt
and Eritrea
Geographic coordinates: 15 00 N, 30 00 E
Map references: Africa
Area:
total area: 2,505,810 sq km
land area: 2.376 million sq km
comparative area: slightly more than one-quarter the size of the US
Land boundaries:
total: 7,687 km
border countries: Central African Republic 1,165 km, Chad 1,360 km,
Egypt 1,273 km, Eritrea 605 km, Ethiopia 1,606 km, Kenya 232 km,
Libya 383 km, Uganda 435 km, Zaire 628 km
Coastline: 853 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 12 nm
International disputes: administrative boundary with Kenya does
not coincide with international boundary; administrative boundary
with Egypt does not coincide with international boundary creating
the "Hala''ib Triangle," a barren area of 20,580 sq km, tensions over
this disputed area began to escalate in 1992 and remain high
Climate: tropical in south; arid desert in north; rainy season
(April to October)
Terrain: generally flat, featureless plain; mountains in east and
west
lowest point: Red Sea 0 m
highest point: Kinyeti 3,187 m
Natural resources: petroleum; small reserves of iron ore, copper,
chromium ore, zinc, tungsten, mica, silver, gold
Land use:
arable land: 5%
permanent crops: 0%
meadows and pastures: 24%
forest and woodland: 20%
other: 51%
Irrigated land: 18,900 sq km (1989 est.)
---------
Location: Northern South America, bordering the North Atlantic
Ocean, between French Guiana and Guyana
Geographic coordinates: 4 00 N, 56 00 W
Map references: South America
Area:
total area: 163,270 sq km
land area: 161,470 sq km
comparative area: slightly larger than Georgia
Land boundaries:
total: 1,707 km
border countries: Brazil 597 km, French Guiana 510 km, Guyana 600 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims area in French Guiana between
Litani Rivier and Riviere Marouini (both headwaters of the Lawa
Rivier); claims area in Guyana between New (Upper Courantyne) and
Courantyne/Koetari Rivers (all headwaters of the Courantyne)
Climate: tropical; moderated by trade winds
Terrain: mostly rolling hills; narrow coastal plain with swamps
lowest point: unnamed location in the coastal plain -2 m
highest point: Wilhelmina Gebergte 1,286 m
Natural resources: timber, hydropower potential, fish, shrimp,
bauxite, iron ore, and small amounts of nickel, copper, platinum,
gold
Land use:
arable land: NEGL%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 97%
other: 3%
Irrigated land: 590 sq km (1989 est.)
---------
Location: Northern Europe, islands between the Arctic Ocean,
Barents Sea, Greenland Sea, and Norwegian Sea, north of Norway
Geographic coordinates: 78 00 N, 20 00 E
Map references: Arctic Region
Area:
total area: 62,049 sq km
land area: 62,049 sq km
comparative area: slightly smaller than West Virginia
note: includes Spitsbergen and Bjornoya (Bear Island)
Land boundaries: 0 km
Coastline: 3,587 km
Maritime claims:
exclusive fishing zone: 200 nm unilaterally claimed by Norway but
not recognized by Russia
territorial sea: 4 nm
International disputes: focus of maritime boundary dispute in the
Barents Sea between Norway and Russia
Climate: arctic, tempered by warm North Atlantic Current; cool
summers, cold winters; North Atlantic Current flows along west and
north coasts of Spitsbergen, keeping water open and navigable most
of the year
Terrain: wild, rugged mountains; much of high land ice covered;
west coast clear of ice about one-half of the year; fjords along
west and north coasts
lowest point: Arctic Ocean 0 m
highest point: Newtontoppen 1,717 m
Natural resources: coal, copper, iron ore, phosphate, zinc,
wildlife, fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (no trees and the only bushes are crowberry and
cloudberry)
Irrigated land: NA sq km
---------
Location: Southern Africa, between Mozambique and South Africa
Geographic coordinates: 26 30 S, 31 30 E
Map references: Africa
Area:
total area: 17,360 sq km
land area: 17,200 sq km
comparative area: slightly smaller than New Jersey
Land boundaries:
total: 535 km
border countries: Mozambique 105 km, South Africa 430 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: Swaziland has asked South Africa to open
negotiations on reincorporating some nearby South African
territories that are populated by ethnic Swazis or that were long
ago part of the Swazi Kingdom
Climate: varies from tropical to near temperate
Terrain: mostly mountains and hills; some moderately sloping plains
lowest point: Great Usutu River 21 m
highest point: Emlembe 1,862 m
Natural resources: asbestos, coal, clay, cassiterite, hydropower,
forests, small gold and diamond deposits, quarry stone, and talc
Land use:
arable land: 11%
permanent crops: NEGL
meadows and pastures: 62%
forest and woodland: 7%
other: 20%
Irrigated land: 640 sq km (1993 est.)','e8f329240a8a429546472d223f71acc200e5f548106a30bf3d38c8aee5d1bb50','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7d9ddcf4926e5cb0e3712eea588589b8816a518d6d7708ebf79fc6391f162b0',1996,'NO','Norway','geography',301,'---------
Location: Northern Europe, bordering the Baltic Sea, Gulf of
Bothnia, and Skagerrak, between Finland and Norway
Geographic coordinates: 62 00 N, 15 00 E
Map references: Europe
Area:
total area: 449,964 sq km
land area: 410,928 sq km
comparative area: slightly smaller than California
Land boundaries:
total: 2,205 km
border countries: Finland 586 km, Norway 1,619 km
Coastline: 3,218 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: agreed boundaries or midlines
territorial sea: 12 nm
International disputes: none
Climate: temperate in south with cold, cloudy winters and cool,
partly cloudy summers; subarctic in north
Terrain: mostly flat or gently rolling lowlands; mountains in west
lowest point: Baltic Sea 0 m
highest point: Kebnekaise 2,111 m
Natural resources: zinc, iron ore, lead, copper, silver, timber,
uranium, hydropower potential
Land use:
arable land: 7%
permanent crops: 0%
meadows and pastures: 2%
forest and woodland: 64%
other: 27%
Irrigated land: 1,120 sq km (1989 est.)
---------
Location: Central Europe, east of France
Geographic coordinates: 47 00 N, 8 00 E
Map references: Europe
Area:
total area: 41,290 sq km
land area: 39,770 sq km
comparative area: slightly more than twice the size of New Jersey
Land boundaries:
total: 1,852 km
border countries: Austria 164 km, France 573 km, Italy 740 km,
Liechtenstein 41 km, Germany 334 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: none
Climate: temperate, but varies with altitude; cold, cloudy,
rainy/snowy winters; cool to warm, cloudy, humid summers with
occasional showers
Terrain: mostly mountains (Alps in south, Jura in northwest) with
a central plateau of rolling hills, plains, and large lakes
lowest point: Lake Maggiore 195 m
highest point: Dufourspitze 4,634 m
Natural resources: hydropower potential, timber, salt
Land use:
arable land: 10%
permanent crops: 1%
meadows and pastures: 40%
forest and woodland: 26%
other: 23%
Irrigated land: 250 sq km (1989)
---------
Location: Middle East, bordering the Mediterranean Sea, between
Lebanon and Turkey
Geographic coordinates: 35 00 N, 38 00 E
Map references: Middle East
Area:
total area: 185,180 sq km
land area: 184,050 sq km
comparative area: slightly larger than North Dakota
note: includes 1,295 sq km of Israeli-occupied territory
Land boundaries:
total: 2,253 km
border countries: Iraq 605 km, Israel 76 km, Jordan 375 km, Lebanon
375 km, Turkey 822 km
Coastline: 193 km
Maritime claims:
contiguous zone: 41 nm
territorial sea: 35 nm
International disputes: Golan Heights is Israeli occupied; Hatay
question with Turkey; dispute over Turkey''s water development plans
for the Tigris and Euphrates Rivers; Syrian troops in northern,
central, and eastern Lebanon since October 1976
Climate: mostly desert; hot, dry, sunny summers (June to August)
and mild, rainy winters (December to February) along coast; cold
weather with snow or sleet periodically hitting Damascus
Terrain: primarily semiarid and desert plateau; narrow coastal
plain; mountains in west
lowest point: unnamed location near Lake Tiberias -200 m
highest point: Mount Hermon 2,814 m
Natural resources: petroleum, phosphates, chrome and manganese
ores, asphalt, iron ore, rock salt, marble, gypsum
Land use:
arable land: 28%
permanent crops: 3%
meadows and pastures: 46%
forest and woodland: 3%
other: 20%
Irrigated land: 10,000 sq km (1992)
---------
Location: Eastern Asia, islands bordering the East China Sea,
Philippine Sea, South China Sea, and Taiwan Strait, north of the
Philippines, off the southeastern coast of China
Geographic coordinates: 23 30 N, 121 00 E
Map references: Southeast Asia
Area:
total area: 35,980 sq km
land area: 32,260 sq km
comparative area: slightly smaller than Maryland and Delaware
combined
note: includes the Pescadores, Matsu, and Quemoy
Land boundaries: 0 km
Coastline: 1,448 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: involved in complex dispute over the
Spratly Islands with China, Malaysia, Philippines, Vietnam, and
possibly Brunei; Paracel Islands occupied by China, but claimed by
Vietnam and Taiwan; Japanese-administered Senkaku-shoto (Senkaku
Islands/Diaoyu Tai) claimed by China and Taiwan
Climate: tropical; marine; rainy season during southwest monsoon
(June to August); cloudiness is persistent and extensive all year
Terrain: eastern two-thirds mostly rugged mountains; flat to
gently rolling plains in west
lowest point: South China Sea 0 m
highest point: Yu Shan 3,997 m
Natural resources: small deposits of coal, natural gas, limestone,
marble, and asbestos
Land use:
arable land: 24%
permanent crops: 1%
meadows and pastures: 5%
forest and woodland: 55%
other: 15%
Irrigated land: NA sq km
---------
Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00 E
Map references: Commonwealth of Independent States
Area:
total area: 143,100 sq km
land area: 142,700 sq km
comparative area: slightly smaller than Wisconsin
Land boundaries:
total: 3,651 km
border countries: Afghanistan 1,206 km, China 414 km, Kyrgyzstan 870
km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: boundary with China in dispute;
territorial dispute with Kyrgyzstan on northern boundary in Isfara
Valley area; Afghanistan''s and other foreign support to Islamic
fighters in Tajikistan''s civil war based in northern Afghanistan
Climate: midlatitude continental, hot summers, mild winters;
semiarid to polar in Pamir Mountains
Terrain: Pamir and Altai Mountains dominate landscape; western
Fergana Valley in north, Kofarnihon and Vakhsh Valleys in southwest
lowest point: Syrdariya 300 m
highest point: Qullai Kommunizm 7,495 m
Natural resources: significant hydropower potential, some
petroleum, uranium, mercury, brown coal, lead, zinc, antimony,
tungsten
Land use:
arable land: 6%
permanent crops: 0%
meadows and pastures: 23%
forest and woodland: 0%
other: 71%
Irrigated land: 6,940 sq km (1990)
---------
Location: Eastern Africa, bordering the Indian Ocean, between
Kenya and Mozambique
Geographic coordinates: 6 00 S, 35 00 E
Map references: Africa
Area:
total area: 945,090 sq km
land area: 886,040 sq km
comparative area: slightly larger than twice the size of California
note: includes the islands of Mafia, Pemba, and Zanzibar
Land boundaries:
total: 3,402 km
border countries: Burundi 451 km, Kenya 769 km, Malawi 475 km,
Mozambique 756 km, Rwanda 217 km, Uganda 396 km, Zambia 338 km
Coastline: 1,424 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: boundary dispute with Malawi in Lake
Nyasa; Tanzania-Zaire-Zambia tripoint in Lake Tanganyika may no
longer be indefinite since it has been informally reported that the
indefinite section of the Zaire-Zambia boundary has been settled
Climate: varies from tropical along coast to temperate in highlands
Terrain: plains along coast; central plateau; highlands in north,
south
lowest point: Indian Ocean 0 m
highest point: Kilimanjaro 5,895 m
Natural resources: hydropower potential, tin, phosphates, iron
ore, coal, diamonds, gemstones, gold, natural gas, nickel
Land use:
arable land: 5%
permanent crops: 1%
meadows and pastures: 40%
forest and woodland: 47%
other: 7%
Irrigated land: 1,530 sq km (1989 est.)
---------
Location: Southeastern Asia, bordering the Andaman Sea and the
Gulf of Thailand, southeast of Burma
Geographic coordinates: 15 00 N, 100 00 E
Map references: Southeast Asia
Area:
total area: 514,000 sq km
land area: 511,770 sq km
comparative area: slightly more than twice the size of Wyoming
Land boundaries:
total: 4,863 km
border countries: Burma 1,800 km, Cambodia 803 km, Laos 1,754 km,
Malaysia 506 km
Coastline: 3,219 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: boundary dispute with Laos; unresolved
maritime boundary with Vietnam; parts of border with Cambodia in
dispute; maritime boundary with Cambodia not clearly defined
Climate: tropical; rainy, warm, cloudy southwest monsoon (mid-May
to September); dry, cool northeast monsoon (November to mid-March);
southern isthmus always hot and humid
Terrain: central plain; Khorat Plateau in the east; mountains
elsewhere
lowest point: Gulf of Thailand 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural gas, tungsten, tantalum,
timber, lead, fish, gypsum, lignite, fluorite
Land use:
arable land: 34%
permanent crops: 4%
meadows and pastures: 1%
forest and woodland: 30%
other: 31%
Irrigated land: 42,300 sq km (1989 est.)
---------
Location: Caribbean, chain of islands in the North Atlantic Ocean,
southeast of Florida
Geographic coordinates: 24 15 N, 76 00 W
Map references: Central America and the Caribbean
Area:
total area: 13,940 sq km
land area: 10,070 sq km
comparative area: slightly larger than Connecticut
Land boundaries: 0 km
Coastline: 3,542 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical marine; moderated by warm waters of Gulf Stream
Terrain: long, flat coral formations with some low rounded hills
lowest point: Atlantic Ocean 0 m
highest point: Mount Alvernia 63 m
Natural resources: salt, aragonite, timber
Land use:
arable land: 1%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 32%
other: 67%
Irrigated land: NA sq km
---------
Location: Western Africa, bordering the North Atlantic Ocean and','2265f0f9afb2d388420757211e20aa52dfaee6665b2ef11125f91a42b5d626c7','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71b5cec0b2f2849a9a1a8d5544d41d2be66076681c48d74cc88e179b7921fc9d',1996,'SN','Senegal','geography',308,'Geographic coordinates: 13 28 N, 16 34 W
Map references: Africa
Area:
total area: 11,300 sq km
land area: 10,000 sq km
comparative area: slightly more than twice the size of Delaware
Land boundaries:
total: 740 km
border country: Senegal 740 km
Coastline: 80 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: short section of boundary with Senegal is
indefinite
Climate: tropical; hot, rainy season (June to November); cooler,
dry season (November to May)
Terrain: flood plain of the Gambia River flanked by some low hills
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 53 m
Natural resources: fish
Land use:
arable land: 16%
permanent crops: 0%
meadows and pastures: 9%
forest and woodland: 20%
other: 55%
Irrigated land: 120 sq km (1989 est.)
---------
Location: Western Africa, bordering the North Atlantic Ocean,
between Benin and Ghana
Geographic coordinates: 8 00 N, 1 10 E
Map references: Africa
Area:
total area: 56,790 sq km
land area: 54,390 sq km
comparative area: slightly smaller than West Virginia
Land boundaries:
total: 1,647 km
border countries: Benin 644 km, Burkina Faso 126 km, Ghana 877 km
Coastline: 56 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 30 nm
International disputes: none
Climate: tropical; hot, humid in south; semiarid in north
Terrain: gently rolling savanna in north; central hills; southern
plateau; low coastal plain with extensive lagoons and marshes
lowest point: Atlantic Ocean 0 m
highest point: Pic Baumann 986 m
Natural resources: phosphates, limestone, marble
Land use:
arable land: 25%
permanent crops: 1%
meadows and pastures: 4%
forest and woodland: 28%
other: 42%
Irrigated land: 70 sq km (1989 est.)
---------
Location: Oceania, group of islands in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Geographic coordinates: 9 00 S, 172 00 W
Map references: Oceania
Area:
total area: 10 sq km
land area: 10 sq km
comparative area: about 17 times the size of The Mall in Washington,
DC
Land boundaries: 0 km
Coastline: 101 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; moderated by trade winds (April to November)
Terrain: coral atolls enclosing large lagoons
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km','72346b28202cd48682d980ae18a1dad20ff2bb353abc877a64f21250e65dd40a','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92425f7569a7a093cc9f932986951a8043e3285c5d9857e8223be6897e397018',1996,'NZ','New Zealand','geography',319,'---------
Location: Oceania, archipelago in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
Geographic coordinates: 20 00 S, 175 00 W
Map references: Oceania
Area:
total area: 748 sq km
land area: 718 sq km
comparative area: four times the size of Washington, DC
Land boundaries: 0 km
Coastline: 419 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; modified by trade winds; warm season (December
to May), cool season (May to December)
Terrain: most islands have limestone base formed from uplifted
coral formation; others have limestone overlying volcanic base
lowest point: Pacific Ocean 0 m
highest point: on Kao Island 1,033 m
Natural resources: fish, fertile soil
Land use:
arable land: 25%
permanent crops: 55%
meadows and pastures: 6%
forest and woodland: 12%
other: 2%
Irrigated land: NA sq km
---------
Location: Caribbean, islands between the Caribbean Sea and the
North Atlantic Ocean, northeast of Venezuela
Geographic coordinates: 11 00 N, 61 00 W
Map references: Central America and the Caribbean
Area:
total area: 5,130 sq km
land area: 5,130 sq km
comparative area: slightly smaller than Delaware
Land boundaries: 0 km
Coastline: 362 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the outer edge of the continental
margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; rainy season (June to December)
Terrain: mostly plains with some hills and low mountains
lowest point: Caribbean Sea 0 m
highest point: El Cerro del Aripo 940 m
Natural resources: petroleum, natural gas, asphalt
Land use:
arable land: 14%
permanent crops: 17%
meadows and pastures: 2%
forest and woodland: 44%
other: 23%
Irrigated land: 220 sq km (1989 est.)
---------
Location: Southern Africa, island in the Indian Ocean, east of','d4121cd69dc559e6e3bb3956f2e020e7a892b4f4c36cb949147cbeb48df30796','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2baee586fa98e8c1453dc03c2c8d92eb788c0bf2f64161c78a4b07ae7a9640d',1996,'SC','Seychelles','geography',322,'Climate: tropical
Terrain: sandy
lowest point: Indian Ocean 0 m
highest point: unnamed location 7 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (scattered bushes)
Irrigated land: 0 sq km
---------
Location: Northern Africa, bordering the Mediterranean Sea,
between Algeria and Libya
Geographic coordinates: 34 00 N, 9 00 E
Map references: Africa
Area:
total area: 163,610 sq km
land area: 155,360 sq km
comparative area: slightly larger than Georgia
Land boundaries:
total: 1,424 km
border countries: Algeria 965 km, Libya 459 km
Coastline: 1,148 km
Maritime claims:
contiguous zone: 24 nm
territorial sea: 12 nm
International disputes: maritime boundary dispute with Libya; land
boundary dispute with Algeria settled in 1993; Malta and Tunisia are
discussing the commercial exploitation of the continental shelf
between their countries, particularly for oil exploration
Climate: temperate in north with mild, rainy winters and hot, dry
summers; desert in south
Terrain: mountains in north; hot, dry central plain; semiarid
south merges into the Sahara
lowest point: Shatt al Gharsah -17 m
highest point: Jabal ash Shanabi 1,544 m
Natural resources: petroleum, phosphates, iron ore, lead, zinc,
salt
Land use:
arable land: 20%
permanent crops: 10%
meadows and pastures: 19%
forest and woodland: 4%
other: 47%
Irrigated land: 2,750 sq km (1989)
---------
Location: Southwestern Asia (that part west of the Bosporus is
sometimes included with Europe), bordering the Black Sea, between
Bulgaria and Georgia, and bordering the Aegean Sea and the
Mediterranean Sea, between Greece and Syria
Geographic coordinates: 39 00 N, 35 00 E
Map references: Middle East
Area:
total area: 780,580 sq km
land area: 770,760 sq km
comparative area: slightly larger than Texas
Land boundaries:
total: 2,627 km
border countries: Armenia 268 km, Azerbaijan 9 km, Bulgaria 240 km,
Georgia 252 km, Greece 206 km, Iran 499 km, Iraq 331 km, Syria 822 km
Coastline: 7,200 km
Maritime claims:
exclusive economic zone: in Black Sea only - to the maritime
boundary agreed upon with the former USSR
territorial sea: 6 nm in the Aegean Sea,; 12 nm in the Black Sea and
in the Mediterranean Sea
International disputes: complex maritime, air and territorial
disputes with Greece in Aegean Sea; Cyprus question; Hatay question
with Syria; dispute with downstream riparians (Syria and Iraq) over
water development plans for the Tigris and Euphrates Rivers
Climate: temperate; hot, dry summers with mild, wet winters;
harsher in interior
Terrain: mostly mountains; narrow coastal plain; high central
plateau (Anatolia)
lowest point: Mediterranean Sea 0 m
highest point: Mount Ararat 5,166 m
Natural resources: antimony, coal, chromium, mercury, copper,
borate, sulfur, iron ore
Land use:
arable land: 30%
permanent crops: 4%
meadows and pastures: 12%
forest and woodland: 26%
other: 28%
Irrigated land: 22,200 sq km (1989 est.)
---------
Location: Central Asia, bordering the Caspian Sea, between Iran
and Kazakstan
Geographic coordinates: 40 00 N, 60 00 E
Map references: Commonwealth of Independent States
Area:
total area: 488,100 sq km
land area: 488,100 sq km
comparative area: slightly larger than California
Land boundaries:
total: 3,736 km
border countries: Afghanistan 744 km, Iran 992 km, Kazakstan 379 km,
Uzbekistan 1,621 km
Coastline: 0 km
note: Turkmenistan borders the Caspian Sea (1,768 km)
Maritime claims: none (landlocked)
International disputes: Caspian Sea boundaries are not yet
determined
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with dunes rising to
mountains in the south; low mountains along border with Iran;
borders Caspian Sea in west
lowest point: Sarygamysh Koli -110 m
highest point: Ayrybaba 3,139 m
Natural resources: petroleum, natural gas, coal, sulfur, salt
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 69%
forest and woodland: 0%
other: 29%
Irrigated land: 12,450 sq km (1990)
---------
Location: Caribbean, two island groups in the North Atlantic
Ocean, southeast of The Bahamas
Geographic coordinates: 21 45 N, 71 35 W
Map references: Central America and the Caribbean
Area:
total area: 430 sq km
land area: 430 sq km
comparative area: 2.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 389 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; marine; moderated by trade winds; sunny and
relatively dry
Terrain: low, flat limestone; extensive marshes and mangrove swamps
lowest point: Caribbean Sea 0 m
highest point: Blue Hills 49 m
Natural resources: spiny lobster, conch
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 98%
Irrigated land: NA sq km
---------
Location: Oceania, island group consisting of nine coral atolls in
the South Pacific Ocean, about one-half of the way from Hawaii to','42eb6792cc2debed36bc3a0afc42b9da6b23bc55b4050bcf0c878c455021515c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42d4e4ed4ffba9c181dee0ef732805bc1fbe385f93b6d58e1bfed284668131c5',1996,'NC','New Caledonia','geography',333,'Climate: tropical; moderated by southeast trade winds
Terrain: mostly mountains of volcanic origin; narrow coastal plains
lowest point: Pacific Ocean 0 m
highest point: Mount Tabwemasana 1,877 m
Natural resources: manganese, hardwood forests, fish
Land use:
arable land: 1%
permanent crops: 5%
meadows and pastures: 2%
forest and woodland: 1%
other: 91%
Irrigated land: NA sq km','6c1a7f0cec3beca8bd40a1fe52b7f84b8ef4f0956677744a5b3cf901adab4be9','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('749cd76c916987bcddfe61f631ba9804879f55d39dacd17b6db07aae76c305a6',1996,'GY','Guyana','geography',341,'---------
Location: Northern South America, bordering the Caribbean Sea and
the North Atlantic Ocean, between Colombia and Guyana
Geographic coordinates: 8 00 N, 66 00 W
Map references: South America
Area:
total area: 912,050 sq km
land area: 882,050 sq km
comparative area: slightly more than twice the size of California
Land boundaries:
total: 4,993 km
border countries: Brazil 2,200 km, Colombia 2,050 km, Guyana 743 km
Coastline: 2,800 km
Maritime claims:
contiguous zone: 15 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claims all of Guyana west of the Essequibo
River; maritime boundary dispute with Colombia in the Gulf of
======================================================================
@Vietnam
-------
Map
---
Location: 16 00 N, 106 00 E -- Southeastern Asia, bordering the
Gulf of Thailand, Gulf of Tonkin, and South China Sea, between China
and Cambodia
Flag
----
Description: red with a large yellow five-pointed star in the
center
---------
Location: Southeastern Asia, bordering the Gulf of Thailand, Gulf
of Tonkin, and South China Sea, between China and Cambodia
Geographic coordinates: 16 00 N, 106 00 E
Map references: Southeast Asia
Area:
total area: 329,560 sq km
land area: 325,360 sq km
comparative area: slightly larger than New Mexico
Land boundaries:
total: 3,818 km
border countries: Cambodia 982 km, China 1,281 km, Laos 1,555 km
Coastline: 3,444 km (excludes islands)
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: maritime boundary with Cambodia not
defined; involved in a complex dispute over the Spratly Islands in
the South China Sea with China, Malaysia, Philippines, Taiwan, and
possibly Brunei; unresolved maritime boundary with Thailand;
maritime boundary dispute with China in the Gulf of Tonkin; Paracel
Islands in the South China Sea occupied by China but claimed by
Vietnam and Taiwan; offshore islands and sections of boundary with
Cambodia are in dispute
Climate: tropical in south; monsoonal in north with hot, rainy
season (mid-May to mid-September) and warm, dry season (mid-October
to mid-March)
Terrain: low, flat delta in south and north; central highlands;
hilly, mountainous in far north and northwest
lowest point: South China Sea 0 m
highest point: Ngoc Linh 3,143 m
Natural resources: phosphates, coal, manganese, bauxite, chromate,
offshore oil deposits, forests
Land use:
arable land: 22%
permanent crops: 2%
meadows and pastures: 1%
forest and woodland: 40%
other: 35%
Irrigated land: 18,300 sq km (1989 est.)
---------
Location: Caribbean, islands between the Caribbean Sea and the
North Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 18 20 N, 64 50 W
Map references: Central America and the Caribbean
Area:
total area: 352 sq km
land area: 349 sq km
comparative area: twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 188 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: subtropical, tempered by easterly trade winds, relatively
low humidity, little seasonal temperature variation; rainy season
May to November
Terrain: mostly hilly to rugged and mountainous with little level
land
lowest point: Caribbean Sea 0 m
highest point: Crown Mountain 474 m
Natural resources: sun, sand, sea, surf
Land use:
arable land: 15%
permanent crops: 6%
meadows and pastures: 26%
forest and woodland: 6%
other: 47%
Irrigated land: NA sq km','d312ad3a39ba053158c0fb6c93cf239fe1ec879930a6fbdc3c071495367ed127','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b41eda02ce21b82b5dd4f3df66e56dc07fda797c0df7f211f4efc3de8b99f708',1996,'MP','Northern Mariana Islands','geography',348,'---------
Location: Oceania, island in the North Pacific Ocean, about
two-thirds of the way from Hawaii to the Northern Mariana Islands
Geographic coordinates: 19 17 N, 166 36 E
Map references: Oceania
Area:
total area: 6.5 sq km
land area: 6.5 sq km
comparative area: about 11 times the size of The Mall in Washington,
DC
Land boundaries: 0 km
Coastline: 19.3 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by the Republic of the Marshall
Islands
Climate: tropical
Terrain: atoll of three coral islands built up on an underwater
volcano; central lagoon is former crater, islands are part of the rim
lowest point: Pacific Ocean 0 m
highest point: unnamed location 6 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
---------
Location: Oceania, islands in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
Geographic coordinates: 13 18 S, 176 12 W
Map references: Oceania
Area:
total area: 274 sq km
land area: 274 sq km
comparative area: slightly larger than Washington, DC
note: includes Ile Uvea (Wallis Island), Ile Futuna (Futuna Island),
Ile Alofi, and 20 islets
Land boundaries: 0 km
Coastline: 129 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; hot, rainy season (November to April); cool,
dry season (May to October); rains 2,500-3,000 mm per year (80%
humidity); average temperature 26.6 degrees C
Terrain: volcanic origin; low hills
lowest point: Pacific Ocean 0 m
highest point: Mount Singavi 765 m
Natural resources: NEGL
Land use:
arable land: 5%
permanent crops: 20%
meadows and pastures: 0%
forest and woodland: 0%
other: 75%
Irrigated land: NA sq km
---------
Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 15 E
Map references: Middle East
Area:
total area: 5,860 sq km
land area: 5,640 sq km
comparative area: slightly smaller than Delaware
note: includes West Bank, Latrun Salient, and the northwest quarter
of the Dead Sea, but excludes Mt. Scopus; East Jerusalem and
Jerusalem No Man''s Land are also included only as a means of
depicting the entire area occupied by Israel in 1967
Land boundaries:
total: 404 km
border countries: Israel 307 km, Jordan 97 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: West Bank and Gaza Strip are Israeli
occupied with current status subject to the Israeli-Palestinian
Interim Agreement - permanent status to be determined through
further negotiation
Climate: temperate, temperature and precipitation vary with
altitude, warm to hot summers, cool to mild winters
Terrain: mostly rugged dissected upland, some vegetation in west,
but barren in east
lowest point: Dead Sea -408 m
highest point: Tall Asur 1,022 m
Natural resources: NEGL
Land use:
arable land: 27%
permanent crops: 0%
meadows and pastures: 32%
forest and woodland: 1%
other: 40%
Irrigated land: NA sq km
---------
Location: Northern Africa, bordering the North Atlantic Ocean,
between Mauritania and Morocco
Geographic coordinates: 24 30 N, 13 00 W
Map references: Africa
Area:
total area: 266,000 sq km
land area: 266,000 sq km
comparative area: about the size of Colorado
Land boundaries:
total: 2,046 km
border countries: Algeria 42 km, Mauritania 1,561 km, Morocco 443 km
Coastline: 1,110 km
Maritime claims: contingent upon resolution of sovereignty issue
International disputes: claimed and administered by Morocco, but
sovereignty is unresolved and the UN is attempting to hold a
referendum on the issue; the UN-administered cease-fire has been in
effect since September 1991
Climate: hot, dry desert; rain is rare; cold offshore air currents
produce fog and heavy dew
Terrain: mostly low, flat desert with large areas of rocky or
sandy surfaces rising to small mountains in south and northeast
lowest point: Sebjet Tah -55 m
highest point: unnamed location 463 m
Natural resources: phosphates, iron ore
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 19%
forest and woodland: 0%
other: 81%
Irrigated land: NA sq km
---------
Location: Oceania, group of islands in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Geographic coordinates: 13 35 S, 172 20 W
Map references: Oceania
Area:
total area: 2,860 sq km
land area: 2,850 sq km
comparative area: slightly smaller than Rhode Island
Land boundaries: 0 km
Coastline: 403 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; rainy season (October to March), dry season
(May to October)
Terrain: narrow coastal plain with volcanic, rocky, rugged
mountains in interior
lowest point: Pacific Ocean 0 m
highest point: Mauga Silisili 1,857 m
Natural resources: hardwood forests, fish
Land use:
arable land: 19%
permanent crops: 24%
meadows and pastures: 0%
forest and woodland: 47%
other: 10%
Irrigated land: NA sq km
---------
Map references: World, Time Zones
Area:
total area: 510.072 million sq km
land area: 148.94 million sq km
water area: 361.132 million sq km
comparative area: land area about 15 times the size of the US
note: 70.8% of the world is water, 29.2% is land
Land boundaries: the land boundaries in the world total 250,883.64
km (not counting shared boundaries twice)
Coastline: 356,000 km
Maritime claims:
contiguous zone: 24 nm claimed by most but can vary
continental shelf: 200-m depth claimed by most or to depth of
exploitation, others claim 200 nm or to the edge of the continental
margin
exclusive fishing zone: 200 nm claimed by most but can vary
exclusive economic zone: 200 nm claimed by most but can vary
territorial sea: 12 nm claimed by most but can vary
note: boundary situations with neighboring states prevent many
countries from extending their fishing or economic zones to a full
200 nm; 43 nations and other areas that are landlocked include
Afghanistan, Andorra, Armenia, Austria, Azerbaijan, Belarus, Bhutan,
Bolivia, Botswana, Burkina Faso, Burundi, Central African Republic,
Chad, Czech Republic, Ethiopia, Holy See (Vatican City), Hungary,
Kazakstan, Kyrgyzstan, Laos, Lesotho, Liechtenstein, Luxembourg,
Malawi, Mali, Moldova, Mongolia, Nepal, Niger, Paraguay, Rwanda, San
Marino, Slovakia, Swaziland, Switzerland, Tajikistan, The Former
Yugoslav Republic of Macedonia, Turkmenistan, Uganda, Uzbekistan,
West Bank, Zambia, Zimbabwe
Climate: two large areas of polar climates separated by two rather
narrow temperate zones from a wide equatorial band of tropical to
subtropical climates
Terrain: the greatest ocean depth is the Marianas Trench at 10,924
m in the Pacific Ocean
lowest point: Dead Sea -408 m
highest point: Mount Everest 8,848 m
Natural resources: the rapid using up of nonrenewable mineral
resources, the depletion of forest areas and wetlands, the
extinction of animal and plant species, and the deterioration in air
and water quality (especially in Eastern Europe and the former USSR)
pose serious long-term problems that governments and peoples are
only beginning to address
Land use:
arable land: 10%
permanent crops: 1%
meadows and pastures: 24%
forest and woodland: 31%
other: 34%
Irrigated land: NA sq km
---------
Location: Middle East, bordering the Arabian Sea, Gulf of Aden,
and Red Sea, between Oman and Saudi Arabia
Geographic coordinates: 15 00 N, 48 00 E
Map references: Middle East
Area:
total area: 527,970 sq km
land area: 527,970 sq km
comparative area: slightly larger than twice the size of Wyoming
note: includes Perim, Socotra, the former Yemen Arab Republic (YAR
or North Yemen), and the former People''s Democratic Republic of
Yemen (PDRY or South Yemen)
Land boundaries:
total: 1,746 km
border countries: Oman 288 km, Saudi Arabia 1,458 km
Coastline: 1,906 km
Maritime claims:
contiguous zone: 18 nm in the North; 24 nm in the South
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: large section of boundary with Saudi
Arabia not defined; a dispute with Eritrea over sovereignty of the
Hanish Islands in the southern Red Sea has been submitted to
arbitration under the auspices of the International Court of Justice
Climate: mostly desert; hot and humid along west coast; temperate
in western mountains affected by seasonal monsoon; extraordinarily
hot, dry, harsh desert in east
Terrain: narrow coastal plain backed by flat-topped hills and
rugged mountains; dissected upland desert plains in center slope
into the desert interior of the Arabian Peninsula
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu''ayb 3,760 m
Natural resources: petroleum, fish, rock salt, marble, small
deposits of coal, gold, lead, nickel, and copper, fertile soil in
west
Land use:
arable land: 6%
permanent crops: 0%
meadows and pastures: 30%
forest and woodland: 7%
other: 57%
Irrigated land: 3,100 sq km (1989 est.)
---------
Location: Central Africa, northeast of Angola
Geographic coordinates: 0 00 N, 25 00 E
Map references: Africa
Area:
total area: 2,345,410 sq km
land area: 2,267,600 sq km
comparative area: slightly more than one-fourth the size of US
Land boundaries:
total: 10,271 km
border countries: Angola 2,511 km, Burundi 233 km, Central African
Republic 1,577 km, Congo 2,410 km, Rwanda 217 km, Sudan 628 km,
Uganda 765 km, Zambia 1,930 km
Coastline: 37 km
Maritime claims:
exclusive economic zone: boundaries with neighbors
territorial sea: 12 nm
International disputes: Tanzania-Zaire-Zambia tripoint in Lake
Tanganyika may no longer be indefinite since it has been informally
reported that the indefinite section of the Zaire-Zambia boundary
has been settled; long section with Congo along the Congo river is
indefinite (no division of the river or its islands has been made)
Climate: tropical; hot and humid in equatorial river basin; cooler
and drier in southern highlands; cooler and wetter in eastern
highlands; north of Equator - wet season April to October, dry
season December to February; south of Equator - wet season November
to March, dry season April to October
Terrain: vast central basin is a low-lying plateau; mountains in
east
lowest point: Atlantic Ocean 0 m
highest point: Margherita Peak (Mount Stanley) 5,110 m
Natural resources: cobalt, copper, cadmium, petroleum, industrial
and gem diamonds, gold, silver, zinc, manganese, tin, germanium,
uranium, radium, bauxite, iron ore, coal, hydropower potential
Land use:
arable land: 3%
permanent crops: 0%
meadows and pastures: 4%
forest and woodland: 78%
other: 15%
Irrigated land: 100 sq km (1989 est.)','e9402d4e9aeea181fa8bd71d40757918da8b4c92016164fcd01bc9fb294f062e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb11324053e78820383d3473b6fd406b11df54221d0a7bfd3d7e2b50122a5ebf',1996,'BW','Botswana','geography',355,'---------
Location: Southern Africa, northeast of Botswana
Geographic coordinates: 20 00 S, 30 00 E
Map references: Africa
Area:
total area: 390,580 sq km
land area: 386,670 sq km
comparative area: slightly larger than Montana
Land boundaries:
total: 3,066 km
border countries: Botswana 813 km, Mozambique 1,231 km, South Africa
225 km, Zambia 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: quadripoint with Botswana, Namibia, and
Zambia is in disagreement
Climate: tropical; moderated by altitude; rainy season (November
to March)
Terrain: mostly high plateau with higher central plateau (high
veld); mountains in east
lowest point: junction of the Lundi and Savi rivers 162 m
highest point: Inyangani 2,592 m
Natural resources: coal, chromium ore, asbestos, gold, nickel,
copper, iron ore, vanadium, lithium, tin, platinum group metals
Land use:
arable land: 7%
permanent crops: NEGL (coffee)
meadows and pastures: 13%
forest and woodland: 49%
other: 31%
Irrigated land: 2,250 sq km (1993 est.)','cc66bf84b023dfd05abda05dcff5238d205aa0c9bc0e98696897e54138f7f95f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47438e854e45a1d814ea844b7027207ccad0c0d590aed8d29960f88f3a9e42b2',1996,'DE','Germany','communications',12,'Telephones: 31.200 (1983 est.)
Telephone system:
very limited telephone and
telegraph service: | public telephone in
Kabul
imernational: satellite earth statrons—i
domestic.
Intelsat (Indian Ocean) liaked only to Tran
and | Intersputnik (Atlantic Ocean Region)
Radio broadcast staiions: AM 5. FM 0.
shortwave 2
Radios: NA
Television broadcast stations: NA
note: several television stations run by
factions and local councils which provide
intermittent service
Televisions: 100.000 (1993 est.)
Defense
Branches: NA. note
not ext on a national scale: some elements
the military still does
of the former Army. Au and Aur Detense
Forces. National Guard. Border Guard
Forces. National Police Force (Sarandos).
and tribal militias still exrst but are
factionalized among the vanous muyahedin
and former regime leaders
Manpower availability:
males age 15-49: 5.549.602
males fit tor military service: 2.976.741
males reach military age (22) annually
220.532 11996 est.)
Defense expenditures: SNA. NAG of GDP
Telephones: 116,000 (1984 est.)
lelephone system:
domestic: natvonwide microwave radio relay
sysiem
international. satellite earth station— |
Intelsat (Atlantic Ocean), connected to
Central American Microwave System
Radio broadcast stations: AM 77. FM 0
shortwave 2
Radios: NA
Television broadcast stations: 5 (1986 est.)
Televisions: 500.700 (1993 est.)
Defense
Branches: Army. Navy. Au Force
Manpower availability:
males age 15-49: 1.415.691
males fit for military service: VOS.938
males reach military age 118) annually
78.660 (1996 est.)
Defense expenditures: exchange rate
conversion—$100 millon. 1% of GDP
(1995)
SrpmeMaved, Lueck
Telephones: 44 million
Telephone system: Germany has one of the
world’s most technologically advanced
lelecommunications systems: as a result of
intensive capital expenditures since
reunification, the formerly backward system
of the eastern part of the country ts being
rapidly modernized and integrated with that
of the western part
domestic: the region which was formerly
West Germany 1s served by an extensive
system of automatic telephone exchanges
connecied by modern networks of fiber-optic
cable. coaxial cable, microwave radio relay.
and a domestic satellite system: cetlular
telephone service ts widely available and
includes roaming service to many foreign
countries: since the reunification of
Germany, the telephone system of the
eastern region has been upgraded and enjoys
many of the advantages of the national
system
international: satellite earth static ns—14
Intelsat (12 Atlantic Ocean and ? Indian
Ocean), | Eutelsat. | Inmarsat (Atlantic
Ocean region), 2 Intersputnik (1 Atlantic
Ocean region and | Indian Ocean region): 6
submarine cable connections: 2 HF
radiotelephone communication centers:
tropospheric scatter links
Radio broadcast stations:
western: AM 80. FM 470. shortwave 0
eastern: AM 23. FM 17. shortwave 0
Radios: 70 million (1991 est.)
Television broadcast stations: 246
(repeaters 6.000): note—there are 15 Russian
repeaters .n eastern Germany
Televisions: 44.8 million (1992 est.)
Defense
Brauches: Army. Navy (includes Naval Air
Arm). Air Force. Border Police. Coast Guard
Manpower availability:
males age 15-49: 2) 540.919
males fit for military service. 1S.S37.347
males reach military ave (18) annually
449.99) (1996 est)
Defense expenditures: exchange rate
conversion—S$42.8 billnon, | So of GDP
(1995)','bfc7e904b21d90c256be0c276504225cba9d66a207bdd59197d21ef5c8c7c1e0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('044df56879236449049ef4ffde92fc2af782e995ab08f9dbac79d2665b3d5418',1996,'AL','Albania','communications',13,'_ —
“/ ate é “y }
._F ~ aa -
j - ‘
Sy eoné
.
,
» 3
TRANS
rres* *
, .
a st
.
TA ¥
¥
*
Telephones: 55.000
Telephone system:
domestic: obsolete wite system: no longer
»fovides a telephone for every village: in
1992. following the tall of the communist
government, peasants cut the wire to about
1.000 villages and used it to build fences
imiemational; madequate. internztional traific
camed by microwave radio relay from the
Tirane exchange to Italy and Greece
Radio broadcast stations: AM 17 ©M |.
shortwave 0
adios: $77,000 (1991 est.)
Television broadcast stations: 4
Televisions: 300.000 (1993 est)
Defense
Branches: Army. Navy. Au and An
Defense Forces. Interior Ministry Troops
Border Guards
Manpower availability:
males age 15-49: 723.23)
mates fit for military service, S88 304
males roach military age (19) annualls
29 3.40 (1996 est.)
Defense expenditures: exchange rat
conversion—$45 million, 2.50 of GDP
(1995)
Aigeria
hee
Tetoe” "ee & |
j
;
;
Sabi
1m :
7 |
‘ ''
ny" i
Telephones: 862.000 (1991 est)
Telephone system:
domestic: excellent service in north but
sparse in south. domestic satellite system
with 12 earth stations (20 additional
domestic earth stations are planned)
imernational: 5 submarine cables:
microwave radio reiay to Italy. France.
Spain. Morocco, and Tunisia: coaxial cable
to Morocco and Tunisia: participant in
Medarabtel: satellite earth stations—2
Intelsat (1 Atlantic Ocean and | Indian
Ocean). | Intersputnik, and | Arabsat
Radio broadcast stations: AM 26. FM 0)
shortwave 0
Radios: 6 million (1991 est.)
Television broadcast stations: |»
Televisions: 2 million (1993 est)
Defense
Branches: National Popular Army. Navy
Air Force. Terntorial Ai Defense. Nationa!
Gendarmerie
Manpower availability:
males ave 15-49: 7391 946
males fit for military service: 4.534.267
males reach military age (19) annually
326.229 (1996 est.)
Defense expenditures: exchange rate
conversion—S$1.3 billion, 2.7% of GDP
(1994)
/6
American Sanwa
‘terrtters of the LS)
+ ——
AGO PAGO e
Aye
Tutuda
/
|
Cae
Telephones: &.399
Telephone system:
domestic: good telex, telegraph, and
facsimile services: domestic satellite system
with | Comsat earth station
international: satellite earth statron—|
Intelsat (Pacific Ocean)
Radio broadcast stations: AM |. FM |
shortwave 0
Radios: NA
Television broadcast stations: |
Televisions: 8.000 (1993 est)
Defense
Defense note: defense is the responsi ulity
of the US
Telephones: 21.258 (1983 est.)
Telephone system:
domestic: modern system with microwave
radio relay connections between exchanges
international: landline circuits to France and','ea23cb5346a2c297e3a55007f1cd6626579dc26c99a50e915778e32623393427','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4698dc6c69e569dfa5b9134943d87908be636044fd243141aa347c37656ee06b',1996,'ES','Spain','communications',20,'Radio broadcast stations: AM |. F.1 0.
shortwave 0
Radios: 10.000 (1993 est.)
Television broadcast stations: ()
Televisions: 7.000 (1991 est.)
Defense
Defense note: defense is the responsibility
of France and Spain
ONGO PYWA
» Cabrida
\\ ZAIRE
t mot © ~
\\ .
® vaNDA ‘
Valanne ‘
ae *
luena _
* g /
. ° . . Ja Too
Sengueia ‘a
;
.-udango “Mer Que
"Name AMBIA
sy
‘
~~ VS F. \\
To
NAMIBIA — ¥,
Note: Civil war has been the norm since
independence trom Portugal on 11} November
1975: a cease-fire lasted trom 31 May 1991 unul
October 1992 when the insurgent National Union
for the Total Independence of Angola (UNITA)
refused to accept its defeat in internationally
monitored elections and fighting resumed
throughout much of the countryside. The two sides
signed another peace accord on 20 November
1994; the cease-fire is generally holding. but most
provisions of the accord remain to be
implemented
a ow
, f a 2
’ fL-™ / —“.
vara ao* ~
as''e ° .
“acs f
J
i
A
--
orto® /
eal
\\
"Ave
/
Owina
. Covina)
‘ mora {
j
itil
nalegre SPAIN
ve,
‘
/
LISBON
4
2D genein
Set uae
4
-
Pea
i
,
5
a |
.
. , ; 5
Telephones: 2.236.411 (19923 est.)
Telephone system:
generally adequate integrated
network of coaxial cables, open wire.
domestic
microwave radio relay, and domestic satellite
earth stations
international: 6 submarine cables: satellite
earth stations—3 Intelsat (2 Atlantic Ocean
and | Indian Ocean). NA Eutelsat:
tropospheric scatter to Azores: note - an
earth station for Inmarsat (Atlantic Ocean
Region?! is planned
Radio broadcast stations: AM 57. FM 66
(repeaters 22). shortwave 0
Radios: 2.2 million (1993 est.)
Television broadcast stations: 66 (repeaters
92)
Televisions: 2.970.892 (1993 est)
Defense
Branches: Army. Navy (includes Marines).
Air Force, National Republican Guard. Fiscal
Guard, Public Security Police
Mannower availability:
males age 15-49: 2.498.965
males fit for military service: 2.014.653
males reach military age (20) annualls
83.427 (1996 est.)
Defense expenditures: exchange rate
conversion—$1.9 billion, 2.4% of GDP
(1995)
377
Telephones: 170,000 (1992 est.)
Telephone system: excellent international
service; good local service
domestic: NA
international: satellite earth station—|
Intelsat (Atlantic Ocean): tropospheric scatter
to Barbados and Guyana
Radio broadcast stations: AM 2. FM 4.
shortwave 0
Radios: 700.000 (1993 est.)
Television broadcast stations: 5 (1987 est.)
Televisions: 400,000 (1992 est.)
Defense
Branches: Trinidad and Tobago Defense
Force (includes Ground Forces, Coast Guard,
and Air Wing), Trinidad and Tobago Police
Service
Manpower availability:
males age 15-49; 351,835
males fit for military service: 252.532 (1996
est.)
Defense expenditures: exchange rate
conversion—$83 million, NA% of GDP
(1994)
87
Tromelin Island
(possession of France)
ree!
_ + indian
Ocean','70997309d31771b3748f0c4c15b37db2d6dc2a9fa6769d50dfae8cf18f28c97d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f43b0cd25a598cab45724831039a1f6f4f8f5c8893ee7fa5637bcad1ebddbf2',1996,'BR','Brazil','communications',31,'Telephones: 890
Telephone system:
domestic: modern interna! telephone system
imernational’ microwave radio relay to
island of Saint Martin (Guadeloupe and
Netherlands Antilles)
Radio broadcast stations: AM 3. FM |.
shortwave 0
Radios: 2.000 (1992 est.)
Television broadcast stations: ()
Televisions: NA
Defense
Defense note: defense is the responsibility
of the UK','76bc64ff301eaf30217057d5cf1cb6d8b2b97b27c8954be57f382b335031df42','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13dafaeac06a10819884c1ec45271c3f0c7a58358131bceb0f0f81de5f28d54b',1996,'AQ','Antarctica','communications',37,'Telephones: NA
Telephone system:
domestic: NA
mernational: NA
Radio broadcast stations: AM NA. FM
NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
Defense note: the Antarctic Treaty prohibits
any measures of a military nature. such as
the establishment of military bases and
fortifications, the carrying out of military
maneuvers, or the testing of any type of
weapon: it permits the use of military
personnel or equipment for screntific
research or tor any other peacetul purpc ses
Climate: mostly temperate: arid in southeast:
subantarctic in southwest
Terrain: nich plains of the Pampas in
northern halt. flat to rolling plateau of
Patagonia in south, rugged Andes along
western border
lowest pout: Salinas Chicas -40 m
highest point: Cerro Aconcagua 6.962 m
Natural resources: tertile plains of the
pampas. lead. zinc. tin, copper. iron ore,
manganese, petroleum, uranium
Land use:
arable land: 9%
permanent Crops 4;
f
.
pile adows and pPrusiure so Ne
j
>
lores! ana we KX
woodland
other: 13%
Irrigated land: 17.600) sq km (1989 est)
Telephones: |.5 million (1994 esi.)
Telephone system: modern system based on
extensive microwave radio relay facilities
domestic: extensive microwave radio relay
links: domestic satellite system with 3 earth
Stations
international: satellite earth stations—2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 159. FM 0.
shortwave 11
Radios: NA
Television broadcast stations: | 3)
Televisions: 2.85 million (1992 est.)
Defense
Branches: Army of the Nation, National
Navy (include, Naval Air, Coast Guard. and
Marines). Air Force of the Nation.
Carabineros of Chile (National Police).
Investigations Police
Manpower availability:
males age 15-49: 3 808.655
males fit for military service: 2.832.198
males reach military age (19) annually:
123.443 (1996 est.)
Defense expenditures: exchange rate
conversion—$970 million, 2.0% of GDP
(1994 est.)','e73828a23db3f20bc81ce29deb8e5ab30535b0a37694218c2967daf535fda6bb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89ced3fac2d2e8bf271b68729e43f6c7e6207796d5d0008f9b3c549b85955fa3',1996,'AG','Antigua and Barbuda','communications',38,'Barbuda
SAINT JOHN’
‘
A ntiqua
Redonda
Telephones: 6.700
Telephone system:
domestic: good automatic telephone system
wernational: 1 coaxial submarine cable:
| Intelsat (Atlantic
Ocean). tropospheric scatter to Saba
satellute earth sation
(Netherlands Antilles) and Guadeloupe
Radio broadcast stations: AM 4. FM 2.
shortwave 2
Radios: NA
Television broadcast stations: 2
Televisions: 28.000 (1993 est)
Defense
Branches: Royal Antigua and Barbuda
Defense Force. Royal Antigua and Barbuda
Police Force (includes the Coast Guard)
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: exchange rate
conversion— $1.4 million, 1% of GDP
(FYVO/9])
Arctic Ocean
Telephone system:
international: no sabmarine cables
19
A’','0ad5fb7528d7db8e46ffc1dc6117f140e549a81abdbc8cf9baa19345bf9c62c2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ddaf9315a4198e0ed814067765b6946f04d15dabc70f77390a991f4669cfab1',1996,'AR','Argentina','communications',45,'- ~ eee 7
*
a
'' ‘ -
| ) BRAZ
J }
| \\
| \\paracuar |
! Nn 4
| )
| . y)
J ‘4
| 26 e af. Sf L
: co
|
“
r™.
aia f
f Se
. * £ ON
; »
i 7 . PUAY
‘ a
BUENOS AIRES®
" Ty
.
. ? Via ata
}
Ww
.
—_ - nee ed
eography
mutton ‘ | ‘ \\ Lal
Sou ‘ ! (Qoean. between
(+4 vraphn coordinates: 6400S. 64 00 W
Miap references: South Am
\\rea
iS
land boundartes
HS 3
ite Boliwta 832 km. Brazil
+ C Tithe SO km. Paraguay 1.880
679 |b
( oastline: 4.989 kn
\\laritime claims:
vid { fle 4 ni
helt) 200 nm or to the edge of
tinental margin
20
exclusive economic zone: 200 nm
terruorial sea: 12 am
Internatioxsal disputes: short section of the
boundary with Uruguay ts in dispute: shor
section of the boundary with Chile ts
indefinite: Clams Brotish-administered
Falkland Islands (Islas Malvinas): claims
Botish-administered South Georgia and the
South Sandwich Islands: terrmtorial claim in
Felephones: 1.180 (1991 est)
Telephone system:
domestic: government-operated
radiotelephone and privaie VHE/CB
radiotelephone networks provide effective
service to almost all points on both rlands
micrnational: saelitte earth station— |
Intelsat (Atlantic Ocean) with links through
London to other countnes
Radio broadcast stations: AM 2. FM 3.
shortwave 0
Radios: 1.000 (1992 est)
Television broadcast stations: |
(government operated)
Televisions: NA
Defense
Branches: British Forces Falkland Islands
(includes Army. Royal Air Force. Royal
Navy. and Royal Marines). Police Force
Defense expenditures: SNA, NAG of GDP
Defense note: defense is the responsibility
of the UK
Telephones: 88.730 (1985 est.)
lelephone system: meager telephone
service: principal switching center ts
\\suncion
domestic: ta microwave radio relay
network
miernational: satellite earth statron—|
Intelsat (Atlantic Ocean)
Radio breadcast stations: AM 40. FM 0.
shortwave 7
Radios: 775.000 (199) est)
Television broadcast stations: 45
Televisions: 370.000 (1992 est)
Defense
Branches: Army. Navy (includes Naval Aw
and Marnnes). Aw Force
Manpower availability:
males age 15-49: 1.334.638
males fit jor military service: 968.297
males reach mitary eve (17) annuals
S8_39K (1996 est.)
Defense expenditures: exchange rate
conversion—$94 million. 0.6% ot GDP
(1994)
3387','293ed2e2bbdb0be134e22295f6cb3f2e1a573c376368b2d5127b4c2c86b5d308','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfef02a7ef255ea3e0f6579bf0eb4d16d8536d7e471661f60f4f814af9cad0e2',1996,'NL','Netherlands','communications',48,'Telephones: 2.7 million (1983 est)
Telephone system: | 2.000 public
telephones: extensive modem system but
many tamilies do not have telephones
despite extensive use of microwave radio
relay. the telephone system frequently
grounds out during rainstorms, even in
Buenos Aires
i~
tv
Radio broadcast stations: AM |7!. FM 0.
Telephones: 900.000 (987 ext)
Telephone system: modern digital s
using cable and microwave radio rela
domestic. microwave radio relay
mermational: satellite earth station—-|
Intelsat (Atlantic Ocean)
Radio broadcast stations: AMI 9. F\\\\ 45
shortwave 0
Radios: 2.2 million (1991 est)
Television broadcast stations: 86 (| 987
est.)
Televisions: 1.025 million (1990 est)
233
Ireland (continued)
Defense
Branches: Vii sncludes Naval Service
and Air Corps), National Police (Garda
Siochana)
Manpower availability:
males uve 15-49° 939 ) .
males fit tor military service. 761.048
males reach militai ave 47) annually
38.904 (1996 esc}
Defense expenditures: exchange rate
conversion—SOIS million. 13° of GDP
(1994)
;
i
\\
t
a ’
: * }
2 t
.
N
t
7,
lelephones: 8 272 million (1983 est)
lelephone system: highly developed and
well maintamned: extensive redundant system
of multiconductor cables. supplemented by
microwave radio relay
domestic’ Natwonwide cellular telephone
microwave radi relay
SSstem
vuernational, S submarine cables: satellite
earth statrons—— 3 Intelsat ¢1 Indian Ocean
and 2 Atlante Ocean). | Eutelsat. and |
Inmarsat (Athanti and Indian Ocean
Regions)
Radio broadcast stations: (MM
tM }2 (repeaters 39). shortwave 0
> .
Sirelayvs 3)
Radios: 13.755 muilion (1992 est)
lelevision broadcast stations: & (repeaters
lelevisions: 7 4 vacthon (1992 est)
Defense
Branches: Royal Netherlands Army. Roval
Netherlands Navy dincludes Naval Au
and Manne Corps). Roval
\\i Force
Manpower availability:
Roval Constabulary
phledle dve i> LY } 1y] QU
4 o<. ) a sc)
Phiadia'' / CP Pb SNOT Ie sf) S48
} y /
males reach milvttary ave (20) annually
YL) 4 61996 est)
Defense expenditures: exchanve rate
mon SS.2 billnon, 2 t+ of GDP
CamIVe
}OUS)
Netherlands Antilles
(part of the Dutch realm)
a , te
Méestpun
Bonaire
Cit aca
.
e « 4
WILLEMSTAD
Ceography
Location: Canbbean. two island groups in
the Canbbean Sea—one includes Curacao
and Bonaire north of Venezuela and the
other as east of the Virgin Islands
Cseographic coordinates: |2 15 N. 6s 45 W
Map references: Centra!
Caunbbean
\\rea:
hital areas YOO sg kim
Amenca and the
land areca) YOO sg km
comparative arca: more than tive tines the
size of Washington, DC
note. meludes Bonaire. Curacao. Saba. Sint
bustatius. and Sint Maarten (Dutch part of
the island of Samt Martin)
Land boundaries: 0 kim
Coastline: 464 km
Maritime claims:
craclasive fishing cones 12 am
12 nm
International disputes:
Climate: tropical: ameliorated by northeast
territorial sea
none
trade winds
lerrain: venerally billy. volcanic interiors
Canbbean Sea Om
Mount Scenery 862 m
Natural resources: phosphates (Curacao
hous? pom
jivhest pou
only). salt (Bonaire only)
Land use:
arable land. &''¢
pormancnt crops, VN
meddows and pastures,
forest and woodland: +
other: 92",
Irrigated land: NA sy kn','169083a0050f05ec0c4c3f530524053f19ec59692c8c5dfb8b743229ec508a69','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc1c7c7d33c47ac20d8b2f7f5df59eedc7af6d7165494444ee7c9cf564a238ed',1996,'AM','Armenia','communications',53,'Telephones: 650.000
Telephone system: joint venture agreement
to install fiber-optic cable and construct
facilities for cellular telephone service
remains in the negotiation phase
domestic: NA
international: international connections to
other former Soviet republics are by landline
or microwave radio relay and to other
countries by satellite and by leased
connection through the Moscow international
gateway switch; satellite earth statron—1
Intelsat
Radio broadcast stations: AM 10. FM 3.
shortwave NA (1991)
Radios: NA
Television broadcast stations: |
note: 1OO% of population receives Armenian
and Russian TV programs
Televisions: NA
Defense
Branches: Army. Air and Air Defense
Forces, Security Forces (internal and border
troops}
Manpower availability:
males age 15-49: 9O1 974
males fit for military service: 719.212
males reach military age (18) annually.
29. YSR (1996 est.)
Defense expenditures: exchange rate
conversion—$75 million, NA& of GDP
(1992)','c879e705f090cd1520fbba62451c7e7f5adec1de0bd3370c00c92354e9aed302','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fc4e63e9699f4f47cf470ba9c21b1561604a4467da224811c730f71608bcb55',1996,'AU','Australia','communications',64,'lelephone system:
. , 1.
numerous submarine cables
een continental Europe and
K. between North America and the
Mediterranean: numerous
Attantic
via Satellite
1 HMRS Gcross
-* Atela-e e ons
CaNBERRA™
Vielbout.4
million (LOST est
lelephones: » 7
lelephone system: good domestic and
MiCmMavONAl servicer
lomestic. domestic satellite svstem
fernational, submarine cables to New
Jealand. Papua New Guinea. and Indonesia:
sulellite earth stations— 10 Intelsat «4 Indian
Ocean and 6 Pacitic Ocean). 2 Inmarsat
(indian and Pacitic Ocean Regions)
Radio broadcast stations: AMI 258. EM 67
shortwave 0
Radios: \\\\
Television broadcast stations: | 34 (| 987
est.)
lelevisions: 9 > million (1992 est)
Defense
Branches: Australian Army. Royal
Australian Navy. Royal Av
Manpower availability:
males ave 15-49: 4.848.777
males fit for military service: 4192250
males reach military ave (17) annually
127.569 (1996 est.)
Defease expenditures: exchange rate
conversion—S87.3 billion. 2.0% of GDP
(EF Y9S/96)
Kn borce
Telephones: NA
Telephone system:
domestic: NA
imternational: NA
Radio broadcast stations: AM |. FM 0
shortwave 0
Radios: S00 (1992)
Television broadcast stations: |
Televisions: 350 (1992)
Defense
Defense note: defense is the responsibility
of Australia
193
“Ma
Clipperton Island
(possession of France)','69f88ea04bacc2ae0cc19ee65ac8f791ca2609c1d758ba1b1845eb80fb625c5e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a614391414ab2ad3399db233985f02b501bb1c28c8b5350131b8ada6b481137c',1996,'AT','Austria','communications',66,'~~ ~ ~~
” 5
we & Vi
¢ Cc 5 P
\\ CZECH EPUBLIC
\\
~MiANY ~
~*~‘ , 4
. ™ ~ s —
LA ~——
— ;
. *
VIENNA mn
a~-a —_
. ~ fr, * <=
‘ Us
’ 7 .
" }
? di A
A
~ aa t, _ os
J » am ~~
‘»
Q | ''
“ 4
c
Pe A }
~ o~}5 a
Telephones: 347 million (1986 est)
lelephone system:
domestic. highly developed and efficient
niernational: satellite earth stations— 2
Intelsat (1 Atlantic Ocean and 1 Indian
Ocean) and 2 Eutelsat
Radio broadcast stations: AM 6. FM 2!
(repeaters 545). shortwave 0
Radios: NA
lelevision broadcast stations: 47 (repeaters
S/O)
Televisions: 2.418.584 (1984 est)
Defense
Branches: Army (includes Fiving Division)
Manpower availability:
males ave 15-489. 2 (R4.827
niles fit for military service: 1.741.068
males reach mulitary ave 19) annually
38.628 (1996 ext )
Defense expenditures: exchange rate
converston—S2.1 bilhon. 1.0% of GDP
1UYys,)','ae50db14a39e54055586b376ab56c317a4819891462eec861bbd155dbdf82c2b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5aae15597576d2a12affd9582c029c3f5daf497b762c3e01105a92e9f301fa64',1996,'AZ','Azerbaijan','communications',72,'RUSSIA
r
GEORGIA ( ™~,. J
at Se \\Soamal
G td . nian
C Genes? ONO Sumaayt®
oumiosy
> Kurgar, Baxu®e
hy JS
t, Kareioo
* | Sepanacet
Note. Azerbaijan continues to be plagued by an
unresolved enght-vear-old conthet with Armenan
separatists over its Nagorno-Karabakh regron. The
Karabakh Armenians have declared independence
and seved almost 20% of the country’s territory
creating almost | millon Azer refugees in the
process. Both sides have generally observed a
Russian-mediated cease-fire in place since May
1994. cad support the OSCE -mediated peace
process. now entering tts filth year) Nevertheless
Baku and Nankand: (Stepanakert. Nagorno
Karabakh regeon) remain far apart on most
substantive mssucs trom the placement and
COMPOSITION OF a Peas cheeping force to the
enclaves ultemate political status, and prospects
ior a negotiated settlement remain dim
Telephones: 710.000 (1991 est)
Telephone system: 202.000 persons wanting
for telephone installations Glanuary 1991 est)
domestic. telephone service ts of poor
quality and inadequate: a joint venture to
establish a cellular telephone system in the
Baku area was supposed to become
operational in 1994
international: cable and microwave radiw
relay connections to former Soviet republics:
connection through Moscow international
gateway switch to other countries: satellite
earth stations—1! Intelsat and | Intersputnik
(Intelsat provides service to Turkey and
th: ugh Turkey to 200 more countries:
Intersputnik provides direct service to New
York)
Radio broadcast stations: AM NA. FM
NA, shortwave NA (1 state-owned radio
broadcast station)
Radios: NA
Television broadcast stations: 2
note: domestic and Russian TV programs are
received locally and Turkish and Iranian TV
is received from an Intelsat satcHiie through
a receive-only earth station
Televisions: NA
Defense
Branches: Army. Navy. Aur Force. Maritime
Border Guard
Manpower availability:
males age 15-49; 1.952.390
males fit for military service: 1 STAR
maies reach military age (18) annually
68.006 (1996 est.)
Defense expenditures: $3.5 billion manats.
NA of GDP (1994): note
defense expenditures into US dollars using
conversion of
the current exchange rate could produce
misleading results
The Bahamas
UNITED
STATES .
Gand tee, 7 SS
. Abacr
ar .
/ NASSAU t eutera
*
ven
Prowde we Ce’ sar
Andros ~
saw a
a ‘ .
Fauna —
270m agus
We
Var eow®
~','3b1cd48c7666041f40d677548e08165d4086e0512c22671e5a0433ab73ef628b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7ceb8d4d08fbe92879d82b594eb903679890b10f7c2217b1edee45d112f6a98',1996,'BB','Barbados','communications',87,'Felephones: s7 34 y
44
Telephone system:
domestic: island wide automatic telephune
system
miernational: satellite earth statron—|
Intelsat (Atlantic Ocean): tropospheric scatter
io Trindad and Saint Lucia
Radio broadcast stations: AM 3. FM 2.
shortwave 0
Radios: NA
Television broadcast stations: 2 (| pay)
lelevisions. 99.350 (1993 est.)
Defense
Branches: Royal Barbados Detense Force
dincludes Ground Forces and Coast Guard).
Roval Barbados Police Force
\\Manpower availability:
males ave 15-49: 71.667
males ju for military service: 49.726 (1996
est.)
Defense expenditures: SNA, NA‘ of GDP
Bassas da India
(possession of France)
_ enn > i¢ .—
- f
- ~ J
jf a
r . 5
™
‘ } r
\\ /
’ ,','b98531495ff212037281fd51ba88fbfe18d124cb72b214720e47940af4c4d4c6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d152639fcd5aaba72b9a0105d2faabd7013105aa43a77af7acfd4b39d6483721',1996,'BY','Belarus','communications',101,'Telephones: 1849 millhon (1991 est
Telephone system: tclephone seri
inadequate for the purposes of cithes
business or the population. about 70 ta
iclephones are in Domes ver 7 SOK
apphcations trom households tor telephones
remain unsatisfied (1992 est new
Invesiment centers on mtematronal
connections and Dusiness needs
the new NMI
SVSiem is how operaling
IMO analow
N‘unshk
miemational tratin
donk Jie celiulal
micrnational s carned
by the Moscow international gateway switch
and also by satellite: satellite earth statrons
| Intelsat (through Canada) and | Eutelsat
(through the UK)
Radio broadcast stations: AMI 35. EMI
shortwave 0
Radios: *.!7
with multiple speaker systems for program
nuilhon (199) est S.6
diffusion)
lelevision broadcast stations: 2 (on
national and one private. the license of t
private station was suspended during the
parhamentary elections of 1994)
Televisions: 3.5 mullon (1992 ext
Defense
Branches: Army. Aw Force. Au Detens
Force. Repubiic Security Forces (internal
hordet Trannpys )
Manpower availability:
1y
muaailes awe /s ’ 45 70
CS tu for multlary series
males reach mulittary aee (18) anna
T6106 (1996 est
Defense expenditures: 892 billion rubels
i of GDP (1998). note—conversion of
defense expenditures mite US dollars using
the current exchange rate could produc
misteading results
Be
lgium
}
}
* :
Ceography
Location: Western |
North § het |
Ni ther Is
Ceographic coordinates:
Na
p references: |
Area:
;
Ma
aiid c aice
T\\ land
Land boundaries:
”
if,/
a”
SAS kim
i |
ade CManTTICs Francs
km
} kim
Luxembourg | 48
(Coastline: 64 km
Na
qi
hk }
on
ritime claims:
nental shelf: median
sii Pyaeree cele tiles:
ghbors cectends about 6s
Merial se 12 nm
International disputes: non
Climate: temperate: mild wi
summers: rary. humid, chouc
lerrain: flat Coastal [ han
central rolling halls. ru dn
Ardennes Forest 1 utheu
lowes! pom) North Sea On
highest pomt: Signal de Botra
Natural resources: Coo!
Land use:
wi
irr
ss
We ja 4
LTP LAL 4 |
LL AA nl Leth is 1)
4 De ndiga ]
gf
igated land: 10) sg km
47
VWAY
Belgium (continued)','3925f77633826bd3ceac8e4ed561feed8ce37199356ab3cde178898a531aa1fd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2022cb4f3405c63fa131f97d7c06f7254c959d49f73919d2d344b7cca5a09c7c',1996,'BE','Belgium','communications',105,'Telephones: 5.69!) million (1992 ext
Telephone system: bigh!y devcloped
technologically advanced. and complet
wtemated domestr and internationa
iclephone amd tele graph facihitve
domestic, natonwide cellular telep!
ssMiem: estensive cable network. tin
mirowave radw relay network
ernational, S submarine cables: sate!
wh statons—! Intelsat (Atlantic Ocean
wd | butelsat
Radio broadcast stations: AVI}. EM fy
shortwave 0
Radios: 100.000 (199) ex.)
Television broadcast stations: $2 (| Ys
est)
Televisions: 8.315.662 (1998 ext)
Defense
Branches: Arms. Nav
Crendarmeric
Manpower availability:
males ave 15-49 2 571 S88
\\u bores Nath
males tit for miltlary sone \\ on i
males reach military ave (19) annual
61 YR6 11996 est)
Defense expenditures: exchange nak
conversion— S846 billhon. | ow GDP
(1YUS;)
49','b7a006ec61a46746118cfa3e092266675b14fba411cd7f4dd9f4585b8677f73e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('650a4ab80a3bbfc17fcccd610dae2a7dd6318af870ae7ceef34c952dcdf973a2',1996,'BZ','Belize','communications',111,'Telephones: 15.917 (1990 est)
Telephone system: above-average sysiem
domestic: rank network depends primarily
on microwave radio relay
international. satelite earth statioa—|
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 6. FM §.
shortwave |
Radios: NA
Television broadcast stations: |
Televisions: 27.048 (1993 est)
Defense
Branches: Belize Defense Force (includes
Army. Navy. Air Fores, and Volunteer
Guard). Belize National Police
Manpower availability:
males age 15-49; $2,290
males fit for military service: 31.086
males reach military age (18) annually
2.390 (1996 est.)
Defense expenditures: exchange rate
$8.1 millon, NAG of GDP
conversion
(FY9S/96)
»
~
<
©
( iphic coordinates ‘ I
mip reterences
land boundaries
( coastline:
Viaritime claims:
International disputes:
Climate: tropical: hot. humid in south:
semiarid in north
Terrain: mostly flat to undulating plain:
some hilly und low mountains
lowest point: Atlantic Ocean 0 m
fighes! pom Mount Tanekas 641 m
Natural resources: small offshore ot!
deposits. limestone. marble. timber
Land use:
arable land: 12%
permanent crops 4%
nwddows and pastures. 4%
forest and woodland: 35%
ther: 4589
Irrigated land: 60 sq kin (1989 est.)
,
lelephones: 16.200 (19 s¢
lelephone system:
domes! hiuir SVsicn
MRTOW Gave Paha Prepay
Intelsat (Atlantic Oceur ub
Radio broadcast stations: \\\\J
fhrtiwave 0
Radios: \\A
lelevision broadcast stations:
lelevisions: wWimwe ss 1OQ8
Defense
Branches: Armed bor
Navy. Arr Force). National G
Manpower availability:
- . eo
malics ave] dy |. tc.4 hi)
females ave 15-49 | 200.774
mies Hl wor militar el ‘ ")
l4 vile he''s fit faowrow TEL qn ‘ fs
j ;
WhdicsS teach HWilifdal ave j is? ‘
(> 5h
i4 Wndics Teds nn tcaual dive IS
HO.Y6R8 (1996 est)
Benin (continued)
note. both sexes are liable tor military
Defense expenditures: exchange rate
22 i] » 2?
on S35 MmMiion, 3','939eba262b8ebf41c136f38224ee4464932232523a31949f1b3471dbbbcc7cfa','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79832d0ac91c6a40f173a3dd122e0f8d7ecc517bbac398ab5804113eb287c5cf',1996,'BM','Bermuda','communications',112,'(dependent territory of the UK)
Sant
_seorge
Somerset ,MAMILTON
Telephones: 54.000 6199) est
lelephone system:
mestic: modern, tully automatic telep!
\\siem
rernational: 3 submarine cable
earth stations—2 Intelsat (Athantic Ocean
Radio broadcast stations: AVES EM 3
shortwave 0
Radios: TR AWW EC TO9O) est)
lelevision broadcast stations:
lelevisions: 57.000 (199) os
Defense
Branches: Bermuda Regiment. Bermuda
Police bi we Berm al I. | i nystal r\\
Defense expenditures: S\\\\0 NA of GDP
Defense note: dctens«
of the | kK
an
mn','bada83f00a83f77e0355abb5c18d4782a105943e4af3cc4b7feb5e0d7fd34e8b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d60a0f35f0f5329479eb7ce7d0b696a62b63b2476a16a50c94a5311aa668be53',1996,'BT','Bhutan','communications',118,'Ceography
Location: S 1.
(,cographic coordinates: 2° 40) N
Viap references: Asia
\\rea:
land boundartes
( oastline:
Nluritime claims:
International disputes:
€ hinnate
Natural resources: |
land use
Irrivated land: (40)
bnvironment
roston: tymited ;
i! i) |
im fall
iis
wCeESS Lo
cnt storms coming
Himaavas are the source of
il]
vhuch translates
56
as Land
of the Thunder Dragon: frequent landslides
during the rainy season
international agreements: party to—
Biodiversity. Climate Change, Nuclear Test
Ban: signed. but not ratified—Law of the
Seu
Geographic note: landlocked: strategic
location between China and india: controls
several key Himalayan mountain passes','01f62831721ce7f6ad0428e4e5a9734f7adb659dbc4a9d4690fa44ce3730703d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('573040dbaa4324bb223111f04c06960d58511278c7d345ea034d3ed631bf5837',1996,'BA','Bosnia and Herzegovina','communications',128,'International disputes: short section of
Telephones: 727,000 boundary with Namibia ts indefinite
Telephone system: telephone and telegraph quadnpomt with Nama, Zambia, and
network is im need of modermzation and Jambabwe 1. in disagreement, disoute with
e\\pansion, many urban areas are below Namba over eninhabited Kasikih (Sidudu
average when compared with services in Island on Linvanti (Chobe) River remained
wher former Yugoslav republics unresolved in January 1996 and the parties
domestic: NA ha.ce acreed to reter the matter to the [CJ
micrnational, no satellite earth statins Climate: senmiand warm winters and hot
Radio broadcast stations: AM 9. FM 2 ummMers
shortwave 0 Terrain: predominately flat to gently rollin
Radios: 840.000 hicland. Kalahan Desert un southwest
Television broadcast stations: 6 cue pont, wncton of the | mpom and
Televisions: |.0))2.094 Shashe Rivers S13 4
highs! p lund ho Mall 484 7
Natural resources: diamonds. copper
meckel. salt. sad ! mash, coal. ron ore
Defense
sive?
Branches: Army Land use:
Manpower availability: arable land
males awe 15-49. 654.426 ermanent os ()
males fit fer military service: 524.963 meadows d pastures: 7%
males reach mittary awe i191 annually forest and 4 diand. 2
+) OO) (1996 est) onthe
63
Botswana (continued)
irrigated land: _
tasirenment:
ie bm (1989 est.)
. overgrazing. pnmarwily as a
ihe capansion of the cattle
desertification. lumited natural
Waictl Tew rus
rds. permadc droughts: scasonal
Aus vinds blew trom the west. carrying
wronss the country. which can
( } ins Ends ccTed
i ! ‘ Nuk ! | “I Ban
| sith dl ml ny
,?
(.cographic note: |andlocked. population
pu 1 4 nl
’','8826316fc1d5938e754e67d3cd70c1163a18f9ffb9245c65a737e46ca4b13d43','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('896a17654182aa5ecf9a6b47f85bec07380711fcdfe095c6fed95fb2830e6649',1996,'BW','Botswana','communications',133,'Telephones: 19 109 (1985S est)
Telephone system: sparse system
domestic: small system of open-wire lines
microwave radio relay links, and a tew
raduMelephone communication stations
international: macrowave radi relay links to
Zambia. Zimbabwe and South Afnca.
sateline earth station—! Intelsat (Indian
Ocean)
Radic broadcast stations: AM 7. FM 13.
shortwave 0
Radios: NA
Television broadcast stations: () (/ 98% est)
Televisions: 13.800 (1993 est)
Defense
Branches: Botswana Defense Force
(includes Army and Air Wing). Botswana
National Police
Manpower availability:
males age 15-49: 334.177
males fit for military service: 175 471
males reach military age (18) annually
17,088 (1925 2st)
Defense expenditures: eu hange rai¢c
conversio:. —$199 millon, 5.29 of GDP
(FY9VWOs,','6ecc30d96e80a07e605b5f77d32de8d372b5856f5efa5ed715830f008f3a9fcd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7617563b5429e7015c92772c6fb893e7d643906a1197c22bd675142ba64e199',1996,'BV','Bouvet Island','communications',134,'(territery of Norway)
~—- —_ 4
Telephones: 76.900 (1993)
Telephone system: service throuzhout
country 1s adequate for present needs:
imntemational service good to adjacent','72cc2de75842182408d47f2fbcbe48179b49c13f6ef700da9224720a9e93e851','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5266311793955b492674e91e7a9013b401346b65403cf8fd7f469ef805e0d2d5',1996,'MY','Malaysia','communications',139,'domestic: NA
imtcernational: satellite earth stations—2
Intelsat (1 Indian Ocean and | Pacific
Ocean)
Radio broadcast stations: AV 4. FM 4
shortwave 0
Radios: 115.000 (1993)
Television broadcast stations: | () 984 est )
Pelevisions: 78.000 (1993 est)
Defense
Branches: Land Forces. Navy. Aw bor
Royal Brunet Police
Manpower availability:
males ave 15-49: S364)
males fit for milttary service: 48559
males reach mittary ave (1N) anne
> YTS (1996 est)
Defense expenditures: exchanve rat
of GDP
conversion-—S312 million. ¢
(1994)
Telephones: | 22.195 (1993 est.)
Telephone system: meets minimun)
requirements for local and intercity service
79
BB
Burma (continued)
tor business and government: international
cl] ce IS good
NA
ational: satellite earth station— |
Intelsat (Indian Ocean)
Radio broadcast stations: AM 2. FM |.
nomwave U | 1YNS est)
rudiobroadcust COVCTALC limit “d lo
the most populous areas
Radios: NA
Lfelevision broadcast stations: | (1YS8S est.)
Pelevisions: SS.000 (1992 est)
Defense
Branches: Army. Navy. Au Force
\\Mlanpower availability:
| 739.636
:i’é +*/
\\
5-49. LL SS8.18I
TV Service fy 24} UNH
r miittary service: 6.184.667
j . j
iS annually
iH ary Ge
~~
es reach milttarv age (18) annually
is xf 106 est.)
both sexes liable for military service
Defense expenditures: exchange rate
vilhon, NAG of GDP
conversion——-$1 35
i} Yous UH)
80','7d067be68c144ab1890b949c3464a35240ccab1b21bb58f9b7f87afb36bbbc45','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3409e0d0f58d8ea2b5b4c31d6fdd65143a4c01fd43c7962001246b5b7066a3d3',1996,'TH','Thailand','communications',148,'Telephones: 21.000 (1993 ex
Telephone system: a!! services only baw
domesta: tuctowave tad
and radute.-phonc
wilecmatonal. + alk ¢ Carin stati
Intelsat (Atlantic Ocean)
Radio broadcast stations: \\Vi > EM
shortwave 0
Radios: \\A
Television broadcast stations: > |»
Televisions: 44 (4% WOT et
Defense
Branches: Army. Aw Force. “
Gendarmern Nal nal; ‘ Pes
Nii ia
Manpower availability:
Pot
Defense expenditures: >
+
- 4s ae
‘i —
y
— .
7
.
''
RANGOON
{ . =
.
i Vv ¢
1
Cceography
Location: Southeastern Asia. bordering the
Vndaman Sea and the Bay of Bengal
Bangladesh and Thailand
(;seographic coordinates: 22 00 NX. 98 00 EF
Map references: Southeast Asia
Areu:
ie G78 SO) G kr)
ed ANC: 657.740 sg km
mparative areca. slight!» smaller than
Pen
Land boundaries:
total: 8.876 km
border countries: Bangladesh 193 km. China
7. ISS km. India 1.463 km. Laos 235 km.
Thailand | .80G0 km
Coastline: |.930 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of
the continental margin
78
exclusive economic zone: 200 nm
terriiorial sea: 12 nm
International disputes: none
Climate: tropical monsoon; cloudy. rainy.
hot. humid summers (southwest monsoon.
June to September): less ¢ loudy. scant
raintall, mild temperatures. lower humidity
during winter (northeast monsoon, December
to April)
Terrain: central lowlands ringed by steep
rugged highiands
lowest point. Andaman Sea 0 m
highest pomt: Hkakabo Rai 5.881 m
Natural resources: petroleum. timber. tn.
antimony. Zinc. copper. tungsten, lead. coal.
some marble. limestone. precious stones,
natural gas
Land use:
arable land: 13%
permanent crops: Ve
meadows and pastures: V
forest and woodland: 49%
other: 34%
irrigated land: 10).
Telephones: | 553,200 (1994 est.)
Telephone system: service to general public
inadequate; bulk of service to government
activities provided by multichannel cable and
microwave radio relay network
domestic: microwave radio relay and
multichannel cable; domestic satellite system
tcing devcloped
international: satellite earth stations—2
Intelsat (1 Indian Oczan and | Pacific
Ocean)
Radio broadcast stations: AM 200 (in
government-controlled network), FM 100 (in
government-controlled network), shortwave 0
Radios: 10.75 million (1992 est.)
Television broadcast stations: || (in
government-controlled network)
Televisions: 3.3 million (1993 est.)
(FY94/95)
Telephones: 12,000 (1987 est.)
Telephone system: fair system based on
network of microwave radio relay routes
supplemented by open-wire lines
domestic: microwave radio relay and open-
wire lines
international: sateilite earth stations—!
Intelsat (Atlantic Ocean) and | Symphonie
Radio broadcast stations: AM 2. FM 0.
shortwave 0
Radios: 795,000 (1992 est.)
Television broadcast stations: 3 (relays 2)
Televisions: 24.000 (1992 est.)
Defense
Branches: Army. Navy. Air Force.
Gendarmene
Manpower availability:
males age 15-49; 975.746
males fit for military service: 512,196 (1996
est.)
Defense expenditures: exchange rate
conversion—$48 million, 2.°% of GDP
(1993)','1ba4ede3238fdf9c571e4be1663749220b343309885480838546ce62d4c47b98','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0533575ca8b90ca6db8bd2c0a895019c285e4fedd735ef27d97d43f3440b5219',1996,'BI','Burundi','communications',155,'zaire to
’ _BUJUMBURA _
& -Ltega
Pelephones: 7.200 (1987 est.)
lelephone system: primitive system
_—','bf892f97fb30ad6d772a4f0d62399f9188fcebb96cf7024f3712bd451091b3a7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c3998bfc83c8f0e6c3d20d1796d742a4c27aae70e4296d79960ad11d60c7fca',1996,'ET','Ethiopia','communications',171,'=
Telephones: 36.737 (1991 est)
Telephone system: available only to
business and government
domestic. cable. microwave radi relay, and
tropospheric scatter
miternational, satelite earth statrons—2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM |). FS! 11.
shortwave 0
Radios: 2 million (1993 est)
Television broadcast stations: | (1995)
Televisions: NA
Defense
Branches: Army. Navy (includes Naval
Infantry). Au Force. National Gendarmerie.
Presidential Guard
Manpower availability:
males ave 15-49; 3 1AN2339
males fit for military service: 1.572.150
males reach military age (18) annually
151.300 (1996 est.)
Defense expenditures: exchange rate
conversion—$102 million, NAG of GDP
(FY93/94)
,Bare
Obock,
Tadpua,
A e
DsIBOUT!
a, —
\\ ‘J
r om , A» Sab
‘
yn
we
-
5 tearm
: jf — & ME \\
>
Awa
j
| ADDIS ABABA, |
i
;
'' VV er oe
; ~nade
; Oo44
!
j
; J
'' o.
’
'' . wiA
L_
(eography
Location: | \\irica, West of Sonvalia
(,copraphic coordinates: 8 00 N. 38 00 &
Viap references: Africa
\\rea:
|2? | of SY km
119.683 sg km
7 walive area slightly less than twice
he size of Texas
Land boundaries:
Sslikm
ridley witries. Dubouts 437 km. Entrea
Kenva S30 kin. Somalia 1.626 km
‘I fil ki
Coastline: 0 ki dlocked)
Viartime claims: pon indlocked)
International disputes: southern half of the
'' th S | Provissonal
line. ternmtorial dispute with
Climate: trop nsoon with wide
ipl miahion
iu with central mountain
Raitt Valles
Denakil 125 m
lerram: bich plat
ity Crea
Rus Dashen Terara 4.620 m
Natural resources: sinall reserves of gold
; i! i Yj pant ish
Lend use:
irrigated land: |.620 sq km (1989 est.)
Lavironment:
rront iwsucs: detorestation: overgrazing:
ePosiot lificatvon: famine
152
natural hazards: geologically active Great
Rift Valley susceptible to earthquakes.
volcanic eruptions; frequent droughts
international agreements: party to—
Biodiversity. Climate Change. Endangered
Species, Ozone Layer Protection: signed. but
not ratified—Desertification, Environmental
Modification, Law of the Sea. Nuclear Test
Ban
Geographic note: landlocked—entire
coastline along the Red Sea was lost with
the de jure independence of Enmtrea on 27
April 1993
Telephones: $5,000 (1992 est)
Telephone system:
domestic. above-average urban system
mucrowave radw relay and cae trunk
sysiem
micrnational. 3 submarine cables. sateiln
earth station—1! Intelsat (Atlantn Oce.w
Radio broadcast stations: A\\i s ME
shortwave 0)
Radios: 850.000 (1998 es
Television broadcast stations: |
lelevisions: 61.000 (1998 os
Defense
Branches: Army. Navy. Au Force. Nat
Gendarmene. Natronal Police (Suret:
Nationale)
Manpower availability:
males age 15-49: 1 864.259
mates fit for milttary service. 974A ATO
males reach military aee (18) annualls
90.154 (1996 est)
Defense expenditures: exchange rate
conversion——S&82 milion, 2.1% of GDP
(1996 est)
Serbia and Montenegro
'' e Coe ad er Da 0 Borteneg: ae
H . “= a setes Te tornahor -
7 ert wGegendet tse Ww
~ Om Re - Ower
é rn ORS ee
i . ue © sited States
33aG “ee,
ad ~
Pp ROVANIA
~<a weS
. wl
BELGRADE —, >
'' —
am
: . i“,
a,
(A
¢ ~\\
‘ \\
~
. . 3 &
* ,
GORICA atin
'' -— .
f"; .
~ ™“~
i » _
EEE ‘
ante Vi fCnev! nave asserted the
pendent state. but this
Ity recognized as a stak
_ s \\ \\ s tha ihe Soctalist
1} Misia ma (SERY>? has
iu si CCSSOP TEP bhics
Telephones: 9.000 (1991 est.)
Telephone system: the public
telecommunications system was completely
destroyed or dismantled by the civil war
factions: all relief organizations depend on
their own private systems
domestic: recently, local cellular telephone
systems have been established in Mogadishu
and in several other population centers
imternational: imternatronal connections are
available from Mogadishu by satellite
Radio broadcast stations: AM NA. FM
NA, shortwave NA (there are at least five
radio broadcast stations of NA type)
Radios: 350.000 (1992 est)
Television broadcast stations: 0 (Somalia''s
only TV station was demolished during the
civil strife, sometime in 1991)
Televisions: | 13.000 (1992 est.)
Defense
Branches: NA; note
government military forces. clan militias
no functioning central
continue to battle tor control of key
economic or political prizes
Manpower availability:
males ave 15-49: 2.333.994
males fit for military service: 1301954
(1996 est.)
Defense expenditures: SNA NA of GDP','c2937f6591cde5d3323504185a65e316091f03a200425fba9f7fa8bb41c420e4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eb333c9fb173a372439b246281d8a09d183b08a9fa90f5b8ebf717081564694',1996,'CA','Canada','communications',172,'| % we 3 oe .
| ys
Telephones: 15.3 million (1990)
Telephone system: excellent service
provided by modern technology
domestic: domestic satellite system with
about 300 earth stations
international: 5 coaxial submarine cables:
satellite earth stations—S Intelsat (4 Atlantic
Ocean and | Pacific Ocean) and 2
interspuinik (Atlantic Ocean Region)
Radio broadcast stations: AM 900. FM 29.
shortwave 0
Radios: NA
Television broadcast stations: 70 (repeaters
1.400) (1991)
Televisions: | 1.53 million (1983 est.)
Defense
Branches: Canadian Armed Forces (includes
Land Forces Command or LC, Maritime
Command or MC, Air Command or AC,
Communications Command or CC, Training
Command or TC), Royal Canadian Mounted
Police (RCMP)
Manpower availability:
males age 15-49: 7.645.245
mates fit for military service: 6.575.057
mates reach military age (17) annually.
197.688 (1996 est.)
Defense expenditures: exchange rate
conversion—$9.0 billion, 1.6% of GDP
(FY9S/96)
''
€
i
Cape Verde
* a
* -
Antao
.
pats lure a
uo “
"9S *Savta
?s Sac Nacote. Ven
%
“e Boa
"lo wrsta
n
40 Sotavento
$ aa . °
yn® aoa Ma
\\
a
Telephones: |.740 (1987 est.)
Telephone system:
domestic: interisland microwave radio relay
sysiem
international: 2 coaxial submarine cables:
HF radiotelephone to Senegal and Guinea-
Bissau: sateilite earth station—1! Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM |. FM 6.
shortwave 0
Radios: NA
Television broadcast stations: | (1987 est.)
Televisions: 7.000 (1991 est.)
Defense
Branches: People’s Revolutionary Armed
Forces (FARP: includes Army and Navy).
Security Service
Manpower availability:
males age 15-49° 84.003
males fit for military service. 48.8385 (1996
es.)
Defense expenditures: exchange rate
conversion—$3.4 million, NA“ of GDP
(1994)
99
Telephones: 14.613 (1993 est)
Telephone system:
domestic: tully automatic network
imernational: microwave radio relay and
SHE radiotelephone links to Martinique and
Guadeloupe: VHF and UHF radiotelephone
links to Saint Lucia
Radio broadcast stations: AM 3. FM 2.
shortwave 0
Radios: 45.000 (1993 est.)
Television broadcast stations: | cable
Televisions: 5.200 (1993 est)
Defense
Branches: Commonwealth of Dominica
Police Force (includes Special Service Unit
Coast Guard)
Manpower availability:
males age 15-49; NA
males ft; for military service: NA
Defense expenditures: SNA. NAG of GDP','ba85d13b69fc864b680479d358be09f3f69d2f1d8963a479979f885d38abac8a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2a22f6dc8072d122ab18c9d838629e74f9c21c5f5cc5d9632180c3ab2cb9c11',1996,'KY','Cayman Islands','communications',179,'(dependent territory of the UK)
Cayman
@rac
ifthe
Cayman
Grand
Cayman
‘ceonce Tra
Telephones: 21.584 (1993 est.)
Telephone system:
domesitc: NA
muternational: | submarine coaxial cable:
satellite earth station—l1 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 2. FM |.
shortwave 0
Radios: 28.200 (1992 est.)
Television broadcast stations: 0)
Televisions: 6.000 (1992 est.)
Defense
Branches: Royal Cayman [slands Police
Force (RCIPF)
Defense note: defense is the responsibility
of the UK','a60c7c78b201d1c4e46a0baba526092d8fe98dc2d1be473dbcd8bb8c6d540404','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1b8a8cc0a94e011964990d086cc283cee0ded911e4af22f9a1c76a592ea40e1',1996,'CF','Central African Republic','communications',184,'CHAD SUDAN
Bwao
CAMEROON al
.bossangoa Bra
_sanoar
BANGUI
Moaik:, ;
ey,
Telephones: 16.867 (1992 est.)
Telephone system: fair system
domestic: network consists principally of
microwave radio relay and low-capacity.
low-powered radiotelephone communication
international: satellite earth station— |
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM |. FM |.
shortwave 0
Radios: NA
Television broadcast stations: | (1987 est.)
Televisions: 7.500 (1993 est.)
Defense
Branches: Central African Army (includes
Republican Guard), Air Force. National
Gendarmerie. Police Force
Manpower availability:
males age 15-49; 737.330
males fit for military service: 384.134 (1996
est.)
Defense expenditures: exchange rate
conversion—$30 million, 2.3% of GDP
(1994)','bb6d1ae821e8738c4968c2c2e6174d51f0600baf757a3197b9de61507f9c1b81','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78e85721dc88c0b598bf2a4bfd286204c0a0b71a747be477271c20c060c3fee4',1996,'CN','China','communications',202,'(also see separate Taiwan entry)
*
Geograph |
Location: | tern Asia. bordering the East
China Sea. Korea Bay. Yellow Sea. and
South Chin: Sea. between North Korea and
Vietnam
Geographic coordinates: 35 00 N_ 105 00
E
Map references: Asia
Area:
total area: 9.596.960 sq km
land area: 9326410 sg km
comparative area, slightly larger than the
US
Land boundaries:
total: 22,143.34 km
border countries: Atghanistan 76 km
Bhutan 470 km, Burma 2.185 km. Hong
Kong 30 km, India 3.380 km. Kazakstan
1.533 km. North Korea 1.416 km
Kyrgyzstan 858 km. Laos 423 km. Macau
0.34 km. Mongoha 4.673 km. Nepal 1.236
km, Pakistan $23 km. Russia (northeast)
3.605 km. Russia (northwest) 40 km.
Tajikistan 414 km. Vietnam 1.281 km
Coastline: 14.500 km
Maritime claims:
continental shelf: claim to shallow areas of
East China Sea and Yellow Sea
territorial sea: 12 nm
International disputes: boundary with India
in dispute: disputed sections of the boundary
with Russia remain to be settled: boundary
with Taykistan in dispute: short section of
the boundary with North Korea ts indefinite:
involved in a complex ¢ispute over the
Spratly Islands with Malaysia. Philippines.
Taiwan, Vietnam. and possibly Brune:
maritime boundary dispute with Vietnam in
the Gulf of Tonkin: Paracel Islands occup.ed
by China. but claimed by Vietnain and
Taiwan, claims Japanese-administered
Senkaku-shoto (Senkaku Islands/Diaovu
Tar). as does Taiwan
Climate: extremely diverse: tropical in south
to subarctic in north
99
China (continued)
Terrain: mestly mountains, high plateaus.
deserts in west: plains, deltas. and hills in
east
lowest point: Turpan Pendi -154 m
inghest point: Mount Everest 8.848 n
Natural resources: coal. iron ore.
petroleum. mercury. tin, tungsten, antimony.
manganese, molybdenum, vanadium,
magnetite. aluminum. lead. zinc. uranium,
hydropower potential (world’s largest)
Land use:
wapic iand VO
permanenl crops ty
mead ms and pastures 3G
uw wudland: 14%
ther 4S
Irrigated land: 478 220 sg km (1991)
Felephones: 20 million (1994 est.)
Telephone system: domestic and
international services are mereasingly
iVailable for private use: unevenly
distributed domestic system serves principal
industrial centers. and most townships
telephone lines are being
*spanded: interprovincial fiber-optic trunk
nes and cellular telephone systems have
veen installed. a domestic satellite system
55 earth stations ts in place
hornesti
crnational, satellite earth stations—S
ielsat (4 Pacific Ocean and | Indian
Ocean). | Intersputnik (Indian Ocean
Region) and | Inmarsat (Pacific and Indian
can Regions); several international fiber-
102
optic links to Japan. South Korea, and Houg
Kong
Radio broadcast stattons: AM 274. FM
NA, shortwave 0
Radios: 216.5 million (1992 est.)
Television broadcast stations: 202
repeaters 2.050)
Televisions: 75 mullon
Defense
Branches: People s Liberation Army (PLA).
which includes the Ground Forces. Navy
(includes Marines and Naval Aviation), Air
Force. Second Artillery Corps (the strategic
missile torce). People’s Armed Police
(internal security troops, nominally
subordinate to Ministry of Public Secu. ity.
but included by the Chinese as part of the
armed torces’” and considered to be an
adjunct to the PLA in wartime)
Manpower availability:
males ave 15-49- 352 506948
males fit for military service: 194.589.216
males reach military age (18) annualls
9 763.916 (1996 est)
Defense expenditures: the officially
announced but suspect figure 1s 70.2 billion
yuan. NAG of GDP (1995 est.) note—
conversion of the defense budget into US
dollars using the current exchange rate could
produce misleading results
Macau as
‘wate
your "Mg i i nN
C.cc-e8 i
‘ bridge
ihr 306 i
i
a Ww:
b a ay
‘
lina da Taipa
apa, auport
Pd
Causeway
ee es he —
. fina de Coloane
Cahengo:r
Dao','0c2e03ef9b405be61831f044073f5ca2c27db9de3546d082963987ffc5de8523','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('669b2c7c1c9ded69ba6d4beefdc5ed98000d8a7f0cbfaf0198c7f30c70460d86',1996,'CC','Cocos (Keeling) Islands','communications',217,'Telephones: NA
Telephone system:
domestic: NA
international: telephone. telex. and tacsimile
communications with Australia via satellite:
| satellite earth staivon of NA type
Radio broadcast stations: AM |. FM 0.
shortwave 0
Radios: 400) (1992 est.)
Television broadcasi stations: ()
note: wmmermuittent television service via
satellite
Televisiens: NA
Defense
Defense note: defense is the responsibility
ft Australia
105
/14','4eb08b6511f3301f5836a4d14cb563abd2d4f8f967f2b2ce6b0e0d96067cdaa5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31699084b040b92696ac0d92f165f3a7af966768828de5a4013928d8f98e0718',1996,'CO','Colombia','communications',218,'i Sania
Mare
j oe f
| rf
i “
'' era
i aa
i . .
1
. VENEZUELA
ae -~
f
@ BOGOTA
|
s“\\
a A
~~ te
j
i _—
i ~ o''Ca
(,eographys
Location: Northern South America.
the Carbbean Sea. between
Ponan md Ven
North Pacitic Ocear
ela. and bordering the
hetween Ecuador and
Pana
C,cographic soordinates: 4.00 N. 72 00 W
Map references: South America
\\rea:
Ht) sg km
is TIM) re kin}
rea. slightly less than three
of Montana
Ista de Malnelo. Roneador
Bank. and Serramila Bank
Land boundaries:
Brazil 1.643 km. Ecuador
Sim. Peru 2.900 km.
Caunbbean Sea 1.760
1.448 kim)
{ coastline:
2 i foun
Viartiime claims:
Mion depth or to the
ne 200 nm
international disputes: mantime boundary
h Venezucla in the Gulf of
tormtonial dispute with Nicaragua
pelugo de San Andres 45
ind Quita Sueno Bank
‘hmate: tropical along coast and eastern
oler in highlands
ferrain: tat coastal lowiands. central
hlands. high Andes Mountains, eastern
i
ha plas
Pacitic Ocean 0 m
Nevado del Huila 5.750 m
ws! prot
hi vie <? pol
106
Natural resources: petroleum, natural gas.
coal, iron ore, nickel, gold, copper, emeralds
Land use:
arable land: 4%
permanent crops: 2%
meadows and pastures: 29%
torest and woodland: 49%
other: 16%
Irrigated land: 5.150 sg km (1989 est.)
Telephones: |.89 million (1986 est.)
Telephone system: modern system in many
respects
domestic: nationwide microwave radio relay
system: domestic satellite system with 1]
earth stations
international: satellite earth stations—2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 413
(licensed), FM 217 (licensed), shortwave 28
108
Radios: NA
Television broadcast stations: 33
Televisions: 5.5 million (1993 est.)
Defense
Branches: Army (bjercito Nacional}. Navy
(Armada Nacional. includes Marines and
Coast Guard), Aur Force (Fuerza Aerea
Colombiana). National Police (Policia
Nacional)
Manpower availability:
males age 15-49. 10.067.538
males fit for military service: 6.774.105
males reach military age (18) annually
346.372 (1996 est.)
Defense expenditures: exchange rate
conversion-—S2 billion, 2.8 of GDP (1995)
f
—
~~ 200 ter
S ~ a ” 00','ae3a94c1b5d5db3a3f7acf0a363f4c70692b73ac62e4dc40e37c7d7c2716ff9d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('745988461bfe8643758576e597b0f658fa3078243089cb41d3c6d6d5ee2895ae',1996,'KM','Comoros','communications',224,'s &
“a 6
& BAC
Grande Comore
(Njazwyjal
Anjouan
Vatsamud., (Nzwan:}
Monel: 7 mMbDON . ;
(Mwali) -. Domon','67587d04706a1b29a2b6dc01a6e94c93edcab263a0f2c8cc2f17a24e44339686','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf5ace2daaef45a51cd227d1d83c3c5cf4e9c6c91c4393d5b67af6e918a1f81c',1996,'CG','Congo','communications',237,'Telephones: 18.000 (1983 est.)
Telephone system: services adequate for
government use: key exchanges are in
Brazzaville. Pointe-Nowre. and Loubomo
domestic. primary network consists of
microwave radio relay and coaxial cable
international: satellite earth station— |
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 4. FM |.
shortwave 0
Radios: NA
Television broadcast stations: 4 (1987 est.)
Televisions: 8.500 (1993 est.)
Defense
Branches: Army. Navy (includes Marines),
Air Force, National Police
Manpower availability:
males age 15-49: 582,103
males fit for military service: 296.602
males reach military age (20) annually:
25.247 (1996 est.)
Defense expenditures: exchange rate
conversion—$110 million, 3.8% of GDP
(1993)
/a/','43ae05c3ae70c9894532daaa744d3f0f1649266bbdd7f6124f9a423b753a84bd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('965068ca8c8173b3aae1c72b89cbf5da231399518cae313e66c87c65addbe4a7',1996,'CK','Cook Islands','communications',238,'(free association with New Zealand)
Rakananga Ponty
Pukapuna _ "Manihik
Nassau
isianc
Suwarrow
Paimerston .
Artutaks |
Takutea itiaro
Aly Mauvhe
a Rarotonga ~ * AVARY
Mangaa
Telephones: 4.180 (1994)
Telephone system:
domestic. the individual islands are
connected by a combination of satellite earth
stations, microwave systems, and VHF and
HF radiotelephone: within the islands.
service ts provided by small exchanges
connected to subscribers by open wire. cable.
and fiber-optic cable
imternational. satellite earth station—|!
Intelsat (Pacific Ocean)
Radio broadcast stations: AM |. FM |.
shortwave |
Radios: 13.000 (1992 est.)
Television broadcast stations: | studio and
% low-powered repeaters to achieve good
coverage on the island of Rarotonga
Televisions: 3.500 (1995 est.)
Defense
Defexse note: defense is the respor sibility
of New Zeaicnd
Coral Sea Islands
(territory of Australia)
.
S $ “
ra | “
: _—
é3 e
Me umes
. . Se Cornea tsiets
¢ Moras Cays-@ Tregrosse ‘ints
* é 2G?
N2<..” a
- *;.
‘< 9
. Po ora
: ~
ays
AUSTRALIA ae - .
» \\ West
wR L sip
Ny on ove het
= q Cato teiand—®','d962f154d0d616a620f12e949a93ba950caf0927597ea0a54ec1289719df6c91','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30251528e9618c3460bd0accb45400c7b20aa1d8d6333fa5c7cc9f9f4c1ec4c7',1996,'NI','Nicaragua','communications',251,'Telephones: 281.042 (1983 est.)
Telephone system: very good domestic
telephone service
domestic: NA
international: connected to Central American
Microwave System: satellite earth station - |
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 7!. FM 0.
shortwave 13
Radios: NA
Television broadcast stations: |&
Televisions: 340,000 (1993 est.)
Defense
Branches: Civil Guard, Coast Guard, Air
Section, Rural Assistance Guard: note - the
Constitution prohibits armed forces
Manpower availability:
males age 15-49; 917.566
males fit for military service: 616420
males reach military age (18) annually:
33,504 (1996 est.)
Defense expenditures: exchange rate
conversion—$55 million, 2.0% of GDP
(1995)
Cote d’lvoire
(also known as Ivory Coast)
BURKINA
FASO
Aazope*
LIBERIA Oat . AO
P ed tate |
"San Pearc
——-','8b28af65a3addbbd4ca7b9697e82108be8aae2f9386e5c6e8b01436a7d2eb189','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e4cf4236f839b1f7a70e9da6fcb69147a5286036ce8bcd943f65ac6d1b90dc3',1996,'MX','Mexico','communications',259,'Telephones: 87.700 (1987 est.)
Telephone system: well-developed by
African standards but operating well below
capacity
domestic: open-wiie lines and microwave
radio relay
international: satellite earth stations—2
Intelsat (1 Atlantic Ocean and | Indian
Ocean), 2 coaxial submarine cables
Radio broadcast stations: AM 71. FM 0.
shortwave 13
Radios: NA
Television broadcast stations: |*
Televisions: 810,000 (1993 est.)
Defense
Branches: Army. Navy. Air Force,
paramilitary Gendarmerie. Presidential Guard
Manpower availability:
males age 15-49; 3.386.638
males fit for military service: |,762.412
males reach military age (18) annually
157.712 (1996 est.)
Defense expenditures: exchange ratc
conversion—$140 million, 1.4% of GDP
(1993)
Telephones: 800,000 (1995 est.)
Telephone system: while Vietnam''s
telecommunicaiion sector lags far behind
other countries in Southeast Asia, Hanoi has
made considerable progress since 1991 in
upgrading the system, Vietnam has digitized
fully 100% of provincial switch boards,
while fiber-optic and microwave
transmission systems have been extended
from Hanoi, Da Nang, and Ho Chi Minh
City to all provinces; the density of
telephone receivers nationwide doubled from
1993 to 1995, but is still far behind other
countries in the region; Vietnam''s
telecommunications strategy aims to increase
telephone density to 30 per 1,000 inhabitants
by the year 2000 and authorities estimate
that approximately $2.7 billion will be spent
on telecommunications upgrades through the
enc. of the decade
domestic: NA
international: satellite earth stations—2
Intersputnik (Indian Ocean region)
Radio broadcast stations: AM NA, FM
228, shortwiive 0
Radios: 7.2/5 million (1992 est.)
Television broadcast stations: 36 (repeaters
77)
Televisions: 2.9 riillion (1992 est.)
Defense
Branches: People’s Army of Vietnam
(PAVN) (includes Ground Forces, Navy, nd
Air Force)
Manpower availability:
males age 15-49: 18,593,129
males fit for military service: 11,769,955
males reach military age (17) annually:
796,312 (1996 est.)
Defense expenditures: exchange rate
conversion—$544 million, 2.7% of GDP
(1995)
Virgin Islands
(territory of the US)
VWs I
worn Atannc Ocean « a
“ease ATs
Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
east of Puerto Rico
Geographic coordinates: 18 20 N, 64 50 W
Map references: Central America and the
Caribbean
Area:
total area: 352 sq km
land area: 349 sq km
comparative area: twice the size of
Washington, DC
Land boundaries: 0 km
Coastline: 188 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 am
International disputes: none
Climate: subtropical, tempered by easterly
trade winds, relatively low humidity, little
seasonal temperature variation, rainy season
May to November
Terrain: mostly hilly to rugged and
mountainous with little level land
lowest point: Caribbean Sea 0 m
highest point: Crown Mountain 474 m
Natural resources: sun, sand, sea. surf
Land use:
arable land: \\S%
permanent crops: 6%
meadows and pastures: 26%
forest and woodland: 6%
other: 47%
Irrigated land: NA sq km','008d4b1716b00dcb58fec18483eb84dc4cb7fae1cb56b8c9f9ed89be738d8de5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2ccfd5691b315e02e44087c57866dadce4d65c753b7c3dcd36f45f549e7fa3e',1996,'HU','Hungary','communications',260,'Pva* ‘_ j
‘, \\ /
‘ ®& BOSN''A AND 9
‘gp Zaaae HERZEGOVINA >
\\< + Soen« .
tors a
~~. > ‘
iTALY ‘er eee
Telephones: |.216 million (1993 est.)
Telephone system:
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM | 4. FM &.
shortwave 0)
Radios: |.) million
Television broadcast stations: |2 (repeaters
2)
Televisions: | 52 million (1992 est.)
Defense
Branches: Ground Forces. Naval Forces. Air
and Air Detense Forces. Frontier Guard.
Home Guard
Manpower availability:
males age 15-49; 1.314.718
males fit for military service: 1.046490
121
130
Croatia (continued)
males reach miluary age (19) annually:
34.914 61996 est)
Defense expenditures: 337 billion to 393
billion dinars. NA& of GDP (1993 est.):
note—conversion of defense expenditures
into US dollars using the current exchange
rate Could produce musleading results
122
Telephones: 143.600 (1993 est)
Telephone system: adequate domesty
service
domestic: the trunk network consists of
coaxial and thoer-optic cables and microwave
radio relay links
international. satellite earth stations
Intelsat (Atlantic Ocean). | Inmarsat
(Atlantic and Indian Ocean Regions): note
Iceland shares the D.:marsat earth station with
the other Nordic coun ines (Denmark.
Finland, Norway. anc Sweden)
Radio broadcast stations: AM 5. FM 147
(transmitters and repeaters), shortwave 0
Radios: 91 S00 licensed (1993 est.)
Television broadcast stations: 2()2
(transmitters and repeaters)
Televisions: 96.100 licensed (1993 est.)
220
Defense
Branches: no regular armed forces: Police.
Coast Guard: note—Iceland’s defense ts
provided by the US-manned Icelandic
Defense Force (IDF) headquartered at
Keflavik
Manpower availability:
males age 15-49: 71.317
males fit for military service: 63,126 (1996
est.)
Defense expenditures: none
Mian
Ravenna Vend
feanrtt 2 ‘ grout (
Ponto , Gaeta Bar at
"Ones wNas
Sardima
Onstang
.
Cag a’
Palerme 5
Sicty ~82", & Caisdra
Augus''a®
Telephones: 25.6 million (1987 est)
Telephone system: moder. well-developed
fast: fully automated telephone. telex. and
data services
domestic: tigh-capacity cable and microwave
radio relay trunks
international: satelite earth stations—3
Intelsat (with a total of 5S antennas - 3 for
Atlantic Ocean and 2 for Indian Ocean). |
Inmarsat (Atlantic Ocean Region). and NA
Eutelsat, 21 submarine cables
Radio broadcast stations: AM 135. FM 2s
(repeaters 1.840). shortwave 0
Radios: 45.7 million (1992 est.)
Television broadcast stations: 3 (repeaters
1.000)
Televisions: 24.35 nullon (1992 esc)
Defense
Branches: Army. Navy. Aur Force
Carabimert
Manpower availability:
males aee 15-49. 14.739.097
males fit for military service: 12.769.62%8
males reach milttary ave (18) annually
35K RRS (1906 ext }
Defense expenditures: exchange rat
conversion—$20.4 bilhon, 1.9 of GDP
i 1YyOS )','9751dff3180f64059ca040f8cf3b92c34e1f1524675b26dbd50b50bf558f8ba8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b67be2902887b9685f0953d4fbbff879a5d8eaf40c6792182bfa50ac1ac71e3',1996,'CH','Switzerland','communications',274,'Felephones: 430,000 (1987 est.)
Telephone system: among the world’s least
developed telephone systems
domestic: NA
imternational: satellite earth station—1
Intersputnik (Atlantic Ocean Region)
Radio broadcast stations: AM 150. FM 5.
shortwave 0
Kadios: 2 14 million (1993 est.)
Television broadcast stations: 58
Televisions: 2.5 million (1993 est.)
Defense
Branches: Revolutionary Armed Forces
(FAR) includes ground forces. Revolutionary
Navy (MGR), Air and Air Defense Force
(DAAFAR),. Territorial Troops Militia
(MTT), and Youth Labor Army (EJT):
Interior Ministry Border Guards (TGF)
Manpower availability:
maies age 15-49; 3,053,431
females age 15-49: 3.009.852
males fit for military service: \\.898.644
females fit for military service: 1.866.313
males reach military age (17) annually:
65,182
females reach miditary age (17) annually:
61,960 (1996 est.)
Defense expenditures: exchange rate
conversion—SNA, roughly 4% of GDP
(1995 est.)
Defense note: Moscow. tor decades the key
military supporter and supplier of Cuba, cut
off almost all military aid by °993
Telephones: 5.622.976 (1986 est}
Telephone system: excellent domestic and
international services
domestic: extensive cable and microwavy:
radw relay network
miernational. satellite earth satwons—2
Intelsat (Atlantic Ocean and Indian Ocean)
Radio broadcast stations: AVI 7. FM 265
shortwave 0
Radios: NA
Television broadcast stations: | 5 (repeater
1.322)
-
> s14 millon \\yud
Televisions:
Defense
Branches: Army. Av born Ant
Command. Fronteer Guards. |
Cruards
Manpower ay ailabiiity
Millie’ ve 4 « .
? 4 j ; :
rile ‘
4 a, rer
Defense expenditures
. i} (.i bi
TURKEY q
——< Pa
, — —™ A “ ‘
7 ; a. - at -
J »~ Aue c0° A) asanar * ,
—— *" “eocer \\
rape ade
> — ey az Zaw” ;
eTatis "*” P ,
“2 . ’ . _ J
he “J Pa
L ‘
> gq DAMASCUS IRAO
TA Guess .
A wave
’ AN -
Ceography
Location: Middle | hordenneg th
\\i rain Sea bhetw Loh
‘
(,cographic coordinates: 6S 00) No os un]
VNiap references: Vi
\\rea
land houndarns
*
( cust home
\\ileritime charms
International dispules
" .
‘
( hiemate
/ \\
“ 1) i
d wealh |
ratte . Warr
lerrain: primar
Plateau. Na©rrew ia
_ , ‘ ; , ; ;
“ne / unnamed hocathon near Lak
Dibenas -200 m
Mmenes! pom) Mount Her yon J’ Ridin
461
ALI0
Syria (continued)
Natural resources: petroleum, phosphates,
chrome and manganese ores, asphalt, iron
ore, rock salt, marble, gypsum
Land use:
arable land: 28%
permanent crops: 3%
meadows and pastures: 46%
forest and woodland: 2%
other: 20%
Irrigated land: 10,000 sq km (1992)
Telephones: 541.465 (1992 est.)
Telephone system: fair system currently
undergoing significant improvement and
digital upgrades, including fiber-optic
technology
domestic: coaxial cable and microwave radio
relay network
international: satellite earth stations-—/
Intelsat (Indian Ocean) and | Intersputnik
(Atlantic Ocean region); | submarine cable;
coaxial cable and microwave radio relay to
Iraq. Jordan, Lebanon, and Turkey:
participant in Medarabtel
Radio broadcast stations: AM 9. FM |.
shortwave 0
Radios: 3.392 million (1992 est.)
Television broadcast stations: |7
Televisions: 700,000 (1993 est.)
Defense
Branches: Syrian Arab Army, Synan Arab
Navy, Syrian Arab Air Force, Syrian Arab
Air Defense Forces, Police and Security
Force
Manpower availability:
males age 15-49; 3,590,557
males fit for military service: 2,011,610
males reach military age (19) annually:
164,598 (1996 est.)
Defense expenditures: exchange rate
conversion—$875 million, 8% of GDP (1994
est.); note - based on official budget data
that understate actual spending
S73
Taiwan entry follows Zimbabwe
Telephones: NA
Telephone system: system is unsatisfactory
both for business and for personal use; 3.56
million applications for telephones had not
been satisfied as of January 1991; electronic
mail services have been established in Kiev,
Odessa, and Luhans’k by Sprint
domestic: an NMT-450 analog cellular
telephone network operates in Kiev (Kyyiv)
and allows Cirect dialing of international
calls '' rough Kiev’s digital exchange
internationa’: calls to other CIS countries are
carried by landline or microwave radio relay:
calls to 167 other countries are carried by
satelhic or by the 150 leased lines through
the Moscow international gateway switch:
satellite earth stations—NA Intelsat, 1
Inmarsat (Atlantic and Indian Ocean
Regions), and NA Intersputnik
Radio broadcast stations: AM NA, FM
NA, shortwave NA; note—there are at least
two radio broadcast stations of NA type
Radios: 15 million (1990)
Television broadcast stations: at least 2
Televisions: |7.3 million (1992)
Defense
Branches: Army, Navy, Air and Air
Defense Forces. Internal Troops, National
Guard, Border Troops
Manpower availability:
males age 15-49: 12,388,788
males fit for military service: 9,716,127
males reach military age (18} annually:
362,000 (1996 est.)
Defense expenditures: |.35 billion hryvni,
less than 2% of GDP (Ukrainian
Government''s forecast for 1996); note—
conversion of defense expenditures into US
dollars using the current exchange rate could
produce misleading results','1593067a8f71ae88ab98097b9c7cb3e63ee9c2938dee4c7bdbde896e6e261feb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c410882db182ce31aa9a0e6e9be63dbc1985d8f3209999dfbe89d91bcff5efe',1996,'CY','Cyprus','communications',275,'* done Oem
OR, a
''
Telephones: 331.000 (1995 est.)
Telephone system: excellent in both the
Greek and Turkish areas
domestic: open wire, fiber-optic cable. and
microwave radio relay
international: tropospheric scatter, 3 coaxial
and § fiber-optic submarine cables: satellite
earth stations—3 Intelsat (1 Atlantic Ocean
and 2 Indian Ocean), 2 Eutelsat. 2
Intersputnik. and | Arabsat
Radio broadcast stations:
Greek area: AM 11, FM 8, shortwave 0
Turkish area: AM 2. FM 6, shortwave 0
Radios:
Greek area: 270,000 (1993 est.)
Turkish area: 42.170 (1985 est.)
Television broadcast stations:
Greek area: \\ (repeaters 34)
Turkish area: |
Televisions:
Greek area: 107.000 (1992 est.)
Turkish area: 75.0000 ((993 est.)
Defense
Branches:
Greek area. Greek Cypriot National Guard
(GCNG: includes air and naval elements).
Greek Cypriot Police
Turkish area: Turkish Cypnot Security Force
Manpower availability:
males age 15-49: 190.372
males fit for miliary service: 20.880
males reach military age (18) annually
§.749 (1996 ost.)
Defense expenditures: exchange rate
conversion—$493 million, 5 6° of GDP
(1995)
Czech Republic
Telephones: 3.349.539 (1995 est)
Telephone system:
domestic: NA
international: satellite earth stations——2
Intersputnik (Atlantic and Indian Ocean
Regions)
Radio broadcast stations: AM NA. FM
NA, shortwave NA
Radios: NA
Television broadcast stations: \\A
Televisions: NA
Defense
Branches: Army. Air and Air Defense
Forces, Civil Defense. Railroad Units
Manpower availability:
males age 18-49, 2.724.607
males fit for miliary service: 2.074.331
males reach miliary age (18) annually
88.418 (1996 est.)
Defense expenditures: exchange rate
conversion—$931 million, 2.5% of GDP
(1995)
129
138','0ed65ceef328b255fd82270c88a5c52fef2168a4d67135e7a371d1c4d176d4ab','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31ab0ce31c2c33aa8109277bbceb3f60324ae8abd2879ae213d34f0867c34298',1996,'DK','Denmark','communications',282,'COPENHAGEN
~ 2
. J ? c
wT. .
» a ve Bornnow
Felephones: 4.005 million (1985 est.)
Felephone system: excellent telephone and
telegraph services
lomes burted and submarine cables and
microwave radvw relay torm trunk network
ry al. 19 submarine coaxial cables:
atellite carth stations—7 Intelsat, NA
Eutelsat. and | Inmarsat (Atiantic and Indian
(iccan R ns). note Denmark shares the
Inmarsat earth station with the other Nordic
itt Finland. Iceland. Norway. and
.
Radio broadcast stations: AM 3. FM 2
Radios: \\A
lelevision broadcast stations: 2
Televisions: Mb millon (1992 est)
Defense
Branches: Royal Danish Army. Royal
Danish Navy. Roval Danish Air Force
Home Cuard
Vianpower availability:
—_ roe 15-49: 1.3
rate tor military service: 1.150.996
es reach military age (20) annualls
43 324 (1996 est.)
Defense expenditures: exchange rate
mversion—S83.2 billion, 1.8% of GDP
Telephones: | 37,000 (1989 est.)
Telephone system: fair system operating
below capacity
domestic: open wire, microwave radio relay,
tropospheric scatter
international: satellite earth stations—2
Intelsat (1 Indian Ocean and | Atlantic
Ocean)
Radio broadcast stations: AM 12, FM 4.
shortwave 0)
Radios: 640,000 (1992 est.)
Television broadcast stations: 2 (1987 est.)
Televisions: 45,000 (1992 est.)','f66d062b839147afa84438bd4fb5512641871814242677649ae32d706c7cd478','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92518390cbac5046ba5b3060d447ec5860213b97de3786bb0e3c73d4baa8946b',1996,'SO','Somalia','communications',289,'LTHIOPIA
Telephones: 72000) (1986 est)
Telephone system: telephone facilities in the
city of Dyibouti are adequate as are the
microwave rad relay conpections to
outlying areas of the country
domestic: mucrowave radio relay network
international, submarine cable to Saudi
1 Intelsat
Arabia: satellite earth stations
(Indian Ocean) and | Arabsat
Radio broadcast stations: AM 2. FM 2
shortwave 0
Radios: NA
Television broadcast stations: |
Televisions: 17.000 (199% est)
Djibouti (continued)
Defense
Branches: Djibouti National Army (includes
Nave and Air Force), National Security
Force (Force Nationale de Securite), National
Police Force
Manpower availability:
males age 15-49: 102.528
maics fit tor milttary service: 60.076 (1996
Defense expenditures: exchange rate
S26 million. NAG of GDP
134
ETHIOPIA y
n ‘
os” Pd
’
7
_o7 ~~", Beledweyne
.Badoa
MOGADISHU,
‘VWerca','0ab9097e0b8af6c2e70390798879afca4582e53d8ddca76e61d66736174332d5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fa6be66cdf5bca7b82b30ddcf8d3c0631dbca9c0b23d8b27dd50ae6146acfd2',1996,'DO','Dominican Republic','communications',300,'SANTO He
DOMINGO, he
Telephones: 190.000 (1987 est.)
Telephone system:
domestic: relatively efficient system based
on tslandwide microwave radio relay
network
137
Dominican Republic (continued)
rerpational: 1 coaxial submarine cable:
tellute earth station—tI Intelsat (Atlantic
‘ ) Cuan}
Radio broadcast stations: AM [20. FM 0.
shortwave 6
Radios: NA
Felevision broadcast stations: 18 (1987
DPelevisions: 728.000 (1994 est)
Defense
Branches: Army. Navy. Au Force. National
Nlanpower availability:
save 18-49. 2.212.012
tor mil ld service | 3y | 472
reach military aee (18) annually
S361) 61996 est.)
Defense expenditures: exchange rate
otf GDP
77 Th ~
million. 1.4‘:
138','358b5b86d2747972b6b9377bbebf2a59c614df27e25d7f7e29870a3951212195','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcfb2872ac157309aec47f099b9264d6b38aa4a5ea407946db7929e897be7cdc',1996,'EG','Egypt','communications',319,'Telephones: 2.2 million (1993)
Telephone system: large system by Third
World standards but inadequate for present
requiremeats and undergoing extensive
upgrading
domestic: prrncipal centers at Alexandria.
Cairo, Al Mansurzh Ismailia, Suez. and
Tanta are connected by coaxial cable and
microwave radio relay
international: satellite earth stations—2
Intelsat (Atlantic Ocean and Indian Ocean). |
Arabsat. and i Inmarsat: 5 coaxial submarine
cables; tropospheric scatter to Sudan:
microwave radio relay to Israel. participant
in Medarabtel
Radio broadcast stations: AM 39. FM 6.
shortwave 0
Radios: NA
Television broadcast stations: 4|
Televisions: 5 million (1993 est.)
Defense
Branches: Army, Navy. Air Force. Au
Defense Command
Manpower availability:
males ave 15-49: 16 S*WAGD
males fit for military service: VOI23.01V1
males reach military age (20) annually
660.453 (1996 est.)
Deferse expenditures: ex. © 2. ‘ale
conversion— $3.5 billion, 8.2 of GDP
(FY94/9S est.)
Fl Salvador
Geograph)
Location: Middle America. bordering the
North Pacific Ocean, between Guatemala and','e8bace8a3e5b3cdeb12aa867cc59b7084ee599cc03bf7705e606e9ce844ef1af','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0652ff2d19785f869f50fbde5d0a53d7f76f1f8cea7db133b36a296c7af6047',1996,'HN','Honduras','communications',320,'Geographic coordinates: |3 50 N. 88 55 W
Map references: Central America and the
Canbbean
Area:
total area: 21040 sy km
land area: 20.720 sq km
comparative area: slightly smaller than
Massachusetts
Land boundaries:
total: 545 km
horder countries: Guatemala 203 km
Honduras 342 km
Coastline: 307 km
Maritime claims:
territorial sea: 200 nm
International disputes: land boundary
dispute with Honduras mostly resolved by 1!
September 1992 International Court of
Justice (ICJ) decision: with respect to the
maritime boundary in the Golfo de Fonseca.
ICJ reterred to an earher agreement in this
century and advised that some tripartite
resolution among El Salvador, Honduras and
Nicaragua likely would be required
Climate: tropical: rainy season (May to
October): dry season (November to April)
Terrain: mostly mountains with narrow
coastal belt and central plateau
lowest point: Pacific Ocean 0 m
nghest point: Cerro El Pital 2.730 m
Natural resources: hydropower. geothermal
power. petroleum
Land use:
arable land: 27%
permanent crops: S%
meadows and pastures: 29%
forest and woodland: 6%
other: OF
Irrigated land: | .200 sq km (1989)
Telephones: 105.000 (1992 est.)
felephone system: inadequate system
domestic: NA
mernational: satelite earth stations—2
Intelsat (Atlantic Ocean): connected to
Central American Microwave System
Radio broadcast stations: AM 176. FM 0.
shortwave 7
Radios: 2.115 million (1992 est.)
Television broadcast stations: 2%
Televisions: 400.000 (1992 est)
Defense
Branches: Army. Navy (includes Marines).
\\ir Force. Public Security Forces (FUSEP)
Manpower availability:
males age 15-49> 1.322.825
males fit for military service: 787 889
males reach military age (18) annually
64.378 (1996 est
Defense expenditures: exchange rate
conversion—$41 million. about 0.4 of
GDP (1994)','78c2a86260c505404793cb7249323362bff1e5c81b0cca7c3b06a4539adeac33','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('429111275871c6a99a5cd630ab380395d9a31e2826b6ac2fe291eb66fc46b6db',1996,'CM','Cameroon','communications',324,'4
toe,
*
“se
Vong .
~
= Vo °
¥ “yY
we & Awe ''
~—/ Aca ayo *
S% OF ore ~
GA ®t ‘
Geographic coordinates: ims
Map refercaces: \\inco
Area:
tal avoa } 27", “j
hv adtea > ty “4
COMpPUrannc ares r
the size of Calitor
Land bound aries:
total 4407 ky
rwder countrics Be 73h
Lov km. Chad sb ‘\\ iy
Coastline: SS) kn
Maritime claims:
‘ , ‘7 Vile 1h) _
,
depih at exp !
.
i gsiie« fiom ‘ i%
legrireorta wud “? Th
International disputes: J
mMemathenal Pour! a
Chad. the lack of whech led te b
moidents im the past vonyyicted
ratiinatam ™ Caumernan. ¢ | Neeet
Nigeria Jl mulc W ne. ''
md Murine Meurdarics i
the Bakasi Peninsula has |
«J
Climate: \\ anes Cuuaheta
wd mm north
Terrain: southern jow
im venict
central hulls and platew
“avuthe, plains im net!
west pout Atlanin Oke
Chappal Wad j
Natural resources: petr
neohes! purnt
columPute. ron ore. coal
7im. Natural cas
M3
, Religions: Mu s0%. Chistian 40 Judicial branch: Supreme Court. judges
ippointed by the Armed Forces Ruling
Languages: | Hionaly. Hausa Council, Federal Court of Appeal. judges are
I J i my lcd Tf if federal government on the
Literacy: ndvice « Advisory Judicial Committee
5 Political paruies and leaders:
! art tem suspended after
" el 7TNo '' W
} | mick
{ I ip im !
ity
international organization participation:
Covernment VCP. AIDB. ¢ ended). COC, ECA
FCOWAS. FAO. G-1S. G19. G-24.G
LARA. IBRD. IC AOL ICC. ICRM. IDA
Name of countrys:
} il Ry
IFAD. TEC. TERCS. ILO. IME. IMO
i. lotelsat. Imerpol. 1OC. TT
— VUENURSOO NAM. OAL. OPEC. POCALUN
Data code: \\ .
UN Securnts ( nporary ). UNAMIR
Ivpe of government ,
. tL NAVEM IL} NCRO. UNCTAD
UNESCO. UNPICR. UNTOO. UNTIKOM
i)
LNPREDEP. UNPROPOR. UNL. UPI
WCOL WEIL. WHO) WEPOL WMO Wlo®
Wied)
Diplomatic representation in US:
\\ y
{ apital .
\\i K\\/ \\ULRI
\\dnunstrative divistons ,
LS diplomatic representation
|
bla
| { Tile
\\ rial trcolecdas
‘ mstetut '' bLconomys
bconomic overview
! eval ,sien
Sullriage
Favccutive branch
}
f ; i ; ’
| f {)
; {
Levtsiative bi anch ,
Mi
363
keep up with rapid population growth. and
Nigeria once a large net exporter of food
now must mport food
GDP: purchasing power panty —$135.9
billion (1995 est.)
GDP real growth rate: 26°" (1995 est
GDP per capita: $1300 (19995 est
(;DP composition by sector:
j ? ‘
avril alliate $A
j . |
Maus oe
4400 ‘
Ta i- st) ‘ (1994 csi
Inflation rate (consumer prices): 57
(1994 est
Labor force: 42.544 mullion
by occupation” agriculture 54°. industry
Commerce. and services [Y vovermmncni
1st
Unemployment rate: 28°" (1992 est
Budget:
x a
f¢ f id¢ '' ‘ billion
jee | ! ,
capenditures. S64 dillon. including pital
, ,
apenditures of SES Dillon (1994 est
Industries: crude ol. coal. tin. Columbit
. ! [ ! avitcou riitye '' 4 ''
| | Litka Al) | all \\ Hi nt i dj 1} |
mstruchhon materials, f } prod
{ , hen { , ''
Industrial production growth rate: \\\\
blectricits
‘+ med RW
/ | a
>hRW his
Agriculture:
lihicit drugs
VN \\
\\\\ ;
\\\\ '' ‘
bE aports: $9
|
Imports
‘ Me SO) is j
EF aternal debt: S''2 5 | y
Economic aid:
recynent, ODA. SNA
Currency: | nauraiN (WH) hol
| ul hange rates: att. \\ 1 ’ | \\S
» xs | ry, [YUL +] wus pyus
Eli Maa iWy* 1Yyy 4 | ys 7
nar ”)
Fiscal vear:
Phlalle Ralin,
Transportation 10654
Railways:
wtal. 3.557 km (1995 |
j 4
HaTOW Laue SOS Am i O60/-m gaug
Vandard vases S’ km | 445-m onue
Highways:
pial: WAZ AAA
pureed. M4 SOO km
mpaied SO644i hm «199
Waterways: 8.575}
Niger and Benue m
|
ANG ciece
Pipelines: crude «oi! 2.042 4 ny
products S10) kom. natural is MAD}
Ports: Calabar. Lagos. Onne. Port Ha
Sapele. Wart
Merchant marine:
has? SS Shap 1 WO GRI
1K7 SS) GRIT/6364 ~ DW
VupPS DP c Pulb ifs
Pyys ‘
Virports:
; ff
; / 4 f
j J
‘
/ ‘
‘ ,
‘
‘ ‘
“
~
Heliports: ny
lelephones ) be y
lelephone system:
Radio broadcast stations \\ HN
Radios: 2)
lelevision broadcast stations
lelevisions: (>
Defense
Branches: Army. N And
marantars Po 4 ban
Manpower availability:
i ‘ ave 4 ‘ } }
A
fy
Defense expenditures:
* ''
36¢
th New Zealand
cmalona vrecme signed. bul not
witicd —I tthe §S
C,eographic note: one of world » largest
Telephones: 276 (1992 est) a
lelephone system:
Labor force: |.000 (1981 est) connects all villages on island
by occupation, most work on family mternational, NA
Radio broadcast stations: AM |. FM |
shortwave 0 (1987 est.)
Radios: | 000 a
Television broadcast stations: Nem
plantations: paid work exists only in
government service, small industry. and the
Nive Development Board
L nemployment rate: NA‘
Budget:
revenues: S55 million
Televisions: 312 (1991 ex
expenditures: $6.3 million, including capital
expenditures of SNA (1985 est.)
Industries: tourism. handicrafts, food Defense
processing
Industrial production growth rate: NA“ Branches: Police | a oo
Electricity: Defense note: detens t
capaci r SOO kW of New Zealand Geography
production: 2.7 mithon kWh Location: ©)
consumption per capita: | AYO kWh (1992) ()
Agriculture: coconuts. passion trun. honey Geographic coordinates
limes. aro, yams. Cassava (Lapicca). sweet Slap references: ©)
potatoes. pigs. poultry. beet cattle Area:
Exports: $117.500 (fob. 1989)
Commodities. Canned Coconut cream. copra
honey. passion fruit products. pawpaw. rot
op if | hal | rip) h rdicral
| md houndariw:
( ousthinne
Western S \\ustra ts
bFaternmal debt: S\\ \\
Lconomic aid:
j mw OPA SNA
Currency: | New 7/ ’ \\/
iw |
bachange rates: New 7/ bdo \\/‘
it SS ‘ las pe
"y Hs4 4 1) ”") j
"y Jinnah
Fiscal vear: | April — 4) Marcel
lransportation
Railways: 0 km
Niaritinn
Internati
chains
yea chispouts ‘
( limats
ber th
Natural resours
land us
Irrigated land','cc9e5a5901e2eb5fa67709902a98d25ca60ab9af018f69a5d5c2000e3b44afb9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('460a3febd89923773927cf54e06c4a6f79cd73dd6a2ec899eca0a60280b9a2a2',1996,'ER','Eritrea','communications',327,'Telephones: 2.000 (1987 est)
Telephone system: poor system with
adequate government services
domestic: NA
international: mmermmational communications
from Bata and Malabo to African and
European countnes: satellite earth station— |
Intelsat (Indian Ocean)
Radio broadcast stations: AM 2. FM 0.
shortwave 0
Radios: NA
Television broadcast stations: |
Televisions: 4.000 (1992 est)
Defense
Branches: Army. Navy. Ai Force. Rapid
Imervention Force. National Police
Manpower availability:
males age 15-49; 92.704
males fit for military service: 47.124 (1996
eM.)
Defense expenditures: exchange rate
conversion—$2.5 million, NAG of GDP
(FY9VW94)
o SAUD!
AGAGIA
SUDAN f
— &. 2
( 4
y
Keren, ~——
Ae order? “Wassawe® CMiN
aswaca®
A r
j . .
os / ee Nw a
j Ny ~
; \\
5 .
Y \\ .
\\Assate
ETHIOPIA sg °
»- 74
jf
heer
Telephones: NA
Telephone system:
domestic: very inadequate: about 4
telephones per 100 families. most of which
are in Asmara: government is seeking
international tenders to improve the system
international: NA
Radio broadcast stations: AM NA. FM
NA, shortwave 0)
Radios: NA
Television broadcast stations: |
(government controlled)
Televisions: NA
Defense
Branches: Army. Navy. Air Force
Manpower availability:
males age 15-49: NA,
males fit for military service: NA
Defense expenditures: SNA. NAG of GDP
>.','3517e89f5c9320ada77e2328a23720f24f8a38c0da5f9a984d28535ab5d1a0fb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4151598cb7339aa5d53c1817241d8b44ced5999f19d8480b9a224c268edfaf27',1996,'FI','Finland','communications',332,'Se | 4 ‘
ase, “Srauw .* “2
ave /
. j
Hoan aa veanpeey
Vonme
54a 0°98 ."# ” Taro
\\
“tt *
“a 74%4 2
a |
a» * P|
Telephones: 400.000
Telephone system: system is antiquated:
improvements are being made piecemeal.
with emphasis on business needs and
international connections: there are stll
bout 150.000 untulfilled requests tor
subscriber service
domestic. subsiantial investment has been
made in cellular systems which are
operational throughout Estonia
imiernational: imerational tratfie ts carried
to the other former Soviet republics by
landline or microwave radio relay and to
other countries partly by leased connection
to the Moscow international gateway switch
and partly by a new Tallinn-Helsinki fiber
optic, submarine cable which gives Estonia
access lo intemational circuits everywhere:
access to the international packet-switched
digital network via Helsinki
Radio broadcast stations: AM NA. FM
NA, shortwave 0
Radios: 710.000 (1992 est)
Television broadcast stations:
note: provide Estonian progranis as well as
Moscow Ostenkino’s first and second
programs
Televisions: 600.000 (1993 est )
Defense
Branches: Ground Forces. Navy. Air and
Air Detense Force (not offictally sanctioned).
Maritime Border Guard. Volunteer Detense
League (Kaitselit). Security Forces (internal
and border [roops }. Coast Guard
Manpower availability:
males age 15-49: 387.835
males fit for military service: 280.757
males reach military age (18) annually
10.525 (1996 est.)
Defense expenditures: exchange rate
conversion—S$35 million. 15° of GDP
(JOYS)
1S]
4 aru is
“BgTOCKHOLM
lelephones: © 4 ye
lelephone system: exc: id
mr j i
j | if
‘% .
‘ ta ; " ;
'' i\\ lé
'' | | \\ ''
{) | ral I if \\ ,
} ‘) i Nu cs
| rt? | ; A ih s?
! rN rd unite 1 mianrk } miant!
he ma | Norway
\\M 5. FEM 4600
shortwave 0
Radio broadcast stations:
Mostly repeater
Radios: 7.272 millwon (1993 est)
lelevision broadcast stations: 880 (mostly
repeaters)
)
lelevisions: 3.5 millon
oT
Defense
"ranches: Swedish Army, Royal Swedish
Navy. Swedish Air Force
Manpower availability:
males age 15-49. 2 AIR
males fu for military service: | 867.031
males reach miliary ave (19) annuails
51.357 (1996 est)
Defense expenditures: exchange rate
conversion—$5S.8 billion, 2.50 of GDP
(FY94/95)','b8f1234a8e48b4a3511869403a00bfa6443e8e7cff989a7b29568a67373b456d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07af868eaa52b77ecf4ca644abe9ac11117b06322406eb04213c9d487127936e',1996,'JP','Japan','communications',342,'Telephones: | 00.000 (1983 est)
Telephone system: open wire and
microwave radw relay system adequate tor
government use
domestt open Wire and microwave radi
relay
mernatonal: open wire to Sudan and
Dubouti: microwave radio relay to Kens,
and Dybouti: satelite earth statrons— 3
Inteisat (1 Atlantic Ocean and 2 Pacith
Ocean)
Radio broadcast stations: AM 4. FM 0
shortwave 0
Radios: 9.9 million (1992 est)
Television broadcast stations: |
Televisions: 1}00,000 (1998 est)
Defense
Branches: Ginvund Forces. Air Force
Police
153
/ba
Ethiopia (continued) Europa Island People
Spano oF PeeN? Population: uninhabited
flowing the secession of Entrea
bthiwy naval facilities retained in
brits ~ Pessession, Current reorgani7ation
ko Mot meclude a navy Government
\\ianpower availability: Name of commtry:
my. Vee’ we ; conventional lone form: none
ES ee ma conventional short form: Europa Island
v1 GRRNEE og eR local lone form: none
, . local short form: Ve Europa
Defense expenditures: ¢ .change 1 . | . Note cede: EU
_ — mate > Type of government: French possession
| , adnunistered by Commissioner of the
if ; Republic: resident in Reunion
\\ . Capital: none: administered by France from
Reunion
Independence: none (possesion of trance)
Flag: the flag of France ts used
¢.
teed " k
¥ i ;
. ainaa?
‘* ry
TOR YO
*
Koon “Nagey®
Pes
ee a ee
ee Om
Ayus?
Telephones: 64 million (1987 est.)
Telephone system: excellent domestic and
international service
domestic: NA
imernational: satellite earth stations—S
Intelsat (4 Pacific Ocean and | Indian
Ocean). | Intersputnik (Indian Ocean
Region). and |! Inmarsat (Pacific and Indian
Ocean Regions): submarine cables to China,
Philippines, Russia. and US (via Guam)
Radio broadcast stations: AM 318. FM 58.
shortwave 0
Radios: 97 million (1993 est.)
Television broadcast stations: | 2.350 (1
kW or greater 196)
Televisions: 100 million (1993 est.)
Defense
Branches: Japan Ground Self-Detense Force
(Army). Japan Maritime Selt-Detense Force
(Navy). Japan Air Self-Defense Force (Air
Force)
Manpower availability:
males age 15-49: 31.833.691
males fit for military service: 27.322.517
males reach military age (18) annually
858.912 (1996 est.)
Defense expenditures: exchange rate
conversion—$50.2 billion, 1% of GDP
(FY9S/96)
Jarvis Island
(territory oi the US)
Telephones: 66.510 (199% est)
Telephone system: low capacity microm ove
radw relay and wire sysiem bemg expanded
connected to Central Amencan Microw ave
Svstem
domestin wire and microwave tadw relay
mite national, satelite earth sation. — |
Inversputnak (Atlantic Ocean Regron) and |
Intelsat (Atlant Ocean)
Radic >roadcast stations: AVI 45. PME
shortwave 3
Radios: 1.037 mullon (199) es)
Television broadcast stations: 7 (1/994 ex |
Televisions: 260,000 (199) ex
Defense
Branches: Ground Forces, Navy. An Force
Manpower availability:
males ave 15-49 YRERSS
males fit for mulitary service. CAIN TS4
males reach mulitery awe (18) anneal:
47.786 (1996 est)
Defense expenditures: exchanve rate
conversion——S2I8 1 millon, NAG of GDP
(1996)
Telephones: 550
Telephone system:
domestic: aatomatic network. HF
radiotelephone to Ascension. then into
worldwide submarine cable and satellite
networks
international: mayor coaxial submarine cable
relay point between South Afnca. Portugal.
and UK at Ascension: satellite earth
stations—2 Intelsat (Atiantic Ocean)
Radio broadcast stations: AM |. FM 0.
shortwave 0
Radios: 2.500 (1993 est)
Television broadcast stations: ()
Televisions: NA
Defense
Defense note: defense is the responsibility
of the UK
AS','1281663e1468a12b964eca13c28a85ad37d1982db318bb5b4e05845ac10131f5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34fa08b088fe25ca5ec239c30fe6339166d2f8b00d9affda83e62c3bb18de274',1996,'FO','Faroe Islands','communications',349,'(part of the Danish realm)
Eysturoy
Steymoy Svinoy
ieniene * Komesve
? Bordoy
Vyames
vagar @ TORSHAVN
Sandoy
Stuwoy
9 vOroyr
Sudui Oy
Telephones: 27.900 (1984
lelephone system:
ommunicateons. tan domestec tacirtes
mies \\V\\
i 4S Coannal bmarwe cables
Radi broadcast stations: \\“t |) EM 4
; '' ’ ;
regm™ ! } MmewiMiasye f
Radios: )4 14" WO? ost)
lelevision broadcast stations: § (repeaters
‘)
lelevisiows: | 4.000) mo? ost)
Defense
Branches: ive moletars
i bores imal ¢ scant
|
Defense expendity res: SN ANAS of GDP
Defense note: de vcs he responsrbalety
,
158
< oenMa
a a
Vai Lew * a
Kadavu
eva','3cc0d500f9d6533f636991be16c4fbe19a4c5447540eb1a6fd658719d6f882bb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('435de4e9d51126e7bbedeeb8c42ffd53d42fb0afc4b3c5d578774c0322bcf627',1996,'EE','Estonia','communications',365,'lelephones: 2.78 million (1986 est
lelephone system: good ser from cabh
mad microwa radi ‘iy net rh
how ‘ ble and rows rad ela
/7/
miernational: | submarine cable: satellite
earth stations—access to Intelsat
transmission service via a Swedish satellite
earth stavon. | Inmarsat (Atlantic and Indian
Ocean Regions): note—Finland shares the
Inmarsa earth station with the other Nordic
countnes (Denmark. Iceland, Norway. and
Sweden)
Radio broadcast stations: AM 6. FM 105.
shortwave 0
Radios: 4.98 million (1991 est)
Television broadcast stations: 235
Televisions: 2.! million (1983 est)
Defense
Branches: Army. Navy. Aur Force. Frontier
Guard (inc ‘es Sea Guard)
Manpower availability:
males ave 15 49: 1.307.128
males fit for military service: 1.074540
males reach miltary age (17) annually
3) 760 (1996 est.)
Defense expenditures: exchange rat
of GDP
conversron—S19Y hillnon. 1.6%
hyys
Climate: maritime: wet, moderate winters
Terrain: low plain
lowest pomt: Baltic Sea 0 m
1 (DP
highest pot: Gaizinkalns 342 m
Natural resources: minimal: amber. peat.
lnnestoue. dolomite
Land use:
arable land: 27%
permanent crops: Of
meadows and pastures, 13%
forest and woodland: 39%
other: AVG
Irrigated land: 160 sg hin (1990)','03bdfad84b6034d8dd9c601ed35e3b37ef9374d043cab9478135930cfb29f288','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9a74a5d05f18883c8f88e16f94a6f2afe38467d8e75c1f6ca9ec3110e89f610',1996,'FR','France','communications',366,'4 “
Durme Que, —
e
o. rans® A
ed
+ we
Telephones: |.572 million (1993 est.)
Telephone system: the domestic system 1s
mediocre, but adequate for government and
business use, in part because major
businesses have established their own private
systems: since 1988. the government has
promoted investment in the national
telecommunications system on a priority
basis: despite major improvements in trunk
and urban systems, telecommunication
services are still not readily available to the
major portion of the population
domestic: microwave radio relay
international: sate! te earth stations—3
Intelsat (1 Atlantic Ocean and 2 Indian
Ocean): microwave radio relay to
neighboring countries
Radio broadcast stations: AM 26. FM &.
shortwave 1]
Radios: | 1.3 million (1992 est.)
Television broadcast stations: 29
Televisions: 2.08 million (1993 est.)
Defense
Branches: Army. Navy. Air Force, Civil
Armed Forces, National Guard
Manpower availability:
males age 15-49; 30,519,339
males fit for military service: 18.720.175
males reach military age (17) annually:
1.437.208 (1996 est.)
Defense expenditures: exchange rate
conversion-—$3.1 billion, 5.3% of GDP
(FY95/96)
377
Telephones: 191.647 (1993 est)
Telephone system: adequaie system
principal center i Saimnt-Dents
domestic) modern open wire and microwave
radio relay network
mternational, radvtelephone communication
to Comoros. France. Madagascar: new
microwave route to Mauritius, satellite earth
station — 1 Intelsat (indian Ocean)
Radio broadcast stations: AM 3. FM | 3.
shortwave 0
Radios: 151.000 (1992 est)
lelevision broadcast stations: | (repeaters
1S)
Televisions: | 16.18! (1992 est)
Defense
Branches: French forces (Army. Navy. Au
Force. and Gendarmerie)
Manpower availability:
males ave 15-49: 176.609
90). 784
males reach military age (18) annually
5.728 (1996 est.)
males fit tor military service
Defense note: defense is the responsibility
of France
.
Telephones: 340 (1985 est.)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM |, FM 0,
shortwave 0
Radios: NA
Television broadcast stations: 0
Televisions: NA
Defense
Defense note: defense is the responsibility
of France
—Mediterranean .-7.
Sea Fd a ae
o* ‘
1 -“ Janin !
| ‘ . ''
j ’ ‘
Be
j ’
j r ;
/ Samaria :
” Tilkarm ‘
‘ ’
- ‘
, 7 s s
eo” » Nabulus ‘ :
4 ‘
<Caigityan Zs
A ‘
a;
‘ ’
. ’
7 ‘JORDAN
'' A
‘ *
''
+ . z
Me, Ravn Allan P
‘
yt -vericno .
wel
No— -’4"s ‘
if.- ¢* ‘
| —* sa “« ‘
)-verusaiem ‘
7
ISRAEL Bw.
Pug Lang J ‘
_* *Betnienem Py
eo” ‘
‘ ;
‘ ’
14 Judaea ‘
Note: The Israel-PLO Declaration of Principles on
Interim Self-Government Arrangements (‘the
DOP**). signed in Washington on 13 September
1993. provides for a transitional period not
exceeding five years of Palestinian intenm self-
government in the Gaza Strip and the West Bank.
Permanent status negouations began on S May
1996.
Telephones: NA
note: 8% of Palestinian households have
telephones (1992 est.)
Telephone system:
domestic: NA
international; NA
note: Israeli company BEZEK is responsible
for communication services in the West
Bank
Radio broadcast stations: AM |, FM 0.
shortwave 0
Radios: NA; note—82% of Palestinian
households have radios (1992 est.)
Television broadcast stations: ()
note: | broadcast station is planned for
Jericho
Televisions: NA; note—54% of Palestinian
households have televisions (1992 est.)
ene
Defense
Branches: NA
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP','c1e136d3996b4e92bae4a715c770ec7b45217e9aa9aea699259a648ddb2ef5ae','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e953bb4d9cff668add64b66686937d3943e21376bb6da1a1aac826777c7a1ab2',1996,'WF','Wallis and Futuna','communications',372,'lelephones: 35
lelephone system.
Radio broadcast stations
Radios
lelevision broadcast stations
}
eles isions
Defense
Branches: \\
\\ Ant
Genda
Manpower availability
$83.95) (1996 est
Defense expenditures: c)
conversion——>4 bil
(1905','f73fc6bfd6ae2845dc93407ece8226665caa5c39c9d2547e518630e7595390b8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f91dacafdae5bd033fd1ce7ad954368ad3e7460fc8aba467c971d5baa068c08',1996,'GF','French Guiana','communications',373,'overseas department of France)
i
''
'' AYENN
.
| .
f
''
''
|
’ *
;
}
|
—— a a |
Felephones: 33.200 (1983 est)
Telephone system:
domestic: NA
miernational: satellite earth station— |
Intelsat (Pacitte Ocean)
Radio broadcast stations: AM 5. 1M 2
shortwave (
Radios: 116.000 (1992 est)
Television broadcast stations: 6
Televisions: 35.000 (1992 est)
Defense
Branches: French Forces (includes Army
Navy. Au Force), Gendarmerte
Defense note: detense is the responsibility
of France
French Southern ard Antarctic
Lands
(overseas territory of France)
te Armsterdarr
“@ Sam +a
2s Aergue ar
Telephones: (| 000 (1991 est)
Felephone system:
domestic. adequate network of microwave
radio relay and open wire
dJermational: microwave radio relay links to
Senegal and Guinea-Bissau: sateilite earth
station—T Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3. FM 2.
sShoriwave 0
Radios: | 80.000 (1993 est.)
Television broadcast stations: NA
Televisions: NA
Defense
Branches: Army. Navy. Nationai Police
Manpower availability:
males age 15-492 267.188
males fit for military service: 134.611 (1996
esti
Defense expenditures: exchange rate
conversion—S14 million, 3.8 of GDP
(FY93/94)
Gaza Strip
. aa
~ ~ .
ay! 4’ Saar” .','f5d2bd058833f97d26ae85ab5d8d5b29621bcbadc1235052cc34e17ee2d21aa6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('658923538e143434bf9db36a5c09c7353c8e6f4cab8bf4552de5597fad147c94',1996,'IL','Israel','communications',379,'“na
.
.
aD §
oreo ®
= e wn “
\\" n me wae ens
oe. -hgone
t ¥PT er ret Le ”
ow TIA
4 os eo
¥ = =gs
Note: The Isracl-PLO Declaration of Principles on
interbm Self-Government Arrangements ¢* ‘the
DOP). sigried in Washington on 13 September
1993. provides for a transition’) period not
eveeeding five vears of Pioestinian interim sellt
government in the Gaza Strip and the West Bank
Permanent status negotiations began on 5 May
1996
Telephones: \\A
note: 1O% of Palestinian households have
telephones (1982 est.)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 0. FM 0.
shortwave 0)
Radios: NA: note—95S% of Palestiman
households have radios (1992 est.)
175
Gaza Strip (continued)
iclesvision broadcast stitions: 0
tclevisions: NA. note—S9% of Palestinian
1992 est.)
''
ais ave TeleVISIONS [ t
Defense
Branches: \\A
\\Mianpower availabilty:
44° NA
service’ NA
Defense expenditures: SNA. NAS of GOP
176
(also see separate Gaza Strip and West Bank
entries)
P.
--_- -
¥
a
. ‘rs
---- - Y <n
J »
Nananyya, -
afer
*
Had ,
- -
Nazaretr PA . ‘Ny
“3Ge"a, )
° %
vYeatan
A fata jwa
t .
. a “. We PY
3 m* > >a
. Jerusaiem
Ashdod $
°.
aC ~
-4
''
e a
°
2D AN
a
Ve
/
Yr e
» “so
Agree:rert
aornanaes at
¢ at , . >
ie ’ ™~
aor
Note: The terrtones occupied by Esracl since the
1967 war are not included in the data below. In
Keeping with the framework established at the
Maadnd Conference in October 1991. bilateral
offations are beige conducted between Israel
1 Palestinian representatives. and tsrael and
Syria. to achieve a permanent sctiiement between
hem. On 25 Apnl 1982. Isracl withdrew trom the
Sings pursuant to the 1979 Isracl-Fgypt Peace
treaty. Outstanding territorial and other dispute
with Jordan were resolved in the 26 October 1994
Isracl-Jordan Treaty of Peace','803cde78ed05ccc14499677352c41feed62ef8741b32a6f4971bd2dc542e13ad','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d0ab3f787742327644a77fa47e76b841d87bf66782a66f3e7b2ae79593f27be',1996,'GE','Georgia','communications',386,'Note: Beset by ethnic and civil strite since
independence in 1991. Georgia began to stabilize
1 1994. Separatist conthicts in Abkhazia and
South Ossetia have been dormant tor more than
Iwo vears. although pohtical setlements remain
ciusive. Russian peacekeepers are deploved in both
regions and a UN Observer Mission is operating
in Abkhazia. As a result of these conthicts
Georgia still has about 250.000 internally
displaced people. In November 1995, Georgia held
neacetul. generally tree and fair nationwide
presidential and parliamentary clecuons. Although
ine COUNnTTV continues to suffer trom a enppling
cconomic crisis, aggravated by a severe energs
shortage. some progress has been made and the
Georgian Government remams committed to
economic reform im cooperation with the IME and
World Bank. Victence and organizeu crime
, rpaaheucdl an 1008
WETE sharply CUTLGHCG in YY
Telephones: 672.000 (1993 est!
Telephone system: poor service: 339.000
unsatistied applications tor telephones
(December 1990 es.)
NA
miernational
dome st
landline to CIS members and
Turkey: satellite earth stauion—! Eutelsat:
leased connections with other countries via
the Moscow international gateway swiich:
imternational electronic mail and telex service
available
Radio broadcast stations: AM NA. FM
NA, shortwave NA
Radios: NA
iclevision broadcast stations: 3
Televisions: NA
Defense
Branches: Ground Forces. Navy. Air and
\\ir Detense Forces, Republic Security
Forces (internal and border troops)
Manpower availability:
males age 15-49: 1,288.29]
males fit for military service: 1.021.632
males reach milttiary age (18) annually
40.654 (1996 est.)
Defense expenditures: exchange rate
conversion—S$60 million to S65 million,
NAG of GDP (1995)
Telephones: 233,000 (1987 est.)
Telephone system: the system is above the
African average; key centers are Sfax.
Sousse, Bizerte, and Tunis
domestic: trunk facilities consist of open-
wire lines, coaxial cable, and microwave
radio relay
international: 5 submarine c2bies; satellite
earth stations—-1 Intelsat (Atlamic Ocean)
and | Arabsat with back-up control station:
coaxial cable and microwave radio relay to
Algeria and Libya; participant in Medarabtel
Radio broadcast stations: AM 7, FM 8,
shortwave 0
Radios: | 693,527 (1991 est.)
Television broadcast stations: 19
Televisions: 670,000 (1992 est.)
Defense
Branches: Army, Navy, Air Force,
paramilitary forces, National Guard
Manpower availability:
males age 15-49: 2,354,513
maies fit for military service: 1,349,728
males reach military age (20) annually:
91,866 (1996 est.)
Defense expenditures: exchange rate
conversion—$535 million, 2.8% of GDP
(1995)
481
AN
Turkey
, s
Telephones: 6.89 million (1990 est )
Telephone system: fair domestic and
international systems
domestic: trunk microwave radio relay
network; limited open-wire network
international: satellite earth stations—2
Intelsat (Atlantic Ocean), | Eutelsat, and 2
Inmarsat (Indian and Atlantic Ocean
regions); | submarine cable
Radio broadcast stations: AM 15, FM 94.
shortwave 0
Radios: 9.4 million (1992 est.)
Television broadcast stations: 357
Televisions: 10.53 million (1993 est.}
Defense
Branches: Land Forces, Navy (includes
Naval Air and Naval Infantry), Air Force,
Coast Guard, Gendarmerie
Manpower availability:
males age 15-49: 16,937,828
males fit for military service: 10,312,010
males reach military age (20) annually:
637.456 (1996 est.)
Defense expenditures: exchange rate
conversion—-$6.0 billion, 4% of GDP
(1995): note—figures do not include about
$7 billion for the government''s
counterinsurgency effort against the
separatist Kurdistan Workers’ Party (PKK)
oe
i =~
—
(ean i Po arcranistas
7 =e —
Telephones: NA
Telephone system: poorly developed
domestic: NA
international: linked by cable and
microwave radio relay to other CIS republics
and to other countries by leased connections
to the Moscow interuational gateway switch;
a new telephoue link from Ashgabat to Iran
has been established; a new exchange in
Ashgabat switches international traffic
through Turkey via Intelsat; satellite earth
stations—1! Orbita and | Intelsat
Radio broadcast stations: AM NA, FM
NA, shortwave NA; note—there is at least
one state-owned radio broadcast station of
NA type
Radios: NA
‘\\ clevieion broadcast stations: NA
Televisions: NA
Defense
Branches: Army, Air and Air Defense.
Republic Security Forces (internal and
border troops), National Guard
Manpower availability:
males age 15-49: 1,024,398
males fit for military service: 834.803
males reach military age (18) annually:
41.697 ,.996 est.)
Defense expenditures: 4.5 billion manats,
3.0% of GDP (1995): note—conversion of
defense expenditures into US dollars using
the current exchange rate could produce
misleading results
eee','b5a5d0ea9a2232be1561d5fe341af1c0ab7009c89c7d22024e9fe58a737b9e78','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f353719c1bec487abcbc68f3b68a842118c61c6c04e98d17bfd40cc0db9e40e0',1996,'GH','Ghana','communications',396,'zatanga’ é ,
w_— :
) avae &
ACCRA® "> on
Telephones: 70.000 (1988 est)
Telephone system: poor to fair system
domestic. primanly microwave radio relay
mermational: satellite earth statron— |
Intelsat (Atlantic Ocean)
Radio broadcast stations: AMI 4. FM |.
shonwave 0
Radios: NA
Television broadcast stations: 4 (repeaters
S)
Televisions: 250.000 (1993 est)
Defense
Branches: Army. Navy. Ar Force. Pelice
Force. Palace Guard, Civil Detense
Manpower availability:
males awe 18-49: 4.135 538
males fit for military service: 2.303.423
males reach military age (18) annually
176.332 (1996 est.)
Defense expenditures: exchange rate
conversion— $30 million, 08% of GDP
(1994)','cd37fe3c44319668dedff7f77603ff05252abc8e4133b59c0af9cd94783ca4e0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82da794e4d61b1399a0aa4b4d4fb432d038aa0ae41fb1332ed7c28ead3a47bf3',1996,'GI','Gibraltar','communications',403,'idependent territory of the UK)
Telephones: 19.529 (1993 est)
Telephone system: adequate. auiomain
domestic system and adequate nvternational
facilities
domestic: automatic exchange facilities
international: radwtelcphone. microwave
radw relay: satellite earth sation—! Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM |. FM 6
shortwave 0)
Radios: NA
Television broadcast stations: 4
Televisions: NA
Defense
Branches: British Army. Roval Navy. Roval
AW For c
Defense note: defense is the responsibility
of the UK
Glorioso Islands
(possession of France)','65375241f14b8fd675df9b77f127f5e18841343056ebfd287ed6b0ace713f842','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4ecbe92d3a8e6db705c8ade4587b8e9d232e516601b159bf994deb03141ade3',1996,'GR','Greece','communications',413,'Pelephones: 5.57) .29 3 esi
Felephone system: juate, modern
’ ’ ° . 9 i.
A‘ . . 4 ty <div?
if )
\\1 ‘ j I i
{ '' iF }
RR,
Radio broadcast stations: \\\\i 298. FEM
Radios: \\
felevision broadcast stations:
lelevisions: 3 on 3
Defense
Branches: H nic Arms. H mic Navy
i Aun Force. Natronal Guard. Police
Manpower availability:
4¥Y 1675 8&7
i¢ > (46 +, 3A
¢ ? Whida
18S
>.
¥Ooro
Danmar
+B vy
Woon
Dyéundh.
mt
40
. - ''
*.
NUUK
A 3
Telephones: 17.900 (1984 est)
Felephone system: adequate domestic and
international service provided by cables and
microwave radio relay
domestic. microwave radio relay
190)
international: 2 coaxial submarine cables:
satellite earth station—! Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 5. FM 7
(repeaters 35). shortwave 0
Radios: 23.000 (199] est.)
Television broadcast stations: 4 (repeaters
Y)
lelevisions: | 2.000 (1991 est.)
Defense
Defense note: detense iy the responsibility
of Denmark
Telephones: | 25.000
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 6. FM 2.
shortwave 0
Radios: 369.000 (1992 est)
Television broadcast stations: 5 (relays 2)
Televisions: 327.01! (1992 est)
Defense
Branches: Army. Nasy. Air and Aw
Detense Forces. Police Force
Manpower availability:
males age 15-49. 371.927
males fil for military service: 488.231
males reach military age (19) annually
16.698 (1996 ests
Defense expenditures: 7 billion denars
NA‘ of GDP (1993 est): note
of defense expenditures into US dollars
conversion
using the current exchange rate could
produce misleading results
291
\\Nladagascar
iw
qs oyraphy
| LL ution
tu ovrapnl
Nilap refer
\\rea
band boundaries
f ousthne: 4 sh
Niaritime claims
International disputes
{,
“H) nih
de Nova Island. and Tromelin Island (all
adnunistered by France)
Climate: tropical along coast. temperate
miand. and m south
Terrain: narrow coxstal plain. hech plateau
dnd mountams in center
lowest pow Indian Ocean 0 m
juehes! pow Maromokotro 2X76 m
Natural resources: graphite. chromite. coal
bauyite. walt, quartz. tar sands, semuiprecious
ones. mica. trish
Land use:
rable ain 4’
permanent crops: Ve
meddows atad Pastures” WSs
rest and woedland: 26%
Irrigated land: 9.000 sy him (1989 est)','eea92079907db8cc525a882b5af16e6c3d1052e70d72e4c3c672ae022b6555b8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8d5bc76ea38f50c4ac2e2a0c3237cb18b75464f5e2380d7eee3e43ca6902bde',1996,'GD','Grenada','communications',415,'ret
Martine Que
Hlsborough
S Carnacou
&
s
RK
2
C ¢
Pm Wik
stand
env e,
& SAINT GEORGE''S
lelephones: ‘N
Lelephone system
Ht} Hi}
SH (
| | ry S i Vi
VHE and UHI ho tinks to Trinidad
Radio broadcast stations: AM EMO
Radios: st) uni OU ’
lelevision broadcast stations: LORS
lelevisions: WH) TO0R8 ect
192
Defense Guadeloupe
Branches: Royal Grenada Police Force. (overseas department of France)
Coast Guard eatin Spee a
Manpower availability:
Males ave 1-49 NA a.
miadics FU for muuary service N \\
Defense expenditures: SNA. NA‘ of GDP
Ma . 2a ” . ;
* BASSE-TERRE —_','59acb4a70531d9627c015a93fdb8173db14e46413ea54d66ee29acb91d9722c9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d72fb0ee7b9c2a3a7d49dffc3b887304f6d3e1bd12a924325c56d9baff32dc20',1996,'GP','Guadeloupe','communications',423,'Felephones: 64.916 (194
Telephone system: domestic facilities
; \\ \\
nite tellite earth station— |
Intelsat (Athantic Ocean): microwave radio
re ha Antigua and Barbuda Dominica,
nd Marty gu
194
Radio broadcast stations: AM 2. FM &
(private stations licensed to broadcast FM
30). shortwave 0
Radios: 100,000 (1993 est.)
Television breadcast stations: 9
Televisions: 150.000 (1993 est.)
Defense
Branches: French Forces. Gendarmerie
Defense note: defense ts the responsibility
of France
(Guam
(territory of the US)
e
sac ~” * 7 .
~<. AG4&NA
Ange
‘ ,“ P 4
~ Z >
a00s Keane ~*~
felephones: 26.317 (1989 est
Telephone system:
lomestic: NA
wad: satelite earth stations
Intelsat (Pacitie Ocean). submarine cables to
y and Japan
Radio broadcast stations: AM 3. FM 3
‘
4
Radios: \\ A
lelevision broadcast stations: °
lelevisions: 75.000 (1993 est
Defense
Defense note: defense is the responsibility
''
(
196','ea430d0a98363a2e628b51b3e4a788b8bad38e1afddb02eec319be5d76a71d38','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cf8db713f38aed4b94f85473ffaf435aefa2497e9154edab80435876f0384a1',1996,'GT','Guatemala','communications',427,'N
=
nm
-
oO
; ©
|
—
|
yi
€
j Looar
/ .
''
a uae ENG
a Zacapa,
j Cuetraterang
) Mazaiens 3 QrvATemaia a HONDURAS
nam pence
.
Sar >
J0s@,, an
let (
vera EL SALVADOR
Pelephones: 210.000 (1993 es!
lelephone system: tairly modern network
the cuv of Guatemala
NA
connected to Central Amencan
Microwave System: satellite earth Mation - |
latetsat «Atlantic Ocean)
Radio broadcast stations: AM 91. FM 0
miwave iS
Radios: Jin cn POO 8 est.)
Ielevision broadcast stations: 25
lelevisions: 475.000 61993 est)
Defense
Branches: Army. Navy. Au Force
Manpower availability:
males ave 18-"G J HSX19§
Perea serie’ 1.737.850
mhaiics til form
males reach mittary ave (18) annually
| 6.847 (1996 est}
Defense expenditures: exchange rate
conversion—S130 million 1 of GDP
hyud,','ade01d7bf5631543017902e821a465180d1ca799a483ecf6007dd5c390e1408c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53a25f0b0a3d274a49064c200d38400e65c469fd61f614dcabad9567d0f6471a',1996,'GG','Guernsey','communications',433,'(British crown dependency )
Burin
St. Apne”
Aloemey
Guemsey
e St Sampson
ad Herm
sr PETER ,
Jerr C.
ark
PORT Qethen oe
aaa
lelephones: 41.850 (1983 est)
Telephone system:
domestic, NA
micrnational | submarme cable
Radio broadcast stations: AME |. FM |
shortwave 0
Radios: \\A
Television broadcast stations: |
Televisions: \\\\
Defense
Defense note: defen
of the UK
the responsibility
199
* *
(,ulnea
i »
i
''
'' “ nN" “”
}
'' 5 _
’
; —— . 4
” > . 7
»
. .-
4 * +
| “area Ta
TNAKRY
+
}
Yacevta «
- 7 *- ,
i
i on >
o
’ J
]
''
; .
Telephones: |8.000 (1994 est)
Telephone system: poor to fair system of
upen-wire lines. small radiotelephone
communication stations, and new microwaye
radw relay system
domestic: mucrowave tadi relay and
radiotelephone communication
international’ satellite earth statron— |
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3. FM |
shortwave 0
Radios: 257.000 (1992 est)
Television broadcast stations: |
Televisions: 65,000 (1993 est)
Defense
Branches: Army. Navy (acts primarily as a
coast guard), Air Force. Republican Guard.
Presidential Guard, paramilitary National
Gendarmene, National Police Force (Surcte
National)
Manpower availability:
males ave 15-49: | 684.264
males fit for military service: 849.404 (1996
eM.)
Defense expenditures: exchenge rate
conversion—-$5S0 million, 1.6% of GDP
(1994)
201
(;uinea-Bissau
*mSSAu
Telephones: 3.000 (1988 est.)
Telephone system: poor system
domestic: combination of microwave radio
relay. open-wire lines, and radiotelephone
international: NA
Radio broadcast stations: AM 2. FM 3.
shortwave 0
Radios: 40.000 (1992 est)
Television broadcast stations: |
Televisions: NA
Defense
Branches: People’s Revolutionary Armed
Force (FARP: includes Army. Navy. and Aur
Force). paramilitary force
Manpower availability:
males age 15-49: 259.738
males fit for military service: 148.291 (1996
est.)
Defense expenditures: exchange rate
conversion—SY million, 4.5% ot GDP
(1994)
203
Wa','da8be2bf4d1c9015465404ee1b30ad7a9fb4a4287960d9aed0593793bb8ec849','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a30baeef367aad15730767b6a9f161ecfd914696ca86062db2b3653f7513f2a1',1996,'GY','Guyana','communications',440,'fneography
Oe biion \\ et Sout! \\n eTICa
North Atlantic Ocean. between
tas ographic coordinates: 5 00 N59 00 -\\
Map references: South America
Area:
tlh smatier than
land boundartes:
‘ Bb 119 kim. Suriname
( oustline: 4>
\\aritime claims:
m or to the outer
niinen Maran
tisdtane cone. MMO nm
International disputes: al! of the area west
he Essequibo River clammed by
7vucia. Surtname claims area between
New (Upper Courantyne) and Courantvne
hk Tt R wT he idwaters of the
Climate: tropical. hot. humid. moderated by
heast trade winds. two rainy seasons
Vias to mid-August. mid-November to mid
berrain: mostly rolling highlands: low
stal plains savanna in south
owest point: Atlantic Ocean 0 m
highest point: Mount Roraima 2.835 m
‘vatural resources: bauxite, gold, diamonds.
.urdwood timber, shrimp, fish
Land use:
rable land: 3%
ermanenl ¢ rops ()%
204
f
meadows and pastures: 6%
forest and woodland: 83%
other: &%
Irrigated land: | 300 sg km (1989 est)
Telephones: 33,000 (1987 est.)
Telephone system: fair system for long
distance calling
domestic: microwave radio relay network for
trunk lines
international: tropospheric scatter to
Trinidad: satellite earth station—! Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 4. FM 3
shortwave |
Radios: 398.000 (1992 est.)
Television broadcast stations: 0 (1987 est )
Televisions: 32.000 (1992 est.)
Defense
Branches: Guyana Detense Force (GDF
includes Ground Forces, Coast Guard. and
Air Corps). Guyana People’s Militia (GPM).
Guyana National Service (GNS)
Manpower availability:
males age 15-49: 197,548
males fit for military service: 149.646 (1996
est.)
Defense expenditures: exchange raic
conversion—$7 million, 1.7% of GDP
(1994)
ay
Telephones: |.44 million (1987 est.)
Telephone system: modem and expanding
domestic: domestic satellite system with 3
earth stations
muternational: 3 submarine coaxial cables:
satellite earth station—1 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 181, FM 0.
shortwave 26
Radios: 9 04 million (1992 est.)
Television broadcast stations: 59
Pelevisions: 3.3 million (1992 est.)
Defense
Branches: National Armed Forces (Fuerzas
Armadas Nacionales or FAN} includes
Ground Forces or Army (Fuerzas Terrestres
or Eyercito), Naval Forces (Fuerzas Navales
or Armada). Au Force (Fuerzas Aereas or
Aviacion), Armed Forces of Cooperation o*
National Guard (Fuerzas Armadas de
Cooperacion or Guardia Nacional)
Manpower availability:
males awe 15-49- S856 491
males fit for miliary service. 4.238.519
male. reach military ae (18) annually
46 184 (1996 est)
Devense expenditures: exchange rate
on-ersvon- —S8902 million, 1.4% of GDP
i set,
Vietnam
“ae CHINA
| renga oH
HANOI g #
'' rong’
¢ f ml
4 ¥
f f
LAOS J Guif of ‘Hainan
Winn Tonk tena
ee
THAILAND .
Wee
Qu: Nnon®
CAMBODIA a
° = : Nna Trange
y Cam Rann®
- to Cr Miner City
. " > a ~ .
Dao Pru x >
Con Dao
im” a ae
1a) 2','c95e81f3cdf7f71dcacbb96e124b0aafa35905bbe086b1756ef5ec74cb652199','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1507a4e58388dd56523846727eb207f33482bf38e64366c5a824f9fb1873594d',1996,'HT','Haiti','communications',452,'Telephones: 50,000 (199u est.)
Telephone system: domestic facilities barely
adequate. international facilities slightly
better
domestic: NA
international: satellite earth station— |!
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 33. FM 0).
shortwave 2
Radios: 320.000 (1992 est.)
Television broadcast stations: 4 (!987 est)
207
Haiti (continued)
Pelesisions: 32.000 (1992 est.)
Defense
Branches: Hanian National Police
\\lanpower availability:
149- | 379.116
746.617
itary age (18) annually
Defense expenditures: SNA, NA‘ of GDP
208
Heard Island and McDonald
Islands
(territory of Australia)
MicDonaid Shag
isiands isiand
Flat ‘sang
McDonaid ''siang
Heard Isiand','c7362013cf0c30c38f862a91ad85f3585451c99a8110d23f7620bc6336d16a36','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecebbdea8141af4b71a0c46811160769c26fdee77f6538adfd122afe5022a020',1996,'HK','Hong Kong','communications',458,'(dependent territory of the UK)
_—
sneung <
Tern:
y Terntones ;
. #0
ver Vu tA
. sven War
iw ogm
Telephones: 4.13 million (1995 est)
lelephone system: modern facilities provide
excellent domestic and international services
domestic: muctowave radio relay links and
extensive fiber-optic network
muternational, satelite earth sations— 3
Intelsat (1 Pacitic Ocean and 2 Indian
Ocean). coaxial cable to Guangzhou, China:
access to 5 international submarine cables
providing connections to ASEAN member
nations. Japan. Tarwan, Australia, Middle
East. and Western Europe
Radio broadcast stations: AM 6. FM 6.
shortwave 0
Radios: 3 million (1992 est.)
Television broadcast stations: 4 (British
Broadcasting Corporation repeater 1. British
Forces Broadcasting Service repeater |)
Televisions: 1.75 million (1992 est.)
Defense
Branches: Headquarters of British Forces
Army. Royal Navy, Royal Air Force, Royal
Hong Kong Auxthary Ai Force. Royal
Hong Kong Police Force
Manpower availability:
males awe 15-49: 1 B95 S35
males fit for military service: 1.442.072
males reach military age (1/8) annually
46.248 (1996 est.)
Defense e -penditures: exchange rate
conversion—$2)7 million, 0.2% of GDP
(FY92/93). this represents 65% of the total
cost of defending the colony. the remainder
being paid by the UK
Defense note: defense is the responsibility
of the UK until 1 July 1°97. when China
Howland Island
(territory of the US)
A
\\
\\
\\ F amar Loght
’ . tay feacn”
‘
"
4
}
{
Telephones: 170.021 (1994 est.)
Telephone system: fairly modern
communication facilities maimtaimed tor
domestic and international services
domestic: NA
international: HE radiotelephone
communication facility: access to
international communications carriers
provided via Hong Kong and China: satellite
earth station—1! Intelsat (Indian Ocean)
Radio broadcast stations: AM 4. FM 3.
shortwave 0
Radios: 135.000 (1992 est.)
Television broadcast stations: ()
note: TV programs received from Hong
Kong
Televisions: 34,000 (1992 est.)
Defense
Branches: NA
Manpower availability:
males age 15-49: 142.704
males fit for military service: 79.225 (1996
est.)
Defense note: defense is the responsibility
of Portugal
Macedonia, The Former
Yugoslav Republic of
@ SKOPUE','2eac40376fcc7347c3d522bafb33433b9480661db008b76337441b40cd278021','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1b1c5856bb892ead226f16d80c3f3287ca42b07cf611c592e0914ca9cbbc4ab',1996,'IN','India','communications',468,'- ° onopa
Anmacatdac
* Nagpur q
>
enDay Vv snaknapatnam
“y0aadad >
Vidlilen Andaman
— ?
«Poracnerry Pot
Telephones: 9 8 mullion (1995)
Telephone system: probably the least
adequate telephone system of any of the
industnializing countnes: three of every tour
Villages have no telephone service. only 5%
of India’s villages have long-distance
service. poor telephone service significant!y
impedes commercial and industrial growth
and penalizes India in global markets. slow
improvement ts taking place with the recent
admission of private and private-public
investors. but demand tor communication
services ts also growing rapidly
domestic: local service ts provided mostly by
open wire and obsolete electromechantical
and manual switchboard systems: within the
last 10 years a substantial amount of digital
switch gear has been introduced for local
service: long-distance traffic is carned
mostly by open wire. coaxial cable. and low-
capacity microwave radio relay: since 1985,
however. significant trunk capacity has been
added in the form of fiber-optic cable and a
domestic satellite system with over 100 earth
Stations
international: sateilite earth stations—s
Intelsat (Indian Ocean) and | Inmarsat
(Indian Ocean Region): submarine cables to
Malaysia and CAE
Radio broadcast stations: AM 96. FM 4.
shortwave 0
Radios: 70 million (1992 est.)
Television broadcast stations: 274
(government controlled)
Televisioas: 33 million (1992 est)
Defense
Branches: Army. Navy. Air Force. various
securmy or paramilitary forces (includes
Border Security Force. Assam Rifles. and
Coast Guard)
\\ianpower availability:
mates ave 15-49- 260.624.0007
males tu for militar. service. 183.1764
males reach military ave
Y 770.331 (1996 est)
Defense expenditures: exchange rat
SRO hijlnon, 2 7% of GDP
CONVeTSION
i} yous Uy)
Indian Ocean
Telephone system:
mernational: submarine cables trom india to
UAE and Malaysia and trom Sn Lanka to
Dyibouti and Indonesia','c933602f422f6821f7b8ec37ad7f952a8aaac2b33403da9bd9a8227d2caf5f94','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36e1814fe792dc392fd858558d09c49e72a522d5fd82e6bfc6095007ed5d0d92',1996,'ID','Indonesia','communications',481,'lelephones: |.276.600 (1993 est)
Felephone system: domestic service fai
international service good
lomestic: wtersiand microwave system and
HF radw police net. domestic satellite
communications system
international: satellite earth stations—2
Intelsat (1 Indian Ocean and | Pacific
Ocean)
Radio broadcast stations: AM 618, FM 38.
shortwave 0
Radios: 28.1 million (1992 est.)
Television broadcast stations: 9
Televisions: 11.5 million (1992 est.)
Defense
Branches: Army. Navy. Air Force. National
Police
Manpower availability:
33.702 .395
males reach military age (14) annually
2.280.360 (1996 est.)
males fit for military service
Defense expenditures: exchange rate
$2.7 billion. 1.4% of GNP
conversion
(FY 9S/96)
Iran
NA my eo
2s
, PAMENISTAN ial
Q ~
-
ha ™,
\\ . Masao,
‘ @ EHAAN =
f or j
. 4
\\ ba«"tarar |
% a S
‘ “ etarar 4 a. ‘
\\ _ - . +4
> ac
j * valZ ° ~—
. Gar arom
; e? aa’ e ey ferrar /
{f~ Ps Srivaz . <<
—_— ad* =, .
7anecen* \\
‘poner @ Biaretr \\
. »
Saga’ e Anas i.
>
A‘ ar ‘ se
7A 4 eS k e 4
, ; Sa° da
a | . sees
Telephones: 3.02 snillion (199) esi)
Telephone system:
domestic: macrowave tadvw relay extends
throughout country: system centered im
Tehran
miemational: satelite earth statrons— 4
Intelsat (2 Atlantic Ocean and | Indian
Ocean) and | Inmarsat (Indian Ocean
Region), HF radio and microwave radio
relay to Turkey. Pakistan, Syna. Kuw art
Tajikistan, and Uzbekistan: submarine fiber
optic cable to UAE
Radio broadcast stations: AM 77. FM 3
shortwave 0
Radios: ''4.3 million (1992 ex.)
Television broadcast stations: 2%
Televisions: 3.9 million (1992 est.)
Defense
Branches: Islamic Republic of Iran regular
forces (includes Ground Forces. Navy. Ai
and Air Defense Forces). Revolutionary
Guards (includes Ground. Air. Navy. Qods.
and Basij-mobilization-forces). Law
Enforcement Forces
Manpower availability:
males age 15-49: 1§.157.796
males fit for military service: 9OIO648
males reach military age (21) annually
63) ,G02 (1996 est.)
Defense expenditures: according to official
Iranian data. Iran in 1994 budgeted 4.377
billion nals and in 1993 spent 2.182 billion
rials. including $850 million in hard
currency: note—conversion of defense
expenditures into US dollars using current
exchange rates could produce misleading
results
Irag
* + f
-
ny Mints
4 . on .
y . .
YReA ’ KomA . 4
. As Sutgyc an yar
x
. Sevres «6 RAN
Yd 4
4
ie ata @ BAGHDAD
d i
dates” 2 «it »
fm
Av Na °
-
Ac™N °
o “ se
S Al o
ARAB - +
Telephones: 632.000 (1987 est )
Telephone system: reconstitution of
damaged telecommunication facilities began
after the Gulf war. most damaged facilities
have been reduilt
domestic’ the yetwork consists of coaxial
cables and microwave radio relay links
micrnational: satellite earth stations
Intelsat (1 Atlantic Ocean and 1 Indian
Ocean). | Iniersputnik (Atlantic Ocean
Region) and | Arabsat: coaxial cable and
microwave radio relay to Jordan. Kuwait.
Syria. and Turkey: Kuwait line is probably
nonoperational
Radio broadcast stations: AM 16. FM |.
shortwave 0
Radivs: 4.02 million (1991 est)
Television broadcast stations: | 4
Televisions: | million (1/992 est)
Defense
Branches: Army. Republican Guard and
Special Republican Guard. Navy. Air |
Air Detense Force. Border Guard Forces
Internal Security Forces
Manpower availability:
males age 15-49: 4.832 00]
males fit for military service: 2.7113)
males reach military age (18) annual)
937.843 (1996 est.)
Defense expenditures: SNA. NAS of GDP
231
Sra)
Felephones: 2.550.957 (1992 est)
Telephone system: international service
ood
GOMEST gan ud intercity service Pron ided on
Peninsular Malaysia mainly by microwave
radio relay: adequate intercity microwave
radio relay network between Sabah and
Sarawak via Bruner. domestic satellite
system with 2 earth stations
miernational, submarine cables to India.
Hong Kong and Singapore: satellite earth
stations—2 Intelsat (1 Indian Ocean and |
Pacific Ocean)
Radio broadcast stations: AM 28. FM 3.
shortwave 0
Radios: 8.08 million (1992 est.)
Television broadcast stations: 33
Televisions: 2 million (1993 est.)
oP ern
Pua Bater','33051c15161dfa7a272608ea87b1e04179cf67d9bc0ef5b44b3ac3c11447494b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('364ffd3206953dcd733850ecfa8094614ccfff9497e76772003f171dbb038279',1996,'JE','Jersey','communications',489,'Telephones: 2.425 million (1990 est)
Telephone system: most highly developed
system in the Middle East although not the
largest
domestic: good system of coaxial cable and
microwave radio relay
international: 3 submarine cables: satellite
earth stations—3 Intelsat (2 Atlantic Ocean
and | Indian Ocean)
Radio broadcast stations: AM 9. FM 45.
shortwave 0
Radios: 2.25 million (1993 est.)
Television broadcast stations: 20
Televisions: 1.5 million (1993 est.)
Defense
Branches: Israel Defense Forces (includes
ground, naval, and air components). Pioneer
Fighting Youth (Nahal). Frontier Guard.
Chen (women): note—historically there have
been no separate Israel: military services
Manpower availability:
males age 15-49- 1 390.603
females ave 15-49. 1 363.986
1.139.137
1.112.947
males reach military age (18) annually
$0,508
males fit for military service
females fit for military service
females reach military age (18) annualls
48.176 (1996 est.)
Defense expenditures: exchange rat
conversion—S89.2 billron. about 9S of
GDP (1996)
Telephones: 61.447 (1983 est)
Felephone system:
domestic. NA
international: 3 submarine cables
Radio broadcast stations: AM |. FM 0
shortwave 0
Radios: NA
Television broadcast stations: |
Televisions: NA
Defense
Defense note: defense ts the responsibility
of the { K
Johnston Atoll
‘territory of the US)','8f3f2ca110d5d18155e282f9c4bc76a1a179fa90a575bd6e0fd3fae9aa2ddbb6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa214b3ef477e359daa8d722d9abdbfb50b50cfe351e22c05c669da435003ee1',1996,'JM','Jamaica','communications',491,'» ES
a
Telephones: 2) 2.257 (1991 ex
Telephone system: fully automatic domest
telephone network
domestic’ NA
micrational satelite earth statrons
Intelsat (Atlantic Ocean). 3 coaxial
submarine cabies
Radic broadcast stations: AME 10) EM 17
shortwave 0
Radios: | 04 million (1992 ex
Television broadcast stations: »
Televisions: 330.000 (199) ex ,
Defense
Branches: Jamaica Detense Force Gincludes
Ground Forces. Coast Guard and Aw Wing
Jamarca Constabulary Force
Manpower availability:
males ave 15-49) GSO0.965
males fit for military service, AS16116
males reach milttary age (18) annually
2S. 81001996 est)
Defense expenditures: ex hanve rate
conversion— S340 nullon, NAG of GDP
(FY9S/96)
Jan Mayen
iterriters of Norway)
o
(seography
Location: Northern bur
the Greenland Seca and the N
mutheas of beland
Ceographic coordinates: 7) 00 \\
Map references: Arctic Re:
Area:
tisaet 73 say kon
haiti aired 173 SY ki
comparalve arca slig
the size of ¥ ashington. Dt
Land boundaries: ( ky
Coastline: | 24) km
Maritime claims:
ontienous cone. WO nm
ontinental shelf: 200-m depth rt
depth of ex dlottation
crclas RELL cle YO) nn
armitornal sca. 4anm
International disputes: none
Climate: arctic maritime with trequ
storms and persistent tog
Terrain: volcanic mtland. part
Viacrers
Norwegian Sea 0
Invhest pomt: Haakon VIL Topper
se be ee |
{ beer nbery ) «
ude ju rir
1v)
Natural resources: non
Land use:
arable land: O
permanent crops {}'',
meadows and Puslures {)}
hoes ana nvandiond 0
other TAG
Irrigated land: 0) su km
lelephone system:
omestic: NA
ernatiwmal. NA
Radio broadcast stations: AVI NA. FM
NA. shortwave NA
¢. radw and meteorological sation
Radios: NA
lelevision broadcast stations: NA
lelevisions: “A
Defense
Defense aote: defense is the responsibility
Norw a','bf72505382a434c67356a1a322ba77f4e01aa0b7abe4725f7c603054f693920d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1abe174bd4445cb3d04481a4d0ca1e979ab13bee8b689d7fc7cec7ed0b70c0bd',1996,'JO','Jordan','communications',505,'lelephones: §1.500 (1987 est)
Felephone system: adequate telephone
mne sic’ Microwave radio relay. cable. and
datciephone Hinks
nonal. satelite earth stathons
Intelsat ¢) Atlantic Ocean and | Indian
(doean) al df Arabs il coastal cable and
cromave radio relay to trag. Saudi Arabia
} SVrha MWTOW ANE radw relay 1 | ebanon - |
achive. Participant in Medarabt
Radio broadcast stations: AVI 5. EM 7
shortwave 0
Radios: |.) million (1992
lelevision broadcast stations: S and | T\\
lelevisions: SSOLOO0 C199) ¢','17420abb6491f1707c4097a012de78586a6cabd18e849fa683a62f2b1d0e63a7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b634ec13cfa6c27c8e3d331817389d0e06b5c60007d08d19a0dbfb2d3a1c0dc9',1996,'MG','Madagascar','communications',506,'5,5,
Telephones: 2.2 millon
Telephone system: service is poor
domestic. landline and muactrowave radw
relay
micrnational, mternatonal trattic wath other
former Soviet republics and China carned by
landline and macrowave radw relay and with
wher countnes by satelinte and through &
merational telecommunications circuits at
the Moscow international gateway switch
witellite earth stateons | Intelsat and a new
satellite earth staton established at Almaty
of unknown type
Radio broadcast stations: AM NA. FM
NA, shortwave NA
Radios: 4.088 million (with multiple
speakers for program diffusion 6.082
millon)
Television broadcast stations: \\ A. Orbits
(TV receive only) earth station
Televisions: 4.75 muillnon
Defense
Branches: Army. Air Force. Ai Detens
Force, National Guard. Security Forces
(internal and border troops), Kazakstan may
also be esaDirsiing a mantime io
or coast guard—on the Caspian Sea
Manpower availaiility:
males ave 15-49- 4.39356
males fit for militar CTV
males reach military age (18) annua
154.750 (1996 est)
Defex.« expenditures: 18 9 billy
NA‘ of GDP (1995). pote Con''s
defense expenditures into US do
the current exchange rate Could prod
nusleading results
(,cography
Location: |
i) *
|
Ceographic cverdimates
Nap references
Areca
and boundarn
( custhone
Nilaritime clamms
Inter sateonal disputes
Natural resources
land us
tv
mMmadeus aid pruasinre ‘
_
. ; j
i ddfidd VCMT
irrigated land: 520) sy km 1/989)
lelephones: ‘‘S “Ss ] IYRY ext |
lelephone system: in top croup of Atncan
liawnne * min Hy tucrowave radw relay
Intelsat ¢) Atlante: Qoean and | Indian
(docu
Radio broadcast stations: AVE 16. 1M 4
shortwave |
Radios: \\ \\
lelesision broadcast stations: §
lelevisions: (600000 wy?
Defense
Branches: Anny. Navy. Aw!
pyal wmittian, General Service Lan of t
Police
Manpower availability:
’
NMC. ave ,44Y OOS) SM
i? iite d)
Kingman Reef
(territory of the LS)
Kenva
Defense expenditures: vc
. i ¢,i¥”
Ceeography
Location: Oceama. reet in the North Pacifx
Ocean. about one-hall of the way trom
Hawan to Amern
C,cographic courdinates: 6 24. N. |62 24 W
im Samoa
Map references: Oceania
\\rea:
t the Mall om Washington. DX
Land boundaries: © kn
{ eastline: § km
Naritime claims:
/ c 4 ”? he 1H) on
cn wa i2 nn
International disputes: non
( timate: tr Pea hut nuaterated |
owrevaling winds
Terrain: low and pearly
‘ rmvunt. Pan Ocea
Natural resources: . on
Land use:
rainy ; 1}
y iphed ; ''
4 f ’ Sieve {?
ry ; iy 1)
thet ith)
Irrigated land: 0 so kn
I nvironment:
wren ws. NA
adiiral nacarads \\A iw awa
me. maximum elevation of ab
makes Kingman Reel a mantime |
mitermational aercements. NA
Ceographic note: barren core
y | ; | ‘
veep mnict PML? Lit cd tk ih mut
lelephones HM)
ielephone system
‘
Pacitic O
Radio broadcast stations:
Radios
lelevision broadcast stations: 0
lelevisions: | data
Defense
Branches: no regular military forces, Police
Force (carries out law enforcement functions
and paramilitary duties: small police posts
are on all islands)
Manpower availability:
15-49: NA
fit for mulitar
Mudics aXe
fidditcs
SCTVice N A
Defense expenditures: SNA. NAG of GDP
Korea, North permane nl cre Ips 1G
meadows and pastures < religious treedom
forest and woodland: 74° Languages: Ko
other: 7% Literacy: age
Irrigated land: 14.000 sg km (1989)
lelephones: 30.000 (1990 est
Telephone system: system is believed to be
available principally for government business
domestic: NA
iniernational: satellite earth stations—|
Inteisat (Indian Ocean) and | Intersputnik
(Indian Ocean Region); other international
connections through Moscow and Beijing
Radio broadcast stations: AM 18, FM 0.
shortwave 0)
Radios: 3.5 million
Television broadcast stations: | |
Televisions: 400,000 (1992 est.)
Defense
Branches: Korean People’s Army (includes
Army, Navy, Air Force), Civil Security
Forces
Manpower availability:
males ave 15-49: 6.844.035
males fit for military service: 4.143.713
males reach military age (18) annually
194.922 (1996 est.)
Defense expenditures: exchange rate
$5 billion to $7 billion, 25%
conversion
3307 ol GDP ( 1995 est.)
Korea, South
lelephones: 16.6 milliwor
TRO AS
Telephone system: excellent domestic and
international services
domestic: NA
imternational: tiber-optic submarine cable to
China: satellite earth statrons—3 Intelsat (2
and |
Pacific Ocean and | Indian Ocean
Inmarsat (Pacific Ocean Region)
Radio broadcast stations: AM 79. FM 46
shortwave 0
Radios: 42 million (1993 est
Television broadcast stations: 256 (57 0!
uch are | KW or greater) (1987
lelevisions: 93 millbon (1992 est
Defense
Branches: Army. Navy. Air Force. Marine
Corps. National Mantime Police (
Csuard)
Manpower availability:
males age 15-49. 13.602 115
maics reach nv an\\ ave iN) qauitad
SYK 39> (1996 est
Defense expenditures: exchas
On S17 41 (iN
r\\py','2e9f37b0cede7e5d9ae1f8c3fba278bc08af9fc8e1faaa2e5988736da3d28c1a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffbc84bfd999b8fc66de33c71a122478ce192cbcb5b46f3150117227283206f2',1996,'KW','Kuwait','communications',510,'Felephones: 548.000 (1991 est)
lelephone system: the civil neiwork
suffered some damage as a result of the Gult
wal. but most of the telephone CAC Nes
were left intact and. by the end of 1994
domestic and international
telecommunications had been restored to
normal operation. the quality of service rs
ervcellent
de LLL TEL
new telephone exchanges provide
a large capacity for new subsermbers. trunk
trattic is carned by microwave radi relay
coaxial cable. open wire and tiber-opti
cable: a cellular telephone svstem operates
throughout Kuwait anc the country is well
supplied with pay telephones
coavial cable and microwave
Arabia
+ Intelsat (1 Atlantic Ocean
| Inmarsat (Atlantic Ox
tory ational
radi relay to Saudi satelite earth
Stations
Indian Ocean)
and | Arabsat
Radio broadcast stations: AVI} EM
shortwave 0
Radios: 720.000 (199) est)
lelevision broadcast stations: § (/ 986 ext
lelevisions: 800.000 (1993 ex)
Defense
Branches: Army. Navy. Au Force. National
Guard, Ministry of Interror Forces. Coast
Cjuard
Manpower availability:
male Save 1s 449 658 2 0
males fit tov mulitary sen ct S91 SRO
'' 18) annual
Defense expenditures: exchange rate
12.8 of GDP
Ky rey 7stan mecrmational aereements: NA former: Karghiz Soviet Socialist Republic
— Geographic note: landlocked Data code: KG
Type of government: republic
Capital: Bishkek
Administrative divisions: 6 oblasttar
. .
itiepranes
i)
}
Radio broadcast stations:
Radios:','ef9b37b5c7a5a3641d42a5d10e259393fbbd2bd0491624ce7fc5a8bc072cee25','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecc6d41f213ab7f5aa4c224c6fa0d5fea027b3fe1c1857a394987883a94adc40',1996,'LV','Latvia','communications',511,'Il publ Geography
Location: basiern Europe. bordering the
le service fi Baltic Sea. between Estonia and Lithuania
Geographic coordinates: 37 00 N. 25 00 E
ons Map references: Europe
\\rea:
rota! areas 64.100 sq km
SAE LO EM 6 land area. 64.100 sg km
m parative area” slightly larger than West
Virginia
Land boundaries:
felesision broadcast stations
Pelevisions: t)
Defense
Branche Nc
Ann kor Nil | P
Manpower availability:
Dotenmse expenditures
Department
hotal: LOTS km
border countries. Belarus 141 km. Estonia
267 km. Lithuama 453 km. Reesia 217 km
Coastline: 53) km
Maritime claims:
ervclasiwe economic zone. 200 nm
LPA erruorial sea: V2 nm
miliva elements). continental shelf) 200-m depth or to the
depth of exploration
International disputes: the Abrene/Pytalove
secuion of border ceded by the Latvian
SkH h64 Soviet Socialist Republic to Russia in 1944:
the maritime borders with Lithuania and
lelephones:
Pelephone system
i
’ ; >
s SACS mill YY
HN} . uu ad N \\
rates: [al LSS {) S44
if , 1 ps {) S60) ¢ LOA)
d 5 ‘ i ~ tutte J i
{ ™ rou 1994
> AAS i ic
S60) 4h yQ)
’ . rr
I Riva Ve S|
Cit eae Nang
~ 43s iy\\\\ |
—
ACT +4
A Heat CaPeo
ti (ig ) fy
, ‘ .
$70 2.45.5 n
’
Sly |
ldm:2
‘ 5
J + (id, 3
4 ‘ , ’
‘
i ti¢ {}
;
than uw
S DUDTICS
mn '' | |
WNET-4 il elu
\\ ‘ t Latvia s
iwork
trattic carried by
Mi sSCOW
through the
iephone exchange in
Finrmish cellular
imTie
\\
net
electronic mail
Radio broadcast stations: AM NA. EM
‘
iv<¢ NA Tha
rie?
14
there are 25 radio
ions of unknown [ype
lelevision broadcast stations: 30 Lebanon
$
a
felevisions: | | million (1993 est.)
Defense
Branches: Ground Forces, Navy. Air and
Air Defense Forces. Security Forces. Border
Guard. Home Guard (Zemessardze)
Manpower availability:
males age 15-49. 583.134
males fit tor military service: 457.067
males reach military age (18) annually
16 180061996 est}
Defense expenditures: |76 million rubles.
3 to 5% of GDP (1994): note—conversion
of detense expenditures into US dollars
using the prevailing exchange rate could
produce misleading results
Note: Lebanon has made progress toward
reburiding us political institutions and regaming is
navional sovereignty since the end of the
devastating 16-vear civil war which began in
L975. Under the Tait aceord-- the blueprint for
natronal rcconcthation —the Lebanese have
established a more equitable political system
parucularly by giving Muslims a greater say un the
political process. Since December 1990, the
ichanese have formed tour cabinets and
conducted the first legislative election in 20 vears
Most of the militias have been weakened oF
disbanded. The Lebanese Armed Forces (1h AF? has
sevved Vast quantities of Weapons used by thy
militias during the war and extended central
government authors over about one-halt of the
country. Hizballah. the radical Shiva party. retains
Most ot its Weapons. Foreign forces stl occupy
eas Of Lebanon. Israch maiiains troops in
southern Lebanon and continues to support a
proxy militia. The Army of South Lebanon «ASI
abone a narrow stretch ol ter
Lory CONLZUOUS To
ts border. The ASL Os enclase encompasses this
self-declared security. zone and about 20
Kilometers north to the strategie town of Jazzin
Svna maintains about 30.000 troops in Lebanon
These troops are based mainly in Beirut. North
Lebanon. and the Bekaa Valley. Svria’s
deplow ment was legitimized by the Arab League
early in Lebanon''s cnval war and in the Tait
accord. Cine the continued weakness of the LAF.
Beirut s nr jucsts and tanlure of the Lebanese
Government to mplement all of the constitutional
reforms ithe Tait accord, Damascus has so tat
refused to withdraw its troops trom Berrut
Telephones: 150.000 (1990 est.)
Telephone system: telecommunications
system severely damaged by civil war;
rebuilding still underway
domestic: primarily microwave radio relay
and cable
imternational: satellite earth stations—2
Intelsat (1 Indian Ocean and | Atlantic
Ocean) (erratic operations): coaxial cable to
Syria: microwave radio relay to Syria but
inoperable beyond Syria to Jordan: 3
submarine coaxial cables
Radio broadcast stations: AM 5. FM 3.
shortwave |
note. more than LOO AM and FM stations
are operated sporadically by various fac sons
Radios: 2.37 million (1992 est.)
Television broadcast stations: |3
Televisions: |.) million (1993 est.)
Defense
Branches: Lebanese Armed Forces (LAF:
includes Army, Navy. and Air Force)
Manpower availability:
males age 15-49; 889.517
est.)
Defense expenditures: exchange rate
conversion——$278 million. 5.5% of GDP
(1994)
Lesothe
*
ee Ae a
ew
a —~
Seve \\
. so arevety: Sf]
w
wre |
e* “>
~ ~~
~ cares, 7
/
VILNIUS
he oe { “we ~ianiee @ ,
ee ” i
‘1 SU
Li >
rane \\ BELARUS
\\
..','86a7d0d10dc49372551d5abfd1c9821a2b012ab9eff17b1465accbe66de71fb4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0431355ef72b5f1896bb721ebc988d3ee3678a4c5c28a671699f3592477fef29',1996,'ZA','South Africa','communications',520,'.
Lenbe
4
f . eyateyaneng
?
Pssene
aa Thabda-7 seka*
-Mateteng
Moknotiong,
Felephones: | 2.000 (1991 est.)
Telephone system: rudimentary system
domestic:
microwave radio relay system, and a minor
radiotelephone communication system
uuernational. satellite earth station—|
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3. FM 4.
shortwave 0
Radios: 66.000
Television broadcast stations: |
Televisions: | 1.000 (1992 est.)
Defense
Branches: Lesotho Detense Force (LDF.
includes Army and Air Wing), Lesotho
Mounted Police
Manpower availability:
males age 15-49. ASS.218
males fi jor muita vy service: 245.774 (1996
est.)
Defense expenditures: SNA. NA‘ of GDP
consists of a few landlines. a small
LEONE an
S } RV
“ An, / * temepa
“a \\
} aa 7 ‘
; Taraog ; COTE
“Roperspot — D''IVOIRE
gMONROWA
*+Harhe —
: - t
= chanan® <weoru ~
Note: Years of civil strife have destroyed much of
Libera s cconomme infrastructure, made civil
administration nearly mmpossible. and brought
coononmme activity virtually to a halt. The
deterioration of econonne conditions has been
greatly exacerbated by the flight of most business
people with their expertise and capital, Civil order
ended in 1990 when President Samuel Kanyon
DOK was killed by rebel forces. The ensuing civil
war persisted until August 1995 when the mayor
lactions signed the Abuya peace accord and. in
Sepiember 1995. formed a transitional coalition
government under Wilton SANKAWULO. The
war was resumed in Apnl 1996. when forces loyal
to faction leaders Charles TAYLOR and Alhay
KROMAH attacked nval factions in Monrovia.
lurther damaging the capital''s already dilapidated
infrastructure and causing panic among the
remaining foreign residents, thousands of whom
soucht refuge in US facilities. Prospects tor peace
hecame exiremely uncertain again
Telephones: less than 25,000 (1991 est.)
Telephone system: telephone and telegraph
service Via microwave radio relay network:
87
main center 1s Monrovia: most
telecommunications services inoperable due
lo Imsurgency movement
domestic: NA
miemational: satellite earth station—|
Intelsat (Atlantic Ocean)
Radio breadcast stations: AM 3. FM 4.
shortwave 0
Radios: 622.000 (1992 est.)
Television broadcast stations: 5 (1987 est.)
Televisions: $1,000 (1992 est.)
Defense
Branches: NA: the ultimate structure of the
Libenan military force will depend on who
is the victor in the ongoing civil war
Manpower availability:
males age 15-49; 479.274
males fit for military service: 256.200 (199%
est.)
Defense expenditures: exchange rate
conversion—$14 million, 2.9% of GDP
(1993)
zimeaawe |
= jf
BOTSWANA Messina\\ M07
j a.
j rs Souw''Gg
NAMIBIA | aS
‘
;\\ ~ A @ PRETORIA j
™~
/ JonannesDu''g” ; A ?
- WAZ =
~ j Nt or dys ar
“iF 7 # < mbe" ley “° é
™ mt ne Of Rognards
ve Aa \\r (ba
East Lonor
*Saidanna °
Cape* * Bor Chzabeth
"ow" Vosselbas
Telephones: 5.206.235 (1993 est.)
Telephone system: the system ts the best
developed. most modern, and has the highest
capacity in Africa
domestic: consists of carner-equipped open
wire lines, coaxial cables, microwave radio
relay links, fiber-optic cable. and
radiotelephone communication stations: key
centers are Bloemfontein, Cape Town
Durban, Johannesburg, Port Elizabeth, and
Pretoria
wuernational: | submarine cable, satellite
earth stations-—3 Intelsat (1 Indian Ocean
and 2 Atlantic Ocean)
Radio broadcast stations: AM 14. FM 286.
shortwave 0
Radios: 12.1 million (1992 est.)
Television broadcast stations: 67 (1987
est.)
Televisions: 3.45 million (1990 est.)
Defense
Branches: South African National Detense
Force (SANDF, includes Army. Navy. Air
Force, and Medical Services). South African
Police Service (SAPS)
Manpower availability:
males age 15-49: 10,686.976
males fit jor milttary service: 6.502.265
males reach military age (18) annually
424.854 (1996 est.)
Defense expenditures: exchange rate
conversion—$2.9 billion, 2.2% of GDP
(FY9S/96)
South Georgia and the South
Sandwich Islands
(dependent territory of the UK)
J) Le!
1
x0 wr
Pag tore: —
een’ ow
South Georgia
/ Drytvinen
Bud
(slang
Clerke ”
Socks
Traversay ;
siands
South
Sandwich Saunders |
islands Montagu |
Bnsto! |
hone re Ly Southem
errec Dy ARG STA Thute
Telephones: | 2.6 million (1990 est.)
Telephone system: generally adequate
modern facilities
domestic: NA
international: 22 coaxial submarine cables
satellie earth statwons—2 Intelsat (1 Atiantic
Ocean and | Indian Ocean), NA Eutelsat.
NA Inmarsat, and NA Marecs; tropospheric
scatter to adjacent countries
Radio broadcast stations: AM 190. FM 406
(repeaters 134), shertwave 0
Radios: 12 million (1992 est.)
Television broadcast stations: | (00
(repeaters 1,297)
Televisions: 15.7 million (1992 est.)
Defense
Branches: Army. Navy. Air Force, Marines.
Civil Guard, National Police, Coastal Civil
Guard
Manpower availability:
males awe 15-49: 10.360,.209
males fit for military service: 8 370197
males reach military age (20) annually
341.670 (1996 est.)
Defense expenditures: exchange rate
conversion—$6.3 bilhon, 1.4% of GDP
(1995)
Spratly Islands
megan Cay
S.xtrwesi Cay ~ >
Wen vr
Sl
oe” The tater Fast
» Om NN, emer ly -
Sana es a c\\
fh Ada istang> - gE tad Ree
isang
i -and
Sn Cowen: Mow Mae &
Fury Cres . : ‘ ee ’
ee
6 >
° Por “an
e* Aisor™ 9 ” ceed tax
Sonat Rew wae
7
/ . “~~
ane °
a
~ ee > .
.
Telephone system:
domestic: NA
micrnational: NA
Radio broadcast stations: AVI NA. FM
NA, shortwave NA
Radios: NA
Television broadcast stations: \\ A
Televisions: NA
Defense
Defense note: about SO small islands of
reets are occupied by China. Malaysia. the
Philippines, Taiwan, and Vietnam
445','7ded5c80ca6f4ca73f8e3573f4eb64a2c1db48a49a90198f653be764fb89eef4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22c9d30e7b6c68a509799326682f8d65e2a54becfa554438422d529c3400300b',1996,'TN','Tunisia','communications',532,'Telephones: 370.000
Telephone system: moder
iclecommunications system
domestic: microwave radw relay. coaxial
cable. tropospheric scatter, and a domestic
satellite system with 14 earth stations
international: satelite earth stations—2
Intelsat (1 Atlantic Ocean and | Indian
Ocean). planned Arabsat and Intersputnik
satellite earth stations, submarine cables to
France and Italy; microwave radto relay to
Tunisia and Egypt: tropospheric scatter to
Greece. participant in Medarabtel
Radio broadcast stations: AM 17. FM 3
shortwave 0
Radios: | million (1993 est)
Television broadcast stations: |2 (1987
es.)
Televisions: S00.000 (1993 est)
Defense
Branches: Armed Peoples of the Libyan
Arab Jamahinvah (includes Army. Navy. and
Air and Ai Defense Command). Potice
Manpower availability:
males awe 15-49- 1LATOA00
males fit for military service: GIY6.288
males reach military age (17) annually
56.434 (1996 est.)
Defense expenditures: exchange rate
conversion—$1_.4 billion. 6.1 of GDP
(1994 est)
Communications note: important
meteorological station
Defense
Defense note: defense is the responsibility
of France
Mediterranean Sea
la°
me i
~_ SA L''Ariana va:','c3994e23986a5e6067d03fb6acf31949a42141b01feab6f51cf16fee820bb29d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a0dd4bf41ff5c352b48812ca417d6d169f4f438523c3b82bdaa70c75e4f6c1f',1996,'LI','Liechtenstein','communications',533,'vam?
Telephones: 18.916 (1993 est.)
Telephone system: limited. but sufficient
automatic telephone system
domestic: NA
international: linked to Swiss networks by
cable and microwave radi relay
Radio broadcast stations: AM NA. FM
NA, shortwave NA
note’ linked to Swiss networks
Radios: 11.000 (1993 est)
Television broadcast stations: \\ A
note: linked to Swiss networks
Televisions: 10.620 (1993 est)
Defense
Defense note: defense is the responsibility
of Switzerland','8cf34c6d76e6b25a47e07e7980631cad5a7aecca84374f953845b6865322e58d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a776c6b1a57f58b7ca767a9e83f1443b4f9c6bf96f869e16715365ad4b57b7fa',1996,'LT','Lithuania','communications',541,'Telephones: 900.000
Telephone system: telecommunications
system ranks among the most modern of the
former Soviet republics
an NMT-450 analog cellular
telephone network Operates in Vilnius and
domestic.
other cities: landlines and microwave radio
relay connect switching centers
wiernational: ternational connections no
longer depend on the Moscow international
gateway switch, but are established by
satellite through Oslo trom Vilnius and
through Copenhagen trom Kaunas: satellite
earth stauions—! Eutelsat and | Intelsat
(Atlantic Ocean): cellular network linked
internationally through Copenhagen by
Eutelsat: international electronic mat! ts
available: landlines or microwave radio relay
to former Soviet republics
Radio broadcast stations: AM 13. FM 26.
shortwave |. longwave |
Radios: |.42 million (1993 est.)
Television broadcast stations: 3
Televisions: 1.77 million (1993 est.)
Defense
Branches: Ground Forces. Navy. Air and
Air Detense Force. Security Forces (internal
and border troops). National Guard (Skat)
Manpower availability:
males age 15-49° 903.437
males fit for military service: 712.875
males reach military age (18) annuall
26.162 (1996 est)
Defense expenditures: exchange rate
conversion— $31.7 million, 1 of GDP
(1998)','980353aa32a4e08fe1c87ca4a15a6623d4bcdd9c3e8f32d895bb56c79672ef86','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f66540291bb800b6af0c86f92bd54dba4b6b5c8653cd5ad10cba6e35b40fa206',1996,'LU','Luxembourg','communications',542,'a
.
3
ene
LUXEMBOURG,
~
Telephones: 214.821 (1993 est.)
Telephone system: highly developed.
completely automated and efficient system.
mainly buried cables
domestic: nationwide cellular telephone
system: buried cable
international: 3 channels leased on TAT-6
coaxtal submarine cable (Europe to North
America)
Radio broadcast stations: AM 2. FM 3.
shortwave 0)
Radios: 230,000 (1993 est.)
Television broadcast stations: 3 (1987 est.)
and | direct-broadcast satellite link
Televisions: 100.500 (1993 est.)
Defense
Branches: Army. National Gendarmerie
Manpower availability:
males age 15-49; 108.27)
males fit for military service: 89.427
males reach military age (19) annually
2.188 (1996 est.)
Defense expenditures: exchange rate
conversion—$142 million. 0.8% of GDP
(1995)
Macau
(overseas territory of Portugal)
Telephones: 17.000 (199! ¢
Telephone S¥stem: poor svsiem of cable and
upen-wire lines. miner mucrowasye radu
relay blinks. and radnteclephone
COMMUNICATIONS slalbons (improvement
being made)
domestic: tostly cable and open-wire lines
micrnational. saeliite earth sation, — |
Intelsat (Atlante Ocean) and 2 Arabsat
Radio broadcast stations: AMI 2 EMO
shoartuave 0
Radios: “HOO F199 h ex)
Television broadcast stations: | 7 ex |
Televisions: S000 199) ey
Defense
Branches: Army. Nov.) Aw bore. Notronal
Gendarmenc. National Guard. Natronal
Pohoe. Presidential Guard
Vianpower availability:
males ave 15-49° SWNTS4
males tit tor milttary wonuc 244.446 11996
est)
Defense expenditures: exchange (ah
comersion— 833 mull. 2 8 1 GDP
i }ywus;)
3
Viauritius
@ PORT LOUIS','f4081c05ae5fb870c5a2b6aa1279ed0b5e1485df6e8c5ec364169e218ccbd33f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60ae33b2739d923978e3b3efc3b9d7a382795a7a0a637afd6d539505be254d9d',1996,'MV','Maldives','communications',559,'(
Fa)
Addu 4fo% -
felephones: >> "y
lelephone svstem: nimal domestic and
\\N\\
ir}t l tana! ()
Radio broadcast stations: \\\\I ’ NI
Radios: 2s 28461992 ext
lelevision broadcast stations:
Pelevisions: 7 309 1/992 es
Defense
Branches: National Security Ser
Paranitary poileoe horny
Manpower availability:
ricile aie ,s Jy sy 17y
sa thi¢ ‘py
Defense expenditures; S\\ VON A ot GDP','634bdce1fad59ac5523e0994a0ffce40b39ebd4e300f3b3fa01a67b36fd579b6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b80863d37d47760737ffbbcb2cdf88d3ce9764073219cb593cf96ed6be8f5585',1996,'DZ','Algeria','communications',565,'aude’
AN 4
eo” ia 1
— a
ea
* Vv i or
NIC
- « 4
>
BAMAKO 4 Nw
i _N
‘ : ’
a? 4
5 -
Gseography
Location: Western Africa. southwest ot
\\lverta
Cseographic coordinates: 17 00 No 4 00 W
Map references: \\inica
\\rea:
total ated 1 24 millon sq km
dnd area 122 milion sq kim
unparatve area. slightly less than twice
the size of Texas
Land boundaries:
tal 7 243 km
Porder countries. Algeria 1.376 km. Burkina
base |O00 kin. Guinea SSS kim. Cote
Pdvore S32 hm. Mauritania 2.237 km. Niger
So} kin Senegal 419 km
Coastline: 0 km Candlocked)
Maritime claims: none () ndlocked)
International disputes: the disputed
niernational boundary between Burkina Faso
ind Mahi was submitted to the International
Court ot Justice ICI) in October 1983 and
IF issued ats final ruling in December
YS6. which both sides agreed lo accept.
Burkina Paso and Mali are proceeding with
houndary demarcation. including the tripomt
with Niger
Climate: subtropical to and. hot and dry
February to June. rams. humid. and mild
June to November. cool and dry November
to February
Terrain: mostly flat to rolling northern
plains covered by sand: savanna in south.
rugged hills in northeast
lowest pot Senegal River 23 m
highest point: Hombort Tondo 1.155 m
Natural resources: gold. phosphates. kaolin,
salt, limestone, uranium, bauxite. iron ore,
manganese. tin. and copper deposits are
Known but not exploited
Land use:
arable land: 2
permanent crops: 0%
meadows and pastures: 25%
forest and woodland: 7%
other: 66%
Irrigated land: 50 sy km (1989 est)
Felephones: | 1.000 (1982 est)
Telephone system: domestic system poor
bul umproving. provides only minimal
service
domestic. network consists of microwave
radio relay. open wire. and radiotelephone
communications stations: expansion of
microwave radio relay in progress
miternational. satellite earth stations—2
Intelsat (1 Atlantic Ocean and | Indian
Ocean)
Radio broadcast stations: AMI 2. FM 2.
shortwave 0
Radios: 430.000 (1992 est.)
Television broadcast stations: 2 (1987 est)
Televisions: |) .000 (1992 est)
Defense
Branches: Army. Air Force, Gendarmerie.
Republican Guard. National Guard. National
Police (Surete Nationale )
Manpower availability:
males ave 15-49; 1.925.205
males fit for military service: 1AOOS99
(1996 est.)
Defense expenditures: exchange rate
conversion—$66 million, 2.2 of GDP
()994)
Telephones: 14.000 (1991 est)
Telephone system: smal! sysiem of “sc
radiotelephone commumecat ms. and
microwave radw relay links concentrated mm
southwesterm area
domestic: wite. tadvotelephone
communications, and microwave radi relay
domestic satellite svstem with 3 earth
Sations and | planned
mcrmational satelite earth stations
Intelsat (1 Atlantic Ocean and | Indian
Ocean)
Radio broadcast stations: AMI 15. FMS
shortwave 0
Radios: SOO.000 (1992 ext)
Television broadcast stations: |»
Televisions: *8.000 (199) ext)
Defense
Branches: Army. Au Force. National
Gendarmerie. Republican Guard, National
Police
Manpower availability:
males awe 15-49 1920244
mile S fil feu muitary seriley | mts is
males reach mulitary aec (18) annually
9) 1342 (1996 est)
Defense expenditures: ox change fate
wt GDP
comversieon——S32 mulleon, 14%
(FY9YYS)','39bdb46916ca6fa40af5a82258430f7636006a5274af11a550f9f44d65af56e8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a045b2b74dd043917c1c53d423135848746e81123582025a59b0e376cc87559d',1996,'MT','Malta','communications',570,'Gozo
"Ravat
Comino
capa’ WALLETTA®
Marsaxionk
Bi zedduga,
Fdtia
felephones: 191.876 (1992 est
Telephone system: automatic system
satisfies normal requirements
domestic. submarine cable and microwave
radio relay between islands
witernational) | submarine cable. satellite
earth siatron—|I Intelsat (Atlantic Ocean!
Radio broadcast stations: AM &. FM 4.
shortwave 0
Radios: | 8Y.000 (1992 est)
Television broadcast stations: 2 (1987 esi.)
Televisions: 267.000 (1992 est.)
Defense
Branches: Armed Forces. Maltese Police
Force
Manpower availability:
males age 15-49. YY O18
males fit for miliary service: 78.656 (1996
est.)
Defense expenditures: exchange rate
conversion—S21.0 million. 1.06 of GDP
(FY9D/93)
Man, Isle of
(Beitish crown dependency)
Harsey °
DOUGLAS,
ieclephones: 4
(Hu wes
le lephone sistem
» A
‘
1
‘
R: dio broadcast stations: AM
Radics
Pelesiston broadcast stations: 4
\\
felesistons: \\ \\
‘
Ddelense
Delors
Thiel
mw OTTS
Mh
M4
ibali’s','0e06f01d210859717e112abddc9c15006b0c5e77b71e441f7a8d7bda30c157d4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4231f254a8aeff8291f73dfb2da1d0689b52190a073b29167496ffdf012c717',1996,'MH','Marshall Islands','communications',583,'letephones: s)
lelephone svstem:
;
Kw ia
Radio broadcast stations: \\\\E) EM
muave |
Rudios: NA
Pelevision broadcast stations:
Televisions: \\\\
Defense
Branches: no reeulas
vuard may be established). Polroe Force
Defense note: detense is the respe sibility
of the US
7
3/6
\\lartinique
overseas department of France)
7 kL
Lib
-
|
i
:
e =
FCAT OF
FEANCE
.*
. ae
*\\eVau a”
Ceeography
Location: C anbbean. island in the Canbbean
S thot Tr tand Tobago
(,eographic coordinates: 14 40 N. 61 00W
Map references: Cent \\merca and the
(
Area:
re hehth more than six
times the s | Washington, De
Land boundaries: (|) km
( oastline: 490 kn
Nlaritime claims:
‘ 1M) ryety
International disputes: non:
Climate: tropical. moderated by trade winds
lune to October). vulnerable to
Mums anes) every eiht
iWerage temperature 17.3
‘ ii
ferrain: ;vountainous with mndented
herant Vomane
ety Canbbean Sea 0 m
Montagne Pelee 1.397 m
Natural resources: Coastal scenery and
itiwable Pe
Land use:
meadows and pastures: 30
tand woodland: 26°
''j IH
irrigated land: 60 sq km (1989 est.)
hLovironment:
‘ , wyvaeer''s NA
OS
natural hazards: harncanes, flooding, and
volcamc activity (an average of one major
natural disaster every five years)
uuernational agreements: NA','7a613aea046df32e2450a0742108c58874fbe44e2be0e46fd2dea54038656a1e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a212b124a085875c4cb7f8792ed398066eac87e689ede93c43e7b22c347374fb',1996,'MQ','Martinique','communications',587,'Telephones: 159.000 (1990 est)
Telephone system: domestic facilities are
adequate
domestic: NA
imernational, microwave radi relay to
Guadeloupe. Dominica. and Saimt Lucia.
satellite earth stations—2 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM |. FM 6.
shortwave 0
Radios: 74.0000 (1992 est.)
Television broadcast stations: |0)
Televisions: 65,000 (1993 est)
Defense
Branches: French forces (Army. Navy. Au
Force). Gendarmerie
Defense note: delense iy the responsibility
ot France
3/8
Nlauritania
-——_——— -—_ -
(,covraphy
location
‘
t,couraphn
\\lap
\\rea
ctereonces
Land houndares
( cnastlhome
Niaritemec chains
soordmates
International disputes
~
( lirrnate
lerram
h
Natural resources:
land use:
sf
Irrigated land:
1) Bt xt)
Radio broadcast stations: AM 4. FM |,
shortwave 0
Radios: 104.000 (1992 est)
Pelevision broadcast stations: | cable
Televisions: 26,000 (1992 est.)
Defense
Branches: Royal Saint Lucia Police Force.
Coust Guard
Manpower availability:
males dee 15-49: NA
males fit for military service: NA
Defense expenditures: exchange rate
conversion——$5.0 million, 2.0% of GDP
(1991): note - tor police forces
410','798066b1afab0f74bd22fbe71e968fb2a118f8260dd00dd0f7995b76ff4f190f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e17cdab884a1fa9d824b0acb7f88ea41cae8d63bc3a82acf3189c1057e77eec',1996,'MU','Mauritius','communications',591,'Telephones: 450
Telephone system: small system
sdmuinistered by French Department of Posts
and Telecommunications
domestic: NA
international: microwave radio relay and HF
radiotelephone communications to Comoros
and other international connections
Radio broadca:* stations: AM |. FM 0.
shortwave 0
Radios: 30.000 (1994 est)
Television broadcast stations: (
>
Televisions: 3.500 (1994 est)
Defense
Defense note: defense ts the responsibility
of France','bf13b5b9f002f17fd5a7ca60b70c781fa665c21a1f774e37cd56ce913bef348f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea56e6c8c59652c721ecf64a017e4712f4e36bf2eaffcc2e2ac68959750a0aa9',1996,'FM','Micronesia, Federated States of','communications',594,'lelephones: \\ \\
lelephone system:
, NA
crm ‘\\\\
Radio broadcast stations: \\\\I NA EM
NA. shortwa \\N\\
Radios: \\ \\
lelevision broadcast stations: \\ \\
lelevisions: \\ \\
Moldova','a2767ec24c1d219e951d61d21ddcfd47d77aa78f3ccd1d15ae1a5728e03b925a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c80224567a19bf63c6a76a1905291868a4655c9875fc4d67df6d01c1f649edd',1996,'RO','Romania','communications',597,'Telephones: 34.600 (1987 est)
Telephone system: automatic telephone
sysiem
domestic: NA
international: no satelite earth stations.
connected by cable into the French
communications system
Radio broadcast stations: AM 3. FM 4.
shortwave 0
Radios: 30.000 (1992 est)
Television broadcast stations: 5 (1987 est.)
Televisions: 22.000 (1992 est)
Defense
Defense note: defense is the responsibility
of France
natural hazards: dest Morms Carl
ars |
sicovania J
rerr’*™ 4 UKRAIN 4
a = . ug & OY
“_ ns , \\ 4 ‘4
ARVs » >» \\ ® ~.
'' e\\ *MOLDOVA
AW » as \\ » v
r 2 NapDOC! ic
ail ;-
.- *A ; { &
\\ Ou , UkRAIRg
L “Tim qoara . sala yd
“ £8 > ‘
~ Pinest Dana oe
> BUCHAREST,
A at Consiantas
; . —
fc. ate Cx “sar gaha
S \\ ~~ ee
~\\
y,
t BULGARIA
aX
~
~
Telephones: 2.3 million (1990 est.)
Telephone system:
domestic: poor service: 89% of telephone
network is automatic: trunk network 1s
microwave radio relay: roughly 3.300
Villages with no service (February 1990 est.)
international: satellite earth station—|
Intelsat: new digital international direct-dial
exchanges are in Bucharest (1993 est.)
Radio broadcast stations: AM |2. FM 5.
shortwave 0
Radios: 4.64 miliion (1992 est.)
Television broadcast stations: |3 (1990
est.)
Televisio::s: 4.58 million (1992 est.)
Defense
Branches: Army. Navy, Air and Air
Defense Forces. Paramilitary Forces, Civil
Defense
Manpower availability:
males age 15-49; 5.572.383
males fit for military service: 4.693.376
males reach military age (20) annually.
198.125 (1996 est.)
Defense expenditures: exchange rate
conversion—S$885 million, 3.0% of GDP
(1995)
Russia
a
j ‘3
“¥
™“— eH Ww
’ ae gene
a * .
- soscow
ae _
é ms
-
Ron 29 ee sore
Peeks ye . - 4 6 Meee te
* mene aon . ; “eo
" / ee
i Fe fees
G aphy
seography
Location: Northern Asia (that part west of
the Urals is sometimes included with
Europe), bordering the Arctic Ocean,
between Europe and the North Pacific Ocean
Geographic coordinates: 60 00 N, 100 00
E
Map references: Asia
Area:
total area: 17,075,200 sq km
land area: 16.995.800 sq km
comparative area: slightly more than 1.8
times the size of the US
Land boundaries:
total; 19.913 km
border countries: Azerbaijan 284 km.
Belarus 959 km. China (southeast) 3.605 km,
China (south) 40 km, Estonia 290 km.
Finland 1.313 km, Georgia 723 km.
Kazakstan 6.846 km. North Korea 19 km,
Latvia 217 km. Lithuania (Kaliningrad
Oblast) 227 km. Mongolia 3.441 km,
Norway 167 km, Poland (Kaliningrad
Oblast) 206 km. Ukraine 1.576 km
Coastline: 37.653 km
Maritime claims:
continental shelf: 200-m depth or to the
depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
international disputes: inherited disputes
from former USSR including sections of the
boundary with China: islands of Etorofu,
Kunashiri, and Shikotan and the Habomai
group occupied by the Soviet Union in 1945,
administered by Russia, claimed by Japan:
maritime dispute with Norway over portion
of the Barents Sea: Caspian Sea boundaries
are not yet determined: potential dispute with
Ukraine over Crimea: Estonia claims cver
2.000 sq km of Russian territory in the
Narva and Pechora regions: the Abrene
section of the border ceded by the Latvian
Soviet Socialist Republic to Russia in 1944;
has made no territorial claim in Antarctica
(but has reserved the night to do so) and does
not recognize the claims of any other nation
Climate: ranges from steppes in the south
through humid continental in much of
European Russia: subarctic in Siberia to
tundra climate in the polar north; winters
vary from cool along Black Sea coast to
frigid in Siberia: summers vary from warm
in the steppes to cool along Arctic coast
Terrain: broad plain with low hills west of
Urals; vast coniferous forest and tundra in
Siberia: uplands and mountains along
southern border regions
lowest point: Caspian Sea -28 m
highest point: Mount El’brus 5,633 m
Natural resources: wide natural resource
base including major deposits of oil. natural
gas. coal, and many strategic minerals,
timber
note: tormidable obstacles ot climate, terrain.
and distance hinder exploitation of natural
resources
Land use:
arable land: 8%
permanent crops: NEGL&%
meadows and pastures: 5%
forest and woodland: 45%
other: 42%
Irrigated land: 56.000 sq km (1992)
Telephones: 25.4 million (1993 est.)
Telephone system: total pay phones tor long
distant calls 34.100: enlisting toreign help.
by means of joint ventures, to speed up the
modermization of its telecommunications
sysMiem: in 1992. only 661.000 new
telephones were installed compared with
855.000 in 1991, and in 1992 the number of
unsatistied applications hor telephones
reached 11.000.000; expanded access to
international electronic mail service available
via Sprint network, the madequacy of
Russian telecommunications ts uw severe
handicap to the economy. especially with
respect to international connections
NMT-450 analog cellular
telephone networks are operational and
dt ile slic
growing in Moscow and St. Petersburg:
intercity fiber-optic cable installation remains
limited
miernctional: wiernational trattic ts
inacequately handled by a system of
satellites. landlines. microwave radio relay.
and outdated submarine cables: much of this
tratfic passes through the international
gateway switch in Moscow which carries
most of the international trattic for the other
countries of the Commonwealth of
Independent States: a new Russian
Intersputnik satellite will link Moscow and
St. Petersburg with Rome trom whence calls
will be relayed to destinations in Europe and
overseas, satellite earth stations—NA
Intelsat. 4 Intersputnik (2 Atiantic Ocean
Region and 2 Indian Ocean Region), NA.
Eutelsat. | Inmarsat Pacific Ocean Region).
and NA Orhita
Radio broadcas: stations: AM NA FM
NA, shortwave NA; pete here ere about
1.050 cincluding AM. FM. and shortwave}
radio broadcast stations throughout the
country
Radios: 50 million (1993 est. (radio
receivers with multiple speaker systems for
program diffusion 74,300,000)
Television broadcast stations: 7.183
Televisions: 54.85 million (1992 est.)
Defense
Branches: Ground Forces. Navy. Air Forces,
Air Detense Forces. Strategie Rocket Forces
Manpower availability:
males age 15-49; 38,673.99]
males fit for military service: 30,224,738
males reach military age (18) annually
1.105.004 (1996 est.)
Defense expenditures: SNA. NA of GDP
note: the Intelligence Community estimates
that defense spending in Russia fell by about
20% in real terms in 1995, reducing Russian
detense outlays to about one-fifth of peux
Soviet levels in the late 1980s
11','5736bc9d6ad911eb18d051b137beb73e87e57c843de1c2a586b542b8fbc68b90','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77aa2338ce2e4f711ea4a5d33a0162d420a5ac2034d925580817291f39ce0b15',1996,'MN','Mongolia','communications',598,'© nemeee People
the spring
wmemational agreements. Parts
Biodiversity Climate Change. Ens
Modification, Nuclear Test Bas
not ratilied—Desertiticatron. Law
Ceographic note: landlocked
location between China and R
Population: 2 496.617! ”
Age structure:
— = i— _ - }
fy4 levi’ ss tT) , a
Geography -3
hy ears a] a . ’
Location: Northern Asia. between China and Sl 11i) Jul 190
Russia Population growth rate: | ''
: ‘ icc in: : 4600 Os (1) :
Ceographic coordinates: N.1 Birth rate: 24 45 bir: -
bE 1YOH est)
Map references: Asia Death rate: 65 deat! -
Area: ‘1996 est
! rea: 1 S6S
mal area. | . mullon sq km Net migration rate
land area. 1565 millon sq km
| . i
Lb lathe vw
comparative area: siettly larger than Alaska
Land boundaries:
Sex ratio
rital: 8.114 km 7
horder countries. China 4.673 km. Russia 1S Ad
3.441 km ro
Coastline: 0 kr Clandlocked
Maritime claims: mone (landlocked)
International disputes: non
Climate: desen: continental (large daily and
Infant mortality rats
‘\\ ryrrt rvs ,
Life expectancy at birth
seasonal temperature ranges) , one be
Terrain: vasM semdesert and desert mi itis - » &e
mountains im west and southwest. Crab ceeale: 9 9
Desert in southeast lotal fertility rate
lowest pouni Hoh Nuur S''S m . in yw
nghest pow Navramadimn Ores! 4.474 9 Nationality:
Natural resources: on). Goal, copper mem: ff
molybdenum. tungsten. phosphates. | \\
mekel. zine. woltram. thoorenw Fthnic divisions: V1 "
Land use: ‘ ''
rable lar | Religions
moran «orem 0 \\1
she chclomm 4 pul th ave y
lowest and woodlas i}
eher: WN languages: Khakho M
Irrigated land: 770) sy kim | 1489 i
Environment: | iteracy
current wees) tinted natural tresh “ater
resources, Polrores of ihe hown rirvour
regime promoting caped urhar thon atl » RAE
mdusinal growth have cared concert h
ther negative effects on the envi
burning of soft coal and the concentratn
lactones in Ulaanbaatar have severely
, o .
polluted the an det resMiainm,. overye (ne VEr nee nt
»
T :
the converting of virgin land to aen ull Name of country
production have mereased sen! croseon fro
wind and ram. desertifpcatoon
Mongolia (¢ ontinited )
Monzel Uls
() \\I
Datu code: \\it
Iype of government: republic
{ upital: ''
\\danunistrative divisions: 1S provinces
} i) } 1) ONT
‘ } ? (; ‘1 Vii i>
'' hi () Ara
‘ e S maul Ii \\
independence: March 1921) «trom China)
National holidays: \\ Dav. Ti July
Constitution: > January 1992
Leval svstem Russian. Chinese
; rW
| yy ''
Sullraye
baccutive branch
it
(peat)
resident
oT 1
held NA 1997
OCHIRB AI
wren toad dares +}
madd
\\ MIPRP
j \\1
\\ WK)
5 , —
\\ Qy
REN TMORI noe NA
the Stale
Levishative branch rl
held tor the tirst
held NA tune
nats NA
VIPRP Lnited Party of
‘ 1p
i ongel
ludicial branch: S Court. serves a
people''s and provmeial
date rarely overturns verdicts
Te udves are nominated by the
(; ral Council of Courts tor appro al ivf
Creat Hur
Political parties and leaders: Mongolian
Peeples Revolutionary Party (MPRP)
326
Budragchaguin DASH-YONDON., secretary
general: Mongolian National Democratic
Party (MNDP). D. GANBOLD. chairman.
Mongolian Social Democratic Panty (MSDP).
Bo BATBAYAR. chairman: United Party of
Mongolia. leader NA
Note. opposition parties were legalized in
May 1990
international organization participation:
ASDB. CCC. ESCAP. FAO. G-77, LARA.
IBRD. ICAO. ICRM. IDA. IFAD. TFC.
FRCS. ILO. IMF. Intelsat (nonsignators
user). Interpol. LOC, ISO. ITU. NAM
tobserver). UN. UNCTAD. UNESCO.
UNIDO. UPL. WETULY 40. WIPO.
WMO. WoO. WTrO (applicant)
Diplomatic representation in US:
ciel of misston. Ambassador Jalbuugiyn
CHOINHOR
chancery. 2833 M Street NW. W ashington.
DC DIM?
felephame> (V] (202) 333-7117
PAN. [1] (202) 298-9227
consulates s) general: New York
US diplomatic representation:
hie of muisston Nbassador Donald C
JOHNSON
cmbassy: ynner north side of the Brg Ring.
just west of the Selbe Gol. Ulaanbaatar
mailing address) Clo American Embassy
Bening. Micro Region Tl. Big Ring Road:
PSC 461. Box 300. FPO AP 96525-0002
telephone (976) (1) 3290958, 329606
PAN. [976] 1) 320776
Flag: three equal. vertical bands of red Chorst
vide). blue. and red. centered on the horst
vide red band in vellow as the national
emblem Cosovombo —a columnar
arrangement of abstract and geometric
representation for tire. sun. neon. earth,
water, and the yin-yang symbol)
Telephones: 89.000 (1995 est)
Telephone system:
domestic: NA
nuternational: satellite earth station— |
Intersputnik (Indian Ocean Region)
Radio broadcast stations: AM 12. 5M |.
shortwave 0
Radios: 220.000
Television broadcast stations: | (provincial
repeaters TS)
Televisions: | 20.000 (1993 est)
Defense
Branches: Mongolian People’s Army
(includes Internal Security Forces and
Frontier Guards). Aw Force
Manpower availability:
males ave 15-49. 638.560
males fit for milttary service: 417.620
males reach mulitary ave (18) annually
>7. 386 (1996 est)
Defense expenditures: exchange rate
conversion-—$22.8 million. 1 of GDP
( 1YY>,','397a2c0d752f60b9eab7af567995c9d14e057f30be538b425e54875e2de2ea95','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2c8eba03a3f766db7a67947d27af3787d55cc9298e8f874a7eb450e1def368f',1996,'MS','Montserrat','communications',601,'(dependent territory of the UK)
oP YMOUTH
Telephones: 3.0000
Telephone system:
domestic: NA
witernational: NA
Radio broadcast stations: AM 8. FM 4.
shortwasve 0
Radios: 6.000 (1992 est)
lelevision broadcast stations: |
Delevisions: 2.000 (1992 est)
Defense
Branches: Police Force
Defense note: detense is the responsibility
of the UR
337','abdd3f80a4946fc2cf23d6efbf45baec4d17a04aa961a7e02ce41ad4a43ba998','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92c9083ce14d190dc2edaedcdeccb2cc37e3a250b39e76c8c80a5603c9ecb775',1996,'MA','Morocco','communications',606,'PORTUGAL SPAIN
Ta ‘aya
Telephones: 270.100 (1987 est)
Telephone system:
domestic: good system composed of open
wire lines, cables, and microwave radio relay
links: principal centers are Casablanca and
Rabat. secondary centers are Fes. Marrakech.
Ouida. Tangier. and Tetouan
miermational: S submarine cables: satellite
earth stations —2 Intelsat (Atlantic Ocean)
and | Arabsat, microwave radio relay to
Gibraltar, Spain. and Western Sahara:
coaxial cable and microwave radio relay to
Algeria. participant in Medarabtel
Radio broadcast stations; AM 20. FM 7.
shortwave 0
Radios: 5.527 million (1992 est)
Television broadcast stations: 26 (repeaters
4)
Televisions: |.2) million (1993 est.)
Defense
Branches: Royal Moroccan Army. Royal
Moroccan Navy. Roval Moroccan Air Force.
Royal Gendarmerie, Auxiliary Forces
Manpower availability:
males age 18-49: 7.541.745
mates fit for military service: 4.782.028
males reach milttary ave (18) annually
330.344 (1996 est.)
Defense expenditures: exchange rate
conversion—S1.38 billion, 4.10 of GDP
(1995)
Radio broadcast stations: AM 2, FM 0.
shortwave 0
Radios: NA
Television broadcast stations: 2
Televisions: NA
Defense
Branches: NA
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: SNA, NA% of GDP
Western Samoa
co ~
. \\
eo,
~ SDM,
Num,
a ts
Telephones: 7,500 (1°88 est.)
Telephone system:
domestic: NA
international, satellite earth station—|
Intelsat (Pacific Ocean)
Radio broadcast stations: AM |. FM 0.
shortwave 0
Radios: 76.000 (1992 est.)
Television broadcast stations: 0 (1987 est.)
Televisions: 6.000 (1992 est)
Defense
Branches: no regular arined services.
Wesiern Samoa Police !
“oree
Manpower availability:
males ave 18-49: NA
males fit for military service: NA
Defense expenditures: SNA. NAT of GDP
524
lelephones: NA
Telephone system:
domestic: NA
mcrnational: NA
Radic broadcast stations: AM NA, FM
NA. shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
Branches: ground, maritime, and air forces
at all levels of technology
Defense expenditures: probably a small
decline in 1995 in aggregate real expenditure
on arms worldwide and somewhat less than
three-quarters of a tnihen dollars in money
terms. or roughly 2° of gross world product
(1995S est.)','a51cbeec8f176158c7c4f706ad7c06b158eebde474b5a0928379c1bbe3df6719','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c11681faa8e527b88798197206ff890832ee018b92dbea8a3595f8e64d1ed559',1996,'PT','Portugal','communications',618,'Telephones: $9,000 (1983 est)
Telephone system: fair system of
tropospheric scatter, open-wire lines. and
mecrowave radw relay
domestic. microwave tadw relay and
tropospheric scatter
miternational, satelite earth stations-—S
Intelsat (2 Atlantic Ocean and 3 Lladian
Ocean)
Radio broadcast stations: AM 29. FM 4
shortwave 0
Radios: 700,000 (1992 est)
Television broadcast stations: |
Televisions: 44,000 (1992 est)
Defense
Branches: Army. Naval Command. Aw and
Ai Detense Forces. Militia
Manpower availability:
rules ave 18-49 4.767 85§
males fil for military service: 2.162.388
(1996 est)
Defense expenditures: exchange rate
conversion—SS4 nullion, 5.36 of GDP
(i944)
Telephones: 2.200 (1986 est.)
Telephone system:
domestic: munmal system
international: satellite earth station—1
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM |. FM 2.
shortwave 0
Radios: 33,000 (1992 est.)
Television broadcast stations: | (1992 est.)
Televisions: NA
Defense
Branches: Army. Navy. Security Police
Manpower availability:
males age 15-49: 34.986
males fit for military service: 18.343 (1996
est.)
Defense expenditures: SNA. NA@ of GDP','3564563c8550bfc6d579ee6ce0972f42b53603d78138d85ae0edaffde7a48cec','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f0046a651a095693f349cd18cc7a1ce6cfdc5ae02b83b2003bf8d38077cf7d7',1996,'NA','Namibia','communications',619,'we
;
~e 4000" 5
.
Waves Bay
lelephomes: 89.722 (1992 est
lelephone system:
donnie Tir van ul urban seTV ices. lan mura
,
4
service. mucrowave rad relay links map
low ns. Connections to other populated p
ire DV open ware
micmattona N\\A
Radio broadcast stations: AVI 4 EM
shortwave 0
Radios: 199.000 (199) ext
lelesvision broadcast stations: °
Velevisions: 27.000 (199% es )
Defense
Branches: National Deiense Force (An
Polnce
Manpower availability:
mules ave /*% Ly ‘ fy
7,54 ‘
males fit for ml il Serilag aa 4 VA,
esi}
Defense expenditures: exchange rai
conversron —S64 mullnon. 2 | of GDP
i} yus Uy)
}
nw.
st)
Telephones: 2.000 (1989 est)
Telephone system: adequate local and
mtemational radiotelephone communications','3f7d5e166fff69ab010e3e886b5185cc1d252c799d9ec620c8e58766969491b8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7e439cf7e2be028c4ffaf07a9599f871e320f9ca146b92c41f89e99695c0f0e',1996,'NP','Nepal','communications',629,'Telephones: 82.074 (1995 es
Telephone SVSeEM: pod telephone and
telegraph service. tan racdhoteleph
COT aT seTVice
domestic. NA
ite rational radutelephon
Commumcations. satelite carth
Intelsat (Indian Ocean)
Radio broadcast stations: AVI ss IM
shortwave 0
Radios: 690.000 (1992 ex)
19
"*«
Nepal (continued)
iclesision broadcasM stations: | (1988 est)
;
belevisiems: 25 (0b YY” es
Delense
{ ''
hPa veg saanlataats:
r~ KAA
sponditures. ve Tal
1 (,DP
340','d5b53d716a63e35cb9f712f1e27a5a7511fb5e1589b1c27893ecd284e71c4674','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83c4e553e5abb1f698cf5b765abf81d03ddc9cb0c1fb2d47c70b73fc08771f92',1996,'TK','Tokelau','communications',635,'7 Agriculture: wheat. barley. potatoes. pulses
fruits. vegetables: wool, meat. dairy Telephones: 1.7 millon (1S86 est)
products: fish catch reached a record 503,000 Telephone system: excellent mtermationa!
mectne tons im 1YSS and domestic systems
Exports: $13.41 billion (1995) domestic: NA
b coprporrnas commodities: wool, lamb, mutton, beet. fish wmitermanonal: submarine cables to Austraha
hea . - > .
— ons et cheese, chemicals. forestry products. trurts and Fin: satellue earth stateons—? Intelsat
i 1 Iie eoserTview: i~-4
owestsiles. — ''
md vegetal les. manulactures (Pacific Ocean)
i a :
eed Britis _ co ee a. pe NES Radio broadcast stations: AM 64. FM 2.
, |. i fy
= Imports: 513.62 billhon (1995) shortwave (0)
, : . adtane % 314 (100? o
" ) mmoadities. Machinery and equipment Radios: pete Meee 03 bes ae
as hoped , “eee hn . lelevision broadcast stations: |4 (/ 986
vehicles and aircrall, petroleum. consumes
a tafe cM)
parmers” Australia 214. US 189, Japan Televisions: 1.53 millron (1992 est)
Wi ty Lk 6
“ External debt: 838.5 billon (September
its TT wos
Economic aid: Defense
mor, ODA. SIS million (1998 Branches: New Zealand Army. Royal New
Currency: | New Zealand dollar (NZS) = Zealand Navy. Royal New Zealand Au
mr cents borce
bv hange rates: New Zealand alan an Manpower availability :
; USS 1 St3S8 (honuars 1996). 1 5245 . males age 15-49) 927 212
. oo ens ; on?
- ™ | son a ane Smee males fit for military service: TRO9N76
} fy )
= biscal vear: hah 4) June “ue “ eee? Mee feet eens
A 43(1996 est)
Defense expenditures; exchange rate
comversion—SSS6 millon, 1 of GDP
Transportation PYOWo4)
Railways:
yy km
‘ hy at dae iyi ka (Wy on juve
Ah Mi kim electntied
pie U vel Highways:
48 km
(,10)’ My “died: 54.142 kim Grpcludimg 141 kn of
COTES AVA)
(.0P real growth rate "7 mpaied. 98.206 km (199) es
DP per capita Waterways: |.609 kim. of lithe umportanc
(DP composition by sector ho Transportation
Pipelines: petroleum products 160 km
tural cas LOOO Am. condensate Chquetied
rroleum gas — LPOG) 180 km
Inflation rate ccomsumer prices) Ports: Auckland. Chosichurch. Dunedin
lauranga, Wellington
bauhor force me Merchant marine:
Mal 7 stups (L000 GR of over) totaling
62 20 GRT218.749 DWI
i ncmphosment rate ‘) 1 iv) ups in ype bulk 6, carge 1. lquetied gas
Hilvet tanker |. onl tanker 3. raslear carner |. roll
ovrolloll cargo 5 (1995S est)
i \\irports:
NACE YY S/96 est ad WS
hrdustries nd pape th paved runways over 8047 m 2
ny win pared runways 1 S247 "4h am ®
1 wilh puares sunudys YVId tor 1 S28 om YY
with paved ranvays under Yld4d om SO
hwiustow production vrowth rate: \\\\ nih unparvcod runways 1524 to 2487 me |
ijheactroeuts with unpaved runways GVId to 1 S28 mm 2)
wy kW (1999S est)
448
’
*?
HONDURAS (V—"
{
JS (2
| IWS Pe, Caterate eeu
; =
4 di ~
5 e se
—_—_
*Matagece
= eer
Pwmero* gMANAGua “ane,
marae Bveteasd as de
aaca* Ma
was,
= “i ~~ ow Caras
COSTA PCA
(territory of New Zealand)
Atat
Fakaolo *
Telephones: NA
Telephone system:
domestic: radiotelephone service between
islands
international: radiotelephone service to
Western Samoa
Radio broadcast stations: AM NA, FM
NA, shortwave NA
note: each atoll has a radio broadcast station
of NA type that broadcasts shipping and
weather reports
Radios: | 000 (1992 est.)
Television broadcast stations: NA
Televisions: NA
Defense
Defense note: defense 1s the responsibility
of New Zealand','ba8f7944fdc2b142ef3e61a3f5b40eb8ef9fed3d56416b2e0f6f0ed963c56b1a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd44809d930e3c49129aac216c913d3e62236ad4dee5d768d1c9f2425fde6fa5',1996,'MP','Northern Mariana Islands','communications',643,'lelephones '' . "Ny
lelephone system
i >
Radio broadcast stations: \\\\ \\I
Radios >
lelesvistion broadcast stations:
1\\
lelevisions
Defense
Defense note i! LDL','ca84ef1a2264d9a246eab9cbfa4a7bbaf1ff4eead6d371658ff398eba98ecbf7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0449717bcfed237fef31621309e6af8fb27b5486cf54a2561e9b1f59ba71083',1996,'NO','Norway','communications',644,'ammenes a
: ‘ag,
0,
‘,
nae,
>
OSLO
r a
* eo
Delephones: 2 39 nullon (1986 est)
lelephone system: high quality domestic
and international telephone. telegraph. and
lcle\\ services
domestic. NA domesuic satelite earth
SLUTMMDS
;
niornational 2 tuned coaxial cable
Sstems., 4 coaxial submarine cables. satellitk
ath stalboas NA butelsat. NA Intelsat
Vthunti Ocean), and | tamarsat ¢ Athantn
md Indian Ocean Regron Te Nor a
Radio broadcast stations: \\\\VI 6 EME 49
K adios
iecleviseem broadcast stations
Deles tstons
Defense
Franches: * \\ }
\\ { \\
( (, he \\ \\
if {
Vianpower availability
; shy
. . ‘Ai
Defense expenditures: exchinve rate
‘ bilhon, 29 of GDP
LL
37/
Oman Environment: C,overnment
curren iwsues. Tisaing soul salinity. beach
Name of country:
pollution trom oil spalls: very limited natur:|
mracnlhiona ity wer ‘ iil< {)
iresh water resources
natural hazards: sammer winds often raise
iat dome fom Sallan | |
large sandstorms and dust storms in interior
i Mai Shortt fom l this!
xrhadsc droughts
Ps ; Data code. Ml
) fo
SM
nicmational aerecments party la
Mama Dah Ivpe of government:
aan Buaxliversasy. Claumate Change. Law of the a
Capital: Muse.
Sea. Manne Dumping. Ship Pollution _ oo
, Administrative divisions
signed. but not ratiied—Hazardous Wastes
svat '' stag
Vale . . PERSIE SE SMivul.
‘@wuscat Ceographic note: Vrateric location with Vermorates” (mul
y ; small tootheld on Musandam Peninsula .
nuhatazat) Ad . Jaki \\ \\) |
controlling Strat of Hormuz. a vital transi ;
Wusta. Ash Shargiveh. Av Za \\
ye mut tau world crude Mi
Musandam”. /utat
We
Independence: 1650 (ox)
Porlugues
> National holiday: “ut Du:','b62d871a664f29d7f72f3a88119e88410bcec846aad5023e21304704c5b92f0a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b35e01bd75eef2ad2867e87abe152e99bff7254273e4e5ca74d7e6ceba55be25',1996,'PH','Philippines','communications',665,'Telephones: | 500 (1988 est.)
Telephone system:
domestic: NA
muernational: satellite earth station— |
Intelsat (Pacific Ocean)
Radio broadcast stations: AM |. FM |}.
shortwave 0
Radios: 9.000 (1993 est.)
Television broadcast stations: 2
Televisions: |.600 (1993 est.)
Defense
Branches: NA
Defense expenditures: SNA. NA% of GDP
Defense note: defense is the responsibility
of the US
Palmyra Atoll
(territory of the US)
PETS sty Taint Aiea ENEIE
on
, oon
a ——— \\
— ee 7 _"
ail ae ‘ ~
ena << .
" ;
}
: ia
\\ a
Telephones: 887.229 (19923 est)
Telephone system: good iniernatior
radiotelephone and submarine cable service
domestic and interisland service adequate
domestic: domestic satellite system with
earth stations
miernational: submarine cables to Hong
Kong. Guam. Singapore. Taiwan. and Japar
satellite earth stations——3 Intelsat (1 Indian
Ocean and 2
Radio broadcast stations: AM 26!. FM S5
shortwave 0
Radios: 9.03 million (1992 est.)
Television broadcast stations: 29
Televisions: 7
Pacific Ocean)
million (1993 esi.)
Defense
Branches: Army. Navy (includes Coast
Guard and Marine Corps), Air Force
383
Pitcairn Islands
(dependent territory of the UK)
Philippines (continued)
Manpower availability:
S f j 7 Si
pl 44° 8 J 2? SOY
is
Defens<
,
conversion-——St billion, 1.4%
expenditures: exchange rate
of GDP <!1995)
Sandy
Over
Hendersc n
ADAMSTOWN
*
‘_ Bounty
Pricarn ©
Telephones: 24
Telephone system: party line telephone
service on the island
domestic: NA
international: radiotelephone
Radio broadcast stations: AM |. FM 0.
shortwave 0
Radios: NA
Television broadcast stations: ()
Televisions: NA
Defense note: defense is the responsibility
WARSAW
Telephones: 5 million (1994)
Telephone system: underdeveloped and
ouimoded system. government aims to have
10 million phones in service by the year
2000
domestic: cable. open wire. and microwave
radi relay
niernational: satellite earth statwons—NA
Intelsat. NA Eutelsat. | Inmarsat (Atlantic
and Indian Ocean Regions). and |
Intersputrik (Atlantic Ocean Regiwn)
Radio broadcast stations: AM 27. FM 27
shortwave 0)
Radios: 10.9 million (1993 est
lelevision broadcast stations: 40 (Russian
repeaters
Televisions: 9.6 millpon
Defense
Branches: Army. Navy. Air and Au
Detense Force
Manpower availability:
males ave 15-49. 10.267.5§]
males fu for military service, 7994460
males reach military ave (19) annuall
3794. 960 (1996 est)
Defense expenditures: exchange rate
conversion—S82.4 billion. 2.40 of GDP
(ies)','ab5ec828aa223eac036d78d87fc5ffb61a0a5db1d04b2d1b6bd289a49cd42a02','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfdc2fdf040bb78b421f0a6ea14cbf33f7b76b4512688af4170e1de3dbcb424a',1996,'PA','Panama','communications',671,'Telephones: 273.000 (1991 est.)
Telephone system: domestic and
international facilities well developed
domestic: NA
international: | coaxial submarine cable:
satellite earth stations—2 Intelsat (Atlantic
Ocean): connected to the Central American
Microwave System
Radio broadcast stations: AM 91. FM 0.
shortwave 0
Radios: 564.000 (1992 est.)
Television broadcast stations: 23
Televisions: 420.000 (1992 est.)
Defense
Branches: Panamanian Public Forces (PPF:
includes the National Police, National
Maritime Service. National Air Service. and
Institutional Protective Service): Judicial
Technical Police
Manpower availability:
males age 15-49; 705.427
males fit for military service: 484.571 (1996
est.)
Defense expenditures: exchange rate
converston—$78 million, NA% of GDP
(1995); note—for police and security forces','7cc90c291fd2b6d646440d7bcd4b9f92e2f64cbb2939d2d0028a760de3727ecf','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63f38174d5de7db8954291d841a1801287f6d209c65c1cd91bdb6c19f6db1e78',1996,'PG','Papua New Guinea','communications',672,'Nero
ean
.
Wewak apa
vew Gar
faearg) ew Bra
> Area
f ae ofl Bougarryitie *
WuUuMmea ~* 7
i ,
afug MORESBY ,
*
¥ -','4eafc5bcd65bf4957b186dc63230504e3342da8021feb0cde0e8c1e766c5e266','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9ffef5258cb5f5c8f5cf9d499f3e005fe162f2c14e24701efadd1a8f184f1aa',1996,'NZ','New Zealand','communications',678,'Telephones: 63.2'' 2 (1986 est.)
Telephone systera: services are adequate
and being improved: facilities provide
radiotelephone and telegraph coastal radio.
aeronautical radi, and international! radio
communication services
mostly radiotelephone
international: submarine cables to Australia
and Guam: satellite earth station—|! Intelsat
(Pacific Ocean): international radio
communication service
Radio broadcast stations: AM 31. FM 2.
shortwave 0
Radios: 298 000 (1992 est.)
Television broadcast stations: 2 (1/987 est.)
Televisions: 10,000 (1992 est.)
domestic
Defense
Branches: Papua New Guiwea Defense
Force (includes Army. Navy. Air Force. and
Special Operations Unit)
Manpower availability:
mates age 15-49: 1 i43.015
mules fil for military service: 635.923 (1996
es.)
Defense expenditures: exchange rate
conversion—S$40 million. 0.9% of GDP
(1995)
375
a
Paracel Islands
Leography
Location \\sid. gro
\\ "
Geograph coordmates: |f oN
''
Niap references: S tA
\\rea
Land boundaries
Coastline:
Maritime claims: \\ \\
International disputes: occup
cf 1 | d Vietn
Climate:
mil
lerrain: \\
( S
Natural resources:
Land use:
N ‘ j
four )
other (M)
Irrigated land: © sq kn
lelephone system:
domestic: NA
mernational: NA
Radio broadcast stations: AM NA. FN
NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
Defense note: occupied by China
BOLIVIA ae
j agerer ra','2530b1636495933e7a482e82ea8a045d15236c94b00bb62df4ae4f382121026c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45b10c1a70fc91647ca51f8307057570fdebcc6e35b62d0e68cc6aa9f8297fb2',1996,'PE','Peru','communications',683,'— (
\\ COLOMBIA )
~ )
ECUADOR f ''
tp rn
| | 7 ?|
eera, ~, ‘~
Pata® «. /
sf
Pus oY UrEQuas
> , "7
— £ BRAZIL
Trugio ae.
Saiavery* ° “——
li ad
LIMA \\
stac@ +, \\
- a eye )
= uso
BOUVIA
aregu ua.
.
Ve''a a ite
—,- ac“er,
wir','92f689d157dca2b495d16ad633feca0eac37c8e951201f54a44a46235ef9157d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28d7b25f278ea14ded143b489b6e8e70108fc1aa4dd376c595844de47cddbff7',1996,'PR','Puerto Rico','communications',686,'(commonwealth associated with the US)
Telephones: 182.558 million (1987 est.)
Telephone system:
domestic: large system of fiber-optic cable.
microwave radio relay. coaxial cable, and
domestic satellites
international: 24 ocean cable systems in use;
satellite earth stations—61 Intelsat (45
Atlantic Ocean and 16 Pacific Ocean) (1990
est.}, 5 Intersputnik (Atlantic Ocean region).
and 4 Inmarsat (Pacific and Atlantic Ocean
regions)
Radio broadcast stations: AM 4.987, FM
4,932. shortwave 0
Radios: 540.5 million (1992 est.)
Television broadcast stations: | 092 (in
addition, there are about 9.000 cable TV
systems)
Televisions: 215 million (1993 est.)
Defense
Branches: Department of the Army.
Department of the Navy (includes Marine
Corps). Department of the Air Force
note: the Coast Guard falls under the
Department of Transportation, but in wartime
reports to the Department of the Navy
Manpower availability:
males age 15-49; 69,302,573
males fit for military service: NA
males reach military age (18) annually:
1,864,580 (1996 est.)
Defense expenditures: $272.2 billion, 3.8%
of GDP (1995 est.)
Location: Southern South America,
bordering the South Atlantic Ocean, between
Argentina and Brazil
Geographic coordinates: 33 00 S. 56 00 W
Map references: South America
Area:
total area: 176.220 sq km
land area: 173,620 sq km
comparative area: slightly smaller than
Washington State
Land boundaries:
total: 1.564 km
border countries: Argentina 579 km, Brazil
98S km
Coastline: 660 km
Maritime claims:
continental shelf: 200-m depth or to the
depth of exploitation
territorial sea: 200 am. overflight and
navigation guaranteed beyond |2 nm
International disputes: short section of
boundary with Argentina is in dispute: two
short sections of the boundary with Brazil
are in dispute—Arroyo de la Invernada
(Arrow Invernada) area of the Rio Cuareim
(Rio Quarai) and the islands at the
confluence of the Rio Cuareim (Rio Quarai)
and the Uruguay River
Climate: warm temperate: freezing
temperatures almost unknown
Terrain: mostly rolling plains and low hills:
fertile coastal lowland
lowest point: Atlantic Ocean 0 m
highest point: Cerro Catedral 514 m
Natural resources: fertile soil, hydropower
potential, minor minerals
Land use:
arable land: 8%
permanent crops: 0%
meadows and pastures: 78%
forest and woodland: 4%
other: 10%
Irrigated land: | .100 sq km (1989 est.)','b804838ed1c2e9fb63d72c09265a0918f54ec6c54d494099e61e70d5de09138c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e780be63434ad1f37b54fe552084683326cee69fe1aa3e4fdae04e8529db86e',1996,'PK','Pakistan','communications',694,'Telephones: 160.717 (1992 est.)
Telephone system: modern system centered
in Doha
domestic: NA
miernational: tropospheric scatter to
Bahrain: microwave radio relay to Saudi
Arabia and UAE; submarine cable to
Bahrain and UAE: satellite earth stations—2
Intelsat (1 Atlantic Ocean and | Indian
Ocean) and | Arabsat
Radio broadcast stations: AM 2. FM 3.
shortwave 0
Radios: 201.000 (1992 est.)
Television broadcast stations: 3 (1988 est.)
Televisions: 205.000 (1992 est.)
Defense
Branches: Army. Navy. Air Force. Public
Security
Manpower availability:
maies age 15-49: 220.635
mates fit for military service: 115403
males reach military age (18) annually:
4.115 (1996 est.)
Defense expenditures: SNA. NA‘ of GDP
Reunion
‘overseas department of France)
Ponte *
Jes Galets SAINT-DENIS
. _
ero Sart Anare”
Sart Pau .
Sant-Beno:*
,oan u''s
Sant-Perre
.2ant-Jos@pn
‘ ,','32b8e19a78b11a7f7d85bf5e6595ceda9d9d38a18691e005f7019f8cb2598c49','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9a7fa88067d65552e98b371b58e915fc562c576da5b022e37cdc8d9c65b01bf',1996,'KN','Saint Kitts and Nevis','communications',695,'“ eee O SO'']rr “ fow
ates
~oer ow Pom ~
Youn a al
Sant
BASSETERRE , ns
vewcaste
Cnariestow. News
Telephones: 3.800 (1986 est.)
Felephone system: good interisland VHF,
LC HE/SHE radiotelephone connections and
international link via Antigua and Barbuda
ind Saint Martin (Guadeloupe and
Netherlands Antilles)
interisiand links are handled by
VHE/UCHE/SHF radiotelephone
niernational: yternational calls are carried
domestty
by radiotelephone to Antigua and Barbuda
and trom there switched to submarine cable
or to Intelsat. or carried to Saint Martin
Guadeloupe and Netherlands Antilles) by
radiotelephone and switched to Intelsat
Radio broadcast stations: AM 2. FM 0
shortwave 0
Radios: 25.000 (1993 est.)
Television broadcast stations: 4
Televisions: 9.500 (1993 est.)
Defense
Branches: Royal Saint Kitts and Nevis
Police Force. Coast Guard
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: SNA. NA‘ of GDP','bdb63e2ea32b7f0a8b648844e349cc208cd6ac6c9e5a550407faabc16a551a69','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0b1acbe8e38b16012d1bf41efd916a7af73e6d524123b4de57e85e535f9038b',1996,'LC','Saint Lucia','communications',701,'# CASTRIES
*.
A Se 2 Maye
Telephones: 26.000 (1992 est.)
Telephone system:
domestic: system ts automatically switched
miernational: direct microwave radio relay
link with Martinique and Saint Vincent and
the Grenadines: tropospheric scatter to
Barbados: international calls beyond these
counties are carned by Intelsat from','c7786adc337a23b4d5a2bd6bc493e22a45e1da7001409687b58635db5a64e1ec','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6f2484b6a06cb6004dccd96bda24172f08e81a3f5bca22deb4f444ec1ca2588',1996,'PM','Saint Pierre and Miquelon','communications',708,'(territorial collectivity of France)
Migueion®
Miquelon
Grande
Langlade ie Saut-Prerre
Peante Miquelon j
* SAINT-PIERRE
Telephones: 3.300 (1992 est.)
Telephone system:
domestic: NA
international: radiotelephone communication
with most countries in the world: | earth
station in French domestic satellite system
Radio broadcast stations: AM |. FM 3.
shortwave 0
Radios: 6.300 (1990 est.)
Television broadcast stations: (
SY
Televisions: 2.000 (1992 est.)
Defense
Defense note: defense is the responsibility
of France
“Yoo
Saint Vincent and the
(;renadines
%.
, hateaubeta
Sami 7 es Ww
ncent
@ KINGSTOWN
L a
Telephones: 6.189 (1983 est.)
JT slephone system:
domestic: ilandwide, fully automatic
telephone system: VHF/UHF radiotelephone
trom Sait Vincent to the other islands of
the Grenadines
international: VHF/UHF radiotelephone
from Saint Vincent to Barbados, new SHF
radiotelephone to Grenada and to Saint
Lucia: access to Intelsat earth station in
Martinique through Saint Lucia
Radio broadcast stations: AM 2. FM 0.
shortwave 0)
Radios: 76.000 (1992 est.)
Television broadcast stations: | cable
Televisions: 20.600 (1992 est.)
Defense
Branches: Royal Saint Vincent and the
Grenadines Police Force. Coast Guard
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: SNA. NA of GDP
413','f3ee74ec0f09b7f81f547190e2b1c62c2c44fa864288bb2c1d0b03f2400e6224','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2eb73b92da64e4ab07f655a5a7a96ad27461489e18861a404d57fb4daa973ea',1996,'SM','San Marino','communications',715,'ber
t
''
3
|
| .
SAN VARINO
al
Telephones: 22.300 (1992 est)
Telephone system:
domestic: auton.atic telephone system
completely integrated into Italian system
micrnational, microwave radio relay and
cable connections to Italian network: no
satellite earth stations
Radio broadcast stations: AM’ NA. EM
NA. shortwave NA (1 private radio
broadcast statron)
Radios: 12.535 (1991) est)
Television broadcast stations: | (199! est)
note. receives broadcasts trom Italy
Televisions: 7.500 (199) est)
Defense
Branches: Voluntary Military Force. Polis
Force
Manpower availability:
males ave 15-49. NA
males fit for military service: NA
Defense expenditures: $3.7 million (1 of
GDP) (1992 est.)','56c8f9c4ebce24876b697b78d80af8146422d7a4b68d1cb1c3ee256cfaf8c9cb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('251ef7e7da269b34d9c45c57b4b67bc07d2893e418fbbb91deec5d8a171264a0',1996,'ST','Sao Tome and Principe','communications',722,'x *
he. Bombom
ha do PnNePpe Sar. amono
te aly 4
* @y40 Tome
ina de
s ? T Whe
“Sarta C','2e10448476ddaa3221dcd2aec32174c0969c022e4cb11fa7ccaaca92b28120a8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7a99e4081cc4533433d42501ec8dc4f54d275c674627d022a2062e6cc8a24dc',1996,'SA','Saudi Arabia','communications',726,'iy YRIA 20) 400 ww
Pat 8 400 ~»
t- IRAQ
“4
{ Jonkx IRAN
ww wait
Suns Fas al Knell
- on "8
A suday''s paneale
SurayGa™* agdDamman*,
Lore - e
¢ ona A
: rivann® wo
Yanbu
7 woe Ring
y War
"Wec 3','0f9bfbb06c0bc11b4c0532d2b22b214009009722d99c402955117737ee94623e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a70023e0c4441f1458e46f9a81f43b2e8a584ae42366be5046503c26ae9d0e8e',1996,'SD','Sudan','communications',727,'4 wee
fr j 7%. rosy
{ ERITREA YEMEN
|
Telephones: | 46 million (1993)
Telephone system: modern sysiem
domestic: extensive microwave radi relay
and coaxial and fiber-optic cuble systems
international: microwave radiw relay to
Bahrain. Jordan. Kuwan, Qatar, UAE
Yemen. and Sudan: coaxial cable to Kuwan
and Jordan: submarine cable to Dybouty
Egypt and Bahrain, satellite earth stations
S Intelsat (3 Atlantic Ocean and 2 Indian
Ocean). | Arabsat. and | Inmarsat (Indian
Ocean region)
Radio broadcast stations: AV 43. FM 14
shortwave 0
Radios: § million (1993 est)
Television broadcast stations: \\0)
Televisions: 4.5 millon (1993 es)
Defense
Branches: Land Force (Army). Navy. Av
Force. Air Defense Force. National Guard
Coast Guard. Frontier Forces. Publi
Securty Force
Manpower availability:
males aec 15-49> 5S 4S RIS
males fit tor military sence. 3008900
males reach mittary awe (18) annualls
165.010 61996 est)
Defense expenditures: exchange rate
conversioa—$12 1 billion, 85% of GDP
(1996)
419','f98e8fe4c0abb331eb591eb35e43613464c4a952b2230500b50e5b6e3dacb11d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79f4167aa339df4ef20464863aa3537852bb9b2637ddb239cf0ac7d8b0cabf2a',1996,'SN','Senegal','communications',730,'a ; a
? .¥
- ———~,
7 ,
‘
. wa? * a
ah,
Poaaan ~
roe 4
| da
>
. ao ;
s ys
a NE
i —
feography
Location: Western Atrica. bordernneg the
North Atlantic Ocean. between Guinea
is u and Mauritama
C,eographic coordinates: 14.00 N. 1400 W
Miap references: Afnco
Ares:
area: 196.190 sq kim
land arca: \\Y2.000 sq kim
comparative area: slightly smaller than
South Dakota
Land boundaries:
1640 kn
the Gambia 740 km
Guinea 430 km. Guinea-Bessau 338 km
\\ 419 km. Mauritania ST km
( eastline: 54) km
Pritaia? LL
Nlarttime claims:
/ ; ’ # Hit
helt 0) nm of to the edve ol
mi cone: DOO am
2 nm
International disputes: short section of the
1 The Gamma us indetinite
vith Mauritania in dispute
(Climate: tromecal. bot. humid: rainy season
\\pni) has strong southeast
Viay to November)
hy hot. drv. harmattan wind
lerrain rally low. cofling. plains rising
ihe ast
Vlaniic Ocean Om
named bocathon m the Futa
Jaldon foothills 81m
Natural resources: fish. phosphates. iron
f
Land use:
420
meadows and pastures: 30%
forest and woodland: 31%
other: A2%
irrigated land: | 800 sg km (1989 est.)','a7bad6ee65e62947d33b7c8fb5d753c7b105c11297ec924c372663c4305cf1bb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('914ca1199527261cb3ae9a912eeeba69382b6cc00fa63fb70598b87a61e59df5',1996,'ME','Montenegro','communications',739,'Telephones: 700.000
Telephone system:
domestic: NA
mternational, satellite earth station— |
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 26. FM ¥
shortwave 0
Radios: 2.015 million
Television broadcast stations: | *
Televisions: | million
Defense
Branches: People’s Army (includes Ground
Forces with internal and border troops, Naval
Forces, and Au and Air Detense Forces).
Civil Defense
Manpower availability:
Vonteneero--males age 15-49. 173942
Vontencero males fit for military service
140).728
Vontenegro--males reach military ave (19)
annually, 5.226
Serbia —males ave 15-492 2546549
Serhia— males fit for military service
2.041.239 (1996 est.)
Defense expenditures: 245 billion dinars
4% to 6% of GDP (1992 est). note
conversion of defense expenditures into US
dollars using the current exchange rate could
produce misleading results','2d06c62cb729db1a65ab31803293e45bbd961cbfadd133d0016c5f4fd4c04177','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c3589c8232f7284d11afdcfca90111341e4d440260e1e2e5a72ff9a60ef48a5',1996,'SC','Seychelles','communications',740,'Les Mane
Amuamtes
Coetivy
Groupe
d Aigabra
‘Ato de
Cosmotedc Atoll de
Farquhar
Telephones: §.300 (1982 est.)
Telephone system:
demestic: radiotelephone communications
between islands in the archipelago
international: direct radiotelephone
communications with adjacent rsland
countries and African coastal countries:
satellite earth statron—1! Intelsat (Indian
Ocean)
Radio broadcast stations: AM 2. FM 0.
shortwave 0
Radios: 34.009 (1992 est.)
Television broadcast stations: 2
Televisions: 8.200 (1991 est.)
Defense
Branches: Army. Coast Guard, Marines.
National Guard. Presidential Protection Unit.
Police Force
Manpower availability:
males age 15-49: 21.547
males fi for military service: 1OS883 (1996
est)
Defense expenditures: SNA. NA& of GDP','71a63f451918edacc0d16a4a79371acf4e16e43fcf500d87a802f0b1201fd83c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f6df5d4d487ec12b6cb6b7810f50f638ee283e2419fcca54c298b5305b76693',1996,'SL','Sierra Leone','communications',746,'J 1
GUINEA [
J .“abala
} ance
NS’
v ane”
"a . a Setas°
®rREETOWN -/T|
otomta, Kadanun
Shenge* “ .Kenema
’ we Moma 3
ed ”
Sow? mine
sar Jf
~ af LIBERIA','2cb659b916b40131d0caf5214f16f167d6b1909c502466a00827cd9861dbbbbc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdc7d2e14c81180aab50e6c758acf85a6ee640e9bd40dc58f65ec0460d464236',1996,'LR','Liberia','communications',752,'Telephones: 17.526 (1991 est.)
Telephone system: marginal telephone and
telegraph service
domestic: nai.onal microwave radio relay
system made unserviceable by military
activities
miernational: satellite earth station—|
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM |. FM |}.
shortwave 0
Radios: 980.000 (1992 est.)
Television broadcast stations:
Televisions: 45,000 (1992 est.)
Defense
Branches: Army. Navy. Police. Security
Forces
Manpower availability:
males age 15-49. | OL9093
males fit for military service: 494.451 (1996
est.)
Defense expenditures: exchange rate
conversion—$14 million, 2.6% of GDP
(FY9Z/93)','235b184ad5591c9b03ce6367cf7b8b55ccb683b63fe08e8fb0c92c1b2eced8fb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e4a577ce748ced97e460a02d9cf6c96e160c873d0245e27b3bdca5729ea480c',1996,'SG','Singapore','communications',753,'MALAYSIA ~
" ‘ :
A, ‘ 2
F j _ Puma .
° “s,s Uewn ~
Woodlands \\
Seta’ > \\
.
€ chang Pua
“etang
vrong, ¥ Becox,
pee
<8 ~ o
Yau Sf"
Gususn ~ ~ Sentosa
n ©
the US. Western
World b mone leiephones: | 2? million (1993 est
Telephone system: good domestic tacilities:
hAapoerts ws good mternational service
ii | | ! rubber done vii NN \\
products micrnational: submarine cables to Malaysia
Sabah and Peninsular Malaysia). Indonesia,
| ) :
, Hoong and the Philippines. satellite earth stations
i} mi ¢ Wud)
N es v4 2 Intelsat (1 Indian Ocean and | Pacific
Imports: , Ocean). and | Inmarsat (Pacific Goean
hemicals
region)
- HIS Radio broadcast stations: AM |3. FM 4
f
. shortwave 0
| , Saud: Arabia 4 1994)
Radios: NA
Eaternal debt: s° Th YY4
‘elowiei ‘ + ‘ ; . YR? . }
crenemic nid: SNA Television broadcast stations: > (| est
T alowict ° K+ . OU o«
Currency: | S Jotlan (SS) = 100 Televisions: 1.05 million (1992 est)
Exchange rates: Singapore dollars (SS) pet
‘* ; tid ary 1YOO). 1.4174
Tt he 746/994). 1.6158 (19938). 1 628
Ky y
Fiscal sear: | Aprl-—3! March','ea73a7274c53eb5b0d000c773528a36deb8f7cefdaeb3189b2647b8c03b88f46','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82b3e21d72c66eea7df57b4b24920b79bab69873482a0ef14cfc44d816a7265d',1996,'SK','Slovakia','communications',762,'Telephones: | 362.178 (1992 est)
Telephone system:
domestic: NA
miernational: NA
Radio broadcast stations: AM NA, FM
NA, shortwave NA: note—there ts | station
of NA type
Radios: |.1 million (1992 est.)
Television broadcast stations: |
Televisions: |.6 million (1994 est.)
Defense
Branches: Army. Air and Air Defense
Forces. Civil Defense. Railroad Units
Manpower availability:
males age 15-49: 1,442,321
males fu for military service: 1104.90)
males reach military age (18) annually
48.695 (1996 est.)
Defense expenditures: exchange rate
conversion—$430 million, 3.0% of GDP
(1995)
Slovenia natural hazards. flooding and earthquakes Administrative divisions: 60 provinces
international agreements: party to—Au (pokapine. singular—pokapina) Aydovs na.
Pollution. Climate Change. Hazardous Brezice. Celjye. Cerkmca, Crome;
Wastes. Manne Dumping. Nuclear Test Ban Dravograd. Gornja Radgona. Grosuplye
Ozone Layer Protection. Ship Pollution, Hrastark Lasko. kénya. Mirska Bistrica. [rola
Wetlands. signed. but not ratitied— Au fesemice. Kammik. Koces je. Koper. Kranj
Pollution-Sulphur 94. Biodiversity. Law of Krsko. Lenarnt. Lendava. Lina Lyublana
the Sea Bezigrad. Lyubljana-Center. Lyublana-Moste
sania — Pole. Lyubljana-Siska. Lyublyana-V ic
: ~~ . Rudmk. Lyutemer. Logatec. Manbor
—_ | Metitha. Mozirye. Murska Sobota, Nova
tau . People Gonca. Novo Mesto, Ormoz. Pesnica. Poerar
— __ | Population: 1.981.443 uly 1996 est) Postoyna. Pray. Radlye Ob Dravi, Radov inca
~ —— | Age structure: Rayne Na Koroskem. Ribnica. Ruse. Sentpur
hon 0-44 vears: 17% (male 172.778: temale Pr Celw. Seva. Sezana. Shotja Loka
J 163.695) Shovenm Gradec. Slovenska Bistrica
15-64 vears: 70% (male 682.501. temale Slovenske Konpoe. Smare Pr Jelsal
Geography H7R.781) lolmin. Trbovije. Trebnye. Trac. Velen
65 vears and over: 13% imale 91.819 Vrhnika, Zagone Ob Savi. Zales
Location: Southeastern Europe. bordering female 161.869) Guiv 1996 est) Independence: *§ June 1991 (from
the Adnatic Sea, between Croatia and Italy Population growt> rate: 1276 (1996 est) Yugoslavia
Geographic coordinates: 46 OO N, 15 OOE Birth rate: §.27 birthy/1.000 penulation National holiday: National Statehood Day
Map references: Europe (1996 est) 25 June (1991)
Area: Death rate: 9.4 death! .000 population Constitution: adopted 2 December 199!
total area: 20.256 sq km (1996 est) ettective 23 December 199]
land area: 20.256 sq km Net migration rate: -! 57 mograntisy/) 000 Legal system: based on civil law system
comparative area: slightly larger than New population (1996 est.) Suffrage: 1% years of age. uni ersal (16
Jersey Sex ratio: years of age. 1f employed)
Land boundaries: at birth: 1.06 maleisWtemale Executive branch:
total: 1207 km under 15 vears: 1.06 maletsWtemale chiet of Mate’ Preadem Makan KUCAN
border countries: Austria 324 km, Croatia 15-64 vears: | maletsViemale isince 22 Apr! 1990) was reelected for o
$46 km. Italy 235 km. Hungary 102 km 65 vears and ove: 0.47 maletsWfemale five-vear term by universal sutivege. election
Coastline: 46.6 km all ages: 0.94 maleisWtemale (1996 est) lat held 6 December 1992 (nea, to be held
Maritime claims: NA Infant mortality rate: 7% deaths) 000 live NA 1997), results —Milan KUCAN reelected
International disputes: maritime border births (1996 est) head of encenment. Pame Minister Janez
dispute with Croatia over direct access to the Life expectancy at birth: DRNOVSEK tcsonce 14 Siav 1992) 4
sea mn the Adriatic: the border issue ts total population 75.09 vears muninated by the president and elected by
currently under negotiation male: 71.4 years the National Assembly
Climate: Mediterranean climate on the coast. female: 79 vear., (1996 est) cabinet’ Council of Ministers was nominated
continental climate with mild to hot summers Total fertility rate: |. 13 children born by the prime minister and elected by th:
and cold winters in the plateaus and valleys woman (1996 est) National Assembty
to the cast Nationality: Legislative branch: unicameral. advisory
Terrain: a short coastal strip on the nenen Meveneis! National Counc!
Adnatic, an alpine mountain region adjacent adjective: Sloveman National Assembly elections last held 6
to Italy. mixed mountain and valleys with Ethnic divisions: Slovene 916. Croat December 199) (next to be held Fall 1996)
numerous rivers to the east Serb >). Mustim 1°. other 3 results - percent of vote by marty NA
lowest point: Adriatic Sea 0 m Religions: Roman Catholic 96% (including scat. (90 total) LDS 22) SKD TS. ZLSD
highest point: Tnglav 2.864 m | Uniate). Musiim 19. other 35 14 SNS 1). SLS 10. DSS 6 ZS 6 SDSS 4
Natural resources: lignite coal. lead. zine. Languages: Sloveman 91% . Serbo-Croatian Hungarian minors |. itahan minority |
mercury. uranium, silver 7%, other 2% mue—-scating as of January 1996 Ww as
Land use: Literacy: NA follows LDS W). SKD IS. ZLSD 14. SLS
arable land: \\WO% 12. DSS 4. SDSS 4. SNS 4. SND 3
permanent crops, 2% Hunganan minority |. Halan menornty |
meadows and pastures: 20% . independents 2
forest and woodland: 48% Government Vatrional Council: the Council is an advisors
other: 28% Name of country: body with no direct legislative powers. on the
Irrigated land: NA sq km conventional lone form Republi ot election of 6 December 199). 40 members
Environment: Slovema were clected to represen local professponal
current issues: Sava River polluted with conventional short form: Slovema and soctoeconomec interests caeat election to
domestic and industrial waste: pollution of local long form: Republika Slovene be held NA Fall 1990)
coastal waters with heavy metals and tox local short form: Slovenia Judicial branch: Supreme Court. judges are
chemicals: forest damage near Koper from Data code: S| clected by the National Assembly on
au pollution (onginating at metallurgical and Type of government: emerging democracy recommendation of the Judicial Council!
chemical plants) and resulting acid rain Capital: Ljubljana Constitutwonal Court, judges clected for nine
433
ofa
Slovenia (continued)
the Natonal Assembly and
he president
Political parties and leaders: Liber!
LDS). Janez DRNOVSER
Shnene Chostian Democrats
SAD) Love PETERLE. chanrman: Social
Party of Shwens (SDSS). Janez
\\ : Slovene People''s Party
‘I PODOBNIK. charrman
i Conpmunimts and allies
ROCTIANCTC. chairman
\\ Part SNS). Zmago
NC i ria n. Democratic Parts
t’} RS \\KR enon Csreens of
Dusan PLU T. chairman
th the LDS: Slovene
} SNI Scso LAP. chairman
rf ine
(ther political or pressure groups: none
Infernatronal organization participation:
hi. EBRD. Chk. FAO. IADB
M AQ. ICRML IDA. TK
NTE. INGO), Intelsat
mol TOO POM
NACC. NAM touest
ka \\ UNCTAD UNESCO
Mt] Who WIPO WMIO) Wood
i
\\ ''
Diplomatic representation in US;
:} lit
‘\\ york
(tS diplomatic representation:
} '' ;
’
| \\ i
'' » \\\\
‘
; ; a”
ble I A Tyite
, ’
|
} ; i “ fit
4 wey
t J
’ ep
; hy ; ‘}
i } ti
it : ae ppc
| ! the w hte
44
Telephones: 527.800 (1993 est.)
Telephone system:
domestic: NA
imternational, NA
Radio broadcast stations: AM 6. FM 5.
shortwave 0
note: there are more than 20 regional and
local radio broadcast stations
Radios: 596.100 (1993 est)
Television broadcast stations: 7
note: there are more than 20 local cable
television broadcast stations
Televisions: 454.400 (1993 est)
Defense
Branches: Slovene Defense Forces
Manpower availability:
males awe 15-49: S25.925
males fit for military service: 419.456
males reach military age (19) annualls
18.380 (1996 est.)
Defense expenditures: | 4.5 billion tolars
1.6% of GDP (1995 est). note—conversion
of the minary budget into US dollars using
the current exchange rate could produce
misleading results','c40ef327e75707711f34f65aa39cb4bfebe1f303f95571c8ea694a1dd7a5ffcc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9892de40e710f12adc74aa86f106dbf0725f3b26b4869b2693af647b723fea4f',1996,'SB','Solomon Islands','communications',763,'PAPUA
NEW
wea
Crosew
Sarva sane
ee -
Yoyprp Maiats
4ON ARA®
suadaicgng ROS Seria
EPO —s
Telephones: §.000 (1991 est.)
Telephone system:
domestic: NA
international. satellite earth station— |
Intelsat (Pacific Ocean)
Radio broadcast stations: AM 4. FM 0).
shortwave 0
Radios: 38.000 (1993 est)
Television broadcast stations: 0 (1/987 est.)
Televisions: 2.000 (1992 est)
Defense
Branches: no regular military forces:
Solomon Islands National Reconnaissance
and Surveillance Force: Royal Solomon
Islands Police (RSIP)
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: SNA. NA&% of GDP','4eb50838675b45693fcd117ae81b9106a449ca1c5755649827b6dc1096d72dc1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da466ebc000359dfc69c2bef829fdf1ee4c246e1ae71abc29322e012d797f557',1996,'LK','Sri Lanka','communications',773,'md boundanrtes
being polluted by industnal wastes and
sewage runoll
natural hazards: occasvonal cyclones and
tomadoes
memational agre- nents party to
Biadiversity. Climate Change. Endangered
Species. Environmental Modification
Hazardous Wastes. Law of the Sea, Nuclear
lest Ban, Ozone Laver Protection, Wetlands
Whaling: signed. but not ratified—Manne
Lite Conservation
(,cographic note: strategic iocation near
may Indian Ocean sea lanes','662fb8f9d062219c2793a6756a0f6bb7a638e8dc58370e37e5776a51925f2a1d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec8ddf3a1137d8a7463dc34ce1417345eacd20c9c69b2835b8977298900336e2',1996,'SR','Suriname','communications',781,'Telephones: 43,522 (1992 est.)
Telephone system: international facilities
good
domestic: microwave radio relay network
international: satellite earth stations—2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 14.
shortwave |
Radios: 290.256 (1993 est.)
Television broadcast stations: 6 (1987 est.)
Televisions: 59.598 (1993 est.)
Defense
Branches: National Army (inciudes smail
Navy and Air Force elements), Civil Police
Manpower availability:
males ave 15-49; 119.010
males fit for military service: T0A00 (1996
est.)
Defense expenditures: SNA, NA@ of GDP
Svalbard
(territory of Norway)
Nordaustiandet
‘ Spasberger
, yard
, Barentso ya
Barentspugy’ LONGYEARBYEN
_— ; Edgeoya
lelephones: 30.364 (1993 est)
leiephone system:
domestic: system consists of carrer
equipped. open-wire lines and low
microwave radio relay
sulellite earth station
Intelsat (Atlantic Ocean
Radio broadcast stations: AM 7. FM 6
wiwave U
Radios: | 29.000 (1992 est)
|
television broadcast stations: |)
lelevisions: 12.500 (1992 est
Defense
Branches: |
|
Vlanpower availability:
>
4 pin
Defense expenditures:','3ad90d245ff4de5dcdf173211ec1b4e2c8622d10437f910f7e03aaa911489527','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e92b95c7c30e9df65e9fe344f699d1818571592bdf59d541a09bfe8a18e0d4b',1996,'TJ','Tajikistan','communications',786,'i ww
KAZARSTAN 4 ~
¢ ates
UZBEKISTAN F¢ KYRGYZSTAN
y we L—+ asee®
\\
. AFGMANISTAN = \\
. Gnas Oa PAKISTAN
Note: Tajikistan has experienced three changes of
government since it gained independence in
Sepiember 199]. The current president, Emomali
RAHMONOV, was elected in November 1994, yet
has been in power since 1992. The country is
suffering through its third year of a civil conflict,
with no clear end in sight. Underlying the conflict
are deeply rooted regional and clan-based
animosities that pit a government consisting of
peorly primamly from the Kulob (Kulyab).
ahujand (Leninabad), and Hisor (Hissar) regions
against a secular and Islamic-led opposition from
the Gharm. Gorno-Badakhshan, and Qurghonteppa
(Kurgan-Tyube) regions. Government and
opposition representatives have held periodic
rounds of UN-mediated peace talks and agreed in
September 1994 to a cease-fire which has been
periodically extended. Russian-led peacekeeping
troops are deployed throughout the country, and
Russian-commanded border guards are stationed
along the Tajik-Afghan border.
Telephones: 303,000 (1991 est.)
Telephone system: poorly developed and
not well maintained; many towns are not
reached by the national network
domestic: cable and microwave radio relay
international: linked by cable and
microwave radio relay to other CIS
republics, and by leased connections to the
Moscow international gateway switch:
Dushanbe linked by Intelsat to international
gateway switch in Ankara (Turkey); satellite
earth stations—1! Orbita and 2 Intelsat
Radio broadcast stations: AM NA, FM
NA, shortwave NA; note—there is one state-
owned radio broadcast station
Radius: NA
Television broadcast stations: |
466
note: | Intelsat earth station provides TV
receive-only service from Turkey
Televisions: NA
Tanzania
Defense
Branches: Army (being fonned),
Presidential National Guard, Security Forces
(internal and border troops)
Manpower availability:
males age 15-49: 1,358,106
males fit for military service: 1,115,149
males reach military age (18) annually:
58,691 (1996 est.)
Defense expenditures: | 80 billion rubles,
3.4% of GDP (1995)','af4f02fcc90a285dc35be83b3ab1ddd2cec72ecefcda50f6f2c5710d201bd510','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01de9d73f653a440a7ee57abea3899253e1ebe0004e1ebced8f372831657d757',1996,'TO','Tonga','communications',797,'Lecation: Oceania. archipelago in the South
Pacific Ocean, about two-thirds of the way
from Hawaii to New Zealand
Geographic coordinates: 20 00 S. 175 00
Ww
Map references: Oceania
Area:
total area: 748 3 4m
land area: 718 sq km
comparative area: four times the size of
Washington, DC
Land boundaries: (0) km
Coastline: 419 km
Maritime claims:
continental shelf: 200-m depth or to the
depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; modified by trade winds:
warm season (December to May). cool
season (May to December)
Terrain: most islands have limestone base
formed from uplifted coral formation. others
have limestone overlying volcanic base
lowest point: Pacific Ocean 0 m
highest point: on Kao Island 1.033 m
Natural resources: fish, fertile sou!
Land use:
arable land: 25%
permanent crops: 55%
meadows and pastures: 6%
forest and woodland: 12%
other: 2%
Irrigated land: NA sq km
Telephones: 3,500 (1986 est.)
Telephone system:
domestic: NA
international: satellite earth station—1
Intelsat (Pacific Ocean)
Radio broadcast stations: AM |, FM 0.
shortwave 0
Radios: 66.000 (1993 est.)
Television broadcast stations: 0
Televisions: |.000 (1992 est.)
Defense
Branches: Tonga Defense Services,
Maritime Division, Royal Tongan Marines,
Tongan Royal Guards, Police
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
8S','4d05493f90795ef2051d0b5be0b2193099a10154a595638d7ec010ddf85c379d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64ba338526ee00c89003ee9c1a4a1911ba9d3a9e4289c234936bd05d88eaa186',1996,'UG','Uganda','communications',823,'Telephones: 54.900 (1989 est.)
Telephone system: fair system
domestic: microwave radio relay and
radiotelephone communications stations
international: satellite earth station—|
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 10). FM 0.
shortwave 0
Radios: 2.04 million (1992 est.)
Television broadcast stations: 9 (1987 est.)
Televisions: 193,000 (1992 est.)
Defense
Branches: Army, Navy Air Wing
Manpower availability:
males age 15-49: 4,359,286
males fit for military service: 2,365,157
(1996 est.)
Defense expenditures: exchange rate
conversion—-$56 million, 1.7% of budget
(FY93/94)
492','eeae2394140d32188653657347ebc982648624d50fb0654b38146ee2becdb2b3','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3f7ca1790358348cf4f8bde871ffd08971ea19dfb9064d1b71b315fd7f095cc',1996,'UA','Ukraine','communications',824,'‘4 By
S et. seus are —
re - wy aestie t “a —_
POLAND -_ nese” * %
)
~~, vm aN
Ping, F = eee “4
sous > ee
r a me < a <<a, ovr ‘
a Va awe ae a
“eae : . ae aussie
Jf aes \\ we
f \\ es, ee,
awa ? ‘ee
f= ,-
ROMANIA ? tee <
J ~*~ —_—
$ ats’ Se
~ —
“> ¢ Smee, ——
‘ =) "=e','53ca2401a935e469619b0344ae97b1eae6875b93477982ece684eb7c443697b6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc718273902bb1e89c2ea5e01d0c5cce5ec44b26611e846e502c633b66d402aa',1996,'AE','United Arab Emirates','communications',830,'‘~ wee &
santas pom | a , (RAN
*
ane! Cae
‘ & oe meer
——, - owe eet
Qaras _ ane Pew Ae
rt me A.
A rag
- aa
a omen
_
. —.
SAUD! ARABIA aut
Telephones: 677,793 (1993 est.)
Telephone system: modern system
consisting of microwave radio relay and
coaxial cable; key centers are Abu Dhabi
and Dubai
domestic: microwave radio relay and coaxial
cable
international: satellite earth stations—3
Intelsat (1 Atlantic Ocean and 2 Indian
Ocean) and | Arabsat; submarine cables to
Qatar, Bahrain, India, and Pakistan;
tropospheric scatter to Bahrain; microwave
radio relay to Saudi Arabia
Radio broadcast stations: AM 8, FM 3.
shortwave 0
Radios: 545,000 (1992 est.)
Television broadcast stations: | 2
Televisions: 170,000 (1993 est.)
Defense
Branches: Army, Navy, Air Force,
paramilitary (includes Federal Police Force)
Manpower availability:
males age 15-49: 1,102,080
males fit for military service: 599,439
males reach military age (18) annuaily:
21,250 (1996 est.)
Defease expenditures: exchange rate
con ersion—$1.59 billion, 4.3% of GDP
(1994)
4) 7s 150 ~
North Gosz
Atlantic tslands
Ocean
or j
Jersey (UK)? }
forest and woodland: 9%
Telephones: 29.5 million (1987 est.)
Telephone system: technologically advanced
domestic and international system
domestic: equal mix of buried cables.
microwave radio relay, and fiber-optic
systems
international; 40 coaxial submarine cables:
satellite earth stations—10 Intelsat (7
499
United Kingdom (continued)
Atlantic Ocean and 3 Indian Ocean), |
Inmarsat (Atlantic Ocean region), and |
Eutelsat. at least 8 large international
switching centers
Radio broadcast stations: AM 225. FM 525
(mostly repeaters). shortwave 0
Radios: 70 million
Television broadcast stations: 207
(repeaters 3,214)
Televisions: 20 ‘nillion
Defense
Branches: Army. Royal Navy ‘(includes
Royal Marine -), Royal Air Force
Manpower availability:
ma °s age 15-49; 14,515,077
males fit for military service: 12,102,431
(1996 est.)
Defense expenditures: exchange rate
conversion—$35.1 billion, 3.1% of GDP
(FY9S/96)
.','2453e11c0b4d0cd1960c9afb2174c9d2f85b2efee0ee7a92cd627a18466bd42a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d02015c33f506e5341d417e29f1b19463542e4516138aae2b018c6d55e2a79a7',1996,'US','United States','communications',840,'SES TTS
LA, IES,
. —=_ >.> — —
——s ——
— ep e '' cua
S Caeava
ae
— _ =,
——
Seems
—-
™
on Vr
- = be ~ - s
a” oe
ay) oe 1S.
Telephones: 60,000 (1990 est.)
Telephone system:
domestic: modern, uses fiber-optic cable and
microwave radio relay
international: submarine cable and satellite
communications, satelite earth stations - NA
Radio broadcast stations: AM 4. FM 8.
shortwave 0 (1988)
Radios: 105,000 (1992 est.)
Television broadcast stations: 4 (1988 est.)
Televisions: 65,000 (1992 est.)
Defense
Defense note: defense is the responsibility
of the US
Telephones: NA
Telephone system: satellite communications.
1 DSN circuit off the Overseas Telephone
System (OTS)
domestic: NA
international: NA
Radio broadcast stations: AM 0. FM NA.
shortwave NA
Service (AFRTS) radio service provided by
satellite
Radios: NA
Television broadcast stations: NA
note: Armed Forces Radio/Television
Service (AFRTS) television service provided
by satellite
Televisions: NA
Defense
Defense note: defense is the responsibility
of the US
tes
Nars
MATALUTVs
he Uves
hes de Home
be Futuna
oSgeve (Leave)
te Aut
les de Home','5df78305a0eb3885eaeb22e9585a50af7e25136b04473837231717beb983c514','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb284ca00caa7bbe59c936dac7b73f4a4a86952635fec0b8bcef4e5ee01e9ca4',1996,'UY','Uruguay','communications',849,'Telephones: 451,000 (1991 est.)
Telephone system: some modern facilities
domestic: most modern facilities
concentrated in Montevideo; new nationwide
microwave radio relay network
international: satellite earth stations—2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 99, FM 0.
shortwave 9
Radios: |.89 million (1992 est.)
Television broadcast stations: 26
Televisions: 725,000 (1992 est.)
Defense
Branches: Army, Navy (includes Naval Air
Arm, Coast Guard, Marines), Air Force,
Grenadier Guards, Coracero Guard, Police
Manpower availability:
males age 15-49: 783,890
males fit for military service: 636,454 (1996
est.)
Defense expenditures: exchange rate
conversion—$256 million, 1.5% of GDP
(1994)','307e3d17f4feae103652a139014313dcffcdc0a62a802cbcd121b3c14cdc70ca','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a8896297663051f9479cc558d75a35b06bb5e2aa1809e349f1449668559a7d3',1996,'UZ','Uzbekistan','communications',850,'— Ss. a .
i Sa,
4 KAZAKSTAN
RALAASTAN \\
j commend, Pm
sf as 7 ''
\\ | > [ ~
= J 2
. a «YRC Y ZSTAN
“Hs, ; ee my ~S, _A
—/ ie: i
L pero
awn =
. ;
TURKMENISTAN a r~ mre ocHa
“ ~y TASRISTAN ~~
~~ "Gow ( “d \\
y™ — ) ras t
~ ‘A, f J 4 Sa
(RAN = Se S ‘ ’
\\ AFOMANNST AN fr ramrsian
Telephones: 1.458 million (1995 est.)
Telephone system: poorly developed
domestic: NMT-450 analog cellular network
established in Tashkent
international: linked by landline or
microwave radio relay with CIS member
States and to other countries by leased
connection via the Moscow international
gateway switch; new Intelsat links to Tokyo
and Ankara give Uzbekistan international
access independent of !tussian facilities;
satellite earth stations—NA Orbita and NA
Intelsat -
Radio broadcast stations: AM NA. FM
NA, shortwave NA: note—there is at least
one state-cwned broadcast station of NA
type
Radios: NA
Television breadcast stations: 2
Televisions: NA
Defense
Branches: Army, Air and Air Defense,
Security Forces (internal and border troops),
National Guard
Manpower availability:
males age 15-49: 5.672.621
males fit for military service: 4,623.960
males reach military age (18) annualiy:
231,293 (1996 est.)
Defense expenditures: 164 million soms.
3.7% of GDP (1993); aote—conversion of
defense expenditures into US dollars using
the current exchange rate could produce
misleading results
507
oy','ac5b24bcf5e377ec8afa50f6a8f2ae130bec4563250b8df17223fabf334ea867','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1a934c54c50b3d0fbd6f15b4e89acbb336f1b674a1200c268ef83ee0ddd00e4',1996,'VU','Vanuatu','communications',857,'hes South
Torres Pacific
'' . Ocean
hes
Banks
Santo
Maewo °
_ugawule
: Pentecote ®
>
. Amorym
Malakula
=z
Eo ®
co
> Foran
e .. -
PORT> Elate -
o
®
Tanna
Anatom
Matthew .
ands claened =HMunter
by FRANCE
G6 VANUAT(
4y -
Telepiones: 3,000 (1987 est.)
Telephone system:
domestic: NA
international: satellite earth station—|
Intelsat (Pacific Ocean)
Radio broadcast stations: AM 2. FM 0.
shortwave 0
Radios: NA
Television broadcast stations: 0 (1987 est.)
Televisions: 2.000 (1992 est.)
Defense
Branches: no regular military forces:
Vanuatu Police Force (VPF; includes the
paramilitary Vanuatu Mobile Force or VMF)
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
5/8
Venezuela
a st “NCEN ;
reba ah “4
sw Neth Antibes
@argusimet> Maracay “Pyerto ¥
ra ” Vaienca La Cruz >
& 6 4
> a -
2. CwSad
(San Crstooai © “Sar Fernando Guayan
wi
Puerto ya
Ayacucho','005d9d38c3eb71fd98c262d6eaed197aec9ce8914be4dbee0701dbc310148a64','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13aa960dfca2c4e8b22d1daa1b118d55aae513da830a72d2a05d8f0bf7934e7e',1996,'EH','Western Sahara','communications',870,'> ‘
'' islands ~~
Rvii-aD S womoceo
Ei Aan A
y .Semara
Sabo Bojyador, Bu
Crea ALGERIA
" Guetta’
¢ Zemmur
$n Daxnia','002c8e8dfcd0960371b71780c963e8f52b0cdddbbfc285dfa6465fbc168801db','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80f6dbbd99113e5d6e98865407166547e3dacd61df8f778afdf4e49cdd1f523e',1996,'MR','Mauritania','communications',871,'Bu Gandus
/ ¢__s0 some
; a
Telephones: 2,000
Telephone system: sparse and limited
system
domestic: NA
international: tied into Morocco’s system by
nucrowave radio relay, tropospheric scatter,
and satellite; satellite earth stations—2
Intelsat (Atlantic Ocean) linked to Rabat.','5cff975326e80517d64d88244416298c2b53025541b2a6388a520b7e1259da71','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96e33e4c776fd3ff4af460a411f115001726cf575951aa2803c9f2ec7c7f9a69',1996,'YE','Yemen','communications',878,'SAUD! ARABIA
iq SOMALIA
ae
Telephones: | 31,655 (1992 est.)
Telephone system: since unification in
1990. efforts have been made to create a
national telecommunications network
domestic: the network consists of microwave
radio relay, cable, and tropospheric scatter
imternational: satellite earth stations—3
Intelsat (2 Indian Ocean and | Atlantic
Ocean), | Intersputmik (Atlantic Ocean
region), and 2 Arabsat: microwave radio
relay to Saudi Arabia and Dyibouti
Radio broadcast stations: AM 4, FM |.
shortwave 0
Radios: NA
Television broadcast stations: |(0)
Televisions: 350,000 (1992 est.)
Defense
Branches: Army, Navy. Air Force.
paramilitary (includes Police)
Manpower availability:
males age 15-49: 2,985,764
males fit for military service: 1.685.517
males reach military age (18) annually:
145.161 (1996 est.)
Defense expenditures: SNA, NA of GDP
Location: Central Africa, northeast of','2b48d1230a39615adc7c2c0776ab2ac9b399527d122cb47f2902da09b8b2aa6f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d50e2c0dff4f9e80f5379004198b0dfa1cc1721138ec8035fcc1e9fe44d8dece',1996,'AO','Angola','communications',884,'Geographic coordinates: () 00 N, 25 00 E
Map references: Africa
Area:
total area: 2,345,410 sq km
land area: 2,267,600 sq km
comparative area: slightly more than one-
fourth the size of US
Land boundaries:
total: 10.271 km
border countries; Angola 2.511 km, Burundi
233 km, Central African Republic 1.577 km.
Congo 2.410 km, Rwanda 217 km, Sudan
628 km, Uganda 765 km, Zambia 1,930 km
Coastline: 37 km
Maritime claims:
exclusive economic zone: boundaries with
neighbors
territorial sea: 12 nm
International disputes: Tanzania-Zaire-
Zambia tripoint in Lake Tanganyika may po
longer be indefinite since it has been
informally reported thet the indefinite section
of the Zaire-Zambia boundary has been
settled; long section with Congo along the
Congo river ts indefinite (no division of the
river or its islands has been made)
Climate: tropical; hot and humid in
equatorial river basin; cooler and drier in
southern highlands, cooler and wetter in
eastern highlands: north of Equavor - wet
season April to October, dry season
December to February; south of Equator -
wet season November to March, dry season
April to October
Terrain: vast central basin is a low-lying
plateau; mountains in east
lowest point: Atlantic Ocean 0 m
i
highest point: Margherita Peak (Mount
Stanley) 5,110 m
Natural resources: cobalt, copper, cadmium,
peiroleum, industrial and gem diamonds,
gold, silver, zinc, manganese, tin,
germanium, uranium, radium, bauxite, iron
ore, coal, hydropower potential
Land use:
arable land: 3%
permanent crops: 0%
meadow’s and pastures: 4%
forest and woodiaad: 78%
other: 1S%
Irrigated land: 100 sq km (1989 est.)
Telephones: 34.000 (1991 est.)
Telephone system:
domestic: barely adequate wire and
microwave radio relay service in and
between urban areas; domestic satellite
system with 14 earth stations
international: satellite earth station—!
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM !0. FM 4.
shortwave 0
Radios: 3.87 million (1992 est.)
Television breadcast stations: |
Televisions: 55.000 (1992 est.)
Defense
Branches: Army. Navy, Air Force, National
Gendarmerie. paramilitary Civil Guard.
Special Presidential Division
Manpower availability:
males age 15-49; 10.025,5%6
males fit for military service: 5 VOR 385
(1996 est.)
Defense expenditures: exchange rate
conversion——$46 million, 1.5% of GDP
(1990)
é','701421a701db920e082004e0622ba34ab6f446f5f22e018e00f31fce9bdc8b0c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52cc4c5eadfc86e3986cf0d55659a61800f55728c3fe42f596694ba46e2179cc',1996,'ZW','Zimbabwe','communications',889,'Location: Southern Africa, cast of Angola
Geographic coordinates: 15 00 S. 30 OO E
Map references: Afnca
Area:
total area: 752.610 sq km
land area: 740,720 sq km
comparative area: slightly larger than Texas
Land boundaries:
total: 5.664 km
border countries: Angola 1.110 km, Malawi
837 km, Mozambique 419 km, Namibia 233
km, Tanzania 338 km, Zaire 1.930 km,
Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: quadmpoint with
Botswana, Namibia, and Zimbabwe is in
disagreement. Tanzania-Zaire-Zambia
tripoint in Lake Tanganyika may aw longer
be indefinite since it has been informally
reported that the indefinite section of the
Zaire-Zambia boundary has been settled
Climate: tropical; modified by altitude, rainy
season (October to April)
Terrain: mostly high plateau with some hills
and mountains
lowest point: Zambezi river 329 m
highest point: in Mafinga Hills 2.301 m
Natural resources: copper. cobalt, zinc.
lead, coal, emeralds, gold, silver, uranium,
hydropower potential
Land use:
arable land: 7%
permanent crops: O%
meadows and pastures: 47%
forest and woodland: 27%
othe: 19%
Irrigated land: 320 sq km (1989 est.)
Telephones: 80.900 (1987 est.)
Telephone system: facilities are among the
best in Sub-Saharan Africa
domestic: high-capacity microwave radio
relay connects most larger towns and cities
international: satellite earth stations—2
Intelsat (1 Indian Ocean and | Atlantic
Ocean)
Radio broadcast stations: AM |1. FM 5.
shortwave 0
Radios: | 889,140
Television broadcast stations: 9
Televisions: 215,000 (1995 est.)
Defense
Branches: Army, Air Force, paramilitary
forces, Police
Manpower availability:
males age 15-49; 1,934,845
males fit for military service: 1 020.851
(1996 est.)
Defense expenditures: exchange rate
conversion—$96 million, 2.7% of GDP
(1995)
a a
baa
Telephones: 30! 000 (1990 est.)
Telephone system: system was once one of
the best in Africa, but now suffers from poor
maintenance
domestic: consists of microwave radio relay
links, open-wire lines, and radiotelephone
communication stations
international: satellite earth station—|
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 8, FM 18.
shortwave 0
Radios: 890,000 (1992 est.)
Television broadcast stations: & (1986 est.)
Tetevisions: 280.000 (1992 est.)
Defense
Branches: Zimbabwe National Army. Air
Force of Zimbabwe. Zimbabwe Republic
Police (includes Police Support Unit.
Paramilitary Police)
Manpower availability:
males age 15-49; 2,629. 880
males fit for military service: 1.632.391
(1996 est.)
Defense expenditures: exchange rate
conversion—$236 million, 3.4% of GDP
(FY9S/96)
53
oe
Taiwan
—-
a W ; “ne are.
> » P ¢ Ch-tung
Crit pene - 7 ''
a ‘TAIPEI
Su-e0
7) & chung
"Cnang-rua
Pescadores
Vawnge
TP arnan
TP artung
Kao-nsuung®.
OO um
, i» om','994024f6632686ad67402e3bc45a962e379106a066ad1ad1e868c92c32748700','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de6826f228f4b7fd33677808a9e48bb06639b64f48dd404fd56d76879d691f1d',1996,'ZW','Zimbabwe','communications',12,'--------------
Telephones: 31,200 (1983 est.)
Telephone system:
domestic: very limited telephone and telegraph service; 1 public
telephone in Kabul
international: satellite earth stations - 1 Intelsat (Indian Ocean)
linked only to Iran and 1 Intersputnik (Atlantic Ocean Region)
Radio broadcast stations: AM 5, FM 0, shortwave 2
Radios: NA
Television broadcast stations: NA
note: several television stations run by factions and local councils
which provide intermittent service
Televisions: 100,000 (1993 est.)
Defense
-------
Branches: NA; note - the military still does not exist on a
national scale; some elements of the former Army, Air and Air
Defense Forces, National Guard, Border Guard Forces, National Police
Force (Sarandoi), and tribal militias still exist but are
factionalized among the various mujahedin and former regime leaders
Manpower availability:
males age 15-49: 5,549,602
males fit for military service: 2,976,741
males reach military age (22) annually: 220,532 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Albania
-------
Map
---
Location: 41 00 N, 20 00 E -- Southeastern Europe, bordering the
Adriatic Sea and Ionian Sea, between Greece and Serbia and Montenegro
Flag
----
Description: red with a black two-headed eagle in the center
--------------
Telephones: 55,000
Telephone system:
domestic: obsolete wire system; no longer provides a telephone for
every village; in 1992, following the fall of the communist
government, peasants cut the wire to about 1,000 villages and used
it to build fences
international: inadequate; international traffic carried by
microwave radio relay from the Tirane exchange to Italy and Greece
Radio broadcast stations: AM 17, FM 1, shortwave 0
Radios: 577,000 (1991 est.)
Television broadcast stations: 9
Televisions: 300,000 (1993 est.)
Defense
-------
Branches: Army, Navy, Air and Air Defense Forces, Interior
Ministry Troops, Border Guards
Manpower availability:
males age 15-49: 723,231
males fit for military service: 588,304
males reach military age (19) annually: 29,340 (1996 est.)
Defense expenditures: exchange rate conversion - $45 million, 2.5%
of GDP (1995)
======================================================================
@Algeria
-------
Map
---
Location: 28 00 N, 3 00 E -- Northern Africa, bordering the
Mediterranean Sea, between Morocco and Tunisia
Flag
----
Description: two equal vertical bands of green (hoist side) and
white with a red, five-pointed star within a red crescent; the
crescent, star, and color green are traditional symbols of Islam
(the state religion)
--------------
Telephones: 862,000 (1991 est.)
Telephone system:
domestic: excellent service in north but sparse in south; domestic
satellite system with 12 earth stations (20 additional domestic
earth stations are planned)
international: 5 submarine cables; microwave radio relay to Italy,
France, Spain, Morocco, and Tunisia; coaxial cable to Morocco and
Tunisia; participant in Medarabtel; satellite earth stations - 2
Intelsat (1 Atlantic Ocean and 1 Indian Ocean), 1 Intersputnik, and
1 Arabsat
Radio broadcast stations: AM 26, FM 0, shortwave 0
Radios: 6 million (1991 est.)
Television broadcast stations: 18
Televisions: 2 million (1993 est.)
Defense
-------
Branches: National Popular Army, Navy, Air Force, Territorial Air
Defense, National Gendarmerie
Manpower availability:
males age 15-49: 7,391,946
males fit for military service: 4,534,267
males reach military age (19) annually: 326,229 (1996 est.)
Defense expenditures: exchange rate conversion - $1.3 billion,
2.7% of GDP (1994)
======================================================================
@American Samoa
--------------
(territory of the US)
Map
---
Location: 14 20 S, 170 00 W -- Oceania, group of islands in the
South Pacific Ocean, about one-half of the way from Hawaii to New
Zealand
Flag
----
Description: blue with a white triangle edged in red that is based
on the outer side and extends to the hoist side; a brown and white
American bald eagle flying toward the hoist side is carrying two
traditional Samoan symbols of authority, a staff and a war club
--------------
Telephones: 8,399
Telephone system:
domestic: good telex, telegraph, and facsimile services; domestic
satellite system with 1 Comsat earth station
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 1
Televisions: 8,000 (1993 est.)
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Andorra
-------
Map
---
Location: 42 30 N, 1 30 E -- Southwestern Europe, between France
and Spain
Flag
----
Description: three equal vertical bands of blue (hoist side),
yellow, and red with the national coat of arms centered in the
yellow band; the coat of arms features a quartered shield; similar
to the flags of Chad and Romania that do not have a national coat of
arms in the center
--------------
Telephones: 21,258 (1983 est.)
Telephone system:
domestic: modern system with microwave radio relay connections
between exchanges
international: landline circuits to France and Spain
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 10,000 (1993 est.)
Television broadcast stations: 0
Televisions: 7,000 (1991 est.)
Defense
-------
Defense note: defense is the responsibility of France and Spain
======================================================================
@Angola
------
Civil war has been the norm since independence from Portugal on 11
November 1975; a cease-fire lasted from 31 May 1991 until October
1992 when the insurgent National Union for the Total Independence of
Angola (UNITA) refused to accept its defeat in internationally
monitored elections and fighting resumed throughout much of the
countryside. The two sides signed another peace accord on 20
November 1994; the cease-fire is generally holding, but most
provisions of the accord remain to be implemented.
Map
---
Location: 12 30 S, 18 30 E -- Southern Africa, bordering the South
Atlantic Ocean, between Namibia and Zaire
Flag
----
Description: two equal horizontal bands of red (top) and black
with a centered yellow emblem consisting of a five-pointed star
within half a cogwheel crossed by a machete (in the style of a
hammer and sickle)
--------------
Telephones: 78,000 (1991 est.)
Telephone system: telephone service limited mostly to government
and business use; HF radiotelephone used extensively for military
links
domestic: limited system of wire, microwave radio relay, and
tropospheric scatter
international: satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 17, FM 13, shortwave 0
Radios: NA
Television broadcast stations: 6
Televisions: 50,000 (1993 est.)
Defense
-------
Branches: Army, Navy, Air and Air Defense Forces, National Police
Force
Manpower availability:
males age 15-49: 2,373,087
males fit for military service: 1,195,176
males reach military age (18) annually: 106,456 (1996 est.)
Defense expenditures: exchange rate conversion - $1.1 billion, 31%
of GDP (1993)
======================================================================
@Anguilla
--------
(dependent territory of the UK)
Map
---
Location: 18 15 N, 63 10 W -- Caribbean, island in the Caribbean
Sea, east of Puerto Rico
Flag
----
Description: blue with the flag of the UK in the upper hoist-side
quadrant and the Anguillan coat of arms centered in the outer half
of the flag; the coat of arms depicts three orange dolphins in an
interlocking circular design on a white background with blue wavy
water below
--------------
Telephones: 890
Telephone system:
domestic: modern internal telephone system
international: microwave radio relay to island of Saint Martin
(Guadeloupe and Netherlands Antilles)
Radio broadcast stations: AM 3, FM 1, shortwave 0
Radios: 2,000 (1992 est.)
Television broadcast stations: 0
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the UK
======================================================================
@Antarctica
----------
Map
---
Location: 90 00 S, 0 00 E -- continent mostly south of the
Antarctic Circle
--------------
Telephones: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
-------
Defense note: the Antarctic Treaty prohibits any measures of a
military nature, such as the establishment of military bases and
fortifications, the carrying out of military maneuvers, or the
testing of any type of weapon; it permits the use of military
personnel or equipment for scientific research or for any other
peaceful purposes
======================================================================
@Antigua and Barbuda
-------------------
Map
---
Location: 17 03 N, 61 48 W -- Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean, east-southeast of Puerto
Rico
Flag
----
Description: red with an inverted isosceles triangle based on the
top edge of the flag; the triangle contains three horizontal bands
of black (top), light blue, and white with a yellow rising sun in
the black band
--------------
Telephones: 6,700
Telephone system:
domestic: good automatic telephone system
international: 1 coaxial submarine cable; satellite earth station -
1 Intelsat (Atlantic Ocean); tropospheric scatter to Saba
(Netherlands Antilles) and Guadeloupe
Radio broadcast stations: AM 4, FM 2, shortwave 2
Radios: NA
Television broadcast stations: 2
Televisions: 28,000 (1993 est.)
Defense
-------
Branches: Royal Antigua and Barbuda Defense Force, Royal Antigua
and Barbuda Police Force (includes the Coast Guard)
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: exchange rate conversion - $1.4 million, 1%
of GDP (FY90/91)
======================================================================
@Arctic Ocean
------------
Map
---
Location: 90 00 N, 0 00 E -- body of water mostly north of the
Arctic Circle
--------------
Telephone system:
international: no submarine cables
======================================================================
@Argentina
---------
Map
---
Location: 34 00 S, 64 00 W -- Southern South America, bordering
the South Atlantic Ocean, between Chile and Uruguay
Flag
----
Description: three equal horizontal bands of light blue (top),
white, and light blue; centered in the white band is a radiant
yellow sun with a human face known as the Sun of May
--------------
Telephones: 2.7 million (1983 est.)
Telephone system: 12,000 public telephones; extensive modern
system but many families do not have telephones; despite extensive
use of microwave radio relay, the telephone system frequently
grounds out during rainstorms, even in Buenos Aires
domestic: microwave radio relay and a domestic satellite system with
40 earth stations serve the trunk network
international: satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 171, FM 0, shortwave 13
Radios: 22.3 million (1991 est.)
Television broadcast stations: 231
Televisions: 7.165 million (1991 est.)
Defense
-------
Branches: Argentine Army, Navy of the Argentine Republic,
Argentine Air Force, National Gendarmerie, Argentine Naval
Prefecture (Coast Guard only), National Aeronautical Police Force
Manpower availability:
males age 15-49: 8,707,014
males fit for military service: 7,063,304
males reach military age (20) annually: 310,107 (1996 est.)
Defense expenditures: exchange rate conversion - $4.7 billion,
1.5% of GDP (1995)
======================================================================
@Armenia
-------
Map
---
Location: 40 00 N, 45 00 E -- Southwestern Asia, east of Turkey
Flag
----
Description: three equal horizontal bands of red (top), blue, and
gold
--------------
Telephones: 22,922 (1993 est.)
Telephone system:
domestic: more than adequate
international: 1 submarine cable to Sint Maarten (Netherlands
Antilles); extensive interisland microwave radio relay links
Radio broadcast stations: AM 4, FM 4, shortwave 0
Radios: NA
Television broadcast stations: 1
Televisions: 19,000 (1993 est.)
Defense
-------
Defense note: defense is the responsibility of the Netherlands
======================================================================
@Ashmore and Cartier Islands
---------------------------
(territory of Australia)
Map
---
Location: 12 14 S, 123 05 E -- Southeastern Asia, islands in the
Indian Ocean, northwest of Australia
Flag
----
Description: the flag of Australia is used
--------------
Telephones: 8.7 million (1987 est.)
Telephone system: good domestic and international service
domestic: domestic satellite system
international: submarine cables to New Zealand, Papua New Guinea,
and Indonesia; satellite earth stations - 10 Intelsat (4 Indian
Ocean and 6 Pacific Ocean), 2 Inmarsat (Indian and Pacific Ocean
Regions)
Radio broadcast stations: AM 258, FM 67, shortwave 0
Radios: NA
Television broadcast stations: 134 (1987 est.)
Televisions: 9.2 million (1992 est.)
Defense
-------
Branches: Australian Army, Royal Australian Navy, Royal Australian
Air Force
Manpower availability:
males age 15-49: 4,848,777
males fit for military service: 4,192,250
males reach military age (17) annually: 127,569 (1996 est.)
Defense expenditures: exchange rate conversion - $7.3 billion,
2.0% of GDP (FY95/96)
======================================================================
@Austria
-------
Map
---
Location: 47 20 N, 13 20 E -- Central Europe, north of Italy
Flag
----
Description: three equal horizontal bands of red (top), white, and
red
--------------
Telephones: 3.47 million (1986 est.)
Telephone system:
domestic: highly developed and efficient
international: satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean) and 2 Eutelsat
Radio broadcast stations: AM 6, FM 21 (repeaters 545), shortwave 0
Radios: NA
Television broadcast stations: 47 (repeaters 870)
Televisions: 2,418,584 (1984 est.)
Defense
-------
Branches: Army (includes Flying Division)
Manpower availability:
males age 15-49: 2,084,827
males fit for military service: 1,741,068
males reach military age (19) annually: 45,628 (1996 est.)
Defense expenditures: exchange rate conversion - $2.1 billion,
1.0% of GDP (1995)
======================================================================
@Azerbaijan
----------
Azerbaijan continues to be plagued by an unresolved eight-year-old
conflict with Armenian separatists over its Nagorno-Karabakh region.
The Karabakh Armenians have declared independence and seized almost
20% of the country''s territory, creating almost 1 million Azeri
refugees in the process. Both sides have generally observed a
Russian-mediated cease-fire in place since May 1994, and support the
OSCE-mediated peace process, now entering its fifth year.
Nevertheless, Baku and Xankandi (Stepanakert, Nagorno-Karabakh
region) remain far apart on most substantive issues from the
placement and composition of a peacekeeping force to the enclave''s
ultimate political status, and prospects for a negotiated settlement
remain dim.
Map
---
Location: 40 30 N, 47 30 E -- Southwestern Asia, bordering the
Caspian Sea, between Iran and Russia
Flag
----
Description: three equal horizontal bands of blue (top), red, and
green; a crescent and eight-pointed star in white are centered in
red band
--------------
Telephones: 710,000 (1991 est.)
Telephone system: 202,000 persons waiting for telephone
installations (January 1991 est.)
domestic: telephone service is of poor quality and inadequate; a
joint venture to establish a cellular telephone system in the Baku
area was supposed to become operational in 1994
international: cable and microwave radio relay connections to former
Soviet republics; connection through Moscow international gateway
switch to other countries; satellite earth stations - 1 Intelsat and
1 Intersputnik (Intelsat provides service to Turkey and through
Turkey to 200 more countries; Intersputnik provides direct service
to New York)
Radio broadcast stations: AM NA, FM NA, shortwave NA (1
state-owned radio broadcast station)
Radios: NA
Television broadcast stations: 2
note: domestic and Russian TV programs are received locally and
Turkish and Iranian TV is received from an Intelsat satellite
through a receive-only earth station
Televisions: NA
Defense
-------
Branches: Army, Navy, Air Force, Maritime Border Guard
Manpower availability:
males age 15-49: 1,952,390
males fit for military service: 1,574,813
males reach military age (18) annually: 68,006 (1996 est.)
Defense expenditures: 33.5 billion manats, NA% of GDP (1994); note
- conversion of defense expenditures into US dollars using the
current exchange rate could produce misleading results
======================================================================
@Bahrain
-------
Map
---
Location: 26 00 N, 50 33 E -- Middle East, archipelago in the
Persian Gulf, east of Saudi Arabia
Flag
----
Description: red with a white serrated band (eight white points)
on the hoist side','ada48364fc5b18b2db16954afb0f2f31c70a206baff30669e39d7fa1c4a872c9','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3232f1af7430b81b5affac313ba7a07fdf4c91342ce0114f96d63d60d536e495',1996,'SA','Saudi Arabia','communications',20,'--------------
Telephones: 73,552 (1987 est.)
Telephone system: modern system; good domestic services and
excellent international connections
domestic: NA
international: tropospheric scatter to Qatar and UAE; microwave
radio relay to Saudi Arabia; submarine cable to Qatar, UAE, and
Saudi Arabia; satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean) and 1 Arabsat
Radio broadcast stations: AM 2, FM 3, shortwave 0
Radios: 320,000 (1993 est.)
Television broadcast stations: 2 (1988 est.)
Televisions: 270,000 (1993 est.)
Defense
-------
Branches: Ground Force, Navy, Air Force, Air Defense, Coast Guard,
Police Force
Manpower availability:
males age 15-49: 213,792
males fit for military service: 118,702 (1996 est.)
Defense expenditures: exchange rate conversion - $247 million,
5.5% of GDP (1994)
======================================================================
@Baker Island
------------
(territory of the US)
Map
---
Location: 0 13 N, 176 31 W -- Oceania, atoll in the North Pacific
Ocean, about one-half of the way from Hawaii to Australia
Flag
----
Description: the flag of the US is used
--------------
Telephones: 249,800 (1994 est.)
Telephone system:
domestic: poor domestic telephone service
international: satellite earth stations - 2 Intelsat (Indian Ocean);
international radiotelephone communications and landline service to
neighboring countries
Radio broadcast stations: AM 9, FM 6, shortwave 0
Radios: NA
Television broadcast stations: 11
Televisions: 350,000 (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, paramilitary forces (includes
Bangladesh Rifles, Bangladesh Ansars, Armed Police Reserve, Village
Defense Parties, National Cadet Corps)
Manpower availability:
males age 15-49: 31,795,848
males fit for military service: 18,814,818 (1996 est.)
Defense expenditures: exchange rate conversion - $481 million,
1.7% of GDP (FY95/96)
======================================================================
@Barbados
--------
Map
---
Location: 13 10 N, 59 32 W -- Caribbean, island between the
Caribbean Sea and the North Atlantic Ocean, northeast of Venezuela
Flag
----
Description: three equal vertical bands of blue (hoist side),
gold, and blue with the head of a black trident centered on the gold
band; the trident head represents independence and a break with the
past (the colonial coat of arms contained a complete trident)
--------------
Telephones: 87,343 (1991 est.)
Telephone system:
domestic: island wide automatic telephone system
international: satellite earth station - 1 Intelsat (Atlantic
Ocean); tropospheric scatter to Trinidad and Saint Lucia
Radio broadcast stations: AM 3, FM 2, shortwave 0
Radios: NA
Television broadcast stations: 2 (1 pay)
Televisions: 69,350 (1993 est.)
Defense
-------
Branches: Royal Barbados Defense Force (includes Ground Forces and
Coast Guard), Royal Barbados Police Force
Manpower availability:
males age 15-49: 71,667
males fit for military service: 49,726 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Bassas da India
---------------
(possession of France)
Map
---
Location: 21 30 S, 39 50 E -- Southern Africa, islands in the
southern Mozambique Channel, about one-half of the way from
Madagascar to Mozambique
Flag
----
Description: the flag of France is used
--------------
Telephones: 1.849 million (1991 est.)
Telephone system: telephone service inadequate for the purposes of
either business or the population; about 70% of the telephones are
in homes; over 750,000 applications from households for telephones
remain unsatisfied (1992 est.); new investment centers on
international connections and business needs
domestic: the new NMT-450 analog cellular system is now operating in
Minsk
international: international traffic is carried by the Moscow
international gateway switch and also by satellite; satellite earth
stations - 1 Intelsat (through Canada) and 1 Eutelsat (through the
UK)
Radio broadcast stations: AM 35, FM 18, shortwave 0
Radios: 3.17 million (1991 est.) (5,615,000 with multiple speaker
systems for program diffusion)
Television broadcast stations: 2 (one national and one private;
the license of the private station was suspended during the
parliamentary elections of 1994)
Televisions: 3.5 million (1992 est.)
Defense
-------
Branches: Army, Air Force, Air Defense Force, Republic Security
Forces (internal and border troops)
Manpower availability:
males age 15-49: 2,635,570
males fit for military service: 2,067,676
males reach military age (18) annually: 76,006 (1996 est.)
Defense expenditures: 892 billion rubels, 1% of GDP (1995); note -
conversion of defense expenditures into US dollars using the current
exchange rate could produce misleading results
======================================================================
@Belgium
-------
Map
---
Location: 50 50 N, 4 00 E -- Western Europe, bordering the North
Sea, between France and the Netherlands
Flag
----
Description: three equal vertical bands of black (hoist side),
yellow, and red; the design was based on the flag of France
--------------
Telephones: 5.691 million (1992 est.)
Telephone system: highly developed, technologically advanced, and
completely automated domestic and international telephone and
telegraph facilities
domestic: nationwide cellular telephone system; extensive cable
network; limited microwave radio relay network
international: 5 submarine cables; satellite earth stations - 2
Intelsat (Atlantic Ocean) and 1 Eutelsat
Radio broadcast stations: AM 3, FM 39, shortwave 0
Radios: 100,000 (1992 est.)
Television broadcast stations: 32 (1987 est.)
Televisions: 3,315,662 (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, National Gendarmerie
Manpower availability:
males age 15-49: 2,571,588
males fit for military service: 2,135,375
males reach military age (19) annually: 61,986 (1996 est.)
Defense expenditures: exchange rate conversion - $4.6 billion,
1.7% of GDP (1995)
======================================================================
@Belize
------
Map
---
Location: 17 15 N, 88 45 W -- Middle America, bordering the
Caribbean Sea, between Guatemala and Mexico
Flag
----
Description: blue with a narrow red stripe along the top and the
bottom edges; centered is a large white disk bearing the coat of
arms; the coat of arms features a shield flanked by two workers in
front of a mahogany tree with the related motto SUB UMBRA FLOREO (I
Flourish in the Shade) on a scroll at the bottom, all encircled by a
green garland
--------------
Telephones: 15,917 (1990 est.)
Telephone system: above-average system
domestic: trunk network depends primarily on microwave radio relay
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 6, FM 5, shortwave 1
Radios: NA
Television broadcast stations: 1
Televisions: 27,048 (1993 est.)
Defense
-------
Branches: Belize Defense Force (includes Army, Navy, Air Force,
and Volunteer Guard), Belize National Police
Manpower availability:
males age 15-49: 52,290
males fit for military service: 31,086
males reach military age (18) annually: 2,390 (1996 est.)
Defense expenditures: exchange rate conversion - $8.1 million, NA%
of GDP (FY95/96)
======================================================================
@Benin
-----
Map
---
Location: 9 30 N, 2 15 E -- Western Africa, bordering the North
Atlantic Ocean, between Nigeria and Togo
Flag
----
Description: two equal horizontal bands of yellow (top) and red
with a vertical green band on the hoist side
--------------
Telephones: 160,717 (1992 est.)
Telephone system: modern system centered in Doha
domestic: NA
international: tropospheric scatter to Bahrain; microwave radio
relay to Saudi Arabia and UAE; submarine cable to Bahrain and UAE;
satellite earth stations - 2 Intelsat (1 Atlantic Ocean and 1 Indian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 2, FM 3, shortwave 0
Radios: 201,000 (1992 est.)
Television broadcast stations: 3 (1988 est.)
Televisions: 205,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, Public Security
Manpower availability:
males age 15-49: 220,635
males fit for military service: 115,403
males reach military age (18) annually: 4,115 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Reunion
-------
(overseas department of France)
Map
---
Location: 21 06 S, 55 36 E -- Southern Africa, island in the
Indian Ocean, east of Madagascar
Flag
----
Description: the flag of France is used','a245e0311cffe388a46f3f6beea559e53bc52cdf1a6d12350c313228cf9361df','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c60149fd4a4f859c68fa3965ff79a8ebd6d1a141feb2e67a20f6d56c3d0376a6',1996,'HK','Hong Kong','communications',24,'--------------
Telephones: 16,200 (1986 est.)
Telephone system:
domestic: fair system of open wire and microwave radio relay
international: satellite earth station - 1 Intelsat (Atlantic
Ocean); submarine cable
Radio broadcast stations: AM 2, FM 2, shortwave 0
Radios: NA
Television broadcast stations: 2
Televisions: 20,000 (1993 est.)
Defense
-------
Branches: Armed Forces (includes Army, Navy, Air Force), National
Gendarmerie
Manpower availability:
males age 15-49: 1,212,440
females age 15-49: 1,290,773
males fit for military service: 620,923
females fit for military service: 653,094
males reach military age (18) annually: 62,526
females reach military age (18) annually: 60,968 (1996 est.)
note: both sexes are liable for military service
Defense expenditures: exchange rate conversion - $33 million, 3.2%
of GDP (1994)
======================================================================
@Bermuda
-------
(dependent territory of the UK)
Map
---
Location: 32 20 N, 64 45 W -- North America, group of islands in
the North Atlantic Ocean, east of North Carolina (US)
Flag
----
Description: red with the flag of the UK in the upper hoist-side
quadrant and the Bermudian coat of arms (white and blue shield with
a red lion holding a scrolled shield showing the sinking of the ship
Sea Venture off Bermuda in 1609) centered on the outer half of the
flag
--------------
Telephones: 54,000 (1991 est.)
Telephone system:
domestic: modern, fully automatic telephone system
international: 3 submarine cables; satellite earth stations - 2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 3, shortwave 0
Radios: 78,000 (1992 est.)
Television broadcast stations: 2
Televisions: 57,000 (1992 est.)
Defense
-------
Branches: Bermuda Regiment, Bermuda Police Force, Bermuda Reserve
Constabulary
Defense expenditures: $NA, NA% of GDP
Defense note: defense is the responsibility of the UK
======================================================================
@Bhutan
------
Map
---
Location: 27 30 N, 90 30 E -- Southern Asia, between China and','42f7a422c324bdedd396e7fcc2da676a567b805e1b332835230c51e3ae815434','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4502cd5a159c2c474a77bdc0b05e71f8626450afaa58b19ab440b19200075824',1996,'IN','India','communications',29,'Flag
----
Description: divided diagonally from the lower hoist side corner;
the upper triangle is yellow and the lower triangle is orange;
centered along the dividing line is a large black and white dragon
facing away from the hoist side
--------------
Telephones: 4,620 (1991 est.)
Telephone system:
domestic: domestic telephone service is very poor with very few
telephones in use
international: international telephone and telegraph service is by
landline through India; a satellite earth station was planned (1990)
Radio broadcast stations: AM 1, FM 1, shortwave 0 (1990)
Radios: 23,000 (1989 est.)
Television broadcast stations: 0 (1990 est.)
Televisions: 200 (1985 est.)
Defense
-------
Branches: Royal Bhutan Army, Palace Guard, Militia
Manpower availability:
males age 15-49: 444,875
males fit for military service: 237,529
males reach military age (18) annually: 17,634 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Bolivia
-------
Map
---
Location: 17 00 S, 65 00 W -- Central South America, southwest of
--------------
Telephones: 8,523 (1992 est.)
Telephone system: minimal domestic and international facilities
domestic: NA
international: satellite earth station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 2, FM 1, shortwave 0
Radios: 28,284 (1992 est.)
Television broadcast stations: 1
Televisions: 7,309 (1992 est.)
Defense
-------
Branches: National Security Service (paramilitary police force)
Manpower availability:
males age 15-49: 59,179
males fit for military service: 33,016 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Mali
----
Map
---
Location: 17 00 N, 4 00 W -- Western Africa, southwest of Algeria
Flag
----
Description: three equal vertical bands of green (hoist side),
yellow, and red; uses the popular pan-African colors of Ethiopia
--------------
Telephones: 11,000 (1982 est.)
Telephone system: domestic system poor but improving; provides
only minimal service
domestic: network consists of microwave radio relay, open wire, and
radiotelephone communications stations; expansion of microwave radio
relay in progress
international: satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean)
Radio broadcast stations: AM 2, FM 2, shortwave 0
Radios: 430,000 (1992 est.)
Television broadcast stations: 2 (1987 est.)
Televisions: 11,000 (1992 est.)
Defense
-------
Branches: Army, Air Force, Gendarmerie, Republican Guard, National
Guard, National Police (Surete Nationale)
Manpower availability:
males age 15-49: 1,925,205
males fit for military service: 1,100,599 (1996 est.)
Defense expenditures: exchange rate conversion - $66 million, 2.2%
of GDP (1994)
======================================================================
@Malta
-----
Map
---
Location: 35 50 N, 14 35 E -- Southern Europe, islands in the
Mediterranean Sea, south of Sicily (Italy)
Flag
----
Description: two equal vertical bands of white (hoist side) and
red; in the upper hoist-side corner is a representation of the
George Cross, edged in red
--------------
Telephones: 41,000 (1995)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 1, FM 4, shortwave 0
Radios: NA
Television broadcast stations: 4
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the UK
======================================================================
@Marshall Islands
----------------
Map
---
Location: 9 00 N, 168 00 E -- Oceania, group of atolls and reefs
in the North Pacific Ocean, about one-half of the way from Hawaii to
--------------
Telephones: 82,774 (1995 est.)
Telephone system: poor telephone and telegraph service; fair
radiotelephone communication service
domestic: NA
international: radiotelephone communications; satellite earth
station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 88, FM 0, shortwave 0
Radios: 690,000 (1992 est.)
Television broadcast stations: 1 (1988 est.)
Televisions: 45,000 (1992 est.)
Defense
-------
Branches: Royal Nepalese Army, Royal Nepalese Army Air Service,
Nepalese Police Force
Manpower availability:
males age 15-49: 5,329,345
males fit for military service: 2,768,887
males reach military age (17) annually: 254,590 (1996 est.)
Defense expenditures: exchange rate conversion - $36 million, 1.2%
of GDP (FY92/93)
======================================================================
@Netherlands
-----------
Map
---
Location: 52 30 N, 5 45 E -- Western Europe, bordering the North
Sea, between Belgium and Germany
Flag
----
Description: three equal horizontal bands of red (top), white, and
blue; similar to the flag of Luxembourg, which uses a lighter blue
and is longer
--------------
Telephones: 8.272 million (1983 est.)
Telephone system: highly developed and well maintained; extensive
redundant system of multiconductor cables, supplemented by microwave
radio relay
domestic: nationwide cellular telephone system; microwave radio relay
international: 5 submarine cables; satellite earth stations - 3
Intelsat (1 Indian Ocean and 2 Atlantic Ocean), 1 Eutelsat, and 1
Inmarsat (Atlantic and Indian Ocean Regions)
Radio broadcast stations: AM 3 (relays 3), FM 12 (repeaters 39),
shortwave 0
Radios: 13.755 million (1992 est.)
Television broadcast stations: 8 (repeaters 7)
Televisions: 7.4 million (1992 est.)
Defense
-------
Branches: Royal Netherlands Army, Royal Netherlands Navy (includes
Naval Air Service and Marine Corps), Royal Netherlands Air Force,
Royal Constabulary
Manpower availability:
males age 15-49: 4,191,998
males fit for military service: 3,670,253
males reach military age (20) annually: 94,013 (1996 est.)
Defense expenditures: exchange rate conversion - $8.2 billion,
2.1% of GDP (1995)
======================================================================
@Netherlands Antilles
--------------------
(part of the Dutch realm)
Map
---
Location: 12 15 N, 68 45 W -- Caribbean, two island groups in the
Caribbean Sea - one includes Curacao and Bonaire north of Venezuela
and the other is east of the Virgin Islands
Flag
----
Description: white with a horizontal blue stripe in the center
superimposed on a vertical red band also centered; five white
five-pointed stars are arranged in an oval pattern in the center of
the blue band; the five stars represent the five main islands of
Bonaire, Curacao, Saba, Sint Eustatius, and Sint Maarten
--------------
Telephones: NA
Telephone system: generally adequate facilities
domestic: extensive interisland microwave radio relay links
international: 2 submarine cables; satellite earth stations - 2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 9, FM 4, shortwave 0
Radios: 205,000 (1992 est.)
Television broadcast stations: 1
Televisions: 64,000 (1992 est.)
Defense
-------
Branches: Royal Netherlands Navy, Marine Corps, Royal Netherlands
Air Force, National Guard, Police Force
Defense note: defense is the responsibility of the Netherlands
======================================================================
@New Caledonia
-------------
(overseas territory of France)
Map
---
Location: 21 30 S, 165 30 E -- Oceania, islands in the South
Pacific Ocean, east of Australia
Flag
----
Description: three horizontal bands, blue (top), red, and green,
with a yellow disk enclosing a black symbol centered to the hoist
side; the flag of France is used for official occasions','9f552da6d5fccbf0479fc4eef67d242ed4c46c5280424f81292f20b88906019a','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f98d0e662d6303e398543b1d062c3de3d799b8f4b78dda08740db7fb0a0eed21',1996,'BR','Brazil','communications',36,'Flag
----
Description: three equal horizontal bands of red (top), yellow,
and green with the coat of arms centered on the yellow band; similar
to the flag of Ghana, which has a large black five-pointed star
centered in the yellow band
--------------
Telephones: 144,300 (1987 est.)
Telephone system: new subscribers face bureaucratic difficulties;
most telephones are concentrated in La Paz and other cities
domestic: microwave radio relay system being expanded
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 129, FM 0, shortwave 68
Radios: NA
Television broadcast stations: 43
Televisions: 500,000 (1993 est.)
Defense
-------
Branches: Army (Ejercito Boliviano), Navy (Fuerza Naval Boliviana,
includes Marines), Air Force (Fuerza Aerea Boliviana), National
Police Force (Policia Nacional de Bolivia)
Manpower availability:
males age 15-49: 1,685,572
males fit for military service: 1,098,948
males reach military age (19) annually: 76,035 (1996 est.)
Defense expenditures: exchange rate conversion - $145 million;
1.9% of GDP (1996)
======================================================================
@Bosnia and Herzegovina
----------------------
On 21 November 1995, in Dayton, Ohio, the former Yugoslavia''s three
warring parties signed a peace agreement that brought to a halt over
three years of interethnic civil strife in Bosnia and Herzegovina
(the final agreement was signed in Paris on 14 December 1995). The
Dayton Agreement, signed by Bosnian President IZETBEGOVIC, Croatian
President TUDJMAN, and Serbian President MILOSEVIC, divides Bosnia
and Herzegovina roughly equally between the Muslim/Croat Federation
and the Bosnian Serbs while maintaining Bosnia''s currently
recognized borders. An international peacekeeping force (IFOR) of
60,000 troops began to enter Bosnia in late 1995 to implement and
monitor the military aspects of the agreement and is scheduled to
depart the country within one year. A High Representative appointed
by the UN Security Council is responsible for civilian
implementation of the accord, including monitoring implementation,
facilitating any difficulties arising in connection with civilian
implementation, and coordinating activities of the civilian
organizations and agencies in Bosnia and Herzegovina. The Bosnian
conflict began in the spring of 1992 when the Government of Bosnia
and Herzegovina held a referendum on independence and the Bosnian
Serbs - supported by neighboring Serbia - responded with armed
resistance aimed at partitioning the republic along ethnic lines and
joining Serb-held areas to form a "greater Serbia." In March 1994,
Bosnia''s Muslims and Croats reduced the number of warring factions
from three to two by signing an agreement in Washington creating
their joint Muslim/Croat Federation of Bosnia and Herzegovina.
Map
---
Location: 44 00 N, 18 00 E -- Southeastern Europe, bordering the
Adriatic Sea and Croatia
Flag
----
Description: white with a large blue shield; the shield contains
white fleurs-de-lis with a white diagonal band running from the
upper hoist corner to the lower outer side
--------------
Telephones: 88,730 (1985 est.)
Telephone system: meager telephone service; principal switching
center is Asuncion
domestic: fair microwave radio relay network
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 40, FM 0, shortwave 7
Radios: 775,000 (1992 est.)
Television broadcast stations: 5
Televisions: 370,000 (1992 est.)
Defense
-------
Branches: Army, Navy (includes Naval Air and Marines), Air Force
Manpower availability:
males age 15-49: 1,334,638
males fit for military service: 968,297
males reach military age (17) annually: 58,398 (1996 est.)
Defense expenditures: exchange rate conversion - $94 million, 0.6%
of GDP (1994)
======================================================================
@Peru
----
Map
---
Location: 10 00 S, 76 00 W -- Western South America, bordering the
South Pacific Ocean, between Chile and Ecuador
Flag
----
Description: three equal, vertical bands of red (hoist side),
white, and red with the coat of arms centered in the white band; the
coat of arms features a shield bearing a llama, cinchona tree (the
source of quinine), and a yellow cornucopia spilling out gold coins,
all framed by a green wreath
--------------
Telephones: 779,306 (1990 est.)
Telephone system: adequate for most requirements
domestic: nationwide microwave radio relay system and a domestic
satellite system with 12 earth stations
international: satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 273, FM 0, shortwave 144
Radios: 5.7 million (1992 est.)
Television broadcast stations: 140
Televisions: 2 million (1993 est.)
Defense
-------
Branches: Army (Ejercito Peruano), Navy (Marina de Guerra del
Peru; includes Naval Air, Marines, and Coast Guard), Air Force
(Fuerza Aerea del Peru), National Police
Manpower availability:
males age 15-49: 6,441,513
males fit for military service: 4,347,460
males reach military age (20) annually: 255,067 (1996 est.)
Defense expenditures: exchange rate conversion - $998 million,
1.6% of GDP (1996)
======================================================================
@Philippines
-----------
Map
---
Location: 13 00 N, 122 00 E -- Southeastern Asia, archipelago
between the Philippine Sea and the South China Sea, east of Vietnam
Flag
----
Description: two equal horizontal bands of blue (top) and red with
a white equilateral triangle based on the hoist side; in the center
of the triangle is a yellow sun with eight primary rays (each
containing three individual rays) and in each corner of the triangle
is a small yellow five-pointed star
--------------
Telephones: 887,229 (1993 est.)
Telephone system: good international radiotelephone and submarine
cable services; domestic and interisland service adequate
domestic: domestic satellite system with 11 earth stations
international: submarine cables to Hong Kong, Guam, Singapore,
Taiwan, and Japan; satellite earth stations - 3 Intelsat (1 Indian
Ocean and 2 Pacific Ocean)
Radio broadcast stations: AM 261, FM 55, shortwave 0
Radios: 9.03 million (1992 est.)
Television broadcast stations: 29
Televisions: 7 million (1993 est.)
Defense
-------
Branches: Army, Navy (includes Coast Guard and Marine Corps), Air
Force
Manpower availability:
males age 15-49: 18,722,509
males fit for military service: 13,221,513
males reach military age (20) annually: 767,056 (1996 est.)
Defense expenditures: exchange rate conversion - $1 billion, 1.4%
of GDP (1995)
======================================================================
@Pitcairn Islands
----------------
(dependent territory of the UK)
Map
---
Location: 25 04 S, 130 06 W -- Oceania, islands in the South
Pacific Ocean, about one-half of the way from Peru to New Zealand
Flag
----
Description: blue with the flag of the UK in the upper hoist-side
quadrant and the Pitcairn Islander coat of arms centered on the
outer half of the flag; the coat of arms is yellow, green, and light
blue with a shield featuring a yellow anchor
--------------
Telephones: 24
Telephone system: party line telephone service on the island
domestic: NA
international: radiotelephone
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 0
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the UK
======================================================================
@Poland
------
Map
---
Location: 52 00 N, 20 00 E -- Central Europe, east of Germany
Flag
----
Description: two equal horizontal bands of white (top) and red;
similar to the flags of Indonesia and Monaco which are red (top) and
white
--------------
Telephones: 5 million (1994)
Telephone system: underdeveloped and outmoded system; government
aims to have 10 million phones in service by the year 2000
domestic: cable, open wire, and microwave radio relay
international: satellite earth stations - NA Intelsat, NA Eutelsat,
1 Inmarsat (Atlantic and Indian Ocean Regions), and 1 Intersputnik
(Atlantic Ocean Region)
Radio broadcast stations: AM 27, FM 27, shortwave 0
Radios: 10.9 million (1993 est.)
Television broadcast stations: 40 (Russian repeaters 5)
Televisions: 9.6 million
Defense
-------
Branches: Army, Navy, Air and Air Defense Force
Manpower availability:
males age 15-49: 10,267,551
males fit for military service: 7,994,460
males reach military age (19) annually: 324,960 (1996 est.)
Defense expenditures: exchange rate conversion - $2.4 billion,
2.4% of GDP (1995)
======================================================================
@Portugal
--------
Map
---
Location: 39 30 N, 8 00 W -- Southwestern Europe, bordering the
North Atlantic Ocean, west of Spain
Flag
----
Description: two vertical bands of green (hoist side, two-fifths)
and red (three-fifths) with the Portuguese coat of arms centered on
the dividing line
--------------
Telephones: 2,236,411 (1993 est.)
Telephone system:
domestic: generally adequate integrated network of coaxial cables,
open wire, microwave radio relay, and domestic satellite earth
stations
international: 6 submarine cables; satellite earth stations - 3
Intelsat (2 Atlantic Ocean and 1 Indian Ocean), NA Eutelsat;
tropospheric scatter to Azores; note - an earth station for Inmarsat
(Atlantic Ocean Region) is planned
Radio broadcast stations: AM 57, FM 66 (repeaters 22), shortwave 0
Radios: 2.2 million (1993 est.)
Television broadcast stations: 66 (repeaters 23)
Televisions: 2,970,892 (1993 est.)
Defense
-------
Branches: Army, Navy (includes Marines), Air Force, National
Republican Guard, Fiscal Guard, Public Security Police
Manpower availability:
males age 15-49: 2,498,965
males fit for military service: 2,014,653
males reach military age (20) annually: 83,427 (1996 est.)
Defense expenditures: exchange rate conversion - $1.9 billion,
2.4% of GDP (1995)
======================================================================
@Puerto Rico
-----------
(commonwealth associated with the US)
Map
---
Location: 18 15 N, 66 30 W -- Caribbean, island between the
Caribbean Sea and the North Atlantic Ocean, east of the Dominican
Republic
Flag
----
Description: five equal horizontal bands of red (top and bottom)
alternating with white; a blue isosceles triangle based on the hoist
side bears a large white five-pointed star in the center; design
based on the US flag
--------------
Telephones: 1,166,231 (1992 est.)
Telephone system: modern system, integrated with that of the US by
high-capacity submarine cable and Intelsat with high-speed data
capability
domestic: digital telephone system with about 1 million lines (1990
est.); cellular telephone service
international: satellite earth station - 1 Intelsat; submarine cable
to US
Radio broadcast stations: AM 50, FM 63, shortwave 0
Radios: 2.565 million (1992 est.)
Television broadcast stations: 9
note: cable television available with US programs (1990 est.)
Televisions: 952,000 (1992 est.)
Defense
-------
Branches: paramilitary National Guard, Police Force
Defense note: defense is the responsibility of the US
======================================================================
@Qatar
-----
Map
---
Location: 25 30 N, 51 15 E -- Middle East, peninsula bordering the
Persian Gulf and Saudi Arabia
Flag
----
Description: maroon with a broad white serrated band (nine white
points) on the hoist side','d686a4dbaf01f6aeed5aafa057b406b1cefcecec63db95a7178f976bc0fa152f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f886616c5f1afc02e07490d343b5e54090cebea3c51456ee6f4839e9980f093f',1996,'HR','Croatia','communications',50,'--------------
Telephones: 727,000
Telephone system: telephone and telegraph network is in need of
modernization and expansion; many urban areas are below average when
compared with services in other former Yugoslav republics
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM 9, FM 2, shortwave 0
Radios: 840,000
Television broadcast stations: 6
Televisions: 1,012,094
Defense
-------
Branches: Army
Manpower availability:
males age 15-49: 654,326
males fit for military service: 524,963
males reach military age (19) annually: 22,902 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Botswana
--------
Map
---
Location: 22 00 S, 24 00 E -- Southern Africa, north of South
Africa
Flag
----
Description: light blue with a horizontal white-edged black stripe
in the center
--------------
Telephones: 19,109 (1985 est.)
Telephone system: sparse system
domestic: small system of open-wire lines, microwave radio relay
links, and a few radiotelephone communication stations
international: microwave radio relay links to Zambia, Zimbabwe and
South Africa; satellite earth station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 7, FM 13, shortwave 0
Radios: NA
Television broadcast stations: 0 (1988 est.)
Televisions: 13,800 (1993 est.)
Defense
-------
Branches: Botswana Defense Force (includes Army and Air Wing),
Botswana National Police
Manpower availability:
males age 15-49: 334,177
males fit for military service: 175,471
males reach military age (18) annually: 17,088 (1996 est.)
Defense expenditures: exchange rate conversion - $199 million,
5.2% of GDP (FY93/94)
======================================================================
@Bouvet Island
-------------
(territory of Norway)
Map
---
Location: 54 26 S, 3 24 E -- Southern Africa, island in the South
Atlantic Ocean, south-southwest of the Cape of Good Hope (South
Africa)
Flag
----
Description: the flag of Norway is used
--------------
Communications note: automatic meteorological station
Defense
-------
Defense note: defense is the responsibility of Norway
======================================================================
@Brazil
------
Map
---
Location: 10 00 S, 55 00 W -- Eastern South America, bordering the
Atlantic Ocean
Flag
----
Description: green with a large yellow diamond in the center
bearing a blue celestial globe with 27 white five-pointed stars (one
for each state and the Federal District) arranged in the same
pattern as the night sky over Brazil; the globe has a white
equatorial band with the motto ORDEM E PROGRESSO (Order and Progress)
--------------
Telephones: 14,426,673 (1992 est.)
Telephone system: good working system
domestic: extensive microwave radio relay system and a domestic
satellite system with 64 earth stations
international: 3 coaxial submarine cables; satellite earth stations
- 3 Intelsat (Atlantic Ocean), 1 Inmarsat (Atlantic Ocean Region
East)
Radio broadcast stations: AM 1,223, FM 0, shortwave 151
Radios: 60 million (1993 est.)
Television broadcast stations: 112
note: Brazil has the world''s fourth largest television broadcasting
system
Televisions: 30 million (1993 est.)
======================================================================
@British Indian Ocean Territory
------------------------------
(dependent territory of the UK)
Map
---
Location: 6 00 S, 71 30 E -- Southern Asia, archipelago in the
Indian Ocean, about one-half the way from Africa to Indonesia
Flag
----
Description: white with the flag of the UK in the upper hoist-side
quadrant and six blue wavy horizontal stripes bearing a palm tree
and yellow crown centered on the outer half of the flag','827829d280fbfff3dd70937b7bcac795189986bdd7712f26ff392936e4be968d','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f8da297134407bb67d3d4134de2bb068ffd9cc71ae56fae886b68e6d64ffd99',1996,'MU','Mauritius','communications',57,'--------------
Telephones: NA
Telephone system: facilities for military needs only
domestic: NA
international: NA
Radio broadcast stations: AM 1, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 1
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the UK
======================================================================
@British Virgin Islands
----------------------
(dependent territory of the UK)
Map
---
Location: 18 30 N, 64 30 W -- Caribbean, between the Caribbean Sea
and the North Atlantic Ocean, east of Puerto Rico
Flag
----
Description: blue with the flag of the UK in the upper hoist-side
quadrant and the Virgin Islander coat of arms centered in the outer
half of the flag; the coat of arms depicts a woman flanked on either
side by a vertical column of six oil lamps above a scroll bearing
the Latin word VIGILATE (Be Watchful)','503222cf9f23378d29014143b2dc84299c0931b2d0389b362e2e3fc21d07748e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29e018cb501f56188243a42d27fde6275f13a05a0d5fe87001c5eb18010cab03',1996,'PR','Puerto Rico','communications',62,'--------------
Telephones: 6,291 (1990 est.)
Telephone system: worldwide telephone service
domestic: NA
international: submarine cable to Bermuda
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 9,000 (1992 est.)
Television broadcast stations: 1
Televisions: 4,000 (1992 est.)
Defense
-------
Defense note: defense is the responsibility of the UK
======================================================================
@Brunei
------
Map
---
Location: 4 30 N, 114 40 E -- Southeastern Asia, bordering the
South China Sea and Malaysia
Flag
----
Description: yellow with two diagonal bands of white (top, almost
double width) and black starting from the upper hoist side; the
national emblem in red is superimposed at the center; the emblem
includes a swallow-tailed flag on top of a winged column within an
upturned crescent above a scroll and flanked by two upraised hands
--------------
Telephones: 3,000
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 8, FM 4, shortwave 0
Radios: 6,000 (1992 est.)
Television broadcast stations: 1
Televisions: 2,000 (1992 est.)
Defense
-------
Branches: Police Force
Defense note: defense is the responsibility of the UK
======================================================================
@Morocco
-------
Map
---
Location: 32 00 N, 5 00 W -- Northern Africa, bordering the North
Atlantic Ocean and the Mediterranean Sea, between Algeria and','e46bf0b7921bbe7a2a37b4eb2e52bf8cffe9d614344cb3007468b1d025ad7742','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee5afb60a50f18b0dcb74df70a3ab5cab463ff24820cf387f9c9e7aa46f5e300',1996,'MY','Malaysia','communications',70,'--------------
Telephones: 76,900 (1993)
Telephone system: service throughout country is adequate for
present needs; international service good to adjacent Malaysia
domestic: NA
international: satellite earth stations - 2 Intelsat (1 Indian Ocean
and 1 Pacific Ocean)
Radio broadcast stations: AM 4, FM 4, shortwave 0
Radios: 115,000 (1993)
Television broadcast stations: 1 (1984 est.)
Televisions: 78,000 (1993 est.)
Defense
-------
Branches: Land Forces, Navy, Air Force, Royal Brunei Police
Manpower availability:
males age 15-49: 83,641
males fit for military service: 48,559
males reach military age (18) annually: 2,918 (1996 est.)
Defense expenditures: exchange rate conversion - $312 million,
6.2% of GDP (1994)
======================================================================
@Bulgaria
--------
Map
---
Location: 43 00 N, 25 00 E -- Southeastern Europe, bordering the
Black Sea, between Romania and Turkey
Flag
----
Description: three equal horizontal bands of white (top), green,
and red; the national emblem formerly on the hoist side of the white
stripe has been removed - it contained a rampant lion within a
wreath of wheat ears below a red five-pointed star and above a
ribbon bearing the dates 681 (first Bulgarian state established) and
1944 (liberation from Nazi control)
--------------
Telephones: 2,773,293 (1993 est.)
Telephone system: almost two-thirds of the lines are residential;
67% of Sofia households have telephones (November 1988 est.)
domestic: extensive but antiquated transmission system of coaxial
cable and microwave radio relay; telephone service is available in
most villages
international: direct dialing to 36 countries; satellite earth
stations - 1 Intersputnik (Atlantic Ocean Region); Intelsat
available through a Greek earth station
Radio broadcast stations: AM 20, FM 15, shortwave 0
Radios: NA
Television broadcast stations: 29 (Russian repeater in Sofia 1)
Televisions: 2.1 million (May 1990 est.)
Defense
-------
Branches: Army, Navy, Air and Air Defense Forces, Border Troops,
Internal Troops
Manpower availability:
males age 15-49: 2,155,332
males fit for military service: 1,797,318
males reach military age (19) annually: 64,568 (1996 est.)
Defense expenditures: exchange rate conversion - $352 million,
2.5% of GDP (1995)
======================================================================
@Burkina Faso
------------
Map
---
Location: 13 00 N, 2 00 W -- Western Africa, north of Ghana
Flag
----
Description: two equal horizontal bands of red (top) and green
with a yellow five-pointed star in the center; uses the popular
pan-African colors of Ethiopia
--------------
Telephones: 80,900 (1987 est.)
Telephone system: facilities are among the best in Sub-Saharan
Africa
domestic: high-capacity microwave radio relay connects most larger
towns and cities
international: satellite earth stations - 2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean)
Radio broadcast stations: AM 11, FM 5, shortwave 0
Radios: 1,889,140
Television broadcast stations: 9
Televisions: 215,000 (1995 est.)
Defense
-------
Branches: Army, Air Force, paramilitary forces, Police
Manpower availability:
males age 15-49: 1,934,845
males fit for military service: 1,020,851 (1996 est.)
Defense expenditures: exchange rate conversion - $96 million, 2.7%
of GDP (1995)
======================================================================
@Zimbabwe
--------
Map
---
Location: 20 00 S, 30 00 E -- Southern Africa, northeast of','791ed70e86a776ba153111e07c1fa2b7d139ca49a5a2a80cd3969c949a3c1906','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f2361b4119250742b24abf943c51ba849f4c702b58713d4205a88e8abac9458',1996,'NE','Niger','communications',79,'--------------
Telephones: 21,000 (1993 est.)
Telephone system: all services only fair
domestic: microwave radio relay, open wire, and radiotelephone
communication stations
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 2, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 2 (1987 est.)
Televisions: 49,000 (1991 est.)
Defense
-------
Branches: Army, Air Force, National Gendarmerie, National Police,
People''s Militia
Manpower availability:
males age 15-49: 2,149,485
males fit for military service: 1,101,184 (1996 est.)
Defense expenditures: exchange rate conversion - $104 million,
6.4% of GDP (1994)
======================================================================
@Burma
-----
Map
---
Location: 22 00 N, 98 00 E -- Southeastern Asia, bordering the
Andaman Sea and the Bay of Bengal, between Bangladesh and Thailand
Flag
----
Description: red with a blue rectangle in the upper hoist-side
corner bearing, all in white, 14 five-pointed stars encircling a
cogwheel containing a stalk of rice; the 14 stars represent the 14
administrative divisions
--------------
Telephones: 122,195 (1993 est.)
Telephone system: meets minimum requirements for local and
intercity service for business and government; international service
is good
domestic: NA
international: satellite earth station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 2, FM 1, shortwave 0 (1985 est.)
note: radiobroadcast coverage is limited to the most populous areas
Radios: NA
Television broadcast stations: 1 (1988 est.)
Televisions: 88,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force
Manpower availability:
males age 15-49: 11,759,636
females age 15-49: 11,588,181
males fit for military service: 6,291,986
females fit for military service: 6,184,667
males reach military age (18) annually: 473,255
females reach military age (18) annually: 454,786 (1996 est.)
note: both sexes liable for military service
Defense expenditures: exchange rate conversion - $135 million, NA%
of GDP (FY95/96)
======================================================================
@Burundi
-------
Map
---
Location: 3 30 S, 30 00 E -- Central Africa, east of Zaire
Flag
----
Description: divided by a white diagonal cross into red panels
(top and bottom) and green panels (hoist side and outer side) with a
white disk superimposed at the center bearing three red six-pointed
stars outlined in green arranged in a triangular design (one star
above, two stars below)
--------------
Telephones: 7,200 (1987 est.)
Telephone system: primitive system
domestic: sparse system of open wire, radiotelephone communications,
and low-capacity microwave radio relay
international: satellite earth station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 2, FM 2, shortwave 0
Radios: NA
Television broadcast stations: 1
Televisions: 4,500 (1993 est.)
Defense
-------
Branches: Army (includes naval and air units), paramilitary
Gendarmerie
Manpower availability:
males age 15-49: 1,312,458
males fit for military service: 683,073
males reach military age (16) annually: 67,990 (1996 est.)
Defense expenditures: exchange rate conversion - $25 million, 2.6%
of GDP (1993)
======================================================================
@Cambodia
--------
Map
---
Location: 13 00 N, 105 00 E -- Southeastern Asia, bordering the
Gulf of Thailand, between Thailand and Vietnam
Flag
----
Description: three horizontal bands of blue (top), red (double
width), and blue with a white three-towered temple representing
Angkor Wat outlined in black in the center of the red band
--------------
Telephones: 7,000 (1981 est.)
Telephone system: service barely adequate for government
requirements and virtually nonexistent for general public
domestic: NA
international: landline international service limited to Vietnam and
other adjacent countries; satellite earth station - 1 Intersputnik
(Indian Ocean Region)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 1 (1986 est.)
Televisions: 70,000 (1993 est.)
Defense
-------
Branches:
Khmer Royal Armed Forces (KRAF): created in 1993 by the merger of
the Cambodian People''s Armed Forces and the two noncommunist
resistance armies; note - the KRAF is also known as the Royal
Cambodian Armed Forces (RCAF)
Resistance forces: National Army of Democratic Kampuchea (Khmer
Rouge)
Manpower availability:
males age 15-49: 2,336,606
males fit for military service: 1,302,234
males reach military age (18) annually: 79,514 (1996 est.)
Defense expenditures: exchange rate conversion - $85 million, 1.4%
of GDP (1995)
======================================================================
@Cameroon
--------
Map
---
Location: 6 00 N, 12 00 E -- Western Africa, bordering the North
Atlantic Ocean, between Equatorial Guinea and Nigeria
Flag
----
Description: three equal vertical bands of green (hoist side),
red, and yellow with a yellow five-pointed star centered in the red
band; uses the popular pan-African colors of Ethiopia
--------------
Telephones: 36,737 (1991 est.)
Telephone system: available only to business and government
domestic: cable, microwave radio relay, and tropospheric scatter
international: satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 11, FM 11, shortwave 0
Radios: 2 million (1993 est.)
Television broadcast stations: 1 (1995)
Televisions: NA
Defense
-------
Branches: Army, Navy (includes Naval Infantry), Air Force,
National Gendarmerie, Presidential Guard
Manpower availability:
males age 15-49: 3,112,339
males fit for military service: 1,572,150
males reach military age (18) annually: 151,300 (1996 est.)
Defense expenditures: exchange rate conversion - $102 million, NA%
of GDP (FY93/94)
======================================================================
@Canada
------
Map
---
Location: 60 00 N, 95 00 W -- Northern North America, bordering
the North Atlantic Ocean and North Pacific Ocean, north of the
conterminous US
Flag
----
Description: three vertical bands of red (hoist side), white
(double width, square), and red with a red maple leaf centered in
the white band
--------------
Telephones: 15.3 million (1990)
Telephone system: excellent service provided by modern technology
domestic: domestic satellite system with about 300 earth stations
international: 5 coaxial submarine cables; satellite earth stations
- 5 Intelsat (4 Atlantic Ocean and 1 Pacific Ocean) and 2
Intersputnik (Atlantic Ocean Region)
Radio broadcast stations: AM 900, FM 29, shortwave 0
Radios: NA
Television broadcast stations: 70 (repeaters 1,400) (1991)
Televisions: 11.53 million (1983 est.)
Defense
-------
Branches: Canadian Armed Forces (includes Land Forces Command or
LC, Maritime Command or MC, Air Command or AC, Communications
Command or CC, Training Command or TC), Royal Canadian Mounted
Police (RCMP)
Manpower availability:
males age 15-49: 7,645,245
males fit for military service: 6,575,057
males reach military age (17) annually: 197,688 (1996 est.)
Defense expenditures: exchange rate conversion - $9.0 billion,
1.6% of GDP (FY95/96)
======================================================================
@Cape Verde
----------
Map
---
Location: 16 00 N, 24 00 W -- Western Africa, group of Islands in
the North Atlantic Ocean, west of Senegal
Flag
----
Description: three horizontal bands of light blue (top, double
width), white (with a horizontal red stripe in the middle third),
and light blue; a circle of 10 yellow five-pointed stars is centered
on the hoist end of the red stripe and extends into the upper and
lower blue bands
--------------
Telephones: 1,740 (1987 est.)
Telephone system:
domestic: interisland microwave radio relay system
international: 2 coaxial submarine cables; HF radiotelephone to
Senegal and Guinea-Bissau; satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1, FM 6, shortwave 0
Radios: NA
Television broadcast stations: 1 (1987 est.)
Televisions: 7,000 (1991 est.)
Defense
-------
Branches: People''s Revolutionary Armed Forces (FARP; includes Army
and Navy), Security Service
Manpower availability:
males age 15-49: 84,003
males fit for military service: 48,885 (1996 est.)
Defense expenditures: exchange rate conversion - $3.4 million, NA%
of GDP (1994)
======================================================================
@Cayman Islands
--------------
(dependent territory of the UK)
Map
---
Location: 19 30 N, 80 30 W -- Caribbean, island group in Caribbean
Sea, nearly one-half of the way from Cuba to Honduras
Flag
----
Description: blue, with the flag of the UK in the upper hoist-side
quadrant and the Caymanian coat of arms on a white disk centered on
the outer half of the flag; the coat of arms includes a pineapple
and turtle above a shield with three stars (representing the three
islands) and a scroll at the bottom bearing the motto HE HATH
FOUNDED IT UPON THE SEAS
--------------
Telephones: 21,584 (1993 est.)
Telephone system:
domestic: NA
international: 1 submarine coaxial cable; satellite earth station -
1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 2, FM 1, shortwave 0
Radios: 28,200 (1992 est.)
Television broadcast stations: 0
Televisions: 6,000 (1992 est.)
Defense
-------
Branches: Royal Cayman Islands Police Force (RCIPF)
Defense note: defense is the responsibility of the UK
======================================================================
@Central African Republic
------------------------
Map
---
Location: 7 00 N, 21 00 E -- Central Africa, north of Zaire
Flag
----
Description: four equal horizontal bands of blue (top), white,
green, and yellow with a vertical red band in center; there is a
yellow five-pointed star on the hoist side of the blue band','2a3b57b3853394595fd82f0ac4d8f63ede17fd565e0c9dc3ae52ad8973b6d2f4','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebd99091a184eebca073bdb0a0555eae36738adc49093ddce2ba0251a7e0bf10',1996,'NA','Namibia','communications',82,'--------------
Telephones: 16,867 (1992 est.)
Telephone system: fair system
domestic: network consists principally of microwave radio relay and
low-capacity, low-powered radiotelephone communication
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 1 (1987 est.)
Televisions: 7,500 (1993 est.)
Defense
-------
Branches: Central African Army (includes Republican Guard), Air
Force, National Gendarmerie, Police Force
Manpower availability:
males age 15-49: 737,330
males fit for military service: 384,134 (1996 est.)
Defense expenditures: exchange rate conversion - $30 million, 2.3%
of GDP (1994)
======================================================================
@Chad
----
Map
---
Location: 15 00 N, 19 00 E -- Central Africa, south of Libya
Flag
----
Description: three equal vertical bands of blue (hoist side),
yellow, and red; similar to the flag of Romania; also similar to the
flag of Andorra, which has a national coat of arms featuring a
quartered shield centered in the yellow band; design was based on
the flag of France','0e6da23d84f05708e3219feaeda10a57748f9ed2002ee47c82e84672b1fb414b','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26dab6b15a99cf273c68904c7d4ca87af92b34e8d4980437fbfb850a025ee275',1996,'FR','France','communications',90,'--------------
Telephones: 5,000 (1987 est.)
Telephone system: primitive system
domestic: fair system of radiotelephone communication stations
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 6, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 1 (1987 est.)
note: limited TV service; many facilities are inoperative
Televisions: 7,000 (1991 est.)
Defense
-------
Branches: Armed Forces (includes Ground Force, Air Force, and
Gendarmerie), Republican Guard, Police
Manpower availability:
males age 15-49: 1,562,052
males fit for military service: 809,210
males reach military age (20) annually: 63,254 (1996 est.)
Defense expenditures: exchange rate conversion - $74 million,
11.1% of GDP (1994)
======================================================================
@Chile
-----
Map
---
Location: 30 00 S, 71 00 W -- Southern South America, bordering
the South Atlantic Ocean and South Pacific Ocean, between Argentina
and Peru
Flag
----
Description: two equal horizontal bands of white (top) and red;
there is a blue square the same height as the white band at the
hoist-side end of the white band; the square bears a white
five-pointed star in the center; design was based on the US flag
--------------
Telephones: 1.5 million (1994 est.)
Telephone system: modern system based on extensive microwave radio
relay facilities
domestic: extensive microwave radio relay links; domestic satellite
system with 3 earth stations
international: satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 159, FM 0, shortwave 11
Radios: NA
Television broadcast stations: 131
Televisions: 2.85 million (1992 est.)
Defense
-------
Branches: Army of the Nation, National Navy (includes Naval Air,
Coast Guard, and Marines), Air Force of the Nation, Carabineros of
Chile (National Police), Investigations Police
Manpower availability:
males age 15-49: 3,808,655
males fit for military service: 2,832,198
males reach military age (19) annually: 123,443 (1996 est.)
Defense expenditures: exchange rate conversion - $970 million,
2.0% of GDP (1994 est.)
======================================================================
@China
-----
(also see separate Taiwan entry)
Map
---
Location: 35 00 N, 105 00 E -- Eastern Asia, bordering the East
China Sea, Korea Bay, Yellow Sea, and South China Sea, between North
Korea and Vietnam
Flag
----
Description: red with a large yellow five-pointed star and four
smaller yellow five-pointed stars (arranged in a vertical arc toward
the middle of the flag) in the upper hoist-side corner
--------------
Telephones: 20 million (1994 est.)
Telephone system: domestic and international services are
increasingly available for private use; unevenly distributed
domestic system serves principal cities, industrial centers, and
most townships
domestic: telephone lines are being expanded; interprovincial
fiber-optic trunk lines and cellular telephone systems have been
installed; a domestic satellite system with 55 earth stations is in
place
international: satellite earth stations - 5 Intelsat (4 Pacific
Ocean and 1 Indian Ocean), 1 Intersputnik (Indian Ocean Region) and
1 Inmarsat (Pacific and Indian Ocean Regions); several international
fiber-optic links to Japan, South Korea, and Hong Kong
Radio broadcast stations: AM 274, FM NA, shortwave 0
Radios: 216.5 million (1992 est.)
Television broadcast stations: 202 (repeaters 2,050)
Televisions: 75 million
Defense
-------
Branches: People''s Liberation Army (PLA), which includes the
Ground Forces, Navy (includes Marines and Naval Aviation), Air
Force, Second Artillery Corps (the strategic missile force),
People''s Armed Police (internal security troops, nominally
subordinate to Ministry of Public Security, but included by the
Chinese as part of the "armed forces" and considered to be an
adjunct to the PLA in wartime)
Manpower availability:
males age 15-49: 352,506,948
males fit for military service: 194,589,216
males reach military age (18) annually: 9,763,916 (1996 est.)
Defense expenditures: the officially announced but suspect figure
is 70.2 billion yuan, NA% of GDP (1995 est.); note - conversion of
the defense budget into US dollars using the current exchange rate
could produce misleading results
======================================================================
@Christmas Island
----------------
(territory of Australia)
Map
---
Location: 10 30 S, 105 40 E -- Southeastern Asia, island in the
Indian Ocean, south of Indonesia
Flag
----
Description: the flag of Australia is used','cafaabc793744604883c63f21404911028a9ed7cffd759901ae64fa069fdbf3c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a61e1a3f1a8cb8e8e99e52d631f9201e2a84260ee146aed69617d55443590c21',1996,'AU','Australia','communications',104,'--------------
Telephones: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 500 (1992)
Television broadcast stations: 1
Televisions: 350 (1992)
Defense
-------
Defense note: defense is the responsibility of Australia
======================================================================
@Clipperton Island
-----------------
(possession of France)
Map
---
Location: 10 17 N, 109 13 W -- Middle America, atoll in the North
Pacific Ocean, 1,120 km southwest of Mexico
Flag
----
Description: the flag of France is used
--------------
Telephones: NA
Telephone system:
domestic: NA
international: telephone, telex, and facsimile communications with
Australia via satellite; 1 satellite earth station of NA type
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 300 (1992 est.)
Television broadcast stations: 0
note: intermittent television service via satellite
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of Australia
======================================================================
@Colombia
--------
Map
---
Location: 4 00 N, 72 00 W -- Northern South America, bordering the
Caribbean Sea, between Panama and Venezuela, and bordering the North
Pacific Ocean, between Ecuador and Panama
Flag
----
Description: three horizontal bands of yellow (top, double-width),
blue, and red; similar to the flag of Ecuador, which is longer and
bears the Ecuadorian coat of arms superimposed in the center
--------------
Telephones: 1.89 million (1986 est.)
Telephone system: modern system in many respects
domestic: nationwide microwave radio relay system; domestic
satellite system with 11 earth stations
international: satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 413 (licensed), FM 217 (licensed),
shortwave 28
Radios: NA
Television broadcast stations: 33
Televisions: 5.5 million (1993 est.)
Defense
-------
Branches: Army (Ejercito Nacional), Navy (Armada Nacional,
includes Marines and Coast Guard), Air Force (Fuerza Aerea
Colombiana), National Police (Policia Nacional)
Manpower availability:
males age 15-49: 10,067,538
males fit for military service: 6,774,105
males reach military age (18) annually: 346,372 (1996 est.)
Defense expenditures: exchange rate conversion - $2 billion, 2.8%
of GDP (1995)
======================================================================
@Comoros
-------
Map
---
Location: 12 10 S, 44 15 E -- Southern Africa, group of islands in
the Mozambique Channel, about two-thirds of the way between northern
Madagascar and northern Mozambique
Flag
----
Description: green with a white crescent in the center of the
field, its points facing downward; there are four white five-pointed
stars placed in a line between the points of the crescent; the
crescent, stars, and color green are traditional symbols of Islam;
the four stars represent the four main islands of the archipelago -
Mwali, Njazidja, Nzwani, and Mayotte (a territorial collectivity of
France, but claimed by Comoros); the design, the most recent of
several, is described in the constitution approved by referendum on
7 June 1992
--------------
Telephones: 3,770 (1991 est.)
Telephone system: sparse system of microwave radio relay and HF
radiotelephone communication stations
domestic: HF radiotelephone communications and microwave radio relay
international: HF radiotelephone communications to Madagascar and
Reunion
Radio broadcast stations: AM 2, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 0
Televisions: 200 (1991 est.)
Defense
-------
Branches: Comoran Security Force
Manpower availability:
males age 15-49: 121,854
males fit for military service: 72,873 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Congo
-----
Map
---
Location: 1 00 S, 15 00 E -- Western Africa, bordering the South
Atlantic Ocean, between Angola and Gabon
Flag
----
Description: divided diagonally from the lower hoist side by a
yellow band; the upper triangle (hoist side) is green and the lower
triangle is red; uses the popular pan-African colors of Ethiopia
--------------
Telephones: 18,000 (1983 est.)
Telephone system: services adequate for government use; key
exchanges are in Brazzaville, Pointe-Noire, and Loubomo
domestic: primary network consists of microwave radio relay and
coaxial cable
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 4, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 4 (1987 est.)
Televisions: 8,500 (1993 est.)
Defense
-------
Branches: Army, Navy (includes Marines), Air Force, National Police
Manpower availability:
males age 15-49: 582,103
males fit for military service: 296,602
males reach military age (20) annually: 25,247 (1996 est.)
Defense expenditures: exchange rate conversion - $110 million,
3.8% of GDP (1993)
======================================================================
@Cook Islands
------------
(free association with New Zealand)
Map
---
Location: 21 14 S, 159 46 W -- Oceania, group of islands in the
South Pacific Ocean, about one-half of the way from Hawaii to New
Zealand
Flag
----
Description: blue, with the flag of the UK in the upper hoist-side
quadrant and a large circle of 15 white five-pointed stars (one for
every island) centered in the outer half of the flag
--------------
Telephones: 4,180 (1994)
Telephone system:
domestic: the individual islands are connected by a combination of
satellite earth stations, microwave systems, and VHF and HF
radiotelephone; within the islands, service is provided by small
exchanges connected to subscribers by open wire, cable, and
fiber-optic cable
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave 1
Radios: 13,000 (1992 est.)
Television broadcast stations: 1 studio and 8 low-powered
repeaters to achieve good coverage on the island of Rarotonga
Televisions: 3,500 (1995 est.)
Defense
-------
Defense note: defense is the responsibility of New Zealand
======================================================================
@Coral Sea Islands
-----------------
(territory of Australia)
Map
---
Location: 18 00 S, 152 00 E -- Oceania, islands in the Coral Sea,
northeast of Australia
Flag
----
Description: the flag of Australia is used
Flag
----
Description: two narrow red horizontal bands encase a wide white
band; centered on the white band is a disk with blue and white wave
pattern on the lower half and gold and white ray pattern on the
upper half; a stylized red, blue and white ship rides on the wave
pattern; the French flag is used for official occasions
--------------
Telephone system:
international: submarine cables from India to UAE and Malaysia and
from Sri Lanka to Djibouti and Indonesia
======================================================================
@Indonesia
---------
Map
---
Location: 5 00 S, 120 00 E -- Southeastern Asia, archipelago
between the Indian Ocean and the Pacific Ocean
Flag
----
Description: two equal horizontal bands of red (top) and white;
similar to the flag of Monaco, which is shorter; also similar to the
flag of Poland, which is white (top) and red
--------------
Telephones: 1,276,600 (1993 est.)
Telephone system: domestic service fair, international service good
domestic: interisland microwave system and HF radio police net;
domestic satellite communications system
international: satellite earth stations - 2 Intelsat (1 Indian Ocean
and 1 Pacific Ocean)
Radio broadcast stations: AM 618, FM 38, shortwave 0
Radios: 28.1 million (1992 est.)
Television broadcast stations: 9
Televisions: 11.5 million (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, National Police
Manpower availability:
males age 15-49: 57,222,025
males fit for military service: 33,702,395
males reach military age (18) annually: 2,280,360 (1996 est.)
Defense expenditures: exchange rate conversion - $2.7 billion,
1.4% of GNP (FY95/96)
======================================================================
@Iran
----
Map
---
Location: 32 00 N, 53 00 E -- Middle East, bordering the Gulf of
Oman, the Persian Gulf, and the Caspian Sea, between Iraq and
--------------
Telephones: 38,748 (1993 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 5, FM 3, shortwave 0
Radios: 97,000 (1992 est.)
Television broadcast stations: 7
Televisions: 47,000 (1992 est.)
Defense
-------
Branches: French Armed Forces (Army, Navy, Air Force,
Gendarmerie); Police Force
Defense expenditures: $NA, NA% of GDP
Defense note: defense is the responsibility of France
======================================================================
@New Zealand
-----------
Map
---
Location: 41 00 S, 174 00 E -- Oceania, islands in the South
Pacific Ocean, southeast of Australia
Flag
----
Description: blue with the flag of the UK in the upper hoist-side
quadrant with four red five-pointed stars edged in white centered in
the outer half of the flag; the stars represent the Southern Cross
constellation
--------------
Telephones: 1.7 million (1986 est.)
Telephone system: excellent international and domestic systems
domestic: NA
international: submarine cables to Australia and Fiji; satellite
earth stations - 2 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 64, FM 2, shortwave 0
Radios: 3.215 million (1992 est.)
Television broadcast stations: 14 (1986 est.)
Televisions: 1.53 million (1992 est.)
Defense
-------
Branches: New Zealand Army, Royal New Zealand Navy, Royal New
Zealand Air Force
Manpower availability:
males age 15-49: 927,212
males fit for military service: 780,976
males reach military age (20) annually: 27,433 (1996 est.)
Defense expenditures: exchange rate conversion - $556 million, 1%
of GDP (FY93/94)
======================================================================
@Nicaragua
---------
Map
---
Location: 13 00 N, 85 00 W -- Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between Costa Rica and
--------------
Telephones: 1,087 (1983 est.)
Telephone system:
domestic: NA
international: radiotelephone service with Sydney (Australia)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 2,000 (1991 est.)
Television broadcast stations: 0
Televisions: 900 (1991 est.)
Defense
-------
Defense note: defense is the responsibility of Australia
======================================================================
@Northern Mariana Islands
------------------------
(commonwealth in political union with the US)
Map
---
Location: 15 12 N, 145 45 E -- Oceania, islands in the North
Pacific Ocean, about three-quarters of the way from Hawaii to the
--------------
Telephones: 54,900 (1989 est.)
Telephone system: fair system
domestic: microwave radio relay and radiotelephone communications
stations
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 10, FM 0, shortwave 0
Radios: 2.04 million (1992 est.)
Television broadcast stations: 9 (1987 est.)
Televisions: 193,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Air Wing
Manpower availability:
males age 15-49: 4,359,286
males fit for military service: 2,365,157 (1996 est.)
Defense expenditures: exchange rate conversion - $56 million, 1.7%
of budget (FY93/94)
======================================================================
@Ukraine
-------
Map
---
Location: 49 00 N, 32 00 E -- Eastern Europe, bordering the Black
Sea, between Poland and Russia
Flag
----
Description: two equal horizontal bands of azure (top) and golden
yellow represent grainfields under a blue sky
--------------
Telephones: NA
Telephone system: system is unsatisfactory both for business and
for personal use; 3.56 million applications for telephones had not
been satisfied as of January 1991; electronic mail services have
been established in Kiev, Odessa, and Luhans''k by Sprint
domestic: an NMT-450 analog cellular telephone network operates in
Kiev (Kyyiv) and allows direct dialing of international calls
through Kiev''s digital exchange
international: calls to other CIS countries are carried by landline
or microwave radio relay; calls to 167 other countries are carried
by satellite or by the 150 leased lines through the Moscow
international gateway switch; satellite earth stations - NA
Intelsat, 1 Inmarsat (Atlantic and Indian Ocean Regions), and NA
Intersputnik
Radio broadcast stations: AM NA, FM NA, shortwave NA; note - there
are at least two radio broadcast stations of NA type
Radios: 15 million (1990)
Television broadcast stations: at least 2
Televisions: 17.3 million (1992)
Defense
-------
Branches: Army, Navy, Air and Air Defense Forces, Internal Troops,
National Guard, Border Troops
Manpower availability:
males age 15-49: 12,388,788
males fit for military service: 9,716,127
males reach military age (18) annually: 362,000 (1996 est.)
Defense expenditures: 1.35 billion hryvni, less than 2% of GDP
(Ukrainian Government''s forecast for 1996); note - conversion of
defense expenditures into US dollars using the current exchange rate
could produce misleading results
======================================================================
@United Arab Emirates
--------------------
Map
---
Location: 24 00 N, 54 00 E -- Middle East, bordering the Gulf of
Oman and the Persian Gulf, between Oman and Saudi Arabia
Flag
----
Description: three equal horizontal bands of green (top), white,
and black with a thicker vertical red band on the hoist side
--------------
Telephones: 677,793 (1993 est.)
Telephone system: modern system consisting of microwave radio
relay and coaxial cable; key centers are Abu Dhabi and Dubai
domestic: microwave radio relay and coaxial cable
international: satellite earth stations - 3 Intelsat (1 Atlantic
Ocean and 2 Indian Ocean) and 1 Arabsat; submarine cables to Qatar,
Bahrain, India, and Pakistan; tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia
Radio broadcast stations: AM 8, FM 3, shortwave 0
Radios: 545,000 (1992 est.)
Television broadcast stations: 12
Televisions: 170,000 (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, paramilitary (includes Federal
Police Force)
Manpower availability:
males age 15-49: 1,102,080
males fit for military service: 599,439
males reach military age (18) annually: 21,250 (1996 est.)
Defense expenditures: exchange rate conversion - $1.59 billion,
4.3% of GDP (1994)
======================================================================
@United Kingdom
--------------
Map
---
Location: 54 00 N, 2 00 W -- Western Europe, islands including the
northern one-sixth of the island of Ireland between the North
Atlantic Ocean and the North Sea, northwest of France
Flag
----
Description: blue with the red cross of Saint George (patron saint
of England) edged in white superimposed on the diagonal red cross of
Saint Patrick (patron saint of Ireland) which is superimposed on the
diagonal white cross of Saint Andrew (patron saint of Scotland);
known as the Union Flag or Union Jack; the design and colors
(especially the Blue Ensign) have been the basis for a number of
other flags including dependencies, Commonwealth countries, and
others
Flag
----
Description: two equal horizontal bands of red (top) and green
with a black isosceles triangle (based on the hoist side) all
separated by a black-edged yellow stripe in the shape of a
horizontal Y (the two points of the Y face the hoist side and
enclose the triangle); centered in the triangle is a boar''s tusk
encircling two crossed namele leaves, all in yellow','7e4e7ad37bcdac877f584e71d4bc34a4ebda112690e8aa49c8b6bae72714738b','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a39463ce634f413f9368832f5c89ba64fc424d91c9675b6364282c9f60e8bcaf',1996,'PA','Panama','communications',116,'--------------
Telephones: 281,042 (1983 est.)
Telephone system: very good domestic telephone service
domestic: NA
international: connected to Central American Microwave System;
satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 71, FM 0, shortwave 13
Radios: NA
Television broadcast stations: 18
Televisions: 340,000 (1993 est.)
Defense
-------
Branches: Civil Guard, Coast Guard, Air Section, Rural Assistance
Guard; note - the Constitution prohibits armed forces
Manpower availability:
males age 15-49: 917,566
males fit for military service: 616,420
males reach military age (18) annually: 33,504 (1996 est.)
Defense expenditures: exchange rate conversion - $55 million, 2.0%
of GDP (1995)
======================================================================
@Cote d''Ivoire
-------------
(also known as Ivory Coast)
Map
---
Location: 8 00 N, 5 00 W -- Western Africa, bordering the North
Atlantic Ocean, between Ghana and Liberia
Flag
----
Description: three equal vertical bands of orange (hoist side),
white, and green; similar to the flag of Ireland, which is longer
and has the colors reversed - green (hoist side), white, and orange;
also similar to the flag of Italy, which is green (hoist side),
white, and red; design was based on the flag of France
--------------
Telephones: 87,700 (1987 est.)
Telephone system: well-developed by African standards but
operating well below capacity
domestic: open-wire lines and microwave radio relay
international: satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean); 2 coaxial submarine cables
Radio broadcast stations: AM 71, FM 0, shortwave 13
Radios: NA
Television broadcast stations: 18
Televisions: 810,000 (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, paramilitary Gendarmerie,
Presidential Guard
Manpower availability:
males age 15-49: 3,386,638
males fit for military service: 1,762,412
males reach military age (18) annually: 157,712 (1996 est.)
Defense expenditures: exchange rate conversion - $140 million,
1.4% of GDP (1993)
======================================================================
@Croatia
-------
Map
---
Location: 45 10 N, 15 30 E -- Southeastern Europe, bordering the
Adriatic Sea, between Bosnia and Herzegovina and Slovenia
Flag
----
Description: red, white, and blue horizontal bands with Croatian
coat of arms (red and white checkered)
--------------
Telephones: 1.216 million (1993 est.)
Telephone system:
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM 14, FM 8, shortwave 0
Radios: 1.1 million
Television broadcast stations: 12 (repeaters 2)
Televisions: 1.52 million (1992 est.)
Defense
-------
Branches: Ground Forces, Naval Forces, Air and Air Defense Forces,
Frontier Guard, Home Guard
Manpower availability:
males age 15-49: 1,314,718
males fit for military service: 1,046,490
males reach military age (19) annually: 34,914 (1996 est.)
Defense expenditures: 337 billion to 393 billion dinars, NA% of
GDP (1993 est.); note - conversion of defense expenditures into US
dollars using the current exchange rate could produce misleading
results
======================================================================
@Cuba
----
Map
---
Location: 21 30 N, 80 00 W -- Caribbean, island between the
Caribbean Sea and the North Atlantic Ocean, south of Florida
Flag
----
Description: five equal horizontal bands of blue (top and bottom)
alternating with white; a red equilateral triangle based on the
hoist side bears a white five-pointed star in the center
--------------
Telephones: 430,000 (1987 est.)
Telephone system: among the world''s least developed telephone
systems
domestic: NA
international: satellite earth station - 1 Intersputnik (Atlantic
Ocean Region)
Radio broadcast stations: AM 150, FM 5, shortwave 0
Radios: 2.14 million (1993 est.)
Television broadcast stations: 58
Televisions: 2.5 million (1993 est.)
Defense
-------
Branches: Revolutionary Armed Forces (FAR) includes ground forces,
Revolutionary Navy (MGR), Air and Air Defense Force (DAAFAR),
Territorial Troops Militia (MTT), and Youth Labor Army (EJT);
Interior Ministry Border Guards (TGF)
Manpower availability:
males age 15-49: 3,053,431
females age 15-49: 3,009,852
males fit for military service: 1,898,644
females fit for military service: 1,866,313
males reach military age (17) annually: 65,182
females reach military age (17) annually: 61,960 (1996 est.)
Defense expenditures: exchange rate conversion - $NA, roughly 4%
of GDP (1995 est.)
Defense note: Moscow, for decades the key military supporter and
supplier of Cuba, cut off almost all military aid by 1993
======================================================================
@Cyprus
------
Map
---
Location: 35 00 N, 33 00 E -- Middle East, island in the
Mediterranean Sea, south of Turkey
Flag
----
Description: white with a copper-colored silhouette of the island
(the name Cyprus is derived from the Greek word for copper) above
two green crossed olive branches in the center of the flag; the
branches symbolize the hope for peace and reconciliation between the
Greek and Turkish communities
--------------
Telephones: 331,000 (1995 est.)
Telephone system: excellent in both the Greek and Turkish areas
domestic: open wire, fiber-optic cable, and microwave radio relay
international: tropospheric scatter; 3 coaxial and 5 fiber-optic
submarine cables; satellite earth stations - 3 Intelsat (1 Atlantic
Ocean and 2 Indian Ocean), 2 Eutelsat, 2 Intersputnik, and 1 Arabsat
Radio broadcast stations:
Greek area: AM 11, FM 8, shortwave 0
Turkish area: AM 2, FM 6, shortwave 0
Radios:
Greek area: 270,000 (1993 est.)
Turkish area: 42,170 (1985 est.)
Television broadcast stations:
Greek area: 1 (repeaters 34)
Turkish area: 1
Televisions:
Greek area: 107,000 (1992 est.)
Turkish area: 75,000 (1993 est.)
Defense
-------
Branches:
Greek area: Greek Cypriot National Guard (GCNG; includes air and
naval elements), Greek Cypriot Police
Turkish area: Turkish Cypriot Security Force
Manpower availability:
males age 15-49: 190,372
males fit for military service: 130,880
males reach military age (18) annually: 5,749 (1996 est.)
Defense expenditures: exchange rate conversion - $493 million,
5.6% of GDP (1995)
======================================================================
@Czech Republic
--------------
Map
---
Location: 49 45 N, 15 30 E -- Central Europe, southeast of Germany
Flag
----
Description: two equal horizontal bands of white (top) and red
with a blue isosceles triangle based on the hoist side (almost
identical to the flag of the former Czechoslovakia)
--------------
Telephones: 3,349,539 (1993 est.)
Telephone system:
domestic: NA
international: satellite earth stations - 2 Intersputnik (Atlantic
and Indian Ocean Regions)
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
-------
Branches: Army, Air and Air Defense Forces, Civil Defense,
Railroad Units
Manpower availability:
males age 15-49: 2,724,607
males fit for military service: 2,074,331
males reach military age (18) annually: 88,418 (1996 est.)
Defense expenditures: exchange rate conversion - $931 million,
2.5% of GDP (1995)
======================================================================
@Denmark
-------
Map
---
Location: 56 00 N, 10 00 E -- Northern Europe, bordering the
Baltic Sea and the North Sea, on a peninsula north of Germany
Flag
----
Description: red with a white cross that extends to the edges of
the flag; the vertical part of the cross is shifted to the hoist
side, and that design element of the Dannebrog (Danish flag) was
subsequently adopted by the other Nordic countries of Finland,
Iceland, Norway, and Sweden
--------------
Telephones: 4.005 million (1985 est.)
Telephone system: excellent telephone and telegraph services
domestic: buried and submarine cables and microwave radio relay form
trunk network
international: 19 submarine coaxial cables; satellite earth stations
- 7 Intelsat, NA Eutelsat, and 1 Inmarsat (Atlantic and Indian Ocean
Regions); note - Denmark shares the Inmarsat earth station with the
other Nordic countries (Finland, Iceland, Norway, and Sweden)
Radio broadcast stations: AM 3, FM 2, shortwave 0
Radios: NA
Television broadcast stations: 2
Televisions: 2.04 million (1992 est.)
Defense
-------
Branches: Royal Danish Army, Royal Danish Navy, Royal Danish Air
Force, Home Guard
Manpower availability:
males age 15-49: 1,338,791
males fit for military service: 1,150,996
males reach military age (20) annually: 34,324 (1996 est.)
Defense expenditures: exchange rate conversion - $3.2 billion,
1.8% of GDP (1995)
======================================================================
@Djibouti
--------
Map
---
Location: 11 30 N, 43 00 E -- Eastern Africa, bordering the Gulf
of Aden and the Red Sea, between Eritrea and Somalia
Flag
----
Description: two equal horizontal bands of light blue (top) and
light green with a white isosceles triangle based on the hoist side
bearing a red five-pointed star in the center
--------------
Telephones: 7,200 (1986 est.)
Telephone system: telephone facilities in the city of Djibouti are
adequate as are the microwave radio relay connections to outlying
areas of the country
domestic: microwave radio relay network
international: submarine cable to Saudi Arabia; satellite earth
stations - 1 Intelsat (Indian Ocean) and 1 Arabsat
Radio broadcast stations: AM 2, FM 2, shortwave 0
Radios: NA
Television broadcast stations: 1
Televisions: 17,000 (1993 est.)
Defense
-------
Branches: Djibouti National Army (includes Navy and Air Force),
National Security Force (Force Nationale de Securite), National
Police Force
Manpower availability:
males age 15-49: 102,528
males fit for military service: 60,076 (1996 est.)
Defense expenditures: exchange rate conversion - $26 million, NA%
of GDP (1989)
======================================================================
@Dominica
--------
Map
---
Location: 13 30 N, 61 20 W -- Caribbean, island between the
Caribbean Sea and the North Atlantic Ocean, about one-half of the
way from Puerto Rico to Trinidad and Tobago
Flag
----
Description: green with a centered cross of three equal bands -
the vertical part is yellow (hoist side), black, and white - the
horizontal part is yellow (top), black, and white; superimposed in
the center of the cross is a red disk bearing a sisserou parrot
encircled by 10 green five-pointed stars edged in yellow; the 10
stars represent the 10 administrative divisions (parishes)','6fb09dc32adc365df153495b6c6fe9a8cb03d0ecf6a1f40481d5754154f0c952','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ed62dbd351b591971713353091a83825aca3b7fb53ff19cd5d69c438aabc9d0',1996,'TT','Trinidad and Tobago','communications',124,'--------------
Telephones: 14,613 (1993 est.)
Telephone system:
domestic: fully automatic network
international: microwave radio relay and SHF radiotelephone links to
Martinique and Guadeloupe; VHF and UHF radiotelephone links to Saint
Lucia
Radio broadcast stations: AM 3, FM 2, shortwave 0
Radios: 45,000 (1993 est.)
Television broadcast stations: 1 cable
Televisions: 5,200 (1993 est.)
Defense
-------
Branches: Commonwealth of Dominica Police Force (includes Special
Service Unit, Coast Guard)
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Dominican Republic
------------------
Map
---
Location: 19 00 N, 70 40 W -- Caribbean, eastern two-thirds of the
island of Hispaniola, between the Caribbean Sea and the North
Atlantic Ocean, east of Haiti
Flag
----
Description: a centered white cross that extends to the edges,
divides the flag into four rectangles - the top ones are blue (hoist
side) and red, the bottom ones are red (hoist side) and blue; a
small coat of arms is at the center of the cross
--------------
Telephones: 190,000 (1987 est.)
Telephone system:
domestic: relatively efficient system based on islandwide microwave
radio relay network
international: 1 coaxial submarine cable; satellite earth station -
1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 120, FM 0, shortwave 6
Radios: NA
Television broadcast stations: 18 (1987 est.)
Televisions: 728,000 (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, National Police
Manpower availability:
males age 15-49: 2,212,012
males fit for military service: 1,391,472
males reach military age (18) annually: 83,611 (1996 est.)
Defense expenditures: exchange rate conversion - $116 million,
1.4% of GDP (1994)
======================================================================
@Ecuador
-------
Map
---
Location: 2 00 S, 77 30 W -- Western South America, bordering the
Pacific Ocean at the Equator, between Colombia and Peru
Flag
----
Description: three horizontal bands of yellow (top, double width),
blue, and red with the coat of arms superimposed at the center of
the flag; similar to the flag of Colombia that is shorter and does
not bear a coat of arms
--------------
Telephones: 586,300 (1994 est.)
Telephone system:
domestic: facilities generally inadequate and unreliable
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 272, FM 0, shortwave 39
Radios: NA
Television broadcast stations: 33
Televisions: 940,000 (1992 est.)
Defense
-------
Branches: Army (Ejercito Ecuatoriano), Navy (Armada Ecuatoriana,
includes Marines), Air Force (Fuerza Aerea Ecuatoriana), National
Police
Manpower availability:
males age 15-49: 2,968,361
males fit for military service: 2,006,509
males reach military age (20) annually: 121,241 (1996 est.)
Defense expenditures: exchange rate conversion - $386 million,
2.1% of GDP (1995)
======================================================================
@Egypt
-----
Map
---
Location: 27 00 N, 30 00 E -- Northern Africa, bordering the
Mediterranean Sea, between Libya and the Gaza Strip
Flag
----
Description: three equal horizontal bands of red (top), white, and
black with the national emblem (a shield superimposed on a golden
eagle facing the hoist side above a scroll bearing the name of the
country in Arabic) centered in the white band; similar to the flag
of Yemen, which has a plain white band; also similar to the flag of
Syria that has two green stars and to the flag of Iraq, which has
three green stars (plus an Arabic inscription) in a horizontal line
centered in the white band
--------------
Telephones: 5,650 (1988 est.)
Telephone system: automatic, islandwide telephone system
domestic: interisland VHF and UHF radiotelephone links
international: new SHF radiotelephone links to Trinidad and Tobago
and Saint Vincent; VHF and UHF radio links to Trinidad
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 80,000 (1993 est.)
Television broadcast stations: 1 (1988 est.)
Televisions: 30,000 (1993 est.)
Defense
-------
Branches: Royal Grenada Police Force, Coast Guard
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Guadeloupe
----------
(overseas department of France)
Map
---
Location: 16 15 N, 61 35 W -- Caribbean, islands in the eastern
Caribbean Sea, southeast of Puerto Rico
Flag
----
Description: three horizontal bands, a narrow green band (top), a
wide red band, and a narrow green band; the green bands are
separated from the red band by two narrow white stripes; a
five-pointed gold star is centered in the red band toward the hoist
side; the flag of France is used for official occasions
--------------
Telephones: 64,916 (1984 est.)
Telephone system: domestic facilities inadequate
domestic: NA
international: satellite earth station - 1 Intelsat (Atlantic
Ocean); microwave radio relay to Antigua and Barbuda, Dominica, and
--------------
Telephones: 159,000 (1990 est.)
Telephone system: domestic facilities are adequate
domestic: NA
international: microwave radio relay to Guadeloupe, Dominica, and
Saint Lucia; satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 6, shortwave 0
Radios: 74,000 (1992 est.)
Television broadcast stations: 10
Televisions: 65,000 (1993 est.)
Defense
-------
Branches: French forces (Army, Navy, Air Force), Gendarmerie
Defense note: defense is the responsibility of France
======================================================================
@Mauritania
----------
Map
---
Location: 20 00 N, 12 00 W -- Northern Africa, bordering the North
Atlantic Ocean, between Senegal and Western Sahara
Flag
----
Description: green with a yellow five-pointed star above a yellow,
horizontal crescent; the closed side of the crescent is down; the
crescent, star, and color green are traditional symbols of Islam
--------------
Telephones: 26,000 (1992 est.)
Telephone system:
domestic: system is automatically switched
international: direct microwave radio relay link with Martinique and
Saint Vincent and the Grenadines; tropospheric scatter to Barbados;
international calls beyond these countries are carried by Intelsat
from Martinique
Radio broadcast stations: AM 4, FM 1, shortwave 0
Radios: 104,000 (1992 est.)
Television broadcast stations: 1 cable
Televisions: 26,000 (1992 est.)
Defense
-------
Branches: Royal Saint Lucia Police Force, Coast Guard
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: exchange rate conversion - $5.0 million,
2.0% of GDP (1991); note - for police forces
======================================================================
@Saint Pierre and Miquelon
-------------------------
(territorial collectivity of France)
Map
---
Location: 46 50 N, 56 20 E -- Northern North America, islands in
the North Atlantic Ocean, south of Newfoundland (Canada)
Flag
----
Description: a yellow sailing ship rides on a dark blue background
with a black wave line under the ship; on the hoist side, a vertical
band is divided into three parts: the top part is red with a green
diagonal cross extending to the corners overlaid by a white cross
dividing the square into four sections; the middle part has a white
background with an ermine pattern; the third part has a red
background with two stylized yellow lions outlined in black, one on
top of the other; the flag of France is used for official occasions
--------------
Telephones: 3,300 (1992 est.)
Telephone system:
domestic: NA
international: radiotelephone communication with most countries in
the world; 1 earth station in French domestic satellite system
Radio broadcast stations: AM 1, FM 3, shortwave 0
Radios: 6,300 (1990 est.)
Television broadcast stations: 0
Televisions: 2,000 (1992 est.)
Defense
-------
Defense note: defense is the responsibility of France
======================================================================
@Saint Vincent and the Grenadines
--------------------------------
Map
---
Location: 13 15 N, 61 12 W -- Caribbean, islands in the Caribbean
Sea, north of Trinidad and Tobago
Flag
----
Description: three vertical bands of blue (hoist side), gold
(double width), and green; the gold band bears three green diamonds
arranged in a V pattern
--------------
Telephones: 6,189 (1983 est.)
Telephone system:
domestic: islandwide, fully automatic telephone system; VHF/UHF
radiotelephone from Saint Vincent to the other islands of the
Grenadines
international: VHF/UHF radiotelephone from Saint Vincent to
Barbados; new SHF radiotelephone to Grenada and to Saint Lucia;
access to Intelsat earth station in Martinique through Saint Lucia
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 76,000 (1992 est.)
Television broadcast stations: 1 cable
Televisions: 20,600 (1992 est.)
Defense
-------
Branches: Royal Saint Vincent and the Grenadines Police Force,
Coast Guard
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@San Marino
----------
Map
---
Location: 43 46 N, 12 25 E -- Southern Europe, an enclave in
central Italy
Flag
----
Description: two equal horizontal bands of white (top) and light
blue with the national coat of arms superimposed in the center; the
coat of arms has a shield (featuring three towers on three peaks)
flanked by a wreath, below a crown and above a scroll bearing the
word LIBERTAS (Liberty)
--------------
Telephones: 22,300 (1992 est.)
Telephone system:
domestic: automatic telephone system completely integrated into
Italian system
international: microwave radio relay and cable connections to
Italian network; no satellite earth stations
Radio broadcast stations: AM NA, FM NA, shortwave NA (1 private
radio broadcast station)
Radios: 12,535 (1991 est.)
Television broadcast stations: 1 (1991 est.)
note: receives broadcasts from Italy
Televisions: 7,500 (1992 est.)
Defense
-------
Branches: Voluntary Military Force, Police Force
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $3.7 million (1% of GDP) (1992 est.)
======================================================================
@Sao Tome and Principe
---------------------
Map
---
Location: 1 00 N, 7 00 E -- Western Africa, island in the Atlantic
Ocean, straddling the Equator, west of Gabon
Flag
----
Description: three horizontal bands of green (top), yellow (double
width), and green with two black five-pointed stars placed side by
side in the center of the yellow band and a red isosceles triangle
based on the hoist side; uses the popular pan-African colors of','dc0162bc991a3dbbe7f75bb7aa10b86003be2b3e842f3352c0f17f86f4b166cb','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('984180c3e504502f7b76a2740efccd210980cb2cc926da17f90e06375e4c0def',1996,'MX','Mexico','communications',132,'--------------
Telephones: 2.2 million (1993)
Telephone system: large system by Third World standards but
inadequate for present requirements and undergoing extensive
upgrading
domestic: principal centers at Alexandria, Cairo, Al Mansurah,
Ismailia, Suez, and Tanta are connected by coaxial cable and
microwave radio relay
international: satellite earth stations - 2 Intelsat (Atlantic Ocean
and Indian Ocean), 1 Arabsat, and 1 Inmarsat; 5 coaxial submarine
cables; tropospheric scatter to Sudan; microwave radio relay to
Israel; participant in Medarabtel
Radio broadcast stations: AM 39, FM 6, shortwave 0
Radios: NA
Television broadcast stations: 41
Televisions: 5 million (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, Air Defense Command
Manpower availability:
males age 15-49: 16,530,460
males fit for military service: 10,723,011
males reach military age (20) annually: 660,453 (1996 est.)
Defense expenditures: exchange rate conversion - $3.5 billion,
8.2% of GDP (FY94/95 est.)
======================================================================
@El Salvador
-----------
Map
---
Location: 13 50 N, 88 55 W -- Middle America, bordering the North
Pacific Ocean, between Guatemala and Honduras
Flag
----
Description: three equal horizontal bands of blue (top), white,
and blue with the national coat of arms centered in the white band;
the coat of arms features a round emblem encircled by the words
REPUBLICA DE EL SALVADOR EN LA AMERICA CENTRAL; similar to the flag
of Nicaragua, which has a different coat of arms centered in the
white band - it features a triangle encircled by the words REPUBLICA
DE NICARAGUA on top and AMERICA CENTRAL on the bottom; also similar
to the flag of Honduras, which has five blue stars arranged in an X
pattern centered in the white band
--------------
Telephones: 116,000 (1984 est.)
Telephone system:
domestic: nationwide microwave radio relay system
international: satellite earth station - 1 Intelsat (Atlantic
Ocean); connected to Central American Microwave System
Radio broadcast stations: AM 77, FM 0, shortwave 2
Radios: NA
Television broadcast stations: 5 (1986 est.)
Televisions: 500,700 (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force
Manpower availability:
males age 15-49: 1,415,691
males fit for military service: 905,938
males reach military age (18) annually: 78,660 (1996 est.)
Defense expenditures: exchange rate conversion - $100 million, 1%
of GDP (1995)
======================================================================
@Equatorial Guinea
-----------------
Map
---
Location: 2 00 N, 10 00 E -- Western Africa, bordering the North
Atlantic Ocean, between Cameroon and Gabon
Flag
----
Description: three equal horizontal bands of green (top), white,
and red with a blue isosceles triangle based on the hoist side and
the coat of arms centered in the white band; the coat of arms has
six yellow six-pointed stars (representing the mainland and five
offshore islands) above a gray shield bearing a silk-cotton tree and
below which is a scroll with the motto UNIDAD, PAZ, JUSTICIA (Unity,
Peace, Justice)
--------------
Telephones: 17,000 (1991 est.)
Telephone system: poor system of cable and open-wire lines, minor
microwave radio relay links, and radiotelephone communications
stations (improvements being made)
domestic: mostly cable and open-wire lines
international: satellite earth stations - 1 Intelsat (Atlantic
Ocean) and 2 Arabsat
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 300,000 (1993 est.)
Television broadcast stations: 1 (1987 est.)
Televisions: 50,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, National Gendarmerie, National
Guard, National Police, Presidential Guard
Manpower availability:
males age 15-49: 500,754
males fit for military service: 244,546 (1996 est.)
Defense expenditures: exchange rate conversion - $33 million, 2.5%
of GDP (1995)
======================================================================
@Mauritius
---------
Map
---
Location: 20 17 S, 57 33 E -- Southern Africa, island in the
Indian Ocean, east of Madagascar
Flag
----
Description: four equal horizontal bands of red (top), blue,
yellow, and green
Flag
----
Description: thirteen equal horizontal stripes of red (top and
bottom) alternating with white; there is a blue rectangle in the
upper hoist-side corner bearing 50 small white five-pointed stars
arranged in nine offset horizontal rows of six stars (top and
bottom) alternating with rows of five stars; the 50 stars represent
the 50 states, the 13 stripes represent the 13 original colonies;
known as Old Glory; the design and colors have been the basis for a
number of other flags including Chile, Liberia, Malaysia, and Puerto
Rico
--------------
Telephones: 182.558 million (1987 est.)
Telephone system:
domestic: large system of fiber-optic cable, microwave radio relay,
coaxial cable, and domestic satellites
international: 24 ocean cable systems in use; satellite earth
stations - 61 Intelsat (45 Atlantic Ocean and 16 Pacific Ocean)
(1990 est.), 5 Intersputnik (Atlantic Ocean region), and 4 Inmarsat
(Pacific and Atlantic Ocean regions)
Radio broadcast stations: AM 4,987, FM 4,932, shortwave 0
Radios: 540.5 million (1992 est.)
Television broadcast stations: 1,092 (in addition, there are about
9,000 cable TV systems)
Televisions: 215 million (1993 est.)
Defense
-------
Branches: Department of the Army, Department of the Navy (includes
Marine Corps), Department of the Air Force
note: the Coast Guard falls under the Department of Transportation,
but in wartime reports to the Department of the Navy
Manpower availability:
males age 15-49: 69,302,573
males fit for military service: NA
males reach military age (18) annually: 1,864,580 (1996 est.)
Defense expenditures: $272.2 billion, 3.8% of GDP (1995 est.)
======================================================================
@Uruguay
-------
Map
---
Location: 33 00 S, 56 00 W -- Southern South America, bordering
the South Atlantic Ocean, between Argentina and Brazil
Flag
----
Description: nine equal horizontal stripes of white (top and
bottom) alternating with blue; there is a white square in the upper
hoist-side corner with a yellow sun bearing a human face known as
the Sun of May and 16 rays alternately triangular and wavy
--------------
Telephones: 451,000 (1991 est.)
Telephone system: some modern facilities
domestic: most modern facilities concentrated in Montevideo; new
nationwide microwave radio relay network
international: satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 99, FM 0, shortwave 9
Radios: 1.89 million (1992 est.)
Television broadcast stations: 26
Televisions: 725,000 (1992 est.)
Defense
-------
Branches: Army, Navy (includes Naval Air Arm, Coast Guard,
Marines), Air Force, Grenadier Guards, Coracero Guard, Police
Manpower availability:
males age 15-49: 783,890
males fit for military service: 636,454 (1996 est.)
Defense expenditures: exchange rate conversion - $256 million,
1.5% of GDP (1994)
======================================================================
@Uzbekistan
----------
Map
---
Location: 41 00 N, 64 00 E -- Central Asia, north of Afghanistan
Flag
----
Description: three equal horizontal bands of blue (top), white,
and green separated by red fimbriations with a crescent moon and 12
stars in the upper hoist-side quadrant
--------------
Telephones: 1.458 million (1995 est.)
Telephone system: poorly developed
domestic: NMT-450 analog cellular network established in Tashkent
international: linked by landline or microwave radio relay with CIS
member states and to other countries by leased connection via the
Moscow international gateway switch; new Intelsat links to Tokyo and
Ankara give Uzbekistan international access independent of Russian
facilities; satellite earth stations - NA Orbita and NA Intelsat
Radio broadcast stations: AM NA, FM NA, shortwave NA; note - there
is at least one state-owned broadcast station of NA type
Radios: NA
Television broadcast stations: 2
Televisions: NA
Defense
-------
Branches: Army, Air and Air Defense, Security Forces (internal and
border troops), National Guard
Manpower availability:
males age 15-49: 5,672,621
males fit for military service: 4,623,960
males reach military age (18) annually: 231,293 (1996 est.)
Defense expenditures: 164 million soms, 3.7% of GDP (1993); note -
conversion of defense expenditures into US dollars using the current
exchange rate could produce misleading results
======================================================================
@Vanuatu
-------
Map
---
Location: 16 00 S, 167 00 E -- Oceania, group of islands in the
South Pacific Ocean, about three-quarters of the way from Hawaii to','f7f4814ad98974eb8464f0de71cb757e3ee8eff5368278f8270cf70d513184c0','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57b29e178db411a4ca5f4312d0d4a962f0e6e06355d3a890098022aa72f41322',1996,'CM','Cameroon','communications',136,'--------------
Telephones: 2,000 (1987 est.)
Telephone system: poor system with adequate government services
domestic: NA
international: international communications from Bata and Malabo to
African and European countries; satellite earth station - 1 Intelsat
(Indian Ocean)
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 1
Televisions: 4,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, Rapid Intervention Force,
National Police
Manpower availability:
males age 15-49: 92,704
males fit for military service: 47,124 (1996 est.)
Defense expenditures: exchange rate conversion - $2.5 million, NA%
of GDP (FY93/94)
======================================================================
@Eritrea
-------
Map
---
Location: 15 00 N, 39 00 E -- Eastern Africa, bordering the Red
Sea, between Djibouti and Sudan
Flag
----
Description: red isosceles triangle (based on the hoist side)
dividing the flag into two right triangles; the upper triangle is
green, the lower one is blue; a gold wreath encircling a gold olive
branch is centered on the hoist side of the red triangle
--------------
Telephones: NA
Telephone system:
domestic: very inadequate; about 4 telephones per 100 families, most
of which are in Asmara; government is seeking international tenders
to improve the system
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave 0
Radios: NA
Television broadcast stations: 1 (government controlled)
Televisions: NA
Defense
-------
Branches: Army, Navy, Air Force
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Estonia
-------
Map
---
Location: 59 00 N, 26 00 E -- Eastern Europe, bordering the Baltic
Sea and Gulf of Finland, between Latvia and Russia
Flag
----
Description: pre-1940 flag restored by Supreme Soviet in May 1990
- three equal horizontal bands of blue (top), black, and white
--------------
Telephones: 400,000
Telephone system: system is antiquated; improvements are being
made piecemeal, with emphasis on business needs and international
connections; there are still about 150,000 unfulfilled requests for
subscriber service
domestic: substantial investment has been made in cellular systems
which are operational throughout Estonia
international: international traffic is carried to the other former
Soviet republics by landline or microwave radio relay and to other
countries partly by leased connection to the Moscow international
gateway switch and partly by a new Tallinn-Helsinki fiber-optic,
submarine cable which gives Estonia access to international circuits
everywhere; access to the international packet-switched digital
network via Helsinki
Radio broadcast stations: AM NA, FM NA, shortwave 0
Radios: 710,000 (1992 est.)
Television broadcast stations: 3
note: provide Estonian programs as well as Moscow Ostenkino''s first
and second programs
Televisions: 600,000 (1993 est.)
Defense
-------
Branches: Ground Forces, Navy, Air and Air Defense Force (not
officially sanctioned), Maritime Border Guard, Volunteer Defense
League (Kaitseliit), Security Forces (internal and border troops),
Coast Guard
Manpower availability:
males age 15-49: 357,835
males fit for military service: 280,757
males reach military age (18) annually: 10,525 (1996 est.)
Defense expenditures: exchange rate conversion - $35 million, 1.5%
of GDP (1995)
======================================================================
@Ethiopia
--------
Map
---
Location: 8 00 N, 38 00 E -- Eastern Africa, west of Somalia
Flag
----
Description: three equal horizontal bands of green (top), yellow,
and red with a yellow pentagram and single yellow rays emanating
from the angles between the points on a light blue disk centered on
the three bands; Ethiopia is the oldest independent country in
Africa, and the colors of her flag were so often adopted by other
African countries upon independence that they became known as the
pan-African colors
--------------
Telephones: 100,000 (1983 est.)
Telephone system: open wire and microwave radio relay system
adequate for government use
domestic: open wire and microwave radio relay
international: open wire to Sudan and Djibouti; microwave radio
relay to Kenya and Djibouti; satellite earth stations - 3 Intelsat
(1 Atlantic Ocean and 2 Pacific Ocean)
Radio broadcast stations: AM 4, FM 0, shortwave 0
Radios: 9.9 million (1992 est.)
Television broadcast stations: 1
Televisions: 100,000 (1993 est.)
Defense
-------
Branches: Ground Forces, Air Force, Police
note: following the secession of Eritrea, Ethiopia''s naval
facilities remained in Eritrea''s possession; current reorganization
plans do not include a navy
Manpower availability:
males age 15-49: 12,912,144
males fit for military service: 6,707,180
males reach military age (18) annually: 583,724 (1996 est.)
Defense expenditures: exchange rate conversion - $140 million,
4.1% of GDP (FY93/94)
======================================================================
@Europa Island
-------------
(possession of France)
Map
---
Location: 22 20 S, 40 22 E -- Southern Africa, island in the
Mozambique Channel, about one-half of the way from southern
Madagascar to southern Mozambique
Flag
----
Description: the flag of France is used
--------------
Communications note: 1 meteorological station
Defense
-------
Defense note: defense is the responsibility of France
======================================================================
@Falkland Islands (Islas Malvinas)
---------------------------------
(dependent territory of the UK)
Map
---
Location: 51 45 S, 59 00 W -- Southern South America, islands in
the South Atlantic Ocean, east of southern Argentina
Flag
----
Description: blue with the flag of the UK in the upper hoist-side
quadrant and the Falkland Island coat of arms in a white disk
centered on the outer half of the flag; the coat of arms contains a
white ram (sheep raising is the major economic activity) above the
sailing ship Desire (whose crew discovered the islands) with a
scroll at the bottom bearing the motto DESIRE THE RIGHT','7cfb0fa7ee719adc4ffeb19cc4dbf8cd505102f193828934099ae8993be2324f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('258fc853ff87a008776f162f4ffbd9b84cb6f97d982b39044505fedba4620b0e',1996,'AR','Argentina','communications',146,'--------------
Telephones: 1,180 (1991 est.)
Telephone system:
domestic: government-operated radiotelephone and private VHF/CB
radiotelephone networks provide effective service to almost all
points on both islands
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
with links through London to other countries
Radio broadcast stations: AM 2, FM 3, shortwave 0
Radios: 1,000 (1992 est.)
Television broadcast stations: 1 (government operated)
Televisions: NA
Defense
-------
Branches: British Forces Falkland Islands (includes Army, Royal
Air Force, Royal Navy, and Royal Marines), Police Force
Defense expenditures: $NA, NA% of GDP
Defense note: defense is the responsibility of the UK
======================================================================
@Faroe Islands
-------------
(part of the Danish realm)
Map
---
Location: 62 00 N, 7 00 W -- Northern Europe, island group between
the Norwegian Sea and the north Atlantic Ocean, about one-half of
the way from Iceland to Norway
Flag
----
Description: white with a red cross outlined in blue that extends
to the edges of the flag; the vertical part of the cross is shifted
to the hoist side in the style of the Dannebrog (Danish flag)
--------------
Telephones: 27,900 (1984 est.)
Telephone system: good international communications; fair domestic
facilities
domestic: NA
international: 3 coaxial submarine cables
Radio broadcast stations: AM 1, FM 3 (repeaters 10), shortwave 0
Radios: 24,000 (1992 est.)
Television broadcast stations: 3 (repeaters 29)
Televisions: 14,000 (1992 est.)
Defense
-------
Branches: no organized native military forces; only a small Police
Force and Coast Guard are maintained
Defense expenditures: $NA, NA% of GDP
Defense note: defense is the responsibility of Denmark
======================================================================
@Fiji
----
Map
---
Location: 18 00 S, 175 00 E -- Oceania, island group in the South
Pacific Ocean, about two-thirds of the way from Hawaii to New Zealand
Flag
----
Description: light blue with the flag of the UK in the upper
hoist-side quadrant and the Fijian shield centered on the outer half
of the flag; the shield depicts a yellow lion above a white field
quartered by the cross of Saint George featuring stalks of
sugarcane, a palm tree, bananas, and a white dove
--------------
Telephones: 60,017 (1987 est.)
Telephone system: modern local, interisland, and international
(wire/radio integrated) public and special-purpose telephone,
telegraph, and teleprinter facilities; regional radio communications
center
domestic: NA
international: access to important cable link between US and Canada
and NZ and Australia; satellite earth station - 1 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM 7, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 0
Televisions: 12,000 (1992 est.)
Defense
-------
Branches: Republic of Fiji Military Forces (RFMF; includes army,
navy, and air elements)
Manpower availability:
males age 15-49: 205,616
males fit for military service: 113,339
males reach military age (18) annually: 8,746 (1996 est.)
Defense expenditures: exchange rate conversion - $28 million, 2.5%
of GDP (1995)
======================================================================
@Finland
-------
Map
---
Location: 64 00 N, 26 00 E -- Northern Europe, bordering the
Baltic Sea, Gulf of Bothnia, and Gulf of Finland, between Sweden and
Russia
Flag
----
Description: white with a blue cross that extends to the edges of
the flag; the vertical part of the cross is shifted to the hoist
side in the style of the Dannebrog (Danish flag)
--------------
Telephones: 2.78 million (1986 est.)
Telephone system: good service from cable and microwave radio
relay network
domestic: cable and microwave radio relay
international: 1 submarine cable; satellite earth stations - access
to Intelsat transmission service via a Swedish satellite earth
station, 1 Inmarsat (Atlantic and Indian Ocean Regions); note -
Finland shares the Inmarsat earth station with the other Nordic
countries (Denmark, Iceland, Norway, and Sweden)
Radio broadcast stations: AM 6, FM 105, shortwave 0
Radios: 4.98 million (1991 est.)
Television broadcast stations: 235
Televisions: 2.1 million (1983 est.)
Defense
-------
Branches: Army, Navy, Air Force, Frontier Guard (includes Sea
Guard)
Manpower availability:
males age 15-49: 1,307,128
males fit for military service: 1,074,540
males reach military age (17) annually: 32,760 (1996 est.)
Defense expenditures: exchange rate conversion - $1.9 billion,
1.6% of GDP (1995)
======================================================================
@France
------
Map
---
Location: 46 00 N, 2 00 E -- Western Europe, bordering the Bay of
Biscay and English Channel, between Belgium and Spain southeast of
the UK; bordering the Mediterranean Sea, between Italy and Spain
Flag
----
Description: three equal vertical bands of blue (hoist side),
white, and red; known as the French Tricouleur (Tricolor); the
design and colors are similar to a number of other flags, including
those of Belgium, Chad, Ireland, Cote d''Ivoire, and Luxembourg; the
official flag for all French dependent areas
--------------
Telephones: 35 million (1987 est.)
Telephone system: highly developed
domestic: extensive cable and microwave radio relay; extensive
introduction of fiber-optic cable; domestic satellite system
international: satellite earth stations - 2 Intelsat (with total of
5 antennas - 2 for Indian Ocean and 3 for Atlantic Ocean), NA
Eutelsat, 1 Inmarsat (Atlantic Ocean Region); HF radiotelephone
communications with more than 20 countries
Radio broadcast stations: AM 41, FM 800 (mostly repeaters),
shortwave 0
Radios: 49 million (1993 est.)
Television broadcast stations: 846 (mostly repeaters)
note: Eutelsat receive-only TV service
Televisions: 29.3 million (1993 est.)
Defense
-------
Branches: Army, Navy (includes Naval Air), Air Force and Air
Defense, National Gendarmerie
Manpower availability:
males age 15-49: 14,782,577
males fit for military service: 12,299,651
males reach military age (18) annually: 383,252 (1996 est.)
Defense expenditures: exchange rate conversion - $47.7 billion,
2.5% of GDP (1995)
======================================================================
@French Guiana
-------------
(overseas department of France)
Map
---
Location: 4 00 N, 53 00 W -- Northern South America, bordering the
North Atlantic Ocean, between Brazil and Suriname
Flag
----
Description: the flag of France is used
--------------
Telephones: 31,000 (1990 est.)
Telephone system:
domestic: fair open wire and microwave radio relay system
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 7, shortwave 0
Radios: 79,000 (1992 est.)
Television broadcast stations: 9
Televisions: 22,000 (1992 est.)
Defense
-------
Branches: French Forces, Gendarmerie
Manpower availability:
males age 15-49: 43,412
males fit for military service: 28,171 (1996 est.)
Defense expenditures: $NA, NA% of GDP
Defense note: defense is the responsibility of France
======================================================================
@French Polynesia
----------------
(overseas territory of France)
Map
---
Location: 15 00 S, 140 00 W -- Oceania, archipelago in the South
Pacific Ocean, about one-half of the way from South America to
Flag
----
Description: three equal, horizontal bands of red (top), white,
and blue with an emblem centered in the white band; unusual flag in
that the emblem is different on each side; the obverse (hoist side
at the left) bears the national coat of arms (a yellow five-pointed
star within a green wreath capped by the words REPUBLICA DEL
PARAGUAY, all within two circles); the reverse (hoist side at the
right) bears the seal of the treasury (a yellow lion below a red Cap
of Liberty and the words Paz y Justicia (Peace and Justice) capped
by the words REPUBLICA DEL PARAGUAY, all within two circles)
--------------
Telephones: NA
Telephone system:
domestic: NA
international: coastal radiotelephone station at Grytviken
Radio broadcast stations: AM 0, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 0
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the UK
======================================================================
@Spain
-----
Map
---
Location: 40 00 N, 4 00 W -- Southwestern Europe, bordering the
Bay of Biscay, Mediterranean Sea, and North Atlantic Ocean,
southwest of France
Flag
----
Description: three horizontal bands of red (top), yellow (double
width), and red with the national coat of arms on the hoist side of
the yellow band; the coat of arms includes the royal seal framed by
the Pillars of Hercules, which are the two promontories (Gibraltar
and Ceuta) on either side of the eastern end of the Strait of','607fd3c62fddf7f571b34f88b70bf2ba1b14b64c9f830d6d6635f5132ea77060','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f856aed6729e48e7055ee93c4b252376c71dcbf6f5946b9962261915419a3965',1996,'NR','Nauru','communications',151,'--------------
Telephones: 33,200 (1983 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 5, FM 2, shortwave 0
Radios: 116,000 (1992 est.)
Television broadcast stations: 6
Televisions: 35,000 (1992 est.)
Defense
-------
Branches: French Forces (includes Army, Navy, Air Force),
Gendarmerie
Defense note: defense is the responsibility of France
======================================================================
@French Southern and Antarctic Lands
-----------------------------------
(overseas territory of France)
Map
---
Location: 43 00 S, 67 00 E -- Southern Africa, islands in the
southern Indian Ocean, about equidistant between Africa, Antarctica,
and Australia; note - French Southern and Antarctic Lands includes
Ile Amsterdam, Ile Saint-Paul, Iles Crozet, and Iles Kerguelen in
the southern Indian Ocean, along with the French-claimed sector of
Antarctica, "Adelie Land"; the US does not recognize the French
claim to "Adelie Land"
Flag
----
Description: the flag of France is used
--------------
Telephones: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of France
======================================================================
@Gabon
-----
Map
---
Location: 1 00 S, 11 45 E -- Western Africa, bordering the
Atlantic Ocean at the Equator, between Congo and Equatorial Guinea
Flag
----
Description: three equal horizontal bands of green (top), yellow,
and blue
--------------
Telephones: 22,000 (1991 est.)
Telephone system:
domestic: adequate system of cable, microwave radio relay,
tropospheric scatter, radiotelephone communication stations, and a
domestic satellite system with 12 earth stations
international: satellite earth stations - 3 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 6, FM 6, shortwave 0
Radios: 250,000 (1993 est.)
Television broadcast stations: 3 (repeaters 5)
Televisions: 40,000 (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, Presidential Guard, National
Gendarmerie, National Police
Manpower availability:
males age 15-49: 273,662
males fit for military service: 139,439
males reach military age (20) annually: 10,966 (1996 est.)
Defense expenditures: exchange rate conversion - $154 million,
2.4% of GDP (1993)
======================================================================
@Gaza Strip
----------
The Israel-PLO Declaration of Principles on Interim Self-Government
Arrangements ("the DOP"), signed in Washington on 13 September 1993,
provides for a transitional period not exceeding five years of
Palestinian interim self-government in the Gaza Strip and the West
Bank. Permanent status negotiations began on 5 May 1996.
Map
---
Location: 31 25 N, 34 20 E -- Middle East, bordering the
Mediterranean Sea, between Egypt and Israel
--------------
Telephones: NA
note: 10% of Palestinian households have telephones (1992 est.)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM 0, shortwave 0
Radios: NA; note - 95% of Palestinian households have radios (1992
est.)
Television broadcast stations: 0
Televisions: NA; note - 59% of Palestinian households have
televisions (1992 est.)
Defense
-------
Branches: NA
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Georgia
-------
Beset by ethnic and civil strife since independence in 1991, Georgia
began to stabilize in 1994. Separatist conflicts in Abkhazia and
South Ossetia have been dormant for more than two years, although
political settlements remain elusive. Russian peacekeepers are
deployed in both regions and a UN Observer Mission is operating in
Abkhazia. As a result of these conflicts, Georgia still has about
250,000 internally displaced people. In November 1995, Georgia held
peaceful, generally free and fair nationwide presidential and
parliamentary elections. Although the country continues to suffer
from a crippling economic crisis, aggravated by a severe energy
shortage, some progress has been made and the Georgian Government
remains committed to economic reform in cooperation with the IMF and
the World Bank. Violence and organized crime were sharply curtailed
in 1995.
Map
---
Location: 42 00 N, 43 30 E -- Southwestern Asia, bordering the
Black Sea, between Turkey and Russia
Flag
----
Description: maroon field with small rectangle in upper hoist side
corner; rectangle divided horizontally with black on top, white below
--------------
Telephones: 672,000 (1993 est.)
Telephone system: poor service; 339,000 unsatisfied applications
for telephones (December 1990 est.)
domestic: NA
international: landline to CIS members and Turkey; satellite earth
station - 1 Eutelsat; leased connections with other countries via
the Moscow international gateway switch; international electronic
mail and telex service available
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: NA
Television broadcast stations: 3
Televisions: NA
Defense
-------
Branches: Ground Forces, Navy, Air and Air Defense Forces,
Republic Security Forces (internal and border troops)
Manpower availability:
males age 15-49: 1,288,291
males fit for military service: 1,021,632
males reach military age (18) annually: 40,654 (1996 est.)
Defense expenditures: exchange rate conversion - $60 million to
$65 million, NA% of GDP (1995)
======================================================================
@Germany
-------
Map
---
Location: 51 00 N, 9 00 E -- Central Europe, bordering the Baltic
Sea and the North Sea, between the Netherlands and Poland, south of','6410e91ca1ddc25981b21bbadcee1f6cf17ef00d29b6ebbc7c7bd088d26b601f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9410f9827e304f0a65e7fc6348521e010a72beca66c191bfd458fb3ada68ceb9',1996,'DK','Denmark','communications',154,'Flag
----
Description: three equal horizontal bands of black (top), red, and
yellow
--------------
Telephones: 44 million
Telephone system: Germany has one of the world''s most
technologically advanced telecommunications systems; as a result of
intensive capital expenditures since reunification, the formerly
backward system of the eastern part of the country is being rapidly
modernized and integrated with that of the western part
domestic: the region which was formerly West Germany is served by an
extensive system of automatic telephone exchanges connected by
modern networks of fiber-optic cable, coaxial cable, microwave radio
relay, and a domestic satellite system; cellular telephone service
is widely available and includes roaming service to many foreign
countries; since the reunification of Germany, the telephone system
of the eastern region has been upgraded and enjoys many of the
advantages of the national system
international: satellite earth stations - 14 Intelsat (12 Atlantic
Ocean and 2 Indian Ocean), 1 Eutelsat, 1 Inmarsat (Atlantic Ocean
region), 2 Intersputnik (1 Atlantic Ocean region and 1 Indian Ocean
region); 6 submarine cable connections; 2 HF radiotelephone
communication centers; tropospheric scatter links
Radio broadcast stations:
western: AM 80, FM 470, shortwave 0
eastern: AM 23, FM 17, shortwave 0
Radios: 70 million (1991 est.)
Television broadcast stations: 246 (repeaters 6,000); note - there
are 15 Russian repeaters in eastern Germany
Televisions: 44.8 million (1992 est.)
Defense
-------
Branches: Army, Navy (includes Naval Air Arm), Air Force, Border
Police, Coast Guard
Manpower availability:
males age 15-49: 21,540,919
males fit for military service: 18,537,347
males reach military age (18) annually: 449,292 (1996 est.)
Defense expenditures: exchange rate conversion - $42.8 billion,
1.5% of GDP (1995)
======================================================================
@Ghana
-----
Map
---
Location: 8 00 N, 2 00 W -- Western Africa, bordering the North
Atlantic Ocean, between Cote d''Ivoire and Togo
Flag
----
Description: three equal horizontal bands of red (top), yellow,
and green with a large black five-pointed star centered in the
yellow band; uses the popular pan-African colors of Ethiopia;
similar to the flag of Bolivia, which has a coat of arms centered in
the yellow band
--------------
Telephones: 70,000 (1988 est.)
Telephone system: poor to fair system
domestic: primarily microwave radio relay
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 4, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 4 (repeaters 8)
Televisions: 250,000 (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, Police Force, Palace Guard, Civil
Defense
Manpower availability:
males age 15-49: 4,135,538
males fit for military service: 2,303,423
males reach military age (18) annually: 176,332 (1996 est.)
Defense expenditures: exchange rate conversion - $30 million, 0.8%
of GDP (1994)
======================================================================
@Gibraltar
---------
(dependent territory of the UK)
Map
---
Location: 36 11 N, 5 22 W -- Southwestern Europe, bordering the
Strait of Gibraltar, which links the Mediterranean Sea and the North
Atlantic Ocean, on the southern coast of Spain
Flag
----
Description: two horizontal bands of white (top, double width) and
red with a three-towered red castle in the center of the white band;
hanging from the castle gate is a gold key centered in the red band
--------------
Telephones: 19,529 (1993 est.)
Telephone system: adequate, automatic domestic system and adequate
international facilities
domestic: automatic exchange facilities
international: radiotelephone; microwave radio relay; satellite
earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 6, shortwave 0
Radios: NA
Television broadcast stations: 4
Televisions: NA
Defense
-------
Branches: British Army, Royal Navy, Royal Air Force
Defense note: defense is the responsibility of the UK
======================================================================
@Glorioso Islands
----------------
(possession of France)
Map
---
Location: 11 30 S, 47 20 E -- Southern Africa, group of islands in
the Indian Ocean, northwest of Madagascar
Flag
----
Description: the flag of France is used','a8f92e167758eb2c5001e37fe2089bfc7d3b7367c5f6170f3e7f344bb4139068','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0ef16fa50fdd771381460a1a83f6effdb21bbdeca2c7390317508aeb2ed811f',1996,'CA','Canada','communications',167,'--------------
Telephones: 17,900 (1984 est.)
Telephone system: adequate domestic and international service
provided by cables and microwave radio relay
domestic: microwave radio relay
international: 2 coaxial submarine cables; satellite earth station -
1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 7 (repeaters 35), shortwave 0
Radios: 23,000 (1991 est.)
Television broadcast stations: 4 (repeaters 9)
Televisions: 12,000 (1991 est.)
Defense
-------
Defense note: defense is the responsibility of Denmark
======================================================================
@Grenada
-------
Map
---
Location: 12 07 N, 61 40 W -- Caribbean, island in the Caribbean
Sea, north of Trinidad and Tobago
Flag
----
Description: a rectangle divided diagonally into yellow triangles
(top and bottom) and green triangles (hoist side and outer side)
with a red border around the flag; there are seven yellow
five-pointed stars with three centered in the top red border, three
centered in the bottom red border, and one on a red disk
superimposed at the center of the flag; there is also a symbolic
nutmeg pod on the hoist-side triangle (Grenada is the world''s
second-largest producer of nutmeg, after Indonesia); the seven stars
represent the seven administrative divisions','e624bb8498e678354c858ac216ace0110d1b153fdbeddb17d1b144ab8d8e3c81','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88d008820692d7f64ca9c5fcafc36ffb7a72b65d7d69d108649e98bfa1f34263',1996,'MQ','Martinique','communications',168,'Radio broadcast stations: AM 2, FM 8 (private stations licensed to
broadcast FM 30), shortwave 0
Radios: 100,000 (1993 est.)
Television broadcast stations: 9
Televisions: 150,000 (1993 est.)
Defense
-------
Branches: French Forces, Gendarmerie
Defense note: defense is the responsibility of France
======================================================================
@Guam
----
(territory of the US)
Map
---
Location: 13 28 N, 144 47 E -- Oceania, island in the North
Pacific Ocean, about three-quarters of the way from Hawaii to the','562672eaaee0ec98adc69df02bd4238e0d96306978581999170cf14932066245','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5daeecc1c7645b81b04cee5494890c6b2b09a39804f99b72afdb82b58564edba',1996,'PH','Philippines','communications',169,'Flag
----
Description: territorial flag is dark blue with a narrow red
border on all four sides; centered is a red-bordered, pointed,
vertical ellipse containing a beach scene, outrigger canoe with
sail, and a palm tree with the word GUAM superimposed in bold red
letters; US flag is the national flag
--------------
Telephones: 26,317 (1989 est.)
Telephone system:
domestic: NA
international: satellite earth stations - 2 Intelsat (Pacific
Ocean); submarine cables to US and Japan
Radio broadcast stations: AM 3, FM 3, shortwave 0
Radios: NA
Television broadcast stations: 3
Televisions: 75,000 (1993 est.)
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Guatemala
---------
Map
---
Location: 15 30 N, 90 15 W -- Middle America, bordering the
Caribbean Sea, between Honduras and Belize and bordering the North
Pacific Ocean, between El Salvador and Mexico
Flag
----
Description: three equal vertical bands of light blue (hoist
side), white, and light blue with the coat of arms centered in the
white band; the coat of arms includes a green and red quetzal (the
national bird) and a scroll bearing the inscription LIBERTAD 15 DE
SEPTIEMBRE DE 1821 (the original date of independence from Spain)
all superimposed on a pair of crossed rifles and a pair of crossed
swords and framed by a wreath
--------------
Telephones: 210,000 (1993 est.)
Telephone system: fairly modern network centered in the city of
======================================================================
@Guernsey
--------
(British crown dependency)
Map
---
Location: 49 28 N, 2 35 W -- Western Europe, islands in the
English Channel, northwest of France
Flag
----
Description: white with the red cross of Saint George (patron
saint of England) extending to the edges of the flag
--------------
Telephones: 41,850 (1983 est.)
Telephone system:
domestic: NA
international: 1 submarine cable
Radio broadcast stations: AM 1, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 1
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the UK
======================================================================
@Guinea
------
Map
---
Location: 11 00 N, 10 00 W -- Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and Sierra Leone
Flag
----
Description: three equal vertical bands of red (hoist side),
yellow, and green; uses the popular pan-African colors of Ethiopia;
similar to the flag of Rwanda, which has a large black letter R
centered in the yellow band
--------------
Telephones: 18,000 (1994 est.)
Telephone system: poor to fair system of open-wire lines, small
radiotelephone communication stations, and new microwave radio relay
system
domestic: microwave radio relay and radiotelephone communication
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 1, shortwave 0
Radios: 257,000 (1992 est.)
Television broadcast stations: 1
Televisions: 65,000 (1993 est.)
Defense
-------
Branches: Army, Navy (acts primarily as a coast guard), Air Force,
Republican Guard, Presidential Guard, paramilitary National
Gendarmerie, National Police Force (Surete National)
Manpower availability:
males age 15-49: 1,684,264
males fit for military service: 849,404 (1996 est.)
Defense expenditures: exchange rate conversion - $50 million, 1.6%
of GDP (1994)
======================================================================
@Guinea-Bissau
-------------
Map
---
Location: 12 00 N, 15 00 W -- Western Africa, bordering the North
Atlantic Ocean, between Guinea and Senegal
Flag
----
Description: two equal horizontal bands of yellow (top) and green
with a vertical red band on the hoist side; there is a black
five-pointed star centered in the red band; uses the popular
pan-African colors of Ethiopia
--------------
Telephones: 3,000 (1988 est.)
Telephone system: poor system
domestic: combination of microwave radio relay, open-wire lines, and
radiotelephone communications
international: NA
Radio broadcast stations: AM 2, FM 3, shortwave 0
Radios: 40,000 (1992 est.)
Television broadcast stations: 1
Televisions: NA
Defense
-------
Branches: People''s Revolutionary Armed Force (FARP; includes Army,
Navy, and Air Force), paramilitary force
Manpower availability:
males age 15-49: 259,738
males fit for military service: 148,291 (1996 est.)
Defense expenditures: exchange rate conversion - $9 million, 4.5%
of GDP (1994)
======================================================================
@Guyana
------
Map
---
Location: 5 00 N, 59 00 W -- Northern South America, bordering the
North Atlantic Ocean, between Suriname and Venezuela
Flag
----
Description: green with a red isosceles triangle (based on the
hoist side) superimposed on a long yellow arrowhead; there is a
narrow black border between the red and yellow, and a narrow white
border between the yellow and the green
--------------
Telephones: 33,000 (1987 est.)
Telephone system: fair system for long-distance calling
domestic: microwave radio relay network for trunk lines
international: tropospheric scatter to Trinidad; satellite earth
station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 4, FM 3, shortwave 1
Radios: 398,000 (1992 est.)
Television broadcast stations: 0 (1987 est.)
Televisions: 32,000 (1992 est.)
Defense
-------
Branches: Guyana Defense Force (GDF; includes Ground Forces, Coast
Guard, and Air Corps), Guyana People''s Militia (GPM), Guyana
National Service (GNS)
Manpower availability:
males age 15-49: 197,548
males fit for military service: 149,646 (1996 est.)
Defense expenditures: exchange rate conversion - $7 million, 1.7%
of GDP (1994)
======================================================================
@Haiti
-----
Map
---
Location: 19 00 N, 72 25 W -- Caribbean, western one-third of the
island of Hispaniola, between the Caribbean Sea and the North
Atlantic Ocean, west of the Dominican Republic
Flag
----
Description: two equal horizontal bands of blue (top) and red with
a centered white rectangle bearing the coat of arms, which contains
a palm tree flanked by flags and two cannons above a scroll bearing
the motto L''UNION FAIT LA FORCE (Union Makes Strength)
--------------
Telephones: 50,000 (1990 est.)
Telephone system: domestic facilities barely adequate,
international facilities slightly better
domestic: NA
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 33, FM 0, shortwave 2
Radios: 320,000 (1992 est.)
Television broadcast stations: 4 (1987 est.)
Televisions: 32,000 (1992 est.)
Defense
-------
Branches: Haitian National Police
Manpower availability:
males age 15-49: 1,379,116
males fit for military service: 746,617
males reach military age (18) annually: 67,287 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Heard Island and McDonald Islands
---------------------------------
(territory of Australia)
Map
---
Location: 53 06 S, 72 31 E -- Southern Africa, islands in the
Indian Ocean, about two-thirds of the way from Madagascar to
Flag
----
Description: blue with a white five-pointed star superimposed on
the gray silhouette of a latte stone (a traditional foundation stone
used in building) in the center, surrounded by a wreath
--------------
Telephones: 13,618 (1993 est.)
Telephone system:
domestic: NA
international: satellite earth stations - 2 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 2, FM 1, shortwave 0 (1984)
Radios: 15,350 (1987 est.)
Television broadcast stations: 1
note: there are 2 cable TV stations
Televisions: 10,650 (1993 est.)
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Norway
------
Map
---
Location: 62 00 N, 10 00 E -- Northern Europe, bordering the North
Sea and the North Atlantic Ocean, west of Sweden
Flag
----
Description: red with a blue cross outlined in white that extends
to the edges of the flag; the vertical part of the cross is shifted
to the hoist side in the style of the Dannebrog (Danish flag)
--------------
Telephones: 2.39 million (1986 est.)
Telephone system: high-quality domestic and international
telephone, telegraph, and telex services
domestic: NA domestic satellite earth stations
international: 2 buried coaxial cable systems; 4 coaxial submarine
cables; satellite earth stations - NA Eutelsat, NA Intelsat
(Atlantic Ocean), and 1 Inmarsat (Atlantic and Indian Ocean
Regions); note - Norway shares the Inmarsat earth station with the
other Nordic countries (Denmark, Finland, Iceland, and Sweden)
Radio broadcast stations: AM 46, FM 493 (350 private and 143
government), shortwave 0
Radios: 3.3 million (1993 est.)
Television broadcast stations: 54 (repeaters 2,100)
Televisions: 1.5 million (1993 est.)
Defense
-------
Branches: Norwegian Army, Royal Norwegian Navy (includes Coast
Artillery and Coast Guard), Royal Norwegian Air Force, Home Guard
Manpower availability:
males age 15-49: 1,125,302
males fit for military service: 937,309
males reach military age (20) annually: 28,328 (1996 est.)
Defense expenditures: exchange rate conversion - $3.7 billion,
2.9% of GDP (1995)
======================================================================
@Oman
----
Map
---
Location: 21 00 N, 57 00 E -- Middle East, bordering the Arabian
Sea, Gulf of Oman, and Persian Gulf, between Yemen and UAE
Flag
----
Description: three horizontal bands of white (top, double width),
red, and green (double width) with a broad, vertical, red band on
the hoist side; the national emblem (a khanjar dagger in its sheath
superimposed on two crossed swords in scabbards) in white is
centered at the top of the vertical band
--------------
Telephones: 150,000 (1994 est.)
Telephone system: modern system consisting of open wire,
microwave, and radiotelephone communication stations; limited
coaxial cable
domestic: open wire, microwave, radiotelephone communications, and a
domestic satellite system with 8 earth stations
international: satellite earth stations - 2 Intelsat (Indian Ocean)
and 1 Arabsat
Radio broadcast stations: AM 2, FM 4, shortwave 1
Radios: 1.043 million (1992 est.)
Television broadcast stations: 9
Televisions: 1.195 million (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, paramilitary (includes Royal Oman
Police)
Manpower availability:
males age 15-49: 532,113
males fit for military service: 301,747 (1996 est.)
Defense expenditures: exchange rate conversion - $1.82 billion,
13.7% of GDP (1996)
======================================================================
@Pacific Ocean
-------------
Map
---
Location: 0 00 N, 160 00 W -- body of water between Antarctica,
Asia, Australia, and the Western Hemisphere
--------------
Telephone system:
international: several submarine cables with network nodal points on
Guam and Hawaii
======================================================================
@Pakistan
--------
Map
---
Location: 30 00 N, 70 00 E -- Southern Asia, bordering the Arabian
Sea, between India and Iran
Flag
----
Description: green with a vertical white band (symbolizing the
role of religious minorities) on the hoist side; a large white
crescent and star are centered in the green field; the crescent,
star, and color green are traditional symbols of Islam
--------------
Telephones: 1.572 million (1993 est.)
Telephone system: the domestic system is mediocre, but adequate
for government and business use, in part because major businesses
have established their own private systems; since 1988, the
government has promoted investment in the national
telecommunications system on a priority basis; despite major
improvements in trunk and urban systems, telecommunication services
are still not readily available to the major portion of the
population
domestic: microwave radio relay
international: satellite earth stations - 3 Intelsat (1 Atlantic
Ocean and 2 Indian Ocean); microwave radio relay to neighboring
countries
Radio broadcast stations: AM 26, FM 8, shortwave 11
Radios: 11.3 million (1992 est.)
Television broadcast stations: 29
Televisions: 2.08 million (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, Civil Armed Forces, National Guard
Manpower availability:
males age 15-49: 30,519,339
males fit for military service: 18,720,175
males reach military age (17) annually: 1,437,208 (1996 est.)
Defense expenditures: exchange rate conversion - $3.1 billion,
5.3% of GDP (FY95/96)
======================================================================
@Palau
-----
Map
---
Location: 7 30 N, 134 30 E -- Oceania, group of islands in the
North Pacific Ocean, southeast of the Philippines
Flag
----
Description: light blue with a large yellow disk (representing the
moon) shifted slightly to the hoist side
--------------
Telephones: 1,500 (1988 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave 0
Radios: 9,000 (1993 est.)
Television broadcast stations: 2
Televisions: 1,600 (1993 est.)
Defense
-------
Branches: NA
Defense expenditures: $NA, NA% of GDP
Defense note: defense is the responsibility of the US
======================================================================
@Palmyra Atoll
-------------
(territory of the US)
Map
---
Location: 5 52 N, 162 06 W -- Oceania, atoll in the North Pacific
Ocean, about one-half of the way from Hawaii to American Samoa
Flag
----
Description: the flag of the US is used','b34360617910fa15a3069465c0cefb9662f563dac35de3516775d119d6cba0a8','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2df9e03ca3f70a47e3842283d5a9271f7eab981dc28637347120b836a7131738',1996,'AQ','Antarctica','communications',178,'Flag
----
Description: the flag of Australia is used
--------------
Telephones: 2,000
Telephone system: automatic exchange
domestic: tied into Italian system
international: uses Italian system
Radio broadcast stations: AM 3, FM 4, shortwave 0
Radios: NA
Television broadcast stations: 0
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of Italy; Swiss Papal
Guards are posted at entrances to Vatican City
======================================================================
@Honduras
--------
Map
---
Location: 15 00 N, 86 30 W -- Middle America, bordering the
Caribbean Sea, between Guatemala and Nicaragua and bordering the
North Pacific Ocean, between El Salvador and Nicaragua
Flag
----
Description: three equal horizontal bands of blue (top), white,
and blue with five blue five-pointed stars arranged in an X pattern
centered in the white band; the stars represent the members of the
former Federal Republic of Central America - Costa Rica, El
Salvador, Guatemala, Honduras, and Nicaragua; similar to the flag of
El Salvador, which features a round emblem encircled by the words
REPUBLICA DE EL SALVADOR EN LA AMERICA CENTRAL centered in the white
band; also similar to the flag of Nicaragua, which features a
triangle encircled by the word REPUBLICA DE NICARAGUA on top and
AMERICA CENTRAL on the bottom, centered in the white band
--------------
Telephones: 105,000 (1992 est.)
Telephone system: inadequate system
domestic: NA
international: satellite earth stations - 2 Intelsat (Atlantic
Ocean); connected to Central American Microwave System
Radio broadcast stations: AM 176, FM 0, shortwave 7
Radios: 2.115 million (1992 est.)
Television broadcast stations: 28
Televisions: 400,000 (1992 est.)
Defense
-------
Branches: Army, Navy (includes Marines), Air Force, Public
Security Forces (FUSEP)
Manpower availability:
males age 15-49: 1,322,525
males fit for military service: 787,889
males reach military age (18) annually: 64,378 (1996 est.)
Defense expenditures: exchange rate conversion - $41 million,
about 0.4% of GDP (1994)
======================================================================
@Hong Kong
---------
(dependent territory of the UK)
Map
---
Location: 22 15 N, 114 10 E -- Eastern Asia, bordering the South
China Sea and China
Flag
----
Description: blue with the flag of the UK in the upper hoist-side
quadrant with the Hong Kong coat of arms on a white disk centered on
the outer half of the flag; the coat of arms contains a shield
(bearing two junks below a crown) held by a lion (representing the
UK) and a dragon (representing China) with another lion above the
shield and a banner bearing the words HONG KONG below the shield
--------------
Telephones: 4.13 million (1995 est.)
Telephone system: modern facilities provide excellent domestic and
international services
domestic: microwave radio relay links and extensive fiber-optic
network
international: satellite earth stations - 3 Intelsat (1 Pacific
Ocean and 2 Indian Ocean); coaxial cable to Guangzhou, China; access
to 5 international submarine cables providing connections to ASEAN
member nations, Japan, Taiwan, Australia, Middle East, and Western
Europe
Radio broadcast stations: AM 6, FM 6, shortwave 0
Radios: 3 million (1992 est.)
Television broadcast stations: 4 (British Broadcasting Corporation
repeater 1; British Forces Broadcasting Service repeater 1)
Televisions: 1.75 million (1992 est.)
Defense
-------
Branches: Headquarters of British Forces, Army, Royal Navy, Royal
Air Force, Royal Hong Kong Auxiliary Air Force, Royal Hong Kong
Police Force
Manpower availability:
males age 15-49: 1,895,535
males fit for military service: 1,442,072
males reach military age (18) annually: 46,248 (1996 est.)
Defense expenditures: exchange rate conversion - $207 million,
0.2% of GDP (FY92/93); this represents 65% of the total cost of
defending the colony, the remainder being paid by the UK
Defense note: defense is the responsibility of the UK until 1 July
1997, when China will assume command
======================================================================
@Howland Island
--------------
(territory of the US)
Map
---
Location: 0 48 N, 176 38 W -- Oceania, island in the North Pacific
Ocean, about one-half of the way from Hawaii to Australia
Flag
----
Description: the flag of the US is used
--------------
Telephones: 1.52 million (1993 est.)
Telephone system: 14,213 telex lines; automatic telephone network
based on microwave radio relay system; 608,000 telephones on order;
12-15 year wait for a telephone; 49% of all telephones are in
Budapest (1991 est.); note - the former state-owned
telecommunications firm MATAV - now privatized and managed by a
US/German consortium - has ambitious plans to upgrade the inadequate
system, including a contract with the German firm Siemens and the
Swedish firm Ericsson to provide 600,000 new phone lines during
1996-98
domestic: microwave radio relay
international: satellite earth stations - 1 Intelsat and 1
Intersputnik (Atlantic Ocean Region)
Radio broadcast stations: AM 32, FM 15, shortwave 0
Radios: 6 million (1993 est.)
Television broadcast stations: 41 (Russian repeaters 8)
Televisions: 4.38 million (1993 est.)
Defense
-------
Branches: Ground Forces, Air and Air Defense Forces, Border Guard,
Territorial Defense
Manpower availability:
males age 15-49: 2,552,794
males fit for military service: 2,036,399
males reach military age (18) annually: 82,040 (1996 est.)
Defense expenditures: exchange rate conversion - $620 million,
1.7% of GDP (1995)
======================================================================
@Iceland
-------
Map
---
Location: 65 00 N, 18 00 W -- Northern Europe, island between the
Greenland Sea and the North Atlantic Ocean, northwest of the UK
Flag
----
Description: blue with a red cross outlined in white that extends
to the edges of the flag; the vertical part of the cross is shifted
to the hoist side in the style of the Dannebrog (Danish flag)
--------------
Telephones: 143,600 (1993 est.)
Telephone system: adequate domestic service
domestic: the trunk network consists of coaxial and fiber-optic
cables and microwave radio relay links
international: satellite earth stations - 2 Intelsat (Atlantic
Ocean), 1 Inmarsat (Atlantic and Indian Ocean Regions); note -
Iceland shares the Inmarsat earth station with the other Nordic
countries (Denmark, Finland, Norway, and Sweden)
Radio broadcast stations: AM 5, FM 147 (transmitters and
repeaters), shortwave 0
Radios: 91,500 licensed (1993 est.)
Television broadcast stations: 202 (transmitters and repeaters)
Televisions: 96,100 licensed (1993 est.)
Defense
-------
Branches: no regular armed forces; Police, Coast Guard; note -
Iceland''s defense is provided by the US-manned Icelandic Defense
Force (IDF) headquartered at Keflavik
Manpower availability:
males age 15-49: 71,317
males fit for military service: 63,126 (1996 est.)
Defense expenditures: none
======================================================================
@India
-----
Map
---
Location: 20 00 N, 77 00 E -- Southern Asia, bordering the Arabian
Sea and the Bay of Bengal, between Burma and Pakistan
Flag
----
Description: three equal horizontal bands of orange (top), white,
and green with a blue chakra (24-spoked wheel) centered in the white
band; similar to the flag of Niger, which has a small orange disk
centered in the white band
--------------
Telephones: 9.8 million (1995)
Telephone system: probably the least adequate telephone system of
any of the industrializing countries; three of every four villages
have no telephone service; only 5% of India''s villages have
long-distance service; poor telephone service significantly impedes
commercial and industrial growth and penalizes India in global
markets; slow improvement is taking place with the recent admission
of private and private-public investors, but demand for
communication services is also growing rapidly
domestic: local service is provided mostly by open wire and obsolete
electromechanical and manual switchboard systems; within the last 10
years a substantial amount of digital switch gear has been
introduced for local service; long-distance traffic is carried
mostly by open wire, coaxial cable, and low-capacity microwave radio
relay; since 1985, however, significant trunk capacity has been
added in the form of fiber-optic cable and a domestic satellite
system with over 100 earth stations
international: satellite earth stations - 8 Intelsat (Indian Ocean)
and 1 Inmarsat (Indian Ocean Region); submarine cables to Malaysia
and UAE
Radio broadcast stations: AM 96, FM 4, shortwave 0
Radios: 70 million (1992 est.)
Television broadcast stations: 274 (government controlled)
Televisions: 33 million (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, various security or paramilitary
forces (includes Border Security Force, Assam Rifles, and Coast
Guard)
Manpower availability:
males age 15-49: 260,624,007
males fit for military service: 153,176,413
males reach military age (17) annually: 9,770,331 (1996 est.)
Defense expenditures: exchange rate conversion - $8.0 billion,
2.7% of GDP (FY95/96)
======================================================================
@Indian Ocean
------------
Map
---
Location: 30 00 S, 80 00 E -- body of water between Africa,
Antarctica, Asia, and Australia','9de1f1139117fed6aa7314f09ee4087cfcf05a388bb7f1ee19e804ad5ff7a243','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69a75f90853a40589b5c02e66d90d0b71b6121283de6daee86c705d7603f134b',1996,'PK','Pakistan','communications',185,'Flag
----
Description: three equal horizontal bands of green (top), white,
and red; the national emblem (a stylized representation of the word
Allah) in red is centered in the white band; ALLAH AKBAR (God is
Great) in white Arabic script is repeated 11 times along the bottom
edge of the green band and 11 times along the top edge of the red
band','a04099e85cb56bf47e368df26454b0f5c60c65daa7ab16243f258c2e4aba2f08','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e128bc08cd233f0761e98c889f602c504c1af0542aa38a6d023760b541402d55',1996,'AF','Afghanistan','communications',197,'--------------
Telephones: 3.02 million (1992 est.)
Telephone system:
domestic: microwave radio relay extends throughout country; system
centered in Tehran
international: satellite earth stations - 3 Intelsat (2 Atlantic
Ocean and 1 Indian Ocean) and 1 Inmarsat (Indian Ocean Region); HF
radio and microwave radio relay to Turkey, Pakistan, Syria, Kuwait,
Tajikistan, and Uzbekistan; submarine fiber-optic cable to UAE
Radio broadcast stations: AM 77, FM 3, shortwave 0
Radios: 14.3 million (1992 est.)
Television broadcast stations: 28
Televisions: 3.9 million (1992 est.)
Defense
-------
Branches: Islamic Republic of Iran regular forces (includes Ground
Forces, Navy, Air and Air Defense Forces), Revolutionary Guards
(includes Ground, Air, Navy, Qods, and Basij-mobilization-forces),
Law Enforcement Forces
Manpower availability:
males age 15-49: 15,157,796
males fit for military service: 9,010,648
males reach military age (21) annually: 632,602 (1996 est.)
Defense expenditures: according to official Iranian data, Iran in
1994 budgeted 4,377 billion rials and in 1993 spent 2,182 billion
rials, including $850 million in hard currency; note - conversion of
defense expenditures into US dollars using current exchange rates
could produce misleading results
======================================================================
@Iraq
----
Map
---
Location: 33 00 N, 44 00 E -- Middle East, bordering the Persian
Gulf, between Iran and Kuwait
Flag
----
Description: three equal horizontal bands of red (top), white, and
black with three green five-pointed stars in a horizontal line
centered in the white band; the phrase ALLAHU AKBAR (God is Great)
in green Arabic script - Allahu to the right of the middle star and
Akbar to the left of the middle star - was added in January 1991
during the Persian Gulf crisis; similar to the flag of Syria that
has two stars but no script and the flag of Yemen that has a plain
white band; also similar to the flag of Egypt that has a symbolic
eagle centered in the white band
--------------
Telephones: 632,000 (1987 est.)
Telephone system: reconstitution of damaged telecommunication
facilities began after the Gulf war; most damaged facilities have
been rebuilt
domestic: the network consists of coaxial cables and microwave radio
relay links
international: satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean), 1 Intersputnik (Atlantic Ocean Region)
and 1 Arabsat; coaxial cable and microwave radio relay to Jordan,
Kuwait, Syria, and Turkey; Kuwait line is probably nonoperational
Radio broadcast stations: AM 16, FM 1, shortwave 0
Radios: 4.02 million (1991 est.)
Television broadcast stations: 13
Televisions: 1 million (1992 est.)
Defense
-------
Branches: Army, Republican Guard and Special Republican Guard,
Navy, Air Force, Air Defense Force, Border Guard Force, Internal
Security Forces
Manpower availability:
males age 15-49: 4,832,001
males fit for military service: 2,711,312
males reach military age (18) annually: 237,843 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Ireland
-------
Map
---
Location: 53 00 N, 8 00 W -- Western Europe, occupying five-sixths
of the island of Ireland in the North Atlantic Ocean, west of Great
Britain
Flag
----
Description: three equal vertical bands of green (hoist side),
white, and orange; similar to the flag of Cote d''Ivoire, which is
shorter and has the colors reversed - orange (hoist side), white,
and green; also similar to the flag of Italy, which is shorter and
has colors of green (hoist side), white, and red
--------------
Telephones: 900,000 (1987 est.)
Telephone system: modern digital system using cable and microwave
radio relay
domestic: microwave radio relay
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 9, FM 45, shortwave 0
Radios: 2.2 million (1991 est.)
Television broadcast stations: 86 (1987 est.)
Televisions: 1.025 million (1990 est.)
Defense
-------
Branches: Army (includes Naval Service and Air Corps), National
Police (Garda Siochana)
Manpower availability:
males age 15-49: 939,237
males fit for military service: 761,048
males reach military age (17) annually: 35,904 (1996 est.)
Defense expenditures: exchange rate conversion - $618 million,
1.3% of GDP (1994)
======================================================================
@Israel
------
(also see separate Gaza Strip and West Bank entries)
Note: The territories occupied by Israel since the 1967 war are
not included in the data below. In keeping with the framework
established at the Madrid Conference in October 1991, bilateral
negotiations are being conducted between Israel and Palestinian
representatives, and Israel and Syria, to achieve a permanent
settlement between them. On 25 April 1982, Israel withdrew from the
Sinai pursuant to the 1979 Israel-Egypt Peace treaty. Outstanding
territorial and other disputes with Jordan were resolved in the 26
October 1994 Israel-Jordan Treaty of Peace.
Map
---
Location: 31 30 N, 34 45 E -- Middle East, bordering the
Mediterranean Sea, between Egypt and Lebanon
Flag
----
Description: white with a blue hexagram (six-pointed linear star)
known as the Magen David (Shield of David) centered between two
equal horizontal blue bands near the top and bottom edges of the flag
--------------
Telephones: 2.425 million (1990 est.)
Telephone system: most highly developed system in the Middle East
although not the largest
domestic: good system of coaxial cable and microwave radio relay
international: 3 submarine cables; satellite earth stations - 3
Intelsat (2 Atlantic Ocean and 1 Indian Ocean)
Radio broadcast stations: AM 9, FM 45, shortwave 0
Radios: 2.25 million (1993 est.)
Television broadcast stations: 20
Televisions: 1.5 million (1993 est.)
Defense
-------
Branches: Israel Defense Forces (includes ground, naval, and air
components), Pioneer Fighting Youth (Nahal), Frontier Guard, Chen
(women); note - historically there have been no separate Israeli
military services
Manpower availability:
males age 15-49: 1,390,603
females age 15-49: 1,363,986
males fit for military service: 1,139,137
females fit for military service: 1,112,947
males reach military age (18) annually: 50,508
females reach military age (18) annually: 48,176 (1996 est.)
Defense expenditures: exchange rate conversion - $9.2 billion,
about 9.8% of GDP (1996)
======================================================================
@Italy
-----
Map
---
Location: 42 50 N, 12 50 E -- Southern Europe, a peninsula
extending into the central Mediterranean Sea, northeast of Tunisia
Flag
----
Description: three equal vertical bands of green (hoist side),
white, and red; similar to the flag of Ireland, which is longer and
is green (hoist side), white, and orange; also similar to the flag
of the Cote d''Ivoire, which has the colors reversed - orange (hoist
side), white, and green
--------------
Telephones: 25.6 million (1987 est.)
Telephone system: modern, well-developed, fast; fully automated
telephone, telex, and data services
domestic: high-capacity cable and microwave radio relay trunks
international: satellite earth stations - 3 Intelsat (with a total
of 5 antennas - 3 for Atlantic Ocean and 2 for Indian Ocean), 1
Inmarsat (Atlantic Ocean Region), and NA Eutelsat; 21 submarine
cables
Radio broadcast stations: AM 135, FM 28 (repeaters 1,840),
shortwave 0
Radios: 45.7 million (1992 est.)
Television broadcast stations: 83 (repeaters 1,000)
Televisions: 24.35 million (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, Carabinieri
Manpower availability:
males age 15-49: 14,739,097
males fit for military service: 12,769,628
males reach military age (18) annually: 358,884 (1996 est.)
Defense expenditures: exchange rate conversion - $20.4 billion,
1.9% of GDP (1995)
======================================================================
@Jamaica
-------
Map
---
Location: 18 15 N, 77 30 W -- Caribbean, island in the Caribbean
Sea, south of Cuba
Flag
----
Description: diagonal yellow cross divides the flag into four
triangles - green (top and bottom) and black (hoist side and outer
side)
--------------
Telephones: 212,257 (1991 est.)
Telephone system: fully automatic domestic telephone network
domestic: NA
international: satellite earth stations - 2 Intelsat (Atlantic
Ocean); 3 coaxial submarine cables
Radio broadcast stations: AM 10, FM 17, shortwave 0
Radios: 1.04 million (1992 est.)
Television broadcast stations: 8
Televisions: 330,000 (1992 est.)
Defense
-------
Branches: Jamaica Defense Force (includes Ground Forces, Coast
Guard and Air Wing), Jamaica Constabulary Force
Manpower availability:
males age 15-49: 680,965
males fit for military service: 481,616
males reach military age (18) annually: 25,810 (1996 est.)
Defense expenditures: exchange rate conversion - $30 million, NA%
of GDP (FY95/96)
======================================================================
@Jan Mayen
---------
(territory of Norway)
Map
---
Location: 71 00 N, 8 00 W -- Northern Europe, island between the
Greenland Sea and the Norwegian Sea, northeast of Iceland
Flag
----
Description: the flag of Norway is used
--------------
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave NA
note: radio and meteorological station
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of Norway
======================================================================
@Japan
-----
Map
---
Location: 36 00 N, 138 00 E -- Eastern Asia, island chain between
the North Pacific Ocean and the Sea of Japan, east of the Korean
Peninsula
Flag
----
Description: white with a large red disk (representing the sun
without rays) in the center
--------------
Telephones: 64 million (1987 est.)
Telephone system: excellent domestic and international service
domestic: NA
international: satellite earth stations - 5 Intelsat (4 Pacific
Ocean and 1 Indian Ocean), 1 Intersputnik (Indian Ocean Region), and
1 Inmarsat (Pacific and Indian Ocean Regions); submarine cables to
China, Philippines, Russia, and US (via Guam)
Radio broadcast stations: AM 318, FM 58, shortwave 0
Radios: 97 million (1993 est.)
Television broadcast stations: 12,350 (1 kW or greater 196)
Televisions: 100 million (1993 est.)
Defense
-------
Branches: Japan Ground Self-Defense Force (Army), Japan Maritime
Self-Defense Force (Navy), Japan Air Self-Defense Force (Air Force)
Manpower availability:
males age 15-49: 31,833,691
males fit for military service: 27,322,517
males reach military age (18) annually: 858,912 (1996 est.)
Defense expenditures: exchange rate conversion - $50.2 billion, 1%
of GDP (FY95/96)
======================================================================
@Jarvis Island
-------------
(territory of the US)
Map
---
Location: 0 22 S, 160 03 W -- Oceania, island in the South Pacific
Ocean, about one-half of the way from Hawaii to the Cook Islands
Flag
----
Description: the flag of the US is used
--------------
Telephones: 61,447 (1983 est.)
Telephone system:
domestic: NA
international: 3 submarine cables
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 1
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the UK
======================================================================
@Johnston Atoll
--------------
(territory of the US)
Map
---
Location: 16 45 N, 169 30 W -- Oceania, atoll in the North Pacific
Ocean, about one-third of the way from Hawaii to the Marshall Islands
Flag
----
Description: the flag of the US is used
--------------
Telephones: NA
Telephone system: 52 telephone lines; excellent system
domestic: 60-channel submarine cable, 22 DSN circuits by satellite,
Autodin with standard remote terminal, digital telephone switch,
Military Affiliated Radio System (MARS station), UHF/VHF air-ground
radio, a link to the Pacific Consolidated Telecommunications Network
(PCTN) satellite, and amateur radio
international: NA
Radio broadcast stations: AM NA, FM 5, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Jordan
------
Map
---
Location: 31 00 N, 36 00 E -- Middle East, northwest of Saudi
Arabia
Flag
----
Description: three equal horizontal bands of black (top), white,
and green with a red isosceles triangle based on the hoist side
bearing a small white seven-pointed star; the seven points on the
star represent the seven fundamental laws of the Koran
--------------
Telephones: 81,500 (1987 est.)
Telephone system: adequate telephone system
domestic: microwave radio relay, cable, and radiotelephone links
international: satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean) and 1 Arabsat; coaxial cable and microwave
radio relay to Iraq, Saudi Arabia, and Syria; microwave radio relay
to Lebanon is inactive; participant in Medarabtel
Radio broadcast stations: AM 5, FM 7, shortwave 0
Radios: 1.1 million (1992 est.)
Television broadcast stations: 8 and 1 TV receive-only satellite
link
Televisions: 350,000 (1992 est.)
Defense
-------
Branches: Jordanian Armed Forces (JAF; includes Royal Jordanian
Land Force, Royal Naval Force, and Royal Jordanian Air Force);
Ministry of the Interior''s Public Security Force (falls under JAF
only in wartime or crisis situations)
Manpower availability:
males age 15-49: 1,011,588
males fit for military service: 721,460
males reach military age (18) annually: 45,406 (1996 est.)
Defense expenditures: exchange rate conversion - $589 million,
8.2% of GDP (1996)
======================================================================
@Juan de Nova Island
-------------------
(possession of France)
Map
---
Location: 17 03 S, 42 45 E -- Southern Africa, island in the
Mozambique Channel, about one-third of the way between Madagascar
and Mozambique
Flag
----
Description: the flag of France is used
--------------
Telephones: 2.2 million
Telephone system: service is poor
domestic: landline and microwave radio relay
international: international traffic with other former Soviet
republics and China carried by landline and microwave radio relay
and with other countries by satellite and through 8 international
telecommunications circuits at the Moscow international gateway
switch; satellite earth stations - 1 Intelsat and a new satellite
earth station established at Almaty of unknown type
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: 4.088 million (with multiple speakers for program
diffusion 6.082 million)
Television broadcast stations: NA; Orbita (TV receive only) earth
station
Televisions: 4.75 million
Defense
-------
Branches: Army, Air Force, Air Defense Force, National Guard,
Security Forces (internal and border troops); Kazakstan may also be
establishing a maritime force - navy or coast guard - on the Caspian
Sea
Manpower availability:
males age 15-49: 4,399,356
males fit for military service: 3,516,583
males reach military age (18) annually: 154,750 (1996 est.)
Defense expenditures: 18.9 billion tenges, NA% of GDP (1995); note
- conversion of defense expenditures into US dollars using the
current exchange rate could produce misleading results
======================================================================
@Kenya
-----
Map
---
Location: 1 00 N, 38 00 E -- Eastern Africa, bordering the Indian
Ocean, between Somalia and Tanzania
Flag
----
Description: three equal horizontal bands of black (top), red, and
green; the red band is edged in white; a large warrior''s shield
covering crossed spears is superimposed at the center
--------------
Telephones: 1,400 (1984 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 15,000 (1992 est.)
Television broadcast stations: 0 (1988 est.)
Televisions: 0 (1988 est.)
Defense
-------
Branches: no regular military forces; Police Force (carries out
law enforcement functions and paramilitary duties; small police
posts are on all islands)
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Korea, North
------------
Map
---
Location: 40 00 N, 127 00 E -- Eastern Asia, northern half of the
Korean Peninsula bordering the Korea Bay and the Sea of Japan,
between China and South Korea
Flag
----
Description: three horizontal bands of blue (top), red (triple
width), and blue; the red band is edged in white; on the hoist side
of the red band is a white disk with a red five-pointed star
--------------
Telephones: 30,000 (1990 est.)
Telephone system: system is believed to be available principally
for government business
domestic: NA
international: satellite earth stations - 1 Intelsat (Indian Ocean)
and 1 Intersputnik (Indian Ocean Region); other international
connections through Moscow and Beijing
Radio broadcast stations: AM 18, FM 0, shortwave 0
Radios: 3.5 million
Television broadcast stations: 11
Televisions: 400,000 (1992 est.)
Defense
-------
Branches: Korean People''s Army (includes Army, Navy, Air Force),
Civil Security Forces
Manpower availability:
males age 15-49: 6,844,035
males fit for military service: 4,143,713
males reach military age (18) annually: 194,922 (1996 est.)
Defense expenditures: exchange rate conversion - $5 billion to $7
billion, 25% to 33% of GDP (1995 est.)
======================================================================
@Korea, South
------------
Map
---
Location: 37 00 N, 127 30 E -- Eastern Asia, southern half of the
Korean Peninsula bordering the Sea of Japan and the Yellow Sea,
south of North Korea
Flag
----
Description: white with a red (top) and blue yin-yang symbol in
the center; there is a different black trigram from the ancient I
Ching (Book of Changes) in each corner of the white field
--------------
Telephones: 16.6 million (1993)
Telephone system: excellent domestic and international services
domestic: NA
international: fiber-optic submarine cable to China; satellite earth
stations - 3 Intelsat (2 Pacific Ocean and 1 Indian Ocean) and 1
Inmarsat (Pacific Ocean Region)
Radio broadcast stations: AM 79, FM 46, shortwave 0
Radios: 42 million (1993 est.)
Television broadcast stations: 256 (57 of which are 1 kW or
greater) (1987 est.)
Televisions: 9.3 million (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, Marine Corps, National Maritime
Police (Coast Guard)
Manpower availability:
males age 15-49: 13,602,115
males fit for military service: 8,706,545
males reach military age (18) annually: 398,322 (1996 est.)
Defense expenditures: exchange rate conversion - $17.4 billion,
3.3% of GNP (1996)
======================================================================
@Kuwait
------
Map
---
Location: 29 30 N, 45 45 E -- Middle East, bordering the Persian
Gulf, between Iraq and Saudi Arabia
Flag
----
Description: three equal horizontal bands of green (top), white,
and red with a black trapezoid based on the hoist side
--------------
Telephones: 548,000 (1991 est.)
Telephone system: the civil network suffered some damage as a
result of the Gulf war, but most of the telephone exchanges were
left intact and, by the end of 1994, domestic and international
telecommunications had been restored to normal operation; the
quality of service is excellent
domestic: new telephone exchanges provide a large capacity for new
subscribers; trunk traffic is carried by microwave radio relay,
coaxial cable, open wire and fiber-optic cable; a cellular telephone
system operates throughout Kuwait and the country is well supplied
with pay telephones
international: coaxial cable and microwave radio relay to Saudi
Arabia; satellite earth stations - 3 Intelsat (1 Atlantic Ocean, 2
Indian Ocean), 1 Inmarsat (Atlantic Ocean), and 1 Arabsat
Radio broadcast stations: AM 3, FM 0, shortwave 0
Radios: 720,000 (1992 est.)
Television broadcast stations: 3 (1986 est.)
Televisions: 800,000 (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, National Guard, Ministry of
Interior Forces, Coast Guard
Manpower availability:
males age 15-49: 658,270
males fit for military service: 391,586
males reach military age (18) annually: 17,544 (1996 est.)
Defense expenditures: exchange rate conversion - $3.5 billion,
12.8% of GDP (FY95/96)
======================================================================
@Kyrgyzstan
----------
Map
---
Location: 41 00 N, 75 00 E -- Central Asia, west of China
Flag
----
Description: red field with a yellow sun in the center having 40
rays representing the 40 Kirghiz tribes; on the obverse side the
rays run counterclockwise, on the reverse, clockwise; in the center
of the sun is a red ring crossed by two sets of three lines, a
stylized representation of the roof of the traditional Kirghiz yurt','65a88eb90ac9ddc0001af01c6f853cad29eff35e0ed00bb97a01486bf4638a6a','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2558c6c5690417068b2648f3a847a80886ac5c1ed83f946de5d817cb0710b43b',1996,'DE','Germany','communications',200,'--------------
Telephones: 342,000 (1991 est.)
Telephone system: poorly developed; about 100,000 unsatisfied
applications for household telephones
domestic: principally microwave radio relay
international: connections with other CIS countries by landline or
microwave radio relay and with other countries by leased connections
with Moscow international gateway switch and by satellite; satellite
earth stations - 1 Intersputnik and 1 Intelsat
Radio broadcast stations: AM NA, FM NA, shortwave NA; note -1
state-run radio broadcast station
Radios: 825,000 (radio receiver systems with multiple speakers for
program diffusion 748,000)
Television broadcast stations: 1
note: receives Turkish broadcasts
Televisions: 875,000
Defense
-------
Branches: Army, National Guard, Security Forces (internal and
border troops), Civil Defense
Manpower availability:
males age 15-49: 1,096,985
males fit for military service: 890,901
males reach military age (18) annually: 44,159 (1996 est.)
Defense expenditures: 151 million soms, NA% of GDP (1995); note -
conversion of defense expenditures into US dollars using the current
exchange rate could produce misleading results
======================================================================
@Laos
----
Map
---
Location: 18 00 N, 105 00 E -- Southeastern Asia, northeast of
Flag
----
Description: three equal horizontal bands of red (top), white, and
light blue; similar to the flag of the Netherlands, which uses a
darker blue and is shorter; design was based on the flag of France
--------------
Telephones: 170,021 (1994 est.)
Telephone system: fairly modern communication facilities
maintained for domestic and international services
domestic: NA
international: HF radiotelephone communication facility; access to
international communications carriers provided via Hong Kong and
China; satellite earth station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 4, FM 3, shortwave 0
Radios: 135,000 (1992 est.)
Television broadcast stations: 0
note: TV programs received from Hong Kong
Televisions: 34,000 (1992 est.)
Defense
-------
Branches: NA
Manpower availability:
males age 15-49: 142,704
males fit for military service: 79,225 (1996 est.)
Defense note: defense is the responsibility of Portugal
======================================================================
@Macedonia, The Former Yugoslav Republic of
------------------------------------------
Map
---
Location: 41 50 N, 22 00 E -- Southeastern Europe, north of Greece
Flag
----
Description: a rising yellow sun with 8 rays extending to the
edges of the red field','5ee2bf9800fa38307cb1040889a786b92cccc8dc6fda1c8d648d7e5eec5583cd','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f044a92518e87daffee3434d58ad852c0192b7da618a87b8d4d1a40763cc4af6',1996,'TH','Thailand','communications',201,'Flag
----
Description: three horizontal bands of red (top), blue (double
width), and red with a large white disk centered in the blue band
--------------
Telephones: 6,600 (1991 est.)
Telephone system: service to general public very poor;
radiotelephone communications network provides generally erratic
service to government users
domestic: radiotelephone communications
international: satellite earth station - 1 Intersputnik (Indian
Ocean Region)
Radio broadcast stations: AM 10, FM 0, shortwave 0
Radios: 560,000 (1992 est.)
Television broadcast stations: 2
Televisions: 32,000 (1993 est.)
Defense
-------
Branches: Lao People''s Army (LPA; includes riverine naval and
militia elements), Air Force, National Police Department
Manpower availability:
males age 15-49: 1,087,264
males fit for military service: 586,664
males reach military age (18) annually: 53,250 (1996 est.)
Defense expenditures: exchange rate conversion - $105 million,
8.1% of GDP (FY92/93)
======================================================================
@Latvia
------
Map
---
Location: 57 00 N, 25 00 E -- Eastern Europe, bordering the Baltic
Sea, between Estonia and Lithuania
Flag
----
Description: two horizontal bands of maroon (top and bottom),
white (middle, narrower than other two bands)
--------------
Telephones: 660,000 (1993 est.)
Telephone system: service is better than in most of the other
former Soviet republics
domestic: an NMT-450 analog cellular telephone network covers 75% of
Latvia''s population
international: international traffic carried by leased connection to
the Moscow international gateway switch, through the new Ericsson
digital telephone exchange in Riga, and through the Finnish cellular
net; Sprint data network carries electronic mail
Radio broadcast stations: AM NA, FM NA, shortwave NA; note - there
are 25 radio broadcast stations of unknown type
Radios: 1.4 million (1993 est.)
Television broadcast stations: 30
Televisions: 1.1 million (1993 est.)
Defense
-------
Branches: Ground Forces, Navy, Air and Air Defense Forces,
Security Forces, Border Guard, Home Guard (Zemessardze)
Manpower availability:
males age 15-49: 583,134
males fit for military service: 457,067
males reach military age (18) annually: 16,180 (1996 est.)
Defense expenditures: 176 million rubles, 3% to 5% of GDP (1994);
note - conversion of defense expenditures into US dollars using the
prevailing exchange rate could produce misleading results
======================================================================
@Lebanon
-------
Lebanon has made progress toward rebuilding its political
institutions and regaining its national sovereignty since the end of
the devastating 16-year civil war which began in 1975. Under the
Ta''if accord - the blueprint for national reconciliation - the
Lebanese have established a more equitable political system,
particularly by giving Muslims a greater say in the political
process. Since December 1990, the Lebanese have formed four cabinets
and conducted the first legislative election in 20 years. Most of
the militias have been weakened or disbanded. The Lebanese Armed
Forces (LAF) has seized vast quantities of weapons used by the
militias during the war and extended central government authority
over about one-half of the country. Hizballah, the radical Shi''a
party, retains most of its weapons. Foreign forces still occupy
areas of Lebanon. Israel maintains troops in southern Lebanon and
continues to support a proxy militia, The Army of South Lebanon
(ASL), along a narrow stretch of territory contiguous to its border.
The ASL''s enclave encompasses this self-declared security zone and
about 20 kilometers north to the strategic town of Jazzin. Syria
maintains about 30,000 troops in Lebanon. These troops are based
mainly in Beirut, North Lebanon, and the Bekaa Valley. Syria''s
deployment was legitimized by the Arab League early in Lebanon''s
civil war and in the Ta''if accord. Citing the continued weakness of
the LAF, Beirut''s requests, and failure of the Lebanese Government
to implement all of the constitutional reforms in the Ta''if accord,
Damascus has so far refused to withdraw its troops from Beirut.
Map
---
Location: 33 50 N, 35 50 E -- Middle East, bordering the
Mediterranean Sea, between Israel and Syria
Flag
----
Description: three horizontal bands of red (top), white (double
width), and red with a green and brown cedar tree centered in the
white band
--------------
Telephones: 150,000 (1990 est.)
Telephone system: telecommunications system severely damaged by
civil war; rebuilding still underway
domestic: primarily microwave radio relay and cable
international: satellite earth stations - 2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean) (erratic operations); coaxial cable to Syria;
microwave radio relay to Syria but inoperable beyond Syria to
Jordan; 3 submarine coaxial cables
Radio broadcast stations: AM 5, FM 3, shortwave 1
note: more than 100 AM and FM stations are operated sporadically by
various factions
Radios: 2.37 million (1992 est.)
Television broadcast stations: 13
Televisions: 1.1 million (1993 est.)
Defense
-------
Branches: Lebanese Armed Forces (LAF; includes Army, Navy, and Air
Force)
Manpower availability:
males age 15-49: 889,517
males fit for military service: 553,538 (1996 est.)
Defense expenditures: exchange rate conversion - $278 million,
5.5% of GDP (1994)
======================================================================
@Lesotho
-------
Map
---
Location: 29 30 S, 28 30 E -- Southern Africa, an enclave of South
Africa
Flag
----
Description: divided diagonally from the lower hoist side corner;
the upper half is white bearing the brown silhouette of a large
shield with crossed spear and club; the lower half is a diagonal
blue band with a green triangle in the corner','a9de6039fc2bcdad237dd5ca29b35b96d750482deeb19e8e9fb3260ea6885255','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f43d48ae171ba2ec64c32ed03be8b4850ff55d2d8805de1ca941fdaf09f58387',1996,'ZA','South Africa','communications',210,'--------------
Telephones: 12,000 (1991 est.)
Telephone system: rudimentary system
domestic: consists of a few landlines, a small microwave radio relay
system, and a minor radiotelephone communication system
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 4, shortwave 0
Radios: 66,000
Television broadcast stations: 1
Televisions: 11,000 (1992 est.)
Defense
-------
Branches: Lesotho Defense Force (LDF; includes Army and Air Wing),
Lesotho Mounted Police
Manpower availability:
males age 15-49: 455,218
males fit for military service: 245,774 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Liberia
-------
Years of civil strife have destroyed much of Liberia''s economic
infrastructure, made civil administration nearly impossible, and
brought economic activity virtually to a halt. The deterioration of
economic conditions has been greatly exacerbated by the flight of
most business people with their expertise and capital. Civil order
ended in 1990 when President Samuel Kanyon DOE was killed by rebel
forces. The ensuing civil war persisted until August 1995 when the
major factions signed the Abuja peace accord and, in September 1995,
formed a transitional coalition government under Wilton SANKAWULO.
The war was resumed in April 1996, when forces loyal to faction
leaders Charles TAYLOR and Alhaji KROMAH attacked rival factions in
Monrovia, further damaging the capital''s already dilapidated
infrastructure and causing panic among the remaining foreign
residents, thousands of whom sought refuge in US facilities.
Prospects for peace became extremely uncertain again.
Map
---
Location: 6 30 N, 9 30 W -- Western Africa, bordering the North
Atlantic Ocean, between Cote d''Ivoire and Sierra Leone
Flag
----
Description: 11 equal horizontal stripes of red (top and bottom)
alternating with white; there is a white five-pointed star on a blue
square in the upper hoist-side corner; the design was based on the
US flag
--------------
Telephones: less than 25,000 (1991 est.)
Telephone system: telephone and telegraph service via microwave
radio relay network; main center is Monrovia; most
telecommunications services inoperable due to insurgency movement
domestic: NA
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 4, shortwave 0
Radios: 622,000 (1992 est.)
Television broadcast stations: 5 (1987 est.)
Televisions: 51,000 (1992 est.)
Defense
-------
Branches: NA; the ultimate structure of the Liberian military
force will depend on who is the victor in the ongoing civil war
Manpower availability:
males age 15-49: 479,274
males fit for military service: 256,200 (1996 est.)
Defense expenditures: exchange rate conversion - $14 million, 2.9%
of GDP (1993)
======================================================================
@Libya
-----
Map
---
Location: 25 00 N, 17 00 E -- Northern Africa, bordering the
Mediterranean Sea, between Egypt and Tunisia
Flag
----
Description: plain green; green is the traditional color of Islam
(the state religion)
--------------
Telephones: 370,000
Telephone system: modern telecommunications system
domestic: microwave radio relay, coaxial cable, tropospheric
scatter, and a domestic satellite system with 14 earth stations
international: satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean); planned Arabsat and Intersputnik
satellite earth stations; submarine cables to France and Italy;
microwave radio relay to Tunisia and Egypt; tropospheric scatter to
Greece; participant in Medarabtel
Radio broadcast stations: AM 17, FM 3, shortwave 0
Radios: 1 million (1993 est.)
Television broadcast stations: 12 (1987 est.)
Televisions: 500,000 (1993 est.)
Defense
-------
Branches: Armed Peoples of the Libyan Arab Jamahiriyah (includes
Army, Navy, and Air and Air Defense Command), Police
Manpower availability:
males age 15-49: 1,170,100
males fit for military service: 696,288
males reach military age (17) annually: 56,834 (1996 est.)
Defense expenditures: exchange rate conversion - $1.4 billion,
6.1% of GDP (1994 est.)
======================================================================
@Liechtenstein
-------------
Map
---
Location: 47 10 N, 9 32 E -- Central Europe, between Austria and','5011dbbf624be22e2cbe9423151aec52cfd5100f3d9acb82ba0c0b9848f26f97','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33f656cf1b769c9b5387d90c72b7255f99e21f46cf3aba54917e034e186dc728',1996,'CH','Switzerland','communications',215,'Flag
----
Description: two equal horizontal bands of blue (top) and red with
a gold crown on the hoist side of the blue band
--------------
Telephones: 18,916 (1993 est.)
Telephone system: limited, but sufficient automatic telephone
system
domestic: NA
international: linked to Swiss networks by cable and microwave radio
relay
Radio broadcast stations: AM NA, FM NA, shortwave NA
note: linked to Swiss networks
Radios: 11,000 (1993 est.)
Television broadcast stations: NA
note: linked to Swiss networks
Televisions: 10,620 (1993 est.)
Defense
-------
Defense note: defense is the responsibility of Switzerland
======================================================================
@Lithuania
---------
Map
---
Location: 56 00 N, 24 00 E -- Eastern Europe, bordering the Baltic
Sea, between Latvia and Russia
Flag
----
Description: three equal horizontal bands of yellow (top), green,
and red
--------------
Telephones: 900,000
Telephone system: telecommunications system ranks among the most
modern of the former Soviet republics
domestic: an NMT-450 analog cellular telephone network operates in
Vilnius and other cities; landlines and microwave radio relay
connect switching centers
international: international connections no longer depend on the
Moscow international gateway switch, but are established by
satellite through Oslo from Vilnius and through Copenhagen from
Kaunas; satellite earth stations - 1 Eutelsat and 1 Intelsat
(Atlantic Ocean); cellular network linked internationally through
Copenhagen by Eutelsat; international electronic mail is available;
landlines or microwave radio relay to former Soviet republics
Radio broadcast stations: AM 13, FM 26, shortwave 1, longwave 1
Radios: 1.42 million (1993 est.)
Television broadcast stations: 3
Televisions: 1.77 million (1993 est.)
Defense
-------
Branches: Ground Forces, Navy, Air and Air Defense Force, Security
Forces (internal and border troops), National Guard (Skat)
Manpower availability:
males age 15-49: 903,437
males fit for military service: 712,875
males reach military age (18) annually: 26,162 (1996 est.)
Defense expenditures: exchange rate conversion - $31.7 million, 1%
of GDP (1995)
======================================================================
@Luxembourg
----------
Map
---
Location: 49 45 N, 6 10 E -- Western Europe, between France and','03e191db46d250fbc4b6636a0a4174cafb6e3c5fc9020f7d60d636d170f58437','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ef134b1cf9866c64e4bf978d812d8f86682000c01cfd8e34637bed2d0571fa6',1996,'BG','Bulgaria','communications',228,'--------------
Telephones: 125,000
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 6, FM 2, shortwave 0
Radios: 369,000 (1992 est.)
Television broadcast stations: 5 (relays 2)
Televisions: 327,011 (1992 est.)
Defense
-------
Branches: Army, Navy, Air and Air Defense Forces, Police Force
Manpower availability:
males age 15-49: 571,927
males fit for military service: 458,231
males reach military age (19) annually: 16,698 (1996 est.)
Defense expenditures: 7 billion denars, NA% of GDP (1993 est.);
note - conversion of defense expenditures into US dollars using the
current exchange rate could produce misleading results
======================================================================
@Madagascar
----------
Map
---
Location: 20 00 S, 47 00 E -- Southern Africa, island in the
Indian Ocean, east of Mozambique
Flag
----
Description: two equal horizontal bands of red (top) and green
with a vertical white band of the same width on hoist side','a9fad276fe77fe7cb18d4307fadabccbfbffec33df7f63dc22e8ce1efb9d6f89','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a725459b354a5bcddb7c280f61e3fb7b806789ae695c1b36b92abcc120ba475',1996,'MZ','Mozambique','communications',235,'--------------
Telephones: 96,000 (1988 est.)
Telephone system: system is above average for Africa
domestic: open-wire lines, coaxial cables, microwave radio relay,
and tropospheric scatter links
international: submarine cable to Bahrain; satellite earth stations
- 1 Intelsat (Indian Ocean) and 1 Intersputnik (Atlantic Ocean
Region)
Radio broadcast stations: AM 17, FM 3, shortwave 0
Radios: 2.565 million (1992 est.)
Television broadcast stations: 1 (repeaters 36)
Televisions: 260,000 (1992 est.)
Defense
-------
Branches: Popular Armed Forces (includes Intervention Forces,
Development Forces, Aeronaval Forces - includes Navy and Air Force),
Gendarmerie, Presidential Security Regiment
Manpower availability:
males age 15-49: 3,103,022
males fit for military service: 1,843,732
males reach military age (20) annually: 132,146 (1996 est.)
Defense expenditures: exchange rate conversion - $29 million, 1.0%
of GDP (1994)
======================================================================
@Malawi
------
Map
---
Location: 13 30 S, 34 00 E -- Southern Africa, east of Zambia
Flag
----
Description: three equal horizontal bands of black (top), red, and
green with a radiant, rising, red sun centered in the black band
--------------
Telephones: 43,000 (1985 est.)
Telephone system:
domestic: fair system of open-wire lines, microwave radio relay
links, and radiotelephone communications stations
international: satellite earth stations - 2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean)
Radio broadcast stations: AM 10, FM 17, shortwave 0
Radios: 1.011 million (1995)
Television broadcast stations: 0 (1987 est.)
Televisions: NA
Defense
-------
Branches: Army (includes Air Wing and Naval Detachment), Police
(includes paramilitary Mobile Force Unit)
Manpower availability:
males age 15-49: 2,106,905
males fit for military service: 1,076,788 (1996 est.)
Defense expenditures: exchange rate conversion - $10.4 million,
NA% of GDP (FY94/95)
======================================================================
@Malaysia
--------
Map
---
Location: 2 30 N, 112 30 E -- Southeastern Asia, peninsula and
northern one-third of the island of Borneo, bordering Indonesia and
the South China Sea, south of Vietnam
Flag
----
Description: 14 equal horizontal stripes of red (top) alternating
with white (bottom); there is a blue rectangle in the upper
hoist-side corner bearing a yellow crescent and a yellow
fourteen-pointed star; the crescent and the star are traditional
symbols of Islam; the design was based on the flag of the US
--------------
Telephones: 2,550,957 (1992 est.)
Telephone system: international service good
domestic: good intercity service provided on Peninsular Malaysia
mainly by microwave radio relay; adequate intercity microwave radio
relay network between Sabah and Sarawak via Brunei; domestic
satellite system with 2 earth stations
international: submarine cables to India, Hong Kong and Singapore;
satellite earth stations - 2 Intelsat (1 Indian Ocean and 1 Pacific
Ocean)
Radio broadcast stations: AM 28, FM 3, shortwave 0
Radios: 8.08 million (1992 est.)
Television broadcast stations: 33
Televisions: 2 million (1993 est.)
Defense
-------
Branches: Malaysian Army, Royal Malaysian Navy, Royal Malaysian
Air Force, Royal Malaysian Police Force, Marine Police, Sarawak
Border Scouts
Manpower availability:
males age 15-49: 5,160,884
males fit for military service: 3,129,626
males reach military age (21) annually: 184,236 (1996 est.)
Defense expenditures: exchange rate conversion - $2.4 billion,
2.9% of GDP (1995)
======================================================================
@Maldives
--------
Map
---
Location: 3 15 N, 73 00 E -- Southern Asia, group of atolls in the
Indian Ocean, south-southwest of India
Flag
----
Description: red with a large green rectangle in the center
bearing a vertical white crescent; the closed side of the crescent
is on the hoist side of the flag','e40304af314879be4fab8a2b2343ac4094e464d2a4a890ffcfa31176ee9da06e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5eb25ba13193d66440965b94c9b2fd2f97975d79f1bd67dbc50dd608ffb243f8',1996,'PG','Papua New Guinea','communications',236,'Flag
----
Description: blue with two stripes radiating from the lower
hoist-side corner - orange (top) and white; there is a white star
with four large rays and 20 small rays on the hoist side above the
two stripes
--------------
Telephones: 800 (1988 est.)
Telephone system: telex services
domestic: islands interconnected by shortwave radiotelephone (used
mostly for government purposes)
international: satellite earth stations - 2 Intelsat (Pacific
Ocean); US Government satellite communications system on Kwajalein
Radio broadcast stations: AM 1, FM 2, shortwave 1
Radios: NA
Television broadcast stations: 1
Televisions: NA
Defense
-------
Branches: no regular military forces (a coast guard may be
established); Police Force
Defense note: defense is the responsibility of the US
======================================================================
@Martinique
----------
(overseas department of France)
Map
---
Location: 14 40 N, 61 00 W -- Caribbean, island in the Caribbean
Sea, north of Trinidad and Tobago
Flag
----
Description: a light blue background is divided into four
quadrants by a white cross; in the center of each rectangle is a
white snake; the flag of France is used for official occasions','63a2be3e340992da11b44dc32baa15e483c52ec07a782974d77edbb75498752f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6e8725eb3d6317a25bb4f92dc96d250de980c1b09aef1c2fc9554e24bfac3d5',1996,'MG','Madagascar','communications',251,'--------------
Telephones: 65,000 (1985 est.)
Telephone system: small system with good service
domestic: primarily microwave radio relay
international: satellite earth station - 1 Intelsat (Indian Ocean);
new microwave link to Reunion; HF radiotelephone links to several
countries
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 395,000 (1992 est.)
Television broadcast stations: 4 (1987 est.)
Televisions: 151,096 (1991 est.)
Defense
-------
Branches: National Police Force (includes the paramilitary Special
Mobile Force or SMF, Special Support Units or SSU, and National
Coast Guard)
Manpower availability:
males age 15-49: 327,403
males fit for military service: 166,466 (1996 est.)
Defense expenditures: exchange rate conversion - $11.2 million,
0.4% of GDP (FY92/93)
======================================================================
@Mayotte
-------
(territorial collectivity of France)
Map
---
Location: 12 50 S, 45 10 E -- Southern Africa, island in the
Mozambique Channel, about one-half of the way from northern
Madagascar to northern Mozambique
Flag
----
Description: the flag of France is used
--------------
Telephones: 450
Telephone system: small system administered by French Department
of Posts and Telecommunications
domestic: NA
international: microwave radio relay and HF radiotelephone
communications to Comoros and other international connections
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 30,000 (1994 est.)
Television broadcast stations: 0
Televisions: 3,500 (1994 est.)
Defense
-------
Defense note: defense is the responsibility of France
======================================================================
@Mexico
------
Map
---
Location: 23 00 N, 102 00 W -- Middle America, bordering the
Caribbean Sea and the Gulf of Mexico, between Belize and the US and
bordering the North Pacific Ocean, between Guatemala and the US
Flag
----
Description: three equal vertical bands of green (hoist side),
white, and red; the coat of arms (an eagle perched on a cactus with
a snake in its beak) is centered in the white band
--------------
Telephones: 11,890,868 (1993 est.)
Telephone system: highly developed system with extensive microwave
radio relay links; privatized in December 1990
domestic: adequate telephone service for business and government,
but the population is poorly served; domestic satellite system with
120 earth stations; extensive microwave radio relay network
international: satellite earth stations - 5 Intelsat (4 Atlantic
Ocean and 1 Pacific Ocean); launched Solidaridad I satellite in
November 1993 and Solidaridad II in October 1994, giving Mexico
improved access to South America, Central America and much of the US
as well as enhancing domestic communications; linked to Central
American Microwave System of trunk connections
Radio broadcast stations: AM 679, FM 0, shortwave 22
Radios: 22.5 million (1992 est.)
Television broadcast stations: 238
Televisions: 13.1 million (1992 est.)
Defense
-------
Branches: National Defense (includes Army and Air Force), Navy
(includes Naval Air and Marines)
Manpower availability:
males age 15-49: 23,945,962
males fit for military service: 17,451,706
males reach military age (18) annually: 1,057,538 (1996 est.)
Defense expenditures: exchange rate conversion - $2.24 billion,
0.9% of GDP (1996)
======================================================================
@Micronesia, Federated States of
-------------------------------
Map
---
Location: 6 55 N, 158 15 E -- Oceania, island group in the North
Pacific Ocean, about three-quarters of the way from Hawaii to
--------------
Telephones: 191,647 (1993 est.)
Telephone system: adequate system; principal center is Saint-Denis
domestic: modern open wire and microwave radio relay network
international: radiotelephone communication to Comoros, France,
Madagascar; new microwave route to Mauritius; satellite earth
station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 3, FM 13, shortwave 0
Radios: 151,000 (1992 est.)
Television broadcast stations: 1 (repeaters 18)
Televisions: 116,181 (1992 est.)
Defense
-------
Branches: French forces (Army, Navy, Air Force, and Gendarmerie)
Manpower availability:
males age 15-49: 176,609
males fit for military service: 90,784
males reach military age (18) annually: 5,728 (1996 est.)
Defense note: defense is the responsibility of France
======================================================================
@Romania
-------
Map
---
Location: 46 00 N, 25 00 E -- Southeastern Europe, bordering the
Black Sea, between Bulgaria and Ukraine
Flag
----
Description: three equal vertical bands of blue (hoist side),
yellow, and red; the national coat of arms that used to be centered
in the yellow band has been removed; now similar to the flags of
Andorra and Chad
--------------
Telephones: 2.3 million (1990 est.)
Telephone system:
domestic: poor service; 89% of telephone network is automatic; trunk
network is microwave radio relay; roughly 3,300 villages with no
service (February 1990 est.)
international: satellite earth station - 1 Intelsat; new digital
international direct-dial exchanges are in Bucharest (1993 est.)
Radio broadcast stations: AM 12, FM 5, shortwave 0
Radios: 4.64 million (1992 est.)
Television broadcast stations: 13 (1990 est.)
Televisions: 4.58 million (1992 est.)
Defense
-------
Branches: Army, Navy, Air and Air Defense Forces, Paramilitary
Forces, Civil Defense
Manpower availability:
males age 15-49: 5,572,383
males fit for military service: 4,693,376
males reach military age (20) annually: 198,125 (1996 est.)
Defense expenditures: exchange rate conversion - $885 million,
3.0% of GDP (1995)
Original publicaton at
http://www.odci.gov/cia/publications/nsolo/wfb-all.htm (June 17,
1997).
======================================================================
@Russia
------
Map
---
Location: 60 00 N, 100 00 E -- Northern Asia (that part west of
the Urals is sometimes included with Europe), bordering the Arctic
Ocean, between Europe and the North Pacific Ocean
Flag
----
Description: three equal horizontal bands of white (top), blue,
and red
--------------
Telephones: 25.4 million (1993 est.)
Telephone system: total pay phones for long distant calls 34,100;
enlisting foreign help, by means of joint ventures, to speed up the
modernization of its telecommunications system; in 1992, only
661,000 new telephones were installed compared with 855,000 in 1991,
and in 1992 the number of unsatisfied applications for telephones
reached 11,000,000; expanded access to international electronic mail
service available via Sprint network; the inadequacy of Russian
telecommunications is a severe handicap to the economy, especially
with respect to international connections
domestic: NMT-450 analog cellular telephone networks are operational
and growing in Moscow and St. Petersburg; intercity fiber-optic
cable installation remains limited
international: international traffic is inadequately handled by a
system of satellites, landlines, microwave radio relay, and outdated
submarine cables; much of this traffic passes through the
international gateway switch in Moscow which carries most of the
international traffic for the other countries of the Commonwealth of
Independent States; a new Russian Intersputnik satellite will link
Moscow and St. Petersburg with Rome from whence calls will be
relayed to destinations in Europe and overseas; satellite earth
stations - NA Intelsat, 4 Intersputnik (2 Atlantic Ocean Region and
2 Indian Ocean Region), NA Eutelsat, 1 Inmarsat (Pacific Ocean
Region), and NA Orbita
Radio broadcast stations: AM NA, FM NA, shortwave NA; note - there
are about 1,050 (including AM, FM, and shortwave) radio broadcast
stations throughout the country
Radios: 50 million (1993 est.)(radio receivers with multiple
speaker systems for program diffusion 74,300,000)
Television broadcast stations: 7,183
Televisions: 54.85 million (1992 est.)
Defense
-------
Branches: Ground Forces, Navy, Air Forces, Air Defense Forces,
Strategic Rocket Forces
Manpower availability:
males age 15-49: 38,673,991
males fit for military service: 30,224,738
males reach military age (18) annually: 1,105,004 (1996 est.)
Defense expenditures: $NA, NA% of GDP
note: the Intelligence Community estimates that defense spending in
Russia fell by about 20% in real terms in 1995, reducing Russian
defense outlays to about one-fifth of peak Soviet levels in the late
1980s
======================================================================
@Rwanda
------
Map
---
Location: 2 00 S, 30 00 E -- Central Africa, east of Zaire
Flag
----
Description: three equal vertical bands of red (hoist side),
yellow, and green with a large black letter R centered in the yellow
band; uses the popular pan-African colors of Ethiopia; similar to
the flag of Guinea, which has a plain yellow band
--------------
Telephones: 6,400 (1983 est.)
Telephone system: telephone system does not provide service to the
general public but is intended for business and government use
domestic: the capital, Kigali, is connected to the centers of the
prefectures by microwave radio relay; the remainder of the network
depends on wire and HF radiotelephone
international: international connections employ microwave radio
relay to neighboring countries and satellite communications to more
distant countries; satellite earth stations - 1 Intelsat (Indian
Ocean) in Kigali (includes telex and telefax service)
Radio broadcast stations: AM 1, FM 1, shortwave 0
Radios: 630,000 (1993 est.)
Television broadcast stations: 1
Televisions: NA
Defense
-------
Branches: Army, Gendarmerie
Manpower availability:
males age 15-49: 1,582,656
males fit for military service: 805,722 (1996 est.)
Defense expenditures: exchange rate conversion - $112.5 million,
7% of GDP (1992)
======================================================================
@Saint Helena
------------
(dependent territory of the UK)
Map
---
Location: 15 56 S, 5 42 W -- Southern Africa, island in the South
Atlantic Ocean, west of Angola, about two-thirds of the way from
South America to Africa
Flag
----
Description: blue with the flag of the UK in the upper hoist-side
quadrant and the Saint Helenian shield centered on the outer half of
the flag; the shield features a rocky coastline and three-masted
sailing ship
--------------
Telephones: 550
Telephone system:
domestic: automatic network; HF radiotelephone to Ascension, then
into worldwide submarine cable and satellite networks
international: major coaxial submarine cable relay point between
South Africa, Portugal, and UK at Ascension; satellite earth
stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 2,500 (1993 est.)
Television broadcast stations: 0
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the UK
======================================================================
@Saint Kitts and Nevis
---------------------
Map
---
Location: 17 20 N, 62 45 W -- Caribbean, islands in the Caribbean
Sea, about one-third of the way from Puerto Rico to Trinidad and
Tobago
Flag
----
Description: divided diagonally from the lower hoist side by a
broad black band bearing two white five-pointed stars; the black
band is edged in yellow; the upper triangle is green, the lower
triangle is red
--------------
Telephones: 3,800 (1986 est.)
Telephone system: good interisland VHF/UHF/SHF radiotelephone
connections and international link via Antigua and Barbuda and Saint
Martin (Guadeloupe and Netherlands Antilles)
domestic: interisland links are handled by VHF/UHF/SHF radiotelephone
international: international calls are carried by radiotelephone to
Antigua and Barbuda and from there switched to submarine cable or to
Intelsat, or carried to Saint Martin (Guadeloupe and Netherlands
Antilles) by radiotelephone and switched to Intelsat
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 25,000 (1993 est.)
Television broadcast stations: 4
Televisions: 9,500 (1993 est.)
Defense
-------
Branches: Royal Saint Kitts and Nevis Police Force, Coast Guard
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Saint Lucia
-----------
Map
---
Location: 13 53 N, 60 68 W -- Caribbean, island in the Caribbean
Sea, north of Trinidad and Tobago
Flag
----
Description: blue with a gold isosceles triangle below a black
arrowhead; the upper edges of the arrowhead have a white border','15dd361f13a0daa193435c9c7febaa6e80941b1c15c8f592e00ca23c875a6634','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c94d7441c7669cf215db50af099b0323aa9f936ecc606fc0b42eb58bb916779b',1996,'ID','Indonesia','communications',252,'Flag
----
Description: light blue with four white five-pointed stars
centered; the stars are arranged in a diamond pattern
--------------
Telephones: 960
Telephone system:
domestic: islands interconnected by shortwave radiotelephone (used
mostly for government purposes)
international: satellite earth stations - 4 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 5, FM 1, shortwave 1
Radios: 17,000 (1993 est.)
Television broadcast stations: 6
Televisions: 1,290 (1993 est.)
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Midway Islands
--------------
(territory of the US)
Map
---
Location: 28 13 N, 177 22 W -- Oceania, atoll in the North Pacific
Ocean, about one-third of the way from Honolulu to Tokyo
Flag
----
Description: the flag of the US is used
--------------
Telephones: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Moldova
-------
Map
---
Location: 47 00 N, 29 00 E -- Eastern Europe, northeast of Romania
Flag
----
Description: same color scheme as Romania - three equal vertical
bands of blue (hoist side), yellow, and red; emblem in center of
flag is of a Roman eagle of gold outlined in black with a red beak
and talons carrying a yellow cross in its beak and a green olive
branch in its right talons and a yellow scepter in its left talons;
on its breast is a shield divided horizontally red over blue with a
stylized ox head, star, rose, and crescent all in black-outlined
yellow
--------------
Telephones: 577,000 (1991 est.)
Telephone system: telecommunication system not well developed;
215,000 unsatisfied requests for telephone service (1991 est.)
domestic: NA
international: international connections to other former Soviet
republics by landline and microwave radio relay through Ukraine and
to other countries by leased connections to the Moscow international
gateway switch; satellite earth stations - 1 Eutelsat and 1 Intelsat
Radio broadcast stations: AM 9, FM 5, shortwave NA (1994)
Radios: NA
Television broadcast stations: 2 (one national and one private)
(1995)
Televisions: NA
Defense
-------
Branches: Ground Forces, Air and Air Defense Forces, Republic
Security Forces (internal and border troops)
Manpower availability:
males age 15-49: 1,125,538
males fit for military service: 888,757
males reach military age (18) annually: 37,183 (1996 est.)
Defense expenditures: 203 million lei, 2.5% of GDP (1995); note -
conversion of defense expenditures into US dollars using the current
exchange rate could produce misleading results
======================================================================
@Monaco
------
Map
---
Location: 43 44 N, 7 24 E -- Western Europe, bordering the
Mediterranean Sea, on the southern coast of France, near the border
with Italy
Flag
----
Description: two equal horizontal bands of red (top) and white;
similar to the flag of Indonesia which is longer and the flag of
Poland which is white (top) and red
--------------
Telephones: 89,000 (1995 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 Intersputnik (Indian
Ocean Region)
Radio broadcast stations: AM 12, FM 1, shortwave 0
Radios: 220,000
Television broadcast stations: 1 (provincial repeaters 18)
Televisions: 120,000 (1993 est.)
Defense
-------
Branches: Mongolian People''s Army (includes Internal Security
Forces and Frontier Guards), Air Force
Manpower availability:
males age 15-49: 638,560
males fit for military service: 417,620
males reach military age (18) annually: 27,386 (1996 est.)
Defense expenditures: exchange rate conversion - $22.8 million, 1%
of GDP (1992)
======================================================================
@Montserrat
----------
(dependent territory of the UK)
Map
---
Location: 16 45 N, 62 12 W -- Caribbean, island in the Caribbean
Sea, southeast of Puerto Rico
Flag
----
Description: blue with the flag of the UK in the upper hoist-side
quadrant and the Montserratian coat of arms centered in the outer
half of the flag; the coat of arms features a woman standing beside
a yellow harp with her arm around a black cross','ad7ce9387911327eca9649f40f2893a5122f9b242e1e1fae970d347b3b26c481','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eeaa1d2bd04c4dd37beaf354bd49ad80a7762c86738eafe47acc1f3d29d18eb',1996,'EH','Western Sahara','communications',256,'Flag
----
Description: red with a green pentacle (five-pointed, linear star)
known as Solomon''s seal in the center of the flag; green is the
traditional color of Islam
--------------
Telephones: 270,100 (1987 est.)
Telephone system:
domestic: good system composed of open-wire lines, cables, and
microwave radio relay links; principal centers are Casablanca and
Rabat; secondary centers are Fes, Marrakech, Oujda, Tangier, and
Tetouan
international: 5 submarine cables; satellite earth stations - 2
Intelsat (Atlantic Ocean) and 1 Arabsat; microwave radio relay to
Gibraltar, Spain, and Western Sahara; coaxial cable and microwave
radio relay to Algeria; participant in Medarabtel
Radio broadcast stations: AM 20, FM 7, shortwave 0
Radios: 5.527 million (1992 est.)
Television broadcast stations: 26 (repeaters 26)
Televisions: 1.21 million (1993 est.)
Defense
-------
Branches: Royal Moroccan Army, Royal Moroccan Navy, Royal Moroccan
Air Force, Royal Gendarmerie, Auxiliary Forces
Manpower availability:
males age 15-49: 7,541,745
males fit for military service: 4,782,028
males reach military age (18) annually: 330,344 (1996 est.)
Defense expenditures: exchange rate conversion - $1.38 billion,
4.1% of GDP (1995)
======================================================================
@Mozambique
----------
Map
---
Location: 18 15 S, 35 00 E -- Southern Africa, bordering the
Mozambique Channel, between South Africa and Tanzania
Flag
----
Description: three equal horizontal bands of green (top), black,
and yellow with a red isosceles triangle based on the hoist side;
the black band is edged in white; centered in the triangle is a
yellow five-pointed star bearing a crossed rifle and hoe in black
superimposed on an open white book
--------------
Telephones: 59,000 (1983 est.)
Telephone system: fair system of tropospheric scatter, open-wire
lines, and microwave radio relay
domestic: microwave radio relay and tropospheric scatter
international: satellite earth stations - 5 Intelsat (2 Atlantic
Ocean and 3 Indian Ocean)
Radio broadcast stations: AM 29, FM 4, shortwave 0
Radios: 700,000 (1992 est.)
Television broadcast stations: 1
Televisions: 44,000 (1992 est.)
Defense
-------
Branches: Army, Naval Command, Air and Air Defense Forces, Militia
Manpower availability:
males age 15-49: 3,767,855
males fit for military service: 2,162,388 (1996 est.)
Defense expenditures: exchange rate conversion - $84 million, 5.3%
of GDP (1994)
======================================================================
@Namibia
-------
Map
---
Location: 22 00 S, 17 00 E -- Southern Africa, bordering the South
Atlantic Ocean, between Angola and South Africa
Flag
----
Description: a large blue triangle with a yellow sunburst fills
the upper left section, and an equal green triangle (solid) fills
the lower right section; the triangles are separated by a red stripe
that is contrasted by two narrow white-edge borders
--------------
Telephones: 89,722 (1992 est.)
Telephone system:
domestic: good urban services; fair rural service; microwave radio
relay links major towns; connections to other populated places are
by open wire
international: NA
Radio broadcast stations: AM 4, FM 40, shortwave 0
Radios: 195,000 (1992 est.)
Television broadcast stations: 3
Televisions: 27,000 (1993 est.)
Defense
-------
Branches: National Defense Force (Army), Police
Manpower availability:
males age 15-49: 377,687
males fit for military service: 224,682 (1996 est.)
Defense expenditures: exchange rate conversion - $64 million, 2.1%
of GDP (FY95/96)
======================================================================
@Nauru
-----
Map
---
Location: 0 32 S, 166 55 E -- Oceania, island in the South Pacific
Ocean, south of the Marshall Islands
Flag
----
Description: blue with a narrow, horizontal, yellow stripe across
the center and a large white 12-pointed star below the stripe on the
hoist side; the star indicates the country''s location in relation to
the Equator (the yellow stripe) and the 12 points symbolize the 12
original tribes of Nauru','9eafc1326a6cd008ac70210f5f050533ed37f5ac58913574c7f3b10056314f70','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea40ab39850a8040ba353d8f40c0b6eec3ac1134366e7b449ffd3e2b08ac113e',1996,'MH','Marshall Islands','communications',269,'--------------
Telephones: 2,000 (1989 est.)
Telephone system: adequate local and international radiotelephone
communications provided via Australian facilities
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 4,000 (1993 est.)
Television broadcast stations: 0 (1986 est.)
Televisions: NA
Defense
-------
Branches: no regular armed forces; Directorate of the Nauru Police
Force
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Navassa Island
--------------
(territory of the US)
Map
---
Location: 18 25 N, 75 02 W -- Caribbean, island in the Caribbean
Sea, about one-fourth of the way from Haiti to Jamaica
Flag
----
Description: the flag of the US is used','9d6cc3976d02012bb4a8e1da438e677d440f912bd8a5bd276ec26f24f6d063d3','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6544b337ffcc6ccf22d2b7e38d39c70eb9dab9096d37654e19102f032b77cc3',1996,'HN','Honduras','communications',270,'Flag
----
Description: three equal horizontal bands of blue (top), white,
and blue with the national coat of arms centered in the white band;
the coat of arms features a triangle encircled by the words
REPUBLICA DE NICARAGUA on the top and AMERICA CENTRAL on the bottom;
similar to the flag of El Salvador, which features a round emblem
encircled by the words REPUBLICA DE EL SALVADOR EN LA AMERICA
CENTRAL centered in the white band; also similar to the flag of
Honduras, which has five blue stars arranged in an X pattern
centered in the white band
--------------
Telephones: 66,810 (1993 est.)
Telephone system: low-capacity microwave radio relay and wire
system being expanded; connected to Central American Microwave System
domestic: wire and microwave radio relay
international: satellite earth stations - 1 Intersputnik (Atlantic
Ocean Region) and 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 45, FM 0, shortwave 3
Radios: 1.037 million (1992 est.)
Television broadcast stations: 7 (1994 est.)
Televisions: 260,000 (1992 est.)
Defense
-------
Branches: Ground Forces, Navy, Air Force
Manpower availability:
males age 15-49: 988,883
males fit for military service: 608,753
males reach military age (18) annually: 47,786 (1996 est.)
Defense expenditures: exchange rate conversion - $28.1 million,
NA% of GDP (1996)
======================================================================
@Niger
-----
Map
---
Location: 16 00 N, 8 00 E -- Western Africa, southeast of Algeria
Flag
----
Description: three equal horizontal bands of orange (top), white,
and green with a small orange disk (representing the sun) centered
in the white band; similar to the flag of India, which has a blue
spoked wheel centered in the white band
--------------
Telephones: 14,000 (1991 est.)
Telephone system: small system of wire, radiotelephone
communications, and microwave radio relay links concentrated in
southwestern area
domestic: wire, radiotelephone communications, and microwave radio
relay; domestic satellite system with 3 earth stations and 1 planned
international: satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean)
Radio broadcast stations: AM 15, FM 5, shortwave 0
Radios: 500,000 (1992 est.)
Television broadcast stations: 18
Televisions: 38,000 (1992 est.)
Defense
-------
Branches: Army, Air Force, National Gendarmerie, Republican Guard,
National Police
Manpower availability:
males age 15-49: 1,920,244
males fit for military service: 1,035,218
males reach military age (18) annually: 92,132 (1996 est.)
Defense expenditures: exchange rate conversion - $32 million, 1.3%
of GDP (FY92/93)
======================================================================
@Nigeria
-------
Map
---
Location: 10 00 N, 8 00 E -- Western Africa, bordering the Gulf of
Guinea, between Benin and Cameroon
Flag
----
Description: three equal vertical bands of green (hoist side),
white, and green
--------------
Telephones: 492,204 (1990 est.)
Telephone system: average system limited by poor maintenance;
major expansion in progress
domestic: microwave radio relay, coaxial cable, and 20 domestic
satellite earth stations carry intercity traffic
international: satellite earth stations - 3 Intelsat (2 Atlantic
Ocean and 1 Indian Ocean); 1 coaxial submarine cable
Radio broadcast stations: AM 35, FM 17, shortwave 0
Radios: 20 million (1992 est.)
Television broadcast stations: 28
Televisions: 3.8 million (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, paramilitary Police Force
Manpower availability:
males age 15-49: 23,739,192
males fit for military service: 13,587,780
males reach military age (18) annually: 1,065,410 (1996 est.)
Defense expenditures: exchange rate conversion - $172 million,
about 1% of GDP (1992)
======================================================================
@Niue
----
(free association with New Zealand)
Map
---
Location: 19 02 S, 169 52 W -- Oceania, island in the South
Pacific Ocean, east of Tonga
Flag
----
Description: yellow with the flag of the UK in the upper
hoist-side quadrant; the flag of the UK bears five yellow
five-pointed stars - a large one on a blue disk in the center and a
smaller one on each arm of the bold red cross
--------------
Telephones: 276 (1992 est.)
Telephone system:
domestic: single-line telephone system connects all villages on
island
international: NA
Radio broadcast stations: AM 1, FM 1, shortwave 0 (1987 est.)
Radios: 1,000
Television broadcast stations: 0
Televisions: 312 (1991 est.)
Defense
-------
Branches: Police Force
Defense note: defense is the responsibility of New Zealand
======================================================================
@Norfolk Island
--------------
(territory of Australia)
Map
---
Location: 29 02 S, 167 57 E -- Oceania, island in the South
Pacific Ocean, east of Australia
Flag
----
Description: three vertical bands of green (hoist side), white,
and green with a large green Norfolk Island pine tree centered in
the slightly wider white band','8e0e4f7cbb9a5abed28282809fe548cbea446156379bf1a4938d728c0c0da82d','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baa89953c86c19907fa5728af113ebefc0deed71592c35a88c1cff97881f7825',1996,'CR','Costa Rica','communications',283,'--------------
Telephones: 273,000 (1991 est.)
Telephone system: domestic and international facilities well
developed
domestic: NA
international: 1 coaxial submarine cable; satellite earth stations -
2 Intelsat (Atlantic Ocean); connected to the Central American
Microwave System
Radio broadcast stations: AM 91, FM 0, shortwave 0
Radios: 564,000 (1992 est.)
Television broadcast stations: 23
Televisions: 420,000 (1992 est.)
Defense
-------
Branches: Panamanian Public Forces (PPF; includes the National
Police, National Maritime Service, National Air Service, and
Institutional Protective Service); Judicial Technical Police
Manpower availability:
males age 15-49: 705,427
males fit for military service: 484,571 (1996 est.)
Defense expenditures: exchange rate conversion - $78 million, NA%
of GDP (1995); note - for police and security forces
======================================================================
@Papua New Guinea
----------------
Map
---
Location: 6 00 S, 147 00 E -- Southeastern Asia, group of islands
including the eastern half of the island of New Guinea between the
Coral Sea and the South Pacific Ocean, east of Indonesia
Flag
----
Description: divided diagonally from upper hoist-side corner; the
upper triangle is red with a soaring yellow bird of paradise
centered; the lower triangle is black with five white five-pointed
stars of the Southern Cross constellation centered
--------------
Telephones: 63,212 (1986 est.)
Telephone system: services are adequate and being improved;
facilities provide radiotelephone and telegraph, coastal radio,
aeronautical radio, and international radio communication services
domestic: mostly radiotelephone
international: submarine cables to Australia and Guam; satellite
earth station - 1 Intelsat (Pacific Ocean); international radio
communication service
Radio broadcast stations: AM 31, FM 2, shortwave 0
Radios: 298,000 (1992 est.)
Television broadcast stations: 2 (1987 est.)
Televisions: 10,000 (1992 est.)
Defense
-------
Branches: Papua New Guinea Defense Force (includes Army, Navy, Air
Force, and Special Operations Unit)
Manpower availability:
males age 15-49: 1,143,015
males fit for military service: 635,923 (1996 est.)
Defense expenditures: exchange rate conversion - $40 million, 0.9%
of GDP (1995)
======================================================================
@Paracel Islands
---------------
Map
---
Location: 16 30 N, 112 00 E -- Southeastern Asia, group of small
islands and reefs in the South China Sea, about one-third of the way
from central Vietnam to the northern Philippines
--------------
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
-------
Defense note: occupied by China
======================================================================
@Paraguay
--------
Map
---
Location: 23 00 S, 58 00 W -- Central South America, northeast of','098e7ed433f3e7952c696f7f69d36553994b6176d620be4d7f090dcf73ad685f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c167adb46993a082257385799de802aa3a3c1d4612318e427c5efecb19cbab53',1996,'ET','Ethiopia','communications',292,'--------------
Telephones: 2,200 (1986 est.)
Telephone system:
domestic: minimal system
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 2, shortwave 0
Radios: 33,000 (1992 est.)
Television broadcast stations: 1 (1992 est.)
Televisions: NA
Defense
-------
Branches: Army, Navy, Security Police
Manpower availability:
males age 15-49: 34,986
males fit for military service: 18,343 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Saudi Arabia
------------
Map
---
Location: 25 00 N, 45 00 E -- Middle East, bordering the Persian
Gulf and the Red Sea, north of Yemen
Flag
----
Description: green with large white Arabic script (that may be
translated as There is no God but God; Muhammad is the Messenger of
God) above a white horizontal saber (the tip points to the hoist
side); green is the traditional color of Islam
--------------
Telephones: 1.46 million (1993)
Telephone system: modern system
domestic: extensive microwave radio relay and coaxial and
fiber-optic cable systems
international: microwave radio relay to Bahrain, Jordan, Kuwait,
Qatar, UAE, Yemen, and Sudan; coaxial cable to Kuwait and Jordan;
submarine cable to Djibouti, Egypt and Bahrain; satellite earth
stations - 5 Intelsat (3 Atlantic Ocean and 2 Indian Ocean), 1
Arabsat, and 1 Inmarsat (Indian Ocean region)
Radio broadcast stations: AM 43, FM 13, shortwave 0
Radios: 5 million (1993 est.)
Television broadcast stations: 80
Televisions: 4.5 million (1993 est.)
Defense
-------
Branches: Land Force (Army), Navy, Air Force, Air Defense Force,
National Guard, Coast Guard, Frontier Forces, Public Security Force
Manpower availability:
males age 15-49: 5,405,828
males fit for military service: 3,005,900
males reach military age (18) annually: 165,010 (1996 est.)
Defense expenditures: exchange rate conversion - $12.1 billion,
8.5% of GDP (1996)
======================================================================
@Senegal
-------
Map
---
Location: 14 00 N, 14 00 W -- Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and Mauritania
Flag
----
Description: three equal vertical bands of green (hoist side),
yellow, and red with a small green five-pointed star centered in the
yellow band; uses the popular pan-African colors of Ethiopia
--------------
Telephones: 55,000 (1993 est.)
Telephone system:
domestic: above-average urban system; microwave radio relay and
cable trunk system
international: 3 submarine cables; satellite earth station - 1
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 8, FM 0, shortwave 0
Radios: 850,000 (1993 est.)
Television broadcast stations: 1
Televisions: 61,000 (1993 est.)
Defense
-------
Branches: Army, Navy, Air Force, National Gendarmerie, National
Police (Surete Nationale)
Manpower availability:
males age 15-49: 1,864,239
males fit for military service: 973,170
males reach military age (18) annually: 90,154 (1996 est.)
Defense expenditures: exchange rate conversion - $82 million, 2.1%
of GDP (1996 est.)
======================================================================
@Serbia and Montenegro
---------------------
Serbia and Montenegro have asserted the formation of a joint
independent state, but this entity has not been formally recognized
as a state by the US; the US view is that the Socialist Federal
Republic of Yugoslavia (SFRY) has dissolved and that none of the
successor republics represents its continuation.
Map
---
Location: 44 00 N, 21 00 E -- Southeastern Europe, bordering the
Adriatic Sea, between Albania and Bosnia and Herzegovina
--------------
Telephones: 700,000
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 26, FM 9, shortwave 0
Radios: 2.015 million
Television broadcast stations: 18
Televisions: 1 million
Defense
-------
Branches: People''s Army (includes Ground Forces with internal and
border troops, Naval Forces, and Air and Air Defense Forces), Civil
Defense
Manpower availability:
Montenegro - males age 15-49: 173,942
Montenegro - males fit for military service: 140,728
Montenegro - males reach military age (19) annually: 5,226
Serbia - males age 15-49: 2,546,549
Serbia - males fit for military service: 2,041,239 (1996 est.)
Defense expenditures: 245 billion dinars, 4% to 6% of GDP (1992
est.); note - conversion of defense expenditures into US dollars
using the current exchange rate could produce misleading results
======================================================================
@Seychelles
----------
Map
---
Location: 4 35 S, 55 40 E -- Eastern Africa, group of islands in
the Indian Ocean, northeast of Madagascar
Flag
----
Description: five oblique bands of blue (hoist side), yellow, red,
white, and green (bottom) radiating from the bottom of the hoist side
--------------
Telephones: 8,300 (1982 est.)
Telephone system:
domestic: radiotelephone communications between islands in the
archipelago
international: direct radiotelephone communications with adjacent
island countries and African coastal countries; satellite earth
station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 34,000 (1992 est.)
Television broadcast stations: 2
Televisions: 8,200 (1991 est.)
Defense
-------
Branches: Army, Coast Guard, Marines, National Guard, Presidential
Protection Unit, Police Force
Manpower availability:
males age 15-49: 21,547
males fit for military service: 10,883 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Sierra Leone
------------
Map
---
Location: 8 30 N, 11 30 W -- Western Africa, bordering the North
Atlantic Ocean, between Guinea and Liberia
Flag
----
Description: three equal horizontal bands of light green (top),
white, and light blue
--------------
Telephones: 17,526 (1991 est.)
Telephone system: marginal telephone and telegraph service
domestic: national microwave radio relay system made unserviceable
by military activities
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave 0
Radios: 980,000 (1992 est.)
Television broadcast stations: 1
Televisions: 45,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Police, Security Forces
Manpower availability:
males age 15-49: 1,019,093
males fit for military service: 494,451 (1996 est.)
Defense expenditures: exchange rate conversion - $14 million, 2.6%
of GDP (FY92/93)
======================================================================
@Singapore
---------
Map
---
Location: 1 22 N, 103 48 E -- Southeastern Asia, islands between
Malaysia and Indonesia
Flag
----
Description: two equal horizontal bands of red (top) and white;
near the hoist side of the red band, there is a vertical, white
crescent (closed portion is toward the hoist side) partially
enclosing five white five-pointed stars arranged in a circle
--------------
Telephones: 1.23 million (1993 est.)
Telephone system: good domestic facilities; good international
service
domestic: NA
international: submarine cables to Malaysia (Sabah and Peninsular
Malaysia), Indonesia, and the Philippines; satellite earth stations
- 2 Intelsat (1 Indian Ocean and 1 Pacific Ocean), and 1 Inmarsat
(Pacific Ocean region)
Radio broadcast stations: AM 13, FM 4, shortwave 0
Radios: NA
Television broadcast stations: 2 (1987 est.)
Televisions: 1.05 million (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, People''s Defense Force, Police
Force
Manpower availability:
males age 15-49: 1,025,300
males fit for military service: 752,382 (1996 est.)
Defense expenditures: exchange rate conversion - $3.9 billion,
4.3% of GDP (1995 est.)
======================================================================
@Slovakia
--------
Map
---
Location: 48 40 N, 19 30 E -- Central Europe, south of Poland
Flag
----
Description: three equal horizontal bands of white (top), blue,
and red superimposed with the Slovak cross in a shield centered on
the hoist side; the cross is white centered on a background of red
and blue
--------------
Telephones: 1,362,178 (1992 est.)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave NA; note - there
is 1 station of NA type
Radios: 1.1 million (1992 est.)
Television broadcast stations: 1
Televisions: 1.6 million (1994 est.)
Defense
-------
Branches: Army, Air and Air Defense Forces, Civil Defense,
Railroad Units
Manpower availability:
males age 15-49: 1,442,321
males fit for military service: 1,104,901
males reach military age (18) annually: 48,695 (1996 est.)
Defense expenditures: exchange rate conversion - $430 million,
3.0% of GDP (1995)
======================================================================
@Slovenia
--------
Map
---
Location: 46 00 N, 15 00 E -- Southeastern Europe, bordering the
Adriatic Sea, between Croatia and Italy
Flag
----
Description: three equal horizontal bands of white (top), blue,
and red with the Slovenian seal (a shield with the image of Triglav
in white against a blue background at the center, beneath it are two
wavy blue lines depicting seas and rivers, and around it, there are
three six-sided stars arranged in an inverted triangle); the seal is
located in the upper hoist side of the flag centered in the white
and blue bands
--------------
Telephones: 527,800 (1993 est.)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 6, FM 5, shortwave 0
note: there are more than 20 regional and local radio broadcast
stations
Radios: 596,100 (1993 est.)
Television broadcast stations: 7
note: there are more than 20 local cable television broadcast
stations
Televisions: 454,400 (1993 est.)
Defense
-------
Branches: Slovene Defense Forces
Manpower availability:
males age 15-49: 525,925
males fit for military service: 419,456
males reach military age (19) annually: 15,350 (1996 est.)
Defense expenditures: 13.5 billion tolars, 3.6% of GDP (1995
est.); note - conversion of the military budget into US dollars
using the current exchange rate could produce misleading results
======================================================================
@Solomon Islands
---------------
Map
---
Location: 8 00 S, 159 00 E -- Oceania, group of islands in the
South Pacific Ocean, east of Papua New Guinea
Flag
----
Description: divided diagonally by a thin yellow stripe from the
lower hoist-side corner; the upper triangle (hoist side) is blue
with five white five-pointed stars arranged in an X pattern; the
lower triangle is green
--------------
Telephones: 5,000 (1991 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 4, FM 0, shortwave 0
Radios: 38,000 (1993 est.)
Television broadcast stations: 0 (1987 est.)
Televisions: 2,000 (1992 est.)
Defense
-------
Branches: no regular military forces; Solomon Islands National
Reconnaissance and Surveillance Force; Royal Solomon Islands Police
(RSIP)
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Somalia
-------
Map
---
Location: 10 00 N, 49 00 E -- Eastern Africa, bordering the Gulf
of Aden and the Indian Ocean, east of Ethiopia
Flag
----
Description: light blue with a large white five-pointed star in
the center; design based on the flag of the UN (Italian Somaliland
was a UN trust territory)
--------------
Telephones: 9,000 (1991 est.)
Telephone system: the public telecommunications system was
completely destroyed or dismantled by the civil war factions; all
relief organizations depend on their own private systems
domestic: recently, local cellular telephone systems have been
established in Mogadishu and in several other population centers
international: international connections are available from
Mogadishu by satellite
Radio broadcast stations: AM NA, FM NA, shortwave NA (there are at
least five radio broadcast stations of NA type)
Radios: 350,000 (1992 est.)
Television broadcast stations: 0 (Somalia''s only TV station was
demolished during the civil strife, sometime in 1991)
Televisions: 113,000 (1992 est.)
Defense
-------
Branches: NA; note - no functioning central government military
forces; clan militias continue to battle for control of key economic
or political prizes
Manpower availability:
males age 15-49: 2,333,994
males fit for military service: 1,301,954 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@South Africa
------------
Map
---
Location: 29 00 S, 24 00 E -- Southern Africa, at the southern tip
of the continent of Africa
Flag
----
Description: two equal width horizontal bands of red (top) and
blue separated by a central green band which splits into a
horizontal Y, the arms of which end at the corners of the hoist
side, embracing a black isoceles triangle from which the arms are
separated by narrow yellow bands; the red and blue bands are
separated from the green band and its arms by narrow white stripes
--------------
Telephones: 5,206,235 (1993 est.)
Telephone system: the system is the best developed, most modern,
and has the highest capacity in Africa
domestic: consists of carrier-equipped open-wire lines, coaxial
cables, microwave radio relay links, fiber-optic cable, and
radiotelephone communication stations; key centers are Bloemfontein,
Cape Town, Durban, Johannesburg, Port Elizabeth, and Pretoria
international: 1 submarine cable; satellite earth stations - 3
Intelsat (1 Indian Ocean and 2 Atlantic Ocean)
Radio broadcast stations: AM 14, FM 286, shortwave 0
Radios: 12.1 million (1992 est.)
Television broadcast stations: 67 (1987 est.)
Televisions: 3.45 million (1990 est.)
Defense
-------
Branches: South African National Defense Force (SANDF; includes
Army, Navy, Air Force, and Medical Services), South African Police
Service (SAPS)
Manpower availability:
males age 15-49: 10,686,976
males fit for military service: 6,502,265
males reach military age (18) annually: 424,854 (1996 est.)
Defense expenditures: exchange rate conversion - $2.9 billion,
2.2% of GDP (FY95/96)
======================================================================
@South Georgia and the South Sandwich Islands
--------------------------------------------
(dependent territory of the UK)
Map
---
Location: 54 30 S, 37 00 W -- Southern South America, islands in
the South Atlantic Ocean, east of the tip of South America
Flag
----
Description: the flag of the UK is used
--------------
Telephones: 34,000 (1991 est.)
Telephone system:
domestic: barely adequate wire and microwave radio relay service in
and between urban areas; domestic satellite system with 14 earth
stations
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 10, FM 4, shortwave 0
Radios: 3.87 million (1992 est.)
Television broadcast stations: 18
Televisions: 55,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, National Gendarmerie,
paramilitary Civil Guard, Special Presidential Division
Manpower availability:
males age 15-49: 10,025,536
males fit for military service: 5,108,385 (1996 est.)
Defense expenditures: exchange rate conversion - $46 million, 1.5%
of GDP (1990)
======================================================================
@Zambia
------
Map
---
Location: 15 00 S, 30 00 E -- Southern Africa, east of Angola
Flag
----
Description: green with a panel of three vertical bands of red
(hoist side), black, and orange below a soaring orange eagle, on the
outer edge of the flag','dec6ad70a014f20bfda87cb279aa8c3757eac4cb19fcc2d4354ca353a510342a','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5aba2a7898065cae92c1c95ad4ad5510194dee02dcef75e3bc752fbab86c0fe9',1996,'GI','Gibraltar','communications',299,'--------------
Telephones: 12.6 million (1990 est.)
Telephone system: generally adequate, modern facilities
domestic: NA
international: 22 coaxial submarine cables; satellite earth stations
- 2 Intelsat (1 Atlantic Ocean and 1 Indian Ocean), NA Eutelsat, NA
Inmarsat, and NA Marecs; tropospheric scatter to adjacent countries
Radio broadcast stations: AM 190, FM 406 (repeaters 134),
shortwave 0
Radios: 12 million (1992 est.)
Television broadcast stations: 100 (repeaters 1,297)
Televisions: 15.7 million (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, Marines, Civil Guard, National
Police, Coastal Civil Guard
Manpower availability:
males age 15-49: 10,360,209
males fit for military service: 8,370,197
males reach military age (20) annually: 341,670 (1996 est.)
Defense expenditures: exchange rate conversion - $6.3 billion,
1.4% of GDP (1995)
======================================================================
@Spratly Islands
---------------
Map
---
Location: 8 38 N, 111 55 E -- Southeastern Asia, group of reefs in
the South China Sea, about two-thirds of the way from southern
Vietnam to the southern Philippines
--------------
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
-------
Defense note: about 50 small islands or reefs are occupied by
China, Malaysia, the Philippines, Taiwan, and Vietnam
======================================================================
@Sri Lanka
---------
Map
---
Location: 7 00 N, 81 00 E -- Southern Asia, island in the Indian
Ocean, south of India
Flag
----
Description: yellow with two panels; the smaller hoist-side panel
has two equal vertical bands of green (hoist side) and orange; the
other panel is a large dark red rectangle with a yellow lion holding
a sword, and there is a yellow bo leaf in each corner; the yellow
field appears as a border that goes around the entire flag and
extends between the two panels
--------------
Telephones: 175,000 (1991 est.)
Telephone system: very inadequate domestic service, good
international service
domestic: NA
international: submarine cables to Indonesia and Djibouti; satellite
earth stations - 2 Intelsat (Indian Ocean)
Radio broadcast stations: AM 12, FM 5, shortwave 0
Radios: 3.525 million (1992 est.)
Television broadcast stations: 5
Televisions: 865,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, Police Force
Manpower availability:
males age 15-49: 5,085,306
males fit for military service: 3,960,070
males reach military age (18) annually: 180,825 (1996 est.)
Defense expenditures: exchange rate conversion - $640 million,
4.4% of GDP (1996)
======================================================================
@Sudan
-----
Map
---
Location: 15 00 N, 30 00 E -- Northern Africa, bordering the Red
Sea, between Egypt and Eritrea
Flag
----
Description: three equal horizontal bands of red (top), white, and
black with a green isosceles triangle based on the hoist side
--------------
Telephones: 77,215 (1983 est.)
Telephone system: large, well-equipped system by African
standards, but barely adequate and poorly maintained by modern
standards
domestic: consists of microwave radio relay, cable, radiotelephone
communications, tropospheric scatter, and a domestic satellite
system with 14 earth stations
international: satellite earth stations - 1 Intelsat (Atlantic
Ocean) and 1 Arabsat
Radio broadcast stations: AM 11, FM 0, shortwave 0
Radios: 6.67 million (1992 est.)
Television broadcast stations: 3
Televisions: 2.06 million (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, Popular Defense Force Militia
Manpower availability:
males age 15-49: 7,152,884
males fit for military service: 4,399,445
males reach military age (18) annually: 329,460 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Suriname
--------
Map
---
Location: 4 00 N, 56 00 W -- Northern South America, bordering the
North Atlantic Ocean, between French Guiana and Guyana
Flag
----
Description: five horizontal bands of green (top, double width),
white, red (quadruple width), white, and green (double width); there
is a large yellow five-pointed star centered in the red band
--------------
Telephones: 43,522 (1992 est.)
Telephone system: international facilities good
domestic: microwave radio relay network
international: satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 14, shortwave 1
Radios: 290,256 (1993 est.)
Television broadcast stations: 6 (1987 est.)
Televisions: 59,598 (1993 est.)
Defense
-------
Branches: National Army (includes small Navy and Air Force
elements), Civil Police
Manpower availability:
males age 15-49: 119,010
males fit for military service: 70,400 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Svalbard
--------
(territory of Norway)
Map
---
Location: 78 00 N, 20 00 E -- Northern Europe, islands between the
Arctic Ocean, Barents Sea, Greenland Sea, and Norwegian Sea, north
of Norway
Flag
----
Description: the flag of Norway is used
--------------
Telephones: NA
Telephone system:
domestic: local telephone service
international: satellite earth station - 1 of NA type (for
communication with Norwegian mainland only)
Radio broadcast stations: AM 1, FM 1 (repeaters 2), shortwave 0
note: there are five meteorological/radio stations
Radios: NA
Television broadcast stations: 1
Televisions: NA
Defense
-------
Defense note: demilitarized by treaty (9 February 1920)
======================================================================
@Swaziland
---------
Map
---
Location: 26 30 S, 31 30 E -- Southern Africa, between Mozambique
and South Africa
Flag
----
Description: three horizontal bands of blue (top), red (triple
width), and blue; the red band is edged in yellow; centered in the
red band is a large black and white shield covering two spears and a
staff decorated with feather tassels, all placed horizontally
--------------
Telephones: 30,364 (1993 est.)
Telephone system:
domestic: system consists of carrier-equipped, open-wire lines and
low-capacity, microwave radio relay
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 7, FM 6, shortwave 0
Radios: 129,000 (1992 est.)
Television broadcast stations: 10
Televisions: 12,500 (1992 est.)
Defense
-------
Branches: Umbutfo Swaziland Defense Force (Army), Royal Swaziland
Police Force
Manpower availability:
males age 15-49: 220,097
males fit for military service: 127,285 (1996 est.)
Defense expenditures: exchange rate conversion - $22 million, NA%
of GDP (FY93/94)
======================================================================
@Sweden
------
Map
---
Location: 62 00 N, 15 00 E -- Northern Europe, bordering the
Baltic Sea, Gulf of Bothnia, and Skagerrak, between Finland and','c898c5fb3c2f54c9628e2de9101828130fa36674f1793470537d8ed867d5437c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee3dd467a7061fe583df9911aae05fb0c359fd9fe232a2604c7ea93b1d8ea7c1',1996,'NO','Norway','communications',300,'Flag
----
Description: blue with a yellow cross that extends to the edges of
the flag; the vertical part of the cross is shifted to the hoist
side in the style of the Dannebrog (Danish flag)
--------------
Telephones: 7.41 million (1986 est.)
Telephone system: excellent domestic and international facilities;
automatic system
domestic: coaxial and multiconductor cable carry most voice traffic;
parallel microwave radio relay network carries some additional
telephone channels
international: 5 submarine coaxial cables; satellite earth stations
- 1 Intelsat (Atlantic Ocean), 1 Eutelsat, and 1 Inmarsat (Atlantic
and Indian Ocean regions); note - Sweden shares the Inmarsat earth
station with the other Nordic countries (Denmark, Finland, Iceland,
and Norway)
Radio broadcast stations: AM 5, FM 360 (mostly repeaters),
shortwave 0
Radios: 7.272 million (1993 est.)
Television broadcast stations: 880 (mostly repeaters)
Televisions: 3.5 million
Defense
-------
Branches: Swedish Army, Royal Swedish Navy, Swedish Air Force
Manpower availability:
males age 15-49: 2,133,816
males fit for military service: 1,867,031
males reach military age (19) annually: 51,357 (1996 est.)
Defense expenditures: exchange rate conversion - $5.8 billion,
2.5% of GDP (FY94/95)
======================================================================
@Switzerland
-----------
Map
---
Location: 47 00 N, 8 00 E -- Central Europe, east of France
Flag
----
Description: red square with a bold, equilateral white cross in
the center that does not extend to the edges of the flag
--------------
Telephones: 5,622,976 (1986 est.)
Telephone system: excellent domestic and international services
domestic: extensive cable and microwave radio relay networks
international: satellite earth stations - 2 Intelsat (Atlantic Ocean
and Indian Ocean)
Radio broadcast stations: AM 7, FM 265, shortwave 0
Radios: NA
Television broadcast stations: 18 (repeaters 1,322)
Televisions: 2.513 million (1994 est.)
Defense
-------
Branches: Army, Air Force and Antiaircraft Command, Frontier
Guards, Fortification Guards
Manpower availability:
males age 15-49: 1,893,587
males fit for military service: 1,623,414
males reach military age (20) annually: 41,425 (1996 est.)
Defense expenditures: exchange rate conversion - $3.74 billion,
1.4% of GDP (1995)
======================================================================
@Syria
-----
Map
---
Location: 35 00 N, 38 00 E -- Middle East, bordering the
Mediterranean Sea, between Lebanon and Turkey
Flag
----
Description: three equal horizontal bands of red (top), white, and
black with two small green five-pointed stars in a horizontal line
centered in the white band; similar to the flag of Yemen, which has
a plain white band and of Iraq, which has three green stars (plus an
Arabic inscription) in a horizontal line centered in the white band;
also similar to the flag of Egypt, which has a symbolic eagle
centered in the white band
--------------
Telephones: 541,465 (1992 est.)
Telephone system: fair system currently undergoing significant
improvement and digital upgrades, including fiber-optic technology
domestic: coaxial cable and microwave radio relay network
international: satellite earth stations - 1 Intelsat (Indian Ocean)
and 1 Intersputnik (Atlantic Ocean region); 1 submarine cable;
coaxial cable and microwave radio relay to Iraq, Jordan, Lebanon,
and Turkey; participant in Medarabtel
Radio broadcast stations: AM 9, FM 1, shortwave 0
Radios: 3.392 million (1992 est.)
Television broadcast stations: 17
Televisions: 700,000 (1993 est.)
Defense
-------
Branches: Syrian Arab Army, Syrian Arab Navy, Syrian Arab Air
Force, Syrian Arab Air Defense Forces, Police and Security Force
Manpower availability:
males age 15-49: 3,590,557
males fit for military service: 2,011,610
males reach military age (19) annually: 164,598 (1996 est.)
Defense expenditures: exchange rate conversion - $875 million, 8%
of GDP (1994 est.); note - based on official budget data that
understate actual spending
======================================================================
@Taiwan
------
Map
---
Location: 23 30 N, 121 00 E -- Eastern Asia, islands bordering the
East China Sea, Philippine Sea, South China Sea, and Taiwan Strait,
north of the Philippines, off the southeastern coast of China
Flag
----
Description: red with a dark blue rectangle in the upper
hoist-side corner bearing a white sun with 12 triangular rays
--------------
Telephones: 10,253,773 (1993 est.)
Telephone system: best developed system in Asia outside of Japan
domestic: extensive microwave radio relay trunk system on east and
west coasts
international: satellite earth stations - 2 Intelsat (1 Pacific
Ocean and 1 Indian Ocean); submarine cables to Japan (Okinawa),
Philippines, Guam, Singapore, Hong Kong, Indonesia, Australia,
Middle East, and Western Europe
Radio broadcast stations: AM 91, FM 23, shortwave 0
Radios: 8.62 million
Television broadcast stations: 15 (repeaters 13)
Televisions: 6.66 million (1993 est.)
Defense
-------
Branches: Army, Navy (includes Marines), Air Force, Coastal Patrol
and Defense Command, Armed Forces Reserve Command, Combined Service
Forces
Manpower availability:
males age 15-49: 6,278,159
males fit for military service: 4,849,057
males reach military age (19) annually: 204,313 (1996 est.)
Defense expenditures: exchange rate conversion - $11.5 billion,
3.6% of GDP (FY96/97)
======================================================================
@Tajikistan
----------
Tajikistan has experienced three changes of government since it
gained independence in September 1991. The current president,
Emomali RAHMONOV, was elected in November 1994, yet has been in
power since 1992. The country is suffering through its third year of
a civil conflict, with no clear end in sight. Underlying the
conflict are deeply rooted regional and clan-based animosities that
pit a government consisting of people primarily from the Kulob
(Kulyab), Khujand (Leninabad), and Hisor (Hissar) regions against a
secular and Islamic-led opposition from the Gharm, Gorno-Badakhshan,
and Qurghonteppa (Kurgan-Tyube) regions. Government and opposition
representatives have held periodic rounds of UN-mediated peace talks
and agreed in September 1994 to a cease-fire which has been
periodically extended. Russian-led peacekeeping troops are deployed
throughout the country, and Russian-commanded border guards are
stationed along the Tajik-Afghan border.
Map
---
Location: 39 00 N, 71 00 E -- Central Asia, west of China
Flag
----
Description: three horizontal stripes of red (top), a wider stripe
of white, and green; a gold crown surmounted by seven five-pointed
gold stars is located in the center of the white stripe
--------------
Telephones: 303,000 (1991 est.)
Telephone system: poorly developed and not well maintained; many
towns are not reached by the national network
domestic: cable and microwave radio relay
international: linked by cable and microwave radio relay to other
CIS republics, and by leased connections to the Moscow international
gateway switch; Dushanbe linked by Intelsat to international gateway
switch in Ankara (Turkey); satellite earth stations - 1 Orbita and 2
Intelsat
Radio broadcast stations: AM NA, FM NA, shortwave NA; note - there
is one state-owned radio broadcast station
Radios: NA
Television broadcast stations: 1
note: 1 Intelsat earth station provides TV receive-only service from
Turkey
Televisions: NA
Defense
-------
Branches: Army (being formed), Presidential National Guard,
Security Forces (internal and border troops)
Manpower availability:
males age 15-49: 1,358,106
males fit for military service: 1,115,149
males reach military age (18) annually: 58,691 (1996 est.)
Defense expenditures: 180 billion rubles, 3.4% of GDP (1995)
======================================================================
@Tanzania
--------
Map
---
Location: 6 00 S, 35 00 E -- Eastern Africa, bordering the Indian
Ocean, between Kenya and Mozambique
Flag
----
Description: divided diagonally by a yellow-edged black band from
the lower hoist-side corner; the upper triangle (hoist side) is
green and the lower triangle is blue
--------------
Telephones: 137,000 (1989 est.)
Telephone system: fair system operating below capacity
domestic: open wire, microwave radio relay, tropospheric scatter
international: satellite earth stations - 2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean)
Radio broadcast stations: AM 12, FM 4, shortwave 0
Radios: 640,000 (1992 est.)
Television broadcast stations: 2 (1987 est.)
Televisions: 45,000 (1992 est.)
Defense
-------
Branches: Tanzanian People''s Defense Force (TPDF; includes Army,
Navy, and Air Force), paramilitary Police Field Force Unit, Militia
Manpower availability:
males age 15-49: 6,499,244
males fit for military service: 3,765,193 (1996 est.)
Defense expenditures: exchange rate conversion - $69 million, NA%
of GDP (FY94/95)
======================================================================
@Thailand
--------
Map
---
Location: 15 00 N, 100 00 E -- Southeastern Asia, bordering the
Andaman Sea and the Gulf of Thailand, southeast of Burma
Flag
----
Description: five horizontal bands of red (top), white, blue
(double width), white, and red
--------------
Telephones: 1,553,200 (1994 est.)
Telephone system: service to general public inadequate; bulk of
service to government activities provided by multichannel cable and
microwave radio relay network
domestic: microwave radio relay and multichannel cable; domestic
satellite system being developed
international: satellite earth stations - 2 Intelsat (1 Indian Ocean
and 1 Pacific Ocean)
Radio broadcast stations: AM 200 (in government-controlled
network), FM 100 (in government-controlled network), shortwave 0
Radios: 10.75 million (1992 est.)
Television broadcast stations: 11 (in government-controlled
network)
Televisions: 3.3 million (1993 est.)
Defense
-------
Branches: Royal Thai Army, Royal Thai Navy (includes Royal Thai
Marine Corps), Royal Thai Air Force, Paramilitary Forces
Manpower availability:
males age 15-49: 16,835,334
males fit for military service: 10,182,904
males reach military age (18) annually: 592,268 (1996 est.)
Defense expenditures: exchange rate conversion - $4.0 billion,
2.5% of GDP (FY94/95)
======================================================================
@The Bahamas
-----------
Map
---
Location: 24 15 N, 76 00 W -- Caribbean, chain of islands in the
North Atlantic Ocean, southeast of Florida
Flag
----
Description: three equal horizontal bands of aquamarine (top),
gold, and aquamarine with a black equilateral triangle based on the
hoist side
--------------
Telephones: 119,000 (1987 est.)
Telephone system:
domestic: totally automatic system; highly developed
international: tropospheric scatter and submarine cable to Florida;
3 coaxial submarine cables; satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 2, shortwave 0
Radios: 200,000 (1993 est.)
Television broadcast stations: 1 (1986 est.)
Televisions: 60,000 (1993 est.)
Defense
-------
Branches: Royal Bahamas Defense Force (Coast Guard only), Royal
Bahamas Police Force
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: exchange rate conversion - $20 million, 3.8%
of GDP (FY95/96)
======================================================================
@The Gambia
----------
Map
---
Location: 13 28 N, 16 34 W -- Western Africa, bordering the North
Atlantic Ocean and Senegal
Flag
----
Description: three equal horizontal bands of red (top), blue with
white edges, and green','5b6fbb30cdb2b02e0e29309c6eda8560152fff1ba050668927c3b8851562fccc','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a78e4844a06b4bcaf33d5b7b536e96f4f835ac5ca133f7f3e99799201fc4d94f',1996,'SN','Senegal','communications',314,'--------------
Telephones: 11,000 (1991 est.)
Telephone system:
domestic: adequate network of microwave radio relay and open wire
international: microwave radio relay links to Senegal and
Guinea-Bissau; satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 2, shortwave 0
Radios: 180,000 (1993 est.)
Television broadcast stations: NA
Televisions: NA
Defense
-------
Branches: Army, Navy, National Police
Manpower availability:
males age 15-49: 267,188
males fit for military service: 134,611 (1996 est.)
Defense expenditures: exchange rate conversion - $14 million, 3.8%
of GDP (FY93/94)
======================================================================
@Togo
----
Map
---
Location: 8 00 N, 1 10 E -- Western Africa, bordering the North
Atlantic Ocean, between Benin and Ghana
Flag
----
Description: five equal horizontal bands of green (top and bottom)
alternating with yellow; there is a white five-pointed star on a red
square in the upper hoist-side corner; uses the popular pan-African
colors of Ethiopia
--------------
Telephones: 12,000 (1987 est.)
Telephone system: fair system based on network of microwave radio
relay routes supplemented by open-wire lines
domestic: microwave radio relay and open-wire lines
international: satellite earth stations - 1 Intelsat (Atlantic
Ocean) and 1 Symphonie
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 795,000 (1992 est.)
Television broadcast stations: 3 (relays 2)
Televisions: 24,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, Gendarmerie
Manpower availability:
males age 15-49: 975,746
males fit for military service: 512,196 (1996 est.)
Defense expenditures: exchange rate conversion - $48 million, 2.9%
of GDP (1993)
======================================================================
@Tokelau
-------
(territory of New Zealand)
Map
---
Location: 9 00 S, 172 00 W -- Oceania, group of islands in the
South Pacific Ocean, about one-half of the way from Hawaii to New
Zealand
Flag
----
Description: the flag of New Zealand is used','482cf303d304bfe8622d80c6c63a62c65536702b761b2b36f8e4f46bd211ea86','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22c39406671c8604b0238eb41ec5ce1dbb4e2afdb135ead01adf7998addbcd77',1996,'NZ','New Zealand','communications',318,'--------------
Telephones: NA
Telephone system:
domestic: radiotelephone service between islands
international: radiotelephone service to Western Samoa
Radio broadcast stations: AM NA, FM NA, shortwave NA
note: each atoll has a radio broadcast station of NA type that
broadcasts shipping and weather reports
Radios: 1,000 (1992 est.)
Television broadcast stations: NA
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of New Zealand
======================================================================
@Tonga
-----
Map
---
Location: 20 00 S, 175 00 W -- Oceania, archipelago in the South
Pacific Ocean, about two-thirds of the way from Hawaii to New Zealand
Flag
----
Description: red with a bold red cross on a white rectangle in the
upper hoist-side corner
--------------
Telephones: 3,500 (1986 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 66,000 (1993 est.)
Television broadcast stations: 0
Televisions: 1,000 (1992 est.)
Defense
-------
Branches: Tonga Defense Services, Maritime Division, Royal Tongan
Marines, Tongan Royal Guards, Police
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Trinidad and Tobago
-------------------
Map
---
Location: 11 00 N, 61 00 W -- Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean, northeast of Venezuela
Flag
----
Description: red with a white-edged black diagonal band from the
upper hoist side
--------------
Telephones: 170,000 (1992 est.)
Telephone system: excellent international service; good local
service
domestic: NA
international: satellite earth station - 1 Intelsat (Atlantic
Ocean); tropospheric scatter to Barbados and Guyana
Radio broadcast stations: AM 2, FM 4, shortwave 0
Radios: 700,000 (1993 est.)
Television broadcast stations: 5 (1987 est.)
Televisions: 400,000 (1992 est.)
Defense
-------
Branches: Trinidad and Tobago Defense Force (includes Ground
Forces, Coast Guard, and Air Wing), Trinidad and Tobago Police
Service
Manpower availability:
males age 15-49: 351,835
males fit for military service: 252,532 (1996 est.)
Defense expenditures: exchange rate conversion - $83 million, NA%
of GDP (1994)
======================================================================
@Tromelin Island
---------------
(possession of France)
Map
---
Location: 15 52 S, 54 25 E -- Southern Africa, island in the
Indian Ocean, east of Madagascar
Flag
----
Description: the flag of France is used','07ddd9d35046fb274e77605efaf5786cd115323f28662ffd13f617e1e6e23144','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6637720b04232acfeeb2f4a7b36912f21947284df73095c79ae5beca191218e',1996,'SC','Seychelles','communications',328,'--------------
Communications note: important meteorological station
Defense
-------
Defense note: defense is the responsibility of France
======================================================================
@Tunisia
-------
Map
---
Location: 34 00 N, 9 00 E -- Northern Africa, bordering the
Mediterranean Sea, between Algeria and Libya
Flag
----
Description: red with a white disk in the center bearing a red
crescent nearly encircling a red five-pointed star; the crescent and
star are traditional symbols of Islam
--------------
Telephones: 233,000 (1987 est.)
Telephone system: the system is above the African average; key
centers are Sfax, Sousse, Bizerte, and Tunis
domestic: trunk facilities consist of open-wire lines, coaxial
cable, and microwave radio relay
international: 5 submarine cables; satellite earth stations - 1
Intelsat (Atlantic Ocean) and 1 Arabsat with back-up control
station; coaxial cable and microwave radio relay to Algeria and
Libya; participant in Medarabtel
Radio broadcast stations: AM 7, FM 8, shortwave 0
Radios: 1,693,527 (1991 est.)
Television broadcast stations: 19
Televisions: 670,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, paramilitary forces, National
Guard
Manpower availability:
males age 15-49: 2,354,513
males fit for military service: 1,349,728
males reach military age (20) annually: 91,866 (1996 est.)
Defense expenditures: exchange rate conversion - $535 million,
2.8% of GDP (1995)
======================================================================
@Turkey
------
Map
---
Location: 39 00 N, 35 00 E -- Southwestern Asia (that part west of
the Bosporus is sometimes included with Europe), bordering the Black
Sea, between Bulgaria and Georgia, and bordering the Aegean Sea and
the Mediterranean Sea, between Greece and Syria
Flag
----
Description: red with a vertical white crescent (the closed
portion is toward the hoist side) and white five-pointed star
centered just outside the crescent opening
--------------
Telephones: 6.89 million (1990 est.)
Telephone system: fair domestic and international systems
domestic: trunk microwave radio relay network; limited open-wire
network
international: satellite earth stations - 2 Intelsat (Atlantic
Ocean), 1 Eutelsat, and 2 Inmarsat (Indian and Atlantic Ocean
regions); 1 submarine cable
Radio broadcast stations: AM 15, FM 94, shortwave 0
Radios: 9.4 million (1992 est.)
Television broadcast stations: 357
Televisions: 10.53 million (1993 est.)
Defense
-------
Branches: Land Forces, Navy (includes Naval Air and Naval
Infantry), Air Force, Coast Guard, Gendarmerie
Manpower availability:
males age 15-49: 16,937,828
males fit for military service: 10,312,010
males reach military age (20) annually: 637,456 (1996 est.)
Defense expenditures: exchange rate conversion - $6.0 billion, 4%
of GDP (1995); note - figures do not include about $7 billion for
the government''s counterinsurgency effort against the separatist
Kurdistan Workers'' Party (PKK)
======================================================================
@Turkmenistan
------------
Map
---
Location: 40 00 N, 60 00 E -- Central Asia, bordering the Caspian
Sea, between Iran and Kazakstan
Flag
----
Description: green field, including a vertical stripe on the hoist
side, with a claret vertical stripe in between containing five
white, black, and orange carpet guls (an asymmetrical design used in
producing rugs) associated with five different tribes; a white
crescent and five white stars in the upper left corner to the right
of the carpet guls
--------------
Telephones: NA
Telephone system: poorly developed
domestic: NA
international: linked by cable and microwave radio relay to other
CIS republics and to other countries by leased connections to the
Moscow international gateway switch; a new telephone link from
Ashgabat to Iran has been established; a new exchange in Ashgabat
switches international traffic through Turkey via Intelsat;
satellite earth stations - 1 Orbita and 1 Intelsat
Radio broadcast stations: AM NA, FM NA, shortwave NA; note - there
is at least one state-owned radio broadcast station of NA type
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
-------
Branches: Army, Air and Air Defense, Republic Security Forces
(internal and border troops), National Guard
Manpower availability:
males age 15-49: 1,024,398
males fit for military service: 834,803
males reach military age (18) annually: 41,697 (1996 est.)
Defense expenditures: 4.5 billion manats, 3.0% of GDP (1995); note
- conversion of defense expenditures into US dollars using the
current exchange rate could produce misleading results
======================================================================
@Turks and Caicos Islands
------------------------
(dependent territory of the UK)
Map
---
Location: 21 45 N, 71 35 W -- Caribbean, two island groups in the
North Atlantic Ocean, southeast of The Bahamas
Flag
----
Description: blue with the flag of the UK in the upper hoist-side
quadrant and the colonial shield centered on the outer half of the
flag; the shield is yellow and contains a conch shell, lobster, and
cactus
--------------
Telephones: 1,359 (1988 est.)
Telephone system: fair cable and radiotelephone services
domestic: NA
international: 2 submarine cables; satellite earth station - 1
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 0, shortwave 0
Radios: 7,000 (1992 est.)
Television broadcast stations: television programs are available
from a cable network, and broadcasts from the Bahamas can be
received in the islands
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the UK
======================================================================
@Tuvalu
------
Map
---
Location: 8 00 S, 178 00 E -- Oceania, island group consisting of
nine coral atolls in the South Pacific Ocean, about one-half of the
way from Hawaii to Australia
Flag
----
Description: light blue with the flag of the UK in the upper
hoist-side quadrant; the outer half of the flag represents a map of
the country with nine yellow five-pointed stars symbolizing the nine
islands','8656a0f4cd2ecb8f809bbbb510ed057e9ca78d6ffc738926cd7a25b050541d59','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5414f9a247636efb548648a56846a0db0021364950fb11b3a09b15e02490834f',1996,'IE','Ireland','communications',332,'--------------
Telephones: 29.5 million (1987 est.)
Telephone system: technologically advanced domestic and
international system
domestic: equal mix of buried cables, microwave radio relay, and
fiber-optic systems
international: 40 coaxial submarine cables; satellite earth stations
- 10 Intelsat (7 Atlantic Ocean and 3 Indian Ocean), 1 Inmarsat
(Atlantic Ocean region), and 1 Eutelsat; at least 8 large
international switching centers
Radio broadcast stations: AM 225, FM 525 (mostly repeaters),
shortwave 0
Radios: 70 million
Television broadcast stations: 207 (repeaters 3,210)
Televisions: 20 million
Defense
-------
Branches: Army, Royal Navy (includes Royal Marines), Royal Air
Force
Manpower availability:
males age 15-49: 14,515,077
males fit for military service: 12,102,431 (1996 est.)
Defense expenditures: exchange rate conversion - $35.1 billion,
3.1% of GDP (FY95/96)
======================================================================
@United States
-------------
Map
---
Location: 38 00 N, 97 00 W -- North America, bordering both the
North Atlantic Ocean and the North Pacific Ocean, between Canada and','e7d1fc0aea72c60f68de43285593d8814e4d0c271e0df87ffa9c704a04ab399e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1227104d6ae44620290dc5856da01d5243ccbf97e52866e6c3dc3cf9a0fafdca',1996,'NC','New Caledonia','communications',339,'--------------
Telephones: 3,000 (1987 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 0 (1987 est.)
Televisions: 2,000 (1992 est.)
Defense
-------
Branches: no regular military forces; Vanuatu Police Force (VPF;
includes the paramilitary Vanuatu Mobile Force or VMF)
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Venezuela
---------
Map
---
Location: 8 00 N, 66 00 W -- Northern South America, bordering the
Caribbean Sea and the North Atlantic Ocean, between Colombia and','1fcc5e0eca3b99a61f085a532de8d9f6f05d2923efd9401c828ffcd7f21edbe7','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1dd74b8c5939d2e48f0b819f6374855c5fb6be847bc1c2951cef209bbc23253',1996,'GY','Guyana','communications',340,'Flag
----
Description: three equal horizontal bands of yellow (top), blue,
and red with the coat of arms on the hoist side of the yellow band
and an arc of seven white five-pointed stars centered in the blue
band
--------------
Telephones: 800,000 (1995 est.)
Telephone system: while Vietnam''s telecommunication sector lags
far behind other countries in Southeast Asia, Hanoi has made
considerable progress since 1991 in upgrading the system; Vietnam
has digitized fully 100% of provincial switch boards, while
fiber-optic and microwave transmission systems have been extended
from Hanoi, Da Nang, and Ho Chi Minh City to all provinces; the
density of telephone receivers nationwide doubled from 1993 to 1995,
but is still far behind other countries in the region; Vietnam''s
telecommunications strategy aims to increase telephone density to 30
per 1,000 inhabitants by the year 2000 and authorities estimate that
approximately $2.7 billion will be spent on telecommunications
upgrades through the end of the decade
domestic: NA
international: satellite earth stations - 2 Intersputnik (Indian
Ocean region)
Radio broadcast stations: AM NA, FM 228, shortwave 0
Radios: 7.215 million (1992 est.)
Television broadcast stations: 36 (repeaters 77)
Televisions: 2.9 million (1992 est.)
Defense
-------
Branches: People''s Army of Vietnam (PAVN) (includes Ground Forces,
Navy, and Air Force)
Manpower availability:
males age 15-49: 18,593,129
males fit for military service: 11,769,955
males reach military age (17) annually: 796,312 (1996 est.)
Defense expenditures: exchange rate conversion - $544 million,
2.7% of GDP (1995)
======================================================================
@Virgin Islands
--------------
(territory of the US)
Map
---
Location: 18 20 N, 64 50 W -- Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean, east of Puerto Rico
Flag
----
Description: white with a modified US coat of arms in the center
between the large blue initials V and I; the coat of arms shows a
yellow eagle holding an olive branch in one talon and three arrows
in the other with a superimposed shield of vertical red and white
stripes below a blue panel
--------------
Telephones: 60,000 (1990 est.)
Telephone system:
domestic: modern, uses fiber-optic cable and microwave radio relay
international: submarine cable and satellite communications;
satellite earth stations - NA
Radio broadcast stations: AM 4, FM 8, shortwave 0 (1988)
Radios: 105,000 (1992 est.)
Television broadcast stations: 4 (1988 est.)
Televisions: 65,000 (1992 est.)
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Wake Island
-----------
(territory of the US)
Map
---
Location: 19 17 N, 166 36 E -- Oceania, island in the North
Pacific Ocean, about two-thirds of the way from Hawaii to the','f09d56c4055afb4808f698c00f49852e45e8cbea39ad0277b5cf0914d4fb88a5','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61a4531482c647091f479dee5eb9dbca6f873242a5866e820d5d6523c03420ed',1996,'MP','Northern Mariana Islands','communications',347,'Flag
----
Description: the flag of the US is used
--------------
Telephones: NA
Telephone system: satellite communications; 1 DSN circuit off the
Overseas Telephone System (OTS)
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM NA, shortwave NA
note: Armed Forces Radio/Television Service (AFRTS) radio service
provided by satellite
Radios: NA
Television broadcast stations: NA
note: Armed Forces Radio/Television Service (AFRTS) television
service provided by satellite
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Wallis and Futuna
-----------------
(overseas territory of France)
Map
---
Location: 13 18 S, 176 12 W -- Oceania, islands in the South
Pacific Ocean, about two-thirds of the way from Hawaii to New Zealand
Flag
----
Description: a white modified Maltese cross centered on a red
background; the flag of France outlined in white on two sides is in
the upper hoist quadrant; the flag of France is used for official
occasions
--------------
Telephones: 340 (1985 est.)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 0
Televisions: NA
Defense
-------
Defense note: defense is the responsibility of France
======================================================================
@West Bank
---------
The Israel-PLO Declaration of Principles on Interim Self-Government
Arrangements ("the DOP"), signed in Washington on 13 September 1993,
provides for a transitional period not exceeding five years of
Palestinian interim self-government in the Gaza Strip and the West
Bank. Permanent status negotiations began on 5 May 1996.
Map
---
Location: 32 00 N, 35 15 E -- Middle East, west of Jordan
--------------
Telephones: NA
note: 8% of Palestinian households have telephones (1992 est.)
Telephone system:
domestic: NA
international: NA
note: Israeli company BEZEK is responsible for communication
services in the West Bank
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: NA; note - 82% of Palestinian households have radios (1992
est.)
Television broadcast stations: 0
note: 1 broadcast station is planned for Jericho
Televisions: NA; note - 54% of Palestinian households have
televisions (1992 est.)
Defense
-------
Branches: NA
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Western Sahara
--------------
Map
---
Location: 24 30 N, 13 00 W -- Northern Africa, bordering the North
Atlantic Ocean, between Mauritania and Morocco
--------------
Telephones: 2,000
Telephone system: sparse and limited system
domestic: NA
international: tied into Morocco''s system by microwave radio relay,
tropospheric scatter, and satellite; satellite earth stations - 2
Intelsat (Atlantic Ocean) linked to Rabat, Morocco
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 2
Televisions: NA
Defense
-------
Branches: NA
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@Western Samoa
-------------
Map
---
Location: 13 35 S, 172 20 W -- Oceania, group of islands in the
South Pacific Ocean, about one-half of the way from Hawaii to New
Zealand
Flag
----
Description: red with a blue rectangle in the upper hoist-side
quadrant bearing five white five-pointed stars representing the
Southern Cross constellation
--------------
Telephones: 7,500 (1988 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 76,000 (1992 est.)
Television broadcast stations: 0 (1987 est.)
Televisions: 6,000 (1992 est.)
Defense
-------
Branches: no regular armed services; Western Samoa Police Force
Manpower availability:
males age 15-49: NA
males fit for military service: NA
Defense expenditures: $NA, NA% of GDP
======================================================================
@World
-----
Map
---
--------------
Telephones: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Defense
-------
Branches: ground, maritime, and air forces at all levels of
technology
Defense expenditures: probably a small decline in 1995 in
aggregate real expenditure on arms worldwide and somewhat less than
three-quarters of a trillion dollars in money terms, or roughly 2%
of gross world product (1995 est.)
======================================================================
@Yemen
-----
Map
---
Location: 15 00 N, 48 00 E -- Middle East, bordering the Arabian
Sea, Gulf of Aden, and Red Sea, between Oman and Saudi Arabia
Flag
----
Description: three equal horizontal bands of red (top), white, and
black; similar to the flag of Syria which has two green stars and of
Iraq which has three green stars (plus an Arabic inscription) in a
horizontal line centered in the white band; also similar to the flag
of Egypt which has a symbolic eagle centered in the white band
--------------
Telephones: 131,655 (1992 est.)
Telephone system: since unification in 1990, efforts have been
made to create a national telecommunications network
domestic: the network consists of microwave radio relay, cable, and
tropospheric scatter
international: satellite earth stations - 3 Intelsat (2 Indian Ocean
and 1 Atlantic Ocean), 1 Intersputnik (Atlantic Ocean region), and 2
Arabsat; microwave radio relay to Saudi Arabia and Djibouti
Radio broadcast stations: AM 4, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 10
Televisions: 350,000 (1992 est.)
Defense
-------
Branches: Army, Navy, Air Force, paramilitary (includes Police)
Manpower availability:
males age 15-49: 2,985,764
males fit for military service: 1,685,517
males reach military age (18) annually: 145,161 (1996 est.)
Defense expenditures: $NA, NA% of GDP
======================================================================
@Zaire
-----
Map
---
Location: 0 00 N, 25 00 E -- Central Africa, northeast of Angola
Flag
----
Description: light green with a yellow disk in the center bearing
a black arm holding a red flaming torch; the flames of the torch are
blowing away from the hoist side; uses the popular pan-African
colors of Ethiopia','be2ebad7c4540a9556ba99f3faccefe105e0bb0241574e397c1c2f69601b24f5','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b78b719aa11cd4e3fa6bbca67589549826b7dc17a05feff13f07fe3235b3401',1996,'BW','Botswana','communications',354,'Flag
----
Description: seven equal horizontal bands of green, yellow, red,
black, red, yellow, and green with a white equilateral triangle
edged in black based on the hoist side; a yellow Zimbabwe bird is
superimposed on a red five-pointed star in the center of the triangle
--------------
Telephones: 301,000 (1990 est.)
Telephone system: system was once one of the best in Africa, but
now suffers from poor maintenance
domestic: consists of microwave radio relay links, open-wire lines,
and radiotelephone communication stations
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 8, FM 18, shortwave 0
Radios: 890,000 (1992 est.)
Television broadcast stations: 8 (1986 est.)
Televisions: 280,000 (1992 est.)
Defense
-------
Branches: Zimbabwe National Army, Air Force of Zimbabwe, Zimbabwe
Republic Police (includes Police Support Unit, Paramilitary Police)
Manpower availability:
males age 15-49: 2,629,880
males fit for military service: 1,632,391 (1996 est.)
Defense expenditures: exchange rate conversion - $236 million,
3.4% of GDP (FY95/96)
======================================================================
End of the Project Gutenberg EBook of The 1996 CIA Factbook, by
United States. Central Intelligence Agency.
*** END OF THIS PROJECT GUTENBERG EBOOK THE 1996 CIA FACTBOOK ***
***** This file should be named 27675.txt or 27675.zip *****
This and all associated files of various formats will be found in:
http://www.gutenberg.org/2/7/6/7/27675/
Produced by Al Haines
Updated editions will replace the previous one--the old editions
will be renamed.
Creating the works from public domain print editions means that no
one owns a United States copyright in these works, so the Foundation
(and you!) can copy and distribute it in the United States without
permission and without paying copyright royalties. Special rules,
set forth in the General Terms of Use part of this license, apply to
copying and distributing Project Gutenberg-tm electronic works to
protect the PROJECT GUTENBERG-tm concept and trademark. Project
Gutenberg is a registered trademark, and may not be used if you
charge for the eBooks, unless you receive specific permission. If you
do not charge anything for copies of this eBook, complying with the
rules is very easy. You may use this eBook for nearly any purpose
such as creation of derivative works, reports, performances and
research. They may be modified and printed and given away--you may do
practically ANYTHING with public domain eBooks. Redistribution is
subject to the trademark license, especially commercial
redistribution.
*** START: FULL LICENSE ***
THE FULL PROJECT GUTENBERG LICENSE
PLEASE READ THIS BEFORE YOU DISTRIBUTE OR USE THIS WORK
To protect the Project Gutenberg-tm mission of promoting the free
distribution of electronic works, by using or distributing this work
(or any other work associated in any way with the phrase "Project
Gutenberg"), you agree to comply with all the terms of the Full Project
Gutenberg-tm License (available with this file or online at
http://gutenberg.net/license).
Section 1. General Terms of Use and Redistributing Project Gutenberg-tm
electronic works
1.A. By reading or using any part of this Project Gutenberg-tm
electronic work, you indicate that you have read, understand, agree to
and accept all the terms of this license and intellectual property
(trademark/copyright) agreement. If you do not agree to abide by all
the terms of this agreement, you must cease using and return or destroy
all copies of Project Gutenberg-tm electronic works in your possession.
If you paid a fee for obtaining a copy of or access to a Project
Gutenberg-tm electronic work and you do not agree to be bound by the
terms of this agreement, you may obtain a refund from the person or
entity to whom you paid the fee as set forth in paragraph 1.E.8.
1.B. "Project Gutenberg" is a registered trademark. It may only be
used on or associated in any way with an electronic work by people who
agree to be bound by the terms of this agreement. There are a few
things that you can do with most Project Gutenberg-tm electronic works
even without complying with the full terms of this agreement. See
paragraph 1.C below. There are a lot of things you can do with Project
Gutenberg-tm electronic works if you follow the terms of this agreement
and help preserve free future access to Project Gutenberg-tm electronic
works. See paragraph 1.E below.
1.C. The Project Gutenberg Literary Archive Foundation ("the Foundation"
or PGLAF), owns a compilation copyright in the collection of Project
Gutenberg-tm electronic works. Nearly all the individual works in the
collection are in the public domain in the United States. If an
individual work is in the public domain in the United States and you are
located in the United States, we do not claim a right to prevent you from
copying, distributing, performing, displaying or creating derivative
works based on the work as long as all references to Project Gutenberg
are removed. Of course, we hope that you will support the Project
Gutenberg-tm mission of promoting free access to electronic works by
freely sharing Project Gutenberg-tm works in compliance with the terms of
this agreement for keeping the Project Gutenberg-tm name associated with
the work. You can easily comply with the terms of this agreement by
keeping this work in the same format with its attached full Project
Gutenberg-tm License when you share it without charge with others.
1.D. The copyright laws of the place where you are located also govern
what you can do with this work. Copyright laws in most countries are in
a constant state of change. If you are outside the United States, check
the laws of your country in addition to the terms of this agreement
before downloading, copying, displaying, performing, distributing or
creating derivative works based on this work or any other Project
Gutenberg-tm work. The Foundation makes no representations concerning
the copyright status of any work in any country outside the United
States.
1.E. Unless you have removed all references to Project Gutenberg:
1.E.1. The following sentence, with active links to, or other immediate
access to, the full Project Gutenberg-tm License must appear prominently
whenever any copy of a Project Gutenberg-tm work (any work on which the
phrase "Project Gutenberg" appears, or with which the phrase "Project
Gutenberg" is associated) is accessed, displayed, performed, viewed,
copied or distributed:
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
1.E.2. If an individual Project Gutenberg-tm electronic work is derived
from the public domain (does not contain a notice indicating that it is
posted with permission of the copyright holder), the work can be copied
and distributed to anyone in the United States without paying any fees
or charges. If you are redistributing or providing access to a work
with the phrase "Project Gutenberg" associated with or appearing on the
work, you must comply either with the requirements of paragraphs 1.E.1
through 1.E.7 or obtain permission for the use of the work and the
Project Gutenberg-tm trademark as set forth in paragraphs 1.E.8 or
1.E.9.
1.E.3. If an individual Project Gutenberg-tm electronic work is posted
with the permission of the copyright holder, your use and distribution
must comply with both paragraphs 1.E.1 through 1.E.7 and any additional
terms imposed by the copyright holder. Additional terms will be linked
to the Project Gutenberg-tm License for all works posted with the
permission of the copyright holder found at the beginning of this work.
1.E.4. Do not unlink or detach or remove the full Project Gutenberg-tm
License terms from this work, or any files containing a part of this
work or any other work associated with Project Gutenberg-tm.
1.E.5. Do not copy, display, perform, distribute or redistribute this
electronic work, or any part of this electronic work, without
prominently displaying the sentence set forth in paragraph 1.E.1 with
active links or immediate access to the full terms of the Project
Gutenberg-tm License.
1.E.6. You may convert to and distribute this work in any binary,
compressed, marked up, nonproprietary or proprietary form, including any
word processing or hypertext form. However, if you provide access to or
distribute copies of a Project Gutenberg-tm work in a format other than
"Plain Vanilla ASCII" or other format used in the official version
posted on the official Project Gutenberg-tm web site (www.gutenberg.net),
you must, at no additional cost, fee or expense to the user, provide a
copy, a means of exporting a copy, or a means of obtaining a copy upon
request, of the work in its original "Plain Vanilla ASCII" or other
form. Any alternate format must include the full Project Gutenberg-tm
License as specified in paragraph 1.E.1.
1.E.7. Do not charge a fee for access to, viewing, displaying,
performing, copying or distributing any Project Gutenberg-tm works
unless you comply with paragraph 1.E.8 or 1.E.9.
1.E.8. You may charge a reasonable fee for copies of or providing
access to or distributing Project Gutenberg-tm electronic works provided
that
- You pay a royalty fee of 20% of the gross profits you derive from
the use of Project Gutenberg-tm works calculated using the method
you already use to calculate your applicable taxes. The fee is
owed to the owner of the Project Gutenberg-tm trademark, but he
has agreed to donate royalties under this paragraph to the
Project Gutenberg Literary Archive Foundation. Royalty payments
must be paid within 60 days following each date on which you
prepare (or are legally required to prepare) your periodic tax
returns. Royalty payments should be clearly marked as such and
sent to the Project Gutenberg Literary Archive Foundation at the
address specified in Section 4, "Information about donations to
the Project Gutenberg Literary Archive Foundation."
- You provide a full refund of any money paid by a user who notifies
you in writing (or by e-mail) within 30 days of receipt that s/he
does not agree to the terms of the full Project Gutenberg-tm
License. You must require such a user to return or
destroy all copies of the works possessed in a physical medium
and discontinue all use of and all access to other copies of
Project Gutenberg-tm works.
- You provide, in accordance with paragraph 1.F.3, a full refund of any
money paid for a work or a replacement copy, if a defect in the
electronic work is discovered and reported to you within 90 days
of receipt of the work.
- You comply with all other terms of this agreement for free
distribution of Project Gutenberg-tm works.
1.E.9. If you wish to charge a fee or distribute a Project Gutenberg-tm
electronic work or group of works on different terms than are set
forth in this agreement, you must obtain permission in writing from
both the Project Gutenberg Literary Archive Foundation and Michael
Hart, the owner of the Project Gutenberg-tm trademark. Contact the
Foundation as set forth in Section 3 below.
1.F.
1.F.1. Project Gutenberg volunteers and employees expend considerable
effort to identify, do copyright research on, transcribe and proofread
public domain works in creating the Project Gutenberg-tm
collection. Despite these efforts, Project Gutenberg-tm electronic
works, and the medium on which they may be stored, may contain
"Defects," such as, but not limited to, incomplete, inaccurate or
corrupt data, transcription errors, a copyright or other intellectual
property infringement, a defective or damaged disk or other medium, a
computer virus, or computer codes that damage or cannot be read by
your equipment.
1.F.2. LIMITED WARRANTY, DISCLAIMER OF DAMAGES - Except for the "Right
of Replacement or Refund" described in paragraph 1.F.3, the Project
Gutenberg Literary Archive Foundation, the owner of the Project
Gutenberg-tm trademark, and any other party distributing a Project
Gutenberg-tm electronic work under this agreement, disclaim all
liability to you for damages, costs and expenses, including legal
fees. YOU AGREE THAT YOU HAVE NO REMEDIES FOR NEGLIGENCE, STRICT
LIABILITY, BREACH OF WARRANTY OR BREACH OF CONTRACT EXCEPT THOSE
PROVIDED IN PARAGRAPH F3. YOU AGREE THAT THE FOUNDATION, THE
TRADEMARK OWNER, AND ANY DISTRIBUTOR UNDER THIS AGREEMENT WILL NOT BE
LIABLE TO YOU FOR ACTUAL, DIRECT, INDIRECT, CONSEQUENTIAL, PUNITIVE OR
INCIDENTAL DAMAGES EVEN IF YOU GIVE NOTICE OF THE POSSIBILITY OF SUCH
DAMAGE.
1.F.3. LIMITED RIGHT OF REPLACEMENT OR REFUND - If you discover a
defect in this electronic work within 90 days of receiving it, you can
receive a refund of the money (if any) you paid for it by sending a
written explanation to the person you received the work from. If you
received the work on a physical medium, you must return the medium with
your written explanation. The person or entity that provided you with
the defective work may elect to provide a replacement copy in lieu of a
refund. If you received the work electronically, the person or entity
providing it to you may choose to give you a second opportunity to
receive the work electronically in lieu of a refund. If the second copy
is also defective, you may demand a refund in writing without further
opportunities to fix the problem.
1.F.4. Except for the limited right of replacement or refund set forth
in paragraph 1.F.3, this work is provided to you ''AS-IS'' WITH NO OTHER
WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
WARRANTIES OF MERCHANTIBILITY OR FITNESS FOR ANY PURPOSE.
1.F.5. Some states do not allow disclaimers of certain implied
warranties or the exclusion or limitation of certain types of damages.
If any disclaimer or limitation set forth in this agreement violates the
law of the state applicable to this agreement, the agreement shall be
interpreted to make the maximum disclaimer or limitation permitted by
the applicable state law. The invalidity or unenforceability of any
provision of this agreement shall not void the remaining provisions.
1.F.6. INDEMNITY - You agree to indemnify and hold the Foundation, the
trademark owner, any agent or employee of the Foundation, anyone
providing copies of Project Gutenberg-tm electronic works in accordance
with this agreement, and any volunteers associated with the production,
promotion and distribution of Project Gutenberg-tm electronic works,
harmless from all liability, costs and expenses, including legal fees,
that arise directly or indirectly from any of the following which you do
or cause to occur: (a) distribution of this or any Project Gutenberg-tm
work, (b) alteration, modification, or additions or deletions to any
Project Gutenberg-tm work, and (c) any Defect you cause.
Section 2. Information about the Mission of Project Gutenberg-tm
Project Gutenberg-tm is synonymous with the free distribution of
electronic works in formats readable by the widest variety of computers
including obsolete, old, middle-aged and new computers. It exists
because of the efforts of hundreds of volunteers and donations from
people in all walks of life.
Volunteers and financial support to provide volunteers with the
assistance they need, is critical to reaching Project Gutenberg-tm''s
goals and ensuring that the Project Gutenberg-tm collection will
remain freely available for generations to come. In 2001, the Project
Gutenberg Literary Archive Foundation was created to provide a secure
and permanent future for Project Gutenberg-tm and future generations.
To learn more about the Project Gutenberg Literary Archive Foundation
and how your efforts and donations can help, see Sections 3 and 4
and the Foundation web page at http://www.pglaf.org.
Section 3. Information about the Project Gutenberg Literary Archive
Foundation
The Project Gutenberg Literary Archive Foundation is a non profit
501(c)(3) educational corporation organized under the laws of the
state of Mississippi and granted tax exempt status by the Internal
Revenue Service. The Foundation''s EIN or federal tax identification
number is 64-6221541. Its 501(c)(3) letter is posted at
http://pglaf.org/fundraising. Contributions to the Project Gutenberg
Literary Archive Foundation are tax deductible to the full extent
permitted by U.S. federal laws and your state''s laws.
The Foundation''s principal office is located at 4557 Melan Dr. S.
Fairbanks, AK, 99712., but its volunteers and employees are scattered
throughout numerous locations. Its business office is located at
809 North 1500 West, Salt Lake City, UT 84116, (801) 596-1887, email
business@pglaf.org. Email contact links and up to date contact
information can be found at the Foundation''s web site and official
page at http://pglaf.org
For additional contact information:
Dr. Gregory B. Newby
Chief Executive and Director
gbnewby@pglaf.org
Section 4. Information about Donations to the Project Gutenberg
Literary Archive Foundation
Project Gutenberg-tm depends upon and cannot survive without wide
spread public support and donations to carry out its mission of
increasing the number of public domain and licensed works that can be
freely distributed in machine readable form accessible by the widest
array of equipment including outdated equipment. Many small donations
($1 to $5,000) are particularly important to maintaining tax exempt
status with the IRS.
The Foundation is committed to complying with the laws regulating
charities and charitable donations in all 50 states of the United
States. Compliance requirements are not uniform and it takes a
considerable effort, much paperwork and many fees to meet and keep up
with these requirements. We do not solicit donations in locations
where we have not received written confirmation of compliance. To
SEND DONATIONS or determine the status of compliance for any
particular state visit http://pglaf.org
While we cannot and do not solicit contributions from states where we
have not met the solicitation requirements, we know of no prohibition
against accepting unsolicited donations from donors in such states who
approach us with offers to donate.
International donations are gratefully accepted, but we cannot make
any statements concerning tax treatment of donations received from
outside the United States. U.S. laws alone swamp our small staff.
Please check the Project Gutenberg Web pages for current donation
methods and addresses. Donations are accepted in a number of other
ways including including checks, online payments and credit card
donations. To donate, please visit: http://pglaf.org/donate
Section 5. General Information About Project Gutenberg-tm electronic
works.
Professor Michael S. Hart is the originator of the Project Gutenberg-tm
concept of a library of electronic works that could be freely shared
with anyone. For thirty years, he produced and distributed Project
Gutenberg-tm eBooks with only a loose network of volunteer support.
Project Gutenberg-tm eBooks are often created from several printed
editions, all of which are confirmed as Public Domain in the U.S.
unless a copyright notice is included. Thus, we do not necessarily
keep eBooks in compliance with any particular paper edition.
Most people start at our Web site which has the main PG search facility:
http://www.gutenberg.net
This Web site includes information about Project Gutenberg-tm,
including how to make donations to the Project Gutenberg Literary
Archive Foundation, how to help produce our new eBooks, and how to
subscribe to our email newsletter to hear about new eBooks.','1c64fc4ab8ae9d792a961d1f83c5c544f9da7df4cd76822c2b891071cc033652','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbbb9700becc3da1b29534cc572891c1c3e93417b2dd049173df05530d2065ea',1996,'DE','Germany','transportation',11,'Railways:
total: 24.6 km
i]
broad gauge: 9.6 km 1.524-m gauge from
Gushgy (Turkmenistan) to Towraghondi: 15
km 1.524-m gauge from Terniz (Uzbekistan)
to Kheyrabad transshipment point on south
bank of Amu Darya
Highways:
total: 21.000 km
paved: 2.300 km
unpaved: 18.200 km (1984 est.)
Waterways: |.200 km: chiefly Amu Darya.
which handles vessels up to about 500 DWT
Pipelines: petroleum products—U zbekistan
to Bagram and Turkimenistan to Shindand:
natural gas 180 km
Ports: Kheyrabad. Shir Khan
Airports:
total: 35
with paved runways over 3,047 m3
with paved runways 2.438 to 3,047 m: 4
to
with paved runways 1,524 to 2,437 m:
with paved sunways under 914 m7
with unpaved runways 2,438 to 3,047 m. 3
with unpaved runways 1,524 to 2,437
with unpaved runways 914 to 1,523 m: 3
(1995 est.)
Heliports: 3 (1995 est.)
Railways:
total; 602 km (single track, note—some
sections abandoned, unusable. or operating at
reduced capacity)
narrow gauge: 602 km 0.914-m gauge
Highways:
total: 12.251 km
paved: 1.740 km (including 107 km of
expressways)
unpaved: 10.511 km (1992 est.)
Waterways: Rio Lempa partially navigable
Ports: Acajutla, Puerto Cutuco, La Libertad.
La Union, Puerto El Tnunto
Merchant marine: none
Airports:
wtal: 73
with paved runways over 3,047 m: |
with paved runways 1,524 to 2.437 me: \\
with paved runways 914 to 1,523 m: 2
with paved runways under 914 1m. 48
with unpaved runways 914 to 1,523 m: 21
(1995 est.)
Heliports: | (1995 est)
Railways:
total: 43.966 km
veindard gauge: 43.531 km 1.435-m, 40.355
kim are owned by Deutsche Bahn AG (DB):
17.015 km ot the DB system are electrified
and 16.941 kin are double- or more-tracked
389 km 1.000-m geuge (DB
operates 146 km of 1.000-m gauge). 7 km
Na ToON Viele
.900-m gauge: 39 km 0.750-m gauge
notes in addition to the DB system there are
Ss? privately-owned industrial or excursion
railways. ranging in route length from 2 km
to 632 km. with a total length of 3.465 km
(1995)
Highways:
total: 636.282 km
paved: S31.018 km Cinciuding 10.955 km of
CAPTeESsWays)
unpaved: 105.264 km (1991 est.)
/39
Waterways:
western: 5,222 km. of which almost 70% ave
usable by craft of 1.000-metric-ton capacity
or larger; major rivers include the Rhine and
Elbe: Kiel Canai ts an important connection
between the Baltic Sea and North Sea
eastern: 2.319 km (1988)
Pipelines: crude oil 3.644 km: petroleum
products 3,946 km: natural gas 97,564 km
(1988)
Ports: Berlin, Bonn, Brake, Bremen.
Bremerhaven, Cologne, Dresden, Duisburg.
Emden, Hamburg. Karlsruhe. Kiel, Lubeck.
Magdeburg. Mannheim, Rostock. Stuttgart
Merchant marine:
total: 452 ships (1.000 GRT or over) totaling
$.054.327 GR1/6.367.036 DWT
whips by tvpe: bulk 6. cargo 193, chemical
tanker 15, combination bulk 4. combination
ore/oil 5, container 166, liquefied gas tanker
12. multifunction large-load carner 6, oil
tanker 1], passenger 3. railcar carner 3.
refrigerated cargo 7. roll-on/roll-off cargo 14,
short-sea passenger 7 (1995 est.)
Airports:
total: 617
with paved runways over 3,047 me 13
with paved runways 2,438 to 3,047 m: 65
with paved runways 1,524 to 2,437 m: 67
with paved runways 914 to 1,523 m: 51
with paved runways under 914 m: 351
with unpaved runways over 3,047 m: 2
with unpaved runways 2,438 to 3,047 m: 6
with unpaved runways 1,524 to 2,437 m: 7
with unpaved runways 914 to 1,523 m- 55
(1995 est.)
Heliports: 55 (1995 est)','a6e865daeeb5de9ddef381118642b5c3df40bc8d0c1e65f6c2d81e905fb0b60b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a09166cb356a0c61a53623c07c699fe8ed696ad50d055ea70e1b10460c0cea0',1996,'AL','Albania','transportation',18,'Railways:
rial: 670 km
standard gauge: 670 km 1.435-m gauge
(1995)
Highways:
total: 18.450 km
paved: 17.450 «m
unpaved: 1 LWO km (1991 esi.)
Waterwa;s: 43 km plus Albanian sections
of Lake Scutan. Lake Ohrid. and Lake
Prespa (1990)
Pipelines: crude oi) 145 km: petroleum
products SS km. natural gas 64 km (1991)
Ports: Durres, Sarande Shengyin. Viore
Merchant marine:
total: V1 cargo ships (1.000 GRT or over)
totaling $2.967 GRT/76.887 DWT (1995
est.)
Airports:
total: VI
with paved runways 2.488 to 3,047 m: 3
with paved runways 914 to 1,523 m: 2
with unpaved runways over 3 047 m: 2
with unpaved runways 2,438 to 3,047 m: |
with unpaved runways 1,524 to 2.437 m: |
with unpaved runways 914 to 1,523 m: 2
(1994 est.)
Railways:
total: 4.772 km
standard gauge: 3.616 km | 435-m gauge
(301 km electrified: 215 km double track)
narrow gauge: 1.156 km 1.055-m gauge
Highways:
total: 95.576 km
paved: 63.080 km Gnciuding 400 km of
expressways)
unpaved: 32.496 km (1992 est)
Pipelines: crude oil 6.612 km: petroleum
products 298 km: natural ga. 2.948 km
Ports: Algiers. Annaba. Arzew. Bejaia. Ben
Sat. Dellys. Dyendyene. Ghazaouet. Jiyel.
Mostaganem, Oran. Skikda, Tenes
Merchant marine:
total: 77 shaps (1.000 GRT or over) totaling
916.701 GRT/1.086.324 DWT
ships by type: bulk 9. cargo 27. chemical
tanker 7. lnquetied gas tanker 10. oil tanker
5. roll-on/roll-off cargo 13. short-sea
passenger 5. specialized tanker 1 (1995 est)
Airports:
total: (9
with paved runways over 3.047 m. &
with paved runways 2.438 to 3.047 m: 24
with paved runways 1,524 to 2.437 m: V3
with paved runways 914 te 1,523 m4
with paved runways under 914m: 17
with unpaved runways 2.438 to 3.047 m: 3
with unpaved runways 1,524 to 2.437 m AY
with unpaved runways 914 to 1,523 m. 31
(1995 est.)
Heliports: | (1995 est)
Railways: 0 km
Highways:
total: 269 km
paved. 198 km
unpaved: 71 km (1991 est.)
Ports: none
Airports: none
West African Development Bank
(WADB)
note—also known as Banque Quest-
Africaine de Developpement (BOAD)
address—BOAD, BP 1172. 68 av de la
liberation, Lome, Togo
telephone—|228| 21 59 06, 21 42 44, 21
Ol 13
FAX—{228] 21 52 67, 21 72 69
established—\\4 November 1973
aim—A0 promote regional economic
development and integration
members—(7) Benin, Burkina Faso, Cote d''Ivoire. Mali, Niger. Senegal. Togo
West African Economic Community
(CEAO)
note—acronym from Communaute
Economique de l’Airigque de lQuest
established on 3 June 1972 to promote regional economic development: its members were
Benin, Burkina Faso, Cote d''Ivoire. Mali, Mauritania, Niger, Senegal: it was disbanded
in 1994
Western European Union (WEU)
address—Rue de la Regence 4, B-1000
Brussels, Belgium
telephone—{32] (2) 500 44 11
FAX—{32] (2) S11 35 19
established—23 October 1954
effective—6 May 1955
aim--to provide mutual defense and to
move toward political unification
members— 10) Belgium. France, Germany, Greece, Italy, Luxembourg, Netherlands. Portugal,
Spain, UK
associate members— 3) Iceland, Norway, Turkey
associate partners—(9) Bulgaria, Czech Republic, Estonia, Hungary, Latvia, Lithuania.
Poland, Romania, Slovakia
observers—(5) Austria. Denmark. Finland. Ireland. Sweden
World Bank
see International Bank for Reconstruction and Development (IBRD)
World Bank Group
includes International Bank for Reconstruction and Development (IBRD), International
Development Association (IDA), and international Finance Corporation (IFC)
World Confederation of Labor (WCL)
address—Rue de Treves 33. B-1040
Brussels. Belgium
telephone —{32]| (2) 230 62 95
FAX—{32] (2) 230 87 22
established—\\9 June 1920 as the
International Federation of Christian Trade
Unions (FCTU). renamed 4 October 1968
aim—A0 promote the trade union
movement
members—{99 national organizations) Algeria, Angola, Antigua and Barbuda, Argentina.
Aruba, Austria, Bangladesh, Belgium, Belize. Benin, Bolivia, Bonaire Island, Botswana,
Brazil, Burkina Faso, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile.
Colombia, Costa Rica, Cote d''Ivoire, Cuba, Curacao, Cyprus. Dominica, Dominican Republic.
Ecuador. El Salvador. France, French Guiana, Gabon, The Gambia, Ghana, Grenada.
Guadeloupe, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong. Indonesia, Iran, lialy.
Jamaica, Kenya, Lesotho, Liberia, Liechtenstein, Luxembourg. Madagascar, Malaysia, Mali.
Malta, Martinique, Mauritius, Mexico, Montserrat, Namibia, Netherlands, Nicaragua, Niger.
Nigeria, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal. Puerto Rico,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Martin, Saint Vincent and
the Grenadines, Senegal. Seychelles, Sierra Leone. Spain, Sri Lanka, Suriname, Switzerland,
Taiwan, Tanzania, Thailand. Togo, UK. US, Uruguay. Venezuela, Vietnam, Zaire. Zambia.','ee538a52b5a3bdd293b4b1c7da6bcd666d1b73271c630c289d0d71066cd3e8af','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec0314311cf3b141d55396193d9870ad54f818f277f1756ead33de3fc6580c54',1996,'BR','Brazil','transportation',27,'Railways:
total: 2.952 km (1995 est.): note—limited
trackage in use because of landmines still in
place from the civil war
narrow gauge: 2,798 km 1.067-m gauge:
154 km 0.600-m gauge
Highways:
total: 72,626 kin
paved: 18,157 km
unpaved: 54.469 km (1992 est.)
Waterways: |.295 km navigable
Pipelines: crude oil 179 km
Ports: Ambriz, Cabinda, Lobito, Luanda.
Malogo, Namibe, Porto Amboim, Soyo
Merchant marine:
total: 12 ships (1,000 GRT or over) totaling
63.776 GRT/99.863 DWT
ships by type: cargo 11, oil tanker 1 (1995
est.)
Airports:
total: 143
with paved runways over 3,047 m: 3
with paved runways 2,438 to 3,047 m: 8
with paved runways 1,524 to 2,437 m: 11
with paved runways 914 to 1,523 m: 4
with paved runways under 914 m: 40
with unpaved runways over 3,047 m: |
with unpaved runways 2,438 to 3,047 m: 4
with unpaved runways 1,524 to 2,437 m: 24
with unpaved runways 914 to 1,523 m: 48
(1995 est.)
links
domestic: limited system of wire. microwave
radio relay. and tropospheric scatter
imernational: satelite earth stations—2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AMI | |) FM | 3
shortwave 0
Radios: NA
Television broadcast stations: 6
Televisions: 50.000 (1993 est)
Defense
Branches: Army. Navy. Air and Air
Defense Forces. National Police Force
Manpower availability:
males age 15-49; 2.373.087
males fit for military service: 1.195.176
males reach military age (18) annually
106.456 (1996 est.)
Defense expenditures: exchange rate
conversion—S$1.1 billion. 31° of GDP
(1993)
cesipsinietbempucsneal
» THE VALLEY
Anguid''a','313c30234f637c55f129a00489f86cd23f143a478cb4b7c97489efb384a5ee54','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65446e1dc4e956f1e9f002af0094f9b03d2bde8c99738d53bd49ac736292e288',1996,'AQ','Antarctica','transportation',36,'Ports: none: offshore anchorage
Airports: SO landing facilities at different
locations operated by 16 national
governments party to the Treaty: one
additional air facility operated by
commercial (nongovernmental) tourist
organization. helicopter pads at 25 of these
locations, runways at 13 locations are gravel.
sea ice. glacier ice. or compacted snow
surface suitable for wheeled fixed-wing
aircraft, no paved runways: 12 locations
have snow-surface skiways limited to use by
ski-equipped planes—® runways/skiways
greater than 3.000 m.10 runways/skiways
1.000 to 3,000 m. 3 runways/skiways less
than 1.000 m. and 4 of unspecified or
variable length: airports generally subject to
severe restrictions and limitations resulting
AS
from extreme seasonal and geographic
conditions: airports do not meet ICAO
Standards: advance approval trom the
respective gov emmental or non-
governmental operating organization required
for landing (1995 est.)
Railways:
total: 6,782 km
broad gauge: 3,743 km 1.676-m gauge
(1,653 km electrified)
narrow gauge: 116 km 1.067-m gauge:
2,923 km 1.000-m gauge (40 km electrified)
(1995)
Highways:
total: 79,593 km
paved: 10.984 km
unpaved: 68,609 km (1991 est.)
Waterways: 725 km
Pipelines: crude oi! 755 km: petroleum
products 785 km: natural gas 320 km
Ports: Antofagasta, Arica, Chanarol,
Coquimbo, Iquique, Puerto Montt, Punta
Arenas, San Antonio, San Vicente.
Talcahuano, Valparaiso
Merchant marine:
total: 37 ships (1.000 GRT or over) totai:ng
§29.512 GRT/925.364 DWT
ships by tvpe: bulk 11, cargo 8. chemical
tanker 4, combination ore/oil 2. container 1.
liquefied gas tanker 2. oil tanker 4, rotl-on/
roll-off cargo 3, vehicle carmer 2 (1995 est.)
Airports:
total: 344
with paved runways over 3,047 m: 5
with paved runways 2.438 to 3,047 m: 5
with paved runways 1,524 to 2,437 m: 17
with paved runways 914 to 1,523 m: 16
with paved runways under 914 m: 220
with unpaved runways 2,438 to 3,047 m: 3
with unpaved runways 1,524 to 2,437 m. 10
with unpaved runways 914 to 1,523 m: 68
(1995 est.)','c5114feadba1a7f9d769a5efd9d3c26a7eec651993541560f9fbae78e60dce8f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64b55d82f97f4921c34cf8367b18c9245b00f92416cfad8e39f77eeb0dc82fcc',1996,'AG','Antigua and Barbuda','transportation',43,'Railways:
rwital: 77 km
radon
le km
(.610-m gauge (used almost exclusively tor
gauge. 64 kin 0.760-m gauge
handling sugarcane)
Highways:
total 240; km
paved: NA km
ed: NA km
Ports: Saint John’s
Merchant marine:
total: 367 ships (1.000 GRT or over) totaling
1.572.063 GRT/2.147,.243 DWT
bulk 6. cargo 247. chemical
WPA
ships by type
tanker 6. combination bulk |. container 72.
AT
liquefied gas tanker 2. oil tanker 3.
retngerated cargo 14. roll-on/roll-off cargo
16
note: a tlag of convenience registry
Germany owns !|2 ships, Slovenia 3. Croatia
2. Cyprus |. and US 1.1995 est)
Airports:
total: %
with paved runways 2.438 to 3,047 m: |
with paved runways under 914 m: 2 (1995
es.)
Ports: Churchill (Canada). Murmansk
(Russia). Prudhoe Bay (US
Transportation note: sparse network of ay
ocean, nver. and land routes: the Northwest
Passage (North Ameneca) and Northen Seu
Route (Eurasia) are important seasonal
WaleTWwayvs','25368b4327fe825c38d097af8f29c28b5cfdccd802448601ed72ba7056ebcfb1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7763d7400f11ee59b4ba6d08ffe4ee56444ff248ea7486529f21684d79a5a7d',1996,'NL','Netherlands','transportation',47,'Defense
Branches: Argentine Army. Navy of the
Railways:
Wal 7 9NlO km
broad gauge 24.124 kin 1.676-m gauge Argentine Republic. Argentine Air Force.
+. Kili clecinitica National Gendarmerie. Argentine Naval
i gauge 2.765 km 1.435-m gauge Prefecture (Coast Guard only), National
we TLO2T km 1.000-m gauge Acronautical Police Force
a ectintied)
Manpower availability:
ighways: : 7
High is pale 4 ue is 4y s. O74
215.578 km ;
males fit for military service: 7.063.304
‘ fi 44h An ;
males reach military age (20) annualls
any 4 1s] ‘Ah Mm
310.107 (1996 est)
Defease expenditures: exchange rate
conversion—S84.7 billion, 1.56 of GDP
Waterways: |) .000 km navigable
Pipelines: crude on! 4.090 kim. petroleum
products 2.900 km: natural gas ¥.918 km .
Ports: Bahia Blanca. Buenos Aires (1995)
Commodore Rivadavia, Concepcion del
Uruguay. La Plata. Mar del Plata. Necochea
Rio Gallegos. Rosano. Santa Fe, Ushuaia
Merchant marine:
total: 37 ships (1.000 GR or over) totaling
¥i3 J48 GRT/SSS 864 DWI
viips by types bulk 1. cargo TL. chemical
tanker |. container 4. onl tanker 14. ratheat
carer |. retmverated cargo 5, roll-on/roll-ott
carga IYYS est
\\irports:
5s 4
ronuwadys over 2047 m §
mwa > 438 to 8047 m OS
runwavs 1524 to 2.437 m: 54
ed runways Yid to 1523 m 46
runways under Yld me STI
rapa s omer {04/7 m |
runways 2438 to 3.047 m: 2
1 824 to 2.4387 m Of
<V¥I/4 to 1 SO8 m: 549
raps
Railways:
total: 1,944 km
broad gauge: 1.944 km 1.600-m gauge (37
km electrified: 485 km double track) (1995)
Highways:
total: 92.327 km
paved: 86.787 km (including 32 km of
CAPTeEssWays)
unpaved: 5.540 km (1992 est
Waterways: limited tor commerciai traffic
Pipelines: natural gas 225 km
Ports: Arklow. Cork. Drogheda. Dublin
Foynes. Galway. Limenck. New Ross
Watertord
Merchant marine:
total: 42 ships (1.000 GRT or over) totaling
129.027 GRT/1558.371 DWI
shins by wpe: bulk 4. cargo 27. chemical
tanker 1. container 3. or) tanker 2. shoit
passenger 3. specialized tanker 2 (1995 ext
Airports:
total; 40
with paved runwavs over 3,047 m4
with paved runways 2.438 to 3.047 m. |
with paved runways 1,824 to 2.437 9
with paved runways Yl4 to 1 S23
with paved runways under 414 m: 29
with unpaved runways 914 to 1523 4
(}995 est.)
Railways:
hatal: S&S km
narres, gantge: SS km 1 OWO-in gauge
YY4»
Highways:
tral: 34.750 km
paved S382 tan
unpaved 29.398 kim (1991 est)
Waterways: of local importance onl,
isolated streams and small portions of Canal
des Pangalanes
Ports: Antsiranana. Antsohimbondrona.
Mahajanga. Toamasina. Toliara
Mercheut marine:
tetas TL ships (1.000 GR or over) totaling
22.132 GRT/31.261 DWT
ships by type: cargo S. chemical tankes
liquefied gas tanker |}. ol tanker 2. roll-on
roll-off cargo 2 (1995 est.)
Airports:
total: 10S
with raved runways over 304-4
with paved runways 2.438 to 3.047 9
with paved runways 1.524 to 2.487 m3
with paved runways 914 to 1,523 m
with paved runways under 914m 3
with unpaved runwavs 1.524 to 2.487 m 2
293
Madagascar (continued)
_ s<
iifi wnparéa ridiwMay YJd4 le / a Pe a
| aus esl ;
‘ ommunications
Telephones: 96.000 (1988 est)
lelephone system: s\\ sicn ihe average
flue Ate
vial Cables
} PoOspichic
cable to Bahrau
In t (indian
Atlantic Ocean
K
Radio broadcas stations: \\VI oF M
Radios: > 4° Wy? est
lelevision broadcast stations: | (repeaters
WM,
lelevisions: >f) ON >
Defense
Branches: Popular Armed Forces (includes
Intervention Forces. Development Forces
Actonasal Forces—includes Navy and Aw
Force). Gendarmene. Presidential Security
Regiment
Manpower availability:
males ave 15-49) XS AOROL2
mates fit tor military service: 1.843.732
males reach milttary age (20) annualls
132.146 (1996 est)
Defense expenditures: exchange rate
conversion-—S$S29 million. 1.06 of GDP
(1994)','03a2058ecfafa0d760c1a21d64b3ffb587ccb5a69006c49a7b1a422e3878fd8a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8c9560c5e8ccff88069dd550594b6e9ce4c5e167b7046eec09e061f84e8f015',1996,'AM','Armenia','transportation',52,'Railways:
total: 825 km in common carrier service:
does not include industrial lines
broad gauge: 825 km 1.520-m gauge (1992)
Highways:
total: 11.300 km
paved: 10.500 km (including graveled)
unpaved: SOO km (1990 est.)
Waterways: NA km
Pipelines: natural gas 900 km (1991)
Ports: none
Airports:
total: 11
with paved runways over 3,047 m: 2
with paved runways 1,524 to 2,437 m: |
with paved runways 914 to 1,523 m: 2
with unpaved runways 1,524 to 2,437 m: 2
with unpaved runways 914 to 1,523 m: 3
with unpaved runways under 914 m: 1 (1994
est.)','03b4474f09c5d56131deaca0efdb00e7863c391dec78c39c887dc46f46ba017d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ba84f626fe631a408f710321b78423c1cf0f972e185e6c5ff272e7682d86d17',1996,'AU','Australia','transportation',61,'Ports: none: offshore anchorage only
Defense
Defense note: defense is the responsibility
of Australia: periodic visits by the Royal
Australian Navy and Royal Australian Air
Force
Atlantic Ocean
Ports: Alexandra (Egypt). Algiers (Algeria).
Antwerp (Belgium), Barcelona (Spain).
Buenos Aires (Argentina), Casablanca
27
Atlantic Ocean (continued)
(Morocco), Colon (Panama). Copenhagen
(Denmark). Dakar (Senegal). Gdansk
(Poland). Hamburg (Germany). Helsink:
Finfand). Las Palmas (Canary Islands.
Spain). Le Havre (France), Lisbon
rlugal), London (UK). Marseille (France).
Montevideo (Uruguay), Montreal (Canada).
Naples italy). New Orleans (US). New York
US). Oran (Algeria). Cslo (Norway).
Piraeus (Greece). Rie de Janeiro (Brazil).
Rot adam (Netherlands), Saint Petersburg
‘Russi Stock Im Sweden)
Transportation note: Kie! Canal and Saint
i ; Wat ore (Ww
‘A nee Yes
sie Ls
)importent
Railways
} lectriftted: 172
1-1) Vduey
‘ All +5 )-ih Vauve
p ify Vue
Highwass:
. ling 1.200 km of
iy
uns fy f i KY est
Waterways: S368 kim. mainly by small
shallow-dratt cratt
Pipelines: cruck S00) km. petroleum
produ 1. MO an tural v. S O00 km
Ports: Adelaide. Brisbane. Cairns. Darwin
Devonport, Fremantle. Geelong. Hobart
(Tasmania). Launceton (Tasmania). Mackay
Melbourne. Sydnes. Townsville
*”
Merchant marine:
total: 76 ships (1.000 GRT or over) totaling
2.547.869 GRT/3.679.534 DWT
viips by npe> bulk 30. cargo 4. chemical
tanker 3. combination bulk |. contamer 6
liquetied gas tanker 6. oil tanker 1S. roll-on
short-sea passenger 1 (1995
.
\\irports:
a a |
Se
’ MING (Mays er *04, mm 9
vi ri j I 43N to JOLT }3
An yuive TAY 132490 2437 mm 106
hh paved runways under Vl4m-: 30
, , ” . i)
{ ’ Pidsived , / S74 ft 4s vi onan
j ,
mynived 4 avs Y1i4 /O25 m- 146
Railways: 24 km to serve phosphate mines
Highways:
total: NA km
paved: NA km
unpaved’ NA km
Ports: Flying Fish Cove
Merchant marine: none
Airports:
imal: |
with paved runways 1,524 to 2.437 m: \\
(1995 est.)
Ports: none: offshore anchorage only
Defense
Defense note: defense is the responsibility
of Australia: visited regularly by the Royal
Australian Navy; Australia has control over
the activities of visitors
Ports: none: offshore anchorage only
Defense
Defense note: defense is the responsibility
of Australia
oVv7
Holy See (Vatican City)
4 Valine" —e |
cty Vuseums 1
wail /
j
a
f Sart Peter''s
> Baseca
nw s Sant Peters |
}
A are
‘N —N\\
> on ''','87724e83c76dd32b7f2113dd9872aadba3f5f1b4cd6d80e776a211a4cccdeb2a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cd9caeef83d78863368802d9639aac8a19d49624e47c01364f02b76ce417ca5',1996,'AT','Austria','transportation',71,'Railways:
“f + *
ndard gauge 5.269 km i 445-m gauge
"Hs kim electntied)
me 35S km | OOO-m and 0 760
we SO Akin eclectritied yy")
Highways:
LOS OOO km
ed 22.000 km Gncluding |S00 km of
.my wauvs
°
mpaved S6000 km (1992 est)
Waterways: 446 km
riy elimes: crude oil 4554 im petroleum
roducts 17!) km: natural gus 2.611 km
Ports: Linz. Vienna
Vierchant marine:
LOOO GRIT or over) totaling
SS.617 GRT/122.475 DWT
vps by type bulk |. cargo 23. combination
ral. 29 ships
bulk 2. contamer |. retrigerated cargo 2
1yys esl
Airports:
total: SS
with paved runways over 3,047 m: |
with paved runways 2.438 to 3,047 m: 5
with paved runways 1,524 to 2.437 m: |
with paved runways 914 to 1,523 m: 3
with paved runways under 9i4 m: 41
with unpaved runways 914 to 1,523 m: 4
{ }Y9S est}
Heliports: | (1995 est)','5cfd4ac2febfe5f6198c35c65b51c599befe0d7c00a58de401197f5fe6c8d93d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f25d1f0629765d36b9e932fc8f3f132f3d69ae5890dff802b9f6d101bb4e07b',1996,'AZ','Azerbaijan','transportation',74,'Railways:
total; 2.125 km in common carrier service:
does not include industrial lines
broad gauge: 2.125 km 1.520-m gauge
(1.278 km electrified) (1993)
Highways:
total: 36.700 km
paved: 31,800 km (includes graveled)
unpaved: 4.900 km (1990 est.)
Pipelines: crude oil 1.130 km: petroleum
products 630 km: natural gas 1.240 km
Ports: Baku (Baki)
Airports:
total: 69
with paved runways over 3,047 m: 2
with paved runways 2.438 to 3,047 m: 6
with paved cunwavs 1,524 to 2.43/ m: 17
with paved runways 914 to 1,523 m: 3
with paved runways under 914m: |
with unpaved runways 914 to 1,523 m
with unpaved runways under 914 m: 33
(1994 est)
Railways: 0 km
Highways:
total: 2.386 km
paved: 1342 km
unpaved: 1044 km (1986 est.)
Ports: Freeport. Matthew Town, Nassau
Merchant marine:
total: 956 ships (1,000 GRT or over) totaling
22.592.285 GRT/35.765.965 DWT
ships by type: bulk 176, cargo 182. chemical
tanker 43, combination bulk 9, combination
ore/oil 19, contamer 53, liquefied gas tanker
0). oil tanker 180. passenger 53. refrigerated
cargo 147, roll-on/roll-off cargo 47, short-sea
passenger 13. vehicle camer 14
note. a lag of convemence registry, includes
ships from 48 countnes among which are
Norway 15S. Greece 124, US 84, Denmark
63. Netherlands 44. Sweden 36, Finland 34,
France 29. Japan 29. and Belgium 24 (1995
es.)
Airports:
ral: SS
with paved runways over 3,047 m: 2
with naved runways 2.438 to 3,047 m: |
with paved runways 1,524 to 2,437 m: 16
with paved runways 914 to 1.523 m: 11
with paved runways under 914 m: 17
with unpaved runways 914 to 1,523 m: 8
(1995 est.)
Cc scati
Telephones: 119.000 (1987 est)
Telephone system:
domestic: totally automatic system: highly
developed
international: troposphenc scatier and
submarine cable to Florida: 3 coaxial
submarine cables. satellite earth station—|
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3. FM 2.
shortwave 0
Radius: 200.000 (1993 est)
Television broadcast stations: | (1986 est.)
Televisions: 60.000 (1993 est.)
Defense
Branches: Royal Bahamas Defense Force
(Coast Guard only). Royal Bahamas Police
Force
Manpower availability:
males awe 15-49: NA
males fit for military service: NA
Defense expenditures: exchange rate
conversion—$20 million, 3.8% of GDP
(FY9S/96)
''
A Mares,
CANAMA
NOd< a Vit Sarre
ats
S* a
Awe,
wr av ef
oe vane','b7af13050c7b79993df7c9234d7fab446f85ea9f86ffe5d4be58403e247c8bd9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b20a442668bf17b9efe335e7c9fe14dd4a31aa492e6626b5c062f6aa7734c082',1996,'MG','Madagascar','transportation',94,'Ports: none: offshore anchorage only
Defense
Defense note: defense ts the responsibility
of France
Ports: |
Virports:
Defense
Defense note:
'' } ’
18S
[94
Railways:
tal? NA km. short line going to a jetty
Ports: none. offshore anchorage only
\\irports:
h unpaved runways Yl4 to 1823 om
US ev
Defense
the re sponsibsl 1\\
Defense note: delense |
brace
Kazakstan
''
Railways:
total: 13.841 km in common camer service:
does not include industrial lines
broad gauge: 13.841 km 1.520-m gauge
(3.299 km electrified) (1992)
Highways:
total: 87.873 km public roads
paved: 82.568 km
unpaved: 5.305 km (1994)
Waterways: 4.002 km on the Syrdarya
River and Ertis River
Pipelines: crude oil 2.850 km: refined
products 1.500 km. natural gas 3.480 km
(1992)
Ports: Agtau (Shevchenko). Atyrau
(Gur yev », Oskemen (Ust-Kamenogorsh)
Paviodar. Semey (Semipalatinsk)
Airports:
total: 352
with paved runways over 3.047 m- 7
with paved runways 2.438 to 3.047 m: 23
with paved runways 1.524 to 2.437 m 11
with paved runways 914 to 1,523 m- §
with paved runways under 914m. 9
with unpaved runways over 3.047 m9
with unpaved runways 2.438 to 3.047 m: &
with unpaved runways 1,524 to 2.437 m: 28
with unpaved runways 914 to 1.523 m- 65
with unpaved runways under 914 m- 19)
(1994 est)
Railways:
* - =
marron = CaN O52 an (Ha)
Highways:
‘/ puite« a
Vaterways: Part «i Lake Victoria system is
“within boundar it Kenva
Pipelines: petroicum products 483 kn
Ports: Kivu I
Merchant marine:
Mlomb isa
+
mal: 2 ships (1 O00 GRT or over) totaling
1883 GRIT/6.255 DWI
erage 77 | tanker mil on/roll off |
(1199S est
\\irports:
al hwy
/ six rw ‘ ‘ ou (iJ ” +
} d ruvwarvs 2.488 fid ww
P rss ‘ j < J ’ J ‘ 5
cd renways Vie >im 2)
‘ iu ‘ ‘ wihkdiel Widow fy
‘ ( rary ‘ +35 tor 3047 m |
pane s J S24 43> m 12
/ ‘ 5 VId ty 15° lw us
~~ ‘
Ports: wone. offshore anchorage only
\\irports: lacowun was used a | i''w
latwon between Hawa 1 A S
mw P American Awa
) BULL
Defense
Defense mote
a .
»
‘ «
t
Rar ome
~~
a
.
a
gaam - om
- - a” «
a “a Meier Chernter ae
Raane
oniedl *. “eee
ee ad .
e * $ an an
Sti .
™
”
ann ‘
* *
as
t
Railways:
total: AYIS km
vandard gauge: 4.250 km 1.435-m gauge
(3.397 km electntied: 159 km double track)
narrow gauge. 665 km 0.762-m guuge
1YRY)
Highways:
tal WO.000 km
ed 4.500 km
a
25.500 km
253 km: mostly
Waterways:
Mahl cralt Onis
Pipelines: cruck
Ports: Ch oner
Hamhung). Kin
Merchant marine:
tan
\\irports','421a345c97f9a6a023b5baff1140aedec0e72c17e8fdfbc4e30973e0f40255ec','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d8a358f363db5dd33f69c800c9b75b44010a0ea1fd7efccd1ac5b4935d42a32',1996,'BY','Belarus','transportation',95,'aA LATVIA ‘
moe S
SF aon UA“ .
/ ash.
THUANIA Ss RUSSIA
a — v tsyeos« ;
f f
a. SSA j ’
a °
\\
—/ @ MINSK a i
4ro0na vareyow <
rs anes , Oarane ~y ‘ a ys"
ger ‘
{ we LR
yo . yy
} rr —, "ha j
~~ MmpA. -” ‘
\\ ~* }
5 K RA ‘
F al
LZ
, - .
Railways:
hnial: SASS km
broad gauge: SASS km 1.520-m gauge (873
km electrified) (1993)
Highways:
total: 92.200 km
paved: 61.000 km tincluding graveled)
unpaved: 31.200 km (1994 est)
Waterways: NA km. note—Belarus has
exvfensive and widely used canal and nvet
“Vstems
Pipelines: crude oil 1.470 km. refined
products 1.100 km: natural gas 1.980 km
(199);
Ports: Marvy:
Merchant marine:
note. Clams Ste of former Soviet feet (1995
est.)
Airports:
nal: Lis
wath paved runways over 3.047 m 2
43N to 8047 m 18
, 5 _”
paved ranwavs 1.524 to 2.437 m: §
nih paved runways 2
nu
nuh
paved runways under 914m: 11
<04/7 mm |
unpaved runways 2.4388 to 3.047 m6
182
unpaved runways 914 to
with aved runwave over
Mie
, _-
> 4t/m 4
j 4?
with unpaved runways 40
with
with unpaved runways under 914 m- 62
(1994 est)
telephone—{7| (172) 293434, 293517
FAX—{7| (172) 261894, 261944
established—%& December 1991
21 December 199!
aur—Ao coordinate intercommonwealth
relations and to provide a mechanism for
the orderly dissolution of the USSR
eflectve—
Commonwealth of Nations
members—( 12) Armenia, Azerbaijan, Belarus, Georgia, Kazakstan, Kyrgyzstan, Moldova,
Russia, Taykistan, Turkmenistan, Ukraine, Uzbekistan
see Commonwealth (C)
Communaute Economiqu. de I Afrique
de TOuest (CEAO)
see West Afacan Econom Communny (CEAO)
Communaute Economique des Etats de
l''Afrique Centrale (CEEAC)
Communaute Economique des Pays es
Grands Lacs (CEPGL)
communist countries
see Looncmc Community of Central African States (CEEAC)
see Econonne Community of the Great Lakes Countnes (CEPOL |
tradenally the Marxist-Lenimist states with authortanan governments zad Command
econome: *ased on the Soviet model, most of the orginal and th. saccessor states arc
no longer. mmuntst, see centrally planned economies
Cenference on Security and Cooperation
in Europe (CSCE)
see Organization for Security and Cooperation in Europe (OSCE)
Conseil Evropeen pour la Recherche
Nucleaire (CERN)
see European Organization for Nuclear Research (CERN)
Contadora Group (CG)
was established 5 January 1983 (on the Panamanian island of Contadora) to reduce tension:
and conflicts in Central America; has evolved into the Rio Group (RG); members included
Colombia, Mexico, Panama, Venezuela
Cooperation Council for the Arab States
of the Gulf
see Gulf Cooperation Council (GCC)
Coordinating Committee on Expert
Controls (COCOM)
established in 1949 to control the export of strategic products and technical data from member
countnes to proscribed destinations; members were Australia, Belgium, Canada, Denmark,
France, Germany, Greece, Italy, Japan, Luxembourg, Netherlands, Norway, Portugal, Spain.
Turkey, UK, US; was abolished 31 March 1994; COCOM members are working on a new
orgamization with expanded membership which focuses on nonproliferation export controls
as opposed to East-West control of advanced technology
Council for Mutual Economic Assistance
(CEMA)
note—aiso known as CMEA or Comecon
established 25 January 1949 to promote the development of socialist economies and was
abolished | January 1991; members included Afghanistan (observer), Albania (had not
participated since 1961 break with USSR), Angola (observer), Bulgaria, Cuba,
Czechoslovakia, Ethiopia (observer), GDR, Hungary, Laos (observer), Mongolia, Mozambique
(observer), Nicaragua (observer), Poland, Romania, USSR, Vieinam, Yemen (observer),
Yugoslavia (associate)
Council of Arab Economic Unity
(CAEL)
address—--BP 925100. Amman, Jordan
telephone—|9%62| (6) 66 43 26, 66 43 27,
66 43 28
FAX—(962| (6) 66 33 43
established—-3 June 1957
effective—M May 1964
aim-—-A0 promote economic integration
among Arab nations
members—( 11 plus the Palestine Liberation Organization) Egypt, Iraq, Jordan, Kuwait, Libya,
Mauritania, Somalia, Sudan, Syria, UAE, Yemen, Palestine Liberation Organization
Council of Europe (CE)
address—Palas de Europe. t 67075
Strasbourg CEDEX. France
telephone—| 33) 88 41 20 00
FAX—[33] BS 41 27 BL. SS 41 27 BQ
S May 1949
+ August 1949
‘ stablivhe d
etlective
am—1o promote increased unity and
quality of life im Europe
members—( 39) Albama, Andorra, Austra, Belgium, Buigana, Cyprus, Czech Republic.
Denmark, Estonia, Finiand, France. Germany, Greece, Hungary. Iceland. Ireland. italy, Latvia.
Liechtenstein, Lithuania, Luxembourg. The Former Yugoslav Republic of Macedonia, Malta
Moldova, Netherlands, Norway, Poland, Portugal, Romania, Russia, San Marino, Slovakia.
Slovenia. Spain, Sweden, Switzerland, Turkey, Ukraine, UK
guests—(4) Belarus, Bosma and Herzegovina, Croatia
observer —A1) Israel
Council of the Baltic Sea States (CBSS)
established —S March 1992
aim —1to promote cooperation among the
Balt Sea states in the areas of and to
new democratic institutions, economic
development, humanitanan aid, energy and
the environment. cultural programs and
education. and transportation and
communication
(10) Denmark, Estoma, Finland, Germany. Latvia. Lithuama. Norway. Poland.
Russia. Sweden
members
Council of the Entente (Entente)
address—BP 3734, Abidjan 01, Cote
d''Ivoire
telephone—{ 225] 33 10 O01, 33 28 35
FAX—{225] 33 11 49
established—29 May 1959
aim—A0 promote economic, social, and
political coordination
members—45) Benin, Burkina Faso, Cote d''Ivoire. Niger, Togo
Customs Cooperation Council (CCC)
address—Rue de l''industrie 26-38, B-104u
Brussels, Belgium
telephone—{ 32] (2) S08 42 11
FAX—{32] (2) SO8 42 40
established—15 December 1950
aim—A0 promote intemationa! cooperation
in customs matters
members—{ 137) Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bangladesh. Belarus, Belgium, Bermuda, Botswana, Brazil.
Bulgaria, Burkina Faso, Burma, Burundi, Cameroon, Canada. Cape Verde. Central African
Republic, Chile, China, Colombia, Comoros, Congo, Cote d''ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Egypt, Estonia, Ethiopia, Finland, France, Gebon, The Gambia,
Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guyana, Haiti, Hong Kong, Hungary.
iceland, India, Indonesia, Iran, Iraq. Ireland, Israel, Italy. Jamaica, Japan, Jordan, Kazakstan.
Kenya, South Korea, Kuwait, Latvia, Lebanon, Lesotho, Liberia, Libya. Lithwania,
Luxembourg, Macau, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi.
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico. Moldova, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ. Niger. Nigena, Norway. Pakistan, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal.
Sierra Leone. Singapore, Slovakia, Slovenia, South Africa, Spain, Sn Lanka, Sudan.
Swaziland, Sweden, Switzerland, Syma, Tanzama, Thailand, Togo, Trinidad and Tobago.
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay. Uzbekistan,
Vietnam, Yemen, Zaire, Zambia, Zimbabwe
developed countries (DCs)
the top group in the nerarchy of developed countries (DCs), former USSR/Eastern Europe
(former USSR/EE). and less developed countries (LDCs): includes the market-onented
economies of the mainly democratic nations un the Organization for Economic Cooperation
and Development (OECD). Bermuda. Israel. South Afnca, and the European ministates. also
known as the First World, high-income countnes. the North, industrial countnes: generally
have a per capita GDP in excess of $10,000 although four OECD countnes and South
Afnca have figures well under $10,000 and two of the excluded OPEC countnes have
figures of more than $10,000), the 35 DCs are: Andorra, Australia. Austria, Belgium.
Bermuda, Canada. Denmark. Farce Islands. Finland. France. Germany. Greece. Holy See.
Iceland, Ireland. Israel. Haly. Japan. Liechienstem. Luxembourg. Malta. Mexico, Monaco,
Netherlands, NZ. Norway. Portugal, San Marino, South Afnca, Spain, Sweden, Switzerland,
Turkey. UK. US
developing countries
an imprecise term tor the less developed countnes with growing coonomies. see less
developed countnes (LDCs)
East African Development Bank (EADB)
address-—4 Nile Avenue, P.O. Box 7128.
Kampala, Uganda
telephone —| 256} (41) 230021, 230825
FAX—{256] (41) 259763
established—*% June 1967
eflectve—\\ December 1967
aim—Ao promote economic development
members—4 +) Kenya. Tanzama. Uganda
na
4
Economic and Social Commission for members—(49) Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh, Bhutan, Brunei,
Asia and the Pacific (ESCAP) Burma, Cambodia, China, Fiji, France, India, Indonesia, Iran, Japan, Kazakstan, Kiribati,
dress—-Umited Nations Building, North Korea, South Korea, Kyrgyzstan, Laos, Malaysia, Maldives, Marshall Islands, Federated
Rajadamnern Avenue, Bangkok 10200, States of Micronesia, Mongolia, Nauru, Nepal, Netherlands, NZ, Pakistan, Papua New Guinea,
hailand Philippines, Russia, Singapore, Solomon Islands, Sri Lanka, Tajikistan, Thailand, Tonga,
lephone —{66] (2) 2829161 through Turkmenistan, Tuvalu, UK, US, Uzbekistan, Vanuatu, Vietnam, Western Samoa
2829200. 2829381 through 2829389 associate members— 10) American Samoa, Cook Islands, French Polynesia, Guam, Hong
FAX —l66] (2) 2811743 : Kong, Macau, New Caledonia, Niue, Northern Mariana Islands, Palau
established—28 March 1947 as Economic
Commission tor Asia and the Far East
(ECAFE)
avu—to carryout the commitment of the
Economic and Social Council of the UN
) promote economic development
Economic and Social Commission for members—(12 plus the Palestine Liberation Organization) Bahrain, Egypt, Iraq, Jordan,
Western Asia (ESCWA) Kuwait, Lebanon, Oman, Qatar, Saudi Arabia, Syria, UAE, Yemen, Palestine Liberation
iddress—(temporary) P.O. Box 927115, Organization
\\mman, Jordan
telephone—-{962} (6) 694351
FAX-—-|962} (6) 694981, 694982
established—9 August 1973 as Economic :
Commission tor Western Asia (ECWA)
aim—io promote economic development as
a regional commission for the UN''s
Economic and Social Council
Economic and Social Council (ECOSOC) members—(54) selected on a rotating basis from all regions
address—United Nations, New York, NY
10017, USA
telephone—{ 1] (212) 963 1234
FAX—!1] (212) 758 2718
estublished—-26 June 1945
effective—2+ October 1945
aim—to coerdinate the economic and
social work ot the UN; includes five
regional commissions (see Economic
Commuissien for Africa, Economic
Commission for Europe, Economic
Commission for Latin America and the
Caribbean. Economic and Social
Commission for Asia and the Pacific,
Economic and Social Commission for
Western Asia) and 10 functional
commissions (see Commission for Social
Development, Commission on Human
Rights, Commission on Narcotic Drugs,
Commission on the Status of Women,
Commission on Population and
Development, Statistical Commission,
Commission on Science and Technology
for Development, Commission on
Sustainable Development, and Commission
on Crme Prevention and Criminal Justice)
558
Economic Commission for Africa (ECA)
address—P.O. Box 3001-3005, Addis
Ababa, Ethiopia
telephone—{251} (1) 51 72 00
FAX—(251} (1) 51 44 16
established—29 April 1958
aim—to promote economic development as
a regional commission of the UN’s
Economic and Social Council
members—(53) Aigeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape
Verde, Central African Republic, Chad, Comoros, Congo, Cote d’Ivoire, Djibouti, Egypt,
Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau,
Kenya, Lesotho, Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco,
Mozambique, Namibia, Niger, Nigeria, Rwanda, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Somalia, South Africa, Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda,
Zaire, Zambia, Zimbabwe
associate members—(2) France, UK
Economic Commission for Asia and the
Far East (ECAFE)
see Economic and Social Commission for Asia and the Pacific (ESCAP)
Economic Commission for Europe (ECE)
address—Palais des Nations, CH-1211
Geneva 10, Switzerland
telephone—{41] (22) 917 1234, 907 2893
FAX—[41] (22) 917 0036
established—28 March 1947
aim—to promote economic development as
a regional commission of the UN’s
Economic and Social Council
members—(55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosria
and Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia.
Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Israel, Italy,
Kazakstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Malta, Moldova, Monaco, Netherlands, Norway, Poland, Portugal.
Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan,
Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan, Yugoslavia
Economic Commission for Latin
America (ECLA)
see Economic Commission for Latin America and the Caribbean (ECLAC)
Economic Commission for Latin
America and the Caribbean (ECLAC)
address—Edificio Naciones Unidas,
Avenida Dag Hammarskjold, Casilla 179
D, Santiago, Chile
telephone—{56} (2) 2102000
FAX—{56] (2) 2080252, 2081946
established—25 February 1948 as
Economic Commission for Latin America
(ECLA)
aim—to promote economic development as
a regional commission of the UN’s
Economic and Social Council
members—(41) Antigua and Barbuda. Argentina, The Bahamas, Barbados, Belize, Bolivia.
Brazil, Canada, Chile, Colombia, Costa Rica, Cuba, Dominica, Dominican Republic. Ecuador,
El Salvador, France, Grenada, Guatemala, Guyana, Haiti, Honduras, italy, Jamaica, Mexico.
Netherlands, Nicaragua, Panama, Paraguay, Peru, Portugal, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Spain, Suriname, Trinidad and Tobago, UK, US, Uruguay.
Venezuela
associate members—{6) Aruba, British Virgin Islands, Montserrat, Netherlands Antilles,
Puerto Rico, Virgin Islands
Economic Commission for Western Asia
(ECWA)
see Economic and Social Commission for Western Asia (ESCWA)
Economic Community of Central
African States (CEEAC)
note—acronym from Communaute
Economique des Etats de |’ Afrique
Centrale
address—CEEAC, BP 2112, Libreville,','3dfc604d0b951d7d3793b6cdeda0963d8fb83ee4c92ddaef3de27baa38e34c60','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1d1115f3136b4dcd6cf6a1980beee2d78b1b3366cdf8f6b3a0a629186f1d2e2',1996,'BE','Belgium','transportation',104,'Railways:
total: 3.396 km (2.363 km electritied: 2.563
kin double track)
vandard vange
(1995S)
Highways:
total: 137.876 km
paved: 129.603 km Uncluding 1.667 kn: of
CAPTESsW ays)
unpaved: 8.273 km (1992 est)
3.396 km 1 .435-m gauge
Waterways: 2.043 km ().528 km on regular
commercial use}
Pipelines: crude «i! 161 km: petroleum
products 1.167 km. natural gas 3.300 kn
Ports: Antwerp Brugge Gent. Hasselt
Liege. Mons. Namur. Oostende. Zcebruggc
Merchant marine:
total: 23 shaps (1.000 GRT of over) totaling
64.2 GRT/K3 oO DWI
hipys A Tyne bulk |. cargo S. chemn
tanker 5. liquetied gas tanker 3 nhker 6
(1995S est)
Airports:
total 4?
wih puaved THNWENS OCT $0479 f
wath pauriecd runways 2 Fas (ld ow }
win paicd runways j $24 le ) 4ivn y
nuth pared PiaviMal\\ YJ d le / $28 7
“Mii puiicd TrunMWaNS wider Yid m
. é
nih wnnaved runways GId to i a)
; | wus esl
Heliports: | (995 est)
telephone—| 32] (2) 224 02 11
FAX—[32] (2) 218 84 15, 219 75 03
established—NA December 1949
um—to promote the trade union
movement
members—{ 164 national organizations in the following 118 areas) Antigua and Barbuda.
Argentina, Australia. Austria, The Bahamas, Bangladesh. Barbados, Basque Country,
Belgium. Belize, Benin, Bermuda, Botswana, Brazil. Bulgaria, Burkina Faso, Cameroon,
Canada, Cape Verde. Chad, Chile, China, Colombia. Cook Islands, Costa Rica, Curacao,
Cyprus, Czech Republic, Denmark, Dominica, Dominican Republic, Ecuador, El Salvador,
Estonia, Falkland Islands, Fiji, Finland, France, French Polynesia, Gabon. The Gambia,
Germany, Ghana, Greece, Grenada, Guatemala, Guyana, Holy See, Honduias, Hong Kong.
Iceland, India, Indonesia, Israel, Italy, Jamaica, Japan, Kenya. Kiribati, South Korea, Lebanon,
Lesotho, Liberia, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritius.
Mexico, Montserrat. Morocco, Netherlands, New Caledonia, NZ, Nicaragua, Norway.
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto
Rico, Romania, Rwanda, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, San Marino, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia.
Spain. Sn Lanka, Suriname. Swaziland, Sweden, Switzerland. Thailand, Togo. Tonga.
Trinidad and Tobago, Tunisia, Turkey, Uganda. UK, US. Venezuela, Western Samoa, Zambia.
telephone—{32] (2) 728 41 11
FAX—(32] (2) 728 45 79
established—& November 199]
effective--20 December 1991
aim—to discuss cooperation on mutual
political and security issues
members—(42) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bulgaria, Canada,
Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary,
Iceland, Italy, Kazakstan, Kyrgyzstan, Latvia, Lithuania, Luxembourg, Malta, Moldova,
Netherlands, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden,
Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
537
North Atlantic Treaty Organization
(NATO)
address—-B-110 Brussels, Belgium
telephone—{32} (2) 728 41 il
FAX—{32] (2) 728 45 79
established—\\7 September 1949
aim—to promote mutual defense and
cooperation
members— 16) Belgium, Canada, Denmark, France, Germany, Greece, Iceland, Italy,
Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA)
address—Le Seine St. Germain, 12 bd des
Iles, F-92130 Issy-les-Moulineaux, France
telephone—{33] (1) 45 24 10 10
FAX—{33] (1) 45 24 11 10
established—NA 1958
aim—1o promote the peaceful uses of
nuclear energy; associated with OECD
members—(23) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany,
Greece, Iceland, Ireland, Italy, Japan, Luxembourg, Netherlands, Norway, Portug.!, Spain,
Sweden, Switzerland, Turkey, UK, US
Nuclear Suppliers Group (NSG)
note—also known as the London Suppliers
Group or the London Group
address—c/o IAEA, Wagramerstrasse 5,
P.O. Box 100, A-1400 Vienna, Austria
telephone—|43]| (1) 2360 2045
FAX—(43] (1) 234564
established—\\974
effective—1975
aim—to establish guidelines for exports of
nuclear materials, processing equipment for
uranium enrichment, and technical
information to countries of proliferation
concern and regions of conflict and
instability
members—(34) Argentina, Australia, Austria, Belgium, Brazil, Bulg»; , Canada, Czech
Republic, Denmark, Finland, France, Germany, Greece, Hungary {re\\und, Italy, Japan, South
Korea, Luxembourg, Netherlands, NZ, Norway, Poland, Portuga’. &«vnania, Russia, Slovakia.
South Africa, Spain, Sweden, Switzerland, Ukraine, UK, US
observer—(1) European Commission
Organismo para la Proscripcion de las
Armas Nucleares en la America Latina
y el Caribe (OPANAL)
see Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean
(OPANAL)
Organization for Economic Cooperation
and Development (OECD)
address—2 rue Andre Pascal, F-75775
Paris CEDEX 16, France
telephone—{33] (1) 45 24 82 00
FAX—{33] (1) 45 24 85 00, 45 24 81 76
established—\\4 December 1960
effective—30 September 1961
aim—to promote economic cooperation and
development
members—(27) Australia, Austria, Beigium, Canada, Czech Republic, Denmark, Finland,
France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, Luxembourg, Mexico.
Netherlands, NZ, Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
special member— 1) EU
ewer ewe me
Organization for Security and
(Cooperation in Europe (OSCE)
note—tormerly the Conference on Security
and Cooperation in Europe (CSCE)
uddress—Karntner Ring 5-7, 1010 Vienna,
Ausinia
telephone—{43}] (1) 514 36-50
FAX—{[43] (1) 514 36-99
sablished—\\| January 1995
um—to toster the implementation of
human nghts, fundamental freedoms,
democracy. and the rule of law: to act as
in instrument of early warning, conflict
prevention and crisis management, and to
serve as a framework for conventional
arms control and confidence building
Measures
members—{53) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and
Herzegovina. Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland,
France, Georgia, Germany, Greece, Holy See, Hungary, Iceland, Ireland, Italy, Kazakstan,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Malta, Moldova, Monaco, Netherlands, Norway, Poland. Portugal, Romania,
Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan, Yugoslavia (suspended)
partners for cooperation——7) Algeria, Egypt, Israel, Japan, South Korea, Morocco, Tunisia
Organization of African Unity (OAL)
address—P. O. Box 3243, Addis Ababa,','77497f531b11d88a8d2ede02a307532b649f20941e44006e72b1a3e57dd94be5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2dacd7ead511ff4ec74e6a86cdb9a491807e8cbb9f0e6d69a813bcf005bbcad',1996,'BZ','Belize','transportation',110,'Railways: 0 km
Highway: .
total: 2.560 km
paved: 3% km
unpaved: 2.224 km (1987 est.)
Waterways: 825 km river network used by
shallow-draft craft: seasonally navigable
Ports: Belize City, Big Creek, Corozol.
Punta Gorda
Merchant marine:
total: 89 ships (1.000 GRT or over) totaling
311.731 GRT/470.272 DWT
ships by type: bulk 9. cargo 60). container 6.
liquefied gas tanker |. oil tanker 3.
refngerated cargo 4. roll-on/roll-off cargo 4.
specialized tanker |. vehicle carner | (1995
est.)
Airports:
total: 35
with paved runways 1,524 to 2.437 m: |
with paved runways under 914 m: 25
with unpaved runways 2.438 to 3.047 m: |
with unpaved runways 914 to 1,523 m: &
(1995 est.)
Railways:
otal: STS km tsingle track) (1995 ¢
AX
narrow gauge: 378 km | OOO-m
Highways:
ratal: 6.070 km
paved 1214 km
unpaved: 4.856 hm (1992 est
Waterways: navigabk
important only local!
Ports: Cotonou, Porto-N
Merchant marine: 1
Airports:
total: S
tat
wath pu Cu Fithin \\ | 1 thd
th unpaved ru ive0of 4
4) " i¢ Pidily , ?
1QYsS t','64424231855504dcfcf19c70e24505831aab487062b83301b7818f54f2e2282f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b986cc0b9e54e25e4bcc3a9750174e133cc1f4ec257b7b5f6c152b946102ea4',1996,'BM','Bermuda','transportation',117,'Railways: 0 km
Highways:
total: 208 km
peved: 208 km
unpaved: 0 km (1986 est.)
note: in addition. there are 400 km ot |
and unpaved roads that are privately ows
Ports: Hamilton. Saint George
Merchant marine:
total. 69 ships (1.000 GRT or over) total
3.146.693 GRT/5.007.242 DWT
ups by type: bulk 10. cargo 3. container 7
liquefied gas tanker 16. oil tanker it
retrigerated cargo 10. roll-on/roll-olf carge 4
short-sea passenger |. specialized tanker
vehicle carner |
note: a tlag of convenience registry: inc!
ships from 11 countmes among wi
UK 17. US 13. Canada 10. Ne
Nigeria 4. Sweden 3. Hong Kong 2. 8
Mexico |. and NZ 1 (1995 est)
Airports:
total: |
with paved runwars 2.438 te
(1995 est','83b8b18ea4de0fab0b241ac9eb835a8fa122c9e106a484b2a4d998cd4357c901','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a90b12af4fc579023c9e30d2f9a8545cba689aa5666aa3f5453dbec4506e4441',1996,'BW','Botswana','transportation',131,'Railways:
trotal: 971 kav
narrow cane
(1995)
Highways:
hital: 11,448 km
paved: 1.590 km
unpaved: 9SSS km (1YSS est)
Ports: none
Airports:
total: &1
971 km 1.067-m gauge
with paved ranwavs over 3.047 m: |
with paved runwavs 2.438 to 3.047 m. |
with paved runwavs 1.524 to 2.437 m9
with paved runways 914 to 1,522 m: |
with paved ranwavs under 914m: 22
with unpaved runways 1.524 to 2.437 m: 3
with unpaved ranwavs 914 to 1523 m: 44
{ }y05 est)
telephone—{267| (31) 51863, 51864,
51865
FAX—(267] (31) 372848
established—\\7 August 1992
aim—A0 promote regional economic
development and integration
members— 12) Angola, Botswana, Lesotho, Malawi. Mauritius, Mozambique. Namibia. South
Africa, Swaziland, Tanzania. Zambia. Zimbabwe
Southern Cone Common Market
(Mercosur)
note—also known as Mercado Comun del
Cono Sur (Mercosur)
address—c/o Cancilleria de la Republica
de Argentina, Buenos Aires, Argentina
established—26 March 199}
aim—Ato increase regional economic
cooperation
members—(4) Argentina, Brazil, Paraguay, Uruguay
associate member— 1) Chile
Statistical Commission
address—cilo ECOSOC, United Nations,
New York, NY 10017, USA
telephone—{\\] (212) 963 1234
FAX—{1] (212) 758 2718
established—2\\1 June 1946
aim—to deal with development and
standardization of national statistics of
interest to the UN, as part of the
Economic and Social Council organization
members— 24) selected on a rviating basis from all regions
Third World
another term for the less developed countries: the term ts fading from use: see less developed
countries (LDCs)
underdeveloped countries
refers to those less developed countries with the potential for above-average economic growth:
see less developed countries (LDCs)
undeveloped countries
refers to those extremely poor less developed countries (LDCs) with little prospect for
economic growth, see least developed countries (LLDCs)
inion Douaniere et Economique de
1 Afrique Centrale (UDEAC)
see Central African Customs and Economic Union (UDEAC)
| nited Nations (UN>
address—United Nations. New York, NY
iwoi7, USA
cleplome—{1} (212) 963 1234
FAX—i1] (212) 758 2718
established—26 June 1945
fiectie—24 October 1945
aim- to maintain international peace and
securnts and to promote cooperation
imvolving economic, social, cultural, and
humanitanan problems
members— \\84 excluding Yugoslavia) Afghanistan, Albania, Algena, Andorra, Angola,
Antigua and Barbuda, Argentina. Armenia, Australia, Austria, Azerbaijan, The Bahamas.
Bahrain, Bangladesh. Barbados, Belarus. Belgium. Belize, Benin, Bhutan. Bolivia, Bosnia
and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde. Central African Republic. Chad, Chile, China,
Colombia, Comoros, Congo, Costa Rica. Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic. Denmark. Djibouti, Dominica, Dominican Republic. Ecuador. Egypt. El Salvador.
Equatorial Guinea, Eritrea. Estonia, Ethiopia, Fiji, Finland, France. Gabon, The Gambia.
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti. Honduras. Hungary. Iceland, India, Indonesia, Iran. Iraq, Ireland, Israel. Italy. Jamaica.
Japan, Jordan, Kazakstan, Kenya, North Korea. South Korea, Kuwait, Kyrgyzstan, Laos.
Latvia, Lebanon, Lesotho, Liberia. Libya. Liechtenstein. Lithuania, Luxembourg. The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta.
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia. Morocco, Mozambique. Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger. Nigeria, Norway, Oman, Pakistan, Palau. Panama, Papua New Guinea, Paraguay.
Peru. Philippines. Poland, Portugal. Qatar. Romania, Russia, Rwanda, Saint Kitts and Nevis.
Saint Lucia. Saint Vincent and the Grenadines, San Marino, Sao Tome and Principe. Saudi
Arabia, Senegal, Seychelles. Sierra Leone, Singapore. Slovakia, Slovenia, Solomon Islands.
Somalia, South Africa. Spain. Sn Lanka, Sudan, Suriname. Swaziland, Sweden, Syria.
Tapkistan, Tanzania, Thailand. Togo, Trinidad and Tobago, Tunisia, Turkey. Turkmenistan.
Uganda, Ukraine. UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Western Samoa. Yemen. Yugoslavia (suspended), Zaire. Zambia, Zimbabwe:
note—all UN members are represented in the General Assembly
observers—(2 plus the Palestine Liberation Organization) Holy See. Switzerland, Palestine
Liberation Organization
United Nations Angola Verification
Mission (UNAVEM Il)
note —successor to onginal UNAVEM and
UNAVEM I
address—</o United Nations, UNAVEM
lil, New York, NY 10017, USA
telephone—{1} (212) 963 1234
FAX~—-{1] (212) 758 2718
established —W0) December 19s"
aim—to assist the parties im restoring
peace and achieving national reconciliation
m Angola on the basis of the Peace
Accords. the Luska Protocol, and relevant
Security Council resolutions; established by
the UN Security Council
member: — 34) Algeria, Argentina, Bangladesh. Brazil. Bulgaria, Congo. Egypt. Fiji, France.
{suinea-Bissau, Hungary. India, Jordan. Kenya. Malaysia, Mali, Morocco, Netherlands. NZ.
Nigeria, Norway. Pakistan, Poland, Portugal. Romania. Russia, Senegal. Slovakia, Sweden.
Tanzania, UK. Uruguay. Zambia. Zimbabwe
United Nations Assistance Mission for
Rwanda (UNAMIR)
address—<c/o UN Peace Keeping Missions.
Office for Special Political Affairs, United
Nations, New York, NY 10017, USA
telephone—{1| (212) 963 1234
FAX—{1] (212) 963 4879
established—S October 1993
aim—to support and provide safe
conditions for displaced persons and
human nights monitors, and to assist m
training a new national police force:
established by the UN Security Council
members—{27) Argentina, Australia, Austria, Bangladesh, Canada, Chad, Congo, Djibouti,
Fiji, Germany, Ghana, Guinea, Guinea-Bissau, India, Jordan, Malawi, Mali, Niger. Nigeria.
Pakistan, Russia, Senegal, Switzerland, Tunisia, Uruguay, Zambia, Zimbabwe
United Nations Children’s Fund
(UNICEF)
nole—acronym retained from the
predecessor organization UN International
Children’s Emergency Fund
address—UNICEF House. Three United
Nations Plaza, New York. NY 10017.
USA
telephone—{1| (212) 326 7000
established—1\\ December 1946
aim—to help establish child health and
welfare services
members—i41) selected on a rotating basis from all regions
United Nations Conference on Trade
and Development (UNCTAD)
address—Palais des Nations, CH-1211
Geneva 10, Switzerland
telephone—{41\\| (22) 917 12 34, 907 12
34
FAX—{41] (22) 907 00 57
established—¥ December 1964
aim—to promote international trade
members— 188) all UN members plus Holy See. Switzerland. Tonga
United Nations Confidence Restoration
Operation in Croatia (UNCRO)
nole—currently in the process of phasing
out and turning over authority to
UNTAFS, which was established |
January 1996
cddress—clo UN Peace Keeping Missions,
Office for Special Political Affairs, United
Nations, New York, NY 10017, USA
telephone—{1} (212) 963 1234
FAX—1!1} (212) 963 4879
established—3\\ March 1995
aim—Ao separate Creatian and Krajina
Serb forces: to monitor demilitarization of
the Provlaka Peninsula: to maintain a
presence on Croatia''s international borders:
tc. monitor and report the crossing of
alitary personnel, equipment. supplies and
weapons. to facilitate delivery of
sumanitarian assistance. to aid refugees
atyd displaced persons: to protect ethnic
minorities: and to clear mines; established
b, the UN Security Counc:!
members—(36) Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark,
Egypt, Estonia, Finland, France, Germany, Ghana, Indonesia, Ireland, Jordan, Kenya,
Lithuania, Malaysia, Nepal, Netherlands, Nigeria, Norway, Pakistan, Poland, Portugal, Russia,
Senegal, Slovakia, Spain, Sweden, Tunisia, Turkey, Ukraine, UK, US
Us.ited Nations Development Program
(UNDP)
address—One United National Plaza, New
York, NY !0017, USA
teiephone—|1] (212) 906 5788, 906 500
FAX—{1] (212) 906 5365
estublished—22 November 1965
aimi—to provide technical assistance to
stimulate econe’ie and social development
members—(36) selected on a rotating basis from all regions
United Nations Disengagement Observer
Force (UNDOF)
addéress—clo UNDOF, P.O. Box 5368,
Damascus. Syrian AR
‘sablished—3\\1 May 1974
tuum—to observe the 1973 Arab-Israeli
cease-fire. established by the UN Security
Council
members—(3) Austria, Canada, Poland
ow"
United Nations Educational, Scientific,
and Cultural Organization (UNESCO)
address—7 place de Fontenoy, F-75700
Paris, France
telephone—{33] (1) 45 68 10 00
FAX—{33] (1) 45 67 16 90
established-—16 November 1945
effective—4 November 1946
aim—to promote cooperation in education,
science, and culture
members—( 184) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Congo,
Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia.
Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg. The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands.
Mauritania, Mauritius, Mexico, Moldova. Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines.
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzeriand, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu. Uganda, Ukraine, UAE,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Western Samoa, Yemen, Yugoslavia
(suspended), Zaire, Zambia, Zimbabwe
associate members—(4) Aruba, British Virgin Islands, Macau, Netherlands Antilles
United Nations Environment Program
(UNEP)
address—One United Nations Plaza, New
York, NY 10017, USA
telephone—{1} (212) 906 5000
FAX—{1] (212) 826 2057
established—\\15 December 1972
aim—to promote international cooperation
on all environmental matters
members—{58) selected on a rotating basis from all regions
United Nations Force in Cyprus
(UNFICYP)
address—c/o UN Peace Keeping Missions,
Office for Special Political Affairs, United
Nations, New York, NY 10017, USA
telephone—{1} (212) 963 1234
FAX—{1] (212) 963 4879
established—4 March 1964
aim—to serve as a peacekeeping force
between Greek Cypriots and Turkish
Cypriots in Cyprus; established by the UN
Security Council
members—(7) Argentina, Australia, Austria, Canada, Finland, Ireland, UK
United Nations General Assembly
address—see United Nations
established—26 June 1945
effective-—24 October 1945
aim—to function as the primary
deliberative organ of the UN
members—{ 185) all UN members are represented in the General Assembly
587
United Nations Industrial Development
Organization (UNIDO)
ddress—-Vienna International Center, P.O.
Box 300, A-1400 Vienna, Austria
elephone—-{43} (1) 211 310
*AX—143| (1) 23 21 56
vtublished—17 November 1966
efectve—1 January 1967
aium—-UN specialized agency that promotes
industrial development especially among
the members
members—{ 169) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia,
Austna, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Beiarus, Belgium, Belize,
Benin, Bhutan, Polivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde. Central African Republic, Chad,
Chile, China, Colombia, Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic. Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq. Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay. Peru,
Philippines, Poland, Portugal. Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal.
Seychelles, Sierra Leone, Slovakia, Slovenia, Somalia, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria. Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey. Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zaire, Zambia. Zimbabwe
United Nations Institute for Training
and Research (UNITAR)
established—11 December 1963
aim—to help the UN become more
effective through training and research
members (Board of Trustees}—(24) Argentina, Belgium, Canada. China, Cote d''Ivoire.
France, Germany. India, Italy, Jamaica, Japan. Libya, Mexico, Netherlands, Norway, Pakistan,
Russia, Sweden, Switzerland, Tunisia, Uganda, UK, US, Yugoslavia
United Nations Interim Force in
Lebanon (UNIFIL)
address —clo UN Peace Keeping Missions.
Office tor Special Political Affairs. United
Nations, New York, NY 10017, USA
fe lephone —[1} (212) 963 1234
FAX—{1} (212) 963 4879
established—\\9 March 1978
aim—to contirm the withdrawal of Israel
forces, and assist in reestablishing
Lebanese authority in southern Lebanon:
established by the UN Secunty Council
members—(9) Fiji, Finland, France. Ghana, Ireland. Italy, Nepal. Norway, Poland
United Nations Iraqg-Kuwait Observation
Mission (UNTKOM)
address—c/o UN Peace Keeping Mission.
Office tor Special Political Affairs, United
Nations, New York, NY 10017, USA
telephone—Aelephone {1} (212) 963 1234
FAX—{1] (212) 963 4879
established—9 Apnl 199]
aim—to observe and monitor the
demilstanzed zone established between Iraq
and Kuwait, established by the UN
Secunty Council
members— 32) Argentina, Austria, Bangladesh, Canada, China, Denmark, Fiji, Finland,
France. Ghana, Greece. Hungary. India. Indonesia, Ireland, Italy, Kenya, Malaysia, Nigeria,
Pakistan. Poland, Romania, Russia, Senegal. Singapore. Sweden, Thailand, Turkey, UK, US,
Uruguay. Venezuela
pe thie
United Nations Military Observer Group members—(8) Belgium, Chile, Denmark, Finland, Italy, South Korea. Sweden, Uruguay
in India and Pakistan (UNMOGIP)
address—c/o OUSGSPA, Room 3853,
United Nations, New York, NY 10017,
USA
telephone—{1] (212) 963 4457
FAX—([1] (212) 758 2718
established—\\|3 August 1948
aim—to observe the 1949 India-Pakistan
cease-fire; established by the UN Security
Council
United Nations Mission for the members— 29) Argentina, Austria. Bangladesh, Belgium, China, Egypt. El Salvador, France
Referendum in Western Sahara Germany. Ghana, Greece, Guinea, Honduras, Hungary, Ireland, Ita''y, Kenya, South Korea.
(MINURSO) Malaysia, Nigeria, Norway, Pakistan, Poland, Russia, Togo, Tunisia, US, Uruguay. Venezuela
address—c/o UN Peace Keeping Missions,
Office for Special Political Affairs, United
Nations, New York, NY 10017, USA
telephone—{1| (212) 963 1234
FAX—-[1] (212) 963 4879
established—29 April 1991
aim—to supervise the cease-fire and
conduct a referendum in Western Sahara:
established by the UN Security Council
United Nations Mission in Haiti members—( 30) Algeria, Argentina, Austria, The Bahamas, Bangladesh, Barbados, Belize.
(UNMIH) Benin, Canada, Djibouti, France. Guatemala, Guyana, Honduras, India, Ireland, Jamaica,
note—mandate expired 19 February 1996 Jordan, Mali, Nepal, Netherlands, Pakistan, Philippines, Russia, Saint Kitts and Nevis. Saint
address—clo UN Peace Keeping Missions. Lucia, Suriname, Togo, Trinidad and Tobago, US
Office for Special Political Affairs, United
Nations, New York, NY 10017, USA
telephone—{\\} (212) 963 1234
FAXN—{1]} (212) 963 4879
established—23 September 1993
aim—to assist in implementing the
agreement to transfer power back into the
civilian government; established by the UN
Security Council
United Nations Mission of Observers in members—(10) Austria, Bangladesh, Bulgaria, Denmark. Hungary, Jordan, Poland.
Tajikistan (UNMOT) Switzerland, Ukraine, Uruguay
address—clo UN Peace Keeping Missions,
Office for Special Political Affairs, United
Nations, New York, NY 10017, USA
telephone—{1] (212) 963 1234
FAX-—{1] (212) 963 4879
established—\\6 December 1994
aim—to monitor and investigate violations
of the cease-fire of 17 September 1994
between Tajikistan and the Tajik
opposition and to assist in the political
negotiation process; established by the UN
Security Council
United Nations Observer Mission in El established 20 May 1991 to verify cease-fire arrangements and to monitor the maintenance
Salvador (ONUSAL) of public order pending the organization of a new National Civil Police: established by
the UN Security Council; members were Argentina, Austria, Brazil. Canada, Chile, Colombia,
France, Guyana, Ireland, Italy, Mexico, Spain, Sweden, Venezuela; disbanded April 1995
589
United Nations Observer Mission in
Georgia (UNOMIG)
address—c/o UN Peace Keeping Missions.
Office for Special Political Affairs, United
Nations, New York. NY 10017, USA
telephone—|\\| (212) 963 1234
FAX—{1} (212) 963 4879
established—August 1993
aim—to verify compliance with the
cease-fire agreement. to monitor weapons
exclusion zone, and to supervise CIS
peacekeeping force for Abkhazia:
established by the UN Secunty Council
members—{23) Albania, Austria, Bangladesh, Cuba, Czech Republic, Denmark, Egypt,
France, Germany, Greece, Hungary, Indonesia, Jordan, South Korea, Pakistan, Poland, Russia,
Sweden, Switzerland, Turkey, UK, US, Uruguay
United Nations Observer Mission in
Liberia (UNOMIL)
address—c/o UN Peace Keeping Missions,
Office for Special Political Affairs, United
Nations, New York, NY 10017, USA
telephone—{1] (212) 963 1234
FAX—(1] (212) 963 4879
established—22 September 1993
aim—to assist in the implementation of
the peace agreement: established by the
UN Security Council
members— 10) China, Czech Republic, Egypt, Guinea-Bissau, India, Jordan, Kenya,
Malaysia, Pakistan, Uruguay
United Nations Observer Mission
Uganda-Rwanda (UNOMUR)
established 1993 for six months to monitor the Uganda/Rwanda border to verify that no
military assistance reaches Rwanda across the border; established by the UN Security Council;
members were Bangladesh, Botswana, Brazil, Hungary, Netherlands, Senegal, Slovakia.
Zimbabwe: subsumed by UNAMIR
United Nations Office of the High
Commissioner for Refugees (UNHCR)
address—Case postale 2500, Depot.
CH-1211 Geneva, Switzerland
telephone—|41| (22) 739 81 11
FAX—|41] (22) 731 95 46
established—3 December 1949
effective—1| January 1951
aim—to ensure the humanitarian treatment
of refugees and find permanent solutions
to refugee problems
members—(50) Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Canada,
China, Colombia, Denmark, Ethiopia, Finland, France, Germany, Greece, Holy See, Hungary,
india, Iran, Israel, Italy, Japan, Lebanon, Lesotho, Madagascar, Morocco, Namibia,
Netherlands, Nicaragua, Nigeria, Norway, Pakistan, Philippines, Russia, Somalia, Spain,
Sudan, Sweden, Switzerland, Tanzania, Thailand, Tunisia, Turkey, Uganda, UK, US,
Venezuela, Yugoslavia, Zaire
United Nations Operation in
Mozambique (UNOMOZ)
established 16 December 1992 to supervise the cease-fire; established by the UN Security
Council; members were Argentina, Austria, Bangladesh, Botswana, Brazil, Canada, Cape
Verde, China Czech Republic, Egypt, Guinea-Bissau, Hungary, India, Ireland, Italy, Japan,
Jordan, Malaysia, Netherlands, Norway, Portugal, Russia, \\ pain, Sweden, US, Uruguay,
Zambia; shut down operations 31 January 1995
United Nations Operation in Somalia
(UNOSOM I}
established 24 April 1992 to facilitate an immediate cessation of hostilities, to maintain
a cease-fire in order to promote a political settlement, and (o provide urgent humanitarian
assistance, established by the UN Security Council; members ‘vere Australia, Bangladesh,
Botswana, Canada, Egypt, India, Ireland, Malaysia, Nepal, NZ, Nigeria, Pakistan, Romania,
Zimbabwe; UN peacekeepers left Somalia on | March 1995; some UN personnel remain
in Somalia engaged in humanitarian work
590
United Nations Population Fund members—{ 34) selected on a rotating basis from all regions
(UNFPA)
nete—acronym retained from predecessor
organization UN Fund for Population
Activities
address—220 E. 42nd Street, 19th Floor,
Room DN-1901, New York, NY 10017,
USA
telephone—{1] (212) 297 5000
FAX—({1] (212) 557 6416
established—NA July 1967
aim—to assist both developed and
developing countries to deal with their
population problems
United Nations Preventive Deployment members—(27) Bangladesh, Brazil, Canada, Denmark, Egyrt, Finland, France, Ghana,
Force (UNPREDEP) Indonesia, Ireland, Jorda... Kenya, Malaysia, Netherlands, NZ, Nigeria, Norway, Pakistan.
established—31 March 1995 Poland, Portugal, Russia, Spain, Sweden, Switzerland, Ukraine, UK, US
aim—to monitor border activity in the
Former Yugoslav Republic of Macedonia
United Nations Protection Force members—(31) Bangladesh, Belgium, Brazil, Canada, Czech Repudlic, Denmark, Egypt.
(UNPROFOR) Finland, France, Germany, Ghana, Indonesia, Ireland, Jordan, Kenya, Malaysia, Nepal.
note—disbanded December 1995; replaced Netherlands, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Spain. Sweden.
by the Implementation Force (IFOR) a Switzerland, Ukraine, UK, US
NATO group
address—clo UN Peace Keeping Mission,
Office for Special Political Affairs, United
Nations, New York, NY 10017, USA
telephone—{1] (212) 963 1234
FAX—{1] (212) 963 4879
established—28 February 1992
aim—to create conditions for peace and
security required for the negotiation of an
overall settlement of the **Yugoslav”’
crisis; established by the UN Security
Council
United Nations Relief and Works members—4 10) Belgium, Egypt, France, Japan, Jordan, Lebanon, Syria, Turkey, UK, US
Agency for Palestine Refugees in the
Near East (UNRWA)
address—-Vienna International Center, P.
O. Box 700, A-1400 Vienna, Austria
telephone—({43] (1) 211 31, ext. 4530
FAX—([43] (1) 230 7487
established—8& December 1949
aim-—to provide assistance to Palestinian
refugees
United Nations Research Institute for members—-no country members, but a Board of Directors consisting of a chairman appointed
Social Development (UNRISD) by the UN secretary general and 10 individual members
established—| July 1964
aim—to conduct research into the
problems of economic development during
different phases of economic growth
591
United Nations Secretariat
address—see United Nations
established—26 June 1945
cftectve—24 October 1945
m—to serve as the primary
simimstrative organ of the UN; a
Secretary General 1s appointed for a
‘Sear term by the General Assembly
ihe recommendation of the Security
mc
members—the UN secretary general and staff
nited Nations Security Council
idress—v/o United Natio','2f075aaf693a29613f25f0a19dcb68901a40fb44347cd53b4e1940bd6b15dd51','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02c246a1f682ab1c7630a8a8dac336e072f0ec36b458004afec7a6e19789d468',1996,'BW','Botswana','transportation',132,'ns, New York,
SY) 10017, USA
phone—{1] (212) 963 1234
iX—-(1] (212) 758 2718
ublished—26 June 1945
tve—24 October 1945
m- to Mamtain international peace and
iyi
permanent members—(5) China, France, Russia, UK, US
nonpermanent members— 10) elected for two-year terms by the UN General Assembly:
Argentina (1994-95), Botswana (1995-96), Czech Republic (1994-95). Germany (1995-96),
Honduras (1995-96), Indonesia (1995-96), Italy (1995-96). Nigeria (1994-95), Oman (1994-
95), Rwanda (1994-95)
nited Nations Transitional Authority in
ambodia (UNTAC)
established by the UN Security Council on 28 February 1992 to contribute to the restoration
and maintenance of peace and to the holding of free elections; disbanded sometime after
the UN-supervised election in May 1993; members were Algeria, Argentina, Australia,
Austria, Bangladesh, Belgium, Brunei, Bulgaria, Cameroon, Canada, Chile, China, Colombia,
Egypt, Fiji, France, Germany, Ghana, Hungary, India, Indonesia, Ireland, Italy, Japan, Jordan,
Kenya, Malaysia, Morocco, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Philippines,
Poland, Russia, Senegal, Singapore, Sweden, Thailand, Tunisia, UK, US, Uruguay
Lnited Nations Truce Supervision
Organization (UNTSO)
Government House, P.O. Box
490. Jerusalem, Israel
telephone—{972] (2) 734 223
established—NA May 1948
aim—Ao supervise the 1948 Arab-Israeli
cease-fire. currently supports timely
deployment of remforcements to other
peacekeeping operations in the region as
needed: initially established by the UN
Security Council
address
members— 19) Argentina, Australia, Austria, Belgium, Canada, Chile, China, Denmark,
Finland, France. Ireland, Italy, Netherlands, NZ, Norway, Russia, Sweden, Switzerland, US
United Nations Trusteeship Council
established on 26 June 1945, effective on 24 October 1945, to supervise the administration
of the 11 UN trust territories; members were China, France, Russia, UK, US; it formally
suspended operations | November 1995 after the Trust Territory of the Pacific Islands (Palau,
became the Republic of Palau, a self-governing territory in free association with the US:
the Trustee Council was not dissolved
United Nations University (UNU)
established—6 December 1973
aim—to conduct research in development,
welfare. and human survival and to train
scholars
members (associated institutes)—(32) Argentina, Australia, Bangladesh, Brazil, Canada, Chile.
China, Colombia, Costa Rica, Ethiopia, France, Ghana, Guatemala, Hungary, Iceland, India,
Japan, Kenya, South Korea, Mexico, Netherlands, Nigeria, Philippines, Spain, Sri Lanka,
Sudan, Switzerland, Thailand, Trinidad and Tobago, UK, US, Venezuela
Universal Postal Union (UPU)
address—Bureau International de l’''UPU,
Welipoststrasse 4, CH-3000 Berne 15,','56ec865657a47c942dc6f2667062b512d94fd3efd810c59fd2749a695ff6bb0f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88ac078e1652d4d8c039899bb0950b77f71f40276d991fe081f4e0760886f1ee',1996,'BV','Bouvet Island','transportation',138,'Railways:
total: 13 km private line
narrow gauge: 13 km OOTG-m gauge
Highways:
total: 2.443 km
pavee. 1.296 km
unpaved: 1147 km (1993)
Waterways: 209 km. navigable by cratt
drawing less than 1.2 m
Pipelines: crude oi) 135 km. petroleum
products 418 km: natural gas 920 km
Ports: Bandar Sen Begawan. Kuala Belan
Muara, Seria. Tuton:
Merchant marine:
total: 7 lquetied gas tankers (1.000 GRE on
over) totaling 348.476 GRT/340.635 DW]
(1904 est)
\\irports:
fatal: 2
with paved runways over 3.047 me. |
with unpaved runways 914 to 1.523 m
(1995 est.)
Heliports: 3 (1995 est)','d032f1f618aa7c5620ebcfb94252de0cc3092e742e7d1ad20db174499591b188','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('693718987f43531330d6ce26b846e4b7372df273f25d32e5b3ebf2480401c426',1996,'BG','Bulgaria','transportation',141,'GDP per capita: 84.920 (1995S est) i
GDP composition by sector: Railways:
; , — 1%)?
eric wiliare i. aa 4 Ar
Defense
mals, Mf) Vithiadiad i fi ‘ 4 i ,*”
writes” S26, (1094) f MP AM ciel } '' \\ Bran hes \\ \\ \\ \\
Inflation rate (consumer prices): *5 aher 245 km 07 , | | Premcpys. bint
(1995 Highways:
Labor force: § | mullor M982 b \\lanpower availability
Py oncupualin miusirs 4 wrneullur +3 MIG 4h ty } j
1s vf Ne j Ww "
Lnemployvment rate: |!) 9 YYS est ‘ih ")
Kudyet: Waterwass: 4 | . nae
; So a. ’ q
Pipelines Di femse expenditures
| ‘ ‘ | . *
uf | s\\ \\ ‘
Industries Ports: | .
‘ » | \\
Nlerchant marim
Industrial production growt) rat
’ ,
blectricits
Thi ina
. \\ \\4
. » \\''
Agriculture
>
,
Init drugs
‘ \\ \\1
\\ \\ \\irports
, a
r.meorts: So ; ; ''
.f .
; " ry \\ | u :
> s wrhmouiiul and tood “i “\\i
ml Ipparel 14 metals had «core iv ; ‘ / 4
chemicals 16.9 minerals and tuels 9.4 ow i j
partners. former CEMA countries 35.7 with w run ;
OK 1) Ih 6 (El shNG ) Arab countries ) ffi vanes? cal Fide j Liltia fia
$1: other 12.65 (1994 est)','c1851c7a318f4467036c4467a41de7a1a0feed6d911148fbcd7c0134cd0f0f84','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b113a72f9e9c3412f0b3587dc52dccd01ccb462b73faa07fa437310216a4aac',1996,'BF','Burkina Faso','transportation',142,'“ AWAD ; ]
|
— —_—_—_—.—-) oo 7)
{, DPM pt
| ‘ (
( coordmates MN) * Hy W
Te
'' ’ is
\\ ‘4
4
>
‘
| Lh
’
ine
lland: (60) b SY','2b4c042127e27f06b3d69ab2780f2175a3d57a123a185114b13e7c14dded9772','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a96c1ccee317afb61c023a8f3f3711a0a0fce3c70107fc146a3078ddc5da2562',1996,'TH','Thailand','transportation',147,'Railways
>
\\ 8
4 {) {
*
‘)
Highways
sf s
‘ s
/ ‘
Ports:
\\irports:
"
} ; rh ; ‘/ ‘ ’
'' ny ‘ ria? ’ ‘ ? ,
wilh puaved rianwavs wider ¥ sm Ss
nih wnpared runways Sod to Od ’
with unpaved runways Vid ta 1 S28 am WW
(1Y9S est)
0 50 100% CHINA =“
0 50 100m
VIETNAM
BURMA
; LAOS J
f
{ a
Udon 4,
eThani ”
N , Phitsanulok
q . Khon Kaen
‘ Nakhon Sawan Khorat
} Plateau
? Ubon” N
Nakhon* :
‘ Ratchasima Ratcnathan
eer
Laem Chabangé> Racna
(" Sananio CAMBODIA
5 sf
} ¥C
a) ba
Gulf of ae NY
Thailand Y >
VIETNAM 4
a
“A. Songknta
‘ mith
INDONESIA -l "i. Sc uth
mM China
ya Straittof \\S wists \\ Sea
\\ Malacca}
) J \\
Railways:
total: 525 km (1995)
narrow gauge: 525 km 1.000-m gauge
Highways:
total: 7.545 km
paved: |,833 km
unpaved: 5,712 km (1993 est.)
Waterways: 50 km Mono river
Ports: Kpeme. Lome
Merchant marine: none
Airports:
total: 8
with paved runways 2,438 to 3,047 m: 2
with paved runways under 9/4 m: 2
with unpaved runways 914 to 1,523 m. 4
(1995 est.)','02a826504f714ee4d08997e2dacc83bfeb44653b2cf635e9166480cd67f390a6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1368bde186a10b8d228d7aaaf1a404fb0b6e49c6291a1ed3e36c976955fc59cf',1996,'MY','Malaysia','transportation',154,'Railways:
total: 3.569 km
narrow gauge: 3.569 km 1.000-m gauge
(1995)
Highways:
total: 26.861 km
paved: 3.481 km
unpaved: 23.680 km (1988 est.)
Waterways: | 2.800 km: 3.200 km navigable
by large commercial vessels
Pipelines: crude oil 1.343 km: natural gas
330 km
Ports: Bassein. Bhamo. Chauk. Mandalay.
Moulmein. Myitkyina, Rangoon, Akyab
(Sittwe}, Tavoy
Merchant marine:
total. 40: ships (1.000 GRT or over) totaling
444.957 GRT/610.420 DWT
ships by tvpe. bulk 11. cargo 1$. chemical
tanker 5. contaimer |. oil tanker 3. passenger-
cargo 3, vehicle carnmer 2 (1995 est.)
Airports:
total: 74
with paved runways over 3,047 m: 2
with paved runways 2.438 to 3.047 m: 2
with paved runways 1,524 to 2.437 m: 13
with paved runways 914 to 1,523 m: 10
with paved runways under 9/4 m: 28
with unpaved runways 1,524 to 2.437 m: 2
with wnpaved runways 914 to 1,523 m: 17
(1995 est.)','e37e1c545cf9ae48194669bc93cba59aad3c407eaac13fde5a90a8c91d059b76','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b32bfe9249b743238fdc7ed43320aaceecf66ac0353ecfdd31f03d51b5484a4d',1996,'BI','Burundi','transportation',161,'Railways: 0 km
Highways:
total: 14.473 km
paved: 1.028 km
unpaved: 13.445 km (1992 est.)
Waterways: Lake Tanganyika
Ports: Bujumbura
Airports:
total; 3
with paved runways over 3,047 m. |
with unpaved runways 9!4 to 1,523 m: 2
(1995 est.)
$1
90
Burundi (continued) Cambodia Land use:
arable land: \\6%
permanent crops: 1%
meadows and pastures: 3%
forest and woodland: 76%
other: 4%
Irrigated land: 920 sg km (1989 est.)','917f4a3fe3328fa3664dc2be3927dabd823135be8e08d1e1eae9e661b036d166','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8363f0f3f5edc1919aab07dd7d643eb089a98c987b349dc25e143dc24fc6994d',1996,'ET','Ethiopia','transportation',170,'Railways:
total: 1.104 km (1995 est.)
narrow gauge? 1104 km 1.000-m gauge
Highways:
total: 64.026 km
paved: 2.666 km
unpaved: 61.960 km (1987 est.)
Waterways: 2.090 km: of decreasing
WMporlance
Ports: Bonaben. Douala, Garoua, Knibi.
Tike
Merchant marine:
word: 2 cargo ships (1.000 GRT or over)
totaling 24.122 GRT/33.509 DWT (1995
esti
Airports:
total: 45
with paved runways over 3,047 m: 2
with paved runways 2.438 to 3,047 m: 4
with paved runways 1,524 te 2.437 m: 3
with paved ranwavs 914 to 1.523 m: |
with paved runways under 914 m: 13
with unpaved runways 1,524 to 2.437 m7
with unpaved runways 914 to 1,523 m: 15
(]99S est.)
Railways: 0 km
Highways:
total: 22.500 km
paved: 2.700 km
unpaved: 19800 km (1992 est.)
Pipelines: crude oi! 15 kin
A447
Ports: Bender Cassim (Boosaaso), Berbera,
Chisimayu (Kismaayo). Merca, Mogadishu
Merchant marine:
total: 2 ships (1.000 GRT or over) totaling
5.529 GRT/6.892 DWT
ships by type: cargo |. retrigerated cargo |
(1995 est.)
Airports:
total: 52
with paved runways over 3,047 m: 3
with paved runways 2,438 to 3,047 m: |
with paved runways 1,524 to 2,437 m: 2
with paved runways 914 to 1,523 m: |
with paved runways under 914 m: 6
with unpaved runways 2,438 to 3,047 m: 4
with unpaved runways 1,524 to 2,437 m: 15
with unpaved runways 914 to 1,523 m: 20
(1995 est.)
telephone—{251} (1) 517700
FAX—{251] (1) 512622
established—-25 May 1963
aim—to promote unity and cooperation
among Atncan states
members—(53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape
Verde, Central African Republic, Chad, Comoros, Congo, Cote d''Ivoire, Djibouti, Egypt.
Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau.
Kenya, Lesotho, Liberia, Libya. Madagascar, Malawi, Mali, Mauritania, Mauritius,
Mozambique, Namibia, Niger, Nigeria, Rwanda, Sahrawi Arab Democratic Republic. Sao
Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa. Sudan,
Swaziland, Tanzania, Togo, Tunisia, Uganda, Zaire, Zambia, Zimbabwe
Organization of American States (OAS)
address—corner of 17th Street and
Constitution Avenue NW, Washington, DC
20006. USA
telephore—A"} (282) 458 3000
FAX—{[1} (202) 458 3967
established—30 April 1948
effectve—13 December 1951
aim—A0 promote regional peace and
security as well as economic and social
development
members— 35) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize. Bolivia.
Brazil, Canada, Chile, Colombia, Costa Rica, Cuba (excluded from forma! participation since
1962), Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana,
Haiti, Honduras, Jamaica, Mexico, Nicaragua. Panama, Paraguay, Peru, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Surname, Trinidad and Tobago, US, Uruguay,
Venezuela
observers— 31) Algeria, Angola, Austria, Belgium, Central American Parliament.
Commission of the European Communities, Cyprus, Egypt, Equatorial Guinea. Finland,
France, Germany. Greece. Holy See, Hungary. India. Israel. Italy, Japan, South Korea,
Morocco, Netherlands, Pakistan, Poland. Portugal, Romania, Russia, Saudi Arabia, Spain,
Switzerland, Tunisia
Organization of Arab Petroleum
Exporting Countries (OAPEC)
address—POB 20501, Satat 13066. Kuwait
telephone—{965| 5340713
FAX-—|965] 5340694
established—9 January 1968
am—AoO promote cooperation im the
petroleum industry
members— 10) Algeria, Bahrain, Egy pt. Irag. Kuwait, Libya, Qatar, Saudi Arabia, Syria,
UAE
587
Organization of Eastern Caribbean
States (OECS)
address—P.O. Box 179, The Morne,
Castries, St. Lucia
telephone—{1| (809) 452 2537
FAX—{1} (809) 453 1628
established—i8 June 1981
effective—4 July 1981
aim—to promote political, economic, and
defense cooperation
members—{7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint Kitts and Nevis.
Saint Lucia, Saint Vincent and the Grenadines
associate members—{2) Anguilla, British Virgin Islands
of Petroleum Exporting
Countries (OPEC)
address—Obere Donaustrasse 93, A-1020
Vienna, Austria
telephone—{43| (1) 21 11 20
FAX—(43] (1) 26 43 20
established—\\|4 September 1960
aim—to coordinate petroleum policies
members— 12) Algeria, Gabon, Indonesia, Iran. Irag. Kuwait, Libya, Nigeria. Qatar. Soudi
Arabia, UAE, Venezuela
Organization of the Islamic Conference
(OIC)
address—Kilo 6. Mecca Road, P.O. Box
178, Jeddah 21411. Saudi Arabia
telephone—{966| (2) 680-0800
FAX—(966] (2) 687-3568
established—22-25 September i969
aim—to promote Islamic solidarity in
economic, social, cultural, and political
affairs
members—{SO plus the Palestine Liberation Organization) Afghanistan, Albania. Algeria.
\\zerbaijan, Bahrain, Bangladesh, Benin, Brunei, Burkina Faso. Cameroon, Chad. Comoros.
Djibouti, Egypt. Gabon, The Gambia, Guinea, Guinea-Bissau, Indonesia, Iran, Irag. Jordan,
Kazakstan, Kuwait, Kyrgyzstan, Lebanon, Libya. Malaysia. Maldives, Mali, Mauritania.
Morocco, Mozambique, Niger, Oman, Pakistan, Qatar, Saudi Arabia, Senegal. Sierra Leone.
Somalia, Sudan, Syria, Tajikistan, Tunisia, Turkey, Turkmenistan, Uganda. UAE. Yemen.
Palestine Liberation Organization
observers—{2) **Turkish Republic of Northern Cyprus’’, Uzbekistan
Paris Club
see Group of 10
Partnership for Peace (PFP)
established—1\\0-11 January 1994
aim—to expand and intensify political and
military cooperation throughout Europe.
increase stability, diminish threats to
peace, and build relationships by
promoting the spirit of practical
cooperation and commitment to democratic
principles that underpin NATO: program
under the auspices of NATO
members—(24) Albania, Armenia, Austria, Azerbaijan, Belarus, Bulgaria, Czech Republic.
Estonia, Finland, Georgia, Hungary, Kazakstan, Kyrgyzstan, Latvia, Lithuania, Malta,
Moldova, Poland, Romania, Russia, Slovakia, Slovenia, Sweden, Turkmenistan, Ukraine.
Uzbelistan
Permanent Court of Arbitration (PCA)
address—Peace Palace, Carnegieplein 2.
NL-2517 KJ The Hague. Netherlands
telephone—| $1] (70) 346 96 80
FAX—{3''; (70) 356 13 38
establi;ned—29 July 1899
aim—to facilitate the settlement of
international disputes
members—(81) Argentina, Australia, Austria, Belarus, Belgium, Bolivia, Brazil, Bulgaria.
Burkina Faso, Cambodia, Cameroon, Canada, Chile, China, Colombia, Cuba, Cyprus, Czech
Republic. Denmark, Dominican Republic. Ecuador, Egypt. El Salvador, Fiji, Finland. France,
Germany, Greece, Guatemala, Haiti, Honduras Hungary, Iceland, India, Iran, Iraq, Israel.
Italy, Japan. Jordan, Kyrgyzstan, Laos, Lebanon, Liechtenstein, Luxembourg, Malta,
Mauritius, Mexico, Netherlands, NZ. Nicaragua, Nigeria, Norway, Pakistan, Panama,
Paraguay, Peru, Poland, Portugal, Romania, Russia, Senegal, Singapore. Slovakia, Spain.
Sri Lanka, Sudan, Suriname. Swaziland, Sweden. Switzerland, Thailand, Turkey, Uganda.
Ukraine, UK, US, Uruguay, Venezuela, Zaire. Zimbabwe
Population Commission
see Commission on Population and Development
Rio Group (RG)
note—tormerly known as Grupo de los
Ocho. established in December 1986
established—NA 1988
aim—to consult on regional Latin
Americar issues
members— 11) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Mexico, Paraguay.
Peru, Uruguay. Venezuela:
note—Panama was expelled in 1988
Second World
another term for the traditionally Marxist-Leninist states of the USSR and Eastern Europe.
wih authorntanan governments and command economies based on the Soviet model; the
term is fading from use: see centrally planned economies
Sistema Economico Latinoamericana
(SELA)
see Latin American Economic System (LAES)
Social Commission
see Commission for Social Development
socialist countries
in general, countries in which the government owns and plans the use of the major factors
of production;
note—the term is sometimes used incorrectly as a synonym for Communist countries
South
a popular term for the poorer, less industrialized countries generally located south of the
developed countries; the counterpart of the North; see less developed countries (LDCs)
South Asian Association for Regional
Cooperation (SAARC)
address—P.0. Box 4222. Kathmandu.','cb19650c7d371fa53a642e7c583a0105acc424ae30fcf754f8b93ee4c0840bd7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c47d0b94f6d71e5cc7759b52717c466eb271824fffb5c8b4e61612b323f4e9a',1996,'CA','Canada','transportation',177,'Railways:
total: 70.176 km: note—there are two major
transcontinental freight railway systems:
Canadian National (privatized November
1995) and Canadian Pacific Ratlway:
passenger service provided by governnient-
opereted firm VIA, which has no trackage of
its own
standard gauge: 70.000 km 1.435-m gauge
(63 km electrified)
narrow gauge: 176 km 0.914-m gauge
(1995)
Highways:
total: 849,404 km
maved: 297.291 km (including 15.983 km of
expressways)
unpaved: 552.113 km (1991 est.)
Waterways: 3.000 km. including Saint
Lawrence Seaway
Pipelines: crude and refined oil 23.564 km:
natural gas 74,980 km
Ports: Becancour (Quebec). Churchill.
Halifax. Montreal, New Westminister. Prince
Rupert. Quebec. Saint John (New
Brunswick), Saint John’s (Newfoundland).
Seven Islands, Sydney. Three Rivers.
Thunder Bay, Toronto, Vancouver, Windsor
Merchant marine:
total: 62 ships (1,000 GRT or over) totaling
573.089 GRT’804.436 DWT
ships by type: bulk 17. cargo 9, chemical
tanker 4, oil tanker 15, passenger 2.
passenger-cargo |, railcar carrier 2. roll-on/
roll-off cargo 7, short-sea passenger 3.
specialized tanker 2
note: does not include ships used exclusively
in the Great Lakes (1995 est.)
Airports:
total: 1,138
with paved runways over 3,047 m: 17
with paved runways 2,438 to 3,047 m: 15
with paved runways 1,524 to 2,437 m: 136
with paved runways 914 to 1,523 m: 226
with paved runways under 914 m: 422
with unpaved runways 1,524 to 2.437 m: 53
with unpaved runways 914 to 1,523 m: 269
(1995 est.)
Heliports: |4 (1995 est.)
Railways: © kin
Highways:
total: 800 km
paved: SOO km
unpaved: 300 km
Ports: Portsmouth. Roseau
Merchant marine: none
Airports:
total: 2
with paved runways 914 te 1,523 im |
with paved runways under Y¥14 me | (1995
est.)','f357bf552cd2747fc3973b7e51a9a2e2aeea9ad102178ee4903e303ebbebac5f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a4cdf311b7227387a747bbbf6e12f774a6872cafd18ef0ce2747dd15b5b3aa3',1996,'CF','Central African Republic','transportation',192,'Railways: |) km
Highways:
total: 23,738 km
paved: 427 km
unpaved: 23.311 km (1991 est.)
Waterways: 800 km: traditional trade
carried on by means of shallow-dratt
dugouts; Oubangui is the Most important
river
Ports: Bangui. Nola
Airports:
total: 48
with paved runways 2.438 to 3.047 m: |
with paved runways 1,524 to 2,437 m: 2
with paved runways under 914m: 11
with unpaved runways 2,438 to 3,047 m: |
with unpaved runways 1,524 to 2.437 m: 9
with unpaved runways 914 to 1,523 m: 24
(1995 est.)','240c87157faf344e29453c254cf94c126ef01d1970fb1964f0e64c70caaef8a1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f14001b2329ad038b4080e53e713a570b81af2b911280e3d11a6df329d0d9ac',1996,'CG','Congo','transportation',197,'Railways: 0 km
Highways:
total: 31.141 km
paved: 32 km
unpaved: 31.109 km (1987 est.)
Waterways: 2.000 km navigable
Ports: none
Aim ports:
total: 47
with paved runways 2,438 to 3,047 m: 3
with paved runways 1,524 to 2,437 m: |
with paved runways under 914 m: 11
with unpaved runways over 3,047 m: |
with unpaved runways 1,524 to 2,437 m: 13
with unnaved runways 914 to 1,523 m: 18
(1995 est.)
Commu: ications
Telephones: 5.000 (1987 est.)
Telephone system: primitive system
domestic: tar system of radiotelephone
communication stations
imternational: satellite earth station— |
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 6. FM |.
shortwave (
Radios: NA
Television broadcast stations: | (1987 est.)
note: ymited TV service: many facilities are
inoperative
Televisions: 7.000 (1991 est.)
Defense
Branches: Armed Forces (includes Ground
Force. Air Force, and Gendarmerie).
Republican Guard, Police
Manpower availability:
males age 15-49; 1.562.052
males fit for military service: 809.210
males reach military age (20) annually:
63.254 (1996 est.)
Defense expenditures: exchange rate
conversion—$74 million, 11.1% of GDP
(1994;
105
CENTRAL AFRICAN
REPUBLIC
CAMERCGON
~Owande
Railways:
total: 795 km (1995 est.)
narrow gauge: 79S km 1.067-m gauge
(includes 285 km that are privately owned)
Highways:
total: 12.745 km
paved 1.236 km
unpaved: 11.509 km (1992 est.)
Waterways: the Congo and Ubang
(Oubangui) Rivers provide 1.120 km ot
commercially navigable water transport:
other rivers are used for local traffic only
Pipelines: crude oil 25 km
Ports: Brazzaville. Imptondo. Quesso, Oyo,
Pointe-Noire
Merchant marine:
total: | cargo ship (1.000 GRT or over)
totaling 2.218 GRT/4.100 DWT (1995 est.)
Airports:
totel: 34
veil, paved runways over 3,047 m: |
with paved runways 1,524 to 2,437 m: 3
with paved runways under 914 m: 9
with unpaved runways 1,524 to 2,437 m: 7
with unpaved runways 914 to 1,523 m: 14
{ 1Y9OS est.)','9421056e0302c301d87915f7fca27249e7d118164aab3d7473d7fe0d8c66b11f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('063206494474a63576bff1748ac912cdde6bcbd3954bcb07bda312a8b6db8832',1996,'PE','Peru','transportation',198,'BOLIVIA
Anca
iquique®
Antotagasta® PARAGUAY
isla San Si
a Chafaral®
isia
San Fehx
La Serena,
Vaipararso, gANTIAGO
San Antonio* . |
.. ° Rancagua
Archupielago Juan
Fernander § ARGENTINA
;'' aicanuano
_* . .
Ounta Aranag .','92fb387b12da78f1442bf4c84596609dfb81978feb5469a5c22d7ba9eb31e6e9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6272004655e999fcd59d226068b51e9569121404d96a439859292c43f5b73529',1996,'PF','French Polynesia','transportation',211,'Ports: none. offshore anchorage only
Defense
Defense note: defense is the responsibility
of France','c1a6116e2a7d0361f60076f440d0d4c455ec0e5f32c5b4156fc34d95c3411157','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45f56759a46e2a1a7142ab2bf321d4087fb4d40a2982fe290052d93f3cba2f83',1996,'CC','Cocos (Keeling) Islands','transportation',212,'(territery of Australia)
North Keating » .
tetanic
Morse
wang
Owecngn tsiand
‘
: Home (Sand
South \\
Keolng .
islands isiang 5
Fan + South tsiand
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: none: lagoon anchorage only
Merchant marine: - »nec
Airports:
total: |
with paved ranwavs 1,524 to 2.437 m: |
(1995 est.)','606a42f9b9d9106fe6ec4a0f52f8ea1b4030c21b3f226b00c7fb0c22d5216c22','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7194b09ca854ecc3aac0b7a19d75a1daa6b9aa3068355a94da9dde628c42b019',1996,'CO','Colombia','transportation',223,'Railways:
386 km
f gauges 130 km 1.435-m gauge
nects Cerreyon coal mines to maritime
t Bahia Portete)
ige 3.236 km 0.914-m gauge
S30 km in use) (1995)
107.200) km
paved. 12.600 km
mpaved: 94.600 km
Waterways: {4.300 km. navigable by rivet
Doats
Pipelines: crude oil
products $.350 km: natural gas 830 kim:
3.585 km: petroleum
natural gas liquids 125 km
Ports: Bar anguilla. Buenaventura.
Cartagena. Leticui. Puerto Bolivar. San
Andres. Santa Marta. Tumaco. Turbo
Merchant marine:
total: 19 ships (1.000 GRT or over) totaling
97.037 GRT/) 29.404 DWI
ships by type. bulk 5. cargo 8. Container 3,
oil tanker 3 (1995 est.)
Airports:
totai: 989
with paved runways over 3.047 m
with paved runways 2.488 to 3.047 m9
with paved runways 1,524 to 2.437 m: 33
with paved runways 914 to 1,523 m. 35
with paved runways under 914m: S57
with unpaved runways 2,438 to 3.047 m. |
with unpaved runways 1,524 to 2.437 m. 4)
with unpaved runways 914 to 1,523 me 311
(1995 est.)
aim—to provide a forum for largest debtor
nations in Latin America
members—(11) Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic, Ecuador,
Mexico, Peru, Uruguay, Venezuela
Group of 15 (G-15)
note—byproduct of the Non-Aligned
Movement
address—Technical Support Facility, Ch du
Champ d’Ancier 17, Case postale 326,
CH-1211 Geneva 19, Switzerland
telephone—{41] (22) 798 42 10
FAX—(|41] (22) 798 38 49
established—September 1989
aim—to promote economic cooperation
among developing nations; to act as the
main political organ for the Non-Aligned
Movement
members—(15) Algeria, Argentina, Brazil, Egypt, India, Indonesia, Jamaica, Malaysia,
Mexico, Nigeria, Peru, Senegal, Venezuela, Yugoslavia, Zimbabwe
573
Group of 19 (G-19)
established—NA October 1975
aim—to represent the interests of the less
developed countries (LDCs) that
participated in the Conference on
International Economic Cooperation (CIEC)
held in several sessions between NA
December 1975 and 3 June 1977
members—{ 19) Algeria, Argentina, Brazil, Cameroon, Egypt, India, Indonesia, Iran, Iraq,
Jamaica, Mexico, Nigeria, Pakistan, Peru, Saudi Arabia, Venezuela, Yugoslavia, Zaire,','2b68dd05746943f279ddb7e27bf2f74924a18f48515dae66cc4b22e6d389c604','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7628fb130f31c5948774487d5cd9ead23a0cdfcdfb5b391aa7050157f72e1332',1996,'KM','Comoros','transportation',231,'Railways: 0 km
110
Highways:
total: 1.104 km
paved: 400 km
704 km (1988 est)
Fombont, Moroni, Mutsamudu
unpaved
Ports:
Merchant marine: none
Airports:
total: 4
with paved runways 2.438 to 3,047 m: |
with paved runways 914 to 1,523 m: 3 (1995
est.)
© omimunications
3.770 (1991 est.)
Telephone system: sparse system ot
Telephones:
microwave radio relay and HF
radiotelephone communication stations
domestic: HE radiotelephone
communications and microwave radio relay
vuternational: HE radiotelephone
communicattons to Madagascar and Reunion
Radio broadcast siations: AM 2. FM |.
shortwave 0
Radios: NA
Television broadcast stations: ()
Televisions: 200 (1991 est)
Defense
Branches: Comoran Security Force
Manpower availability:
15-49; 121.854
males fit tor military service: 72.873 (1996
males ave
est.)
Defense expenditures: SNA. NAG of GDP','a2965c387581e0baa435325a1aa087408603814088d540e697ceec21c007902a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e30399f09c2bebbd5007ff009f0e15326d3a3f0651e426bd152332a0df5731c7',1996,'GA','Gabon','transportation',232,'rem
ome ZAIRE
*"Mossen ae
Loubome msdn i
a f Neay va .
:
es; ——
Nowe reed i 2H m
all
a >
telephone—({241}] 73 35 47, 73 35 48, 73
36 77
established—18 October 1983
aim—to promote regional economic
cooperation and establish a Central African
Common Market
members—(10) Burundi, Cameroon, Central African Republic, Chad, Congo, Equatorial
Guinea, Gabon, Rwanda, Sao Tome and Principe, Zaire
observer— 1) Angola
559
Economic Community of the Great members—(3) Burundi, Rwanda, Zaire
Lakes Countries (CEPGL)
note—acronym from Communaute
Economique des Pays des Grands Lacs
address—B.O. Box 58. Gisenyi, Rwanda
telephone—| 250} 40228
FAX-—{250] 40785
established—26 September 1976
aim—to promote regional economic
cooperation and integration
Economic Community of West African members— 16) Benin, Burkina Faso, Cape Verde, Cote d''Ivoire, The Gambia, Ghana,
States (ECOWAS) Guinea, Guinea-Bissau, Liberia, Mali, Mauritania, Niger, Nigeria, Senegal, Sierra Leone,
address—6 King George V Road, PMB Togo
12745, Lagos, Nigeria
telephone—| 234] (1) 636839, 636841,
636064, 630398
FAX—{234] (1) 636822
establiskhed—-28 May 1975
aim—to promote regional economic
cooperation
Economic Cooperation Organization members—(10) Afghanistan, Azerbaijan, Iran, Kazakstan, Kyrgyzstan, Pakistan, Tajikistan,
(ECO) Turkey, Turkmenistan, Uzbekistan
address—5 Hejab Avenue. Bd Keshavarz, associate member—{1) **Turkish Republic of Northern Cyprus”
P.O. Box 14155-6176, Teheran, Iran
Islamic Republic
telephone—{98} (21) 658614, 656152,
658945
FAX—{98] (21) 658046
established—NA 1985
aim—Ao promote regional cooperation in
trade, transportation, communications,
tourism, cultural affairs, and economic
telephone—|44] (71) 338 6000 Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Mexico, Moldova,
ap Morocco, Netherlands, NZ, Norway, Poland, Portugal, Russia, Romania, Slovakia, Slovenia,
FAX—(44] (71) 338 6100 Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan:
established—\\5 April 1991 includes all 25 meinbers of the OECD; also includes the EU as a single entity
aim—Ao facilitate the transition of seven
centrally planned economies in Europe
(Bulgaria. former Czechoslovakia, Hungary,
Poland. Romania, former USSR, and
former Yugoslavia) to market economies
by committing 60% of its loans to
privatization
development
European Bank for Reconstruction and members— 59) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus, Belgium, Bulgaria,
Development (EBRD) Canada, Croatia, Cyprus, Czech Republic, Denmark, Egypt, EU, European Investment Bank :
address—One Exchange Square, London (EIB), Estonia, Finland, France, Georgia, Germany, Greece, Hungary. Iceland, Ireland, Israel,
EC2A 2EH. UK Italy, Japan, Kazakstan, South Korea, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
European Community (or European was established 8 April 1965 to integrate the European Atomic Energy Community
Communities, EC) (Euratom), the European Coal and Steel Community (ESC), the European Economic
Community (EEC or Common Market), and to establish a completely integrated common
market and an eventual federation of Europe; merged into the European Union (EU) on
7 February 1992; member states at the time of merger were Belgium, Denmark, France,
Germany, Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association members—(4) Iceland, Liechtenstein, Norway, Switzerland
(EFTA)
address—9-11 rue de Varembe, CH-1211
Geneva 20, Switzerland
telephone—{41] (22) 749 11 11
FAX—(41] (22) 733 92 91
established—4 January 1960
effective—3 May 1960
aim—to promote expansion of free trade
European Investment Bank (EIB) members—{15) Austria, Belgium, Denmark, Finland, France, Germany. Greece, Ireland, Italy.
address—Bd Konrad Adenauer 100. Luxembourg, Netherlands, Portugal, Spain, Sweden, UK
L-2950 Luxembourg, Luxembourg
telephone—{352] 43791
FAX—{352] 437704
established—25 March 1957
effective—1 January 1958
aim—to promote economic development of
the EU
European Organization for Nuclear members— 19) Austria, Belgium, Czech Republic, Denmark, Finland, France, Germany.
Research (CERN) Greece, Hungary, Italy, Netherlands, Norway, Poland, Portugal, Slovakia. Spain, Sweden.
note—acronym retained from the Switzerland, UK
predecessor organization Conseil Europeen observers—{6) EV, Israel, Russia, Turkey, United Netions Educational. Scientific. and
pour la Recherche Nucleaire Cultural Organization (UNESCO), Yugoslavia (suspended)
address—CH-1211 Geneva 23, Switzerland
telephone—{41] (22) 767 61 11
FAX—{41] (22) 767 65 55
established—\\ July 1953
effective—29 September 1954
aim—to foster nuclear research for
peaceful purposes only
European Space Agency (ESA) members—(14) Austria, Belgium, Denmark, Finland, France, Germany, Irelanc. italy,
address—8-10 rue Mario Nikis. F-75738 Netiverlands, Norway, Spain, Sweden, Switzerland, UK
Paris CEDEX 15, France cooperating state—( 1) Canada
telephone—[33] (1) 42 73 76 54
FAX—{33] (1) 42 73 75 60
established—3\\ July 1973
effective—| May 1975
aim—to promote peaceful cooperation in
space research and technology
561
European Union (EU)
note—evolved from the European
Community (EC)
address—cio European Commission, Rue
de la Loi 200, B-1049 Brussels. Belgium
telephone—| 32] (2) 299 11 11
FAX—{32) (2) 295 O1 38 through 295 01
40
established —7 February 1992
November 1992
aim—te coordinate policy among the 15
members in three tields: economics,
building on the European Economic
Community s (EEC) efforts to establish a
common market and eventually a common
efiective-—-|
currency (European Currency Units—ECU);
detense. within the concept of a Common
Foreign and Security Policy (CFSP): and
justice and home affairs, including
immigration. drugs. terrorisin, and
improved living and working conditions
members—( 15) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy,
Luxembourg, Netherlands, Portugal, Spain, Sweden, UK
membership applicants— 12) Albania, Bulgaria, Cyprus, Czech Republic, Estonia, Hungary,
Latvia, Lithuania, Malta, Poland, Romania, Slovakia
First World
another term for countries with advanced, industrialized economies; this term is fading from
use: see developed countries (DCs)
Food and Agriculture Organization
(FAQ)
address—Viale delle Terme di Caracalla,
1-00100 Rome, Italy
telephone—|3°| (6) 52251
FAX—(39] (6) 5225 3152, 5225 5155, 578
2616
established—16 October 1945
aim—to raise living standards and increase
availability of agricultural products, as a
UN specialized agency
members—( 175) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina,
Armeria, Austra!ta, Austria, Azerbaijan, The Bainamas, Bahrain, Bangladesh, Barbados.
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Congo, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic. Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea.
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya. North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, L-.via, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe,
Saudi Arabia, Senecai, Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands.
Somalia, South Afnca, Spain, Sri Lanka, Sudan. Suriname, Swaziland. Sweden, Switzerland.
Syria, Tajikistan, Tanzania, Thaland, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey.
Turkmenistan, Uganda, UAE, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Western
Samoa, Yemen, Yugoslavia (suspended), Zaire, Zambia, Zimbabwe
associate member—(1) Puerto Rico
Former USSR/Eastern Europe (former
USSR/EE)
the middle group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe
(former USSR/EE), and less developed countries (LDCs): these countries are in political
and economic transition and may well be grouped differently in the near future; this group
of 27 countries consists of Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakstan, Kyrgyzstan, Latvia,
Lithuania, The Former Yugoslav Republic of Macedonia, Moldova, Poland, Romania, Russia,
Serbia and Montenegro, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
Four Dragons
the four small Asian less developed countries (LDCs) that have experienced unusually rapid
economic growth; also known as the Four Tigers; this group includes Hong Kong, South
Korea, Singapore, Taiwan
562
57/
Four Tigers
another term for the Four Dragons; see Four Dragons
Franc Zone (FZ)
uddress—Direction Generale des Service
Etrangers (Service de la Zone Franc),
Banque de France, 39 rue Crois-des-Petits-
Champs, BP 140-01, Paris CEDEX 01,','2eb994d546da58a42a4a127ee0bca468d94672ff309b5192bcaca07b8a26e2df','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c714fbbc0f0c679653685f263365a9a7a24b412067766a8eeea8bb06058b7b6',1996,'CK','Cook Islands','transportation',244,'Railways: 0 km
114
Highways:
total: 187 km
paved 35 km
unpaved: 152 km (1980 est.)
Ports: Avarua. Avatiu
Merchant marine:
total. 1 cargo ship (1.000 GRT or over)
totaling 1.464 GRT/2.181 DWT (1995 est.)
Airports:
total. 7
with paved runways 1,524 to 2.437 m: |
with unpaved runways 1,524 to 2,437 m: 3
with unpaved runways 914 to 1,523 m: 3
(1995 est.)','7df1edb70e4d8240c299722964f06f483be9db81f58e0958bb1927cfe40d6fa0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5a1a4372f38be27ffad12ed4bd20cecbbdba1e6f3e2fb4613d8b7fa7eb9b0e2',1996,'NI','Nicaragua','transportation',245,'Pavawe
Railways:
total: 950 km
narrow gauge: 950 km 1.067-m gauge (260
km electrified)
note: the entire system was scheduled to be
shut down on 31 June ''995 because of
insolvency
Highways:
total: 35,560 km
paved: 5.608 km
unpaved: 29,952 km (1992 est.)
Waterways: about 730 km. seasonally
navigable
Pipelines: petroleum products 176 km
Ports: Caldera. Golfito, Moin, Puerto
Limon. Puerto Quepos, Puntarenas
Merchant marine: none
Airports:
total: 145
with paved runways 2,438 to 3,047 m: 2
with paved runways 1,524 to 2,437 m: |
with paved runways 914 to 1,523 m: \\6
with paved runways under 914 m: 97
with unpaved runways 914 to 1,523 m: 29
(1995 est.)','e2e11ccc37dd3b9a17d4245d161abf2431845fcbc2af5a43f14da88cce85a995','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4de7aa7791d305324e0ad8dc44d2cf5daa5870ccbbfb7b580d5249c171b48e50',1996,'MX','Mexico','transportation',258,'Railways:
total: 660 km (1995 est.)
narrow gauge: 660 km 1.000-meter gauge:
25 km double track
Highways:
total; 46.331 km
paved: 3,579 km
unpaved: 42,752 km (1984 est.)
Waterways: 980 km navigable rivers.
canals, and numerous coastal lagoons
Ports: Abidjan. Aboisso, Dabou, San-Pedro
Merchant marine:
total: 3 ships (1.000 GRT or over) totaling
27.726 GRT/34.711 DWT
ships by type: container 2. oil tanker | (1995
est.)
Airports:
total: 35
with paved runways over 3,047 m: \\
with paved runways 2,438 to 3,047 m: 2
with paved runways 1,524 to 2,437 m: 4
with paved runways under 914 m: \\0
with unpaved runways 1,524 to 2,437 m: 6
with unpaved runways 914 to 1,523 m: 12
(1995 est.)
Railways:
total: 2,835 km (in addition, there are 224
km not restored to service after war damage)
standurd gauge: 151 km 1.435-m gauge
narrow gauge: 2.454 km 1.000-m gauge
other gauge: 230 km NA-m dual gauge
(three rails)
Highways:
total: 105,000 km
paved: 10,500 km
unpaved: 94,500 km (1993 est.)
Waterways: 17.702 km navigable: more
than 5,149 km navigable at all times by
vessels up to 1.8 m draft
Pipelines: petroleum products 150 km
Ports: Da Nang. Haiphong. Ho Chi Minh
City, Hon Gai, Qui Nhon, Nha Trang
Merchant marine:
total: 112 ships (1,000 GRT or over) totaling
569,269 GRT/947,938 DWT
ships by type: bulk 3, cargo 95, oil tanker
10, refngerated cargo 3, roll-on/roll-off cargo
|
note; Vietnam owns an additional 9 ships
(1,000 GRT or over) totaling 120.320 DWT
operating under the registries of Honduras,
Panama, The Bahamas, and Malta (1995 est.)
Airports:
total: 48
with paved runways over 3,047 m: 8
with paved runways 2,438 to 3.047 m: 3
with paved runways 1,524 to 2,437 m: §
with paved runways 914 to 1,523 m: 13
with paved runways under 914 m: 7
with unpaved runways 1,524 to 2,437 m: 2
with unpaved runways 914 to 1,523 m: §
with unpaved runways under 914 m: 5 (1994
est.)','a946c149d2986b2e644c457a344e72591de875f705f4c94677cc58fbdc69add9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb015a5a1668fdf1239e2d45392193e223303b64d5a824c6fc01f17028a412c3',1996,'HU','Hungary','transportation',265,'Railways:
total: 2,699 km
standard gauge: 2.699 km 1.435-m gauge
(1213 km electrified)
note: disrupted by territorial dispute with
Serbia (1994)
Highways:
total: 27,378 kim
paved: 22,176 km (including 302 km ot
expressways)
unpaved: 5,202 km (1991 est.)
Waterways: 785 km perennially navigable
Pipelines: crude oi! 670 km: petroleum
products 20 km: natural gas 310 km (i992):
note—under repair following territorial
dispute
Ports: Dubrovnik. Omisalj, Ploce. Pula.
Rijeka, Sibenik. Solit. Zadar
Merchant marine:
total: 39 ships (1.000 GRT or over) totaling
203.495 GRT/252.818 DWT
ships by type: bulk 2. cargo 23. chemical
tanker 1, container 3. oi] tanker 1. passenger
2. refrigerated cargo |. roll-on/roll-ott cargo
2, short-sea passenger 4
note: Croatia owns an additional 140 ships
(1.000 GRT or over) totaling 3.368.035
DWT operating under the registries of Malta.
Liberia. Cyprus, Panama, Antigua and
Barbuda. The Bahamas, and Saint Vincent
and the Grenadines (1995 est.)
Airports:
total: 68
with paved runways over 3,047 m: 2
with paved runways 2.438 to 3.047 m: 6
‘
with paved runways 1,524 to 2.437 m: 2
with paved runways 914 to 1,523 m: 3
with paved runways under 9]4 m- 47
with unpaved runways 1,524 to 2,437 m: |
with unpaved runways 914 to 1,523 m7
(1995 est.)
Heliports: 2 (1995 est.)
Railways:
total: 7.685 km
broad gauge: 35 km 1.524-m gauge
standard gauge: 7.474 km 1.435-m gauge
(2.162 km electrified: 1.236 km double
track)
narrow gauge: 176 km mostly 0.760-m
gauge (1995)
note: Hungry and Austria jointly manage the
cross-border standard-gauge railway between
Gyor, Sopron, Fbenfurti. and Vasut. a
distance of about 100 kin
Highways:
total: \\S8.711 km
paved: 69.992 km (including 441 km of
expressways)
unpaved: 88.719 km (1992 est.)
Waterways: |.622 km (1988)
Pipelines: crude oi] 1.204 km: natural gas
4.387 km (1991)
Ports: Budapest. Dunaujvaros
Merchant marine:
total: 10 cargo ships (1.000 GRT or over)
totaling 46.121 GRT/61.613 DWT (1995
est.)
Airports:
total: 78
with paved runways over 3,047 m: 2
with paved runways 2,438 to 3,047 m: 7
with paved runways 1,524 to 2,437 m: 4
with paved runways under 914 m: |
217
Hungary (continued) Iceland Environment: BO
. current issues. water pollution from fertilizer
runoff: inadequate wastewater treatment
natural hazards: earthquakes and volcanic
ied runways 2 438 io 304, Mn. 7
naved runways 1,524 to 2,437 m: 9
_ activily
unpaved runways 914 to 1,523 m: 1A
iuernanonal agreements: party to—Alr
Pollution, Biodiversity, Climate Change.
Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands: signed, but not
ratitied—Environmental Modification.
naved runwavs under 914 m: 34
( ommunications
Gnmsey .Rautarhoin Hazardous Wastes. Marine Life Conservation
tclephones: | 52 million (1993 est.) ee, F Geographic note: strategic location between
j lephone system: 14.213 telex lines: 7 snseun® — Greenland and Europe: westernmost
telephone network based on Seyahistéranu” European country; more land covered by
radio relay system: 608.000 glaciers than in all of continental Europe
es on order: 12-15 year wait tor a NB re vKoavix ete BS
4$9%¢ of all telephones are in Senav''<” Halrasiron
t ( 199] est.) note—the former stite vestmannaeyiar, People
elecommunications firm MATAV _ ;
. a 1 aero hs Population: 270.292 uly 1996 est.)
rh atized 4 4 “ v : \\ ‘ S/ >
a Sn ae tt note: population data estimates based on
, My -hi ‘ Vi . . ;
— has ambitious plans to average growth rate may differ slightly from
he Inadequate system, including a official population data because of volatile
ct with the German firm Siemens and ; _—. ate
siwiriech feean as _ 1. Geography migration rates
wedish tirm Eniesson to provide Age structure:
100 new phone lines during 1996-98 Location: Northern Europe. island between 0-14 vears: 24% (male 33.605: female
mest microwave radio relay ihe Greenland Sea and the North Atlantic 31.933)
onal: satellite earth stations— | Ocean. northwest of the UK 15-64 vears: 64% (male 88.064; female
Intelsat and [ Intersputmk (Atlantic Ocean Geographic coordinates: 69 ON. 18 vu ¥. 85.724)
Region) Map references: Arctic Region 65 vears and over: 12% (male 13.916:
Radio broadcast stations: AM 32. FM 15, nee: female 17.050) July 1996 est.)
shortwave 0 total area: 103.000 sq km Population growth rate: 0.83°¢ (1996 est.)
: 7 land area: 100.250 sq km : ate: 16 ¢
Radios: 6 million (1993 est) — 4 Birth rate: 16.94 births/1.000 population
i” comparative area: slightly smaller than (1996 est.)
Pelevision broadcast stations: 41 (Russian ae |
Kentucky Death rate: 6.17 deaths/1.000 population
epealers & .
Land boundaries: () km (1996 est.)
Pelevisions: 438 million (1993 est.) : «ae 1 ; .
Coastline: 4.988 kiu Net migration rate: -2.5 migrant(s)/1.000
Nlaritime ciaims: population ( 1996 est.)
continental shelf: 200 nm or to the edge otf Sex ratio:
the continental margin at birth: 1.05 male(s)/female
Defense 7 ) - a
exclusive economic zone: 200 nm under 15 vears: 1.05 male(s)/temale
Branches: Ground rorces, Air and Aur territorial sea: 12 nm 12-64 vears: 1.03 male(s)/female
Forces. Border Guard. Territorial International disputes: Rockall continental 65 vears and over: 0.82 male(s)/female
shelf dispute involving Denmark, Ireland. all ages: 1.01 male(s)/female (1996 est.)
\\ianpower availability: and the UK (lreland and the UK have signed infant mortality rate: 4.3 deaths/1,000 live
19 2552-794 a boundary agreement in the Rockall area) birti:s (1996 est.)
military service: 2.036.399 Climate: temperate: moderated by North Life expectancy at birth:
cach miliary age (18) annually Atlantic Current: mild. windy winters: damp. total population: 80.08 years
1006 est cool summers male: 77.68 vears
; Terrain: mos''iy plateau interspersed with female: 82.6 vears (1996 est.)
Defense expenditures: exchange rate ; - eee
1) mill! is + GDP mountain peaks. icetields: coast deeply lotal fertility rate: 2.24 children born/
SOU mititon. boo Of G :, : .
indented by bays and fiords woman (1996 est.)
lowest point: Atlantic Ocean 0 m Nationality:
highest point: Hvannadalshnukur 2.119 m noun: Ieelander(s)
Natural resources: fish, hydropower. adjective: Ieelandic
geothermal power, diatomite Ethnic divisions: homogeneous mixture of
Land use: descendants of Norwegians and Celts
arable land: \\% Religions Evangelical Lutheran 96%, other
permanent crops: 0% Protestunt and Roman Catholic 3%, none 1%
meadows and pastures: 20% (1988)
forest and woodland: \\% Languages: Icelandic
other: 78% Literacy: age 15 and over can read and
Irrigated land: NA sg km write (1976 est.)
total population: 1\\OO%
male: NA%
female: NA%
Railways: 0 ki
Highways:
TTL S SOU kim OY) est.)
Ports: Akur Hornatiordur, [satyordur.
Keflavik. Rautarhoin, Reykjavik.
Sevdhistjordhur, Straumsvik. Vestmannaey jai
Merchant marine:
total: 6 ships 1.000 GRI
30.025 GRT/40.410 DWT
or over) totaling
ships by type: cargo |. chemical tanker 1. o1]
tanker |. refrigerated cargo 1. roll-on/roll-off
cargo 2 (1995 est.)
Airporis:
total: &4
with paved runways over 3,047 me 4
with paved runways 1,524 to 2.437 m: 3
with paved runways 914 to 1523 m. §
with paved runways unaer 914m 49
with unpaved runways 1,524 1
with unpaved runway. 914 to 1,523 m
(1995 est.)
Roilways:
total: 18961 kin
standard gauge: 17.981 km 1.435-m gauge:
ltalian Railways (FS) operates 16.118 km of
the total standard gauge routes (10.560 km
electrified)
narrow gauge: 113 km 1L000-m gauge ( 113
km electrified): 867 km 0.950-m gauge (144
km electrified)
Highways:
total: 305.388 km Gncluding 45.076 km
major roads, 112.111 km secendary roads
6.301 km motorways)
paved: 271.674 km
unpaved: 33.714 km (1991 est.)
Waterways: 2.400 km for various types of
commercial traffic. although of limited
overall value
Pipelines: crude oi! 1.703 km: petroleum
products 2.148 km: naturai gas 19.400 km
Ports: Ancona. Augusta, Ban. Caghan
(Sardinia). Catama. Gaeta, Genoa, La Spezia.
Livorno, Naples. Oristano (Sardinia)
Palermo (Sicily). Prombino, Porto Torres
(Sardinia). Ravenna, Savona, Trieste. Venice
Merchant marine:
otal: 419 ships (1.000 GRT of over) totaling
§ 480 200 GRT/7.919.064 DWT
ships by type: bulk 3S, cargo $7. chemical
tanker 39. combination bulk |. combination
ore/oil 3. contamer 16. liquetied ga. tanker
37. multifunction large-load carner 1. on!
tanker 123 passenger > roll-on/roll-otf
cargo 53. short-sea passenger +] Sper malized
tanker 11. vehicle carnmer 7 (1995 sst)
Airports:
wntal: 132
with paved runways over 3.047 m: §
1 wth paved Previa % J Ji ln ; tid / yr Y<§
with paved runways 1,524 to 2,437 m: 15
with paved runways 914 to 1,523 m: 24
with paved runways under 914 m. 32
with unpaved runways 1,524 to 2.437 m: 2
with unpaved runways 914 to 1,523 m: 20
(1995 est.)
Meliports: 2 (1995 est)','76fa91116a058e735e58c6a41d7bb1d540e567c59a9c0e9394cd51396f1fe201','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69bc4c2d501e10d71f032991daeb4b757768943723e4a53d5a7da1ea703c7a59',1996,'CH','Switzerland','transportation',272,'Railways:
I 4.677 km
tidard gtuge. 4.677 km 1.435-m gauge
132 kim clectritied)
nore large amount of track Is In private
lise DY ‘ur plantations
Hoy ways:
foltal. ZO Ma kim
pared: tA km
} ‘5 '' ‘
unpaved: t1).925 km (1996 est.)
Waterways: 240 km
Ports: Crentuegos, La Habana, Manzanillo.
Manel. Matanzas, Nuevitas, Santiago de
Cu
Vierchant marine:
}} Ships (1.000 GRT or over) totaling
70 GRT/3 10.169 DWT
cargo 17, chemical tanker 1.
1s by type
liquefied gas tanker 4. oil tanker 9.
passenger-cargo |. refngerated cargo 9
ve Cuba owns an addstional 47 ships
WW GRT or over) totaling 462.517 DWT
erating under the registries of Panama,
Cyprus. Malta. Belize. and Mauritius (1995
\\irports:
fat. {Sh
i paved runways over 3,047 rie 7
paved runwavs 2.438 to 3,047 m: 7
paved runways 1,524 to 2,437 m: 14
ed runwavs Y1l4 to 1,523 m: 9
runways under 914 m: &7
with unpaved runways 1,524 to 2,437 m: |
nin paurved
| precedes
vith unpaved runways G14 to 7, 23 m: 31
( 1GUOS est.)
Railways:
8.719 km (1.432 km double track)
Vandard Cue SOR An ‘S-M Cauce
Ww clectnitied. 410 kim m emment
\\A ed
aaa Ville ve *s4 aT (kM eon
—"y Mectniticd Ss)
mined
‘te? |* ar NA si ws
Highways:
7] XR kn
ed? SAN rhe HUT Si4 An
expre sways
mpaved 0 km (19? est
Waterways: 6 km. Rhine (Bas
Rheinfelden. Schatfhausen to Bodense
navigable lake
Pipelines: crude oil 414 4 Aural gas
1.506 ka
Ports: Base!
Merchant marine:
wital: 23 ships (1.000 GRT or over) totaling
10.581 GRT/727,744 DWT
sups by type bulk 14 cargo |, chemmeal
tanker 4, ol tanker 2. roll-on/roll-off carg
1, specialized tanker | (1995 est.)
Airports:
total: 67
with paved runways over 3,047 m: 4
with paved runway 2.438 to 3,047 m: 4
with paved runways 1,524 to 2.437 m: \\2
with paved ranways 914 io 1,523 m: §
with paved runways under 914 m: 4
;
with unpaved runways 914 to 1,523 m: |
(1995 est.)
Railways:
total: 1,998 km
broad gauge: 1,766 km 1.435-m gauge
narrow gauge: 232 km 1.050-m gauge
Highways:
total: 31,569 km
paved: 24,308 km (including 712 km of
expressways)
unpaved: 7,261 km (1991 est.)
Waterways: 870 km; minimal economic
importance
Pipelines: crude oil 1,304 km: petroleum
nroducts 515 km
Ports: Baniyas, Jablah, Latakia, Tartus
Merchant marine:
total: 99 ships (1,000 GRT or over) totaling
294,355 GRT/454,990 DWT
ships by type: bulk 12, cargo 85, livestock
carrier 1, vehicle carrier 1 (1995 est.)
Airports:
total: 99
with paved runways over 3,047 m: 5
with paved runways 2,438 to 3,047 m: 15
with paved runways 1,524 to 2,437 m: |
with paved runways 914 to 1,523 m: |
with paved runways under 914 m: 62
with unpaved runways 1,524 to 2,437 m: 2
with unpaved runways 914 to 1,523 m: 13
(1995 est.)
Heliports: 2 (1995 est.)
Railways:
total: 23,350 km
broad gauge: 23,350 km 1.524-m gauge
(8,600 km electrified)
Highways:
total: 169,964 km
paved: 168,094 km (including 1,767 km of
expressways)
unpaved: 1,870 km (1992 est.)
wae <pagtiagtes
Waterways: 4,400 km navigable waterways,
of which 1,672 km were on the Pryp’’yat’
and Dnipro (1990)
Pipelines: crude oil 2,010 km; petroleum
products 1,920 km; natural gas 7,800 km
(1992)
Ports: Berdyans’k, Illichivs’k, Izmayil,
Kerch, Kherson, Kiev (Kyyiv), Mariupol’,
Mykolayiv, Odesa, Pivdenne, Reni
Merchant marine:
total: 353 ships (1,000 GRT or over) totaling
3,262,341 GRT/4,356,374 DWT
ships by type: barge carrier 5, bulk 39, cargo
217, chemical tanker 2, combination bulk 1,
container 11, multifunction large-load carrier
3, oil tanker 21, passenger 7, passenger-
cargo 5, railcar carrier 2, refrigerated cargo
5, roll-on/roll-off cargo 32, short-sea
passenger 3 (1995 est.)
Airports:
total: 706
with paved runways over 3,047 m: 14
with paved runways 2,438 to 3,047 m: 55
with paved runways 1,524 to 2,437 m: 34
with paved runways 914 to 1,523 m: 3
with paved runways under 914 m: 57
with unpaved runways over 3,047 m: 7
with unpaved runways 2,438 to 3,047 m: 7
with unpaved runways 1,524 to 2,-437 m: 16
with unpaved runways 914 to 1,523 m. 37
with unpaved runways under 914 m:; 476
(1994 est.)
telephone—{4\\| (22) 730 42 22
FAX—{41} (22) 733 03 95
established—S May 1919
aim—to organize. coordinate. and direct
international rehef actions: to promote
humanitarian activities; to represent and
encourage the development of National
Societies: to bong help to victims of
armed conflicts. refugees, and displaced
people: to reduce the vulnerability of
people through development programs
members—{ 169) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda.
Argentina. Armenia, Australia, Austna. Azerbaijan. The Bahamas. Bahrain, Bangladesh.
Barbados, Belarus. Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroca, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia. Congo, Costa Rica, Cote d''Ivoive, Croatia, Cuba, Czech
Republic, Denmark. Djibouti. Dominica, Dominican Republic, Ecuador, Egypt. El Salvador.
Equatorial! Guinea, Estonia, Ethiopia. Fiji, Finland. France. The Gambia, Germany, Ghana,
Greece, Grenada, Gustemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary.
iceland, India, Indonesia, Iran, Iraq. Ireland, italy. Jamaica, Japan. Jordan, Kenya, North
Korea, South Korea. Kuwait, Laos, Latvia, Lebanon, Lesotho, Libervia, Libya, Liechtenstein,
Lithuania, Luxembourg. The Former Yugoslav Republic of Macedonia, Madagascar, Malawi.
Malaysia, Mali, Malta, Mauritania. Mauritius. Mexico, Monaco, Mongolia. Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan.
Panama, Papua New Guinea, Paraguay. Peru, Philippines, Poland, Portugal, Qatar, Romania.
Russia, Rwanda. Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal. Seychelles, Sierra Leone.
Singapore. Slovakia, Slovenia, Solomon Isiands, Somalia, South Africa, Spain, Sri Lanka.
Sudan, Suriname. Swaziland, Sweden, Switzerland, Syria, Tanzania. Thailand, Togo, Tonga,
Trinidad and Tobago. Tunisia, Turkey, Turkmenistan. Uganda. Ukraine. UAE, UK. US,
Uruguay. Uzbekistan. Vanuatu, Venezaela, Vietnam. Western Samoa, Yemen, Yugoslavia,
Zaire, Zambia, Zimbabwe
associate members— 13) Andorra, Antigua and Barbuda, Comoros, Cyprus. Equatorial
Guinea, Gabon, Kinbati, Namibia, Saint Kitts and Nevis, Seychelles, Suriname. Tuvalu.
telephone—{41} (22) 799 61 11
FAX—{41] (22) 798 86 85
established—1\\1 April 1919 (affiliated with
the UN 14 December 1946)
aim—to deal with world labor issues: a
UN specialized agency
members— 173) Afghanistan, Albania, Algeria. Angola, Antigua and Barbuda. Argentina.
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain. Bangladesh. Barbados.
Belarus, Belgium. Belize, Benin, Bolivia, Bosnia anc Herzegovina, Botswana. Brazil.
Bulgaria. Burkina Faso, Burma. Burundi, Cambodia, “amercon. Canada, Cape Verde. Central
African Republic, Chad. Chile. China, Colombia, Comoros, Congo, Costa Rica, Cete d''Ivoire.
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic.
Ecuador. Egypt, El Salvador. Equatorial Guinea, Eritrea, Estonia. Ethiopia. Fiji. riniand.
France, Gabon, The Gambia, Georgia. Germany, Ghana, Greece, Grenada. Guatemala, Guinea
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary. Iceland, India, Indonesia. Iran, Iraq.
Ireland, Israel. Italy. Jamaica, Japan. Jordan, Kazakstan, Kenya, South Korca. Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia. Libya, Lithuania, Luxembourg. The
Former Yugoslav Republic of Macedonia, Madagascar. Malawi, Malaysia. Mali. Maita.
Mauritania, Mauritius, Mexico, Moldova, Mongolia. Morocco, Mozambique. Namibia, Nepal.
Netherlands. NZ, Nicaragua, Niger, Nigeria, Norway. Oman, Pakistan, Panama. Papua New
Guinea. Paraguay. Peru. Philippines, Poland, Portugal. Qatar. Romania, Russia. Rwanda, Saint
Lucia, Saint Vincent and the Grenadines, San Marino, Sao Tome and Principe. Saudi Arabia.
Senegal. Seychelles, Sierra Leone. Singapore. Slovakia, Slovenia. Solomon Islands, Somalia,
South Afnca. Spain, Sri Lanka. Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria.
Tajikistan, Tanzania, Thailand. Togo, Trinidad and Tobago. Tunisia, Turkey. Turkmenistan.
Uganda, U raine, UAE, UK. US, Uruguay. Uzbekistan. Venezuela. Vietnam. Yemen.
Yugoslavia (suspended), Zaire. Zambia. Zimbabwe
International Maritime Organization
(IMO)
note—name changed from
Iniergovernmental Maritime Consultative
Organization (IMCO) on 22 May 1982
udidress—4 Albert Embankment, London
SEI 7SR. UK
relephone—|44} (71) 735 7611
FAX—{44] (71) 587 3210
established—\\17 March 1958
wm—to deal with international maritime
alfairs; a UN specialized agency
members—( 152) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Brazil, Brunei, Bulgaria, Burma, Cambodia, Cameroon,
Canada, Cape Verde, Chile, China, Colombia, Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakstan, Kenya, North Korea, South Korea, Kuwait, Latvia,
Lebanon, Liberia, Libya, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Malta, Mauritania, Mauritius, Mexico, Monaco,
Morocco, Mozambique, Namibia, Nepal, Netherlands. NZ, Nicaragua, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania. Russia, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden,
Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago. Tunisia, Turkey,
Turkmenistan, Ukraine, UAE, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen,
Yugostavia (suspended), Zaire
associate members—(2) Hong Kong, Macau
International Maritime Satellite
Organization ‘Inmarsat)
see International Mobile Satellite Organization (Inmarsat)
International Mobile Satellite
Organization (Inmarsat)
nore—tormerly International Maritime
Satellite Organization
address—99 City Road, London ECLY
1AX. UK
fe lephone—|44] (71) 728 1000
FAX—|44] (71) 728 1044
established—3 September 1976
effective—26 July 1979
aim—to provide worldwide
communications for commercial, distress,
and safety applications, at sea, in the air,
and on land
members—(75) Algeria, Argentina, Australia, The Bahamas, Bahrain, Bangladesh, Belarus,
Belgium, Brazil, Brunei, Bulgaria, Cameroon, Canada, Chile, China, Colombia, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Egypt, Finland, France, Gabon, Georgia, Germany,
Greece, Iceland, India, Indonesia, Iran, Iraq, Israel, Italy, Japan, South Korea, Kuwait, Liberia,
Malaysia, Malta, Mauritius, Mexico, Monaco, Mozambique, Netherlands, NZ, Nigeria,
Norway, Oman, Pakistan, Panama, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saudi Arabia, Senegal, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Sweden,
Switzerland, Tunisia, Turkey, Ukraine, UAE, UK, US, Yugoslavia
53/
ore ee Ter eens
International Monetary Fund (IMF)
address—700 19th Street NW,
Washington, DC 20431, USA
telephone—{1} (202) 623 7000
FAX—{1] (202) 623 4661, 623 7491, 623
4662
established—-22 July 1944
effective—27 December 1945
aim-—-to promote world monetary stability
and economic development; a UN
specialized agency
members—(180) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia. Germany, Ghana, Greece. Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg. The Former Yugoslav
Republic of Macedonia, Madagascar, Maluwi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland.
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles.
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Western Samoa.
Yemen, Zaire, Zambia, Zimbabwe
International Olympic Committee (IOC)
note—there are 194 National Olympic
Committees of which 185 are recognized
by the International Olympic Committee
address—Chateau de Vidy, CH-1007
Lausanne, Switzerland
telephone—{41} (21) 621 61 11
FAX—{41] (21) 621 62 16
established—23 June 1894
aim—to promote the Olympic ideals and
administer the Olympic games: 1996
Summer Olympics in Atlanta, United
States (20 July-4 August); 1998 Winter
Olympics in Nagano, Japan (date NA);
2000 Summer Olympics in Sydney,
Australia (date NA); 2002 Winter
Olympics in Salt Lake City, United States
(date NA)
members—National Olympic Committees—( 194 and the Palestine Liberation Organization)
Afghanistan, Albania, Algeria, American Samoa, Andorra, Angola, Antigua and Barbuda.
Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan, The Bahamas, Bahrain.
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia
and Herzegovina, Botswana. Brazil. British Virgin Islands, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cameroon, Canada, Cape Verde, Cayman Islands, Central African Republic.
Chad, Chile, China, Colombia, Comoros, Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic.
Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France.
Gabo... The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea,
Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakstan, Kenya, North Korea, South Korea, Kuwait.
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, L-bya. Liechtenstein, Lithuania.
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia.
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mouaco, Mongolia.
Morocco, Mozambique, Namibia, Nepal, Netherlands, Netherlands Antilles, NZ. Nicaragua.
Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru.
Philippines, Poland, Portugal, Puerto Rico, Qatar, Reunion, Romani Russia. Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, San Marino. Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Taiwan, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Virgin Islands, Western Samoa. Yemen.
Yugoslavia (Serbia and Montenegro), Zaire, Zambia, Zimbabwe. Palestine Liberation
Organization
573
International Organization for Migration
(LOM)
note—established as Provisional
Intergovernmental Committee for the
Movement of Migrants from Europe:
renamed Intergovernmental Commitiee for
European Migration (ICEM) on i5
November 1952: renamed
Intergovernmental Committee for Migratior
(ICM) in November 1980: current name
adopted 14 November 1989
address—\\7 route des Mornillons, CP 71,
CH-i211 Geneva 19. Switzerland
telephone—{41] (22) 717 91 11
FAX—j41] (22) 798 61 50
established—5 December 1951
aim—to facilitate orderly international
emigration and immigration
members—55) Albaniz, Angola, Argentina, Armenia, Australia, Austria, Bangladesh,
Belgium, Bolivia, Bulgaria, Canada, Chile, Colombia, Costa Rica, Croatia, Cyprus, Denmark,
Dominican Republic, Ecuador, Egypt, El Salvador, Finland, France, Germany, Greece,
Guatemala, Haiti, Honduras, Hungary, Israel, Italy, Japan, Kenya, South Korea, Luxembourg,
Netherlands, Nicaragua, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal. Sr: Lanka, Sweden, Switzerland, Tajikistan, Thailand, Uganda, US, Uruguay,
Venezuela, Zambia
observers—(47) Afghanistan, Belarus, Belize, Bosnia and Herzegovina, Brazil, Cape Verde,
Czech Republic, Federation of Ethnic Communities’ Council of Australia Inc., Georgia,
Ghana, Guinea-Bissau, Holy See, India. Indonesia, Iran, Japan International Friendship and
Welfare Foundation, Jordan, Kyrgyzstan, Latvia, Liberia, Malta, Mexico, Moldova, Morocco,
Mozambique, Namibia, NZ, Niwano Peace Foundation, Partnership with the Children of
the Third World, Presiding Bishop''s Fund for World Relief/Episcopal Church, Refugee
Council of Australia, Romania, Russia, Rwanda, San Marino, Sao Tome and Principe,
Slovakia, Slovenia, Somalia, Spain, Sudan, Turkey, Ukraine, UK, Vietnam, Yugoslavia,
telephone—{41] (31) 350 31 11
FAX—{41] (31) 350 31 10
established—9 October 1874, affiliated
with the UN 15 November 1947
effective—i July 1948
aim—to promote internationai postal
cooperation; a UN specialized agency
members— 189) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda. Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil.
Brunei, Bulgaria, Burkina Faso, Burma, Burundi. Cambodia, Cameroon, Canada, Cape Verde.
Central African Republic, Chad, Chile, China, Colombia, Comoros, Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji.
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada.
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary. Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakstan. Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon. Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg. The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius.
Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique. Namibia, Nauru, Nepal.
Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway. Oman. Overseas
Territories of the UK, Pakistan, Panama, Papua New Guinea. Paraguay. Peru, Philippines.
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis. Saint Lucia. Saint
Vincent and the Grenadines, San Marino. Sao Tome and Principe. Saudi Arabia. Senegal.
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Airica, Spain, Sri Lanka, Sudan, Suriname, Swaziiand, Sweden. Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Totago. Tunisia, Turkey, Turkmenistan,
Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela.
Vietnam, Western Samoa, Yemen, Yugoslavia (suspended), Zaire. Zambia, Zimbabwe
Warsaw Pact (WP)
established 14 May 1955 to promote mutual defense: member: met | July 1991 to dissolve
the alliance: member states at the time of dissolution were Bulgaria. Czechoslovakia.
Hungary. Poland, Romania, and the USSR; earlier members included East Germany and
telephone—{4\\} (22) 730 9111
FAX—{41] (22) 733 5428
established—\\4 July 1967
effective—26 April 1970
aim—to furnish protection for literary.
artistic, and scientific works; a UN
specialized agency
members— 157) Albania, Algeria, Andorra, Angola. Argentina, Armenia. Australia, Austria,
Azerbaijan. The Bahamas. Bahrain, Bangladesh. Barbados. Belarus. Belgium. Benin. Bhutan,
Bolivia, Bosnia and Herzegovina, Brazil, Brunei, Bulgaria, Burkina Faso, Burund. Cambodia.
Cameroon, Canada, Central African Republic. Chad. Chile. China, Colombia. Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus. Czech Republic, Denmark. Dominican Republic.
Ecuador. Egypt. El Salvador, Estonia. Fiji, Finiand. France. Gabon. The Gambia. Georgia.
Germany. Ghana, Greece. Guatemala, Guinea. Guinea-Bissau, Guyana. Haiti. Holy See.
Honduras, Hungary. Iceland. India, Indonesia. Iran. Irag. Ireland. Israel, Italy. Jamaica. Japan.
Jordan, Kazakstan. Kenya, North Korea, South Korea. Kyrgyzstan, Laos. Latvia, Lebanon.
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxenibourg. The Former Yugoslay
Republic of Macedonia, Madagascar. Malawi, Malaysia. Mali, Malta, Mauritania, Mauritius.
Mexico, Moldova, Monaco, Mongolia, Morocco, Namibia. Netherlands, NZ. Nicaragua. Niger.
Nigeria, Norway, Pakistan, Panama. Paraguay, Pers. Philippines, Poland. Portugal, Qatar.
Romania. Russia, Rwanda, Saint Kitts and Nevis. Saint Lucia, San Marino, Saudi Arabia.
Senegal. Sierra Leone. Singapore. Slovakia, Slovenia. Somalia, South Africa, Spain, Sn
Lanka, Sudan, Suriname. Swaziland, Sweden, Switzeriand. Tajikistan. Tanzania. Thailand
Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine. UAE. UK. US, Uruguay.
Uzbekistan, Venezuela. Vietnam, Yemen. Yugoslavia (suspended), Zaire. Zamina, Zimbabwe
World Meteorological Organization
WMO)
Jdress—Case Postale 2300, 41 Av
Giuseppe-Motta, CH-1211 Geneva 2.
telephone—{41} (22) 730 81 11
FAX —{41] (22) 734 23 26
established—\\1 October 1947
fectve—+ Apnl 1951
aun—to sponsor meteorological
cooperation, i JN specialized agency
members— (181) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina,
Armenia Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium. Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British
Caribbean Territories, Brunei, Bulgaria, Burkina Faso. Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic. Chad, Chile, China, Cocos Islands, Colombia,
Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark. Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece. Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong
Kong. Hungary, Iceland, India, Indonesia, Iran. Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Federated States of Micronesia. Moldova, Mongolia, Morocco, Mozambique.
Namibia, Nepal. Netherlands,','6c1e807b0d02a513fe437a5459561bd9879852ccf0d872a3d10f1f17f493c033','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8106e7b8e7831b24147c6efce72381760f3b704e8feee1f324a09ebb6f4ff396',1996,'CH','Switzerland','transportation',273,'Netherlands Antilles, New Caledonia, NZ, Nicaragua, Niger.
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Sao Tome and Principe,
Saudi Arabia, Senegal. Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland. Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey. Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Western Samoa, Yemen, Yugoslavia (suspended), Zaire, Zambia,','5bc67862ae81667ebe8c3c8f634f9ce3da7f96063dd6204980e76f969f5a5ccc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c7b78e59f38c9c8b229ba79ff386c92674cc73bddc8042ff2baf57b39db9b74',1996,'CY','Cyprus','transportation',281,'Railways: () km
Highways:
Greek area—total: 10.448 km
Greek area—paved: 5.694 km
Greek area—unpaved: 4.754 km
Turkish area- total: 6.116 km
Turkish area—paved: 5.278 km
Turkish area—unpaved: 838 km
Ports: Famagusta. Kyrenia. Larnaca.
Limassol, Vasilikos Bay
Merchant marine:
total: 1.524 ships (1.000 GRT or over)
totaling 23.949.242 GRT/40.236.638 DWT
ships by type: bulk 490, cargo 562. chemical
tanker 27. combination bulk 53. combination
ore/oil 22. container 115. liquefied gas
tanker 3. mulutunction large-load carner 4.
oil tanker 129. passenger 6, passenger-cargo
|. retrgerated cargo 62. roll-on/roll-off cargo
28. short-sea passenger 17. specialized tanker
3. vehicle carner 2
note. a flag of convemence registry. includes
ships trom 48 countnes among which are
Greece 706, Germany 171. Russia 44.
Netherlands 31. Belgium 30. Japan 29, Cuba
21. UK 17. Spain 14. and Hong Kong 13
(1995 est.)
Airports:
total: 1S
with paved runways 2.438 to 3.047 m: &
with paved runways 914 to 1,523 me 3
with paved ranwavs under 914 m: 3
with unpaved runways 914 to 1,523 me |
(1995 est.)
Heliports: 4 (1995 est.)
Railways:
total: 9,413 km
standard gauge: 9.316 km 1.435-m standard
gauge (2640 km electrified)
narrow gauge: 97 km several narrow gauges
(1995)
Highways:
total: 55,557 km 41994 est.)
paved: NA km
unpaved: NA km
Waterways: NA km: the Elbe (Labe) 1s the
principal river
Pipelines: natural gas 5.400 km
Ports: Decin, Prague, Usti nad Labem
Merchant marine:
total: 10 ships (1.000 GRT or over) totaling
155.946 GRT/251.624 DWT
ships by type: bulk 5. cargo 5 (1995 est.)
Airports:
total: 116
with paved runways over 3,047 m: 2
with paved runways 2,438 to 3,047 m: 9
with paved runways 1,524 to 2.437 m: 13
with paved runways under 914 m: 5
with unpaved runways over 3,047 m: |
with unpaved runways 2,438 to 3,047 m: 3
with unpaved runways 1,524 to 2,437 nm. 10
with unpaved runways 914 to 1,523 m: 32
with unpaved runways under 914 m: 41
(1994 est.)','5e926b1dd914d9d4f8d36535dd19fbce1c9f9c74d934ddcf6267a1532f7bb543','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5486f4c5ebc3bf35f824a36cd7b0dc046b813b0103d79eb5cb887d8f90d54b83',1996,'DK','Denmark','transportation',288,'Railways:
total: 2.848 km (499 km privately owned
and operated)
standard gauge: 2.848 km | 435-m gauge
(326 kim electnitied. 760 km? uble track)
(1995)
Highways:
total, 71042 km
paved. 71.042 km including 696 kin ot
eCVpressways)
unpaved. Ohm (1992 est)
Waterways: 417 km
Pipelines: crude oi! 110 km: petroleum
products S78 km. natural gas 700 km
Ports: Alborg. Arhus. Copenhagen. Esbyerg
Fredencia. Grenaa. Koge. Odense. Struet
Merchant marine:
total, 334 ships (1.000 GRT or over) totaling
5.013.084 GRT/7. 171.871 DWI
ships by type bulk 13. cargo 114, chemical
tanker 2S. container 6S. liquefied gas tanker
27. liwestock carer S. ol tanker 41. railcar
camer |. retngerated cargo 17, roll-on/rot!
13
Denmark (continued)
oft cargo 26. short-sea passengel y
|
necialized tanker |
¢- Denmark has created tts own internal
gister, called the Danish International Ship
register (DIS). DIS ships do not have to
meet Danish manning regulations, and they
tto a flag of convemence wit''un the
Danish re gister 1995S est.)
\\irports:
iw
ed runways over 3.047 m: 2?
ed runways 2.438 to 3,047 m: 7
unwavs 1,524 to 2.437 m: 3
runways Yl4 to ] $23 m 13
i runways under 914m
ws 1.524 ta 2437 m: 1
6 ¥/4 10 1,523 m 6
mpairtca i
Railways:
total: 3,569 km (1995)
narrow gauge: 2,600 km 1.000-m gauge:
969 km 1.067-m gauge
note:: the Tanzania-Zambia Railway
Authority (TAZARA), which operates 1,860
km of 1.067-m narrow gauge track between
Dar es Salaam and New Kapiri M’poshi in
Zambia is not a part of Tanzania Railways
Corporation; 969 km are in Tanzania and
891 km are in Zambia; because of the
difference in gauge, this system does not
connect to Tanzaria Railways
Highways:
total: 55,600 km
Defense
Branches: Tanzanian People’s Defense
Force (TPDF; includes Army, Navy, and Air
Force). paramilitary Police Field Force Unit.
Militia
Manpower availability:
males age 15 49; 6,499,244
males fit for military service: 3,765,193
(1996 est.)
Defense expenditures: exchange rate
conver:ion——$69 million, NA% of GDP
(FY94/95)
v77 |','c381604de878925f987c6ba1c81b400f1c5e818224cc448f8a4e10d890538ec8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83007ff7ed1f41bffa73afe5de5a417553aefef453e5d5ca64118ab30e1fae54',1996,'SO','Somalia','transportation',294,'Railways:
total: 97 km (Dybout: segment of the Addis
Ababa-Dybouti raibroad)
narrow gauge: 97 km 1.000-m gauge
Highways:
total: 2.379 km
paved: 563 km
unpaved: 2.516 km (1991 est.)
Ports: Dybouty
Merchant marine:
wial: | cargo ship (1.000 GRT or over
totaling 1.369 GRT/3.030 DWT (1995 est)
Airports:
total: V1
with paved runways over 3.047 m. |
with paved runways 2.438 to 3.047 m: |
with paved runways under 914 m- 2
with unpaved runways 1.524 to 2.437 m 2
with unpaved runways 914 to 1,523 m
(1995 est)','45579bdc0517f43fb52e568f668b6dd705999ad3419d413b7edf0efa1592c206','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eba097d1d78a7d3a60ea01e823f8c6390d6b017233ffe9c1eadfaaeed532d8cb',1996,'DO','Dominican Republic','transportation',306,'Railways:
total: 757 km
standard gauge: 375 km 1.435-m gauge
(Central Romana Railroad)
narrow gauge: 142 km 0.762-m gauge
(Dominica Government Ratmaay): 240 km
operated by sugar companies in various
gauges (O.558-m. 0.762-m. 1.067-m gauges)
(1995)
Highways:
total: 11.931 km
paved: 3.766 km
unnaved: 6.165 km (1987 est.)
Pipelines. crude oi] 96 km. petroleum
products 8 km
Ports: Barahona, La Romana. Puerto Plata,
San Pedro de Macoris. Santo Doringo
Merchant marine:
total: | cargo ship (1.000 GRT or over)
totaling 1.587 GRT/1.165 DWT (1995 est)
Airports:
total; 31
with paved runways over 3,047 m: 2
with paved runways 1,524 to 2.437 m: 6
5
with paved runways 914 to 1.523
with paved runways under 914m: 14
with wapaved runways 2.438 to 3.047 m. |
with unpaved runways 1,524 to 2.437 m. |
with unpaved runways Y¥14 to 1,523 m: 4
(1995 est.)','ea37174641e8b9077b7b1296dd051a9e7d15ea5debd2e1bc8cb483c94b3f4868','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52c61ef1c162e354f3c3f7cdf6d16c4929b76492ff99086602876b46c16e808f',1996,'EG','Egypt','transportation',318,'Railways:
total: 4.751 km
standard gauge: 4.751 km 1.435-m gauge
(42 km electrified: 951 km double track)
Highways:
total: 47.387 km
paved: 34,593 km
unpaved: 12,794 km (1992 est)
Waterways: 3.500 kin (including the Nile.
Lake Nasser, Alexandna-Cairo Waterway.
and numerous smaller canals im the delta):
Suez Canal, 193.5 km long (iacluding
approaches}. used by oceangoing vessels
drawing up to 16.1 m of water
Pipelines: crude oil 1.171 km: vetroleum
products 596 km: natural gas 460) km
Ports: Alexandria, Al Ghardagah. Aswan.
Asyut. Bur Satajah. Damietta, Marsa Matrun.
Port Said, Suez
Merchant marine:
total: 164 ships (1.000 GRT of over) totaling
1.187.290 GRT/1.833.108 DWT
ships by type. bulk 22. cargo 74. liquetied
gas tanker !. onl tanker 14. passenger 33,
refrigerated cargo |. roll-on/roll-off cargo 15,
short-sea passenger 4 (1995 est.)
Airports:
total: 80
with paved rm. wavs over 3,047 m 11
with paved runways 2.438 to 3.047 m: 34
with paved runways 1,524 to 2.437 m: 16
with paved runways 914 to 1,523 m2
15/
with paved runways under 914 m: 9
with unpaved runways 2,438 to 3,047 m:
tv ty
with unpaved runways 1,524 to 2,437 m.
with unpaved runways 914 to 1,523 m: 4
(1995 est.)
Heliports: 2 (1995 est )','ae87733033ae07f5f5ed6e83d47b7a4f93c7a6e58fc3606cf49a372aaede43b5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c9a8a436e5388340001eb717be3f76bff37d61b2f9167999e89aa938c8626ea',1996,'ER','Eritrea','transportation',331,'Railways:
total: 307 km, note—nonoperational since
1978 except for about 5 km that was
reopened in Massawa in 1994; rehabilitation
of the remainder and of the rolling stock 1s
under way: links Ak’ ordat and Asmara
(formerly Asmera) with the port of Massawa
(formerly Mits iwa)
narrow gauge: 307 km 0.950-m gauge (1995
est)
Highways:
total: 3.845 km
paved: 807 km
unpaved: 3.038 km (1993 est.)
Ports: Assab (Aseb), Massawa (Mits iwa)
Merchant marine:
total: | cargo ship (1.000 GRT or over)
totaling 11.573 GRT/13.593 DWT (1995
est.)
Airports:
total: 14
with paved runways over 3,047 m: |
with paved runways 2,438 to 3,047 m: |
with paved runways under 914 m: 2
with unpaved runways over 3,047 m: |
with unpaved runways 2.438 to 3.047 m: |
with anpaved runways 1,524 to 2,437 m: 4
with unpaved runways 914 to 1,523 m: 4
(1995 est.)','3d156f95e42e671c12c5a26ddd5a246f2edd88964a72e8634e9cf711634a74fa','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('324523d4a3d71b4b7100888d8142e304a9f6a0884a69bc4b11bffaa556850c8b',1996,'FI','Finland','transportation',337,'Railways:
total: 1,018 km common carer lines only:
does not include dedicated industrial lines
broad gauge: 1.018 km 1.520-m gauge (132
km electrified) (1995)
Highways:
total: 14,771 km
paved: 8.124 km (including 62 km of
expressways)
unpaved: 6.647 km (1993)
Waterways: 500 km perennially navigable
Pipelines: natural gas 420 km (1992)
Ports: Haapsalu. Narva. Paldiski., Parnu
Tallinn
Merchant marine:
total: 52 ships (1.000 GRT or over) totaling
353.140 GRT/467.086 DWT
ships by type: bulk 6. cargo 33. oil tanker 3.
roli-on/roll-off cargo 6, short-sea passenger 4
(1995 est.)
Airports:
total: 22
with paved runways 2.438 to 3,047 m: 7
with paved runways 914 to 1,523 me: 3
with unpaved runways 2.438 to 3,047 m: |
with unpaved runways 1,524 to 2,437 m: 2
with unpaved runways 914 to 1,523 m: 4
with unpaved runways under 914m: 5 (1994
est!
Railways:
total: 12.624 km (includes 953 km of
privately-owned railways)
standard gauge: 11,767 km 1.435-m gauge
(7.320 km electrified and 1,152 km double
traca,
other: 857 km NA-m gauge (1995)
Highways:
total: 135.850 km
paved: 97 318 km (including 936 km of
C\\PTressW ANS)
unpaved: S8O041 km (1991 est.)
Watcrways: 2.052 km navigable tor small
Meamers and barges
Pipelines: natural gas 84 km
Ports: Gavie. Goteborg. Halmstad.,
Helsingborg. Hudiksvall. Kalmar
Karlshamn, Malmo, Solvesborg, Stockholm,
Sundsvall
Mercha-* marine:
total: 16% ships (1.000 GRT or over) ialing
1.993.422 GRT/2. 183.215 DWI
svups by nnpe: bulk 10. cargo 35, chemical
tanker 24
vas tanker |
combination ore/oil |. liquetied
,
“ul tanker 32. railcar carner 2.
retngerated cargo | roll-on/roll-ott cargo 3x
short-sea passenger 7, specialized tanker 4
schicle carner 14 (1995 est)
Airports:
wal 25]
with paved runways over 3.047 m.: 2
2438 to 3047
1 S24 to 2487 om RS
nhpaved rurAadys
Nilt@al Fidtinmays
Wt ymiicd THiwMays HNdtol 5. ‘wm h
; Wil¢ rid s hulev Yidn })
j gerry a4 Pigeiy j Vid fy j 4. ‘A }
~~
Heliports: 5','d2985ae252887dfa280439cf99ca35aa0aa7abba1375f4b5302df50e42ca619d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7b4d9789337b24e1b08601af2c97d8b8f72a754217f673c7b67cbfb91cb4813',1996,'JP','Japan','transportation',341,'Railways:
total: 681 km (Ethiopian segment of the
Addis Ababa-Dyibout: railroad)
narrow gauge: OS) km |.000-m gauge
Highways:
total: 24.127 km
paved: 3.289 km
unpaved: 20.838 km (1993 est)
Ports: none: Ethiopia ts landlocked but by
agreement with Eritrea may use the ports ot
Assab and Massawa
Merchant marine:
total: 12 ships (1.000 GRT or over) totaiin
62.627 GRT/88.908 DWT
ships by tvpe
cargo S. oil tanker 2. roll-on
roll-off cargo 2 (1995 est.)
Airports:
total: S&S
with paved runways over 3.047 m. 2
with paved runways 2.438 io 3.047 m: 3
with paved runways 1.524 to 2.457 m: |
with paved runways 914 to 1,523 m |
with paved runways under 914m. 6
with unpaved runways over 3.047 m
with unpaved runways 2.4388 to 3.04
with unpaved runways 1,524 te 243° m 9
,
with unpaved runways 9/4 to 1523 4
(1995 est.)
Railways:
total: 26.506 km
standard gauge: 3.233 km 1.435-m gauge
(entrely electniied)
narrow gauge: 72 km 1.372-m gauge (72 km
electntied): 23.154 km 1.067-m gauge
(13.835 km electnfied): 47 km 0.762-m
gauge (47 km electrified) (1994)
Highways:
total: 1 112.844 km
paved: 790.119 km (including 5.054 km of
CAPTessWays)
unpaved: 322.725 km (1992 est.)
Waterways: about 1.770 km: seagoing craft
ply all coastal inland seas
Pipelines: crude oi! 84 km: petroleum
products 322 km. natural gas 1.800 km
Ports: Akita. Amagasaki. Chiba. Hachinohe.
Hakodate. Higashi-Harima. Himeji.
Hiroshima. Kawasaki. Kinuura, Kobe.
Kushiro. Mizushima. Mop, Nagoya, Osaka,
Sakai. Sakaide. Shimizu, Tokyo, Tomakomai
Merchant marine:
total: 796 ships (1.000 GRT or over) totaling
15.944.137 GRT/23.662.930 DWT
sdups by type: bulk 192. cargo 57. chemical
tanker 6, combination bulk 2. combination
ore/oil 6, container 38, liquetied gus tanker
39. oil tanker 259. passenger 9. passenger
cargo 3, refrigerated cargo 35, roll-on/roll-oft
cargo 43, short-sea passenger 28. specialized
tanker 2. vehicle carrier 77
note: Japan owns an additional 1.587 ships
(1.000 GRT or over) totaling 50.072.815
DWT operating under the registries of
Panama. Liberia. \\ anuatu, The Bahamas.
Singapore. Cyprus, Philippines. Hong Kong.
and Malta (1995 est.)
Airports:
total: 164
with paved runways over 3,047 m: 6
with paved runways 2.438 to 3,047 m: 32
with paved runways 1,524 to 2,437 m: 34
with paved runways 914 to 1,523 m: 30
with paved runways under 914 m: 60
with unpaved runways 914 to 1,523 m: 2
(1995 est.)
Heliports: | 1 (1995 est.)
Ports: none: offshore anchorage onl)
note there is one boat landing area in tl
middle of the west coast and another
the southwest corner of the island
Transportation note: there is a day beacon
near the middle of the west co
Defense
Defense note: defense ts the respons
ol the US: vistted annually by the US Coast
Guard
tv
=
mn
ASY
Raiiways:
tal Okm
narrom gauge: O km 1 067-m gauge. note
part of the pres nous 176 kim system was
closed and dismantied m 1994 and. m 1994
the remainder was closed. the track and
rolling stock berg sold for sorap
Highways:
total: 26.000 km
paved: 4.000 km
unpaved: 22.00 km (1993 est)
note. there ts a 368.5 km portion of the Pan
Amencan Highway which ts not mcluded im
the total
Waterways: 2.220 km. including 2 larce
lakes
Pipelines: crude on! SO km
Ports: Blucticids. Connto. El Bluff, Puerto
Cabezas. Puerto Sandiwo. Rama. San Juan
del Sur
Merchant marine: nonce
Airports:
nial, 148
with paved runways over 3.047 m: |
with paved runways 2.438 ta 3.047 m: |
with paved runways 1,524 to 2.437 m: 3
with paved runways 914 to 1.525 m: %
with paved runways under 9/4 mm. (07
with unpaved runways 1.524 10 2427 m 1
with unpaved ranwavs 9/4 to 1,523 m- 32
(1995 est)
Railways: 0 km
Highways:
total: 13.173 km
paved: 1,186 km
unpaved: 11.987 km (1990 est.)
Waterways: Lac Kivu navigable by shallow
draft barges and aative craft
Ports: Cyangugu. Gisenyi. Kibuye
Airports:
total: 7
with paved runways over 3,047 m: |
with paved runways 914 to 1,523 m: 2
with paved runways under 914m: 3
with unpaved runways 914 to 1,523 m: |
(1995 est)
Ceaununications
Telephones: 6.400 (1983 est)
Telephone system: telephone system does
not provide service to the general public but
is intended for business and government use
domestic. the capital, Kigali. 1s connected to
the centers of the prefectures by microwave
radio relay: the remainder of the network
depends on wire and HF radiotelephone
international: imernational connections
employ microwave radio relay to
neighboring countnes and satellite
communications to more distant countries:
satellite earth stations—1 Intelsat (Indian
Ocean) in Kigali (includes telex and telefax
service)
Radio broadcast stations: AM |. FM |.
shortwave 0)
Radios: 630,000 (1993 est.)
Television broadcast stations: |
Televisions: NA
Defense
Branches: Army. Gendarmerie
Manpower availability:
males age 15-49; | 582.656
o/3
males fit for military service: 805,722 (1996
est.)
Defense expenditures: exchange rate
conversion—$112.5 million, 7% of GDP
(1992)
Saint Helena
(dependent territory of the UK)
*
JAMES OWN
Railways: 0 km
Highways:
hital: NA km (mainland 118 km, Ascension
NA km. Tristan da Cunha NA km)
poved. 180.7 km (mainland 98 km.
Ascension 80 km. Tristan da Cunha 2.70
km)
unpaved: NA km (mainland 20 km.
Ascension NA km. Tristan da Cunha NA
km)
Ports: Georgetown, Jamestown
Merchant marine: none
\\irports:
total: |
with paved runways over 3.047 m: 1 (1995
esl }','ec178881a46c55fe1795da01ff93fa28a2fc4e0418fa1787855ddff9f15bd352','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44d4bcfdd1890c59ef84253d169a74e162fdb8e1270654d00e808ab89d796452',1996,'AR','Argentina','transportation',348,'Railways: 0 km
Highways:
total: S1O km
paved: Wkm
unpaved: 480 km
Ports: Stanley
Merchant marine: none
\\irperts:
total: S
with paved runways 2,438 to 3,047 m: \\
with paved runways under 914 m: 4 (1995
est.)
Railways:
total: 971 km
viandard gauge: 441 km |.435-m gauge
narrow gauge: OO km 1.000-m gauge
other: 470 km varvous gauges (privately
owned)
Highways:
total: 21.834 km
paved 1778 km
unpaved 20.156 kim (1987 est.)
Waterways: 3.100 km
Ports: Asuncion, Villeta. San Antonw
Encarnacion
Merchant marine:
total: 16 ships (1.000 GRT or over) totaling
21.323 GRT/23,.907 DWT
vups by type: cargo 13, oil tanker 2. roll-op
roll-ott 1 (1995 est)
\\irports:
total: 739
with paved runways over 3,047 m: 3
with paved runways 1,424 to 2.437 m: 2
with paved runways 914 to 1.523 m: 4
with paved runways under 914 m: 438
with unpaved runways over 3,047 m: |
with unpaved runways 1,524 to 2.437 m: 25
with unpaved runways 914 to 1,523 m: 266
(1995 est.)','47355b59099b9467eeba8585a8edacc5a17b4bbeedd0b818f36c4d02d0893946','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('589c554cf306c1280c0eda2278ce39957585d1f4cb27ff539aa5d6126c144a4f',1996,'FO','Faroe Islands','transportation',354,'Railways: 0 km
Highways:
ied ATT)
ed NAM
iat od NA Ks
Ports: Klab ch. Torsha
Merchant marine.
lvonwn
MMI CR] om over) totaling
GRT/1S.444 DWT
S gorli«<m roll Ml cargo
oT : wes esl )
\\Virports:','fcad30560ed16608665f9729b5cf549cb735333d2025c4b17d1f1a394a927307','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9eb0c4f1bf11479224f3c1f583ada6243c9cb3c9bd8a38be2e73d120cae5ed1',1996,'EE','Estonia','transportation',364,'Railways:
s &US KT
ru SAY >} 4 vue
nm 4 si \\ rr ’
" wus
Highways:
3 &
~* > + >
Viuterwass
Pipelines st)
Ports '' : \\s > ‘a ;
,
Vierchant marin
r
Lirports','964c649afd9b8c0a58a264bb34150106da95bab59a974f8bfef1b0a01af019b9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd56e7a7643aa649a634bbc3d0fa1dc71a37c6d2984d70bf1f15d7e5f25a08b7',1996,'WF','Wallis and Futuna','transportation',371,'Railways:
x
hy ;
Highways:
Si]
|
CAPTESSWays
npaved. J00.000 km (1992
note. meludes Corsica
Waterways: 14.932 km. 6.969 km heavily
traveled
Pipelines: crude oi! 3.059 km. petroleum
products 4.487 km: natural gas 24.746 km
Ports: Bordeaux Boulogne, Cherbourg
Dijon. Dunkerque. La Pallice. Le Havre
Lyon, Marseille. Mullhouse. Nantes, Pan
Rouen. Saint Nazaire. Saint Malo
Merchant marine:
total: 5S ships (1.000 GRT or over
1.203.086 GRT/1.779.263 DWT
ships by type: oil tanker 16, passer
roll-on/roll-oft cargo 6
5. specialized tanker |
note: France also m
tor French-owned
Islands (French Sou
Lands) (199% est
Airports:
total: 460
wilh paved runwa
nNuP pared
with paved
wih
win j
with MnNpaved Fun
wil unpaved rid
(1995 est)
Heo in udes Corsi
Heliports: 3 (1995','5bed979165e2ebfa51933742da856f66003a8be89a656ce1393e1b18c4876c47','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77aab94e53f575ed046c6cc908ab30dcffccc14ebcffac4b880c47e225b2483c',1996,'GF','French Guiana','transportation',377,'Railways: 0 km
Highways:
total: 792 km
paved: 792 km (1995 est.)
Ports: Mataura. Papeete. Rikitea, Uturoa
Merchant marine:
total: 3 ships (1.000 GRT or over) totaling
4.127 GRT/6.710 DWT
ups by type: passenger-cargo 2.
cargo 1 (1995 est.)
Airports:
total: 4
with paved runways over 3,047 m
refrigerated
5
with paved runways | $24 to 2.4387 m §
with paved runways 914 to 1523 m 13
with paved runways under 914m 1S
with unpaved runways 914 to 1523 m6
(| WS est.)
Railways: 0 km
Highways:
otal: 2.386 km
paved: 764 km
unpaved. 1.622 km (1990 est.)
Waterways: 400 kin
Ports: Banjul
Merchant marine: none
Airports:
total: |
174
with paved runways over 3,047 m: 1 (1995
est.)','d360c8cfd3ea2655c3d7d7ef599f66191b18ede9c2135d298b73095020db4f65','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f82eb497c678a7631ce1930e80d0ba23befca753937c69296dcb9fa6e27fe9f4',1996,'IL','Israel','transportation',385,'Railways:
total: NA km: note
and in disrepair. little trackage remains
Highways:
total: NA km
paved: NA km
unpaved: NA km
one line. abandoned
note. small. POTTS dev eloped road network
Ports: Gaza
Airports:
total: |
with Pared runny vunder Yld me 1199S
est.)','b2f113bc188cf2379cb0f4e696dde5cf6777af7d9bbbffdcd2595cb08e5c6ca5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1866d75bbf792794750bde0ead4eb39ad6a215427478b5acab5d9912f0ea4762',1996,'GH','Ghana','transportation',402,'Railways:
total: 953 km. note—undergoing major
renovation (1995 est.)
narrow gauge: 953 km 1.067-m gauge: 32
km double track
Highways:
total: 58.145 km
paved: 7.476 km (including 21 km of
CAPTEssW ays)
unpaved: 30.669 km (1990 est.)
Waterways: Volta, Ankobra. and Tano
Rivers provide 168 km of perennial
navigation for launches and lighters: Lake
Volta provides 1.125 km of arterial and
feeder waterways
Pipelines: nor
Ports: Takoradi, Tema
Merchant marine:
total: 3 stups (1.000 GRT or over) totaling
27.427 GRT/35.894 DWT
ships by type: cargo 2
(1995 est)
retngerated cargo |
Airports:
wial: 12
with paved runways 2.438 to 3.047 m: 3
with paved runways 1,524 to 2.437 m |
with paved runways 914 to 1,523 m
with paved runways under 914m: 2
with unpaved runways 1.524 to 2.437 m: 2
with unpaved runways 914 to 1,523 m
{ 1V905 es)','d8a77d355202f367650bcb0209c3adf3886ea0bd1dd8e19c734ddb372416e9d4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18a6abcc33891ce28375666da77237a0b0e500949eb1023c6be07bde9d4a5986',1996,'GI','Gibraltar','transportation',407,'Railwas s:
total: NA km. 1.000-m gauge system in
don kyard area only
Highways:
tal: 49.9 km (including 12.9 km public
highways)
paved: 49.9 km
unpaved. O km
Pipelines: none
Ports: Gibraltar
Merchant marine:
wial- 19 ships (1.000 GRT or over) totaling
387.730 GRT/635.769 DWT
ups by type: bulk 1. cargo 4. chemical
tanker |. contamer |. on! tanker 13 (199%
est.)
Airports:
total: |
7
with paved runways 1,524 to 2.437 m: |
{ }YV5 est)','1ad797d172f0393e117eda3854a1828fe176536500b079d8fa7c09d011e260c9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e4e696e0e86de26e9f48e4b898234233455925efc12078488e1645fb7d2804c',1996,'GR','Greece','transportation',408,'—
a * ATHENS
C,eography
location: S hus hordering the
‘ ‘ | Ns it
\\I ean S hetw Vibania and
(,cographic coordinates: 89 00 N. 22 001
Map references: Europ
\\rea
rit) 1
leae iy > stn) il
omparalive ti, smatier than
Alab
\\ll i 282 km. Buleana
" f® ko. The kormet
}? , Macedonia ek km
€ costhone Ty /t &
\\iaritime clams:
in ey ! TT
International disputes: nplex maritime
j if | ith i
\\ ( n. dispute will
; \\ . R nul |
1 h er demarcation
i treatment of Albania s
{, ‘a oty. and micramt Albanian
ret (; f nam unm olved isstic’
Climate: temperak id. wet winters. hot
urs uliinel
Ferrain: mostly mountains with ranges
extending int Aas penn has 4 chams ofl
islands
lowest pom: Mediterranean Sea Om
hichest point: Mount Olvinpus 2.917 m
Natural resources: bowie. lene
magnesite. petroleum. marbl
Land use:
arable land: 23%
permanent crops: S&S"
meadows and pastures: 40%
forest and woodland: 20%
other: 9
Irrigated land: 11.900 sg km (1989 est)
Railways:
tial: 2.474 km
vandard gauge: 1.565 km 1.435-m gauge
(46 km electrified. 100 km double track)
arrow gauge: S87 km 1.000-m gauge. 22
km 0.750-m gauge (a rack type railway for
seep grades)
Highways:
total: 130.000 km
paved. 119.210 km Uncluding 116 km of
expressways)
unpaved: 10.790 km (1990 est)
Waterways: S80 km. system consists of three
coastal canals: including the Cornth Cana!
(6 km) which crosses the Isthmus of Cormnth
connecting the Gulf of Corinth with the
Sarome Gulf and shortens the sea vovage
from the Adriatic to Pirarevs (Piracus) by
325 km: and three unconnected rivers
Pipelines: crude oil 26 km: petroleum
products 547 km
Ports: Alexandroupolis. Elevsis, Iraktion
(Crete). Kavala. Kerkira, Khalkis
187
*%
Greece (continued) Defense expenditures: exchange rate Greenland
conversion—S4.9 billion, 4.6% of GDP (part of the Danish realm)
1 GOS
1OuUM« . on. Patra. Pirarevs ao )
Merchant marine:
S] ships (MM) GRT or over)
>8.842.200 GRT/S2.583.281 |
> ''
Wik 408. cargo Yl. Chemica
Ke n bulk 22. combinatio
f + quetied gas | inkel
La +>» a © = ‘ Pass u l
i \\ on ‘ 4 i} j i( 1] t?) ]
»t se ISSCTILC \\+ SPecla ed
Greece in add "YS ships
RI vy 62.29] 974
s. Malta. I
h bial Hor \\
\\ ; YON ~
\\irports
Tay S
4 ‘ h4 ‘
Vf J / f
4 ; ‘
Heliports: ys
Railways: 0 km
Hivhwavs:
SOkn
Oli Ke
f Yt) }
Ports: | i i } ( KAI rab
\\ LPveore i] h Narsaq Nuuk
Nond Stromtyord
\\ierchant marine:
ver (1 OOO GRE of
(RE/610 DWH p99s
Airports
Railways:
total: 699 km
standard gauge: 699 km 1.435-m gauge (232
km electrified) (1995)
Highways.
total: 1O.S91 km
paved: 5.091 km
unpaved: § SOO km (1991 est.)
Waterways: none. lake transport only
Pipelines: none
Ports: none
Airports:
total: 16
with paved runways 2.488 to 3,047 m: 2
with paved runways under Yl4m: 12
with unpaved runways 914 to 1.5238 m: 2
(1995 est.)','a20f4c58c9de0d00e91905592d3a1ebfa15ff73637f62eca47718c6f1cad5fb4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81926b055df19a767349a5a20c5d16bb0e843dab2af8db544e2cb3c8fdc2f697',1996,'GG','Guernsey','transportation',439,'Railways: 0 km
Highways:
total? NA km
paved: NA km
WNpare d- NA km
Ports: Saint Peter Port, Saint Sampson
Merchant marine: none
\\irports:
total: 2
with paved runways Y¥14 to 1.523 m: |
with paved runways under 914 ne 1199S
en }
Railways:
total: 1086 km
standard gauge: 279 km 1.435-m gauge
narrow gauge: 807 km 1.000-m gauge:
note-—includes 662 km in common carrer
service from Kankan to Conakry
Highways:
total: 29.750 km
paved. 4.490 km
unpaved: 25.260 km (1991 est.)
Waterways: 1.295 km navigable by shallow-
draft native craft
Ports: Boke. Conakry. Kamsar
Merchant marine: jone
Airports:
total: 14
with paved runways over 3,047 m: |
with paved runways 2,438 to 3,047 m
— tv
with paved runways 1,524 to 2.437 m
with paved runways under 914m: |
with unpaved runways 1,524 to 2.437 m: 6
with unpaved runways 914 to 1,523 m
(1995 est.)
Railways: 0) km
Highways:
total: 3.200 km
paved: 416 km
unpaved: 2.784 km (1988 est.)
Waterways: scattered stretches are important
to coastal commerce
Ports: Bissau
Merchant marine: none
Airports:
total: 16
with paved runways over 3,047 m: |
with paved runways 1,524 to 2.437 m: 2
with paved runways 914 to 1,523 m: |
with paved runways under 914 m: &
with unpaved runways 914 to 1,523 m: 4
(1995 est.)','df6a27f705b0546996b779aa56353f999c5ec93f6c61f41df616a5d4f52c49b1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bba70e59c9f6890624814c8fd9c1b690dfdf0210b91f941f85cbc9eacb85fea0',1996,'GY','Guyana','transportation',445,'Railways:
total: 88 km
siandara gauge. 40 km 1.435-m gauge
(dedicated to ore transpe ft)
narrow gauge: 48 km O.Y1i4-m gauge
(dedicated to ore transport)
Highways:
total: 7.621 km
paved. 547 km
unpaved: 7.074 km (1987 est.)
Waterways: 6.000 km total of nayigadk
waterways: Berbice. Demerara. and
Essequibo Rivers are navigable by
oceangoing Vessels for 150 km. 100 kin an
SO km. respectively
Ports: Bartica, Georgetown. Linden. New
Amsterdam, Parka
Merchant marine:
total: 1 cargo ship (1,000 GRT or over)
totaling 1.317 GRT/2.558 DWT (1995 est.)
Airports:
total: 47
with paved iunways 1,524 to 2.437 m
with paved unways 914 to 1.523 m: |
with paved runways under 9/4 m- 32
with unpaved runways 1,524 to 2.437 m: 2
with unpaved runways 914 to 1,523 m. 9
(1995 est.)
Railways:
total: S84 km (336 km single track. 248 km
privately owned)
standard gauge: S84 km 1.435-m gauge
Highways:
total: 93,472 km
paved: 29.954 km
unpaved. 63.518 km (\\993 est.)
Waterways: 7.100 km. Rio Orinoco and
Lago de Maracaibo accept oceangoing
vessels
Pipelines: crude oi! 6.370 km: petroleum
products 480 km: natural gas 4.010 km
Ports: Amuay. Bajo Grande. Et Tablazo. La
Guaira, La Salina. Maracaibo, Matanzas
Palua, Puerto Cabello, Puerto la Cruz, Puerto
Ordaz, Puerto Sucre. Punta Cardon
Merchant marine:
total: 32 ships (1.000 GRT or over) totaling
612.645 GRT/1 090.707 DWT
ships by type: buik 4. cargo 9. comlunation
bulk 1. liquefied gas tanker 2. oi! tanker 12.
passenger-cargo |, roll-on/roll-off cargo 2.
short-sea passenger | (1995 est.)
Airports:
total: 377
with paved runways ever 3,047 m: §
with paved runways 2,438 to 3,047 m: 10
with paved runways 1,524 to 2,437 m: 34
Sil
520
Venezuela (continued)
with paved runways 914 to 1,523 m: 59
with paved runways under 914 m: 165
with unpaved runways 1,524 to 2,437 m: 8
with unpaved runways 914 to 1,523 m: 9%
(1995 est.}','ac40a7c610c7ae0efdcb013e13f3241d97f492b198bafe37f08457ba374428dd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e52bc319778ee4932aa5727786ca32fe54c287c42d41fd282825a6962a8fa1a',1996,'HT','Haiti','transportation',451,'Railways:
total: 40 km (single track: privately owned
industrial line)-ciosed in early 1990''s
narrow gauge: 40 km 0.760-m gauge
Highways:
total: 3.978 km
paved: 944 km
unpaved: 3.034 km (1987 est.)
Waterways: negligible: less than 100 km
navigable
Ports: Cap-Haitien. Gonaives. Jacmel.
Jeremie, Cayes. Miragoane. Pori-au-Prince
Port-de-Paix. Saint-Mare
Merchant marine: none
Airports:
total: V1
with paved runways 2.438 to 3,047 m: 2
with paved runways 1,524 to 2,437 m: |
with paved runways under 914 m: 4
with unpaved runways 914 to 1,523 m: 4
(1995 est.)','215aecdead1a16a8b3c02b8450d7d6b2517fdc7c94aca8f75edb567cddcf5d4a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35ae47f3dd6d93a2a5b76ff3ee5b7fd1c63055b6b47f65ba5d86d822cab6aa86',1996,'HK','Hong Kong','transportation',463,'Railways:
S br
lard 2auee ‘Skm 1.435-m yauuge
Highways:
| ‘ofy! b
, fyt Livy
wip ¢ ) + YU |
Ports: Hong Kor
Merchant marine:
jotal: 238 ships (1.000 GRT or over) totahag
8.632.224 GRT/14.820.657 DWT
ships by tvpe: bulk 12°. cargo 32. chemical
tanker |. combiaation bulk 4. combination
will assume command
ore/onl 3, contamer 39, liquefied gas tanker
+. multifunction large load camer 1, oil
tanker refrigerated cargo 5, short-sea
passenger |. vehicle carer 3
mote. a tag of convenience registry: includes
ships trom 17 countnes among which are
UK S51. China 11. Belgium 8. South Afnca
S. US &. Japan 7. Bermuda 6. Switzerland 6
Germany 3. and Israel 3 (1995 est.)
\\irports:
+
nun paved runwavs over 3.047 m: |
wilh paved runways under Vid m: 1 (1995
cs)
note. NeW Intermational airport to be
commissioned in 1997/98
Heliperts: | (1995S est)
Ports: none. offshore anchorage only
novte—there 1s one boat landing area along
the middle of the west coast
Airports: airsinp constructed in 1937 for
scheduled refueling stop on the round-the
world flight of Amelia Earhart and Fred
Noonan—they left Lae. New Guinea, tor
Howland Island. but were never seen again
the airstrip ts no longer serviceable
Transportation note: Earhart Light ts a day
beacon near the middie of the west coast that
was partially destroyed during World War II.
but has since been rebuilt’ named in memory
of famed aviatnix Amelia Earhart
Defense note: defense ts the responsibility
of the US: visited annually by the US Coast
aay
Railways: 0 km
Highways:
total: 90 km
paved: 42 km
unpaved: 48 km (1987 est.)
Ports: Macau
Merchant marine: none
Airports: new international airport
completed in 1995: 1 seaplane station','a3ff198561ebfd7ee3ef91377f64b69ca3b594c0010a20de324b59707ca22102','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dd59cd1cd626c0c20f585527b738e1d56b8ff275ec589ef27a5772e175b42e8',1996,'IN','India','transportation',474,'Railways:
total: 62.462 km (11,793 km electrified:
12.617 km double track)
broad gauge: 37,824 km 1.676-m gauge
narrow gauge: 20.653 km 1.000-m gauze:
3.955 km 0.762-m and 0.610-m gauge (1995
est.)
Highways:
total: 2.037 million km
paved: 981.834 km
unpaved: 1.055.166 km (1995 est.)
Waterways: 16.180 km. 3.631 km navigable
by large vessels
Pipelines: crude oi! 3.005 km. petroleum
products 2.687 km: natural gas 1.700 km
(1995)
Ports: Calcutta, Cochin. Jawaharal Nehru.
Kandla. Madras. Mumbai (Bombay ).
Vishakhapatnam
Merchant marine:
total: 310 ships (1.000 GRT or over) totaling
6.787.834 GRT/11.296.222 DWT
ships by wpe) bulk 133. cargo 65. chemical
tanker 10. combination bulk 2. combination
ore/oil 3. container 11. liquefied gas tanker
6. ol tanker 73. passenger-cargo 5. roll-on
roll-off cargo 1. short-sea passenger | (1995
est.)
Airports.
total: 288
with paved runways over 3.047 m. 11
with paved runways 2.488 to 3,047 m. 4s
with paved runways 1,524 to 2.437 m: SY
a
with paved runways 914 to 1523 m. OS
with paved runways under 914m. 62
with unpaved runways 2.438 to 8.047 m
with unpaved runways 1,524 to 2.437 m
with unpaved runways 914 to 15238 m- 36
(1995S est)
Heliports: 15 (i995 est)','0fd4fb1a4c134c82fcb8747adce662eb7152b339fd119e0a7018b1b7bb481ba9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10d3e84d1d9a3168782027bc4a53236899bf8d11794aba015280b7db40db4f5f',1996,'ID','Indonesia','transportation',480,'Railways:
rtal: 6.ASS km
narrow gauge: 5.961 km 1.067-m gauge
(101 km electrified: 101 km double track):
497 km 0.750-m gauge (1995)
Highways:
total: 283.516 kin
paved: 125.051 km
unpaved: 158.465 km (1995 est.)
Waterways: 21.579 km total: Sumatra 5.471
km. Java and Madura 820 km. Kalimantan
10.460 km. Celebes 241 km. Inan Jaya
4.587 km
Pipelines: crude oi! 2.505 km. petroleum
products 456 km: natural gas 1.703 km
(1YUR9)
Ports: Cilacap. Cirebon, Jakarta, Kupang.
Palembang. Semarang. Surabaya.
Uyungpandang
Merchant marine:
otal: 457 ships (1.000 GRT or over) totaling
>.098.988 GRT/3.086.040 DWT
drips by types bulk 30. cargo 265, chemical
tanker 6. container 11. liquefied gas tanker 5
livestock carer |. oil tanker YS. passenger
5 pussehrer-carea 12. roll-on/roll-otf care
short-sea passenger 6. specialized tanker
vehicle carrier 4 (1995 est.)
Airports:
4)4
i paved runways over ,047 m4
wh paved runways 2.438 to 3.047 m9
th paved runwavs 1.524 to 2,437 m: 3S
hh paved runways YJ4d ta 1.523 m: 4
ith paved rum avs under 914m: 299
wh unpaved raways | $24 to 2.487 m 3
vith unpaved runways 914 to 1 S> 3m 33
1YYS est.)
Heliports: 4 (1995 est)
Reilways:
total: SAYS km
96 km 1.676-m gauge
hroad eauve
standard gauge: 4.997 km 1.432-m gauge
(146 km electnfied) (1995)
Highways:
total: 140,200 km
paved 42.700 km
unpaved: 97.500 km (1995 est.)
Waterways: 904 km: the Shatt al Arab ts
usually navigable by maritime traffic tor
about 130 km: channel has been dredged to
3m and ts in use
Pipelines: crude oil 5.900 km: petroleum
products 3.900 km: natural gas 4.550 km
Ports: Abadan (largely destroyed in fighting
dunng 1980-88 war). Ahvaz. Bandar
Beheshtr. Bandar-e “Abbas. Bandar-e Anzali.
Bandar-e Bushehr. Bandar-e Khomeyni.
Bandar-e Mah Shahr. Bandar-e Torkeman,
Jazireh-ye Khark. Jazireh-ye Lavan. Jazireh-
ye Sim. Khorramshahr (limited operation
since November 1992). Now Shahr
Merchant marine:
total: 130 ships (1.000 GRT of over) totaling
2.791. 892 GRT/4.891.615 DWT
ships by type: bulk 47, cargo 41. chemical
tanker 5. combination bulk 2. liquefied gas
tanker |, multifunction large-load carner |.
oil tanker 19, refmgetated cargo 3. roll-on/
roli-off cargo 9. short-sea passenger |.
specialized tanker 1 (1995 est.)
Airports:
total: 212
with paved runwavs over 3.047 m:
with paved runways 2.438 to 3.047 m: 11
with paved runways 1,524 to 2.437 m: 3N
with paved runways 914 to 1,523 m: 17
with paved runways under 914m: 22
with unpaved runways over 3.047 m: |
with unpaved runways 2.438 to 3,047 m: 2
with unpaved runways 1,524 to 2.437 m: 10
with unpaved runways 914 te 1,523 m: BS
(1995 est.)
Heliports: |2 (1995 est)
railways:
total: 2.032 km
standard gauge: 2.032 km |.435-m gauge
Highways:
total: 45.554 kin
paved: 38,402 km (including 976 km of
expressways)
unpaved: 7.452 km (1989 est.)
Waterways: 1.015 km: Shatt al Arab ts
usually navigable by maritime traffic tor
about 130 km: channel has been dredged to
3 meters and ts in use: Tigris and Euphrates
Rivers have navigable sections tor shallow-
draft watercraft; Shatt al Basrah canal was
navigable by shallow-draft cratt before
closing in 199! because of the Persian Gulf
war
Pipelines: crude oi] 4.350 km: petroleum
products 725 km: natural gas 1.360 km
Ports: Unim Qasr. Khawr az Zubayr. and Al
Merchant marine:
total: 36 ships (1.000 GRT or over) totaling
795.346 GRT/1 432.292 DWT
ships by type: cargo 14, oil tanker 16.
passenger |. passenger-cargo i. refmgerated
cargo 1, rell-on/roll-off cargo 3 (1995 est.)
Airports:
total: 102
with paved runways over 3,047 m: 2\\
with paved runways 2,438 to 3,047 m: 34
with paved runways 1,524 to 2.437 m: &
with paved runways 914 to 1,523 m: 6
with paved runways under 914 m: 16
with unpaved runways over 3,047 m: 2
with unpaved runways 2.438 to 3.047 m: 3
with unpaved runways 1,524 to 2,437 m: 3
with unpaved runwavs 914 to 1,523 m: 9
(1995S est.)
Heliports: 5 (1995 est.)
Railways:
total’ 1.806 km (Peninsular Malaysia 1.672
km. Sabah 124 km: Sarawak O km)
298
2.5474 (1992).
narrow gauge: 1.806 km 1.000-m gauge
(Peninsular Malaysia 1.672 km: Sabah 134
km)
Highways:
total: 92.545 km
paved: 69.409 km Uncluding 574 km ot
CAPTessW ays)
Defense
Branches: Malaysian Army. Royal
Malaysian Navy. Royal Malaysian Air Force.
Royal Malaysian Police Force. Marine |
Police. Sarawak Border Scouts
Manpower availability:
males age 15-49: 5 160.884
unpaved: 23.136 km (1992 est.) .
males tit for military service: 3.129.626
Waterways:
Peninsular Malaysia: 3.209 km
Sabah: 1.569 km
Sarawak: 2.518 km
Pipelines: crude oi! 1.307 km: natural gas
379 km
Ports: Kota Kinabalu, Kuantan. Kuching.
Kudat. Lahad Datu. Labuan. Lumut. Mir.
Pasir Gudang. Penang. Port Dickson, Port
Kelang. Sandakan. Sibu. Tanjong Berhala.
Tanjong Kidurong. Tawau
Merchant marine:
total: 248 ships (1.000 GRT or over) totaling
3.035.684 GRT/4.494.476 DWI
sips by type: bulk 43. cargo 83. chemical
males reach military age (21) annually:
184.236 (1996 est.)
Defense expenditures: exchange rate
conversion—S$2.4 billion, 2.9% of GDP
(1995)
tunker 13. contamer 31. liquetied gas tanker
12. livestock carner |. onl tanker 55. roli-on/
roll-off cargo 5. short-sea passenger 1.
vehicle carrer 4. (1995 est.)
\\irports:
total. JOS
wath paved raways over 3,047 me 3
2438 to 3047 mFS
vith paved runways 1.524 to 2.437 m 11
with paved runways
with paved runways 914 to 1.523 m6
nih paved runways under Yl4 m: 74
with unpaved runways 1,524 to 2.437 m: |
Meth unpaved runways GYl4 to 1 S23 me §
11YYS est}
,s
Heliports: 2 (1) 995 est)
established—\\-6 September 1961
aim—to establish political and military
cooperation apart from the traditional East
or West blocs
members—(111 pius the Palestine Liberation Organization) Afghanistan, Algeria, Angola,
The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana,
Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African
Republic, Chad, Chile, Colombia, Comoros, Congo, Cote d’Ivoire, Cuba, Cyprus, Djibouti,
Ecuador, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras, India, !ndonesia, Iran, Iraq, Jamaica,
Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar.
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua
New Guinea, Peru, Philippines, Qatar, Rwanda, Saint Lucia, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Somalia, South Africa, Sri Lanka,
Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Uganda, UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zaire, Zambia,
Zimbabwe, Palestine Liberation Organization
observers—(20) Afro-Asian Solidarity Organization, Antigua and Barbuda, Arab League.
Armenia, Azerbaijan, Brazil, China, Costa Rica, Croatia, Dominica, El Salvador, Kanuka
Socialist National Liberation Front (New Caledonia), Mexico, Mongolia, Organization of
African Unity, Organization of the Islamic Conference, Socialist Party of Puerto Rico, UN,','5e653b4d78c8206235cb47b3e1681839ddd0d6a5785f897820ec589f8ec17c2f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33eb773460c570fe2dd83d1f10f9964b37777a3f5e0c4c864791f13337bab987',1996,'JE','Jersey','transportation',488,'Railways:
tal: S26 km
standard gauge: 526 km 1.435-m gauge
Highways:
total: 13.461 km
paved: 13.461 kim (including 56 km of
CAPTessWal ‘)
unpaved: Okm (1992 est.)
Pipelines: crude oil 7O8 km: petroleum
products 290 km: natural gas 89 km
Ports: Ashdod. Ashgelon. Elat. Hadera
Haita, Tel Aviv-Yato
Merchant marine:
total: 28 ships (1.000 GRT or over) totaling
$77,747 GRT/701.459 DWT
ships by type: cargo 5. container 20
retrigerated cargo 2. roll-on/roll-off cargo |
(1995 est.)
\\irports:
tatal: SO
ith paved runways over 3,047 m: 2
ith paved runways 2.438 to 3,047 m: 6
2437 mm: 7
ith paved runways 914 to 1,523 m: &
’ , id
'' qeice é* )
in paved runways 1,524 t
oie)
ith paved runways under 914m
+
ith unpaved runways 1,524 to 2.457 m
vith unpaved runways 914 to 1,523 m: 3
{ 1YOS est }
Heliports: 2 (1995 est.)
British crown dependency)
Railways: 0 km
Highways:
roatal: NA km
paved: NA km
unpaved: NA km
Ports: Gorey. Saint Aubin. Saint Helter
Merchant marine: none
Airports:
total: |
with paved runways 1,524 to 2,437 m
(1995 est.)
Railwesys: 0 kin
Highways:
total NA km
paved: NA km
mpaved: NA km
Ports: Johnston Island
Airports:
with paved runwa
i} YOS csi }
247
Johnston Atoll (continued)
( ommunications
bel phones: NA
telephone system: 52 telephone lines
’ 60-channe!l submarine cable. 22
DSN circuits by satellite. Autodin with
‘minal. digital telephone
Mi Attiliated Radio System
ARS stat LCHE/VHE air-ground radio
} { v | ;
Net PCTN
oad
YA
Radio broadcast stations: AM NA. FM 5
N \\
Radios: \\
felevision broadcast stations: \\.\\
eles tsions
Delense
DetTense note: t] I OOSIDETEN
248','3e4d65e42a32ae2e706cefcabca8d50ae84f9c746977ec3aa9da051ae9250dca','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f148df68479da939c9c3f344121a85390e75256821d5ed29ce429df56d4e0b2',1996,'JM','Jamaica','transportation',496,'Railways:
total: 272 km
standard gauge: 272 km 1.435-m gauge
note—207 km belonging to the Jamaica
Railway Corporation which were in commen
camer service are no longer operational: the
remaining track is privately owned and used
lo transport bauxtte
Highways:
total: 18.094 km
paved: 12.528 km
unpaved: 5.566 km (19RR et.)
Pipelines: petroleum products 10 km
Ports: Alligator Pond. Discovery Bay
Kingston, Montego Bay. Ocho Rios. Port
Antonio, Longs Whart. Rocky Point
Merchant marine:
total: 2 ships (1.000 GRT or over) totaling
3.435 GRT/6.108 DWT
vups by type: ol tanker 1. roll-on/roll-oft
cargo 1 (1995 est.)
Airports:
total 27
with paved runways 2.438 to 3,047 m: 2
with paved runways 914 to 1,523 m: 3
with paved runways under 914m: 2
with unpaved runways 914 to 1,523 m: |
(1995 est.)
Highways
\\ \\ q
\\ \\ 0
j \\ \\ 5
Ports:
Airports:
ws
242','95ca0ce50ed10f530b0b46ef5596364f0ded1fb69270011c99818002c3cd6ed4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50b3183fb699fa0772d926583ba49f55f79d1eb0959bf0cca61e059adfa48757',1996,'JO','Jordan','transportation',504,'Railways:
Potal: 676 ka
narron wild fykuy Ss ,
note—an additional kim stret (4
old Hedyayz rath
Highways:
otal: S.OSO Ke
Pipelines: crock
Ports: Al Agabah
Merchant marine:
total: 3 bulk ship WOR I
totaling 4).960 GRI DWI ys
est
Airports:
uj ’ ’
iteidd >
nuh Puiica TMNwWays unde} Y/4 aii | (1995 Juan de Nova Island
est.) (possession of France)','1e2f4ff1407d11b1fec422321202d036cd4887e69859deec2dc6ded265723a6b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('080992945e05ac3942e67687d41e6695c64a9c859ae3bccbafc173dc81d7799d',1996,'KW','Kuwait','transportation',509,'Railways: 0 km
Highways:
total: 4.273 km
paved: NA km (including 280 km of
expressways) (1989 est.)
unpaved: NA km
Pipelines: crude oi! 877 km: petroleum
products 40 km: natural gas 165 kin
Ports: Ash Shu aybah, Ash Shuwaykh.
Kuwait, Mina’ “Abd Allah. Mina’ al
Ahmadi, Mina’ Suud
Merchant marine:
total: 46 ships (1,000 GRT or over) totaling
2.053.667 GRT/3.242.305 Dwi
ships by type
conversion—S$3.5 billion
(FY95/96)
cargo 10. container 3
liquefied gas tanker 7. livestock carer 4, oi!
tanker 21
Airports:
total: 4
with paved runways over 3.047 m: 3
vs 24388 to 3.047 ino |
vehicle carner | (1995 est)
with paved runw
(1995S est.)
Heliports: | (1995 est)
Ruilwass "
Highways:
, i kn
Waterways: ab } 4x7 4
Met wributas By
"T than 4
ray ii
Pipelines: petroleur aduct (4
Ports:
Merchant marine:
| cargo stup (1.000 GRI
VO GRT AO DW QV
hang
269
Laos (continued)
Airports:
;','d40d9fa4049fad3342eaf7da82655d8d96d1a98331750395101a83cb067e00c7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68e4202b3ee263308a3bc56d10812b5c903f709786da36e47bf931f645896538',1996,'LV','Latvia','transportation',519,'Railways:
total; 222 km
standard gauge: 222 km 1.435-m (from
Beirut to the Syrian border)
Highways:
total: 7.370 km
paved: 6,265 km
unpaved: 1.105 km (1990 est.)
Pipelines: crude oi! 72 km (none in
operation)
Ports: Al Batrun. Al Mina. An Naqurah,
Antilyas, Az Zahrani, Beirut, Jubayl,
Juniyah, Shikka, Sidon, Tripoli. Tyre
Merchant marine:
total: 58 ships (1,000 GRT or over) totaling
192.075 GRT/296,256 DWT
ships by type: bulk 4, cargo 39, chemical
tanker 1, combination bulk ?, combination
ore/oil 1, container 2, livestock carrier 4.
refrigerated cargo 1, roll-on/roll-off cargo 2.
specialized tanker |. vehicle carrier 2 (1995
ent.)
Airports:
total: 7
with paved runways ever 3,047 m: |
with paved runways 2,438 to 3,047 m: 2
with paved runways 1,524 to 2.437 m |
with paved runways under 914 m. 2
with unpaved runways 914 to 1,523 m: |
(1995 est.)','da97e36d1f4fd38daf39a9eae9f093f66b2d5fcd9d76fdc5ddf9ab31d42795d5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c843fb67aef72d653b77e40c3aab2bf5ca186646d7e59e062ab9f5e78507d08',1996,'ZA','South Africa','transportation',525,'Railways:
2.6 km: note
and included in the statistics of South Atnica
total owned by. operated by.
RaITOW Cate
Highways:
natal: S324 km
pared: 799 km
unpaved 4.525 km (1993 est.)
Ports: none
Airports:
total, 29
with paved runways over 3 O47 me: |
26 km 1.067-m gauge
with parea runwars 914 to 1528 me |
with paved runvavs under C14 me 23
with unpaved runways 914 to 1.523 m: 4
(1995 est.)
Railways:
total 490 km (single track): note—three rail
syMems owned and operated by foreign sicel
and financial interests in conjunction with
Liberian Government, one of these. the
Lameo Railroad, closed in 1989 after iron
ore production ceased: the other two have
been shut down by the civil war
siandard gauge: 345 km 1.435-m gauge
narrow gauge: 145 km 1.067-m gauge
Highways:
total: 10.029 kin
paved: 600 km
unpaved: 9.429 km (1987 est.)
Ports: Buchanan. Greenville. Harper.
Monrovia
Merchant marine:
total: 1.601 ships (1.000 GRT or over)
totaling 59.449.296 GRT/98.819.081 DWT
ships by tvpe: barge carner 2. bulk 411.
carg 121. chemical tanker 108, combination
bulk 28. combination ore/oil 56, container
143. liquefied gas tanker 77. multifunction
large-load carner 1. of tanker 463. paysenger
42. passenger-cargo |, refrigerated cargo 64.
roll-on/roll-off cargo 23. short-sea passenger
4. specialized tanker 9, vehicle carer 48
note: a flag of convemence registry. includes
ships trom S59 countries among which are US
253. Japan 172. Norway 165. Germany 149.
Greece 137. Hong Kong 114. UK 78. China
49. Monaco 41. and Cyprus 34 (1995 est)
Airports:
total; 39
with paved runways over 3,047 me: |
with paved runways 1,524 to 2.437 m1
with paved runways under 914 m: 29
with unpaved runways 1,524 to 2.437 m: 2
with unpaved runways 914 to 1,523 m6
(1995 est.)
Railways:
total: 21.431 km
narrow gauge: 20.995 km 1.067-m gauge
(9.087 km electrified); 436 km 0.610-m
gauge (1995)
Highways:
total: 182,329 km
paved: 55,428 km (including 2,040 km of
expressways)
unpaved: 126,901 km (1991 est.)
Pipelines: crude oil 931 km: petroleum
products 1,748 km; natural gas 322 km
Ports: Cape Town, Durban, East London.
Mosselbaai, Port Elizabeth, Richards Bay.
Saldanha
Merchant marine:
total: 4 container ships (1,000 GRT or over)
totaling 21!.276 GRT/198.602 DWT (1995
est.)
Airports:
total: 667
with paved runways over 3,047 m: 10
with paved runways 2.438 to 3,047 m: 4
with paved runways | 524 to 2,437 m: 44
with paved runways 9/4 to 1,523 m: 75
with paved runways under 914 m: 221
with unvaved runways 1,524 to 2,437 m: 33
with unpaved runways 914 to 1,523 m: 280
(1995 est.)
Railways:
total: 14.74? jan
broad gauge: 12.139 km 1.668-m gauge
(6.510 km electrified; 2.295 km double
track)
standard gauge: 488 km 1.435-m gauge (488
km electrified)
narrow gaxge: 1.716 km (privately owned
1.669 km 1.000-m gauge, 489 km electnfied:
28 km 0.914-m gauge. 28 km electntied:
government owned: 19 km 1.000-m gauee,
all electrified)
Highways:
total: 331.961 km
paved: 328.641 km (including 2.700 km of
exrwessways)
unpaved: 3.320 km (1991 est)
Waterways: 1.045 km. but of minor
coononmic importance
Pipelines: crude oi! 265 km, petroleum
products 1.794 km. natural gas 1,666 km
Ports: Aviles, Barcelona, Bilbao, Cadiz,
Cartagena, Castellon de la Plana, Ceuta.
Huelva, La Coruna, Las Palmas (Canary
Islands), Malaga. Melilla, Pasayes. Puerto de
CGayon, Santa Cruz de Tenente (Canary
Islands), Santander, Tarragona, Valencia.
Vigo
Merchant marine:
total: 147 ships (1.000 GRT or over) totaling
874.688 GRT/1.391,.421 DWT
ships by type: bulk 9, cargo 36, chemical
tanker 11, combination ore/oil 1, container 8,
lnquetied gas tanker 4, oil tanker 25,
passenger 2.
refrigerated cargo | 2, roll-on/
roll-off cargo 32, short-sea passenger 6,
specialized tanker 1 (1995 est.)
Airports:
total: 9%
with paved runways over 3,047 m: 1S
with paved runways 2,438 to 3.047 m1
with paved runways 1,524 to 2,437 m: 1§
with paved runways 914 to 1,523 m: 13
with paved runways under 914 m: 28
with unpaved runways 1,524 to 2.437 m: 2
with unpaved runways 914 to 1,523 m: 12
(1995 est.)
Heliports: 2 (1995 est.)
Ports: none
Airnorts:
lota. 4
with paved runways 914 to TS23 im: |
with paved runways wader 914m. 2
with unpaved runways 914 to 1,523 m: |
{ 1Vu ’ cM }
established—\\|1 December 1969
aim—jo promote free trade and
cooperation in customs matters
members—{5) Botswana, Lesotho, Namibia. South Africa. Swaziland
Southern African Development
Community (SADC)
note—evolved from the Southern African
Development Coordination Conference
(SADCC)
address—Private Bag 008, Gaborone,','902fd22f2298b3dc6e835f4c7003b413885ef9aeafc1bddebb0aa9fe039d4aac','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9534846f4c3b601de8f80ccfa034e0e342cdfb36f8bca68776642e29e02ff63',1996,'TN','Tunisia','transportation',531,'Railways:
note. Libya has had no railroad in operation
since 1965, all previous systems having been
dismantled: current plans are to construct a
1.435-m standard gauge line from the
Tunisian frontier to Tripoli and Misratah.
then inland to Sabha, center of a mineral-rich
area, but there has been no progress: other
plans made jointly with Egypt would
establish a rail line from As Sallum, Egypt.
to Tobruk with completion set for mid-1994;
no progress has been reported
Highways:
total: WY ARY km
paved: 10.738 km
unpaved: 8.451 km (1987 est.)
Waterways: none
Pipelines: crude oi! 4.383 km: petroleum
products 443 km (includes liquefied
87
petroleum gas 256 km): natural gas 1.947
kim
Ports: A: Khums. Banghazi, Darnah. Marsa
al Burayyah, Misratah. Ra''s Lanuf, Tobruk.
Tripoli, Zuwarah
Merchant marine:
jotal: 30 shups (1.000 GRT or over) totaling
686.834 GRT/1.209.263 DWT
siups by type: cargo 10. chemucai tanker |.
liquetied gas tanker 2. oil tanker 10. roll-on/
roll-olf cargo 3. short-sea passenger 4
note: Labya owns an additional 6 ships
(1.000 GRT or over) totaling 38.260 DWT
operating under the regisines of Algena and
Turkey (1995 est)
Airports:
total: 10
with paved runways over 3,047 m: 24
with paved runways 2.438 to 3,047 m: §
with paved ranways 1,524 to 2.437 m: 22
with paved runways 914 to 1,523 m: 6
with paved runways under 914 m: 13
with unpaved runways over 3.047 m: 4
with unpaved runways 2.438 to 3,047 m: 3
with unpaved runways 1,524 to 2.437 m: 1S
with unpaved runways 914 to 1,523 m: 8
(1995 est.)
Ports: none: offshore anchorage only
Airports:
total: |
with paved runways under 914 m: 1 (1995
est.)','5a3d5055b8adae7f29b8a3048c7f34f9c7e14a3ca1e7f33ddfe4796e72e8f328','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1997fab2d4269f6ff41ee8c41011adec92326aa4e65e45d9e005614f3ba58d1',1996,'LI','Liechtenstein','transportation',538,'Railways:
total: 18.5 km. note—owned, operated. and
included in statrstics of Austrian Federal
Railways
standard gauge: 18.5 km 1.435-m gauge
(electrified)
Highways:
total: 238 km
paved: 23% km
unpaved. 0 ky. (1986 est.)
Ports: none
Airports: none','386d5fc6f8b432333b34a0a874b643100278d1e4b6b4f37caf1f0e5d86c34345','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0dd1ec7629a4abcc142ed55b30726887a6113d2350320130875747f0813038a',1996,'LT','Lithuania','transportation',540,'Railways:
total: 2.002 km
broad gauge: 2.002 km 1.524-m gauge (122
km electritied) (1994)
Highways:
total’ 55.603 km
paved: 42.209 km (including 382 kim of
eAPTressways)
unpaved: 13.394 km (1994)
Waterways: 600 km perennially navigable
Pipelines: crude oil, 10S km: natural gas 760
km (1992)
Ports: Kaunas. Klaipeda
Merchant marine:
total: 43 ships (1.000 GRT or over) totaling
264.639 GRT/303.649 DWT
ships by type: cargo 26, combination bulk
11. of tanker 2. railcar carner 1. roll-on/roil-
off cargo 1, short-sea passenger 2 (1995 est)
Airports:
total: 96
with paved runways over 3.047 m3
with paved runways 2.438 to 3,047 m: 2
with paved runways 1,524 to 2.437 m 4
with paved runways 914 to 1.523 m
with paved runways under 914 m4
with unpaved runways 2.438 to 3.047 m- |
with unpaved runways 1,524 to 2.437 m |
with unpaved runways 914 to 1,523 m6
with unpaved runways under 914 m- 63
(1994 esi.)','a0b813eeb3dc2cf66d3ff0bb6894d13a964a4b0789c39d0b42e6f64f3b4616e1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc0a81e92afe605eeffc03adbaea9cc9404e182ead677ba285bed1f1b13339a1',1996,'LU','Luxembourg','transportation',548,'Railways:
total: 275 km
standard gauge: 275 km 1.435-m gauge (262
km electrified: 178 km double track) (1995)
Highways:
total: 5.134 km
paved: 5.088 km (including 121 km of
expressways)
unpaved: 46 km (1995 est.)
Waterways: 37 km: Moselle
Pipelines: petroleum products 48 km
Ports: Mertert
Merchant marine:
total: 36 ships (1.000 GRT or over) totaling
825.496 GRT/1.238.354 DWT
ships by type: bulk 3. chemical! tanker 4.
combination bulk 6, container 2. Inquetied
gas tanker 6, oil tanker 5, passenger 2
refrigerated cargo 6, roll-on/roll-ott cargo 2
(1995 est.)
Airports:
total: 2
with paved runways over 3.047 m- |
with paved runways under 914m. 1 (1995
est.)
Railways:
total, 704 km (single track). note—owned
and operated by government mining
company
standard gauge. 704 km | 435-m gauge
(1995S)
Highways:
total: 7496 km
paved: 1342 km
unpaved: 6.154 km (1987 est.)
Waterways: mostly ferry traffic on the
Senegal River
Ports: Bogue. Kacdi. Nouadhibou.
Nouakchott, Rosse
Merchant marine: pone
Airports:
total: 24
with paved runways 2.438 te 3047 me: 3
with paved runways 1.524 to 2.437 m 4
with paved runways 914 to 1 S23 m |
with paved runways under 9/4 m 2
with unpaved runways 243° to 304
with unpaved runways 1524 to 2437 #
with unpaved runways Yidg te 1 S23 m9
(1995 est)','c7924cb795f5e2d937ae86095f322f3aaf1993d33e6248317371fb11011b90ec','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24bf7883a556b8b38b23ca5d0054696cd50e5a8235f30980badbea2c38ad5414',1996,'ZW','Zimbabwe','transportation',550,'2
Ceography
Location: Southern Africa, east of Zambia
Ceographic coordinates: |3 30S. 34 00 F
Map references: Africa
Area:
total area: 118.480 sq km
land area: 94.080 sq km
comparative area: slightly larger than
Pennsylvania
Land boundaries:
total: 2.881 km
border countries: Mozambique 1.569 km,
Tanzania 475 km. Zambia 837 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
International disputes: dispute with
Tanzania over the boundary in Lake Nyasa
(Lake Malawi)
Climate: tropical: rainy season (November
to May). dry season (May to November)
Terrain: narrow elongated plateau with
rolling plains. rounded hills. some mountains
lowest point: yanction of the Shire River and
international boundary with Mozambique 37
m
highest point: Mount Mlanje Sapitwa 3.002
m
Natural resources: limestone. unexploited
deposits of uranium. coal. and bauxite
Land use:
arable land: 25%
permanent crops: O%
meadows and pastures: 20%
forest and woodland: 30%
other: 5%
Irrigated land: 200 sy km (1989 est)
Railways:
total: 2,164 km (1995)
narrow gauge: 2,164 km 1.067-m gauge (13
km double track)
note: the total includes 891 km of the
Tanzania-Zambia Railway Authority
(TAZARA), which operates 1.860 km of
|.067-m narrow gauge track between Dar es
Salaam and New Kapiri M’poshi where it
connects to the Zambia Railways system:
TAZARA is not a part of Zambia Railways
Highways:
total: 37,359 km
paved: 6.575 km (including 56 km of
express Ways)
unpaved: 30,784 km (1992 est.)
Waterways: 2.250 km. including Zambezi
and Luapula rivers, Lake Tanganyika
Pipelines: crude cil 1.724 km
Ports: Mpulungu
Airports:
total: 104
with paved runways over 3,047 m: |
with paved runways 2,438 to 3,047 m: 3
with paved runways 1,524 to 2,437 m: 4
with paved runways 914 to 1,523 m: 2
with paved runways under 914 m: 35
with unpaved runways 2,438 to 3,047 m: \\
with unpaved runways 1,524 to 2,437 m: 4
with unpaved runways 914 to 1,523 m: 54
(1995 est.)
Railways:
total: 2.759 km (1995)
narrow gauge: 2.759 km 1.067-m gauge
(313 km electnitied: 42 km double track!
(1995 est.)
Highways:
total: 91.07% km
paved: 14,572 km
unpaved: 76.506 km (1992 est.)
Waterways: Lake Kariba ts 4 potential line
of communication
Pipelines: petroleum products 212 km
Ports: Binga, Kariba
Airports:
total; 403
with paved runways over 3,047 m: 3
with paved runways 2,438 to 3,047 m: 2
with paved runways 1,524 to 2,437 m: 6
with paved runways 914 to 1,523 m: 8
with paved runways under 914 m: 185
with unpaved runways 1,524 to 2,437 m: |
with unpaved runways 914 to 1,523 m: 198
(1995 est.)
International Court of Justice (ICJ)
note—also known as the World Court
address—Peace Palace. NL-2517 KJ The
Hague, Netherlands
telephone—{31| (70) 302 23 23
FAX—(31] (70) 364 99 28
established--26 June 1945
effective—24 October 1945
aim—primary judicial organ of the UN
members— 15 judges) elected by the UN General Assembly and Security Council to represent
all principal legal systems
International Criminal Police
Organization (Interpol)
address—BP 6041, F-69411 Lyon CEDEX
06, France
telephone—{33)\\ 71 44 70 00
FAX—{33] 72 44 71 63
established—\\3 June 1956
aim—to promote international cooperation
among police authorities in fighting cnme
members—({176) Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina,
Armenia, Aruba, Australia, Austria, Azerbaijan. The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon. Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia. Congo, Costa Rica, Cote
d''Ivuire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt. El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland
France, Gabon, The Gambia, Georgia, Germany. Ghana, Greece, Grenada, Guatemala, Guinea
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India. Indonesia, Iran. Iraq.
ireland, Israel, italy. Jamaica, Japan, Jordan, Kazakstan, Kenya, Kiribati, South Korea.
Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein. Lithuania.
Luxembourg, The Former Yugoslav Republic of Macedonia. Madagascar. Malawi, Malaysia.
Maldives, Mali, Malta. Marshall Istands, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique. Namibia, Nauru. Nepal. Netherlands. Netherlands Antilles.
NZ, Nicaragua, Niger, Nigeria, Norway. Oman. Pakistan. Panama. Papua New Guinea,
Paraguay. Peru, Philippines, Poland, Portugal, Qatar. Romania, Russia, Rwanda, Sait Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines. Sao Tome and Principe. Saudi
Arabia. Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia. Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname. Swaziland, Sweden. Switzerland. Syria, Tanzania.
Thailand, Togo, Tonga. Trinidad and Tobago. Tunisia, Turkey, Uganda. Ukraine. UAE, UK.
US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen. Zaire, Zambia. Zimbabwe
subbureaus— 11) American Samoa, Anguilla. Bermuda, British Virgin Isiands. Cayman
Islands, Gibraltar, Hong Kong, Macau. Montserrat, Puerto Rico, Turks and Caicos Islands
International Development Association
(IDA)
address—181\\8 H Street NW, Washington.
DC 20433, USA
telephone—{\\} (202) 477 12 34
established—26 January 1960
effective—24 September 1960
aim—UN specialized agency and IBRD
affiliate that provides economic loans for
low imcome countries
members— 158)
Part I—{24 more economically advanced countries) Australia, Austria, Belgium. Canada.
Denmark, Finland, France, Germany. Iceland, Ireland. Italy, Japan, Kuwait, Luxembourg.
Netherlands, NZ, Norway, Russia. South Africa. Sweden, Switzerland. UAE. UK, US
Part 11—(134 less developed nations} Afghanistan, Albania, Algeria, Angola, Argentina.
Armenia, Azerbaijan, Bangladesh. Belize, Benin, Bhutan, Bolivia, Botswana. Brazil, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde. Central African Republic, Chad.
Chile, China, Colombia, Comoros, Congo. Costa Rica, Cote d''Ivoire. Croatia, Cyprus. Czech
Republic, Djibouti, Dominica, Dominican Republic. Ecuador. Egypt. El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, Gabon. The Gambia, Georgia, Ghana, Greece, Grenada.
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras. Hungary. India, Indonesia. Iran.
iraq, Israel, Jordan. Kazakstan, Kenya, Kiribati. South Korea, Kyrgyzstan. Laos. Latvia.
Lebanon, Lesotho, Liberia, Libya, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Mongolia, Morocco, Mozambique. Nepal.
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea. Paraguay. Peru
Philippines, Poland, Portugal, Rwanda, Saint Kitts and Nevis. Saint Lucia. Sait Vincent
and the Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal. Sierra Leone. Slovakia.
Slovenia, Solomon Islands, Somalia, Spain. Sn Lanka, Sudan, Swaziland, Syria, Tajikistan.
Tanzania, Thailand, Togo. Tonga, Trinidad and Tobago. Tunisia, Turkey. Uganda, Uzbekistan,
Vanuatu, V-ctnam, Western Samoa. Yemen, Zaire, Zambia, Zimbabwe
International Energy Agency (IEA)
address—2 rue Andre Pascal, F-75775
Paris CEDEX 16, France
telephone—{33\\ (1) 45 24 82 00
FAX—{33] (1) 45 24 99 8&8
established—\\15 November 1974
aim—A0 promote cooperation on energy
matters, especially emergency oi! sharing
and relations between oil consumers and
oil producers; established by the OBCD
members—(23) Australia, Austria, Belgium, Canada, Denmark. Finland, France, Germany,
Greece. Ireland, Italy. Japan. Luxembourg, Netherlands. NZ, Norway, Portugal, Spain.
Sweden, Switzerland, Turkey, UK. US
International Federation ef Red Cross
and Red Crescent Societies (IFRCS)
note—tormerly known as League of Red
Cross and Red Crescent Societies
(LORCS)
uldress—P.O.B. 372. CH-121! Geneva 19.
International Investment Bank (IIB)
established on 7 July 1970. to promoie economic development: members were Bulgaria.
Cuba, Czechoslovakia, East Germany. Hungary, Mongolia, Poland, Romania. USSR. Vietnam:
now it is a Russian bank with a new charter
International Labor Or) anization (ILO)
address—International Latwor Office, 4
route des Morillons, CH-1211 Geneva 22.
international Organization for
Standardization (ISO)
address—CP 56, | rue de Varembe, CH-
1211 Geneva 20, Switzerland
telephone—|[41} (22) 749 O1 11
FAX—{41} (22) 733 34 30
established—NA February 1947
aim—to promote the development of
international standards with a view to
facilitating international exchange of goods
and services and to developing cooperation
in the sphere of intellectual, scientific,
technological and economic activity
members—{76 national standards organizations) Albania, Algeria, Argentina, Australia.
Austria, Bangladesh, Belarus, Belgium. Brazil, Bulgaria, Canada, Chile, China, Colombia,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Egypt. Ethiopia, Finland, France, Germany,
Greece, Hungary, Iceland, India. Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Kenya,
North Korea, South Korea, Libya, Malaysia, Mexico, Mongolia, Morocco, Netherlands, NZ,
Norway, Pakistan, Philippines, Poland, Portugal, Romania, Russia, Saudi Arabia, Singapore,
Slovakia Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Tanzania,
Thailand, ‘lrimidad and Tobago, Tunisia, Turkey. Ukraine, UK. US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yugoslavia, Zimbabwe
correspondent members-—(19) Bahrain, Barbados, Brunei. Estonia, Hong Kong, Jordan,
Kuwait. Lithuania, Malawi, Malta, Mauritius, Nepal, Oman, Papua New Guinea, Peru, Qatar,
Turkmenistan, Uganda, UAE
subscriber members—4) Antigua and Barbuda, Burundi, Grenada, Saint Lucia
International Red Cross and Red
Crescent Movement (ICRM)
address—-CICR, 19 Avy de la Paix. CH-
1202 Geneva, Switzerland
telephone—{41] (22) 734 60 O1
FAX—|41} (22) 733 20 57
established—NA 1928
aim—to promote worldwide humanitarian
aid through the {nternational Committee of
the Red Cross (ICRC) in wartime. and
International Federation of Red Cross and
Red Crescent Societies (IFRCS: formerly
League of Red Cross and Red Crescent
Societies or LORCS) in peacetime
National Societies—(161 countries) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Australia, Austria, The Bahamas. Bahrain, Bangladesh, Barbados,
Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Czech Republic, Denmark,
Djibouti. Dominica, Dominican Republic, Ecuador, Egypt. El Salvador, Estonia, Ethiopia,
Fiji, Finland, France, The Gambia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea.
Guinea-Bissau, Guyana, Haiti. Honduras. Hungary. Iceland, India, Indonesia, Iran, Iraq,
Ireland, Italy, Jamaica, Japan, Jordan, Kenya, North Korea, South Korea, Kuwait, Laos,
Latvia, Lebanon, Lesotho. Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar.
Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco.
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan. Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo. Tonga,
Trinidad and Tobago, Tunisia, Turkey. Uganda, Ukraine, UAE, UK, US, Uruguay, Vanuatu,
Venezuela, Vietnam, Western Samoa, Yemen, Yugoslavia, Zaire, Zambia, Zimbabwe
574
International Telecommunication Union
(ITU)
address—Place des Nations, 1211 Geneva
20, Switzerland
telephone—{41] (22) 730 51 11
FAX—|41] (22) 733 72 56
established—9 December 1932
effective—\\ January 1934
affiliated with the UN—\\15 November 1947
aim—to deal with world
telecommunications issues: a UN
specialized agency
members—( 184) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Ciile, China, Colombia, Comoros,
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominican Republic, Ecuador, Egypt, El Salvador. Equatorial Guinea, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece.
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See. Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, ireland, Israel, Italy, Jamaica, Japan, Jordan. Kazakstan.
Kenya, Kiribati, North Korea. South Korea, Kuwait, Kyrgyzstan, Laos. Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives. Mali, Malta, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru. Philippines, Poland, Portugal.
Qatar. Romania, Russia, Rwanda, Saint Vincent and the Grenadines, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Sierra Leone. Singapore, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname. Swaziland. Sweden.
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga. Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay. Uzbekistan,
Vanuatu, Venezuela, Vietnam, Western Samoa, Yemien, Yugoslavia (suspended), Zaire.
Zambia, Zimbabwe
International Telecommunications
Satellite Organization (Intelsat)
address—Intelsat. 3400 International Drive
NW, Washington, DC 20008-3098, USA
telephone—{1} (202) 944 6800
FAX—([\\] (202) 944 7860
established—20 August 197]
effective—12 February 1973
aim—to develop and operate a global
commercial telecommunications satellite
system
members— 136) Afghanistan, Algeria, Angola, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Benin, Bhutan, Bolivia,
Botswana, Brazil, Brunei, Burkina Faso, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Congo, Costa Rica, Cote dIvoire, Croatia, Cyprus,
Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Ethiopia. Fiji,
Finland. France, Gabon, Germany, Ghana, Greece, Guatemala, Guinea, Haiti. Holy See.
Honduras, Hungary, Iceland. India, Indonesia, Iran, Iraq, Ireland. Israel. Italy, Jamaica, Japan,
Jordan, Kazakstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Lebanon, Libya, Liechtenstein.
Luxembourg, Madagascar, Malawi, Malaysia. Mali, Malta, Mauritania, Mauritius, Mexico.
Federated States of Micronesia, Monaco, Morocco, Mozambique, Namibia, Nepal.
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru. Philippines. Poland, Portugal, Qatar, Romania, Russia, Rwanda.
Saudi Arabia, Senegal, Singapore, Somalia, South Africa, Spain. Sri Lanka, Sudan, Swaziland,
Sweden, Switzerland, Syria, Tanzania. Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey.
Uganda, UAE, UK, US, Uruguay. Venezuela, Vietnam, Yemen, Yugoslavia, Zaire. Zambia,
nonsignatory users—(48) Albania, Antigua and Barbuda, Belarus. Belize, Bosnia and
Herzegovina, Bulgaria, Burma, Burundi, Cambodia. Comoros, Cook Islands, Cuba, Djibouti.
Equatorial Guinea, Eritrea, The Gambia. Guinea-Bissau, Guyana. Kiribati, North Korea, Laos,
Latvia, Lesotho, Liberia, Lithuania, The Former Yugoslav Republic of Macedonia, Maldives.
Marshall Islands, Moldova, Mongolia, Nauru. Niue, Saint Lucia, Saint Vincent and the
Grenadines, Sao Tome and Principe, Seychelles, Sierra Leone, Slovakia. Slovenia, Solomon
Islands, Suriname, Tajikistan, Tonga, Turkmenistan, Tuvalu, Ukraine, Vanuatu, Western
World Court
see International Court of Justice (1CJ)
World Federation of Trade Unions
(WETL)
address—Branicka 112, Bramk. CS-14700
Prague 4. Czech Republic
telephone—{42} (2) 46 21 40
FAX—{42] (2) 46 13 78
3 October 1945
adim—to promote the trade umon
movement
established
members—( 116) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina, Australia.
Austria, Bahrain, Bangladesh, Benin, Bolivia, Botswana. Brazil, Bulgaria, Burkina Faso,
Cambodia, Cameroon, Canada, Chile, Colombia, Congo, Costa Rica, Cote d''Ivoire. Cuba,
Cyprus, Czech Republic. Denmark. Djibouti, Dominican Republic, Ecuador, Egypt. El
Salvador, Eritrea, Ethiopia. Fij!, Finland, France. French Guiana, The Gambia, Ghana, Greece.
Guadeloupe. Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary. India,
Indonesia. Iran, Irag. Jamaica, Japan, Jordan, North Korea, Kuwait, Laos, Lebanon, Lesotho,
Liberia, Libya, Madagascar. Malawi, Malaysia, Mali, Martinique. Mauritius, Mexico,
Mongolta, Mozambique. Nepal. New Caledonia, NZ, Nicaragua. Niger, Nigeria, Oman.
Pxistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal, Puerto Rico.
Reunion. Romania, Saint Lucia, Saint Perre znd Miquelon, Saint Vincent and the Grenadines,
Saudi Arabia. Senegal. Sierra Leone, Soiomon Islands, Somalia, South Africa, Spain, Sri
Lanka. Sudan, Sweden, Syria. Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Uganda, Uruguay. Vanuatu, Venezuela, Vietnam, Yemen, Zaire, Zimbabwe
World Food Council (WFC)
address—-c/o FAQ, Via Terme di
Caracalla, 1-00100 Rome. Italy
tefephone--|39| (6) 522821
FAX—|39] (6) 574 S091
17 December 1974
aim—to study worl food problems and to
recommend solutions, ECOSOC
organization
established
members—i 36) selected on a rotating basis from all regions
World Food Program (WFP)
address—Via Cristotoro Colombo 426, I-
OOI4S Rome. Italy
telephone—|39| (6) 522821
FAX—|39] (0) 5123700, 5133537,
$228 2840
established—24 November 196]
aim—to provide food aid in support of
economic development or disaster relief:
an ECOSOC organization
members—(5") selected on a rotatiag basis from all regions
World Heaith Organization (WHO)
address—CH-1211 Geneva 27, Switzerland
telephone—{41] (22) 791 21 11, 791 32
23
FAX—{41] (22) 791 07 46
established—22 July 1946
effective—7 April 1948
aim—to deal with health matters
worldwide, a UN specialized agency
members—{ 190) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda. Argentina.
Armenia, Australia, Austria, Azerbaijan, The Bahamas. Bahrain, Bangladesh, Barbados.
Belarus, Belgium, Belize, Benin. Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil.
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cu:aeroon, Canada, Cape Verde.
entral African Republic, Chad, Chile, China, Colombia, Comoros, Congo, Cook Islands.
Costa Rica, Cote @ ivoire, Croatia, Cuba, Cyprus. Czech Republic, Denmark. Djibouti.
Dominica, Dominican Republic. Ecuador, Egypt. El Salvador, Equatorial Guinea. Eritrea.
Estonia, Ethiopiz, Fiji, Finland. France. Gabon, The Gambia. Georgia. Germany. Ghana,
Greece, Grenad1, Guatemala, Guinea. Guinea-Bissau. Guyana, Haiti, Honduras. Hungary.
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy. Jamaica. Japan. Jordan. Kazakstan.
Kenya, Kiribati, North Korea, South Korea, Kuwait. Kyrgyzstan. Laos. Latvia, Lebanon.
Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic ot
Macedonia, Madagascar, Maiawi, Malaysia, Maldives. Mali, Malta. Marshall Islands.
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova. Monaco. Mongolia.
Morocco, Mozanubique, Namibia, Nauru, Nepal. Netherlands, NZ. Nicaragua. Niue. Niger.
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea. Paraguay. Peru.
Philippines, Poland, Portugal. Qatar, Romania, Russia. Rwanda. Saint Kitts and Nevis. Saint
Lucia, Saint Vincent and the Grenadines, San Marino, Sao Tome and Principe. Saudi Arabia.
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia. Slovenia. Solomon Islands. Somalia.
South Africa, Spain, Sri Lanka, Sudan, Suriname. Swaziland. Sweden. Switzerland. Syma.
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago. Tunisia. Turkey.
Turkmenistan, Tuvalu, Uganda. Ukraine. UAE, UK, US, Uruguay. Uzbekistan. Vanuatu.
Venezuela, Vietnam, Western Samoa, Yemen, Yugoslavia (suspended). Zaire. Zambia.
associate members—{2) Puerto Rico, Tokelau
World Intellectual Property Organization
(WIPO)
address—34 chemin des Colombettes, Case
Postale 18, CH-1211 Geneva 20.
World Tourism Organization (WToO)
address —Calle Capitan Haya 41, 28020
Madrid, Spain
telephone—{34| (1) 571 06 28
FAX—|34] (1) 571 37 33
established—2 January 1975
aim—A0 promote tourism as a means of
contributing to economic development.
international understanding. and peace
members— 121) Afghanistan, Albania, Algeria, Angola, Argentina, Austria, Bangladesh,
Belgium, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, Burkina Faso, Burundi,
Cambodia, Cameroon, Canada, Chad, Chile, China, Colombia, Congo, Cote d''Ivoire, Croatia,
Cuba. Cyprus, Czech Republic. Dominican Republic, Ecuador, Egypt, El Salvador, Ethiopia,
Finland, France. Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Haiti, Hungary, India, Indonesia, Ian, Iraq, Israel, Italy.
Jamaica, Japan, Jordan, Kazakstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan,
Laos, Lebanon, Lesotho, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico. ,loldova, Mongolia, Morocco, Nepal, Netherlands, Nicaragua.
Niger. Nigeria, Pakistan, Panama, Paraguay, Peru, Poland, Portugal, Romania, Russia.
Rwanda, San Marino, Sao Tome and Principe. Senegal. Seychelles, Sierra Leone. Slovakia,
Slovenia, Spain, Sn Lanka, Sudan, Switzerland, Syria, Tanzania. Togo, Tunisia, Turkey,
Turkmenistan, Uganda, UAE, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
Yugoslavia (suspended), Zaire, Zambia, Zimbabwe
associate members—(4) Aruba, Macau. Netherlaads Antilles, Puerto Rico
observer—(1) Holy See
World Trade Organization (WTrO)
note—succeeded General Agreement on
Tariff and Trade (GATT)
established—tS April 1994
effective—\\ January 1995
aim—to provide a means to resolve trade
conflicts between members and to carry
on negotiations with the goal of further
lowering and/or eliminating tariffs and
other trade barriers
members— 114) Antigua and Barbuda, Argentina, Australia, Austria, Bahrain, Bangladesh.
Barbados, Belgium, Belize, Bolivia, Botswana, Brazil. Brunei. Burkina Faso, Burma, Burundi,
Cameroon, Canada, Central African Republic, Chile. Colombia, Cosia Rica, Cote d''Ivoire,
Cuba, Cyprus. Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic. Egypt.
El Salvador, EU, Fiji, Finland, France, Gabon, Germany. Ghana, Greece, Guatemala, Guinea.
Guinea-Bissau, Guyana, Honduras, Hong Kong. Hungary. Iceland. India, Indonesia, Ireland.
Israel, Italy, Jamaica, Japan, Kenya, South Korea, Kuwait, Lesotho. Liechtenstein.
Luxembourg, Macau, Madagascar, Malawi, Malaysia. Maldives, Mali, Malta. Maurntania.
Mauritius, Mexico, Morocco, Mozambique, Namibia, Netherlands. NZ. Nicaragua. Nigeria.
Norway, Pakistan, Paraguay, Peru. Philippines, Poland, Portugal. Qatar. Romania. Saint Lucia.
Saint Vincent and the Grenadines, Senegal. Sierra Leone. Singapore. Slovakia. Slovenia.
South Africa, Spain, Sn Lanka, Suriname. Swaziland. Sweden. Switzerland, Tanzania.
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UK, US. Uruguay.
Venezuela. Zambia, Zimbabwe
observers— 11) Azerbaijan, Ethiopia,','897fe523e0adb6cc4633449d6f728c82bb0b0e98886dff1c1a11cce325750373','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0034428b9f3df7c81b937e44070d3f1825364eec5a48dbd41350d37ca193ab95',1996,'ZW','Zimbabwe','transportation',551,'Kazakstan, Kyrgyzstan, Laos, Libya, The Former
Yugoslav Republic of Macedonia, Somalia, Sudan, Tajikistan. Turkmenistan
applicants— 28) Albania. Algeria, Armenia, Belarus, Bulgaria, Cambodia, Cape Verde,
China, Croatia, Ecuador, Equatonal Guinea. Estonia, Jordan, Latvia, Lithuania. Moldova.
Mongolia, Nepal, Panama, Russia, Sao Tome and Principe. Saudi Arabia, Seychelles, Ukraine.
Uzbekistan, Vietnam, Yemen, Taiwan
note—the following members of GATT had not become members of WTrO as of January
1996: Angola, Benin, Chad, Congo, The Gambia. Grenadu. Haiti. Niger. Papua New Guinea.
Rwanda, Saint Kitts and Nevis, Solomon Islands, UAE. Zaire
Zangger Committee (ZC)
established—early 1970s
aim—to establish guidelines for the export
conirol provisions of the Nonproliferation
of Nuclear Weapons Treaty (NPT)
members—4 29) Australia, Austria, Belgium. Bulgaria, Canada. Czech Republic. Denmark.
Finland, France, Germany, Greece. Hungary. Ireland, Italy. Japan, Luxembourg. Netherlands.
Norway, Poland, Portugal. Romania, Russia, Slovakia, South Africa. Spain, Sweden.
Switzerland, UK, US
Appendix D:
Selected International Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning
the Control of Emissions of Nitrogen Oxides or Their Transboundary Fluxes
Air Pollution-Sulphur &5
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the
Reduction of Sulphur Emissions or Their Transboundary Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further
Reduction of Suiphur Emissions
Air Pollution-\\ olatile Organic
Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning
the Control of Emissions of Volatile Organic Compounds or Their Transboundary Fluxes
Antarctic-E.nvironmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature—| December 1959
entered into force—23 Jane 1961
objective—4o ensure that Antarctica ty used
for peaceful purposes, such as. for
imemevenal Cooperation im scientific
research, and that nt does not become the
scene or object of international discord
parties—442) Argentina, Australia, Austria, Belgium. Brazil. Bulgaria, Canada, Chile, China,
Colombia, Cuba. Czech Republic. Denmark. Ecuador, Finland, France. Germany. Greece.
Guatemala, Hungary. India. Italy. Japan, North Korea, South Korea, Netherlands, NZ.
Norway. Papua New Guinea. Peru, Poland. Romania. Russia, Slovakia, South Afnca, Spain.
Sweden, Switzerland, Ukraine, UK. US, Uruguay
Basel Convention on the Control of
Transboundary Movements of Hazardous
Wastes and Their Disposal
note—abbreviated as Hazardous Wastes
opened for signature—22 March 1989
entered into force—S May 1992
ayective—to reduce transboundary
movements of wastes subject to the
Convention to a minimum consistent with
the environmentally sound and efficient
management of such wastes: to manimize
the amount and toxicity of wastes
generated and ensure their environmentally
sound management as closely as possible
to the source of generation; and to assist
LDCs im environmentally sound
management of the hazardous and other
wastes they generate
parties—(83) Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas. Bahrain,
Bangladesh. Belgium, Brazil. Canada. Chile. China. Comoros, Cote dIvoire, Croatia, Cuba.
Cyprus. Czech Republic, Denmark. Ecuador, Egypt. El Salvador. Estonia. EU. Finland,
France. Germany, Greece, Guatemala, Hungary. India, Indonesia, Iran. Ireland, Israel. Italy.
Japan, Jordan, South Korea, Kuwait, Latvia, Lebanon. Liechtenstein, Luxembourg. Malawi.
Malaysia, Maldives, Mauritius, Mexico, Monaco, Netherlands. NZ. Nigeria. Norway, Pakistan.
Panama. Peru. Philippines. Poland, Portugal. Romania. Russia. Saint Kitts and Nevis. Saint
Luci, Saudi Arabia, Senegal. Seychelles. Slovakia, Slovenia. South Africa. Spain. Sn Lanka.
Sweden, Switzerland, Syria, Tanzania. Trinidad and Tobago, Turkey. UAE, UK. Uruguay.
Zaire, Zambia
countries that have signed, but not vet ratified—4\\9) Afghanistan, Barbados, Bolivia,
Col»abia, Costa Rica, Guinea. Haiti, loeland, Micronesia, Namibia, Oman, Papua New
Guinea, Paraguay. Qatar, Thailand, Tunisia, US. Venezuela, Vietnam
Biodiversity
see Convention on Biological Diversity
Convention on Biclogical Diversity
note—abbreviated as Biodiversity
opened for signature—S June 1992
entered into force—29 December 1993
objective—to develop national strategies
for the conservation and sustainable use of
biological diversity
pariies— 134) Albania, Algeria, Antigua and Barbuda. Argentina, Armenia, Australia, Austria,
The Bahamas, Bangladesh, Barbados, Belarus, Belize. Benin, Bhutan, Bolivia, Botswana,
Brazil, Burkina Faso, Burma, Cameroon, Canada, Cape Verde, Central Afncan Republic.
Chad, Chile, China, Colombia, Comoros, Cook Islands, Costa Rica, Cote d''Ivoire, Cuba.
Czech Republic, Denmark, Djibouti, Dominica, Ecuador, Egypt. El Salvador, Equatorial
Guinea, Estonia, Ethiopia, EU, Fiji, Finland, France. The Gambia, Georgia, Germany. Ghana.
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras. Hungary. Iceland.
India, Indonesia, Israel, Italy, Jamaica, Japan, Jordan. Kazakstan, Kenya. Kiribati. North
Korea, South Korea, Latvia, Lebanon, Lesotho, Luxembourg. Malawi, Malaysia. Maldives.
Mali, Marshall Islands, Mauritius, Mexico, Federated States of Micronesia, Moldova. Monaco,
Mongolia, Morocco, Mozambique, Nauru, Nepal. Netherlands, NZ. Nicaragua. Niger. Nigeria.
Norway, Oman, Pakistan, Panama, Papua New Guinea. Paraguay. Peru. Philippines. Portugal.
Romania, Russia, Saint Kitts and Nevis, Saint Lucia. San Marino. Senegal. Seychelles. Sierra
Leone, Singapore. Slovakia, Solomon Islands, South Africa. Spain, Sn Lanka. Sudan.
Swaziland, Sweden, Switzerland, Tunisia, Uganda, Ukraine. UK. Uruguay. Vanuatu.
Venezuela, Vietnam, Western Samoa, Zaire, Zambia, Zimbabwe
countries that have signed, but not vet ratified—(43) Atghamistan. Angola. Azerbaijan.
Bahrain, Belgium. Bulgaria, Burundi, Cambodia. Congo, Croatia, Cyprus, Dominican
Republic, Gabon. Haiti, Iran, Ireland, Kuwait. Liberia, Libya, Liechtenstein, Lithuania.
Madagascar, Malta, Mauritania, Namibia, Poland, Qatar, Rwanda, Sao Tome and Principe.
Slovenia, Suriname. Syria, Tanzania, Thailand. Togo. Trinidad and Tobago. Turkey. Tuvalu,
UAE, US. Uzbekistan. Yemen. former Yugoslavia
Climate Change
see United Nations Framework Convention on Climate Change
Convention on Fishing and Conservation
of Living Resources of the High Seas
note-—abbreviated as Marine Life
Conservation
opened for signature—29 April 1958
entered into force—20 March 1966
objective—to solve through international
cooperation the problems involved in the
conservation of living resources of the
high seas. considering that because of the
development of modern technology some
of these resources are in danger of being
overexplotted
parties—(38) Australia, Belgium, Bosnia and Herzegovina. Burkina Faso, Cambodia.
Colombia, Denmark. Dominican Republic. Fij:. Finland. France. Haiti, Jamaica, Kenya,
Lesutho, Madagascar, Malawi, Malaysia, Mauritius, Mexico, Morocco, Netherlands. Nigeria.
Portugal. Senegal. Sierra Leone. Solomon Islands, South Africa. Spain. Switzerland. Thailand,
Tonga. Trinidad and Tobago, Uganda, UK. US, Venezuela, former Yugoslavia
countries that have signed, but not vet ratified—(21) Atghanistan, Argentina, Bolivia, Costa
Rica, Cuba, Ghana, Iceland, Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal. NZ.
Pakistan. Panama. Sri Lanka. Taiwan (Canada signed on behalf of Taiwan), Tunisia. Uruguay
Convention on Long-Range
Transboundary Air Pollution
nole—abbreviated as Air Pollution
opened for signature—13 November 1979
entered into force—\\6 March 1983
objective—to protect the human
environment against air pollution and to
gradually reduce and prevent air pollution.
including long-range transboundary air
pollution
parties—( 39) Austria, Belarus. Belgium. Bosnia and Herzegovina. Bulgaria, Canada, Croatia,
Cyprus, Czech Republic. Denmark. EU. Finland. France. Germany. Greece. Hungary. Iceland,
Ireland, aly. Latvia. Liechtensteim. Lithuania. Luxembourg. Netherlands. Norway. Poland.
Portugal. Romania. Russia, Slovakia, Slovenia. Spain. Sweden. Switzerland, Turkey. Ukraine,
UK, US, former Yugoslavia
countries that have signed, but not vet ratified—43) Holy See. Moldova, San Marino
( onsention on the International Trade
in Endangered Species of Wild Flora
and Favaa (CITES)
«— abbreviated as Endangered Species
ed for stgenature—3 March 1973
stered ito force—| July 1975
ive—to protect certain endangered
species trom overexploitation by means of
system of import/export permits
parties— 130) Afghanistan, Algeria, Argentina, Australia, Austria, The Bahamas, Bangladesh,
Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Buigaria, Burkina Faso,
Burundi, Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominican Repubiic, Ecuador, Egypt, Ei Saivador, Equaiorial Guinea, Eritrea,
Estonia, Ethiopia, Finland, France, Gabon, The Gambia, Germany, Ghana, Greece, Guatemala,
Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, India, Indonesia, Iran, Israel, Italy,
Japan, Jordan, Kenya, Kiribati, South Korea, Liberia, Liechtenstein, Luxembourg,
Madagascar, Malawi, Malaysia, Mali, Malta, Mauritius, Mexico, Monaco, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Senegal.
Seychelles, Sierra Leone, Singapore, Slovakia, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago,
Tunisia, Tuvalu, Uganda, UAE, UK, US, Uruguay, Vanuatu. Venezuela, Vietnam, Zaire,
Zambia, Zimbabwe
countries that have signed, but not yet ratified—(4) Cambodia, Ireland, Kuwait, Lesotho
Convention on the Prevention of Marine
Pollution by Dumping Wastes and Other
Matter (London Convention)
noie—abbreviated as Marine Dumping
opened for signature—29 December 1972
entered into force—30 August 1975
objective—to control pollution of the sea
by dumping and to encourage regiona!
agreements supplementary to the
Convention
parties—477) Afghanistan, Antigua and Barbuda, Argentina, Australia, Barbados, Belarus.
Belgium, Belize, Bosnia and Herzegovina, Brazil, Canada, Cape Verde, Chile, China, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Egypt, EU,
Finland, France, Gabon, Germany, Greece, Guatemala, Haiti, Honduras, Hungary, Iceland,
Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, Libya, Luxembourg, Malta, Mexico,
Monaco, Morocco, Nauru, Netherlands, NZ, Nigeria, Norway, Oman, Panama, Papua New
Guinea. Philippines, Poland, Portugal, Russia, Saint Lucia, Seychelles, Slovenia, Solomon
islands, South Africa, Spain, Suriname, Sweden, Switzerland, Tonga, Tunisia, Tuvalu,
Ukraine, UAE, UK, US, Vanuatu, former Yugoslavia, Zaire
Convention on the Prohibition of
Military or Any Other Hostile Use of
Environmental Modification Techniques
note—abbreviated as Environmental
Modification
opened for signature—\\10 December 1976
entered into force—5S October 1978
objective—to prohibit the military or other
hostile use of environmental modification
techniques in order to further world peace
and trust among nations
parties—(63) Afghanistan, Algeria, Antigua and Barbuda, Argentina. Australia, Austria,
Bangladesh, Belarus, Belgium, Benin, Brazil, Bulgaria, Canada, Cape Verde. Chile, Cuba,
Cyprus, Czech Republic, Denmark, Dominica, Egypt. Finland, Germany, Ghana, Greece,
Guatemala, Hungary, India, Ireland, Italy, Japan, North Korea, South Korea, Kuwait, Laos,
Malawi, Mauritius, Mongolia, Netherlands, NZ, Niger, Norway, Pakistan, Papua New Guinea,
Poland, Romania, Russia, Saint Lucia, Sao Tome and Principe, Slovakia, Solomon Islands,
Spain, Sri Lanka, Sweden, Switzerland, Tunisia, Ukraine, UK, US, Uruguay, Uzbekistan,
Vietnam, Yemen
countries that have signed, but not vet ratified—(17) Bolivia, Ethiopia, Holy See, Iceland.
Iran, Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal, Sierra Leone, Syria.
Turkey, Uganda, Zaire
Convention on Wetlands of International
Importance Especially As Waterfowl
Habitat (Ramsar)
note—abbresiated as Wetlands
opened for signature—2 February 1971
entered into force—2\\1 December 1975
objective—to stem the progressive
encroachment on and loss of wetlands
wow and in the future, recognizing the
fundamental ecological functions of
wetlands and their economic, cultural,
scientific, and recreational value
parties—(87) Algeria, Argentina, Armenia, Australia, Austria, Bangladesh, Belgium, Bolivia,
Brazil, Bulgaria, Burkina Faso, Canada, Chad, Chile, China, Costa Rica, Croatia, Czech
Republic, Denmark, Ecuador, Egypt. Estonia, Finland, France, Gabon, Germany, Ghana,
Greece, Guatemala, Guinea, Guinea-Bissau. Honduras, Hungary, Iceland, India, Indonesia,
Iran. Ireland, Italy, Japan, Jordan, Kenya, Lesotho. Liechtenstein, Lithuania, Mali, Malta.
Mauritania, Mexico, Morocco, Netherlands. NZ, Niger, Norway. Pakistan, Panama. Papua
New Guinea, Peru, Philippines, Poland. Portugal, Romania, Russia, Senegal, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Trinidad and
Tobago, Tunisia, Turkey, Uganda, UK, US, Uruguay, Venezuela. Vietnam. former
Yugoslavia, Zambia
country that has signed, but not ratified—(1) Paraguay
Desertification
see United Nations Convention to Combat Desertification in those Countries Experiencing
Serious Drought and/or Desertification, Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild Flora and Fauna
(CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of Environmental
Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of Hazardous Wastes
aid Tien Disposal
International Convention for the
Regulation of Whaling
note—abbreviated as Whaling
opened for signature—2 December 1946
entered into force—\\10 November 1948
objective—to protect all species of whales
from overfishing; to establish a system of
international regulation for the whale
fisheries to ensure proper conservation and
development of whale stocks; and to
safeguard for future generations the great
natural resources represented by whaie
stocks
parties—{56) Antigua and Barbuda, Austria, The Bahamas, Barbados, Belize, Brazil, Brunei,
Canada, Cyprus, Denmark, Dominica, Ecuador, Egypt, Fiji, Finland, France, The Gambia,
Ghana, Grenada, Guyana, Ireland, Italy, Jamaica, Kiribati, Latvia, Malaysia, Malta, Mauritius,
Mexico, Monaco, Netherlands (Netherlands also extended the convention to Netherlands
Antilles), NZ, Nicaragua, Nigeria, Norway, Poland, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Sierra Leone, Slovakia, Solomon Islands, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Switzerland, Tanzania, Tonga, Trinidad and Tobago, Turkey,
Tuvalu, UK, US, former Yugoslavia
International Tropical Timber
Agreement, 1983
note—abbreviated as Tropical Timber 83
opened for signature—\\18 November 1983
entered into force—\\ April 1985; this
agreement will expire when the
International Tropical Timber Agreement.
1994, goes into force
objective—to provide an effective
framework for cooperation between tropical
timber producers and consumers and to
encourage the development of national
policies aimed at sustainable utilization
and conservation of tropical forests and
their genetic resources
parties—{53) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cameroon, Canada, China,
Colombia, Congo, Cote d''Ivoire, Denmark, Ecuador, Egypt, EU. Fiji, Finland, France, Gabon,
Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South
Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua
New Guinea, Peru, Philippines, Portugal, Russia, Spain, Sweden. Switzerland, Thailand, Togo,
Trinidad and Tobago, UK, US, Zaire
International Tropical Timber
Agreement, 1994
note—abbreviated as Tropical Timber 94
opened for signature-—-26 January 1994,
but not yet in force
objective—to ensure that by the year 2000
exports of tropical timber originate from
sustainably managed sources; to establish a
fund to assist tropical timber producers in
obtaining the resources necessary to reach
this objective
parties—(11) Bolivia, Ecuador, Fiji, Ghana, Indonesia, Japan, South Korea, Liberia. Malaysia,
Norway, Peru
countries that have signed, but not yet ratified—{20) Burma, Cambodia, Canieroon, Canada,
Colombia, Congo, Egypt, Gabon, Germany, Honduras, Japan, Netherlands, New Zealand,
Panama, Papua New Guinea, Philippines, Switzerland, Togo, US. Venezuela
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter
(London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High Seas
601
Montreal Protocol on Substances That
Deplete the Ozone Layer
note—abbieviated as Ozone Layer
Protection
opened for signature—\\6 September 1987
entered into force—\\ January 1989
objective—to protect the ozone layer by
controlling emissions of substances that
deplete i!
parties—(147) Algeria, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas,
Bahrain. Bangladesh, Barbados, Belarus, Belgium, Benin, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Cameroon, Canada, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus. Czech Republic, Denmark, Dominica, Dominican Republic, Ecuador, Egypt,
E! Salvador, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guyana, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Kuwait,
Lebanon, Lesotho, Libya, Liechtenstein, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malawi, Malaysia, Maldives, Mali, Malta. Marshall Islands, Mauritania,
Mauritius, Mexico, Monaco, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger. Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poiand, Portugal (Portugal has also extended the protocol to Macau), Romania,
Russia, Saint Kitts and Nevis, Saint Lucia, Saudi Arabia. Senegal, Seychelles, Singapore,
Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Swaziland,
Sweden. Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine. UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam. Western Samoa, former Yugoslavia, Zaire, Zambia, Zimbabwe
countries that have signed, but not vet ratified—44) North Korea. Latvia, Lithuania, Federated
States of Micronesia
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere. in Outer Space, and Under
Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the
International Convention for the
Prevention of Pollution From Ships,
1973 (MARPOL)
note—abbreviated as Ship Pollution
opened for signature—\\7 February 1978
entered into force—2 October 1983
objective—to preserve the marine
environment through the complete
elimination oi pollution by oil and other
harmful substances and the minimization
of accidental discharge of such substances
parties—(91) Algeria, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas,
Barbados, Belgium, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Chile, China.
Colombia, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Ecuador, Egypt. Estonia, Finland, France. Gabon, The Gambia, Georgia, Germany, Ghana,
Greece. Hungary. Iceland. India. Indonesia, Israel, lialy, Jamaica, Japan, Kazakstan, Kenya,
North Korea, South Korea. Latvia, Lebanon, Liberia, Lithuania, Luxembourg, Malta, Marshall
Islands, Mexico, Monaco, Morocco, Netherlands, Norway. Oman, Pakistan, Panama, Papua
New Guinea, Peru, Poland. Portugal, Romania, Russia. Saint Vincent and the Grenadines,
Seychelles, Singapore, Slovakia, Slovenia, South Africa, Spain, Suriname, Sweden,
Switzerland, Syria, Togo, Tunisia, Turkey, Tuvalu, Ukraine. UK, US, Uruguay, Vanuatu,
Venezuela, Vietnam, former Yugoslavia
Protocol on Environmental Protection to
the Antarctic Treaty
note—abbreviated as Antarctic-
Environmental Protocol
opened for signature—4 October 1991, but
not yet in force
objective—to enhance the protection of the
Antarctic environment and dependent and
associated ecosystems
parties—{21) Argentina, Australia, Brazil, Chile. China. Ecuador, France, Germany, Greece,
Italy, South Korea, Netherlands, NZ, Norway, Peru, Poland. South Africa, Spain, Sweden,
UK, Uruguay
countries that have signed, but not yet ratified—(19) Austria, Belgium, Bulgaria, Canada
Colombia, Cuba, Czech Republic, Denmark, Finland, Guatemaia, Hungary, India, Japan.
North Korea, Romania, Russia, Slovakia, Switzerland, US
602
6//
Ks
Protocol to the 1979 Convention on
Long-Range Transboundary Air
Pollution Concerning the Control of
Emissions of Nitrogen Oxides or Their
Transboundary Fluxes
note—abbreviated as Air Pollution-Nitrogen
Oxides
opened for signature—3\\ October 1988
entered into force—\\4 February 1991
objective—to provide for the control or
reduction of nitrogen oxides and their
transboundary fluxes
parties—{25) Austria, Belarus, Bulgaria, Canada, Czech Republic, Denmark, EU. Finland,
France, Germany, Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands, Norway,
Russia, Slovakia, Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified—{3) Belgium, Greece, Poland
Protocol to the 1979 Convention on
Long-Range Transboundary Air
Pollution Concerning the Control of
Emissions of Volatile Organic
Compounds or Their Transboundary
Fluxes
note—-abbreviated as Air Pollution-Volatile
Organic Compounds
opened for signature—18 November 1991,
but not yet in force
objective—to provide for the control and
reduction of emissions of volatile organic
compounds in order to reduce their
transboundary fluxes so as to protect
human health and the environment from
adverse effects
parties—(13) Austria, Finland, Germany, Hungary, Italy, Liechtenstein, Luxembourg.
Netherlands, Norway, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified—(\\0) Belgium. Bulgaria, Canada, Denmark.
EU, France, Greece, Portugal, Ukraine, US
Protocol to the 1979 Convention on
Long-Range Transboundary Air
Pollution on Further Reduction of
Sulphur Emissions
note—abbreviated as Air Pollution-Sulphur
94
opened for signature—14 June 1994, but
not yet in force
objective—to provide for a further
reduction in sulfur emissions or
transboundary fluxes
parties—({2) Norway, Sweden
countries that have signed, but not yet ratified—(26) Austria, Belgium, Bulgaria, Canada.
Croatia, Czech Republic, Denmark, EU, Finland, France. Germany, Greece, Hungary. Ireland,
Italy, Liechtenstein, Luxembourg, Netherlands, Poland, Russia, Slovakia, Slovenia, Spain.
Switzerland, Ukraine, UK
Protocol to the 1979 Convention on
Long-Range Transboundary Air
Pollution on the Reduction of Sulphur
Emissions or Their Transboundary
Fluxes by at Least 30%
note—abbreviated as Air Pollution-Sul','9c18a2c6aca04ec94d6ca781bc8b2f2089c36f65e8eaf8a3e130cc99a77e4c32','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8db61376b6673540635146ba2b84a88e6b30260ab52b964d0cef8c94bd3e4689',1996,'ZW','Zimbabwe','transportation',552,'phur
85
opened for signature—8 July 1985
entered into force—2 September 1987
objective—to provide for a 30% reduction
in sulfur emissions or transboundary fluxes
by 1993
parties—(21) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark.
Finland, France, Germany, Hungary, Italy, Liechtenstein, Luxembourg, Netherlands, Norway,
Russia, Slovakia, Sweden, Switzerland, Ukraine
Ship Pollution
see Protocol of 1978 Relating to the International Convention for the Prevention of Petlution
From Ships, 1973 (MARPOL)
&/3
Treaty Banning Nuclear Weapon Tests
in the Atmosphere, in Outer Space, and
Under Water
note—abbreviated as Nuclear Test Ban
opened for signature—S August 1963
entered into force—\\10 October 1963
objective—Ao obtain an agreement on
general and complete disarmament under
strict international control in accordance
with the objectives of the United Nations;
to put an end to the armaments race and
eliminate incentives for the production and
tes ang of all hinds of weapons, including
nuclear weapons
parties—125) Afghanistan, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
The Bahamas, Bangladesh, Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Bulgaria, Burma, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech
Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece, Guatemala, Guinea-Bissau,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kenya, South Korea, Kuwait, Laos, Lebanon, Liberia, Libya, Luxembourg,
Madagascar, Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Mongolia, Morocco,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New
Guinea, Peru, Philippines, Poland, Romania, Russia, Kwanda, San Marino, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sn Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela,
Western Samoa, Yemen, former Yugoslavia, Zaire, Zambia
counies that have signed, but not yet ratified—(\\1) Aigeria, Burkina Faso, Burundi,
Cameroon, Ethiopia, Haiti, Mali, Paraguay, Portugal, Somalia, Vietnam
Tropical Timber 83
see Internationa! Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law
of the Sea (LOS)
note—abbreviated as Law of the Sea
opened for signature—\\0 December 1982
entered into force—\\6 November 1994
objective—1o set up a comprehensive new
legal regime for the sea and oceans: to
include rules concerning environmental
standards as well as enforcement
provisions dealing with pollution of the
marine environment
parties(79) Angola, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas,
Bahrain, Barbados, Belize, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Cameroon,
Cape Verde, Comoros, Cook Isiands, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti,
Dominica, Egypt, Fiji, The Gambia, Germany, Ghana, Greece, Grenada, Guinea, Guinea-
Bissau, Guyana, Honduras, Iceland, India, Indonesia, Iraq, Italy, Jamaica, Kenya, Kuwait,
Lebanon, The Former Yugoslav Republic of Macedonia, Mali, Malta, Marshall Islands,
Mauritius, Mexico, Federated States of Micronesia, Namibia, Nigeria, Oman, Paraguay,
Philippines, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome
and Principe, Senegal, Seychelles, Sierra Leone, Singapore, Somalia, Sri Lanka, Sudan,
Tanzania, Togo, Trinidad and Tobago, Tunisia, Uganda, Uruguay, Vietnam, Western Samoa,
Yemen, former Yugoslavia, Zaire, Zambia, Zimbabwe
countries that have signed, but not vet ratified--(88) Afghanistan, Algeria, Bangladesh,
Belarus, Belgium, Benin, Bhutan, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Canada, Central African Republic, Chad, Chile, China, Colombia, Congo, Croatia,
Czech Republic, Denmark, Dominican Republic, El Salvador, Equatorial Guinea, Ethiopia,
EU, Finland, France, Gabon. Guatemala, Haiti, Hungary, Iran, Ireland, Japan, Jordan, North
Korea, South Korea, Laos, Lesotho, Liberia, Libya, Liechtenstein, Luxembourg, Madagascar,
Malawi, Malaysia, Maldives, Mauritania, Monaco, Mongolia, Morocco, Mozambique. Nauru,
Nepal, Netherlands, NZ, Nicaracua, Niger, Niue, Norway, Pakistan, Panama, Papua New
Guinea, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Slovakia, Slovenia,
Solomon Islands, South Africa, Spain, Suriname, Swaziland, Sweden, Switzerland, Thailand,
Tonga, Tuvalu, Ukraine, UAE, Vanuatu
United Nations Convention to Combat
Desertification in Those Countries
Experiencing Serious Drought and/or
Desertification, Particularly in Africa
note—abbreviated as Desertification
opened for signature—\\4 October 1994,
but not yet in force
objective—Ao combat desertification and
mitigate the effects of drought through
national action programs that incorporate
long-term strategies supported by
international cooperation anu partnership
arrangements
parties 14) Canada, Cape Verde, Ecuador, Egypt. Guinea-Bissau, Lesotho, Mali, Mexico,
Peru, Senegal, Sudan, Sweden, Tunisia, Uzbekistan
countries that have signed, but not yet ratified—(102) Afghanistan, Algeria, Angola, Antigua
ad Barbuda, Argentina, Armenia, Australia, Bangladesh, Benin, Bolivia, Botswana, Brazil,
Burkina Faso, Burundi, Cambodia, Cameroon, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Denmark Djibouti,
Equatorial Guinea, Eritrea, Ethiopia, EU, Finland, France. The Gambia, Georgia, Germany,
Ghana, Greece, Guinea, Haiti, Honduras, India, Indonesia, Iran, Ireland. Israel, Italy, Japan,
Jordan, Kazakstan, Kenya, South Korea, Kuwait, Laos, Lebanon, Libya, Luxembourg,
Madagascar, Malawi, Malaysia, Malta, Mauritania, Mauritius, Federated States of Micronesia,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, Nicaragua, Niger. Nigeria,
Norway, Pakistan, Panama, Paraguay, Philippines, Portugal, Rwanda, Saint Vincent and the
Grenadines, Sao Tome and Principe, Seychelles “ierra Leone, South Africa, Spain,
Swaziland, Switzerland, Syria. Tanzania, Togo, Turkey, Turkmenistan, Uganda, UK, US.
Vanuatu, Zaire, Zambia, Zimbabwe
United Nations Framework Convention
on Climate Change
note—abbreviated as Climate Change
opened for signature—9 May 1992
entered into force—2\\1 March 1994
objective—to achieve stabilization of
greenhouse gas concentrations in the
uimosphere at a low enough level to
prevent dangerous anthropogenic
interference with the climate system
parties—{145) Albania, Algeria, Antigua and Barbuda, Argentina, Armenia. Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan. Bolivia,
Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Cook Islands, Costa Rica, Cote
d''Ivoire, Cuba, Czech Republic, Denmark, Djibouti, Dominica, Ecuador, Egypt. El Salvador,
Estonia, Ethiopia, EU, Fiji, Finland, France, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India,
Indonesia, Ireland, Italy, Jamaica, Japan, Jordan, Kazakstan, Kenya, Kiribati, North Korea,
South Korea, Kuwait, Latvia, Lebanon, Lesotho, Liechtenstein, Lithuania, Luxembourg,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia. Morocco, Mozambique.
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal.
Romania, Russia, Saint Kitts and Nevis, Saint Lucia, San Marino, Saudi Arabia, Senegal,
Seychelles, Sierra Leone. Slovakia, Slovenia, Solomon Islands, Spain, Sn Lanka, Sudan,
Sweden, Switzerland, Thailand, Trinidad and Tobago, Tunisia, Tuvalu, Uganda, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Western Samoa, Zaire, Zambia,
countries that have signed, but not yet ratified—(31) Afghanistan, Angola, Belarus, Belgium,
Burundi, Cambodia, Congo, Croatia, Cyprus, Dominican Republic, Eritrea, Gabon, Haiti,
Iran, Israel, Laos, Liberia, Libya, Madagascar, Rwanda, Sao Tome and Principe, Singapore,
South Africa, Suriname, Swaziland, Tanzania, Togo, Turkmenistan, Ukraine, Yemen, former
Yugoslavia
Wetlands see Convention on Wetlands of International Importance Especially As Waterfowl! Habitat
(Ramsar)
Whaling see International Convention for the Regulation of Whaling
605
Appendix E:
Weights and Measures
Mathematical Notation Mathematical Power Name
1o''s ~- | Ok 1).000,000.06 1.000.000 one quintillion
10° or 1,000,000,000,000.000————~*~—””——ne quadrillion
i0''- or 1.000,000.000,000 ene trillion
10” or 1.000.000.0000 one billion
10° or 1,000,000 one million
10° or 1.000 one thousand
1 or 100 one hundred
LO! or 10 ten
10° or | OO —_ a pon ;
WoO . one-tenth
10? or O.O1 one hundredth
10 * or 0.001 one thousandth
10 © or 0.000 001 one millionth
10” or 0.000 000 001 one billionth
10 © or 0.000 000 000 001 one trillionth
10 |* or 0.000 000 000 000 00] one quadnithonth
10) oF 0.000 000 000 000 000 001 _ one quintilionth
Metric tnterrelationships Prefix Symbol Length, (rea Volume
weight, or
capacity
eva E 1''s 10% 1s
peta P 1''s 1 lors
tera T 1! (4 le
vigu G tLe lays le
mega M iy 1 1ay''s
hectokilo hk we oe ai
myria ma ir lay" hay
kilo » 1s 1 we
hecto h 1 tt hye
basic unit — | meter, | meter” | meter’
igram.
1 liter
deci d Ww! te 10
cent Cc le ‘Le 1°
milli is 16 Ww”
decimilli au 4 18 Ww!
centimill cm 1s i wis
micro u i) © ‘a ‘Li
nano n i’ ly tS 10
pico p i)! 4 10-=
femto f wo Wy io
alto a W''s Wy ws
606
=
Conversion Factors To Convert From To Multiply by
acres ares 40.468 564 224
acres hectares 0.404 685 642 24
acres square feet 43.560
acres square kilometers 0.004 046 856 422 4
acres square meters 4.046.856 422 4
acres square miles (siatute) 0.001 562 50
acres square yarcs 4.840
ares square meters 100
ares square yards 119.599
barrels. US beer galions 3]
barrels, US beer liters __ 117.347 77
barrels. US petroleum gallons (British) 34.97
barrels. US petroleum gallons (US) 42
barrels, US petroleum liters 158.987 29
barrels. US proof spirits gallons 40
barrels, US proof spirits | liters 151.416 47
bushels (US) bushels (British) 0.968 9
bushels (US) cubic feet | 244 456
bushels (US) cubic inches 2.150.42 . |
bushels (US)
cubic meters
bushels (US)
O35 2
cubic yards
bushels (US) dekaliters
bushels (US) dry pints
bushels (US) dry quarts
bushels (US) pecks
cable. fathoms
cables meters
cables yards
carat carat
centimeters leet
centimeters inches
centimeters meters
centimeters y ds
centimeters. cubic
cubic inches
0.046 090 96
3.§23 907
64
120)
219.456
240
2M)
().032 808 40
0.393 7008
0]
O.O10 946 13
0.061 023 744
centimeters, square
square feet
0.001 076 39
centimeters, square
square inches
0155 000 3]
centimeters, square square meters 0.000}
centimeters, square square yards 0.000 119 599
chains, square surveyor’s ares 4.046 86
607
Conversion Factors To Convert From To Multiply by
chains, square surveyor’s square feet 4,356
chains, surveyor’s leet 66
chains, surveyor’s meters 20.116 8
chains, surveyors rods 4
cords of wood cubic feet 128
cords of wood cubic meters 3.624 556
cords of wood cubic yards 4.7407
cups liquid ounces (US) 8
cups liters 0.236 S88 2
degrees Celsius
degrees Fahrenheit
multiply by 1.8 and add 32
degrees Fahrenheit
degrees Celsius
subtract 32 and divide by 1.8
dekaliters bushels 0.283 775 9
dekaliters cubic feet 0.353 1467
dekaliters cubic inches 610.237 4
dekaliters dry pints 18.161 66
dekaliters dry quarts 9.080 829 &
de \\aliters liters 10
dekalhters pecks 1.135 104
drams. avirdupors avoirdupots ounces 0.062 55
drams. avourdupots grains 27.344
drams. avourdupois grams 1.771 845 2
dram. troy grains 60)
drams, troy grams 3.887 934 6
drams. troy wruples 3
drams. troy drams, troy 0.125
drams, liquid (US) cubic inches 0.226
drams. liquid (US) liquid drams (British) 1.041
drams. liquid (US) liquid ounces 0.125
drams. liquid (US) milliliters 3.696 69
drams. liquid (US) minims Oo)
fathoms feet 6
tathoms meters 1.828 8
feet centimeters 4).48
leet inches | 2
feet kilometers 0.000 304 8
leet meters 0.304 &
feet Statute miles 1.000 189 39
leet vards
0.333 333 3
Conversion Factors To Convert From To Multiply by
feet, cubic bushels 0.803 563 95
feet, cubic __ cubic decimeters 28.316 847
feet, cubic cubic inches 1,728
feet, cubic cubic meters 0.028 316 846 592
feet, cubic cubic yards 0.037 037 04
feet, cubic dry pints 51.426 09
feet, cubic dry quarts 25.714 05
feet, cubic gallons 7.480 519
feet, cubic gills 239.376 6
feet, cubic liquid ounces 957.506 5
feet, cubic liquid pints 59.844 16
feet, cubic liquid quarts 29.922 O08
feet, cubic liters 28.316 846 592
feet. cubic pecks 3.214 256
feet, square acres 0.000 022 956 &
feet, square square centimeters 929.030 4
feet. square square decimeters 9.290 304
feet, square square inches 144 _
feet, square square meters 0.092 903 04 :
feet, square square yards O11
furlongs feet 660
furlongs inches 7,920
furlongs meters 201.168 7
furlongs statute miles 0.125 a
furlongs yards 220
gallons, liquid (US) cubic feet 0.133 680 6
gallons, liquid (US) cubic inches 231
gallons, liquid (US) cubic meters 0.003 785 411 784
gallons, liquid (US) cubic yards 0.004 951 13
gallons, liquid (US) gills (US) 32
gallons, liquid (US) liquid gallons (British) 0.832 67
gallons, liquid (US) liquid ounces 128 —
gallons, liquid (US) liquid pints x a
gallons, liquid (US) liquid quarts 4 ;
gallons, liquid (US) liters 3.785 411 784
gallons, liquid (US) milliliters 3.785.411 784
gallons, liquid (US) minims 61,440
gills (US) centiiiters 11.829 4
“9
Conversion Factors Te Convert From To Multiply by
gills (US) cubic feet 0.004 177 517
gills (US) cubic inches 7.218 75
giils (US) gallons 0.031 25
gills (US) gills (British) 0.832 67
gills (US) liquid ounces +
gills (US) liquid pints 0.25
gills (US) liquid quarts 0.125
gills (US) liters 0.118 294 118 25
gills (US) milliliters 118.294 118 25
gills (US) milliliters 118.294 118 25
gills (US) minims 1,920
grains avoirdupois drams 0.036 571 43
grains avoirdupois ounces 0.002 285 71
grains avoirdupois pounds 0.000 142 86
grains grams 0.064 798 91
grains grams 0.064 798 91
grains kilograms 0.000 064 798 91
grains grains 64.798 910
grains penny weights 0.042
grains scruples 0.05
grains troy drams 0.016 6
grains troy ounces 0.002 083 33
grains troy pounds 0.000 173 61
grains avoirdupois drams 0.564 383 39
grams aveirdupots ounces 0.035 273 961
grams avoirdupots pounds 0.002 204 622 6
grams grains 0.001
grams milligrams 1,000
grams troy ounces 0.032 150 746 6
grams grams 0.002 679 23
hands (height of horse) centimeters 10.16
hands (height of horse) inches 4
hectares acres 2.471 053 8
hectares square feet 107,639.1
hectares square kilometers 0.01
hectares square meters ee 10,000
hectares square miles 0.003 861 02
hectares square yards 11,959.90
610
a ieee ee ie
—— eo
Conversion Factors To Convert From To Multiply by
hundredweights, long avoirdupois pounds 112
hundredweights, long kilograms 50.802 345
hundredweights, long long tons 0.05
hundredweights, long metric tons 0.050 802 345
hundredweights. long shert ions 0.056
hundredweights, short avoirdupois pounds 100
hundredweights, short kilograms 45.359 237
hundredweights, short long tons 0.044 642 86
hundredweights, short metric tons 0.045 359 237
hundredweights, short short tons 0.05
inches centimeters 2.54
2.54 feet 0.083 333 33
inches meters 0.025 4
inches millimeters 25.4
inches yards 0.027 777 78
inches, cubic bushels 0.000 465 025
inches, cubic cubic centimeters 16.387 064
inches, cubic cubic feet 0.000 578 703 7
inches, cubic cubic meters 0.000 016 387 064
inches, cubic cubic yards 0.000 021 433 47
inches, cubic dry pints 0.629 761 6
inches, cubic dry quarts 0.014 880
inches, cubic gallons 0.004 329 0
inches, cubic gills 0.138 528 |
inches, cubic
liquid ounces
0.554 1126
inches, cubic
liquid pints
0.034 632 U3
inches, cubic liquid quarts 0.017 316 02
inches, cubic liters 0.016 387 064
inches, cubic milliliters 16.387 064
inches, cubic inches, cubic 265.974 0
inches, cubic pecks 0.001 860 10
inches. square square centimeters 6.451 600
inches, square square feet 0.006 944 44 -
inches, square square meters 0.000 645 16
inches, square square yards 0.000 771 605 Oo
kilograms avoirdupots drams 564.383 4
kilograms avoirdupois ounces 35.273 962
kilograms avoirdupois pounds 2.204 622 622 |
Conversion Factors To Convert From Te Multiply by
kilograms grains 15,432.36
15,432.36 grams 1,000
kilograms long tons 0.000 984 2
kilograms metric tons 0.001
kilograms short hundredweights 0.022 046 23
kilograms kilograms 0.001 102 31
kilograms troy ounces 32.150 75
kilograms troy pounds 2.679 229
kilometers meters 1,000
kilometers statute miles 0.621 371 192
kilometers, square acres 247.105 38
kilometers, square hectares 100
kilometers, square square meters 1,000,000
kilometers, square statute miles 0.386 102 16
knots (nautical mi/hr) kilometers/hour 1.852
knots (nautical mi/hr) statute miles/hour 1.151
leagues, nautical kilometers 5.556
leagues. nautical nautical miles 3
leagues. statute kilometers 4.828 032
leagues. statute statute miles 3
links, square surveyor''s links, square surveyor''s 404.686
links, square surveyors square inches 62.726 4
links, surveyor’s centimeters 20.116 8
links, surveyors chains 0.01
links, surveyor’s inches 7.92
liters liters 0.028 377 59
liters cubic feet 0.035 314 67
liters cubic inches 61.023 74
liters cubic meters 0.001
liters cubic yards 0.001 307 95
liters dekaliters 0.1
liters dry pints 1.816 166
liters dry quarts 0.908 OR2 98
liters gallons 0.264 172 052
liters gills (US) 8.453 506
liters liquid ounces 33.814 02
liters liquid pints 2.113 376
612
Conversion Factors Te Convert From Te Multiply by
isters liquid quarts 1.056 688 2
liters mullilnters 1,000
liters pecks 0.113 5104
meters centimeters 100
meters feet 3.280 839 895
meters inches 39.370 079
meters kilometers 0.001
meters mullimeters 1,000 7
meters statute miles 0.000 621 371
meters yards 1.093 613 298
meters. cubic bushels 28.377 59
meters, cubic cubic feet 35.314 666 7 ;
meters, cubic cubic inches 61.023.744
meters. cubic cubic yards 1.307 950 619 -
meters. cubic gallons 264.172 0S -
meters. cubic liters 1,000
meters, cubic pecks 113.5104 :
meters. square acres 0.000 247 105 38 _
meters. square hectares 0.000 | : 7
meters, square square centimeters 10,000 7
meters. square square feei 10.763 910 4 _
meters, square square inches 1.SSO0.003 | _
meters, square square yards l 198 990 046 oe
microns meters 0.000001 ;
microns inches 0.000 039 4 7 i
mils inches 0.00) _
mils millimeters 0025 4 a -
miles, nautical kilometers | 8520 —
miles, nautical statute miles 1.180 779 s _
miles, statute centimeters 1G.9%44 :
miles. statute feet $.280) _
miles, statute furlongs oe s
miles, statute inches _ 63.360
miles, statute kilometers - 1.609 44
miles. statute meters oe 1.O09 344 |
miles. statute rods 320 - ;
miles, statute yards 1.760 _ _
miles, square nautical square kilometers 3.429 94 —
613
Conversion Factors
To Convert From
Te
614
miles, square nautical
square statute miles
miles, square statute
acres
miles, square statute
hectares
258.998 811 033 6
miles, square statute
sections
miles, square statute
square kilometers
2.589 988 110 336
miles, square statute square nautical miles 0.755 miles
miles, square statute square rods 102,400
milligrams grains 0.015 432 358 35
milliliters cubic inches 0.061 023 744
milliliters gallons 0.000 264 17
milliliters gills (US) 0.008 453 5
milliliters milliliters 0.033 814 02
milliliters liquid pints 0.002 113 4
milliliters liquid quarts 0.001 056 7
milliliters liters 0.001
milliliters minims 16.230 73
millimeters inches 0.039 370 078 7
minims (US)
cubic inches
0.003 759 77
minims (US) gills (US) 0.000 520 83
minims (US) liquid ounces 0.002 083 33
minims (US) milliliters 0.061 611 52
minims (US) minims (British) 1.04]
ounces, avoirdupois avoirdupois drams 16
ounces, avoirdupois avoirdupois pounds 0.062 5
ounces, avoirdupois grains 437.5
ounces, avoirdupois crams 28.349 523 125
ounces, avoirdupois kilograms 0.028 349 523 125
ounces, avoirdupois troy ounces 0.911 458 3
ounces, avoirdupois troy pounds 0.075 954 86
ounces, liquid (US) cubic feet 0.001 044 38
ounces, liquid (US) centiliters 2.957 35
ounces, liquid (US) cubic inches 1.804 687 5
ounces, liquid (US) gallons 0.007 812 5
ounces, liquid (US) liquid drams ®
ounces, liquid (US) liquid ounces (British) 1.04]
ounces, liquid (US) liquid pints 0.062 5
ounces, liquid (US) liquid quarts 0.031 25
ounces, liquid (US)
liters
0.029 573 53
a A aie
Conversion Factors To Convert From To Multiply by
ounces, liquid (US} milliliters 29.573 529 6
ounces, liquid (US) minims 480 —
ounces, troy avoirdupeis drams 17.554 29
ounces, troy avoirdupois ounces 1.097 143
ounces, troy avoirdupois pounds 0.068 571 43
ounces, troy grains 480
ounces, troy grams 31.103 476 8
ounces, troy pennyweights 20
ounces, troy troy drams 8
ounces, troy troy pounds 0.083 333 3
paces (US centimeters 76.2
paces (US) inches 30
pecks (US) bushels 0.28
pecks (US) cubic feet 0.311 114
pecks (US) cubic inches 537.60
pecks (US) cubic meters 0.008 809 77
pecks (US) cubic yards 0.011 522 74
pecks (US) dekaliters 0.880 976 75
pecks (US) dry pints 16
pecks (US) dry quarts x
pecks (US) liters 8.809 767 5
pecks (US) pecks (British) 0.968 9
penny weights grains 24
pennyweights grams 1.555 173 84
pennyweights troy ounces 0.05
pints, dry (US) bushels 0.015 625
pints, dry (US) cubic feet 0.019 444 6
pints, dry (US)
cubic inches
33.600 312 5
pints, dry (US) dekaliters 0.055 061 OS
pints, dry (US) dry pints (British) 0.968 9
pints, dry (US) dry quarts 0.5
pints, dry (US) liters 0.550 610 47 7
pints, liquid (US) cubic feet 0.016 710 07 —
pints, liquid (US) cubic inches 28.875 _
pints, liquid (US) deciliters 4.731 76 a :
pints, liquid (US) gallons 0.125
pints, liquid (US\\ gallons 0.125
pints, liquid (US) gills (US) 4 -
615
Conversion Factors To Convert From To Multiply by
pints, liquid (US) liquid ounces 16
pints, liquid (US) pints, liquid (US) 0.832 67
pints, liquid (US) liquid quarts 0.5
pints, liquid (US) liters 0.473 176 473
pints, liquid (US) milliliters 473.176 473
pints, liquid (US) minims 7,680
points (typographical) inches 0.013 837
points (typographical) millimeters 0.351 459 8
pounds, avoirdupois avoirdupois drams 256
pounds, avoirdupois avoirdupois ounces 16
pounds, avoirdupois grains 7.000
7.000 grams 453.592 37
pounds, avoirdupois kilograms 0.453 592 37
616
pounds, avoirdupois
long tons
0.000 446 428 6
pounds, avoirdupots
metric tons
0.000 453 592 37
pounds. avoirdupois quintals 0.004 535 92
pounds, avoirdupois short tons 0.000 5
pounds, avoirdupois troy ounces 14.583 33
pounds, avoirdupois troy pounds 1.215 278
pounds, troy avoirdupois drams 210.651 4
pounds, troy avoirdupois ounces 13.165 71
pounds, troy
avoirdupois pounds
0.822 857 |
pounds. troy grains 5.760
pounds, troy grams 373.241 721 6
pounds, troy kilograms 0.373 241 7216
pounds, troy pennyweights 240
pounds, troy troy ounces 12
quarts, dry (US) bushels 0.031 25
quarts, dry (US) cubic feet 0.038 889 25
quarts. dry (US)
cubic inches
67.2™ 625
quarts, dry (US) dekaliters 0.1:0 122 1
quarts, dry (US) dry pints 2
quarts, dry (US) dry quarts (British) 0.968 9
quarts, dry (US) liters 1.101 221
quarts, dry (US) pecks 0.125
quarts, dry (US) pints, dry (US) 2
quarts, liquid (US)
cubic feet
0.033 420 14
quarts, liquid (US)
cubic inches
57.75
—
Conversion Factors To Convert From To Multiply by
quarts, liquid (US) deciliters 9.463 53
quarts, liquid (US) gallons 0.25
quarts, liquid (US) gills (US) «
quarts, liquid (US) liquid ounces 32
qua','8170cb834df307da47a52212cb125631c54ab99f1c3f78a0bfc14ba3a0a533e5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b01481dca3c11f0a2aebe28ddaafbd709c0769a6e72dd97b18e20cc6a88e212b',1996,'ZW','Zimbabwe','transportation',553,'rts, liquid (US) liquid pints (US) 2
quarts, liquid (US) liquid quarts (British) 0.832 67
quarts, liquid (US) liters 0.946 352 946
guarts, liquid (US) milliliters 946.352 946
quarts, liquid (US) minims 15,360
quintals avoirdupvis pounds 220.462 26
quintals kilograms 100
quintals metric tons 0.1
rods feet 16.5
rods meters 5.029 2
rods yards 5.5
rods, square acres 0.006 25
rods, square square meters 25.292 85
rods, square square yards 30.25
scruples grains 20
scruples grams 1.295 978 2
scruples troy drams 0.333
sections (US) square kilometers 2.589 988 |
sections (US) square statute miles l
spans centimeters 22.86
spans inches )
steres cubic meters l
steres cubic yards 1.307 95
tablespoons milliliters 14.786 76
tablespoons teaspoons 3
teaspoons milliliters 4.928 922
teaspoons tablespoons 0.333 333
ton-miles, long metric ton-kilometers 1.635 169
ton-miles, short metric ton-kilometers 1.459 972
tons, gross register cubic feet of permanently enclosed 100','78b9df1e419e1a2bb62823fb965d105523765b228daad5d0aa4ddef7081fe07c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22ce9fdd8ab051801e450c92b3b225b13ec2dec563d1dd7bb384a3bfb5c5db77',1996,'MV','Maldives','transportation',564,'Railways: 0 kin
Highways:
NAV An
é ‘“ \\ Ali
‘ ‘ NA kin. note
hrehwass within the city CLYSS est
Ports: Cran, Male
Male has 9 6 kim of
Vlerchant marine:
ships (bE OWOO GRE of over) totaling
SEGRE LT) 3.6609 DWI
h ''
Airports:','93d35fb1707e166d2176636366c556abbd023b2da9b0f283407f3b8413b8f3ea','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c83061bc0e16cd72124170a10209de68001bcc0305e4f27587293c468f17fefc',1996,'MT','Malta','transportation',576,'Railways:
total: S2 kim (27 km electnitied)
Highways:
total’ 640 km
paved) 320 km
unpaved: 320 km
Ports: Castletown. Douglas. Peel. Ran
Merchant marine:
total: 83 ships 1.000 GRT ot over) tot
2.099.888 GRT/3.569.632 DWI
ships by type: bulk 13. cargo 10. chen
tanker 4. container 12. liquefied gas |
oil tanker 18. passenger 2. roll-on/rell ot
cargo 13. short-sea passenger |. veh»
carrier 2
note: a flag of convenience registry. UA
owns 10 ships. Switzerland 2. South Att
2. Denmark |. and Netherlands |.) 495
\\irports:
total: |
with paved runways 1,524 to 2.437 9
(1995 est.)
305
oH
Nan, Isle of (continued)','18f7dcef4661b81becb6cb421e935f4e7b69f26e8e3f097835024b2fe5009ecb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a945f696be6a93c5a7ea5b0171fba9c876dd37ad2b98e86b5329655e17535e3a',1996,'MH','Marshall Islands','transportation',582,'Railways: 0) +
Highways:
NA}
Miicad NA ,
iis NA 4
5
t ’ ,
Kw
Latent tee ,
Ports: \\i
Nlerchant marim
4 (Wys . (;kR] S 4) . pW]
\\irports:','0a8d410b8ebda73a8bf03b064020f0aaa8dea6875213f73d35b112d49829252e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3d99bc807443d9974f4ed32ed46386466c3176eae01eaf39bf580764a8021e3',1996,'MQ','Martinique','transportation',586,'Railways: 0 km
Highways:
1.690 km
1 km
unpaved. 390 km
Ports: Fort-de-France. La Trinite
Merchant marine: none
Airports:
total: 2
total
paved
with paved runways over 3.047 m. |
with unpaved runways 914 ta 1.5238 m |
(1995 est.)','b05a5ba72993407a5ac15af501c9124c99bfad632eb5d2c1aa56054e09581c37','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3b87e3107f806079bd8f98fd0222b756342b2686125d4abb07a3eb222ceb939',1996,'MU','Mauritius','transportation',590,'Railways: 0 kim
Highways:
total: 93 km
paved: 72 km
unpaved: 21 km
Ports: Dzaouds1
Merchant marine: none
Airports:
total: |
with paved runways 914 to 1528 me 1 (1995
CSL.)','c1d02dccbdde4318b0bbb12d48eb275d306af59f5ad69cb033370479d8227c6d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82ce6307ce3171b14c2258ef7f5558c0ec7f35acd01d48c2acd13c1452565ad1',1996,'RO','Romania','transportation',596,'Railways:
total: 1.328 km
broad gauze: 328 km 1.520-m gauge
(1992)
Highways: RANCE
total: 14,508 km
paved: 12.346 km a
unpaved: 2.162 km (1992 est.) .
Waterways: 424 km (1994)
Pipelines: natural gas 310 km (1992)
Ports: none _
Airports: an
total: 26 .
with paved runways over 3,047 m: |
with paved runways 2.438 to 3,047 m: 2 |
with paved runways 1,524 to 2.437 m: 2
with paved runways under 914m: 3
with unpaved runways 2.438 to 3.047 m: 3 Geography
with unpaved runways 1,524 to 2.437 m: 2 Location: Western Europe. bord |
with unpaved runways 914 to 1,523 me: § Mediterranean Sea. on the souther
with unpaved runways under 914 m- & (1994 France. near the border with Ita
est.) Ceographic coordinates: 44 44 \\ 7
Map references: Eunos
Arca:
Communications whe oni
heath ave ) >
Telephones: 577.000 (1991 est) aie a yr Hiemeee eh
Telephone system: telecommunication '' The Ma ‘A -
system not well developed: 215.000 Land boundaries:
unsatistied requests for telephone service f Sik
(1991 est.) I oncle ‘ | $44
domestic: NA (Coastline: 4 | 5
international. international connections to Maritime claims:
other former Soviet republics by landline and crvitortal sea Al 4
microwave radi relay through Ukrame and International disputes: »..
to other countries Sy leased connections to Climate: Mediterranean wo
the Moscow international gateway swatch. winters and hot. dr same
satellite earth stations - | Eutelsat and | lerrain: byl!) ed. rock
Intelsat ue Mediterranean 8
Radio broadcast stations: AM 9. FM 5 rar Mont 4 i
shortwave NA (1994) Natural resources:
Radios: NA Land use:
Television broadcast statins: 2 (one avabl
national and one private) (1995) permanent
Televisions: NA meadows and pasture
Cowes ated taverniland
ther TOAy
Irrigated land: \\\\ w }
Defense ;
bavironment:
Branches: Ground Forces. Aur and Au current wees NA
Defense Forces. Republic Security Force: natural hacards: NA
(internal and border troops) international agreements patty |
Manpower availability: Biodiversity. Climae Change. |
males awe 18-49. 1 AISS38 Species. Hazardous Wastes. Mus
males fit for military service, 888.757 Dumping. Ozone Laver Protection. Ship
males seach military age (18) annually Polluvon. Whaling. ened. but not rautred
37.183 (1996 est) Law of the Sea
323
Monaco (continued)
(,eographic note: second smallest
ndependent state wn world (after Holy See):
nest entirely urban
Railways:
total: 1.7 km
standard gauge
Highways:
total: SO km
paved: Wkm
unpaved: 0 km (1994)
Ports: Monaco
Merchant marine: none
Airports: linked to airport in Nice. France
by heloopter service
17 km |435-m gauge
333
Railways:
total: 11.374 km
hroad gauge: 60 km 1.524-m gauge
standard gauge: 10,887 km 1.435-m gauge
(3.866 km electrified; 3.060 km double
track)
narrow gauge: 427 km 0.760-m gauge
(1994)
Highways:
total: 153.014 km
paved: 78,037 km (including 113 km of
expressways)
unpaved: 74.977 km (1992 est.)
Waterways: |.724 km (1984)
Pipelines: crude oi! 2,800 km; petroleum
products 1.429 km: natural gas 6.400 km
(1992)
Ports: Braila, Constanta. Galatz, Mangalia.
Sulina, Tulcea
Merchant marine:
total: 233 ships (1.000 GRT or over) totaling
2.425.729 GRT/3.641.741 DWT
ships by type: bulk 39, cargo 166, container
2, oi} tanker 13. passenger |. passenger-
carge i, railear carrier 2, roll-on/roll-ott
cargo ¥
nvie: Romania owns an additional 15 ships
(1.000 GRT or over) totaling 1.078.490
DWT operating under the registries of
Liberia, Malta, Cyprus, and The Bahamas
(1995 est.)
Airports:
total: 156
with paved runways over 3,047 m: 4
with paved runways 2,438 to 3,047 m: 9
with paved runways 1,524 to 2,437 m: 14
with unpaved runways 2,438 to 3,047 m: 3
with unpaved runways 1,524 to 2.437 m: |
with unpaved runways 914 to 1,523 m: 17
with unpaved runways under 914 m: 108
(1994 est.)
Railways:
S000 4k S7.000 km on
{ vice (458.000) km
f) (MMP Rim serve specilic
dat t avaiable for common
/ UL KT) i. 1) 1? Cuiuce (|
Hivhwavs:
ve oe } dil ’ 115.000 km
sines or farms and
nhon Camrier use)
Waterways isivable routes in general
Minh navigation
kk in River Fleet
tht navigational
guble routes
wal
Pipelines: AS AMM AT. Petroleum
< vik '' gas 140.000 km
| ny
Ports: Ayki ’ kK. Astrakhan
b h Khabarovsk, Kholmsk
hk k Nf Murmansk
Nab 1h \\ k Novorossiysk
Petropastovsk. St. Petersburg. Rostov. Sochi.
lu Vlad tok. Volgograd
\\ \\
Merchant marine:
OOO GRT or over) totaling
GREY ASS S65 DWI
irae mer .. bulk 2S. cargo
ker 6. combination bulk 21
oil tanker
roll-off caro
if. speci ilived tanker
iN vns an additional 163 ships
(sk I totaling 2.276.829
DW iin a | wistries of Malta
Cyorus. Liberta. Panama. Saint Vincent and
he Gi Honduras, | Bahamas
and Vanuat YS esi
Airports:
Saf 4
with paved runways over 3.04/7 m: S4
ith paved runways 2.438 to 3,047 m
with paved runways 1,524 to 2.437 m: 108
with paved runways 9/4 to 1,523 me VIS
with paved runways under 9/4 m: 151
with unpaved runways over 3,047 m: 25
with unpaved runways 2,438 to 3,047 m: 45
with unpaved runways 1,524 to 2,437 m: 134
with unpaved runways 914 to 1,523 m: 291
402
with unpaved runways under 914 m: 1392
(1994 est)','5b196329a1a47b1a5dfcb3ec092153413038ba03abe26c396e8b81fde0c36e32','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a174fd7ba5fca99c2eb419a69875825a5774e93fa3c81bc45f02dd5b3614a048',1996,'MN','Mongolia','transportation',600,'Railways:
total: 1.928 km
broad gauge
(1994)
Highways:
total: 46.700 km
paved: 1000 km
unpaved: 45.700 km ¢:
Waterways: 397 km of principal routes
(1YS8S)
1.928 km 1.524-m gauge
YAR est)
Ports: none
\\irports:
total: 34
with paved runways 2.438 to 3.047 m: 7
with paved runways under 9Y14 me |
with unpaved runways over 3,047 m: 3
with unpaved runways 2.438 to 3,047 m: 5
with unpaved runways 1,524 to 2.437 m: 10
with unpaved runways 914 to 1.528 me 3
with unpaved runways under 914m: 5 (1994
est.)','c108a7375c0108e07638880a4d3735b72df38b5360419b70f89aa072e94dcd7f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d565f136455408544f0ff1cacedd0e12700269e36bf51353ab297841178e5075',1996,'MS','Montserrat','transportation',605,'Railways: 0 kin
Highways:
lavtad SO km
|
paiiod (Md KIN
ywnndied. BOkm
Ports: Plymouth
Verchant marine: none
\\irports:
total |
ith paved runways Yid to 1828 me LV AVY9IS
I','d038a299a0cb24f31e479c3ccc5ec3f2630bc1c814e96542dd032c02047a046d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90a9d922ff28b4467a4e6f84ce9be134636d27128933469025812f50ca9b5d74',1996,'MA','Morocco','transportation',612,'Railways:
total: 1 YO7 km
viandard gauge: 1.907 km 1.435-m gauge
(1003 kin electrtied: 246 km double track)
(1994)
Highways:
total: SY.474 km
paved. 29.440 km Cnecluding
CAPTESsWays)
40.034 kin (19917 est)
73 km of
unpaved
337
Pipelines: crude oi! 362 km: petroleum
products 491 km (abandoned): natural gas
241 km
Ports: Agadir. Al Jadida. Casablanca. El Jort
Lastar. Kenitra, Mohammedia, Nador. Rabat.
Sati. Tangier. alyo Spanish-controlled Ceuta
and Melilla
Merchant marine:
total: 37 ships (1.000 GRT or over) totaling
175.962 GRT/257.449 DWT
ups by type: cargo &. chemical tanker 7.
container 2. oil tanker 4. refrigerated cargo
Y. roll-on/roll-off cargo 6. short-sea
passenger | (1995 est.)
Airports:
total: 63
with paved runways over 3,047 m V1
with paved runways 2.438 to 3,047 m: 4
with paved runways 1,524 to 2.437 m. 7
with paved runways 914 to 1,523 m: 2
with paved runways under 914m: 12
with unpaved runways 2.438 to 3,047 me: |
with unpaved runways 1,524 to 2,437 m: V1
with unpaved runways 914 to 1.523 me AS
(1995 est.)
Heliports: | (1995 est.)
Railways: 0 km
Highways:
total: 2.030 km
paved: 373 km
unpaved: 1,657 km (1988 est.)
Ports: Apia, Asau, Mulitanua, Salelologa
Merchant marine:
total: | roll-on/roll-otf cargo ship (1,000
GRT or over) totaling 3,838 GRT/5S.536
DWT (1995 est.)
Airports:
total: 3
with paved runways 2,438 to 3,047 m: |
with paved runways under 914 m:; 2 (1995
est.)
Railways:
total: 1,201,337 km includes about 190,000
to 195.000 km of electrified routes of which
147,760 km are in Europe, 24.509 km in the
Far East, 11,050 km in Africa, 4.223 km in
South America, and 4,160 km in North
America, note—fastest speed in daily service
is 300 km/hr attained by France''s Societe
Nationale des Chemins-de-Fer Francais
(SNCF) Le Train a Grande Vitesse (TGV )—
Atlantique line
broad gauge: 251,153 km
standard gauge: 710,754 km
narrow gauge: 239.430 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: Chiba, Houston, Kawasaki. Kobe.
Marseille, Mina’ al Ahmadi (Kuwait). New
Orleans, New York, Rotterdam, Yokohama
Merchant marine:
total: 25,521 ships (1,000 GRT or over)
totaling 442.276.527 GRT/701 647,274 DWT
ships by type: barge carrier 22, bulk 5,308,
cargo 8.089, chemical tanker 920,
combination bulk 307, combination ore/oil
279, container 1,938, liquefied gas tanker
709, livestock carrer 52, multifunction large-
load carer 62, oil tanker 4,320, passenger
298, passenger-cargo 117, railcar carrier 2!,
refngetaied cargo 1,022, roll-on/roll-off
cargo 1.034, short-sea passenger 484,
specialized tanker 81. vehicle carrier 458
(1995 est.)
World (continued)
established—17 February 1989
aim—A0 promote cooperation and
integration among the Arab states of
northern Africa
members—{5) Algeria, Libya, Mauritania, Morocco, Tunisia
Arab Monetary Fund (AMF)
address—P.O. Box 2818, Abu Dhabi.
United Arab
Emurates
telephone——{971| (2) 215000
FAX—{971] (2) 326454
established—27 April 1976
effective—2 February 1977
aim—to promote Arab cooperation,
development, and integration in monetary
and economic affairs
members—(\\9 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq,
Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia,
Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
Asia Pacific Economic Cooperation
(APEC)
address .
Ministry of Trade and Industry
Public Relations, 8 Shenton Way No 48
Ol, Treasury Building, Singapore.','578888f2a10b54682987f7ac025550011d4b23433f2f62b74f63a2a6bbe9777e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b83f6b454a7b1cc8541dcd4546cf2ebf58f9022593ce1ceac393a047859ce26',1996,'PT','Portugal','transportation',617,'Railways:
total: F131 km
narrow gauge. 2988 km 1067-m gauge
143 km (.762-m gauge (1994)
Highways:
total: 27,287 km
paved: 4.693 km
unpaved. 22.594 km (1991 est)
note” highway trattic impeded by land mines
not removed at end of civil war
Waterways: about 3.750 km ot navigable
routes
Pipelines: crude oil (not operating) 306 km:
petroleum products 289 km
Ports: Beira. Inhambane. Maputo. Nacala.
Pemba
Merchant marine:
total: 4 cargo ships (1.000 GRT or over)
totaling 5.694 GRT/9.724 DWT (1995 est)
Airports:
total: V3)
with paved runaays over 3,047 mo |
with paved ranways 2.438 to 3,047 m 4
with paved runways 1,524 to 2.437 mV
with paved runways 914 to 1,523 m: §
with paved runways under 914m: 67
with unpaved runways 1,524 to 2.437 m: 12
with unpaved runways 914 to 1,523 m- 32
(1995 est)
Railways: 0 km
Highways:
total: 298 km
paved: 198 km
unpaved: 100 km (1987 est.)
note. roads on Principe are mostly unpaved
and mm need ef repair
Ports: Santo Antonio, Sao Tome
Merchant marine:
total: 1 cargo ship (1.000 GRT or over)
totaling 1.096 GRT/1.10S DWE (1995 est)
Airports:
total: 2
with paved runways 1,524 to 2.437 m: |
with paved runways 914 to 1.528 m: 1 (1995
est.)','ff2f2d09f2f128ff8b042b2e893e5e8f4cbf41b5a222d994d9054cf140e582e9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df8c236b051ba86afd4916bd5fc3af342f887fc8bb3327e0cafb08d817f7241f',1996,'NA','Namibia','transportation',621,'Railways:
tN hoy e POS,
> a8) km 1067 -m cave
nele track
Highways:
al 54.186 kim
minied 4.056 km
mpaied SOLA kim C1987 est)
Ports: Luderitz. Walvis Say
Merchant marine: none
Airports:
total: (ON
niwth paved runways over 3.047 m: 2
with paved runways 2.438 to 3.047 m
wwth paved runways | $24 to D437 me |
with paved runways 914 ta 1,523 m. 3
nwin puarcd ranwavs under Y1id n it)
DD 4as wi 3047
‘1 an it? juivecd Pind
, > -
'' th “a paved riiwMays / Sd la’ 4% ”
'' wh i? juiced Pidsiumaiys Yj J ie? Li
/ wes si }
Railways:
total: 3.9 km. note—used te haul phosphates
from the center of the island to processing
lacihities on the southwest coast
Highways:
natal, 27 km
paved 2) km
unpaved: 6 km C1986 est)
Ports: Nauru
Merchant marine: nonce
Airports:
total: |
with paved runways 1,824 to 2437 m |
(1995 est.)
Navassa Island Bay. Cuba. mostly exposed rock. but enough
iterritery of the US) grassland to support gaat herds. dense stand
of tig-lthe trees. scattered Cactus','e0c29d4b3bac1191dfae8c20ad25071648bdb1e8cdf115ab7c99faf8390250e5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa804d6b2b7828c8d57ac8d26d1bfa232258c33dd430fbd18140c2d1571e10bc',1996,'NP','Nepal','transportation',628,'Railways:
! teil it kn mvc
Indian hordet
st} Tera:
narnm eanec TO) km OC62-m guys
Highways:
vital YYF4 kn
mived 4.421 kn
unpaved: OS12 kin (1995S est
Ports: none
\\irports:
nial 43
with puved Temas overs ig ow
with poved runways 1 S524 ta 248 om 4
with paved runways Vid te 1 Soa a
mui punieca rors wider Vida
now mrp cal rors si $d / a ;
neh wngur ca ranmays Vid Se oy i)
,1Ous cM
telephone—{977| (1) 221785, 221787.
221794
FAX--—(977] (1) 227033
esiablished—8 December 1985
aim—t0 promote economic, social, and
cultural cooperation
members—{7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
South Pacific Commission (SPC)
address—Anse Vata, BP DS N »umea
CEDEX. New Caledonia
telephone—{687| 26 20 00
FAX—|687] 26 38 18
established—6 February 1947
effective—29 July 1948
aim—to promote regional cooperation in
economic and social matters
members—(27) American Samoa, Australia, Cook Islands, Fiji, France, French Polynesia,
Guam, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, New Caledonia,
NZ, Niue, Northern Mariana Islands, Palau, Papua New Guinea, Pitcairn Islands, Solomon
Islands, Tokelau, Tonga, Tuvalu, UK, US, Vanuatu, Wallis and Futuna, Western Samoa
South Pacific Forum (SPF)
address—c/o forum Secretariat, Ratu
Sukuna Road GPO Box 856, Suva, Fiji
telephone-—|679| 312 600, 303 106
FAX—|679] 302 204
established—S August 197!
aim—40 promote regional cooperation in
politcal matters
members—(16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru. NZ, Niue, Palau, Papua New Guinea, Solomon Islands, Tonga, Tuvalu,
Vanuatu, Western Samoa
582
SY/
South Pacific Regional Trade and
Economic Cooperation Agreement
(Sparteca)
address—{see South Pacific Forum)
established—NA 198}
aim—to redress unequal trade relationships
of Australia and New Zealand with small
isiand economies in the Pacific region
members—{15) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru, NZ, Niue, Papua New Guinea, Solomon Islands. Tonga. Tuvalu, Vanuatu.
Western Samoa
Southern African Customs Union
(SACU)
address—Director General, Trade and
Industry, Private Bag X84, Pretoria 0001,','cfb3fd0a27fc38f18f74caa8ad7a20991450fca68beb59489933ddd8a2c50a84','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8e5f087775be02e0f4ff416af51d36399bbab8aaad8f6b726a5fc99c801fb7e',1996,'DZ','Algeria','transportation',640,'Railways: 0 km
Highways:
total: 11,25.- km
paved: 3.265 km
unpaved: 7.993 km (1990 est)
Waterways: Niger nver ts navigable 300 km
from Niamey to Gaya on the Benin frontier
from mid-December through March
Ports: none
Airports:
total: 23
with paved runways 2.438 to 3.047 m. 2
with paved runways 1,524 to 2.437 m. 6
wah paved runways 914 te 1523 mj
with paved ranways under 914m. 2
witk unpaved runways 1,524 to 2.437 m: |
witn unpaved runways 914d to 1.523 m V1
(1995 est)','3131cd5c8b5825d66d846a9c5400c46badb8e94aa9da62b77cd079ed73d1cf52','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e5de9c5110a269efea086ed38cf8a666c73aafc8570d10a18c6b1e8bbf25b52',1996,'MP','Northern Mariana Islands','transportation',642,'Railways: kim
Highways:
SS} SN Am C1991) est
NA km
mparved NA kim
Waterways: non
Ports: Saipan. tu
Vlerchant marine: jon
\\irports:
/ a 1, (id ;
” ; YJ ’ j o
; siruled 44
j pid 4 ‘ th ;
Heliports: uv','0448423293bae547d62ef3d2a27198fe0edab18eeb4b9276758daaf46db85d67','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07f94734b367afa28cbbc1c541392e755b818b9f1f36b2033fb3965b1776cede',1996,'NO','Norway','transportation',649,'Kutlway
Mivhwass
Waterways q
Pipelines ;
Ports |
i i
b \\ 4 {)
Vierchant marin
WWI cok]
YGRI DWI
4 ‘ » }
i ‘ | Rh it} amnihy i
'' ‘ ; | } i tank
h ‘SP wer 10. passenger
carge 2. calear canner |, retiugerated cargo
13. roll-on/‘roll-olf cargo 49 Showt-sea
passenger 21. vehicle camer 30
note? the government has created an intemal
register. the Norwegian International Ship
Register iNIS). as a subset of the Norwegian
register. Stups on the NIS enjoy many
benetits of flags of convemence and do not
have to be crewed by Norwegians (1995 est)
Airports:
nh maied runways oer 3040 9» |
wil paaicd rigimMadys JIN ww iid om i
udh paced rwmave / s 4 le J 43 om tA
with pated runways GI4d to TOO 8 me fi
nah pared runways under Yl4dim- Of
WTA MAN TMS GJdto LT XSO8 am .
;}Vus est)
Heliports: | (1995S est)
Ports: Honckok « Tho ‘ Hione A
Ko > hseur | iM ul | ~
Miumila city perks Pusu South A
San bran is, S&S ’ is, Si
i? \\S S\\ \\
\\ 7 ste mh '' \\W '' ‘'' \\
Vohkovhy
( Ommunications
lelephone system:
4 i, if','627933e0697d9cef955f3fc957ae39d1fcf155bc89001451f9b8aec23def3915','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5135a54d28591b945714b0a710ee9f34fbaf3fa4b72ac8c8ba822f2be4e4353d',1996,'PK','Pakistan','transportation',650,'.
~ * @''SLAMABAD
¢
Railways: 0 km
Highways:
total: 1AYL km
paved: 1.028 km
unpaved: 163 km (1988 est.)
Pipelines: crude oil 235 km: natural gas 400
km
Ports: Doha, Halul Island. Umm Sa‘id
Merchant marine:
total: 19 ships (1.000 GRT or over) totaling
467.447 GRT/771.483 DWT
ships by type: combination ore/oil 2.
container 3, cargo 11. oil tanker 3 (1995 est.)
Airports:
total: 3
with paved runways over 3,047 m: |
with paved runways under 914m: |
with unpaved runways 914 to 1,523 m: |
(1995 est.)
Heliports: | (1995 est.)','dc4fbb0f7257e649e557a9e53e192620e459e26666bc44a55b3ed3936f80c6cc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3879a9aca297a3605d26cc690bf269d685b2f116c12f4c9852e77e99dc300dd6',1996,'FR','France','transportation',657,'Railways:
total: SAO3 km
/
7.718 km 1.676-m gauge (293
OU Lue
kin electrified: |.037 km double track}
368
narrow gauge: 445 km 1.000-m gauge; 661
km less than 1.000-m gauge (1995 est.)
Highways:
total: 205.304 km
paved: 104.735 km
unpaved: 100,569 km (1995 est.)
Pipelines: crude oi] 250 km: petroleum
products 885 km; natural gas 4.044 km
(1987)
Ports: Karachi. Port Muhammad bin Qasim
Merchant marine:
total: 24 ships (1.000 GRT or over) totaling
345.606 GRT/560.641 DWT
shups by type: bulk 3, cargo 19, oil tanker 1.
passenger-cargo | (1995 est.)
Airports:
total: Vn
with paved runways over 3,047 m: 12
with paved runways 2,438 to 3,047 m: 19
with paved runways 1,524 to 2.437 m: 25
with paved runways 914 to 1,523 m: 11
with paved runwevs under 914 m: 18
with unpaved runways 1,524 to 2.437 m: 7
with unpaved runways 914 to 1,523 m: 8
(1995 est.)
Heliports: 6 (1995 est.)
Railways: 0 km
Highways:
total: 2.784 km
pure d: 2.187 km
unpaved: S97 km (1987 est.)
Ports: Le Port. Pointe des Galets
Merchant marine: pone
Airports:
total: 2
with paved runways 2.438 to 3.047 m: |
with paved runways 914 to 1.523 me 1 C1995
USL)
Railways: 0 km
Highways:
total: 120 km (Ile Uvea 100 km, Ile Futuna
20 km)
paved: 16 km (all on Ile Uvea)
unpaved: 104 km (Ile Uvea 84 km, Ile
Futuna 20 km)
Waterways: none
Ports: Leava, Mata-Utu
Merchant marine:
total: | oil tanker (1,000 GRT or over)
totaling 26,000 GRT/40,000 DWT (1995
est.)
Airports:
total: 2
with paved runways 1,524 to 2,437 m: |
with unpaved runways 914 to 1,523 m: |
(1995 est.)
Railways: () km
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: smali road network: Israelis have
developed many highways to service Jewish
settlements
Ports: none
Airports:
total: 2
with paved runways 1,524 to 2,437 m: |
with paved runways under 914 m: 1 (1995
est.)
telephone—{33] (1) 42 92 31 26
FAX—{33] (1) 42 92 39 88
established—20 December 1945
aim-—to form a monetary union among
countries whose currencies are linked to
the French franc
members—( 15) Benin, Burkina Faso, Cameroon, Central African Republic, Chad, Comoros,
Congo, Cote d''Ivoire, Equatorial Guinea, France, Gabon, Mali, Niger, Senegal, Togo; France
includes metropolitan France, the four overseas departments of France (French Guiana,
Guadeloupe, Martinique, Reunion), the three territorial collectivities of France (Corsica,
Mayotte, Saint Pierre and Miquelon), and the three overseas territories of France (French
Polynesia, New Caiedonia, Wallis and Futuna)
Front Line States (FLS)
established to achieve black majority rule in South Africa; has since gone out of existence;
members included Angola, Botswana, Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and
Trade (GATT)
was established 30 October 1947 to promote the expansion of international trade on a
nondiscriminatory basis; subsumed by the World Trade Organization (WTrO) on | January
1995; niembers at the time were Angola, Antigua and Barbuda, Argentina, Australia, Austria,
Bahrain, Bangladesh, Barbados, Belgium, Belize Benin, Bolivia, Botswana, Brazil, Brunei,
Burkina Faso, Burma, Burundi, Cameroon, Canada, Central African Republic, Chad, Chile,
Colombia, Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic. Denmark,
Dominica, Dominican Republic, Egypt, El Salvador, Fiji, Finland, France, Gabon, The
Gambia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea-Bissau. Guyana, Haiti,
Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Ireland Israel, Italy, Jamaica,
Japan, Kenya, South Korea, Kuwait, Lesotho, Liechtenstein, Luxembourg, Macau,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Paraquay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Senegal, Sierra Leone, Singapore,
Slovakia, South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia Turkey, Uganda, UAE, UK, US,
Uruguay, Venezuela, Yugoslavia (suspended), Zaire, Zambia, Zimbabwe
Group of 2 (G-2)
established—informal term that came into
use about 1986
aim—to facilitate bilateral economic
cooperation between the two mos
powerful economic giants
members—(2) Japan, US
Group of 3 (G-3)
established—NA October 1990
aim—mechanism for policy coordination
members— 3) Colombia, Mexico. Venezuela
Group of 5 (G-5)
established—22 September 1985
aim—to coordinate the economic policies
of five major non-communist economic
powers
members—(5) France, Germany, Japan, UK, US
Group of 6 (G-6)
note—also known as Groupe des Six Sur
le Desarmement; not to be confused with
the Big Six
established—22 May 1984
aim—to achieve nuclear disarmament
members—(6) Argentina, Greece, India, Mexico, Sweden, Tanzania
563
Group of 7 (G-7)
note—membership is the same as the Big
Seven
established—22 September 1985
aim-—to facilitate economic cooperation
among the seven major non-communist
economic powers
members—{7) Group of 5 (France, Germany, Japan, UK, US) plus Canada and Italy
Group of 8 (G-8)
established—NA October 1975
aim—to facilitate economic cooperation
among the developed countries (DCs) that
participated in the Conference on
International Economic Cooperation
(CIEC), held in several sessions between
NA December 1975 and 3 June 1977
members—(8) Australia, Canada, EU (as one member), Japan, Spain, Sweden, Switzerland,
US
Group of 9 (G-9)
established—NA
aim—to discuss matters of mutual interest
on an informal basis
members—(9) Austria, Belgium, Bulgaria, Denmark, Finlaad, Hungary, Romania, Sweden,
Yugoslavia
Group of 10 (G-10)
note—aiso known as the Paris Club:
includes the wealthiest members of the
IMF who provide most of the money to
be ioaned and act as the informe! steering
committee; Name persists in spite of the
addition of Switzerland on NA April 1984
address—c/o IMF Office in Europe, 64-66
ave d''lena, F-75116 Paris, France
telephone—{ 33] (1) 40 69 30 80
PAX—[33] (1) 47 23 40 89
established—NA October 1962
aim—to coordinate credit policy
members—(11) Belgium, Canada, France, Germany, Italy, Japan, Netherlands, Sweden,
Switzerland, UK, US
nonstate participants—(4) BIS, EU, IMF, OECD
Group of 11 (G-11)
note—also known as the Cartagena Group
established—22 June 1984, in Cartagena,
if','b8450357799edaaa60f62300e86b0bbd8791156e1c9e99a37df58b3630d3ad15','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5deae39180ce303d5be8ec5c4e963144419ab51e3adaff657c0d6a5417783cd3',1996,'PH','Philippines','transportation',664,'Railways: 0 km
Highways:
total: 61 km
paved: 36 km
unpaved: 25 km
Ports: Koro!
Merchant marine: none
\\irports:
total: 4
with paved runways 1,524 to 2.437 m: |
with unpaved runways 1,524 to 2.437 m: 2
{ }99S esi }
Highways: much of the road and many
causeways built during World War II are
unserviceable and »vergrown
Ports: West Lageon
Airports: airstrip has been overgrown by
vegetation and is no longer serviceable
Defense
Defense note: deferise is the responsibility
of the US
Railways:
total: 499 km
NaATTOW LAULE 499 km 1.067-m gauge
(}9Q3)
Highways:
total: 160.633 km
paved: 22.489 km
“unpaved 138.144 kn. (1992 est
Waterways: 3.219 km: luted to shallos
draft Giess chan 1.5 m) vessels
Pipelines: petroleum products 357 km
Ports: Batangas. Cagayan de Ore. Cebu
Davao, Guimaras Island. Higan. Hoo. Jolo
Legaspi. Manila. Masao. Puerto Princesa
San Fernando, Subic Bay. Zamboanga
Merchant marine:
total: 535 ships (1.000 GRT or over) totaling
8.033.849 GRT/13.101. 188 DWT
ships by type: buik 230, cargo 126, chemical
tanker 3. combination bulk 11. container
liquefied gas tanker 9. livestock carner |2
oil tanker 44. passenger 2. passenger-cargo
12. refrigerated cargo 19, roll-on/roil-oft
cargo 12. short-sea passenger 18. vehicle
carrer 25
note: & flag of convenience registry: Japar
owns 22 ships. Hong Kong 4, Switzerland
Taiwan 1. Denmark |. and UK | (1995 ¢
Airports:
total: 235
J , 4
with PurYea PUNMANVS OVeT 3 U4 })
with Paved Turnways 2438 to 3.047
with paved run avs f $O4 ty > 43 ay) >s
with paved rHINWaAYS U]4 lo 1 Sfp
with paved ridgiwadys unde) Y/4 /} it}
witht MNpaved FUNWUYS 1524 t+ 2.437 nw
with Mnpaved runwavs ¥Yl4 to 1.523 me 63
(1995 est.)
Railways: ) km
Highways:
total: 6.4 km
paved: 0 km
unpaved: 6.4 km
Ports: Bounty Bay
Merchant marine: none
Airports: none','9a19eabbc8e86ff1a03f549f89add519a286700705cdb3a923253d9756995c2b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83ee989375d993d9ff409360e7e19e6d3644628e31c212a2a7d945d761a5a84c',1996,'PA','Panama','transportation',666,'.
+ enawe
Railways:
total: 355 km
broad gauge: 76 km | 524-m gauge
narrow gauge: 279 km 0.914-m gauge
Highways:
total: 10.103 km
paved: 3,233 km
unpaved: 6.870 km (1992 est.)
Waterways: 800 km navigable by shaliow
draft vessels: 82 km Panama Canal
Pipelines: crude oi! 130 km
Ports: Balboa, Cristobal, Coco Solo North,
Vacamonte
Merchant marine:
total; 3,758 ships (1,000 GRT or over)
totaling 69,960,500 GRT/107,632.713 DWT
ships by type: bulk 902, cargo 1.050,
chemical tanker 168, combination bulk 40,
combination ore/oil 19, container 307,
liquefied gas tanker 155, livestock carrier 7,
multifunction large-load carrier 3, oil tanker
488. passenger 31, passenger-cargo 5,
refrigerated cargo 295, roll-on/roll-off cargo
93, short-sea passenger 34, specialized tanker
11, vehicle carrier 150
note: a flag of convenience registry; includes
ships from 83 countries among which are
Japan 1,212, Greece 360, Hong Kong 263,
Taiwan 203, South Korea 198, US 160,
China 152, Singapore 118, UK 79,
Switzerland 67, and Norway 58 (1995 est.)
Airporis:
total: 99
with paved runways over 3,047 m: |
with paved runways 2.438 to 3,047 m: |
with paved runways 1,524 to 2,437 m: 5
with paved runways 914 to 1,523 m: 14
with paved runways under 914 m: 60
with unpaved runways 914 to 1,523 m: 18
(1995 est.)','b70f71904438e546b2ef7b64f45c5253ce7973685f8bd093a850b372f0329282','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f22a998eb75fa61b053f02ce71cae651296b732ed7ca2e1420a8b8198273ba10',1996,'NZ','New Zealand','transportation',677,'Railways: 0 km
Highways:
total: 19,088 km
paved 640 km
unpaved: 18.448 km (1988 est.)
Waterways: 10.940 km
Ports: Kieta. Lae, Madang. Port Moresby.
Rabaul
Merchant marine:
total: 12 ships (1.000 GRT or over) totaling
22.565 GRT/27.114 DWT
ships by tvpe: bulk 2. cargo 3. combination
ore/oil 5. container 1, roll-on/roll-otf 1 (1995
est.)
Airports:
total: 45)
with paved runways 2,438 to 3,047 m: |
with paved runways 1,524 to 2,437 m: \\2
with paved runways 914 to 1,523 m: §
with paved runways under 914 m- 371
with unpaved runways 1,524 to 2.437 m: V1
with unpaved runways 914 to 1,523 m: Si
(1995 est.)
Heliports: 2 (1995 est)
Ports: small Chinese port tacilities on
Woody Island and Duncan Island being
expanded
Airports:
fotal: |
with paved runways 1,524 to 2.437 m: | ton
Woods Island) (1995 est.)','a3f31172004ab247c820e79c1c240b3fb010710a5cc6b453633eabd2ee9502c7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56480abce14c1b772a885cb934f32aae2f61cb63445e2e18bd8a90faaf64b1c5',1996,'ES','Spain','transportation',685,'Railways:
total: 3.068 km
broad gauge: 2.761 km 1.668-m gauge (464
km electrified: 426 km double track)
narrow gauge: 307 km 1.000-m guuge
note: in 1992. Portugal had 3,588 km ot
track of which 464 km were electrified
Highways:
total: 70.176 km (statistics for continenta!
Portugal only)
paved: 60.351 km (including $i9 km of
expressways)
unpaved: 9.825 kin (1992 est.)
Waterways: 820 km navigable: relatively
unimportant to national economy, used by
shallow-draft craft limited to 300 metric-ton
cargo capacity
Pipelines: crude oi] 22 km. petroleum
products 58 km
Ports: Aveiro. Funchal (Madeira Islands).
Horta (Azores). Leixoes, Lisbon, Porto,
Ponta Delgada (Azores). Praia da Vitoria
(Azores). Setubal. Viana do Castelo
Merchant marine:
total: 72 ships (1.000 GRT or over) totaling
795.725 GRT/1 418.538 DWT
ships by tvpe: bulk 7. cargo 35. chemical
tanker 5. container 5. liquefied gas tanker 4.
ml tanker 12. passenger-cargo |. refrigerated
cargo |. roll-on/roll-off cargo 1. short-sea
passenger |
note: Portugal has created a captive register
on Madeira tor Portuguese-owned ships:
ships on the Madeira Register (MAR) will
have taxation and crewing benefits of a flag
of convemence: Portugal owns an additional
25 ships (1.000 GRT or over) totaling
155.776 DWT operating under the registnes
ow Panama and Malta (1995 est.)
Airports:
total: 67
with paved runways over 3,047 m: 5
with paved runways 2.438 to 3,047 m: &
nith paved runways 1,524 to 2.437 m: 3
with paved runways 914 to 1,523 m: 18
with paved runways under 914 m: 30
with unpaved runways 914 to 1,523 m: 3
(1995 est.)
Railways:
note: minima! agricultural railroad system
near San Fernando: railway service was
discontinued in 1968
Highways:
total: 8,352 km
paved: 3,978 km
unpaved: 4,374 km (1987 est.)
Pipelines: crude oil 1,032 km; petroleum
products 19 kin; natural gas 904 km
Ports: Pointe-a-Pierre, Point Fortin, Point
Lisas, Port-of-Spain, Scarborough,
Tembladora
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling
2,928 GRT/5,571 DWT
ships by type: cargo 1, oil tanker 1 (1995
est.)
Airports:
total: 5
with paved runways over 3,047 m: |
with paved runways 2,438 to 3,047 m: |
with paved runways under 914 m: 2
with unpaved runways 914 to 1,523 m: |
(1995 est.)','1d1b525d35e7a6f741c861b748047fe14171c37bc6b9c00744d7e0de97a36f3a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fdeb1bcb7cc7023cb46c6647359afe11eedf0dc500c292a21b76898bb3c0d50',1996,'KN','Saint Kitts and Nevis','transportation',700,'Railways:
total; S& km
narrow gauge: 38 km 0.762-m gauge on
Saint Kitts to serve sugarcane plantations
(}]99S)
Highways:
total: 300 km
paved: 125 km
MNPare d: 175 km
Ports: Basseterre. Charlestown
Merchant marine: nore
\\irports:
lOldle 2
with paved runways 2.438 to 3,047 m: |
with paved runways under 914 me 1 C1995
est.)','53044e1dedb50b1acb3d9f7356fdf4622f4fc8c93017c566df622c4169ae323c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4e3125ffd6b6234130c9fddfa0a9ab09b343e33f84ac9519020fca38a391c16',1996,'LC','Saint Lucia','transportation',707,'Railwass: ko
Highways:
mparved: 2004
Ports: Castn Vieux Fort
Merchant marine: none
Airports:
total: 3
438 10 3.047 me |
924 to 2.437 m: |
, under Yl4e me 1 C1995
with Paved TURMAYNS .
with paved ridid
vith paved ruaiwa
CSL)','b7723281bade55ae6b2a08376204ded226f0b2a8ddcf96e6210c60ec60c33bee','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b200f78a53ef3a77763dafa0db8f7afaa46ec4844071adaff894ea3fc5c1426',1996,'PM','Saint Pierre and Miquelon','transportation',714,'Railways: ( km
Highways:
total: 120 km
paved: 60 km
unpaved: 60 km (1985 est.)
Ports: Saint Pierre
Merchant marine: none
Airports:
total: 2
with paved runways 914 to 1,523 m: 2
note: NeW airport to open June 1996 (1995
est.)
Railways: © km
Highways:
total: 1,100 km
paved: 330 km
unpaved: 770 km
Ports: Kingstown
Merchant marine:
total: 611 ships (1.000 GRT or over) totaling
5.690.104 GRT/9.367.014 DWT
ships by type: bulk 106, cargo 305, chemical
tanker 20. combination bulk 9, combination
ore/oil 4, container 33. liquefied gas tanker
4. livestock carner 5, oil tanker 58,
passenger |. passenger-cargo |, refriverated
cargo 35, roll-on/roll-off cargo 25, short-sea
passenger 2. specialized tanker |. vehicle
carrier 2
note: a tlag of convenience registry: includes
ships from 24 countries among which are
Croatia 42, Russia !4, Slovenia 9, China 9.
Germany 2. Serbia 2. Hong Kong 2, Latvia
1. Ukraine 1. and Poland | (1995 est.)
Airports:
total: 6
with paved runways 914 to 1,523 m: 2
with paved runways under 914 m: 4 (1995
est.)','f944f803517dd77145df14670742b51686019fd85e556246e2eb16e90a0bf5b2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23ab80fa8088f37dd54195594e622950e85da6d627538274438712396a6ae236',1996,'SM','San Marino','transportation',721,'Railways: 0 km; note—there is a 1.5 km
cable railway connecting the city of s. 1
Manno to Borgo Maggiore
Highways:
total: 220 km
paved: NA km
unpaved: NA km
Ports: none
Airports: none','1cd36895bc908c0b98e286cf3f222918f29867fb85cfa5c3d53f18b7b291603d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0756a4cf210a1a7367e8e7ca9263811c7d0db6d1536fa80f8832cb3461334d29',1996,'SD','Sudan','transportation',729,'Railways:
total: 1.390 km
standard gauge. 1.390 km 1.435-m gauge
(448 km double track) (1992)
Highways:
total: ($1,532 km
paved: 60.613 km
unpaved: 90.919 km (1992 est.)
Pipelines: crude oi! 6.400 km; petroleum
products 150 km; natural gas 2.200 km
(includes natural gas liquids 1.600 km)
Ports: Ad Dammam. Al Jubay!. Duba.
Siddah, Jizan, Rabigh. Ra’s al Khafji. Al
Mishab, Ras Tanura, Yanbu’ al Bahr.
Yanbu’ al Sinaiyah
Merchant marine:
total: 76 ships (1.000 GRT or over) totaling
944.946 GRT/1.322.167 DWT
ships by type: bulk 1. cargo 13, chemical
tanker 5, container 3. liquefied gas tanker 1.
livestock camer 4. oil tanker 22. passenger
1. refrigerated cargo 4, roll-on/roll-off cargo
13. short-sea passenger 9 (1995 est.)
Airports:
total: 175
with paved runways over 3,047 m:
with paved runways 2.438 to 3.047 m: 11
with paved runways 1,524 to 2.437 m. 22
with paved runways 914 to 1,523 m: 4
with paved runways under 914 m- 13
with unpaved runways over 3.047 m: |
with unpaved runways 2.438 to 3,047 m: 4
with unpaved runways 1,524 to 2.437 m: 66
with unpaved runways 914 to 1,523 m: 24
(1995 est.)
Heliports: 4 (1995 est)
if - , aoe
LIsyva SEE cover “ ,* an aoee
'' Was
i tale Pon
~~ S on,
Sawhar®
pe
WAL ‘
rms | cassaa /tmrms
{AR TOUM { aul
5 5 gsr Wao Vader ° vw
, ° /
- & Daye” Kus” A
t “Ayate ¢
os »
4 \\ ;
Go Yroenal ETHIOPIA
“be ra
‘ : wee q.
— a \\
i La \\
= — ° pa
nd No ue =
ZAIRE coon “A at’ ~','38f122aa2096be0f87cb9cda067a8591caa42d85b105626337510e1b031e4398','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('934c87b5bfd39eb30e0ac3ef06b2617632b9879011637bcc415742e66f41dc3d',1996,'ME','Montenegro','transportation',738,'Railwavs:
total: 3.960 km
standard CUu Le Ol) kim 1.435 Mi gauge
(1.441 km
| km electrified) (1992)
Highways:
otal 46.019 km
paved: 26.949 km
unpaved. 19.070 km (1990 est)
Waterways: NA km
Pipelines: crude oi! 415 km: petroleum
products 130 km: natural gas 2.110 km
Ports: Bar. Belgrade, Kotor, Novi Sad.
Pancevo, Tivat
Merchant marine:
Montenegro: total 21 ships (1,000 GRT or
over) totaling 326,133 GRT/544,600 DWT
(controlled by Montenegrin beneficial
owners)
424
ships by type: bulk 9, cargo 8, container 3.
short-sea passenger ferry |
note: ships operate under the flags of Malta,
Panama, and Cyprus; no ships remain under
Yugoslav flag (1995 est.)
Serbia: total 2 bulk ships (1.000 GRT or
over) totaling 42.916 GRT/77.103 DWT
(controlled by Serbiaa beneficial owners)
note: all under the flag of Saint Vincent and
the Grenadines: no ships remain under
Yugoslav flag (1995 est.)
Airports:
total: 44 (Serbia 39. Montenegro 5)
with paved runways over 3,047 m: 2 (Serbia
2. Montenegro 0)
with paved runways 2,438 to 3,047 m. §
(Serbia 3. Montenegro 2)
with paved runways 1,524 to 2.437 m: §
(Serbia 4. Montenegro |)
with paved ranwavs 914 to 1523 m
(Serbia 2. Montenegro 0)
with paved runways under 914m. 14 (Serbia
i4. Montenegro 0)
> )
j -% ,
with unpaved runways 1524 to 2.4387 m
,
(Serbia 2. Montenegro 0)
ah Wapaicd THUNWAYVS Yj 4 fea / .)
lim. 4
,
, 2) (1999S est)
(Serbia 12. Montenegro','9b98b5f788d1e8916326da37eda526ceec3ef3cb2293f530d3c53f2b7301826d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcd7510960205e5a271c4c5496c877f91118587bca920ac78bd69cdce6a543b1',1996,'LR','Liberia','transportation',751,'Railways:
val &4 km used on a limited basis because
the mine at Marampa ts closed
NUITTOW CAN Kd km | 067 mm pauve
Highways:
fy) + kn
Phl i ! xd km
428
unpaved: 10.390 km (1992 est.)
Waterways: 800 km: 600 km navigable year
round
Ports: Bonthe. Freetown, Pepel
Merchant marine: none
Airports:
wal. 5
with paved runways over 3,047 m: |
with paved runways 914 to 1,523 m: 2
with unpaved runways 914 to 1,523 m: 2
(1995 est.)','afa7161d551f5e5c0be1d8647cdab13506a22329d42dc6aadb2a3f7d9f6e8a57','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c2a0584d7935f33556788824fea65f32b023ab0423a196378d8c75228f5c855',1996,'SG','Singapore','transportation',756,'Kuiiwavys
sf kim
s Ff s , “ } Lj
Highways:
ORY kn
‘ YU } Teh ion !
i\\
i i S4 ks YUO4 !
Ports: Sing ip
Vierchant marine:
S46 ships CL OOO GRT of over) totalu
SORT SAO DWI
i\\h ) mo TiS. chemnk
. t il ruth mbination
} uu | loos lankel
uy ly { vl mr 1 nl
1 ret ‘ Hl-on/roll
1 na neve
y ityh vehicic iy r 24
i f ( } rm ry. nei
ines amone whech are
mn 39) Hone Kor Denmark 24
, Sweden !4. Tiland 14
4)
y) Defense
Navy. Au Force
Police Force
Branches: Army People’s
Defense Force
Manpower availability:
1S-49° 1.025.300
mrale , ave
mates fit for military service: 782. 382 (1996
cst.)
Defense expenditures: exchange rate
mversion—$3.9 bilhhon, 4.39 of GDP
, TOUS est )
established
aim—1o promote trade and investment in
7 November
the Pacific basin
}YRY
Asian Development Bank (AsDB)
addr 44
6 ADB Avenue
Mandaluyong
METRO Manila, Philippine
tele phone
FAX
established
163] (2) 711
163) (2) 74]
796)
19 December
KS]
631 O16
1966
aim—A0 promote regional economic
cooperation
Asociacion Latinoamericana de
integracion (ALADI)
members—( 18) all ASEAN members (Brunei, Indonesia, Malaysia, Philippines, Singapore
Thailand) plus Australia, Canada, Chile, China, Hong Kong. Japan, South Korea, Mexico
NZ, Papua New Guinea, Taiwan, US
observers—( 3) Association of Southeast Asian Nations, Pacific Econumic Cooperation
Conference, South Pacific Forum
regional members—(40) Atghanistan, Australia, Bangladesh, Bhutan. Burma, Cambodia
China, Cook Islands, Fip, Hong Kong. India, Indonesia, Japan, Kazakstan. Kiribati, South
Korea. Kyrgyzstan, Laos, Malaysia. Maldives. Marshal! Islands. Federated States of
Micronesia, Mongolia, Nauru. Nepal, NZ. Pakistan, Papua New Guinea. Philippines
Singapore, Solomon Islands, Sn Lanka, Taiwan, Thasland. Tonga. Tuvalu. Uzbekistan
Vanuatu, Vietnam, Western Samoa
nonregional members— 16) Austra. Belgsum. Canada, Denmark. Finland, France. Germany
lialy. Netherlands, Norway. Spain, Sweden, Switzerland, Turkey. UK, US
see Latin American Integration Association (LALA
\\ssociation of Southeast Asian Nations members—{7) Brunei, Indonesia, Malaysia, Philippines, Singapore, Thailand, Vietnam
ASEAN) observer— |) Laos
Jalan Sisingamangaraja 70A,
Baru, P.O. Box 2072, Jakarta
NCSid
62} (21) 71 22 72, 71 19 88
21) 739 &2 34
) August 1967
courage regionai economic,
cullural cooperation among
munmist countnes of Southeast
\\SrAN—Mekong Basin Development members— 11) Brunei, Burma, Cambodia, China, Indonesia, Laos, Malaysia, Philippines,
(,roup (Mekeng Group) Singapore, Thailand, Vietnam
hed-——NA December 1995
June 1996
perate in the development of
investment. tourism, agriculture,
in resources, and technology for the
''
build a railway trom Singapore to
\\ustralia Group members—( 28) Argentina, Australia, Austria, Belgium, Canada, Czech Republic, Denmark,
hed—i9&4 Finland, France, Germany Greece, Hungary, Iceland, freland, Italy, Japan, Luxembourg.
; Netherlands, NZ, Norway, Poland, Portugal. Slovakia, Spain, Sweden, Switzerland. UK, US
nsult on and coordinate ¢ Aport :
to chemical and biological observer—(1) Singapore
Australia-New Zealand-United States members—(3) Australia, NZ. US
Security Treaty (ANZUS)
/
iddress—c/o Department of Foreign
ind Trade. Bag &, Quecn Victoria
Canberra ACT 26000. Australia
611 (62) 6) OL TI
Kanco Centroamericano de integracion ee Central American Bank tor Eee mic Integration (BCIE)
Lconoemice (BCTR)
Banco Interamericano de Desarrollo ee Inter-American Development Bank (LADB)
(BID
Bank for International Settlements (BIS)
address—Centralbahnplatz 2, CH-4002
Basel, Switzerland
telephone—41] (61) 280 80 80
FAX—{41] (61) 280 91 00
established—20 January 1930
effective—17 March 1930
aim—A0 promote cooperation among
central banks in international financial
settlements
members—{ 33) Australia, Austria, Belgium, Bulgaria, Canada, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, Latvia,
Lithuania, Netherlands, Norway, Poland, Portugal, Romania, Slovakia, South Africa, Spain,
Sweden, Switzerland, Turkey, UK, US, Yugoslavia (suspended)
Banque Africaine de Developpement
(BAD)
see Afncan Development Bank (AfDB)
Banque Arabe de Developpement
Economique en Afrique (BADEA)
members—see Arab Bank for Econornic Development in Africa (ABEDA)
Banque de Developpement des Etats de
l’ Afrique Centrale (BDEAC)
see Central African States Development Bank (BDEAC)
Banque .>«est-Africaine de
Developpement (BOAD)
see West African Development Bank (WADB)
Benelux Economic Union (Benelux)
note—acronym from Belgium, Netherlands
and Luxembourg
address—Rue de la Regence 39, B-1000
Brussels, Belgium
telephone—{ 32] (2) S19 38 11
FAX—(32] (2) 513 42 06
» February 1955
effectve—i November 1960
aim—to develop closer economic
cooperation and integration
established
members—{3) Belgium, Luxembourg, Netherlands
Big Seven
note—membership is the same as the
Crroup of 7
established NA 1975
aim—to discuss and coordinate mayor
economic policies
Big Six
note not to be confused with the Crour
of 6
established —NA 1967
aim—Ao0 toster economic cooperation
Blak Sea Economic Cooperation Zone
(BSEC)
established—25 June 1992
aim—to enhance regional stability through
economic cooperation
members-—(7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus
members—A6) Canada, France, Germany, Italy, Japan, UK
members—( 11) Albamia, Armenia, Azerbaijan, Bulgaria, Georgia. Greece
Russia, Turkey. Ukraine
observers—(5) Egypt, Israel, Poland, Slovakia, Tunisia
Caribbean Community and Common members—< 14) Antigua and Barbuda, The Bahamas, Barbados, Belize, Dominica, Grenada,
Ma.tet (Caricom) Guyana, Jamaica, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
address—-Caricom. P.O. Box 10827. Bank Grenadines, Suriname, Trinidad and Tobago
of Guyana Building, 3rd floor, Avenue of associate members—{2) British Virgin Islands, Turks and Caicos Islands
the Republic, Georgetown, Guyana observers—A9) Anguilla, Bermuda, Cayman Islands, Dominican Republic, Haiti, Mexico,
telephone $92] (2) 69281 through 69289 Netherlands Antilles, Puerto Rico, Venezuela
FAX 59)! (2) 66091. 67816. 5734]
j
€MadDUSNed
aim—A0 promote economic integration and
development, especially among the less
devek ped «
Caribbean Development Bank (CDB) regional members—(20) Anguilla, Antigua and Barbuda, The Bahamas, Barbados, Belize.
address—P_O. Box 408. Wildev. St British Virgin islands, Cayman Islands, Colombia, Dominica, Grenada, Guyana, Jamaica,
Michael. Barbados Mexico, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
telephone—{\\} (809) 431 1600 Trinidad and Tobago, Turks and Caicos Islands, Venezuela
FAX—|1} (809) 426 7269
nonregional members—{5) Canada, France, Germany, Italy, UK
established—\\8 October 1969
effective—26 January 1970
aim—A0 promote economic development
and cooperation
Cartagena Group see Group of I]
Central African Customs and Lconomic members—(6) Cameroon, Central African Republic, Chad, Congo, Equatorial Guinea, Gabon
Union (UDEAC)
note—acronym trom Union Douaniere et
Economique de | Afnque Centrale
address—BP 969, Bangui, Central Atncan
Republic
telephone 1236) 61 O09 22. 61 45 77
FAX—{236] 61 21 35
established—-& December 1964
effective | January 1966
aim—to promote the establishme
Central Atrican Common Markct
Central African States Development members—(9) Cameroon, Central Atncan Republic, Chad, Congo, Equatorial Guine .. France
Bank (BDEAC) Gabon, Germany, Kuwait
|
I
At muue
ivecrnement
Central American Bank for Economic
integration (BCIE)
note—acroxym from Banco
Centroamericano de Integracion Economico
address—Apartado Postal 772, Tegucigalpa
DC, Honduras
telephone—{504| 372230 through 372239,
371184 through 371188
FAX—{504] 370793
established—\\13 December 1960
aim—AG promote economic integration and
development
members—{5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members—{4) Argentina, Mexico, Taiwan, Venezucla
Central American Common Market
(CACM)
address—4A Avda 10-25, Zona 14, Apdo
Postal 1237, 01901 Guatemala City,','406c997dcf20cdb6f651fdab0d6cdde6383b35bb20f64adcaf21364ed1bd5574','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('501db63c81c2495b6735a29ca4c65dc18c85561ad8c11471a33e7504e8ce2a00',1996,'SB','Solomon Islands','transportation',770,'Railways: 0 km
Highways:
total: 1300 km
paved: 30 km
unpaved: 1,270 km
note: in addition, there are 800 km of private
logging and plantation roads of varied
surtace (1982 est.)
Ports: Aola Bay. Honiara, Lotung. Noro,
Viru Harbor. Yandina
Merchant maring. none
Airports:
total; 0)
with paved runways 1,524 to 2,437 m: \\
with paved runways 914 to 1,523 m: |
with paved runways under 914m: 18
with unpaved runways 1,524 to 2,437 m: |
with unpaved runways 914 to 1,523 m: 9
(1995 est.)','6e137b6016e8b680e7400daf9c822cd3b8a719b72bf70a4bb32fd0a79c7f7b85','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee0f7a2ba3382633a2c581ef9ccedf6564028d4136c1f150960b7b5d0fb3e5cf',1996,'LK','Sri Lanka','transportation',776,'Railways:
tal 1.484 ko
Pvt del Calle we 1 459 4 f
mirroM Cane »§ aT
Highways:
tur YS651 ko
paved: 24.749 kn
unpaved. O3.902 km my
Waterways: 480 ki nave
dratt cratt
Pipelines: crude «ml and pet
62 kom (19R7)
Ports: Colombo. Galle. hat
Merchant marine:
26 ships (1 O00 GRIT
220.508 GRT/329.410 DWI
le tal
ips fy Tyr bulk J
ml tanker reinecrated cargo * ")
\\irports:
nial. 14
447
‘ or S04
‘ .'' ,. ~ » d .
(Communica .ions
lelephenes LL WI ¢
Telephone system: vor nicgu.
"
. 5
'' in
Ksclow broadcast Statbons \\\\i
Koadtos vw
Sri Lanka (continued)
lelesision broadcaM stations: 4
bole vtsnons
” fy i 1yOs
Ss Vim lis’
Defense
Branches: \\ ‘ Air Fou
bores
Vianpower availability:
-_, ‘ s+ ~* ti
nates
” ws j 5 j
Iete NOS (pur
Defense expenditures: exch.
,
COMNVeTSIOM S40) nullnon. 4
1p
ny
445
telephone—{94| (1) S81813, S8IRS3,
581754
FAX—{94} (1) 58072)
established—| July 1951
aim—A0 promote economic and social
deve''opment in Asia and the Pacific
members— 24) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Cambodia, Fiji, Inca,
Indonesia, Iran, Japan, South Korea, Laos, Malaysia, Maldives, Nepal, NZ, Pakistan. Pupua
New Guinea, Philippines, Singapore, Sri Lanka, Thailand, US
Commission for Social Development
note—tormerly Social Commission
address—c/o ECOSOC/DPCSD, United
Nations, New York, NY 10017, USA
telephone—{1} (212) 963 2320
FAX—{1] (212) 963 5935
established—2\\ June 1946 as the Social
Commission, renamed 29 July 1966
aim—to deal, as part of the Economic and
Social Council, with social development
programs of UN
members—(32) selected on a rotating basis from all regions
PA
2
~
Commission oa Crime Prevention and
Criminal Justice
established—® February 1992
um —to provide guidance, as part of the
yvonne and Social Council, on come
prevention and criminal justice
members—{40) selected on a rotating basis from all regions
(Commission on Human Rights
lress—</o United Nations Office, Centre
; Human Rights, Palass des Nations,
CH-12!11 Geneva 10, Switzerland
hrome—41] (22) 917 12 34, 907 12
FAN —{41] (22) 733 32 4
established—\\S February 1946
we lo assist, as part of the Economic
ind Secal Council, with human nights
programs of UN
members—4 53) selected on a rotating basis from all *g1ons
Commission on Narcotic Drugs
uldress—clo International Drug Control
Programme. Treaty Implementation and
Legal Athurs Division, P.O. Box S00,
\\usina
ephor h43) ab) 211 310
1) 2% 7002
iS February 1946
um—booneme and Social Council
\\ 1400 Vienna
ablished
wgamzavhon dealing with illicit drugs
programs of UN
members—453) selected on a rotating basis from all regions with emphasis on producing
and processing countries
Commission on Population and
Development
address do BCOSOC, United Nations
New York, NY POOT?, USA
cicphnonm 212) 754 1244
bhished—’ October 1946
o deal with population matters of
meta vw UN. as part of
'' L af Sonal Counc
( ommission on Science and Technology
for Development
hed —™*) Apnl 1992
" le international cooperatior
rt i tl } TOL im Sohal
cTut The
554
members—4 27) selected on a rotating basis from all regions
members (54) selected on a rotating basis from all regions
Commission on the Status of Women
address—<c/o Economic and Social
Council, Affairs Division, Department for
Policy Coordination and Sustainable
Development, Room S-2963, United
Nations, New York, NY 10017, U**
established—2\\ June 1946
aim—to deal, as part of the Economic and
Social Council, with women’s rights goals
of UN
members—{45) selected on a rotating basis from ail regions
Commission on Sustainable Development
establis ed—12 February 1993
aim—to monitor, as part of the Economic
and Social Council, implementation of
agreements reached at the UN Conference
on Environment and Development
members—{53) selected on a rotating basis from all regions
Commonwealth (C)
note—see Commonwealth of Nations
address—cio Commonwealth Secretariat,
Marlborough House, Pall Mall, London
SWIYSHX, UK
telephone—(44| (71) 839 3411
FAX—({44] (71) 9% 0827
established—31 December 1931
aim—to foster multinational cooperation
and assistance, as a voluntary association
that evolved from the British Empire
members—(49) Antigua and Barbuda, Australia, The Pahamas, Bangladesh, Barbados, Belize.
Botswana, Brunei, Canada, Cyprus, Dominica, The G.mbia, Ghana, Grenada, Guyana, India,
Jamaica, Kenya, Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius, Namibia,
NZ, Nigeria (suspended), Pakistan, Papua New Guinea Saint Kitts and Nevis. Saint Lucia.
Saint Vincent and the Grenadines, Seychelk _ sierra Leone, Singapore, Solomon Islands,
South Afnca, Sn Lanka, Swaziland, Tanzania, Tonga. Trinidad and Tobago. Uganda. UK.
Vanuatu, Western Samoa, Zambia, Zimbabwe
special members—42) Nauru, Tuvalu
Commonwealth of Independent States
(CIS)
address—Kirov Street 17, 220000 Minsk.','223bd951797a5360b419b306ac1cfade731d961457c1a5897c398e725471e2ec','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af5f398480db8acf2798d8e8024bd725d8b6292f284762094b31345952c2883e',1996,'TJ','Tajikistan','transportation',792,'Railways:
fotal: 480 km in common cartier service;
does not include industrial lines (1996,
Highways:
total: 32,752 km
paved: 21.119 km
unpaved: 11,633 km (1992 est.)
Pipelines: natural gas 400 km (1992)
Ports: none
Airports:
total: 59
with paved runways over 3,047 m: |
with paved runways 2,438 to 3,047 m: 5
with paved runways 1,524 to 2,437 m: 7
with paved runways 914 to 1,523 m: |
with unpaved runways 914 to 1,523 m: 9
with unpaved runways under 914 m: 36
(1994 est.)','1f3e5b3efef0727e45e66e8ec4bba6b83947ea5ca703874b90e77694c6f42f4d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d310d91da8e3f2d07d256d8d0984cf818fa9d15ea9e3558a1973487b6b06543e',1996,'TK','Tokelau','transportation',796,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: none; offshere anchorage only
Merchant marine: none
Airports: none: lagoon landings by
amphibious aircraft from Western Samoa','947d80078146acb0598e9d53ebb6f9111937bfbfdaed81e767788f77eb179a17','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c065519de09041ba541ac3da25c0edad05579c0881e92cc50806bf7cb826d1ce',1996,'TO','Tonga','transportation',801,'Railways: 0 km
Highways:
total: 432 km
paved: 280 km
unpaved: 152 km (1987 est.)
Ports: Neiafu, Nuku’alofa, Pangai
Merchant marine:
total: 4 ships (1,000 GRT or over) totaling
9,990 GRT/14.884 DWT
ships by type: cargo |, liquefied gas tanker
2, roll-on/roll-off cargo 1 (1995 est.)
Airports:
total: 6
with paved runways 2,438 to 3,047 m: |
with paved runways under 914 m: 2
with unpaved runways 1,524 to 2,437 m: |
with unpaved runways 914 to 1,523 m: 2
(1995 est.)','0b72a6f2506e34116d713fe0d1ab5ee48411c2055711f5db80f34304ed502039','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c2665e56caf345097264c7d6265d343406f44bdad02639cc4511c01ae7394c0',1996,'GE','Georgia','transportation',806,'Railways:
total: 2,260 km
standard gauge: 492 km 1.435-m gauge
narrow gauge: 1,758 km 1.000-m gauge
dual gauge: 10 km 1.000-m and 1.435-m
gauges (1993 est.)
Highways:
total: 29,183 km
paved: 17,510 km (including 52 km of
expressways)
unpaved: 11,673 km (1989 est.)
Pipelines: crude oil 797 km; petroleum
products 86 km; natural gas 742 km
Ports: Bizerte, Gabes, La Goulette, Sfax,
Sousse, Tunis, Zarzis
Merchant marine:
total: 19 ships (1,000 GRT or over) totaling
125,840 GRT/164,277 DWT
ships by type: bulk 6, cargo 4, chemical
tanker 3, oil tanker 2, roll-on/roll-off cargo
3, short-sea passenger 1 (1995 est.)
Airports:
total: 29
with paved runways over 3,047 m: 3
with paved runways 2,438 to 3,047 m: 6
with paved runways 1,524 to 2,437 m: 3
with paved runways 914 to 1,523 m: 3
with paved runways under 914 m: 6
with unpaved runways 1,524 to 2,437 m: 2
with unpaved runways 914 to 1,523 m: 6
(1995 est.)
Railways:
total: 10.386 km
standard gauge: 10.286 km 1.435-m gauge
(1,088 km electrified)
Highways:
total: 386,704 km
paved: 45,683 km (including 862 km of
expressways)
unpaved: 341,021 km (1992 est.)
Waterways: about |.200 km
Pipelines: ©:4¢ wi 1,738 km; petroleum
products 2,321 km, natural gas 708 km
Ports: Gemlik, Hopa, Iskenderun, Istanbul,
Izmir, [zmit, Mersin, Samsun, Trabzon
Merchant marine:
total: 465 ships (1.000 GRT or over) totaling
5.509.741 GRT/9,494,434 DWT
ships by type: bulk 139, cargo 212. chemical
tanker 18, combination bulk 7, combination
ore/oil 12, container 2, liquefied gas tanker
4. livestock carrier |, oi tanker 43,
passenger-cargo |, refrigerated cargo 2, roll-
on/roll-off cargo 15, short-sea passenger 7,
specialized tanker 2
note: Turkey owns an additional 18 ships
(1,000 GRT or over) totaling 247,369 DWT
operating under the registries of Malta,
Panama, Libya, and Greece (1995 est.)
Airports:
total: 104
with paved runways over 3,047 m: 17
with paved runways 2,438 to 3,047 m: 19
with paved runways 1,524 to 2,437 m: 12
with paved runways 914 to 1.523 m: 18
with paved runways under 914 m: 28
with unpaved runways 1,524 to 2,437 m: 2
with unpaved runways 914 to 1,523 m: 8
(1995 est.)
Helinorts: 2 (1995 est.)','9cd26c398f2d39ce63b341b7cfef7afcd7224cb642ba4897cd95f1db47c3c31d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cc29b1379f48aac8f351973330b035827eb961e693caf309fdb216e23e4836c',1996,'TC','Turks and Caicos Islands','transportation',813,'Railways: 0 km
Highways:
total: 121 km
paved: 24 km
unpaved: 97 km
Ports: Grand Turk. Providenciales
Merchant marine: none
Airports:
total: 7
with paved runways 1,524 to 2.437 m: 3
with paved runways 914 to 1,523 m: |
with paved runways under 914 m: |
with unpaved runways 914 to 1,523 m.
(1995 est.)
tv
Comimunications
Telephones: | 359 (1988 est.)
Telephone system: fair cable and
radiotelephone services
domestic: NA
international: 2 submarine cables: satellite
earth station—! Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3. FM 0.
shortwave 0
Radios: 7,000 (1992 est.)
Television breadcast stations: television
programs are available from a cable network,
and broadcasts from the Bahamas can be
received in the islands
Televisions: NA
Defense
Defense note: defense is the responsibility
of the UK
Railways: 0 km
Highways:
total: & km
paved: 0 km
unpaved: 8 km (1988 est.)
Ports: Funafuti, Nukufetau
Merchant marine:
total: 13 ships (1,000 GRT or over) totaling
56,786 GRT/89.128 DWT
ships by type: cargo 6, chemical tanker 4, oil
tanker |, passenger-cargo |, refrigerated
cargo | (1995 est.)
Tuvalu (continued)
Airports:
oladi |
with unpaved runways 1,524 to 2,437 m: |
PUUGS ect y
d
( ommunications
ielephones: | 30 (1983 est.)
lelephone system:
lomestic: radiotelephone communications
between islands
wiuernational N A
Rzdio broadcast stations: AM |. FM 0.
‘nortwave O
Radios: 4.000 61993 est)
‘elevision broadcast stations: 0
Volevisions: NA
Defense
Branches: no regular military forces: Police
i Tee
Nianpower availability:
males ave 15-49° NA
males fa for military service: NA
Defense expenditures: SNA. NA& of GDP
490','b9d40d43b537947d34de55dc5085e247a20974039c5e56c940b38362d76f7d0b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72b9e050c89c17aff9039c6fba07d4ed9e717fbc104e995efe123834b524aac9',1996,'UG','Uganda','transportation',817,'_ Fort Porta
KAMPALA ae
Enteode M208 at, _
“ Bei ,
Masaka. . ,
4
e Se,
3
“Mparara ; |
ad TANZANIA
RWANDA Pi
Railways:
total: |.241 km single track
narrow gauge: 1,241 km 1.000-m gauge
note.. a program to rehabilitate the railroad
is underway (1995)
Highways:
total: 30,320 km
paved: 3,480 km
unpaved: 26.840 km (1987 est.)
Waterways: Lake Victoria, Lake Albert,
Lake Kyoga, Lake George. Lake Edward;
Victoria Nile, Albert Nive
Ports: Entebbe, Jinja, Port Bell
Merchant marine:
total: 3 roll-on/roll-off cargo ships (1.000
GRT or over) totaling 5,091 GRT/2,743
DWT (1995 est.)
Airports:
total: 2\\
with paved runways over 3,047 m: 2
with paved runways 1,524 to 2,437 m: |
with paved runways under 914 m: 7
with unpaved runways 2.438 to 3,047 m: |
with unpaved runways 1,524 to 2,437 m: §
with unpaved runways 914 to 1.523 m:
(1995 est.)','d4b09fb803df9c1803eb572a11465d067883bcc20d54170014d6f72755a82361','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6885272f4c5a7e010ec18f6a82b5fcb4cdf88a901ab458294933d6387e12635',1996,'AE','United Arab Emirates','transportation',836,'Railways: 0 km
Highways:
toial: 3,000 km
paved: 3,000 km
unpaved: 0 km (1993 est.)
Pipelines: crude oil 830 km; natural gas,
including natural gas liquids, 870 km
Ports: ‘Ajman, Al Fujayrah, Das Island,
Khawr Fakkan, Mina’ Jabal “Ali, Mina’
Khalid, Mina’ Rashid, Mina’ Sagr, Mina’
Zayid, Umm al Qaywayn
Merchant marine:
total: 57 ships (1,000 GRT or over) totaling
1,068,980 GRT/1,876,504 DWT
ships by type: bulk 2, cargo 17, chemical
tanker 2, container 7, liquefied gas tanker |,
livestock carrier |, oil tanker 22, refrigerated
cargo 2, roll-on/roll-off cargo 3 (1995 est.)
Airports:
total: 36
with paved runways over 3,047 m: 9
with paved runways 2,438 to 3,047 m: 3
with paved runways 1,524 to 2,437 m: 2
with paved runways 914 to 1,523 m: 3
with paved runways unde: 914 m: 10
with unpaved runways 1,524 to 2,437 m: 2
with unpaved runways 914 to 1,523 m: 7
(1995 est.)
Heliports: 2 (1995 est.)
Railways:
total: 17,561 km
broad gauge’ 434 km 1.600-m gauge (''90
km double wack); note—all |.600-m gauge
track, of which 357 km is in common camer
use, 1s in Northern Ireland
standard gauge: 16.892 km 1.435-m gauge
(4.928 km electrified: 12.591 km double or
multiple track); note—16,532 km of 1.435-m
routes are in common carrer service: the
remaining 360 km are operated by a total of
40 tourst or other private companies
narrow gauge: 235 km 0.260-m, 0.31 1-m.,
0.381-m. 0.600-m, 0.616-m, 0.686-m. 0.760-
m, 0.762-m. 0.800-m, 0.825-m._ 0.914-m and
1.067-m gauges: note—these short. narrow-
gage lines are operated by a total of 25
tourist and other private firms (1995)
Highways:
total: 386.243 km (1993 est.)
paved: NA km (including 3.237 km of
expressways in Great Britain)
unpaved: NA km
Waterways: 3.200 km under British
Waterways Board
Pipelines: crude oil (almost all insignificant)
933 km: petroleum products 2.995 km:
natural gas 12.800 km
Ports: Aberdeen. Belfast. Bristol, Cardiff.
Grangemouth, Hull. Leith. Liverpool.
London, Manchester, Medway. Sullom Voe
Tees. Tyne
Merchant marine:
total: 151 ships (1,000 GRT or over) totaling
3.191.969 GRT/3.861.239 DWT
ships by type: bulk 10, cargo 21. chemical
tanker 2. container 24, liquefied gas tanker 2.
oil tanker 56, passenger 8. passenger-cargo
|, rost-on/roll-off cargo 12, short-sea
passenger 14. specialized tankci | (1995 est.)
Airports:
total: 388
with paved runways over 3,047 m 9
with paved runways 2,438 1: 0.047 m: 29
with paved runways 1,524 to 2,437 m: \\03
with paved runways 914 to 1.523 m: 59
with paved runways under 914 m: 166
with unpaved runways 914 to 1,523 m: 22
(1995 est.)
Heliports: 10 (1995 est.)
543
UDEAC
Union Douaniere et Economique de | Afrique Centrale; see
Central African Customs and Economic Union (UDEAC)
UHF uitra-high-frequency
UK United Kingdom
UN United Nahons
UNAMIR Unitedt Nations Assistance Misston for Rwanda
UNAVEM Ill United Nations Angola Verification Mission III
UNCRO United Nations Confidence Restoration Operation in Croatia
UNCTAD United Nations Conference on Trade and Development
UNDOF United Nations Disengagement Observer Force
UNDP United Nations Development Program
UNEP United Nations Environment Program
UNESCO United Nations Educational, Scientific, and Cultural
Orgamzation
UNFICYP United Nations Force in Cyprus
UNFPA United Nations Fund for Population Activities, see UN
Population Fund (UNFPA)
UNHCR United Nations Office of the High Commissioner for Refugees
UNICEF United Nations Children’s Fund
UNIDO United Nations Industral Development Organization
UNIFIL United Nations Interim Force in Lebanon
UNIKOM United Nations Irag-Kuwait Observation Mission
UNITAR United Nations Institute for Training and Research
UNMIH United Nations Mission in Haiti
UNMOGIP United Nations Military Observer Group in India and Pakistan
UNMOT United Nations Mission of Observers m Tajikistan
UNOMIG United Nations Observer Mission in Georgia
UNOMIL United Nations Observe; Mission in Liberia
UNOMOZ United Nations Operation in Mozambique
UNOMUR United Nations Observer Mission Uganda-Rwanda
UNOSOM Il United Nations Operation in Somalia I
UNPREDEP United Nations Preventive Deployment Force
UNPROFOR United Nations Protection Force
UNRISD United Nations Research Institute for Social evelopment
UNRWA United Nations Relief and Works Agency for Palestine
Refugees in the Near East
UNTAC United Nations Transitional Aw hority in Carbodia
UNTSO United Nations Truce Supervision Organization
UNU United Nations University
UPU Universal Postal Union i
US United States
USSR Union of Soviet Socialist Republics (Soviet Union . used for
information dated before 25 December 1991
USSR/EE Umon of Soviet Socialist Republcs/Eastern Europe
\\ VHF very-high-frequency
“ WADB West African Development Bank
WCL World Confederation of Labor
S44
Convention on Wetlands of International Importance Especially
As Waterfowl Habitat
WEU Western European Union
WFC World Food Council
WFP World Food Program
WFTU World Federation of Trade Unions
Whaling international Convention for the Regulation of Whaling
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
WTO former abbreviation for the World lourssm Organization, now
see WToO
WToO World Tounsm Organization a
WTrO World Trade Organization
YAR Yemen Arab Republic [Yemen (Sanaa) or "North Yemen}. used
for information dated befove 22 May 1990 or CY9!
ZC Zangger Committee
545
Ss¥
Appendix B:
United Nations System
-——-¢
Oe
————@
_——
nD
—
a
|
| ie)
-_——
pa ®
————® .
--——® p
7
-——~*
>—4
Li.
—(j
}—_©
~*
—O
- "
r—--
———_ y
|
5
Appepdix C:
International Organizations and Groups
advanced developing countries another term for those less developed countries (LDCs) with particularly rapid industrial
development, see newly industrializing economies (NIEs)
African, Caribbean, and Pacific members—i70) Angola, Antigua and Barbuda, The Bahamas, Barbados. Belize, Benin.
Countries (ACP) Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African Republic, Chad.
address—Avenue Georges Henri 451, B- Comoros, Congo, Cote d''Ivoire, Djibouti, Dominica, Dominican Republic. Equatorial Guinea
1200 Brussels, Belgium Eritrea, Ethiopia, Fijs, Gabon, The Gambia, Ghana, Grenada. Guinea, Guinea-Bissau. Guyana
telephone—{32| (2) 733 96 00 Haiti, Jamaica, Kenya, Kiribati, Lesotho. Libera. Madagascar. Mal awi, Mali, Mauritania
FAX—[32] (2) 735 55 73 Maunitus, Mozambique. Namubia. Niger, Nigeria. Papua New Guinea. Rwanda, Saint Kitt |
~~ * and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe. Senega!
established—\\| April 1976 Seychelles, Sierra Leone, Solomon Islands, Somalia, Sudan. Sunname. Swaziland. Tanzania
aim—to manage their preferential Togo, Tonga, Trinidad and Tobago, Tuvalu, Uganda. Vanuatu, Western Samoa, Zaire
economic and aid relationship with the EU Zambia, Zimbabwe
African Developmert Pank (AfDB) regional members—{52) Algeria. Angola, Benin, Botswana, Burkina Faso. Burundi
note—also known as Banque Africaine de Cameroon, Cape Verde, Central African Republic. Chad, Comoros, Congo, Cote d''Ivoire
Developpement (BAD) Djibouti, Egypt. Equal nal Guinea, Eritrea, Ethiopia, Gabon. The Gambia. Ghana. Guinea
address—O1 BP 1387, Abidjan 01, Cote Guinea-Bissau, Kenya, Lesotho, Liberia. Libya. Madagascar, Malawi. Mali. Mauritania
Mauritius, Morocco, Mozambique. Namibia, Niger, Nigeria, Rwanda. Sao Tome and Princip:
Senegal, Seychelles, Sierra Leone, Somalia, Sudan, Swaziland, Tanzania, Togo, Tunisia
Uganda, Zaire, Zambia, Zimbabwe
d''Ivoire
‘elephone—{225| 20 44 44
FAX—|225] 21 77 53, 20 49 O01, 20 49 nonregional members— 25) Argentina, Austna, Belgium. Brazil, Canada, China, Denmark
0 Finland, France. Germany. India. Italy. Japan, South Korea, Kuwait, Netherlands. Norway
established—4 August 1963 Portugal. Saudi Arabia, Spain. Sweden. Switzerland. UAE. UK. US
aim—to promote economic and social
development
Agence de Cooperation Culturelle et see Agency for Cultural and [echnical Cooperation (ACCT)
Technique (ACCT)
Agency for Cultural and Technical members— 37) Beigium, Benin, Bulgaria, Burkina Faso, Burunds, Cambodia, Cameroor
Cooperation (ACCT) Canada. Central African Republic. Chad. Comoros, Congo, Cote d''Ivoire, Djibouti, Donut
rate acronym from Agence de Equatonal Guinea France, Gabon, Guinea, Haiti, Laos, Lebanon. Luxembourg Madaga
Cooperation Culturelle et Technique Mali. Mauritius, Monaco, Niger, Romania, Rwanda. Senegal. Seychelles. Togo. Tunisia
. Vanuatu, Vietnam. Zaire
address—\\3 quai Andre-Citroen, F-75015 .
Pans. France associate members— 5) Egypt Guinea-Bissau. Mauritama, Morocco, Saint Luck
telephone 331 4G) participating governments— 2) New Brunswick (Canada). Quebec (Canada)
FAX 33)
establis 2t March 1970
aim—to promote cultural and technical
cooperation among French-speaking
ountric
Note: The Socialist Federal Republic of Yugoslavia (SFRY) has dissolved and ceases to exist. None of the successor states
former Yugoslavia, including Serbia and Montenegro, have been permitted to participate solely on the basis of the membership
the former Yugoslavia in the United Nations General Assembly and Economic and Social Council and their subsidiary bodies and
in various United Nations specialized agencies. The United Nations, however, permits the seat and nameplate of the SFRY to reman
permits the SFRY mission to continue to function, and continues to fly the flag of the former Yugoslavia. For a vaniety of reason
a number of other organizations have not ye? taken action with regard to the membership of the former Yugoslavia. The World
Factbook therefore continues to list Yugoslavia under international organizations where the SFRY seat remains or where no action
has yet been take
Agency for the Prohibition of Nuclear members—4 29) Antigua and Barbuda. Argentina, The Bahamas, Barbados, Belize, Bolivia,
Weapons in Latin America and the Brazil, Chile, Colombia, Costa Rica, Dominica, Dominican Republic, Ecuador, El Salvador,
Caribbean (OPANAL) Grenada, Guatemala, Haiti. Honduras. Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru,
nym from Organismo para la Saint Vincent and the Grenadines, Surname. Trinidad and Tobago, Uruguay, Venezuela
Armas Nucleares en ia
Canbe (OPANAL)
78. Col Polanco, CP
5S DF. Mexice
220) 5064
i4 February 1967
aw lo encourage the peacetul uses of
atomic enerey and promibit nuclear
Weapons
Andean Group (AG) members—4(5) Bolivia, Colombia, Ecuador, Peru, Venezuela
address—</o JUNAC, Paseo de la associate member— 1) Panama
Republica 3895, Casilla 18-1177, Lima 27 observers— 26) Argentina, Australia, Austra, Belgium, Brazil, Canada, Costa Rica, Denmark.
Peru Egypt. Finland, France. Germany. India, Israel, Italy. Japan, Mexico, Netherlands, Paraguay,
telephore Si} (14) 414212 Spain. Sweden. Switzerland, UK. US, Uruguay. Yugoslavia
FAX—{S1] (14) 420911
established—-26 May 1969
eflectinve lf October 1969
am—Ao promote Rarmonw levclopment
through economic imnte:
Arab Bank for Economic Development members——(17 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt. Iraq.
in Africa (ABEDA) Jordan. Kuwait, Lebanon, Libya. Maurittama, Morocco, Oman, Qatar, Saudi Arabia, Sudan,
note Iso known as Banque Arabe de Syna. Tunisia, UAE. Palestine Liberation Organization, note these are all the members of
Developpement Economique en Afnque the Arab League excluding Comoros, Dybouti, Somalia. and Yemen
BADEA
Say de! Rahman EI Mahdi
PQ) Box 2640. Khartoum. Sudan
4h > dye ,4JUK
\\rab Cooperation Council (AC , wal Yemen
, ‘De te.
Arab Fund for tLconomic and Social member (20 plus the Palestine Liberation Orgamzatwn) Algena. Bahrain, Dybouts, Eg
Development (AFESD) ispended trom 1979 to 1988). tray. Jordan. Kuwait, Lebanon, Libya. Mauritania, Mor
Oman. Qatar. Saudi Arabia. Somalia. Sudan, Syna. Tunisia. UAE. Yemen. Palestine
; '') ’ ;
| sheration (Weanmsatwr
Arab League (AL)
note—also known as League of Arab
States (LAS)
address—Midan Attahrir, Tahrir Square,
P.O. Box 11642, Cairo, Egypt
telepho:.e
FAX—{20} (2) 740 331
established—22 March 1945
aim—Ac promote economic, social,
politicai, and military cooperation
{20} (2) 750 S11
members—{2\\ plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros,
Djibouti, Egypt, Irag, Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar,
Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
Arab Maghreb Unien (AMU)
address-—-27 avenue Okba Agdal, Rabat,','3fba01724c5d6e284c5cd08e76e3ff57b7241e599e0b0fa8587e5538d06ec83d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09262026f222389c10d988d43918669c56f52577bffc6e71b6e6a7efeba53a82',1996,'PR','Puerto Rico','transportation',845,'Railways:
total: 240,000 km mainline routes
(nongovernment owned)
standard gauge: 240,000 km 1.435-m gauge
(1989)
Highways:
total: 6.284.488 km
paved: 5,574,341 km (in 1991, included
85.267 km of expressways)
unpaved: 710,147 km (1993 est.)
Waterways: 41.009 km of navigable inland
channels, exclusive of the Great Lakes
Pipelines: petroleum 276,000 km: natural
gas 331,000 km (1991)
Caarleston, Chicago, Duluth. Hampton
Roads, Honolulu, Houston, Jacksonville, Los
Angeles, New Orleans, New York.
Philadelphia, Port Canaveral, Portland
(Oregon), Prudhoe Bay. San Francisco.
Savannah, Seattle, Tampa. Toledo
Merchant marine:
total: 322 ships (1,000 GRT or over) totaling
10.716.000 GRT/15,259.000 DWT
ships by type: bulk 21. cargo 20, chemical
tanker 17, intermodal 125. liquefied gas
tanker 14, passenger-cargo 2, tanker 110,
tanker tug-barge 13
note: in addition, there are 190 government-
owned vessels (1995 est.)
Airports:
total: 13,387
with paved runways over 3,047 m: 179
with paved runways 2.438 to 3,047 m: 201
with paved runways 1,524 to 2,437 m: 1,204
with paved runways 914 to 1,523 m: 2.361
with paved runways under 914 m: 7.720
with unpaved runways over 3,047 m: |
with unpaved runways 2,438 to 3,047 m: 7
with unpaved runways 1,524 to 2.437 m: 151
with unpaved runways 914 to 1.523 m: 1563
(1995 est.)
Heliports: 63 (1995 est)','5aa96e18a4a7af7c3eaf002fd4f7413f12c4c9f98d89d48402071345372427bd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aef60a86c534078a51a9c581da30bb15653709ea8915cce35636315fa91f51ab',1996,'UY','Uruguay','transportation',848,'Railways:
total: 2,070 km (461 km closed; additional
460 km only partially operational)
standard gauge: 2.070 km 1.435-m gauge
Highways:
total: 49,600 km
paved: 6,656 km
unpaved. 42,944 km (1988 est.)
Waterways: 1,600 km: used by coastal and
shallow-draft river craft
Ports: Fray Bentos, Montevideo, Nueva
Palmira, Paysandu, Punta del Este
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling
71,405 GRT/110.939 DWT
ships by type: cargo 1, container 1, oil tanker
1 (1995 est.)
Airports:
total: 66
with paved runways 2,438 to 3,047 m: |
with paved runways 1,524 to 2,437 m: 5
with paved runways 914 to 1,523 m: 8
with paved runways under 914 m: 36
with unpaved runways 1,524 to 2,437 m: 2
with unpaved runways 914 to 1,523 m: 14
(1995 est.)
guests—(22) Australia, Austria, Bosaia and Herzegovina, Bulgaria, Canada, Dominican
Republic, Finland, Germany, Greece, Hungary, Italy, Netherlands, NZ, Norway, Poland,
Portugal, Romania, San Marino, Slovenia, Spain, Sweden, Switzerland
Nordic Council (NC)
address—Tyrgatan 7, Box 19506, S-104
32 Stockholm, Sweden
telephone—{46] (8) 453 47 00
FAX—|4>] (8) 411 75 36
established—\\6 March 1952
effective—1\\2 February 1953
aim—Ao0 promote regional economic,
cultural, and environmental cooperation
members—{5) Denmark (including Faroe Islands and Greenland), Finland (including Aland
Islands), Iceland, Norway, Sweden
observers— 3) the Sami (Lapp) local parliaments of Finland, Norway, and Sweden
Nordic Investment Bank (NIB)
address—Fabiansgatan 34, PB 249 SF-
00171 Helsinki, Finland
telephone—|358| (0) 18001
FAX—{358] (0) 1800309
established—4 Decemiber 1975
effective—| June 1976
aim—1to promote economic cooperation and
development
members—(5) Denmark (including Faroe Islands and Greenland), Finland (including Aiand
Islands), Iceland, Norway, Sweden
North
members—a popular term for the rich industrialized countries generally located in the
northern portion of the Northern Hemisphere; the counterpart of the South; see developed
countries (DCs)
North Atlantic Cooperation Council
(NACC)
note—an extension of NATO
addvess—clo NATO, B-1110 Brussels,','9334820961f29d8623959dcf09616303871c3a12d414dcfde20d541a5ce76e6f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f053871ecf23f78402bb80c43d0e07b476a377cc14660409b28513a8afddb89d',1996,'UZ','Uzbekistan','transportation',856,'Railways:
total: 3.460 km in common carrier service:
does not include industrial lines
broad gauge: 3,460 km 1.520-m gauge
(1990)
Highways:
total: 78,400 km
paved: NA km
unpaved: NA km (1990 est.)
Pipelines: crude oil 250 km: petroleum
products 40 km; natural gas 810 km (1992)
Ports: Termiz
Airports:
total: 261
with paved runways over 3,047 m: 6
with paved runways 2,438 to 3,047 m: 14
with paved runways 1,524 to 2,437 m: 2
with paved runways 914 to 1,523 m: 8
with paved runways under 914 m: 5
with unpaved runways 2,438 to 3,047 m: 2
with unpaved runways 1,524 to 2,437 m: |
with unpaved runways 914 to 1,523 m: 7
with unpaved runways under 914 m: 216
(1994 est.)','e9d3fbbf12498a599309f2497e59492a91f7ddccfde1e6d8c0e06f8fb23ec724','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76fa118bbd7f85c3c0096194b3a1d66246b9ff35b3c850e0b56f67952d35c875',1996,'VU','Vanuatu','transportation',863,'Railways: 0 km
Highways:
total: 1.021 km
paved: 238 km
unpaved: 783 km (1987 est.)
Ports: Forari, Port-Vila, Santo (Espiritu
Santo)
Merchant marine:
total: 112 ships (1,000 GRT or over) totaling
1,587,286 GRT/2,.173,970 DWT
ships by type: bulk 38, cargo 29, chemical
tanker 3, combination bulk 1, container 3,
liquefied gas tanker 5, livestock carrier 1, oil
tanker 6, reingerated cargo 16, vehicle
carrier 10
note: a flag of convenience registry; includes
ships from 20 countries among which are
Japan 37, US 19, Netheriands 10, Greece 6.
Hong Kong 6, China 4, Canada 4, UAE 3.
Rus‘ta 2, and Australia 2 (1995 est.)
Airports:
total: 3}
with paved runways 2,438 to 3,047 m: |
with paved runways 1,524 to 2,437 m: |
with pavec runways under 914 m: 17
vith unpaved runways 1,524 to 2,437 m: |
with unpaved runways 914 to 1,523 m: 11
(1995 est.)
International Finance Corporation (IFC)
address—\\818 H Street NW. Washington,
DC 20433. USA
telephone—{\\| (202) 477 1234
FAX—{1} (202) 477 6391
established—25 May 1955
eflective—220 July 1956
aim—A0 support private enterprise in
international economic development, a UN
specialized agency and IBRD affiliate
members— 165) Atghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina.
Armenia, Australia, Austria, The Bahamas, Bangladesh, Barbados, Belarus. Belgium. Belize.
Benin. Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cameroon.
Canada, Cape Verde. Central African Republic, Chile, China, Colombia, Comoros, Congo,
Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic. Denmark. Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt. El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji.
Finland. France, Gabon, The Gambia, Georgia, Germany. Ghana. Greece. Grenada.
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary. Iceland, India.
Indonesia, Iran, Iraq. Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakstan, Kenya, Kiribati.
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania.
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia.
Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Mongolia, Morocco. Mozambique. Namibia, Nepal. Netherlands, NZ.
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay.
Peru, Philippines, Poland, Portugal. Romania, Russia, Rwanda, Saint Lucia. Saudi Arabia.
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria. Tajikistan,
Tanzania, Thailand, Togo, Tonga. Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Western Samoa, Yemen.
Zaire, Zambia, Zimbabwe
International Pund for Agricultural
Deveiopment (IFAD)
address—Via del Serafico 107, 1-00142
Rome, Italy
telephone—{ 39) 14) 54591
FAX—{39] (5) 5043463
esiablisked—NA Novembe: 1974
aim—to promote agricultural development:
a UN specialized agency
members—i 15%)
Category I-21 industrialized aid contributors) Australia. Austna. Belgrum. Canada
Denmark, Finland. France. Germany. Greece. Ireland. Italy. Japan. Luxembourg. Netherlands
NZ. Norway. Spain. Sweden, Switzerland. UK. US
Category li—{\\|2 petrcleum-exporting aid coninbutors) Algena. Gabon. ladomesi. Iran. irag
Kuwait, Libya. Nigeria. Qatar. Saudi Arabia. UAE. Venezuela
Category 111-4125 aid recipients) Afghanistan, Albania. Angola. Antigua and Barbuda
Argentina, Armenia, Azerbaijan, Bangladesh. Barbados. Belize. Benin. Bhutan. Bolivia
Bosnia and Herzegovina. Bctswana, Brazil. Burkina Faso. Burma. Burund: Cambodia
Cameroon, Cape Verde. Central African Republic. Chad. Chile. China. Colombia. Comoros
Congo, Cook Islands, Costa Rica, Cote d Ivowe. Croatia, Cuba, Cyprus. Dybouts:. Domumeca
Dominican Republic, Ecuador, Egypt. El Salvador. Equatonal Guinea. Entrea. Ethopia. Fips
The Gambia, Georgia, Ghana, Grenada, Guatemala. Guinea. Guinea-Bissau. Guyana. Haiti
Honduras, India, Israel, Jamaica, Jordan, Kenya, North Korea. South Korea. Kyrgysstan
Laos, Lebanon, Lesotho, Liberia, The Former Yugoslav Republic of Macedonia. Madagascar
Malawi. Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius. Mexico. Mongolia
Morocco, Mozambique, Namubia, Nepal, Nicaragua. Niger. Oman. Pakistan. Panama. Papua
New Guinea, Paraguay. Peru, Philippines, Portugal. Romania, Rwanda, Samm Kitis and Nevis.
Saint Lucia, Saint Vincent and the Grenadines. Sao Tome and Principe. Senegul. Seychelles.
Sierra Leone, Solomon Islands. Somalia, Sri Lanka, Sudan. Suriname. Swaziland. Syria.
Tajikistan, Tanzania, Thailand, Togo. Tonga. Trinidad and Tobago. Tunisia. Turkey, Uganda
Uruguay. Vietnam, Western Samoa, Yemen. Yugoslavia (suspended), Zaire. Zambia.','07937746478143413992cab968452152371ada5585069aef748d1891c7f2beda','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fea25bda12f6dd2016602346e7dc06998d00f9c57255443c88e6f7a6b720308c',1996,'US','United States','transportation',867,'Railways: 0 km
Highways:
total: 856 km
paved: NA km
unpaved: NA km
Ports: Charlotte Amalie, Christiansted, Cruz
Bay. Port Alucroix
Merchant marine: none
Airports:
total: 2
with paved runways 1,524 to 2.437 m: 2
note: international airports on Saint Thomas
and Saint Croix (1995 est.)
Railways: 0 km
Ports: none: two offshore anchorages for
large ships
Merchant marine: none
Airports:
total: |
with paved runways 2,438 to 3,047 m: \\
(1995 est.)
Transportation note: formerly <n important
commercial aviation base, now used by US
military, some commercial cargo p''anes, as
well as the US Army Space and Strategic
Defense Command for missile launches','7146d061abc3d29b0240f9f118587734b3c1a995c758962327af2d08b2ba0e61','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c1887d57593ef333b09ceb206a86a24cb018c8188d61d778122aad0477f3ac7',1996,'MR','Mauritania','transportation',877,'Railways: 0 km
Highways:
total: 6,200 km
paved: 0 km
unpaved: 6,200 km
Ports: Ad Dakhla, Cabo Bojador, El Aaiun
Airports:
total: 12
with paved runways 2,438 to 3,047 m: 3
with paved runways under 914 m: 3
with unpaved runways 1,524 to 2,437 m: \\
with unpaved runways 914 to 1,523 m: 5
(1995 est.)
Heliports: | (1995 est.)','6cc9abed46e32b472b5ae8901e861b7a6114b775f58353118ce86f0f9b841170','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f75c269854d2b97998cce442c95b46269b5eca5559ebd57b4c86a543098dcffa',1996,'YE','Yemen','transportation',883,'Railways: 0 km
Highways:
total: 51,492 km
paved: 4.331 km
unpaved: 46.561 km (1992 est.)
Pipelines: crude oi! 644 km. petroleum
products 32 km
Ports: Aden. Al Hudaydah, Al Mukalla,
Mocha, Nishtun
Merchint marine:
total: 3 stups (1.000 GRT or over) totaling
12,089 GRT/18.563 DWT
sips by type: cargo |, oil tanker 2 (1995
est)
Airports:
total \\]
with paved runways over 3.047 m: 2
with paved runways 2.438 to 3,047 m: 6
with paved runways 1.524 to 2.437 m1
with paved runways under 914 m: 3
with unpaved runways over 3,047 m: 2
with unpaved runways 2,438 to 3,047 m: 8
with unpaved runways 1,524 to 2,437 m: 9
with unpaved runways 914 to 1,523 m: 10
(1995 est.)
576
:
s
;
PT rene eT
less developed countries (LDCs)
the bottom group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe
(former USSR/EE), and less developed countries (LDCs); mainly countries and dependent
areas with low levels of output, living standards, and technology; per capita GDPs are
generally below $5,000 and often less than $1,500; however, the group also includes a
number of countries with high per capita incomes, areas of advanced technology, and rapid
rates of growth; includes the advanced developing countries, developing countries, Four
Dragons (Four Tigers), least developed countries (LLDCs), low-income countries, middle-
income countries, newly industrializing ecouomies (NIEs), the South, Third World.
underdeveloped countries, undeveloped countries; ihe 172 LDCs are: Afghanistan, Algeria
American Samoa, Angola, Anguilla, Antigua and Barbuda, Argentina, Aruba, The Bahamas.
Bahrain, Bangladesh, Barbodos, Belize, Benin, Bhutan, Bolivia, Botswana. Brazil, British
Virgin Islands, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde.
Cayi an Islands, Central African Republic. Chad, Chile. China, Christmas Island, Cocos
Islands, Coiombia, Comoros, Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Cuba, Cyprus.
Djibouti, Dominica, Dominican Repubiic, Ecuador, Egypt, El Salvador. Equatonal Guinea.
Eritrea, Ethiopia, Falkland Islands, Fiji, French Guiana, French Polynesia, Gabon, The
Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guatemala.
Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras. Hong Kong, India, Indonesia,
Iran, Iraq, Jamaica, Jersey, Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Laos, Lebanon, Lesotho, Liberia, Libya, Macau, Madagascar, Malawi, Malaysia, Maldives
Mali, Isle of Man, Marshall Islands, Martinique, Mauritania, Mauritius, Mayotte, Federated
States of Micronesia, Mongolia, Montserrat, Morocco, Mozambique. Namibia. Nauru, Nepal.
Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk Island,
Northern Mariana Islands, Oman, Palau, Pakistan, Panama, Papua New Guinea, Paraguay.
Peru, Philippines, Pitcairn Islands, Puerto Rico, Qatar, Reunion, Rwanda, Saint Helena. Saint
Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychetles, Sierra Leone. Singapore. Solomon
Islands, Somalia, Sri Lanka, Sudan, Suriname, Swaziland, Syria. Taiwan, Tanzania, Thailand.
Togo, Tokelau, Tonga, Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu.
UAE, Uganda, Uruguay. Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis and Futuna.
West Bank, Western Sahara, Western Samoa, Yemen, Zaire. Zambia, Zimbabwe
low-income countries
another term for those less developed countries with below-average per capita GDPs: see
less developed countries (LDCs)
London Suppliers Group
see Nuclear Suppliers Group (NSG)
Mercado Comun del Cono Sur
(Mercosur)
see Southern Cone Common Market
middle-income countries
another term for those less developed countries with above-average per capita GDPs; see
less developed countries (LDCs)
Missile Technology Control Regime
(MTCR)
established—16 April 1987
aim—to arrest the proliferation of missiles
(unmanned delivery vehicles of mass
destruction) by controlling the export of
key missiie technologies and equipment
members—(28) Argentina, Australia, Austria, Belgium, Brazil, Canada, Denmark, Finland,
France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, Luxembourg. Netherlands,
NZ, Norway, Portugal, Russia, South Africa, Spain. Sweden, Switzerland, UK. US
Near Abroad
Russian term for the 14 non-Russian successor states of the USSR, in which 25 million
ethnic Russians live and in which Moscow has expressed a strong national security interest
newly industrializing countries (NICs)
former term for the newly industrializing economies; see newly industrializing economies
(NIEs)
newly industrializing economies (NIEs)
that subgroup of the less developed couniries (LDCs) that has experienced particularly rapid
industrialization of their economies: formerly known as the newly industrializing countries
(NICs); also known as advanced developing countries; usually includes the Four Dragons
(Hong Kong, South Korea, Singapore, Taiwan), and Brazil
577
Nonaligned Movement (NAM)
address—c/o Ministry of Foreign Affairs,
Jalan Taman Pejambon 6, Jakarta PUSAT,','ca7fc2fe211cde03cc53cbb7fe4b68d1e5916c824f19cd4cc448124594bb8399','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7c54d270804bb1665fa5043366e27458f7bd3c29ff21dfa6181d8cbee2cc61c',1996,'AO','Angola','transportation',888,'Railways:
total: 5.138% km (1995), note—vseverely
reduced trackage in use because of civil
strife
narrow gauge: 3.987 km 1.067-m gauge
(858 km electrified), 125 km |.000-m gauge:
1,026 km 0.600-m gauge
Highways:
total: 145,000 km
paved: 290 km
unpaved: 144,710 km (1991 est.)
Waterways: 15.000 km including the
Congo, its trbutanes, and unconnected lakes
Pipelines: petroleum products 390 km
Ports: Banana, Boma, Bukavu, Bumba.
Goma. Kalemie, Kindu, Kinshasa. Kisangani.
Matadi, Mbandaka
Merchant marine: none
Airports:
total: 217
with paved runways over 3.047 m: 4
with paved runways 2,438 to 3,047 m: 3
with paved runways 1,524 to 2,437 m: 1S
with paved runways 914 to 1,523 m: 2
with paved runways under 914 m: &2
with urpaved runways 1,524 to 2.437 m: 17
with unpaved runways 914 to 1,523 m: 94
(1995S est.)','30ca864cb70f8260d6d593aae89ac20c3b9f514d0b1761cf28be7cd06ec4424f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8230e5ceacbf8aa2119eca933b742f679c93ff60d109117a6c8e19866882228',1996,'CN','China','transportation',893,'Railways:
total: 4,600 km, note—1,075 km in common
carrier service and about 3,525 km is
dedicated to industrial use
narrow gauge: 4,600 km 1.067-m
Highways:
total: 19,860 km
paved: 17,119 km (including 382 km of
expressways)
unpaved: 2.741 km (1990 est.)
Pipelines: petroleum products 615 km:
natural gas 97 km
Ports: Chi-lung (Keelung), Hua-lien, Kao-
hsiung, Su-ao, T’ai-chung
Merchant marine:
total: 198 ships (1.000 GRT or over) totaling
5.812.534 GRT/8.885,092 DWT
ships by type: bulk 50, cargo 29,
combination bulk 3, combination ore/oil 1,
container 83, oil tanker 19, refrigerated cargo
11, roll-on/roll-off cargo 2 (1995 est.)
Airports:
total: 38
with paved runways over 3,047 m: 8
with paved runways 2,438 to 3,047 m: 12
with paved runways 1,524 to 2,437 m: 4
with paved runways 914 to 1,523 m: 6
with paved runways under 914 m: 7
with unpaved runways 1,524 to 2,437 m: |
(1995 est.)
Heliports: | (1995 est.)
Com:nunications
Telephones: 10,253,773 (1993 est.)
Telephone system: best developed system in
Asia outside of Japan
domestic: extensive microwave radio relay
trunk system on east and west coasts
international: satellite earth stations—2
Intelsat (1 Pacific Ocean and | Indian
Ocean); submarine cables to Japan
(Okinawa), Philippines, Guam, Singapore,
Hong Kong, Indonesia, Australia, Middle
East, and Western Europe
Radio broadcast stations: AM 91. FM 23.
shortwave 0
Radios: 8.62 million
Television broadcast stations: |5 (repeaters
13)
Televisions: 6.66 million (1993 est.)
Defense
Branches: Army, Navy (includes Marines),
Air Force, Coastal Patrol and Defense
Command, Armed Forces Reserve
Command, Combined Service Forces
Manpower availability:
males age 15-49; 6,278,159
males fit for military service: 4.849.057
males reach military age (19) annually:
204,313 (1996 est.)
Defense expenditures: exciiange rate
conversion—$11.5 billion, 3.6% of GDv
(FY96/97)
5H
Appendix A:
Abbreviations
ABEDA Arab Bank for Economic Development in Africa
ACC Arab Cooperation Council
ACCT Agence de Cooperation Culturelle et Technique: see Agency
for Cultural and Technical Cooperation
ACP African, Caribbean, and Pacific Countnes
AfDB Afncan Development Bank
AFESD Arab Fund for Economic and Social Development
AG Andean Group
Air Pollution
Convention on Long-Range Transboundary Air Pollution
Air Pollution—Nitrogen
Oxides
Protocol to the 1979 Convention on Long-Range Transboundary
Air Pollution Concerning the Control of Emissions of Nitrogen
Oxides or Their Transboundary Fluxes
Air Pollution—-Sulphur 85
Protocol to the 1979 Convention on Long-Ranze Transboundary
Air Pollution on the Reduction of Sulphur Emissions or Their
Transboundary Fluxes by at Least 30%
A Pollution—Sulphur 94
Protocol to the 1979 Convention on Long-Range Transboundary
Air Pollution on Further Reduction of Sulphur Emissions
A‘r Pollution— Volatile
Organic Compounds
Protocol to the 1979 Convention on Long-Range Transboundary
Air Pollution Concerning the Control of Emissions of Volatile
Organic Compounds or Their Transboundary Fluxes
AL Arab League
ALADI Asociacion Latinoamericana de Integracion: see Latin American
Integration Association (LAIA)
AMI Arab Monetary Fund
AMU Arab Maghreb Unien
Antarctie-—Environmental
Protocol
Protocol on Esvironmental ! tection to the Antarctic Treaty
ANZUS Australia-New Zealand United States Security Treaty
APEC Asia Pacific Economic Cooperation
Arabsat Arab Satellite Communications Organization
AsDB Asian Development Bank
ASEAN Association of Southeast Asian Nations
Autodin Automatic Digital Network
BAD Banque Africaine de Developpement; see African Development
Bank (AfDB)
BADEA Banque Arabe de Developpement Economique en Afrique: see
Arab Bank for Economic Development in Africa (ABEDA)
BCIE Banco Centroamericano de Integracion Economico; see Central
American Bank for Economic Integration (BCIE)
BDEAC Banque de Developpment des Etats de | Afrique Centrale; see
Central African States Development Bank (BDEAC)
Benelux Benelux Economic Union
BID Banco Interamericano de Desarrollo; see Inter-American
Development Bank (IADB)
Biodiversity Convention on Biological Diversity
BIS
Bank for International Settlements
BOAD Banque Ouest—Afnicaine de Developpement; see West Afnican
Development Bank (WADB)
BSEC Black Sea Economic Cooperation Zone
Cc Cc Commonwealth
CACM Central American Common Market
CAEU Council of Arab Economic Unity
Caricom Caribbean Community and Common Market
CB citizen''s band mobile radio communications
CBSS Council of the Baltic Sea States
cce Customs Cooperation Council
CDB Caribbean Development Bank
CE Council of Europe
CEAO Communaute Economique de | Afnque de Quest: see West
Afncan Econoinic Community (CEAO)
CEEAC Communaute Economique des Etats de | Afrique Centrale: see
Economic Community of Central African States (CEEAC)
CEI Central European Initiative
CEMA Council for Mutual Economic Assistance: also known as
CMEA or Comecon
CEPGL Communaute Economique des Pays des Grands Lacs; see
Economic Community of the Great Lakes Countries (CEPGL)
CERN Conseil Europeen pour la Recherche Nucleaire: see European
Organization for Nuclear Research (CERN)
CG Contadora Group
Cf cost, surance, and freight
CIS Commonwealth of Independent States
CITES see Endangered Species
Climate Change United Nations Framework Convention on Climate Change
CMEA Council for Mutual Economic Assistance (CEMA), also known
as Comecon
COCOM Coordinating Committee on Export Controls
Comecon Council for Mutual Economic Assistance (CEMA), also known
as CMEA
Comsat Communications Satellite Corporation
CP Colombo Plan
CSCE Conference on Security and Cooperation in Europe; see
Organization on Security and Cooperation in Europe (OSCE)
CY calendar year
D DC developed country
Desertification United Nations Convention to Combat Desertification in Those
Countnes Experiencing Serious Drought and/or Desertification.
Particularly in Africa ee
DSN Defense Switched Network
DWT deadweight ton
E EADB East African Development Bank
EBRD European Bank for Reconstruction and Development
EC European Community; see Furopean Union (EU)
ECA Economic Commission for Africa _
ECAFE Economic Commission for Asia and the Far East. see Economic
and Social Commission for Asta and the Pacific (ESCAP)
ECE Economic Commission for Europe
539
ECLA
Economic Commission for Latin America; see Economic
Commission for Latin America and the Caribbean (BCLAC)
ECLAC Economic Commission for Latin America and the Caribbean
ECO Economic Cooperation Organization
ECOSOC Economic and Social Council
ECOWAS Economic Community of West African States
ECSC — Coal and Steel Community, see European Union
{ )
ECV A Economic Commission for Western Asia; see Economic and
Social Commission for Western Asia (ESCWA)
EEC European Economic Community; see European Union (EU)
EFTA European Free Trade Association
EIB European Investment Bank
Endangered Species
Convention on the International Trade in Endangered Species
of Wild Flora and Fauna (CITES) _
Eniente Council of the Entente
Environmental Convention on the Prohibition of Military or Any Other Hostile
Modification Use of Environmental Modification Techniques _
ESA European Space Agency
ESCAP Economic and Social Commission for Asia and the Pacific
ESCWA Economic and Social Commission for Western Asia
est estimate
EU European Union
Euratom European Atomic Energy Community; see European
Community (EC)
Eutelsat European Telecommunications Satellite Organization
Ex-Im Export-Import Ban! of the United States
F FAO Food and Agnculture Organization
FAX facsimile
f.o.b. tree on board
FLS Front Line States
FRG Federal Republic of Germany (West Germany), used for
information dated before 3 October 1990 or CY9!
FSU former Soviet Union
FY fiscal year (FY93/94, for example, began in calendar year 1993
and ended m cak “ular year 1994)
FYROM The Former Yugosla, Republic of Macedonia
FZ Franc Zone
G G-2 Group of 2
G-3 Group of 3
G-S Group of 5S
G- Group of 6 (not to be confused with the Big Six)
G.7 Group of 7
G-& Group of 8
G-9 Group of 9
G-10 Group of 10
G-1l Group of 1!
G-15 Group of 15
540
G-19 Group of 19
G-24 Group cf 24
G-§# Group of 30
G-33 Group of 33
G-77 Group of 77
GATT General Agreement on Tanffs and Trade; subsumed by the
World Trade Organization (WTrO) on | January 1995
Gcc Gulf Cooperation Council
GDP gross domestic product
GDR German Democratic Republic (East Germany); used for
information dated before 3 October 1990 or CY9!
GNP gross national product 7
GRT gross register ton
GWP gross world product
Hazardous Wastes
Basel Convention on the Control of Transboundary Movements
of Hazardous Wastes and Their Disposal
HF high-frequency
IADB Inter-American Development Bank
IAEA International Atomic Energy Agency
IBEC International Bank for Economic Cooperation
IBRD International Bank for Reconstruction and Development (World
Bank)
ICAO International Civil Aviation Organization
icc International Chamber of Commerce
ICEM Intergovernmental Committee for European Migration, see
International Organization for Migration (IOM)
ICFTU International Confederation of Free Trade Unions: see World
Confederation of Labor (WCL)
CJ International Court of Justice
ICM Intergovernmental Committee for Migration: see International 7
Organization for Migration (1OM)
ICRC International Committee of the Red Cross
ICRM International Red Cross and Red Crescent Movement
IDA International Development Association
IDB Islamic Development Bank
IEA International Energy Agency
IFAD International Fund for Agricultural Development
IFC International Finance Corporation
IPCTU International Federation of Christian Trade Unions
IFRCS International Federation of Red Cross and Red Crescent
Societies
IGADD Inter-Governmental Authority on Drought and Development
IB International Investment Bank
ILO International Labor Organization
IMCO Intergovernmental Maritime Consultative Organization, see
International Maritime Organization (IMO)
IMF international Monetary Fund _
IMO International Maritime Organization
54]
Inmarsat International Mobile Satellite Organization
Intelsat International Telecommunications Satellite Organization
interpol international Cnmuinal Police Organization
Intersputnik International Organization of Space Communications
10C international Olympic Commitiee
10M Internatonal Organization for Migration _
iSO international Organization for Standardization
ITU International Telecommunication Union _
h kHz kilohertz
km kilometer
kW kilow att
kWh kilowatt hour
i LAES Latin American Economic System
LAIA Latin Amencan Integration Association
LAS League of Arab States; see Arab League (AL)
Law of the Sea United Nations Convention on the Law of the Sea (LOS)
LDC less developed country
LLDC least developed country
Lendon Convention see Marine Dumping
LORCS League of Red Cross and Red Crescent Societies; see
International Federation of Red Cross and Red Crescent
Societies (FRCS) -
LOS see Law of the Sea
M n meter
Marecs Maritime European Communications Satellite
Marine Dumping Convention on the Prevention of Marine Pollution by Dumping
Wastes and Other Matter
Marine Life Conservation Convention on Fishing and Conservation of Living Resources
of the High Seas
MARPOL see Ship Pollution
Mercosur Mercado Comun del Cono Sur, see Southern Cone Common
Market
MHz megahertz
MINURSO United Nations Mission for the Referendum in Western Sahara
MTCR Missile Technology Control Regime
‘N NA not available
NACC North Atlantic Cooperation Council
NAM Neaaligned Movement
NATO North Atlantic Treaty Organization
NC Nordic Council
NEA Nuclear Energy Agency
NEGL negligible
NIB Nordic Investment Bank
Nic newly industrializing country, see newly indu Anializing
economy (NIE)
NIE newly industnalizing economy
nm nautical mile
NMT Nordic Mobile Telephone
NSG Nuclear Suppliers Group
Nuclear Test Ban
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in
Outer Space. and Under Water
NZ New Zealand
OAPEC Organization of Arab Petroleum Exporting Countnes
OAS Organization of Amencan States
OAU Organizaxon of African Unity
ODA official development assistance
OECD Organiza..sn for Economic Cooperation and Development
OECS Organization of Eastern Caribbean States
OIC Organization of the Islamic Conference
ONUMOZ see United Nations Operation in Mozambique (UNOMOZ)
ONUSAL United Nations Observer Mission in El Salvador
OOF other official flows
OPANAL Organismo para la Proscnpcion de las Armas Nucigares en la
America Latina y el Caribe: see Agency for the Prohibition
of Nuclear Weapons in Latin America and the Caribbean
OPEC Orgamzation of Petroleum Exporting Countnes
OSCE Organization on Security and Cooperation in Europe
Ozone Layer Protection
Montreal Protocel on Substances That Deplete the Ozone Layer
PCA Permanent Court of Arbitration |
PDRY People’s Democratic Republic of Yemen | Yemen (Aden) or
South Yemen]: used for information dated before 22 May 1990
or CY9I
PFP Partnership for Peace
Ramsar see Wetlands
RG Rio Group
SAARC South Asian Association for Regional Cooperation
SACU Southern Afnican Customs Union
SADC Southern Afncan Development Communi»
SADCC Southern African Development Coordination Conference. see
Southern African Development Community (SADC)
SELA ©) stema Economico Latinoamericana, see Latin American
Economic System (LAES)
SFRY Socialist Federal Repubiic of Yugeslavia, dissolved 5 December
1991
SHF super-high-frequency
Ship Pollution
Protocol of 1978 Relating to the International Convention for
the Prevention of Pollution From Ships. 1973 (MARPOL)
Spartec. South Pacific Regional Trade and Economic Cooperation
Agreement
SPC South Pacific Commission
SPF South Pacific Forum
sq km square kilometer
sq mi square mile
TAT Trans-Attantic Telephone
Tropical Timber 83
International Tropical Timber Agreement, 1983
Tropical Timber 94
International Tropical Timber Agreement, 1994
UAE','92840256cdbab6209c1ceefa09367bdbc92a033e2124f6a7944d079c8ca0a499','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a786d991bcaf845583efe0f950103c96a86c4fbd95aa3c389738b07728ea7857',1996,'GT','Guatemala','transportation',894,'telephone—{502} (2) 682151
rAX—{502] (2) 681071
established—\\3 December 1960
effective—3 June 1961
aim—A0 promote establishment of a
Central American Common Market
members—{5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
centrally planned economies
a term applied mainly to the traditionally communist states that looked to the former USSR
for leadership, most are now evolving toward more democratic aid market-oriented systems,
also known formerly as the Second World or as the communist countnes; through the 1980s,
this group included Albania, Bulgaria, Cambodia, China, Cuba, Czechoslovakia, GDR,
Hungary, North Korea, Laos, Mongolia, Polard, Romania, USSR, Vietnam, Yugoslavia
Colombe Plan (CP)
address—Colombo Plan Bureau, P.O. Box
596, 12 Melbourne Avenue. Colombo 4,','894a03cb51aab86f9cf15177a222ff5c30926bc9c58c3d6982274c019ba3969b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09627e39ed69b7817b45b2ed4e5c7323aa08ab6ea2fdbbe46e7be166d41ce4a5',1996,'ZM','Zambia','transportation',895,'Group of 24 (G-24)
address—c/o European Commission, DGI,
G-24 Coordination Unit, Rue de la
Science 29, B-1049 Brussels, Belgium
telephone—{32] (2) 299 22 44
FAX—{32] (2) 299 06 02
established—NA January 1972
aim—to promote the interests of
developing countries in Africa, Asia, and
Latin America within the IMF
members—{24) Algeria, Argentina, Brazil, Colombia, Cote d''Ivoire, Egypt, Ethiopia, Gabon,
Ghana, Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru, Philippines, Sri
Lanka, Syria, Trinidad and Tobago, Venezuela, Yugoslavia, Zaire
Group of 3€ (G-30)
address—\\1990 M Street NW, Suite 450,
Washington, DC 20036, USA
telephone—{1} (202) 331 2472
established—NA_ 1979
aim—to discuss and propose solutions to
the world’s economic problems
members—{30) informal group of 30 leading international bankers, economists. financial
experts, and business leaders organized by Johannes Witteveen (former managing director
of the IMF)
Group of 33 (G-33)
established—NA 1987
aim—to promote solutions to international
economic problems
members— 33) leading economists from 13 countries
Group of 77 (G-77)
established—NA October 1967
aim—A0 promote economic cooperation
among developing countries; name persists
in spite of increased membership
members—( 128 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola.
Antigua and Barbuda, Argentina, The Bahamas, Bahrain, Bangiadesh, Barbados, Belize.
Benin, Bhutan, Bolivia, Botswana, Brazil, Brunei, Burkina Faso. Burma, Burundi, Cambodia,
Cameroon, Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Congo,
Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Ethiopia. Fiji, Gabon, The Gambia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq.
Jamaica, Jordan, Kenya, North Korea, South Korea, Kuwait, Laos. Lebanon, Lesotho, Liberia.
Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger, Niveria, Oman.
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Qat uw, Romania, Rwanda.
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines. Sao Tome and Priucipe.
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore. Solomon Islands, Somalia, South
Africa, Sri Lanka, Sudan, Suriaame, Swaziland, Syria, Tanzania, Thailand, Togo. Tonga
Trinidad and Tobago, Tunisia, Uganda, UAE, Uruguay, Vanuatu. Venezuela, Vietnam,
Western Samoa, Yemen, Yugoslavia, Zaire, Zambia, Zimbabwe, Palestine Liberation
Organization
Gulf Cooperation Council (GCC)
note—also known as the Cooperation
Council! for the Arab States of the Gulf
address—P.O. Box 7431. Riyadh 11462','6baf0634d6004e88f03157b27ebcb78bdc4a2fb482673f368a02c8074522202e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc03c2b884a655ea1e8584d6ee87550394b3ef6582c720ce7095655718c2b02a',1996,'SA','Saudi Arabia','transportation',896,'telephone—|966| (1) 4827777
FAX—[966] (1) 4829089
established——-25 May 1981
aim—A0 promote regional cooperation in
economic, social, political, and military
affairs
members—6) Bahrain, Kuwait, Oman. Qatar, Saudi Arabia, UAE
Hexagonal Group
see Central European Initiative (CEI)
high-income countries
another term for the industrialized countries with high per capita GDPs; see developed
countnes (DCs)
industrial countries
another term for the developed countries; see developed countries (DCs)
Inter-American Development Bank
(LADB)
note—also known as Banco Interamericano
de Desarrollo (BID)
address—|1300 New York Avenue NW,
Washington, DC 10577, USA
telephone—{1} (202) 632 1000
FAX—{1} (202) 789 2835
established—8& Apni 1959
effective-—39 December 1959
aim-——t0 promote economic and social
development in Latin America
members—{ 46) Argentina, Austria, The Bahamas, Barbados. Belgium, Belize, Bolivia, Brazil.
Canada, Chile, Colombia, Costa Rica, Croatia, Denmark, Dominican Republic, Ecuador. El
Salvador. Finland, France, Germany, Guatemala. Guyana, Haiti, Honduras, Israel, Italy,
Jamaica, Japan, Mexico, Netherlands. Nicaragua, Norway, Panama, Paraguay, Peru. Portugal,
Slovenia, Spain, Suriname, Sweden, Switzerland. Trinidad and Tobago, UK, US, Uruguay.
Venezuela
Inter-Governmental Authority on
Drought and Development (IGADD)
address—BP 2653. Djibouti, Dyibout
telephone—{253} 354050, 352880
FAX—{ 253] 356994
established—15-16 January 1986
aim—A0 promote cooperation on
drought-related matters
members—( 7} Djibouti, Eritrea, Ethiopia, Kenya, Somalia, Sudan, Uganda
International Atomic Energy Agency
(LAEA)
address—-Wagramerstrasse 5, P.O. Box
100, A-1400 Vienna. Austria
ielephone——\\43) (1) 2360 2045
FAX—j43] (1) 234564
established —26 October 1956
eflectne—29 July 1957
aim—to promote peacetul uses of atomic
energ
members— 122) Afghanistan, Albania, Algeria, Argentina, Armenia, Australia, Austria,
Bangladesh, Belarus, Belgium, Bolivia, Brazil, Bulgaria, Burma, Cambodia, Cameroon,
Canada, Chile, China, Colombia, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia,
Finland, France, Gabon, Germany. Ghana, Greece, Guatemala, Haiti, Holy See. Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakstan,
Kenya, South Korea, Kuwait, Lebanon, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg.
The Former Yugoslav Republic of Macedonia, Madagascar, Malaysia, Mali, Marshall Islands,
Mauritius, Mexico, Monaco, Mongolia, Morocce, Namibia, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal.
Qatar, Romania, Russia, Saudi Arabia, Senegal, Sierra Leone, Singapore. Slovakia, Slovenia,
South Afneca, Spain, Sr Lanka, Sudan, Sweden, Switzerland, Syria, Tanzania, Thailand,
Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Yugoslavia (suspended), Zaire, Zambia, Zimbabwe
International Bank for Economic
Cooperation (IBEC)
was established on 22 October 1963 to promote ecenomic cooperation and development:
members were Bulgaria, Cuba, Czechoslovakia, East Germany. Hungary, Mongolia, Poland,
Romania, USSR, Vietnam: now it is a Russia: bank with a new charter
International Bank for Reconstruction
and Development (IBRD)
note—also known as the World Bank
address—1818 H Street NW, Washington,
DC 20433, USA
telephone—{\\| (202) 477 1234
FAX—{1] (202) 477 63%1
established—22 July 1944
effective—27 December 1945
aim—to provide economic development
loans: a UN specialized agency
members— 179) Afgharistan, Albania, Algeria, Angola, Aniigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbzdos.
Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon. Canada, Cape Verde. Central African Republic.
Chad, Chile, Chins. Colombia, Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus.
Czech Republic, Denmark. Djibouti, Dominica, Dominican Republic, Ecuador, Egypt. El
Salvador, Equatorial Guinea, Eritrea, Estonia. Ethiopia. Fiji, Finland, France. Gabon. The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland. India, Indonesia. Iran. Irag, Ireland. Israel. ltaly.
Jamaica, Japan, Jordan, Kazakstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan. Laos.
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania. Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia Maldives, Mali, Maita, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Mongolia.
Morocco, Mozambique, Namibia, Nepal, Netheriands. NZ. Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea. Paraguay. Peru. Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis. Saint Lucia, Saint Vincent
and the Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal. Seychelles. Sierra Leone.
Singapore, Slovakia, Slovenia, Soicnon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzeriand, Syria, Tajikistan. Tanzania, Thailand.
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey. Turkmenistan, Uganda, Ukraine, UAE.
UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Western Samoa, Yemen. Zaire.
Zambia. Zimbabwe
International Chamber of Commerce
(ICC)
address—38 Cours Albert Ist, F-75008
Paris, France
telephone—{33| (1) 49 53 28 75
FAX—{33] (1) 49 53 29 42
established—NA 1919
aim—to promote free trade and private
enterprise and to represent business
interests at national and international levels
members—{59 national councils) Argentina, Australia, Austria, Belgium, Brazil, Burkina Faso.
Cameroon, Canada, Colombia, Cote d''Ivoire, Cyprus, Denmark, Ecuador. Egypt. Finland.
France, Gabon, Germany, Greece, Iceland, India, Indonesia, Iran, Ireland, Israel. Italy. Japan.
Jordan, South Korea, Kuwait, Lebanon, Luxembourg, Madagascar. Mexico, Morocco,
Netherlands, Nigeria, Norway. Pakistan, Portugal, Saudi Arabia. Senegal. Singapore. South
Africa, Spain, Sri Lanka, Sweden. Switzerland, Syria. Taiwan, Togo, Tunisia, Turkey. UK.
US, Uruguay. Venezuela, Yugoslavia, Zaire
International Civil Aviation Organization
(ICAO)
address—1000 Sherbrooke Street West,
Suite 327, Montreal PQ H3A 2R2. Canada
telephone—(\\i| (514) 285 8219
FAX—{1] (514) 288 4772
established—7 December 1944
effective—4 April 1947
aim—Ao0 promote international cooperation
in civil aviation; a UN specialized agency
memiers-—(183) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda. Argentina.
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados.
Belarus, Belgium. Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil.
Brunei, Bulgaria. Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada. Cape Verde.
Central African Republic, Chad, Chile, China, Colombia, Comoros, Congo, Cook Islands.
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus. Czech Republic, Denmark, Djibouti,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia.
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany. Ghana. Greece.
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary. lccland.
India, Indonesia, Iran, Iraq. Ireland, Israel. Italy, Jamaica, Japan, Jordan, Kazakstan. Kenya.
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos. Latvia, Lebanon, Lesotho.
Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia.
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania.
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco.
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway.
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Lucia, Saint Vincent and the Grenadines. San Marino.
Sao Tome and Principe, Saudi Arabia, Senegal. Seychelles. Sierra Leone. Singapore. Slovakia.
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname.
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzonta, Thailand. Togo, Tonga. Trinidad
and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK. US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam. Yemen, Zaire, Zambia, Zimbabwe
567
International Committee of the Red
Cross (ICRC)
ide ress-—ICRC, 19 av de la Paix,
CH 1202 Geneva, Switzerland
ele mhone—j41} (22) 734 60 01
FAX—j41} (22) 733 82 80
established—NA 1863
aim—to provide humanitanan aid in
tyne
W aiiitic
members—{ 25 individuals) al] Swiss nationals
International Confederation of Free
Irade Unions (ICFTU)
id/ress—Imternational Trade Union House.
Bd Emile Jacqgmain 155, B-1210 Brussels,
telephone—(966] (2) 6361400
FAX—|966] (2) 6366871
established—15 December 1973
aim—to promote Islamic economic aid and
social development
members—(50 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria.
Azerbaijan, Bahrain, Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros.
Djibouti, Egypt, Gabon, The Gambia, Guinea, Guinea-Bissau, Indonesia, Iran, Iraq. Jordan.
Kazakstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania,
Morocco, Mozambique, Niger, Oman, Pakistan, Qatar, Saudi Arabia, Senegal. Sierra Leone.
Somalia, Sudan, Syria, Tajikistan, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Yemen.
Palestine Liberation Organization
575
Latin American Economic System
(LAES)
note—also known as Sistema Economico
Latinoamericana (SELA)
address—SELA, Avda Francisco de
Miranda. Torre Europa, piso 4, Chacaito,
Apertado de Correos 17035, Caracas
iO10-A. Venezuela
‘elephone—-{58] (2) 905 S111
FAX—{58] (2) 951 6953, 951 7246
established—-17 October 1975
dim—to promote economic and social
development through regional cooperation
members—{27) Argentina, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica,
Cuba, Dominican Republic, Ecuador, El Salvador. Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Mexico, Nicaragua, Panama. Paraguay, Peru, Suriname, Trinidad and
Tobago, Uruguay, Venezuela
Latin American Integration Association
(LATA)
note—also known as Asociacion
Latinoamericana de Integracion (ALADI)
address—Calle Cebollati 1461. Casilla de
Correo 577, 11000 Montevideo, Uruguay
telephone—{598]| (2) 40 11 21, 49 59 15
FAX—j598] (2) 49 06 49
established—\\2 August 1980
eflective—18 March 198]
aim—to promote freer regional trade
members— 11) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Mexico, Paraguay,
Peru, Uruguay. Venezuela
observers— 17) China, Commission of the European Communities, Costa Rica, Cuba,
Dominican Republic, El Salvador, Guatemala, Honduras, Inter-American Development Bank,
Italy, Nicaragua, Organization of American States, Panama, Portugal, Spain, United Nations
Development Program, United Nations Economic Commission for Latin America and the
Caribbean
League of Arab States (LAS)
see Arab League (AL)
League of Red Cross and Red Crescent
Societies (LORCS)
see International Federation of Red Cross anc Red Crescent Societies (IFRCS)
least developed countries (LLDCs)
that subgroup of the less developed countries (LDCs) initially identified by the UN General
Assembly in 1971 as having no significant economic growth, per capita GDPs normally
less than $1,000, and low literacy rates; also known as the undeveloped countries; the 42
LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan, Bo!swana, Burkina Faso, Burma,
Burundi, Cape Verde, Central African Republic. Chad, Comoros, Djibouti, Equatorial Guinea,
Eritrea, Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos, Lesotho, Malawi.
Maldives, Mali, Mauritania, Mozambique, Nepal, Niger, Rwanda, Sao Tome and Principe,
Sierra Leone, Somalia, Sudan, Tanzania. Togo, Tuvalu, Uganda, Vanuatu, Western Samoa,','1f7ce74741e833ca40493635e713ac82627b449cc921097696901adebe7dc38a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9f34dce78e829fb84fc4524ca784ebe0cc59f87c4e1a2a827fb81b05ab7b4b2',1996,'ZW','Zimbabwe','transportation',11,'--------------
Railways:
total: 24.6 km
broad gauge: 9.6 km 1.524-m gauge from Gushgy (Turkmenistan) to
Towraghondi; 15 km 1,524-m gauge from Termiz (Uzbekistan) to
Kheyrabad transshipment point on south bank of Amu Darya
Highways:
total: 21,000 km
paved: 2,800 km
unpaved: 18,200 km (1984 est.)
Waterways: 1,200 km; chiefly Amu Darya, which handles vessels up
to about 500 DWT
Pipelines: petroleum products - Uzbekistan to Bagram and
Turkmenistan to Shindand; natural gas 180 km
Ports: Kheyrabad, Shir Khan
Airports:
total: 35
with paved runways over 3 047 m: 3
with paved runways 2 438 to 3 047 m: 4
with paved runways 1 524 to 2 437 m: 2
with paved runways under 914 m: 7
with unpaved runways 2 438 to 3 047 m: 3
with unpaved runways 1 524 to 2 437 m: 13
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
Heliports: 3 (1995 est.)
--------------
Railways:
total: 670 km
standard gauge: 670 km 1.435-m gauge (1995)
Highways:
total: 18,450 km
paved: 17,450 km
unpaved: 1,000 km (1991 est.)
Waterways: 43 km plus Albanian sections of Lake Scutari, Lake
Ohrid, and Lake Prespa (1990)
Pipelines: crude oil 145 km; petroleum products 55 km; natural gas
64 km (1991)
Ports: Durres, Sarande, Shengjin, Vlore
Merchant marine:
total: 11 cargo ships (1,000 GRT or over) totaling 52,967 GRT/76,887
DWT (1995 est.)
Airports:
total: 11
with paved runways 2 438 to 3 047 m: 3
with paved runways 914 to 1 523 m: 2
with unpaved runways over 3 047 m: 2
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 2 (1994 est.)
--------------
Railways:
total: 4,772 km
standard gauge: 3,616 km 1.435-m gauge (301 km electrified; 215 km
double track)
narrow gauge: 1,156 km 1.055-m gauge
Highways:
total: 95,576 km
paved: 63,080 km (including 400 km of expressways)
unpaved: 32,496 km (1992 est.)
Pipelines: crude oil 6,612 km; petroleum products 298 km; natural
gas 2,948 km
Ports: Algiers, Annaba, Arzew, Bejaia, Beni Saf, Dellys,
Djendjene, Ghazaouet, Jijel, Mostaganem, Oran, Skikda, Tenes
Merchant marine:
total: 77 ships (1,000 GRT or over) totaling 916,701 GRT/1,086,324
DWT
ships by type: bulk 9, cargo 27, chemical tanker 7, liquefied gas
tanker 10, oil tanker 5, roll-on/roll-off cargo 13, short-sea
passenger 5, specialized tanker 1 (1995 est.)
Airports:
total: 119
with paved runways over 3 047 m: 8
with paved runways 2 438 to 3 047 m: 24
with paved runways 1 524 to 2 437 m: 13
with paved runways 914 to 1 523 m: 4
with paved runways under 914 m: 17
with unpaved runways 2 438 to 3 047 m: 3
with unpaved runways 1 524 to 2 437 m: 19
with unpaved runways 914 to 1 523 m: 31 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 350 km
paved: 150 km
unpaved: 200 km
Ports: Aanu''u (new construction), Auasi, Faleosao, Ofu, Pago Pago,
Ta''u
Merchant marine: none
Airports:
total: 3
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 2
note: small airstrips on Fituita and Ofu (1995 est.)
--------------
Railways: 0 km
Highways:
total: 269 km
paved: 198 km
unpaved: 71 km (1991 est.)
Ports: none
Airports: none
--------------
Railways:
total: 2,952 km (1995 est.); note - limited trackage in use because
of landmines still in place from the civil war
narrow gauge: 2,798 km 1.067-m gauge; 154 km 0.600-m gauge
Highways:
total: 72,626 km
paved: 18,157 km
unpaved: 54,469 km (1992 est.)
Waterways: 1,295 km navigable
Pipelines: crude oil 179 km
Ports: Ambriz, Cabinda, Lobito, Luanda, Malogo, Namibe, Porto
Amboim, Soyo
Merchant marine:
total: 12 ships (1,000 GRT or over) totaling 63,776 GRT/99,863 DWT
ships by type: cargo 11, oil tanker 1 (1995 est.)
Airports:
total: 143
with paved runways over 3 047 m: 3
with paved runways 2 438 to 3 047 m: 8
with paved runways 1 524 to 2 437 m: 11
with paved runways 914 to 1 523 m: 4
with paved runways under 914 m: 40
with unpaved runways over 3 047 m: 1
with unpaved runways 2 438 to 3 047 m: 4
with unpaved runways 1 524 to 2 437 m: 24
with unpaved runways 914 to 1 523 m: 48 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 105 km
paved: 65 km
unpaved: 40 km (1992 est.)
Ports: Blowing Point, Road Bay
Merchant marine: none
Airports:
total: 2
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Ports: none; offshore anchorage
Airports: 50 landing facilities at different locations operated by
16 national governments party to the Treaty; one additional air
facility operated by commercial (nongovernmental) tourist
organization; helicopter pads at 25 of these locations; runways at
13 locations are gravel, sea ice, glacier ice, or compacted snow
surface suitable for wheeled fixed-wing aircraft; no paved runways;
12 locations have snow-surface skiways limited to use by
ski-equipped planes - 8 runways/skiways greater than 3,000 m,10
runways/skiways 1,000 to 3,000 m, 3 runways/skiways less than 1,000
m, and 4 of unspecified or variable length; airports generally
subject to severe restrictions and limitations resulting from
extreme seasonal and geographic conditions; airports do not meet
ICAO standards; advance approval from the respective governmental or
non-governmental operating organization required for landing (1995
est.)
--------------
Railways:
total: 77 km
narrow gauge: 64 km 0.760-m gauge; 13 km 0.610-m gauge (used almost
exclusively for handling sugarcane)
Highways:
total: 240 km
paved: NA km
unpaved: NA km
Ports: Saint John''s
Merchant marine:
total: 367 ships (1,000 GRT or over) totaling 1,573,063
GRT/2,147,243 DWT
ships by type: bulk 6, cargo 247, chemical tanker 6, combination
bulk 1, container 72, liquefied gas tanker 2, oil tanker 3,
refrigerated cargo 14, roll-on/roll-off cargo 16
note: a flag of convenience registry: Germany owns 12 ships,
Slovenia 3, Croatia 2, Cyprus 1, and US 1 (1995 est.)
Airports:
total: 3
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 2 (1995 est.)
--------------
Ports: Churchill (Canada), Murmansk (Russia), Prudhoe Bay (US)
Transportation note: sparse network of air, ocean, river, and land
routes; the Northwest Passage (North America) and Northern Sea Route
(Eurasia) are important seasonal waterways
--------------
Railways:
total: 37,910 km
broad gauge: 24,124 km 1.676-m gauge (142 km electrified)
standard gauge: 2,765 km 1.435-m gauge
narrow gauge: 11,021 km 1.000-m gauge (26 km electrified)
Highways:
total: 215,578 km
paved: 61,440 km
unpaved: 154,138 km
Waterways: 11,000 km navigable
Pipelines: crude oil 4,090 km; petroleum products 2,900 km;
natural gas 9,918 km
Ports: Bahia Blanca, Buenos Aires, Comodoro Rivadavia, Concepcion
del Uruguay, La Plata, Mar del Plata, Necochea, Rio Gallegos,
Rosario, Santa Fe, Ushuaia
Merchant marine:
total: 37 ships (1,000 GRT or over) totaling 303,448 GRT/458,864 DWT
ships by type: bulk 1, cargo 11, chemical tanker 1, container 3, oil
tanker 14, railcar carrier 1, refrigerated cargo 5, roll-on/roll-off
cargo 1 (1995 est.)
Airports:
total: 1,253
with paved runways over 3 047 m: 5
with paved runways 2 438 to 3 047 m: 25
with paved runways 1 524 to 2 437 m: 54
with paved runways 914 to 1 523 m: 46
with paved runways under 914 m: 511
with unpaved runways over 3 047 m: 1
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 60
with unpaved runways 914 to 1 523 m: 549 (1995 est.)
--------------
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: Barcadera, Oranjestad, Sint Nicolaas
Merchant marine: none
Airports:
total: 2
with paved runways 2 438 to 3 047 m: 1
with paved runways 914 to 1 523 m: 1
note: government-owned airport east of Oranjestad accepts
transatlantic flights (1995 est.)
--------------
Ports: none; offshore anchorage only
Defense
-------
Defense note: defense is the responsibility of Australia; periodic
visits by the Royal Australian Navy and Royal Australian Air Force
======================================================================
@Atlantic Ocean
--------------
Map
---
Location: 0 00 N, 25 00 W -- body of water between Africa, Europe,
Antarctica, and the Western Hemisphere
--------------
Railways:
total: 38,563 km (2,914 km electrified; 172 km dual gauge)
broad gauge: 6,083 km 1.600-m gauge
standard gauge: 16,752 km 1.435-m gauge
narrow gauge: 15,728 km 1.067-m gauge
Highways:
total: 810,264 km
paved: 283,592 km (including 1,200 km of expressways)
unpaved: 526,672 km (1989 est.)
Waterways: 8,368 km; mainly by small, shallow-draft craft
Pipelines: crude oil 2,500 km; petroleum products 500 km; natural
gas 5,600 km
Ports: Adelaide, Brisbane, Cairns, Darwin, Devonport, Fremantle,
Geelong, Hobart (Tasmania), Launceton (Tasmania), Mackay, Melbourne,
Sydney, Townsville
Merchant marine:
total: 76 ships (1,000 GRT or over) totaling 2,547,869 GRT/3,679,534
DWT
ships by type: bulk 30, cargo 4, chemical tanker 3, combination bulk
1, container 6, liquefied gas tanker 6, oil tanker 18,
roll-on/roll-off cargo 7, short-sea passenger 1 (1995 est.)
Airports:
total: 442
with paved runways over 3 047 m: 9
with paved runways 2 438 to 3 047 m: 13
with paved runways 1 524 to 2 437 m: 106
with paved runways 914 to 1 523 m: 116
with paved runways under 914 m: 30
with unpaved runways 1 524 to 2 437 m: 22
with unpaved runways 914 to 1 523 m: 146 (1995 est.)
--------------
Railways:
total: 5,624 km
standard gauge: 5,269 km 1.435-m gauge (3,263 km electrified)
narrow gauge: 355 km 1.000-m and 0.760-m gauge (86 km electrified)
(1995)
Highways:
total: 108,000 km
paved: 22,000 km (including 1,800 km of expressways)
unpaved: 86,000 km (1992 est.)
Waterways: 446 km
Pipelines: crude oil 554 km; petroleum products 171 km; natural
gas 2,611 km
Ports: Linz, Vienna
Merchant marine:
total: 29 ships (1,000 GRT or over) totaling 88,617 GRT/122,475 DWT
ships by type: bulk 1, cargo 23, combination bulk 2, container 1,
refrigerated cargo 2 (1995 est.)
Airports:
total: 55
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 5
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 41
with unpaved runways 914 to 1 523 m: 4 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways:
total: 2,125 km in common carrier service; does not include
industrial lines
broad gauge: 2,125 km 1.520-m gauge (1,278 km electrified) (1993)
Highways:
total: 36,700 km
paved: 31,800 km (includes graveled)
unpaved: 4,900 km (1990 est.)
Pipelines: crude oil 1,130 km; petroleum products 630 km; natural
gas 1,240 km
Ports: Baku (Baki)
Airports:
total: 69
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 6
with paved runways 1 524 to 2 437 m: 17
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 1
with unpaved runways 914 to 1 523 m: 7
with unpaved runways under 914 m: 33 (1994 est.)','109c25f59476636be31b9b0b33f0c8cdae5ed1a6e299cdb9e100b913802252ec','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f4ca5cbfc3cce3c91978a989f81f9220d1389814596244cb8c489935c29f110',1996,'SA','Saudi Arabia','transportation',19,'--------------
Railways: 0 km
Highways:
total: 2,671 km
paved: 2,011 km
unpaved: 660 km (1991 est.)
Pipelines: crude oil 56 km; petroleum products 16 km; natural gas
32 km
Ports: Manama, Mina'' Salman, Sitrah
Merchant marine:
total: 6 ships (1,000 GRT or over) totaling 117,060 GRT/194,061 DWT
ships by type: bulk 1, cargo 3, chemical tanker 1, oil tanker 1
(1995 est.)
Airports:
total: 3
with paved runways over 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 1 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Ports: none; offshore anchorage only; note - there is one boat
landing area along the middle of the west coast
Airports: 1 abandoned World War II runway of 1,665 m
Transportation note: there is a day beacon near the middle of the
west coast
Defense
-------
Defense note: defense is the responsibility of the US; visited
annually by the US Coast Guard
======================================================================
@Bangladesh
----------
Map
---
Location: 24 00 N, 90 00 E -- Southern Asia, bordering the Bay of
Bengal, between Burma and India
Flag
----
Description: green with a large red disk slightly to the hoist
side of center; green is the traditional color of Islam
--------------
Railways:
total: 2,892 km
broad gauge: 978 km 1.676-m gauge
narrow gauge: 1,914 km 1.000-m gauge (1992)
Highways:
total: 13,627 km
paved: 8,546 km
unpaved: 5,081 km (1992)
Waterways: 5,150-8,046 km navigable waterways (includes
2,575-3,058 km main cargo routes)
Pipelines: natural gas 1,220 km
Ports: Chittagong, Dhaka, Chalna Port (Mongla)
Merchant marine:
total: 37 ships (1,000 GRT or over) totaling 296,503 GRT/423,274 DWT
ships by type: bulk 3, cargo 29, oil tanker 2, refrigerated cargo 3
(1995 est.)
Airports:
total: 15
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 4
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 6 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 1,550 km
paved: 1,550 km
Ports: Bridgetown
Merchant marine:
total: 34 ships (1,000 GRT or over) totaling 183,937 GRT/271,707 DWT
ships by type: bulk 6, cargo 21, combination bulk 3, oil tanker 3,
roll-on/roll-off cargo 1 (1995 est.)
Airports:
total: 1
with paved runways over 3 047 m: 1 (1995 est.)
--------------
Ports: none; offshore anchorage only
Defense
-------
Defense note: defense is the responsibility of France
======================================================================
@Belarus
-------
Map
---
Location: 53 00 N, 28 00 E -- Eastern Europe, east of Poland
Flag
----
Description: red horizontal band (top) and green horizontal band
one-half the width of the red band; a white vertical stripe of white
on the hoist side bears in red the Belarusian national ornament
--------------
Railways:
total: 5,488 km
broad gauge: 5,488 km 1.520-m gauge (873 km electrified) (1993)
Highways:
total: 92,200 km
paved: 61,000 km (including graveled)
unpaved: 31,200 km (1994 est.)
Waterways: NA km; note - Belarus has extensive and widely used
canal and river systems
Pipelines: crude oil 1,470 km; refined products 1,100 km; natural
gas 1,980 km (1992)
Ports: Mazyr
Merchant marine:
note: claims 5% of former Soviet fleet (1995 est.)
Airports:
total: 118
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 18
with paved runways 1 524 to 2 437 m: 5
with paved runways under 914 m: 11
with unpaved runways over 3 047 m: 1
with unpaved runways 2 438 to 3 047 m: 6
with unpaved runways 1 524 to 2 437 m: 4
with unpaved runways 914 to 1 523 m: 9
with unpaved runways under 914 m: 62 (1994 est.)
--------------
Railways:
total: 3,396 km (2,363 km electrified; 2,563 km double track)
standard gauge: 3,396 km 1.435-m gauge (1995)
Highways:
total: 137,876 km
paved: 129,603 km (including 1,667 km of expressways)
unpaved: 8,273 km (1992 est.)
Waterways: 2,043 km (1,528 km in regular commercial use)
Pipelines: crude oil 161 km; petroleum products 1,167 km; natural
gas 3,300 km
Ports: Antwerp, Brugge, Gent, Hasselt, Liege, Mons, Namur,
Oostende, Zeebrugge
Merchant marine:
total: 23 ships (1,000 GRT or over) totaling 64,220 GRT/83,360 DWT
ships by type: bulk 1, cargo 8, chemical tanker 5, liquefied gas
tanker 3, oil tanker 6 (1995 est.)
Airports:
total: 42
with paved runways over 3 047 m: 6
with paved runways 2 438 to 3 047 m: 9
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 21
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 2,560 km
paved: 336 km
unpaved: 2,224 km (1987 est.)
Waterways: 825 km river network used by shallow-draft craft;
seasonally navigable
Ports: Belize City, Big Creek, Corozol, Punta Gorda
Merchant marine:
total: 89 ships (1,000 GRT or over) totaling 311,731 GRT/470,272 DWT
ships by type: bulk 9, cargo 60, container 6, liquefied gas tanker
1, oil tanker 3, refrigerated cargo 4, roll-on/roll-off cargo 4,
specialized tanker 1, vehicle carrier 1 (1995 est.)
Airports:
total: 35
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 25
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 914 to 1 523 m: 8 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 1,191 km
paved: 1,028 km
unpaved: 163 km (1988 est.)
Pipelines: crude oil 235 km; natural gas 400 km
Ports: Doha, Halul Island, Umm Sa''id
Merchant marine:
total: 19 ships (1,000 GRT or over) totaling 467,447 GRT/771,483 DWT
ships by type: combination ore/oil 2, container 3, cargo 11, oil
tanker 3 (1995 est.)
Airports:
total: 3
with paved runways over 3 047 m: 1
with paved runways under 914 m: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
Heliports: 1 (1995 est.)','b3e61fb39d893b1d6d57ec9339ae1828c1cf8bc2b8bb6b2e131ce1f854810feb','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a909accfaefc6f1b1011faaabd820d8758190a5c957415ae743d9b91f7352876',1996,'HK','Hong Kong','transportation',23,'--------------
Railways:
total: 578 km (single track) (1995 est.)
narrow gauge: 578 km 1.000-m gauge
Highways:
total: 6,070 km
paved: 1,214 km
unpaved: 4,856 km (1992 est.)
Waterways: navigable along small sections, important only locally
Ports: Cotonou, Porto-Novo
Merchant marine: none
Airports:
total: 5
with paved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 2 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 208 km
paved: 208 km
unpaved: 0 km (1986 est.)
note: in addition, there are 400 km of paved and unpaved roads that
are privately owned
Ports: Hamilton, Saint George
Merchant marine:
total: 69 ships (1,000 GRT or over) totaling 3,146,693 GRT/5,007,242
DWT
ships by type: bulk 10, cargo 3, container 7, liquefied gas tanker
16, oil tanker 16, refrigerated cargo 10, roll-on/roll-off cargo 4,
short-sea passenger 1, specialized tanker 1, vehicle carrier 1
note: a flag of convenience registry; includes ships from 11
countries among which are UK 17, US 13, Canada 10, Norway 9, Nigeria
4, Sweden 3, Hong Kong 2, Syria 2, Mexico 1, and NZ 1 (1995 est.)
Airports:
total: 1
with paved runways 2 438 to 3 047 m: 1 (1995 est.)','5558faf67cb24535bb12ce2511180d595bc4eaf41dd5cd35d289fd5ed92c63cd','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e070d7a107a8913ee8043c160efc9b34e6195f2c74ee65c0b1745bdc5eaa57e',1996,'IN','India','transportation',35,'--------------
Railways: 0 km
Highways:
total: 1,296 km
paved: 416 km
unpaved: 880 km (1988 est.)
Ports: none
Airports:
total: 2
with paved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km; note - Male has 9.6 km of coral highways within the
city (1988 est.)
Ports: Gan, Male
Merchant marine:
total: 20 ships (1,000 GRT or over) totaling 73,284 GRT/113,669 DWT
ships by type: cargo 17, container 2, oil tanker 1 (1995 est.)
Airports:
total: 2
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1 (1995 est.)
--------------
Railways:
total: 641 km; note - linked to Senegal''s rail system through Kayes
narrow gauge: 641 km 1.000-m gauge (1995)
Highways:
total: 15,610 km
paved: 1,661 km
unpaved: 13,949 km (1987 est.)
Waterways: 1,815 km navigable
Ports: Koulikoro
Airports:
total: 24
with paved runways 2 438 to 3 047 m: 4
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 7
with unpaved runways 1 524 to 2 437 m: 3
with unpaved runways 914 to 1 523 m: 8 (1995 est.)
--------------
Railways:
total: 52 km (27 km electrified)
Highways:
total: 640 km
paved: 320 km
unpaved: 320 km
Ports: Castletown, Douglas, Peel, Ramsey
Merchant marine:
total: 83 ships (1,000 GRT or over) totaling 2,099,888 GRT/3,569,632
DWT
ships by type: bulk 13, cargo 10, chemical tanker 4, container 12,
liquefied gas tanker 8, oil tanker 18, passenger 2, roll-on/roll-off
cargo 13, short-sea passenger 1, vehicle carrier 2
note: a flag of convenience registry; UK owns 10 ships, Switzerland
2, South Africa 2, Denmark 1, and Netherlands 1 (1995 est.)
Airports:
total: 1
with paved runways 1 524 to 2 437 m: 1 (1995 est.)
Flag
----
Description: red with a blue border around the unique shape of two
overlapping right triangles; the smaller, upper triangle bears a
white stylized moon and the larger, lower triangle bears a white
12-pointed sun
--------------
Railways:
total: 101 km; note - all in Terai close to Indian border
narrow gauge: 101 km 0.762-m gauge
Highways:
total: 9,933 km
paved: 3,421 km
unpaved: 6,512 km (1995 est.)
Ports: none
Airports:
total: 43
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 27
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 10 (1995 est.)
--------------
Railways:
total: 2,891 km
standard gauge: 2,891 km 1.435-m gauge; 2857 km are in common
carrier service (1,991 km electrified) and 34 km serve tourists
Highways:
total: 104,831 km
paved: 92,251 km (including 2,118 km of expressways)
unpaved: 12,580 km (1992 est.)
Waterways: 6,340 km, of which 35% is usable by craft of 1,000
metric ton capacity or larger
Pipelines: crude oil 418 km; petroleum products 965 km; natural
gas 10,230 km
Ports: Amsterdam, Delfzijl, Dordrecht, Eemshaven, Groningen,
Haarlem, Ijmuiden, Maastricht, Rotterdam, Terneuzen, Utrecht
Merchant marine:
total: 352 ships (1,000 GRT or over) totaling 2,681,133
GRT/3,379,762 DWT
ships by type: bulk 1, cargo 206, chemical tanker 21, combination
bulk 3, container 34, liquefied gas tanker 13, livestock carrier 1,
multifunction large-load carrier 2, oil tanker 38, railcar carrier
1, refrigerated cargo 16, roll-on/roll-off cargo 11, short-sea
passenger 3, specialized tanker 2
note: many Dutch-owned ships are operating under the registry of
Netherlands Antilles (1995 est.)
Airports:
total: 28
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 8
with paved runways 1 524 to 2 437 m: 6
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 7
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 944 km
paved: 299 km
unpaved: 645 km (1985 est.)
Ports: Kralendijk, Philipsburg, Willemstad
Merchant marine:
total: 119 ships (1,000 GRT or over) totaling 1,141,003
GRT/1,490,958 DWT
ships by type: bulk 1, cargo 38, chemical tanker 7, combination bulk
1, container 2, liquefied gas tanker 4, multifunction large-load
carrier 18, oil tanker 9, passenger 4, refrigerated cargo 27,
roll-on/roll-off cargo 8 (1995 est.)
Airports:
total: 4
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 1 (1995 est.)','87b97a6f8c5e634ce18fdfeb069c7dd60ff5a677601b5e42a9cd36b961387380','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecc519361a0de0eef9e6e44b2d5943c9c168b73567282fd58497f60334ea5d27',1996,'BR','Brazil','transportation',43,'--------------
Railways:
total: 3,691 km (single track)
narrow gauge: 3,652 km 1.000-m gauge; 39 km 0.760-m gauge (13 km
electrified) (1995)
Highways:
total: 46,311 km
paved: 1,940 km (including 27 km of expressways)
unpaved: 44,371 km (1991 est.)
Waterways: 10,000 km of commercially navigable waterways
Pipelines: crude oil 1,800 km; petroleum products 580 km; natural
gas 1,495 km
Ports: none; however, Bolivia has free port privileges in the
maritime ports of Argentina, Brazil, Chile, and Paraguay
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 4,214 GRT/6,390 DWT
(1995 est.)
Airports:
total: 1,017
with paved runways over 3 047 m: 3
with paved runways 2 438 to 3 047 m: 4
with paved runways 1 524 to 2 437 m: 3
with paved runways under 914 m: 750
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 69
with unpaved runways 914 to 1 523 m: 186 (1995 est.)
--------------
Railways:
total: 971 km
standard gauge: 441 km 1.435-m gauge
narrow gauge: 60 km 1.000-m gauge
other: 470 km various gauges (privately owned)
Highways:
total: 21,834 km
paved: 1,778 km
unpaved: 20,056 km (1987 est.)
Waterways: 3,100 km
Ports: Asuncion, Villeta, San Antonio, Encarnacion
Merchant marine:
total: 16 ships (1,000 GRT or over) totaling 21,323 GRT/23,907 DWT
ships by type: cargo 13, oil tanker 2, roll-on/roll-off 1 (1995 est.)
Airports:
total: 739
with paved runways over 3 047 m: 3
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 4
with paved runways under 914 m: 438
with unpaved runways over 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 25
with unpaved runways 914 to 1 523 m: 266 (1995 est.)
--------------
Railways:
total: 2,041 km
standard gauge: 1,726 km 1.435-m gauge
narrow gauge: 315 km 0.914-m gauge (1994)
Highways:
total: 69,942 km
paved: 13,538 km
unpaved: 56,404 km (1987 est.)
Waterways: 8,600 km of navigable tributaries of Amazon system and
208 km of Lago Titicaca
Pipelines: crude oil 800 km; natural gas and natural gas liquids
64 km
Ports: Callao, Chimbote, Ilo, Matarani, Paita, Puerto Maldonado,
Salaverry, San Martin, Talara, Iquitos, Pucallpa, Yurimaguas
note: Iquitos, Pucallpa, and Yurimaguas are all on the upper reaches
of the Amazon and its tributaries
Merchant marine:
total: 9 ships (1,000 GRT or over) totaling 77,584 GRT/144,030 DWT
ships by type: bulk 2, cargo 7 (1995 est.)
Airports:
total: 230
with paved runways over 3 047 m: 5
with paved runways 2 438 to 3 047 m: 15
with paved runways 1 524 to 2 437 m: 12
with paved runways 914 to 1 523 m: 6
with paved runways under 914 m: 96
with unpaved runways over 3 047 m: 1
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 22
with unpaved runways 914 to 1 523 m: 71 (1995 est.)
--------------
Railways:
total: 499 km
narrow gauge: 499 km 1.067-m gauge (1993)
Highways:
total: 160,633 km
paved: 22,489 km
unpaved: 138,144 km (1992 est.)
Waterways: 3,219 km; limited to shallow-draft (less than 1.5 m)
vessels
Pipelines: petroleum products 357 km
Ports: Batangas, Cagayan de Oro, Cebu, Davao, Guimaras Island,
Iligan, Iloilo, Jolo, Legaspi, Manila, Masao, Puerto Princesa, San
Fernando, Subic Bay, Zamboanga
Merchant marine:
total: 535 ships (1,000 GRT or over) totaling 8,033,849
GRT/13,101,188 DWT
ships by type: bulk 230, cargo 126, chemical tanker 3, combination
bulk 11, container 12, liquefied gas tanker 9, livestock carrier 12,
oil tanker 44, passenger 2, passenger-cargo 12, refrigerated cargo
19, roll-on/roll-off cargo 12, short-sea passenger 18, vehicle
carrier 25
note: a flag of convenience registry; Japan owns 22 ships, Hong Kong
4, Switzerland 1, Taiwan 1, Denmark 1, and UK 1 (1995 est.)
Airports:
total: 235
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 7
with paved runways 1 524 to 2 437 m: 25
with paved runways 914 to 1 523 m: 31
with paved runways under 914 m: 104
with unpaved runways 1 524 to 2 437 m: 3
with unpaved runways 914 to 1 523 m: 63 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 6.4 km
paved: 0 km
unpaved: 6.4 km
Ports: Bounty Bay
Merchant marine: none
Airports: none
--------------
Railways:
total: 25,166 km
broad gauge: 656 km 1.520-m gauge
standard gauge: 22,655 km 1.435-m gauge (11,496 km electrified;
8,978 km double track)
narrow gauge: 1,855 km various gauges including 1.000-m, 0.785-m,
0.750-m, and 0.600-m (1995)
Highways:
total: 367,000 km (excluding farm, factory, and forest roads)
paved: 235,247 km (including 257 km of expressways)
unpaved: 131,753 km (1992 est.)
Waterways: 3,997 km navigable rivers and canals (1991)
Pipelines: crude oil 1,986 km; petroleum products 360 km; natural
gas 4,600 km (1992)
Ports: Gdansk, Gdynia, Gliwice, Kolobrzeg, Szczecin, Swinoujscie,
Ustka, Warsaw, Wrocaw
Merchant marine:
total: 131 ships (1,000 GRT or over) totaling 2,093,491
GRT/3,167,660 DWT
ships by type: bulk 73, cargo 36, chemical tanker 4, container 7,
oil tanker 1, passenger 1, roll-on/roll-off cargo 4, short-sea
passenger 5
note: Poland owns an additional 18 ships (1,000 GRT or over)
totaling 179,913 DWT operating under the registries of The Bahamas,
Liberia, Saint Vincent and the Grenadines, Vanuatu, and Cyprus (1995
est.)
Airports:
total: 134
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 30
with paved runways 1 524 to 2 437 m: 27
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 7
with unpaved runways 2 438 to 3 047 m: 5
with unpaved runways 1 524 to 2 437 m: 10
with unpaved runways 914 to 1 523 m: 32
with unpaved runways under 914 m: 18 (1994 est.)
--------------
Railways:
total: 3,068 km
broad gauge: 2,761 km 1.668-m gauge (464 km electrified; 426 km
double track)
narrow gauge: 307 km 1.000-m gauge
note: in 1992, Portugal had 3,588 km of track of which 464 km were
electrified
Highways:
total: 70,176 km (statistics for continental Portugal only)
paved: 60,351 km (including 519 km of expressways)
unpaved: 9,825 km (1992 est.)
Waterways: 820 km navigable; relatively unimportant to national
economy, used by shallow-draft craft limited to 300 metric-ton cargo
capacity
Pipelines: crude oil 22 km; petroleum products 58 km
Ports: Aveiro, Funchal (Madeira Islands), Horta (Azores), Leixoes,
Lisbon, Porto, Ponta Delgada (Azores), Praia da Vitoria (Azores),
Setubal, Viana do Castelo
Merchant marine:
total: 72 ships (1,000 GRT or over) totaling 795,725 GRT/1,418,538
DWT
ships by type: bulk 7, cargo 35, chemical tanker 5, container 5,
liquefied gas tanker 4, oil tanker 12, passenger-cargo 1,
refrigerated cargo 1, roll-on/roll-off cargo 1, short-sea passenger 1
note: Portugal has created a captive register on Madeira for
Portuguese-owned ships; ships on the Madeira Register (MAR) will
have taxation and crewing benefits of a flag of convenience;
Portugal owns an additional 25 ships (1,000 GRT or over) totaling
155,776 DWT operating under the registries of Panama and Malta (1995
est.)
Airports:
total: 67
with paved runways over 3 047 m: 5
with paved runways 2 438 to 3 047 m: 8
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 18
with paved runways under 914 m: 30
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
--------------
Railways:
total: 96 km
narrow gauge: 96 km 1.000-m gauge, rural, narrow-gauge system for
hauling sugarcane; no passenger service
Highways:
total: NA km
paved: 13,762 km (1982 est.)
unpaved: NA km
Ports: Guanica, Guayanilla, Guayama, Playa de Ponce, San Juan
Merchant marine: none
Airports:
total: 23
with paved runways over 3 047 m: 3
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 8
with paved runways under 914 m: 7
with unpaved runways 914 to 1 523 m: 2 (1995 est.)','3256b148711e31a5bef97c1b02a110a67619987949c15fd35ce9a191015c0243','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f53f0dd5b9dca18f7c4c45d3813608d51f4354655784b64f6a3cecbe3823e962',1996,'HR','Croatia','transportation',49,'--------------
Railways:
total: 1,021 km (electrified 795 km)
standard gauge: 1,021 km 1.435-m gauge (1991)
Highways:
total: 21,168 km
paved: 11,436 km
unpaved: 9,732 km (1991 est.)
Waterways: NA km
Pipelines: crude oil 174 km; natural gas 90 km (1992); note -
pipelines now disrupted
Ports: Bosanski Brod
Merchant marine: none
Airports:
total: 24
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 7
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 9 (1995 est.)
--------------
Ports: none; offshore anchorage only
--------------
Railways:
total: 27,418 km (1,750 km electrified)
broad gauge: 5,730 km 1.600-m gauge
standard gauge: 194 km 1.440-m gauge
narrow gauge: 20,958 km 1.000-m gauge; 13 km 0.760-m gauge
dual gauge: 523 km 1.000-m and 1.600-m gauges
Highways:
total: 1,661,850 km
paved: 142,919 km
unpaved: 1,518,931 km (1992 est.)
Waterways: 50,000 km navigable
Pipelines: crude oil 2,000 km; petroleum products 3,804 km;
natural gas 1,095 km
Ports: Belem, Fortaleza, Ilheus, Imbituba, Manaus, Paranagua,
Porto Alegre, Recife, Rio de Janeiro, Rio Grande, Salvador, Santos,
Vitoria
Merchant marine:
total: 207 ships (1,000 GRT or over) totaling 5,108,543
GRT/8,477,760 DWT
ships by type: bulk 48, cargo 29, chemical tanker 11, combination
ore/oil 12, container 14, liquefied gas tanker 11, multifunction
large-load carrier 1, oil tanker 64, passenger-cargo 5, refrigerated
cargo 1, roll-on/roll-off cargo 11 (1995 est.)
Airports:
total: 2,950
with paved runways over 3 047 m: 5
with paved runways 2 438 to 3 047 m: 19
with paved runways 1 524 to 2 437 m: 122
with paved runways 914 to 1 523 m: 295
with paved runways under 914 m: 1,298
with unpaved runways 1 524 to 2 437 m: 66
with unpaved runways 914 to 1 523 m: 1,145 (1995 est.)','86fb0916eb0e52dc956bfac7ab85ba7bca6a9035a26fe005bb69d8245588c44f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('477b44411853f878b7b3c4aca0f27a2ea9bb5c9c004d9e94961aa89c7fde4155',1996,'MU','Mauritius','transportation',56,'--------------
Railways: 0 km
Highways:
total: NA km
paved: short stretch of paved road of NA km between port and
airfield on Diego Garcia
unpaved: NA km
Ports: Diego Garcia
Airports:
total: 1
with paved runways over 3 047 m: 1 (1995 est.)','9f4ce45382fe058028d88345a0e78a3baae64c1ba18f306ffde437b77930cc62','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68e6337afc42e74099d43f45e750e5ddf41822c96f1a73899410a12857566302',1996,'PR','Puerto Rico','transportation',61,'--------------
Railways: 0 km
Highways:
total: 106 km (1983 est.)
paved: NA km
unpaved: NA km
Ports: Road Town
Merchant marine: none (1995 est.)
Airports:
total: 3
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 280 km
paved: 200 km
unpaved: 80 km
Ports: Plymouth
Merchant marine: none
Airports:
total: 1
with paved runways 914 to 1 523 m: 1 (1995 est.)','defc156609b4ddb49c5f4fe3c2b6ab245b0ee40beca7ae53e1282de6acaac300','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52b11751fd14f75df9458345286f41fbb0789145e920bc41e787d9034d657d95',1996,'MY','Malaysia','transportation',69,'--------------
Railways:
total: 13 km private line
narrow gauge: 13 km 0.610-m gauge
Highways:
total: 2,443 km
paved: 1,296 km
unpaved: 1,147 km (1993)
Waterways: 209 km; navigable by craft drawing less than 1.2 m
Pipelines: crude oil 135 km; petroleum products 418 km; natural
gas 920 km
Ports: Bandar Seri Begawan, Kuala Belait, Muara, Seria, Tutong
Merchant marine:
total: 7 liquefied gas tankers (1,000 GRT or over) totaling 348,476
GRT/340,635 DWT (1994 est.)
Airports:
total: 2
with paved runways over 3 047 m: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
Heliports: 3 (1995 est.)
--------------
Railways:
total: 4,292 km
standard gauge: 4,047 km 1.435-m gauge (2,650 km electrified; 917
double track)
other: 245 km 0.760-m gauge (1995)
Highways:
total: 36,932 km
paved: 33,904 km (including 276 km of expressways)
unpaved: 3,028 km (1992 est.)
Waterways: 470 km (1987)
Pipelines: crude oil 193 km; petroleum products 525 km; natural
gas 1,400 km (1992)
Ports: Burgas, Lom, Nesebur, Ruse, Varna, Vidin
Merchant marine:
total: 103 ships (1,000 GRT or over) totaling 1,084,090
GRT/1,596,735 DWT
ships by type: bulk 45, cargo 27, chemical tanker 4, container 2,
oil tanker 13, passenger-cargo 1, railcar carrier 2,
roll-on/roll-off cargo 6, short-sea passenger 2, refrigerated cargo 1
note: Bulgaria owns an additional 7 ships (1,000 GRT or over)
totaling 135,016 DWT operating under the registries of Liberia and
Malta (1995 est.)
Airports:
total: 355
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 17
with paved runways 1 524 to 2 437 m: 10
with paved runways under 914 m: 88
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 10
with unpaved runways under 914 m: 226 (1994 est.)
--------------
Railways:
total: 2,164 km (1995)
narrow gauge: 2,164 km 1.067-m gauge (13 km double track)
note: the total includes 891 km of the Tanzania-Zambia Railway
Authority (TAZARA), which operates 1,860 km of 1.067-m narrow gauge
track between Dar es Salaam and New Kapiri M''poshi where it connects
to the Zambia Railways system; TAZARA is not a part of Zambia
Railways
Highways:
total: 37,359 km
paved: 6,575 km (including 56 km of expressways)
unpaved: 30,784 km (1992 est.)
Waterways: 2,250 km, including Zambezi and Luapula rivers, Lake
Tanganyika
Pipelines: crude oil 1,724 km
Ports: Mpulungu
Airports:
total: 104
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 4
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 35
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 4
with unpaved runways 914 to 1 523 m: 54 (1995 est.)','a63fa57c2536af69d4b0538248780f46270f415620e3bb135392a8078e5be836','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2d24a6652a86e01227db6e27cfc7b4a5cd77bd13a504efd6e4d04c38bbec379',1996,'NE','Niger','transportation',78,'--------------
Railways:
total: 622 km (1995 est.)
narrow gauge: 622 km 1.000-m gauge (517 km Ouagadougou to Cote
d''Ivoire border and 105 km opened in 1993 from Ouagadougou to Kaya)
Highways:
total: 16,400 km
paved: 1,280 km
unpaved: 15,120 km (1987 est.)
Ports: none
Airports:
total: 23
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 8
with unpaved runways 1 524 to 2 437 m: 3
with unpaved runways 914 to 1 523 m: 10 (1995 est.)
--------------
Railways:
total: 3,569 km
narrow gauge: 3,569 km 1.000-m gauge (1995)
Highways:
total: 26,861 km
paved: 3,181 km
unpaved: 23,680 km (1988 est.)
Waterways: 12,800 km; 3,200 km navigable by large commercial
vessels
Pipelines: crude oil 1,343 km; natural gas 330 km
Ports: Bassein, Bhamo, Chauk, Mandalay, Moulmein, Myitkyina,
Rangoon, Akyab (Sittwe), Tavoy
Merchant marine:
total: 40 ships (1,000 GRT or over) totaling 444,957 GRT/610,420 DWT
ships by type: bulk 11, cargo 15, chemical tanker 5, container 1,
oil tanker 3, passenger-cargo 3, vehicle carrier 2 (1995 est.)
Airports:
total: 74
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 13
with paved runways 914 to 1 523 m: 10
with paved runways under 914 m: 28
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 17 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 14,473 km
paved: 1,028 km
unpaved: 13,445 km (1992 est.)
Waterways: Lake Tanganyika
Ports: Bujumbura
Airports:
total: 3
with paved runways over 3 047 m: 1
with unpaved runways 914 to 1 523 m: 2 (1995 est.)
--------------
Railways:
total: 603 km
narrow gauge: 603 km 1.000-m gauge
Highways:
total: 34,100 km
paved: 3,000 km
unpaved: 31,100 km (1994 est.)
Waterways: 3,700 km navigable all year to craft drawing 0.6 m; 282
km navigable to craft drawing 1.8 m
Ports: Kampong Saom (Sihanoukville), Kampot, Krong Kaoh Kong,
Phnom Penh
Merchant marine:
total: 5 cargo ships (1,000 GRT or over) totaling 17,451 GRT/18,280
DWT (1995 est.)
Airports:
total: 14
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 2
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 7 (1995 est.)
Heliports: 2 (1995 est.)
--------------
Railways:
total: 1,104 km (1995 est.)
narrow gauge: 1,104 km 1.000-m gauge
Highways:
total: 64,626 km
paved: 2,666 km
unpaved: 61,960 km (1987 est.)
Waterways: 2,090 km; of decreasing importance
Ports: Bonaberi, Douala, Garoua, Kribi, Tiko
Merchant marine:
total: 2 cargo ships (1,000 GRT or over) totaling 24,122 GRT/33,509
DWT (1995 est.)
Airports:
total: 45
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 4
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 13
with unpaved runways 1 524 to 2 437 m: 7
with unpaved runways 914 to 1 523 m: 15 (1995 est.)
--------------
Railways:
total: 70,176 km; note - there are two major transcontinental
freight railway systems: Canadian National (privatized November
1995) and Canadian Pacific Railway; passenger service provided by
government-operated firm VIA, which has no trackage of its own
standard gauge: 70,000 km 1.435-m gauge (63 km electrified)
narrow gauge: 176 km 0.914-m gauge (1995)
Highways:
total: 849,404 km
paved: 297,291 km (including 15,983 km of expressways)
unpaved: 552,113 km (1991 est.)
Waterways: 3,000 km, including Saint Lawrence Seaway
Pipelines: crude and refined oil 23,564 km; natural gas 74,980 km
Ports: Becancour (Quebec), Churchill, Halifax, Montreal, New
Westminister, Prince Rupert, Quebec, Saint John (New Brunswick),
Saint John''s (Newfoundland), Seven Islands, Sydney, Three Rivers,
Thunder Bay, Toronto, Vancouver, Windsor
Merchant marine:
total: 62 ships (1,000 GRT or over) totaling 573,089 GRT/804,436 DWT
ships by type: bulk 17, cargo 9, chemical tanker 4, oil tanker 15,
passenger 2, passenger-cargo 1, railcar carrier 2, roll-on/roll-off
cargo 7, short-sea passenger 3, specialized tanker 2
note: does not include ships used exclusively in the Great Lakes
(1995 est.)
Airports:
total: 1,138
with paved runways over 3 047 m: 17
with paved runways 2 438 to 3 047 m: 15
with paved runways 1 524 to 2 437 m: 136
with paved runways 914 to 1 523 m: 226
with paved runways under 914 m: 422
with unpaved runways 1 524 to 2 437 m: 53
with unpaved runways 914 to 1 523 m: 269 (1995 est.)
Heliports: 14 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 1,100 km
paved: 680 km
unpaved: 420 km (1992 est.)
Ports: Mindelo, Praia, Tarrafal
Merchant marine: cargo 3, chemical tanker 1 (1995 est.)
total: 4 (1,000 GRT or over) totaling 5,632 GRT/8,872 DWT
Airports:
total: 6
with paved runways over 3 047 m: 1
with paved runways 914 to 1 523 m: 5 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 406 km
paved: 304 km
unpaved: 102 km
Ports: Cayman Brac, George Town
Merchant marine:
total: 19 ships (1,000 GRT or over) totaling 283,734 GRT/432,610 DWT
ships by type: bulk 3, cargo 6, chemical tanker 2, container 1, oil
tanker 3, roll-on/roll-off cargo 4
note: a flag of convenience registry; UK owns 1 ship, India 1,
Norway 1, US 3, Sweden 1, and UAE 1 (1995 est.)
Airports:
total: 3
with paved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 1 (1995 est.)','35a8e8445f3a4f0187c0c73bb6e184e9fb9b7bea82909a8b7bd335a43ff90450','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c22d82e5bf0c92eac14e50de20bc130a225384d18ff97a943e9c008d8e84ba9',1996,'NA','Namibia','transportation',81,'--------------
Railways: 0 km
Highways:
total: 23,738 km
paved: 427 km
unpaved: 23,311 km (1991 est.)
Waterways: 800 km; traditional trade carried on by means of
shallow-draft dugouts; Oubangui is the most important river
Ports: Bangui, Nola
Airports:
total: 48
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 2
with paved runways under 914 m: 11
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 9
with unpaved runways 914 to 1 523 m: 24 (1995 est.)','af6da1cfdedf93bb8ede1076a551f0533267674191ea037bf21f41c8f3bb81ee','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ade901fb19d4fd1f26c44e31ae103cdfcda60c2ca3fa1fc17497d2dcdb4ea58d',1996,'FR','France','transportation',89,'--------------
Railways: 0 km
Highways:
total: 31,141 km
paved: 32 km
unpaved: 31,109 km (1987 est.)
Waterways: 2,000 km navigable
Ports: none
Airports:
total: 47
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 11
with unpaved runways over 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 13
with unpaved runways 914 to 1 523 m: 18 (1995 est.)
--------------
Railways:
total: 6,782 km
broad gauge: 3,743 km 1.676-m gauge (1,653 km electrified)
narrow gauge: 116 km 1.067-m gauge; 2,923 km 1.000-m gauge (40 km
electrified) (1995)
Highways:
total: 79,593 km
paved: 10,984 km
unpaved: 68,609 km (1991 est.)
Waterways: 725 km
Pipelines: crude oil 755 km; petroleum products 785 km; natural
gas 320 km
Ports: Antofagasta, Arica, Chanarol, Coquimbo, Iquique, Puerto
Montt, Punta Arenas, San Antonio, San Vicente, Talcahuano, Valparaiso
Merchant marine:
total: 37 ships (1,000 GRT or over) totaling 529,512 GRT/925,364 DWT
ships by type: bulk 11, cargo 8, chemical tanker 4, combination
ore/oil 2, container 1, liquefied gas tanker 2, oil tanker 4,
roll-on/roll-off cargo 3, vehicle carrier 2 (1995 est.)
Airports:
total: 344
with paved runways over 3 047 m: 5
with paved runways 2 438 to 3 047 m: 5
with paved runways 1 524 to 2 437 m: 17
with paved runways 914 to 1 523 m: 16
with paved runways under 914 m: 220
with unpaved runways 2 438 to 3 047 m: 3
with unpaved runways 1 524 to 2 437 m: 10
with unpaved runways 914 to 1 523 m: 68 (1995 est.)
--------------
Railways:
total: 58,399 km
standard gauge: 54,799 km 1.435-m gauge (7,174 km electrified; more
than 11,000 km double track)
narrow gauge: 3,600 km 0.762-m gauge local industrial lines (1995)
Highways:
total: 1.029 million km
paved: 170,000 km
unpaved: 859,000 km (1990 est.)
Waterways: 138,600 km; about 109,800 km navigable
Pipelines: crude oil 9,700 km; petroleum products 1,100 km;
natural gas 6,200 km (1990)
Ports: Aihui, Changsha, Dalian, Fuzhou, Guangzhou, Hangzhou,
Harbin, Huangpu, Nanning, Ningbo, Qingdao, Qinhuangdao, Shanghai,
Shantou, Tanggu, Xiamen, Xingang, Zhanjiang
Merchant marine:
total: 1,700 ships (1,000 GRT or over) totaling 16,663,260
GRT/25,026,090 DWT
ships by type: barge carrier 2, bulk 316, cargo 876, chemical tanker
15, combination bulk 11, container 103, liquefied gas tanker 4,
multifunction large-load carrier 3, oil tanker 227, passenger 24,
passenger-cargo 28, refrigerated cargo 22, roll-on/roll-off cargo
24, short-sea passenger 45
note: China owns an additional 267 ships (1,000 GRT or over)
totaling 9,044,039 DWT operating under the registries of Panama,
Hong Kong, Malta, Liberia, Vanuatu, Cyprus, Saint Vincent and the
Grenadines, The Bahamas, Marshall Islands, and Singapore (1995 est.)
Airports:
total: 204
with paved runways over 3 047 m: 17
with paved runways 2 438 to 3 047 m: 69
with paved runways 1 524 to 2 437 m: 89
with paved runways 914 to 1 523 m: 9
with paved runways under 914 m: 7
with unpaved runways 1 524 to 2 437 m: 7
with unpaved runways 914 to 1 523 m: 3
with unpaved runways under 914 m: 3 (1994 est.)','4d4096b5fa1371cad9068dc69bb8d1e98ce9410b9980ad8bbea4e1023d6b108e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f929daa4d1c19528cc4b0bf37451c8d652111cb51f677aee92fd56bd4f7f903f',1996,'AU','Australia','transportation',103,'--------------
Railways: 24 km to serve phosphate mines
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: Flying Fish Cove
Merchant marine: none
Airports:
total: 1
with paved runways 1 524 to 2 437 m: 1 (1995 est.)
--------------
Ports: none; offshore anchorage only
Defense
-------
Defense note: defense is the responsibility of France
======================================================================
@Cocos (Keeling) Islands
-----------------------
(territory of Australia)
Map
---
Location: 12 30 S, 96 50 E -- Southeastern Asia, group of islands
in the Indian Ocean, south of Indonesia, about one-half of the way
from Australia to Sri Lanka
Flag
----
Description: the flag of Australia is used
--------------
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: none; lagoon anchorage only
Merchant marine: none
Airports:
total: 1
with paved runways 1 524 to 2 437 m: 1 (1995 est.)
--------------
Railways:
total: 3,386 km
standard gauge: 150 km 1.435-m gauge (connects Cerrejon coal mines
to maritime port at Bahia Portete)
narrow gauge: 3,236 km 0.914-m gauge (1830 km in use) (1995)
Highways:
total: 107,200 km
paved: 12,600 km
unpaved: 94,600 km
Waterways: 14,300 km, navigable by river boats
Pipelines: crude oil 3,585 km; petroleum products 1,350 km;
natural gas 830 km; natural gas liquids 125 km
Ports: Barranquilla, Buenaventura, Cartagena, Leticia, Puerto
Bolivar, San Andres, Santa Marta, Tumaco, Turbo
Merchant marine:
total: 19 ships (1,000 GRT or over) totaling 97,037 GRT/129,404 DWT
ships by type: bulk 5, cargo 8, container 3, oil tanker 3 (1995 est.)
Airports:
total: 989
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 9
with paved runways 1 524 to 2 437 m: 33
with paved runways 914 to 1 523 m: 35
with paved runways under 914 m: 557
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 41
with unpaved runways 914 to 1 523 m: 311 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 1,104 km
paved: 400 km
unpaved: 704 km (1988 est.)
Ports: Fomboni, Moroni, Mutsamudu
Merchant marine: none
Airports:
total: 4
with paved runways 2 438 to 3 047 m: 1
with paved runways 914 to 1 523 m: 3 (1995 est.)
--------------
Railways:
total: 795 km (1995 est.)
narrow gauge: 795 km 1.067-m gauge (includes 285 km that are
privately owned)
Highways:
total: 12,745 km
paved: 1,236 km
unpaved: 11,509 km (1992 est.)
Waterways: the Congo and Ubangi (Oubangui) Rivers provide 1,120 km
of commercially navigable water transport; other rivers are used for
local traffic only
Pipelines: crude oil 25 km
Ports: Brazzaville, Impfondo, Ouesso, Oyo, Pointe-Noire
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 2,218 GRT/4,100 DWT
(1995 est.)
Airports:
total: 34
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 3
with paved runways under 914 m: 9
with unpaved runways 1 524 to 2 437 m: 7
with unpaved runways 914 to 1 523 m: 14 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 187 km
paved: 35 km
unpaved: 152 km (1980 est.)
Ports: Avarua, Avatiu
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 1,464 GRT/2,181 DWT
(1995 est.)
Airports:
total: 7
with paved runways 1 524 to 2 437 m: 1
with unpaved runways 1 524 to 2 437 m: 3
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
--------------
Ports: none; offshore anchorage only
Defense
-------
Defense note: defense is the responsibility of Australia; visited
regularly by the Royal Australian Navy; Australia has control over
the activities of visitors
======================================================================
@Costa Rica
----------
Map
---
Location: 10 00 N, 84 00 W -- Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between Nicaragua and
--------------
Ports: Calcutta (India), Colombo (Sri Lanka), Durban (South
Africa), Jakarta (Indonesia), Madras (India), Melbourne (Australia),
Mumbai (Bombay; India), Richard''s Bay (South Africa)
--------------
Railways:
total: 6,458 km
narrow gauge: 5,961 km 1.067-m gauge (101 km electrified; 101 km
double track); 497 km 0.750-m gauge (1995)
Highways:
total: 283,516 km
paved: 125,051 km
unpaved: 158,465 km (1995 est.)
Waterways: 21,579 km total; Sumatra 5,471 km, Java and Madura 820
km, Kalimantan 10,460 km, Celebes 241 km, Irian Jaya 4,587 km
Pipelines: crude oil 2,505 km; petroleum products 456 km; natural
gas 1,703 km (1989)
Ports: Cilacap, Cirebon, Jakarta, Kupang, Palembang, Semarang,
Surabaya, Ujungpandang
Merchant marine:
total: 457 ships (1,000 GRT or over) totaling 2,098,958
GRT/3,056,040 DWT
ships by type: bulk 30, cargo 265, chemical tanker 6, container 11,
liquefied gas tanker 5, livestock carrier 1, oil tanker 98,
passenger 5, passenger-cargo 12, roll-on/roll-off cargo 7, short-sea
passenger 6, specialized tanker 7, vehicle carrier 4 (1995 est.)
Airports:
total: 414
with paved runways over 3 047 m: 4
with paved runways 2 438 to 3 047 m: 9
with paved runways 1 524 to 2 437 m: 35
with paved runways 914 to 1 523 m: 41
with paved runways under 914 m: 299
with unpaved runways 1 524 to 2 437 m: 3
with unpaved runways 914 to 1 523 m: 23 (1995 est.)
Heliports: 4 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 6,340 km
paved: 634 km
unpaved: 5,706 km (1987 est.)
Ports: Mueo, Noumea, Thio
Merchant marine:
total: 1 roll-on/roll-off ship (1,000 GRT or over) totaling 3,079
GRT/724 DWT (1995 est.)
Airports:
total: 28
with paved runways over 3 047 m: 1
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 12
with unpaved runways 914 to 1 523 m: 12 (1995 est.)
Heliports: 7 (1995 est.)
--------------
Railways:
total: 3,973 km
narrow gauge: 3,973 km 1.067-m gauge (504 km electrified)
Highways:
total: 93,348 km
paved: 54,142 km (including 141 km of expressways)
unpaved: 39,206 km (1992 est.)
Waterways: 1,609 km; of little importance to transportation
Pipelines: petroleum products 160 km; natural gas 1,000 km;
condensate (liquefied petroleum gas - LPG) 150 km
Ports: Auckland, Christchurch, Dunedin, Tauranga, Wellington
Merchant marine:
total: 17 ships (1,000 GRT or over) totaling 162,220 GRT/213,749 DWT
ships by type: bulk 6, cargo 1, liquefied gas tanker 1, oil tanker
3, railcar carrier 1, roll-on/roll-off cargo 5 (1995 est.)
Airports:
total: 113
with paved runways over 3 047 m: 2
with paved runways 1 524 to 2 437 m: 8
with paved runways 914 to 1 523 m: 31
with paved runways under 914 m: 50
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 21 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 80 km
paved: 53 km
unpaved: 27 km
Ports: none; loading jetties at Kingston and Cascade
Merchant marine: none
Airports:
total: 1
with paved runways 1 524 to 2 437 m: 1 (1995 est.)
--------------
Railways:
total: 1,241 km single track
narrow gauge: 1,241 km 1.000-m gauge
note:: a program to rehabilitate the railroad is underway (1995)
Highways:
total: 30,320 km
paved: 3,480 km
unpaved: 26,840 km (1987 est.)
Waterways: Lake Victoria, Lake Albert, Lake Kyoga, Lake George,
Lake Edward; Victoria Nile, Albert Nile
Ports: Entebbe, Jinja, Port Bell
Merchant marine:
total: 3 roll-on/roll-off cargo ships (1,000 GRT or over) totaling
5,091 GRT/2,743 DWT (1995 est.)
Airports:
total: 21
with paved runways over 3 047 m: 2
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 7
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 5
with unpaved runways 914 to 1 523 m: 5 (1995 est.)
--------------
Railways:
total: 23,350 km
broad gauge: 23,350 km 1.524-m gauge (8,600 km electrified)
Highways:
total: 169,964 km
paved: 168,094 km (including 1,767 km of expressways)
unpaved: 1,870 km (1992 est.)
Waterways: 4,400 km navigable waterways, of which 1,672 km were on
the Pryp''''yat'' and Dnipro (1990)
Pipelines: crude oil 2,010 km; petroleum products 1,920 km;
natural gas 7,800 km (1992)
Ports: Berdyans''k, Illichivs''k, Izmayil, Kerch, Kherson, Kiev
(Kyyiv), Mariupol'', Mykolayiv, Odesa, Pivdenne, Reni
Merchant marine:
total: 353 ships (1,000 GRT or over) totaling 3,262,341
GRT/4,356,374 DWT
ships by type: barge carrier 5, bulk 39, cargo 217, chemical tanker
2, combination bulk 1, container 11, multifunction large-load
carrier 3, oil tanker 21, passenger 7, passenger-cargo 5, railcar
carrier 2, refrigerated cargo 5, roll-on/roll-off cargo 32,
short-sea passenger 3 (1995 est.)
Airports:
total: 706
with paved runways over 3 047 m: 14
with paved runways 2 438 to 3 047 m: 55
with paved runways 1 524 to 2 437 m: 34
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 57
with unpaved runways over 3 047 m: 7
with unpaved runways 2 438 to 3 047 m: 7
with unpaved runways 1 524 to 2 437 m: 16
with unpaved runways 914 to 1 523 m: 37
with unpaved runways under 914 m: 476 (1994 est.)
--------------
Railways: 0 km
Highways:
total: 3,000 km
paved: 3,000 km
unpaved: 0 km (1993 est.)
Pipelines: crude oil 830 km; natural gas, including natural gas
liquids, 870 km
Ports: ''Ajman, Al Fujayrah, Das Island, Khawr Fakkan, Mina'' Jabal
''Ali, Mina'' Khalid, Mina'' Rashid, Mina'' Saqr, Mina'' Zayid, Umm al
Qaywayn
Merchant marine:
total: 57 ships (1,000 GRT or over) totaling 1,068,980 GRT/1,876,504
DWT
ships by type: bulk 2, cargo 17, chemical tanker 2, container 7,
liquefied gas tanker 1, livestock carrier 1, oil tanker 22,
refrigerated cargo 2, roll-on/roll-off cargo 3 (1995 est.)
Airports:
total: 36
with paved runways over 3 047 m: 9
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 10
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 7 (1995 est.)
Heliports: 2 (1995 est.)','bc57d0623903e6d66d73da907a00d0efeef4f5116f9c790637ba1f113964caad','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39c4152914f928621b1e7c4ff0205e8956f72c3fe5378936fce93c99e5b0629f',1996,'PA','Panama','transportation',108,'Flag
----
Description: five horizontal bands of blue (top), white, red
(double width), white, and blue, with the coat of arms in a white
disk on the hoist side of the red band
--------------
Railways:
total: 950 km
narrow gauge: 950 km 1.067-m gauge (260 km electrified)
note: the entire system was scheduled to be shut down on 31 June
1995 because of insolvency
Highways:
total: 35,560 km
paved: 5,608 km
unpaved: 29,952 km (1992 est.)
Waterways: about 730 km, seasonally navigable
Pipelines: petroleum products 176 km
Ports: Caldera, Golfito, Moin, Puerto Limon, Puerto Quepos,
Puntarenas
Merchant marine: none
Airports:
total: 145
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 16
with paved runways under 914 m: 97
with unpaved runways 914 to 1 523 m: 29 (1995 est.)
--------------
Railways:
total: 660 km (1995 est.)
narrow gauge: 660 km 1.000-meter gauge; 25 km double track
Highways:
total: 46,331 km
paved: 3,579 km
unpaved: 42,752 km (1984 est.)
Waterways: 980 km navigable rivers, canals, and numerous coastal
lagoons
Ports: Abidjan, Aboisso, Dabou, San-Pedro
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 27,726 GRT/34,711 DWT
ships by type: container 2, oil tanker 1 (1995 est.)
Airports:
total: 35
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 4
with paved runways under 914 m: 10
with unpaved runways 1 524 to 2 437 m: 6
with unpaved runways 914 to 1 523 m: 12 (1995 est.)
--------------
Railways:
total: 2,699 km
standard gauge: 2,699 km 1.435-m gauge (1213 km electrified)
note: disrupted by territorial dispute with Serbia (1994)
Highways:
total: 27,378 km
paved: 22,176 km (including 302 km of expressways)
unpaved: 5,202 km (1991 est.)
Waterways: 785 km perennially navigable
Pipelines: crude oil 670 km; petroleum products 20 km; natural gas
310 km (1992); note - under repair following territorial dispute
Ports: Dubrovnik, Omisalj, Ploce, Pula, Rijeka, Sibenik, Split,
Zadar
Merchant marine:
total: 39 ships (1,000 GRT or over) totaling 203,495 GRT/252,818 DWT
ships by type: bulk 2, cargo 23, chemical tanker 1, container 3, oil
tanker 1, passenger 2, refrigerated cargo 1, roll-on/roll-off cargo
2, short-sea passenger 4
note: Croatia owns an additional 140 ships (1,000 GRT or over)
totaling 3,368,035 DWT operating under the registries of Malta,
Liberia, Cyprus, Panama, Antigua and Barbuda, The Bahamas, and Saint
Vincent and the Grenadines (1995 est.)
Airports:
total: 68
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 6
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 47
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 7 (1995 est.)
Heliports: 2 (1995 est.)
--------------
Railways:
total: 4,677 km
standard gauge: 4,677 km 1.435-m gauge (132 km electrified)
note: a large amount of track is in private use by sugar plantations
Highways:
total: 26,500 km
paved: 14,575 km
unpaved: 11,925 km (1996 est.)
Waterways: 240 km
Ports: Cienfuegos, La Habana, Manzanillo, Mariel, Matanzas,
Nuevitas, Santiago de Cuba
Merchant marine:
total: 41 ships (1,000 GRT or over) totaling 220,870 GRT/310,169 DWT
ships by type: cargo 17, chemical tanker 1, liquefied gas tanker 4,
oil tanker 9, passenger-cargo 1, refrigerated cargo 9
note: Cuba owns an additional 47 ships (1,000 GRT or over) totaling
462,517 DWT operating under the registries of Panama, Cyprus, Malta,
Belize, and Mauritius (1995 est.)
Airports:
total: 156
with paved runways over 3 047 m: 7
with paved runways 2 438 to 3 047 m: 7
with paved runways 1 524 to 2 437 m: 14
with paved runways 914 to 1 523 m: 9
with paved runways under 914 m: 87
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 31 (1995 est.)
--------------
Railways: 0 km
Highways:
Greek area - total: 10,448 km
Greek area - paved: 5,694 km
Greek area - unpaved: 4,754 km
Turkish area - total: 6,116 km
Turkish area - paved: 5,278 km
Turkish area - unpaved: 838 km
Ports: Famagusta, Kyrenia, Larnaca, Limassol, Vasilikos Bay
Merchant marine:
total: 1,524 ships (1,000 GRT or over) totaling 23,949,242
GRT/40,236,638 DWT
ships by type: bulk 490, cargo 562, chemical tanker 27, combination
bulk 53, combination ore/oil 22, container 115, liquefied gas tanker
3, multifunction large-load carrier 4, oil tanker 129, passenger 6,
passenger-cargo 1, refrigerated cargo 62, roll-on/roll-off cargo 28,
short-sea passenger 17, specialized tanker 3, vehicle carrier 2
note: a flag of convenience registry; includes ships from 48
countries among which are Greece 706, Germany 171, Russia 44,
Netherlands 31, Belgium 30, Japan 29, Cuba 21, UK 17, Spain 14, and
Hong Kong 13 (1995 est.)
Airports:
total: 15
with paved runways 2 438 to 3 047 m: 8
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 3
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
Heliports: 4 (1995 est.)
--------------
Railways:
total: 9,413 km
standard gauge: 9,316 km 1.435-m standard gauge (2640 km electrified)
narrow gauge: 97 km several narrow gauges (1995)
Highways:
total: 55,557 km (1994 est.)
paved: NA km
unpaved: NA km
Waterways: NA km; the Elbe (Labe) is the principal river
Pipelines: natural gas 5,400 km
Ports: Decin, Prague, Usti nad Labem
Merchant marine:
total: 10 ships (1,000 GRT or over) totaling 155,946 GRT/251,624 DWT
ships by type: bulk 5, cargo 5 (1995 est.)
Airports:
total: 116
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 9
with paved runways 1 524 to 2 437 m: 13
with paved runways under 914 m: 5
with unpaved runways over 3 047 m: 1
with unpaved runways 2 438 to 3 047 m: 3
with unpaved runways 1 524 to 2 437 m: 10
with unpaved runways 914 to 1 523 m: 32
with unpaved runways under 914 m: 41 (1994 est.)
--------------
Railways:
total: 2,848 km (499 km privately owned and operated)
standard gauge: 2,848 km 1.435-m gauge (326 km electrified; 760 km
double track) (1995)
Highways:
total: 71,042 km
paved: 71,042 km (including 696 km of expressways)
unpaved: 0 km (1992 est.)
Waterways: 417 km
Pipelines: crude oil 110 km; petroleum products 578 km; natural
gas 700 km
Ports: Alborg, Arhus, Copenhagen, Esbjerg, Fredericia, Grenaa,
Koge, Odense, Struer
Merchant marine:
total: 334 ships (1,000 GRT or over) totaling 5,013,054
GRT/7,171,871 DWT
ships by type: bulk 13, cargo 114, chemical tanker 25, container 65,
liquefied gas tanker 27, livestock carrier 5, oil tanker 31, railcar
carrier 1, refrigerated cargo 17, roll-on/roll-off cargo 26,
short-sea passenger 9, specialized tanker 1
note: Denmark has created its own internal register, called the
Danish International Ship register (DIS); DIS ships do not have to
meet Danish manning regulations, and they amount to a flag of
convenience within the Danish register (1995 est.)
Airports:
total: 109
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 7
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 13
with paved runways under 914 m: 77
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 6 (1995 est.)
--------------
Railways:
total: 97 km (Djibouti segment of the Addis Ababa-Djibouti railroad)
narrow gauge: 97 km 1.000-m gauge
Highways:
total: 2,879 km
paved: 363 km
unpaved: 2,516 km (1991 est.)
Ports: Djibouti
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 1,369 GRT/3,030 DWT
(1995 est.)
Airports:
total: 11
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 2
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 5 (1995 est.)','68e19be868d9aec92e06cbe57f103e8c87012973c64838cc5700fb4e78309f00','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d16ba04e249c4fe2a701e0827320ac69bb5c53db23516beb32a1042d69dc986a',1996,'TT','Trinidad and Tobago','transportation',123,'--------------
Railways: 0 km
Highways:
total: 800 km
paved: 500 km
unpaved: 300 km
Ports: Portsmouth, Roseau
Merchant marine: none
Airports:
total: 2
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways:
total: 757 km
standard gauge: 375 km 1.435-m gauge (Central Romana Railroad)
narrow gauge: 142 km 0.762-m gauge (Dominica Government Railway);
240 km operated by sugar companies in various gauges (0.558-m,
0.762-m, 1.067-m gauges) (1995)
Highways:
total: 11,931 km
paved: 5,766 km
unpaved: 6,165 km (1987 est.)
Pipelines: crude oil 96 km; petroleum products 8 km
Ports: Barahona, La Romana, Puerto Plata, San Pedro de Macoris,
Santo Domingo
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 1,587 GRT/1,165 DWT
(1995 est.)
Airports:
total: 31
with paved runways over 3 047 m: 2
with paved runways 1 524 to 2 437 m: 6
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 14
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 4 (1995 est.)
--------------
Railways:
total: 965 km (single track)
narrow gauge: 965 km 1.067-m gauge
Highways:
total: 43,709 km
paved: 5,245 km
unpaved: 38,464 km (1991 est.)
Waterways: 1,500 km
Pipelines: crude oil 800 km; petroleum products 1,358 km
Ports: Esmeraldas, Guayaquil, La Libertad, Manta, Puerto Bolivar,
San Lorenzo
Merchant marine:
total: 19 ships (1,000 GRT or over) totaling 114,701 GRT/171,240 DWT
ships by type: container 2, liquefied gas tanker 1, oil tanker 12,
passenger 3, refrigerated cargo 1 (1995 est.)
Airports:
total: 188
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 7
with paved runways 1 524 to 2 437 m: 8
with paved runways 914 to 1 523 m: 13
with paved runways under 914 m: 121
with unpaved runways 1 524 to 2 437 m: 5
with unpaved runways 914 to 1 523 m: 32 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 994 km
paved: 597 km
unpaved: 397 km (1988 est.)
Ports: Grenville, Saint George''s
Merchant marine: none
Airports:
total: 3
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways:
total: NA km; privately owned, narrow-gauge plantation lines
Highways:
total: 2,082 km (national 329 km, regional 582 km, community/local
1171 km)
paved: 1,742 km
unpaved: 340 km (1985 est.)
Ports: Basse-Terre, Gustavia, Marigot, Pointe-a-Pitre
Merchant marine: none
Airports:
total: 9
with paved runways over 3 047 m: 1
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 6 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 1,690 km
paved: 1,300 km
unpaved: 390 km
Ports: Fort-de-France, La Trinite
Merchant marine: none
Airports:
total: 2
with paved runways over 3 047 m: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 760 km
paved: 500 km
unpaved: 260 km
Ports: Castries, Vieux Fort
Merchant marine: none
Airports:
total: 3
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 120 km
paved: 60 km
unpaved: 60 km (1985 est.)
Ports: Saint Pierre
Merchant marine: none
Airports:
total: 2
with paved runways 914 to 1 523 m: 2
note: new airport to open June 1996 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 1,100 km
paved: 330 km
unpaved: 770 km
Ports: Kingstown
Merchant marine:
total: 611 ships (1,000 GRT or over) totaling 5,690,104
GRT/9,367,014 DWT
ships by type: bulk 106, cargo 305, chemical tanker 20, combination
bulk 9, combination ore/oil 4, container 33, liquefied gas tanker 4,
livestock carrier 5, oil tanker 58, passenger 1, passenger-cargo 1,
refrigerated cargo 35, roll-on/roll-off cargo 25, short-sea
passenger 2, specialized tanker 1, vehicle carrier 2
note: a flag of convenience registry; includes ships from 24
countries among which are Croatia 42, Russia 14, Slovenia 9, China
9, Germany 2, Serbia 2, Hong Kong 2, Latvia 1, Ukraine 1, and Poland
1 (1995 est.)
Airports:
total: 6
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 4 (1995 est.)
--------------
Railways: 0 km; note - there is a 1.5 km cable railway connecting
the city of San Marino to Borgo Maggiore
Highways:
total: 220 km
paved: NA km
unpaved: NA km
Ports: none
Airports: none','23647f3de0261a3e6fa091ab2180efb9cbddce51fd1b5be769201280791c2ee8','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ad146912d1cbda9365e7fff25c62a935fa84e00652524d8bc82c29bd58708f8',1996,'MX','Mexico','transportation',131,'--------------
Railways:
total: 4,751 km
standard gauge: 4,751 km 1,435-m gauge (42 km electrified; 951 km
double track)
Highways:
total: 47,387 km
paved: 34,593 km
unpaved: 12,794 km (1992 est.)
Waterways: 3,500 km (including the Nile, Lake Nasser,
Alexandria-Cairo Waterway, and numerous smaller canals in the
delta); Suez Canal, 193.5 km long (including approaches), used by
oceangoing vessels drawing up to 16.1 m of water
Pipelines: crude oil 1,171 km; petroleum products 596 km; natural
gas 460 km
Ports: Alexandria, Al Ghardaqah, Aswan, Asyut, Bur Safajah,
Damietta, Marsa Matruh, Port Said, Suez
Merchant marine:
total: 164 ships (1,000 GRT or over) totaling 1,187,290
GRT/1,833,108 DWT
ships by type: bulk 22, cargo 74, liquefied gas tanker 1, oil tanker
14, passenger 33, refrigerated cargo 1, roll-on/roll-off cargo 15,
short-sea passenger 4 (1995 est.)
Airports:
total: 80
with paved runways over 3 047 m: 11
with paved runways 2 438 to 3 047 m: 34
with paved runways 1 524 to 2 437 m: 16
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 9
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 4 (1995 est.)
Heliports: 2 (1995 est.)
--------------
Railways:
total: 602 km (single track; note - some sections abandoned,
unusable, or operating at reduced capacity)
narrow gauge: 602 km 0.914-m gauge
Highways:
total: 12,251 km
paved: 1,740 km (including 107 km of expressways)
unpaved: 10,511 km (1992 est.)
Waterways: Rio Lempa partially navigable
Ports: Acajutla, Puerto Cutuco, La Libertad, La Union, Puerto El
Triunfo
Merchant marine: none
Airports:
total: 73
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 48
with unpaved runways 914 to 1 523 m: 21 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways:
total: 704 km (single track); note - owned and operated by
government mining company
standard gauge: 704 km 1.435-m gauge (1995)
Highways:
total: 7,496 km
paved: 1,342 km
unpaved: 6,154 km (1987 est.)
Waterways: mostly ferry traffic on the Senegal River
Ports: Bogue, Kaedi, Nouadhibou, Nouakchott, Rosso
Merchant marine: none
Airports:
total: 24
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 4
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 2
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 4
with unpaved runways 914 to 1 523 m: 9 (1995 est.)
--------------
Railways:
total: 240,000 km mainline routes (nongovernment owned)
standard gauge: 240,000 km 1.435-m gauge (1989)
Highways:
total: 6,284,488 km
paved: 5,574,341 km (in 1991, included 85,267 km of expressways)
unpaved: 710,147 km (1993 est.)
Waterways: 41,009 km of navigable inland channels, exclusive of
the Great Lakes
Pipelines: petroleum 276,000 km; natural gas 331,000 km (1991)
Ports: Anchorage, Baltimore, Boston, Charleston, Chicago, Duluth,
Hampton Roads, Honolulu, Houston, Jacksonville, Los Angeles, New
Orleans, New York, Philadelphia, Port Canaveral, Portland (Oregon),
Prudhoe Bay, San Francisco, Savannah, Seattle, Tampa, Toledo
Merchant marine:
total: 322 ships (1,000 GRT or over) totaling 10,716,000
GRT/15,259,000 DWT
ships by type: bulk 21, cargo 20, chemical tanker 17, intermodal
125, liquefied gas tanker 14, passenger-cargo 2, tanker 110, tanker
tug-barge 13
note: in addition, there are 190 government-owned vessels (1995 est.)
Airports:
total: 13,387
with paved runways over 3 047 m: 179
with paved runways 2 438 to 3 047 m: 201
with paved runways 1 524 to 2 437 m: 1,204
with paved runways 914 to 1 523 m: 2,361
with paved runways under 914 m: 7,720
with unpaved runways over 3 047 m: 1
with unpaved runways 2 438 to 3 047 m: 7
with unpaved runways 1 524 to 2 437 m: 151
with unpaved runways 914 to 1 523 m: 1,563 (1995 est.)
Heliports: 63 (1995 est.)
--------------
Railways:
total: 2,070 km (461 km closed; additional 460 km only partially
operational)
standard gauge: 2,070 km 1.435-m gauge
Highways:
total: 49,600 km
paved: 6,656 km
unpaved: 42,944 km (1988 est.)
Waterways: 1,600 km; used by coastal and shallow-draft river craft
Ports: Fray Bentos, Montevideo, Nueva Palmira, Paysandu, Punta del
Este
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 71,405 GRT/110,939 DWT
ships by type: cargo 1, container 1, oil tanker 1 (1995 est.)
Airports:
total: 66
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 5
with paved runways 914 to 1 523 m: 8
with paved runways under 914 m: 36
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 14 (1995 est.)
--------------
Railways:
total: 3,460 km in common carrier service; does not include
industrial lines
broad gauge: 3,460 km 1.520-m gauge (1990)
Highways:
total: 78,400 km
paved: NA km
unpaved: NA km (1990 est.)
Pipelines: crude oil 250 km; petroleum products 40 km; natural gas
810 km (1992)
Ports: Termiz
Airports:
total: 261
with paved runways over 3 047 m: 6
with paved runways 2 438 to 3 047 m: 14
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 8
with paved runways under 914 m: 5
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 7
with unpaved runways under 914 m: 216 (1994 est.)','e03fe31c8bd5cb57aecf5953ed64932f3d500f159250d91c84af74f22b341ffb','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c5c7445fd138fc251c3c150e4587c74f35f7a6307cbf5d25365de28a13ac64e',1996,'CM','Cameroon','transportation',135,'--------------
Railways:
total: 0 km
Highways:
total: 2,744 km
paved: 330 km
unpaved: 2,414 km (1988 est.)
Ports: Bata, Luba, Malabo
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 6,412 GRT/6,699 DWT
ships by type: cargo 1, passenger-cargo 1 (1995 est.)
Airports:
total: 3
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways:
total: 307 km; note - nonoperational since 1978 except for about 5
km that was reopened in Massawa in 1994; rehabilitation of the
remainder and of the rolling stock is under way; links Ak''ordat and
Asmara (formerly Asmera) with the port of Massawa (formerly Mits''iwa)
narrow gauge: 307 km 0.950-m gauge (1995 est.)
Highways:
total: 3,845 km
paved: 807 km
unpaved: 3,038 km (1993 est.)
Ports: Assab (Aseb), Massawa (Mits''iwa)
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 11,573 GRT/13,593
DWT (1995 est.)
Airports:
total: 14
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 2
with unpaved runways over 3 047 m: 1
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 4
with unpaved runways 914 to 1 523 m: 4 (1995 est.)
--------------
Railways:
total: 1,018 km common carrier lines only; does not include
dedicated industrial lines
broad gauge: 1,018 km 1.520-m gauge (132 km electrified) (1995)
Highways:
total: 14,771 km
paved: 8,124 km (including 62 km of expressways)
unpaved: 6,647 km (1993)
Waterways: 500 km perennially navigable
Pipelines: natural gas 420 km (1992)
Ports: Haapsalu, Narva, Paldiski, Parnu, Tallinn
Merchant marine:
total: 52 ships (1,000 GRT or over) totaling 353,140 GRT/467,086 DWT
ships by type: bulk 6, cargo 33, oil tanker 3, roll-on/roll-off
cargo 6, short-sea passenger 4 (1995 est.)
Airports:
total: 22
with paved runways 2 438 to 3 047 m: 7
with paved runways 914 to 1 523 m: 3
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 4
with unpaved runways under 914 m: 5 (1994 est.)
--------------
Railways:
total: 681 km (Ethiopian segment of the Addis Ababa-Djibouti
railroad)
narrow gauge: 681 km 1.000-m gauge
Highways:
total: 24,127 km
paved: 3,289 km
unpaved: 20,838 km (1993 est.)
Ports: none; Ethiopia is landlocked but by agreement with Eritrea
may use the ports of Assab and Massawa
Merchant marine:
total: 12 ships (1,000 GRT or over) totaling 62,627 GRT/88,908 DWT
ships by type: cargo 8, oil tanker 2, roll-on/roll-off cargo 2 (1995
est.)
Airports:
total: 58
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 6
with unpaved runways over 3 047 m: 2
with unpaved runways 2 438 to 3 047 m: 5
with unpaved runways 1 524 to 2 437 m: 9
with unpaved runways 914 to 1 523 m: 29 (1995 est.)
--------------
Ports: none; offshore anchorage only
Airports:
total: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)','0399534267693e2a83c258b9fa38edcb8fb394995e6c1e2a68c356d351d93018','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c303425c8416b646640f1a1fa4e0bed7bc745aa3bf3c7f31d3ea2484ec84e2d9',1996,'AR','Argentina','transportation',145,'--------------
Railways: 0 km
Highways:
total: 510 km
paved: 30 km
unpaved: 480 km
Ports: Stanley
Merchant marine: none
Airports:
total: 5
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 4 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 443 km
paved: NA km
unpaved: NA km
Ports: Klaksvick, Torshavn, Tvoroyri
Merchant marine:
total: 7 ships (1,000 GRT or over) totaling 19,879 GRT/18,444 DWT
ships by type: cargo 5, roll-on/roll-off cargo 1, short-sea
passenger 1 (1995 est.)
Airports:
total: 1
with paved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways:
total: 597 km; note - belongs to the government-owned Fiji Sugar
Corporation
narrow gauge: 597 km 0.610-m gauge (1995)
Highways:
total: 4,800 km
paved: NA km
unpaved: NA km
Waterways: 203 km; 122 km navigable by motorized craft and
200-metric-ton barges
Ports: Labasa, Lautoka, Levuka, Savusavu, Suva
Merchant marine:
total: 5 ships (1,000 GRT or over) totaling 16,267 GRT/17,884 DWT
ships by type: chemical tanker 2, oil tanker 1, roll-on/roll-off
cargo 2 (1995 est.)
Airports:
total: 21
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 15
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
--------------
Railways:
total: 5,895 km
broad gauge: 5,895 km 1.524-m gauge (1,993 km electrified; 480 km
double- or more-track) (1995)
Highways:
total: 76,755 km
paved: 47,588 km (including 318 km of expressways)
unpaved: 29,167 km (1992 est.)
Waterways: 6,675 km total (including Saimaa Canal); 3,700 km
suitable for steamers
Pipelines: natural gas 580 km
Ports: Hamina, Helsinki, Kokkola, Kotka, Loviisa, Oulu, Pori,
Rauma, Turku, Uusikaupunki, Varkaus
Merchant marine:
total: 92 ships (1,000 GRT or over) totaling 1,051,231 GRT/1,075,397
DWT
ships by type: bulk 8, cargo 20, chemical tanker 5, oil tanker 12,
passenger 2, refrigerated cargo 1, roll-on/roll-off cargo 31,
short-sea passenger 12, vehicle carrier 1 (1995 est.)
Airports:
total: 157
with paved runways over 3 047 m: 3
with paved runways 2 438 to 3 047 m: 23
with paved runways 1 524 to 2 437 m: 13
with paved runways 914 to 1 523 m: 21
with paved runways under 914 m: 92
with unpaved runways 914 to 1 523 m: 5 (1995 est.)
--------------
Railways:
total: 33,891 km
standard gauge: 33,524 km 1.435-m gauge; 32,275 km are operated by
French National Railways (SNCF); 13,741 km of SNCF routes are
electrified and 12,132 km are double- or multiple-tracked
narrow gauge: 367 km 1.000-m gauge
note: includes Corsica; does not include 33 tourist railroads,
totalling 469 km, many being of very narrow gauge (1995)
Highways:
total: 1,511,200 km
paved: 811,200 km (including 7,700 km of expressways)
unpaved: 700,000 km (1992 est.)
note: includes Corsica
Waterways: 14,932 km; 6,969 km heavily traveled
Pipelines: crude oil 3,059 km; petroleum products 4,487 km;
natural gas 24,746 km
Ports: Bordeaux, Boulogne, Cherbourg, Dijon, Dunkerque, La
Pallice, Le Havre, Lyon, Marseille, Mullhouse, Nantes, Paris, Rouen,
Saint Nazaire, Saint Malo, Strasbourg
Merchant marine:
total: 55 ships (1,000 GRT or over) totaling 1,203,086 GRT/1,779,263
DWT
ships by type: bulk 6, cargo 5, chemical tanker 5, container 7,
liquefied gas tanker 3, oil tanker 16, passenger 1, roll-on/roll-off
cargo 6, short-sea passenger 5, specialized tanker 1
note: France also maintains a captive register for French-owned
ships in the Kerguelen Islands (French Southern and Antarctic Lands)
(1995 est.)
Airports:
total: 460
with paved runways over 3 047 m: 13
with paved runways 2 438 to 3 047 m: 26
with paved runways 1 524 to 2 437 m: 91
with paved runways 914 to 1 523 m: 73
with paved runways under 914 m: 179
with unpaved runways 1 524 to 2 437 m: 3
with unpaved runways 914 to 1 523 m: 75 (1995 est.)
note: includes Corsica
Heliports: 3 (1995 est.)
--------------
Railways: 0 km (1995)
Highways:
total: 1,817 km (national 432 km, departmental 385 km, community
1,000 km)
paved: 727 km
unpaved: 1,090 km (1995 est.)
Waterways: 460 km, navigable by small oceangoing vessels and river
and coastal steamers; 3,300 km navigable by native craft
Ports: Cayenne, Degrad des Cannes, Saint-Laurent du Maroni
Merchant marine: none
Airports:
total: 10
with paved runways over 3 047 m: 1
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 4
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
--------------
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: Grytviken
Airports: none','6661c2b4663330ba8514931334cdd512cfaa73aea144579f94030f5bb63afed9','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87fe59c53e827184e24e70d2d123b678adff8e133eeb7d97047f0752502a8da5',1996,'NR','Nauru','transportation',150,'--------------
Railways: 0 km
Highways:
total: 792 km
paved: 792 km (1995 est.)
Ports: Mataura, Papeete, Rikitea, Uturoa
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 4,127 GRT/6,710 DWT
ships by type: passenger-cargo 2, refrigerated cargo 1 (1995 est.)
Airports:
total: 41
with paved runways over 3 047 m: 2
with paved runways 1 524 to 2 437 m: 5
with paved runways 914 to 1 523 m: 13
with paved runways under 914 m: 15
with unpaved runways 914 to 1 523 m: 6 (1995 est.)
--------------
Ports: none; offshore anchorage only
Merchant marine:
total: 66 ships (1,000 GRT or over) totaling 2,133,942 GRT/3,617,863
DWT
ships by type: bulk 2, cargo 6, chemical tanker 7, container 10,
liquefied gas tanker 4, multifunction large-load carrier 1, oil
tanker 18, refrigerated cargo 4, roll-on/roll-off cargo 13,
specialized tanker 1
note: a subset of the French register allowing French-owned ships to
operate under more liberal taxation and manning regulations than
permissable under the main French register (1995 est.)
Airports: none (1994 est.)
--------------
Railways:
total: 649 km Gabon State Railways (OCTRA)
standard gauge: 649 km 1.435-m gauge; single track (1994)
Highways:
total: 7,456 km
paved: 560 km
unpaved: 6,896 km (1988 est.)
Waterways: 1,600 km perennially navigable
Pipelines: crude oil 270 km; petroleum products 14 km
Ports: Cape Lopez, Kango, Lambarene, Libreville, Mayumba, Owendo,
Port-Gentil
Merchant marine:
total: 3 bulk (1,000 GRT or over) totaling 36,976 GRT/60,319 DWT
(1995 est.)
Airports:
total: 54
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 7
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 21
with unpaved runways 1 524 to 2 437 m: 8
with unpaved runways 914 to 1 523 m: 15 (1995 est.)
--------------
Railways:
total: NA km; note - one line, abandoned and in disrepair, little
trackage remains
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: small, poorly developed road network
Ports: Gaza
Airports:
total: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways:
total: 1,570 km in common carrier service; does not include
industrial lines
broad gauge: 1,570 km 1.520-m gauge (1990)
Highways:
total: 35,100 km
paved: 31,200 km
unpaved: 3,900 km (1990 est.)
Pipelines: crude oil 370 km; refined products 300 km; natural gas
440 km (1992)
Ports: Bat''umi, P''ot''i, Sokhumi
Merchant marine:
total: 23 ships (1,000 GRT or over) totaling 307,765 GRT/483,567 DWT
ships by type: bulk 8, cargo 2, oil tanker 12, short-sea passenger 1
(1995 est.)
Airports:
total: 28
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 7
with paved runways 1 524 to 2 437 m: 4
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 1
with unpaved runways over 3 047 m: 1
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 5
with unpaved runways under 914 m: 6 (1994 est.)
Transportation note: transportation network is in poor condition
and disrupted by ethnic conflict, criminal activities, and fuel
shortages; network lacks maintenance and repair','80d4675f49e684e7133634b388093c7ef2750b47a9585e14d8f1ec79adbb0217','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b577028ebcdaf335f837c9df59079902339f64445df3113e50114994a02c6253',1996,'DK','Denmark','transportation',160,'--------------
Railways:
total: 43,966 km
standard gauge: 43,531 km 1.435-m; 40,355 km are owned by Deutsche
Bahn AG (DB); 17,015 km of the DB system are electrified and 16,941
km are double- or more-tracked
narrow gauge: 389 km 1.000-m gauge (DB operates 146 km of 1.000-m
gauge); 7 km 0.900-m gauge; 39 km 0.750-m gauge
note: in addition to the DB system there are 54 privately-owned
industrial or excursion railways, ranging in route length from 2 km
to 632 km, with a total length of 3,465 km (1995)
Highways:
total: 636,282 km
paved: 531,018 km (including 10,955 km of expressways)
unpaved: 105,264 km (1991 est.)
Waterways:
western: 5,222 km, of which almost 70% are usable by craft of
1,000-metric-ton capacity or larger; major rivers include the Rhine
and Elbe; Kiel Canal is an important connection between the Baltic
Sea and North Sea
eastern: 2,319 km (1988)
Pipelines: crude oil 3,644 km; petroleum products 3,946 km;
natural gas 97,564 km (1988)
Ports: Berlin, Bonn, Brake, Bremen, Bremerhaven, Cologne, Dresden,
Duisburg, Emden, Hamburg, Karlsruhe, Kiel, Lubeck, Magdeburg,
Mannheim, Rostock, Stuttgart
Merchant marine:
total: 452 ships (1,000 GRT or over) totaling 5,054,327
GRT/6,367,036 DWT
ships by type: bulk 6, cargo 193, chemical tanker 15, combination
bulk 4, combination ore/oil 5, container 166, liquefied gas tanker
12, multifunction large-load carrier 6, oil tanker 11, passenger 3,
railcar carrier 3, refrigerated cargo 7, roll-on/roll-off cargo 14,
short-sea passenger 7 (1995 est.)
Airports:
total: 617
with paved runways over 3 047 m: 13
with paved runways 2 438 to 3 047 m: 65
with paved runways 1 524 to 2 437 m: 67
with paved runways 914 to 1 523 m: 51
with paved runways under 914 m: 351
with unpaved runways over 3 047 m: 2
with unpaved runways 2 438 to 3 047 m: 6
with unpaved runways 1 524 to 2 437 m: 7
with unpaved runways 914 to 1 523 m: 55 (1995 est.)
Heliports: 55 (1995 est.)
--------------
Railways:
total: 953 km; note - undergoing major renovation (1995 est.)
narrow gauge: 953 km 1.067-m gauge; 32 km double track
Highways:
total: 38,145 km
paved: 7,476 km (including 21 km of expressways)
unpaved: 30,669 km (1990 est.)
Waterways: Volta, Ankobra, and Tano Rivers provide 168 km of
perennial navigation for launches and lighters; Lake Volta provides
1,125 km of arterial and feeder waterways
Pipelines: none
Ports: Takoradi, Tema
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 27,427 GRT/35,894 DWT
ships by type: cargo 2, refrigerated cargo 1 (1995 est.)
Airports:
total: 12
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 2
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 2 (1995 est.)
--------------
Railways:
total: NA km; 1.000-m gauge system in dockyard area only
Highways:
total: 49.9 km (including 12.9 km public highways)
paved: 49.9 km
unpaved: 0 km
Pipelines: none
Ports: Gibraltar
Merchant marine:
total: 19 ships (1,000 GRT or over) totaling 357,730 GRT/635,769 DWT
ships by type: bulk 1, cargo 3, chemical tanker 1, container 1, oil
tanker 13 (1995 est.)
Airports:
total: 1
with paved runways 1 524 to 2 437 m: 1 (1995 est.)
--------------
Ports: none; offshore anchorage only
Airports:
total: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
Defense
-------
Defense note: defense is the responsibility of France
======================================================================
@Greece
------
Map
---
Location: 39 00 N, 22 00 E -- Southern Europe, bordering the
Aegean Sea, Ionian Sea, and the Mediterranean Sea, between Albania
and Turkey
Flag
----
Description: nine equal horizontal stripes of blue alternating
with white; there is a blue square in the upper hoist-side corner
bearing a white cross; the cross symbolizes Greek Orthodoxy, the
established religion of the country','b0279343b287465982dd37f52be1a62c12bfe6ac845f0fb1461a686afce8aaf7','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0264499b8f628fd19a230ea670306d31f0ce61c2a7c56ce9f534fb9f6f7ff05',1996,'CA','Canada','transportation',166,'--------------
Railways: 0 km
Highways:
total: 150 km
paved: 60 km
unpaved: 90 km
Ports: Faeringehavn, Frederikshaab, Holsteinsborg, Nanortalik,
Narsaq, Nuuk (Godthaab), Sondre Stromfjord
Merchant marine:
total: 1 short-sea passenger (1,000 GRT or over) totaling 2,162
GRT/610 DWT (1995 est.)
Airports:
total: 8
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 1
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 2 (1995 est.)','cef7cdf66b69ef5c562ed2cdae9f1949bcbfb4120ac08420422cb25f6509ec2f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cba8efb23c3125cc1d7b5b3c551678e0c7497196a3a9a7c9fdb03aa0969a72b',1996,'PH','Philippines','transportation',177,'--------------
Railways: 0 km
Highways:
total: 674 km (all-weather roads)
paved: NA km
unpaved: NA km
Ports: Apra Harbor
Merchant marine: none
Airports:
total: 4
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways:
total: 884 km (102 km privately owned)
narrow gauge: 884 km 0.914-m gauge (single track)
Highways:
total: 12,033 km
paved: 3,117 km (including 125 km of expressways)
unpaved: 8,916 km (1992 est.)
Waterways: 260 km navigable year round; additional 730 km
navigable during high-water season
Pipelines: crude oil 275 km
Ports: Champerico, Puerto Barrios, Puerto Quetzal, San Jose, Santo
Tomas de Castilla
Merchant marine: none
Airports:
total: 463
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 5
with paved runways under 914 m: 320
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 9
with unpaved runways 914 to 1 523 m: 124 (1995 est.)
--------------
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: Saint Peter Port, Saint Sampson
Merchant marine: none
Airports:
total: 2
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways:
total: 1,086 km
standard gauge: 279 km 1.435-m gauge
narrow gauge: 807 km 1.000-m gauge; note - includes 662 km in common
carrier service from Kankan to Conakry
Highways:
total: 29,750 km
paved: 4,490 km
unpaved: 25,260 km (1991 est.)
Waterways: 1,295 km navigable by shallow-draft native craft
Ports: Boke, Conakry, Kamsar
Merchant marine: none
Airports:
total: 14
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 1
with unpaved runways 1 524 to 2 437 m: 6
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
--------------
Railways:
total: 88 km
standard gauge: 40 km 1.435-m gauge (dedicated to ore transport)
narrow gauge: 48 km 0.914-m gauge (dedicated to ore transport)
Highways:
total: 7,621 km
paved: 547 km
unpaved: 7,074 km (1987 est.)
Waterways: 6,000 km total of navigable waterways; Berbice,
Demerara, and Essequibo Rivers are navigable by oceangoing vessels
for 150 km, 100 km, and 80 km, respectively
Ports: Bartica, Georgetown, Linden, New Amsterdam, Parika
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 1,317 GRT/2,558 DWT
(1995 est.)
Airports:
total: 47
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 32
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 9 (1995 est.)
--------------
Railways:
total: 40 km (single track; privately owned industrial line)-closed
in early 1990''s
narrow gauge: 40 km 0.760-m gauge
Highways:
total: 3,978 km
paved: 944 km
unpaved: 3,034 km (1987 est.)
Waterways: negligible; less than 100 km navigable
Ports: Cap-Haitien, Gonaives, Jacmel, Jeremie, Cayes, Miragoane,
Port-au-Prince, Port-de-Paix, Saint-Marc
Merchant marine: none
Airports:
total: 11
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 4
with unpaved runways 914 to 1 523 m: 4 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 381.5 km (1991 est.)
paved: NA km
unpaved: NA km
Waterways: none
Ports: Saipan, Tinian
Merchant marine: none
Airports:
total: 5
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 2
with paved runways under 914 m: 1
with unpaved runways 2 438 to 3 047 m: 1 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways:
total: 4,027 km
standard gauge: 4,027 km 1.435-m gauge (2422 km electrified; 96 km
double track) (1995)
Highways:
total: 88,922 km
paved: 61,356 km (including 75 km of expressways)
unpaved: 27,566 km (1990 est.)
Waterways: 1,577 km along west coast; 2.4 m draft vessels maximum
Pipelines: refined products 53 km
Ports: Bergen, Drammen, Flora, Hammerfest, Harstad, Haugesund,
Kristiansand, Larvik, Narvik, Oslo, Porsgrunn, Stavanger, Tromso,
Trondheim
Merchant marine:
total: 712 ships (1,000 GRT or over) totaling 19,278,205
GRT/32,209,679 DWT
ships by type: bulk 114, cargo 98, chemical tanker 83, combination
bulk 10, combination ore/oil 31, container 15, liquefied gas tanker
87, oil tanker 148, passenger 10, passenger-cargo 2, railcar carrier
1, refrigerated cargo 13, roll-on/roll-off cargo 49, short-sea
passenger 21, vehicle carrier 30
note: the government has created an internal register, the Norwegian
International Ship Register (NIS), as a subset of the Norwegian
register; ships on the NIS enjoy many benefits of flags of
convenience and do not have to be crewed by Norwegians (1995 est.)
Airports:
total: 102
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 12
with paved runways 1 524 to 2 437 m: 13
with paved runways 914 to 1 523 m: 11
with paved runways under 914 m: 60
with unpaved runways 914 to 1 523 m: 5 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 25,948 km
paved: 4,930 km (including 413 km of expressways)
unpaved: 21,018 km (1992 est.)
Pipelines: crude oil 1,300 km; natural gas 1,030 km
Ports: Matrah, Mina'' al Fahl, Mina'' Raysut
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 16,306 GRT/8,210 DWT
ships by type: cargo 1, passenger 1, passenger-cargo 1 (1995 est.)
Airports:
total: 129
with paved runways over 3 047 m: 4
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 34
with unpaved runways over 3 047 m: 3
with unpaved runways 2 438 to 3 047 m: 3
with unpaved runways 1 524 to 2 437 m: 57
with unpaved runways 914 to 1 523 m: 26 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Ports: Bangkok (Thailand), Hong Kong, Kao-hsiung (Taiwan), Los
Angeles (US), Manila (Philippines), Pusan (South Korea), San
Francisco (US), Seattle (US), Shanghai (China), Singapore, Sydney
(Australia), Vladivostok (Russia), Wellington (NZ), Yokohama (Japan)
--------------
Railways:
total: 8,163 km
broad gauge: 7,718 km 1.676-m gauge (293 km electrified; 1,037 km
double track)
narrow gauge: 445 km 1.000-m gauge; 661 km less than 1.000-m gauge
(1995 est.)
Highways:
total: 205,304 km
paved: 104,735 km
unpaved: 100,569 km (1995 est.)
Pipelines: crude oil 250 km; petroleum products 885 km; natural
gas 4,044 km (1987)
Ports: Karachi, Port Muhammad bin Qasim
Merchant marine:
total: 24 ships (1,000 GRT or over) totaling 345,606 GRT/560,641 DWT
ships by type: bulk 3, cargo 19, oil tanker 1, passenger-cargo 1
(1995 est.)
Airports:
total: 100
with paved runways over 3 047 m: 12
with paved runways 2 438 to 3 047 m: 19
with paved runways 1 524 to 2 437 m: 25
with paved runways 914 to 1 523 m: 11
with paved runways under 914 m: 18
with unpaved runways 1 524 to 2 437 m: 7
with unpaved runways 914 to 1 523 m: 8 (1995 est.)
Heliports: 6 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 61 km
paved: 36 km
unpaved: 25 km
Ports: Koror
Merchant marine: none
Airports:
total: 3
with paved runways 1 524 to 2 437 m: 1
with unpaved runways 1 524 to 2 437 m: 2 (1995 est.)
--------------
Highways: much of the road and many causeways built during World
War II are unserviceable and overgrown
Ports: West Lagoon
Airports: airstrip has been overgrown by vegetation and is no
longer serviceable
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Panama
------
Map
---
Location: 9 00 N, 80 00 W -- Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between Colombia and','d5dac214e15da74f3cbc29ba3584d994924dc46abb09651810776d0e9a37c1b5','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bfd5f1d99fc55242abf2979ab8705150357206a5bc7034de267ec757de5bea4',1996,'AQ','Antarctica','transportation',184,'--------------
Ports: none; offshore anchorage only
Defense
-------
Defense note: defense is the responsibility of Australia
======================================================================
@Holy See (Vatican City)
-----------------------
Map
---
Location: 41 54 N, 12 27 E -- Southern Europe, an enclave of Rome
(Italy)
Flag
----
Description: two vertical bands of yellow (hoist side) and white
with the crossed keys of Saint Peter and the papal miter centered in
the white band
--------------
Railways:
total: 862 meters; note - connects to Italy''s network at Rome''s
Saint Peter''s station
narrow gauge: 862 meters 1.435-m gauge
Highways: none; all city streets
Ports: none
Airports: none
--------------
Railways:
total: 595 km
narrow gauge: 190 km 1.067-m gauge; 128 km 1.057-m gauge; 277 km
0.914-m gauge
note: in 1993, there was a total of 988 km of track (1995)
Highways:
total: 14,203 km
paved: 2,533 km
unpaved: 11,670 km (1993 est.)
Waterways: 465 km navigable by small craft
Ports: La Ceiba, Puerto Castilla, Puerto Cortes, San Lorenzo,
Tela, Puerto Lempira
Merchant marine:
total: 257 ships (1,000 GRT or over) totaling 769,518 GRT/1,148,423
DWT
ships by type: bulk 29, cargo 165, chemical tanker 2, combination
bulk 1, container 7, liquefied gas tanker 1, livestock carrier 3,
oil tanker 19, passenger 1, passenger-cargo 3, refrigerated cargo
16, roll-on/roll-off cargo 7, short-sea passenger 2, vehicle carrier
1
note: a flag of convenience registry; Russia owns 8 ships, Vietnam
4, North Korea 2, Greece 1, Japan 1, US 1, Iran 1 (1995 est.)
Airports:
total: 111
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 5
with paved runways under 914 m: 79
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 914 to 1 523 m: 21 (1995 est.)
--------------
Railways:
total: 35 km
standard gauge: 35 km 1.435-m gauge
Highways:
total: 1,661 km
paved: 1,661 km
unpaved: 0 km (1994 est.)
Ports: Hong Kong
Merchant marine:
total: 238 ships (1,000 GRT or over) totaling 8,632,224
GRT/14,820,657 DWT
ships by type: bulk 129, cargo 32, chemical tanker 1, combination
bulk 4, combination ore/oil 3, container 39, liquefied gas tanker 3,
multifunction large load carrier 1, oil tanker 17, refrigerated
cargo 5, short-sea passenger 1, vehicle carrier 3
note: a flag of convenience registry; includes ships from 17
countries among which are UK 51, China 11, Belgium 8, South Africa
8, US 8, Japan 7, Bermuda 6, Switzerland 6, Germany 3, and Israel 3
(1995 est.)
Airports:
total: 2
with paved runways over 3 047 m: 1
with paved runways under 914 m: 1 (1995 est.)
note: new international airport to be commissioned in 1997/98
Heliports: 1 (1995 est.)
--------------
Ports: none; offshore anchorage only; note - there is one boat
landing area along the middle of the west coast
Airports: airstrip constructed in 1937 for scheduled refueling
stop on the round-the-world flight of Amelia Earhart and Fred Noonan
- they left Lae, New Guinea, for Howland Island, but were never seen
again; the airstrip is no longer serviceable
Transportation note: Earhart Light is a day beacon near the middle
of the west coast that was partially destroyed during World War II,
but has since been rebuilt; named in memory of famed aviatrix Amelia
Earhart
Defense
-------
Defense note: defense is the responsibility of the US; visited
annually by the US Coast Guard
======================================================================
@Hungary
-------
Map
---
Location: 47 00 N, 20 00 E -- Central Europe, northwest of Romania
Flag
----
Description: three equal horizontal bands of red (top), white, and
green
--------------
Railways:
total: 7,685 km
broad gauge: 35 km 1.524-m gauge
standard gauge: 7,474 km 1.435-m gauge (2,162 km electrified; 1,236
km double track)
narrow gauge: 176 km mostly 0.760-m gauge (1995)
note: Hungry and Austria jointly manage the cross-border
standard-gauge railway between Gyor, Sopron, Ebenfurti, and Vasut, a
distance of about 100 km
Highways:
total: 158,711 km
paved: 69,992 km (including 441 km of expressways)
unpaved: 88,719 km (1992 est.)
Waterways: 1,622 km (1988)
Pipelines: crude oil 1,204 km; natural gas 4,387 km (1991)
Ports: Budapest, Dunaujvaros
Merchant marine:
total: 10 cargo ships (1,000 GRT or over) totaling 46,121 GRT/61,613
DWT (1995 est.)
Airports:
total: 78
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 7
with paved runways 1 524 to 2 437 m: 4
with paved runways under 914 m: 1
with unpaved runways 2 438 to 3 047 m: 7
with unpaved runways 1 524 to 2 437 m: 9
with unpaved runways 914 to 1 523 m: 14
with unpaved runways under 914 m: 34 (1994 est.)
--------------
Railways: 0 km
Highways:
total: 11,373 km
paved: 2,513 km
unpaved: 8,860 km (1992 est.)
Ports: Akureyri, Hornafjordur, Isafjordur, Keflavik, Raufarhofn,
Reykjavik, Seydhisfjordhur, Straumsvik, Vestmannaeyjar
Merchant marine:
total: 6 ships (1,000 GRT or over) totaling 30,025 GRT/40,410 DWT
ships by type: cargo 1, chemical tanker 1, oil tanker 1,
refrigerated cargo 1, roll-on/roll-off cargo 2 (1995 est.)
Airports:
total: 84
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 5
with paved runways under 914 m: 49
with unpaved runways 1 524 to 2 437 m: 4
with unpaved runways 914 to 1 523 m: 22 (1995 est.)
--------------
Railways:
total: 62,462 km (11,793 km electrified; 12,617 km double track)
broad gauge: 37,824 km 1.676-m gauge
narrow gauge: 20,653 km 1.000-m gauge; 3,985 km 0.762-m and 0.610-m
gauge (1995 est.)
Highways:
total: 2.037 million km
paved: 981,834 km
unpaved: 1,055,166 km (1995 est.)
Waterways: 16,180 km; 3,631 km navigable by large vessels
Pipelines: crude oil 3,005 km; petroleum products 2,687 km;
natural gas 1,700 km (1995)
Ports: Calcutta, Cochin, Jawaharal Nehru, Kandla, Madras, Mumbai
(Bombay), Vishakhapatnam
Merchant marine:
total: 310 ships (1,000 GRT or over) totaling 6,787,834
GRT/11,296,222 DWT
ships by type: bulk 133, cargo 65, chemical tanker 10, combination
bulk 2, combination ore/oil 3, container 11, liquefied gas tanker 6,
oil tanker 73, passenger-cargo 5, roll-on/roll-off cargo 1,
short-sea passenger 1 (1995 est.)
Airports:
total: 288
with paved runways over 3 047 m: 11
with paved runways 2 438 to 3 047 m: 48
with paved runways 1 524 to 2 437 m: 59
with paved runways 914 to 1 523 m: 68
with paved runways under 914 m: 62
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 36 (1995 est.)
Heliports: 15 (1995 est.)','4d3f98ebe1219658aff325adb93a38e471ebd79a51b3c4ae5aa54302eacceb49','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13377d262a7cbdfc4dcdf59b9cf4a4a392413cad7048c0bee394227fbb117182',1996,'AF','Afghanistan','transportation',196,'--------------
Railways:
total: 5,093 km
broad gauge: 96 km 1.676-m gauge
standard gauge: 4,997 km 1.432-m gauge (146 km electrified) (1995)
Highways:
total: 140,200 km
paved: 42,700 km
unpaved: 97,500 km (1995 est.)
Waterways: 904 km; the Shatt al Arab is usually navigable by
maritime traffic for about 130 km; channel has been dredged to 3 m
and is in use
Pipelines: crude oil 5,900 km; petroleum products 3,900 km;
natural gas 4,550 km
Ports: Abadan (largely destroyed in fighting during 1980-88 war),
Ahvaz, Bandar Beheshti, Bandar-e ''Abbas, Bandar-e Anzali, Bandar-e
Bushehr, Bandar-e Khomeyni, Bandar-e Mah Shahr, Bandar-e Torkeman,
Jazireh-ye Khark, Jazireh-ye Lavan, Jazireh-ye Sirri, Khorramshahr
(limited operation since November 1992), Now Shahr
Merchant marine:
total: 130 ships (1,000 GRT or over) totaling 2,791,892
GRT/4,891,615 DWT
ships by type: bulk 47, cargo 41, chemical tanker 5, combination
bulk 2, liquefied gas tanker 1, multifunction large-load carrier 1,
oil tanker 19, refrigerated cargo 3, roll-on/roll-off cargo 9,
short-sea passenger 1, specialized tanker 1 (1995 est.)
Airports:
total: 212
with paved runways over 3 047 m: 30
with paved runways 2 438 to 3 047 m: 11
with paved runways 1 524 to 2 437 m: 31
with paved runways 914 to 1 523 m: 17
with paved runways under 914 m: 22
with unpaved runways over 3 047 m: 1
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 10
with unpaved runways 914 to 1 523 m: 88 (1995 est.)
Heliports: 12 (1995 est.)
--------------
Railways:
total: 2,032 km
standard gauge: 2,032 km 1.435-m gauge
Highways:
total: 45,554 km
paved: 38,402 km (including 976 km of expressways)
unpaved: 7,152 km (1989 est.)
Waterways: 1,015 km; Shatt al Arab is usually navigable by
maritime traffic for about 130 km; channel has been dredged to 3
meters and is in use; Tigris and Euphrates Rivers have navigable
sections for shallow-draft watercraft; Shatt al Basrah canal was
navigable by shallow-draft craft before closing in 1991 because of
the Persian Gulf war
Pipelines: crude oil 4,350 km; petroleum products 725 km; natural
gas 1,360 km
Ports: Umm Qasr, Khawr az Zubayr, and Al Basrah have limited
functionality
Merchant marine:
total: 36 ships (1,000 GRT or over) totaling 795,346 GRT/1,432,292
DWT
ships by type: cargo 14, oil tanker 16, passenger 1, passenger-cargo
1, refrigerated cargo 1, roll-on/roll-off cargo 3 (1995 est.)
Airports:
total: 102
with paved runways over 3 047 m: 21
with paved runways 2 438 to 3 047 m: 34
with paved runways 1 524 to 2 437 m: 8
with paved runways 914 to 1 523 m: 6
with paved runways under 914 m: 16
with unpaved runways over 3 047 m: 2
with unpaved runways 2 438 to 3 047 m: 3
with unpaved runways 1 524 to 2 437 m: 3
with unpaved runways 914 to 1 523 m: 9 (1995 est.)
Heliports: 5 (1995 est.)
--------------
Railways:
total: 1,944 km
broad gauge: 1,944 km 1.600-m gauge (37 km electrified; 485 km
double track) (1995)
Highways:
total: 92,327 km
paved: 86,787 km (including 32 km of expressways)
unpaved: 5,540 km (1992 est.)
Waterways: limited for commercial traffic
Pipelines: natural gas 225 km
Ports: Arklow, Cork, Drogheda, Dublin, Foynes, Galway, Limerick,
New Ross, Waterford
Merchant marine:
total: 42 ships (1,000 GRT or over) totaling 129,027 GRT/155,371 DWT
ships by type: bulk 4, cargo 27, chemical tanker 1, container 3, oil
tanker 2, short-sea passenger 3, specialized tanker 2 (1995 est.)
Airports:
total: 40
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 29
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
--------------
Railways:
total: 526 km
standard gauge: 526 km 1.435-m gauge
Highways:
total: 13,461 km
paved: 13,461 km (including 56 km of expressways)
unpaved: 0 km (1992 est.)
Pipelines: crude oil 708 km; petroleum products 290 km; natural
gas 89 km
Ports: Ashdod, Ashqelon, Elat, Hadera, Haifa, Tel Aviv-Yafo
Merchant marine:
total: 28 ships (1,000 GRT or over) totaling 577,747 GRT/701,459 DWT
ships by type: cargo 5, container 20, refrigerated cargo 2,
roll-on/roll-off cargo 1 (1995 est.)
Airports:
total: 50
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 6
with paved runways 1 524 to 2 437 m: 7
with paved runways 914 to 1 523 m: 8
with paved runways under 914 m: 22
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
Heliports: 2 (1995 est.)
--------------
Railways:
total: 18,961 km
standard gauge: 17,981 km 1.435-m gauge; Italian Railways (FS)
operates 16,118 km of the total standard gauge routes (10,560 km
electrified)
narrow gauge: 113 km 1.000-m gauge (113 km electrified); 867 km
0.950-m gauge (144 km electrified)
Highways:
total: 305,388 km (including 45,076 km major roads, 112,111 km
secondary roads, 6,301 km motorways)
paved: 271,674 km
unpaved: 33,714 km (1991 est.)
Waterways: 2,400 km for various types of commercial traffic,
although of limited overall value
Pipelines: crude oil 1,703 km; petroleum products 2,148 km;
natural gas 19,400 km
Ports: Ancona, Augusta, Bari, Cagliari (Sardinia), Catania, Gaeta,
Genoa, La Spezia, Livorno, Naples, Oristano (Sardinia), Palermo
(Sicily), Piombino, Porto Torres (Sardinia), Ravenna, Savona,
Trieste, Venice
Merchant marine:
total: 419 ships (1,000 GRT or over) totaling 5,480,320
GRT/7,919,064 DWT
ships by type: bulk 35, cargo 57, chemical tanker 39, combination
bulk 1, combination ore/oil 3, container 16, liquefied gas tanker
37, multifunction large-load carrier 1, oil tanker 123, passenger 5,
roll-on/roll-off cargo 53, short-sea passenger 31, specialized
tanker 11, vehicle carrier 7 (1995 est.)
Airports:
total: 132
with paved runways over 3 047 m: 5
with paved runways 2 438 to 3 047 m: 34
with paved runways 1 524 to 2 437 m: 15
with paved runways 914 to 1 523 m: 24
with paved runways under 914 m: 32
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 20 (1995 est.)
Heliports: 2 (1995 est.)
--------------
Railways:
total: 272 km
standard gauge: 272 km 1.435-m gauge; note - 207 km belonging to the
Jamaica Railway Corporation which were in common carrier service are
no longer operational; the remaining track is privately owned and
used to transport bauxite
Highways:
total: 18,094 km
paved: 12,528 km
unpaved: 5,566 km (1988 est.)
Pipelines: petroleum products 10 km
Ports: Alligator Pond, Discovery Bay, Kingston, Montego Bay, Ocho
Rios, Port Antonio, Longs Wharf, Rocky Point
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 3,435 GRT/6,105 DWT
ships by type: oil tanker 1, roll-on/roll-off cargo 1 (1995 est.)
Airports:
total: 27
with paved runways 2 438 to 3 047 m: 2
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 21
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: none; offshore anchorage only
Airports:
total: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways:
total: 26,506 km
standard gauge: 3,233 km 1.435-m gauge (entirely electrified)
narrow gauge: 72 km 1.372-m gauge (72 km electrified); 23,154 km
1.067-m gauge (13,835 km electrified); 47 km 0.762-m gauge (47 km
electrified) (1994)
Highways:
total: 1,112,844 km
paved: 790,119 km (including 5,054 km of expressways)
unpaved: 322,725 km (1992 est.)
Waterways: about 1,770 km; seagoing craft ply all coastal inland
seas
Pipelines: crude oil 84 km; petroleum products 322 km; natural gas
1,800 km
Ports: Akita, Amagasaki, Chiba, Hachinohe, Hakodate,
Higashi-Harima, Himeji, Hiroshima, Kawasaki, Kinuura, Kobe, Kushiro,
Mizushima, Moji, Nagoya, Osaka, Sakai, Sakaide, Shimizu, Tokyo,
Tomakomai
Merchant marine:
total: 796 ships (1,000 GRT or over) totaling 15,944,137
GRT/23,662,930 DWT
ships by type: bulk 192, cargo 57, chemical tanker 6, combination
bulk 2, combination ore/oil 6, container 38, liquefied gas tanker
39, oil tanker 259, passenger 9, passenger-cargo 3, refrigerated
cargo 35, roll-on/roll-off cargo 43, short-sea passenger 28,
specialized tanker 2, vehicle carrier 77
note: Japan owns an additional 1,587 ships (1,000 GRT or over)
totaling 50,072,815 DWT operating under the registries of Panama,
Liberia, Vanuatu, The Bahamas, Singapore, Cyprus, Philippines, Hong
Kong, and Malta (1995 est.)
Airports:
total: 164
with paved runways over 3 047 m: 6
with paved runways 2 438 to 3 047 m: 32
with paved runways 1 524 to 2 437 m: 34
with paved runways 914 to 1 523 m: 30
with paved runways under 914 m: 60
with unpaved runways 914 to 1 523 m: 2 (1995 est.)
Heliports: 11 (1995 est.)
--------------
Ports: none; offshore anchorage only; note - there is one boat
landing area in the middle of the west coast and another near the
southwest corner of the island
Transportation note: there is a day beacon near the middle of the
west coast
Defense
-------
Defense note: defense is the responsibility of the US; visited
annually by the US Coast Guard
======================================================================
@Jersey
------
(British crown dependency)
Map
---
Location: 49 15 N, 2 10 W -- Western Europe, island in the English
Channel, northwest of France
Flag
----
Description: white with the diagonal red cross of Saint Patrick
(patron saint of Ireland) extending to the corners of the flag
--------------
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: Gorey, Saint Aubin, Saint Helier
Merchant marine: none
Airports:
total: 1
with paved runways 1 524 to 2 437 m: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: Johnston Island
Airports:
total: 1
with paved runways 2 438 to 3 047 m: 1 (1995 est.)
--------------
Railways:
total: 676 km
narrow gauge: 676 km 1.050-m gauge; note - an additional 110 km
stretch of the old Hedjaz railroad is out of use
Highways:
total: 5,680 km
paved: 5,680 km (including 1,712 km of expressways)
unpaved: 0 km (1991 est.)
Pipelines: crude oil 209 km
Ports: Al''Aqabah
Merchant marine:
total: 3 bulk ships (1,000 GRT or over) totaling 41,960 GRT/67,515
DWT (1995 est.)
Airports:
total: 14
with paved runways over 3 047 m: 10
with paved runways 2 438 to 3 047 m: 3
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways:
total: NA km; short line going to a jetty
Ports: none; offshore anchorage only
Airports:
total: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
Defense
-------
Defense note: defense is the responsibility of France
======================================================================
@Kazakstan
---------
Map
---
Location: 48 00 N, 68 00 E -- Central Asia, northwest of China
Flag
----
Description: sky blue background representing the endless sky and
a gold sun with 32 rays soaring above a golden steppe eagle in the
center; on the hoist side is a "national ornamentation" in yellow
--------------
Railways:
total: 13,841 km in common carrier service; does not include
industrial lines
broad gauge: 13,841 km 1.520-m gauge (3,299 km electrified) (1992)
Highways:
total: 87,873 km public roads
paved: 82,568 km
unpaved: 5,305 km (1994)
Waterways: 4,002 km on the Syrdariya River and Ertis River
Pipelines: crude oil 2,850 km; refined products 1,500 km; natural
gas 3,480 km (1992)
Ports: Aqtau (Shevchenko), Atyrau (Gur''yev), Oskemen
(Ust-Kamenogorsk), Pavlodar, Semey (Semipalatinsk)
Airports:
total: 352
with paved runways over 3 047 m: 7
with paved runways 2 438 to 3 047 m: 23
with paved runways 1 524 to 2 437 m: 11
with paved runways 914 to 1 523 m: 5
with paved runways under 914 m: 9
with unpaved runways over 3 047 m: 9
with unpaved runways 2 438 to 3 047 m: 8
with unpaved runways 1 524 to 2 437 m: 25
with unpaved runways 914 to 1 523 m: 65
with unpaved runways under 914 m: 190 (1994 est.)
--------------
Railways:
total: 2,652 km
narrow gauge: 2,652 km 1.000-m gauge
Highways:
total: 62,573 km
paved: 8,322 km
unpaved: 54,251 km (1991 est.)
Waterways: part of Lake Victoria system is within boundaries of
======================================================================
@Kingman Reef
------------
(territory of the US)
Map
---
Location: 6 24 N, 162 24 W -- Oceania, reef in the North Pacific
Ocean, about one-half of the way from Hawaii to American Samoa
Flag
----
Description: the flag of the US is used
--------------
Ports: none; offshore anchorage only
Airports: lagoon was used as a halfway station between Hawaii and
American Samoa by Pan American Airways for flying boats in 1937 and
1938
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Kiribati
--------
Map
---
Location: 1 25 N, 173 00 E -- Oceania, group of islands in the
Pacific Ocean, straddling the equator and the International Date
Line, about one-half of the way from Hawaii to Australia
Flag
----
Description: the upper half is red with a yellow frigate bird
flying over a yellow rising sun, and the lower half is blue with
three horizontal wavy white stripes to represent the ocean
--------------
Railways: 0 km
Highways:
total: 640 km (1987 est.)
paved: NA km
unpaved: NA km
Waterways: small network of canals, totaling 5 km, in Line Islands
Ports: Banaba, Betio, English Harbor, Kanton
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 3,248 GRT/4,496 DWT
ships by type: oil tanker 1, short-sea passenger 1 (1995 est.)
Airports:
total: 20
with paved runways 1 524 to 2 437 m: 4
with paved runways under 914 m: 5
with unpaved runways 914 to 1 523 m: 11 (1995 est.)
--------------
Railways:
total: 4,915 km
standard gauge: 4,250 km 1.435-m gauge (3,397 km electrified; 159 km
double track)
narrow gauge: 665 km 0.762-m gauge (1989)
Highways:
total: 30,000 km
paved: 4,500 km
unpaved: 25,500 km
Waterways: 2,253 km; mostly navigable by small craft only
Pipelines: crude oil 37 km
Ports: Ch''ongjin, Haeju, Hungnam (Hamhung), Kimch''aek, Kosong,
Najin, Namp''o, Sinuiju, Songnim, Sonbong (formerly Unggi), Ungsang,
Wonsan
Merchant marine:
total: 88 ships (1,000 GRT or over) totaling 712,480 GRT/1,140,923
DWT
ships by type: bulk 9, cargo 71, combination bulk 1, oil tanker 3,
passenger 2, passenger-cargo 1, short-sea passenger 1
note: North Korea owns an additional 4 ships (1,000 GRT or over)
totaling approximately 34,782 DWT operating under the registries of
Hondurus and Poland (1995 est.)
Airports:
total: 49
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 15
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 2
with unpaved runways 2 438 to 3 047 m: 4
with unpaved runways 1 524 to 2 437 m: 5
with unpaved runways 914 to 1 523 m: 12
with unpaved runways under 914 m: 6 (1994 est.)
--------------
Railways:
total: 3,101 km
standard gauge: 3,081 km 1.435-m gauge (560 km electrified)
narrow gauge: 20 km 0.762-m gauge
Highways:
total: 61,296 km
paved: 51,918 km (including 1,550 km of expressways)
unpaved: 9,378 km (1993)
Waterways: 1,609 km; use restricted to small native craft
Pipelines: petroleum products 455 km
Ports: Chinhae, Inch''on, Kunsan, Masan, Mokp''o, Pohang, Pusan,
Ulsan, Yosu
Merchant marine:
total: 428 ships (1,000 GRT or over) totaling 6,076,981
GRT/9,822,089 DWT
ships by type: bulk 124, cargo 122, chemical tanker 21, combination
bulk 3, combination ore/oil 1, container 59, liquefied gas tanker
12, multifunction large-load carrier 1, oil tanker 61, refrigerated
cargo 13, short-sea passenger 1, vehicle carrier 10
note: South Korea owns an additional 231 ships (1,000 GRT or over)
totaling 10,128,506 DWT operating under the registries of Panama,
Liberia, Cyprus, Malta, The Bahamas, and Thailand (1995 est.)
Airports:
total: 105
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 20
with paved runways 1 524 to 2 437 m: 13
with paved runways 914 to 1 523 m: 14
with paved runways under 914 m: 54
with unpaved runways 914 to 1 523 m: 3 (1995 est.)
Heliports: 201 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 4,273 km
paved: NA km (including 280 km of expressways) (1989 est.)
unpaved: NA km
Pipelines: crude oil 877 km; petroleum products 40 km; natural gas
165 km
Ports: Ash Shu''aybah, Ash Shuwaykh, Kuwait, Mina'' ''Abd Allah,
Mina'' al Ahmadi, Mina'' Su''ud
Merchant marine:
total: 46 ships (1,000 GRT or over) totaling 2,053,667 GRT/3,242,305
DWT
ships by type: cargo 10, container 3, liquefied gas tanker 7,
livestock carrier 4, oil tanker 21, vehicle carrier 1 (1995 est.)
Airports:
total: 4
with paved runways over 3 047 m: 3
with paved runways 2 438 to 3 047 m: 1 (1995 est.)
Heliports: 1 (1995 est.)','7d8c5f0fb122dbece6e40e1f7f7b5f1bed39bb4bbd5b9ac3e66a0bf0bb6cc656','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53431bb53758d7c023264b5bd9d00391c275c29967c62d7e3ecd1bcfab863c0d',1996,'DE','Germany','transportation',199,'--------------
Railways:
total: 370 km in common carrier service; does not include industrial
lines
broad gauge: 370 km 1.520-m gauge (1990)
Highways:
total: 28,400 km
paved: 22,400 km
unpaved: 6,000 km (1990)
Pipelines: natural gas 200 km
Ports: Balykchy (Ysyk-Kol or Rybach''ye)
Airports:
total: 54
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 9
with paved runways under 914 m: 1
with unpaved runways 1 524 to 2 437 m: 4
with unpaved runways 914 to 1 523 m: 4
with unpaved runways under 914 m: 32 (1994 est.)
--------------
Railways: 0 km
Highways:
total: 90 km
paved: 42 km
unpaved: 48 km (1987 est.)
Ports: Macau
Merchant marine: none
Airports: new international airport completed in 1995; 1 seaplane
station','59576e9d713911c8f10dcc0e59d9805909ebdc8b0f8ba0095bf28c40f2a2295a','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3879b05367c62612063f74a0d53108a8cd60038a6a44b59c625147f48199700',1996,'TH','Thailand','transportation',207,'--------------
Railways: 0 km
Highways:
total: 14,130 km
paved: 2,261 km
unpaved: 11,869 km (1992 est.)
Waterways: about 4,587 km, primarily Mekong and tributaries; 2,897
additional kilometers are sectionally navigable by craft drawing
less than 0.5 m
Pipelines: petroleum products 136 km
Ports: none
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 2,370 GRT/3,000 DWT
(1995 est.)
Airports:
total: 39
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 5
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 16
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 13 (1995 est.)
--------------
Railways:
total: 2,412 km
broad gauge: 2,379 km 1.520-m gauge (271 km electrified) (1992)
narrow gauge: 33 km 0.750-m gauge (1994)
Highways:
total: 66,718 km
paved: 12,076 km
unpaved: 54,642 km (1992 est.)
Waterways: 300 km perennially navigable
Pipelines: crude oil 750 km; refined products 780 km; natural gas
560 km (1992)
Ports: Daugavpils, Liepaja, Riga, Ventspils
Merchant marine:
total: 56 ships (1,000 GRT or over) totaling 519,859 GRT/678,987 DWT
ships by type: cargo 7, oil tanker 24, refrigerated cargo 18,
roll-on/roll-off cargo 7 (1995 est.)
Airports:
total: 50
with paved runways 2 438 to 3 047 m: 6
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 27
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 914 to 1 523 m: 2
with unpaved runways under 914 m: 10 (1994 est.)
--------------
Railways:
total: 222 km
standard gauge: 222 km 1.435-m (from Beirut to the Syrian border)
Highways:
total: 7,370 km
paved: 6,265 km
unpaved: 1,105 km (1990 est.)
Pipelines: crude oil 72 km (none in operation)
Ports: Al Batrun, Al Mina, An Naqurah, Antilyas, Az Zahrani,
Beirut, Jubayl, Juniyah, Shikka, Sidon, Tripoli, Tyre
Merchant marine:
total: 58 ships (1,000 GRT or over) totaling 192,075 GRT/296,256 DWT
ships by type: bulk 4, cargo 39, chemical tanker 1, combination bulk
1, combination ore/oil 1, container 2, livestock carrier 4,
refrigerated cargo 1, roll-on/roll-off cargo 2, specialized tanker
1, vehicle carrier 2 (1995 est.)
Airports:
total: 7
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 2
with unpaved runways 914 to 1 523 m: 1 (1995 est.)','5c9e02812f9a814730ef145f62a37d0e871fcbdb272f97d47f0e195995d9389d','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97ce204fa459bb5160ea9ed9794863bdaacf7d26360361064100bdd3be51613f',1996,'ZA','South Africa','transportation',209,'--------------
Railways:
total: 2.6 km; note - owned by, operated by, and included in the
statistics of South Africa
narrow gauge: 2.6 km 1.067-m gauge
Highways:
total: 5,324 km
paved: 799 km
unpaved: 4,525 km (1993 est.)
Ports: none
Airports:
total: 29
with paved runways over 3 047 m: 1
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 23
with unpaved runways 914 to 1 523 m: 4 (1995 est.)
--------------
Railways:
total: 490 km (single track); note - three rail systems owned and
operated by foreign steel and financial interests in conjunction
with Liberian Government; one of these, the Lamco Railroad, closed
in 1989 after iron ore production ceased; the other two have been
shut down by the civil war
standard gauge: 345 km 1.435-m gauge
narrow gauge: 145 km 1.067-m gauge
Highways:
total: 10,029 km
paved: 600 km
unpaved: 9,429 km (1987 est.)
Ports: Buchanan, Greenville, Harper, Monrovia
Merchant marine:
total: 1,601 ships (1,000 GRT or over) totaling 59,449,296
GRT/98,819,081 DWT
ships by type: barge carrier 2, bulk 411, cargo 121, chemical tanker
108, combination bulk 28, combination ore/oil 56, container 143,
liquefied gas tanker 77, multifunction large-load carrier 1, oil
tanker 463, passenger 42, passenger-cargo 1, refrigerated cargo 64,
roll-on/roll-off cargo 23, short-sea passenger 4, specialized tanker
9, vehicle carrier 48
note: a flag of convenience registry; includes ships from 59
countries among which are US 253, Japan 172, Norway 165, Germany
149, Greece 137, Hong Kong 114, UK 78, China 49, Monaco 41, and
Cyprus 34 (1995 est.)
Airports:
total: 39
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 29
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 6 (1995 est.)
--------------
Railways:
note: Libya has had no railroad in operation since 1965, all
previous systems having been dismantled; current plans are to
construct a 1.435-m standard gauge line from the Tunisian frontier
to Tripoli and Misratah, then inland to Sabha, center of a
mineral-rich area, but there has been no progress; other plans made
jointly with Egypt would establish a rail line from As Sallum,
Egypt, to Tobruk with completion set for mid-1994; no progress has
been reported
Highways:
total: 19,189 km
paved: 10,738 km
unpaved: 8,451 km (1987 est.)
Waterways: none
Pipelines: crude oil 4,383 km; petroleum products 443 km (includes
liquefied petroleum gas 256 km); natural gas 1,947 km
Ports: Al Khums, Banghazi, Darnah, Marsa al Burayqah, Misratah,
Ra''s Lanuf, Tobruk, Tripoli, Zuwarah
Merchant marine:
total: 30 ships (1,000 GRT or over) totaling 686,834 GRT/1,209,263
DWT
ships by type: cargo 10, chemical tanker 1, liquefied gas tanker 2,
oil tanker 10, roll-on/roll-off cargo 3, short-sea passenger 4
note: Libya owns an additional 6 ships (1,000 GRT or over) totaling
38,260 DWT operating under the registries of Algeria and Turkey
(1995 est.)
Airports:
total: 130
with paved runways over 3 047 m: 24
with paved runways 2 438 to 3 047 m: 5
with paved runways 1 524 to 2 437 m: 22
with paved runways 914 to 1 523 m: 6
with paved runways under 914 m: 13
with unpaved runways over 3 047 m: 4
with unpaved runways 2 438 to 3 047 m: 3
with unpaved runways 1 524 to 2 437 m: 15
with unpaved runways 914 to 1 523 m: 38 (1995 est.)','c25f12270a15bd9ab128810a7c35621a2d9fc34130b5f7462562a001e5f5d2d6','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab256968c952e1e7f8ba760ad2f1782639822ec86fe389cbcf6ddb6086e2237a',1996,'CH','Switzerland','transportation',221,'--------------
Railways:
total: 18.5 km; note - owned, operated, and included in statistics
of Austrian Federal Railways
standard gauge: 18.5 km 1.435-m gauge (electrified)
Highways:
total: 238 km
paved: 238 km
unpaved: 0 km (1986 est.)
Ports: none
Airports: none
--------------
Railways:
total: 2,002 km
broad gauge: 2,002 km 1.524-m gauge (122 km electrified) (1994)
Highways:
total: 55,603 km
paved: 42,209 km (including 382 km of expressways)
unpaved: 13,394 km (1994)
Waterways: 600 km perennially navigable
Pipelines: crude oil, 105 km; natural gas 760 km (1992)
Ports: Kaunas, Klaipeda
Merchant marine:
total: 43 ships (1,000 GRT or over) totaling 264,639 GRT/303,649 DWT
ships by type: cargo 26, combination bulk 11, oil tanker 2, railcar
carrier 1, roll-on/roll-off cargo 1, short-sea passenger 2 (1995
est.)
Airports:
total: 96
with paved runways over 3 047 m: 3
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 4
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 14
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 6
with unpaved runways under 914 m: 63 (1994 est.)','acfd8d836f085f768bfeeab1e25a9cb9729cf2f59612afdb77dfd18ca58b1a7f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9289bc8fd88eae6e2cede8053a82013a389cb22af2a14558eaddeb9c3f719faf',1996,'BG','Bulgaria','transportation',227,'--------------
Railways:
total: 699 km
standard gauge: 699 km 1.435-m gauge (232 km electrified) (1995)
Highways:
total: 10,591 km
paved: 5,091 km
unpaved: 5,500 km (1991 est.)
Waterways: none, lake transport only
Pipelines: none
Ports: none
Airports:
total: 16
with paved runways 2 438 to 3 047 m: 2
with paved runways under 914 m: 12
with unpaved runways 914 to 1 523 m: 2 (1995 est.)','5dd90e4a5d7bb1d1907d854cef0f6b545b1331200949cd2e382bb9a065b729d8','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87e7a596a9b05b7aebfc9900cc8f834c4b44a85e92d06c318e887138f6c404ba',1996,'MZ','Mozambique','transportation',234,'--------------
Railways:
total: 883 km
narrow gauge: 883 km 1.000-m gauge (1994)
Highways:
total: 34,750 km
paved: 5,352 km
unpaved: 29,398 km (1991 est.)
Waterways: of local importance only; isolated streams and small
portions of Canal des Pangalanes
Ports: Antsiranana, Antsohimbondrona, Mahajanga, Toamasina,
Toliaria
Merchant marine:
total: 11 ships (1,000 GRT or over) totaling 22,132 GRT/31,261 DWT
ships by type: cargo 5, chemical tanker 1, liquefied gas tanker 1,
oil tanker 2, roll-on/roll-off cargo 2 (1995 est.)
Airports:
total: 105
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 21
with paved runways under 914 m: 31
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 45 (1995 est.)
--------------
Railways:
total: 789 km
narrow gauge: 789 km 1.067-m gauge
Highways:
total: 27,294 km (1990 est.)
paved: NA km
unpaved: NA km
Waterways: Lake Nyasa (Lake Malawi); Shire River, 144 km
Ports: Chipoka, Monkey Bay, Nkhata Bay, Nkhotakota
Airports:
total: 41
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 4
with paved runways under 914 m: 20
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 14 (1995 est.)
--------------
Railways:
total: 1,806 km (Peninsular Malaysia 1,672 km; Sabah 134 km; Sarawak
0 km)
narrow gauge: 1,806 km 1.000-m gauge (Peninsular Malaysia 1,672 km;
Sabah 134 km)
Highways:
total: 92,545 km
paved: 69,409 km (including 574 km of expressways)
unpaved: 23,136 km (1992 est.)
Waterways:
Peninsular Malaysia: 3,209 km
Sabah: 1,569 km
Sarawak: 2,518 km
Pipelines: crude oil 1,307 km; natural gas 379 km
Ports: Kota Kinabalu, Kuantan, Kuching, Kudat, Lahad Datu, Labuan,
Lumut, Miri, Pasir Gudang, Penang, Port Dickson, Port Kelang,
Sandakan, Sibu, Tanjong Berhala, Tanjong Kidurong, Tawau
Merchant marine:
total: 248 ships (1,000 GRT or over) totaling 3,035,684
GRT/4,494,476 DWT
ships by type: bulk 43, cargo 83, chemical tanker 13, container 31,
liquefied gas tanker 12, livestock carrier 1, oil tanker 55,
roll-on/roll-off cargo 5, short-sea passenger 1, vehicle carrier 4
(1995 est.)
Airports:
total: 105
with paved runways over 3 047 m: 3
with paved runways 2 438 to 3 047 m: 5
with paved runways 1 524 to 2 437 m: 11
with paved runways 914 to 1 523 m: 6
with paved runways under 914 m: 74
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 5 (1995 est.)
Heliports: 2 (1995 est.)','207d18e7e1e1297eb2e22d4f8cf39f229fa900c3f9b50ca184ce4f2bc76c9bbd','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9a04bc34bb4fd603781b72750bad3afb9dc16a36fab9c41ea84c7d8f1d21e45',1996,'PG','Papua New Guinea','transportation',242,'--------------
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: paved roads on major islands (Majuro, Kwajalein), otherwise
stone-, coral-, or laterite-surfaced roads and tracks
Ports: Majuro
Merchant marine:
total: 78 ships (1,000 GRT or over) totaling 3,068,782 GRT/5,073,125
DWT
ships by type: bulk carrier 43, cargo 4, combination ore/oil 1,
container 17, oil tanker 11, refrigerated cargo 1, vehicle carrier 1
(1995 est.)
Airports:
total: 16
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 5
with unpaved runways 914 to 1 523 m: 7 (1995 est.)','29b1f04d354a2c63cc892ac8d67fcd1729fa2dfdd9ea188fc6e5abae22677072','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f086ae5e236d3338961ee9daf37a9c8893eeb5fbc491a9fa8a1531c34ba5a320',1996,'MG','Madagascar','transportation',250,'--------------
Railways: 0 km
Highways:
total: 1,831 km
paved: 1,703 km (including 29 km of expressways)
unpaved: 128 km (1991 est.)
Ports: Port Louis
Merchant marine:
total: 17 ships (1,000 GRT or over) totaling 221,446 GRT/308,478 DWT
ships by type: bulk 1, cargo 9, container 4, liquefied gas tanker 1,
oil tanker 1, passenger-cargo 1 (1995 est.)
Airports:
total: 4
with paved runways 2 438 to 3 047 m: 1
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 2 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 93 km
paved: 72 km
unpaved: 21 km
Ports: Dzaoudzi
Merchant marine: none
Airports:
total: 1
with paved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways:
total: 20,567 km
standard gauge: 20,477 km 1.435-m gauge (246 km electrified)
narrow gauge: 90 km 0.914-m gauge (1994)
Highways:
total: 245,433 km
paved: 88,601 km (including 4,286 km of expressways)
unpaved: 156,832 km (1993 est.)
Waterways: 2,900 km navigable rivers and coastal canals
Pipelines: crude oil 28,200 km; petroleum products 10,150 km;
natural gas 13,254 km; petrochemical 1,400 km
Ports: Acapulco, Altamira, Coatzacoalcos, Ensenada, Guaymas, La
Paz, Lazaro Cardenas, Manzanillo, Mazatlan, Progreso, Salina Cruz,
Tampico, Topolobampo, Tuxpan, Veracruz
Merchant marine:
total: 51 ships (1,000 GRT or over) totaling 875,314 GRT/1,245,932
DWT
ships by type: cargo 1, chemical tanker 4, container 4, liquefied
gas tanker 7, oil tanker 29, refrigerated cargo 1, roll-on/roll-off
cargo 2, short-sea passenger 3 (1995 est.)
Airports:
total: 1,411
with paved runways over 3 047 m: 9
with paved runways 2 438 to 3 047 m: 25
with paved runways 1 524 to 2 437 m: 88
with paved runways 914 to 1 523 m: 66
with paved runways under 914 m: 815
with unpaved runways 1 524 to 2 437 m: 50
with unpaved runways 914 to 1 523 m: 358 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 2,784 km
paved: 2,187 km
unpaved: 597 km (1987 est.)
Ports: Le Port, Pointe des Galets
Merchant marine: none
Airports:
total: 2
with paved runways 2 438 to 3 047 m: 1
with paved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways:
total: 11,374 km
broad gauge: 60 km 1.524-m gauge
standard gauge: 10,887 km 1.435-m gauge (3,866 km electrified; 3,060
km double track)
narrow gauge: 427 km 0.760-m gauge (1994)
Highways:
total: 153,014 km
paved: 78,037 km (including 113 km of expressways)
unpaved: 74,977 km (1992 est.)
Waterways: 1,724 km (1984)
Pipelines: crude oil 2,800 km; petroleum products 1,429 km;
natural gas 6,400 km (1992)
Ports: Braila, Constanta, Galatz, Mangalia, Sulina, Tulcea
Merchant marine:
total: 233 ships (1,000 GRT or over) totaling 2,425,729
GRT/3,641,741 DWT
ships by type: bulk 39, cargo 166, container 2, oil tanker 13,
passenger 1, passenger-cargo 1, railcar carrier 2, roll-on/roll-off
cargo 9
note: Romania owns an additional 15 ships (1,000 GRT or over)
totaling 1,078,490 DWT operating under the registries of Liberia,
Malta, Cyprus, and The Bahamas (1995 est.)
Airports:
total: 156
with paved runways over 3 047 m: 4
with paved runways 2 438 to 3 047 m: 9
with paved runways 1 524 to 2 437 m: 14
with unpaved runways 2 438 to 3 047 m: 3
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 17
with unpaved runways under 914 m: 108 (1994 est.)
--------------
Railways:
total: 154,000 km; note - 87,000 km in common carrier service
(38,000 km electrified); 67,000 km serve specific industries and are
not available for common carrier use
broad gauge: 154,000 km 1.520-m gauge (1 January 1994)
Highways:
total: 934,000 km (including 445,000 km which serve specific
industries or farms and are not available for common carrier use)
paved: NA km
unpaved: NA km (1994 est.)
Waterways: total navigable routes in general use 101,000 km;
routes with navigation guides serving the Russian River Fleet 95,900
km; routes with night navigational aids 60,400 km; man-made
navigable routes 16,900 km (1 January 1994)
Pipelines: crude oil 48,000 km; petroleum products 15,000 km;
natural gas 140,000 km (30 June 1993)
Ports: Arkhangel''sk, Astrakhan'', Kaliningrad, Kazan'', Khabarovsk,
Kholmsk, Krasnoyarsk, Moscow, Murmansk, Nakhodka, Nevel''sk,
Novorossiysk, Petropavlovsk, St. Petersburg, Rostov, Sochi, Tuapse,
Vladivostok, Volgograd, Vostochnyy, Vyborg
Merchant marine:
total: 745 ships (1,000 GRT or over) totaling 6,730,178
GRT/9,385,565 DWT
ships by type: barge carrier 2, bulk 25, cargo 406, chemical tanker
6, combination bulk 21, combination ore/oil 17, container 31,
multifunction large-load carrier 3, oil tanker 134, passenger 4,
passenger-cargo 5, refrigerated cargo 19, roll-on/roll-off cargo 54,
short-sea passenger 16, specialized tanker 2
note: Russia owns an additional 163 ships (1,000 GRT or over)
totaling 2,276,829 DWT operating under the registries of Malta,
Cyprus, Liberia, Panama, Saint Vincent and the Grenadines, Honduras,
The Bahamas, and Vanuatu (1995 est.)
Airports:
total: 2,517
with paved runways over 3 047 m: 54
with paved runways 2 438 to 3 047 m: 202
with paved runways 1 524 to 2 437 m: 108
with paved runways 914 to 1 523 m: 115
with paved runways under 914 m: 151
with unpaved runways over 3 047 m: 25
with unpaved runways 2 438 to 3 047 m: 45
with unpaved runways 1 524 to 2 437 m: 134
with unpaved runways 914 to 1 523 m: 291
with unpaved runways under 914 m: 1,392 (1994 est.)
--------------
Railways: 0 km
Highways:
total: 13,173 km
paved: 1,186 km
unpaved: 11,987 km (1990 est.)
Waterways: Lac Kivu navigable by shallow-draft barges and native
craft
Ports: Cyangugu, Gisenyi, Kibuye
Airports:
total: 7
with paved runways over 3 047 m: 1
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 3
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: NA km (mainland 118 km, Ascension NA km, Tristan da Cunha NA
km)
paved: 180.7 km (mainland 98 km, Ascension 80 km, Tristan da Cunha
2.70 km)
unpaved: NA km (mainland 20 km, Ascension NA km, Tristan da Cunha NA
km)
Ports: Georgetown, Jamestown
Merchant marine: none
Airports:
total: 1
with paved runways over 3 047 m: 1 (1995 est.)
--------------
Railways:
total: 58 km
narrow gauge: 58 km 0.762-m gauge on Saint Kitts to serve sugarcane
plantations (1995)
Highways:
total: 300 km
paved: 125 km
unpaved: 175 km
Ports: Basseterre, Charlestown
Merchant marine: none
Airports:
total: 2
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 1 (1995 est.)','c3fedb334f90d6bea2658073febfd223fdf5ea421a646f0ea3ddef2e7f486f0d','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6456bd248618dd52b2b7ef1116fed2a961e528d36a6c0c8b37fa637cb8579c0d',1996,'ID','Indonesia','transportation',254,'--------------
Railways: 0 km
Highways:
total: 226 km
paved: 39 km
unpaved: 187 km
Ports: Colonia (Yap), Kolonia (Pohnpei), Lele, Moen
Merchant marine: none
Airports:
total: 5
with paved runways 1 524 to 2 437 m: 4
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 32 km
paved: NA km
unpaved: NA km
Pipelines: 7.8 km
Ports: Sand Island
Airports:
total: 2
with paved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways:
total: 1,328 km
broad gauge: 1,328 km 1.520-m gauge (1992)
Highways:
total: 14,508 km
paved: 12,346 km
unpaved: 2,162 km (1992 est.)
Waterways: 424 km (1994)
Pipelines: natural gas 310 km (1992)
Ports: none
Airports:
total: 26
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 2
with paved runways under 914 m: 3
with unpaved runways 2 438 to 3 047 m: 3
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 5
with unpaved runways under 914 m: 8 (1994 est.)
--------------
Railways:
total: 1,928 km
broad gauge: 1,928 km 1.524-m gauge (1994)
Highways:
total: 46,700 km
paved: 1,000 km
unpaved: 45,700 km (1988 est.)
Waterways: 397 km of principal routes (1988)
Ports: none
Airports:
total: 34
with paved runways 2 438 to 3 047 m: 7
with paved runways under 914 m: 1
with unpaved runways over 3 047 m: 3
with unpaved runways 2 438 to 3 047 m: 5
with unpaved runways 1 524 to 2 437 m: 10
with unpaved runways 914 to 1 523 m: 3
with unpaved runways under 914 m: 5 (1994 est.)','c358c38f2fdf46e65bfa882ea18365e3608464181ad44f0ae356da3cab00e2c8','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0523510b59993b748cc695a5d133c27b5dd9aa0d00272ba6bcee8a292d04f94d',1996,'EH','Western Sahara','transportation',262,'--------------
Railways:
total: 1,907 km
standard gauge: 1,907 km 1.435-m gauge (1003 km electrified; 246 km
double track) (1994)
Highways:
total: 59,474 km
paved: 29,440 km (including 73 km of expressways)
unpaved: 30,034 km (1991 est.)
Pipelines: crude oil 362 km; petroleum products 491 km
(abandoned); natural gas 241 km
Ports: Agadir, Al Jadida, Casablanca, El Jorf Lasfar, Kenitra,
Mohammedia, Nador, Rabat, Safi, Tangier; also Spanish-controlled
Ceuta and Melilla
Merchant marine:
total: 37 ships (1,000 GRT or over) totaling 175,962 GRT/257,449 DWT
ships by type: cargo 8, chemical tanker 7, container 2, oil tanker
4, refrigerated cargo 9, roll-on/roll-off cargo 6, short-sea
passenger 1 (1995 est.)
Airports:
total: 63
with paved runways over 3 047 m: 11
with paved runways 2 438 to 3 047 m: 4
with paved runways 1 524 to 2 437 m: 7
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 12
with unpaved runways 2 438 to 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 11
with unpaved runways 914 to 1 523 m: 15 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways:
total: 3,131 km
narrow gauge: 2,988 km 1.067-m gauge; 143 km 0.762-m gauge (1994)
Highways:
total: 27,287 km
paved: 4,693 km
unpaved: 22,594 km (1991 est.)
note: highway traffic impeded by land mines not removed at end of
civil war
Waterways: about 3,750 km of navigable routes
Pipelines: crude oil (not operating) 306 km; petroleum products
289 km
Ports: Beira, Inhambane, Maputo, Nacala, Pemba
Merchant marine:
total: 4 cargo ships (1,000 GRT or over) totaling 5,694 GRT/9,724
DWT (1995 est.)
Airports:
total: 131
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 4
with paved runways 1 524 to 2 437 m: 10
with paved runways 914 to 1 523 m: 5
with paved runways under 914 m: 67
with unpaved runways 1 524 to 2 437 m: 12
with unpaved runways 914 to 1 523 m: 32 (1995 est.)
--------------
Railways:
total: 2,382 km (1995)
narrow gauge: 2,382 km 1.067-m gauge; single track
Highways:
total: 54,186 km
paved: 4,056 km
unpaved: 50,130 km (1987 est.)
Ports: Luderitz, Walvis Bay
Merchant marine: none
Airports:
total: 108
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 14
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 10
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 17
with unpaved runways 914 to 1 523 m: 58 (1995 est.)','e0719cbb8d1edc1e16892d41ebc80305c26ef106cc9c30556c491fb7cac4eab8','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b97a94ed5f68a98cb59b7dc16b0d49eead8e6f52fc2dc585480c130c6378647',1996,'MH','Marshall Islands','transportation',268,'--------------
Railways:
total: 3.9 km; note - used to haul phosphates from the center of the
island to processing facilities on the southwest coast
Highways:
total: 27 km
paved: 21 km
unpaved: 6 km (1986 est.)
Ports: Nauru
Merchant marine: none
Airports:
total: 1
with paved runways 1 524 to 2 437 m: 1 (1995 est.)
--------------
Ports: none; offshore anchorage only
Defense
-------
Defense note: defense is the responsibility of the US
======================================================================
@Nepal
-----
Map
---
Location: 28 00 N, 84 00 E -- Southern Asia, between China and','0e2f7fd18b3ddfba8e1061ca42bb27d4304832b290d838493e663d2c7d751242','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dccc0985fe79998a845e205e399f242e238d44a085dac7d93068ca48ec848e5',1996,'HN','Honduras','transportation',276,'--------------
Railways:
total: 0 km
narrow gauge: 0 km 1.067-m gauge; note - part of the previous 376 km
system was closed and dismantled in 1993 and, in 1994, the remainder
was closed, the track and rolling stock being sold for scrap
Highways:
total: 26,000 km
paved: 4,000 km
unpaved: 22,000 km (1993 est.)
note: there is a 368.5 km portion of the Pan-American Highway which
is not included in the total
Waterways: 2,220 km, including 2 large lakes
Pipelines: crude oil 56 km
Ports: Bluefields, Corinto, El Bluff, Puerto Cabezas, Puerto
Sandino, Rama, San Juan del Sur
Merchant marine: none
Airports:
total: 148
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 107
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 32 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 11,258 km
paved: 3,265 km
unpaved: 7,993 km (1990 est.)
Waterways: Niger river is navigable 300 km from Niamey to Gaya on
the Benin frontier from mid-December through March
Ports: none
Airports:
total: 23
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 6
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 2
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 11 (1995 est.)
--------------
Railways:
total: 3,557 km (1995)
narrow gauge: 3,505 km 1.067-m gauge
standard gauge: 52 km 1.435-m gauge
Highways:
total: 112,140 km
paved: 31,500 km
unpaved: 80,640 km (1991 est.)
Waterways: 8,575 km consisting of the Niger and Benue rivers and
smaller rivers and creeks
Pipelines: crude oil 2,042 km; petroleum products 3,000 km;
natural gas 500 km
Ports: Calabar, Lagos, Onne, Port Harcourt, Sapele, Warri
Merchant marine:
total: 33 ships (1,000 GRT or over) totaling 387,552 GRT/636,578 DWT
ships by type: bulk 1, cargo 16, chemical tanker 3, oil tanker 12,
roll-on/roll-off cargo 1 (1995 est.)
Airports:
total: 66
with paved runways over 3 047 m: 6
with paved runways 2 438 to 3 047 m: 10
with paved runways 1 524 to 2 437 m: 10
with paved runways 914 to 1 523 m: 8
with paved runways under 914 m: 18
with unpaved runways over 3 047 m: 1
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 12 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 229 km
unpaved: 229 km
Ports: none; offshore anchorage only
Merchant marine: none
Airports:
total: 1
with paved runways 1 524 to 2 437 m: 1 (1995 est.)','d0dd08713931963fbd7e35c947307a53407687615faaa76bfb57f3c1d0fc4abf','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f62b85f3cc52fc46647021dfff881c83cbf9349a136bb7d8ef02a450f18011da',1996,'CR','Costa Rica','transportation',277,'Flag
----
Description: divided into four, equal rectangles; the top
quadrants are white (hoist side) with a blue five-pointed star in
the center and plain red, the bottom quadrants are plain blue (hoist
side) and white with a red five-pointed star in the center
--------------
Railways:
total: 355 km
broad gauge: 76 km 1.524-m gauge
narrow gauge: 279 km 0.914-m gauge
Highways:
total: 10,103 km
paved: 3,233 km
unpaved: 6,870 km (1992 est.)
Waterways: 800 km navigable by shallow draft vessels; 82 km Panama
Canal
Pipelines: crude oil 130 km
Ports: Balboa, Cristobal, Coco Solo North, Vacamonte
Merchant marine:
total: 3,758 ships (1,000 GRT or over) totaling 69,960,500
GRT/107,632,713 DWT
ships by type: bulk 902, cargo 1,050, chemical tanker 168,
combination bulk 40, combination ore/oil 19, container 307,
liquefied gas tanker 155, livestock carrier 7, multifunction
large-load carrier 3, oil tanker 488, passenger 31, passenger-cargo
5, refrigerated cargo 295, roll-on/roll-off cargo 93, short-sea
passenger 34, specialized tanker 11, vehicle carrier 150
note: a flag of convenience registry; includes ships from 83
countries among which are Japan 1,212, Greece 360, Hong Kong 263,
Taiwan 203, South Korea 198, US 160, China 152, Singapore 118, UK
79, Switzerland 67, and Norway 58 (1995 est.)
Airports:
total: 99
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 5
with paved runways 914 to 1 523 m: 14
with paved runways under 914 m: 60
with unpaved runways 914 to 1 523 m: 18 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 19,088 km
paved: 640 km
unpaved: 18,448 km (1988 est.)
Waterways: 10,940 km
Ports: Kieta, Lae, Madang, Port Moresby, Rabaul
Merchant marine:
total: 12 ships (1,000 GRT or over) totaling 22,565 GRT/27,114 DWT
ships by type: bulk 2, cargo 3, combination ore/oil 5, container 1,
roll-on/roll-off 1 (1995 est.)
Airports:
total: 451
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 12
with paved runways 914 to 1 523 m: 5
with paved runways under 914 m: 371
with unpaved runways 1 524 to 2 437 m: 11
with unpaved runways 914 to 1 523 m: 51 (1995 est.)
Heliports: 2 (1995 est.)
--------------
Ports: small Chinese port facilities on Woody Island and Duncan
Island being expanded
Airports:
total: 1
with paved runways 1 524 to 2 437 m: 1 (on Woody Island) (1995 est.)','1b46b3bc04a022a42a687ba137ce8d976f597f0b495954b7e6ba40e231316b55','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a412c60a49239fa07f12f33a6643dff87831daef4cc9dac1935f0574e8c65a5c',1996,'ET','Ethiopia','transportation',291,'--------------
Railways: 0 km
Highways:
total: 298 km
paved: 198 km
unpaved: 100 km (1987 est.)
note: roads on Principe are mostly unpaved and in need of repair
Ports: Santo Antonio, Sao Tome
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 1,096 GRT/1,105 DWT
(1995 est.)
Airports:
total: 2
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways:
total: 1,390 km
standard gauge: 1,390 km 1.435-m gauge (448 km double track) (1992)
Highways:
total: 151,532 km
paved: 60,613 km
unpaved: 90,919 km (1992 est.)
Pipelines: crude oil 6,400 km; petroleum products 150 km; natural
gas 2,200 km (includes natural gas liquids 1,600 km)
Ports: Ad Dammam, Al Jubayl, Duba, Jiddah, Jizan, Rabigh, Ra''s al
Khafji, Al Mishab, Ras Tanura, Yanbu'' al Bahr, Yanbu'' al Sinaiyah
Merchant marine:
total: 76 ships (1,000 GRT or over) totaling 944,946 GRT/1,322,167
DWT
ships by type: bulk 1, cargo 13, chemical tanker 5, container 3,
liquefied gas tanker 1, livestock carrier 4, oil tanker 22,
passenger 1, refrigerated cargo 4, roll-on/roll-off cargo 13,
short-sea passenger 9 (1995 est.)
Airports:
total: 175
with paved runways over 3 047 m: 30
with paved runways 2 438 to 3 047 m: 11
with paved runways 1 524 to 2 437 m: 22
with paved runways 914 to 1 523 m: 4
with paved runways under 914 m: 13
with unpaved runways over 3 047 m: 1
with unpaved runways 2 438 to 3 047 m: 4
with unpaved runways 1 524 to 2 437 m: 66
with unpaved runways 914 to 1 523 m: 24 (1995 est.)
Heliports: 4 (1995 est.)
--------------
Railways:
total: 904 km
narrow gauge: 904 km 1.000-meter gauge (70 km double track) (1995)
Highways:
total: 13,850 km
paved: 3,900 km
unpaved: 9,950 km (1990 est.)
Waterways: 897 km total; 785 km on the Senegal river, and 112 km
on the Saloum
Ports: Dakar, Kaolack, Matam, Podor, Richard-Toll, Saint-Louis,
Ziguinchor
Merchant marine:
total: 1 bulk ship (1,000 GRT or over) totaling 1,995 GRT/3,775 DWT
(1995 est.)
Airports:
total: 17
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 8
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 1
with unpaved runways 1 524 to 2 437 m: 4
with unpaved runways 914 to 1 523 m: 2 (1995 est.)
--------------
Railways:
total: 3,960 km
standard gauge: 3,960 km 1.435-m gauge (1,341 km electrified) (1992)
Highways:
total: 46,019 km
paved: 26,949 km
unpaved: 19,070 km (1990 est.)
Waterways: NA km
Pipelines: crude oil 415 km; petroleum products 130 km; natural
gas 2,110 km
Ports: Bar, Belgrade, Kotor, Novi Sad, Pancevo, Tivat
Merchant marine:
Montenegro: total 21 ships (1,000 GRT or over) totaling 326,133
GRT/544,600 DWT (controlled by Montenegrin beneficial owners)
ships by type: bulk 9, cargo 8, container 3, short-sea passenger
ferry 1
note: ships operate under the flags of Malta, Panama, and Cyprus; no
ships remain under Yugoslav flag (1995 est.)
Serbia: total 2 bulk ships (1,000 GRT or over) totaling 42,916
GRT/77,103 DWT (controlled by Serbian beneficial owners)
note: all under the flag of Saint Vincent and the Grenadines; no
ships remain under Yugoslav flag (1995 est.)
Airports:
total: 44 (Serbia 39, Montenegro 5)
with paved runways over 3 047 m: 2 (Serbia 2, Montenegro 0)
with paved runways 2 438 to 3 047 m: 5 (Serbia 3, Montenegro 2)
with paved runways 1 524 to 2 437 m: 5 (Serbia 4, Montenegro 1)
with paved runways 914 to 1 523 m: 2 (Serbia 2, Montenegro 0)
with paved runways under 914 m: 14 (Serbia 14, Montenegro 0)
with unpaved runways 1 524 to 2 437 m: 2 (Serbia 2, Montenegro 0)
with unpaved runways 914 to 1 523 m: 14 (Serbia 12, Montenegro 2)
(1995 est.)
--------------
Railways: 0 km
Highways:
total: 269 km
paved: 187 km
unpaved: 82 km (1988 est.)
Ports: Victoria
Merchant marine: none
Airports:
total: 14
with paved runways 2 438 to 3 047 m: 1
with paved runways 914 to 1 523 m: 5
with paved runways under 914 m: 6
with unpaved runways 914 to 1 523 m: 2 (1995 est.)
--------------
Railways:
total: 84 km used on a limited basis because the mine at Marampa is
closed
narrow gauge: 84 km 1.067-m gauge
Highways:
total: 11,674 km
paved: 1,284 km
unpaved: 10,390 km (1992 est.)
Waterways: 800 km; 600 km navigable year round
Ports: Bonthe, Freetown, Pepel
Merchant marine: none
Airports:
total: 5
with paved runways over 3 047 m: 1
with paved runways 914 to 1 523 m: 2
with unpaved runways 914 to 1 523 m: 2 (1995 est.)
--------------
Railways:
total: 38.6 km
narrow gauge: 38.6 km 1.000-m gauge
Highways:
total: 2,989 km
paved: 2,905 km (including 111.6 km of expressways)
unpaved: 84 km (1994 est.)
Ports: Singapore
Merchant marine:
total: 646 ships (1,000 GRT or over) totaling 12,915,788
GRT/20,292,580 DWT
ships by type: bulk 110, cargo 118, chemical tanker 18, combination
bulk 3, combination ore/oil 8, container 92, liquefied gas tanker
13, multifunction large-load carrier 4, oil tanker 234, refrigerated
cargo 5, roll-on/roll-off cargo 13, short-sea passenger 1,
specialized tanker 3, vehicle carrier 24
note: a flag of convenience registry; includes ships from 22
countries among which are Japan 39, Hong Kong 27, Denmark 24,
Germany 20, Sweden 14, Thailand 14, Belgium 12, Norway 9, Indonesia
7, and US 7 (1995 est.)
Airports:
total: 8
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways:
total: 3,660 km
broad gauge: 102 km 1.520-m gauge
standard gauge: 3,507 km 1.435-m gauge (1378 km electrified)
narrow gauge: 51 km (46 km 1,000-m gauge; 5 km 0.750-m gauge) (1995)
Highways:
total: 17,737 km
paved: NA km
unpaved: NA km (1993 est.)
Waterways: 172 km on the Danube
Pipelines: petroleum products NA km; natural gas 2,700 km
Ports: Bratislava, Komarno
Merchant marine:
total: 4 cargo ships (1,000 GRT or over) totaling 17,010 GRT/22,039
DWT (1995 est.)
Airports:
total: 37
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 4
with unpaved runways 2 438 to 3 047 m: 2
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 10
with unpaved runways under 914 m: 11 (1994 est.)
--------------
Railways:
total: 1,201 km
standard gauge: 1,201 km 1.435-m gauge (electrified 499 km) (1994)
Highways:
total: 14,794 km
paved: 13,314 km (including 187 km of expressways)
unpaved: 1,480 km (1994 est.)
Waterways: NA
Pipelines: crude oil 290 km; natural gas 305 km
Ports: Izola, Koper, Piran
Merchant marine:
total: 14 ships (1,000 GRT or over) totaling 229,727 GRT/290,456 DWT
(controlled by Slovenian owners)
ships by type: bulk 9, cargo 1, container 4
note: ships operate under the flags of Saint Vincent and the
Grenadines, Singapore, Liberia, and Antigua and Barbuda; no ships
remain under the Slovenian flag (1995 est.)
Airports:
total: 14
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 5
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 2 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 1,300 km
paved: 30 km
unpaved: 1,270 km
note: in addition, there are 800 km of private logging and
plantation roads of varied surface (1982 est.)
Ports: Aola Bay, Honiara, Lofung, Noro, Viru Harbor, Yandina
Merchant marine: none
Airports:
total: 30
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 18
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 9 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 22,500 km
paved: 2,700 km
unpaved: 19,800 km (1992 est.)
Pipelines: crude oil 15 km
Ports: Bender Cassim (Boosaaso), Berbera, Chisimayu (Kismaayo),
Merca, Mogadishu
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 5,529 GRT/6,892 DWT
ships by type: cargo 1, refrigerated cargo 1 (1995 est.)
Airports:
total: 52
with paved runways over 3 047 m: 3
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 2
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 6
with unpaved runways 2 438 to 3 047 m: 4
with unpaved runways 1 524 to 2 437 m: 15
with unpaved runways 914 to 1 523 m: 20 (1995 est.)
--------------
Railways:
total: 21,431 km
narrow gauge: 20,995 km 1.067-m gauge (9,087 km electrified); 436 km
0.610-m gauge (1995)
Highways:
total: 182,329 km
paved: 55,428 km (including 2,040 km of expressways)
unpaved: 126,901 km (1991 est.)
Pipelines: crude oil 931 km; petroleum products 1,748 km; natural
gas 322 km
Ports: Cape Town, Durban, East London, Mosselbaai, Port Elizabeth,
Richards Bay, Saldanha
Merchant marine:
total: 4 container ships (1,000 GRT or over) totaling 211,276
GRT/198,602 DWT (1995 est.)
Airports:
total: 667
with paved runways over 3 047 m: 10
with paved runways 2 438 to 3 047 m: 4
with paved runways 1 524 to 2 437 m: 44
with paved runways 914 to 1 523 m: 75
with paved runways under 914 m: 221
with unpaved runways 1 524 to 2 437 m: 33
with unpaved runways 914 to 1 523 m: 280 (1995 est.)
--------------
Railways:
total: 5,138 km (1995); note - severely reduced trackage in use
because of civil strife
narrow gauge: 3,987 km 1.067-m gauge (858 km electrified); 125 km
1.000-m gauge; 1,026 km 0.600-m gauge
Highways:
total: 145,000 km
paved: 290 km
unpaved: 144,710 km (1991 est.)
Waterways: 15,000 km including the Congo, its tributaries, and
unconnected lakes
Pipelines: petroleum products 390 km
Ports: Banana, Boma, Bukavu, Bumba, Goma, Kalemie, Kindu,
Kinshasa, Kisangani, Matadi, Mbandaka
Merchant marine: none
Airports:
total: 217
with paved runways over 3 047 m: 4
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 15
with paved runways 914 to 1 523 m: 2
with paved runways under 914 m: 82
with unpaved runways 1 524 to 2 437 m: 17
with unpaved runways 914 to 1 523 m: 94 (1995 est.)','25952c1e1de8706b3d35fc12ee016bd2bee8fdee41be32beca786e28f8f440db','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52fd44846654ffb3d4f15d4e55bc48f7e2ff5ea21ae5d4a70c33b0733f52c572',1996,'GI','Gibraltar','transportation',298,'--------------
Railways:
total: 14,343 km
broad gauge: 12,139 km 1.668-m gauge (6,510 km electrified; 2,295 km
double track)
standard gauge: 488 km 1.435-m gauge (488 km electrified)
narrow gauge: 1,716 km (privately owned: 1,669 km 1.000-m gauge, 489
km electrified; 28 km 0.914-m gauge, 28 km electrified; government
owned: 19 km 1.000-m gauge, all electrified)
Highways:
total: 331,961 km
paved: 328,641 km (including 2,700 km of expressways)
unpaved: 3,320 km (1991 est.)
Waterways: 1,045 km, but of minor economic importance
Pipelines: crude oil 265 km; petroleum products 1,794 km; natural
gas 1,666 km
Ports: Aviles, Barcelona, Bilbao, Cadiz, Cartagena, Castellon de
la Plana, Ceuta, Huelva, La Coruna, Las Palmas (Canary Islands),
Malaga, Melilla, Pasajes, Puerto de Gijon, Santa Cruz de Tenerife
(Canary Islands), Santander, Tarragona, Valencia, Vigo
Merchant marine:
total: 147 ships (1,000 GRT or over) totaling 874,688 GRT/1,391,421
DWT
ships by type: bulk 9, cargo 36, chemical tanker 11, combination
ore/oil 1, container 8, liquefied gas tanker 4, oil tanker 25,
passenger 2, refrigerated cargo 12, roll-on/roll-off cargo 32,
short-sea passenger 6, specialized tanker 1 (1995 est.)
Airports:
total: 96
with paved runways over 3 047 m: 15
with paved runways 2 438 to 3 047 m: 11
with paved runways 1 524 to 2 437 m: 15
with paved runways 914 to 1 523 m: 13
with paved runways under 914 m: 28
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 12 (1995 est.)
Heliports: 2 (1995 est.)
--------------
Ports: none
Airports:
total: 4
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 2
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways:
total: 1,484 km
broad gauge: 1,459 km 1.676-m gauge
narrow gauge: 25 km .762-m gauge (1995)
Highways:
total: 94,651 km
paved: 25,749 km
unpaved: 68,902 km (1990)
Waterways: 430 km; navigable by shallow-draft craft
Pipelines: crude oil and petroleum products 62 km (1987)
Ports: Colombo, Galle, Jaffna, Trincomalee
Merchant marine:
total: 26 ships (1,000 GRT or over) totaling 220,508 GRT/329,410 DWT
ships by type: bulk 2, cargo 13, container 1, oil tanker 2,
refrigerated cargo 8 (1995 est.)
Airports:
total: 13
with paved runways over 3 047 m: 1
with paved runways 1 524 to 2 437 m: 6
with paved runways 914 to 1 523 m: 6 (1995 est.)
--------------
Railways:
total: 5,516 km
narrow gauge: 4,800 km 1.067-m gauge; 716 km 1.6096-m gauge
plantation line
Highways:
total: 19,885 km
paved: 1,989 km
unpaved: 17,896 km (1986 est.)
Waterways: 5,310 km navigable
Pipelines: refined products 815 km
Ports: Juba, Khartoum, Kusti, Malakal, Nimule, Port Sudan, Sawakin
Merchant marine:
total: 5 ships (1,000 GRT or over) totaling 43,024 GRT/57,985 DWT
ships by type: cargo 3, roll-on/roll-off cargo 2 (1995 est.)
Airports:
total: 56
with paved runways 2 438 to 3 047 m: 8
with paved runways 1 524 to 2 437 m: 3
with paved runways under 914 m: 7
with unpaved runways 1 524 to 2 437 m: 13
with unpaved runways 914 to 1 523 m: 25 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways:
total: 166 km (single track)
standard gauge: 80 km 1.435-m gauge
narrow gauge: 86 km 1.000-m gauge
Highways:
total: 4,470 km
paved: 1,162 km
unpaved: 3,308 km (1990)
Waterways: 1,200 km; most important means of transport; oceangoing
vessels with drafts ranging up to 7 m can navigate many of the
principal waterways
Ports: Albina, Moengo, New Nickerie, Paramaribo, Paranam,
Wageningen
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 2,421 GRT/2,990 DWT
ships by type: cargo 1, container 1 (1995 est.)
Airports:
total: 38
with paved runways over 3 047 m: 1
with paved runways under 914 m: 31
with unpaved runways 914 to 1 523 m: 6 (1995 est.)
--------------
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: Barentsburg, Longyearbyen, Ny-Alesund, Pyramiden
Merchant marine: none
Airports:
total: 4
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 3 (1995 est.)
--------------
Railways:
total: 297 km; note - includes 71 km which are not in use
narrow gauge: 297 km 1.067-m gauge (single track)
Highways:
total: 2,960 km
paved: 804 km
unpaved: 2,156 km (1993 est.)
Ports: none
Airports:
total: 17
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 10
with unpaved runways 914 to 1 523 m: 6 (1995 est.)','e8395bc019faf129ca0836f1904b84de3e86528754eb6476620bc575ce78254a','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a26d3de006d1c590a113711d4db4db9b56811de08fa4917e88294a79d6b87ff8',1996,'NO','Norway','transportation',307,'--------------
Railways:
total: 12,624 km (includes 953 km of privately-owned railways)
standard gauge: 11,767 km 1.435-m gauge (7,320 km electrified and
1,152 km double track)
other: 857 km NA-m gauge (1995)
Highways:
total: 135,859 km
paved: 97,818 km (including 936 km of expressways)
unpaved: 38,041 km (1991 est.)
Waterways: 2,052 km navigable for small steamers and barges
Pipelines: natural gas 84 km
Ports: Gavle, Goteborg, Halmstad, Helsingborg, Hudiksvall, Kalmar,
Karlshamn, Malmo, Solvesborg, Stockholm, Sundsvall
Merchant marine:
total: 169 ships (1,000 GRT or over) totaling 1,993,422
GRT/2,183,215 DWT
ships by type: bulk 10, cargo 35, chemical tanker 24, combination
ore/oil 1, liquefied gas tanker 1, oil tanker 32, railcar carrier 2,
refrigerated cargo 1, roll-on/roll-off cargo 38, short-sea passenger
7, specialized tanker 4, vehicle carrier 14 (1995 est.)
Airports:
total: 251
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 7
with paved runways 1 524 to 2 437 m: 85
with paved runways 914 to 1 523 m: 26
with paved runways under 914 m: 127
with unpaved runways 914 to 1 523 m: 4 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways:
total: 5,719 km (1,432 km double track)
standard gauge: 3,283 km 1.435-m gauge (99% electrified; 310 km
nongovernment owned)
narrow gauge: 1,255 km 1.000-m gauge (99% electrified; 1,181 km
nongovernment owned)
other: 1,181 km NA-m gauge (1995)
Highways:
total: 71,118 km
paved: 71,118 km (including 1,514 km of expressways)
unpaved: 0 km (1992 est.)
Waterways: 65 km; Rhine (Basel to Rheinfelden, Schaffhausen to
Bodensee); 12 navigable lakes
Pipelines: crude oil 314 km; natural gas 1,506 km
Ports: Basel
Merchant marine:
total: 23 ships (1,000 GRT or over) totaling 410,581 GRT/727,744 DWT
ships by type: bulk 14, cargo 1, chemical tanker 4, oil tanker 2,
roll-on/roll-off cargo 1, specialized tanker 1 (1995 est.)
Airports:
total: 67
with paved runways over 3 047 m: 4
with paved runways 2 438 to 3 047 m: 4
with paved runways 1 524 to 2 437 m: 13
with paved runways 914 to 1 523 m: 5
with paved runways under 914 m: 40
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways:
total: 1,998 km
broad gauge: 1,766 km 1.435-m gauge
narrow gauge: 232 km 1.050-m gauge
Highways:
total: 31,569 km
paved: 24,308 km (including 712 km of expressways)
unpaved: 7,261 km (1991 est.)
Waterways: 870 km; minimal economic importance
Pipelines: crude oil 1,304 km; petroleum products 515 km
Ports: Baniyas, Jablah, Latakia, Tartus
Merchant marine:
total: 99 ships (1,000 GRT or over) totaling 294,355 GRT/454,990 DWT
ships by type: bulk 12, cargo 85, livestock carrier 1, vehicle
carrier 1 (1995 est.)
Airports:
total: 99
with paved runways over 3 047 m: 5
with paved runways 2 438 to 3 047 m: 15
with paved runways 1 524 to 2 437 m: 1
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 62
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 13 (1995 est.)
Heliports: 2 (1995 est.)
--------------
Railways:
total: 4,600 km; note - 1,075 km in common carrier service and about
3,525 km is dedicated to industrial use
narrow gauge: 4,600 km 1.067-m
Highways:
total: 19,860 km
paved: 17,119 km (including 382 km of expressways)
unpaved: 2,741 km (1990 est.)
Pipelines: petroleum products 615 km; natural gas 97 km
Ports: Chi-lung (Keelung), Hua-lien, Kao-hsiung, Su-ao, T''ai-chung
Merchant marine:
total: 198 ships (1,000 GRT or over) totaling 5,812,534
GRT/8,885,092 DWT
ships by type: bulk 50, cargo 29, combination bulk 3, combination
ore/oil 1, container 83, oil tanker 19, refrigerated cargo 11,
roll-on/roll-off cargo 2 (1995 est.)
Airports:
total: 38
with paved runways over 3 047 m: 8
with paved runways 2 438 to 3 047 m: 12
with paved runways 1 524 to 2 437 m: 4
with paved runways 914 to 1 523 m: 6
with paved runways under 914 m: 7
with unpaved runways 1 524 to 2 437 m: 1 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways:
total: 480 km in common carrier service; does not include industrial
lines (1990)
Highways:
total: 32,752 km
paved: 21,119 km
unpaved: 11,633 km (1992 est.)
Pipelines: natural gas 400 km (1992)
Ports: none
Airports:
total: 59
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 5
with paved runways 1 524 to 2 437 m: 7
with paved runways 914 to 1 523 m: 1
with unpaved runways 914 to 1 523 m: 9
with unpaved runways under 914 m: 36 (1994 est.)
--------------
Railways:
total: 3,569 km (1995)
narrow gauge: 2,600 km 1.000-m gauge; 969 km 1.067-m gauge
note:: the Tanzania-Zambia Railway Authority (TAZARA), which
operates 1,860 km of 1.067-m narrow gauge track between Dar es
Salaam and New Kapiri M''poshi in Zambia is not a part of Tanzania
Railways Corporation; 969 km are in Tanzania and 891 km are in
Zambia; because of the difference in gauge, this system does not
connect to Tanzania Railways
Highways:
total: 55,600 km
paved: 20,572 km (including 50 km of expressways)
unpaved: 35,028 km (1992 est.)
Waterways: Lake Tanganyika, Lake Victoria, Lake Nyasa
Pipelines: crude oil 982 km
Ports: Bukoba, Dar es Salaam, Kigoma, Lindi, Mkoani, Mtwara,
Musoma, Mwanza, Tanga, Wete, Zanzibar
Merchant marine:
total: 8 ships (1,000 GRT or over) totaling 30,371 GRT/41,269 DWT
ships by type: cargo 3, oil tanker 2, passenger-cargo 2,
roll-on/roll-off cargo 1 (1995 est.)
Airports:
total: 111
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 6
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 28
with unpaved runways 1 524 to 2 437 m: 15
with unpaved runways 914 to 1 523 m: 57 (1995 est.)
--------------
Railways:
total: 4,623 km
narrow gauge: 4,623 km 1.000-m gauge (99 km double track)
Highways:
total: 54,388 km
paved: 48,786 km (including 171 km of expressways)
unpaved: 5,602 km (1992 est.)
Waterways: 3,999 km principal waterways; 3,701 km with navigable
depths of 0.9 m or more throughout the year; numerous minor
waterways navigable by shallow-draft native craft
Pipelines: petroleum products 67 km; natural gas 350 km
Ports: Bangkok, Laem Chabang, Pattani, Phuket, Sattahip, Si Racha,
Songkhla
Merchant marine:
total: 259 ships (1,000 GRT or over) totaling 1,559,037
GRT/2,498,812 DWT
ships by type: bulk 32, cargo 143, chemical tanker 3, container 11,
liquefied gas tanker 12, oil tanker 45, passenger 1, refrigerated
cargo 7, roll-on/roll-off cargo 2, short-sea passenger 1,
specialized tanker 2 (1995 est.)
Airports:
total: 98
with paved runways over 3 047 m: 6
with paved runways 2 438 to 3 047 m: 9
with paved runways 1 524 to 2 437 m: 12
with paved runways 914 to 1 523 m: 22
with paved runways under 914 m: 36
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 12 (1995 est.)
Heliports: 2 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 2,386 km
paved: 1,342 km
unpaved: 1,044 km (1986 est.)
Ports: Freeport, Matthew Town, Nassau
Merchant marine:
total: 956 ships (1,000 GRT or over) totaling 22,592,285
GRT/35,765,965 DWT
ships by type: bulk 176, cargo 182, chemical tanker 43, combination
bulk 9, combination ore/oil 19, container 53, liquefied gas tanker
20, oil tanker 180, passenger 53, refrigerated cargo 147,
roll-on/roll-off cargo 47, short-sea passenger 13, vehicle carrier 14
note: a flag of convenience registry; includes ships from 48
countries among which are Norway 155, Greece 124, US 84, Denmark 63,
Netherlands 44, Sweden 36, Finland 34, France 29, Japan 29, and
Belgium 24 (1995 est.)
Airports:
total: 55
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 16
with paved runways 914 to 1 523 m: 11
with paved runways under 914 m: 17
with unpaved runways 914 to 1 523 m: 8 (1995 est.)','354425c5a4954dbc60d3b68708074b74965b36eb0e72150e94ed162918be6351','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93a473b4e941118659fda1822904aa67b8e20b0e9378377b75eecd81b10c2dfc',1996,'SN','Senegal','transportation',313,'--------------
Railways: 0 km
Highways:
total: 2,386 km
paved: 764 km
unpaved: 1,622 km (1990 est.)
Waterways: 400 km
Ports: Banjul
Merchant marine: none
Airports:
total: 1
with paved runways over 3 047 m: 1 (1995 est.)
--------------
Railways:
total: 525 km (1995)
narrow gauge: 525 km 1.000-m gauge
Highways:
total: 7,545 km
paved: 1,833 km
unpaved: 5,712 km (1993 est.)
Waterways: 50 km Mono river
Ports: Kpeme, Lome
Merchant marine: none
Airports:
total: 8
with paved runways 2 438 to 3 047 m: 2
with paved runways under 914 m: 2
with unpaved runways 914 to 1 523 m: 4 (1995 est.)','74b0d988036525e98f264ae0deac5ef2d1b97d209237758577f0f63fc2eb8ea9','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b4acd01f214619ae55f0793fbcc87935ced041320c69b1d0ea4b1e3abee3052',1996,'NZ','New Zealand','transportation',317,'--------------
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: none; offshore anchorage only
Merchant marine: none
Airports: none; lagoon landings by amphibious aircraft from
Western Samoa
--------------
Railways: 0 km
Highways:
total: 432 km
paved: 280 km
unpaved: 152 km (1987 est.)
Ports: Neiafu, Nuku''alofa, Pangai
Merchant marine:
total: 4 ships (1,000 GRT or over) totaling 9,990 GRT/14,884 DWT
ships by type: cargo 1, liquefied gas tanker 2, roll-on/roll-off
cargo 1 (1995 est.)
Airports:
total: 6
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 2
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 2 (1995 est.)
--------------
Railways:
note: minimal agricultural railroad system near San Fernando;
railway service was discontinued in 1968
Highways:
total: 8,352 km
paved: 3,978 km
unpaved: 4,374 km (1987 est.)
Pipelines: crude oil 1,032 km; petroleum products 19 km; natural
gas 904 km
Ports: Pointe-a-Pierre, Point Fortin, Point Lisas, Port-of-Spain,
Scarborough, Tembladora
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 2,928 GRT/5,571 DWT
ships by type: cargo 1, oil tanker 1 (1995 est.)
Airports:
total: 5
with paved runways over 3 047 m: 1
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 2
with unpaved runways 914 to 1 523 m: 1 (1995 est.)','8551611c4098f73779fd60a121081256252966bc0ca86bbda279efa34c0c0294','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d14365991b0eefba6036a1c925efe2421b6e9e36ec6d0683ad36e9c3ef8e80a4',1996,'SC','Seychelles','transportation',327,'--------------
Ports: none; offshore anchorage only
Airports:
total: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways:
total: 2,260 km
standard gauge: 492 km 1.435-m gauge
narrow gauge: 1,758 km 1.000-m gauge
dual gauge: 10 km 1.000-m and 1.435-m gauges (1993 est.)
Highways:
total: 29,183 km
paved: 17,510 km (including 52 km of expressways)
unpaved: 11,673 km (1989 est.)
Pipelines: crude oil 797 km; petroleum products 86 km; natural gas
742 km
Ports: Bizerte, Gabes, La Goulette, Sfax, Sousse, Tunis, Zarzis
Merchant marine:
total: 19 ships (1,000 GRT or over) totaling 125,840 GRT/164,277 DWT
ships by type: bulk 6, cargo 4, chemical tanker 3, oil tanker 2,
roll-on/roll-off cargo 3, short-sea passenger 1 (1995 est.)
Airports:
total: 29
with paved runways over 3 047 m: 3
with paved runways 2 438 to 3 047 m: 6
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 3
with paved runways under 914 m: 6
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 6 (1995 est.)
--------------
Railways:
total: 10,386 km
standard gauge: 10,386 km 1.435-m gauge (1,088 km electrified)
Highways:
total: 386,704 km
paved: 45,683 km (including 862 km of expressways)
unpaved: 341,021 km (1992 est.)
Waterways: about 1,200 km
Pipelines: crude oil 1,738 km; petroleum products 2,321 km;
natural gas 708 km
Ports: Gemlik, Hopa, Iskenderun, Istanbul, Izmir, Izmit, Mersin,
Samsun, Trabzon
Merchant marine:
total: 465 ships (1,000 GRT or over) totaling 5,509,741
GRT/9,494,434 DWT
ships by type: bulk 139, cargo 212, chemical tanker 18, combination
bulk 7, combination ore/oil 12, container 2, liquefied gas tanker 4,
livestock carrier 1, oil tanker 43, passenger-cargo 1, refrigerated
cargo 2, roll-on/roll-off cargo 15, short-sea passenger 7,
specialized tanker 2
note: Turkey owns an additional 18 ships (1,000 GRT or over)
totaling 247,369 DWT operating under the registries of Malta,
Panama, Libya, and Greece (1995 est.)
Airports:
total: 104
with paved runways over 3 047 m: 17
with paved runways 2 438 to 3 047 m: 19
with paved runways 1 524 to 2 437 m: 12
with paved runways 914 to 1 523 m: 18
with paved runways under 914 m: 28
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 8 (1995 est.)
Heliports: 2 (1995 est.)
--------------
Railways:
total: 2,120 km in common carrier service; does not include
industrial lines
broad gauge: 2,120 km 1.520-m gauge (1990)
Highways:
total: 23,000 km
paved: NA km
unpaved: NA km (1990 est.)
Waterways: the Amu Darya is an important inland waterway
Pipelines: crude oil 250 km; natural gas 4,400 km
Ports: Turkmenbashi (formerly Krasnowodsk)
Airports:
total: 64
with paved runways 2 438 to 3 047 m: 13
with paved runways 1 524 to 2 437 m: 8
with paved runways 914 to 1 523 m: 1
with unpaved runways 914 to 1 523 m: 7
with unpaved runways under 914 m: 35 (1994 est.)
--------------
Railways: 0 km
Highways:
total: 121 km
paved: 24 km
unpaved: 97 km
Ports: Grand Turk, Providenciales
Merchant marine: none
Airports:
total: 7
with paved runways 1 524 to 2 437 m: 3
with paved runways 914 to 1 523 m: 1
with paved runways under 914 m: 1
with unpaved runways 914 to 1 523 m: 2 (1995 est.)','765a68a0c6e279b65d0c2250e4d257a2b14b090ba388dec43fb8494a57c35680','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c97ef198b13dc2f10eb66b3a412ff212a42a10b2855e0fa07bc157f360762b86',1996,'IE','Ireland','transportation',331,'--------------
Railways:
total: 17,561 km
broad gauge: 434 km 1.600-m gauge (190 km double track); note - all
1.600-m gauge track, of which 357 km is in common carrier use, is in
Northern Ireland
standard gauge: 16,892 km 1.435-m gauge (4,928 km electrified;
12,591 km double or multiple track); note - 16,532 km of 1.435-m
routes are in common carrier service; the remaining 360 km are
operated by a total of 40 tourist or other private companies
narrow gauge: 235 km 0.260-m, 0.311-m, 0.381-m, 0.600-m, 0.610-m,
0.686-m, 0.760-m, 0.762-m, 0.800-m, 0.825-m, 0.914-m and 1.067-m
gauges; note - these short, narrow-gage lines are operated by a
total of 25 tourist and other private firms (1995)
Highways:
total: 386,243 km (1993 est.)
paved: NA km (including 3,237 km of expressways in Great Britain)
unpaved: NA km
Waterways: 3,200 km under British Waterways Board
Pipelines: crude oil (almost all insignificant) 933 km; petroleum
products 2,993 km; natural gas 12,800 km
Ports: Aberdeen, Belfast, Bristol, Cardiff, Grangemouth, Hull,
Leith, Liverpool, London, Manchester, Medway, Sullom Voe, Tees, Tyne
Merchant marine:
total: 151 ships (1,000 GRT or over) totaling 3,191,969
GRT/3,861,239 DWT
ships by type: bulk 10, cargo 21, chemical tanker 2, container 24,
liquefied gas tanker 2, oil tanker 56, passenger 8, passenger-cargo
1, roll-on/roll-off cargo 12, short-sea passenger 14, specialized
tanker 1 (1995 est.)
Airports:
total: 388
with paved runways over 3 047 m: 9
with paved runways 2 438 to 3 047 m: 29
with paved runways 1 524 to 2 437 m: 103
with paved runways 914 to 1 523 m: 59
with paved runways under 914 m: 166
with unpaved runways 914 to 1 523 m: 22 (1995 est.)
Heliports: 10 (1995 est.)','0559b65450c6ec735cffbc618c85bbc6352b547a441963ec5e920ff438e11324','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43ca4f9bdb78d6ba9835dcbcf69ede6353910ce27a174058e295d78ad4a7f55c',1996,'NC','New Caledonia','transportation',338,'--------------
Railways: 0 km
Highways:
total: 1,021 km
paved: 238 km
unpaved: 783 km (1987 est.)
Ports: Forari, Port-Vila, Santo (Espiritu Santo)
Merchant marine:
total: 112 ships (1,000 GRT or over) totaling 1,587,286
GRT/2,173,970 DWT
ships by type: bulk 38, cargo 29, chemical tanker 3, combination
bulk 1, container 3, liquefied gas tanker 5, livestock carrier 1,
oil tanker 6, refrigerated cargo 16, vehicle carrier 10
note: a flag of convenience registry; includes ships from 20
countries among which are Japan 37, US 19, Netherlands 10, Greece 6,
Hong Kong 6, China 4, Canada 4, UAE 3, Russia 2, and Australia 2
(1995 est.)
Airports:
total: 31
with paved runways 2 438 to 3 047 m: 1
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 17
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 11 (1995 est.)','a0feac18f55e2e1928d870b6b38acc4ffba060c4414f6f6f4f6e6528d6fd7da1','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('706bb1909e13220e4e7206a9e2fcba9af136c853712e9af001203f680ddaddb2',1996,'GY','Guyana','transportation',346,'--------------
Railways:
total: 2,835 km (in addition, there are 224 km not restored to
service after war damage)
standard gauge: 151 km 1.435-m gauge
narrow gauge: 2,454 km 1.000-m gauge
other gauge: 230 km NA-m dual gauge (three rails)
Highways:
total: 105,000 km
paved: 10,500 km
unpaved: 94,500 km (1993 est.)
Waterways: 17,702 km navigable; more than 5,149 km navigable at
all times by vessels up to 1.8 m draft
Pipelines: petroleum products 150 km
Ports: Da Nang, Haiphong, Ho Chi Minh City, Hon Gai, Qui Nhon, Nha
Trang
Merchant marine:
total: 112 ships (1,000 GRT or over) totaling 569,269 GRT/947,938 DWT
ships by type: bulk 3, cargo 95, oil tanker 10, refrigerated cargo
3, roll-on/roll-off cargo 1
note: Vietnam owns an additional 9 ships (1,000 GRT or over)
totaling 120,320 DWT operating under the registries of Honduras,
Panama, The Bahamas, and Malta (1995 est.)
Airports:
total: 48
with paved runways over 3 047 m: 8
with paved runways 2 438 to 3 047 m: 3
with paved runways 1 524 to 2 437 m: 5
with paved runways 914 to 1 523 m: 13
with paved runways under 914 m: 7
with unpaved runways 1 524 to 2 437 m: 2
with unpaved runways 914 to 1 523 m: 5
with unpaved runways under 914 m: 5 (1994 est.)
--------------
Railways: 0 km
Highways:
total: 856 km
paved: NA km
unpaved: NA km
Ports: Charlotte Amalie, Christiansted, Cruz Bay, Port Alucroix
Merchant marine: none
Airports:
total: 2
with paved runways 1 524 to 2 437 m: 2
note: international airports on Saint Thomas and Saint Croix (1995
est.)','2a8dda8dd3354a4eb5a8982dbc8ee2e79539b8a87a12ff096336b19708fe43c6','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ccdafbfa01d6cb166d363dbbd4396770be71479691cfa39f87bc7262304fd15',1996,'MP','Northern Mariana Islands','transportation',353,'--------------
Railways: 0 km
Ports: none; two offshore anchorages for large ships
Merchant marine: none
Airports:
total: 1
with paved runways 2 438 to 3 047 m: 1 (1995 est.)
Transportation note: formerly an important commercial aviation
base, now used by US military, some commercial cargo planes, as well
as the US Army Space and Strategic Defense Command for missile
launches
--------------
Railways: 0 km
Highways:
total: 120 km (Ile Uvea 100 km, Ile Futuna 20 km)
paved: 16 km (all on Ile Uvea)
unpaved: 104 km (Ile Uvea 84 km, Ile Futuna 20 km)
Waterways: none
Ports: Leava, Mata-Utu
Merchant marine:
total: 1 oil tanker (1,000 GRT or over) totaling 26,000 GRT/40,000
DWT (1995 est.)
Airports:
total: 2
with paved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: small road network; Israelis have developed many highways to
service Jewish settlements
Ports: none
Airports:
total: 2
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 6,200 km
paved: 0 km
unpaved: 6,200 km
Ports: Ad Dakhla, Cabo Bojador, El Aaiun
Airports:
total: 12
with paved runways 2 438 to 3 047 m: 3
with paved runways under 914 m: 3
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 5 (1995 est.)
Heliports: 1 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 2,030 km
paved: 373 km
unpaved: 1,657 km (1988 est.)
Ports: Apia, Asau, Mulifanua, Salelologa
Merchant marine:
total: 1 roll-on/roll-off cargo ship (1,000 GRT or over) totaling
3,838 GRT/5,536 DWT (1995 est.)
Airports:
total: 3
with paved runways 2 438 to 3 047 m: 1
with paved runways under 914 m: 2 (1995 est.)
--------------
Railways:
total: 1,201,337 km includes about 190,000 to 195,000 km of
electrified routes of which 147,760 km are in Europe, 24,509 km in
the Far East, 11,050 km in Africa, 4,223 km in South America, and
4,160 km in North America; note - fastest speed in daily service is
300 km/hr attained by France''s Societe Nationale des Chemins-de-Fer
Francais (SNCF) Le Train a Grande Vitesse (TGV) - Atlantique line
broad gauge: 251,153 km
standard gauge: 710,754 km
narrow gauge: 239,430 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports: Chiba, Houston, Kawasaki, Kobe, Marseille, Mina'' al Ahmadi
(Kuwait), New Orleans, New York, Rotterdam, Yokohama
Merchant marine:
total: 25,521 ships (1,000 GRT or over) totaling 442,276,527
GRT/701,647,274 DWT
ships by type: barge carrier 22, bulk 5,308, cargo 8,089, chemical
tanker 920, combination bulk 307, combination ore/oil 279, container
1,938, liquefied gas tanker 709, livestock carrier 52, multifunction
large-load carrier 62, oil tanker 4,320, passenger 298,
passenger-cargo 117, railcar carrier 21, refrigerated cargo 1,022,
roll-on/roll-off cargo 1,034, short-sea passenger 484, specialized
tanker 81, vehicle carrier 458 (1995 est.)
--------------
Railways: 0 km
Highways:
total: 51,392 km
paved: 4,831 km
unpaved: 46,561 km (1992 est.)
Pipelines: crude oil 644 km; petroleum products 32 km
Ports: Aden, Al Hudaydah, Al Mukalla, Mocha, Nishtun
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 12,059 GRT/18,563 DWT
ships by type: cargo 1, oil tanker 2 (1995 est.)
Airports:
total: 41
with paved runways over 3 047 m: 2
with paved runways 2 438 to 3 047 m: 6
with paved runways 1 524 to 2 437 m: 1
with paved runways under 914 m: 3
with unpaved runways over 3 047 m: 2
with unpaved runways 2 438 to 3 047 m: 8
with unpaved runways 1 524 to 2 437 m: 9
with unpaved runways 914 to 1 523 m: 10 (1995 est.)','2b4357520e87d50b3eed6e2f7a08bd75bc23258b09438e50ec4be26203ccb3e3','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2336644611ea7229a0923b03d611bb1d369bf06e734a92c31947e19ad4bea8e',1996,'BW','Botswana','transportation',360,'--------------
Railways:
total: 2,759 km (1995)
narrow gauge: 2,759 km 1.067-m gauge (313 km electrified; 42 km
double track) (1995 est.)
Highways:
total: 91,078 km
paved: 14,572 km
unpaved: 76,506 km (1992 est.)
Waterways: Lake Kariba is a potential line of communication
Pipelines: petroleum products 212 km
Ports: Binga, Kariba
Airports:
total: 403
with paved runways over 3 047 m: 3
with paved runways 2 438 to 3 047 m: 2
with paved runways 1 524 to 2 437 m: 6
with paved runways 914 to 1 523 m: 8
with paved runways under 914 m: 185
with unpaved runways 1 524 to 2 437 m: 1
with unpaved runways 914 to 1 523 m: 198 (1995 est.)','40fecce0c3075850b69b4ec1f3edecd1766de4d1d64796bb67eb7e2614dc2c45','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee2f1819b1fbcbcb707aacc947be9dcf7bc1d14b04d99a3ae2446f04fdfbf780',1996,'','','raw',1,'BEST COPY AVAILABLE fm
CENTRAL INTELLIGENCE AGENCY
I4-GjIIIS OH \\ LOe AQ
BLANK PAGE
CENT A,
4
Cs
oe ie, 7 :
& a) Central
= &; Intelligence
Yat —f/ Agency
~~”
The
Worl
Factbook
1996
The printed version of the Factbook 1s published
annually in August by the Central Intelligence
Agency for the use of US Government officials.
and the style. format. coverage, and content are
designed to meet their specific requirements.
Information was provided by the American
Geophysical Union, Bureau of the Census.
Central Intelligence Agency. Defense
Intelligence Agency. Defense Mapping Agency.
Defense Nuclear Agency. Department of State.
Foreign Broadcast Information Service.
Maritime Administration, National Science
Founcation (Antarctic Sciences Section).
National Maritime Intelligence Center, Office of
Insular Affairs. US Board on Geographic
Names, US Coast Guard, and others.
Comments and queries are welcome and may
be addressed to
Central Intelligence Agency
Attn.: Public Affairs Staff
Washington, DC 20505
Telephone: [1] (703) 482-0623
Fax: [1] (703) 482-1739
Phe a
and ma
US Government officials may obtain printed of
other versions of The World Factbook directly
from their own organizations or through liaison
channels torm the Central Intelligence Agency
Other users may purchase copies trom
Document Expediting (DOCEN) Project
Exchange and Gift Division
Library of Congress
101 Independence Avenue, SE
Washington, DC 20540-4230
Telephone: [{1] (202) 707-9527
FAX: [1] (202) 707-0380
Photoduplication Service
Library of Congress
Washington, PC 20540-4230
Telephone: | 1] (202) 707-5640
FAX: [1] (202) 707-1771
Superintendent of Documents
P.O. Box 371954
Pittsburgh, PA 15250-7954
Telephone: | 1] (202) 512-1800
FAX: [BE] (202) 512-2250
http://www.odci.gov/cia
cthook ws also available on the [Internet
be accessed through the following
World-Wide Web uniform resou.ce locator
(URL)
//
CONTENTS
Page
Notes and Definitions vil
A Atghanistan |
Albania 3
Algeria 5
American Samoa _8
Andorra 9
Angola 11
Anguilla 13
Antarctica 15
Antigua and Barbuda 17
Arctic Ocean 19
Argentina 20
Armenia 22
Aruba 25
Ashmore and Cartier Islands 26
Atlantic Ocean 27
Australia 28
Austria 30
Azerbaijan 33
B Bahamas, The 35
Bahrain 37
Baker Island 39
Bangladesh 4()
Barbados 4?
Bassas da India 44
Belarus 45
Belgium 7 47
Belize 50
Benin $2
Bermuda 54
Bhutan 56
Bolivia 58
Bosnia and Herzegovina 60)
Botswana 63
Bouvet Island 65
Brazil 66
British Indian Ocean Territory 69
British Virgin Islands 70
Brunei 71
Bulgaria Lb
Burkina Faso 76
Burma 78
_ Burundi 80
Cc Cambodia 82
Cameroon R4
Carada 8&6
Cape Verde __ 89
Cayman Islands 9]
Central African Republic 9?
Chad O4
Page Page
Chile 97 Guatemala 196
China (a/so see separate 99 Guernsey 198
Taiwan entry) .
Cuinea 200)
Christmas Island 102 ; :
= Guinea-Bissau 202
Clipperton Island 104 ee ,
PP — Guyana 204
Cocos (Keeling) Islands 104 . BO
= H Haiti 206
Colombia W060 - ne
Heard Island and McDonald 18
Comoros LOS Islands a
Congo 0 Holy See (Vatican City ) 2009
Cook Islands 113 Honduras 210
Coral Sea Islands 114 Hong Kong )
Costa Rica 115 Howland Isiand —__
Cote d''Ivoire 117 Hungary
Croatia 119 I Iceland
Cuba 122 India 20)
Cyprus 124 Indian Ocean 224
Czech Republic 127 Indonesia 224
D Denmark 130 ran 2
Djibouti 132 Irag 229
Dominica 134 Ireland AB
Deminican Republic 136 Israel (also see separate Gaza 234
E Bosadios 138 Strip and West Bank enirics
Egypt a _ i40 ae ftaly Sarena le
El Salvador 143 J pamnnice —
Equatorial Guinea _ __—idAAS see eayen =-
Eritrea 147 Japan -
Estonia 149 sacvis Island =i
a soe fo “~* Y ih
Ethiopia _ 432 = —e
Europa Island 154 Johnston Atoll____ a
as . — a 5 A » 14
F Falkland Islands (Islas 155 a =
Malvinas) ee Juan de Nova Island
Faroe Islands 156 K Kazakstan
Fiji —____I5& Kenya | 254
Finland 160 Kingman Reef | 256
France 163 Kinbau 257
French Guiana 166 Korea, North 259
French Polynesia ___167 Korea, South 8
French Southern and Antarctic 169 Kuwait — 263
Lands SO :
—_—_-—--- Kyrgyzstan 26
G iabo a |
; Gabon ee L Laos 68
The Gambia 172 oo -
Latvia 21)
Gaza Stri 174 Rh tS
P — Lebanon af
Georgia 176 Be ttttS~*~S
E : OO Lesotho 4b
Germany 178 a
= ——-—— Libera ;
Ghana 181 =
Libya 279
Gibraltar 183 7 aa
, - Liechtenstein | 2 |
Glorioso Islands 185
Lithuania oni
Greece 1X6 .
—————— Luxembourg 288
Greenland 188 <0 a
Aca sSrcclaar ane M Macau 287
Grenada 190 oo
oe Macedonia, The Forme 289
Guadeloupe 192 Yugoslav Republic of .
Guam 194 Madagascar 292
CONTENTS (continued)','a60bf1eb594348a649081252be058c0ebdbaa3bfa33d4a09ed5c3c525bfd1a9d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f22a4a420fd226c8f00c8f17b62812f6202b66491c3e2d8e5bb36ea4aed55ef',1996,'MH','Marshall Islands','raw',2,'Marti
igude
>
+: Jerated St
ales
Page Page
Palmyra Atoll 370 Swaziland 454
Panama 371 Sweden 456
Papua New Guinea __ 373 Switzerland 159
Paracel Islands 376 Syria 461
Paraguay CT i Taiwan entry follows
Peru 379 Zimbabwe _
Philippines 381 Tapkistan 464
Pitcairn Islands 384 Tanzania 466
Poland 386 Thailand 469
Portugal 388 Togo 47]
Puerto Rico Token RT
Q_ (Qatar 393 Tonga 475
R Reunion 395 Trinidad and Tobago 77
Romania 396 Tromelin island 479
Russia 399 Tunisia —s—~—~—=~SSY
_ Rwanda 403 Turkey 4x2
S Saint Helena 405
a : Turkmenistan 484
Saint Kitts and Nevis 407
Turks and Caicos Islands 487
Saint Lucia 408 ; —_
Saint Pierre and Miqucion 410 ee —— —-
Saint Vincent and the 4]2 . —_= a
Grenadines Ukraine 492
San Marino United Arab Emirates 495
Sao Tome and Principe 415 United Kingdom 497
Saudi Arabia 417 United States SOO
Senegal 420 Uruguay 5003
Serbia and Montenegro 422 Uzbekistan 505
Seychelles 424 V Vanuatu 508
Sierra Leone 426 Venezuela S10
Singapore 428 Vietnam 512
Slovakia £00 _ Virgin Islands 515
sanesa Wake Island 516
Soromon anes a2) Wallis and Futuna 517
— = West Bank 519
South Africa 439 , _
— —— Western Sahara $21
South Georgia and the South = 441 - ~~ ~~
Sandwich !slands Western Samoa 522
Spain” 7 442 «World ___524
Spratly Islands AS Yemen 526
Sri Lanka. 44600 Zaire SRK
Sudan ee 2) Zambia 531
Suriname ASI Zimbabwe | — 533
Svalbard | 453 Taiwan $35
iV
Appendices A: Abbreviations 538
B: United Nations System 546
C: International Organizations and Groups 547
D: Selecied International Environmental Agreements 598
E: Weights and Measures 606
F: Cross-Reference List of Country Data Codes 620
G: Cross-Reference List of Hydrographic Data Codes 630)
635
H: Cross-Reference List of Geographic Names
Keference Maps
North America
Central America and the Caribbean
South America
Europe','682278b8ef80a448fd5edc8a0c8c05876ea903f264d21d4a3f5e25f7608380d7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d208dafa99f30f9165823007c6f582fc42b5772ca4197758954bce6a799eac1',1996,'BA','Bosnia and Herzegovina','raw',3,'Middle East
A t rica
Asia
Commonwealth of Independent States
Southeast Asia
Oceania
Arctic Region
Antarctic Reson
Standard Time Zones of the World
Political Map of the World, August 1996
Notes and Definitions
There have been some significant changes in this edition. The maps accompanying
each entity include more detai,. adjoming countnes. and bodies of water. Flags
are also shown for nearly all entities. The spelling of Kazakhstan has been changed
to Kazakstan and the name of Burkina has been changed to Burkina Faso. There
are new entries on Geographic coordinates, Sex ratio, Heliports, Industrial
production growth rate, Telephones, and GDP composition by sector. 1)
Radio entry has been replaced by two new entnies—Radios and Radio broadcast
Stations. The Television entry has been replaced by two new entries— Televisions
and Television broadcast stations. The Digraph entry hay been renamed Data
code and the Member of entry has been renamed International organization
participation. The National product, National product real growth rate, .
National product per capita entries have been renamed GDP, GDP real growth
rate, and GDP per capita, respectively. Highest and lowest points have been
added to the Terrain entry. All abbreviations used in the Factbook have bec
consolidated into a new appendia— Appendix A: Abbreviations. spall Hi:
Cross-Reference List of Geographic Names now inciudes geographic Coordinak
for each entry. Two new appendixes have been added—Appendinx F: Cross-
Reference List of Country Data Codes and Appendix ©: Cross-Reference List
of Hydrographic Data Codes. New reference maps tor Besnia and Herzegovina,
the Commonwealth of Independent States, and the World have also been adc
Abbreviations: (see Appendix A)
Administrative divisions: The numbers. designator) terms. and tirst-orde
administrative divisions are generally those approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet acted
on by BGN are noted
Age structure: The distnbution of a population according to age. usually by tiv.
year age groups. The age structure of a population will affect where the country
needs to invest resources. Countries with young populations (high percentage under
age 15) need to invest more in schools. while countnes with ok fer vanlaines
(high percentage ages 65 and over) need to worry about nursing homes. ete. The
age structure can also be used to help predict potential politycal issues. For ex amp
the rapid growth of a young adult population unable to find employment can lead
to unrest
Airports: Only airports with usable runways are included in this listing. For airports
with more than one runway, only the longest runway ts included. Not ail airports
have tacilities for refueling. maintenance. or air tratfie control. Paved runways
have concrete or asphalt surfaces: unpaved runways have grass. dirt. sand. or gravel
surfaces
Area: Total ares. 1s the sum of all land and water areas delimited by international
boundanes and/or coastlines. Land area ts the aggregate of all surtaces delimited
by internation: | boundaries and/or coastlines. excluding inland water bodies (lakes
reservoirs, rivers). Comparative areas are based on total area equivalents. Most
entities are compared with the entire US or one of the SO states. The smaller
entities are compared with Washington. DC (17s sq kin. 69 sq on) or The Mali
in Washington, DC (0.59 sq km, 0.23 sy mi. 146 acres)
Birth rate: The average annual number of births during a yeat per |.000 population
at midyear: also known as crude birth rate The birth rate ts usually the dominant
factor in determing the rate of population growth. It depends on both the level
of tertility and the age structure of the population
Data codes: The data code is an official US Government standard thai precisely
identifies every land entity without overlap. duplication, or omission. AF. tor
example, is the data code for Afghanistan. This two-letter country code or digraph
is a Standardized geopolitical data element Apyeneuts in the Federal Information
Processing Standards Publication (FIPS) 10-4 by the National Institute of Standards
and Technology at the US Department of Commerce and maintained by the Office
of the Geographer and Global Issues at the US Department of State. The data
code 1s used to eliminate confusion and incompatibility in the collection. processing.
and dissemination of area- specific data and ts particularly usetul for interchanging
data between databases Appendix F is a cross-reference list of FIPS. International
vii
Notes and Definitions—continued
vill
Organization for Standardization (ISO), and Internet country codes. The US
Government has not yet approved a standavd for hydrographic codes similar to
the FIPS 10-4 standard for country codes. but Appendix G provides a cross-
reverence list of International Hydrographic Organization (THO), Aeronautical Chan
and Information Center (now Defense Mapping Agency). and Defense Intelligence
Agency hydrographic codes
Dates of information: In general. information available as of | January 1996
is used in the preparation of this edition. Population figures are estimates for |
July 1996, with population growth rates estimated for calendar year 1996. Mayor
political events have been updated through May 1996
Death rate: The average annual number of deaths during a year per 1,000
population at midyear. also known as crude death rate. The death rate. while only
a rough indicator of the mortality situation in a country. accurately indicates the
current mortality impact on population growth. This indicator ts significantly
attected by the age distnbution. and most countnes will eventually show a rise
in the rate. in spite of continued declines in mortality at all ages. as declining
fertility results in an aging population
Diplomatic representation: The US Government has diplomatic relations with 184
nations, including 178 of the 18S UN members ,excluded UN members are Bhutan.
Cuba. Iran. Ieag. North Korea, former Yugoslavia, and the US itself). In addition,
the US has diplomatic relations with 6 nations that are not in the UN—Holy
See. Kintbat.. Nauru, Switzerland, Tonga, and Tuvalu
Economic aid: This entry reters to bilateral commitments of official development
assistance (ODA) and other official flows (OOF). ODA ts defined as financial
assistance Which ts concessional in character. has the main objective to promote
economic development and welfare of LDCs. and contains a grant element of at
least 25°. OOF transactions are also official government assistance. but with a
main objective other than development and with a grant element less than 25%
OOF transactions include official export credits (such as Ex-Im Bank credits).
official equity and portfoiio investmeni, and debt reorganization by the official
sector that does not meet concessional terms. Aid ts considered to have been
committed when agreements are initialed by the parties involved and constitute
a torma!l declaration of intent
Entities: Some of the nations, dependent areas. areas of special sovereignty, and
governments included in this publication are not independent, and others are not
officially cogmized by the US Government. “Nation” refers to a people politically
organized into a sovereign state with a definite territory. ““‘Dependent area’ refers
to a broad categery of political entities that are associated in some way with
a nation. Names used for page headings are usually the short-form names as
approved by the US Board on Geographic Names. There are 267 entities in The
World Factbook that may be categorized as follows:
NATIONS
184 UN members cexclhuding the former Yugoslavia. which os sull counted by the UN)
7 nations that are not members of the UN-——-Holyv See. Kanbati. Nauru. Serbia and
Montenegro. Swazeriand, Tonga. Tuvalu
OTHER
| Taman
DEPENDENT AREAS
® Australia —Ashmore and Cartier Islands, Christmas Island. Cocos (Keeling) Islands. Coral
Sea Islands. Heard Island and McDonald Islands. Nortolk Island
Denmark — Faroe Islands. Greenland
ta
if
“
France Bassas da India. Clipperton Island, Europa Island, French Guiana, French
Polynesia, French Southern and Antarctic Lands. Glonoso stands, Guadeloupe. Juan
de Nova Island. Martumque, Mavotic, New Caledoma. Reunion, Saint Pierre and
Miquelon, Tromelin island, Wallis and Futuna
Nethertands— Aruba, Netherlands Antilles
New Zesland—Cook Islands, Nae, Tokelau
Norway —Bouvet Island, Jan Mayen. Svalbard
4
-
~
Notes and Definitions—continued
| Pornugal— Macau
16 United Kingdom—Anguilla. Bermuda, Brush Indian Ocean Termory. Botish Virgin
Islands. Cayman Islands. Falkland Islands. Gibraltar. Guernsey. Hong Kong. Jerscy. Ist
of Man. Montserrat. Pucaum Islands. Saomt Helena. South Georgia and the Sout!
Sandwich Islands. Turks and Cascos Islands
14 United States—Amencan Samoa. Baker Island, Guam. How land Island. Jarves Islas
Johnsion Atoll, Kingman Reet. Midway Islands. Navassa Island. Northern Mariana
Islands, Palmyra Atoll, Puerto Rico. Virgin Isiands. Wake bland
MISCELLANEOUS
6 Antarcica, Gaza Simp. Paracel! Islands. Spratly Islands. West Bank. Westcrn Sahara
OTHER ENTITIES
4 aceanms—Arcte. Occan. Adantc Ocean. lndhan Ocean. Pacitie Ocean
| World
266 Total
Exchange rate: The official value of a nation’s monetary uni at a given date
or over a given penod of time. as expressed in units of local currency per US
dollar and as determined by international market forces or official fiat
Flags: In addition to the written flag descriptions in the Government section.
flags in color are displayed at the beginning of the text for nearly all entities
in the Factbook. The flags of independent nations are used by their dependencies
unless there ts an officially recognized local flag. Some disputed and other areas
do not have a flag. The flags were produced trom the best information available
at the ume theFactbook. went to press. but some may have changed completely.
show a variance in detail. or a change in color from the current official flag
GDP methodology: In the Economy section. GDP dollar estimates tor all countries
are derived from purchasing power panty <PPP) calculations rather than from
conversions at official currency exchange rates. The PPP method involves the use
of international dollar price weights. which are applied to the quantities of goods
and services produced in a given economy. The data derived from the PPP method
provide 2 better comparison of economic well-being between countries. The division
of a GDP estimate in domestic currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. When priced in PPPs. $1,000 will buy the
same market basket of goods in any country. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing counties are often rough
approximations. Most of the GDP estimates are based on extrapolation of numbers
published by the UN International Comparison Program and by Professors Robert
Summers and Alan Heston of the University of Pennsylvania and their colleagues
Currency exchange rates depend on a varnety of international and domestic financial
forces that often have little relation to domestic output. In developing countries
with weak currencies the exchange rate estimate of GDP in dollars ts typically
one-fourth to one-half the PPP estimate. Furthermore. exchange rates may suddenly
go up or down by 10% or more because of market forces or official fiat whereas
real output has remained unchanged. On 12 January 1994. jor example. the 14
countnes of the Afncan Financial Community (whose currencies are tied to the
French franc! devalued their currencies by SO. This move. of course, did not
cut the real output of these countnes by half. One important caution: the proportion
ul, say. defense expenditures as a percentage of GDP im local currency accounts
may differ substantially from the proportion when GDP accounts are expressed
in PPP ter.ns, as, for example. when an observer tries to estimate the dollar level
of Russian or Japanese military expenditures. Note: The numbers for GDP and
other economic data can not be chained together from successive volumes of the
Factbook because of changes in the US dollar measuring rod. revisions of data
by statistical agencies, use of new or different sources of information, and changes
in National statistical method. and practices. For statistical serres on GDP and
other economic variables, see the Handbook of International Economic Statistics
available from the same sources as The World Facthook
Gross domestic product (GDP): The value of all goods and services produced
within a nation in a given year
Notes and Definitions—continued
Gruss national product (GNP): The value of all goods and services produced
within a nation in a given year. plus income earned abroad. minus income earned
by foreigners from domestic production.
Gross world product (GWP): The aggregate value of all goods and service:
produced worldwide in a given year
IMicit drugs: There are five categones of illicit drugs—narcotics, stimulants.
depressants (sedatives). hallucinogens, and cannabis. These categories include many
drugs legally produced and prescribed by doctors as well as those illegally produced
and sold outside of medical channels
Cannabis (Cannabis sativa) is the common hemp plant. which provides
hallucinogens with some sedative properties, and includes manjuana (pot. Acapulco
gold, grass, reefer). tetrahydrocannabinol (THC, Mannol). hashish (hash). and
hashish oil (hash oil).
Coca (mostly Erythroxylum coca) ts a bush, and the leaves contain the stimulant
used to make cocaine. Coca ts not to be confused with cocoa. which comes from
cacao seeds and 1s used in making chocolate. cocoa, and cocoa butter.
Cocaine 1s a stumulant derived from the leaves of the coca bush
Depressants (sedatives) are drugs that reduce tension and anxiety and include
chloral hydrate. barbiturates (Amytal, Nembutal, Seconal. phenobarbital).
benzodiazepines (Librium. Valium), methaqualone (Quaalude). glutethimide
(Donden), and others (Equanil. Placidyl. Valmid).
Drugs are any chemical substances that effect a physical, mental, emotional.
or behavioral change in an individual
Drug abuse ts the use of any licit or illicit chemical substance that results
in physical, mental, emotional, or behavioral impairment in an individual.
Hallucinogens are drugs that affect sensation, thinking. self-awareness, and
emotion. Hallucinogens include LSD (acid, microdot), mescaline and peyote (mexc.
buttons, cactus), amphetamine variants (PMA, STP. DOB). phencyclidine (PCP.
angel dust, hog). phencyclidine analogues (PCE, PCPy, TCP). and others
(psilocybin, psilocyn)
Hashish ts the resinous exudate of the cannabis or hemp plant (Cannabis sativa)
Heroin ts a semisynthetic derivative of morphine
Mandrax ts the Southwest Asian slang term for methaqualone, a pharmaceutical
depressant
Marijuana ts the dned leaves of the cannabis or hemp plant (Cannabis sativa)
Methaqualone ts a pharmaceutical depressant, in slang referred to as Quaaludes
in North America or Mandrax in Southwest Asia
Narcotics are drugs that relieve pain, often induce sleep. and refer to opium.
opium derivatives, and synthetic substitutes. Natural narcotics include opium
(paregonic, parepectolin), .norphine (M1S-Contin, Roxanol). codesne (Tylenol with
codeine, Empirin with ce deine, Rotatussan AC), and thebaine. Semisynthetic
narcotics include heroin ta@urse, smack). and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan). methadone
(Dolophine, Methadose). and others (Darvon, Lomotil)
Opium ts the brown, gummy exudate of the incised. unripe seedpod of the
Opium Poppy
Opium poppy (Papaver somniferum) ts the source for the natural and
semisynthetic narcotics
Poppy siraw concentrate 1s the alkalead derived from the mature dred opium
POPP)
Qat (kat, khat) is a stemulant from the buds or leaves of Catha edulis that
is chewed or drunk as tea
Quaaludes ts the North American slang term for methaqualone, a pharmaceutical
depressant
Stimulants are drugs that relieve mild depression, increase energy and activity,
and include cocaine (coke. snow, crack), amphetamines | Desoxyn, Dexedrine).
phenmetrazine (Preludin), methylphenidate (Ritalin). and others «Cylen, Sanorex.,
Tenuate)
Infant mortality rate: The number of deaths to infants under one year old in
a given year per 1.000 live births occurring in the same year. The infant mortality
rate 1s often used as a good indicator of the level of health in a country
Notes and Definitions—continued
international disputes: This category includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral claims of one sort
or another. Information regarding disputes over international boundanes and
maritime boundanes has been reviewed by the Department of State. References
to other situations involving borders or frontiers may also be included. such as
resource disputes, geopolitical questions. or inredentist issues. However, inclusior
does not necessanly constitute official acceptance or recognition by the US','68fdcf61ceed1603c43281a1b4867058c83f3a7cf0038d078bddb2bea3e97310','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a361417826e423671882cd6e2f826ccd4334f074533fe7f74b19a0f2cc165b5',1996,'','','raw',1,'The Project Gutenberg EBook of The 1996 CIA Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 1996 CIA Factbook
Author: United States. Central Intelligence Agency.
Release Date: December 31, 2008 [EBook #27675]
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 1996 CIA FACTBOOK ***
Produced by Al Haines
THE 1996 CIA WORLD FACTBOOK
[Transcriber''s note: At the time of the preparation of this
file (December 2008), the various supplementary sections
of the 1996 Factbook (Appendixes, Notes and Definitions,
History, etc.) were no longer available. Users of this
edition should refer to the Project Gutenberg''s versions
of the 1995 and 1997 Factbooks for those sections. Note
that there may be changes in this material from year to year.]
A','6e5ce56688c2df62ee285025947d6a8cbe07c73e01116baa9f210871ffcac124','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f4766da1bf36b111fa0fb56c0198621204ceee247d9f2d3fb72ffa9cdd73eac',1996,'ZW','Zimbabwe','raw',2,'=====================================================================
@Afghanistan
-----------
Map
---
Location: 33 00 N, 65 00 E -- Southern Asia, north of Pakistan
Flag
----
Description: three equal horizontal bands of green (top), white,
and black with a gold emblem centered on the three bands; the emblem
features a temple-like structure with Islamic inscriptions above and
below, encircled by a wreath on the left and right and by a bolder
Islamic inscription above, all of which are encircled by two crossed
scimitars','12f51aa29a7af4d405c9781fb90a4bd8b28da3b098b8ec6c0e7b040f64b63c9a','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

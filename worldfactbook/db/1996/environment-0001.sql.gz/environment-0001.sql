SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('347663aab1129226a2e8244b704873c48894222f01e31f1561d0c907e4dff7d6',1996,'TM','Turkmenistan','environment',7,'current issues: soil degradation: overgrazing:
deforestation (much of the remaining forests
are being cut down for fuel and building
materials); desertification
natural hazards: damaging earthquakes
occur in Hindu Kush mountains: flooding
imernational agreements: party to—
Endangered Species, Environmental
Modification, Marine Dumping. Nuciear Test
Ban: signed. but not ratified—Biodiversity.
Climate Change. Desertification, Hazardous
Wastes. Law of the Sea. Marine Lite
Conservation
Geographic note: landlocked','3f9ded8fc7cda17fdc54796e9edf519838cce43b145cd91e224bf4d675d8922c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16c35667601a962906e49c0d6170ca6a7e12490f8ef8a7e7f9f0c2ee7327f1c0',1996,'AL','Albania','environment',15,'a7re vil ise ic
Nlerniahonal avcrec
Brovcdiv sity. ( j ef
Geographic note:
Strait of Otrant ‘
lonran Sea and M
Med
ry vere
‘ \\1 ()
’ '' WW c i
i? |
\\ \\ bg
Geographic note Be \\
\\
current issues: limited natural fresh water
resources. im many areas of the island. water
supplies Come from roof catchments
natural hazards: typhoons common trom
December to March
international agreements: NA
Geographic note: Pago Pago has one of the
best natural deepwater harbors in the South
Pacitic Ocean. sheltered by shape from
rough seas and protected by penpheral
mountains from high winds: strategic
location in the South Pacific Ocean
current issues: detorestation, overgrazing of
mountain meadows contributes to soil
cTOSION
natural hazards: snowslides. avalanches
mternational agreements: NA
Geographic note: landlocked
9
/$
kndorra (continued)
, »
Peo,
Pop maitien tf fu \\ YU est.)
\\ irtiactare:
SS29. female S.SS1)
{ $297 Io
+. iCiibediC
Population growth rate: 296% (i996 est)
Birth rats | O00) population
Death rate bs 1.000 population
Set ougration rate: 22.29 micrantisV 1.000
val
; ; i.»
'' ATA
t ti»
oo rT‘
it i SMa Ii tic
''
nianat mortatity rate: 2 2 deaths/! 000 live
Pile expectanes at birth:
sue - )
} otal fertuhits rats } Children born
Nationality:
4
Pthoic divisions \\ndorrar
#chigions: | mwedominant)
mviaves tional). Fr
ihcnt
uintirs
I |
e
Deatia coocke
Iype of government: parliamentary
that retains
rincipality. the two
| France and
‘ le Lrvel. who are
'' als called
Capital: Andorra ta Vella
Administrative divisions: 7 parishes
parroquiad: Andorra.
PaAPTimgitie SNL UE
10
Canillo, Encamp, La Massana, Les Escaldes,
Ordino, Sant Julia de Lona
Independence: | 275
National holiday: Mare de Deu de
Meritxell, 8 September
Constitution: Andorra’s first written
constitution was drafted in 1991: adopted I4
March 1993
Legal system: based on French and Spanish
civil codes: no judicial review of legislative
acts: has not accepted compulsory ICJ
jurisdiction
Suffrage: |S years of age: universal
Executive branch:
chiefs of state: French Coprince Jacques
CHIRAC (since 17 May 1995) and Spanish
Episcopai Coprince Monseigneur Juan
MARTI Alanis (since 31 January 1971):
each coprince Is represented by a veguer
(current names NA)
head of government: Executive Council
President Marc FORNE Molne (since 21
December 1994) was elected by the General
Council and formally appointed by the
coprinces
cabmet: Executve Council was designated
by the executive council president
Legislative branch: unicameral!
General Council of the Valleys (Conseil
General de les Valls): elections last held 12
December 1993 (next to be held NA 1997);
results - percent of vote by party NA:
seats—1 28 total) AND &. UL 5. ND 5. CNA
2. IDN 2. other 6
Judicial branch: Supreme Court of Andorra
at Perpignan (France) tor civil cases, two
civil yudges appointed by the veguers. one
appeals judge appointed by the co-princes
alternately» Eeclesiastical Court of the
Bishop of Seo de Urgel (Spain) tor civil
cases: Tribunal of the Courts (Tribunal des
Cortes) for criminal cases. presided over by
the two civil judges. one appeals judge. the
veguers, and two members of the General
Council
Political parties and leaders: Nationa!
Democratic Group (AND). Oscar RIBAS
Reig and Jordi FARRAS: Liberal Union
(UL). Francese CERQUEDA: New
Democracy (ND), Jaume BARTOMEU:
Andorran National Coalition (CNA), Antoni
CERQUEDA, National Democratic Initiative
(DN). Vincene MATEL: Liberal Union
(UL). Mare FORNE
note. there are two other small parties
International organization participation:
Ck. ECE. IFRCS, Interpol. IOC, ITU. UN.
UNESCO, WIPO
Diplomatic representation in US:
chief of mission: Ambassador Juli
MINOVES-TRIQUELL (also Permanent
Representative to the UN)
embassy: 2 United Nations Plaza. 25th Floor.
New York, NY LOOL7
telephone: (212) 750-8064
FAX: (212) 750-6630
US diplomatic representation: the US does
not have an embassy in Andorra; US
interests in Andorra are represented by the
Consulate General''s office in Barcelona
(Spain): mailing address: Paseo Reina
Elisenda, 23, 08034 Barcelona, Spain:
telephone: (343) 280-2227; FAX: (343; 205-
7705; note—Consul General Maurice S.
PARKER makes periodic visits to Andorra
Flag: three equal vertical bands of blue
(hoist side). yellow, and red with the
national coat of arms centered in the yellow
band: the coat of arms features a quartered
shield: similar to the flags of Chad and
Romania that do not have a national coat of
arms in the center','6e7ab65ab57f92479adf2024be09187e2768b1fadb8fa81da39d216880a1e951','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee4a87d0db601628bd3262078a8efc657825f6aedebe753e553390cdea7d3f67',1996,'ES','Spain','environment',22,'current issues. population pressures
4
contributing to overuse of pastures and
subsequent sot! erosion. desertification
deforestation of tropical rain torest
atibutable to the international demand for
tropical timber and domestic use as a fuel:
deforestation contributing to loss of
biodiversity: soil erosion contributing to
water pollution and siltation of rivers and
dams: inadequate supplies of potable wate:
natural hazards: locally heavy raintall
causes periodic flooding on the plateau
uuernational agreements. party to——Law
the Sea: signed. but not ratitied
Biodiversity, Climate Change. Desertification
Geographic note: Cabinda ts separated trom
rest of country by Zaire
current issues: soil erosion, air pollution
caused by industrial and vehic!< emissions:
water pollution, especially in coastal areas
ratural hazards: Azores subject to severe
earthquakes
international agreements: party to—Air
Pollution, Biodiversity, Climate Change.
Endangered Species. Hazardous Wastes.
Marine Dumping. Marine Lite Conservation.
Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Wetlands: signed. but
not ratified—Air Pollution-Volatile Organic
Compounds, Desertification, Environmental
Modification, Law of the Sea. Nuclear Test
Ban
Geographic note: Azores and Madeira
Islands occupy strategic locations along
western sea approaches to Strait of Gibraltar
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: climatologically important
location for forecasting cyclones; wildlife
sanctuary','27a7eb90caada10fc73b41b32e247cd228473d702eea22c4dc860921b9cba1cf','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77415b28da2bb3e0d59a80f101c48a2f2bddd6bcb8a12263b2613b6e5da0ebb0',1996,'BR','Brazil','environment',29,'current issues: supplies of potable water
sometimes cannot meet increasing demand
largely because of poor distribution system
natural hazards: frequent hurricanes and
other tropical storms (July to October)
13
Anguilla (continued)
iiies 4 aj advrec*mcis NA','09308b7422ec13fd94ad8b951413152405e90cc69bf4fec1c50712948d4e063f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8fb57b1f0a102a357ab724cc3e3ef46ade19fa23ad3b60ebbdece0fa428ce4b',1996,'AQ','Antarctica','environment',33,'current issues. i Octol Ol uw
reported that the
the Earth s surtece tror
radiation. had dwind
recorded over Antarctn ! os
measurements Were ty Lake
natural hhacards: katabat era
winds blow coastward | ihn
Irequent! blizzards
plateau CVC hone lin | ttl
and Mwave CIOCK WIS i
volcanism on Deception Isha
reas of West Antarc
KTINGEN rare and weab
Memalional Gerecmen4s XN \\
Geographic note: the coldest
highest. and dnest coninent: dus
more solar radiation reaches th
the South Pole than 1s received al tl
Equator in an equivalent period: mos
uninhahitabl«
current iwsues. erosion results trom
inadequate flood controls and improper land
use practices: imygated soil degt.dation:
desertification: air pollution in Buenos Aires
and other mayor cities, water pollution in
urban areas. rivers becoming polluted due to
increased pesticide and fertilizer use
natural hazards: Tucuman and Mendoza
areas in the Andes subject to earthquakes.
pamperos are violent windstorms that can
strike the Pampas and northeast: heavy
Hooding
miternational agreements nearly lo
\\ntarcic-Environmental Protocol, Antarctic
Treaty. Biodiversity. Climate Change.
Endangered Species. Environmental
Modification. Hazardous Wastes. Law of the
Sea. Marine Dumping. Nuclear Test Ban.
Ozene Layer Protection, Ship Pollution.
Wetlands: signed. but not ratified—
Desertification, Marine Lite Conservation
Ceographic note: second-largest country in
South America (after Brazil): strategic
location relative to sea lanes between South
Atlantic and South Pacific Oceans (Strait of
Magellan, Beagle Channel. Drake Passage)','06886ea34819f30ecdab48e276da424519a4dea2b6d7012f54e96a43d06468aa','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00ac41edabd378009e8feebca25e58ccb8de317dc51a9bd44eef07fa34473f3c',1996,'AG','Antigua and Barbuda','environment',40,'current issues
Waler Management— 4 mayor
concern because of limited natural fresh
Maler resources
‘
clearing of ifees to mecrease crop prod
is further hampered by the
E
causing raintall to run off quickly
natural hazards. hurmcanes and tropical
storms (July to October): periodic droug
wifermanhional aereei p Ik
Biodiversity. Climate Change. | ronm
Modification Hazardous W ast. i
Sea. Marine Dumping. Nuclear 1
Ozone Layer Protection. Ship P
Wha inv’. sighed Mul thot ratifies
Desertulicaty
urrent issues” endangered n
mclude walruses and whales
eoosvsiem stow to change a
recover trom disruptions or damag«
raailural ih / Gg
bre th Ma tro } 1? i | ]
weberg¢s calved trom vilacrers m «
Greenland and ext mc mwtheas m (a
permairost in wlands. virtually te Kod
trom Octover to June. shy
superstructure cing trom October to Mf
hlerinaliona areca 4 \\\\
C,eographic note: major Chokep
uthern Chukch: Sea mhert ss to the
Pacilic Ocean via the Bering Strait). strates
location between North America and Ru
snortest marine link between the extremes «
eastern and western Rus | line rescan
Sluations operated by US and Ru
maximum snow March or April
about 20 to SO centimeters over the trozer
Kw. i! \\ We r ii] | 1}','b3d86ea69ad4e852cc1b5a270bff22ebe5a1cc593246f4a1200870bc09488fca','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7f0242db3b73ef956994305a3a163eddfc2eda33796eb27a8bc59b29bf76a59',1996,'AZ','Azerbaijan','environment',50,'current issues: soil pollution from toxic
chemicals such as DDT: energy blockade.
the result of conflict with Azerbaijan. has led
to deforestation as citizens scavenge for
firewood: pollution of Hrazdan (Razdan) and
Aras Rivers, the draining of Sevana Lich. a
result of its use as a source for hydropower,
threatens drinking water supplies: restart of
Metsamor nuclear power plant without
adequate (IAEA-recommended) safety and
backup systems
natural hazards: occasionally severe
earthquakes. droughts
imiernational agreements: patty to—
Biodiversity, Climate Change. Nuclear Test
Ban. Wetlands: signed. but not ratified—
Desertification
Geographic note: land! ocked
Population: 3.463.574 uly 1996 est.)
Age structure:
0-14 vears: 28% (male 497,461. temale
476.649)
15-64 vears: 64% (male 1.085.935: female
1.132.282)
65 vears and over: 8% (male 111.661:
female 159.586) Ululy 1996 est.)
Population growth rate: 0.02% (1996 est.)
Birth rate: 16.27 births/!.000 population
(1996 est.)
Death rate: 7.73 deaths/1.000 population
(1996 est.)
Net migration rate: -§.3 migrantisy/! 000
population (1996 est.)
Sex ratio:
at birth: 1.05 maleisWfemale
under 15 vears: 1.04 maleisWtemale
15-64 vears: 0.96 male(s\\female
65 vears and over: 0.7 maletsWtlemale
all ages: 0.96 maleisWiemale (1996 est.)
Infant mortality rate: 38 9 deaths 1.000
live births (1996 est.)
Life expectancy at birth:
total population: 69.06 years
male: 64.44 years
female: 73.92 years (1996 est.)
Total fertility rate: 2.06 children born/
woman (1996 est.)
Nationality :
noun. Armenianis)
adjective. Atmeman
Ethnic divisions: Armenian 93°. Aven 3%.
Russian 2%. other (mostly Yezidi Kurds) 2%
(1989)
note: as of the end of 1993. virtually all
Azeris had emigrated from Armenia
Religions: Armenian Orthodox 94%
Languages: Armenian 967. Russian 2%.
other 2%
Literacy: age 15 ar.’ over can read and
write (1989 est.)
total population: 99%
male: 99%
female: 98%
Name of country:
conventional long form: Republic of
current issues: local scientists consider the
Abseron (Apsheron) Peninsula (including
Baku and Sumyayit) and the Caspian Sea to
be the ecologically most devastated area in
the world because of severe air, Wile aud
soil pollution: soil pollution results from the
us? of DDT as a pesticide aad also trom
toxic defohants used in the production of
cotton
natural hazards: droughts. some fowland
areas threatened by rising levels of the
Caspian Sea
international agreements, party to—Climate
Change: signed, but not ratified
Biodiversity
Geographic note: landlocked
current iwsues” coral reet decay
natural hasards” Warncanes and other
tropical storms that cause extensive food
and wind damage
miernational agrcements party to
Biodiversity. Climate Change. Endangered
as
"*
The Bahamas (continued) Data code: BF US diplomatic representation:
Type of government: commonwealth chief of mission: Ambassador Sidney
Species. Hazardous Wastes, Law of the Sea. Capital: Nassau WILLIAMS
Nuclear Test Ban. Ozone Layer Protection. Administrative divisions: 2| districts: embassy: Mosmar Building, Queen Street,
Ship Pollution. Whaling Acklins and Crooked Islands, Bimini, Cat Nassau |
Geographic note: strategic location adjacent Island, Exuma, Freeport. Fresh Creek. mailing address: P.O. Box N-8197, Nassau:
tS and Cuba. extensive bland chain Governor''s Harbour, Green Turtle Cay, P.O. Box 9009, Miami, FL 33159. Nassau.
Harbour Island, High Rock, Inagua, Kemps Department of State, Washington, DC
Bay. Long Island, Marsh Harbour. 20521-3370 (pouch)
; Mayaguana, New Providence. Nicholls Town —!elephone: [1] (809) 322-1181, 328-2206
People and Berry Islands. Ragged Island, Rock FAX: (1] (809) 328-7838
Population: 259.367 uly 1996 est) Sound, Sandy Point San Salvador and Rum Flag: three equal horizontal bands of
Ave structure: Cay aquamarine (top), gold, and aquamarine with
(1-14 4 2s''c (male 36.331: female Independence: |(0) July 1973 (from UR) a black equilateral tnangle based on the host
NS. 7 National holiday: National Day. 10 July side
''S-O4 years. 67% (male 84.107; female (1973)
NTS . Constitution: 10 July 1973 a
. rsand over: X% (make 5.449. female Legal system: based on English common .
S16) July 1996 est) law . Economy
Population growth rate: 1.05% (1996 est.) Suffrage: 18 years of age: universal Economic overview: The Bahamas ts a
Birth rate: 18.73 birthy/1.000 population Tuscutive bromine: stable. developing nation with an economy
pio ‘
Queen ELIZABETH I (since heavily dependent on touzism and offshore
6 February 1952) is a hereditary monarch, banking. Tourism alone accounts for more
represented by Governor General Sir Orville than 50% of GDP and directly or indirectly
TURNQUEST (since 2 January 1995) who employs 40% of the archipelagos labor
force. A slowdown in the expansion of the
tourism sector—especially stopover travel
7 hief of stat
Death rate: 5.74 deaths/1.000 population che] of state
(iYV6 est:
Net migration rate: -2 54 migrantis)/1.000
population (1996 est)
was appointed by the queen
head of government: Prime Minister Hubert
Alexander INGRAHAM (since 19 August wom Europe—ted to a reduction in the
1992) and Deputy Prime Minister Frank country’s GDP growth rate in 1995. down to
Sex ratio:
at birth) 102 maleisWtlemale
. . .
under 15 vears: 1.02 matetsVtemale
8-64 years: 0.94 maie(sWiemale .
: wars ciad cnet ead laren WATSON (since NA) were appointed by the an estimated 2% from 3.5% in 1994. The
construction sector benefited from hotel
all ages. 0.94 maletsWtemale (1996 est.) governor general rehabilitation and the government''s ongoing
Infant mortality rate: 23.3 deaths/1.000 cabinet: Cabinet was appointed by the aueien devek sane e eee Hesle _
live births (1996 est) governor general on ithe prime minister''s ‘eon pot oa adil and ans £
Life expectancy at birth: recommendation saileacthats teas Natl decreasing since 1993
total populati 72.83 years Legislative branch: bicameral Parliament - ave expected to incsense in ouee int mn
male, 6— . Senate: a 16-member body appointed by the storm damage to crops in Florid: . The
—_ . ee _dibiaiacael generat overall growth prospects througt 1996 will
Fotal ferauiy ate: 1.97 children born/ House of Assembly: elections last held 19 depend heavily on the fortunes of the
woman (1996 est) August 1992 (next to be held by August souriam sector and continued income growth
Nationality: 1997). results —percent of vote by party NA. in the US, which accounts for the majority
noun: Bahamian s) seats—(49 total) FNM 32. PLP 17 _
adiective: Bahamian Judicial branch: Supreme Court 7 ee cael
Ethnic divisions: black 856. white 155 P GDP: purchasing power parity —$4.8 billion
_ _ Political parties and leaders: Progressive (1995 est.)
Religions: Baptist ° Anglican 20% Liberal Party (PLP). Sir Lynden O GDP real growth rate: 2% (1995 est.)
Roman Catholic 19%. Methodist 6%. Church PINDLING: Free National Movement GDP per capita: $1X an (7995 ost
USSOG SS. CORNET PRONE RE Oe (FNM). Hubert Alexander INGRAHAM GDP composition by sector:
o~_ wile International organization participation: asriculare: %
Languages: English. Creole (among Haitian ACP. C. Caricom. CCC. CDB. ECLAC. dears: 200
| | FAQ. G-77, IADB, IBRD. ICAO. ICFTU. services: 62% (1994)
munncde nae SEE SO ERR A ICRM. IFC, IFRCS. ILO. IMF. IMO. '' ; 21 Se
literacy not available | . — nflation rate (consumer prices): |.5°
Inmarsat, Intelsat. Interpol, JOC, ITU, NAM. (1994)
| 4 OAS, OPANAL, UN, UNCTAD. UNESCO. Labor force: 136.900 (1993)
“ip UNIDO, UNMIH, UPU, WHO, WIPO. by occupation: government 30%, tourrsm
is WMO 40%, business services 10%, agneculture S%
Diplomatic representation in US: (1995 est)
chief of mission: Ambassador Timothy Unemployment rate: 15% (1995 est.)
Baswell DONALDSON Budget:
Government chancery: 2220 Massachusetts Avenue NW, revenues: S665 million
Name of country: Washington, DC 20008 expenditures: $725 million, including capital
onventional long form. Commonwealth of telephone: \\1| (202) 319-2660 expenditures of $94 million (FY95/96 est.)
The Bahamas FAX: [1] (202) 319-2668 industries: tourism. banking. cement. oi!
nventional short form: The Bahamas consulate(s) general: Miami and New York refining and transshipment. salt production.
M
YS
rum, aragonite, pharmaceuticals. spiral-
welded steel pipe
Industrial production growth rate: NA‘
Electricity:
capacity: 424,000 kW
production: 929 million kWh
consumption per capita: 3.200 kWh (1993)
Agriculture: citrus. vegetables: poultry
Micit drugs: transshipment point for cocaine
and manjuana bound for US and Europe:
also a money-laundering center
Exports: $224.257 million (f.0.b., 1994)
commodities: pharmaceuticals, cement, rum.
crawfish, refined petroleum products
partners: US 51%, UK 7%, Norway 7%.
France 6%. Italy 5%
Imports: $1.08 billion (cif, 1994)
commodities: toodstults, manufactured
goods, crude oil, vehicles. electronics
partners: US 55%, Japan 17%, Nigeria 12%.
Denmark 7%. Norway 6%
External debt: $407.8 million (December
1994)
Economic aid: SNA
Currency: | Bahamian dollar (BS) = 100
cents
Exchange rates: Bahamian dollar (BS) per
USS1—1.00 (fixed rate)
Fiscal year: | July — 30 June
currem issues: desertification resulting trom
the degradation of limited arable land
penods of drought. and dust storms: cuastal
degradation (damage to coastlines. coral
7
Bahrain (continued)
ects. and sea vegetation) resulting trom oil
her discharges from large
relineries, and distnbution
no Natural tresh water resources so
undwater and sea water are the only
ces for all water needs
“dural hazards. periodic droughts: dust
crnational agreements. party to—Climate
Hazardous Wastes. Law of the Sea.
one Laver Protection: signed. but not
itied —Brodiversity
Geographic note: close to primary Middle
frolecum sources, Srategh location
Gull which much of Western
im must transit to reach open
Peopic
Population: 590.042 (July 1996 est)
Aue structure:
imate 236.048. temaule
(male 7.956: female
Population growth rate: 2.27% (1996 est)
Birth rate:
pot
* hirths/1.000 population
Death rate:
1 uy
29 deaths/1.000 population
Net migration rate: 242 migrant(s)/ 1.000
iabiay IYYO est)
Sex ratio:
emale
1. i
prea’ 4
4 | si/ten ile
| (MH mnalersi/fematle
CLA 1YUH at }
infant mortality rate: | 7 | deaths/ 1.000
Life expectancy at birth:
rie } P| Vedlrs
a, HA yeu IYYOH est)
etal fertility rate: 3.08 children born
Nationality:
dice e Bahram
Ethnic divisions: Bahraim 63°. Asian 13%
i} \\rab 10
other lraman S&S“. other 6%
Religions: Sia Muslim 75%. Sunm
Muslim 25
Languages: Arabic. Enelish. Farsi. Urdu
Literacy: age 15 and over can read and
srite (1995 est)
38
female: 79.4%','3be5e2673853dfcbdde245929c6a35ad0edaa53358805dbf121dc24d80806b22','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92eda8d8f721e94d289ea05e30d17d9fda5c434667aa4b0224f06b68fea0a08f',1996,'AM','Armenia','environment',51,'conventional short form: Armenia
local long form: Hayastam Hanrapetut yun
local short form: Hayastan
former: Armenian Soviet Socialist Republic:
Armeman Republic
Data code: AM
Type of government: republic
Capital: Yerevan
Administrative divisions: 37 regions
(shrjanner, singular—shrjan) and 23 cities”
(kaghakner. singular—kaghak): Abovyan*.
Akhuryam Shrjan. Alaverdi*®., Amasiay:
Shyan, Anu Shryan, Aparani Shrjan. Aragatss
Shrjan, Ararat®. Ararat: Shrjan, Armavini
Shrjan, Artashat*. Artashati Shrjan. Art ik
Ariki Shran. Ashots k''s Shrjian. Ashtarak”.
Ashtaraki Shran, Baghramyani Shryjan.
Ch arents avan*. Diliyjan*. Eymiatsin®.
Eymiatsm Shryan, Gors*, Goria Shryan.
Gugark 1 Shyan, Gyumn". Hoktembery an’
Hrazdan*. Hrazdami Shryan. lyevan*. evan
Shrjan, Jermuk*, Kamo*. Kamoyi Shryan.
Kapan*. Kapam Shrjan. Kotayk i Shryan
Krasnoselski Shran. Martunu Shryan, Masis
Shrjan. Meghru Shrjan. M Asamor®. Nairn
Shnan. Noyemberyam “hayjan. Sevan
Sevam Shryan. Sisiam Shryan, Sprtak”.
Spitaki Shryan, Step anavan”. Step anavani
Shrjan. Talim Shrjan. Tashin Shrjan. Taushi
Shrjan. Tumanyam Shrjan, Vanadzor
Vardenisi Shrjan, Vayk''i Shryjan
Yeghegnadzon Shrjan. Yerevan"
note: with the adoption of the new
constitution of S July 1995. the country was
divided into 10 provinces plus the capital
Aragatsotn, Ararat, Armavir, Gegharkunth
Gugark. Kotayk. Shirak. Syunk. Uak. Vayots
Dor. and the capital city of Yerevan
Independence: 28 May 1918 (First
Armeman Republic): 23 September 199!
(from Soviet Union)
National holiday: Referendum Day. 2!
September
Constitution: adopted by nationwide
referendum 5 July 1995
Legal system: based on civil law system
Suffrage: 18 years of age: universal
Executive branch:
chief of state: President Levon Akopovich
TER-PETROSSIAN (since NA October
1991) was elected Chairman of the
Armenian Supreme Soviet 4 August 1990
before being elected president by popular
vote: election last held 16 October 1991
(next to be held NA September 1996).
results—Levon Akopovich TER-
PETROSSIAN 86%. radical nationalists 7%
(es)
head of government: Prime Minister Hrant
BAGRATYAN (since 16 February 1993)
was appointed by the president: First Deputy
Pome Minister Vigen CHITECHY AN (since
i6 February 1993)
cabinet: Council of Ministers was appointed
by the president
Legislative branch: unicameral!
National Assembly. elections last held 5 July
1995 (next to be held NA 2000): results
percent of vote by party NA: seats—1 190
total) Republican Bloc 159 (ANM 63. DLP
Hanrapetutyun Bloc 6. Republic Party 4.
CDU 3. Intellectual Armenia 3. Social
Democratic Party 2. independents 7&8), SWM
8 ACP NDU S.NSDU 3. DLP IL. ARI
1. other 4. vacamt 2
Judicial branch: Supreme Court
Political parties and leaders:
Republic Bloc (Hanrapetoutioun). Armeman
National Movement (ANM). Hush
LAZARIAN.,. chairman. Democratic Liberal
Party (split away from the epposttion party )
Republican Party. Ashot NAVARSARDIAN
chairman. Christian Democratic Union
(CDU). Azat ARSHAKIAN., chairmen
Intellectual Armema. Ho TOKMLAJTAN
Social Democratic (Hachakian) Party
Yeghia NAJARIAN
opposition parties: Shamiram Women s
Movement (SWM). Nadezhda SARKISIAN
Armenian Communit Party (ACP). Serge
BADALY AN, National Democratic Unior
INDU). Davitt VARDANIAN and Vasken
MANUKIAN, Union of National Sell
Determination (NSDU). Parwr HAIRIKIAN.
chairman, Democratic Liberal Party (DLP)
Rouben MIRZAKHANIAN, chairman
Armenian Revolutionary Federation (ARF)
Rouben HAKOBIAN,. chanman
International organization participation:
BSEC. CCC. CIS. EBRD. BCE. ESCAP
FAQ. LABE.N. IBRD. IC AO. IDA. IFAD. TPC
IFRCS. ILO. IMF. Intelsat. Interpol, 10%
1OM. ITU. NACC. NAM ctobserver), OSCI
PEP. UN. UNCTAD. UNESCO, UNIDO
UPL. WHO. WIPO, WMO. WTrO
(applicant)
Diplomatic representation in US:
chict of mission. Ambassador Ruben
SHUGARIAN
Lith floor, 1660 L Street NW
Washington. DC 20036
11) (202) 628-5766
chancers
tole phone
FAX: 11) (202) 628-5769
consulate(s! eeneral: Los Angeles
23
Srmenia
‘ vrtinued)
is diplomatic representation:
hassador Peter
{
~ ( Bavramian. Yerevan
embassy street address
74. 3}-144. 524-66]
.*‘*
tlay rivontal bands of red
bo conmonns
toonomic overview: Under the old Soviet
tem. Armemia had
mdustrial sector.
nulding tools. textiles
tured goods to sister
nee tor raw materials and
ood importer and its
a. haurtte )
are small
kw In recent vears (1991
{ larly severe due to the
er the ethnic Armenian-
| Nagorno-Karabakh in
und Turkey have
nd railroad tratfie to
Karabakh
Armenia with
port of the
UE’ hecdus at al hac k
Y iy and frequent Gaisruptions ehi
is deliveries through unstable
as difficulties in obtainn
ivpes of tuel. Nevertheless. the
omy appears to have bottomed out du
\\ to the vernment § strong reform
C;})P " ify i, | gos
| i | I i PAL Hy! pe
n carl 4 in average 2.447 pr
IS A COT re very
t be expected until the
i in ! bh] Kade lifted
(,DP:
bunk
(-DI
(,DP
i,DP
74
Inflation rate (consumer prices): 32.2%
mans
Labor force: | |
lt nemployment rate: X‘
t.>¢9
. soarets
} { \\; } \\
- } . } ''
lated trom World
SOUT billion
"
ii’
t
Wao
real growth rate: 5 - 1Y9S est
per capita: S2.560 (1995 est.)
( omposition by sector:
} sf
PU Ss prs
1? million
Dealt mdustry and construction
rericulture transportation and
unication other 45% (1992)
officially
{ unemployed. but large numbers of
remployed (December 1995)
24
Budget:
revenues: SNA
expenditures: SNA, including capital
expenditures of SNA
Industries: much of industry ts shut down:
metal-cutting machine tools, forging-pressing
machines. electric motors. tires. knitted wear.
hosiery. shoes, silk fabric, washing
machines. chemicals, trucks. watches.
instruments, microelectronics
Industrial production growth rate: 2.4
(1995 est.)
Electricity:
capacity: 4.620.000 KW
production: 5.7 billion kWh
1.620 kWh (1994)
Agriculture: truit (especially grapes).
CONSUMPHON Per Capua:
vegetables: vineyards near Yerevan are
famous for brandy and other liqueurs: minor
livestock sector
Iicit drugs: illicit cultivator of cannabis
mostly tor domestic consumption: used as a
transshipment point tor illicit drugs to
Western Europe
Exports: $248 million (t.o.b., 1995)
commodities: gold and jewelry. aluminum.
transport equipment, electrical equipment.
scrap metal
partners: Iran. Russia. Turkmenistan.
Georgla
Imports: S66) million (c..t.. 1995)
commodities: grain, other foods. fuel. other
enerey
partners. Tran. Russia. Turkmenistan.
Georgia US. EU
External debt: S850 million (of which $75
million to Russia) (1995 est.)
Economic aid:
recipient. ODA, $30 million (1993)
note. commitments (excluding Russia).
S1.385 million (S675 million in
disbursements) (1992-95)
Currency: | dram = 100 luma (introduced
new currency in November 1993)
Exchange rates: dram per USS!—401.8
(end December 1995), 406 (end December
1994)
Fiscal year: calendar year','c0a48d666d25e21f203aaf245baf4c9d4292669fd239202d98306c92db52beed','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d85dbbcdcfcbb89f7b1da06e85c407aa66fc71fd23bb10c335d04691d220571a',1996,'AW','Aruba','environment',55,'current issues: NA
natural hazards: les outside the Caribbean
hurricane belt
international agreements: NA','52513e9ec7ffa39b673ddad66828a005b8af9065df469e74a088ef0729370b36','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b90316ca4c1000762744a40ec9eb819b0f7176fddca93724b3c2b039d20eec1',1996,'AU','Australia','environment',63,'current issues: endangered marine species
include the manatee, seals, sea lions, turtles.
and whales: drift net fishing is hastening the
decline of fish stocks and contributing to
international disputes: municipal sludge
pollution off eastern US. southern Brazil,
and eastern Argentina: oi! pollution in
Canbbean Sea. Gulf of Mexico, Lake
Maracaibo, Mediterranean Sea. and North
Sea: industrial waste and municipal sewage
pollution in Baltic Sea, North Sea. and
Mediterranean Sea
natural hazards: icebergs common in Davis
Strait. Denmark Strait. and the northwestern
Atlantic Ocean irom February to August and
have been spotted as far south as Bermuda
and the Madeira Islands: icebergs from
Antarctica occur in the extreme southern
Atlantic Ocean: ships subject to
superstructure icing in extreme northern
Atlanuc trom October to May and extreme
southern Atlanuc from May to October:
persistent fog can be a maiitime hazard from
May to September
international agreements: NA
Geographic note: major choke points
include the Dardanelles. Strait ot Gibraltas
access to the Panama and Suez Canals:
Strategic straits include the Strait of Doves
Straits of Florida. Mona Passage. The Sound
(Oresund), and Windward Passage: the
Equator divides the Atlantic Ocean into the
North Atlantic Ocean and South Adantic
Ocean
current issues: soil erosion from overgrazing.
industrial development, urbanization, and
poor farming practices: soil salinity msing
due to the use of poor guality water:
desertification: clearing for agricultural
purposes threatens the natural habitat of
many unique animal and plant species: the
Great Barner Reef off the northeast coast,
the largest coral reef in the world, ts
threatened by increased shipping and its
popularity as a tourist site: limited natural
tresh water resources
natural hazards: cyclones along the coast:
severe droughis
international agreements: party to—
Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity. Climate Change.
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping. Marine Life
Conservation, Nuclear Test Ban, Ozone
Layer Protection. Ship Pollution, Tropical
Timber 83, Wetlands: signed. but not
ratified— Desertification
Geographic note: world’s smallest continent
but sixth-largest country: population
concentrated along the eastern and
southeastern coasts; regular, tropical.
Invigorating. sea breeze Known as ‘the
Doctor” occurs along the west coast in the
summer
arent issucs: FA
tural hasards, subject to tornadoes
HWemathonai aegercemeiv''s NA
(,eographic note: rect about 8 km in
ircumlerence','0e0b1a45fb95da9f6dfb278d5cd3a400147fa3e98eb1e43e93e3abf4df66e1ea','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffa3fb64f16a0f72720645365c9212d89babd08683c73fbdc59ba11bc03971ca',1996,'AT','Austria','environment',68,'current issues: some forest degradation
caused by air and soil pollution: soil
pollution results from the use of agricultural
chemicals: air pollution results from
emissions by coal- and oil-fired power
Stations and industrial plants and from trucks
transiting Austnia between northern and
southern Europe
natural hazards: NA
utermational agreements. party to—An
Pollution, Aw Pollution-Nitrogen Oxides. Air
Pollution-Sulphur 85, Air Pollution- Volatile
Organic Compounds. Antarctic Treaty.
Biodiversity. Climate Change. Endangered
Species. Environmental Modification,
Hazardous Wastes. Law of the Sea. Nuclear
Test Ban. Ozone Layer Protection. Ship
Pollution, Tropical Timber 83. Wetlands.
Whaling: signed, but not ratitied— Air
Pollution-Sulphur 94. Antaretn
Environmental Protocol
Geographic note: landlocked. strateg
location at the crossroads of central Europe
with many easily traversable Alpine passes
and valleys: mayor river ts the Danube
population is concentrated on eastern
lowlands because of Sleep Slopes pun sols.
and low temperatures elsewhere','a65155a9aad2e8673bc68a97e07f0f1d241e427413536c331f89bb589f58a7f5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('960b4690c84cae674cbcf4626db59eeb9a2feb33f4b43ab0f7e953024df6d678',1996,'BD','Bangladesh','environment',79,'current issues: many people are landless and
forced to live on and cultivate flood-prone
land: limited access to potable water: water-
borne diseases prevalent: water pollution
especially of fishing areas results from the
use of commercial pesticides: intermittent
water shortages because of falling water
iables in the northern and central parts of the
country: soil degradation: deforestation:
severe overpopulation
natural hazards: droughts. cyclones: much ot
the country routinely flooded during the
“UMMeP PONSOON season
mternational agreements: party to
Biodiversity. Climate Change. Endangered
Species. Environmental Modification,
Hazardous Wastes. Nuclear Test Ban, Ozone
Laver Protection. Wetlands: signed. but not
ratitied— Desertification, Law of the Sea','feda33b13db9c0925beccb2e107ea1a0f13b6a080612241361afae6878be2a13','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c84f542d4f0de863f426cb9322b14495abddcf1442fa259aa2a5eeed5cb7c75',1996,'BB','Barbados','environment',84,'current issues: pollution of coastal waters
from waste disposal by ships: soil erosion:
legal solid waste disposal threatens
contamiiation of aquifers
natural hazards: hurricanes (especially June
to October): periodic landslides
S/
international agreements: party to-—Climate
Change, Endangered Species, Law of the
Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Whaling: signed.
but not ratified—Buiodiversity, Hazardous
Wastes
Geographic note: easternmost Caribbean
island','c8e085dacfdf7addbd994830ee918d6d6d2a5ed52c991a093c3dd09cd3c8bf3f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23047dc2a881e0dc267537d2c7842729b55a3148745c13a0f0cc35fbf3fb4b47',1996,'MG','Madagascar','environment',90,'current issues: NA
natural hazards: maritime hazard since it is
usually under water during high tide and
surrounded by reefs. subject to periodic
cyclones
mternational agreements: NA
53
current issues: NA
natural hazards: NA
muernational agreements: NA
Geographic note: wildlife sanctuary
154
/63
Falkland Islands (Islas
Malvinas)
(dependent territory of the UK)
East ¥ ahkiand
Pot Howard,
STANLEYs
f2008e Grae
Yresoe
Wes!
Fatiand
curren issues NA
natural hazards: pervodic cyclones
miernational aercements, NA
Cron ssi. NA
natural hacards. pervodie evclones
mitcrmatonal aereements: NA
Ceeographic note: wildlile sanctuary
radioactive or toxtc chemn
CUTOUT UNNites
Sites associated with its former detense
industries and test ranges are found
throughout the country and pose health 1
lor humans and animals: industrial pollution
h
(,eographic note:
ecm iwsucs: Watet pollution trom urban
ind mdustrial Wwasies: degradatnm of water
quality trom meorcased use of pesticides and
orestalion. soil erospon
hoaton. poaching
LE Me ara \\ \\
(ymin livre veils party lk?
imate Change. Endangered
Sper Law of the Sea. Manne Dumping
‘I rik | ite C onsen alhon Nuc leas lest Ban
Ovene Layer Protection. Ship Pollution
Wetlands. srgned. but not ratified
1) hHicalhm
Leographic note: the Kenyan Hichlands
morse one of the most successful
lural production tecroms m Afnca
n Mt. Renva: umque phy srography
wts abundant and vaned wildiite of
Mitt whl C.iMwnMriithk $4 tluc
''
Peoph
Population: 285.176.6086 uly 1996 est
\\ge Mructure:
" a
j $8 male 6.562.100) temak
f f
‘ hk j S76 temal
_ :
1) 4s fav
rT) ;is luly VU est
Population growth rate: 1YYH est
Birth rate: 33038 berths) .000 population
Death cate: * aed O00) nconulation
por
Net migration rate: -0. 35 micrantisy 1.000
villi WO) est
Ses ratio:
} " ik Tha
P j } ir | dle
4 al Thh.dl
O83 mal femal
feral | WU, 1
Infant mortality rate: 55 4 deaths’) 000
hurtiys | (pu «1
Life expectancy at birth:
) r SS fot yy ws
ss.‘ \\ |
SS OY years (10906 est)
lotal fertility, rate: 4 45 children born
comon | (pur, ''
Nationality:
‘ Ket Vis)
Lihnic divisions: Kiku Lubva 14
luo 4 Kalennn 12 Kamba 1] Kisii
f Meru 6 Asian. | uropean mad Arab
Religions: Protestant (including Anglican)
ws. Roman Catholic 28% indigenous
beliets 267. other 8%
Languages: English (official). Swahih
(official), numerous indigenous languages
Literacy: age 15 and over can read and
write (1995 est)
—
,
; ; ;
fonlal poynaidlioa RI‘,
male: SOV
homale ‘ta
arent sues: heavy pollutron m lagoon of
wuth Tarawa atoll due to heavy migration
mixed with traditronal practices such as
lagoon latrines and open-pit dumping:
ground water at risk
natural hazards: typhoons can occur any
lume, but usually November to March:
occasional tornadoes
mermatonal agreements party to
Biodiversity, Climate Change. Endangered
Species, Marine Dumping. Ozone Layer
Protection, Whaling
Ceorraphic note: 20 of the 33 lands are
inhabited: Banaba (Ocean Island) in Karibats
is one of the three great phosphate rock
islands im the Pacitic Ocean—the others are
Makatea in French Polynesia and Nauru
current issues: localized air pollution
attributable to inadequate industrial controls
water pollution: inadequate supplies of
px Mable water
jatural hazards: late spring droughts often
followed by severe flooding: occasional Government
typhoons during the early tall
a. Name of country:
wilermahonal agreements party lo
Antarctic Treaty. Biodiversity, Climate
Change. Environmental Modification, Ship
Pollution: signed, but not ratified— Antarciic
_ sar Environmental Protocol, Law of the Sea
PYONGYANG
Namgp, .<., Ozone Layer Protection
Geographic note: strategic location
borderng China. South Korea
mounk. JOUusS interor
bby DPR
Data code: K™
inaccessible and
Geography Ivpe of government: (
Stal , _ ee
Location: Eastern Asia. northern half of the
Korean Peninsula bordering the Korea Bay
* Sea ol Japan betw ex China and Population:
People Capital: P
»3.904.124 | oad Administrative divisions
South Korea Age structure:
Geographic coordinates: 40 00 N
I
Map references: Asia
Area:
20.540 sa kn
20.410 sq km lemale 649.1] luly 199
compara slightly smaller that Population growth rate:
\\I Birth rate: 22 s
Land houndaries: IG est
Death rate: 5 4
al
;
K ; : Net migration rate:
''
;
(Coastline: 249° D “)
Naritime claims Sex ratio: Independencs
National holiday
) Infant mortality rat | Constitutior
International disputes: rt hint wn
( letinat Life expectancy at birth
1) , , , ‘ Legal svstem
Chimate:
,?
lerrain: 1 nount lotal fertility rate:
yo
ontinuous mn ea Nationality: Suffrage
Sea of Japan 0 m reat Executive branch
‘ nowt: Paektu-san 2.744 m ar live cre KINI ¢
Natural resources: coal. lead. tungste: kth nic divisions:
71K raphit wnes iron ore, Copper Religions: Buddh
it tly nal hydropowet
role
almost non
continued )
Korea, North
branch
organization participation:
i ’
} | t \\i}
representation in US
»
ition
of military outlays from a
, CCONMOTIIN pie Moreover a seTHOUs
in inventones and critical
eclor have led t
in industrial
mineral resources
lormed the Dasis of
pment since World War I
is cemtered on heavy industr
industry. with light
tar behind Despite ine use
Varieties, expansion of
heavy use of fertilizers
ut yet become self
m. Indeed. a
le lands. several vears of
ind a cumbersome distribution
sulted im chronic food
1Y9S was marked by
that worsened an
sttuation. Substantial
Japan ind Sout! Ke tea
North Kore
;
;
GDP: pun
’ us
GDP real growth rate: -*
(GDP per capita: SY. YS
GDP composition by sector:
’
Inflation rate (consumer prices): \\ A
Labor force: 4 ¢
;
‘
t nemployment rate
Budget
lodustries
Industrial production growth rate
blectricits
Agriculture
baports
Imports:
JUIDTH
partners: China, Japan, Hong Kong.
Germany, Russia, Singapore
External debt: $8 billion (1992 est.)
Economic aid:
recipient. ODA, SNA
note: small amounts of grant aid from Japan
and other countries
Currency: | North Korean won (Wn) = 100
chon
Exchange rates: North Korean won (Wn)
per USS1—2.15 (Ma, 1994), 2.13 (May
1992). 2.14 (September 1991), 2.1 Gianuary
> 3 (December 1989)
}Y9D))
Fiscal year: calendar year
Current issues: al
Wale? po
af i ry F Ty ] > ¥
ang inagustnial ert i
natural harards
high winds anc
southwest
Mmiernahonai agreements p)
Antarctic-Environmental Prot
2ttt
Treaty Biodiversity ( imal
Endang
Pollution, Tropical Tin
Timber Y4 signed
Desertification. Law','b9214f2a658a66a8b480e0bfe3fca7fccf16dd9edb68d300f8010f2b0dea3d0e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2e3147cac6d58031051ffa13eeae8f2fecf32e67d52fcef047d98d3c04b9222',1996,'BY','Belarus','environment',97,'current issues: soil pollution trom pesticide
use: southern part of the country
contaminated with fallout from 1986 nuclear
reactor accident at Chornobyl
natural hazards: NA
wmemational agreements” party to—At
Pollution, Air Pollution-Nitrogen Oxides. Au
Pollution-Sulphur 85. Biodiversity
Environmental Moditication. Marine
Ozone Lave
Protecuion: signed. but not ratitred—Clim
Change. Law of the Sea
Geographic note: landlocs
Dumping. Nuclear Test B
“” » Meuse River. a mayor source
ant airine ile polluted trom steel
wastes: other nvers polluted by
wastes and tertilivers: industnal au
n ir Ahold Tain if
isa threat wm areas
. ’ , > > "
uF CoM ind. protected trom the
party to \\n
Sulphur 85
. ! < red Sine Ks
Mo thom. Hazardous
Murine | ife
1 | Ban. Ovone
\\ }> ul 7 Tropical
Th } mul my
\\ ven Onaides. Au
Ve Pollution Volaul
> \\
| 13 ''
{ ( | \\
(,cographi note: vuds of W
t i . SS | rene ul
wh) hy','63ae46df947a14a51ab3acd7aed4ae21ebcba350b498fa4d3a9cfd0193ab2468','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3eee913d1409850bb0c0d3ccd070a57f01064fea1bc2967a4e193f047d4821b5',1996,'BZ','Belize','environment',107,'curren issues: detorestation, water pollution
from sewage. industnal effluents. agncultural
runt!
natural hazards: trequem, devastating
hurncanes (September to December) and
coastal flooding (especially in south)
international agreements: patty to—
Biodiversity, Climate Change. Endangered
Species. Law of the Sea. Manne Dumping.
Whaling
Geographic note: national capital moved 80
km inland from Belize City to Belmopan
because of burncanes: only country in
Central America without a coastline on the
North Pacific Ocean
rent issues: Tecemt droughts have severely
affected marginal agriculture in north:
nadequate supplies of potable water,
poaching threatens wildlife populations:
deforestation: desertification
dural hazards: hot. dry. dusty harmatian
wind may affect north in winter
femal
onal agreements: party to
Biodiversity. Climate Change. Endangered
Species. Environmental Modification
Nuclear Test Ban. Ozone Layer Protection:
signed. but not ratified - Desertification, Law
ft the Sea
Geographic note: no natural harbors','8f07e1f6b75a92012a1cb8d84976cf1df810d78d532b47432cf728b4d0107905','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc5780af53e63868fdf41452667fef0070817cf67d3efaa5a3f85ab2d06a73bd',1996,'BM','Bermuda','environment',114,'current issues: NA
natural hazards: bwarnecanes une to
November)
mernational agreements» NA
Geographic note: consists of about 460
small coral islands with ample ramtall. but
no rivers or freshwater lakes: some
reclaimed land leased by US Government','fe03559f0ed893304ce5c8cd5a4e1d85defe0a15f209a067ff3adf21723f85e9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc1985114b8994adfade76e53c9b02833419f98f69e1efd6370930080b17e7aa',1996,'BT','Bhutan','environment',122,'cucremt issues: the clearing of land for
agricultural purposes and the international
demand tor tropical umber are contributing
lo deforestation: soil erosion from
overgrazing and poor culi:vation methods
(including slash-and-durn agriculture):
desertification: loss of biodiversity: industnal
pollution of water supplies used for drinking
and imgation
natural hazards: cold. thin air of high
plateau is obstacle to efficient fuel
combustion, as well as to physical activity
by those unaccestomed to it trom birth:
flooding in the northeast (March-Apnil)
niermational agreements: party to
Biodiversity. Cliamate Change. Endangered
Species. Law of the Sea. Nuclear Test Ban.
Tropical Timber 83. Tropical Timber 94.
Wetlands: signed. but not ratified
Desertification, Environmental Modification,
Hazardous Wastes. Marine Dumping. Marine
Lite Conservation, Ozone Layer Protection
Geographic note: landlocked: shares control
of Lavo Titicaca, world’s highest navigable
lake (clevation 3.805 m). with Peru','a030307948139dbcf92e29063b9d5f7824feb85fc11afb71c048788bf49c21b3','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab97331f09b55ddd5d4cf391266f1e6f336f3acc9ae900abcee38fe7cf0d16b6',1996,'BA','Bosnia and Herzegovina','environment',126,'wren iWsees) ait pollution trom
metallurgical plants, sites tor disposing of
urban waste are boited. widespread
casualties, water shorlace md destruction
iM omtrastructure because of crvel strete
natural hacards. trequemt and destructrv¢
wthquakes
nicmahon erocmonts. pa4nty t \\u
Polluteon. Law of the Sea. Marine Dumpin
Meanie Lite Conservation. Nuclear Test Ban
Ovone Laver Protecthon
Geographic note: as of January 1996
Bosman Serb leaders continued to demand
rvissons to the territorial pects of the
Dasion Agreement espechally im Sarapes:
designated to be under Federation control
wal th icho/Posavina comdor area
members of the Bosciwn Croat communi
ise repect several territorial aspects of the
wreement, cing that histoncally Bosnian
Croat land re to be transterred to Bosnian
Serb control, despite disagreements, mttial
mpliementation of the agreement as of
January 1996 appeared on course with the
Marine parties mecting the deadline tot
withdrawal of torces trom the tront lines u
Suraevo
’ "','e8d2fb8780dd6b2e8c7fbc320f861df95ae1ee0034a187725a5b6a12a2b390c7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffe67cae3048b635a5e3b85afae54e5a0c4efacbc58de78a5c89e37f63bda0ed',1996,'BV','Bouvet Island','environment',136,'current issues, NA
natural hacards: NA
micrnational aercements: NA
Ceographic note: covered bh clacta
other','7d3e85b34fd76f8b4f4267b439a53162042c4749dbb9ef624468ef2bbb8b2c95','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cbf556f11bc3d1bc491561365a277a21e03f198bd79641f49f8d6fa24bf937b',1996,'BF','Burkina Faso','environment',143,'rem issues: recem droughts and
descmiification severely alflecting agncultural
Mites. population distobulton. and the
COOMMS. OVeTer Asn st UevTadaiion
delores talon
ie reid miu agroements. party tu
Baahiversity. Clumate Change. kndangered
SPec tes Manne Lite Consern ation, Ozone
Wetlands: signed. bul not
railed Desertification. Law of the Sea
Ceographic note: landlocked','75e6bf89886374939c87fcc55d5fa5daed580343603710206c9e08a43e527741','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae4ed3e13cac56e2bcaa2d8c56fca8c8c96f61288108bb9d1b22794a89cec83a',1996,'TH','Thailand','environment',149,'current issues: detorestation, industrial
)sq km (1989)
pollution of air, soil, and water: inadequate
sanitation and water treatment contribute to
disease
natural hazards: destructive earthquakes and
eyclones: flooding and landslides common
during rainy season (June to September):
periodic droughts
muernational agreements: party to—
Biodiversity. Climate Change. Nuclear Test
Ban. Ozone Laver Protection, Ship Pollution,
Tropical Timber 83. signed, but not ratified
- Law of the Sea. Tropical Timber 94
Geographic note: strategic location near
major Indian Ocean shipping lanes
current issues: ait pollution from vehicle
emissions; water pollution from organic and
factory wastes; deforestation; seil erosion;
wildlife populations threatened by illegal
hunting
natural hazards: \\and subsidence in Bangkok
area resulting trom the depletion of the water
table; droughts
international agreements: party to—Climate
Change, Endangered Species, Marine Life
Conservation, Nuclear Test Ban, Ozone
Layer Protection, Tropical Timber 83:
signed, but not ratified —Biodiversity.
Hazardous Wastes, Law of the Sea
Geographic note: controls only land route
from Asia to Malaysia and Singapore
current issues: detorestation attributable to
slash-and-burn agriculture and the use of
wood for fuel; recent droughts affecting
agriculture
natural hazards: bot, dry harmattan wind can
reduce visibility in north during winter:
peniodic droughts
international agreements: patty to—
Endangered Species, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection,
Ship Poilution, Tropical Timber 83; signed,
but not ratified - Biodiversity, Climate
Change. Desertification, Tropical Timber 94
Population: 4.570.530 Uuly 1996 est.)
Age structure:
0-14 years: 49% (male 1,116,030; female
1,105,957)
15-64 years: 49% (male 1.085.774; female
1.163.374)
65 vears and. . er. 2% (male 46,089, female
§3.306) uly 1996 est.)
Population growth rate: 3.56% (1996 est.)
Birth rate: 46.23 births/1.000 population
(1996 est.)
Death rate: 10.66 deaths/!.000 population
(1996 est.)
Net migration rate: 0 migrant(sj/1,000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(s\\/temale
under 15 vears: 1.01 male(s)/female
15-64 vears: 0.93 male(s)/female
65 vears and over: 0.86 male(s)/female
all ages: 0.97 male(sWfemale (1996 est.)
Infant mortality rate: 84.3 deaths/!,000
live births (1996 est.)
Life expectancy at birth:
total popuiation: 57.87 years
male: 55.7 years
female: 60.1 years (1996 est.)
472
Total fertility rate: 6.75 children born/
woman (1996 est.)
Nationality:
noun: Togolese (singular and plural)
adjective: Togolese
Ethnic divisions: native African (37 tribes:
largest and most important are Ewe, Mina,
and Kabre) 99%. European and Syrian-
Lebanese less than 1%
Religions: indigenous beliefs 70%, Christian
20%, Muslim 10%
Languages: French (official and the
language of commerce), Ewe and Mina (the
two major African languages in the south),
Dagomba and Kabye {sometimes spelled
Kabiye: the two major African languages in
the north)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 31.7%
male: 67%
female: 37%','01bf0d4770a3aa4e5cf6d4a46d5d467f404741d51d89cfb7ab23f4729da6f8bd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('925e7fe9984573077807354696092f691ca8280e8d31c19496c013b4d783715e',1996,'BI','Burundi','environment',157,'current issues: soil erosion as a result of
overgrazing and the expansion of agriculture
into marginal lands; deforestation (little
forested land remains because ot
uncontrolled cutting of trees for fuel): habitat
loss threatens wildlife populations
natural hazards: flooding, landslides
international agreemenis: party to—
Endangered Species: signed, but not
ratified—Biodiversity, Climate Change,
Desertification, Law of the Sea, Nuclear Test
Ban
Geographic note: landlocked: straddles crest
of the Nile-Congo watershed
me i pst .e : a * open a ° | S current issues: logging activities throughout
siceicdienainaiaaniiaaacbaaati a saahaie FL Sa08 5 the country and strip mining for gems in the
APS, SARE ave ieee Pe pay _ ~ 4 NF western region along the border with
cotsilink paste skttin —! Xx ~~) \\ Thailand are resulting in habuat loss and
Intelscc (Indian Ocean) é os a declining biodiversity (in particular,
nadio broadcast stations: AM 2. FM 2 Saarcang oe / destruction of mangrove swamps threatens
hortwave : cacnen \\ natura: fisheries): deforestation: soil erosion:
Radios: \\\\ ee ; _/4~ in rural areas, a majority of the population
felevision broadcast stations: | \\ aia a does not have access to potable water
Televisions: 4.500 (1993 est aon _— v VIETNAM natural hazards: monsoonal rains (June to
“O79 kamoorg «= ya November): flooding: occasional droughts
i ye international agreements: party to—-Marine
™~ Lite Conservation, Ship Pollution: signed.
Defense but not ratified—Biodiversity, Climate
ee a oe ae ee ee Change. Desertification. Endangered Species.
inti’. wecuecibicre Condemns Law of the Sea, Marine Dumping. Tropical
Geography Timber 94
Manpower availability: , .
lanpower availabilit Geographic note: a land of paddies and
males age 15-49: 1.312.458 Location: Southeastern Asia. bordering the forests dominated by the Mekong River and
males fit for military service- 683.072 Gult of Thailand. between Thailand and Tonle Sap ;
oe ey ry ave (16) annually Vietnam
67.990 £1996 est) Geographic coordinates: 13.00 N_ 105 00 = sincere
Defense expenditures: exchange rate E
comversion—-$?4 million. 2.6% of GDP Map references: Southeast Asia People
(1993) Area: Population: 10.861.218 uly 1996 est.)
total area: 181.040 sq km Age structure:
land area: 176520 sq km 0-14 vears: 45% (male 2.505.998: female
comparative area: slightly smaller than > 432.620)
Oklahoma 15-64 vears: 51% (male 2.579.986; female
Land boundaries: 3.007.838)
total: 2.572 km 65 vears and over: 4% (male 143.759:
horder countries: Laos 541 km, Thailand female 191.017) uly 1996 est.)
803 km. Vietnam 1.228 km Population growth rate: 2.77 (1996 est.)
Coastline: 443 km Birth rate: 43.5 births/1.000 population
Maritime clainis: (1996 est.)
contiguous Zone: 24 nm Death rate: 15.78 deaths/1,000 population
continental shelf: 200 nm (1996 est.)
exclusive economic zone: 200 nm Net migration rate: 0 migrant(s)/1.000
territorial sea: 12 nm population (1996 est.)
International disputes: offshore islands and Sex ratio:
sections of the boundary with Vietnam are in at birth: 1.05 male(svVfemale
dispute. maritime boundary with Vietnam under 15 vears: 1.63 male(s\\/female
not detined: parts of border with Thailand in 15-64 vears: 0.86 maleisi/temale
dispute: maritime boundary with Thailand 65 vears and over: 0.75 male(s)/female
not clearly detined all ages: 0.93 male(s)/female (1996 est.)
Climate: tropical: rainy, Monsoon season Infant mortality rate: 107.8 deaths/!.000
‘May to November): dry season (December live births (1996 est.)
to April); littke seasonal temperature Live expectancy at birth:
Variation total population: 49.86 years
Terrain: mosily low, flat plains: mountains male: 48.39 years
in southwest and north female; 51.39 years (1996 est.)
lowest point: Gult of Thailand 0 m Total fertility rate: 5.81 children born/
highest point. Phnum Aoral 1.810 m woman (1996 est.)
Natural resources: timber, gemstones. some Nationality:
iron ore, Manganese. phosphates, hydropower noun: Cambodian(s)
potential adjective: Cambodian
q/
Ethnic divisions: Khmer 90°. Vietnamese
5%, Chinese 1%, other 4%
Religions: Theravada Buddhism 95%. other
5%
Languages: Khmer (official). French
Literacy: age 15 and over can read and
write (1990 est.)
total population: 35%
male: A8%
female: 22%
current issues: deforestation results trom
uncontrolled cutting of trees for fuel:
overgrazing, soil exhaustion, soil erosion
natural hazards: penodic droughts: the
volcanic Virunga mountains are in the
northwest along the border with Zaire
international agreements: patty to—
Endangered Species, Nuclear Test Ban:
signed, but not ratified - Biodiversity.
Climate Change. Desertiticaiion, Law of the
Sea
Geographic note: landlocked: predominantly
rural population','3effd7a18905e081c6ebb1212668bea036b50400c7d7fea6268dae628875cc6d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d83115e931be4036e2576b0d0ca3c22a29b3164ef55175a56857878a500cc05',1996,'CM','Cameroon','environment',166,'current issues: water-borne diseases are
prevalent, deforestation: overgrazing;
desertification: poaching: overfishing
natural hazards: recent volcanic activity
with release of poisonous gases
international agreements: party to—
Biodiversity, Climate Change, Endangered
Species. Law of the Sea, Ozone Layer
Protection, Tropical Timber 83: signed, but
not ratified - Desertification, Nuclear Test
Ban, Tropical Timber 94
Geographic note: sometimes referred to as
the hinge of Africa
current issues: tap water is not potable
desertification
145
Equatorial Guinea (continued)
nuural hazards: violent wandstorms
nicrnational agreements” patty to—
Buativersity. Endangered Species. Nuclear
lest Ban. signed. but not ratified
Deserufication. Law of the Sea
(,eographic note: insular and continental
regions rather widely separated
/ \\
\\
4
Highways: ;, v
total ? " KIN
unpaved: 229 km
Ports: none: offshore anchorage onl
VMierchant marine: non
Norfolk Island (continued) Exccutive branch: production: & million kWh
duet of state’ Queen ELIZABETH II (ot the consumption per capita +160 kWh cl990)
. , * e"
71 United Kingdom since 6 February 1952) 1s a Agriculture: Norfolk Island pine seed.
4
hereditary monarch: the queen and Australia Kenta palm seed, cereals. vegetables, truit
canamie 70 aidan re represented by Admunistrater Alan cattle. poultry
‘ tf it '' m.* < 7 rY 4 ) , P
'' es Gardner KERR (since NA April 1992) whe Exports: S15 million (hob. FY9I/92)
, muomnicd by 1 sormmor venmcial of
'' _- ~ = eee ah =< commmnodttics. Prustage Stamps seeds of the
Ye \\u i ,
Norfolk Island pine and Kentia palm. small
4 4
4 hhe ial covets Assembly President The ''
'' Quantities ol aVancades
yulution growth rate: {> MO ost ( i Minister Jol lerrence BROWN
raivthnedrs \\ustralia Pact re Istands NZ
th rate: \\ At MM ruil al co NAD was elected tor mot more "aa \\
z vial ul yh
rite \\ j tilie: curs bv the Le Hive Assembly
. . , Imports: 8179 mullion (cat. FYYT/92)
f migration rate \\ an ile t iLt\\ ( Unmotl is Made up «o
(MALES NA
iu i ive
tj , partners, Australia. Pacitie Islands. NZ
, ‘
. ° sil \\ cep
Leyvislative branch: Can \\ bury
basconad elections last held 20 External debt: S\\N A
Mluy 1992 cneat to be held NA May 1995 Lconomuc aid: none
lve by party NA Currency: | Australian dollar (SA) 1(M)
’ Phot ley lents 9 Cents
bets raat iW Judicial branch: Supreme Court Exchange rates: Australian dollars (SA) pet
Political parties and leaders: to USST 1 3477 (danuary 1996). 1 3486
t lurth International organization participation: 1s) | lee togd) | S705 (1993) 1 00
hy Saye ]09 1 SOY ¢ 1 OUD,
Diplomatic representation in US: Fiscal vear: | July 30 Jun
« « . , ii
tA
Yt LS diplomatic representation:
ste
4
oa ;
blag lransportation
‘ , Railways: 0) 4}
Highways
''
bconomy
Ports h
| COrpantan mservicw (
\\lerchant marin
\\irports
’
( ommunications
i,pP
(,DP real vrowth rate: \\ lelephone
(DP per capita lelephone system
(,pPr composition by sector
Kadio broadcast stations: \\\\I iN]
Inflation rate (consumer prices)
tabor force } ”")
Radios L ")
hemes « nemployment rate: \\
lelevision broadcast stations
N.ithonel 7 seis } Budyet
lelevisions: YOU) Ny
‘ tatuiti j f
. its | TT Te NA CEY9 }
Industries
Defense
Industrial production growth rate: \\\\
hI hlectricity: Defense note: deten the responsibility
sullraye ma (MM KW of Australia
35k
567
Northern Mariana Islands Environment: convent
(commonwealth in political union with the US) current issues: Comtamination of groundwatet Island
on Saipan by raw sewage contributes to Data code: CQ
disease Iype of government:
nalural hazards: ative Volcanoes on Pagan political unron will
and \\gnhan typhoons fespecially August to with local
November)
wiernahonal aercecmenls NA
Geographic note: strategic location
North Pacitic Ocean
Capital: Saipa
Administrative divisions
People Independence:
National holiday: ¢
Age structure: ly,
l4 years NA
Od veatrs NA
O53 \\ears and cr, NA
Population growth rate:
Birth rate: 33.05 birt! |
* prearennt hs
SAIPAN Legal system
, My ost
Population: >»
;
( onstitution: (
\\
‘
Death rate: 4
aL
Sulfrage:
Net migration rate: 0
{ yor
Geography populati
Sen ratio:
Location: Oceania. islands in the Nort! he Fvccutive branch
about thres
Ceographic coordinates: sata
| ‘ N\\
, , ~—* ()
Map references: Infant mortality rats
Are a } py
Life expectancs at birth
lotal fertility cate
}.
land boundaries Nautionalits
( ousthine
\\ilaritime claims
bthanw division
\\1
International disputes n
( limats Religions: (
|
languayes: |
lerraimn
literacy
if
Natural resources:
Land use:
Judicial branch
( i {
Government Political parties and leade:
rest and mdland Name of country 15
her NA ; ;
Irrigated land: NA sy ki th hern Mag','1f3faf20b697f15895642cd272a4b12dc431a32f6eed7a3177cc0c86ec19c5be','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0823f203baed93a21c28fbbb43c2ef2613302e6ec7c3aaf83f95f31df695519',1996,'CA','Canada','environment',174,'current issues: air pollution and resulting
acid rain severely affecting lakes and
damaging forests; metal smelting. coal-
burning utilities, and vehicle emissions
IS
impacting on agncultural and forest
productivity; ocean waters becoming
contaminated due to agricultural, industrial.
mining. and forestry activities
natural hazards: continuous permafrost in
north ts a serious obstacle to development:
cyclonic storms form east of the Rocky
Mountains, a result of the mixing of air
masses from the Arctic, Pacific. and North
American intenor, .ad produce most of the
country’s rain and snow
miernational agreements: party to—Air
Pollution, Air Pollution-Nitrogen Oxides. Air
Pollutiou-Sulphur 85. Antarctic Treaty.
Biodiversity. Climate Change.
Desertification, Endangered Species.
Environmental Modification, Hazardous
Wastes. Marine Dumping. Nuclear Test Ban.
Ozone Layer Protection, Ship Pollution.
Tropical Timber 83, Wetlands. Whaling:
signed. but not ratified—Aur Pollution-
Sulphur 94, Air Pollution- Volatile Organic
Compounds, Antarctic-Environmental
Protocol, Law of the Sea. Tropical Timber
94
Geographic note: second-largest country in
world (after Russia). strategic location
between Russia and US via north polar
route: nearly 90% of the population ts
concentrated within 161 km of the US/
Canada border
current issues: overgrazing of livestock and
improper land use such as the cultivation of
crops on steep slopes has led to soil erosion:
demand for wood used as fuel has resulted
in deforestation, desertification.
environmental damage has threatened several
indigenous species of birds and reptiles:
overfishing
natural hazards: prolonged droughts:
harmattan wind can obscure visibility:
volcamically and seismically active
international agreements: party to—
Biodiversity, Climate Change.
Desertification, Environmental Mod:fication.
Law of the Sea, Marine Dumping. Nuclear
Test Ban
Geographic note: strategic location 500 km
from west coast of Afnca near major north-
south sea routes: important communications
Station: important sea and air refueling site','9aef80ef0b4443af61a5281ec6510ae0868dbc4fa9c851338f1983cadb90b4f1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('409ab982ebb52e2a253541bfb034555631e91a5169453c0979ed3fd983c19b2a',1996,'KY','Cayman Islands','environment',181,'current issues: no natural fresh water
resources, drinking water supplies must be
met by rainwater catchment
natural hazards: hurncanes (July to
November)
international agreements: NA
Geographic note: important location
between Cuba and Central America','65e0feeea1177ed509a3492020cd36e2c9abc1a1125c7b2945047e35033b7520','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3f8466586e2fd2af62048a0ac755da5fc6ebd62a46d9f094475cb19351fdd06',1996,'CF','Central African Republic','environment',186,'current issues; tap water ts not potable:
poaching has diminished reputation as one of
last great wildlife refuges: desertification
natural hazards: hot, dry, dusty harmattan
winds affect northern areas: floods are
common
/0)
international agreements: party to—
Biodiversity, Climate Change, Endangered
Species, Nuclear Test Ban, Ozone Layer
Protection: signed, but not ratified—
Desertification, Law of the Sea
Geographic note: landlocked: almost the
precise center of Africa','fa8d0f659cc4dcc5903aebf5924730376b951d3d28d69173b9afcca5586e5fd9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cf82c2a1ed7cb2f205860a6a3d749ce6d299e81ccd8d4feeeacec9a77efe4b6',1996,'CG','Congo','environment',194,'current issues: inadequate supphes of
potable water: improper waste disposal in
rural areas contributes to soil and water
pollution: desertification
natural hazards: hot, dry. dusty harmattan
winds occur in north’ periodic ¢roughts:
locust plagues
international agreements: party to-—
Biodiversity. Climate Change, Endangered
Species. Nuclear Test Ban, Ozone Layer
Protection, Wetlands: signed. but not
ratifiei—Desertification, Law of the Sea.
Marne Dumping
Geographic note: landlocked: Lake Chad ts
the 1ost significant water body in the Sahel','1474720542a0f6c9c024525db8810ed67a5b1cbacc70e5cbde4b269c350a0761','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1ca3e08c9968d4d00e74e58a0aa2963fd8e5f7b52aa008a589068a7bbaae9a2',1996,'PE','Peru','environment',200,'current issues: air pollution trom industrial
and vehicle emissions: water pollution from
raw sewage: deforestation contributing to
loss of biodiversity: soil erosion:
desertification
natural hazards: severe earthquakes: active
volcanism: tsunamis
international agreements; party to—
Antarctic-Environmental Protocol, Antarctic
Treaty. Biodiversity. Climate Change.
Endangered Species. Environmental
Modification, Hazardous Wastes. Marine
Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands: signed.
but not ratified —Desertification, Law of the
Sea
Geographic note: strategic location relative
to sea lanes between Atlantic and Pacific
Oceans (Strait of Magellan, Beagle Channel.
Drake Passage): Atacama Desert is one of
world’s driest regions','e922e1cb594dc66b96fa5fe151995325eabf2813ec70611d1bf3ff189b60bf9c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28a5819a82d1a0fe233ed215ce382579833dd8459127a09c78f64c670d4ec6eb',1996,'CN','China','environment',203,'wrent issues’ air pollution from the
overwhelming use of high-sulfur coal as a
fuel. produces acid rain which ts damaging
forests. Water shortages experienced
throughout the country. particularly m urban
areas, future growth im water usage threatens
fo Outpace supplies: Water pollution from
industrial effluents: much of the population
does not have access to potable Water. less
than 10% of sewage receives treatment,
deforestation. estimated loss of one-fith of
agricultural land since 1957 to soil erosion
and ecusem: Je. opment, desertification:
trade in endangered species
natural hacards: trequent typhoons (about
five per vear along southern and caster
cousts): damaging thoods: tsunamis;
earthquakes, droughts
miernaiional agreements party two
Antarcic-Environmental Protocol, Antarctic
lreaty. Biodiversity. Climate Change.
Lidanvered Species. Hazardous Wastes.
Manne Dumping. Nuclear Test Ban. Ozone
Laver Protection. Ship Pollution, Tropical
Wetlands
Desertification, Law of the Sea
limber S3 igned, but not
roatiteect
itil i
Gcographic note: world’s third-largest
country Catter Russia and Canada)
current issues: water pollution from
industrial emissions, raw sewage: air
pollution: contamination of drinking water
supplies; trade in endangered species
natural hazards: earthquakes and typhoons
international agreements: signed, but not
ratified—Marine | ‘fe Conservation','07c0350ce80220633570365f5993437a05035cd23829826b2ac4f1b85dbb2944','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0334abde94a69fabffec304fb81a57fe41294d31ff57347a0f75cf88663c641b',1996,'CX','Christmas Island','environment',208,'current issues: NA
natural hazards: the narrow fringing reef
surrounding the island can be a maritime
hazard
international agreements: NA
Geographic note: locaied along major sea
lanes of Indian Ocean
/}]','7060b486004d897d141e76f5149a97f326f84252141512b9d553d76926699a43','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d92dc57ad5a149f3bf9bfbc7236693d219b926ff9abca1784a42062f6c5da74',1996,'CC','Cocos (Keeling) Islands','environment',214,'curren’ issues: tresh water resources are
limited . » raimwater accumulations in natural
underground reservoirs
113
natural hazards: cyclones may occur in the
early months of the year
international agreements: NA
Geographic note: two coral atolls thickly
covered with coconut palms and other
vegetation','3c00fff77e6994ff70ce91ac2bfb50d2ffc022ca21ef3ddd8f4228a6f40a8a8d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d144890f1ebd39f5d57d1d794a82d1ae344128c87d7aeb333dcac38bdebb2007',1996,'CO','Colombia','environment',219,'current issues: deforestation: soil damage
trom overuse of pesticides: air pollution,
especially in Bogota, irom vehicle emissions
natural hazards: highlands subject to
volcanic eruptions: occasional earthquakes:
periodic droughts
international agreements: party to—
Antarctic Treaty, Biodiversity, Climate
Change. Endangered Species, Marine Life
Corservation, Nuciear Test Ban, Ozone
Layer Protection. Ship Pollution. Tropical
Timber &3: signed. but not ratifted—
Antaretic-Environmental Protocol,
Desertification. Hazardous Wastes. Law of
the Sea. Marine Dumping. Tropical Timber
Y4
Geographic note: only South American
country with coastlines on both North Pacific
Ocean and Caribbean Sea','2c93f19ae0154c40337be9e7138acd95fbe5b76625e4d9faaaecd15f77f31f67','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d57a4312388aa0fb9b5c876918134601368a1645f6f9095c829fdfb4f9459b0',1996,'YT','Mayotte','environment',226,'current issues: soil degradation and erosion
results trom crop cultivation on slopes
without proper terracing: deforestation
natural hazards: cyclones and tsunamis
possible during rainy season (December to
/17
April); Mount Kartala on Grand Comore is
an active volcano
international agreements: party to—
Biodiversity, Climate Change. Endangered
Species. Hazardous Wastes, Law of the Sea,
Ozone Layer Protection; signed, but not
ratified - Desertification
Geographic note: important location at
northern end of Mozambique Channel','6289a50408b7e416d81a27d78dd0f5cfb743ef1174baa0fd6184b2162eb3e1c2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ac60cb8e385bc917114ca58c5258298a9376338b565210da06ebadf59cb0823',1996,'GA','Gabon','environment',234,'current issues: air pollution from vehicle
emissions; water pollution from the dumping
of raw sewage: tap water is not potable:
deforestation
natural hazards: seasonal flooding
international agreements: party to—
Endangered Species, Ozone Layer
Protection, Tropical Timber 83: signed, but
not ratified—Biodiversity, Climate Change.
Desertification, Law of the Sea, Tropical
Timber 94
Geographic note: about 70 of the
population lives in Brazzaville, Pointe Noire.
vr aiong the railroad between them','7b07fc86e493d92ee9492899a4f11b647fcd0d976d43928deeb6b244332fc6f4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45190b293549ef4035562b11ab811e202f4d0c991bb51468d6d68dfbddf595d3',1996,'CK','Cook Islands','environment',240,'current issues: NA
natural hazards: typhoons (November to
March)
international agreements: party to—
Biodiversity. Climate Change. Law of the
Sea
current issues: no permanent fresh water
resources
natural hazards: occasional, tropical
cyclones
international agreements: NA
/A3
Geographic note: important nesting area for
birds and turtles','c1c76b7ee49975cb7d96ce76e3f159420ca8d6bec3587cb12eda1f3ec33b81e1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6d54c3da97a1b82d7b34fc2ef6ea304df3f66aebe5ccdbd4acbd653691b38d1',1996,'NI','Nicaragua','environment',247,'current issues: deforestation, largely a result
of the clearing of land for cattle ranching:
soil erosion
natural hazards: occasional earthquakes.
hurricanes along Atlantic coast: frequent
flooding of lowlands at onset of rainy
season; active volcanoes
international “greements: part, to—
Biodiversity, Climate Change, Endangered
Species. Law of the Sea. Marine Dumping.
Nuclear Test Ban. Ozone Layer Protection.
Wetiands: signed. but not ratified
Desertification, Hazardous Wastes. Marine
Life Conservation
current issues: urban population expanding:
deforestation results from logging and the
clearing of land for agncultural purposes:
turther land degradation and soil erosion
hastened by uncontrolled development and
improper land use practices such as farming
of marginal lands: mining activities polluting
Lago de Yojoa (the country’s largest source
of freshwater) with heavy metals as well as
several nvers and streams
natural hazards: trequem, but generally
nuld. earthquakes: damaging hurricanes and
floods along Canbbean coast
miernational agreements party lo
Biodiversity. Climate Change. Endangered
Species. Law of the Sea, Marine Dumping.
Nuclear Test Ban. Ozone Layer Protection.
Tropical Timber 83. Wetlands: signed. but
not ratitied—Desertification, Tropical
Timber 94','6757c0ea933e7ac2b4f5c5ae7fdd9161932c47b6b92e00785e5186c647e0a308','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5818766965d57c3cf997405e6eeac449e9885012ec8261faca183366fca0439a',1996,'MX','Mexico','environment',254,'current issues: detorestation (most of the
country ''s forests—once the largest in West
Atnca—have been cleared by the umber
industry). water pollution from sewage and
indusinal and agncultural efflueats
natural hazare’s: coast has heavy surf and no
natural harbors. dunng the ramy season
torrential flooding is possible
miernational agreements. party to
Biodiversity. Climate Change. Endangered
Species. Hazardous Wastes. Law of the Sea
Marine Dumping. Nuclear Test Ban. Ozone
Layer Protection, Ship Pollution, Tropica!
Timber 83: signed. but not ratified
Desertification
current issues. Natural tresh water resources
scarce and polluted in north. inaccessible and
poor! quality in center and extreme southeast
315
Bay
Mexico (continued)
mm sewage and industrial effluents polluting
urban areas: deforestation:
lespread erosion: desertification: serious
utron an the national capita! and urban
‘s along US-Mexico border
‘sy. tsunamus along the Pacitic
‘structive earthguakes in the center
i hurmeanes on the Gulf and
ints
vreemicnts. party to
Climate Change
tifttcation. Endangered Species
» Wastes. Law of the Sea. Marine
Marine Lite Conservation. Nuclear
Ozone Laver Protection, Ship
Wetlands Whaling
(Gseovraphic note: strategic location on
border of US
current issues: logging and slash-and-burn
agricultural practices are contributing to
deforestation; soil degradation: water
pollution and overfishing threatening marine
life populations; inadequate supplies of
potable water because of groundwater
contamination
natural hazards; occasional typhoons (May
to January) with extensive flooding
international agreements: party to—
Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Law of
the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands: signed, but not
ratified—Hazardous Wastes, Nuclear Test
Ban
Population: 73.976.973 (July 1996 est.)
Age structure:
0-14 years: 36% (male 13,73°,304: female
12,988,929)
15-64 years: 59% (male 20,956,735; female
22,448,944)
65 years and over: 5% (male 1,548,513;
female 2,294,548) (July 1996 est.)
Population growth rate: 1.57% (1996 est.)
SV
Birth rate: 23 births/1,000 population (1996
est.)
Death rate: 6.95 deaths/!,000 population
(1996 est.)
"Net migration rate: -(0.35 migrant(s)/1,060
population (1996 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: \\.06 male(s)/female
15-64 vears: 0.93 male(s)/female
65 vears and over: 0.68 male(s)/female
all ages: 0.96 male(s)/female (1996 est.)
Infant mortality rate: 38.4 deaths/! 009
live births (1996 est.)
Life expectancy at birth:
total population: 67.02 years
male: 64.69 years
female: 69.48 years (1996 est.)
Total fertility rate: 2.69 children born/
woman (1996 est.)
Nationality:
noun: Vietnamese (singular and plural)
adjective: Vietnamese
Ethnic divisions: Vietnamese 85%-90%,
Chinese 3%, Muong, Thai, Meo, Khmer,
Man, Cham
Religions: Buddhist, Taoist, Roman
Catholic, indigenous beliefs, Islam,
Protestant
Languages: Vietnamese (official), French.
Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian)
Literacy: age 15 and over can read and
write (1995 est.)
total population: 93.7%
male: 96.5%
female: 91.2%
current issues: lack of natural freshwater
resources
natural hazards: rarely affected by
hurricanes; frequent and severe droughts,
floods, and earthquakes
international agreements: NA
Geographic note: important location along
the Anegada Passage—a key shipping lane
for the Panama Canal; Saint Thomas has one
of the best natural, deepwater harbors in the
Caribbean','51bac5a141bc41f34185cafc21d17807b3bd1d87da480cfb76e61a4789b16ced','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac88c0c3ffaae8af80b58d50f6e7b4a16df87599862b805a7df806c37162df71',1996,'CU','Cuba','environment',267,'current issues: pollution of Havana Bay:
overhunting threatens wildlife populations:
deforestation
natural hazards: the east coast is subject to
hurricanes trom August to October (in
general. the country averages about one
hurricane every other year): droughts are
common
international agreements: party to—
Antarctic Treaty, Biodiversity, Climate
Change. Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the
Sea. Marine Dumping, Ozone Layer
Protection, Ship Pollution: signed, but not
ratified - Antarctic-Environmental Protocol,
Desertification. Marine Life Conservation
Geographic note: largest country in
Caribbean','651b05e9cc304767f2ce25a2ffed832798edb0b8e8f14e5e51cf7d798d81cbd3','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7e84fe4dc3d6732be13817446ad3d168da91fe94bb039c74cb4af124962b32d',1996,'CY','Cyprus','environment',277,'current issues: water resource problems (no
natural reservoir catchments, seasonal
disparity in rainfal!, and most potable
resources concentrated in the Turkish
Cypriot area); water pollution from sewace
and industrial wastes; coastal degradation.
loss of wildlife habitats from urbanization
natural hazards: moderate earthquake
activity
international agreemenis: party to—Air
Pollution, Endaugered Species.
Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping.
Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Whaling: signed, but not
ratified—-Biodiversity. Climate Change','72be4027fb799449df4713e2f483690c3fc6573934e5ee8b0d567de6173b776c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7948ac6660275c75c65e0a0b938dd56af68a09897d7674376e2d3373cd125380',1996,'DK','Denmark','environment',284,'current issues: air pollution. principally from
vehicle emissions: nitrogen and phosphorus
pollution of the North Sea: dnnking and
surface water becoming polluted from animal
Wastes
natural hazards: Nhooding ts a threat in some
areas of the country (e.g.. parts of Jutland,
along the southern coast of the island of
Lolland) that are protected trom the sea by
a system of dikes
international agreemenis party to—Aw
Pollution, Air Pollution-Nitrogen Oxides. Air
Pollution-Sulphur 85, Antarctic Treaty.
Biodiversity, Climate Change, Endangered
Species. Environmental Modification,
Hazardous Wastes. Marine Dump ng, Marine
Lite Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83. Wetlands. Whaling: signed. but
not ratitied—Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol.
Desertification. Law of the Sea
Geographic note: controls Danish Straits
linking Baltic and North Seas: about one-
quarter of the population lives in
Copenhagen','dfc83c1504c9e0f6b642a998db8e5eff8825d6ea7bfb8c558160159aab7d7dee','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e00827264c4514501105b9cd8735153122c15a5b30a658bf03d3d66fbd2980a3',1996,'SO','Somalia','environment',291,'curren: issues: madequate supplies of
potable water, desertification
natural hazards: earthquakes, droughts:
occasional cyclonic disturbances trom the
Indian Ocean bring heavy rains and flash
floods
international agreements: party to—
Biodiversity. Climate Change. Endangered
Species, Law of the Sea, Ship Pollution:
signed, but not ratified—Desertification
Geographic note: strategic location near
world’s busiest shipping lanes and close to
Arabian oilfields: terminus of rail traffic into
Ethiopia: a vast wasteland
Population: 427.642 Ululy 1996 est.)
Age structure:
0-14 years: 43% (male 91,687: temale
91,242)
15-64 vears: 55% (male 123.699, female
110.530)
65 vears and over: 2% (male 5.389: female
5,095) Ululy 1996 est.)
Population growth rate: |.S% (1996 est.)
Birth rate: 42.5 births/!.000 population
(1996 est.)
Death rate: 15.26 deaths/!.000 population
(1996 est.)
Net migration rate: -!2.28 migrant(s)/ 1.000
population (1996 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 veurs: | maleisWfemale
15-64 vears: 1.12 male(s)/female
65 vears and over: 1.06 maleis\\Wtemale
ali aves: 1.07 male(sWfemale (1996 est.)
Infant mortality rate: 106.7 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: SOAS years
male: 48.24 years
female: 52.12 years (1996 est.)
Total fertility rate: 6.08 children born/
woman (1996 est.)
Nationality:
noun: Dyboutian(s)
adjective: Dyboutian
Ethnic divisions: Somali 60%. Afar 35%.
French, Arab, Ethiopian, and Italian 5%
Religions: Muslim 94%, Christian 6%
Languages: French (official). Arabic
(official), Somali, Afar
Literacy: age 15 and over can read and
write (1995 est.)
total population: 46.2%
male: 60.3%
female: 32.7%','c2a95affd53a818b8756a15f33d32d0ac4b20760a60d4074eef989484de2288d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77416eb56f7b629330748f20a9486183f4afbc2e62aa46a56afebda3f4b21422',1996,'DM','Dominica','environment',296,'current issues: NA
natural hazards: Nash floods are a constant
threat: destructive hurricanes can be expected
during the late summer months
international agreements: party to—
Biodiversity. Climate Change, Environmental
Modification, Law of the Sea. Ozone Layer
Protection, Whaling','564a60bb6677cad0d80e5d4bdd4cb7ea2d2cd05f496f01e6ed3adc2d42b6b6f2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9944b401c8ec9ac0e5b7f137e81a889afedb61cc2375e1690bd59ffa505107ef',1996,'DO','Dominican Republic','environment',302,'current issues: Water shortages: soil eroding
into the sea damages coral reefs.
deforestation
natural hazards: occasional hurneanes (July
to October)
miemational agreements party to-
Endangered Species. Marine Dumping.
Manne Lite Conservation. Nuclear Test Ban.
Ovone Layer Protection: signed. but not
ratified — Biodiversity. Climate Change. Law
of the Sea
Geographic note: shares island of
Hispaniola with Haiti (eastern iwo-thirds ts
the Dominican Republic. western one-th rd is
Haiti)','4759cdfb2c81f28d26292a651e194fa67b69dec8072894da8b10c4143d7c2657','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06f84ae096f23e5e728b39a929b192acb60de5ba16a44304a5fe38f39a7610f3',1996,'EC','Ecuador','environment',308,'current issues: detorestation: soil erosion:
desertification; water pollution
natural hazards: trequent earthquakes.
landslides, volcanic activity: pe.todic
droughts
international agreements: party to—
Antarctic-Environmental Protecol, Antarctic
Treaty. Biodiversity, Climate Change,
Desertification. Endangered Species.
Hazardous Wastes, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83. Tropical Timber 94, Wetlands.
Whaling
Geographic note: Cotopaxi in Andes is
highest active volcano in world
current issues: detorestation, overgrazing of
the slopes of the costa and sierra leading to
soil erosion: desertification: air poliution in
Lima; pollution of nvers and coasial waters
‘rom municipal and mining wastes
natural hazards: earthquakes. tsunamis,
flooding. landslides, mild volcanic activity
iniernational a2zrer™ent’: party to—
Antarctic-En’
Treaty. Bio.
Desertifica
Hazardous ‘
Layer Protection. Ship Pollution, Tropical
Timber 83. Tropical Timber 94. Wetlands
Geographic note: shares control of Lago
'' Protocol, Antarctic
sity uote Change.
nda: gered Species.
uwicar Test Ban. Ozone
Titicaca, world’s hrghest navigable lake. with
Bolivia','738b354385c23ac042bdbe4a0d651197effe6a2e42733f04b02c1ce985dfb241','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('366d686fdb9986d39ef63c8ed4bfd4b85adfce90c398a882aa61838e780bd95a',1996,'SD','Sudan','environment',314,'current issues: agricultural land being lost to
urbanization and windblown sands:
increasing soil salinization below Aswan
High Dan.; desertification; oil pollution
threatening coral reefs, beaches, and marine
habitats: other water pollution from
agricultural pesticides, raw sewage, and
industrial effluents: very limited natural fresh
water resources away from the Nile which ts
the only perennial water source: rapid
growth in population overstraining natural
resources
natural hazards: periodic droughts, frequent
earthquakes, flash floods, landslides, volcanic
activity: hot, driving windstorm called
khamsin occurs in spring: dust storms,
sandstorms
international agreements: party to—
Biodiversity, Climate Change.
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping.
Nuclear Test Ban. Ozone Layer Protection,
Ship Pollution, Tropical Timber 83.
Wetlands. Whaling: signed, but not
ratified—-Tropical Timber 94
Geographic note: controls Sinai Peninsula.
only land bridge between Africa and
remainder of Eastern Hemisphere: controls
Suez Canal, shortest sea link between Indian
Ocean and Mediterranean Sea: size. and
juxtaposition to Israel, establish its major
role in Middle Eastern geopolitics
current issues: madequate supplies of
potable water. wildlife populations
threatened by excessive hunting, soul er sion:
desertification
dust storms
party to
Biodiversity. Climate Change
Desertification, Endangered Species. Law ot
the Sea. Nuclear Test Ban. Ozone Layer
Protection, Whaling
Geographic note: larg: st country m Afnca
dominated by the Nile and tts tnbutarnes
natural hazards
iniernational agreements','2b14abf28522b930359d923d513968d9f2cdb9deb6f3cfe0a3f934296349e544','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d4e9050a5e30bb52ea42247bc7ce79aa87efe79926c7804ab47002d667bb61f',1996,'HN','Honduras','environment',321,'current issues: detorestation: soil erosion:
water pollution: contamination of soils from
disposal of toxic wastes
natural hazards: known as the Land of
Volcanoes: frequent and sometinics very
destructive earthquakes and volcanic activity
memational agreements: party to- -
Biodiversity. Climate Change. Eadangered
Species. Hazardous Wastes. Nuclear lest
Ban. Ozone Layer Protection. signed, but not
ratified - Law of the Sea
C,eographic note: smallest Central American
country and only one without a coastline on
Canbbean Sea','95aed1c8cfe911369d5d856d36b1b57a513a876fb1d8294755fc86e5fd38ca5d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83408e3c4390025ce524388bc3410617fcb70ed09c2f904b1b4645acaaf1d34c',1996,'FI','Finland','environment',334,'re sues. au heavily polluted with
¢ trom onl-shale burning power
heast. contamination of soil and
sroundw ater with petroleum products.
Soviet military bases
ing occurs frequently
; Paty to
aie Change. Endangered
> i is Wastes Ship Pollution
Peoph
Population: | 459 428 (July 1996 est)
Age structure:
{ 4 i tS .ON 5 female
» ~
On / f Lit fy SY” tematic
7 i ~
, Hr YvTe
» | La x!
Population growth rate: (1996 est)
Birth rate: }0.74 births 1.000 population
Death rate: 41) deaths/ 1.000 population
Vy
Net migration rate: 46 migrants V7 TOO0
ry pie
''
Se\\ rato:
j emale
ls
(48 mauleds female
| ite (1996 si }
Infant mortality rate: | 4 deaths’ 11000
Life expectanes at birth:
le fy
mrad ‘ » (1996 est)
fotal fertility rate:
'' ;
Nationality
ton
bthaive divisions: Estonian 61 Russian
Byecloru nm |X
bipetyy
Religions: | vran. Orthodox Chistian
lLunguages: bs m dottnes Latvian
i | k i! 1) |
Literacy Sand over can read and
;
(Mm)
150
current issues: acid rain damaging soils and
lakes, pollution of the North Sea and the
Baltic Sea
natural hazards: we floes in the surrounding
waters, especially in the Gulf of Bothnia, can
interfere with maritime traffic
international agreements: party to—Air
Pollution, Air Pollution-Nitrogen Oxides, Au
Pollution-Sulphur 85, Au Pollution-Sulphur
94. Air Pollution- Volatile Organic
Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity,
Climate Charge, Desertification, Endangered
Species, Envuonmental Modification
Hazardous Wastes. Manne Dumping.
Nuclear Test Ban, Ozone Layer Protection
Ship Pollution, Tropical Timber 8&3,
Wetlands; signed. but not ratified—Law ot
the Sea
(-eographic note: strategic location along
Danish Straits linking Baltic and North Seas','7559f18d5fd2e6619fd14019c8b8b7aaf02aff63c7a51078aa4978a4652459ec','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad0ba72a7b8dfadd850545d39b7462f427f73a19150e67ee2ccf1caccb29b76f',1996,'AR','Argentina','environment',344,'current issues: NA
natural hazards: strong winds persist
throughout the year
international agreements: NA
Geographic note: deeply indented coast
provides good natural harbors: short growing
season
current issues: deforestation (an estimated 2
million hectares of forest land have been lost
from 1958-85): water pollution: inadequate
means for waste disposal present healih risks
for many urban residents
natural hazards: iocal flooding in southeast
(early September to June}. poorly drained
plains may become boggy (early October to
June)
imicrnatuonal agreements: party to-—
Biodiversity, Climate Change. Endangered
Species, Law of the Sea, O7zone Layer
Protection: signed, but noi ratified —
Desertification, Hazardous Wastes, Nuclear
Test Ban, Wetlands
Geographic note: landlocked: lies between
Argentina, Bolivia, and Brazil','4b195691354271e4cfebccf9d2994893a2a64969589d565671f0e398c93dbe34','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('537100752a0b98fe904dfbe754cc5af8575d6a598176cb22f92c5b03d0dad965',1996,'FO','Faroe Islands','environment',351,'current issues: NA
natural hazards: NA
miernational aercements: NA
Geographic note: archipelago of 18
inhabited islands and a few umnhabited
islets; strategically located along important
eS
sea lanes in northeastern Atlantic: precipitous
terrain limits habitation to small coastal
lowlands','add87b656d6fca153a1331c6bcd01402982304f06d0999c9d633d9b2c0dd107e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79df9f5dd775ac144405466bdbdd5ac64a245769ed8647cbd86111bd194ef7cc',1996,'JE','Jersey','environment',356,'current iwsues: delorestatron, soul erosion
natural hacards: evclome storms can occur
from November to January
imernational agreements: party to—
Biodiversity, Climate Change. Law of the
Sea, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection, Tropical
Tumber 83. Tropical Timber 94, Whaling
(,eographic note: includes 332 islands of
which approxmmately 110 are inhabited
if
current issues. limited arable land and
natural fresh water resources pose serious
constraints: desertification: air pollution from
industrial and vehicle emissions:
groundwater pollution from industrial and
domestic waste. chemical fertilizers. and
pesticides
natural hazards: sandstorms may occut
during spring and summer
international agreements: party to
Biodiversity. Endangered Species. Hazardous
Wastes. Nuclear Test Ban. Ozone Layer
Protection, Ship Poliution: signed, but not
ratified - Climate Change. Desertification.
Marine Lite Conservauon
Geographic note: there are 202 Israeli
settlements and civilian land use sites in the
West Bank, 42 nthe Israeli-occupired Golan
Heights, 24 1 tae Gaza Strip, and 26 in East
Jerusalem (August 1995 est.)
RY3
current issues: no natural tresh water
resources
natural hazards: NA
mitermmational agreements: NA
Geographic note: strategic location in the
North Pacific Ocean: Johnston Island and
Sand Island are natcral islands. which have
been expanded by coral dredging: North
Island (Akau) and East Island (Hikina) are
manmade islands tormed from coral
dredging: closed to the public: tormer
nuclear Weapons fest site: site of Johnston
Atoll Chemical Agent Disposal System
(JACADS): some low-growing vegetation
current isucs. delorestation. soil erosion
native fleqa and tauna hard-hit by species
troduced trom outside
natural hazards: earthquakes are commen
though usually not severe. volcan activity
MNCTHATONGT ALTCCMCILS | Pa4»nty ts
\\ntarcic-Environmental Protocol, Antarctic
freaty. Biodiversity, Climate Change
bndaavered Species. Environmental
Moditication. Hazardous Wastes. Marine
Dumping. Nuclear Test Ban. Ozone Layer
Protection. Tropical Timber 83. Wetlands
Whaling: signed, but aot rated Law ot
the Sea. Marine Lite Conservation. Tropical
Dimber 94
Ceographic note: about SU) of the
population Lives mn cites','9e6729a29b32a4e177556633ca06b81bc1ff67653278588f0d488613365276b5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22fa50d55e276cb7244d80d360467efbf560ceef4a1629b7243b2132d22d278a',1996,'EE','Estonia','environment',362,'current issues; at pollutian trom
manufacturing and power plants contributing
to acid rain, water pollution from indus“nal
wastes, agncultural chemicals, habitat loss
threatens wildhfe populations
natural hazards: NA
mternational agreements: patty to—Aw
Pollution, Air Pollution-Nitrogen Ourdes, Ai
Potlution- Sulphur 8S. Air Pollution-Volatile
Orgamec Compounds, Antantic Treaty,
Biodiversity, Climate Change. Endangered
Species. Environmental Modification.
Hazardous Wastes. Marine Dumping. Marine
Lite Conservation. Nuclear Test’ Ban, Ozone
Layer Pro « son, Ship Pollution, Tropical
Timber 83, Wetlands. Whaling. signed, but
not ratified — Air Pollution-Sulphur 94.
Antarctic-Environmental Protocol,
Desertification, Law of the Sea
Ceographic note: long bounds, with
Russia. Helsinks ts northernnost national
capital on European continent, population
concentrated on small southwestern coastal
plain
current issues: air and water pollution
because of a lack of waste conversion”
equipment: Gulf of Riga and Daugava River
heavily polluted: contamination of sol and
groundwater with chemicals and petroleum
products at military bases
natural hazards NA
270
iniernational agreements: party to—Air
Pollution. Biodiversity. Climate Change.
Hazardous Wastes. Ship Pollution, Whaling:
signed, but not ratitied—Ozone Layer
Protection','c4792d2fd8ddae0319f054dbaeb1d251bb56de1a0b3780e36729d0ab932b69c9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30c440be332ee95a75ea25a511b12d8d35934f4fe640fcf4ca6e54bfb6ee582a',1996,'FR','France','environment',368,'seve ‘e '' ,
i
| \\u P ‘
/ ‘ py aS \\
| , j \\
, { (
s \\\\
\\I (
. »
\\ \\\\
\\ ''
() (
(eographic not \\
Peopk
Population
Age structure
Population growth rat
Birth rate: |»
1 Pipe
Death rate: 9
LP. bt,
Net migration cate
mv ity '' 1 cpio
Sex ratio:
and Hunter
I rance fie Trilite dj | ands. Glorioso Islands Juan de Nov |
Island. New Caledoma. Tromelin Islard
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: landlocked; highlands are
main recharge area for Israel''s coastal
aquifers: there are 202 Israeli settlements and
civilian land use sites in the West Bank and
26 in East Jerusalem (August 1995 est.)','5b2d350c0203f2919919a2b1154222a6211bdf0508604c8961ae8d04250370ab','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df7b06f1a8b99b59d84ca8214f4c7b02a09e37ee393d54a86a2acfa51dabce4e',1996,'WF','Wallis and Futuna','environment',369,'the US does not recognize claims to
'' ‘ Antarctica
106 ext independence: 486 (unitied by Clovis)
infant mortality rate: 5 3 dea MM) National holiday: National Day. Taking of
he Bastille L July «1 78Y
Lift expectancy af birth:
I tf president in 1962
led to comply “ith provisions of Ef
Nhua | oni I re it\\ I a PD mended la
foetal lertduty rate: J vhien mmigration laws 1993
Legal system: legislative acts
Nationality : Suffrage: 1X \\ears of age: unin
Executive branch:
r alalle Pre siden! deny yucs ( HIk \\C
1? May 1995) was elected tor a
rt ( GIVESHORS: | \\ Vear term Ds direct universal sults
chon last held 17 Mav 1995 (next to be
bby May 2002 esults —Second Ball
is lacgues CHIRAC $2.64. Lionel JOSPIN
;, :
ry Pome Min \\
PPI ~ Nf YS) wa 7.
k |
( tM
’ , n the
Legislative branch: ral Pas
f,overnment . ''
ludicul branch
Political parties and leaders
Kb) }
1
rR FI) RAD PSI }
io RI) | }’ 1} }
he \\h 1) | rl)
| SAYROL RR KAD) A
ROSSINOT. § dist Part PS) 1
KOSPIN, Lett Rad \\i 1 i(MRG
Communist Party (PCh) Robert HUT
Dependent areas: | National Front (FN). Jean-Mane LE PR’
lhe Greens. Domnnque VOYNET
Gh). Bnce LALONDI
Constitution: 2S September 1958. amended
Citizens Movement (MDC), Jean Pierre
CHEVENEMENT
Other political or pressure groups:
Communist-controlled labor union
(Contederation Generale du Travail - CGT)
nearly 2.4 million members (claimed):
Socialist-leaning labor union (Contederation
Francaise Democratique du Travail—CFDT)
ihout SOO.000 members (est.). independent
labor umon (Force Ouvnere; | million
members (est.): independent white-collar
umon (Confederation Generale des Cadres)
340.000) members (clammed): Nathonal
Council of French Employers (Consetl
National du Patronat Francais—CNPF on
Patronat)
International organization participation:
ACCT. AIDB. AG cobserver). ASDB
Australia Group. BDEAC. BIS. CCC. CDB
non-regionaly. CE. CERN. EBRD. ECA
msociite) ECk. BCLAC, EIB. ESA
ESCAP. EL. FAO. FZ. G- 5. G- 7. G-10
IADB. TABA. IBRD. ICAO, ICC, ICFT
MRM. IDA. TRA. TRAD. TRC. TEROS. ILO
IME. IMO. tnmarsat. Intelsat. Interpol, 104
JOM. ISO] TTL. MINURSO. MTCR. NACE
NATO. NEA. NSG. OAS cobserver). OECD
OSCE. POA. SPC) UN. UN Security
Council UNAVEM TE UNCRO. UNCTAD
NESCO. UNHOR. UNIDOL UNTEE
tL NIRKOM. UNTEP AR. UNMIEL UNOMEG
LNPREDEP. UL NPROPFOR, UNRW A
NINO ENE bLrt WoL. WEI Wiel
Wilt) WIPO) WATKD Wot) Wet) Ze
Dig ‘omatic representation in US
''
tS diplomatic representation
’ ‘
wig i\\!
j
; { t ) }
, ful ;
\\1 \\
blag I
'' a! ’
| | ! j lf | } wh
1) r , tly
| | { Bi j ( lL o|y The
Ca llvou ind Luxembour Li Hictal
it] i nen ch y* nent | i','cf4002d826d10010ae566f0f3765363d8cb626a583b6e6bc3c797e300616e4c5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdb1cac66f88b9740ee94fcbd7e50654536f0d6acd2805da65e101496afda41b',1996,'GF','French Guiana','environment',375,'current issues: NA
natural hazards: igh trequency of heavy
showers and severe thunderstorms: flooding
uucrnational agreements: NA
Geographic note: mostly an unse tled
current issues. NA
natural hazards: le Amsterdam and Ik
Saint-Paul are extinct volcanoes
uwuernational aercements: NA
Geographic note: remote location in thy
southern Indian Oce
‘
Rio iv. Clhamate Change. Endangered
Spees | iw of the Sea. Nucleas Test Ban
() « Laver Protection, Ship Pollution
Whaling: signed, but not ratified—
Desertification
Geographic note: almost an enclave of
Senegal; smallest country on the continent of
Atnca','4c555dd2d036093f60e4e96d51672c64d7fea8a1b00856da8c8e9c356282eefe','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ab67340b36d8eb5e1d7b809ce224bc9af0ad4f7f11293247cc44ee80b164459',1996,'IL','Israel','environment',381,'current issues: desertification
natural hazards: NA
international agreements: NA
Geographic note: there are 24 Israeli
settlements and civilian land use sites in the
Gaza Sirip (August 1995 est.)','9de0c8e9b4dbc56aa7dc3eeb8b50fb26deb54bd284b6718874e3ec6eebe909e6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82298c14c9f04e86b373ebeda8a0dfa1afe48cbfe995d961eefc47e765632c9f',1996,'GE','Georgia','environment',388,'current issues: air pollution, particularly in
Rustavi: heavy pollution of Mtkvari River
and the Black Sea: inadequate supplies of
potaole water: soil pollution from toxic
chemicals
natural hazards: NA
international agreemetits: party to—
Biodiversity, Climate Change. Ship
Pollution: signed. but not ratified—
Desertification
current issues: toxic and hazardous waste
disposal is ineffective and presents human
health risks; water pollution from raw
sewage: limited natural fresh water
resources; deforestation: overgrazing; soil
erosion; desertification
natural hazards: NA
international agreements: party to—
Biodiversity, Climate Change,
Desertification, Endangered Species,
Environmental Modification, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands;
signed, but not ratified—Hazardous Wastes,
Marine Life Conservation
Geographic note: strategic location in
central Mediterranean
current issues: water pollution from dumping
of chemicals and detergents; air pollution,
particularly in urban areas: deforestation
natural hazards: very severe earthquakes,
especially in northern Turkey, along an arc
extending from the Sea of Marmara to Lake
Van
international agreements: party to—Air
Pollution, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling; signed, but not ratified -
Biodiversity, Desertification, Environmental
Modification
Geographic note: stratezic location
controlling the Turkish Straits (Bosporus,
Sea of Marmara, Dardanelles) that iink Black
and Aegean Seas
current issues: contamination of soil and
groundwater with agricultural chemicals,
pesticides; salinization, water-logging of soil
due to poor irrigation methods; Caspian Sea
pollution; diversion of a large share of the
flow of the Amu Darya into irrigation
“93
''
contributes to that river’s inability to
replenish the Aral Sea; desertification
natural hczards: NA
international agreements: party to—O/. ne
Layer Protection; signed, but not ratifica —
Climate Change, Desertification
Geographic note: landlocked','76f2adee5eb67204d12407e60d0a8591c9ccf500d3c3d02ef2eaf470441497b4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('521694cd2c9554d7036da12094bfe1b059bf13887acbae29e08564ec46848c01',1996,'DE','Germany','environment',393,'current issues: emissions from coal-burning
utilities and industries and lead emissions
from vehicle exhausts (the result of
continued use of leaded fuels) contribute to
air pollution: acid rain, resulting from sulfur
dioxide emissions, is damaging forests;
heavy pollution in the Baltic Sea from raw
sewage and industrial effluents from rivers in
eastern Germany
natural hazards: NA
international agreements: party to—Atr
Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution- Volatile
Organic Compounds, Antarctic-
Environmental Protocol, Antarctic Treaty.
Biodiversity, Climate Change, Endangered
Species. Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber
83. Wetlands: signed, but not ratified—Air
fF ollution-Sulphur 94, Desertification.
Tropical Timber 94
Geographic note: strategic location on
North European Plain and along the entrance
to the Baltic Sea','d932a755c60005fa0e8304b2836fbbac88fdd7216861ac402afb78a1d58f6afe','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6ad7c0da46511427e52eca96771ea8ca7dd3565650019e6e5f4a0bf40f3cf82',1996,'GH','Ghana','environment',398,'curren! issues: recent drought in north
verely alfecting agnecuitural activities
lorestavion. overgrazing: soil erosion:
maching and habitat destruction threatens
dite populations: water pollution:
deqguate supphes of potable water
ids dry. dusty. harmattarn winds
» January to March: droughts
coments: party to
Climate Change. Endangered
‘I! Environmental Modification, Law of
Nu | Ban. Ozone Laver
Say Pi Lion iropical Timber
limber 94. Wetlands. Whaling:
hed— Desenitication
i ( ''
Geographic note: Lake Volta is the world''s
th vortheasierly harmattan
anu: Morcl','0420d3fcd4e39c14f7975a0eb82f4fa5588beeccc4e656f191c8e18609539eb8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80982ebb0750c4c38a6cdbe6d8dc9ddb1fea317efad315a9d8b40bc053b3dd16',1996,'GI','Gibraltar','environment',405,'current iwsues: limited natural treshw ater
resourees, so large concrete or natural rock
water catchments collect rain water
183
IFA
Gibraltar (cortinued)
NA
greements: NA
(;eographic note: strategic location on S rai
Gibraltar that links the North Atlantic
1 Mediterranean Sea','ac55e897ef992830f89e0b21e5148979421ac39c8df752ec7b8d895fc811d89d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a6bd2b719d9f8a09f85fc59a55c10f20c964a2ad30db67fcb458c50756df281',1996,'GR','Greece','environment',409,'curren! issues: au pollution: ¥ ale pollution
natural hazards: severe earthquakes
niernational agreements: party tlo—Au
Polluien. Antarctic-Environmental Protocol.
\\ntarctn Treaty Baoadiversity Climate
Change. Endangered Species. Environmental
Modification, Hazardous Wastes. Law of the
Sea. Manne Dumping. Nuclear Test Ban.
Ozone Layer Protection, Ship Pollution.
Tropical Timber 83. Wetlands: signed. but
mot catitied—Aw Pollution-Nitrogen Oxides
Air Pollunion-Sulphur 94. Air Pollution-
Volanle Organic Compounds. Desertification
(,eographic note: strategic location
domunating the Aegean Sea and southern
approach to Turkish Straits: a peninsular
country. possessing an archipelago of about
2.000 islands
current issues: NA
natural hazards: contnuous permatrost ovei
nothern two-thirds of the tsland
miernational agreements: NA
Geographic note: dominates North Atlantic
Ocean between North America and Europe:
sparse population contined to small
settlements ak me coast
wrent osucs. sal erosson results trom
deforestation and overgrazing
desertification, surface water contaminated
with raw sew ave and othes irganic Wastes.
several species of flora and tauna unique to
the rsiand are endangered
natural hazards: pervdic cyclones
mernational cercements: patty to
Endangered Species. Marine Life
Conservation, Nuclear Test Ban: signed. but
not ratihied —Brodiversity. Climate Change.
Desertification, Law of the Sea
(,ceographic note: world’s tourth-largest
land. strategie location along Mozambique
Chaunne!
Peoph
Population: 1 3.670.507 uly 1996 est)
Ave sructure:
(0-34 years: ASG tmale 3.105.958: temale
.
male 3.499.021: temale
imale 224.710
/; ears and over ;
female 233.487) cluly 1996 est
Population growth rate: 283) (1996 est)
Birth rate: 42.63 birthy/1.000 population
L006 ost
Locth rate: (4 38 deaths/1.000 population
1YYVH est)
Net migration rate: 0 microntisy/ 1 O00
population (1996 est
Sex ratio:
at durth 1 OF matetsWtemale
muler TS year 102 maletsWtemale
1S 4 years, O YS maletsWtematle
WS years and over O96 maletsiVtemale
all aves maletsi/temale (1996 est)
Infant mortality rate: 9) 5 deaths’ 1.000
V4 inths (1996 est)
Life expectancy at birth:
+
poypmlation S219 vears
hile S}oll vears
female: 53.3 years (1996 est.)
Total fertility rate: 5.89 children born/
woman (1996 est)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic divisions: Malayo-lndonesian
(Menna and related Betsileo). Cotrers (mixed
Aincan, Malayo- fadonesian. and Arab
ancestry —Betsimisaraka. Tsimihety.
Antaisaka. Sakalava). French. Indian. Creole
Comoran
Religions: indigenous beliefs 52. Chnsuian
41%. Muslim 7%
Languages: French (otticial). Malagasy
(otticial)
Literacy: age 15 and over can read and
write (1990 est.)
tal population: SOS
male: SS
‘
he male 736','b6e0408cc0c6fd18ad89eb26827953021ff3b0f210ac0f6c4109e1b460d05d33','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68140625d609faca95035e165c2a95c73053d9f0e5e59f3f38f1f46ab2bcc055',1996,'GD','Grenada','environment',417,'current issues: NA
natural hazards: lies on edge of hurricane
belt: hurricane season lasts from June to
November
imernational agreements: party to—
Biodiversity. Climate Change. Law of the
Sea, Ozone Layer Protection, Whaling
199
Geographic note: the administration of the
islands of the Grenadines group is divided
between Saint Vincent and the Grenadines
and Grenada
current issues: NA
natural hazards: hurricanes (June to
October); La Soufmere is an active volcano
international agreements: NA','2f2f0bd8852ad318cd5e573710f386b80c4609ecc8e6078db2a63ecb350dfc0f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6af59c164e7e92397f6428bd703541d071d424b00c66f2c758084c2e6bb2408c',1996,'GP','Guadeloupe','environment',425,'current issues: NA
natural hazards: trequent squalls during
rainy season; relatively rare. but potentially
very destructive typhoons (especially in
August)
international agreements: NA
Geographic note: largest and southernmost
island in the Manana Islaads archipelago:
Strategic location in western North Pacific
Ocean','4a20ad9d29b964c90982e9c0ea2ed7a6226d05a3a1616a78dd2776cd1ad09b58','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89b8e4caea1ce37a70c94b446279f8dbea8413f9eb8aff4f7c9be8a8d66760fe',1996,'GT','Guatemala','environment',429,'current issues: detorestation, soil erosion:
water pollution
natural hazards: numerous volcanoes in
mountains, with frequent violent
earthquakes: Canbbean coast subject to
hurricanes and other tropical storms
international agreements: party to—
Antarctic Treaty. Biodiversity. Climate
Change. Endangered Species. Environmental
Modification, Hazardous Wastes. Marine
Dumping. Nuclear Test Ban, Ozone Layer
Protection, Wetlands: signed. but not
ratified—Antarctic-Environmental Protocol.
Law of the Sea
Geographic note: no natural harbors on
west coas','b6ed24799f93d5d18de1b564255704811279db6fe79a4eb30d192f2fa1031bb0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bbb077bd49f38bc488ebe53924a379afcafbb115ceb5759048a768586c14ed3',1996,'GG','Guernsey','environment',435,'current issues: NA
natural hazards: NA
mernational agreements: NA
S07
Ceographic note: large. deepwater harbor at
Saint Peter Port
current issues: detorestation: inadequate
supplies of potable water. desertification: soil
contamination and erosion, overfishing
natural hazards: bot, dry. dusty harmattan
haze may reduce visibility during dry season
international agreements: party to—
Biodiversity. Ciumate Change, Endangered
Species. Caw of the Sea, Ozone Layer
Protection. Wetlands: signed, but not
ratitied—Desertification. Hazardous Wastes
current issues: detorestation: soil erosion:
overgrazing: overfishing
natural hazards: hot, dry, dusty harmattan
haze may reduce visibility during dry season:
brush fires
imernational agreements: party to—
Biodiversity, Climate Change.
Desertification, Endangered Species. Law of
the Sea. Nuclear Test Ban. Wetlands','4252516497790b57839723f2eb0f2c5da1ce1b3c5a494065ac5681c6f4748e5e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3901a27d3521f1e649778cbbcb843b54c7da9025aaebc0c181b3eb1f1f613dae',1996,'GY','Guyana','environment',441,'current issues: water pollution trom sewage
and agnecultural and industrial chemicals.
deforestation
natural hazards: tash hoods are a constant
threat during rainy seasons
uuernavional agreements. party to
Biodiversity. Climate Change. Endangered
Species. Law of the Sea. Ozone Layer
Protection. Tropical Timber 83. Whaling
current issues: sewage pollution of Lago de
Valencia; oil and urban pollution of Lago de
Maracaibo: deforestation: soil degradation:
urban and industrial pollution, especiaily
along the Caribbean coast
natural hazards: subject to floods,
rockslides, mud slides: periodic droughts
international agreements: party to—
Biodiversity, Climate Change. Endangered
Species, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands: signed, but not
ratified—Hazardous Wastes. Marine
Dumping. Tropical Timber 94
Geographic note: on major sea and air
routes linking North and South America','a32962ba1ce24808a72b265ea9bb0139e727e06e2ebafbe1490d22b42c485eaa','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3aa2fca134b9fb13ae213569f29b9d9455b398ada0b1c84d30fcfd20675e4a4b',1996,'HT','Haiti','environment',447,'current issues: extensive deforestation (much
of the remaining forested land is being
206
cleared for agriculture and use as fuel): soil
erosion: inadequate supplies of potable water
natural hazards: lies in the middle of the
hurricane belt and subject to severe storms
from June to October: occasional flooding
and earthquakes: periodic droughts
international agreements: party to—Marine
Dumping. Marne Life Conservation: signed.
but not ratitied— Biodiversity. Climate
Change. Desertification, Hazardous Wastes.
Law of the Sea, Nuclear Test Ban
Geographic note: shares island of
Hispaniola with Dominican Republic
(western one-third is Haiti, eastern two-thirds
1s the Dominican Republic)
current issues: NA
natural hazards: Heard Island 1s dominated
by a dormant volcano called Big Ben
miernational agreements: NA
Geographic note: primarily used for
research stations','170eae872a13eb5b9200c30850b6f54cd4cb120f4358643ba54b3c0ad6e76568','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cdb1c0391fe64e7207cb4114d0abef8968bbcbaf502f1b25a6530bc0fbdc3ff',1996,'IT','Italy','environment',454,'current issues: NA
natural hazards: NA
international agreements: signed, but not
ratified—Air Pollution, Environmental
Modification
Geographic note: urban. landlocked:
enclave of Rome. Italy: world’s smallest
state: outside the Vatican City, 13 buildings
in Rome and Castel Gandolfo (the pope''s
summer residence) enjoy extraterntorial
rights','952ef11b73a03d1a17b6c04569fab2b5784c487eb313b7905bbbba5f2a848139','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83cff237a54ccad739a00d357299f300163cab9de58ec5539a7a191f1c50ecc0',1996,'HK','Hong Kong','environment',460,'current issues: air and water pollution from
rapid urbanization
natural hazards: occasional typhoons
international agreements: NA
aa/
Geographic note: more than 200 islands
current issues: no natural fresh water
resources
natural hazards: the narrow fringing reet Defense
surrounding the island can be a maritime
hazard
international agreements: NA
Geographic note: almost totally covered
with grasses, prostrate vines, and low-
growing shrubs: small area of trees in the
center, pnmaniy a nesting, roosting. and
foraging habitat for seabirds. shorebirds. and
marine wildlife: feral cats
Guard','8ef4195d346683cb1169a1d1d325e006344001e8e97571040d6edec749aee5cf','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed100aa7aaf07ea7b13b7cf1752d96434ff15ee3a09afd78bc31c8f5f2905e65',1996,'RO','Romania','environment',465,'current issues: an early-1996 government
study identified 179 areas that suffer from
air pollution, 54 areas with polluted soil, and
32 areas with polluted underground water,
the study estimated clean-up costs at $350
million, but the 1996 government budget
allocates only about $7 million tor this
purpose
international agreements: party to—Air
Pollution, Air Pollution-Nitrogen Oxides. Air
Pollution-Sulphur 85, Air Pollution-Volatile
Organic Compounds, Antarctic Treaty,
Biodiversity. Climate Change, Endangered
Rnavin, nmisranmantal AAAAifieatian
Speeits. En Peererttrerttetrmmis tel etre i ettet elt me
~sS
Hazardous Wastes, Marine Dumping.
Nuclear Test Ban, Ozone Layer Protection.
Ship Pollution. Wetlands: signed, but not
ratified—Air Pollution-Sulphur 94.
Antarctic-Environmental Protocol, Law ot
the Sea
Geographic note: landlocked: strategic
location astride main land routes between
Western Europe and Balkan Peninsula as
well as between Ukraine and Mediterranean
basin
current issues: heavy use of agricultural
chemicals, including banned pesticides such
as DDT. has contaminated soil and
groundwater, extensive soil erosion from
poor darming methods
natural hazards: NA
ternational agreements. party to
Biodiversity, Climate Change: signed. but
not ratified - Air Pollution
Geographic note: landlocked
current issues: soil erosion and degradation:
water pollution: air pollution in south from
industrial effluents: contamination of Danube
delta wetlands
natural hazards: earthquakes most severe in
south and southwest: geologic structure and
climate promote landslides
international agreements: party to—Air
Pollution, Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species.
Environmental Modification, Hazardous
Wastes. Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands: signed,
but not ratified—Antarctic-Environmental
Protocol, Law of the Sea
Geographic note: controls most easily
traversable land route between the Balkans.
Moldova, and Ukraine
current issues: air pollution from heavy
industry, emissions of coal-fired electric
plants, and transportation in major cities:
industrial and agricultural pollution of inland
waterways and sea coasts: deforestation: soil
erosion; soil contamination from improper
application of agricultural chemicals:
scattered areas of sometimes intense
radioactive contamination
natural hazards: permatrost over much ot
Siberia is a Major impediment to
development; volcanic activity in the Kuril
Islands: volcanoes and earthquakes on the
Kamchatka Peninsula
international agreements: party to—Air
Pollution. Air Pollution-Nitrogen Oxides. Air
Pollution-Sulphur 85. Antarctic Treaty.
Biodiversity, Climate Change. Endangered
Species, Environmental Modification,
Hazardous Wastes, Marine Dumping.
Nuclear Test Ban. Ozone Layer Protection.
Ship Pollution. Tropical Timber 83.
Wetlands: signed. but not ratified—Air
Pollution-Sulphur 94, Antarctic-
Environmental Protocol, Law of the Sea
Geographic note: largest country in the
world in terms of area but unfavorably
located in relation to major sea lanes of the
world: despite its size. much of the country
lacks proper soils and climates (either too
cold or too dry) for agriculture','feed88e9985a70aa6317684f4073453395882c6a751ef4e010d1e697510afefd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cadc270a2706dd0c5287871d69e8492ea1b22fb829a95354d20259f75d39e59',1996,'IN','India','environment',470,'current issus: detorestation: soil erosion:
ove... “azing: desertification: air pollution
from industrial effluents and vehicle
emissions; water pollution from raw sewage
and runoff of agricultural pesticides: iap
water ts not potable throughout the country:
huge and rapidly growing population is
overstraining natural resources
natural hazards: droughts, flash floods,
severe thunderstorms common: earthquakes
international agreements: party to—
Antarctic Treaty, Biodiversity, Climate
Change. Endangered Species. Environmental
Modification, Hazardous Wastes. Law of the
Sea. Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber.
Wetlands: signed, but not ratified—
Antarctic-Envirionmental Protoco!,
Desertification
Geographic note: dominates South Asian
subcontinent: near important Indian Ocean
trade routes
arent issues: endangered marine species
lude the dugong. seals. turtles. and
| polluteon in the Arabian Sea
, 3 Re d Sc
Ships subject to
cing im eAtreme south near
i Ma to October
ments: NA
Geographic note: major Chokepomts include
\\i Su ft Honmuz. Strat
the Sue, ( dna
Ceovernment
Dat a 4 cncle | ‘ a
bLconoms
Economic overview: na Te ar
\\i hd 1 \\ | \\ iwit!
l ransportation
Ports ! { \\
4
| 4 1 \\1
\\ \\1 | ''
Ri
i
224','349b11f28d924f90f1fd12ddab04583e0b0f7cde05a340e5fad0d86eb0b8558e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40d7e5153a71c670d54e3d73cf31a7ca60b564e649e6e21a77d6c4cdcbda654d',1996,'ID','Indonesia','environment',476,'current issues: detorestation, water pollution
from industrial wastes. sewage: air pollution
m urban areas
natural hazards: occasional floods. severe
droughts. and tsunamis |
33
international agreements: party to—
Biodiversity, Climate Change, Endangered
Species. Hazardous Wastes. Law of the Sea.
Nuclear Test ban, Ozone Layer Protection.
Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands: signed, but not ratified
- Desertification, Marine Life Conservation
Geographic note: archipelago of 13,500
islands (6.000 inhabited): straddles Equator:
Strategic location astride or along major sea
lanes from Indian Ocean to Pacific Ocean
current issues: or pollution, especially in
urban areas. from vehicle emissions, refinery
operations, and mdustrial effluents
deforestation, overgrazing. desertification: oil
pollution mn the Persian Guii. madequate
supphes of potable water
natural hacards. periodic droughts. foods
dust storms. sandstorms. earthquakes along
the Western border
micmatonal aercoments party to
Endangered Species. Hazardous Wastes
Nuclear Test Ban. Ozone Laver Protection
Wetlands. signed. but not ratified
Biodiversity. Climate Change
Desertification. Environmental Moditication
Law of the Sea. Marine Lite Consers ation
current issaes: government Water control
projects have dramed most of the inhabited
marsh areas east of An Nasirivah by drying
up or diverting the feeder streams and myers:
aonce sizable population of Shia Muslims
Who have inhabited these areas tor thousands
of vears. has been displaced: turthermore.
the destruction of the natural habitat poses
serious threats to the area''s wildiite
populations: inadequate supplies of potable
water. development of Tigris-Euphrates
Rivers system contingent upon agreements
with upstream mparian Turkey. air and water
pollution: soil degradation (salinization) and
erosion, desertification
natural hacards: dust storms, sandstorms
floods
miernahional agreements. party to-——Law ol
the Sea. Nuclear Test Ban. signed. but not
ratified - Eny mental Moditication
current issues: au pollution trom industrial
and vehicular emissions, water pollution
from raw sewage. deforestation
natural hazards: flooding
micmational agreements: party to—
Biodiversity. Climate Change. Endangered
Species. Hazardous Wastes. Marine Lite
Conservation, Nuclear Test Ban. Ozone
Layer Pratection. Tropical Timber 83.
Tropical Timber 94. Whaling. signed. but
mot ratified - Desertification. Law of the Sea
Geographic note: strategic location along
Stran of Malacca and southern South China
Sea
introlled detorestation u
wd areas: son erosion: air and wate!
n Manila: mereasing pollution of
s which ar
\\ 2 ( nats
Prediidd ‘ ras Stride UN pho n belt
d by 1A and struck by five to
'' torms per vear: landslides
. i ‘ ‘ iN Ged vUcli. ie wists,
destructive earthquakes,
rhational agreements. party to
Biodiversity. Climate Change. Endangered
Species Hazardous Wastes, Law of the Sea.
Mar [> Nuclear Test Ban. Ozone
?y the Fropical Timber 83,
Wetlands. signed. but not ratified
Desertification. Tropical Timber 94
current issues: industrial pollution, limited
natural fresh water resources: limited land
availability presents waste disposal problems
37
natural hazards: NA
international agreements: party to—
Biodiversity, Endangered Species, Law of
the Sea. Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution: signed, but not
ratified - Climate Change
Geographic note: focal point for Southeast
Asian sea routes','f068d1f724f49ec0883302ab5449358dbc495cb6b5e1e539f7679a3f1f8f9c4d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ceba60df8de4555c632f5771ac89ef6812806e878725f69314f99b48b7ed3af6',1996,'IE','Ireland','environment',483,'current issues: Watel pollution. especially ol
lakes. trom agnecultura: runoff
natural hazards: NA
memanonal agreements. party to—Aw
Pollution. Aur Pollution-Nitrogen Oxides.
Climate Change. Environmental
Modification. Hazardous Wastes. Manne
Dumping. Nuclear Test Ban. Ozone Layer
Protecnion. Tropical Timber 83. Wetlands.
Whaling. signed. but not rautied—Au
Pollution-Sulphur 94. Biodiversity.
Desertification. Endangered Species. Law ot
the Sea. Marine Lite Consery ation
Geographic note: strategic location on
or air and sea routes between North
America and northern Europe. over 40% of
) resides within 60 miles of
Dublin','933382098ccb0106019c38efd8b229b44c12bc0b2ca02d341a5d5c5e4d16112b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('711ffe8b32e4513960ca9f1b76ea241d0d81d0d90294235057fcafeb13b1311a',1996,'HU','Hungary','environment',490,'current issues: ait pollution trom industnal
emiss ons such as sulfur dioxide: coastal and
inland nvers polluted from industrial and
agncultural effluents: acid rain damaging
lakes: inadequate industrial waste treatment
and disposal facilities
natural hazards: regional risks include
landslides. mudflows. avalanches.
earthquakes. volcanic eruptions, flooding:
land subsidence in Venice
international agreements: patty to—Air
Pollution, Air Pollution-Nitrogen Oxides. Air
Pollution-Sulphur 85. Air Pollution-Volatile
Organic Compounds, Antarctic-
Environmental Protocol. Antarctic Treaty.
Biodiversity. Climate Change. Endangered
Species, Environmental Modification.
Hazardous Wastes. Law of the Sea. Marine
Dumping. Nuclear Test Ban. Ozone Layer
Protection, Ship Pollution, Tropical Timber
83. Wetlands, Whaling: signed. but not
ratiftied—Atr Pollution-Sulphur 94.
Desertification
Geographic note: strategic location
dominating central Mediterranean as well as
southern sea and air approaches to Western
Europe','5c7f96b127728086eb1b0e992ea6d133ea0fc549889fc02e6a9ca5e989b54bfd','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fef340c8f6869f01590ad3e1497b0fb17b8c85ac7638c1ee36cc1beb6e3a14ef',1996,'JM','Jamaica','environment',493,'arvevil isin dctorestation. coastal waters
polluted by mdustnial waste. sewage. and oul
sill. } “9 '' ] oo 4 '' |] "
spills. Gatlhage to coral reels. air pollution on
Kingston results tron vehicle emissrons
adtural hacards: Warne ves Cespecially July
to Nove “T)
micmanomnal agrccments, Pa4#°nty to
Biodiversity. Climate Change. Law of the
Sea. Manne Dumping. VMicune Loic
Cun rvatwon. Nuclear Test Ban. Ozone
Laver Protection. Ship Pollution. Whaling
29
Jamaica (continued)
(,cographic note: strategic location between
|
h and Jamaica C? annel. the
ow Panama Canal
currem iusnes: NA
241
Jan Maven (continued)
(,cographic note:','398d1bac14adcb2d2d7dd335520d1746e8c0f48f77f890ccff3ad02ac14af9e6','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7aaa98febc5e07cfa679876db0009b7ddb269f7327ca3e766242903f51f80b2',1996,'JP','Japan','environment',498,'current issues. an pollution trom power
plant emissions results mm acid rain
acndification of lakes and reservoirs
degrading water quality and threatening
aquatic life. Japan''s appetite for fish and
tropical timber ts contributing to the
depletion of these resources m Asia and
elses here
natural hazards. many dormant and some
active volcanoes: about 1.500 seni
wccurrences (mostly tremors) every year
tsunamis
nucrnational agreements: party to
Antarctic Treaty. Brodiversity, Climate
Change. Endangered Species. Environmental
Modification, Hazardous Wastes. Marine
Dumping. Nuclear Test Ban. Ozone Laver
Protection. Ship Pollution. Trop.) Timber
83. Tropical Timber 94, Wetlands: signed
but not ratihred—Antarctic-Environmental
Protocol, Desertification. Law of the Sea
Tropical Timber 94
Cseographic note: strategic location in
northeasm’ Asia
current issues: no natural tresh water
resources
natural hazards: the narrow tringing reet
surrounding the isiand can be a maritime
hazard
international a ereements NA
Geographic note: sparse bunch grass.
prostrate vines, and low-growing shrubs
primarily a nesting. roosting. and foraging
habitat tor seabirds. shorebirds. and marine
wildlite: feral cats
current issues: NA
nuural ha-ards. ative volcanism on Tristan
da Cunha
wuemational agreements \\N A
(,eographic note: Napoleon Bonaparte +
place of exaile and burial itis remains were
taken to Parts m 1840). harbors at least 40
species ol plants UNKNOWN any her is }
the world. Ascension ts a breeding ground
hw sea furties am','9f88df9ea0469420ac35d94755b86a15a2fa2bdacb78d895a391fb1dcac521f1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dba8cde2668a6f73ea4a4cd023f14987f84c4c7f1243bb6179179e51373ae828',1996,'JO','Jordan','environment',502,'current iwsues? limited natural tresh wate
resources, delorestation. overgrazing. soul
erosion, desertification
natural hazards: NA
international agreements: patty to—
Biodiversity, Climate Change, Endangered
Species. Hazardous Wastes, Marine
Dumping. Nuclear Test Ban. Ozone Layer
Protection, Wetlands: signed. but not
ratitied—Desertification, Law of the Sea','d4f6ecc2750e4f0879f030dec99723b1068a264d8dd34dd81cfe9d0a7b14907f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fbe9df97a0fda9fec314e4265a45fa7dddf420b050784c31da79001d6e65486',1996,'LV','Latvia','environment',516,'current issues: deforestation, soil erosion:
desertification: air pollution in Beirut from
vehicular traffic and the burning of industrial
Wastes: pollution of coastal waters from raw
sewage and oil spills
natural hazards: dust storms, sandstorms
international agreements: party to—
Biodiversity. Climate Change. Hazardous
Wastes. Law of the Sea. Nuclear Test Ban.
Ozone Layer Protection, Ship Pollution:
signed. but not ratitied—Desertification,
Envionmental Modification, Marine
Dumping. Marine Lite Conservation
Geographic note: Nahr al Litam only major
river in Near East not crossing an
International boundary: rugged terrain
historically helped isolate. protect. and
develop numerous factional groups based on
religion, clan. and ethnicity
ive vir se
Orel i ‘ * Wir
Nena i i
PiadiMta i \\ \\
rireThwi ‘ le ‘
( epee S ‘ ? “ * .
ui n ral ‘ Is ‘3
Protes','843709db4885472f0d014adbd79dea44ccf21fc14a317d504f0a2dd2c9489655','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34ac705d6c4fe3c9d63a9b02c7fd67d0835326389c288a9e8145b9f0647f53a3',1996,'ZA','South Africa','environment',522,'current issues; population pressure forcing
settlement in marginal areas results in
overgrazing, severe soil erosion, soil
exhaustion: desertification: Highlands Water
Project will control, store, and redirect water
to South Atrica
natural hazards: periodic droughts
international agreements: party to—
Biodiversity, Climate Change,
Desertification, Marine Life Conservation,
Ozone Layer Protection, Wetlands: signed.
but not ratified - Endangered Species, Law
of the Sea, Marine Dumping
Geographic note: landlocked: surrounded by
current issues: tropical rain forest subject to
deforestation: soil erosion: loss of
modi versity: pollution of rivers trom the
dumping of iron ore tailings and of coastal
Waters trom oi residue and raw sewage
natural hazards: dust-laden harmattan winds
blow trom the Sahara (December to March)
miernational agreements: party to
Endangered Species. Nuclear Test Ban. Ship
Pollution, Tropical Timber 83. Tropical
Timber 94: signed. but not ratified
Biodiversity. Climate Change. Environmental
Modification. Law cf the Sea. Marine
Dumping. Marine Lite Conservation
current issues: lack of important an
rivers or lakes requires extensi:
conservation and control measures. grow!
Water usage threatens t outpace SUD
pollution Ol nvers trom agricultural runs!
and urban discharge: air pollution resultu
in acid rain, soil erosion, desertificats
natural hazards: prolonged drought
mlermational agreements, Party to
Antarctic-Environmental Protocol, Anta
Treaty Biodiversity Endangered Species
Hazardous Wastes Marine Dumping Marine
Lite Conservation, Nuclear Test Ban. O7or
Layer Protection. Ship Pollution. Wetland
Whaling: signed. but not ratified —Clin
Change. Desertification, Law ot the Sea
Geographic note: South Atnica comp
surrounds Lesotho and almost comp
surrounds Swaziland
current issues: pollution of the
Mediterranean Sea from raw sewage and
effluents from the offshore production of oil
and gas; air pollution: detorestation:
desertification
natural hazards: pertodic droughts
party to—Au
Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Volatile Organic Compounds.
miernational agreements
Antarctic-Environmental Protocol, Antarctic
Treaty. Biodiversity, Climate Change.
Endangered Species. Environmental
Modification, Hazardous Wastes, Marine
Dumping. Marne Lite Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands.
Whaling: signed, but not ratified —Au
Pollution-Sulphur 94, Desertification, Law ot
the Sea
Geographic note: strategic location along
approaches to Strait of Gibraltar','1861f0f457af508dd9db23f23be234edea3dfd87e7c5371b7c5568cd0c010b8e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcecc3089873476f871189aad455fb12f5260043e4fa13ab2fa6d9413ea1ab8e',1996,'TN','Tunisia','environment',528,'current issues: deserttication. verv limited
natural fresh water resources. the Great
Manmade River Project. the largest wates
development scheme in the world peme
built to bring water from large aqguiters
under the Sahara to coastal cities
natural hazards: bot. dry. dusi-laden ghib
is a southern wind lasting one to four day
in spong and tall. dust storms. sandstorms
memanonal agreements Party i Marin
Dumping. Nuclear Test Ban Ozone Lay
Protection: signed. but not ratified
Biodiversity. Climate Change
Desertification. Law of the Sea','be49687562f06d37a6d824d13251e7dc6310da4fc722f80d7db262bc4be623b7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a19b8e263a85af1cb7ef9cb06c3ddb758a7d2411fb9650bb9369e4af987a168',1996,'LI','Liechtenstein','environment',535,'current issues. NA
natural hacsards. NA
281
Liechtenstein (continued)
ereemems: party to—Au
r Pollution-Nutregen Oxides. Au
lution Sulphur SS. Am Pollution- Volatile
( pours. Climate Change.
Hazardous Wastes
Wetlands: signed
‘ollution-Sulphur 94.
} : . "ine Sea
~<
f,cographi note: landiahke? vanety of
hased on clevation
'' pet
tie 19UG est)
! lure
> 461. temale 2.871)
L775. temale
t66: female
nety «
Population gro oth rate: | Us'') (1996 est)
Birth rat 17 berth. 1000 peu lation
} th
Death rate: 6.5!) death 1.000 population
~~
Net migration rate: 6 1) nucrantisy 1.000
Pre rprar lather | <P I}
Sex ratio:
aiperi 4 maletsViemale
under 15 \\ears, 1 O8 maletsWtemale
13.64 vsurs 197 muleiswlemale
HS vears a cr O67 maletsWiemale
all ages he ft leis Wtemale (1996 est.)
Infant mortality rate: 5 § deaths/!.000 live
mrt LSPbty .t 3
Life expectancy at birth:
worvials ; 5 Ad Cars
Jf YU, est }
lotal fertility rate: | 47 ciuldren born/
Wh owt
Nationality:
pigiler | wecMltiecnstett
(didjad Tite | ecnicnstcin
bihnic divisions: \\icmannc 9S ltalian
thes
Religions: Roman Catholic 87.3%
Proviestant > unknown |6%. other 2.8%
Languayes: German Cottioal), Alemanni
halect
Literacy: ace 10 and over can read and
write (1YR] esi)
otal population WOO
male VO
fe noale }(my,
282','80abcec108c05cf13c812ff6fdef8f6b1b48670fd73011171177ee096ae68c5c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6141f5d9f6238e38b9e0366423120fd92d8ffa2f3a10048b388f3278da7e297',1996,'LU','Luxembourg','environment',544,'current isues. detorestation: au and wate:
pollution in urban areas
dural hazards: NA
uiutiernational agreements: party to--An
Pollution, Air Pollution- Nitrogen Oxides
285
with miid
Ni
34.
Luxembourg (continued)
Sulphur SS. Air Pollution-Volatile
Orzanic ( pounds Biodiversity. Climate
ed Species. Hazardous
Wastes. Marie Dumping. Nuclear Test Ban.
Laver Protection, Ship Pollution.
signed. but not rautied
Desertification.
| Nloditication. Law of the Sea
(-eovraphic nate: diocked
current issues: Water pollution
natural hazards: cyclones (November to
April): almost completely surrounded by
reefs that may pose maritime hazards
auernational agreements: party to—
Biodiversity. Climate Change. Endangered
Species. Environmental Modification,
Hazardous Wastes. Law of the Sea. Marine
Life Conservation, Nuclear Test Ban. Ozone
Layer Protection. Whaling: signed, but not
railitied - Desertification','e1b42a5058dc35a2b8696d2d11ac0da0a8b28c892c4fbd8659b992733d44daa3','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a047ebbfe7ab063dd6bb20993c9a9aa5dd0ac92719cc5efa3190fc0cf944a2b5',1996,'ZW','Zimbabwe','environment',554,'current issues: detorestation: land
degradation, water pollution from
agricultural runoff. sewage. industrial wastes:
siltation of spawning grounds endangers fish
populations
natural hazards: NA
international agreements. party lo-—
Biodiversity, Climate Change. Endangered
Species, Environmental Modification,
Hazardous Wastes. Marine Life
Conservation, Nuclear Test Ban, Ozone
Layer Protection: signed, but not ratified—
Desertification, Law of the Sea
Geographic note: landlocked
current issues: ait pollution and resulting
acid rain in the mineral extraction and
cefining region; poaching seriously threatens
rhinoceros and clephant populations:
deforestation, soil erosion, deserufication:
lack of adequate water treatment presents
human health risks
natural hazards: tropical storms (November
to April)
international agreements: patty to—
Biodiversity, Climate Change. Endangered
Species, Hazardous Wastes, Law of the Sea.
Nuclear Test Ban, Ozone Layer Protection.
Wetlands; signed, but not ratified —
Desertification
Geographic note: tandlocked','c8b6a8399585fec8e238c2007bc0ecbcd883f5d778742105961c2eebcf7fee7c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f496a1838dad7a444471b1306d9799259357e86ba358674e6d7e8420611670d',1996,'MV','Maldives','environment',561,'current issues: depletion of freshwater
aquifers threatens water supplies
natural hazards: low level of islands makes
them very sensitive to sea level rise
international agreements: Darty to—
Biodiversity. Climate Change. Hazardous
Wastes. Ozone Layer Protection: signed. but
not ratified—Law of the Sea
Geographic note: |.190 coral islands
grouped into 26 atolls: archipelago ot
Strategic location asinde and along mayor sea
lanes in Indian Ocean','11668b74d027cfa45a9be6419e6cc57c1b8ad67084e682b0a58b1b2159f1af7c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('449d70b6ec568ff3434e501a0a4f3bcdf548c0fb8eb53af1c5524a7e88e908a7',1996,'DZ','Algeria','environment',566,'current issues: detorestation, soil erosion:
desertification: inadequate supplies of
potable water: poaching
natural hazards: hot, dust-laden harmattan
haze common during dry seasons: recurring
droughts
international agreements: party to-
Biodiversity, Climate Change.
Desertification, Endangered Species. Law ot
the Sea. Ozone Layer Protection, Wetlands:
signed, but not ratified—Nuclear Test Ban
Geographic note: landlocked','f8435cc392c6e54efbcad709825bdc84f08ece261da50cfdabed8fc09bfe1d05','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbdaa51fb06d8a3506452a85ca67901753bfc9c8ade3c164e8b1e6feb1e799fa',1996,'MT','Malta','environment',572,'current issues: very limiied natural fresh
Water resources: increasing reliance on
desalination
Sy/
natural hazards: NA
international agreements: party to—Climate
Change. Endangered Species, Law of the
Sea. Marine Dumping, Nuclear Test Ban.
Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling: signed, but not
ratified —Buodiversity, Desertification
Geographic note: the country comprises an
archipelago, with only the three largest
islands (Malta. Gozo, and Comino) being
inhabited: numerous bays provide good
harbors
current wsues. NA
natural hazards: NA
miernational aereements: NA
Geographic note: one small istet. the Calt
of Man. lies, to the southwest, and is a bird
sanctuary
3/3','59dcfc13579d8bad795d8558cd034671e7cc3230e4073eb63c37c452ecb1d738','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6370ddb5b48fd8979af15e203e9ca507180fe3852f86322bc9e578040afdbad1',1996,'MH','Marshall Islands','environment',578,'current wsues. inadequate supphies of
potable water
natural hazards: occasvonal typhoons
party to
Biodiversity. Clamate Change. Law of the
mecmational aercements
Sea. Ozone Layer Protection, Ship Pollution
(,eographic note: two archipelagic island
chains of 30 atolls and 1.152 stands: Brhins
and Enewetak an tormer US nuclear test
sites. Av ajalem. the famous World War Il
battleground. 1 now uved as a US mussile
leM range','19f1bc221e0f706ac0f5c156fced536b383f502f971ec92bb955374b49acbb25','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08fe2c9eee639ea6ae171f6a501ae6952f3eb9a4a1087f5bdd19aadb49b7f6b7',1996,'MQ','Martinique','environment',588,'Curren! iss#es” OVeTETA7 NG Jetoresiation
and sui erosion aggravated by drought are
contnbuting to desertification. very limited
natural fresh water resources away trom the
Senegal which ts the only perennial nvet
natural harards: tut. dry. dust/sand-laden
wirecee wind blows ponmarnily m March and
April. penodie droughts
nlemlemal avrcenmcnss parts lh
Nuclear Test Ban. Ozone Laver
Wetlands but not
( hance
Pratectnon signed
Desertifncatro | iM
3 \\.
‘
Ceographic note: most of the population
centirated a w the Senezal River om the
ike Part «ol ihe Contr
, »
Peoph
Population: 2.236.048 luly [996 est
\\ve sMructure:
4 ,* : ’ wes SS ‘ ’
ay j
j ay Wot) SA
; ; 4
mia § |
i7 liily (pur
Population growth rate: } |” nn
Birth rate: 46 92 birth. 1.000 popula
Death rate: }5 24 dew! HD rcnul
a hi
Net migration rate: 0 micron nm
, haf 1
Se’ ratio:
,
. ’ 4
4 Nn | j
YS | el i
f wets Vien 1
W Heis) temal YEH est
Infant mortality rate: 8! 7 deaths’) .000
hyirtiys | ur «1
Life expectancy at birth:
ry sin j svi) Vcul
, ni ,
cmale S206 years (1996 «¢
lotal fertility rate: 6.54 Children bor
wnan (1996 es
Nationality:
wm. Mauritanian
« Mauritaman
Ethnic divisions: mixed Maur/black 40
Miaaur 40. black 40
Religions: Viuslim 100
Languages: Hassanya Arab Cotticil)
Pular, Se Wolol tottrciuls
Literacy: ave 15 and over can read and
rinnh«
Mnte (1995S est
C,overnment
Name of country:
comentional lone torm: Islamic Republi ol
Mauritama
comvcntional short form: Mauritania
ecal long form. Ni Jambhuryah al Islami ah
al Muritany ah
lncal short form: Murvtianiy ah
Data code: VIR
Ivpe of government: republa
(Capital: Nowakchot
Administrative divisions: | 2 regions
Adrar. Assaba
Brakna. Dakbict Nouadhibou. Gorge
Gundimaka. Hodh ech Chareus. Hodh el
CGiharh lavamt. Tons Zemmour
(regions. singular —recun)
Inchon
lrarsa
« there may be au new distnict of
Nowake hott
Independence:
ht mw.
National holiday: Independence Day. 28
November
Constitution: |2 fuly
tal
*s November 1960 (from
1 \\otwll
Legal svstem: three-tier svstem: ama
Shur a) comer smectal Courts, and state
COUTITN Certirts nm tlk Priwess of Pee
Suffrage: |S veo face. un
Fxvecutive branch:
Presidemt ( VMiagousa Ould
Sul Al PAYA tsince 12 December
S4) Was Teciected hog 4 si\\-Vear term
< i} sulfrave. eclectlnmn toheki 17
lanuars 199) cnet to be held NA January
nient ¢ Maawousa Ouid
‘ a \\hined | \\\\) \\ Wis Tes cCclced
Prome Virnster Cheikh
YS) results — Pres
cial «rt Pari
bE! Attu Ould Mohamed AHOUNA (since
NA Jonuars 1996) mpruntod by the
messdent
‘ c cum iN kt
Legislative branch: hic omeral leeistatur
Senate (Ma ‘ Shavwhhhi clectoons Last
held TS April 1994 cnet to be held 12 April
WYO). results - percent of vote hy party NA
cats (56 with 10 up tor clection every
two sears) PRDS 16, LED/NE |
National Assembly (Majlis al-Wate
lecthoms last held 6 and 14 Mar hn 1992
nest to be held NA March 1997)
percent of vote Oy party NA. seats — 79
total) CED/NE 67. PMR IL RDU |
independents 10)
results
Judicial branch: Supreme Court (Cour
Supremn
Political parties and leaders: legalized by
yy]
constitution passed 12 July however
prrlitis s continue to be tobally based
emerging parties include Democratic and
Social Republican Party (PRDS). led by
Maaouva Ould Sid Ahmed
President Col
TAYA: Union of Democratic Forces-New
Era (UFD/NE). headed by Ahmed Ould
DADDAH. Assembly for Democracy and
Unity (RDU). Ahmed Ould SIDI BABA:
Popular Social and Democratic Union
(UPSD). Mohamed Mahmoud Ould MAH.
Mauritaman Party for Renewal (PMR).
Hameinda BOUCHRAY A: National Avant-
Garde Party (PAN). Khattry Ould JIDDOU:
Mauritaman Party of the Democratic Center
(PCDM). Bamba Ould SIDI BADI
Other political or pressure groups:
Mauritaman Workers Union (UTM)
International organization participation:
ABEDA, ACCT (associate). ACP. ATDB.
AFESD. AL. AMF, AMU. CAEU. CCC.
ECA, ECOWAS. FAO. G-77, IBRD. ICAO.
ICRM. IDA. IDB. IFAD. TFC. IFRCS. ILO.
IMF. IMO. Intelsat. Interpol. IOC, ITU.
NAM. OAL. OIC, UN, UNCTAD.
UNESCO, UNIDO, UPL, WHO. WIPO.
WMO. WT0O, WTrO
Diplomatic representation in US:
clnet of mssson: Ambassador Ismail Ould
1y AHI
cory. 2129 Leroy Place NW
Woshingten, DC 20008
lephone: {1} 4202) 232-5700
LS diplomatic representation:
chief of mission: Ambassador Dorothy Myers
SAMPAS
cmbass\\: address NA, Nouakchott
mailing address: B. P. 222. Nouakchott
telephone: { 222) (2) 526-60, $26-63
FAX. [222] (2) 515-92
Flag: green with a yellow five-pomnted star
above a yellow. horizontal crescent: the
closed side of the crescent ts down: the
crescemt, star. and color green are traditional
symbols of Islam','24e92e29e85992df01eaaf54157934fe5f078d7c9a702edaa448f3e84360034c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc94dc2ce736f361f5610166ca49d7686405284c13f1e6c4256c57206115a810',1996,'FM','Micronesia, Federated States of','environment',593,'’
Cithien
S18
ws NA
vyroup in the North
cecaun. about three-quarters of the
natural hazards: typhoons (June to
December)
uiermatioral azreements party to
Biodiversity, Climate Change. Law of the
Sea: signed. but not ratitied—Desertification
Hazardous Wastes. Ozone Layer Protection
Geographic note: four major island groups
totaling 607 islands
Peop''c
Population: 125.377 uly 1996 est
Age stricture:
ears N \\
/> hd Voarys Ss
-s4
{est 5
NA
Population growth tote: 3 34
Birth rate: 27
i }OU6H si
h.% CUTS Ghd Oe
1 | SIty ost
94 births WW) population
i) j
Death rate: 6 22 deaths) 1.000 population
| pe Csi
Net migration rate: |) 65 nuerant. (MW)
}UUH est
}™ ul thon
Sev ratio:
Infant mortality rate: > 8 doo LL
ali
Life expectancy at birth:
sn ‘ Py Cy 7 pipe ''
lotal fertility rate: 496 Childe
yo s!
Nationalits:
w Micron
© Moicromesiagn K
Pohnperan Frukese. Y
bithnic divisions: ny
md Polynesian groups
Religions: Roman Catholic 30%). Protestant
y, ther and nom
Languages: bnelis! HHrcnal ana ¢
Trukes
Literacy: dvge tS and over can read and
write (1USO est
had Poyndahton if a
Covernment
Name of country:
comvenitonal jong form. tkederated States of
Micronesia
(MN CHMONAaAL Shor form. Mon
357
former: Kostrae, Ponape. Truk. and Yap FAX: [691] 320-2186 Economic aid:
Districts (Trust Territory of the Pacilic Flag: light blue with four white five-pointed recipient: under terms of the Compact of
Islands) Stars centered. the stars are arranged in a Free Association. the US wall provide $1.3
abbreviation: FSM diamond pattern billion in grant wid during the penod 1986
Data code: FM WO!
Type of government: constitutional
government in tree association with the US:
the (mpact of Free Association entered into Economy
force 3 November 1986
Capital: Kolonia (on the island of Pohnpet)
note. anew capital ts being built about 10
Currency: | United States dollar (USS
1M) cents
Exchange rates: |S corre:
Economic overview: Economic activity Fiscal sear: | OGobo: ‘
consists primary of subsistence farming and
fishing. The islands have tew mineral
km southwest in the Palikir valley .
o 7 - deposits worth ex YNomwmne except tor high
Administrative divisions: 4 states. Kosrac | | y P ,
P hap 1. Chuuk (Truk). \\ p vrade phosphate The potential for a tournst + ransportation
“ Cl. Hun f in}. al
, mdustry exists. but the remoteness of the
Independence: 3 November 1986 (from the . Railways: 0 ko
location and a lack of adequate facilities ;
US-administered UN Trusteeship) . Highways:
. ) hinder development binencial assistance ¥
National holiday: Proclamation of the total Deak
from the US is the primary source of ~
Federated States of Micronesi. 10 May naved WWhkm
1979 revenue. with the US pledged te spend S Julies
}
billion in the mlands im the [990s weaved. Ins AN
Constitution: |) May 1979 ) ; .
. ‘ > . ’ .
Geographical tolation and a poorls Ports: Coloma (Yap) K ''
Legal system: based on adapted Trust |
; desecloped infrastructure are mayor Mot
Permtory laws. acts of the legislature .
mmpediments to long-term growth Vierchant marine:
mumcipal, commen. and customary hiws Di
. GDP: purchasing power panty — S208 irperts:
Suffrage: |S vears of age. universal , ee eee \\irports
. nithlioy 1YYUd , '' ~
Executive branch: halo
duet of Mate and head «'' Vernearnenl Nave GD ! su] peecmented PV Shan aid J :
. , moe poerboans (mw): its i!
President Bailes OL TER (since 2! May WETALINE PETNAPS S ne ''
: . ’ oe ‘ .* i ail
991) and Vice President Jacob NENA GDP real growth rate: | 4 m4
(since 21 Mav 1991) were elected bv the GDP per capita: » (mM) ean
Congress trom among the tour Senators-at GDP composition by sector:
Large. election last held TT May 1998 crest agriculture NA
to be held NA Miav 18 9a. results. Barley ndiasti NA ( ommunications
OLTER reelected ta second term at enwes NA
| I} R 4 Ic ced t iw nN | ter ! lelephones
president. Jacob NENA reelected toc second Inflation rate (consumer prices): 4 m4 Telead
Saad ciephone system
CTTi as Vie pots Shieh
dhinet Cabinet Labor force: \\ \\
Legislative branch: unicameral My occ aagratiant AN
Caoneress clections last held > March [9s emplovees
newt to be hen NA March P9899) results Unemployment rate: - :
'' } | te wt i} hl i| .
percent al Vale \\N\\ il ia Td Budyet:
, . , . 1 i Af
independents 4 venues: 644 1 | Radio broadcast station
Judicial branch: Supreme Coun ee ee
’ af ners ‘ ; . ‘ * ) bd la’ v7 ‘
Political parties and leaders: no torn. expenditures of SNA CEY 94/05 Radios
pPuaTICS Industries: tov : nat : od lelestsion broadcast Stiathons
International organization participation: processing. cralt items trom st Peles sions
DB. ESCAP IBRD. ICAO IDA. Ti neart
earls
IMB. Intelsat. ITU. Sparteca. SPC. SPEOUN
Industrial production growth cate: \\ \\
LI NCTAD. WHOL. WMO
blectricity:
Diplomatic representation in US: Defense
| . ! : apyuicil 1s (MM) KW .
linet of musston Ambassador Jesse B , wh Det
poduchon 40 mitlen } clensc mot
MIAREHALAL
COMSNpPTION Por capita sSOO RWI pn) _
cedars | 738 \\ Sireet! VW.) W ashington
I” MDG Agriculture: blac. pep ver. tropic | trun
laoloriion 1) 00) 293-4383 and vegetables, CO.
iia) cele a! - ,A.4
PAN U1} 4202) 223-439] sweet potatoes. pigs. chickens
OMUTS. Cassava Chapeau
. *\\ HO ] firh }i) }
consulatets) vencral, Honolulu and Eaports: | ition
Pamunng (Guan) commodities. tish. garments. bananas. black
US diplomatic representation:
net of mission” Ambassador March Fong
pepper
parmers. Japan. CS. Guam
HI Imports: S141 i million coat. 1994 est
cmbass\\” address NA. Kolonia commodities. tood. manutactured rons
mailing address’ POL Bow 1286. Pohnper machinery and equipment. beverages
Federated States of Micronesia 9694 | partners: US. Sapan. Australia
telephone: [O91] 320-218 External debt: S!29 million
\\lidway Islands
ters of the US)
Tt} ordima
lisgpiites
steal lanl
P ete ereortepene
f,cogr ipl hc Theele
820
= :
People Defense
Population: no indigenous whabitants ''
pulation: ne indigenous mhabitant Defense note: detense is the responsibility
mve—tAhere are 453 US nubian personne!
al the | ‘
(ju \\ Ys es
Covernment
Name of country:
cntional long form: none
cntenal short form: Midway Islands
Data code: IQ
Ivpe of government: unincorporated
tory of the US tormeriy administered by
| ‘ N »\\ under Nuval | Teri} cs
t necriny’ ( PEtD and Prrcits Divas . {nis
n en pe! ithonatl \\ wed Th
S n ; mia S currently
li el ar ree intability and
| rd Woaldlits SETV 14
Capital: no cht tered tron
Wost 1M
Flay: : is
bconomys
btconomic over siew: | hused
blectricity iS Mf
lransportation
Railways
Hivhwasys
Pipelimes: — s 4
Ports: 5
Virports,','ac5887e064ddb22046cd377e99ae51d59e071d0895b222e46b90b809e65e8199','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('441597336a2c430ee6fc78cbe7d25e2a7d2c4079e3d22ccc33b8d5d7bb456578',1996,'MS','Montserrat','environment',603,'current issues: land erosion occurs on slopes
that have been cleared for cultivation
natural hazards: severe hurricanes (June to
November): volcanic eruptions (there are
seven active volcanoes on the island)
miernational aereements: NA','865bbded32da91de54bc83bad4a7dc2ca72c5941597fad511e5f78c253cac2af','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c39763996c9cf1f5ffbea45e9b3ce9e75c76591ad713e44ef1c7d0b7ad771c9',1996,'MA','Morocco','environment',608,'current iwsues. land degradation/
desertification (soil erosion resulting from
farming of marginal areas. overgrazing.
destruction of vegetation): Water supplies
contaminated by raw sewage. siltation of
reservoirs: onl pollution of coastal waters
natural hazards. northern mountams
geologically unstable and subject to
earthquakes: perniodic droughts
ternational agreements: party to
Biodiversity. Climate Change. Endangered
Species. Marine Dumping. Marine Lite
Conservation. Nuclear Test Ban. Ozone
Layer Protection. Ship Pollution. Wetlands:
signed, but not ratitied—Desertitication.
Environmental Moditication., Law of the Sea
Geographic note: strategic location along
Strait of Gibraltar
current issues: soil erosion
natural hazards: occasional typhoons, active
volcanism
international agreements: party to—
Biodiversity, Climate Change, Lew of the
Sea, Nuclear Test Ban, Ozone Layer
Protection
current issues: large areas subject to
overpopulation, industrial disasters, pollution
(air, water, acid rain, toxic substances), loss
of vegetation (overgrazing, deforestation,
desertification), loss of wildlife, soil
degradation, soi! depletion, erosion
natural hazards: \\arge areas subject to severe
weather (tropical cyclones), natural disasters
(earthquakes, landslides, tsunamis, volcanic
eruptions)
international agreements: selected
international environmental agreements are
included under the Environment entry for
each country and in the Selected
International Environmental Agreements
appendix','20d5464fc1d0e0e16134fd73a9a7bc41e73ee86e05267e64b3d1e7810d35b8ba','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2b053c931dc18f955338ed76706a1d180b99d14b75b5bb9424d1cc04d1b5c39',1996,'MZ','Mozambique','environment',613,'current issues. cvil strife and recurrent
drought in the hinterlands have resulted in
increased migration to urban wnd coastal
areas With adverse environmental
COMSeQUeneEe’s de .ortificalion: pollution ol
surface and coastal waters
natural hazards. severe droughts and tloods
occur in central and southern provinces
devastating evclones
HWUCHHNANONaGL ALTCCHICHIS party ty
Biodiversity. Climate Change. Endangered
Species. Ozone | Avel Protection. srgned. but
not rauitied —Deserniticanion., Law of the Sea
current issues: soil degradation;
deforestation; desertification; destruction of
coral reefs threatens marine habitats; recent
droughts affected marginal agriculture
natural hazards: the tsetse fly and lack of
water limit agriculture; flooding on the
central plateau during the rainy season
international agreements: party to—
Endangered Species, Hazardous Wastes, Law
of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Whaling; signed, but not
ratified—Biodiversity, Climate Change,
Desertification
Geographic note: Kilimanjaro is highest
point in Africa','e7dd0199133f48e7b0de9f36ee4fb9fc79499215bc2bacf5034c5fb5e34ea726','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51f2978ccd21ae3052aac819a71b651913998f1dd3ba37824ed6bfa05992a99c',1996,'NA','Namibia','environment',622,'Ciarren isso Tinite !
resources, rool storave tank
rain atet prarspyhat minima thy
livited remaming land res ces
natural hacards. pervade drow
nictmnalwmnal aereceoments prmar4rty
Brodiversity. Clamate Chanve. Vian
Aas
Nauru (continued)
ping. signed. but not ratiied—Law ot
|
.
(,cographic note: Nauru ts one of the three
seat phosphate rock islands im the Pacitk
can the others are Banaba «Ocean
dyon Kombat) and Makatea im French
esta. only $3 km south of Equator
current iwsues” NA
natural hacards. NA
mernational agreements NA
Ceographic note: strategic location 160 km
south of the US Naval Base at Guantanamo
aay','de410cdbc5a97a43f763b9558ce627a7b5ac67c47c8f0c0fe4e37506fb54df6a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06a14e48535e32714220fd3afde06a7252cc3ce46a0a7b78455a772316852fd4',1996,'NP','Nepal','environment',625,'f.couraphy
icin thn , \\ We
(,cographic coordinates: 2s OO NO S4 00T
Map references: \\
\\rea
t fiat
land hboundarte
fy hon. Tod
{ sas thnane AS
\\Nlarttome clo nlhacked
International disputes:
( lmats miners at
vir "?
, ,
lerram phan
|
. Rails {
J } *» \\44
Natural resources “Mole mh<er
% sil
bh, 7 re
spel tase
trrivated land " WAY)
i nvironment
nem «
bern lrees to
“wit eplanting
; kelorestalnon
i “« of! Cwlamenated
n bealth rmsekes
sere thunderstorms
les, drought. and tamune
ine. mtensaty. and
’ ’ | HTT TIMING MTs
438
(hina and
memational agreements: patty to—
Biodiversity. Clamate Change. Endangered
Species. Nuclear Test Ban. Ozone Layer
Protecthon. Tropical Timber 83. Wetlands
signed. but not catfied-—Desenification, Law
wt the Sea. Manne Dumping. Manne Lite
Consens ation
(,cographic note: landlocked. strategic
hacation berween China and ladia: contains
eight of world’s 10 highest peaks','b822c263fe042dd2d99e54dc250d315dd998bdf0f62049215cc9e4b252746cd8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b02847b3ebb52f315197fd2212b7bb584f1e854dfb57445d800b48dbcb3eb64',1996,'NL','Netherlands','environment',633,'NA
CMON USSMES
natural hazards: Curacao and Bonaire are
south of Canbbean hurricane belt, so are
rarely threatened: Sint Maarten. Saba, and
Sint Eustatius are subject to hurricanes trom
July to October
international agreements: party to—Whaling
(extended trom Netherlands)','81742538133863fbd2f735dcefc613aecd68c6f55adea336cf70eb7ac46f2f23','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('082ee30b3e8d82dc41eae23b288bf7833d684cf33a835a056758dd2e1ff7a3af',1996,'TK','Tokelau','environment',637,'current issues: declorestation, seal erosion
water pollution
natural hazards: destructive earthquakes
volcanoes, landslides. and occasionally
severe hurncanes
ink national agreements. patty to
Biodiversity. Climate Change. Endangered
Species. Nuctear Test Ban, Ozone Layer
Proteciion, Whaizng: signed. but not
ratified — Desertification, Environmental
Modification. Law of the Sea
current issues: very limited natural resources
and overcrowding are contnbuting to
emigration to New Zealand
natural hazards: Wes in Pacific typhoon belt
international agreements: NA
474','131eea84552aea33c68c9985821ab4cb866b04d9cf67b0e7f4e9cfb963ab4130','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3e29a121b552122c3afcaf485d4a47218cd110b69538f65f9476e4986f6bd3e',1996,'MP','Northern Mariana Islands','environment',641,'international organization participation:
licdustries
Industrial product
blectrocits
Avriculture
‘*
Exports
ai
tO)
parmners NA
imports: $392.4 million (ct. 1991 est)
mmodities: tood, construcuen equipment
ind materials. petroleum products
partners. US Japan
Eaternal debt: SNA
Economic aid: none
Currency: | United States dollar (USS
K) cents
Exchange rates: US currency ts used
Fiscal vear: | October — 30 September','b140b9e0984f0885948ff403d86ce11f19b76ff487e6d843ebd779c2da343e8a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('835098a0ec1426433069d6e1bfb54202cdd090582710775ad1199c49653f425e',1996,'NO','Norway','environment',646,'current issues: Water pollution: acid rain
damaging forests and adversely affecting
lakes, threatening fish stocks. air pollution
from vehicle emissions
natural hazards: NA
mternational agreements. party to— Au
Pollution, Au Pollution-Nitrogen Oxides. Air
Pollution-Sulphur 85. Au Pollution-Sulphur
94. Aw Pollution- Volatile Organic
Compounds, Antarciic- Environmental
Protocol, Antarctic Treaty. Brodiversity.
Climate Change. Endangered Species.
Environmental Modification, Hazardous
Wastes. Marine Dumping. Nuclear Test Ban.
Ozone Layer Protection, Ship Pollution.
Tropical Timber 83. Tropical Timber 94.
Wetlands. Whaling: signed. but aot
ratified —Desertinication, Law of the Sea
Geographic note: about two-thirds
mountains some SO.000 islands off its much
indented coastline: strategie location adjacent
to sea lanes and air routes in North Atlantic.
one of most rugged and longest coastlines in
world: Norway and Turkeys only NATO
members having a land boundary with
Russia
current sues. endangered marme species
mclude the dugong. sea lon, ca cater, seals.
turtles, and whales: of pollution im
Philippine Sea and South China Sea
natural hazards: surrounded by a sone ot
violent volcame and earthquake activity
Pacitie Ring
subject to tropical cyclones
sometimes referred to as the
aw hire
(t\\phoons) mm seutheam and cast Asia tron
May te December (most frequent trom July
to October). tropical ovclones Churnmcanes)
mas form south of Meso and strrke Central
Amernca and Meane trom June to October
(most commen om August and September)
a CheTYs
fron) Antarocteca. ox casmonal EL Nem
southerm shippeng lanes subject t
Phenmamecnen a oours off the Gaast of Peru
when the trade wrials shaken and the «arn
byguatenal Countercurrent moves south
hill.owe the Piunkion that is the proma4ry tied
source for am Pers tes vescygucntiy. tf
mhrvies hee to hetier feedmmeg ¢ ml
.ausing resem miarine herds tee stu my
the thewrsamads Pre. aus | the lew 1?
; 7 we MTR shragys . al wal : . myers "
ymecstremc meth than CA thet. \\I
mal om cA\\treTe seacth ine Miu i A teen
persisient he on the merther Pian it m ™%
i mnurtome hasan tno Jt ! Decors
hight inte sa ae PPh Firs \\V\\
(eographic mete: the major doke pounts
are the Bermne Strant. Panama C anal. |
pile
Strat, and the Sengapore Strat. the bquate
divides the Pactth Ooean wate the Neartt
Pactn Ocean and the South Pacttn Oocw
dtied with how Coral mlands and rugged
sohkounn hands on the sathwestern Pacttn
Choean','7e8b8d7faa5dd873e4c0b845b9300c6a6365b578ea7793fab2d1d689a7b44216','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dba35272531f8cce6d3c00403f95b5f99b0d58f41608e0b054bc895ffaf36191',1996,'PK','Pakistan','environment',652,'current issues: Water pollution trom raw
seWage. industrial wastes. and agricultural
ruaott: limited natural fresh water resources:
a majorty of the population does not have
adecess to potable water: deforestation. soil
erosion, desertification
natural hazards: treguent earthquakes.
occasionally severe especially in north and
west: flooding along the Indus after heavy
rains (July and August)
international agreements. party to-
Biodiversity, Climate Change. Endang2red
Species, Environmental Modification.
Hazardous Wastes. Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands:
signed. but not ratiftied— Desertification, Law
of the Sea. Marine Life Conservation
C;eographic nete: controls Khyber Pass and
Bolan Pass. traditional invasion routes
between Central Asia and the Indian
Subcoptinent
current issues: NA
natural hazards: penodic, devastating
cyclones (December to April): Piton de la
Fournaise on the southeastem coast ts an
active volcano
international agreements: NA','9447c0ca3d8e926441140dd4c85b73c67c20a2942fdd573eb6bdf9a380897c6b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd9babcbe8db0d32242060a4a697d3616f35a29bc7862d176a2791039fc19f69',1996,'PH','Philippines','environment',660,'current issues: inadequate facilities for
disposal of solid waste; threats to the marine
ecosystem from sand and coral dredging and
illegal fishing practices that involve the use
of dynamite
natural hazards: typhoons (June to
December)
international agreements: NA
Geographic note: includes World War II
battleground of Beliliou (Peleliu) and wor!d-
famous rock islands: archipelago of six
island groups totaling over 200 islands in the
Caroline chain
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: about 50 islets covered
with dense vegetation, coconut trees, and
balsa-like trees up to 30 meters tall
377
current issues: situation has improved since
1989 due to decline in heavy industry and
increased envircnmental concern by
postcommunist governments; air pollution
nonetheless remains serious because of sulfur
dioxide emissions trom coal-fired power
plants, and the resulting acid rain has caused
forest damage: water pollution trom
industrial and municipal sources ts also a
problem. as is disposal of hazardous wastes
natural hazards: NA
miernational agreements: party to—Atr
Pollution, Antarctic-Environmental Protocol.
Antarctic Treaty, Climate Change.
Endangered Species. Environmental
Modification, Hazardous Wastes. Marine
Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands,
Whaling: signed, but not ratified—A’¢
Pollution-Nitrogen Oxides. Av Pollution-
Sulphur 94, Biodiversity. Law of the Sea
Geographic nete: historically, an area of
conflict because of flai terrain and the lack
of natural barriers on the North European
Plain','5d224544d974610f131bd9cd0c87f78f8ddbf7616704784fdb05df666d023c3b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d5ebdc9b40ab59fa397b0e9c89618504e7a4004564dde718fbd6128d439cd11',1996,'PA','Panama','environment',668,'current issues: water pollution from
agricultural runctf threatens fishery
resources: deforestation of tropical rain
forest: land degradation
natural hazards: NA
international agreements: patty to—
Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes. Marine
Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollutioa, Tropical Timber
83, Wetlands: signed, but not ratified
Desertification, Law of the Sea, Marine Lite
Conservation, Tropical Timber 94
Geographic note: strategic location on
eastern end of isthmus forming land bridge
connecting North and South America:
controls Panama Canal that links Nonh
Atlantic Ocean via Caribbean Sea with North
Pacific Ocean','1a17b08b0405b3c9d0239de0df65cd28af037e08a28c6a888d27d781132558e7','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37785ae3717854b5855e0a0b7faf8ebd8ca91b1d699e5a04c6252078364adad3',1996,'PR','Puerto Rico','environment',688,'current issues: the recent drought has caused
water levels in reservoirs to drop and
prompted water rationing for more than one
half of the population
natural hazards: pervodic droughts
international agreements: NA
Geographic note: important location along
the Mona Passage—a key shipping lane to
the Panama Canal: San Juan is one of the
biggest and best natural harbors in the
Canbbean; many small nvers and high
central mountains ensure land ts well
watered; south coast relatively dry: fertle
coastal plain belt in north
current issues: substantial pollution from
Brazilian industry along border. one-fifth of
country affected by acid rain generated by
Brazil; water pollution from meat packing/
tannery industry; inadequate solid/hazardous
waste disposal
natural hazards: seasonally high winds (the
pempero ts a chilly and occasional violent
wind which blows north from the Argentine
pampas). droughts, floods: because of the
absence of mountains, which act as weather
barners, all locations are particularly
vulnerable to rapid changes in weather fronts
international agreements: party to—
Antarctic-Environmental Protocol, Antarctic
Treaty. Biodiversity, Climate Change.
Endangered Species. Environmental
Modification, Hazardous Wastes, Law of the
Sea. Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands: signed.
but not ratified—Manne Dumping. Marine
Life Conservation','83fc7f9dbdabb0f93610e2430600d71b974cbf7f4abfd49794690d252fb4484f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('625d2b6e50b193a0b53f888443dca26a3725a0a5fdd689c4825e757837283b5b',1996,'BH','Bahrain','environment',692,'current issues. limited natural tresh water
resources are increasing dependence on
large-scale desalination tacilities
haze. dust storms.
sandstorms common
natural hazards
international agreements: signed. but not
ratified —Biodiversity. Hazardous Wastes.
Law of the Sea
Geogiaphic note: strategic location in
central Persian Gulf near major petroleum
depusits','306b88aa15c9b0e557bea1cdcf59b20b72d1aee68164ff107310733f66a8ccf0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9925eb7cd5f72678bbf12067abca9f51961cc9d0afe9c9123d2504a09870e650',1996,'KN','Saint Kitts and Nevis','environment',697,'current issues: NA
natural hazards: warrnecanes Uuly to October)
international agreements: party to
Biodiversity, Climate Change. Endangered
Species. Hazardous Wastes. Law of the Sea.
Ozone Layer Protection, Whaling','f09353b7e8a75b32255f41ef56fc98d7635a3fd356b5d0f70676a51d1248757e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da3d2c242572f4744bde5a6cd9a60e7233e0a7add2dd6531fbe01f259760cd68',1996,'LC','Saint Lucia','environment',703,'current issues. detorestation: soil erosion,
particularly in the northern region
of/7
natural hazards; hurricanes and volcanic
activity
international agreements: party to—
Biodiversity, Climate Change, Endangered
Species, Environmental Modification,
Hazardous Wastes. Law of the Sea. Marine
Dumping, Ozone Layer Protection, Whaling','6c47c51631322cbd4db88c0d7b3ce372049f90d34e80e937f70e69ffc7eb255f','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c70c6b1e4c1e9909a7e24d809b7c188a1b6cc92ba4ac08836454ded0e74e00bb',1996,'PM','Saint Pierre and Miquelon','environment',710,'current issues: NA
natural hazards: persistent fog throughout
the year can be a maritime hazard
mernational agreements: NA
Geographic note: vegetation scanty
current issues: pollution of coastal waters
and shorelines from discharges by pleasure
yachts and other etfluents: in some areas
pollution is severe enough to make
swimming prohibitive
natural hazards: hurricanes. Soufriere
volcano on the island of Saint Vincent 1s a
constant threat
imernational agreements: party to—
Endangered Species. Law of the Sea, Ship
Pollution, Whaling. signed, but not ratiited—
Desertification
Geographic note: the administration of the
islands of the Grenadines group is divided
between Saint Vincent and the Grenadines
and Grenada','418704c50f25c73edaab87223e8b473c35633599652adecc6ead75fd788541e1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('add100de426da87b1e799d05fc86905e9a6fd9d9442b79883880ae8ee8866a99',1996,'SM','San Marino','environment',717,'rromt issues: NA
natural hacards: NA
mermational agreements: party to
Biodiversity, Climate Change. Nuclear Test
Ban: signed, but not ratified-—Air Pollution
Ceographic note: landlocked: smallest
independeni state in Europe after the Holy
See and Monaco: dominated by the
Apennines
414','93c1131f286344571d91fb2bc6db97cfd2de138aee0e1ed0d162321f9fc0ee8e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f302dd0ed4dd95abe994e8b97930173daed6b620069752036424f8d1a66297dc',1996,'ST','Sao Tome and Principe','environment',724,'current iwsues” detorestation, soil erosron at
exhaustion
natural hacards. NA
miernational agreements: party to
Environmental Modification. Law of the Sea
signed. but not ratifred—-Briodiversity
Climate Change. Desertification
415
voy
(continued)','cf667c141927f1026532cdd24376c0f488ccd445ab639fa3b2f852e7d459cb43','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d880219caca053885d93665c38f650cfebab8d84e0424c17e62b6ec0a281b005',1996,'SN','Senegal','environment',731,'current issaes: wildlite populations
threatened by poaching: deforestation:
overgrazing. soil erosion, desertification:
overtishing
natural hazards: lowlands seasonally
flooded: penodic droughts
international agreements, patty to—
Brodiversity. Climate Change.
Desertification, Endangered Species.
Hazardous Wastes. Law of the Sea, Marine
Lite Conservation. Nuclear Test Ban, Ozone
Layer Protection, Wetlands: signed. but nei
ratitied—Manne Dumping
(,eographic note: The Gambia ts almost an
enclave of Senegal','36c0ec87d4beccd15d7ea12a02e2940572858b384b0cacaa84ac02aaa258756a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7774a1c150fe61c0e79a1accd6b2f880e9bb9e65f24bea1bce443d8b6fe3bd17',1996,'ET','Ethiopia','environment',735,'current issues: pollution of coastal waters
trom sewage outlets, especially in tourist-
related areas such as Kotor: air pollution
around Belgrade and other industrial cities:
water pollution trom industrial wastes
dumped into the Sava which tlows into the
Danube
natural hazards. destructive earthquakes
miernational agreements: NA
Geographic note: controls one of the major
land routes from Western Europe to Turkey
and the Near East: strategic location along
the Adriatic coast
current issues: famine: use of contaminated
water contnibutes to human health problems;
deforestation: overgrazing: soil erosion:
desertification
natural hazards: recurring droughts; frequent
dust storms over eastern plains in summer
international agreements: party to—
Endangered Species, Law of the Sea; signed,
but not ratified - Marine Dumping, Nuclear
Test Ban
Geographic note: strategic location on Horn
of Africa along southern approaches to Bab
el Mandeb and route through Red Sea and
Suez Canal','1f1bbafdda7094a6f6d4e6bfe0ebee967f64c561a2fd9510924bfe424f1310e8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b7adf8098d34512b5736bdd763753f96808ab1697963744fa41b3668aaf2864',1996,'SC','Seychelles','environment',742,'current issues: no natural fresh water
resources, catchments collect ram water
natural hazards: lies outside the cyclone
belt, so severe storms are rare; short
droughts possible
international agreements: party to—
Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Whaling:
signed, but not rat!fred—Desertification
Geographic note: 40 granitic and about 50
coralline islands','19667acf2c0e36215ec7881625a549688abfa9923136577614bb94405db5154a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3078d13e8e1d289a35392cfa36c367bb5f3b67cb706c38863b6b0461332cd4c',1996,'LR','Liberia','environment',748,'current issues: rapid population growth
pressuring the environment: overharvesting
of tiraber, expansion of cattle grazing. and
slash-and-burn agriculture have resulted in
deforestation and soil exhaustion: civil war
depleting natural resources; overfishing
natural hazards: dry, sand-laden harmattan
winds blow trom the Sahara (November to
May): sandstorms, dust storms
international agreements: party to—
Biodiversity, Climate Change. Endangered
Species, Law of the Sea, Marine Lite
Conservation, Nuclear Test Ban, Whaling:
signed. but not ratified—Desertification,
Environmental Modification','77b2b78b8df36abbed642e1e2d46842241c56a48569f843ab7bc17d87e5fad30','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be91442b8c17947f891662d616b52b31f982d1c7013cc3024153f6711e7e3524',1996,'SK','Slovakia','environment',758,'current issues: ait pollution trom
other
metallurgical plants presents human health
risks: acid rain damaging forests
NA
merational agercemenis
natural hasards
party to—An
Pollution, Ai Pollutron-Nitrogen Oxides, Ait
Pollution-Sulphur 85, Antarctic Treaty
Biodiversity. Climate Change. Endangered
S39
Species, Environmental Modification.
Hazardous Wstes. Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands.
Whaling: signed, but not ratified—Atr
Pollution-Sulphur 94, Antarctic-
Environmental Protocol, Law of the Sea
Geographic note: landlocked','819b1a7d02317efcb83a93d1cb786c85e311fcd06b6c2e9118bf662e363fbca4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edd7f34d69cc522e87f525b5dbd64cbea25bb20efc09d325483459c71a0e8ebc',1996,'GN','Guinea','environment',766,'current issues: delorestation. soil erosion
much of the surrounding coral reets are dead
om dying
natural hazards: typhoons. but they are
rarely destructive, geologically active region
with trequent earth tremors: volcanic activat
miernational agreements party to
Biodiversity. Climate Change. Env iconmental
Moditication, Marine Dumping. Marine Lite
Conservation. Ozone Layer Protector
Whaling: signed. but not ratified—Lavw
the Sea','2c3bea4965e77793ac3d0b2d5bee53ac6b7115a5e84ae16a4d771b5a77d67d4b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1b311fb9147c385e377c040253f3daf9b0e12fc6ed75aa77987d4d5fb5ab340',1996,'SR','Suriname','environment',778,'current issues: detorestation as foreign
producers obtain timber concessions
natural hazards NA
imlernational agreements: patty to
Endangered Species. Marine Dumping
Nuclear Test Ban, Ship Pollution, Wetlands
Whaling: signed. but not ratified
Si0diversity., Climate Change. Law
Seu
Geographic note: mostly tropical rain
forest, great diversity of flora and fauna
which for the most part is not threatened
because of the lack of development
relatively small population most of which
lives along the coast
Curren! issues
naliutal Narardas
entrance to
X]
kort) on The
make parts of
inaccessible to mantn
filer Gina GveTceanse
Geographic note: 1
Kingdom of Norway
ie and SI
current issues: limited access to potable
water, wildlife populations being depleted
because of excessive hunting: overgrazing:
soil degradation; soil erosion
natural hazards: NA
miermational agreements: party to
Biodiversity, Nuclear Test Ban, Ozone Layer
Protection; signed, but not ratifted—Climate
Change, Desertification, Law of the Sea
Geographic note: landlocked: almost
completely surrounded by South Atnca','e4a53bcccb30a19b8d1a92a0a20d93c6f3d5846aacf30f86217ea1253a751bd5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a4f106b52e8c928ff21152cf708bef2d052392f5def692271b092e38c2fc200',1996,'CH','Switzerland','environment',785,'current issues: detorestation; overgrazing:
soil erosion; desertification; water pollution
from dumping of raw sewage and wastes
from petroleum refining: inadequate supplies
of potable water
natural hazerds: dust storms, sandstorms
international agreements: party to—
Hazardous Wastes, Nuclear Test Ban, Ozone
Layer Protection. Ship Pollution: signed, but
not ratifted—-Biodiversity. Desertification,
Environmental Modification
Geographic note: the.c are 42 Israeli
settlements and civilian land use sites in the
Israeli-occupied Golan Heights (August 1995
est.)','5889a13884e36d672d9f86ebdd9059158da76a421794115d76ce0b459dadc181','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4de22429700a19fea237ba9100410fb43293e62da32d1dc3f5af7d7491e6d57b',1996,'TJ','Tajikistan','environment',788,'current issues: inadequate sanitation
facilities; increasing levels of soil salinity;
industrial pollution; excessive pesticides; part
of the basin of the shrinking Aral Sea suffers
from severe overutilization of available water
for irrigation and associated pollution
natural hazards: NA
internationa! agreements: NA
Geographic note: iandlocked','b9511084709b05e85fdb0b8e09a3702444cda5ccbb8fffb3949269c4f4288ab8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('136211881aea3dbceb178e7f35bd32205aa06be133b8aa94fa68b9215216a1c7',1996,'TO','Tonga','environment',798,'current issues: deforestation results as more
and more land is being cleared for
agriculture and settlement; some damage to
coral reefs from starfish and indiscriminate
coral and shei! collectors. overhunting
threatens native sea turtle populations
natural hazards: cyclones (October to Apnil)
earthquakes and volcanic activity on
Fonuafo ou
mermatonal agreements: party to—Manne
Life Conservation, Nuclear Test Ban
Whaling: signed, bui not ratified—Law of
the Sea
Geographic note: archipelago of | 70 islands
(36 inhabited)
Peop!
Popula 71
Age strinwic:
0-14 years: NA
15-64 vears: NA
65 veers and over: NA
Population growth rate: 0.82% (1996 est.)
Birth rate: 27.33 births/1.000 population
(1996 est.)
Death rate: 6.26 deaths/1,000 population
(1996 est.)
Net migration rate: -!.29 migrant(s)/1.000
population (199m est.)
Sex ratio:
at birth: NA maleis\\/femaie
under 15 years. NA male(sWfemale
15.64 vears: NA male(s)/female
65 years and over: NA male(s)/female
all ages: NA male(s/female
Infant mortality rate: 40.26 deaths/! 000
live births (1996 est.)
Life expectancy at birth:
total population: 69.04 years
male: 67.03 years
female: 71.4 years (1996 est.)
Total fertility rate: 3.75 ¢ uldren born/
woman (1996 est.)
Nationality:
noun: Tongan(s)
adjective: Tongan
Ethnic divisions: Polynesian, Europeans
about 300
Rei: gions: Chrisi. > (Free Wesleyan Church
claims over 30,000 adherents)
Languages: Tongan. English
Literacy: age 15 and over can read and
write a simple message in Tongan or English
(1976 est.)
total population: \\O0%
male: 100%
female: 100%
(July 1996 est.)','5bcdbf3932ab1fcd77e6ead524895df9f9f662757f4819281dc4785b25c65cf2','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f70338be515e1ba667911d4997e222c221ce183c02e3257e89275379ee94c986',1996,'TT','Trinidad and Tobago','environment',803,'current issues: water pollution from
agricultural chemicals, industrial wastes, and
raw sewage; oil pollution of beaches;
deforestation; soil erosion
natural hazards: outside usual path of
hurricanes and other tropical storms
international agreements: party to—Climate
Change, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone
Layer Protection, Tropical Timber 83,
Wetlands, Whaling; signed, but not
ratified—Biodiversity','749263d76622d6466bac88445e520bf0811eecc798a3cf46105eac1fe5eee967','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39de0677d8e26f0206684823dee6f0106813e512f97659aeba50d087037b6a2f',1996,'BS','Bahamas','environment',809,'current issues: limited natural fresh water
resources, private cisterns collect rainwater
natural hazards: frequent hurricanes
international agreements: NA
Geographic note: 30 islands (eight
inhabited )','7fc41a4ea49ad06c5481dc0401e3c313cbb1b9a0d5bb24b225446a4de47b55e8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6467fbdb87f2f39e7685732f4db86b1b2db12faee662450f4ebc70be24650f85',1996,'TC','Turks and Caicos Islands','environment',814,'current issues: since there are no streams or
rivers and groundwater is not potable, all
water needs must be met by catchment
systems with storage facilities; beachhead
erosion because of the use of sand for
building materials; excessive clearance of
forest undergrowth for use as fuel; damage
to coral reefs from the spread of the crown
of thors starfish
natural hazards: severe tropical storms are
rare
international agreements: party to—Climate
Change. Endangered Species, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Whaling: signed. but not ratified —
Biodiversity. Law of the Sea','f7e7b6100ba2ad761f583097426d31c541360eb1bc4638813489b92a1e0f096e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6966d44269f5e1e2de098eaf90f6cdac760c13bbafa3aa707d9deeff23156ab',1996,'UG','Uganda','environment',819,'current issues: draining of wetlands for
agricultural use; deforestation: overgrazing;
soil erosion; poaching is widespread
natural hazards: NA
international agreements: party to—
Biodiversity, Climate Change, Endangered
Species, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone
Layer Protection, Wetlands: signed, but not
ratified—Desertification, Environmental
Modification
Geographic note: landlocked','3397186d37d336dda5c4f842cc7bc65f97e551b985459cc2189055096749235a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc6cbee679b9fafe3ca29209edb597fe2c3d8cad6bc50880f6504829e6acab65',1996,'UA','Ukraine','environment',826,'current issues: inadequate supplies of
potable water: air and water pollution;
deforestation; radiation contamination in the
northeast from 1986 accident at Chornobyl’
Nuclear Power Plant
natural hazards: NA
international agreements: party to—Air
Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Antarctic Treaty,
Biodiversity, Environmental Modification,
Marine Dumping. Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution; signed, but
not ratified—Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Climate Change. Law of the Sea
Geographic note: strategic position at the
crossroads between Europe and Asia:
second-largest country in Europe','c1fa69289a65309d92dd9f5aed24676cba1b2f739252f3f63d2a0d174db1bbec','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d25c8c257fa4be6df8228e9f70cac3c5544805b3940243eace10a94013a0637',1996,'OM','Oman','environment',832,'current issues: lack of natural freshwater
resources being overcome by desalination
plants: desertification; beach pollution from
oil spills
natural hazards: trequent sand and dust
storms
international agreemenis: party to—
Endangered Species. Hazardous Wastes,
Marine Dumping, Ozone Layer Protection:
signed, but not ratified—-Biodiversity, Law
of the Sea
Geographic note: strategic location along
southern approaches to Strait of Hormuz. a
vital transit point for world crude onl','dc90eed4f4d110a7ad444e681123ebb27ab8346ace9250673b2622c01ad2e915','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e6e0fbf1a5806add312d68c78471db77b13a5f31d2353b285f1b1b049f343a9',1996,'AE','United Arab Emirates','environment',838,'current issues: sulfur dioxide emissions from
power plants contribute to air pollution:
some rivers polluted by agricultural wastes
and coastal waters polluted because of large-
scale disposal of sewage at sea
natural hazards: NA
international agreements: party to—Air
Pollution. Air Pollution-Nitrogen Oxides, Air
Pollution- Volatile Organic Compounds.
Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change.
Endangered Species, Environmental
Modification, Hazardous Wastes, Marine
Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83. Wetlands,
Whaling: signed, but not ratified—Air
Pollution-Sulphur 94, Desertification
Geographic note: lies near vital North
Atlantic sea lanes; only 35 km from France
and now linked by tunnel under the English
Channel; because of heavily indented
coastline, no location is more than 125 km
from tidal waters','f373b30bee1ba9369c56e50fd786e5e4304d887217cde50d7be34f11020edca5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('818737083d681ce025aaca291c731245caaddd40b478640d7ff204d1772d44f2',1996,'US','United States','environment',842,'current issues: air pollution resulting in acid
rain in both the US and Canada; the US ts
the largest single emitter of carbon dioxide
from the burning of fossii fuels; water
pollution from runoff of pesticides and
fertilizers; very limited natural fresh water
resources in much of the western part of the
country require careful management;
desertification
natural hazards: tsunamis, voicanoes, and
earthquake activity around Pacific Basin:
hurricanes along the Atlantic coast;
tornadoes in the midwest; mud slides in
California: forest fires in the west: flooding:
permafrost in northern Alaska ts a major
impediment to development
international agreements: party to—Air
Pollution, Air Pollution-Nitrogen Oxides.
Antarctic Treaty, Climate Change.
Endangered Species. Environmental
Modification, Marine Dumping. Marine Life
Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83, Wetlands, Whaling; signed, but
not ratified—Air Pollution- Volatile Organic
Compounds, Antarctic-Environmental
Protocol, Biodiversity, Desertification,
Hazardous Wastes, Tropical Timber 94
Geographic note: world’s fourth-largest
country (after Russia, Canada, and China)
current issucs: NA
natural hazards: occasional typhoons
international agreements: NA
Geographic note: strategic location in the
North Pacific Ocean; emergency landing
location for transpacific flights
Peopie
Population: no indigenous inhabitants. there
are 302 US military and contract personnel
(July 1995 est.)
Population growth rate: 0% (1996 est.)
Birth rate: NA births/! 000 population
Death rate: NA deaths/| 000 population
Net migration rate: NA migrant(s)/!,000
population
Infant mortality rate: NA deaths/!.000 live
births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/
woman
curreni issues: deforestation (only small
portions ef the original forests remain)
largely as a result of the continued use of
wood as the main fuel source: as a
consequence of cutting down the forests, the
mountainous terrain of Futuna is particularly
prone to erosion; there are no permanent
settlements on Alofi because of the lack of
natural fresh water resources
natural hazards: NA
international agreements: NA
Geographic note: both island groups have
tringing reefs','edb090295362fc30e88673bd2334dcf10b5ae1614bebb325d893dfb87a330e00','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('118f77fc2d1863e04e88347d312763d9b1b6bada46160ec28fb18585d0209d06',1996,'UZ','Uzbekistan','environment',852,'current issues: drying up of the Aral Sea is
resulting in growing concentrations of
chemical pesticides and natural salts: these
substances are then blown irom the
505
SH
Uzbekistan (continued)
increasingly exposed lake bed and contribute
to desertification: water pollution from
industrial wastes and the heavy use of
fertilizers and pesticides is the cause of
many human health disorders; increasing soil
salinization; soil contamination from
agricultural chemicals, including DDT
natural hazards: NA
international agreements: party to—Climate
Change. Desertification, Environmental
Modification, Ozone Layer Protection:
signed, but not ratified —Biodiversity
Geographic note: landlocked','0975d02db8b2e234e832b84d8d49905bf60a08505745591ce61a847548d12dee','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1034cdeb7e3a30b6d64a52d22ac89a1e6d9a6ff59835ebeefff021e56fe56439',1996,'VU','Vanuatu','environment',859,'current issues: » majority of the population
does not have access to a potable and
reliable supply of water
natural hazards: tropical cyclones or
typhoons (January te April); volcanism
causes minor earthquakes
international agreements: party to—
Biodiversity, Climate Change, Endangered
Species, Marine Dumping, Ozone Layer
Protection, Ship Pollution; signed, but not
ratified - Desertification, Law of the Sea','6523d9582c3cdd91ee8917e535c2372ebbb7b2d1228561febee4af447121fc2a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69998ef4e54a7b20bba3cc04dd1ac86491e24b98ed06b433ef8d3b88342e6ac3',1996,'MR','Mauritania','environment',873,'current issues: sparse water and arable land
natural hazards: hot, dry, dust/sand-laden
sirocco wind can occur during winter and
spring; widespread harmattan haze exists
60% of time, often severely restricting
visibility
international agreements: NA','6242f1a4a51f4829f241664df7ff92c04e3a4194e5edf3ac173fb16c906f10ea','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('503f1dc9a7f07909572a8364757f45247a227c000360ed7b1982d4383bd33e06',1996,'YE','Yemen','environment',880,'current issues: very limited natural fresh
water resources, inadequate supplies of
potable water, overgrazing; soil erosion;
desertification
natural hazards: sandstorms and dust storms
in summer
international agreements: party to—
Environmental Modification, Law of the Sea,
Nuclear Test Ban; signed. but not ratified—
Biodiversity, Climate Change
Geographic note: controls Bab el Mandeb.
the strait linking the Red Sea and the Gulf
of Aden, one of world’s most active shipping
janes
Population: | 3.483.178 uly 1996 est.)
Age structure:
0-14 years: 48% (male 3,302,489, female
3,122,246)
15-64 vears: SO% (male 3,327,682; female
3,364,787)
65 vears and over: 2% (male 158,018;
female 207,956) (July 1996 est.)
Population growth rate: 3.56% (1996 est.)
Birth rate: 45.22 births/1,000 population
(1996 est.)
Death rate: 9.59 deaths/!,000 population
(1996 est.)
Net migration rate: 0 migrant(s)/! 000
population (1996 est.)
Sex ratio:
at birth: 1.05 maleisWfemale
under 15 years: 1.06 male(sWfemale
15-64 vears: 0.99 male(s)/female
65 vears and over: 0.76 male(sVfemale
all ages: 11 male(sWfemale (1996 est.)
Infant mortality rate: 71.5 deaths/!.000
live births (1996 est.)
Life expectancy at birth:
total population: 59.58% years
male: 58.23 years
female: 60.99 years (1996 est.)
Total fertility rate: 7.29 children born/
woman (1996 est.)
Nationality:
noun: Yemeni(s)
adjective: Yemeni
Ethnic divisions: predominantly Arab; Afro-
Arab concentrations in western coastal
locations; South Asians in southern regions;
small European communities in major
metropolitan areas
Religions: Muslim including Sha’fi (Sunni)
and Zaydi (Shi''a), small numbers of Jewish,
Christian, and Hindu
Languages: Arabic
Literacy: age 15 and over can read and
write (1990 est.)
toial popalation: 38%
male: 53%
female: 26%','7e0fcce2d3631f5413b6ffa7daa8e70f8041c1b5a9311e9ef2697521ead9ba8a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('395a3c2300e5f97b437f5e701f9f05a3b1318869efe4dd8cbddc7b07b0367b40',1996,'AO','Angola','environment',885,'current issues: poaching threatens wildlife
populations; water pollution; deforestation:
1.2 million Rwandan refugees are
responsible for significant deforestation, soil
erosion, and wildlife poaching in eastern
Zaire
natural hazards: periodic droughts in south;
volcanic activity
international agreements: patty to—-
Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea.
Marine Dumping. Nuclear Test Ban, Ozone
Layer Protection, Tropical Timber 83;
signed, but not ratified—Desertification,
Environmental Modification
Geographic note: straddles Equator. very
narrow strip of land that controls the lower
Congo river and is only outlet to South
Atlantic Ocean; dense tropical rain forest in
central river basin and eastern highlands','a97ab3ab4a5762f216af907c3bc5873078cece3f23fae9bc5ef7a912bbfc1d01','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28eba751bade92660859d983eda382be763e2c7ac79af379423295441e6f4c5c',1996,'BW','Botswana','environment',891,'current issues: deforestation; soil erosion;
land degradation; air and water pollution; the
black rhinoceros herd—once the largest
concentration of the species in the world—
has been significantly reduced by poaching
natural hazards: recurring droughts: floods
and severe storms are rare
international agreements: party to—
Biodiversity, Climate Change, Endangered
Species, Law of the Sea, Ozone Layer
Protection; signed, but not ratified—
Desertification
Geographic note: landlocked','b71fab6427ae200ece5d4d7c65dbe5347c8198593d861083b20f163ebfd55423','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a4408f864bfb49e1084029a5ab09d06d5eb3e05a4c2304b2ce5b92bfabd9a59',1996,'ZW','Zimbabwe','environment',4,'current issues: soil degradation; overgrazing; deforestation (much
of the remaining forests are being cut down for fuel and building
materials); desertification
natural hazards: damaging earthquakes occur in Hindu Kush mountains;
flooding
international agreements: party to - Endangered Species,
Environmental Modification, Marine Dumping, Nuclear Test Ban;
signed, but not ratified - Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea, Marine Life
Conservation
Geographic note: landlocked
current issues: deforestation; soil erosion; water pollution from
industrial and domestic effluents
natural hazards: destructive earthquakes; tsunami occur along
southwestern coast
international agreements: party to - Biodiversity, Climate Change
Geographic note: strategic location along Strait of Otranto (links
Adriatic Sea to Ionian Sea and Mediterranean Sea)
current issues: soil erosion from overgrazing and other poor farming
practices; desertification; dumping of raw sewage, petroleum
refining wastes, and other industrial effluents is leading to the
pollution of rivers and coastal waters; Mediterranean Sea, in
particular, becoming polluted from oil wastes, soil erosion, and
fertilizer runoff; inadequate supplies of potable water
natural hazards: mountainous areas subject to severe earthquakes;
mud slides
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Ozone Layer
Protection, Ship Pollution, Wetlands; signed, but not ratified -
Desertification, Law of the Sea, Nuclear Test Ban
Geographic note: second-largest country in Africa (after Sudan)
current issues: limited natural fresh water resources; in many areas
of the island, water supplies come from roof catchments
natural hazards: typhoons common from December to March
international agreements: NA
Geographic note: Pago Pago has one of the best natural deepwater
harbors in the South Pacific Ocean, sheltered by shape from rough
seas and protected by peripheral mountains from high winds;
strategic location in the South Pacific Ocean
current issues: deforestation; overgrazing of mountain meadows
contributes to soil erosion
natural hazards: snowslides, avalanches
international agreements: NA
Geographic note: landlocked
current issues: population pressures contributing to overuse of
pastures and subsequent soil erosion; desertification; deforestation
of tropical rain forest attributable to the international demand for
tropical timber and domestic use as a fuel; deforestation
contributing to loss of biodiversity; soil erosion contributing to
water pollution and siltation of rivers and dams; inadequate
supplies of potable water
natural hazards: locally heavy rainfall causes periodic flooding on
the plateau
international agreements: party to - Law of the Sea; signed, but not
ratified - Biodiversity, Climate Change, Desertification
Geographic note: Cabinda is separated from rest of country by Zaire
current issues: supplies of potable water sometimes cannot meet
increasing demand largely because of poor distribution system
natural hazards: frequent hurricanes and other tropical storms (July
to October)
international agreements: NA
current issues: in October 1991 it was reported that the ozone
shield, which protects the Earth''s surface from harmful ultraviolet
radiation, had dwindled to the lowest level recorded over Antarctica
since 1975 when measurements were first taken
natural hazards: katabatic (gravity-driven) winds blow coastward
from the high interior; frequent blizzards form near the foot of the
plateau; cyclonic storms form over the ocean and move clockwise
along the coast; volcanism on Deception Island and isolated areas of
West Antarctica; other seismic activity rare and weak
international agreements: NA
Geographic note: the coldest, windiest, highest, and driest
continent; during summer, more solar radiation reaches the surface
at the South Pole than is received at the Equator in an equivalent
period; mostly uninhabitable
current issues: water management - a major concern because of
limited natural fresh water resources - is further hampered by the
clearing of trees to increase crop production, causing rainfall to
run off quickly
natural hazards: hurricanes and tropical storms (July to October);
periodic droughts
international agreements: party to - Biodiversity, Climate Change,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling; signed, but not ratified - Desertification
current issues: endangered marine species include walruses and
whales; fragile ecosystem slow to change and slow to recover from
disruptions or damage
natural hazards: ice islands occasionally break away from northern
Ellesmere Island; icebergs calved from glaciers in western Greenland
and extreme northeastern Canada; permafrost in islands; virtually
icelocked from October to June; ships subject to superstructure
icing from October to May
international agreements: NA
Geographic note: major chokepoint is the southern Chukchi Sea
(northern access to the Pacific Ocean via the Bering Strait);
strategic location between North America and Russia; shortest marine
link between the extremes of eastern and western Russia, floating
research stations operated by the US and Russia; maximum snow cover
in March or April about 20 to 50 centimeters over the frozen ocean;
snow cover lasts about 10 months
current issues: erosion results from inadequate flood controls and
improper land use practices; irrigated soil degradation;
desertification; air pollution in Buenos Aires and other major
cities; water pollution in urban areas; rivers becoming polluted due
to increased pesticide and fertilizer use
natural hazards: Tucuman and Mendoza areas in the Andes subject to
earthquakes; pamperos are violent windstorms that can strike the
Pampas and northeast; heavy flooding
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands; signed, but not ratified - Desertification,
Marine Life Conservation
Geographic note: second-largest country in South America (after
Brazil); strategic location relative to sea lanes between South
Atlantic and South Pacific Oceans (Strait of Magellan, Beagle
Channel, Drake Passage)
current issues: soil pollution from toxic chemicals such as DDT;
energy blockade, the result of conflict with Azerbaijan, has led to
deforestation as citizens scavenge for firewood; pollution of
Hrazdan (Razdan) and Aras Rivers; the draining of Sevana Lich, a
result of its use as a source for hydropower, threatens drinking
water supplies; restart of Metsamor nuclear power plant without
adequate (IAEA-recommended) safety and backup systems
natural hazards: occasionally severe earthquakes; droughts
international agreements: party to - Biodiversity, Climate Change,
Nuclear Test Ban, Wetlands; signed, but not ratified -
Desertification
Geographic note: landlocked
current issues: NA
natural hazards: lies outside the Caribbean hurricane belt
international agreements: NA
current issues: NA
natural hazards: surrounded by shoals and reefs that can pose
maritime hazards
international agreements: NA
Geographic note: Ashmore Reef National Nature Reserve established
in August 1983
current issues: endangered marine species include the manatee,
seals, sea lions, turtles, and whales; drift net fishing is
hastening the decline of fish stocks and contributing to
international disputes; municipal sludge pollution off eastern US,
southern Brazil, and eastern Argentina; oil pollution in Caribbean
Sea, Gulf of Mexico, Lake Maracaibo, Mediterranean Sea, and North
Sea; industrial waste and municipal sewage pollution in Baltic Sea,
North Sea, and Mediterranean Sea
natural hazards: icebergs common in Davis Strait, Denmark Strait,
and the northwestern Atlantic Ocean from February to August and have
been spotted as far south as Bermuda and the Madeira Islands;
icebergs from Antarctica occur in the extreme southern Atlantic
Ocean; ships subject to superstructure icing in extreme northern
Atlantic from October to May and extreme southern Atlantic from May
to October; persistent fog can be a maritime hazard from May to
September
international agreements: NA
Geographic note: major choke points include the Dardanelles,
Strait of Gibraltar, access to the Panama and Suez Canals; strategic
straits include the Strait of Dover, Straits of Florida, Mona
Passage, The Sound (Oresund), and Windward Passage; the Equator
divides the Atlantic Ocean into the North Atlantic Ocean and South
======================================================================
@Australia
---------
Map
---
Location: 27 00 S, 133 00 E -- Oceania, continent between the
Indian Ocean and the South Pacific Ocean
Flag
----
Description: blue with the flag of the UK in the upper hoist-side
quadrant and a large seven-pointed star in the lower hoist-side
quadrant; the remaining half is a representation of the Southern
Cross constellation in white with one small five-pointed star and
four, larger, seven-pointed stars
current issues: soil erosion from overgrazing, industrial
development, urbanization, and poor farming practices; soil salinity
rising due to the use of poor quality water; desertification;
clearing for agricultural purposes threatens the natural habitat of
many unique animal and plant species; the Great Barrier Reef off the
northeast coast, the largest coral reef in the world, is threatened
by increased shipping and its popularity as a tourist site; limited
natural fresh water resources
natural hazards: cyclones along the coast; severe droughts
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Wetlands; signed, but not ratified - Desertification
Geographic note: world''s smallest continent but sixth-largest
country; population concentrated along the eastern and southeastern
coasts; regular, tropical, invigorating, sea breeze known as "the
Doctor" occurs along the west coast in the summer
current issues: some forest degradation caused by air and soil
pollution; soil pollution results from the use of agricultural
chemicals; air pollution results from emissions by coal- and
oil-fired power stations and industrial plants and from trucks
transiting Austria between northern and southern Europe
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Wetlands, Whaling; signed, but not ratified - Air Pollution-Sulphur
94, Antarctic-Environmental Protocol
Geographic note: landlocked; strategic location at the crossroads
of central Europe with many easily traversable Alpine passes and
valleys; major river is the Danube; population is concentrated on
eastern lowlands because of steep slopes, poor soils, and low
temperatures elsewhere
current issues: local scientists consider the Abseron (Apsheron)
Peninsula (including Baku and Sumqayit) and the Caspian Sea to be
the ecologically most devastated area in the world because of severe
air, water, and soil pollution; soil pollution results from the use
of DDT as a pesticide and also from toxic defoliants used in the
production of cotton
natural hazards: droughts; some lowland areas threatened by rising
levels of the Caspian Sea
international agreements: party to - Climate Change; signed, but not
ratified - Biodiversity
Geographic note: landlocked','aae360f37ab01898c4a6caed23c91922efe8da4430ae843c6fc6e4ef9fe499d2','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6e2d9e589ab3e0c51fe173db95711351dfb9389c28c83f911436fd64329440b',1996,'SA','Saudi Arabia','environment',14,'current issues: desertification resulting from the degradation of
limited arable land, periods of drought, and dust storms; coastal
degradation (damage to coastlines, coral reefs, and sea vegetation)
resulting from oil spills and other discharges from large tankers,
oil refineries, and distribution stations; no natural fresh water
resources so that groundwater and sea water are the only sources for
all water needs
natural hazards: periodic droughts; dust storms
international agreements: party to - Climate Change, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection; signed, but not
ratified - Biodiversity
Geographic note: close to primary Middle Eastern petroleum
sources; strategic location in Persian Gulf which much of Western
world''s petroleum must transit to reach open ocean
current issues: no natural fresh water resources
natural hazards: the narrow fringing reef surrounding the island can
be a maritime hazard
international agreements: NA
Geographic note: treeless, sparse, and scattered vegetation
consisting of grasses, prostrate vines, and low growing shrubs;
primarily a nesting, roosting, and foraging habitat for seabirds,
shorebirds, and marine wildlife
current issues: many people are landless and forced to live on and
cultivate flood-prone land; limited access to potable water;
water-borne diseases prevalent; water pollution especially of
fishing areas results from the use of commercial pesticides;
intermittent water shortages because of falling water tables in the
northern and central parts of the country; soil degradation;
deforestation; severe overpopulation
natural hazards: droughts, cyclones; much of the country routinely
flooded during the summer monsoon season
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Hazardous Wastes,
Nuclear Test Ban, Ozone Layer Protection, Wetlands; signed, but not
ratified - Desertification, Law of the Sea
current issues: pollution of coastal waters from waste disposal by
ships; soil erosion; illegal solid waste disposal threatens
contamination of aquifers
natural hazards: hurricanes (especially June to October); periodic
landslides
international agreements: party to - Climate Change, Endangered
Species, Law of the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Whaling; signed, but not ratified - Biodiversity,
Hazardous Wastes
Geographic note: easternmost Caribbean island
current issues: NA
natural hazards: maritime hazard since it is usually under water
during high tide and surrounded by reefs; subject to periodic
cyclones
international agreements: NA
current issues: soil pollution from pesticide use; southern part of
the country contaminated with fallout from 1986 nuclear reactor
accident at Chornobyl''
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Biodiversity,
Environmental Modification, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection; signed, but not ratified - Climate Change, Law of
the Sea
Geographic note: landlocked
current issues: Meuse River, a major source of drinking water,
polluted from steel production wastes; other rivers polluted by
animal wastes and fertilizers; industrial air pollution contributes
to acid rain in neighboring countries
natural hazards: flooding is a threat in areas of reclaimed coastal
land, protected from the sea by concrete dikes
international agreements: party to - Air Pollution, Air
Pollution-Sulphur 85, Antarctic Treaty, Endangered Species,
Environmental Modification, Hazardous Wastes, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands; signed, but not ratified -
Air Pollution-Nitrogen Oxides, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Biodiversity, Climate Change, Law of the Sea
Geographic note: crossroads of Western Europe; majority of West
European capitals within 1,000 km of Brussels which is the seat of
the EU
current issues: deforestation; water pollution from sewage,
industrial effluents, agricultural runoff
natural hazards: frequent, devastating hurricanes (September to
December) and coastal flooding (especially in south)
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Marine Dumping, Whaling
Geographic note: national capital moved 80 km inland from Belize
City to Belmopan because of hurricanes; only country in Central
America without a coastline on the North Pacific Ocean
current issues: recent droughts have severely affected marginal
agriculture in north; inadequate supplies of potable water; poaching
threatens wildlife populations; deforestation; desertification
natural hazards: hot, dry, dusty harmattan wind may affect north in
winter
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Nuclear Test Ban,
Ozone Layer Protection; signed, but not ratified - Desertification,
Law of the Sea
Geographic note: no natural harbors
current issues: limited natural fresh water resources are increasing
dependence on large-scale desalination facilities
natural hazards: haze, dust storms, sandstorms common
international agreements: signed, but not ratified - Biodiversity,
Hazardous Wastes, Law of the Sea
Geographic note: strategic location in central Persian Gulf near
major petroleum deposits','ad38760362b9a304547692c896ce46659a53f7259d9338684ac70372446518be','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfb8fc4177fd96e64aea37b1ff90dacf2d6f6fba552b9110739fd8b0fd6bb724',1996,'HK','Hong Kong','environment',26,'current issues: NA
natural hazards: hurricanes (June to November)
international agreements: NA
Geographic note: consists of about 360 small coral islands with
ample rainfall, but no rivers or freshwater lakes; some reclaimed
land leased by US Government','ad1d8e7f8f89d0efffb0a2b95eed7e2fe0d38910c42fba7b4f55485f2cf63114','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b25bbb9ed581d3a65880cd3153c770bb6850deb514be88d32ee865f4da2a9ba5',1996,'IN','India','environment',31,'current issues: soil erosion; limited access to potable water
natural hazards: violent storms coming down from the Himalayas are
the source of the country''s name which translates as Land of the
Thunder Dragon; frequent landslides during the rainy season
international agreements: party to - Biodiversity, Climate Change,
Nuclear Test Ban; signed, but not ratified - Law of the Sea
Geographic note: landlocked; strategic location between China and
India; controls several key Himalayan mountain passes
current issues: depletion of freshwater aquifers threatens water
supplies
natural hazards: low level of islands makes them very sensitive to
sea level rise
international agreements: party to - Biodiversity, Climate Change,
Hazardous Wastes, Ozone Layer Protection; signed, but not ratified -
Law of the Sea
Geographic note: 1,190 coral islands grouped into 26 atolls;
archipelago of strategic location astride and along major sea lanes
in Indian Ocean
current issues: deforestation; soil erosion; desertification;
inadequate supplies of potable water; poaching
natural hazards: hot, dust-laden harmattan haze common during dry
seasons; recurring droughts
international agreements: party to - Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Ozone Layer
Protection, Wetlands; signed, but not ratified - Nuclear Test Ban
Geographic note: landlocked
current issues: very limited natural fresh water resources;
increasing reliance on desalination
natural hazards: NA
international agreements: party to - Climate Change, Endangered
Species, Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling; signed, but not
ratified - Biodiversity, Desertification
Geographic note: the country comprises an archipelago, with only
the three largest islands (Malta, Gozo, and Comino) being inhabited;
numerous bays provide good harbors
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: one small islet, the Calf of Man, lies to the
southwest, and is a bird sanctuary
current issues: the almost total dependence on wood for fuel and
cutting down trees to expand agricultural land without replanting
has resulted in widespread deforestation; soil erosion; water
pollution (use of contaminated water presents human health risks)
natural hazards: severe thunderstorms, flooding, landslides,
drought, and famine depending on the timing, intensity, and duration
of the summer monsoons
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Wetlands; signed, but not ratified -
Desertification, Law of the Sea, Marine Dumping, Marine Life
Conservation
Geographic note: landlocked; strategic location between China and
India; contains eight of world''s 10 highest peaks
current issues: water pollution in the form of heavy metals, organic
compounds, and nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities; acid rain
natural hazards: the extensive system of dikes and dams, protects
nearly one-half of the total area from being flooded
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Wetlands, Whaling;
signed, but not ratified - Air Pollution-Sulphur 94, Biodiversity,
Desertification, Law of the Sea, Tropical Timber 94
Geographic note: located at mouths of three major European rivers
(Rhine, Maas or Meuse, and Schelde)
current issues: NA
natural hazards: Curacao and Bonaire are south of Caribbean
hurricane belt, so are rarely threatened; Sint Maarten, Saba, and
Sint Eustatius are subject to hurricanes from July to October
international agreements: party to - Whaling (extended from
Netherlands)','72e3b41f2c51f8d1979fcb463047d3e007b75d8e69a719fe6190781ee0f64086','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08ae887591902a47a1431c240e20fdb7b9a85e90c515bfdb7b2ecbb17fc92ced',1996,'BR','Brazil','environment',38,'current issues: the clearing of land for agricultural purposes and
the international demand for tropical timber are contributing to
deforestation; soil erosion from overgrazing and poor cultivation
methods (including slash-and-burn agriculture); desertification;
loss of biodiversity; industrial pollution of water supplies used
for drinking and irrigation
natural hazards: cold, thin air of high plateau is obstacle to
efficient fuel combustion, as well as to physical activity by those
unaccustomed to it from birth; flooding in the northeast
(March-April)
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Nuclear Test Ban, Tropical
Timber 83, Tropical Timber 94, Wetlands; signed, but not ratified -
Desertification, Environmental Modification, Hazardous Wastes,
Marine Dumping, Marine Life Conservation, Ozone Layer Protection
Geographic note: landlocked; shares control of Lago Titicaca,
world''s highest navigable lake (elevation 3,805 m), with Peru
current issues: deforestation; overgrazing of the slopes of the
costa and sierra leading to soil erosion; desertification; air
pollution in Lima; pollution of rivers and coastal waters from
municipal and mining wastes
natural hazards: earthquakes, tsunamis, flooding, landslides, mild
volcanic activity
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
Geographic note: shares control of Lago Titicaca, world''s highest
navigable lake, with Bolivia
current issues: uncontrolled deforestation in watershed areas; soil
erosion; air and water pollution in Manila; increasing pollution of
coastal mangrove swamps which are important fish breeding grounds
natural hazards: astride typhoon belt, usually affected by 15 and
struck by five to six cyclonic storms per year; landslides, active
volcanoes, destructive earthquakes, tsunamis
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Tropical Timber
83, Wetlands; signed, but not ratified - Desertification, Tropical
Timber 94
current issues: deforestation (only a small portion of the original
forest remains because of burning and clearing for settlement)
natural hazards: typhoons (especially November to March)
international agreements: NA
current issues: situation has improved since 1989 due to decline in
heavy industry and increased environmental concern by postcommunist
governments; air pollution nonetheless remains serious because of
sulfur dioxide emissions from coal-fired power plants, and the
resulting acid rain has caused forest damage; water pollution from
industrial and municipal sources is also a problem, as is disposal
of hazardous wastes
natural hazards: NA
international agreements: party to - Air Pollution,
Antarctic-Environmental Protocol, Antarctic Treaty, Climate Change,
Endangered Species, Environmental Modification, Hazardous Wastes,
Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling; signed, but not ratified - Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 94, Biodiversity,
Law of the Sea
Geographic note: historically, an area of conflict because of flat
terrain and the lack of natural barriers on the North European Plain
current issues: soil erosion; air pollution caused by industrial and
vehicle emissions; water pollution, especially in coastal areas
natural hazards: Azores subject to severe earthquakes
international agreements: party to - Air Pollution, Biodiversity,
Climate Change, Endangered Species, Hazardous Wastes, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands; signed, but not ratified -
Air Pollution-Volatile Organic Compounds, Desertification,
Environmental Modification, Law of the Sea, Nuclear Test Ban
Geographic note: Azores and Madeira Islands occupy strategic
locations along western sea approaches to Strait of Gibraltar
current issues: the recent drought has caused water levels in
reservoirs to drop and prompted water rationing for more than
one-half of the population
natural hazards: periodic droughts
international agreements: NA
Geographic note: important location along the Mona Passage - a key
shipping lane to the Panama Canal; San Juan is one of the biggest
and best natural harbors in the Caribbean; many small rivers and
high central mountains ensure land is well watered; south coast
relatively dry; fertile coastal plain belt in north','4839441bfc1f2f5cb659888ef56997c90232f09b2a225908b94a5cff56a0c0c6','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fcf3e8801fa129a2b1f4c6ed65b6e99ecf7a480849d5c34e38b7a5d3528e5a9',1996,'HR','Croatia','environment',45,'current issues: air pollution from metallurgical plants; sites for
disposing of urban waste are limited; widespread casualties, water
shortages, and destruction of infrastructure because of civil strife
natural hazards: frequent and destructive earthquakes
international agreements: party to - Air Pollution, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection
Geographic note: as of January 1996, Bosnian Serb leaders
continued to demand revisions to the territorial aspects of the
Dayton Agreement, especially in Sarajevo - designated to be under
Federation control - and the Brcko/Posavina corridor area; members
of the Bosnian Croat community also reject several territorial
aspects of the agreement, citing that historically Bosnian Croat
lands are to be transferred to Bosnian Serb control; despite
disagreements, initial implementation of the agreement as of January
1996 appeared on course with the warring parties meeting the
deadline for withdrawal of forces from the front lines in Sarajevo
current issues: overgrazing, primarily as a result of the expansion
of the cattle population; desertification; limited natural fresh
water resources
natural hazards: periodic droughts; seasonal August winds blow from
the west, carrying sand and dust across the country, which can
obscure visibility
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection; signed, but not ratified - Desertification
Geographic note: landlocked; population concentrated in eastern
part of the country
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: covered by glacial ice
current issues: deforestation in Amazon Basin destroys the habitat
and endangers the existence of a multitude of plant and animal
species indigenous to the area; air and water pollution in Rio de
Janeiro, Sao Paulo, and several other large cities; land degradation
and water pollution caused by improper mining activities
natural hazards: recurring droughts in northeast; floods and
occasional frost in south
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands, Whaling; signed, but not
ratified - Desertification
Geographic note: largest country in South America; shares common
boundaries with every South American country except Chile and Ecuador','9fa876909b6cc1d78330f1569a090dcc99067e9ba4c8ce6828522958cf5b9cf6','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('310a1dc7c8b6b7255899dd53e90ccea016900cb532965a0b5b9fa971a543374d',1996,'MU','Mauritius','environment',52,'current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: archipelago of 2,300 islands; Diego Garcia,
largest and southernmost island, occupies strategic location in
central Indian Ocean; island is site of joint US-UK military facility
current issues: limited natural fresh water resources (except for a
few seasonal streams and springs on Tortola, most of the island''s
water supply comes from wells and rainwater catchment)
natural hazards: hurricanes and tropical storms (July to October)
international agreements: NA
Geographic note: strong ties to nearby US Virgin Islands and','39f7b6b90e631a286665ec5d27d3dfae6b02f66539e9b96b071e42cde908354d','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('973c527c7c2dfb36039eb168d4dac5dbdf0ff74514b752a2fb738b640bdc50d6',1996,'MY','Malaysia','environment',65,'current issues: NA
natural hazards: typhoons, earthquakes, and severe flooding are very
rare
international agreements: party to - Endangered Species, Ozone Layer
Protection, Ship Pollution, Whaling; signed, but not ratified - Law
of the Sea
Geographic note: close to vital sea lanes through South China Sea
linking Indian and Pacific Oceans; two parts physically separated by
Malaysia; almost an enclave of Malaysia
current issues: air pollution from industrial emissions; rivers
polluted from raw sewage, heavy metals, detergents; deforestation;
forest damage from air pollution and resulting acid rain; soil
contamination from heavy metals from metallurgical plants and
industrial wastes
natural hazards: earthquakes, landslides
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Antarctic
Treaty, Climate Change, Endangered Species, Environmental
Modification, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands; signed, but not ratified - Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Biodiversity, Law of the Sea
Geographic note: strategic location near Turkish Straits; controls
key land routes from Europe to Middle East and Asia','5541893528ece9b02261f7dbc31ae3b0e51348a7439e0b14f95723642b3d2719','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26948e27161861d7b0903bdf03537dcfc57561b64ec1d8a90f9a7414d41c41fc',1996,'NE','Niger','environment',72,'current issues: recent droughts and desertification severely
affecting agricultural activities, population distribution, and the
economy; overgrazing; soil degradation; deforestation
natural hazards: recurring droughts
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Marine Life Conservation, Ozone Layer
Protection, Wetlands; signed, but not ratified - Desertification,
Law of the Sea, Nuclear Test Ban
Geographic note: landlocked
current issues: deforestation; industrial pollution of air, soil,
and water; inadequate sanitation and water treatment contribute to
disease
natural hazards: destructive earthquakes and cyclones; flooding and
landslides common during rainy season (June to September); periodic
droughts
international agreements: party to - Biodiversity, Climate Change,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83; signed, but not ratified - Law of the Sea, Tropical
Timber 94
Geographic note: strategic location near major Indian Ocean
shipping lanes
current issues: soil erosion as a result of overgrazing and the
expansion of agriculture into marginal lands; deforestation (little
forested land remains because of uncontrolled cutting of trees for
fuel); habitat loss threatens wildlife populations
natural hazards: flooding, landslides
international agreements: party to - Endangered Species; signed, but
not ratified - Biodiversity, Climate Change, Desertification, Law of
the Sea, Nuclear Test Ban
Geographic note: landlocked; straddles crest of the Nile-Congo
watershed
current issues: logging activities throughout the country and strip
mining for gems in the western region along the border with Thailand
are resulting in habitat loss and declining biodiversity (in
particular, destruction of mangrove swamps threatens natural
fisheries); deforestation; soil erosion; in rural areas, a majority
of the population does not have access to potable water
natural hazards: monsoonal rains (June to November); flooding;
occasional droughts
international agreements: party to - Marine Life Conservation, Ship
Pollution; signed, but not ratified - Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Marine Dumping,
Tropical Timber 94
Geographic note: a land of paddies and forests dominated by the
Mekong River and Tonle Sap
current issues: water-borne diseases are prevalent; deforestation;
overgrazing; desertification; poaching; overfishing
natural hazards: recent volcanic activity with release of poisonous
gases
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Ozone Layer Protection, Tropical
Timber 83; signed, but not ratified - Desertification, Nuclear Test
Ban, Tropical Timber 94
Geographic note: sometimes referred to as the hinge of Africa
current issues: air pollution and resulting acid rain severely
affecting lakes and damaging forests; metal smelting, coal-burning
utilities, and vehicle emissions impacting on agricultural and
forest productivity; ocean waters becoming contaminated due to
agricultural, industrial, mining, and forestry activities
natural hazards: continuous permafrost in north is a serious
obstacle to development; cyclonic storms form east of the Rocky
Mountains, a result of the mixing of air masses from the Arctic,
Pacific, and North American interior, and produce most of the
country''s rain and snow
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Wetlands, Whaling; signed, but not ratified -
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Law of the Sea, Tropical Timber 94
Geographic note: second-largest country in world (after Russia);
strategic location between Russia and US via north polar route;
nearly 90% of the population is concentrated within 161 km of the
US/Canada border
current issues: overgrazing of livestock and improper land use such
as the cultivation of crops on steep slopes has led to soil erosion;
demand for wood used as fuel has resulted in deforestation;
desertification; environmental damage has threatened several
indigenous species of birds and reptiles; overfishing
natural hazards: prolonged droughts; harmattan wind can obscure
visibility; volcanically and seismically active
international agreements: party to - Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of the Sea, Marine
Dumping, Nuclear Test Ban
Geographic note: strategic location 500 km from west coast of
Africa near major north-south sea routes; important communications
station; important sea and air refueling site
current issues: no natural fresh water resources, drinking water
supplies must be met by rainwater catchment
natural hazards: hurricanes (July to November)
international agreements: NA
Geographic note: important location between Cuba and Central
America
current issues: tap water is not potable; poaching has diminished
reputation as one of last great wildlife refuges; desertification
natural hazards: hot, dry, dusty harmattan winds affect northern
areas; floods are common
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Nuclear Test Ban, Ozone Layer Protection;
signed, but not ratified - Desertification, Law of the Sea
Geographic note: landlocked; almost the precise center of Africa','8b16d70020995caf30a726cc873344c146e209ae7602c63508f609471539098f','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3a5d666f5607cdd8444c29ce283cea63bd0dc04d35cbbd80ae5fed7734ad98d',1996,'NG','Nigeria','environment',85,'current issues: inadequate supplies of potable water; improper waste
disposal in rural areas contributes to soil and water pollution;
desertification
natural hazards: hot, dry, dusty harmattan winds occur in north;
periodic droughts; locust plagues
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Nuclear Test Ban, Ozone Layer Protection,
Wetlands; signed, but not ratified - Desertification, Law of the
Sea, Marine Dumping
Geographic note: landlocked; Lake Chad is the most significant
water body in the Sahel','a752b7b73a424a5c111b80ff974ee2a7ce789315c9dc08f4073abe95e2bcc825','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd8f56849a6276eb75479d9cca18122f9c2760f7aa4e0f7fcb0fd716b1babe2b',1996,'FR','France','environment',92,'current issues: air pollution from industrial and vehicle emissions;
water pollution from raw sewage; deforestation contributing to loss
of biodiversity; soil erosion; desertification
natural hazards: severe earthquakes; active volcanism; tsunamis
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands; signed, but not ratified - Desertification, Law of the Sea
Geographic note: strategic location relative to sea lanes between
Atlantic and Pacific Oceans (Strait of Magellan, Beagle Channel,
Drake Passage); Atacama Desert is one of world''s driest regions
current issues: air pollution from the overwhelming use of
high-sulfur coal as a fuel, produces acid rain which is damaging
forests; water shortages experienced throughout the country,
particularly in urban areas; future growth in water usage threatens
to outpace supplies; water pollution from industrial effluents; much
of the population does not have access to potable water; less than
10% of sewage receives treatment; deforestation; estimated loss of
one-fifth of agricultural land since 1957 to soil erosion and
economic development; desertification; trade in endangered species
natural hazards: frequent typhoons (about five per year along
southern and eastern coasts); damaging floods; tsunamis;
earthquakes; droughts
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Wetlands;
signed, but not ratified - Desertification, Law of the Sea
Geographic note: world''s third-largest country (after Russia and
Canada)','311344fff74fcb25f8914729925c694e0d2a3caee642ca87682264c86633332c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9601ad33a5261fec065746019616eec1792a4bf739e4875645a5dd044bc643e',1996,'ID','Indonesia','environment',96,'current issues: NA
natural hazards: the narrow fringing reef surrounding the island can
be a maritime hazard
international agreements: NA
Geographic note: located along major sea lanes of Indian Ocean
current issues: NA
natural hazards: typhoons (June to December)
international agreements: party to - Biodiversity, Climate Change,
Law of the Sea; signed, but not ratified - Desertification,
Hazardous Wastes, Ozone Layer Protection
Geographic note: four major island groups totaling 607 islands
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: a coral atoll; closed to the public
current issues: heavy use of agricultural chemicals, including
banned pesticides such as DDT, has contaminated soil and
groundwater; extensive soil erosion from poor farming methods
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change;
signed, but not ratified - Air Pollution
Geographic note: landlocked
current issues: NA
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Whaling; signed, but not ratified - Law
of the Sea
Geographic note: second smallest independent state in world (after
Holy See); almost entirely urban
current issues: limited natural fresh water resources; policies of
the former communist regime promoting rapid urbanization and
industrial growth have raised concerns about their negative effects
on the environment; the burning of soft coal and the concentration
of factories in Ulaanbaatar have severely polluted the air;
deforestation, overgrazing, the converting of virgin land to
agricultural production have increased soil erosion from wind and
rain; desertification
natural hazards: dust storms can occur in the spring
international agreements: party to - Biodiversity, Climate Change,
Environmental Modification, Nuclear Test Ban; signed, but not
ratified - Desertification, Law of the Sea
Geographic note: landlocked; strategic location between China and
Russia','c57fd8bea63587d938b9de12f4a18773f97ff44e817d5ec170f282e7dd47c219','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b5ad72c92fe96873346773eab80bf77e52e50373eca2e447528abbc39cd4b48',1996,'AU','Australia','environment',106,'current issues: NA
natural hazards: subject to tornadoes
international agreements: NA
Geographic note: reef about 8 km in circumference
current issues: fresh water resources are limited to rainwater
accumulations in natural underground reservoirs
natural hazards: cyclones may occur in the early months of the year
international agreements: NA
Geographic note: two coral atolls thickly covered with coconut
palms and other vegetation
current issues: deforestation; soil damage from overuse of
pesticides; air pollution, especially in Bogota, from vehicle
emissions
natural hazards: highlands subject to volcanic eruptions; occasional
earthquakes; periodic droughts
international agreements: party to - Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83; signed, but not ratified - Antarctic-Environmental
Protocol, Desertification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Tropical Timber 94
Geographic note: only South American country with coastlines on
both North Pacific Ocean and Caribbean Sea
current issues: soil degradation and erosion results from crop
cultivation on slopes without proper terracing; deforestation
natural hazards: cyclones and tsunamis possible during rainy season
(December to April); Mount Kartala on Grand Comore is an active
volcano
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection; signed, but not ratified - Desertification
Geographic note: important location at northern end of Mozambique
Channel
current issues: air pollution from vehicle emissions; water
pollution from the dumping of raw sewage; tap water is not potable;
deforestation
natural hazards: seasonal flooding
international agreements: party to - Endangered Species, Ozone Layer
Protection, Tropical Timber 83; signed, but not ratified -
Biodiversity, Climate Change, Desertification, Law of the Sea,
Tropical Timber 94
Geographic note: about 70% of the population lives in Brazzaville,
Pointe Noire, or along the railroad between them
current issues: NA
natural hazards: typhoons (November to March)
international agreements: party to - Biodiversity, Climate Change,
Law of the Sea
current issues: no permanent fresh water resources
natural hazards: occasional, tropical cyclones
international agreements: NA
Geographic note: important nesting area for birds and turtles
current issues: NA
natural hazards: occasional cyclonic storms in January
international agreements: NA
Geographic note: includes five archipelagoes; Makatea in French
Polynesia is one of the three great phosphate rock islands in the
Pacific Ocean - the others are Banaba (Ocean Island) in Kiribati and
current issues: endangered marine species include the dugong, seals,
turtles, and whales; oil pollution in the Arabian Sea, Persian Gulf,
and Red Sea
natural hazards: ships subject to superstructure icing in extreme
south near Antarctica from May to October
international agreements: NA
Geographic note: major chokepoints include Bab el Mandeb, Strait
of Hormuz, Strait of Malacca, southern access to the Suez Canal, and
the Lombok Strait
current issues: deforestation; water pollution from industrial
wastes, sewage; air pollution in urban areas
natural hazards: occasional floods, severe droughts, and tsunamis
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands; signed, but not ratified -
Desertification, Marine Life Conservation
Geographic note: archipelago of 13,500 islands (6,000 inhabited);
straddles Equator; strategic location astride or along major sea
lanes from Indian Ocean to Pacific Ocean
current issues: NA
natural hazards: typhoons most frequent from November to March
international agreements: NA
current issues: deforestation; soil erosion; native flora and fauna
hard-hit by species introduced from outside
natural hazards: earthquakes are common, though usually not severe;
volcanic activity
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Tropical Timber
83, Wetlands, Whaling; signed, but not ratified - Law of the Sea,
Marine Life Conservation, Tropical Timber 94
Geographic note: about 80% of the population lives in cities
current issues: NA
natural hazards: typhoons (especially May to July)
international agreements: NA
current issues: since there are no streams or rivers and groundwater
is not potable, all water needs must be met by catchment systems
with storage facilities; beachhead erosion because of the use of
sand for building materials; excessive clearance of forest
undergrowth for use as fuel; damage to coral reefs from the spread
of the crown of thorns starfish
natural hazards: severe tropical storms are rare
international agreements: party to - Climate Change, Endangered
Species, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Whaling; signed, but not ratified - Biodiversity, Law of the Sea
current issues: draining of wetlands for agricultural use;
deforestation; overgrazing; soil erosion; poaching is widespread
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Wetlands; signed, but not
ratified - Desertification, Environmental Modification
Geographic note: landlocked
current issues: inadequate supplies of potable water; air and water
pollution; deforestation; radiation contamination in the northeast
from 1986 accident at Chornobyl'' Nuclear Power Plant
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Antarctic
Treaty, Biodiversity, Environmental Modification, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution; signed,
but not ratified - Air Pollution-Sulphur 94, Air Pollution-Volatile
Organic Compounds, Climate Change, Law of the Sea
Geographic note: strategic position at the crossroads between
Europe and Asia; second-largest country in Europe
current issues: lack of natural freshwater resources being overcome
by desalination plants; desertification; beach pollution from oil
spills
natural hazards: frequent sand and dust storms
international agreements: party to - Endangered Species, Hazardous
Wastes, Marine Dumping, Ozone Layer Protection; signed, but not
ratified - Biodiversity, Law of the Sea
Geographic note: strategic location along southern approaches to
Strait of Hormuz, a vital transit point for world crude oil
current issues: sulfur dioxide emissions from power plants
contribute to air pollution; some rivers polluted by agricultural
wastes and coastal waters polluted because of large-scale disposal
of sewage at sea
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Wetlands, Whaling; signed, but not ratified - Air
Pollution-Sulphur 94, Desertification
Geographic note: lies near vital North Atlantic sea lanes; only 35
km from France and now linked by tunnel under the English Channel;
because of heavily indented coastline, no location is more than 125
km from tidal waters','e2fc4e9f567c4b0319a2bd144f047e2575ade03532cbc2a009715404633d32e6','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('069f9dcebc622546bd945b592e9b89a768528d88dcce80b8afb08bb16342219a',1996,'PA','Panama','environment',110,'current issues: deforestation, largely a result of the clearing of
land for cattle ranching; soil erosion
natural hazards: occasional earthquakes, hurricanes along Atlantic
coast; frequent flooding of lowlands at onset of rainy season;
active volcanoes
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Wetlands; signed, but not ratified -
Desertification, Hazardous Wastes, Marine Life Conservation
current issues: deforestation (most of the country''s forests - once
the largest in West Africa - have been cleared by the timber
industry); water pollution from sewage and industrial and
agricultural effluents
natural hazards: coast has heavy surf and no natural harbors; during
the rainy season torrential flooding is possible
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83; signed, but not ratified - Desertification
current issues: air pollution (from metallurgical plants) and
resulting acid rain is damaging the forests; coastal pollution from
industrial and domestic waste; widespread casualties and destruction
of infrastructure in border areas affected by civil strife
natural hazards: frequent and destructive earthquakes
international agreements: party to - Air Pollution, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands; signed, but not ratified - Air
Pollution-Sulphur 94, Biodiversity, Climate Change, Desertification,
Law of the Sea
Geographic note: controls most land routes from Western Europe to
Aegean Sea and Turkish Straits
current issues: pollution of Havana Bay; overhunting threatens
wildlife populations; deforestation
natural hazards: the east coast is subject to hurricanes from August
to October (in general, the country averages about one hurricane
every other year); droughts are common
international agreements: party to - Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution; signed, but not ratified -
Antarctic-Environmental Protocol, Desertification, Marine Life
Conservation
Geographic note: largest country in Caribbean
current issues: water resource problems (no natural reservoir
catchments, seasonal disparity in rainfall, and most potable
resources concentrated in the Turkish Cypriot area); water pollution
from sewage and industrial wastes; coastal degradation; loss of
wildlife habitats from urbanization
natural hazards: moderate earthquake activity
international agreements: party to - Air Pollution, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Whaling; signed, but not ratified - Biodiversity, Climate
Change
current issues: air and water pollution in areas of northwest
Bohemia and in northern Moravia around Ostrava present health risks;
acid rain damaging forests
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands; signed, but not
ratified - Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Law of the Sea
Geographic note: landlocked; strategically located astride some of
oldest and most significant land routes in Europe; Moravian Gate is
a traditional military corridor between the North European Plain and
the Danube in central Europe
current issues: air pollution, principally from vehicle emissions;
nitrogen and phosphorus pollution of the North Sea; drinking and
surface water becoming polluted from animal wastes
natural hazards: flooding is a threat in some areas of the country
(e.g., parts of Jutland, along the southern coast of the island of
Lolland) that are protected from the sea by a system of dikes
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands, Whaling; signed, but not
ratified - Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Desertification, Law of
the Sea
Geographic note: controls Danish Straits linking Baltic and North
Seas; about one-quarter of the population lives in Copenhagen
current issues: inadequate supplies of potable water; desertification
natural hazards: earthquakes; droughts; occasional cyclonic
disturbances from the Indian Ocean bring heavy rains and flash floods
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Ship Pollution; signed, but not
ratified - Desertification
Geographic note: strategic location near world''s busiest shipping
lanes and close to Arabian oilfields; terminus of rail traffic into
Ethiopia; a vast wasteland','9dc67560c56da4c6af8be667a5380437ee1962325af75f6313852c4cf8ebba62','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce54bc56925c320b7a07b78819b0596ce5e73eca5513d410ce1484c0982fb57a',1996,'TT','Trinidad and Tobago','environment',118,'current issues: NA
natural hazards: flash floods are a constant threat; destructive
hurricanes can be expected during the late summer months
international agreements: party to - Biodiversity, Climate Change,
Environmental Modification, Law of the Sea, Ozone Layer Protection,
Whaling
current issues: water shortages; soil eroding into the sea damages
coral reefs; deforestation
natural hazards: occasional hurricanes (July to October)
international agreements: party to - Endangered Species, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection; signed, but not ratified - Biodiversity, Climate Change,
Law of the Sea
Geographic note: shares island of Hispaniola with Haiti (eastern
two-thirds is the Dominican Republic, western one-third is Haiti)
current issues: deforestation; soil erosion; desertification; water
pollution
natural hazards: frequent earthquakes, landslides, volcanic
activity; periodic droughts
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
Geographic note: Cotopaxi in Andes is highest active volcano in
world
current issues: NA
natural hazards: lies on edge of hurricane belt; hurricane season
lasts from June to November
international agreements: party to - Biodiversity, Climate Change,
Law of the Sea, Ozone Layer Protection, Whaling
Geographic note: the administration of the islands of the
Grenadines group is divided between Saint Vincent and the Grenadines
and Grenada
current issues: NA
natural hazards: hurricanes (June to October); La Soufriere is an
active volcano
international agreements: NA
current issues: NA
natural hazards: hurricanes, flooding, and volcanic activity (an
average of one major natural disaster every five years)
international agreements: NA
current issues: deforestation; soil erosion, particularly in the
northern region
natural hazards: hurricanes and volcanic activity
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Whaling
current issues: NA
natural hazards: persistent fog throughout the year can be a
maritime hazard
international agreements: NA
Geographic note: vegetation scanty
current issues: pollution of coastal waters and shorelines from
discharges by pleasure yachts and other effluents; in some areas
pollution is severe enough to make swimming prohibitive
natural hazards: hurricanes; Soufriere volcano on the island of
Saint Vincent is a constant threat
international agreements: party to - Endangered Species, Law of the
Sea, Ship Pollution, Whaling; signed, but not ratified -
Desertification
Geographic note: the administration of the islands of the
Grenadines group is divided between Saint Vincent and the Grenadines
and Grenada
current issues: NA
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change,
Nuclear Test Ban; signed, but not ratified - Air Pollution
Geographic note: landlocked; smallest independent state in Europe
after the Holy See and Monaco; dominated by the Apennines','928d8c1db2b9c1859a18ec9239280efb8eca3d89ad77ebcb423b0a716070244e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ddea32024e601cdb75ce48ec8a38dff09c94d45bd66cbc0ab17fe2ca5f089b8',1996,'MX','Mexico','environment',126,'current issues: agricultural land being lost to urbanization and
windblown sands; increasing soil salinization below Aswan High Dam;
desertification; oil pollution threatening coral reefs, beaches, and
marine habitats; other water pollution from agricultural pesticides,
raw sewage, and industrial effluents; very limited natural fresh
water resources away from the Nile which is the only perennial water
source; rapid growth in population overstraining natural resources
natural hazards: periodic droughts; frequent earthquakes, flash
floods, landslides, volcanic activity; hot, driving windstorm called
khamsin occurs in spring; dust storms, sandstorms
international agreements: party to - Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Wetlands, Whaling; signed, but not ratified - Tropical Timber 94
Geographic note: controls Sinai Peninsula, only land bridge
between Africa and remainder of Eastern Hemisphere; controls Suez
Canal, shortest sea link between Indian Ocean and Mediterranean Sea;
size, and juxtaposition to Israel, establish its major role in
Middle Eastern geopolitics
current issues: deforestation; soil erosion; water pollution;
contamination of soils from disposal of toxic wastes
natural hazards: known as the Land of Volcanoes; frequent and
sometimes very destructive earthquakes and volcanic activity
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer
Protection; signed, but not ratified - Law of the Sea
Geographic note: smallest Central American country and only one
without a coastline on Caribbean Sea
current issues: tap water is not potable; desertification
natural hazards: violent windstorms
international agreements: party to - Biodiversity, Endangered
Species, Nuclear Test Ban; signed, but not ratified -
Desertification, Law of the Sea
Geographic note: insular and continental regions rather widely
separated
current issues: overgrazing, deforestation, and soil erosion
aggravated by drought are contributing to desertification; very
limited natural fresh water resources away from the Senegal which is
the only perennial river
natural hazards: hot, dry, dust/sand-laden sirocco wind blows
primarily in March and April; periodic droughts
international agreements: party to - Climate Change, Nuclear Test
Ban, Ozone Layer Protection, Wetlands; signed, but not ratified -
Biodiversity, Desertification, Law of the Sea
Geographic note: most of the population concentrated along the
Senegal River in the southern part of the country
current issues: air pollution resulting in acid rain in both the US
and Canada; the US is the largest single emitter of carbon dioxide
from the burning of fossil fuels; water pollution from runoff of
pesticides and fertilizers; very limited natural fresh water
resources in much of the western part of the country require careful
management; desertification
natural hazards: tsunamis, volcanoes, and earthquake activity around
Pacific Basin; hurricanes along the Atlantic coast; tornadoes in the
midwest; mud slides in California; forest fires in the west;
flooding; permafrost in northern Alaska is a major impediment to
development
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Antarctic Treaty, Climate Change,
Endangered Species, Environmental Modification, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Wetlands, Whaling; signed, but
not ratified - Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Biodiversity, Desertification,
Hazardous Wastes, Tropical Timber 94
Geographic note: world''s fourth-largest country (after Russia,
Canada, and China)
current issues: substantial pollution from Brazilian industry along
border; one-fifth of country affected by acid rain generated by
Brazil; water pollution from meat packing/tannery industry;
inadequate solid/hazardous waste disposal
natural hazards: seasonally high winds (the pampero is a chilly and
occasional violent wind which blows north from the Argentine
pampas), droughts, floods; because of the absence of mountains,
which act as weather barriers, all locations are particularly
vulnerable to rapid changes in weather fronts
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands; signed, but not ratified - Marine Dumping, Marine Life
Conservation
current issues: drying up of the Aral Sea is resulting in growing
concentrations of chemical pesticides and natural salts; these
substances are then blown from the increasingly exposed lake bed and
contribute to desertification; water pollution from industrial
wastes and the heavy use of fertilizers and pesticides is the cause
of many human health disorders; increasing soil salinization; soil
contamination from agricultural chemicals, including DDT
natural hazards: NA
international agreements: party to - Climate Change,
Desertification, Environmental Modification, Ozone Layer Protection;
signed, but not ratified - Biodiversity
Geographic note: landlocked','682802dffa2908d19d861d90d00afb5ac8466c3dda7acb8d78867b3707f304c7','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03c4965c0e6841d296739984a8f6548c75e864f315e71a037331da5347a8987a',1996,'CM','Cameroon','environment',138,'current issues: famine; deforestation; desertification; soil
erosion; overgrazing; loss of infrastructure from civil warfare
natural hazards: frequent droughts
international agreements: party to - Endangered Species; signed, but
not ratified - Climate Change, Desertification
Geographic note: strategic geopolitical position along world''s
busiest shipping lanes; Eritrea retained the entire coastline of
Ethiopia along the Red Sea upon de jure independence from Ethiopia
on 27 April 1993
current issues: air heavily polluted with sulfur dioxide from
oil-shale burning power plants in northeast; contamination of soil
and groundwater with petroleum products, chemicals at former Soviet
military bases
natural hazards: flooding occurs frequently in the spring
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Ship Pollution, Wetlands
current issues: deforestation; overgrazing; soil erosion;
desertification; famine
natural hazards: geologically active Great Rift Valley susceptible
to earthquakes, volcanic eruptions; frequent droughts
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Ozone Layer Protection; signed, but not ratified
- Desertification, Environmental Modification, Law of the Sea,
Nuclear Test Ban
Geographic note: landlocked - entire coastline along the Red Sea
was lost with the de jure independence of Eritrea on 27 April 1993
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: wildlife sanctuary','387567dafcd3ea64bb6315b2010b1e3ae9d2294ba83310ce06898f68d74607f9','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e4270f456f363bdb52e98fb81fcf3f2e75a21fc4e549664d71fd16bb2b776b8',1996,'AR','Argentina','environment',141,'current issues: NA
natural hazards: strong winds persist throughout the year
international agreements: NA
Geographic note: deeply indented coast provides good natural
harbors; short growing season
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: archipelago of 18 inhabited islands and a few
uninhabited islets; strategically located along important sea lanes
in northeastern Atlantic; precipitous terrain limits habitation to
small coastal lowlands
current issues: deforestation; soil erosion
natural hazards: cyclonic storms can occur from November to January
international agreements: party to - Biodiversity, Climate Change,
Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Tropical Timber 83, Tropical Timber 94, Whaling
Geographic note: includes 332 islands of which approximately 110
are inhabited
current issues: air pollution from manufacturing and power plants
contributing to acid rain; water pollution from industrial wastes,
agricultural chemicals; habitat loss threatens wildlife populations
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands, Whaling; signed, but not
ratified - Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Desertification, Law of the Sea
Geographic note: long boundary with Russia; Helsinki is
northernmost national capital on European continent; population
concentrated on small southwestern coastal plain
current issues: some forest damage from acid rain; air pollution
from industrial and vehicle emissions; water pollution from urban
wastes, agricultural runoff
natural hazards: flooding
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85,
Antarctic-Environmental Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Hazardous Wastes, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands, Whaling; signed, but not
ratified - Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Desertification, Law of the Sea
Geographic note: largest West European nation; occasional strong,
cold, dry, north-to-northwesterly wind known as mistral
current issues: NA
natural hazards: high frequency of heavy showers and severe
thunderstorms; flooding
international agreements: NA
Geographic note: mostly an unsettled wilderness
current issues: deforestation (an estimated 2 million hectares of
forest land have been lost from 1958-85); water pollution;
inadequate means for waste disposal present health risks for many
urban residents
natural hazards: local flooding in southeast (early September to
June); poorly drained plains may become boggy (early October to June)
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Ozone Layer Protection; signed,
but not ratified - Desertification, Hazardous Wastes, Nuclear Test
Ban, Wetlands
Geographic note: landlocked; lies between Argentina, Bolivia, and
current issues: NA
natural hazards: the South Sandwich Islands have prevailing weather
conditions that generally make them difficult to approach by ship;
they are also subject to active volcanism
international agreements: NA
Geographic note: the north coast of South Georgia has several
large bays, which provide good anchorage; reindeer, introduced early
in this century, live on South Georgia','c8bec48d2cb59dca1afee12907d86588445dd2e5f9c171b6687160dacf9e5900','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9dd0d0ec1911ecbb1831f09b14cd520da49209f927babfda42cbed85d6dd535',1996,'NR','Nauru','environment',153,'current issues: NA
natural hazards: Ile Amsterdam and Ile Saint-Paul are extinct
volcanoes
international agreements: NA
Geographic note: remote location in the southern Indian Ocean
current issues: deforestation; poaching
natural hazards: NA
international agreements: party to - Endangered Species, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Wetlands; signed, but not ratified -
Biodiversity, Climate Change, Law of the Sea, Tropical Timber 94
current issues: desertification
natural hazards: NA
international agreements: NA
Geographic note: there are 24 Israeli settlements and civilian
land use sites in the Gaza Strip (August 1995 est.)
current issues: air pollution, particularly in Rust''avi; heavy
pollution of Mtkvari River and the Black Sea; inadequate supplies of
potable water; soil pollution from toxic chemicals
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change,
Ship Pollution; signed, but not ratified - Desertification','818ae3fc88a4e06d6df600b630e5b56323437cff24280d094b5f3ce00fbc6967','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4640b113332576cf308ab641bc25584f74a0cdfe18bf9013570537345b230943',1996,'DK','Denmark','environment',156,'current issues: emissions from coal-burning utilities and industries
and lead emissions from vehicle exhausts (the result of continued
use of leaded fuels) contribute to air pollution; acid rain,
resulting from sulfur dioxide emissions, is damaging forests; heavy
pollution in the Baltic Sea from raw sewage and industrial effluents
from rivers in eastern Germany
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands; signed, but not ratified -
Air Pollution-Sulphur 94, Desertification, Tropical Timber 94
Geographic note: strategic location on North European Plain and
along the entrance to the Baltic Sea
current issues: recent drought in north severely affecting
agricultural activities; deforestation; overgrazing; soil erosion;
poaching and habitat destruction threatens wildlife populations;
water pollution; inadequate supplies of potable water
natural hazards: dry, dusty, harmattan winds occur from January to
March; droughts
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling; signed, but not
ratified - Desertification, Marine Life Conservation
Geographic note: Lake Volta is the world''s largest artificial
lake; northeasterly harmattan wind (January to March)
current issues: limited natural freshwater resources, so large
concrete or natural rock water catchments collect rain water
natural hazards: NA
international agreements: NA
Geographic note: strategic location on Strait of Gibraltar that
links the North Atlantic Ocean and Mediterranean Sea
current issues: NA
natural hazards: periodic cyclones
international agreements: NA
current issues: air pollution; water pollution
natural hazards: severe earthquakes
international agreements: party to - Air Pollution,
Antarctic-Environmental Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Wetlands; signed, but not ratified - Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Desertification
Geographic note: strategic location dominating the Aegean Sea and
southern approach to Turkish Straits; a peninsular country,
possessing an archipelago of about 2,000 islands','83a26930f65af791ca419e2bed80f7f5c07f06fb3f7297ae1be7e87ecec89db3','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb07d5fe90ee49e677f8755017672c87df6f3a4ba4465245321e3d56a6c23d23',1996,'CA','Canada','environment',163,'current issues: NA
natural hazards: continuous permafrost over northern two-thirds of
the island
international agreements: NA
Geographic note: dominates North Atlantic Ocean between North
America and Europe; sparse population confined to small settlements
along coast','129f5dfc26ef463e8d0dce5867b7272edea07a928721f7a779fa2d5773e736a1','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de828b06cf86634ef907e5b162b991fdd14fa90ce5f9b7584504a19f1607fbd4',1996,'PH','Philippines','environment',171,'current issues: NA
natural hazards: frequent squalls during rainy season; relatively
rare, but potentially very destructive typhoons (especially in
August)
international agreements: NA
Geographic note: largest and southernmost island in the Mariana
Islands archipelago; strategic location in western North Pacific
Ocean
current issues: deforestation; soil erosion; water pollution
natural hazards: numerous volcanoes in mountains, with frequent
violent earthquakes; Caribbean coast subject to hurricanes and other
tropical storms
international agreements: party to - Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Wetlands; signed, but not ratified -
Antarctic-Environmental Protocol, Law of the Sea
Geographic note: no natural harbors on west coast
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: large, deepwater harbor at Saint Peter Port
current issues: deforestation; inadequate supplies of potable water;
desertification; soil contamination and erosion; overfishing
natural hazards: hot, dry, dusty harmattan haze may reduce
visibility during dry season
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Ozone Layer Protection,
Wetlands; signed, but not ratified - Desertification, Hazardous
Wastes
current issues: deforestation; soil erosion; overgrazing; overfishing
natural hazards: hot, dry, dusty harmattan haze may reduce
visibility during dry season; brush fires
international agreements: party to - Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Nuclear Test
Ban, Wetlands
current issues: water pollution from sewage and agricultural and
industrial chemicals; deforestation
natural hazards: flash floods are a constant threat during rainy
seasons
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Ozone Layer Protection, Tropical
Timber 83, Whaling
current issues: extensive deforestation (much of the remaining
forested land is being cleared for agriculture and use as fuel);
soil erosion; inadequate supplies of potable water
natural hazards: lies in the middle of the hurricane belt and
subject to severe storms from June to October; occasional flooding
and earthquakes; periodic droughts
international agreements: party to - Marine Dumping, Marine Life
Conservation; signed, but not ratified - Biodiversity, Climate
Change, Desertification, Hazardous Wastes, Law of the Sea, Nuclear
Test Ban
Geographic note: shares island of Hispaniola with Dominican
Republic (western one-third is Haiti, eastern two-thirds is the
Dominican Republic)
current issues: contamination of groundwater on Saipan by raw sewage
contributes to disease
natural hazards: active volcanoes on Pagan and Agrihan; typhoons
(especially August to November)
international agreements: NA
Geographic note: strategic location in the North Pacific Ocean
current issues: water pollution; acid rain damaging forests and
adversely affecting lakes, threatening fish stocks; air pollution
from vehicle emissions
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling; signed, but not ratified - Desertification, Law
of the Sea
Geographic note: about two-thirds mountains; some 50,000 islands
off its much indented coastline; strategic location adjacent to sea
lanes and air routes in North Atlantic; one of most rugged and
longest coastlines in world; Norway and Turkey only NATO members
having a land boundary with Russia
current issues: rising soil salinity; beach pollution from oil
spills; very limited natural fresh water resources
natural hazards: summer winds often raise large sandstorms and dust
storms in interior; periodic droughts
international agreements: party to - Biodiversity, Climate Change,
Law of the Sea, Marine Dumping, Ship Pollution; signed, but not
ratified - Hazardous Wastes
Geographic note: strategic location with small foothold on
Musandam Peninsula controlling Strait of Hormuz, a vital transit
point for world crude oil
current issues: endangered marine species include the dugong, sea
lion, sea otter, seals, turtles, and whales; oil pollution in
Philippine Sea and South China Sea
natural hazards: surrounded by a zone of violent volcanic and
earthquake activity sometimes referred to as the "Pacific Ring of
Fire"; subject to tropical cyclones (typhoons) in southeast and east
Asia from May to December (most frequent from July to October);
tropical cyclones (hurricanes) may form south of Mexico and strike
Central America and Mexico from June to October (most common in
August and September); southern shipping lanes subject to icebergs
from Antarctica; occasional El Nino phenomenon occurs off the coast
of Peru, when the trade winds slacken and the warm Equatorial
Countercurrent moves south, killing the plankton that is the primary
food source for anchovies; consequently, the anchovies move to
better feeding grounds, causing resident marine birds to starve by
the thousands because of the loss of their food source; ships
subject to superstructure icing in extreme north from October to May
and in extreme south from May to October; persistent fog in the
northern Pacific can be a maritime hazard from June to December
international agreements: NA
Geographic note: the major choke points are the Bering Strait,
Panama Canal, Luzon Strait, and the Singapore Strait; the Equator
divides the Pacific Ocean into the North Pacific Ocean and the South
Pacific Ocean; dotted with low coral islands and rugged volcanic
islands in the southwestern Pacific Ocean
current issues: water pollution from raw sewage, industrial wastes,
and agricultural runoff; limited natural fresh water resources; a
majority of the population does not have access to potable water;
deforestation; soil erosion; desertification
natural hazards: frequent earthquakes, occasionally severe
especially in north and west; flooding along the Indus after heavy
rains (July and August)
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Hazardous Wastes,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands;
signed, but not ratified - Desertification, Law of the Sea, Marine
Life Conservation
Geographic note: controls Khyber Pass and Bolan Pass, traditional
invasion routes between Central Asia and the Indian Subcontinent
current issues: inadequate facilities for disposal of solid waste;
threats to the marine ecosystem from sand and coral dredging and
illegal fishing practices that involve the use of dynamite
natural hazards: typhoons (June to December)
international agreements: NA
Geographic note: includes World War II battleground of Beliliou
(Peleliu) and world-famous rock islands; archipelago of six island
groups totaling over 200 islands in the Caroline chain
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: about 50 islets covered with dense vegetation,
coconut trees, and balsa-like trees up to 30 meters tall','e3560e579e54b8488fec3095dba17b2a53bdb042762affc5d2baa118be5240f7','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9bf1e707abe8e75382e569f036635408f73860aee35c9835707331a57717b78',1996,'AQ','Antarctica','environment',180,'current issues: NA
natural hazards: Heard Island is dominated by a dormant volcano
called Big Ben
international agreements: NA
Geographic note: primarily used for research stations
current issues: NA
natural hazards: NA
international agreements: signed, but not ratified - Air Pollution,
Environmental Modification
Geographic note: urban; landlocked; enclave of Rome, Italy;
world''s smallest state; outside the Vatican City, 13 buildings in
Rome and Castel Gandolfo (the pope''s summer residence) enjoy
extraterritorial rights
current issues: urban population expanding; deforestation results
from logging and the clearing of land for agricultural purposes;
further land degradation and soil erosion hastened by uncontrolled
development and improper land use practices such as farming of
marginal lands; mining activities polluting Lago de Yojoa (the
country''s largest source of freshwater) with heavy metals as well as
several rivers and streams
natural hazards: frequent, but generally mild, earthquakes; damaging
hurricanes and floods along Caribbean coast
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Tropical Timber 83, Wetlands; signed,
but not ratified - Desertification, Tropical Timber 94
current issues: air and water pollution from rapid urbanization
natural hazards: occasional typhoons
international agreements: NA
Geographic note: more than 200 islands
current issues: no natural fresh water resources
natural hazards: the narrow fringing reef surrounding the island can
be a maritime hazard
international agreements: NA
Geographic note: almost totally covered with grasses, prostrate
vines, and low-growing shrubs; small area of trees in the center;
primarily a nesting, roosting, and foraging habitat for seabirds,
shorebirds, and marine wildlife; feral cats
current issues: an early-1996 government study identified 179 areas
that suffer from air pollution, 54 areas with polluted soil, and 32
areas with polluted underground water; the study estimated clean-up
costs at $350 million, but the 1996 government budget allocates only
about $7 million for this purpose
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands; signed, but not
ratified - Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Law of the Sea
Geographic note: landlocked; strategic location astride main land
routes between Western Europe and Balkan Peninsula as well as
between Ukraine and Mediterranean basin
current issues: water pollution from fertilizer runoff; inadequate
wastewater treatment
natural hazards: earthquakes and volcanic activity
international agreements: party to - Air Pollution, Biodiversity,
Climate Change, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands; signed, but not
ratified - Environmental Modification, Hazardous Wastes, Marine Life
Conservation
Geographic note: strategic location between Greenland and Europe;
westernmost European country; more land covered by glaciers than in
all of continental Europe
current issues: deforestation; soil erosion; overgrazing;
desertification; air pollution from industrial effluents and vehicle
emissions; water pollution from raw sewage and runoff of
agricultural pesticides; tap water is not potable throughout the
country; huge and rapidly growing population is overstraining
natural resources
natural hazards: droughts, flash floods, severe thunderstorms
common; earthquakes
international agreements: party to - Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber, Wetlands; signed, but
not ratified - Antarctic-Environmental Protocol, Desertification
Geographic note: dominates South Asian subcontinent; near
important Indian Ocean trade routes','01fc209eaec6268c63adcf88ee40e83ade3657f17bca45178ac48450196fb450','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b857cd7dbcefa6b559c87434f30c80991958e1deabd01209fdadcf68189f859',1996,'AF','Afghanistan','environment',188,'current issues: air pollution, especially in urban areas, from
vehicle emissions, refinery operations, and industrial effluents;
deforestation; overgrazing; desertification; oil pollution in the
Persian Gulf; inadequate supplies of potable water
natural hazards: periodic droughts, floods; dust storms, sandstorms;
earthquakes along the Western border
international agreements: party to - Endangered Species, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection, Wetlands; signed,
but not ratified - Biodiversity, Climate Change, Desertification,
Environmental Modification, Law of the Sea, Marine Life Conservation
current issues: government water control projects have drained most
of the inhabited marsh areas east of An Nasiriyah by drying up or
diverting the feeder streams and rivers; a once sizable population
of Shi''a Muslims, who have inhabited these areas for thousands of
years, has been displaced; furthermore, the destruction of the
natural habitat poses serious threats to the area''s wildlife
populations; inadequate supplies of potable water; development of
Tigris-Euphrates Rivers system contingent upon agreements with
upstream riparian Turkey; air and water pollution; soil degradation
(salinization) and erosion; desertification
natural hazards: dust storms, sandstorms, floods
international agreements: party to - Law of the Sea, Nuclear Test
Ban; signed, but not ratified - Environmental Modification
current issues: water pollution, especially of lakes, from
agricultural runoff
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Climate Change, Environmental
Modification, Hazardous Wastes, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Tropical Timber 83, Wetlands, Whaling;
signed, but not ratified - Air Pollution-Sulphur 94, Biodiversity,
Desertification, Endangered Species, Law of the Sea, Marine Life
Conservation
Geographic note: strategic location on major air and sea routes
between North America and northern Europe; over 40% of the
population resides within 60 miles of Dublin
current issues: limited arable land and natural fresh water
resources pose serious constraints; desertification; air pollution
from industrial and vehicle emissions; groundwater pollution from
industrial and domestic waste, chemical fertilizers, and pesticides
natural hazards: sandstorms may occur during spring and summer
international agreements: party to - Biodiversity, Endangered
Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution; signed, but not ratified - Climate Change,
Desertification, Marine Life Conservation
Geographic note: there are 202 Israeli settlements and civilian
land use sites in the West Bank, 42 in the Israeli-occupied Golan
Heights, 24 in the Gaza Strip, and 26 in East Jerusalem (August 1995
est.)
current issues: air pollution from industrial emissions such as
sulfur dioxide; coastal and inland rivers polluted from industrial
and agricultural effluents; acid rain damaging lakes; inadequate
industrial waste treatment and disposal facilities
natural hazards: regional risks include landslides, mudflows,
avalanches, earthquakes, volcanic eruptions, flooding; land
subsidence in Venice
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands, Whaling; signed, but not
ratified - Air Pollution-Sulphur 94, Desertification
Geographic note: strategic location dominating central
Mediterranean as well as southern sea and air approaches to Western
Europe
current issues: deforestation; coastal waters polluted by industrial
waste, sewage, and oil spills; damage to coral reefs; air pollution
in Kingston results from vehicle emissions
natural hazards: hurricanes (especially July to November)
international agreements: party to - Biodiversity, Climate Change,
Law of the Sea, Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Whaling
Geographic note: strategic location between Cayman Trench and
Jamaica Channel, the main sea lanes for Panama Canal
current issues: NA
natural hazards: dominated by the volcano Beerenberg; volcanic
activity resumed in 1970
international agreements: NA
Geographic note: barren volcanic island with some moss and grass
current issues: air pollution from power plant emissions results in
acid rain; acidification of lakes and reservoirs degrading water
quality and threatening aquatic life; Japan''s appetite for fish and
tropical timber is contributing to the depletion of these resources
in Asia and elsewhere
natural hazards: many dormant and some active volcanoes; about 1,500
seismic occurrences (mostly tremors) every year; tsunamis
international agreements: party to - Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands; signed, but not ratified - Antarctic-Environmental
Protocol, Desertification, Law of the Sea, Tropical Timber 94
Geographic note: strategic location in northeast Asia
current issues: no natural fresh water resources
natural hazards: the narrow fringing reef surrounding the island can
be a maritime hazard
international agreements: NA
Geographic note: sparse bunch grass, prostrate vines, and
low-growing shrubs; primarily a nesting, roosting, and foraging
habitat for seabirds, shorebirds, and marine wildlife; feral cats
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: largest and southernmost of Channel Islands;
about 30% of population concentrated in Saint Helier
current issues: no natural fresh water resources
natural hazards: NA
international agreements: NA
Geographic note: strategic location in the North Pacific Ocean;
Johnston Island and Sand Island are natural islands, which have been
expanded by coral dredging; North Island (Akau) and East Island
(Hikina) are manmade islands formed from coral dredging; closed to
the public; former nuclear weapons test site; site of Johnston Atoll
Chemical Agent Disposal System (JACADS); some low-growing vegetation
current issues: limited natural fresh water resources;
deforestation; overgrazing; soil erosion; desertification
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Wetlands; signed, but not ratified -
Desertification, Law of the Sea
current issues: NA
natural hazards: periodic cyclones
international agreements: NA
Geographic note: wildlife sanctuary
current issues: radioactive or toxic chemical sites associated with
its former defense industries and test ranges are found throughout
the country and pose health risks for humans and animals; industrial
pollution is severe in some cities; because the two main rivers
which flowed into the Aral Sea have been diverted for irrigation, it
is drying up and leaving behind a harmful layer of chemical
pesticides and natural salts; these substances are then picked up by
the wind and blown into noxious dust storms; pollution in the
Caspian Sea; soil pollution from overuse of agricultural chemicals
and salinization from faulty irrigation practices
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change,
Ship Pollution; signed, but not ratified - Desertification
Geographic note: landlocked
current issues: water pollution from urban and industrial wastes;
degradation of water quality from increased use of pesticides and
fertilizers; deforestation; soil erosion; desertification; poaching
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands; signed, but not ratified - Desertification
Geographic note: the Kenyan Highlands comprise one of the most
successful agricultural production regions in Africa; glaciers on
Mt. Kenya; unique physiography supports abundant and varied wildlife
of scientific and economic value
current issues: NA
natural hazards: wet or awash most of the time, maximum elevation of
about 1 meter makes Kingman Reef a maritime hazard
international agreements: NA
Geographic note: barren coral atoll with deep interior lagoon;
closed to the public
current issues: heavy pollution in lagoon of south Tarawa atoll due
to heavy migration mixed with traditional practices such as lagoon
latrines and open-pit dumping; ground water at risk
natural hazards: typhoons can occur any time, but usually November
to March; occasional tornadoes
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Marine Dumping, Ozone Layer Protection, Whaling
Geographic note: 20 of the 33 islands are inhabited; Banaba (Ocean
Island) in Kiribati is one of the three great phosphate rock islands
in the Pacific Ocean - the others are Makatea in French Polynesia
and Nauru
current issues: localized air pollution attributable to inadequate
industrial controls; water pollution; inadequate supplies of potable
water
natural hazards: late spring droughts often followed by severe
flooding; occasional typhoons during the early fall
international agreements: party to - Antarctic Treaty, Biodiversity,
Climate Change, Environmental Modification, Ship Pollution; signed,
but not ratified - Antarctic-Environmental Protocol, Law of the Sea,
Ozone Layer Protection
Geographic note: strategic location bordering China, South Korea,
and Russia; mountainous interior is isolated, nearly inaccessible,
and sparsely populated
current issues: air pollution in large cities; water pollution from
the discharge of sewage and industrial effluents; drift net fishing
natural hazards: occasional typhoons bring high winds and floods;
earthquakes in southwest
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94; signed, but not ratified - Desertification, Law
of the Sea
current issues: limited natural fresh water resources; some of
world''s largest and most sophisticated desalination facilities
provide much of the water; air and water pollution; desertification
natural hazards: sudden cloudbursts are common from October to
April, they bring inordinate amounts of rain which can damage roads
and houses; sandstorms and dust storms occur throughout the year,
but are most common between March and August
international agreements: party to - Climate Change, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection; signed, but not ratified - Biodiversity,
Desertification, Endangered Species, Marine Dumping
Geographic note: strategic location at head of Persian Gulf
current issues: water pollution; many people get their water
directly from contaminated streams and wells; as a result,
water-borne diseases are prevalent; increasing soil salinity from
faulty irrigation practices
natural hazards: NA
international agreements: NA
Geographic note: landlocked','8b1c6cb8064ac8b92d1382237c21627a1578f530c7e76501fa2e20d4f62958ad','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4080b8009391fec5029b8f3680678184b5dbb67dc37f9b3a43ecba8a9fd66b91',1996,'TH','Thailand','environment',203,'current issues: deforestation; soil erosion; a majority of the
population does not have access to potable water
natural hazards: floods, droughts, and blight
international agreements: party to - Environmental Modification,
Nuclear Test Ban; signed, but not ratified - Climate Change,
Desertification, Law of the Sea
Geographic note: landlocked
current issues: air and water pollution because of a lack of waste
conversion equipment; Gulf of Riga and Daugava River heavily
polluted; contamination of soil and groundwater with chemicals and
petroleum products at military bases
natural hazards: NA
international agreements: party to - Air Pollution, Biodiversity,
Climate Change, Hazardous Wastes, Ship Pollution, Whaling; signed,
but not ratified - Ozone Layer Protection
current issues: deforestation; soil erosion; desertification; air
pollution in Beirut from vehicular traffic and the burning of
industrial wastes; pollution of coastal waters from raw sewage and
oil spills
natural hazards: dust storms, sandstorms
international agreements: party to - Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution; signed, but not ratified -
Desertification, Environmental Modification, Marine Dumping, Marine
Life Conservation
Geographic note: Nahr al Litani only major river in Near East not
crossing an international boundary; rugged terrain historically
helped isolate, protect, and develop numerous factional groups based
on religion, clan, and ethnicity
current issues: population pressure forcing settlement in marginal
areas results in overgrazing, severe soil erosion, soil exhaustion;
desertification; Highlands Water Project will control, store, and
redirect water to South Africa
natural hazards: periodic droughts
international agreements: party to - Biodiversity, Climate Change,
Desertification, Marine Life Conservation, Ozone Layer Protection,
Wetlands; signed, but not ratified - Endangered Species, Law of the
Sea, Marine Dumping
Geographic note: landlocked; surrounded by South Africa','b2ffedbb3ada5c0989b11e7c6d3ea712d14478fb98fbe343005409f7cfe3fc0c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10060451b0e8dc6d6752a27ee2900922a597083676d38d88e778fb42622eff64',1996,'ZA','South Africa','environment',212,'current issues: tropical rain forest subject to deforestation; soil
erosion; loss of biodiversity; pollution of rivers from the dumping
of iron ore tailings and of coastal waters from oil residue and raw
sewage
natural hazards: dust-laden harmattan winds blow from the Sahara
(December to March)
international agreements: party to - Endangered Species, Nuclear
Test Ban, Ship Pollution, Tropical Timber 83, Tropical Timber 94;
signed, but not ratified - Biodiversity, Climate Change,
Environmental Modification, Law of the Sea, Marine Dumping, Marine
Life Conservation
current issues: desertification; very limited natural fresh water
resources; the Great Manmade River Project, the largest water
development scheme in the world, is being built to bring water from
large aquifers under the Sahara to coastal cities
natural hazards: hot, dry, dust-laden ghibli is a southern wind
lasting one to four days in spring and fall; dust storms, sandstorms
international agreements: party to - Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection; signed, but not ratified -
Biodiversity, Climate Change, Desertification, Law of the Sea','f484b188630caeab7acd5ac3aee2be5d7e1c50149f0234de0421ce82cd3d4cd3','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2cde13a6fef27f5757734bb670116998809ea2409d33e0564d093e466178f69',1996,'CH','Switzerland','environment',217,'current issues: NA
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Volatile Organic Compounds, Climate Change, Endangered
Species, Hazardous Wastes, Ozone Layer Protection, Wetlands; signed,
but not ratified - Air Pollution-Sulphur 94, Biodiversity, Law of
the Sea
Geographic note: landlocked; variety of microclimatic variations
based on elevation
current issues: contamination of soil and groundwater with petroleum
products and chemicals at military bases
natural hazards: NA
international agreements: party to - Climate Change, Ship Pollution,
Wetlands; signed, but not ratified - Biodiversity, Ozone Layer
Protection','c14ab2e2f4ae4dde4b1a95f29344072fddb5721738e238d8951ed351babbf03b','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea95a1055f7af0e1c4f0eb939cf729be3d4bd2105890f60adc442ce424b967b9',1996,'DE','Germany','environment',223,'current issues: deforestation; air and water pollution in urban areas
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Volatile Organic Compounds, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83;
signed, but not ratified - Air Pollution-Sulphur 94,
Desertification, Environmental Modification, Law of the Sea
Geographic note: landlocked
current issues: NA
natural hazards: NA
international agreements: party to - Ozone Layer Protection
(extended from Portugal)
Geographic note: essentially urban; one causeway and one bridge
connect the two islands to the peninsula on mainland
current issues: air pollution from metallurgical plants
natural hazards: high seismic risks
international agreements: party to - Law of the Sea, Ozone Layer
Protection
Geographic note: landlocked; major transportation corridor from
Western and Central Europe to Aegean Sea and Southern Europe to
Western Europe','59d4dfb9cc1ec049a200e861efd72b3234864af44bff0e4dc42499e22d40cfa6','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a52d11a002b6c516b650ac996c8f10131cff993590fa33d104c3da3766271f7',1996,'MZ','Mozambique','environment',230,'current issues: soil erosion results from deforestation and
overgrazing; desertification; surface water contaminated with raw
sewage and other organic wastes; several species of flora and fauna
unique to the island are endangered
natural hazards: periodic cyclones
international agreements: party to - Endangered Species, Marine Life
Conservation, Nuclear Test Ban; signed, but not ratified -
Biodiversity, Climate Change, Desertification, Law of the Sea
Geographic note: world''s fourth-largest island; strategic location
along Mozambique Channel
current issues: deforestation; land degradation; water pollution
from agricultural runoff, sewage, industrial wastes; siltation of
spawning grounds endangers fish populations
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Hazardous Wastes,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection;
signed, but not ratified - Desertification, Law of the Sea
Geographic note: landlocked
current issues: air pollution from industrial and vehicular
emissions; water pollution from raw sewage; deforestation
natural hazards: flooding
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Tropical Timber 83,
Tropical Timber 94, Whaling; signed, but not ratified -
Desertification, Law of the Sea
Geographic note: strategic location along Strait of Malacca and
southern South China Sea','856c3bc6e5dcfbece6cfa8c83b41fe3ca43c97f52955ae849f2a14660acf38e4','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d911e6f64dddb176a40679d9e6ae1c1e410d361d8accae0afd786e6691a39c6',1996,'PG','Papua New Guinea','environment',238,'current issues: inadequate supplies of potable water
natural hazards: occasional typhoons
international agreements: party to - Biodiversity, Climate Change,
Law of the Sea, Ozone Layer Protection, Ship Pollution
Geographic note: two archipelagic island chains of 30 atolls and
1,152 islands; Bikini and Enewetak are former US nuclear test sites;
Kwajalein, the famous World War II battleground, is now used as a US
missile test range','0d0ddd05c30da428dbd3562e4feb49a4873e0e4c741f7fdfb9a60ed55650f15e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9291906d55c902c757e52f7208f842c0cc9047dfba016e88a470f763aa03cc8',1996,'MG','Madagascar','environment',244,'current issues: water pollution
natural hazards: cyclones (November to April); almost completely
surrounded by reefs that may pose maritime hazards
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Whaling; signed, but not ratified - Desertification
current issues: NA
natural hazards: cyclones during rainy season
international agreements: NA
Geographic note: part of Comoro Archipelago
current issues: natural fresh water resources scarce and polluted in
north, inaccessible and poor quality in center and extreme
southeast; raw sewage and industrial effluents polluting rivers in
urban areas; deforestation; widespread erosion; desertification;
serious air pollution in the national capital and urban centers
along US-Mexico border
natural hazards: tsunamis along the Pacific coast, destructive
earthquakes in the center and south, and hurricanes on the Gulf and
Caribbean coasts
international agreements: party to - Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
Geographic note: strategic location on southern border of US
current issues: NA
natural hazards: periodic, devastating cyclones (December to April);
Piton de la Fournaise on the southeastern coast is an active volcano
international agreements: NA
current issues: soil erosion and degradation; water pollution; air
pollution in south from industrial effluents; contamination of
Danube delta wetlands
natural hazards: earthquakes most severe in south and southwest;
geologic structure and climate promote landslides
international agreements: party to - Air Pollution, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands; signed, but not
ratified - Antarctic-Environmental Protocol, Law of the Sea
Geographic note: controls most easily traversable land route
between the Balkans, Moldova, and Ukraine
current issues: air pollution from heavy industry, emissions of
coal-fired electric plants, and transportation in major cities;
industrial and agricultural pollution of inland waterways and sea
coasts; deforestation; soil erosion; soil contamination from
improper application of agricultural chemicals; scattered areas of
sometimes intense radioactive contamination
natural hazards: permafrost over much of Siberia is a major
impediment to development; volcanic activity in the Kuril Islands;
volcanoes and earthquakes on the Kamchatka Peninsula
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Wetlands; signed, but not ratified - Air
Pollution-Sulphur 94, Antarctic-Environmental Protocol, Law of the
Sea
Geographic note: largest country in the world in terms of area but
unfavorably located in relation to major sea lanes of the world;
despite its size, much of the country lacks proper soils and
climates (either too cold or too dry) for agriculture
current issues: deforestation results from uncontrolled cutting of
trees for fuel; overgrazing; soil exhaustion; soil erosion
natural hazards: periodic droughts; the volcanic Virunga mountains
are in the northwest along the border with Zaire
international agreements: party to - Endangered Species, Nuclear
Test Ban; signed, but not ratified - Biodiversity, Climate Change,
Desertification, Law of the Sea
Geographic note: landlocked; predominantly rural population
current issues: NA
natural hazards: active volcanism on Tristan da Cunha
international agreements: NA
Geographic note: Napoleon Bonaparte''s place of exile and burial
(his remains were taken to Paris in 1840); harbors at least 40
species of plants unknown anywhere else in the world; Ascension is a
breeding ground for sea turtles and sooty terns
current issues: NA
natural hazards: hurricanes (July to October)
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Whaling','a8a21e134793d528502eece04f03858ca0dcd5506d47292b431de64a1b1700f8','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c9d3038117aaac52feed3de818026d118cfe5f001a8e9b0b4bb038377294afb',1996,'PR','Puerto Rico','environment',255,'current issues: land erosion occurs on slopes that have been cleared
for cultivation
natural hazards: severe hurricanes (June to November); volcanic
eruptions (there are seven active volcanoes on the island)
international agreements: NA','b5aec0c71750031dacb622bd60a5c5c4df16f78a40cc4516b5128f71da8dc6bd','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c11391c83ee704c943a4cd7be5640e070c359bc0eae22732e0791730fed3c90',1996,'EH','Western Sahara','environment',258,'current issues: land degradation/desertification (soil erosion
resulting from farming of marginal areas, overgrazing, destruction
of vegetation); water supplies contaminated by raw sewage; siltation
of reservoirs; oil pollution of coastal waters
natural hazards: northern mountains geologically unstable and
subject to earthquakes; periodic droughts
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands;
signed, but not ratified - Desertification, Environmental
Modification, Law of the Sea
Geographic note: strategic location along Strait of Gibraltar
current issues: civil strife and recurrent drought in the
hinterlands have resulted in increased migration to urban and
coastal areas with adverse environmental consequences;
desertification; pollution of surface and coastal waters
natural hazards: severe droughts and floods occur in central and
southern provinces; devastating cyclones
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Ozone Layer Protection; signed, but not ratified
- Desertification, Law of the Sea
current issues: very limited natural fresh water resources;
desertification
natural hazards: prolonged periods of drought
international agreements: party to - Climate Change, Endangered
Species, Law of the Sea, Ozone Layer Protection; signed, but not
ratified - Biodiversity, Desertification, Hazardous Wastes','1cd3a7961ef7cf0adffdb466245302ab08e72a290d3186dbb8e87f4ca6d46483','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4964dfbc3bdc482fe21cab30bd5476a45811a841f9f06155ea50e6faad4f6fe',1996,'MH','Marshall Islands','environment',264,'current issues: limited natural fresh water resources, roof storage
tanks collect rainwater; phosphate mining threatens limited
remaining land resources
natural hazards: periodic droughts
international agreements: party to - Biodiversity, Climate Change,
Marine Dumping; signed, but not ratified - Law of the Sea
Geographic note: Nauru is one of the three great phosphate rock
islands in the Pacific Ocean - the others are Banaba (Ocean Island)
in Kiribati and Makatea in French Polynesia; only 53 km south of
Equator
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: strategic location 160 km south of the US Naval
Base at Guantanamo Bay, Cuba; mostly exposed rock, but enough
grassland to support goat herds; dense stands of fig-like trees,
scattered cactus','d727e1b1e7bcc3bb26c1ff4317888b631061c54ef84d7a1b6262ad82ac6c3e07','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab276debf1dd1771a495d47d7dce5d290162e9e0037163b544ddcfa25b5fd1ef',1996,'HN','Honduras','environment',272,'current issues: deforestation; soil erosion; water pollution
natural hazards: destructive earthquakes, volcanoes, landslides, and
occasionally severe hurricanes
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Nuclear Test Ban, Ozone Layer Protection,
Whaling; signed, but not ratified - Desertification, Environmental
Modification, Law of the Sea
current issues: overgrazing; soil erosion; deforestation;
desertification; wildlife populations (such as elephant,
hippopotamus, and lion) threatened because of poaching and habitat
destruction
natural hazards: recurring droughts
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Nuclear Test Ban,
Ozone Layer Protection, Wetlands; signed, but not ratified -
Desertification, Law of the Sea
Geographic note: landlocked
current issues: soil degradation; rapid deforestation;
desertification; recent droughts in north severely affecting
marginal agricultural activities
natural hazards: periodic droughts
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Whaling; signed, but not ratified - Desertification
current issues: traditional methods of burning brush and trees to
clear land for agriculture have threatened soil supplies which are
not naturally very abundant
natural hazards: typhoons
international agreements: signed, but not ratified - Law of the Sea
Geographic note: one of world''s largest coral islands','17b2203adb6e73dcb3223cac70e880918e2267459544ed96e0f22e539dadb675','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('531afd64b3b7712ad65a41555e9c78f6e1acc3ce9b31256188c619aa40ef26a6',1996,'CR','Costa Rica','environment',279,'current issues: water pollution from agricultural runoff threatens
fishery resources; deforestation of tropical rain forest; land
degradation
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Wetlands; signed, but not ratified - Desertification, Law of the
Sea, Marine Life Conservation, Tropical Timber 94
Geographic note: strategic location on eastern end of isthmus
forming land bridge connecting North and South America; controls
Panama Canal that links North Atlantic Ocean via Caribbean Sea with
North Pacific Ocean
current issues: rain forest subject to deforestation as a result of
growing commercial demand for tropical timber; pollution from mining
projects
natural hazards: active volcanism; situated along the Pacific "Rim
of Fire"; the country is subject to frequent and sometimes severe
earthquakes; mud slides
international agreements: party to - Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands; signed, but not ratified -
Hazardous Wastes, Law of the Sea, Tropical Timber 94
Geographic note: shares island of New Guinea with Indonesia; one
of world''s largest swamps along southwest coast
current issues: NA
natural hazards: typhoons
international agreements: NA','69832902e4fb63f815f3ac6a786fea8e256522747ceb19b6e56a87c5f2ce64de','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('351f0e3aefd3797e322d8410b0a21f1218b7b39667533cc3e5a87b82444f10b4',1996,'ET','Ethiopia','environment',285,'current issues: deforestation; soil erosion and exhaustion
natural hazards: NA
international agreements: party to - Environmental Modification, Law
of the Sea; signed, but not ratified - Biodiversity, Climate Change,
Desertification
current issues: desertification; depletion of underground water
resources; the lack of perennial rivers or permanent water bodies
has prompted the development of extensive seawater desalination
facilities; coastal pollution from oil spills
natural hazards: frequent sand and dust storms
international agreements: party to - Climate Change, Hazardous
Wastes, Ozone Layer Protection; signed, but not ratified - Law of
the Sea
Geographic note: extensive coastlines on Persian Gulf and Red Sea
provide great leverage on shipping (especially crude oil) through
Persian Gulf and Suez Canal
current issues: wildlife populations threatened by poaching;
deforestation; overgrazing; soil erosion; desertification;
overfishing
natural hazards: lowlands seasonally flooded; periodic droughts
international agreements: party to - Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Wetlands; signed, but not ratified - Marine Dumping
Geographic note: The Gambia is almost an enclave of Senegal
current issues: pollution of coastal waters from sewage outlets,
especially in tourist-related areas such as Kotor; air pollution
around Belgrade and other industrial cities; water pollution from
industrial wastes dumped into the Sava which flows into the Danube
natural hazards: destructive earthquakes
international agreements: NA
Geographic note: controls one of the major land routes from
Western Europe to Turkey and the Near East; strategic location along
the Adriatic coast
current issues: no natural fresh water resources, catchments collect
rain water
natural hazards: lies outside the cyclone belt, so severe storms are
rare; short droughts possible
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling; signed, but not ratified - Desertification
Geographic note: 40 granitic and about 50 coralline islands
current issues: rapid population growth pressuring the environment;
overharvesting of timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in deforestation and soil
exhaustion; civil war depleting natural resources; overfishing
natural hazards: dry, sand-laden harmattan winds blow from the
Sahara (November to May); sandstorms, dust storms
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Whaling; signed, but not ratified -
Desertification, Environmental Modification
current issues: industrial pollution; limited natural fresh water
resources; limited land availability presents waste disposal problems
natural hazards: NA
international agreements: party to - Biodiversity, Endangered
Species, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution; signed, but not ratified - Climate Change
Geographic note: focal point for Southeast Asian sea routes
current issues: air pollution from metallurgical plants presents
human health risks; acid rain damaging forests
natural hazards: NA
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands, Whaling; signed,
but not ratified - Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Law of the Sea
Geographic note: landlocked
current issues: Sava River polluted with domestic and industrial
waste; pollution of coastal waters with heavy metals and toxic
chemicals; forest damage near Koper from air pollution (originating
at metallurgical and chemical plants) and resulting acid rain
natural hazards: flooding and earthquakes
international agreements: party to - Air Pollution, Climate Change,
Hazardous Wastes, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands; signed, but not ratified - Air
Pollution-Sulphur 94, Biodiversity, Law of the Sea
current issues: deforestation; soil erosion; much of the surrounding
coral reefs are dead or dying
natural hazards: typhoons, but they are rarely destructive;
geologically active region with frequent earth tremors; volcanic
activity
international agreements: party to - Biodiversity, Climate Change,
Environmental Modification, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Whaling; signed, but not
ratified - Law of the Sea
current issues: famine; use of contaminated water contributes to
human health problems; deforestation; overgrazing; soil erosion;
desertification
natural hazards: recurring droughts; frequent dust storms over
eastern plains in summer
international agreements: party to - Endangered Species, Law of the
Sea; signed, but not ratified - Marine Dumping, Nuclear Test Ban
Geographic note: strategic location on Horn of Africa along
southern approaches to Bab el Mandeb and route through Red Sea and
Suez Canal
current issues: lack of important arterial rivers or lakes requires
extensive water conservation and control measures; growth in water
usage threatens to outpace supply; pollution of rivers from
agricultural runoff and urban discharge; air pollution resulting in
acid rain; soil erosion; desertification
natural hazards: prolonged droughts
international agreements: party to - Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Endangered Species,
Hazardous Wastes, Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling;
signed, but not ratified - Climate Change, Desertification, Law of
the Sea
Geographic note: South Africa completely surrounds Lesotho and
almost completely surrounds Swaziland
current issues: air pollution and resulting acid rain in the mineral
extraction and refining region; poaching seriously threatens
rhinoceros and elephant populations; deforestation; soil erosion;
desertification; lack of adequate water treatment presents human
health risks
natural hazards: tropical storms (November to April)
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Wetlands; signed, but not ratified -
Desertification
Geographic note: landlocked','fab8985160d2a6dd009441f6765c7858f0be3ca60743e318fe49d000ddc948ea','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('940caa7f06b6956f18ed97e2a1fbd23f9fc4aad1bc34b2c7a7543367800465ab',1996,'GI','Gibraltar','environment',294,'current issues: pollution of the Mediterranean Sea from raw sewage
and effluents from the offshore production of oil and gas; air
pollution; deforestation; desertification
natural hazards: periodic droughts
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Wetlands, Whaling; signed, but not ratified - Air
Pollution-Sulphur 94, Desertification, Law of the Sea
Geographic note: strategic location along approaches to Strait of
current issues: NA
natural hazards: typhoons; serious maritime hazard because of
numerous reefs and shoals
international agreements: NA
Geographic note: strategically located near several primary
shipping lanes in the central South China Sea; includes numerous
small islands, atolls, shoals, and coral reefs
current issues: deforestation; soil erosion; wildlife populations
threatened by poaching; coastal degradation from mining activities
and increased pollution; freshwater resources being polluted by
industrial wastes and sewage runoff
natural hazards: occasional cyclones and tornadoes
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands,
Whaling; signed, but not ratified - Marine Life Conservation
Geographic note: strategic location near major Indian Ocean sea
lanes
current issues: inadequate supplies of potable water; wildlife
populations threatened by excessive hunting; soil erosion;
desertification
natural hazards: dust storms
international agreements: party to - Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Whaling
Geographic note: largest country in Africa; dominated by the Nile
and its tributaries
current issues: deforestation as foreign producers obtain timber
concessions
natural hazards: NA
international agreements: party to - Endangered Species, Marine
Dumping, Nuclear Test Ban, Ship Pollution, Wetlands, Whaling;
signed, but not ratified - Biodiversity, Climate Change, Law of the
Sea
Geographic note: mostly tropical rain forest; great diversity of
flora and fauna which for the most part is not threatened because of
the lack of development; relatively small population most of which
lives along the coast
current issues: NA
natural hazards: ice floes often block up the entrance to Bellsund
(a transit point for coal export) on the west coast and occasionally
make parts of the northeastern coast inaccessible to maritime traffic
international agreements: NA
Geographic note: northernmost part of the Kingdom of Norway;
consists of nine main islands; glaciers and snowfields cover 60% of
the total area
current issues: limited access to potable water; wildlife
populations being depleted because of excessive hunting;
overgrazing; soil degradation; soil erosion
natural hazards: NA
international agreements: party to - Biodiversity, Nuclear Test Ban,
Ozone Layer Protection; signed, but not ratified - Climate Change,
Desertification, Law of the Sea
Geographic note: landlocked; almost completely surrounded by South
Africa','482ad7034b5b58bae3b1d6e20fcffe834473ad294a0b6ad767c8454385484be4','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a4bf4d337beffeb3f470d65f11ea0b27e5381309b85d7bc35cba5da057f2e59',1996,'NO','Norway','environment',302,'current issues: acid rain damaging soils and lakes; pollution of the
North Sea and the Baltic Sea
natural hazards: ice floes in the surrounding waters, especially in
the Gulf of Bothnia, can interfere with maritime traffic
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Wetlands; signed, but not ratified - Law of the Sea
Geographic note: strategic location along Danish Straits linking
Baltic and North Seas
current issues: air pollution from vehicle emissions and open-air
burning; acid rain; water pollution from increased use of
agricultural fertilizers; loss of biodiversity
natural hazards: avalanches, landslides, flash floods
international agreements: party to - Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands, Whaling; signed, but not
ratified - Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Desertification, Law of the Sea, Tropical Timber 94
Geographic note: landlocked; crossroads of northern and southern
Europe; along with southeastern France and northern Italy, contains
the highest elevations in Europe
current issues: deforestation; overgrazing; soil erosion;
desertification; water pollution from dumping of raw sewage and
wastes from petroleum refining; inadequate supplies of potable water
natural hazards: dust storms, sandstorms
international agreements: party to - Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution; signed, but not
ratified - Biodiversity, Desertification, Environmental Modification
Geographic note: there are 42 Israeli settlements and civilian
land use sites in the Israeli-occupied Golan Heights (August 1995
est.)
current issues: water pollution from industrial emissions, raw
sewage; air pollution; contamination of drinking water supplies;
trade in endangered species
natural hazards: earthquakes and typhoons
international agreements: signed, but not ratified - Marine Life
Conservation
current issues: inadequate sanitation facilities; increasing levels
of soil salinity; industrial pollution; excessive pesticides; part
of the basin of the shrinking Aral Sea suffers from severe
overutilization of available water for irrigation and associated
pollution
natural hazards: NA
international agreements: NA
Geographic note: landlocked
current issues: soil degradation; deforestation; desertification;
destruction of coral reefs threatens marine habitats; recent
droughts affected marginal agriculture
natural hazards: the tsetse fly and lack of water limit agriculture;
flooding on the central plateau during the rainy season
international agreements: party to - Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection,
Whaling; signed, but not ratified - Biodiversity, Climate Change,
Desertification
Geographic note: Kilimanjaro is highest point in Africa
current issues: air pollution from vehicle emissions; water
pollution from organic and factory wastes; deforestation; soil
erosion; wildlife populations threatened by illegal hunting
natural hazards: land subsidence in Bangkok area resulting from the
depletion of the water table; droughts
international agreements: party to - Climate Change, Endangered
Species, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Tropical Timber 83; signed, but not ratified -
Biodiversity, Hazardous Wastes, Law of the Sea
Geographic note: controls only land route from Asia to Malaysia
and Singapore
current issues: coral reef decay
natural hazards: hurricanes and other tropical storms that cause
extensive flood and wind damage
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Whaling
Geographic note: strategic location adjacent to US and Cuba;
extensive island chain','263e2e0b7a97ed7f35401e54697284302bc040593023f7196e3ce353b002852e','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e61f20308e0bc0ea4b2ddb065a7fb3179b1ace43c7a57db48f6ee1c67ab8041',1996,'SN','Senegal','environment',309,'current issues: deforestation; desertification; water-borne diseases
prevalent
natural hazards: rainfall has dropped by 30% in the last 30 years
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Whaling; signed, but not ratified -
Desertification
Geographic note: almost an enclave of Senegal; smallest country on
the continent of Africa
current issues: deforestation attributable to slash-and-burn
agriculture and the use of wood for fuel; recent droughts affecting
agriculture
natural hazards: hot, dry harmattan wind can reduce visibility in
north during winter; periodic droughts
international agreements: party to - Endangered Species, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83; signed, but not ratified - Biodiversity, Climate
Change, Desertification, Tropical Timber 94
current issues: very limited natural resources and overcrowding are
contributing to emigration to New Zealand
natural hazards: lies in Pacific typhoon belt
international agreements: NA','809591326842f0e0747a61577407f100f1c2943cb107862cb7350d8d38c6b0ca','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1048e0a757d30c82187a701046d83cd52b83b13716a9ab7df5cc1c7607d7f31a',1996,'NZ','New Zealand','environment',320,'current issues: deforestation results as more and more land is being
cleared for agriculture and settlement; some damage to coral reefs
from starfish and indiscriminate coral and shell collectors;
overhunting threatens native sea turtle populations
natural hazards: cyclones (October to April); earthquakes and
volcanic activity on Fonuafo''ou
international agreements: party to - Marine Life Conservation,
Nuclear Test Ban, Whaling; signed, but not ratified - Law of the Sea
Geographic note: archipelago of 170 islands (36 inhabited)
current issues: water pollution from agricultural chemicals,
industrial wastes, and raw sewage; oil pollution of beaches;
deforestation; soil erosion
natural hazards: outside usual path of hurricanes and other tropical
storms
international agreements: party to - Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Tropical Timber 83,
Wetlands, Whaling; signed, but not ratified - Biodiversity','25ed2362690964ba3440c39c5801f7d68711e1906e6fc317f480fb14c0e64c73','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f25786f6879dd11719626f1a3bdf5c5fb2d2bb64ea41307e15002247006b4e3a',1996,'SC','Seychelles','environment',323,'current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: climatologically important location for
forecasting cyclones; wildlife sanctuary
current issues: toxic and hazardous waste disposal is ineffective
and presents human health risks; water pollution from raw sewage;
limited natural fresh water resources; deforestation; overgrazing;
soil erosion; desertification
natural hazards: NA
international agreements: party to - Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification, Law
of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands; signed, but not ratified -
Hazardous Wastes, Marine Life Conservation
Geographic note: strategic location in central Mediterranean
current issues: water pollution from dumping of chemicals and
detergents; air pollution, particularly in urban areas; deforestation
natural hazards: very severe earthquakes, especially in northern
Turkey, along an arc extending from the Sea of Marmara to Lake Van
international agreements: party to - Air Pollution, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling; signed, but not ratified - Biodiversity,
Desertification, Environmental Modification
Geographic note: strategic location controlling the Turkish
Straits (Bosporus, Sea of Marmara, Dardanelles) that link Black and
Aegean Seas
current issues: contamination of soil and groundwater with
agricultural chemicals, pesticides; salinization, water-logging of
soil due to poor irrigation methods; Caspian Sea pollution;
diversion of a large share of the flow of the Amu Darya into
irrigation contributes to that river''s inability to replenish the
Aral Sea; desertification
natural hazards: NA
international agreements: party to - Ozone Layer Protection; signed,
but not ratified - Climate Change, Desertification
Geographic note: landlocked
current issues: limited natural fresh water resources, private
cisterns collect rainwater
natural hazards: frequent hurricanes
international agreements: NA
Geographic note: 30 islands (eight inhabited)','736006b7b1a67c1960329c912a388f65cdded1ea9a79feea561c69cb724b010c','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffa4d6b22ffd111dbdb3b07fd4afc2efe19f4520f5113842a7213e5300d06645',1996,'NC','New Caledonia','environment',334,'current issues: a majority of the population does not have access to
a potable and reliable supply of water
natural hazards: tropical cyclones or typhoons (January to April);
volcanism causes minor earthquakes
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Marine Dumping, Ozone Layer Protection, Ship
Pollution; signed, but not ratified - Desertification, Law of the Sea','3afd9d65d2cb4e951e05911a707d8bf1bfd732382fe1766e40b1fa7c703c2667','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d73cbef0fda79b4846303cab55d5c82e6ec22d2186cb4d74af339c80ab087688',1996,'GY','Guyana','environment',342,'current issues: logging and slash-and-burn agricultural practices
are contributing to deforestation; soil degradation; water pollution
and overfishing threatening marine life populations; inadequate
supplies of potable water because of groundwater contamination
natural hazards: occasional typhoons (May to January) with extensive
flooding
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Environmental Modification, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wetlands; signed, but not
ratified - Hazardous Wastes, Nuclear Test Ban
current issues: lack of natural freshwater resources
natural hazards: rarely affected by hurricanes; frequent and severe
droughts, floods, and earthquakes
international agreements: NA
Geographic note: important location along the Anegada Passage - a
key shipping lane for the Panama Canal; Saint Thomas has one of the
best natural, deepwater harbors in the Caribbean','73b17edbf64b93bea64006e82770932162957e8399330f0032bf2163716c4be8','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e00ef2c996479dfd8a3ffb3946a0ccfaa31c366cea9c0af007f51bb127adf3e6',1996,'MP','Northern Mariana Islands','environment',349,'current issues: NA
natural hazards: occasional typhoons
international agreements: NA
Geographic note: strategic location in the North Pacific Ocean;
emergency landing location for transpacific flights
current issues: deforestation (only small portions of the original
forests remain) largely as a result of the continued use of wood as
the main fuel source; as a consequence of cutting down the forests,
the mountainous terrain of Futuna is particularly prone to erosion;
there are no permanent settlements on Alofi because of the lack of
natural fresh water resources
natural hazards: NA
international agreements: NA
Geographic note: both island groups have fringing reefs
current issues: NA
natural hazards: NA
international agreements: NA
Geographic note: landlocked; highlands are main recharge area for
Israel''s coastal aquifers; there are 202 Israeli settlements and
civilian land use sites in the West Bank and 26 in East Jerusalem
(August 1995 est.)
current issues: sparse water and arable land
natural hazards: hot, dry, dust/sand-laden sirocco wind can occur
during winter and spring; widespread harmattan haze exists 60% of
time, often severely restricting visibility
international agreements: NA
current issues: soil erosion
natural hazards: occasional typhoons; active volcanism
international agreements: party to - Biodiversity, Climate Change,
Law of the Sea, Nuclear Test Ban, Ozone Layer Protection
current issues: large areas subject to overpopulation, industrial
disasters, pollution (air, water, acid rain, toxic substances), loss
of vegetation (overgrazing, deforestation, desertification), loss of
wildlife, soil degradation, soil depletion, erosion
natural hazards: large areas subject to severe weather (tropical
cyclones), natural disasters (earthquakes, landslides, tsunamis,
volcanic eruptions)
international agreements: selected international environmental
agreements are included under the Environment entry for each country
and in the Selected International Environmental Agreements appendix
current issues: very limited natural fresh water resources;
inadequate supplies of potable water; overgrazing; soil erosion;
desertification
natural hazards: sandstorms and dust storms in summer
international agreements: party to - Environmental Modification, Law
of the Sea, Nuclear Test Ban; signed, but not ratified -
Biodiversity, Climate Change
Geographic note: controls Bab el Mandeb, the strait linking the
Red Sea and the Gulf of Aden, one of world''s most active shipping
lanes
current issues: poaching threatens wildlife populations; water
pollution; deforestation; 1.2 million Rwandan refugees are
responsible for significant deforestation, soil erosion, and
wildlife poaching in eastern Zaire
natural hazards: periodic droughts in south; volcanic activity
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Tropical Timber
83; signed, but not ratified - Desertification, Environmental
Modification
Geographic note: straddles Equator; very narrow strip of land that
controls the lower Congo river and is only outlet to South Atlantic
Ocean; dense tropical rain forest in central river basin and eastern
highlands','82179105e7e493e8052e2852a34f22466efd0ad2d2df051e4173d7c6d19708f1','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02546c253990c4808c33376090728f8b15b42a47f1b266cd0823fec735593808',1996,'BW','Botswana','environment',356,'current issues: deforestation; soil erosion; land degradation; air
and water pollution; the black rhinoceros herd - once the largest
concentration of the species in the world - has been significantly
reduced by poaching
natural hazards: recurring droughts; floods and severe storms are
rare
international agreements: party to - Biodiversity, Climate Change,
Endangered Species, Law of the Sea, Ozone Layer Protection; signed,
but not ratified - Desertification
Geographic note: landlocked','41ce23598cd1f04f4f9408dd84bc77c6a8954bb6b7b5fbe807a3c126d5b60f33','internet-archive','theciaworldfactb27675gut','txt','d698c9441f3b38771c91af16a02cbcfda8b7a8267acdfad0d0015f218d2b2fc2','https://archive.org/download/theciaworldfactb27675gut/27675.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

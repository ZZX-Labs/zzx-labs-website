SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb230de67426eb675dc8538f913f3fa5719307f4c167d723d3fba43f8b2cebd1',1996,'ZW','Zimbabwe','space',897,'tons, gross register cubic meters of permanently 2.831 684 7
enclosed space
tons, long (deadweight) avoirdupois ounces 35,840
tons, long (deadweight) avoirdupois pounds 2,240
Conversion Factors To Convert From To Multiply by
tons, long (deadweight) kilograms 1,016.046 909 8
tons, long (deadweight) long hundredweights 20
tons, long (deadweight) metric tons 1.016 046 908 8
tons, long (deadweight) short hundredweights 22.4
tons, long (deadweight) short tons 1.12
tons, metric avoirdupois pounds 2.204.623
tons, metric kilograms 1,000
tons, metric long hundredweights
tons, metric long tons 0.984 206 5
tons, metric long tons 0.984 206 5
tons, metric quintals 10
tons, metric short hundredweights 22.046 23
tons, metric short tons 1.102 311 3
tons, metric troy ounces 32,150.75
tons, net register cubic feet of permanently enclosed 100
space for cargo and passengers
tons, nci register cubic meters of permanently 2.831 684 7
enclosed space for cargo and
passengers
tons, shipping cubic feet of permanently enclosed 42
cargo space
tons, shipping cubic meters of permanently 1.189 307 574
enclosed cargo space
tons, short avoirdupois pounds 2,000
tons, short kilograms 907.184 74
tons, short long tons 0.892 857 |
tons, short metric tons 0.907 184 74
tons, short short hundredweights 20 —_
townships (US) sections 36
618
townships (US)
square kilometers
93.239 $72
townships (US) square statute Miics 36
miles, square statute acres 640
miles, square statute miles, square statute 258.998 811 033 6
miles, square statute square feet 27,878,400
miles, square statute Square meters 2,589,988.110 336
miles, square statute square yards 3.097,600
yards centimeters 91.44
yards feet 3
yards inches 36
yards meters 0.914 4
yards miles 0.000 568 18
637
eS
Conversion Factors To Convert From To Multiply by
yards, cubic bushels 21.696 227
yards, cubic cubic feet 27
yards, cubic cubic inches 46.654
yards, cubic cubic meters 0.764 554 857 984
yards, cubic gallons 201.974 0
yards, cubic liters 764.554 857 984
yards, cubic pecks 86.784 91
yards, square acres 0.000 206 611 6
yards, square hectares 0.000 083 612 736
yards, square square centimeters 8.361.273 6
yards, square square feet y
yards, square square inches 1,296
yards, square Square meters 0.836 127 36
yards, square square miles 0.000 000 322 830 6
Note: At this time, only three countries—Burma, Liberia, and the US—have not adopted the International System of Units (Si, or metric system)
as their official system of weights and measures. Although use of the metric system has been sanctioned by law in the US since 1966, it has been
slow in displacing the American adaptation of the British Imperial System known as the US Customary System. The US is the only industrialized
nation that does not mainly use the metric system in its commercial and standards activities, but there is increasing acceptance in science, medicine,
government, and many sectors of industry.
619
Appendix F:
Cross-Reference List of Country Data Codes
FIPS 10-4: Countries, Dependencies, Areas of Special Sovereignty, and Their Principal
Administrative Divisions (FIPS PUB 10-4) is maintained by the Office of the
Geographer and Global Issues (Department of State) and published by the National
institute of Standards and Technology (Department of Commerce). These two-character
alphabetic codes are included in the text of the Factbook in the Data Code entry
under te Government category. FIPS 10-4 codes are intended for general use
throughout the US Government, especially in activities associated with the mission
of th. Department of State and national defense programs.
ISO 3166: Codes for the Representation of Names of Countries (ISO 3166) is prepared by the
International Organization for Standardization. ISO 3166 includes two- and three-
character alphabetic codes and three-digit numeric codes that may be needed for
activities involving exchange of data with international organizations that have adopted
that standard. Except for the numeric codes, ISO 3166 codes have been adopted
in the US as FIPS 104-1: American National Standard Codes for the Representation
of Names of Countries, Dependencies, and Areas of Special Sovereignty for
Information Interchange.
Internet: a provisional compilation that generally agrees with the ISO 3166 two-character
alphabetic codes
ently 10-4 3166 ©3166 3166 =—s‘termet una
Afghanistan Oo AR — AF AFG 004 AF
Albania AL AL ALB 008 AL
Aigeria “AG 02 = iDZAiCéits tsi
American Samoa AQ AS ASM.—s16 AS
Andorra AN AD AND 020 AD
Angola AO AO AGO 024 AO
Anguilla AV Al AIA 660 Al
Antarctica AY AQ ATA 010 AQ ISO defines as the territory south
of 60 degrees south latitude
Antiqua and Barbuda AC ; AG ATG 028 | AG. 7 |
Argentina AR AR ARG 032 AR
Armenia AM AM ARM 051 AM
Aruba AA AW ABW 533 AW
Ashmore and Cartier Islands AT _ — —_ — ISO includes with Australia
Australia AS AU AUS 036 AU ISO includes Ashmore and
Cartier islands, Coral Sea
Islands
Austria AU AT AUT 040 AT
Azerbaijan AJ AZ AZE 031 AZ
620
-—— ISO includes with the US Minor
Outlying Isiands
onsular Agency! Brazil
\\ustria
Armenia Azerbayan. Belarus, Estoma, Georgia
Kazakstan, Kyrev7san. Latvia. Lithuania
Moldova, Russia. Taphistan, Turkmenistan
Ukrame, Uzbekistan','20c308c4dc471049965fe4a1c44e8e8317c3465ca7ff1df742a42c2d33aca77e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a547c0ab92ed69de4c619166ddf42a949e3862f5b03912e0d1303bd902e44826',1996,'BB','Barbados','space',898,'Bassas da India
Salv FN Isla de la Kingstown re *
EL SALVADOR pence ST. VINCENT AND Bridgetown
pene Netherlands Antilles: THE GRENADINES
Isla de San Andrés Sienlenied (NETH.)
(COLOMBIA) Oranjestad K Curacao | fy GRENADA
eens St. George''s
pet MAIZ Willemstad
(NICARAGUA) Isla de Tobago
Isla | Margarita =
| ° Tertune Port-of-Spain TRINIDAD AND
Barranquilla, Santa Marta Puerto 92 = 4 a TOBAGO
feria Cabello 7m ~ Trinidad
Puerto . gen, | \\
Limon re ono aes
Bocas
9c! Toro Colon,
eee ne
Cen sa el < Monteria
David wSC CRE ! alboa ®
° PANAMA :
Santiago® LaP
e
Bucaramanga
Medellin
Isla del Coco ad
Scale 1:12,500,000 ey
Lambert Conformal Conic Projection, C O L O Vi B I A
standard parallels 9''N and 17°N
Pereira Bogota
0 100 200 300 Kilometers © *
-— 4. T . i. T 7 7)
0 100 200 300 Miles Ibague
Buenaventura
e
Boundary representation is not necessarily authoritative. Cal BRAZIL
|
&
Boa Vista ®
}
4
802471 (RO2068) 1-97
Jf \\
|
Northern Wake Island TW oO Hawaii
Mariana (U.S.) S
mr “+ Johnston Atoll
i U.S.
anila te Saipan (U.S.)
Guam ye Agana
U.S.
a Enewetak |
- ™ - MARSHAI |
Yap FEDERATED STATES OF MICRONESIA . Kwajelein
‘ 3 ISLANDS
Pohnpei \\.
¥%& Koror + ° ; fe Majuro ro he
Kolonia > _
PALAU CAROLINE ISLANDS | —e
Kiritimati
(GILBERT ISLANDS} (U.S.)
Yaren District Banaba Baker Island (U.S.) Jarvis Island
N NAURU (U.S.)
ew
ewak Ireland KIRIBATI , Lanne <
-
ya | N D 0 N E S A, unce —sus?® New Britain an ae “
Re. Fee wee’ Flores 5, me mwas eeFunatuti @ Tokelau KIR! BA "Noy LES
Denpasar eg HeHoniara @ (N.Z.) 9 | ° MARQUISES
Timor e SP
Lombok sympa Kurang m Port Guadalcanal SANTA CRUZ %
Moresby ISLANDS a
WESTERN American Cook
Ashmore and e. Rotuma Mata-utu
Cartier Islands —_ * mee mrt ® Islands
(AUSTRALIA) @ Wallisand = Apia” Ye (N.Z.)
Coral Sea Vanua ps | Pago
VANUATU Levu 8 Pago
, Islands Fits ARCHIPEL DES TUAMOTU
Cairns, Papeete
New *% Port-vila ar Suva \\'' opp * .
(AUSTRALIA) 4 Caledonia vic * a” ° ISLANDS Tahiti
evu °
. Townsville® a @ (FRANCE) @_@ TONGA a" "0 8
: ww °
Port Hedland stount lea ane >. - $, Nuku’alota =—— ahve French Polynesia
a ee Ceva-i-Ra e e (FRANCE)
Rockhampton, Noumea °
_—— Siete? e ILES TUBUAI | © 6 °
®@ Pitcaim Islands
AUSTRALIA WK)
7 Brisbane, Rapa
Geraldton Gold Cost ® Kingston
Norfolk Island ” een
Kalgoorlie eaten (AUSTRALIA) ISLANDS
@ Perth Hill Lord Howe Island ® (N.Z.)
unbury hyalla
Esperance y . s ydney,
o Adelaide Canberra ik ® Wollongong
— North
‘Be Island
Geelong. qelbourne
NEW Hastings
ZEALAND
Scale: 1:36,000,000 at 30°S
Hobart , rr
e Tasmania | Mercator Projection
Christchurch @ CHATHAM
ISLANDS 0 aa 500 Kilometers
South Island (N.Z.) T T T T 1
0 500 Miles
b Stewart Island
802480 (RO2111) 1-97
*
‘ .
i
’
*
*
‘
* .
f
.
‘
*
~
:
nas *
—
Ww
”
*
~
e
.
ef
.
,
|
.
t ’ ’
‘
° ‘ <
4
)
‘
* “
,
‘
‘
-— °
‘
‘
. ‘
.
. ee .
.
.
.
,
. .
.
*
.
.
*
«
. ,
.
P -
.
‘
.
*
€ . . .
“
‘ , ’ .
¥
t
‘ . . *
oe P °
“ 2
‘
.
*
4 .
~%
ww ,
7 >
oy
ve e .
. . “
¢ “~
. >
as .
.
al
‘
‘ c ‘ .
fi - .
; ma
Y : \\
) ° i. .
1 at
+ ry? < :
ti } >
, é . , ‘ .
° % ;
! . m i ® ‘ »
‘ ‘ > .
ij ‘ i ar “ " 7 >
, i n> art “iy : * if . '' e s ‘ ‘
4 7 " . ¥ 2 ; J . ‘
/ “ L ¢ '' x . ~
\\ sy
; | a AN di PLN a : oe
i$ i a o i r ¥ ; ? ''
own»
i
¥
we
o
VA},
ae : ‘ 7 L 4 : i “ f "
tid p ¥
Pat Piet
Bok
VOR Ve','728ac061c190eb975ed48616f30154a63481299e79a30d74c43c281b3029c93d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f76a6327df1df325240d496cf2beea95a75be2c7cf79ace2977733cdd098a23b',1996,'CA','Canada','space',899,'Cape Verde
(Canada
Czech Republic
Czech Republic
South Alnca
Antarcuica
larwan
Pacinw Occan
Holy Sec
pa TL
South Atnca
Paci: Ocean
Hone K
Sovchelles
\\u
A
} shia','ec1e98ef1d6d2da1fabb3730acccf6479e8c92961f35215a94772d22a0fd7af0','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('363efb51407ed1c5134d2a3a87c67d5dfc497cc1e0d68aff48b2b4e2f44d9208',1996,'CF','Central African Republic','space',900,'— ISO includes with the
Miscellaneous (French)
indian Ocean Islands
MM iSO uses the name Myanmar
621
Entity 10-4 3166 3166 3166 _ internet Comment
Chile _ : Ci CL CHL 152 CL
China CH CN CHN 156 CN see also Taiwan
Chnstmas Isiard KT CX CXR 162 Cx | .
Clipperton island IP _— — = a ISO includes with French
Polynesia
Cocos (Keeling) islands CK cc CCK 166 CC
Colombia co co COL - 170 _ co re
Comoros CN KM COM 174 KM
Congo CF CG COG 178 CG
Cook isiands CW CK COK 184 CK
Coral Sea Islands CR _ _ — _ ISO includes with Australia
Sassine vp _ RR
Costa Rica CS CR CRI 188 CR
Cote d ivoire iV Ci civ 384 cI i -
Croatia HR HR HRV 191 HR
Cuba CU CU CUB 192 CU
Cyprus CY CY CYP 196 CY
Czech Republic EZ CZ CZE 203 CZ
Denmark DA DK DNK 208 | OK
Djibouti DJ DJ DJi 262 DJ
Dominica DO DM DMA 212 DM
Dominican Republic DR DO DOM 214 DO
East Timor — TP TMP 626 TP FIPS includes with indonesia |
Ecuador EC EC ECU 218 EC
Egypt EG EG EGY 818 EG
£| Salvador ES SV SLV 222 SV
Equatorial Guinea EK GQ GNOQ 226 GQ
Eritrea ER ER ERI 232 ER oo
€ nia EN EE EST 233 EE
Ethiopia ET ET ETH 231 ET
Europa Isiand EU — -- = | ISO neato with the
Miscellaneous (French)
indian Ocean Islands
Falkland Islands (Islas Malvinas) FA FK FLK 238 FK
622
FIPS ISO ISO ISO
Entity 10-4 3166 3166 3166 internet Comment
Faroe Islands FO FO FRO 234 FO
Fiji FJ FJ FJ 242 FJ
Finland Fl FI FIN 246 Fi
France FR FR FRA 250 FR
France. Metropolitan — FX FXX 249 FX ISO limits to the European part
of France, excluding French
Guiana, French Polynesia,
French Southern and Antarctic
Lands, Guadeloupe.
Martinique, Mayotte, New
Caledonia. Reunion, Saint
Pierre and Miquelon, Wallis
and Futuna
French Guiana FG 3F GUF 254 GF
French Polynesia FP PF PYF 258 PF ISO includes Clipperton Island
French Southern and Antarctic Lands FS TF ATF 260 os FIPS 10-4 does not include the
French-claimed portion of
Antarctica (Terre Adelie)
Gabon GB GA GAB 266 GA
The Gambia GA GM GMB 270 GM
Gaza Strip GZ -— a _ —
Georgia GG GE GEO 268 GE
Germany GM DE DEU 276 DE
Ghana GH GH GHA 288 GH
Gibraltar GI Gi GIB 292 Gi
Glorioso Islands GO _— -- _ — ISO includes with the
Miscellaneous (French)
indian Ocean Islands
Greece GR GR GRC 300 GR
Greenland GL GL GAL 304 GL
Grenada GJ GD GRD 308 GD
Guadeloupe GP GP GLP 312 GP
Guam GQ GU GUM 316 GU
Guatemala GT GT GTM 320 GT
Guernsey GK _ _ —- _ ISO includes with the United
Kingdom
Guinea GV GN GIN 324 GN
Guinea-Bissau PU GW GNB 624 GW
Guyana GY GY GUY 328 GY
623
Entity 10-4 3166 3166 3166 © «~—Ss‘mtenet Comment
Hail HA HT HTI 332 HT
Heard Island anc McDonaid islands HM HM HMO 334 HM : a a
Holy See (Vatican City) VT VA VAT 336 VA 7
Honduras HO HN HND 340 HN :
Hong Kong WKOOC*~<“‘z KK‘ KG
Howland isiand HQ — _ _ _— ISO includes with the US Minor
Outlying islands
Hungary HU HU HUN 348 HU
iceland iC iS ISL 352 IS
india IN IN IND 356 IN
indonesia 0 DN
rar IR IR IRN 364 IR
IZ iQ IRQ 368 iQ
nd e © mm 32 ©
ie IS iL ISR 376 iL
aly IT IT ITA 380 IT
Jamaica JM JM JAM 388 | IM
Jan Mayen JN _ _ _ _ ISO includes with Svalbard
Japan JA JP JPN 392 JP
Jarvis island DQ —_ —_ _ a _ - “180 eteten wih the US Minor
Outlying Isiands
ersey JE — -- = _ ISO includes with the United
Kingdom
jonnston Atoll JQ _ — _ — ISO ataies with the US Minor
Outlying Islands
Jordan JO JO JOR 400 JO _
Juan de Nova Isiand JU _— — — —_ ISO includes with the
Miscellaneous (French)
indian Ocean Islands
Kazakstan KZ KZ KAZ 398 KZ
Kenya KE KE KEN 404 KE
Kingman Reet KQ _ —_ _ _ ISO includes with the US Minor
Outlying Islands
Kiribat KR KI KIR 296 KI
Korea. North KN KP PRK 408 KP
Korea, South
Entity 10-4 3166 46s «3166 (is3166—St:«éstonct Comment
Kuwait KU KW KWT 414 KW
Kyrgyzstan KG KG KGZ 417 KG
in LA LA LAO 418 LA
Latvia LG LV LVA 428 LV
tae SO LE LB LBN 422 iB
Lesotho LT LS LSO 426 LS
Liberia. Li LR LBR 430 LR
Libya LY LY LBY 434 LY
Liechtenetein LS il LIE 438 Ll
Lithuania LH LT LTU 440 LT
Luxembourg LU LU LUX 442 LU
beses a MC MO MAC 446 MO
Macedonia, The Former Yugosiav Republic MK MKD 807 MK
of
Madagascar MA MG MDG 450 MG
Malawi M! MW Mw 454 MW
Malaysia MY MY MYS 458 MY
Maidives MV MV MDV 462 MV
Mali ML ML MLI 466 ML
Malta MT MT MLT 470 MT
Man, isie of IM — — — _ ISO includes with the United
Kingdom
Marshall islands RM MH MHL MH
D584
Martinique MB MO MTOQ 474 MOQ
Mauritania MR MR MRT 478 MR
Mauritius MP MU MUS 480 MU
Mayotte MF YT MYT 175 YT
Mexico Mx Mx ME x 484 Mx
Micronesia. Federated States o! FM FM FSM 583 FM
Midway Islands MOQ - -- — - ISO includes with the US Minor
Miscellaneous (French) indian Ocean Is-
lands
Outlying Isianes
ISO includes Bassas da india
Europa island. Glonoso
islands, Juan de Nova
island, Tromelin tsiand
625
Entity
Moldova','878f19683457f6e729fde386c1d2b4e1dd681463f683e8cc389d259f0548382b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f1167d0db7e683b889eb2b28ab5728cfc148346dc1b4f1afcc814ce6750bf45',1996,'MN','Mongolia','space',901,'Monjenegro"
Korea, South
Pacific Ocean
Armeme. Avzerbayan. Belarus
Kazakstan Ayrev7san
Moldova, Russia Tapkistan
Ukrame. U zhekostan
bey Syria','37d14955667bbeb3f7b871d717e20eed8aabf1c2e7304b4320f4aff0d0aac07a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd3b8cd9341f073b7d92c6720ac6967f982438491efa994772e42ec498f3dce0',1996,'NL','Netherlands','space',902,'Netherlands Antilles
French Southern and Antarctic Lands
Pacific Ocean
China, Russia
Turkey','707ed39344c36d3299722b5282571541bb9c3fada8eb659601d9c9e44188ae12','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35e5c7f234c3399b9d98b51ff35d49d89cea34af285bfc4a218ae1dc6f8c46a5',1996,'PK','Pakistan','space',903,'w9ua New Guinea
t tace!l isiands
Falkland Islands (Islas Malvinas)
Turkey
Croatia. Slovenia
Eritrea. | thiopia Somalia','e46e6baf87eb281a6c51bb7c070f1fe064c7a9a934fe5a014aa244d6c8034dd5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b471f7936bbf216fe759dd3150bb096c14801c3f68340d5435338e66b774740b',1996,'PE','Peru','space',904,'626
MD MOD MDA 438 MD
MN MC MCO 492 MC
MG MN MNG 496 MN
MW _ _ — _ see footnote at enc of table
MR MS MSR 500. Ms
MO MA MAR 504 MA
MZ MZ MOZ 508 Mz
~ — — — _ see Burma
WA NA NAM 516 | NA |
NR NR NRU 520 NR
=e) _ - _ _
NP NP NPL 524 NP
NL NL NLD 528 NL
NT AN ANT 530 AN
NC NC NCL 540 NC
NZ NZ NZL 554 NZ
NU NI NIC 558 Ni
NG NE NER 562 NE
NI NG NGA 566 NG
NE NU NIU 579 NU
NF NF NFK 574 NF
CQ MP MNP 580 MP
NO NO NOR 578 NO
MU OM OMN 512 Om
PK PK PAK £86 PK
PS PW PLW 585 PW
LO — _ —_ — ISO includes with the US Minr:
Outlying islands
PM PA PAN 591 PA
PP PG PG 598 PG
PF - . - -_
PA py PRY 600 Py
PE PE PER 604 PE
ently 10-4 3166166 Stee —~S«tornt Comment
Philippines RF PH PHL 608 PH
Pitcairn islands PC PN PCN 612 PN
Poland PL PL POL 616 PL
Portugal PO PT PRT 620 PT
PuetoRico = ti itststi“‘<‘«‘z ORCC
Catar OA OA OAT 634 QA
Reunion : | RE RE REU 636 RE
Romania RO RO ROM 642 RO
Russia _ RS RU RUS 643 RU
Rwanda RW RW RWA 646 RW
Saint Helena SH SH SHN 654 SH
Saint Kitts and Nevis sc KN KNA 659 KN
Saint Lucia ST LC LCA 662 LC
Saint Pierre and Miquelon SB PM SPM 6B OPM
Saint Vincent and the Grenadines vc vc vcT 670 vc
Samoa - 7 | _ _ — _— — see Western Samoa
San Marino SM SM SMR 674 SM
Sao Tome and Principe TP ST STP 678 ST
Saudi Arabia SA SA SAU 682 SA
Senegal! SG SN SEN 686 SN
Serbia’ SR — _ — see footnote at end of table
Serbia wid Montenegro _ - — — — see footnote at end of table
Seychelles SE sc Syc 690 SC
Srerra Leone SL SL SLE 694 SL
Singapore SN SG SGP 702 SG
Slovakia LO SK SVK 703 SK
Slovenia SI S! SVN 705 S|
Solomon islands BP SB SLB 090 SB
Somalia SO So SOM 706 SO
South Africa SF ZA ZAF 710 ZA
South Georgia and the South Sandwich is- SX GS SGS 239 GS
lands
Spain SP ES ESP 724 ES
627
Entity oe =. So, CS nternet Comment
Spratly islands PG — — —_ -—
Sri Lanka cELK KA MK
Sudan SL SD SDN 736 SD
Suriname NS SR | SUR 740 | SR ;
Svalbard sv _ gy SJM 744 SJ - ISO includes Jan Mayen
Swaziland wZ SZ SWZ 748 . SZ . | | |
Sweden sw sC«SE:*=*=«SWESC*é‘“‘SSC*;*«‘SSE
Switzerland SZ CH CHE ; 756 CH
Syria sy sy SYR 760 SY Bn
Taiwan TW TW WN 158 | TW
Tayikistan TI TJ TJK 762 W
Tanzania Z 2 Ati“ (TO OO
Thailand TH TH THA 764 TH
Togo TO TG TGO 768 TG
Tokelau TL kK TK 72 K | Oo
Tonga TN TO TON 776 TO
Trinidad and Tobago TD TT TTO 780 TT
Tromelin Island TE _ _ | _ _ _ | ‘Iso eeietes with the a
Miscellaneous (French)
Indian Ocean Isiancs
Tunisia TS TN TUN 788 ™N
Turkey TU TR TUR 792 TR
Turkmenistan TX ™ TKM 795 T™
Turks and Caicos Islands TK TC TCA 796 TC
Tuvalu TV TV TUV 798 TV
Uganda UG UG UGA 809 UG
Ukraine UP UA UKR 804 UA
United Arab Emirates TC AE . ARE 784 AE
United Kingdom UK GB GBR 826 UK/GB ISO includes Guernsey, Isle of
Man, Jersey
United States US US USA 840 US
United States Minor Outlying Islands — UM UMI 581 UM ISO includes Baker Isiand,
628
Howland ‘sland, Jarvis Island,
Johnston Atoll. Kingman Reef,
Midway Islands, Palmyra Atoll,
Wake Island
637
iso =F si
Entity 10-4 3166 3166 3166 internet Comment
Uruguay UY UY URY 858 UY
Uzbekistan UZ UZ UZB 860 UZ
Vanuatu NH VU VUT 548 VU
Venezuela VE VE VEN 862 UE
Vietnam VM VN VNM 704 VN
Virgin Islands vQ Vi VIR 850 Vi
Virgin Islands (UK) _ — _ —_ — see British Virgin Isiands
Virgin Islands (US) —_ -~ — _- _ see Virgin islands
Wake Island wQ — — — “— iSO includes with the US Minor
Outlying Islands
Wallis and Futuna WF WF WLF 876 WF
West Bank WE — — — —
Western Sahara WI EH ESH 732 EH
Western Samoa WS WS WSM 882 WS ISO uses the name Samoa
World — — -- — a the Factbook uses the W data
code from DIAM 65-18
Geopolitical Data Elements
and Related Features. Data
Standard No. 3, December
1994, published by the
Defense Intelligence Agency
Yemen YM YE YEM 887 YE
Yugoslavia* — YU YUG 891 YU see footnote at end of table
Zaire CG ZR ZAR 180 ZR
Zambia ZA ZM ZWB 894 2M
Zimbabwe Zl ZW ZWE 716 ZW
*Serbia and Montenegro have asserted the formation of a joint independent state, but this entity has not been formally recognized as a state
by the US; the US view is that the Socialist Federal Republic of Yugoslavia (SFRY) has dissolved and that none of the successor republics
represents its continuation.
629
Appendix G:
Cross-Reference I ist of Hydrographic Codes
IHO 23-4th: Limits of Oceans and Seas, Special Publication 23, Draft 4th Edition 1986, published
by the International Hydrographic Bureau of the International Hydrographic
Organization
1HO 23-3rd: Limits of Oceans and Seas, Special Publication 23, 3rd Edition 1953, published by
the International Hydrographic Organization
ACIC M 49-1: Chart of Limits of Seas and Oceans, revised January 1958, published by the
Aeronautical Chart and Information Center (ACIC), United States Air Force; note—
ACIC is now pari of the Defense Mapping Agency
DIAM 65-18: Geopolitical Data Flements and Related Features, Data Standard No. 4, Defense
Intelligence Agency Manual 65-18, December 1994, published by the Defense
Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes similar
to the Federal Information Processing Standards (FIPS) 10-4 country codes. The names
and lanits of the following oceans and seas are not always directly comparable because
of cifferences in the customers, needs, and requirements among the individual
ceganizations. Even the number of principal water bodies varies from organization
to organization. Factbook users, for example, find the Atlantic Ocean and Pacific
Ocean entries useful, but none of the following .taiJdaids include those oceans in
their entirety. Nor is there any provision for combining codes or overcodes to
aggregate water bodies.
Principal Oceans and Seas of the World With Hydrographic
Codes by Institution
IHO IHO ACIC DIAM
23—4th 23—3rd* M 49-1 65-18
Arctic Ocean 9 17 A 5A
Atlantic Ocean
North Atlantic Ocean | 23 B 1A
South Atlantic Ocean _ : 32 C 2A
Baltic Sea 2 | B26 7B
Indian Ocean § 45 F 6A
Mediterranean Sea 31 2 Bil
Eastern Mediterranean 3.4.2 28 B RE
Western Mediterranean . 44 7 RA RW
Pacific Ocean
North Pacific Ocean 7 §7 D 3A
South Pacific Ocean s 61 E 4A
South China and Eastern Archipelagic Seas © 49 and 48 DIS plus others 3U plus others
Oceans and Seas of the World With Hydrographic Codes by
Institution
IHO IHO ACIC DIAM
234th 23-—3rd* M 49-1 65-18
ARCTIC OCEAN 9 17 A 5A
East Siberian Sea 9.1 11 A6 58
Laptev Sea 9.2 10 AS SP
Kara Sea 9.3 9 4 SK
Barents Sea 94 7 A2 5B _
White Sea 95 8 A3 Swe
North Greenland Sea 96 — — _ ee
Norwegian Sea 9.7 6 BM SN ee
Iceland Sea 98 — — _ —
Davis Strait 99 iS B2 1’
Hudson Strait 9.10 16 A Al5 IU -_
Hudson Bay 9.11 16 AlG 1H ee
Baffin Bay 9.12 I4A Al2 IP
Lincoln Sea 9.13 I7A Al3 SL
Northwest Passages (Northwest Passage. 9.14 14 AY S1
Northwestern Passages)
Beaufort Sea 9.15 13 AX SU
Chukchi Sea 9.16 12 A7 sc
James Bay — —— All
Kane Basin — — Al4
ATLANTIC OCEAN (see North Atlantic = — -
Ocean and South Atlantic Ocean) _
BALTIC SEA 2 1 B26 7B
Gulf of Bothnia 2.1 1 (a) B29 7%
Gulf of Finland 2.2 1 (b) B28 7F
Gulf of Riga 2.3 l(c) B27 7H
The Sound 24 2 a
The Great Belt 2.5 2
The Little Belt 2.6 2
Katicgat 2.7 2 B25 7K ee
INDIAN OCEAN 5 45 F 6A
Mozambique Channel 3.1 45 A Fl 67
Gulf of Suez $.2 35 FS 6W
Gull of Agaba 5.3 6 - 60
Red Sea 5.4 37 F4 6
Gulf of Aden 5.5 38 F3 6D __
Persian Gulf (Gulf of Iran) 5.6 4) F7 oP
Gulf of Oman 5.7 40) 6 6M
Arabian Sea 5.8 39 F2 OR
Laccadive Sea (Lakshadweep Sea) 5.9 42 FY 6L.
Gulf of Mannar 5.10 - FS
Palk Strait and Palk Bay 5.11 _
Bay of Bengal 5.12 43 FIO 6B
Andaman Sea (Burma Sea) 5.13 44 Fil ON
Strait of Malacca (Malacca Strait) 5.14 46 (a) Fi2 6C
Great Australian Bighi 5.15 62 F2) 6G
Suez Canal : —- 6
MEDITERRANEAN REGION 3
631
a
IHO IHO ACIC DIAM
23—4th 23-3rd* M 49-1 65-18
Medtierranean Sea 3.1 28 Bll —
Mediterranean Sea, Western Basin 3.1.1 28 A --- 8W
_ Strait of Gibraltar 3.1.1.1 28 (a) B7 8S
Alboran Sea 3.1.1.2 28 (b) — 8Y
Baleane Sea (Balear Sea, Iberian Sea) 3.1.1.3 28 (c) BY J
iagurian Sea (Ligure Sea) 3.1.14 28 (d) BIO 8L
Tyrrhenian Sea (Tirreno Sea) 3.1.1.5 28 ie) Bl2 8T
Mediterranean Sea, Eastern Basin 3.1.2 28 B _ 8E
\\dnatic Sea 3.1.2.1 28 ig) Bi4 8D
Strait of Sicily (Strait of Sicilia) 3.1.2.2 - — —
__doman Sea 3.1.2.3 28 if) Bi3 SN
__ Aegean Sea - 3.1.2.4 28 th) BIS 8G
Sea of Marmara 3.2 29 Bl6 kM
_ Black Sea 3.3 ww B17 8B
_ Sea of Azov 3.4 31 Bis 87
_ Guilt ot Lion (Gull of Lions) - BS 8X
__Aral Sea - KR |
ores. . 7 sp
__Caspran Sea 8C
__ Dardanelles _ 8U :
NORTH ATLANTIC OCEAN } 23 I 1A !
Skagerrak 11 3 B24 IS
North Sea 12 4 B23 IN
Inver Seas off the West Coast of Scotland 1.3 18 IK
irish Sea and Sain Georges Channel 1.4 iv B?2 IR. 1Q
Bristol Channel 1.5 20 _ BI 1€
_ Celtic Sea 16 DLA
English Channel 1.7 21 B20 iE
__Bay of Biscay 1.8 22 BIY IB
_ Canarias Sea ee 19
Gull of Guinea i.10 44 C4 IG
_ Caribbean Sea 1.4 27 BO 1X
Guilt ot Mexico 1.12 26 BS IM :
__Bay of Fundy _ 13 25 B4 If :
__Gult of Saint Lawrence 1.14 24 B3 11 :
__Labrac or Sea - 1.15 ISA IL __
_Greentand Sea 1.16 7 : Al 5G
_ Denmark Strait BI ID
Lake bre YE
take Huron 9H :
bake Michigan OM }
bake Ontarmo 9S
Lake Supenor ae — YN ee
Panama Canal _ a J
Saint Lawrence Seaway YL.
NORTH PACIFIC OCEAN 7 _ 57 D 3A
Philippine Sea i.4 56 126 Pp
Taiwan Strait (Formosa Stray oD _ D17 -
East China Sea (Tung Hat) r3 mal DIS JE
Yellow Sea (Huang Ha, Hwang Hai) 5] Di4 xY
632
IHO [HO ACIC DIAM
23—4th 23-3rd* M 49-1 65-18
Bo Hai (Bo Sea, Gulf of Chihli) 7.5 = D16 3X
Liaodong Wan (Liaodong Gulf) 7.6 _ -_
Inland Sea of Japan (Seto Naika) 7.7 53 — 3N —
Sea of Japan Japan Sea) 7.8 52 Dil ee
Gulf of Tartary 7.9 = DIO oe
__ Sea of Okhotsk 7.10 54 D& QQ.
Bering Sea 7.11 55 Dé SD
Anadyrskiy Zativ (Anadyrskiy Gulf) 7.12 — -- SY a
Gulf of Alaska 7.13 58 a D4 SF
Coastal Waters of Southeast Alaska and Bntish 7.14 59 D3 St
_ Columbia aeeeeb eens
__Gult of California 7.15 60) D2 ne
Gulf of Panama 7.16 om DI a
Amurskiy Liman — — 127 ee
Bering Strait — — D7 SR
Bristol Bay — - DS
Korea Bay — -~ DIS 3R
Korea Strait ~- - Di2
Sakhalinskiy Zaliv — - D28 3B
Zaliv Shelikhova (Zaliv Shelekhova) — _ D9 kK
Luzon Strait — — -- 3
Tatar Strait -— - - 3D
PACIFIC OCEAN (see North Pacific Ocean —
and South Pacific Ocean)
SOUTH ATLANTIC OCEAN 4 32 C 2A
Rio de la Plata 4.1 33 Ci 2R
Drake Passage C5 2D
Golfo San Matias - C2 2M
Golfo San Jorge C3 2)
Scotia Sea - a C6 2S
Weddell Sea — C7 2W
SOUTH CHINA AND EASTERN 6 49, 48
ARCHIPELAGIC SEAS ee
South China Sea (Nan Hai) 6.1 AY Dis BD
Gulf of Tonkin 6.2 __ bt G
Gulf of Thailand (Gulf of Siam) 6.3 47 D20 1 a
Natuna Sea 6.4 —
Singapore Strait 6.5 46 tb) 37 Oo
Sunda Strait 6.6 lc .
Java Sea (Jawa Sea) _ 6.7 48 (n) F13 4 a
Makassar Strait (Makasar Strait) 6.8 48 im) EI AN
__Bali Sea 6.9 48 (1) Fi4 : 4 ee
Flores Sea 6.10 48 (j) ee Flo / _
Sumba Strait 6.11 a
Savu Sea (Sawu Sea) 6.12 48 (wo) FIS 6S
Timor Sea 6.13 48 (1) IY 61 Oo
Joseph Bonaparte Gulf 6.14 F20 . a
Gult of Carpentaria 6.15 b4 4P oe
Aralura Sea 6.16 48 th) 3 4U a
Aru Sea 6.17 OO
_ Banda Sea 6.18 48 (g) FE? 4B
_ Teluk Bone (Gulf of Bone, Gull of Bont) 6.19 48 (k) F17 45
_Ceram Sea (Seram Sea) 6.20 48 if) D25 4Q
_ Guilt of Berau 6.21 -- --
Halmahera Sea 6.22 48 ic) D24 3H
Molucea Sea (Molukka Sea. Maluku Sea) 6.23 48 ic) D23 3M
leluk Tomim (Gulf of Tominiy 6.24 48 id) FIs WV
Sulawesi Sea 6.25
Mindanao Sea 6.26
‘ S —— 6.27 48 (a) D2I 3S
Celebes Sea 48 tb) D2? a
SOUTH PACIFIC OCEAN. : 61 E 4A
Bismarck Sea S.1 66 6 4K
Solomon Sea %.2 65 E7 48 _
Torres Strait es 8.3 ES __
Coasial Waters of Great Barner Reels 84
Coral Sea . a 8.5 oe 64 EY 4C —
lasiman Sea a ___—*G 63 E10 4T
Bass Suat ee 8.7 2 F22 6F
_Amundsen Sea a E12 4D
_Bellingstausen Sea EN G
Cook Surat, ee ES
Ross Sea . . Ell 4R
footnotes
634
Appendix H:
Cross-Reference List of Geographic Names
This list indicates where various geographic geographical portions of larger entities—can
names—including the location of all United be found in The World Factbook. Spellings
States Foreign Service Posts, alternate names are normally, but not always, ihose approved
(BGN). Alternate names are included in
parentheses; additional information is
included in brackets
of countries, former names, and political or by the US Board on Geographic Names
Name Entry in The World Factbook
A Abidjan [US Embassy]
Abu Dhabi [US Embassy]
Abu Musa [island]
Abuja [US Embassy Branch Office]
Abyssinia
Acapulco [US Consular Agency]
Accra [US Embassy]
Adamstown
Adana {US Consulate}
Addis Ababa [US Embassy |
Adeche Land (Tene Adclic) |claamed by France}
Aden
Aden. Gulf of
Admuralty Island
Admiralty Islands
Adnatic Sea
Aegean Islands
Acgean Sea
Afars and Issas, French Territory of the (F.T.AL)
Agalega Islands
Agana
Ayacewo
Aland Islands
Alaska
Alaska, Gulf of (Groupe d° Aldabra)
Aldabra islands
Alderney [island]
Alcutian Islands
Alexander Archipelago
Alexander Island
Alexandna
Algiers [US Embassy |
Alhucemas, Penon de
Alma-Ata «see Almaty)
Almaty [US Embassy |
Aloti
Alphonse Island
Amami Strait
Amuindive Islands
Amuirante Isles (Les Amirantes)
Amman [US Embassy]
Amsterdam {US Consulate General]
Amsterdam Island (He Amsterdam)
Amundsen Sea
Amur River
Anatolka [region]
Andaman Islands
Andaman Sea
Andorra la Vella
Andros [island]
Andros Island
Anegada Passage
Angkor Wat [ruins]
Anglo-Egyptian Sudan
Anjouan [island]
Ankara [US Embassy]
Annobon jistand|
Antananarivo [US Embassy]
Antigua [island]
Antipodes Islands
Antwerp [European Logistical Suppor Office]
Cote d''Ivoire','c88301a7cffba9952c17afb07ccd18842a5810e8685334e705a9743982deccab','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54328cfa615cec16104cc0567ee174f8f79f2387d129c2b5a6d30513a64ed878',1996,'YE','Yemen','space',905,'Indian Occan
United States (Alaska)
C hailk
6455 W
6100 W
45 45 E
I400E
143 OOF
Os OO W
ios OO W
SSL Ww
1s 021
125 001
Ss 10}
i712 00 W
44 I
44 12 1
7952 W
8130 W
I4 101
sOOS W
405 W
b6 07 W
12 251
KY 12 W
63 10W
loo {St
70 40 W
S1OW
69 54 W
1H 37 W
?WIIW
140 W
Nanubia','7603a861dbe88f1a5ebe646b76c83ded422a1ed38b5b1d0f1ad7a47fc3293624','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da19f892de8ddaa2da4446e2e3adb25afa20e67216c4e50f7194f8b225effc68',1996,'US','United States','space',906,'Pacific Ocean
Sevchelles
Guemscy
United States (Alaska)
United States (Alaska)
Kinbats
kthopia, Somaha
Boush Indian Ocean Tertory
Pacitic Ocean','99e66bad9e58114a81675df674aadf5785b92b465757e425bf1de4417676687c','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27344a7632806b64399ba1c01165a6f848cb668160da202b7a9e440d17f27011',1996,'ES','Spain','space',907,'Kazakstan
Kazaksian
Niwe
Sevehelles
Pacific Ocean
\\ustiralia
( jena
Kinhat
South Alnmes
Venesucia
Viauritis
trederated States of Vibcromesia. Palau
Vilantic C.Ccan
Pacthc Ocean
Vieracco
Samm Lucw
\\ustralia
Russia
breach Crnana
Broish ladien tlocan Terriers
(jucrpscs. berscs
Viren Islands
. Letooor
Cw aia
Russia lobe lacto}
Nc vohelles
Brasil
bquatonal CGurmnea
Milani Oocan
ltals
Vilantec Occan
Armema. Averhayan, Belarus, Estonia. Georgia,
Kavaksian. Ayrev7san. Latvia. Letheama
Moldowa, Ruwsia Turkmenistan
L kramnec, zhekistan
Taman
Tawhistan
Paciic Ocean
\\ilanti thea }
Alex ria Libva Maur Lania Miorocce Tunisia
Sevehelles
Marshall Island:
Pacttte Occas
byquatonal Guinea
Indian Occat
Madagaxcar
( ohommMa
Atlantic Occat
Falkland Islands (Islas Maly ona.
Mav clk
Nk aT ava','1419eabbbb021962f8d2dc122e8083c93dc55567331711934325367b294356dc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8db2c3a922aca19db8e64adc35c5d6516483296febf13e3a755e40ea7044d71',1996,'IN','India','space',908,'Indian Occan
India, Pakistan
Pacitic Ocean
Lao
Indian Oc
Niger dl
Bolivia
Pacilic Oceat
Arctic OK
|
Indonesia, Papua New Guinea','5e06042e7ce8af8f1412f6e7af8f302ead6dbcad53b41c5bbe38b5bdc0edf582','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db087483d3db4daa6a03697296fcef580e431a0d5350a267d58e3848ce3b0dcb',1996,'BE','Belgium','space',909,'635
Latitude |
ideg min)
S19 N
2428 N
25 S52 N
9I12IN
SOON
16 SIN
S33N
25045
37 GIN
902 N
66 WS
12 46 N
12 WN
S744N
20S
42 WN
38 OO N
38 BON
11 MN
lols Ss
13 IRN
4155 N
OOS N
65 OON
Sk OO N
9258
49 45N
S2 0ON
S7TOON
T1008
s) 12 N
% 47 N
25 J3N
ss iS N
4315 N
9OLSs
TOS
78 40 N
11 WON
O08
4, S57 N
$2 22 N
ws
TwS
S> S56 N
WOON
12 OON
Ooo N
42 MIN
37 45 N
2426 N
ik WON
1326 N
IS OON
2188
w S56 N
1258
IR S2S
i4 MAN
41S
SI I3N
Longitude
(deg min)
ais W
SISE
WIDE
iwoot
4501 E
48 OOF
13420 W
7 00F
1600 F
MOE
SOOT
SIOOF
56 40 F
144455
R445
MOOT
iss00W
4s 00W
46 DE
212W
17600 W
ihM00W
TO00W
29 S4 I
ORF
7530
7657 Fk
76 *7 4
169 SS I
$2 4S 1
129 wh
72 Mi
Sito}
8 SH]
i Si}
77494
ho aow
i441 it
soo]
4° 48 I
OS OO}
iw
34) 4
77 57 W
6340 W
108 So}
woot
4425 4
8) |
Sw]
47 wd
90 44 W
17K 43 E
4251
6.36
Latitude
Name Entry in The World Factbook bmw ey
Aozeu Simp Chad 22 (ON IS GOE
Ama (US Embassy] Western Samoa 13508 i711 44.N
Agaba. Gaull of Indian Occan »” OON M w E
Arab, Shatt al {nver] Iran, frag 29 57 N SME
Arabian Sca Indian Ocean ISOON OSOOE
Aralura Sea Pacilic Ocean 9000S I3OE
Aral Sea Kazakstan, Uzbekistan 45 00 N HWE
Argun River China, Ru. sia 53 20 N 121 RE
Ascension Island Saint Helewa 7578 i422 W
Ashgabat [US Embassy] Turkmenistan 37 STN SS IIE
Ashkhabad isce Ashgabat) Turkmenistan 7 $7 N 58 23 EF
Asmara [US Embassy] Enirea IS 20N WSIE
Asmera (see Asmara) Enitrea 1S 20.N WSIE
\\ssumption Island Seychelles 9465 46 NE
Asuncion [US Embassy] Paraguay 25 16$ 57 40 W
Asuncion Island Northern Manana Islands 19 40 N M5 34E
\\lacama [region] Chile 4WwWS SIisSW
Vthens [US Fimbassy | Greece 37 SYN BHE
Autu Island United States S255 N 17257 E
Nuckland [US Consulate General] New Zealand 6525S 174 46E
Vuckland Islands New Zealand Ssiaus lob SOE
\\ustrales Hes (es Tubuar) French Polynesia 22S isi aoow
\\varua Cook stands 7112S 189 46 4
\\acl Herherg Island Canada 79 MON 90 00 W
\\vad Kashmu Pakistan ON TOE
Avores [istands| Portugal 8 MIN 200 W
Avon. Sea of Milantic Ocean 4900 N 6% OOF
Lab cl Mandeb [stran| Indian Ocean 12 40 N 43 >%0GE
Babuyan Channel Pacilic Ocean Ik 44.N 140k
Babuy an Islands Philippines 19 lu N 121 40F
Battin Bay Arctic Ocean 7 00N 66 00 W
Bation Island Canada 68 OO N TOO W
Baghdad [US Embassy temporanly suspended: US Inter Iraq 3321N OSE
ests Section located in Poland''s envhussy i Baghdad]
Baki isee Baku) Averbayan 4023 N 49511
Baku [US Embassy] Averbayan HO I3N 4SYSILE
Baky (sce Baku) Averbanan SOON SUSIE
Balanac Strat «ilic Ocean 73S N HIT OOF
Balearic Islands Spain ~~ WEN OOF
Baleanc Sea tiberian Sea) Atlantic Ocean SO MON OOF
Bah listand] Indonesia ROS IISOOF
Bah Sea Indian Ocean 7458 11S WE
Balintang Channel Pacilic Ocean 19 JON 121 40F
Ralintang Islands Philippines 19 SSN 122 WE
balkan Peninsula \\lbama, Bosma and Herzegovina, Bulgana, Cro 4200 N OOF
aia, Greece, Romama, Sera and Montenegro,
Slovema, The Former Yugoslav Republic of
Macedoma. Turkey (European part)
lballeny Islands Antarctica 6718S Ini OF
Balochistan [regron| Pakistan 2 YN HOOF
Balt Sea Atlantic Occan S700 N WY OOE
Bamako (US Embassy! Mah 12 WN .OOW
Banaba (Occan Island) Kinhaty os2s 169 VE
Bandar Sen Begawan [US Enhassy | Brune: 4528 11455 FE
Banda Sea Pacitic Ocean Soos 12k OOF
Bangkok [US Embassy] Thailand 1345 N wae
Banew [US Enbhassy] Central African Republic 422 N IR ‘SE
Banjul [US Envhassy] The Gara 13 28 N 6 WW
Banks Island Australia wiws 142 16 F
Ranks Island Canada 75 15 N 121 ww
Banks Islands des Banks) Vanuatu 400s 167 WE
Barbuda [island] Antigua and Barbada 17 38.N 61 48 W
Barcelona |US Consulate General] Spain 41 23.N 2HE
Karents Sea Arctic Ocean 74 00N %M OOF
Barranquilla [US Consulate] Coloma 10 SYN 7448 W
Bashi Channel Pacitic Ocean 22 OO N 121 00F
Basilan Strat Pacific Ocean 6h 49 N 2205 EF
Basque Provinces Spain 43 00 N 2wwW
Hass Stravt Pacific Ocean wows 145 WE
Basse- Terre Cuadeloupe 16 00 N 6144 W
Basseterte Saint Kitts and Nevis 17 IS N 6243 W
Bastia Corsica 424.2 N 927E
Basutoland Lesotho Ny ws WE
Batan Islands Philippines 20 30 N 121 WE
Latitude I i
Name Entry in The World Factbook bmg ol une
Bavana (Bayern) Germany 48 WON IL WE
Beagle Channel Atlantic Ocean S45358 6k 10 W
Bear Is‘''and (sce Byornoya) Svalbard 74 26N 19SE
Beaulon Sea Arcuc Ocean 7300 N 14000 W
Bechuanaland Botswana Dws MWe:
Beying [US Embassy] China WwW SON ll6 WE
Beirut [US Embassy] * Shanon 33 S3.N 5 ME
Belau (Palau Islands) ate. | TMIN 134 WE
Belem [US Consular Agency] Brasil i278 48 29 W
Belep Islands (Hes Belep) New Caledoma 1945S 163 40F
Belfast [US Consulate General] United Kingdom S435 N sss
Belgian Congo Zaire O00 N 25 OOF
Belgrade [US Embassy: US docs not maintain tull diplo- Serbia and Montenegro 44 50N 20 MF
matic relations with Scrtia and Montencgro]
Belize Cay [US Embassy] Belize 17 WN S812 W
Belle isie, Strat of Atlantic Ocean Si 3S N So WW
Bellingshausen Sea Pacific Oceas T1008 gS 00 W
Belmopan Belize 1715S N KK 46 W
Belorussia Belarus Si 00N "ROOT
Bengal, Bay of indian Ocean IS OON 90 OOF
Bering Sca Pacific Ocean 60 OO N ims oo W
Bering Islan! Russia $8 ON loo Wt
Bering Strait Pacific Ocean 6S MN io” OOW
Berkner Island Antarctica ~wS 9 wW
Berlin (US Branch Office} Germany S231.N 13241
Berlin, East Germany $2 MN 13 33F
Berlin, West Germany S2 MON 12 WE
Bern (US Embassy} Sw uzerland 46 57 N 7 261
Bessarabia [regen] Romama, Moldova. U krame 7 00.N 28 ME
Bhopal India RioON T7 244
Biatra [regien| Nigeria SN 7 ME
Big Diomede Island Russia 65 46.N 169 06 W
Bijagos, Arqguipelago dos Guinea-Bissau 1) 25''N lio 200
Bikinis Atoll Marshall islands 11 38.N 6S Dit
Bilbao [US Consulate] Spain 4315 N >Ss5 W
Bioko [island] Equatonal Guinea . MN R421
Biscay. Bay of Atlanuc Ocean 44 00N s0OW
Bishkek [US Embassy} Kyrgv7stan 42 54.N 74 HI
Bishop Rock United Kingdom 952 N 627 W
Bismarck Archipelago Papua New Guinea sus SO OOF
Bismarck Seca Pacific Ocean +008 48 OOF
Bissau [US Embassy] Cnunea- Bissau 11 SEN is asW
Byornoya (Bear Island) Svalbard 74.26N 19 St
Black Forest Germany 48 00N RISk
Black Rock South Georgia and the South Sandwich tslands Saws 4) 48 W
Black Sea Ailantic Ooean s300N sO]
Bloemtontcin South Africa ~I12S wut
Boa Vista [island] Cape Verde OOS N sow
Bogota [US Embassy] Colomma 4 %N “S050
Boherma [region] . 7ech Republic SO ON i4 ME
Bombay (sce Munibar) India IX SEN 72 SOF
Bonaire [sland] Netherlands Antilles i210} os 1S W
Bonmtacw, Strait of Atlantic Ocean 41 01N i4aof
Bonin Islands Japan 27 00N owt
Bonn [US Enhassy] Germany SO 44 N TOSI
Bophuthats« ana South Afnea WS 6 wt
Bora-Bora [island] French Polynesia lo WS is; 480
Bordeaux [US Consulate General} France 44 50 N oww
Borneo [rstand| Brune. Indonesia, Malay sia OMEN 4a
Bornholm jistand] Denmark SSION isa
Bosnta Bosnia and Herzegovina 44.00 N Ik OOF
Bosporus [strait] A\\vlantc Ocean 4100N ~oOt
Bothnia, Gull of Atlantic Ocean 63 00N ‘oot
Bougainville [island] Papua New Guinea 6005S iss aot
Bougainville Strait Pacific Ocean 64058 156 WOE
Bounty Islands New Zealand 47 4n8 4a
Brassha [US Embassy] Brasil is 478 47 58 W
Bratislava [US Embassy! Slovakia 48 YN 707
Brazzaville {US Embassy] Congo 4168 is ivf
Bridgetown [US Embassy | Barbados 13 06N sou7
Brishane [US Consulate} Australia 27 RS isaant
Britain (see Great Britain) United Kingdom S4.008N >owowW
British East Ainca Kenya, Tanzama, l ganda 1 00.N wOOT
British Guiana Guyana SOON ssoOoW
British Honduras Belize I7 15. N RRS
637
\\ame
. ~ ‘7 Per te
. Soma nd
iH bh ILS haa LS \\Vipwss
SFI ivS™M he “N
SW 470)
Hi
t » "
4 \\ s‘
1 \\ } .
} i
is
{
‘ s
|
ist
is { wh
‘ ‘ { {, ;
‘ ‘
}
}
. ;
w }
| { is
s\\ ?
‘ ‘\\
‘
''
'' ‘ i»
j
;
inf
‘ ‘\\
\\ "
\\ nil
i
’
‘ ;
‘
»
{ '' {
| | (| rt
( \\i sf '' t, ral
Bo Ha
‘ Ronub
( !
i)
! 1 Hdech (hea
{ | tiAm it Pact
''
i | | ( iw fe)
{ Nu \\h COT
( (
{ ] ''
{ |
{ ™\\ i» ) ;
( \\ 1 hk tty |
f ler | ds (Komand b
{ a? is. an
( Bra
638
buropean (ar
\\ Lanvin
Treaty On
*)
Entry in The Werld Facthook','124736f78f8725930e106c641da5e601dc5ca23a76c2ddd7bad32b4e0b3840d9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fac15c95d469a4f46734021b15244f56161ccd68ff32d6b27008f12e5bad981',1996,'SO','Somalia','space',910,'Belgaum
AUS atl
Romatua
Hungsr
Arecntima
Burund
Nortolk Island
Kussia [de tacto]
Cote d Ivoire
Moldova. Romania
I rvche orn shal
Ki nva
\\llantic GObhocat
Vik iP Se
| iby ria
Latitude
(deg min)
41 SON
wars
41 13N
32 40 N
1,04 N
40 24.N
S4 005
,weOO N
4415
12 15 N
wwN
TOS N
7S
45 N
7 weN
{0008
4s 10N
wWwwaNnN
SOON
Soh 44N
$1458
478
I aweNn
1A N
,ORS
4400) N
j4 1%) %
i435 N
,wS
xe wWN
a
S 6x &
si6N
Ifa N
ine 5)
Wit N
pies
j sN
ows
a |
ms
\\
; \\
.
‘
w)
WN
“eN
x7 N
saN
Win”
worn
(aN
OO N
7mWS
OAS
is MeN
4344 N
O&O 1® N
Longitude
ideg min)
OO
147 24 E
OD 245
i6 45 W
SO 16+
341 W
7TI0OW
SOOF
55 WE
KOO W
+O
171 O% |
117 we
8 47 E
lot 20}
17 OOF
733i
OF
yO JO W
331
ssvoOoW
4S 141
KO 17 W
sO 35 [
ooor W
4001
iJ4 00}
172) ot
127 231
TO OMT
ev 35 W
t> 3S 4
isa}
i48 wi
17 S21]
IS |
yy ww
77
“St W
»Ss7>W
iwi}
ii}
} \\W
fy W
}
}
“ \\A
wy ft
}
jj }
4 ;
TTh
; !
s VW
\\A
4 mT
|
min Ww
meiwe W
} |
Si init
sim
is}
404
(1? |
i}
tint
Si]
$22]
yin t
"MOT
Ww LI
67 45 W
S|
1047 W
Name','61421e1083fb8b456ed9f81b69936e3f8e6d419d2f1e0a87544502d8d25e90ea','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e63a39d9f7a54f643aea6bbaaf20c98c3d28aff10ecf5227448eea24a4ab2817',1996,'ID','Indonesia','space',911,'Paciinv Ocean
\\llantn Ohocan
( eniral Atmoan Re pith
‘pf A}
Sri | wha
Adantic Occan
Romania, Serbia and Montenegro
Saint Helena
Pacific Ocean
Svalbard
Falkland Islands (Islas Malvinas)
Indonesia, Malaysia
Indian Occan
Pacific Ocean
Sunnain
iy
Russia
Amencan Samou','e8e9272fb2298b86afe198d63f7e5c4f0503d8f4536e6b21e2d723018fe391a1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38012c0efd09049b92d9c7178137b33b934aa4ae7922dcbe3f74321dd7a737bf',1996,'NZ','New Zealand','space',912,'Kus J
Korca South
Pact Ooo
Ih iti im
Latitude
(deg min)
siuoS
wow N
sO 50 N
~47N
4 Oh N
47 WN
MMS
on
~OS
soo N
so N
iy in
mo
4} 44
i 47
1) im)
§ 3)
i ws
6 36 N
FAFAFFHAAFFGLSFLFF FFF LFCFC CLC CLCC}C4CC LEC GL LE EC4EL LOL LOL GG
| ongitude
ideg min)
is aot
49 UOT
4
48 101
~‘h U6 I
wos t
S827 W
Pad |
BS 22 1
i4os Ww
mooowW
tov OP |
7Yy 45 W
isvwew
149 UX I
LPs
bh S56 W
SY ik}
iin im
720) W
pwootl
isW
61a W
oT
iis, W
ie ww
48 40]
ih MI
1H Mt
Ww]
Iss iS]
om $9 4
Pwo}
ws) t
ms oo}
* SOF
2100
is wi
‘S720 W
1ooWw
7}
le UW
"wih
m7 OOF
S704 W
UH SOI
7 S14
90 40 W
ny OOF
1443 W
soo}
c7
. Latitude i
Name Entry in The World Factbook bee al eee
Couge (Kinshasa) Jaite ISaos WHE
Congo (Leopoidvilic) Zaire isms WOE
Con Son [Islands] Victnam KR 43''N 1 ME
Cook Strait Pacific Ocean 41188 174 WE
Cepenhagen [US Embassy! Denmark 55 40.N 12 3S E
Coral Sea Paci Ocean isms Is OOE
Cortu [island] Corecce WaI0N 19 451
Connth Corecce 37 SON 2) SOE
Corn Islands ‘Islas del Maiz) Nacaragua 12 1S N aso W
Corecoro Island Guyana. Venesucla . RN hi SOW
Coraco |itand] Equatonal Guinea OSS N 9191
Cosmotede Group (Atoll de Cosmoledo) Sevehelles 9435 47 Si
Cotonou [US Embassy} Benin HIN > ®t
Courantyne River Guyana, Surname $S7.N s7 06 W
Crete |rstand] Cmecce SiS N "4 451
Crimea [region] t Krame 48 00N wut
Cnomean Penmmnsula L kraine S00N wool
Crooked Island Passage Atlanuc Occan 22 S8N “4550
Crozet Islands (Hes Crozet) French Southern and Antarctic Lands 46 WS Ss) ot
Curacao {US Consulate General] Netheriands Amilles 2 ai N mow
Cyclades |iands|} Corecce 7 OO N Ss WE
Cvechoslos ahia Czech Republic. Show ahia 4900 N Inmet
Dahomes Benin “MIN 2151
Dano Istands Japan 4300N BAL,
Dakar {US Enmihassy! Senezal i440 N i7 ®W
Dalmatia [regron] Croas s00N
Daman (Daman) Inchia MION 720}
Damascus [US Envhassy} Svna wWwN Miki
Danger Islands isce Pukapuha Atoll) Cook Islands wwsis ins 49 W
Danish Straits Atlantic Ovcan sSsouoN bia
Danish West Indies Vergin Islands IN UN mo sO W
Danzig (Gdansk) Poland S425 N is 401
Dao Bach Long Vi |istand] Vectnasy OR N iy 444
Dardanctles | strart} Milani Ocean weIsN *h 25 I
Dar cs Salaam [US Embassy | Tanzama h 4a w 17 I
Davis Strait Atlan Oocan 47 00 N sy, OO W
Dead Sea israci. Jordan. West Bank 2 wN ie |
Deception Island Amtarchea 62 S68 muw
Denmark Strart Atlantic Ocean ov; OO N 100 W
D Entrecasicaus Is!ands Papua New Guinea Y MS 180 404
Desolation Islands (isles Kergucten) French Sowthern and Antarctic Lands 9 WS mw we
Devils Island (Ne du Diable) French Guiana S$i7N s- as W
Devon Island (Canada %® OON a7 OO W
Dhahran [US Consulate General} Saudi Arata IRN SOON |
Dhaka [US Embassy} Bangladesh Pa 4hN wos |}
Dhotar [region] Onnan 7 OO N Saf
Diego Garcia [island] Brith Indian Ocean Terntory 7S 72 25%
Diego Ramirez {istands| Chile se w)S os 45 W
Diomede Islands Russa [Bre Diomede!. United States [Lith 6s a7 N moa
Dromede |
Dru Incha M42 N 759 1
Dybouts [US Embassy] Dyrhouts 1 WN $3154
Dmeper [river] (Dayvapro, Drepr, Drpro) Belarus. Russia, UKrarne ih WN A st
Limester [rnver}] (Nestru, Darter) Moldova, Ukraine 46 18 ''N wiiyt
Dodecanese [islands] Cirecee WOON 7 Os |
Doxdoma Tansama His S48]
Doha (US Embassy] Qatar 17 N $1321
Donets Basin Russa, Ukraine RIS .N ww Mw
Douala Cameroon sor N ¥ 4) }
Douglas Man. Isle of sa N ion W
Dover, Strait of Atlantic Occan si; 00.N i wt
Drake Passage Atlantic Ocean aus ao Ww
Duta [US Consulate General] UL mited Arab Emurates 2S IRN SS IK}
Dubayy (sce Dubai) United Arab Enurates 2S IRN SS IK]
Dublin [US Embassy} Ircland SiN 61S W
Durban [US Consulate General] South Atnca wm S85 ui SHI
Dushanbe [US Embassy] Tapkisian ww OUS NN H& 48 I
Dutch Antilles Netherlands Aniuiles S208 N 418}
Dutch East Indies Indonesia sims want
Dutch Guiana Surname S00N SOO W
Dutch West Indies Netherlands Antilles S2 USN L181
Dvunganan Gate China, Kazakstan 4S 25 N B2 IS ft
6.39
Name
Fast Chena Sca
bast Pres nm islands
bast Ger aany (German Democratic Republic)
bast Ay ca Stran (hasiem Channel or Teushema Seran)
bast Pakistan
tam Sshorian Sea
t T rw Portugues< Timor)
f ot Island iista de Pascua)
bostern Channec! itast Korea Stran or Tsashema Soran)
basicrn Sammua
tahebureh 10S Consulate General
!
bite estan
t ! Rimenes Island
i mere IsLand
. Islands
theese. Ishas che
/ lerburs istand
! sctak Atoll thaiactok Atoll;
'' Lm) ifegnwan
} sh ( hannecl
} sactok Atoll isec Fnewetak Atoll)
i Iwavk
} Northern
j ho [room clamed hy Voneructal
laurut boned
rds p «Atoll de Farquhar
} le Noronl
} hi i ¢ Brot
’ if : ''
} me [ti NC Hate Cactheta
! Stra
i s { rSI
rm i hal
j rhrna Stra . lamwan Stra
} tS Co w Agen’
} le France
} kiwrt Miu LS Consulate General
ita j i] J listand
ty i LS behasss
t } { ane? ''
/ (y
’ h Indoct
} hh \\iow
} Son iva!
bh Sool
j h Ver he A ml issue (FT AT
j hl
nh VW !
} , I j
} | }
tt Histhea
both \\ { S\\ ¢ copsulak
} ih
t | | H Inlands/Thes de Horn
{ t \\ bo \\
Isiands « Archymelage de Colon)
,
‘ a ;
{ } Islam lles Crane
{ ¢ Stra
( eva [Branch Offmee of the US Fevhasey. US Viewseon
Furopean Ott tthe UN and other micriatwmal
i! ;
{ ’
{ '' low
i, Toww
(scoree Town [US Consular Agency!
640)
Entry in The World Factbook
Paciic Oocan
Gsermans
Germans
Pacit« Ocean
Korca, South
Antarcuca
Pacific Ocean','969dff5382f5c4f198b441af39f8b811e963c95325c3e6eb83bae2c4445ee9e8','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cabbb4ca9492574d687212b7ea7bad3963265ad604a9523c49c1aed14a34ca2',1996,'CL','Chile','space',913,'Paciic Ocean
Amencan Samoa
Untied Arngdom
Ircland
hialy
Cape Verdc
Dommnmecan Republic
Brasil
Brasil
Cape Vera
Sao Tome and Princip','704573adb893245db6c2455dd597f453e448e6863a1d098d2244f6df22194599','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35b5c3ee341c4b5e499c69286bd2c5bee9f90f47f6f8cbbbd84f8dd14b8e293d',1996,'BR','Brazil','space',914,'Martinus
CacrTmans
Russia
Sierra Lown
( amc
Cpuihica
Cambodia. Laos, Vietnam
Viorocce
[Destrcmuets
Mal
L>yrbrcnuts
Toma
Guadeloupe, Marteniguc
longa
Denmark, Germans. Netherlands
Avrev7sian
Trini Th ma loba a)
Ben
Federited States at
Northern Manana Islands
Northern Mariana fslands
Latitude
(deg min)
271 30N
oss
28 25 N
TOON
HO00S
S32 0OON
c
=
\\ Aa Aa’ ay “ay “ay Aa’ “a “a Aa’ A’ ee’ i 4
=
an ne ae et ee ae ae ae ae ae ae ae ae ae ae ee
‘
4
‘
i
is6H \\
‘
‘
‘
‘
> . »
» 5
”
i,
‘
: .
ix %
) } \\
} ,
+
‘
; 4
4 ~
/ ,;‘\\
iN
. ‘
Jini
yy ws
“eis
1) WN
fy yN
Longitude
(deg min)
Sk OO W
169 35 |
178 20 W
46 00 FE
71 WE
150 00
128 OOF
Sk 30]
IS 00F
o43W
70 06 W
12 401
,00 W
135 we
1045
131 OOF
IY Oot
7358 W
13iW
hos OOF
145 47 |
17042 W
lis 308
13214
ss 1S]
1 45 |
Ty OO]
6200 W
932 W
7945 W
79 tO W
[22
1 > (Md
M9 VW
sso ew
ty (MY
“1
Lp \\
" \\A
wii
|
|
j
;
\\\\
” }
uw) }
|
|
''
wi
‘ iW
ff |
f iW
. |
Wy W
“Ww
S7 MI
147 WOH
Si qi w
6és3°
Portuguese East Alrnica
Portuguese Guinea
Portuguese Timor (East Timor)
Pon-Vila
Poznan [US Consulate General]
Prague [US Embassy]
Praia [US Embassy |
Pretona [US Embassy |
Pribilot Islands
Prince Edward Island
Prince Edward Isiand:
Prince Patrick Island
Principe [island]
Prussia [region]
Pukapuka Atoll
Pusan [US Consulate]
Pyongyang
Quebec [US Consulate General
Queen Charlotte Islands
Queen Elizabeth Islands
Queen Maud Land {claimed by Norway
Quemwy [island]
Quito [US Embassy |
Rabat [US Embassy |
Ralik Chain
Rangoon [US Embassy |
Ratak Chain
Reeile ILS ¢ onsulate |
Redonda [island]
Red Sea
Revillagigedo Island
Revillagigedo Islands
Revkyavik [US Embassy]
Phodes [island]
Rhodes
Rhodesia. Norther
F nodesia. Souther
Riva [US Embassy
Rio de Janciro [US Con
Rio de Oro
Rio Mun
Rivadh [US Emba
Road Town
Rohinson CF
Rocas, Atal
Rockall |
Rodriguc
ome [US kmba
neon (sec Ho Chi Minh City)
wnt Brandon (Cargada
unt Christopher and Nevis
>i
Si
Saint Christopher [island]
‘i
S:
unt-Dents
Saimt George s [US Embassy
Sait George s Channel
Entry in The World Factbook','d29eba0a37bd29c5e91048b14f7b197a654dd7572a3bc0d9ac35a1fcb24794ab','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0178cec22df32c6a7b64d2321b0f34a9cda4ae616f69af8e57577bd79924327c',1996,'MY','Malaysia','space',915,'The Baharnas
; ont
saoaow
>>) W
iso}
y I
Sid}
Tiee tm"
,in) W
yssS Ww
isk OOF
SFL 4-FSCFFL4FLFCSLLFLLLC4CHL4LLLZL4LZLGCCKCLLLLELLL4L.
,
“
“SL
\\I | 1) ‘i by
Korca. South
Sera and Montencen
(; hombia
17 oe
TOOT
Mth if W
79 46 W
Oo4 19 W
YX (WH) I
TOO]
> wt
woo W
12) 28 4
123 271
iww
133 wi
146 45 1
hoo oof
( he
Rus rr
J AIT
Heard Island and McDonald Island
South Georgi and the South Sandwich Island
C hina','db5a7b01a94f639c2a51a45dc50669df1a5e4117728d3e82c9fac22ec340640d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39399a0b4703598842b775bbfecc2bdaa0c3eddc143dae7075c54733d40fac66',1996,'KY','Cayman Islands','space',916,'| atitude
(deg min)
Longitude
(deg min:
woon
Siain
$2 00 N
1300 N
4.00 N
74.00 N
9S
NTws
WOON
14S
6857 N
sSsa0oN
42 46N
7A OO N
kao N
soos
OowN
,OR Ss
1) WN
s> wiN
sO N
1i WN
‘* MIN
suo N
400%
6 SON
4355 N
Ww
+4]
; Mw
mlial
43 46
sin)
CFF FGFS
if Ww)
$3 45
=
FFF F FEL FFL 44 FL 444 G4+F
=
SS FFF FG
SoA N
2tMWN
iy ON
IME
7IE
IS OOE
IMME
GOODE
ifs OO E
IM OO E
woo Ww
IN GOE
Wiihtin.:
,I3W
soaOW
wiv F
mu w
ow
I7R OE
9 iF
i7tsW
162 158i
iwaw
iPaow
62 ISE
isi
~DwE
400 W
Sk Oa W
147 2OF
Si 10f
228
R421
7 OOF
11st
~~ 45 W
i oof
ivan
Mm MW
61 os Ww
in)
sso
risW
iat
Mmooaow
7 OOF
soaow
soo W
400 W
ice
fw
a 0OoW
msaow
6 404
71 Wi
iw 241
Imo 12 t
6600 W
rsx os W
* 441
www
ee
ass Ww
i458 W
17 te
Hh if
RS’ FH
Wom
7546 W
a1 Ou W
. : : | atitude i j
Name Entry in The World Factbook pg a oie
Geoorgewwn The Gamina 13 WN 14470
Georgetown [US Embassy} Guy ana 6 48 N SOW
German Democratic Republic (East Germany } Germany Ss. Q0N Lao
German Southwest Afnca Nama ws jo oF
Germany. Federal Republic of Germany =) aN 9D
Cabraltar Grbraltar ti N sl22wW
Cabraltar, Siran of Atlantx Ocean ws STN swMw
Cac Pass bey weiaN tiie}
Gilbert islands Karthats 125 N Tl
(soe [state] India i4 ON 72 ODF
Godthah (Nuwh) Greenland Oo itN s14aW
Cold Coast Ghana su N >aOoW
Gotan Heig’ts [region} Syna sOON 18 454
Good Hope. Care of South Atnca MMS SME
Cotchorg Sucden $, 728 ii S8t
Catlant (niand} Sweden ST WN in 3a t
Gough Istand Samm Helena ws 945 W
Grand Banks Avlanuc Ocean 47 06N S445 W
Grand Cayman [island] Cayman Islands 19 DON s1o0 Ww
Grand Turk Turks and Catoous Islands >) 28 N om W
Great Austrahan Bight Inhan Ocean sos mime
Cacat Beh (Store Bach) Atlanic Ocean s*wN ime
Great Brttcr Lake Fevpt 0 N 2 236
Great Britain [istand| United Kingdom S00N OW
Creat Channel lndion Ocean 6h 25 N ee
Cwcater Sunda Islands Brunci. Indonesia. Malay sia 2008 OOF
Green IMands Papua New Guinea 4MIS Si 1of
Greenland Sea Arcuc Ocean ~wOoON sow
(Grenadines. Northern Samm Vincent and the Grenadines isis N oF il Ww
Grenadines. Seuthern Grenada ay N ai so’
Cirytviken South Georgia and the South Sandwich Isand “ISS sw
Cwadalajara [US Consulate General! Mexno “40 N ouewW
Cuadalcanal [island] Solomon Islands 9 ars im itt
Cuadalupe. Ista de Mero M1IN is i7
Guangzhou [US Consulate General | China 206 N int
(wanmtaname Bay [US Naval Base! Cuha woON son Ww
Cuatemala [US Embassy} (wuatemala i4 %* wa) \\W
Curnea, Gull of Milani Oocan +i N ''
CGuavaguil [US Consulate General] bouador 2138 ~SaW
H Ha apai Group Tonga Lee 74 oY W
Hahomar Islands Russia [de fact! saweN i46 104
Hadhramaut |[reguin| Yomen isa N woof
Hague. The [US Embassy] Netherlands S205 N sis]
Hasta Isracl SON Sit
Haiphong Victnam ~~ s7N im 4) 1
Haman Daw [rstand] China io N wwe
Halitax [US Consulate General! ( anada NM owN ww
Halmahera [sland] Indume sta iaON ~~
Hamburg [US Consulate General! (Gscermany S}aaN sO]
Harmulies [US Consulat: Cener:!! Bermuda WIN hd 46 W
Han (|. S Lianon Onfice; Vic unam 102N ls Sy
Harare [US Embassy | 7 imbab ¢ i7 SOs pais
Hatay [province] Turkes WN wm 1St
Havana [US post noi mamtamed, representahen by US Cuha 2208 N 4222 W
Imerests Section (USINT) of the Swrss Ervvhasss /
Hawan lL anted Mates ~~ N ‘ \\
Heard Island Heard Island and McDonald Islands sto Ss i}
Hejaz [regron| Saudi Arata “4 wN wn MDF
Helwnks [US Enihassy | bintand worn 1 Sa}
Hermosillo (US Consulate | Mew /wiWN sa W
Herzegovina Bowma and Herzegovina 400N sin
Hispamola '' land] Dommecan Repubbhe, Hart in 48 N 7 oOo W
Ho Chi Minh City Victnar was \\ im 20''
Hokkardo |rstand] Japan MOON ERSLU
Holland Netherlands sS wN oe et |
Hong Kong [US Conswlate General} Hong Kong 2218 N iw
Homara Solomon Islands 9 ™HS iso $7 4
Honshu |isdand] Japan wouON pao
Hormus. Strait of Indian OQoecan MN 1S)
Hor, Cape (Cabo de Hornmos) Chik ss su 67 160
Horne. les de Walls and Futuna 4419S rmaosw
Horn of Afnca Dybouts, Eritrea, Fihopa, Somata SUN sus
Hudson Bay Arctic Ocean sooo N GLIA.
Hudson Strar Arctn (loean 5a N "TOO W
641
Name
Eniry in The World Factbook
New Caledonia. Vanuatu
Portugal. Spain
Saint Helena
Cambodia. Laos. Vietnam','8414ae34427cdd3b363df4e3ef73bd989e33853a04a97ac7db2285919ee5b15b','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc04408b57bee280a81ca6876e21463820812f6a09b727fb880949a980a6c3e6',1996,'SA','Saudi Arabia','space',917,'Isracl. West Ban
South Atnca
Pacitic Ocean
Chik
Indian Occ:
Israo'' W
Denmarh
C hin:
Su lan','0446d9d7259d36cc223a450e10b4e3c4ee733b8de1a9bd91f654fa5b518a8546','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7977f3423a29f02cc48b9ecb06bd2c7d59dd130e762edcba13dc1134e4174b48',1996,'KH','Cambodia','space',918,'Qinan
Afghanistan. Pakistan
l kramn
ike Wanda
lamaica
Nortolk Island
Latitude
(deg min)
iS
S
N
N
N
N
S
S
N
N
iN
+S
N
S
\\
‘
‘\\
N
4fSLL L444 LL bt
a an 2
Pd
#
a a A
S
Ik OON
WOAS
Longitude
172 06 E
sooW
12740 W
WE
IS OOF
138 OOF
S20 W
JI3IE
TR IOF
sy 00 W
28 SKE
14 OOF
3% 0) EF
49 OOF
147 401
Soo W
141 205
106 46 fF
$44W
74524
76 OT
13S Oo]
KOs OF
(Hit
(Mi ft
121
l4+f
I. 1
*» (|
2400 W
SO) WA
22 =44 |
Smif
9151
soso W
41
39 34
mos oof
$6 OOF
71104
Y O% |
w) 41 i
wy) Od |
7648 W
167 SKI
Kingstown
Kinshasa [US Embassy |
Kirghiziya
Kintimati (Christmas island)
Kishinev (see Chisinau)
Kthira Strait
Kobe
Kodiak Island
Kola Peninsula (Kol skiy Poluostroy)
Kolonia [US Embassy]
Korea Bay
Korea, Democratic People’s Republic of
Korea. Republic ol
Korea Strait
Koror [US Liaison Office]
Kosovo [region]
Kow loon
Kra. Isthmus of
Krakatoa | volcano}
Krakow [US Consulate General]
Kuala Lumpur [US Embassy]
Kunashin (Kunashir) [island]
Kunlun Mountains
Ki Islands
Kuwait [US Enshassy]
Kuznetsk Basin
Kwajalein Atoll
Kyushu [island]
Kyyin isee Kiev)
abrador
accadive Islands
accadive Sea
agos [US Embassy!
ahore [US Consulate General]
akshadweep (Laccadive Islands)
a Paz [US Embassy}
a Perouse Strait
ds Palm j
iu Group
me {US Emba
ondon [LS kimbha
eycarnvel
ord Howe Island
oursiack Archipelago
ovalty tsicads (Lic Lovaute)
uUdnua iI S } mbassy |
any
ubumbashi
usaka [US Embassy]
uxembourg [US Emba
uzon fisland|]
uzon Strait
vakhov Island
Mia at)
Entry in The World Factbook Latitude Longitude
(deg min) (deg min)
Saim Vincent and the Grenadine i309 61i14W
/aire iS IX]
Kyrgyzstan i] 700
Kirtbati : Is7 20 W
Moldova i) 2% SOF
Avanuc Ocean ; 2200
Japan $4 Ss 1OF
United States 5) 3
Russia
Federated States of Micronesia
Pacific Ocean
Korea. North
Korea. South
Pacitic Ocean','9b8841854ea59d95c6306b063cadba34a7d7192e87b2c7d954a917f698dc92e9','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82cd9e5a6cfce9bd667d4eaa95eb560b892b6beb6ab33116ba5ce9da1f0a72fd',1996,'CN','China','space',919,'Russia fdk
Kuwalt
Russia
Netherlands Antilies
Netherlands Aatille
Atlanuc Ocean
Macedoma, The Former Yugoslav Republic of
@ ashi
om TURKEY : aku
4 Y Dushanbe an, TAJIKSTAN indian
pon ‘*‘ claim
e > Ny
ke « 4 “4
Tabriz
afeeags 7 ie oe . \\ af
. Aleppo indus . “~~ xO? - ;
CYPRUS . Line A * Chinese tine *€
‘ SYRIA i of control
Beirut ¥e re vant —, sabe t
jamascus
é
; = IRAN AFGHANISTAN ‘1. INDIA S
"Herd { PAK.
802478 (RO2110) 1-97
DEST COPY AVAILABI F
669
Southeast Asia
ej Ga; ©
Hete ° {f° ; i f _— 14
Shangna ,
> ——_— GH » Eas! S$ >
- Chengcu 4 Vuhar
4 a) v. "en, Ha grnod gr P China of, »
, 2 Chongqing -y Wingnosgs P 8 y
— a =~ 263 ~ =
Z gong af Nancha e 3 3 ~ °
HINA vet es
oe 4 _ >
Changsha »/ : ~ = BONN
eouvane ¥ oe ~ : (SLANDS
Fuznoy, PI Nana” y ,* . °
~ fape % . DA a
7 4 + SHOTO voitaNno
mamen. ¢ od . 4 v AP aN (SL ANDS
. Shantou” £
na — —tSangrneu—g 7
. Wr oe Sl Kao-nsiung » Tamwan
Nanning y BD tory ng wm
Do Inara F SS Macau Okinc-tor
: »Y — shima
i Pratas
Ha ahong 5 Island . PON |
” be » * BABUYAN ISLANDS
’ aan 9 ° .
Dao Philippine
B e . Hue PARACEL S ea
- ISLANDS
th | MooRec THAILAND Pgh? Nave
= VIETNAM
@ Ratchasima S th
. x
» ANDAMAN China
Si 4VDS q'' _
F mow %
—_— / Sea
»¥ ~ ‘ Palawan . ,
y the SPRATLY FED. STATES OF
(‘SLANOS :
NC OBAR . « Koror MICRONESIA
bi ad ne? ’ \\s gkhia x
NDIA
¥ yeorge T Em, ~~ . PALAU N oO r f h
: : YSIA °
) ? ~ KEPULAUAN Pacific
Moser, ee uripur ~ waruNa . Ocean
p oS etn , 0
ulau neulue - ;\\
we j
— , D9 satmarer
Pulau Nias -* ‘ EL quate
. \\ . . j
vinamstunllll pee >
\\ \\ Paden ©” Pulav ay ny a >d
7 Bargeea & OO, m . an
Pulau Siberut \\\\ Sumatra | -« 2 2 = oO , eo
ermasuan % A ° Ceram
v"A ” nr —™. ~ . “ r
ay Bilitan Oo Ambon e
omungkarang Javea Sea
Te + tung
‘ah Jakarta | N D O N‘“ Banda Sea Vv A
- - Wd 7 vor Madura ’ anu
wt. dave Cine os
—~> Lh Arsture
Denpasa ; Sea
ete Lombot — .
; an
A STPALA ) | e
4 4) x.
a &> Bi On Meh,
ake ae | e asia ‘
ands Ashmore and Soar (
AUSTRALIA Cartier Islands > , '' /
(AUSTRALIA on I / Q Guar \\
Indi O ‘or Cope
ndian Ocean } ye 4
—_ re
| A ~F} /
Ly SU
Scale 1:32,000,000 at 5 N i (
» | / |
Meret OES | J AUSTRALIA |
W) Fnorveter j|A ae a 2044
- |
i a ee Apo P wt led and Mount tsa®
00 Vide f Karratha W sa |
~ i
» represeritaty recessar ly autmontative hs
, Vv ar’ are w" aithout Cacritcal marks \\ ido 140
ige j r
BEST COPY AVAILABI
802479 (RO2106) 1.97
67%
Arctic Region
10°C (50°F) isotherm,
July
RUSSIA
SEVERVAYA
ZEMLVA
» Jan Mayen
Norwegia
Seg
¥
North Atlantic Ocean
wO4
ot, Petersburg
:
gy Mos ow
Scale 1:39,000,000
Azimuthal Equal-Area Projection
0 500 Wlometers
aa ee ae at
a cree,
0 500 Mix
The Arctic region is often defined as tnat area where the
average temperature for the warmest month is below | 0°C
30
de —
J’ s '' ane? 7A é}
Dd e a : .
st h™ GOOUEEC Dy "hE SOVIET Linu” JAPAN
a nS emesis Sy Pome (ere (y +a, ;
‘ < ''
&
. an
“~— Satna
Fra a de |
<
“4
Provideniya
+ 4
.
Oxnotu«
vakuT
.
.
BEST COPY AVAILABL..
6
7/
Antarctic Region
a Port Elizabeth ~
® Year-round research station . —— AFTECA
Scale 1:68,000,000 South ''iAtlantic
Azimuthal Equal-Area Projection 7 |
en 7” .
500 1000 Miometers Ice |
’ %
500 1000 Muies
Nineteen of 26 Antarctic consultative natons nave made ;
aus Antarctic territory (altnough Russiz and the
Una States have reserved We rg to Go $0) and Go eat Bowel ilar 7 )
gn.z x woRway ; PRINCE EDWARD ISLANDS
a ° (SOUTH AFRICA) |
Sour Ce ‘pa ard the
Sout 2 , Jacl tsiancs
en aie
y BRITISH “Les
CLAM NORWEGIAN CLAIM moet ;
ARGENTINE : undefined lima 6,
raliand ‘lands CLAIM g 4
na — cote Ses . F Sou :
sere ty AL NTN - SOUTH | Novy and Antarcfic Lathids
F ORKNEY 1 ~~~ (RUSSIA 4
iad ANDS a ’ an :
; Neumaye'' = Marr: ~wy
souTy’ (GERMANY) (INDIA) ear UAPAN)
NA SHETLAND area of . ® Molodezhnaya v
ARGENT! wr gh enlargement Queen Maud Land . (RUSSIA) neuen 3,
| f. B Halley (U.K)
NINE 7 Belgrano Ii
> 4 j Dome Fuy) ..
CHILE | = . 5 (JAPAN) pt - STRALIA ~ aA) Heard island and
——__—1 © Beigtare il omen
j . )
’ (ARGENTINA)
m=
.. Zhong Shan™ @ Davis
CHILEAN
(CHINA) >
CLAM | —
{ Amundsen Scott paadiads
Peter / Island ; an Po (U.S ) ’ pi Murnyy | | ’
s Vostok (
Viarme Kyrd (RUSSIA) > ‘
Lari 4 > ce Shet
cif / ; > ss $
; Casey v
a > (ausTRAUA) 3
w.S.) ¥
: A
| Vatoria Land * x&
ey / - Dument d''Urville y
rug ty Pussa and Coma each have J (FRANCE)
9 station on King George island Scott
h
‘ Esperarza —_ BALLENY ~ S/,.
, gy ARGENTINA) tSLANOS FRENC:
s wy, Maram ip’ CLAIM
Arture Prat Bernards (ARGENTINA) . abt
CHILP) O''Hiogas Vey, ~ _ nus pi
mn Ci ays | (CHILE) ; “ALAN, a — ae ch
(SPAIN) © CLAIM
| Macquarie Isiard
: P ‘ (AUSTRALIA,
; s / 4 Carnpbel/
Crahar island
NEW ZEALAND) AUCKLAND ISLANDS
} o bund
Arn \\ J, (NEW TEAASND) Tesmenie
Faraday/Vernartsky ottart
Antarctic 4U.%.) ((RIRAINE) SNARES ISLANDS aaunad
| Paninsula (NEW ZEALAND) ‘, a
. el ne
! NEW ™
. CHATHAM /SLANDS ZEALAND Coetsichurch Canberra
(NEW ZEALAND) » ™ *
San Maitix, ener AUSTRALIA
Rather, ARGENTINA nn aw |
(UK. , . South island
802482 (RO2207) 1.97 j
:
:
2
BEST COPY AVAILABLE
67a
ah
re ~
Andros
San Salvador
Cay Sal Island
Bank Great Rum Cay
Havana (THE BAHAMAS) Exuma Long Island ‘Somena Cov
Guinchos Cay
Pinar (THE BAHAMAS) Crooked Island
nar
Cay Lobes RAGGED | Mayaguana
(THE BAHAMAS) RANGE Acklins Turks and
eo = felon Caicos Islands
(U.K.)
Mérida Cancun Isla de la G eat Ina a
° Juventud : gu Grand
Isla Turk
Cozumel!
es ''|...”__
Campecne
U.S. Naval Base . 8
_— de! MEXI CO p George Town, Cayman Islands Guantanamo Bay Cap-Haitien Santiago
armen (U.K.) HAIT| 7 DOMINICAN British
| Chetumal Virgin Is.
Montego Bay Port-au-Prince * sehen (U.K.) Anguilla (U.K.)
s Navassa Cayes Sant San Juan Virgin Is. Neth. St. Martin (Guad. and Neth. Antilles)
@viliahermosa island ° Domi vd 9 7 (U.S.) , Antilles St. Barthelemy (Guad.)
on Ci (U.S.) oe (NETH.)
belize City SWAN ISLANDS JAMAICA * Mona Puerto Rico — st croix Basseterra ANTIGUA AND BARBUDA
Tuxtla Flores % Belmopan (HONDURAS) (U.S.) — i - = fe . % St. John’s
_ Gutiérrez a Plymouth y
BELIZE ISLAS DE Montserrat (U.K.) $. Guadeloupe
_ LA BAHIA ie (FRANCE)
L Isla Aves Basse-Terre * Marie-Galante
Puerto : NEZUELA
GUATEMALA Barrios.” « * La Ceiba 7 DOMINICA
T - San Pedro tsi
= Itenango Sula oseau 7
(FRANCE)
Guatemala HONDURAS Fort-de-France ™
| Castries
Fvod st.won®','85dafd693f26cca2c25415145ad825538264105960009eb3b9c52e7b6a25f5ea','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0702d3689bf3c7d11e4634a19438974e49210e5435688ae5c7abe4da3afc4115',1996,'JP','Japan','space',920,'L kramne
( anada
Indian Ocean
Pacitic Ocean
\\lgeria
Russia
Pacitic Ocean
Bosma and Herz
<fFLSFSFFS 4 4LL4LL4L 4
Russia lok 1a to]','a8b8bc200211e514d954555d82c4149a602eec72cd3ea3f46b96c8cd1ec3294d','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4646e185fe23e0fe8d5ba70a739bda8e4d9cc42dc4f01fd054a3c6432dddbd1',1996,'LU','Luxembourg','space',921,'Philippin
Pacitic Ocean
Russia
Mac dul
\\arike
644
Entry in The World Facthook
Macedoma. The Former Yugoslav Republic of','eebd1da9f73ab094047678c37a1bdc4b2a787b4b8ddd75999f5fb640e6840dcb','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b943e6b90415d551c980431d4c032ef40d3805733e67ff2792af5f30fff39a0f',1996,'AU','Australia','space',922,'ltaly
Ponugal
Latitude Longitude
(deg min) (deg miu)
60 0O N 1 OO F
4450 N 119 3}
37 WN i400 fF
37 DON 11 201
31 30 N Is Oot
27 SON Sk OF
29 WN 4 OOF
1i7N 13 Sit
1ISN 14 OO |
4° WON ROH OM) E
17 29 N 6258 W
IS ON 6805 W
ST aN 9 OO]
41 SYN 21 261
Oos Ma 00 W
}2 MN Ss. 001
4241 N 23 191
6008 135 0]
KOOS 189 OO |}
KOOS sso}
12! 1K)
$8 S0.N 12 401
wos issoo Ww
OOO N bis oot
S415S 45 W
4200008 iy} OOF}
7 ON }>7 we}
Oil is mooW
woos wee Ww
s is, 6 fy web W
Ho? wos SU THEW
1 MON i Me}
1 >aweN\\ js (nH)
i400 N ix Od
SN | in) }
(MeN (yim) |
ooN mW
SS ISN ‘hom \\''
4 4ON “VA
7S “ar ie
Th wo init
Ss} 42S 1; W
SY OU N Sa]
48 55 iS]
iX 4h } }
iy 4? \\\\
yY SSN |
yiN }
fo0ON ni}
xSiweS\\ wil
om@s\\ wy}
mms Mint ie
i, is
his 1s 45 )
ISS iS |
hors N 12S 24]
OO N sooo W
IScxR Ss 178 OS]
S6 SON mi) Wi
Wosgs 71 is Vv
17 258 8356 W
ae is; rat
649
Nae
lahit lisiand
| yh
flamwan Stra
| nits]
Janvanvika
la
! iv
| Su
| ih i''s
ia
| \\
’ ’,
j ist
|
«
’
| \\ ‘
4
i (
[ q
j
|
\\
| _atitude
Fetry in The World Factbook ideg min)
French Polynesia 1737S
Taman 75 03 N
Pacihe Ocean 4 00N
bkMoma $9 D5 N
lanzama 6008
Morecce 38 48 N
Aunbats 1°58 N
Pacihe Ocean SOON
UL zbehisian 41 20 N
Australia 43008
Pacilie Occal 40S
Russia 76 WON
Georgia $1 43 N
Honduras 14 ti) N
iran 38 40N
israci 32 0S N
\\ntarctica bb OS
Pacihic Ocean hKOOON
Cireece 4) 38 N
Bhutan 27 OB N
CGarmans SPOON
Antarctica 72 OS
Isracl 32 48 N
China Yoon
Georgi 4) 43 N
(hina. As , SOON
\\ i (hy S4008
Vicwn y2 QIN
| YOOS
i {) roos
. NI Island ihsooN
| () SOON
\\ 4) OON
| 17 ON
i. hb ISN
ta ae, ©
i) ‘YOON
j mN\\
} i) ig) 74 \\
| yr OTN
j oN
i“moN
ss
} im WIN
,
i,
; \\
'' i''s
; j » \\
eN
"WN
» 5
im;
H14N
f iN
A INN
is iW N
\\ {) we aN
\\ my
() HiN\\
} sN
4 ‘ 4 |
| im VIN
\\tlontn ©} WoiN
Longitude
(deg min)
149 27 W
17) Moe
mvVoof
M451
soot
S45 W
PARLE:
i4t oot
Oy Ist
147 OE
lok OFT
Tie ete,
44 49 I
87 13 W
Si 261
44 48 1
iwool
Oopoaot
22 Sh I
RY Wi
ib oot
oo a W
48 34]
wiki |
44 49 I
wip cn) ft
ovo Ww
1701 W
iS im}
mae
145 381
M427 4
iV SOF
1) ot
m) 40 W
1 4h }
os (MT
yoTW
I4- iO]
f 46 W
iy is }
wi)
SIST
,imit
iW
si]
!
\\\\
+}
bin}
pind
eile
I
bi im)
mw
meow
j
"1
!
i]
Sined
fab inet
Lim):
} imo}
o4-W
1) ME
Pais
“
Name
Uderm (Udon Tham) (US Consulate]
( laanhaatar [US Enmohassy]
l lhung-de {island]
i nomak Pass [strait]
Umon of Sovect Socialist Republics (USSR)
lL aited Arab Republic (1 AR)
Lipper Volta
tral Mountain,
lL ssunm River
Vaduz [US post not mersianed
ncoh, Swrveriand|
Vakhan (Wakhan Cornndor
Valletta [US Enyhassy
Valley. The
Vancouver [US ¢
Vancouver Ishand
Van Diemen Strat (Osami Strait)
Vatican City [US Embassy!
Velez de la Gomera
Venda
Verde Island Passagc
Victona
Victona [US Embasss
Vienna [US Envhassy
mZavons m Viepna
Vientiane [US Enhas
Vilows [US kahasass
Viu Levu Iesland
Vladivostok [US Consulate Gener
Penon ck
UNVIb)
loan ishands
tok Island
“ & Ff
Yemen. Nort | Yeoemes
Yom Sanaa) | Yemer
Yemen, People''s Democratic Kepu
Yemen. South
\\V ib he
Democrats
Py 7D
cmysu late ( nn neral |
Arab Keopul
Ry
"
tS Missnon la) Internat “¥
representation trom Zu
Yorn
Entry in The World Factbook','d29f4aa7b0ff6ab4fbf0141fef55c8d2a6253a1ae1b5c430d07c9419051578d4','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cfaef2dc571261bc1775658c0fda8a70f19826c253f2a2c5afe036edec5727f',1996,'ME','Montenegro','space',923,'Monterrey) [US Consulate General |
Montevideo [US Embassy]
Montreal {US Consulate General, US Mission to the
International Civil Aviation Organization (ICAQO)|
Moravia [region]
Moravian Gate
Moroni
Mortlock Islands (Nomoi Islands)
Moscow jt ''S Embassy |
Mount Pinatubo
fozambique Channel
Mumbai [US Consulate General]
Munich [US Consulate General]
Musandam Peninsula
Muscat [US Embassy;
Muscat and Oman
Myanma, Myanmar
Nagorno-Karabakh [region}
Nagoya [US Consulate]
Naha [US Consulate General |
Nairobi [US Embassy |
Nampo-shoto [islands |
Naples [US Consulate General |
Nassau [US Embassy]
Natuna Besar Islands
N''Djamena [US Embassy]
Negev [region]
Negros [island]
Netherlands East Indies
Netherlands Guiana
Nevis [rsland}
New Britain [tsiand|
New Delhi [US Embassy
New Guinea
New Hebrides
New Siberian Islands
New Terntores
Ncw York New York \\{ S Mission > ih Lt nited Na
tions (USUN)|
Newtloundland |istand|
Niamey [US Embassy |
Nicobar Islands
Nicosia [US Embassy |
Nightingale Island
Nomot Islands (Mortlock Island
North Atlantic Ocean
North Channel!
North Frisian Island
North Island
North Korea
North Pacilic Ocea
North Sea
North Vietnam
North Yemen (Yemen Arab Repubh
Northeast Providence Channe!
Norther Epirus
Northern Grenadines
Northern Ireland
Northern Rhodesia
Northwest Passages
Norwegian Sea
Nouakchott [US Embassy |
Noumea
Novava Zemlya ''istands]
Nubia
Nuku alola
Nuevo Laredo [US Consulate |
Nuuk (Godthab)
Nyasaland
Entry in The World Factbook
Serbia and Montenegro','41be8cc601feee352a30b78ebd25c7235f9cdf3b41e02ac7eae54e053bce9a3a','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97bd67ab94680c6919c54dbf19c45dfa456415942af0da5e7384a086e4c3bf3f',1996,'VU','Vanuatu','space',924,'Russia
Hong Kor
hederated Stat iM
Lihania, € 9%
Sam Vincent and the Gre j
lL noited Kinedon
Jama
Arctee Ocean
Atlantic Ocean','c76a90bc895bd8e4aa55a644ddf87aa1884a1dc72c6b314ac86c624fc0d8a897','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e488d42437a6391eda618b62db10dc80d18f8fe0dded77133ee703b77e13bba8',1996,'MW','Malawi','space',925,'Latitude
(deg min)
55 44
15 O§8
yO
Ik SS
4K UW
26 1%
FFL LC LHL LL GL 2
SFL L 44 LL LL LF
120
4) 40
Ooo
\\ (nH)
at)
| (Wy
fy (th)
ane
Soos
4 im) 6
75 (4) S
i\\
443 N
(¥
\\
y
4
W \\
.
” \\
“
mamN
wy *
\\
“
is *
}
iu) S
i400 N
bo ON
ik (tH \\
if ‘
7400 N
“)49N
TOR SN
’ wyeN
64 11 N
| ws
Longitude
(deg min)
19 OO F
tows W
S611 W
334 W
17 OOF
7 505
43 161
1423 40 }
37 45 4
120 21
4] OOF
72 SOF
11 351
56 24 1
Sk 35}
57 OO f
YX OO) |
46 40 |
136 SS I
127 401
% 49 I
140 00 |
IS ISt
1 W
14) a)
IS Ost
+551
23 OT
iM}
56 (KA
f SW
wil
I
M) }
OH (ni
ie |
}
}
f \\A
\\\\
‘) |
wecwe WW
H (my
\\A
6 274
(Mm) I
‘tin
si2W
99 41 W
$i 44 W
LOO}
oS¥
Name
646
Entry in The World Factbook','f3be26fead5d35d10d0484533aa72f374da7ccb58d97d534e5bad566e7a3cc6e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1361deeba8251611dfb489d6c0ff5761b26f2d133ef5e9c4c44804c8434cb927',1996,'LV','Latvia','space',926,'Brasil
Miauritiu
Samt Kat
Saint Katt
Reumon
Crrenada
Atlantic Occan
J SLL 4Lh4LE LLL hL GS
7
“
vA 4.4.4
S 4S 4+. 4
is agitude
deg min)
SOO}
SsoOoW
26 O} |
los 19 I
16 5S
21 001
31 W
28 101
ITO 00 W
fy"
im"
‘KO
yiyW
Latitude Longitude
(deg min) (deg min)
amt Helies Jersey ?! 237 W
aint Jolin’s Anugua and Barbuda | 6151 W
saint Lawrence. Gull of Adantuc Ocean 48 OO N 6200 W
aint Lawrence Island United States 49 WON 67 0O W
unt Lawrence Scaway Adantuic Ocean 49 15 N 67 00 W
unt Martun {island} Guadeloupe Ik OF N 6304 W
unt Martin (Sint Maarten) Netherlands Anuille IS OF N 6304 W
amt Paui lsiand Canada 47 }? N 60098 W
N
S
N
Name Entry in The World Factbook
saint Paul Island United States 57 11 W016 W
unt Paul Island (tle Saimt-Paul) French Southern and Antarctic Lands 3K 43 77 Wt
Saint Peter and Sami Paul Rocks (Penedos de Sao Pedro — Brazil 23
Sao Paulo)
2Y23W
imt Peter Port Guemscy
nt Petersbur onsulate General} Russia
t-Prerr Saint Pierre and Miquelon
Thy is | ISK Virgin Islands
Vincent ISSCC Adlantic Ocean
Northern Mariatia islands
Ccunrgia
Lathuania
Turkic mista
651
Latitude
ideg min}
“4+#F
S#4LbLbbhé4¢
an an an 4
FA
4
,
“
longitude
ideg min)
li? 46 |
lH SS t
1M) S2 |
Ind SOW
ime Ww
fai ind}
so}
Out
Tin
+4
Hsia W
{ \\\\
OO W
ni}
7 |
+; is W
nit
I
109 |
S< }
fy >|
; i}
|
nit
!
HiT
\\\\
\\\\
iim}
bin}
,im]
ify (wT
WT
Name
\\
Yon
Yuc
Yuk
a
''
LS bahay
Isle of (isla ck
» ''
loll Pen Tisalid
eb [US Embasss
Nar fishand
Viount
LS
consult
¢ lsenera
ty
;
Eniry in The World Factbook','23c38ba5fccc36f00a1f2d9346a06598eb574cd4eda563ecf96431647b8056ec','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9ffbf3287d589ec1da64399c2b5db838fff065ccce7e3d2d3d62a946087a866',1996,'TH','Thailand','space',927,'ye -
Name
Siberna [region]
Sibutu Passage
Sicily [island]
Sicily, Strait of
Sidra, Gulf of
Sikkin. [state]
Sinai Peninsula
Singapore [US Embassy]
Singapore Strait
Sinkiang (Xinjiang)
Sint Eustatius [island]
Sint Maarten [island]
Skagerrak [strait]
Skopye [US Liaison Office]
Society Islands (iles de la Societe)
Socotra [island]
Sofia [US Embassy}
Solomon Islands, northern
Solomon Islands, southern
Solomon Sea
Songkhla [US Consulate]
Sound, The (Oresund)
South Atlantic Ocean
South China Sea
South Georgia listand]
South Island
South Korea
South Orkney Islands
South Pacific Ocean
South Sandwich Islands
South Shetland lands
South Tyrol [region]
South Vicinam
South Yemen (People’s Democratic Republic of Yemen)
South-West Africa
Southern Grenadimes
Southern Rhodesia
Soviet Union
Spanish Guinea
Spanish Morocco
Spanish North Atneca
Spanisin Sahara
Spice Islands (Moluccas;
Spiisbergen [island]
Stanley
Stockholm [US Enbassy |
Strasbourg [US Consulate General!
Siutigarnt [US Consulate General}
Sucre
Suc7 Canal
Sucz, Gull of
Sulu Archipelago
Sulu Sea
Sumatra fisland!
Sumba {island
Sunda Islands (Soenda Isles)
Sunda Strain
Surabaya [US Consulate General
Sungao Strat
Surnmam
Suva [US Embassy]
Sverdlovsk (see Yekatermburg)
Swains Island
Swan Islands
Sydney [US Consulate General]
Entry in The World Facthook
Russia
Pacific Ocean
Atlantic Ocean
Atlanic Ocean
Pacilic Ocean','f636b3ef7d49696955b2f6df7ec77f59959d78482f311f610c5d0dd879ba61bc','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1c765e1b08302406acab89dd5069099788801f40d4dfd97d30b1158840bc466',1996,'MA','Morocco','space',928,'Spain (Ceuta, Islas Chatarmas, Melilla, Penon ck
Alhucemas, Penon de Velez de la Gomera)','34bdabd45b8ac96c4fc6cc21cbd16a7a1713ce3e298e5f81314c87dda8f4dcc5','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cbd19d86409822482e76ce09e30324410d258551fbde1294ba7b54767de6914',1996,'AM','Armenia','space',929,'( ubha
Vik \\a0)
Ailanic Occan
Bosmia and Herzegovina
Yugoslas Republic of
Montenegro. Slovenia
Croatia: The Former
Macedoma: Serma and
infin jordan
SM iivetiand
Latitude
ideg min)
wWiiN
2140 N
iS WN
2145 N
45 48 N
6 iS
4] 46 N
47 23.N
Longitude
ideg min)
44 WE
8250 W
S900 W
8545 W
66/
North America
wy t
.
Leahy
*
RUSSIA *®e oT.
“\\ Aer
a CU msegeetrocn. ©
Scteesiytur ¢ Le
a acyre ° >
Providenrya® y eu" . Yese’ 2
bile anos ay
eect = an . .
erome & @ Bay '' : Aaeetussag
> Keue woe Sendre Stren tjo@h
. Bants esau» . P
isan 1 << ¢
| _
». L_ UNITED. STATES ‘ Goode
- ‘ Betta . * —
Bemre! , 7 Victoria * .
onets. P ite keland eed Pas ,
; | Bay a . 4 er.
“y ” hanes > — |
Ag yh gValder ‘; oon Reps Bay, *Fropester Bay
+e Kod a ™ x, a Eche Bay . - . j
''
: — Rang beg ,
a ate y Rare niet,
a
an
CANADA ox
my Yer? Nappy Valley.”
xe oe Goose Bay g
eee, ae
Wense, aia *
UNITE Dew Doe |
> ° 7 . |
e- . :
. .
* STATES . |
. = . ’ : . | |
oo '' - |
“=, ~ ’
. \\ . . THE BAHS VAS
e NnuTrO™~ . ; “
—
‘MEXICO . , >
. .
d AMA A
» ae ta! a. be sa
Lambert Conforrma/ Conec Proyection , Mexeo™ e © > we ire
standard paratiels 37 N and 65 .N ‘ ant & t
’
wero « ;
wy a™) * wrer ; AS
° 0 neter i @ ; HOUND RAS?
ux rw) Vides e ie |
aoe , . |
¢ /* MPARAGLA
sn comaeinie GUATEMADA. Feat
ecessartily aut? tal ve - —_ a
- . .
14 1x fi SALVADOR * .
BEST COPY AVAILABLE
South America
ne 80 Marunaue (FRANCE) 60 40
HONDURAS } } ST. WC
ronounas oe Ista We Caribbean saul a ed ST. VINCENT AND 7 | _aanmanos |
* San Andres (NETH.) _ (NETH.) GRENADINES
( : ~~) . GRENADA . ;
North
Atlantic
om
Cucuta
Barranquilla
et | -
?
Medeilin
Ocean
1
/
} ta
s''a de Malpelo z { wx 5200
H COLOMBIA) ali =
« ./ COLOMBIA
Y JS
Equator 7
¢ |ECUADOR
2
South 0
, ° | Pe i A gcuiada f Brasilia |
Pacific > ? lity, =i |
. BOLIVIA d I cating |
e / i,
, <
O Cc e an Cochaba “Santa Cruz ’ © j
— A Belo
_— Voeriandia {Horizonte ||
- - - @ f Vitor i eee
- e/ we | oo]
< \\ ew ’ |
Antotag " sa -
craic CANOE 0 el
tsia San Ambrosio
Isia San Félix “\\* ‘ ’
(CHILE)
CH Porto Alegre = /
A 4
‘ 4 |
Valparaiso
ARCHIPIELAGO . 4 S OU t h
JUAN FERNANDEZ ‘|
(CHILE) .
La Plata ’ ;
Montevideo Atlantic
Mar de! Plata O Cc e a n
/
\\ i
—$$$— j
+ eee Sa
| —o, —
= | “B80.
|
/
/
j
/
.
Scale 1:35,000,000 /
Azimuthal Equal-Area Projection Stanley /
Falkland Islands
PE wconmmany a /
9 590 Miles (administered by U.K., South Georgia and the
claimed by South Sandwich Isiands
Boundary representation is (administered by U.K.,
not neceasaii''y author tative claimed by ARGENTINA)
100 0 4 2°
802472 (RO2108) 1-97
BEST COPY AVAILABLE
Ocean
Jan Mayen
(NORWAY)
(DENMARK)
SHETLAND
‘3
Rockall \\
(UK) hs
ums fo f=
= ss we
Aj - . * * -«
North Pig 7
th
/ - ~ + ‘ Avs ¥
Atlantic > -
FACS)
se
2)
Seria and Montanegro have asserted the formation
of 2 jownt incepencent state. but Tes entity has
not been tormaily "ecagnizec as 2 state Dy the
Unded States
FYROM - The Former Yugosiav Repub. of Macedone
> on =<" Sardinia
BALEARIC '' Sea
>
St. Petersburg
RUSSIA
BEST COPY AVAILABLE
ISLANDS \\ @ >€4
‘\\) Cagtian — % 7
. Palermo Cn . £0 e
Mediterranean Sea . Sea Ae eae
. Sicily - Rhodes
Agere sy ,
* ‘ ~_~ghl - Ay . Crete
. 7 Scale 1: 19,500,000 naomi
\\ mata® Lambert Conformal Conic Projection,
~ standard parallels 40 N and 56 N
ALGERIA — a
i? 0 300 Miles
-
802473 (RO1083) 1','6a55b53ec9bf49240fd9f76db29f1c20ba5784369118066167ed01b39610a275','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a76490c3420dbb6501fe05abb7539d6e1e765689e84487fd551dc091675f9c1e',1996,'BA','Bosnia and Herzegovina','space',930,'Las f = =
| SLOVENIA
Zagreb >
La AS
. Cc
| & A BR \\ a eon,
v oe %, “ Voj ip
i . Osiyek \\* Tis@- Dy iy
} Ka a es Ne, oe
- op CROATIA tN
| Vukovar, | <
Novi Sad | &
Slavortski ™ eX. “ees \\ ly
/ Brod Federation of Bosnia “Danube \\ Ny
\\ Save 2 and Herzegovina \\
y Ruma, 2 ,
( y ° = a \\
8 on™ ne \\
\\
» Bing Republika Srpska Brcko / Belgrade 3
. Bania Luka The status of Brck ‘
sa — ; tinct - S, » /
D OD e . = Bijeijina Sabac® <te ~~
ber-Entit 1 ~~ *
Giy Line UE BL \\ os
2, K Tuzla |
2,
A N D :
. Zenica*\\— S e r b | a
a Srebren ca,
HERZEGOVINA | .
Zepa® ?
Sarajevo \\ Uzice
* fale °
_ oie Federation of Bosnia
| and Herzegovina Gorazde +
Spi
Mostar, \\
ros 8 e
Republika
Srpska ; .
Otok Hvar ry 4
‘ ~~
'' af ,
Otok Korcuta “Pica
| .
| Montenegro c
* Nikéic : ~
a 7 Kosovo
Dubrovnik n_4
Adriatic ? Podgorica
Scale: 1:2,270,000 Sox ® that *
ymbert Contormal Conic Projection,
Standard parallels 40 N and 56 N S e a , tLeke
Knoneters Scutar:
—— ALBANIA
( les é Se
cm Bar \\ __ Shikodér | 424
ue ex a , 20
eB Za “Pécs 4 \\ af ren —
E HUNGARY
| \\¢
802474 (RO2172) 1.97
BEST COPY AVAILABLE
66S
oor —= -
* Krasnodar
EGYPT a
Yanbu’
al Bahr eMedina
°
re Adrunestrate r7
oe
: Jiddah » e
Mecca
RUSSIA
Ha
rh
Grozny 4
An Nasiriyat®
Al Basrah®
*Hatar
a! Batin
A! Jubayle
Ad Dammam Manama
qourayaan — "s * ’ an
BAHRAIN’ QATAR Dubai,
SAUDI *
ARABIA
~
«i Port Sudan
: ghbha s
SUDAN é
rf
Omdurman,
rf ee hie 41 Ghaydan,
Wad . plain aaa ‘ hian Co;
> ~, r ; Pi 7 4
» Madar.: YEMEN ‘ | abian Sea
P “ an ¥ ¢ Al Mukaila
= of
2 5 ; a Be ss
= a Gust of A Socotra
= ; (YEMEN)
-10——_ Scale 1:21,000,000 \\
Lambert Conforma! Conic Projection,
standard parallels 12°N and 38°N
Addis Ababe SOMALIA
0 300 Kilometers +
fatty
4 ; * Israeli occupied with current status subject to the Israeli
Bou ; is a , . Palestinian Interim Agreement -- permanent siatus to be
30 not necessarily authoritative. 4 aeaenenes , . determined tnrough further negotiations
.
802475 (RO2107) 1-97
BEST COPY AVAILABLE
:
jeigad PORTUGAL
AZORES
PORTUGAL Lisoon *
Nouatin tx','740ba0dc4a6c131081097d07adff86ea9dddbbf9c61e0c3cd385da6081ab95ed','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('447ea5543d29eb5282aa68fa4601d94cbf12166e15edab86b325a68d30305a32',1996,'MR','Mauritania','space',931,'« CAPE VERDE * Nouakchott
Brae
‘* Dakar
% SENEGAL
Bani
THE GAMBIAL Bamako
Bissau
GUINEA. BISSAU * GUINEA
Conakry
Freetown
SIERRA LEORE
Monrovia
UBER
Ascension
St Helena
UK)
Scale 1:51,400,000
Azimuthal Equal-Area Projection
800 Kilometers
} rm - ai. —
0 800 Miles
A
Boundary representation is
not necessarily authoritative
a\\
ae
SPAIN ‘ Saraima
Algiers Tun
_* ~ ey
ISIA
Constanti
Annobon
(EQUA. Gul.) \\
Brazzaville
oe al','8dc72030a39df23d0d0e61274b4403967ad704e26209c345d91c17f04ed21160','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36ee64c6eb7d13cec8bf33f894539d1c3e1300217c2d53c8dfd2118341c7a8ea',1996,'NA','Namibia','space',932,'ALY
\\ | AFRICA
;
d
Cape Town) ion ee”
aL— Port Elizabeth
Indian
4
adem by France
tener ty Como
) de Nova island @
(FRANCE)
Toamasina
°
Ocean
Mahajange','9bbb03a8c5bf6c9f836babb2b510e14e06a06936ac5ade6b063655eaecab033e','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bf117f22c2b8ede5e873293af9361da6139d68a7351924c92557201ec7fc696',1996,'SC','Seychelles','space',933,'60
BEST COPY AVAILABLE
802476 (RO2109) 1-97
667
——aEeEeEeEeEeEEeee————ee
Woe
§© 0 100 120 =
fy \\
aa Ocean
NOVAYA
ZEMLYA
\\ | - ° ™,
/ 180
, ~“
Bering
Sea
Azimuthal Equal-Area Projection
0 800 Kilometers Indian
oO 7 1
ae Ocean
Boundary representation is
802477 (RO2105) 1-97
SEST COPY AVAILABI !
668
Commonwealth of Independent States
— ,
”" = T . eee —
of . Scale 1:20,700,000
- SWEDEN , hg engeres Lrecheng ” Lambert Conformal Conic Projection,
Standard parallels 47 N and 62''N
; ) 300 Kilometers
} ; ‘ = i - ‘t 4 -
0 300 Miles
Boundary representation is
not necessarily authoritative
™“
~~“... _— Krasnoyarsk 7
RUS S I A- ,
Ka mingra ; .
5 @ Kemerovo ‘
e {
Yaroslavl Permi<¢ @ Novosibirsk Novokuznetsk
— .
Moscow Nizhny Vehkaterint
* y!Novgorod On, os 9B amaui
- ; @ Omsk
an
Ryazan * -
st se uv - Chelyabinsk
7
jta
Wya vk e
Paviodar®
ePenza a ol''yatt 9 eostanay
@ oamafa
Voronezh 4
. 4
;
@hamola ‘ .
tat v Orer burp ,
Kharkiv . id @ *
@ Garaghandy
Dnipropetrovs’k
Kryvyy Rih,
phvsoiayn Zaporizhzhya
. ae VO)pOgeec
‘ Conets’k® we
—— Baiaas:
Mariupol, - . ‘
~e 2. = , *" “‘“¢ a
e ® me «
Constanta P ons Saryshaghan Taldyyorghan®
fi
BULG. Sevastopo!, 7 ah tyrau A
Krasnodar Astrakhany ;
~ ‘ '' A ty
« Beyneu > 9 2yzylorda
qtanbu ° wy
"Bursa Sokhumi®
SaMSUN »
; @hatau
Shymbent
Ankara
* Bat''umi Tashkent','b92d727cbe47ee8378d4fcd36409d9fde67a11deb474b54b261e8992861cc4b1','internet-archive','cia-reports_prex-3151996','txt','8fe14304788da05fd9dc5d22ef0cfc0758f725f5537aad47c0459b41bae1995b','https://archive.org/download/cia-reports_prex-3151996/cia-reports_prex-3151996_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6af06fd3137cde6c6270997de1063693ef2aa59bbddb9d4e06d0eee517c68a47',1972,'','','communications',5,'Ratlroads: 4,991 mi.; 4,940 mi. 4''8 1/2” gage, 5] mi, double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 402 mi.; refined products, 1,277 mi.
Ports: 10 major, 35 minor
Merchant marine: 88 ships (1,000 GRT or over) totaling 596,300 GRT, 829,500 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 11 bulk, 2 specialized carrier
Civil air: 17 major transport aircraft
Airfields: 119 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 18 with runways 8,000-11,999 ft., 25 with runways
4,000-7 ,999 ft.; 2 seaplane stations
Teleconmunications: excellent international radioconmunication and fair domestic
telecommunication services; 577,000 telephones; 3.1 million radio and 50,000
TV receivers; 39 AM, 2 FM, and 7 TV stations; communications satellite ground
station to be operational in 1972 .
DEFENSE FORCES:
Military manpower: males 15-49, 9,585,000; 5,655,000 fit for military service;
about 402,000 reach military age (20) annually
Personnel: army 375,000 navy 39,500, air force 54,600 (1,082 pilots),
gendarmerie 75,000 (S)
Major ground units: 3 armfes, 10 corps with corps troops, 13 infantry divisions,
2 mechanized divisions, 1 mechanized brigade, 1 armored division, 4 separate
armored brigades, 2 armored cavalry brigades, 4 infantry brigades, 2 regiments
(1 border, 1 armored cavalry), 32 battalions (20 artillery, 11 border, 1 on
Cyprus), and 1 commando brigade; army aviation companies with about 5 aircraft
each are assigned to each army, corps, and divisfon
438
Seca
‘Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
SECRET
DEFENSE FORCES (cont''d):
Ships: 15 destroyers, 1 destroyer escort, 16 submarines, 71 patrol craft, 33
mine warfare, 62 amphibious craft, 38 auxiliary, 47 service
Aircraft: 1,223 including 428 (nonjet) in army aviation, 4 (nonjet) in naval
air, 791 (602 jet) in air force
Missiles: 8 SAM squadrons (Nike Ajax/Hercules)
Supply: mostly dependent on foreign sources, primarfly U.S., Canada, and West
Germany; manufactures some smatl arms, tru adequate quantities of
ammunition; builds some of its naval ships
Military budget: for fiscal year ending 28 February 1973, $599.7 million;
about 19% of central government budget
INTELLIGENCE AND SECURITY:
National Intelligence Organization (MIT), including Turkish National Security
Service Directorate (TNSS), domes tic/foreign; Turkish General Staff, J-2
Section, Intelligence Branch, domestic/foreign; Turkish National Police,
domestic; Ministry of Foreign Affairs, foreign; Gendarmerie, domestic
439
Approved for Release: 2018/04/27 C06726997','c7a3c13800a7f80209df199f4e15cd31ac06b3366a1526781ce16a01816910d3','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94230ac2827a37eedad221dbcd62accf89c3de114e66ab3ed4edc84862fcf113',1972,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track: 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. grave? or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annual ly
78,000) ee navy 39,500, air force 54,600 (1,082 pilots), gendarmerie
75 ,000
Major ground units: 3 armies, 10 corps with corps troops, 13 infantry divisions,
2 mechanized divisions, 1 mechanized brigade, 1 armored division, 4 separate
armored brigades, 2 armored cavalry brigades, 4 infantry brigades, ] border
regiment, 34 battalions (22 artillery, 11 border, 1 on Cyprus), and 7
airborne/commando brigade; army aviation companies with about 5 aircraft
each are assigned to each army, corps, and division
Ships: 13 destroyers, 12 submarines, 71 patrol » 28 mine warfare, 60
amphibious craft, 40 auxiliary, 47 service
Aircraft: 1,252 including 437 (nonjet) in arny aviation, 15 (nonjet) in naval
air, 800 (605 jet) in air force
Missiles: 8 SAM squadrons (Nike Ajax/Hercules)
Supply: mostly dependent on foreign sources, primarily U.S., Canada, and West
Germany; manufactures some small arms, trucks and adequate quantities of
ammunition; builds some of its naval ships
448
““SECRE
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
_ SEsRET,
DEFENSE FORCES (cont''d):
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
INTELLIGENCE AND SECURITY:
National Intelligence Organization (MIT), including Turkish National Security
Service Directorate (TNSS), domestic/foreign; Turkish General Staff, J-2
Section, Intelligence Branch, domestic/foreign; Turkish National Polf
domestic; Ministry of Foreign Affairs, foreign; Gendarmerie, domestic
449
Approved for Release: 2018/04/27 C06727039','9d4a2b2fc51ea58b3df2ca018de5da87ff79463fa05f18e4af69d388d6b68cd4','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93820c38796a35554263f5facaa4afa0ca0767f5cfe581d494230299c0f1b038',1972,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi1, 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DHT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4 ,000-7 ,999 ft.; 2 seaplane stations
Teleconmunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annually
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
346
Approved for Release: 2018/04/27 C06726998','3f12afb7679ed6d6fbd9995b63f1709fd9f751fa11e529d9e6974f040abec1d6','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c630d91bf5fd6d4ca8b80211a730770f2aaab3c2e748bcb3922611dddfcecd80',1972,'AF','Afghanistan','communications',5,'Railroads: 6 mi. (single track) 5''O"-gage, government-owned spur of Soviet line
Highways: 10,740 mi.; 420 mi. concrete, 980 mi. bituminous surfaced, 2,100 mi.
gravel, 3,630 mi. improved earth, and 3,610 mi. unimproved earth
Inland waterways: total navigability 760 mi.; steamers use Amu Darya
Ports: only minor river ports
Civil air: 7 major transport aircraft ''
Airfields: 64 total, 35 usable; 9 with permanent-surface runways; 7 with runways
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.
Telecommunications: limited telephone, telegraph, and radiobroadcast services,
barely sufficient to meet civil and military requirements; 13,967 telephones;
est. 400,000 radio receivers; no TY receivers; 1 AM, no FM, no TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1972, $32.2 million; 19.2%
of total budget
2
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
meget:
sw sae WE octal
SS ae guerre eatin :
wt ats ae dn i an 8
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','c1222711199de7b0f9ecb8af8aa1ca8b87a4478c6d667c06373979ed995ad761','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cac27c2fb378611f1a6be8b4ffbdd593b4740c0df1998c56ed2d2dc0462f54e6',1972,'AL','Albania','communications',6,'LAND:
11,100 sq. mi.; 19% arable, 24% other agricultural, 43%
forested, 14% other (1967)
Land boundaries: 445 mt.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 225 mi. (including Sazan Island)
Railroads: 127 mi. standard gage, single track; government owned (1972)
Highways: 3,100 mi.; 300 mi. paved, 1,200 mi. crushed stone and/or gravel, 1,600
mi. improved or unimproved earth (1972)
Inland waterways: 27 mi. plus Albanian sections of Lake Scutari, Lake Ohrid,
and Lake Prespa (1972
Freight carried: rail -- 2.8 million short tons, 109.6 million short ton/mi. (1970);
highways -- 31 million short tons, 519.9 million short ton/mi. (1970)
Pipelines: crude oi], 110 mi.
Civil air: no major transport aircraft (1972)
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, 588,000,000 leks;
about 8.7% of total budget
4
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
x
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','e854b89f2ed2eba38028b459ada9006a6de5648c55837fcace1d99903e19f6ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6f1faa28d6e5d6bd0a3d1269a71823986922578181f28b7a2f6ab64882a9054',1972,'DZ','Algeria','communications',10,'LAND:
950,000 sq. mi.; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban (1967)
Land boundaries: 3,890 mi.
WATER: ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 735 mi.
Railroads: 2,414 mi.; 1,660 mi. standard gage, 663 mi. 3''5 9/16" gage, 91 mi.
meter gage; 188 mi. electrified; 120 mi. double track
Highways: 40,600 mi., of which 17,000 mi. are concrete or bituminous and the
remainder gravel or crushed stone
Ports: 9 major, 8 minor
Pipelines: crude oil, 2,251 mi.; refined products, 177 mi.; natural gas, 494 mi.
Civil air: 22 major transport aircraft
Airfields: 240 total, 194 usable; 55 with permanent-surface runways; 18 with
runways 8,000-11,999 ft., 112 with runways 4,000-7 ,999 ft.; 3 seaplane
stations
Telecommunications: adequate domestic and international facilities in the north,
primarily radio communications in the desert, 182,000 telephones; 1,150,000
radio receivers; 250,000 TV receivers; 16 AM and 13 TV stations; 3 submarine
cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, $108,200 ,000;
approximately 5.5% of national budget
6
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: 25,368 mi.; 23,615 mi. standard gage, 1,753 mi. other gages (3'' 3 3/8"
to 4'' 9 7/10"); 5,784 mi, electrified, 9,892 mi. double or multiple track
Highways: National, Departmental, and Communal roads total 487,600 mi. comprising
292,600 mi. paved, 190,000 mi. crushed stone and gravel, and 14,600 mi.
improved earth; in addition, there are approximately 434,000 mi. of local
farm and forest roads
Inland waterways: 9,320 mi.; 4,820 mi. heavily traveled
Pipelines: total, 10,000 mi.; crude of], 1,400 mi.; refined products, 2,700 mi.;
natural gas, 5,900 mi.
Ports: 22 major, 165 minor
Civil air: 273 major transport aircraft 7
Airfields: 510 total, 418 usable; 158 with permanent-surface runways; 1 with -
runways over 12,000 ft., 20 with runways 8,000-11,999 ft., 127 with runways
4 ,000-7,999 ft.; 10 seaplane stations
Telecommunications: highly developed system provides satisfactory telephone,
telegraph, telex, facsimile, and radio and TV broadcast services; 9.5 million
telephones; 16 million radiobroadcast receivers; 11 million TV receivers:
countrywide AM, FM, and TV service including 40 AM, 60 FM, and 40 primary
TY stations; 25 submarine cables
106
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, $6.1 billion; about
17% of central government budget
107
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: none
Highways: 19 miles, all paved
Ports: 1 major
Civil air: 1 major transport aircraft (registered in U.K.)
Airfields: 1 permanent-surface runway, 4,000-7,999 ft.; 1 seaplane station
Teleconmunications: international radiocommunication facilities; automatic
telephone system serving 5,600 telephones; 6,000 radio receivers; 6,600
television receivers; 1 AM, 1 FM, and 2 TY stations; 14 submarine cables
DEFENSE FORCES:
Defense is responsibility of United Kingdom
Aircraft: small detachment of fighter/trainer aircraft (3-4)
124
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: 10,570 mi.; 8,507 mi.; (5''6" gage), 2,063 mi. other gages
(4''8 1/2" to 1''11 5/8"), 1,309 mi., double track; 2,317 mi. electrified
310
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Highways: 83,080 mi.3 national -- 24,800 mi., bituminous, 22,940 mi. crushed
stones. provincial -- 32,860 mi., 80% crushed stone, 20% paved; 2,480 mi. other
Inland waterways: about 650 mi.; of minor importance as transport arteries and
contribute little to economy
Pipelines: crude oi], 230 mi.; refined products, 515 mi.; natural gas, 3 mi.
Ports: 23 major, 20 minor
Civil air: 161 major transport aircraft
Airfields (including Balearic and Canary Islands): 118 total, 78 usable; 42
with permanent-surface runways ; A with runways over 12,000 ft., 17 with
runways 8,000-11,999 ft., 36 with runways 4,000-7,999 ft.3 5 seaplane
stations
Telecommunications: modern, well engineered, well maintained; 4.5 million
telephones; 5.5 million radio and 4.5 million television receivers; 190
AM, 40 FM, and 27 TV stations with numerous FM/TV repeaters; 15 submarine
cables; 3 communication satellite ground stations
DEFENSE FORCES:
Military budget: for biennium ending 31 December 1971, $1,255 million; 23% of
central government budget
31]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
SPANISH SAHARA
D:
103,000 sq. mi., nearly all desert
Land boundaries: 1,296 mi.
WATER:
Limits of territorial waters (claimed): 6-n. mi.
(fishing, 12 n. mi.)
Coastline: 690 mi.
Railroads: none
Highways: 3,790 mi.; 305 bituminous treated, 3,485 mi. unimproved earth roads
and tracks
Ports: 2 major, 2 minor
313
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Airfields: 25 total, 17 usable; 3 with permanent-surface runways; 5 with
runways 4,000-7,999 ft.
Telecommunications: telephone poor, telegraph poor to fair; 540 telephones;
1,500 radio receivers; 1 AM, no FM or TV stations
314
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
SRI LANKA (formerly Ceylon)
LAND:
25,300 sq. mi.; 23% arable; 20% desert, waste, or urban;
54% forested; 3% inland water (1968)
WATER: wileray/
Limits of territorial waters (claimed): 12 n. mi. ao
(fishing, 12 n. mi.)
Coastline: 835 mi.
Railroads: 938 mi.; 851 mi. 5''6" gage, 87 mi. 2''6" gage; 63 mi. double track;
no electrification; government owned
Highways: 25,580 mi.; 11,700 mi. paved (mostly bituminous treated), 11,500 mi.
crushed stone or gravel, 530 mi. improved earth, 1,850 mi. unimproved earth;
in addition several thousand mi. of tracks, mostiy unmotorable
Inland waterways: 270 mi.; navigable by shallow-draft craft
Ports: 3 major, 9 minor
Airfields: 17 total, 13 usable; 13 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: an inadequate telephone and a less extensive but more
efficient telegraph system serves most areas, with greatest concentration
around Colombo and Kandy; all areas are served by radio and/or wire
broadcast; excellent international service; 62,954 telephones; 500,000 radio
sets, no TV sets; 1 AM (plus 4 repeater stations), no FM, and no TY stations;
submarine cables extend to India, Malaysia, Seychelle Islands, and Aden
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, $31.6 million, 3.1% of
total budget
316
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','23f72bc5820b1d15aa77403d6915191a6a358ccfb5a95415700ef24b91f6e5aa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2341ad8a00a29e56923558115fed9c4f384b51f6087c97dd335619dc8800a260',1972,'AD','Andorra','communications',14,'LAND:
180 sq. mi.
Land boundaries: 65 mi.
Railroads: none
Highways: about 60 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 2 AM and 1 FM radiobroadcast facilities, 1 TV repeater
station; manual telephone system serving about 1,700 telephones; 8,000
radio receivers, 2,500 TV receivers
7
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
DEFENSE FORCES:
Andorra has no defense forces; Spain and France are responsible for protection
as needed
8
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','45970c6cebb9aa7d8b2868c582f5548d8472f15747671d21f8f6fe7520f40c10','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc7f3fe096ce542be5364d2f1d10c921dc258142b9ca4413e0dafff65ec5e5af',1972,'AO','Angola','communications',18,'LAND:
481,000 sq. mi.; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow) (1965)
Land boundaries: 3,150 mi.
WATER: .
Limits of territorial waters (claimed): 6 n. mi. (navy)
(fishing 12 n. mi.)
Coastline: 1,000 mi.
Railroads: 1,918 mi.; 1,724 mi. 3''6" gage, 194 mi. 1''11 5/8" gage
Highways: 29,000 mi.; 3,000 mi. bituminous-surface treatment, 1,000 mi. crushed
stone or gravel, 25,000 mi. earth
Inland waterways: 2,000 mi. navigable
Ports: 3 major
Pipelines: crude oj], 111 mi.
Civil air: 12 major transport aircraft
Airfields: 454 total, 394 usable; 19 with permanent-surface runways; 1 with
runway over 12,000 ft., 5 with runways 8,000-11,999 ft., 56 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: simple network of low-capacity open-wire and radio-relay
facilities; 25,300 telephones; 95,000 radio receivers; 2] AM, 7 FM, and no
TV stations
DEFENSE FORCES:
Defense is responsibility of Portugal
Supply: dependent on Portugal
Military budget: for fiscal year ending 31 December 1971 $64.17 million; about
17% of total budget
10
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ANTIGUA
LAND:
108 sq. mi.; 54% arable, 5% pasture, 14% forested,
9% unused but potentially productive, 18% wasteland
and built on (1964)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 95 mi.
®
VENEZUELA','c697618e114b848eb1c004947553aec9b230e075cb08215b891c26cc6f410fb6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d32593becde71bb81b89d3ba26a35efd3adeb9f65e035cbd9b1c37b4c58bb767',1972,'BR','Brazil','communications',27,'Railroads: none
Highways: 235 mi.; 150 mi. main, 85 mi. secondary
Ports: 7 minor
Civil air: 8 major transport aircraft
Airfields: 3 total, 1 usable; 1 with asphalt runway 9,000 ft.; 1 seaplane
station
Telecommunications: new automatic telephone system recently installed; 2,500
telephones; tropospheric scatter links with Tortola and St. Lucia; 5,000
radio receivers, 1 AM and 2 TV stations; 2 coaxial submarine cables
12
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: none
Highways: 555 mi.; 380 mi. paved, 100 mi. gravel, 20 mi. improved earth; 55 mi.
unimproved earth
19
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Ports: 5 major, 9 minor
Civil air: no major transport aircraft registered, 2 on lease from U.K.
Airfields: 56 total, 53 usable; 17 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 23 with runways 4,000-7,999 ft.; 4 seaplane
stations
Telecommunications: telecom facilities highly developed, including 43,850
telephones in totally automatic system; tropospheric scatter link with
Florida; 55,000 radio receivers and 16,000 TV sets, 1 AM station; 2 special
coaxial submarine cables; plan TV station for color broadcasts and new cable
connection with the United States
20
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: none
Highways: 950 mi.; 800 mi. paved, 100 mi. gravel, 50 mi. improved earth
Ports: 1 major, 2 minor
Civil air: 1 major transport aircraft
Airfields: 1 with permanent-surface runway 8,000-11,999 ft.; 1 seaplane station
Telecommunications: islandwide automatic telephone system with 29,000
telephones; key international traffic transit center for Caribbean area;
tropospheric scatter Jinks to Trinidad and St. Lucia; 86,000 radio and
16,000 TV sets, 2 AM and 1 TV stations; 2 telegraph submarine cables; planned
construction of satellite earth station to be operational in 1972
26
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: 2,310 mi., single track; 2,290 mi., meter gage, 20 mi., 2''6" gage;
all government owned except 60 mi. of meter-gage track; 5.6 mi. of meter-
gage track electrified
Highways: 15,900 mi.; 600 mi. paved, 7,200 mi. gravel, 1,600 mi. improved
earth, 6,500 mi. unimproved earth
Inland waterways: officially estimated to be 6,250 mi. of commercially
navigable waterways
Pipelines: crude oi], 1,044 mi.; refined products and crude 888 mi.; natural gas
20 mi.
Ports: none (Bolivian cargo moved through Arica and Antofagasta, Chile, and
Matarani, Peru)
Civil air: 28 major transport aircraft
Airfields: 500 total, 432 usable; 3 with permanent-surface runways; 1 with
runway over 12,000 ft., 3 with runways 8,000-11,999 ft., 91 with runways
4,000-7,999 ft.
Telecommunications: poorest telecom facilities on continent with local and
intercity networks needing rehabilitation; almost 38,000 telephones; est.
750,000 radio and 10,000-15,000 TV receivers; 1 TV, 78 AM, and 16 FM stations;
long-range improvement plans revised and partly implemented
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1971, $15.9 million;
about 9% of proposed central government budget
34
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
.
+
oe ee ec
SMT
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
3,290,000 sq. mi.; 4% cultivated, 14% pastures, 14%
waste, urban, or other, 13% fallow, idle, or
woodlot, 55% forested (1970)
Land boundaries: 8,125 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 4,655 mi.
Railroads: 20,160 mi.; 17,886 mi. 3''3 3/8" gage, 1,982 mi. 5''3" gage, 121 mi.
4''8 1/2" gage, 171 mi. narrow gages; 1,692 mi. electrified
Highways: 707,000 mi.; 33,000 mi. paved, 63,000 mi. gravel, and 611,000 mi. of
improved and unimproved earth
Injand waterways: 31,000 mi. navigable
Ports: 6 major, 24 minor
Pipelines: crude oi], 633 mi.; refined products, 139 mi.; natural gas, 24 mi.
Civil air: 112 major transport aircraft
Airfields: 4,714 total, 2,342 usable; 115 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 322 with runways 4,000-7,999 ft.; 18 seaplane
stations
Telecommunications: extensive telecom facility expansion programs; radio relay
widely used; communications satellite ground station; 2 million telephones;
est. 10.5 million radio and 6 million TY receivers; 850 AM, 145 FM, and 72
TV stations; 10 telegraph submarine cables
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1972, $946,000 ,000;
15.3% of federal budget
38
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
BRITISH HONDURAS
LAND:
8,870 sq. mi.; 38% agricultural (5% cultivated), 46%
exploitable forest, 16% urban, waste, water,
offshore islands or other (1966)
Land boundaries: 320 mi.
WATER: :
Limits of territorial waters (claimed): 3 n. mi. icbilenain
Coastline: 240 mi.
PEOPLE: weil
Population: 128,000, average annual growth rate 2.9%
(April 60-70); males 15-49, 28,000; 16,000 fit for
military service; 1,500 reach military age (18) annually
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican, Seventh-day Adventist, Methodist,
Baptist, Jehovah''s Witnesses, Mennonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,000; 39% agriculture, 14% manufacturing, 8% commerce,
12% construction, 20% transportation, and 7% services; shortage of skilled
labor and all types of technical personnel; over 15% are unemployed
Organized labor: 8% of labor force
Railroads: none
Highways: 1,350 mi.; 150 mi. paved, 600 mi. improved (gravel, earth), 600 mi.
unimproved
Inland waterways: 514 mi. river network used by shallow-draft craft
Ports: ] major, 4 minor
Civil air: no major transport aircraft
Airfields: 49 total, 29 usable; 2 with permanent-surface runways; | with
runway 4,000-7,999 ft.; 1 seaplane station
Telecommunications: meager but adequate facilities; Belize City center of
2,800 telephone network; over 48,000 radio receivers; 2 AM stations; no
submarine cables
40
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
BRUNEI
LAND:
2,230 sq. mi.; 3% cultivated; 3% industry, waste, or
urban; 94% forested
Land boundaries: 237 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 136 mi.
Railroads: 6 mi. narrow gage (2'')
Highways: 750 mi.; 110 mi. paved (bituminous treated), 220 mi. gravel or stone,
420 mi. unimproved
Inland waterways: 130 mi.; navigable by shallow-draft craft
Ports: 2 minor (Bandar Seri Begawan, formerly Brunei, and Kuala Belait)
Pipelines: crude of1, 84 mi.; refined products, 35 mi.; natural gas, 35 mi.;
crude oi] and natural gas, 150 mi. under construction
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface runway; 1 with runway
over 12,000 ft., 2 with runways 4,000-7,999 ft.
Telecommunications: service throughout country is adequate for present needs;
international service good to adjacent Sabah and Sarawak; radiobroadcast
coverage good; 3,819 telephones: 13,000 radio sets; Radio Brunei
broadcasts from 3 stations and uses 4 mediumwave and 1 shortwave
transmitter
DEFENSE FORCES:
Ships: 4 coastal patrol, 4 river/roadstead patrol craft
Military budget: for fiscal year ending 31 December 1970, $9.8 million for the
military and $7.1 million for the police; about 15% of the total budget
42
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
BULGARTA
D:
42,800 sq. mi.; 41% arable, 11% other agricultural,
33% forested, 15% other (1966)
Land boundaries: 1,170 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. masee
Coastline: 220 mi. ao
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 200 n. mi.)
Coastline: 4,000 mi.
PEOPLE: cre ehegt
Population: 9,239,000, average annual growth rate 2% oe op
(November 60-April 70); males 15-49, 2,204,000; 1,640,000 fit for military
service; average number reaching military age (19) annually about 90,000
Ethnic divisions: 85%-90% mestizo, 3% Indian, 7% European, Asiatic, and other
Religion: 90% Roman Catholic, 5% (est.) Evangelical, 5% other
Language: Spanish
Literacy: 84%
Labor force: 3.1 million (1969); 28% agricultural, 24% industry and construction,
24% services, 10% commerce, 4% mining, 10% other (1962)
Organized labor: 20% of labor force
Railroads: 5,511 mi.; 2,086 mi. 5''6" gage, 154 mi. 4''8 1/2" gage, 2,644 mi.
3''3 3/8" gage, 69 mi. 2''6" gage, 22 mi. 1''1]1 5/8" gage, 536 mi. specific gage
not given; 199 mi. double track; 667 mi. electrified
Highways: 45,300 mi.; 4,900 mi. paved, 19,900 mi. gravel, 20,500 mi. improved
and unimproved earth
Inland waterways: 451 mi.
Pipelines: crude oi], 380 mi.; refined products, 510 mi., natural gas, 200 mi.
Ports: 10 major, 20 minor
Civil air: 48 major transport aircraft
Airfields: 439 total, 331 usable; 44 with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 55 with runways 4,000-7,999 ft.; 7 seaplane stations
Telecommunications: extensive radio relay network; telephone network modern but
with only 369,000 instruments; communications satellite ground station; est.
2.5 million radio and 500,000 TV receivers, 137 AM, 30 FM, and 15 TV stations
60
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
CHINA, PEOPLE''S REPUBLIC OF
LAND:
3.7 million sq. mi.; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of
this area consists largely of denuded wasteland,
plains, rolling hills, and basins from which about 3%
could be reclaimed), 8% forested; 2%-3% inland water
(1971)
Land boundaries: 15,000 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 9,000 mi.
WATER: ; ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,500 mi.
Railroads: 2,160 mi., al] 3''O" gage, single track, 22 mi. electrified
Highways: 28,600 mi.; 3,700 mi. paved, 19,900 mi. crushed stone or gravel,
3,100 mi. improved earth, 1,900 mi. unimproved earth
Injand waterways: 8,900 mi., navigable by river boats
Pipelines: crude of1, 2,000 mi.; refined products, 828 mi.; natural gas, 370 mi.;
natural gas liquids 83 mi.
Ports: 5 major, 5 minor
Merchant marine: 36 ships (1,000 GRT or over) totaling 204,800 GRT, 267,100 DWT;
31 cargo, 2 bulk, 3 tanker (includes 3 naval tankers sometimes used
commercially)
Civil air: 93 major transport aircraft
Airfields: 831 total, 715 usable; 32 with permanent-surface runways; 1 with
runway over 12,000 ft.; 6 with runways 8,000-11,999 ft., 87 with runways
4,000-7,999 ft.; 11 seaplane stations
Telecommunications: rapidly improving nationwide telecom system, with UHF relay ;
system being installed, communications satellite ground station; over 974,000
telephones; est. 6 million radio and 730,000 TV receivers, 253 AM, 132 FM, .
and 16 TY stations
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1972, $95.0 million;
about 10.2% of central government budget
66
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMORO ISLANDS
“2, SAUDI
LAND ; ARABIA 2
838 sq. mi.; 4 main islands Z
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 211 mi.
Railroads: none
Highways: 600 mi.; approximately 100 mi. bituminous, 450 mi. crushed stone or
gravel, remainder tracks
Inland waterways: none
Ports: 1 minor (Moroni on Grande Comore)
Civil air: 2 major transports
Telecommunications: one central telephone exchange; number of telephones and
radio receivers not available; 4 radiotelephone and radiotelegraph stations
link the islands and the Malagasy Republic; 1 AM, 1 FM, and no TV stations
67
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
DEFENSE FORCES:
Defense is the responsibility of France
68
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: 407 mi., 395 mi. 3''6" gage, 12 mi. 3''0" gage, all single track, 72 mi.
electrified
Highways: 11,700 mi.; 850 mi. paved, 3,200 mi. gravel, 7,650 mi. earth
Inland waterways: about 455 mi. perennially navigable
Pipelines: refined products, 75 mi.
Ports: 3 major, 4 minor
Civil air: 17 major transport aircraft
Airfields: 198 total, 122 usable; 10 with permanent-surface runways; 8 with
runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic telephone service greatly improved with new
automatic exchanges; 61,300 telephones; connection to international Central
American microwave net began November 1971; 330,000 radio and 100,000
television receivers in use, 45 AM, 9 FM, and 12 TV stations
DEFENSE FORCES:
Supply: dependent on imports from U.S.
Military budget: for fiscal year ending 31 December 1971, $3.3 million for
Ministry of Public Security, including the Civil Guard; about 2.3% of total
central government budget
72
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: none
Highways: 460 mi.; 175 mi. paved, 190 mi. gravel, crushed stone, or stabilized
earth surface, 95 mi. unimproved
Ports: 5 minor
83
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 4,830 ft.
Telecommunications: 1,970 fully automatic telephones; VHF interisland links to
St. Lucia and Antigua; no data on radio or TV receivers; 1 AM station
84
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: 1,000 route mi. of which 65 mi. government-owned common carrier
(3''6" gage) and 935 mi. privately owned plantation network (approximately 4
different gages ranging from 1''10 1/2" to 4''8 1/2", with 2''6" predominating)
Highways: 6,200 mi.; 3,200 mi. paved, 900 mi. gravel, 1,400 mi. improved earth,
800 mi. unimproved earth
eee product lines (1.5 mi. and 43 mi.) under construction, to be completed
in 1971
Ports: 5 major, 17 minor
Civil air: 16 major transport aircraft
Airfields: 59 total, 38 usable; 7 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: relatively efficient domestic system based on islandwide
radio relay network; automatic telex exchange inaugurated in 1971 provides
international connections via New York; 47,400 telephones; 400,400 radio and
1,250,000 TV viewers, 92 AM, 24 FM, and 6 TV stations; 2 submarine cables, 1
of which is coaxial
DEFENSE FORCES:
Supply: dependent upon U.S. and Western Europe
Military budget: for fiscal year ending 31 December 1971, $32.3 million; about
12.3% of central government budget
86
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: none
Highways: 512 mi.; 9 mi. paved, 23 mi. gravel, 480 mi. earth
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
*The possession of the Falkland Islands has been disputed by the U.K. and Argentina
(which refers to them as the Malvinas) since 1833,
99
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Airfields: 1 seaplane station
Telecommunications: government-operated open-wire and radiotelephone networks
providing effective service to almost all points on both islands; approx-
imately 500 telephones; 1 AM station and approximately 1,100 radiobroadcast
receivers
100
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
(April 60-April 70)
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects; Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 25,170 (1960); 40% agriculture, 30% unemployed or underemployed
Organized labor: 33% of labor force
Railroads: none
Highways: 600 mi.; 380 mi. paved, 100 mi. gravel, crushed stone, or earth
surface; 120 mi. unimproved
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 4 total, 3 usable; 1 with asphalt runway 5,000 ft.
Telecommunications: automatic, islandwide telephone system with 2,700 telephones;
VHF island link to Trinidad; no data on radio or TV receivers; 1 AM station
129
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
St Cee
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: privately owned, narrow-gage plantation lines
Highways: 1,200 mi.; 780 mi. paved, 420 mi. grave] and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 1 major transport
Telecommunications: domestic facilities inadequate; international, approaching
saturation point; 14,400 telephones, 83% automatic; telegrams re-transmitted
by telephone; international radio-telegraph carries 5 telex circuits;
inter-island VHF radio Tinks; 2 AM radio and 2 TV transmitters, with about
22,500 radio and 5,200 TV receivers
DEFENSE FORCES:
Defense is responsibility of France; data included with France
Personnel: army, 200 (S)
Airfields: 7 total, 6 usable, 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft.; 1 seaplane station
132
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: 592 mi., 3''0" gage; single-tracked; 520 mi. government owned, 72 mi.
privately owned
Highways: 7,600 mi., 1,300 mi. bituminous, 4,200 mi. gravel, 2,100 mi. improved
or unimproved earth (1965)
Inland waterways: 164 mi. navigable year-round; additional 458 mi. navigable
during high-water season
Pipelines: crude oil, 28 mi.
Freight carried: rail (1960) -- 191.8 million ton/miles, 1.1 million tons
Ports: 4 major, 1 minor
Airfields: 477 total, 312 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 1] major transport aircraft
Telecommunications: modern telecom facilities largely limited to Guatemala;
intercity open wire network; 39,500 telephones; est. 350,000 radio and
90,000 TV receivers, 86 AM, 25 FM, and 3 TV stations; plan for satellite
earth station canceled; connection to international Central American microwave
net operational November 1971
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 3] December 1972, $18.9 million;
about 7.5% of central government budget
134
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: 220 mi.; 200 mi. of 3''6" gage, government owned; 20 mi. narrow gage,
privately owned
Highways: 8,750 mi.; 800 mi. paved, 3,250 mi. otherwise improved, 4,700 mi.
unimproved
Inland waterways: 1,380 mi., including 2 large lakes
Pipelines: crude of1, 36 mi.
Ports: 4 major, 6 minor
Civil air: 10 major transport aircraft
Airfields: 459 total, 414 usable; 5 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 8 with runways 4,000-7,999 ft.: 2 seaplane stations
Telecommunications: extensive but low-capacity wire network; single radio relay
link; connection to international Central American microwave net operational
November 1971; 25,900 telephones; est. 700,000 radio and 55,000 TV receivers,
70 AM, 26 FM, and 5 TV stations: satellite ground service station scheduled to
enter service in 1973
DEFENSE FORCES:
Supply: dependent primarily upon U.S.
Military budget: for fiscal year ending 31 December 1972, $8.8 million for the
Ministry of Defense, including civil functions (e.g., police and civil air);
8.3% of central government budget
242
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Heke ae car me tii ne NR ir SSIES RNR eee SNR A er | et eer ee npn pene feet: tiem
ce ee
—
ee
ee oe ee
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: 345 mi.; 48 mi. 5''O" gage, 107 mi. 3''0" gage; 190 mi. plantation
feeder lines
Highways: 4,200 mi.; 1,100 mi. paved, 600 mi. gravel or crushed stone, 300 mi.
improved earth, 2,200 mi. unimproved earth; Panama Canal Zone 145 mi.;
140 mi. paved; 5 mi. gravel
Inland waterways: 500 mi. navigable by shallow draft vessels; 50-mile
Panama Canal
Pipelines: refined products, 56 mi.
Ports: 2 major, 10 minor
Civil air: 30 major transport aircraft
Airfields: 238 total, 120 usable; 15 with permanent-surface runways; 3 with
runways 8,000-11,999 ft.; 11 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic and international telecom facilities well developed,
including nearly nationwide radio-relay system; connection to international
Central American microwave net operational November 1971; communications
satellite ground station; 72,900 telephones; 550,000 radio and 108,000 Tv
receivers, 77 AM, 25 FM, and 13 TV stations; 1 coaxial submarine cable
254
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: none
iba 550 mi.; 170 mi. paved; 180 mi. otherwise improved; 200 mi. unimproved
eart
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 3 total; 2 usable, with asphalt runway 4,800 ft.
Telecommunications: islandwide fully automatic telephone system with 2,300
instruments; VHF interisland links to Barbados and St. Lucia; no data on
radio or TV receivers; 2 AM stations
289
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','ede12037b356b3243efc751cd8ea9b5deaab3a62a36460c6963e8b46fb9adb25','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a96948a509702133cc824ab0e94085f10fbd530cff16e08f1d885feeb20a8e1e',1972,'AR','Argentina','communications',28,'LAND:
1,070,000 sq. mi.; 57% agricultural (11% crops, improved
pasture and fallow, 46% natural grazing land), 25% ern
forested, 18% mountain, urban, or waste (1968 est.)
Land boundaries: 5,850 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 3,100 mi.
Railroads: 25,000 mi.; 2,000 mi. standard gage (4''8 1/2"), 13,750 mi. broad
gage (5''6") 8,750 mi. meter gage (3''3 3/8"), 500 mi. 2''5 1/2" gage;
about 1,035 mi. double track; 76 mi. electrified; 99.6% government-owned
Highways: 125,000 mi., of which 21,000 mi. paved, 17,000 mi. gravel, 41,000
mi. improved earth, and 46,000 mi. unimproved earth
Inland waterways: 6,800 navigable mi.
Ports: 7 major, 21] minor
Pipelines: crude oi7, 1,962 mi.; refined products 1,774 mi.; natural
gas, 4,061 mi.
Civil air: 58 major transport aircraft
Airfields: 2,381 total, 1,793 usable; 66 with permanent-surface runways;
1 with runway over 12,000 ft., 16 with runways 8,000-11,999 ft., 245 with
runways 4,000-7,999 ft.; 10 seaplane stations
Teleconmunications: foremost in telecom facilities in South America; improving
telephone network has 1.8 million sets, radio relay widely used, communications
satellite ground station; estimated 6.5 million radio receivers and 3.3
million TV sets; 94 AM, and 49 TV stations; 8 telegraph submarine cables
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1972,
$580 000,000 about 15% of total central government budget
14
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
~@&
©
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
STAT
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','639b81e6620337af88e81951a607c53b118edba1fc66ed221eb4ec64a4fabff4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd2ec38a28e5c3ef59032d49cdbe549e983641f56c226436a00306ec6137c98f',1972,'AT','Austria','communications',32,'LAND:
32,400 sq. mi.; 20% cultivated, 27% meadows and pastures,
14% waste or urban, 38% forested, 1% inland water (1969)
Land boundaries: 1,605 mi.
Railroads: 4,073 mi.; 3,612 mi. standard gage, 833 mi. double tracked; 433 mi.
2''5 7/8" gage, and 28 mi. electrified 3''3 3/8" narrow gage; 1,584 mi.
electrified
Highways: 20,356 mi. total: 6,056 mi. Federal (5,656 mi. bituminous, concrete,
stone block, 400 mi. crushed stone, gravel, improved earth); 14,290 mi.
Provincial (4,340 mi. bituminous, concrete, stone block, 9,950 mi. crushed
stone, gravel, improved earth); additionally about 38,000 mi. of communal
roads, mostly of gravel, crushed stone, and improved earth
Inland waterways: 267 mi.; carries 5% freight, 6% passengers
Ports: 3 major
Pipelines: crude oi], 450 mi.; natural gas, 720 mi.
Civil air: 11 major transport aircraft
Airfields: 61 total, 50 usable; 11 with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 7 with runways 4,000-7 ,999 ft.
Telecommunications: highly developed and efficient; excellent national and
international services; extensive TV and radiobroadcast systems with 13 AM,
15 FM, and 20 TV stations; 1.51 million telephones; 2 million radio receivers;
1.38 million television receivers
DEFENSE FORCES:
Supply: produces some smali arms and ammunition, trucks, and tank destroyers;
current sources of other items are the U.S., Western Europe, Sweden,
and the Communist countries
Military budget: for fiscal year ending 31 December 1972, $198.4 million; about
3.9% of the federal budget and 1.2% of GNP
18
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COmMPPT a 1 ie
aR oS IH (LRU Heimat
Ae COE Ae eee
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','031a352e9633cb1732f65881096bbf07c7053ff85f6618698a643d5d0f2f2bf0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27da27d182b423a68ef0d0992a97b80e30bd4d81b0fb71255d38292054b45632',1972,'BS','Bahamas','communications',36,'LAND:
4,400 sq. mi.; 1% cultivated, 29% forested, 70% built
on, wasteland, and other (1962)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.) ea
Coastline: 2,200 mi. (New Providence Is. 47 mi.) sine','5ac1da1012085402d288496c9b427065a14dd8268865bf550775613eb6b1050a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9199d9da793871295d4f9c608284085d2a54713ec500f3f6ecfd728aa76a64c',1972,'BH','Bahrain','communications',38,'LAND:
230 sq. mi. plus group of smaller istands; 5% cultivated,
negligible forested area, remainder desert, waste,
or urban
WATER :
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 100 mi.
Highways: 120 mi. bituminous surfaced; undetermined mileage of natural surface
tracks
Ports: 1 major
Merchant marine: 1 cargo ship (1,000 GRT or over) of 1,600 GRT, 2,600 DWT
Pipelines: crude oi1, 34 mi.; refined products, 9 mi.; natural gas, 19 mi.
Civil air: 8 major transport aircraft (all registered in the U.K.)
Airfields: 5 total, 3 usable; 1 with permanent-surface runway; 1 with runway over
12,000 ft; 1 with runway 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent international radiocommunications; limited
domestic services; 10,800 telephones: 56,500 radio receivers; 10,000 TV sets;
1 AM radiobroadcast station; satellite earth station; tropospheric scatter
Bahrain-Qatar
21
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1971; $3,490,000, 6.9% of total
budget
22
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','d2dad42e4d90c6e93c6817de854145313379628ba8a9e2b9d7570bb473106fee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cf55b19c5debde3f8bac19f73e3b27aaba1506cbb134ad667d32740e67f04d2',1972,'BD','Bangladesh','communications',42,'LAND:
56,700 sq. mi.; 79% arable (including cultivated and PEOPLE''S REPUBLIC
fallow), 5% waste or urban, 16% forested ; ae
Land boundaries: 1,575 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi.
Railroads: 1,752 mi.; 1,158 mi. meter gage, 554 mi. broad gage, 20 mi. narrow
gage; 87 mi. double track; government owned
Highways: 28,350 mi.; 2,450 mi. paved; 1,750 mi. gravel, 24,150 mi. earth
Inland waterways: 4,600 mi.; river steamers navigate main waterways
Ports: 1 major; 50 minor
24
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','fbd5f9948453e7d2c89d6bf44bd52816135aee0efd312c7b9f0f1dd5cd222213','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14955359e468bfa56d08bec4283f94e06ea0f78cb2641e8f1f6185dd3fae23d7',1972,'BB','Barbados','communications',46,'LAND:
166 sq. mi.; 60% cropped, 10% permanent meadows, 30% built
on, waste, other (1960)
WATER: ; ;
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 60 mi.','c3f01568f1e23c3a748b82b49488af243e519575c26523856e4575d50c6fbb41','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d2f4641fd4e6dcc921892badfb1adf9fd8e730ea16355db89711e7303f184bd',1972,'BE','Belgium','communications',48,'LAND:
11,800 sq. mi.3; 28% cultivated, 24% meadow and pasture,
28% waste, urban, or other; 20% forested (1969)
Land boundaries: 856 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 40 mi.
Railroads: 2,873 mi.; 2,645 mi. standard gage, 1,615 mi. double track, 920 mi.
electrified; 228 mi. (3''3 3/8") narrow gage
Highways: 57,700 mi.; 26,550 mi. bituminous, stone block, or concrete; 31,150
mi. crushed stone, gravel, earth
Inland waterways: 1,270 mi., af which 950 are in regular use by commercial
transport
Ports: 5 major, | minor
Pipelines: refined products, 400 mi.; crude, 50 mi.; natural gas, 45 mi.
Civil air: 56 major transport aircraft, including 6 based in Libya
Airfields: 51 total, 37 usable; 20 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 10 with runways 4,000-7,999 ft.
Telecommunications: excellent domestic and international telephone and
telegraph facilities; 2,019,000 telephones; 3.6 million radio receivers;
2.1 million TV receivers; countrywide broadcast coverage provided by 7 AM,
10 FM, and 18 TV stations; submarine cables to U.K. and to Portugal
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1972, $720.0 million;
about 7.3% of proposed central government budget
28
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','b89ad6dd8c097cd772b6c9a2144990bdc91979bdef40539dca500269a0b574e4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df9976292613a9621b8d2a401ee1d9f79fb1cf6bd95294fed4f965742f1adcb4',1972,'BM','Bermuda','communications',52,'LAND:
21 sq. mi.; 8% arable, 60% forested, 21% built on,
wasteland, and other, 11% leased for air and
naval bases (1964)','7b0363d6ff682243b003aabf3cc1cdc0e7ffc340452314fb5f0504d4976b635e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bf5701d92cfea444931c4d5afeb78953fc07a112ffdba4058d71c63fceadfcc',1972,'CA','Canada','communications',53,'WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 64 mi.
Railroads: none
Highways: 130 mi., all paved
Ports: 4 major
Civil air: no major transport aircraft
29
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Airfields: 1 with concrete runway 9,660 ft.; 1 heliport
Telecommunications: modern telecom system suited to island needs, includes fully
automatic telephone system with 29,000 instruments; 29,000 radio and
17,000 TV receivers, 2 AM, 1 FM, and 2 TV stations; 3 submarine coaxial cables
30
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','87a6b8d72fbbfda93e958b1842678af86a1d40ccfe521aec513506d4144268a7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('598a95d36132d05c37baa4a9d45491a4eacf07d1f8b01b497f0580d8666436ce',1972,'BT','Bhutan','communications',57,'LAND:
19,000 sq. mi.; 15% agricultural, 15% desert, waste,
urban, 70% forested (1963) eect
Land boundaries: about 540 mi. af
Highways: 810 mi.; 260 mi. surfaced, 320 mi. improved, 230 mi. unimproved
earth
Freight carried: not available, very light traffic
Civil air: no major transport aircraft
3]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Airfields: 1 permanent surface runway 4,500 feet long
Telecommunications: facilities almost nonexistent; data not available on
telephones; 6,000 radio sets; no TV sets; data not available on AM; no
FM; and no TV stations
DEFENSE FORCES:
Supply: dependent on India
32
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
BOLIVIA
D:
424,000 sq. mi.; 2% cultivated and fallow, 11% pasture
and meadow, 45% urban, desert, waste, or other,
40% forest, 2% inland water (1967)
Land boundaries: 3,780 mi.','3b03ed56b483e1ef216954a69dda919d1e6033bcd292cab1faeaa539aa15f2ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7649c5756343b9141c5ffb78333b3bc67732a4906559fdde19463d6e2700f4f',1972,'BW','Botswana','communications',62,'D:
220,000 sq. mi.; about 6% arable, less than 1% under
cultivation, mostly desert (1972)
Land boundaries: 2,345 mi.
Railroads: 400 mi. 3''6" gage, single track; owned and operated by the Rhodesia
Railroads
Highways: 5,016 mi.; 16 mi. paved, 472 mi. crushed stone, gravel, or stabilized
soil; 4,529 mi. improved or unimproved earth
Inland waterways: native craft only; of local importance
Civil air: 1] major transport aircraft
Airfields: 83 total, 72 usable; 2 with permanent-surface runways; 19 with
runways 4,000-7,999 ft.
Telecommunications: the system is a minimal combination of a single main wire
line and a few radioconmmunication stations; Gaberone is the center; 4,000
telephones; 20,000 radio receivers; 1 AM, 7] FM, and no TV stations
DEFENSE FORCES:
Police only
36
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','dc4fc39772d8d878d330ee337f9a565d08eb866b407f1ddb3c67700f37f159b9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9c4fb4e75815ce72cb3d36b9264b7d12f3def1f3d520853f5226cdd9fcb628a',1972,'IQ','Iraq','communications',69,'Railroads: 2,650 mi.; about 2,470 mi. standard gage, 180 mi. narrow gage; 148 mi.
double track; 528 mi. electrified; government owned (1971)
Highways: 20,700 mi.; 7,900 mi. paved, 8,100 mi. crushed stone and gravel,
4,700 mi. earth (1971)
Iniand waterways: 300 mi. (1972)
Freight carried: rail -- 75.2 million short tons, 9.5 billion short ton/mi.
(1970); highway -- 542 million short tons, 5.4 billion short ton/mi. (1970);
waterway -- 3.5 million short tons, 1.2 billion short ton/mi. (1970)
44
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
BURMA
D:
262,000 sq. mi.; 28% arable, of which 12% is cultivated,
62% forest, 10% urban and other area (1969)
Land boundaries: 3,630 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(extended base lines 15 November 1968)
Coastline: 1,200 mi.
Railroads: 2,022 mi.; 1,952 mi. meter gage, 70 mi. narrow-gage industrial lines;
204 mi. double track; government owned
Highways: 15,540 mi.; 4,210 mi. paved, 4,770 mi. gravel, 5,810 improved earth,
750 mi. unimproved earth
Inland waterways: 8,000 mi.; 2,000 mi. navigable by large commercial vessels
Ports: 4 major, 6 minor
Merchant marine: 9 cargo ships (1,000 GRT or over) totaling 55,500 GRT, 73,600
DWT
Airfields: 118 total, 83 usable; 20 with permanent-surface runways; 2 with
runways 8,000-11,999 ft., 37 with runways 4,000-7,999 ft.: 2 seaplane
stations
Telecommunications: provide minimum requirements for Tocal intercity service;
international service is fair: radiobroadcast coverage is limited to the
more populous areas; 24,654 telephones; 500,000 radio sets; 1 AM, 1 FM,
and no TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1971; $112.3 million, 35%
of total budget
46
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','8b710d870f95546228549220fc17da6c3ac573bee252ea28d6bcf00ec8d9de6a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c7c1ceb65a1eaa004faf9f713b5553dad41ef3e919cf426861a72b804c62174',1972,'BI','Burundi','communications',70,'LAND:
11,000 sq. mi.; about 37% arable (about 66% cultivated),
23% pasture, 10% scrub and forest, 30% other
Land boundary: 605 mi.
Railroads: none
Highways: 3,700 mi.; 45 mi. bituminous, 3,655 mi. crushed stone, gravel, laterite,
and improved or unimproved earth
Inland waterways: Lake Tanganyika navigable for lake steamers and barges
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 32 total, 22 usable; 1 with permanent-surface runway; | with runway
8,000-11,999 ft.
Telecommunications: telegraph is principal service, limited telephones; 3,400
telephones, 65,000 radio receivers; 2 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending December 1971, $1,100,000: about 4.5% of
ordinary budget
48
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','9d00599f49f723ba0ad348b69b3b67bb98022862221bf1f8f99e7e8ec344d8f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c5636fb79c096efca37eecadd4ff66e0e654402979b26cd17b5d401b15122de',1972,'KH','Cambodia','communications',74,'D:
69,898 sq. mi.; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other (1958)
Land boundaries: 1,515 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi.)
Coastline: about 400 mi.
Railroads: 409 mi. meter gage; government owned
Highways: 9,340 mi.; 1,600 mi. bituminous, 1,000 mi. crushed stone, gravel, or
laterite; 275 mi. improved earth; and 6,465 mi. unimproved earth; 7,900 mi.
are selected designated routes
Inland waterways: 1,220 mi. during high water, 1,010 mi. during low water;
90% of total navigability on Mekong system and Tonle Sap
Freight carried: (1968) rail -- 50 million ton-miles; waterway -- approximately
300,000 short tons annually; figures unavailable for highways
Ports: 2 major, 6 minor
Airfields: 97 total, 43 usable; 8 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: service to general public considered poor; barely adequate
for government requirements; international service fair to adjoining countries
and a few other nations; radiobroadcasts and television coverage limited by
small number of stations and receivers: 8,139 telephones; 105,000 radio
receivers; 30,000 (est.) TV receivers; 1 AM, 2 AM relay, no FM, and 7 TV
station; no submarine cables
50
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','08d37c11bc75bad3e70c49c462c463449047eea6a2556a0fe38f25cdc7038303','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00723de95488f094c7c8d8e52d2ad41f976f27f83e6ca2437e531f9a263d97b4',1972,'CM','Cameroon','communications',77,'ND:
183,400 sq. mi.; 4% cultivated, 18% grazing, 13% fallow,
50% forest, 15% other (1964)
Land boundaries: 2,830 mi.
WATER: : .
Limits of territorial waters (claimed): 18 n. mi.
Coastline: 250 mi.
Railroads: 623 mi.; 533 mi. meter gage, 90 mi, 1''11 5/8" gage
Highways: approximately 8,545 mi.; 765 mi. BST, 7,780 mi. gravel, laterite, or
improved earth
Intand waterways: 1,300 mi.
Ports: 1 major, 3 minor
Civil air: 4 major transport aircraft
Airfields: 59 total, 56 usable; 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: good telephone service between Douala and Yaounde, fair in
southern part; fair to good telegraph service; 5,800 telephones; 211,500
radio receivers; 4 AM, no FM, and no TV stations; limited wired broadcast;
1 submarine cable
DEFENSE FORCES:
Supply: mostly from France and U.S,
52
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
~@&
V4
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
STAT
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','db340ced0c32a7b20fc816ad34b4dd748430763e9a739cbc581e91213ac799ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4c3c81718f5782a4edd02f296581b3e0492e9ba6739e93ebe0ff38fed12381b',1972,'CF','Central African Republic','communications',81,'D:
242,000 sq. mi.; 10%-15% cultivated, 5% dense forests,
80%-85% grazing, fallow, vacant arable land, urban,
waste (1966 est.)
Land boundaries: 3,095 mi.
Railroads: none
Highways: 13,250 mi.; 50 mi. bituminous, 2,330 mi. gravel and/or crushed stone,
3,420 mi. improved earth, 7,450 mi. unimproved earth
Inland waterways: 4,400 mi.; traditional trade carried on by means of dugouts
on the extensive system of rivers and streams; only the Oubangui River
between Bangui and Brazzaville and short sections of the Sangha and the
Lobaye Rivers are navigable throughout year; during high-water period
(July - December) Oubangui navigable upstream from Bangui as far as Quango
Port: Bangui, Quango (river ports)
Civil air: 5 major transport aircraft
Airfields: 65 total, 49 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 15 with runways 4,000-7,999 ft.
Telecommunications: facilities are meager and provide only barely sufficient
services; principal network is 39 low-capacity, low-powered radioconmmunica-
tion stations; no cables or radio relay links are used; single center of
Bangui has only international radio connections; 3,500 telephones; 46,000
radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Supply: completely dependent on France
Military budget: for fiscal year ending 31 December 1971, $5,299,000; about
11.7% of total budget
26
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','c3f378729f249e9e3c244556fd820b79e5de78ddb6b8ae0b662f6dbe8df6b65d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bbd8c5952d21159ab67c952eff3de7084cd5708429cd9108cfcee7b71781b7c',1972,'TD','Chad','communications',85,'LAND:
496,000 sq. mi.; 17% arable, 35% pastureland, 2% forest
and scrub, 46% other uses and waste (1967) cena} ava feGver,
Land boundaries: 3,720 mi.
Railroads: none
Highways: 19,200 mi.; 160 mi, bituminous, 3,300 mi. gravel and laterite, and
15,740 mi. unimproved
Inland waterways: approximately 1,300 mi. of year-round navigability, increased
to 3,000 mi. during high-water period
Civil air: 4 major transport aircraft
Airfields: 74 total, 60 usable; 4 with permanent-surface runways; | with runway
8,000-11 ,999 ft., 17 with runways 4,000-7,999 ft.
Telecommunications: fair system of radiocommunication stations only for intercity
links; principal center Fort-Lamy, secondary center Fort-Archambault; 5,000
telephones; 60,000 radio receivers; 1 AM, 1 FM, and no TV stations
58
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','d7b06e898852b70f196328210547ff6d9cd91ce1433ae7d60bc9d77e0018c952','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f50da99ca9f9d9231688391fe97b9c8085cd98320564169894cd261a72ef773c',1972,'CL','Chile','communications',89,'LAND:
286,000 sq. mi; 2% cultivated, 7% other arable, 15%
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities (1965)
Land boundaries: 3,930 mi.','79613f38151e584e5027f292b5d164db4e495f5063ac117fd9dd815bbfb2108a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f041f4e09beb9df88c4e8d0beeae32ce5f4533e52eed5d013cff5dba83153a6',1972,'AU','Australia','communications',93,'Railroads: about 25,000 mi., of which 370 mi. 3''3 3/8" gage, 30 mi. 3''6" gage,
24,600 mi. 4''8 1/2" gage; mostly single track, less than 1% electrified;
government owned
Highways: 325,000 mi.; 1,000 mi. paved, 74,000 mi. gravel and crushed stone,
80,000 mi. improved earth, and 170,000 mi. unimproved earth, including tracks
Inland waterways: 105,000 mi.; 25,000 mi. navigable by modern motorized craft
Ports: 9 major, 157 minor
Airfields: 303 total; 209 with permanent-surface runways; 5 with runways over
12,000 ft., 60 with runways 8,000-11,999 ft., 207 with runways 4,000-7,999
ft.; 1] seaplane station
62
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
CHINA, REPUBLIC OF
PEOPLE''S REP.
OF CHINA
LAND:
14,000 sq. mi. (Taiwan and Pescadores); 24% cultivated,
6% pasture, 55% forested, 15% other (urban, industrial,
denuded, water area) (1969)
WATER: ; ;
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 615 mi. Taiwan, 285 mi. offshore islands
Railroads: 2,823 mi., all narrow gage; 130 mi. double track; 623 mi. government
owned, 2,200 mi. industrial
Highways: 10,300 mi. plus 300 mi. on Penghu and offshore islands; 3,300 mi. paved,
5,000 mi. gravel and crushed stone, 2,000 mi. earth
Ports: 7 major, 9 minor
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $620.0 million; about 48%
of total budget
64
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: 4,364 mi.; 3,990 mi. 3''6" gage, 317 mi. 2''5 1/2" gage, 57 mi.
T''ll 5/8" gage; 132 mi. double track; 74 mi. electrified; government owned
Highways: 57,460 mi.; 12,600 mi. paved, 25,200 mi. gravel or crushed stone,
19,660 mi. improved or unimproved earth
Inland waterways: 14,010 mi.; Sumatra 4,000 mi., Java and Madura 510 mi., Borneo
6,500 mi., Celebes 150 mi., and Irian Barat 2,850 mi.
Ports: 10 major, 62 minor
Airfields: 342 total, 236 usable; 33 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 55 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: extensive police net for interisland service; international
and domestic service is limited; radiobroadcast coverage adequate but TV
available on Java only; 182,319 telephones; 3.2 million radio sets; 90,000
TV sets; AM stations at 53 locations; 1 FM and 5 TV stations; 2 submarine
cables to Singapore
152
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
TRAN
ND:
636,000 sq. mi.; 14% agricultural, 11% forested, 16%
cultivable with adequate irrigation, 51% desert,
waste, or urban, 8% migratory grazing and other (1968)
Land boundaries: 3,305 mi.
WATER: ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,580 mi.
Railroads: 2,100 mi. 4''8 1/2" gage, 57 mi. 5''6" gage
Highways: 26,535 mi.; 7,084 mi. paved, 12,943 mi. gravel and crushed stone,
6,508 mi. improved earth
Inland waterways: 565 mi., not including Caspian Sea and Shatt al Arab and Lake
Urmia
Pipelines: crude ofl, 2,351 mi.; refined products, 2,241 mi.; natural gas,
1,552 mi.
Ports: 7 major, 6 minor
Civil air: 18 major transport aircraft
Airfields: 227 total, 148 usable; 53 with permanent-surface runways; 7 with
runways over 12,000 ft., 15 with runways 8,000-11,999 ft., 52 with runways
4,000-7,999 ft.
Teleconmunications: excellent international radiocommunications; good domestic
telecommunication facilities; 286,200 telephones; 1.8 million radio and
200,000 TV receivers; 17 AM, 2 FM, and 11 TV stations; satellite earth station
DEFENSE FORCES:
Military budget: for fiscal year ending 20 March 1972, $1,170.0 million; about
29% of total budget
154
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
TRAQ
D:
172,000 sq. mi.; 18% cultivated, 68% desert, waste, or
urban, 10% seasonal and other grazing land, 4% forest
and woodland
Land boundaries: 2,280 mi.
WATER: :
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 36 mi.
Railroads: 1,408 mi.; 698 mi. 4''8 1/2" gage, 710 mi. meter (3''3 3/8") gage;
10 mi. meter gage double track
Highways: 12,900 mi.; 4,000 mi. paved; 2,900 mi. crushed stone, gravel, or
improved earth; 6,000 mi, earth and sand tracks
Inland waterways: 635 mi.; Shatt al Arab navigable by maritime traffic for
about 65 mi.; Tigris and Euphrates navigable by shallow-draft steamers
Ports: 3 major
Pipelines: crude oil, 2,860 mi.; 81 mi. refined products; 548 mi. natural gas
Civil air: 6 major transport aircraft
Airfields: 162 total, 64 usable; 2] with permanent-surface runways; 33 with
runways 8,000-11,999 ft., 13 with runways 4,000-7,999 ft.
Telecommunications: fair international radiocommunication service; poor
domestic telephone and telegraph service; 120,000 telephones; 1,100,000 radio
receivers; 180,000 TV receivers; 4 TV and 4 AM stations
156
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
~ Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9 earn ae an ets Fred','35dbde3c6ccb7589b97c6e02ab182c0b248a457b5284cf9b44ee71c97e6e201d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abf6d266acfa70caf4928013b75af46020953f69f2072e615ed744062067bc63',1972,'CO','Colombia','communications',94,'D:
440,000 sq. mi.; settled area 28% consisting of cropland
and fallow 5%, pastures 14%, woodland, swamps, and
water 6%, urban and other 3%; unsettled area 72% --
mostly forest and savannah (1967)
Land boundaries: 3,750 mi.
Railroads: none
Highways: 415 mi.; 175 mi. paved; 240 mi. otherwise improved
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
287
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Airfields: 3 total, 3 usable; 2 airfields with permanent surface runways; one
with a 9,000 foot runway; one with a 5,700 foot runway; 2 seaplane stations
Telecommunications: fully automatic telephone system with 3,000 telephones; direct
radio link with Martinique began November 1971; interisland tropospheric links
to Barbados and Antigua; no data on radio or TV receivers, 1 AM station
288
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
WATER:
PEOPLE: PSONeIa
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ST. VINCENT
150 sq. mi. (including northern Grenadines); 50% arable, 3%
pasture, 44% forest, 3% wasteland and built-on (1964)
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 52 mi.
VENEZUELA
da 91,000, average annual growth rate 1.1% (April
60-70
Ethnic divisions: mainly of African Negro descent; remainder ,
mixed with some white and East Indian and Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 24,000 (1960); about 40% in agriculture
Organized labor: 10% of labor force','fd08b137deb0c58dadf6f8cdf7f256a5cfdc79adf70f5ba1bce8b2ec0a4ca945','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7b6617777c5cce556a1af86246274b4f39f261be65906548172f239f83eea90',1972,'CG','Congo','communications',95,'LAND:
135,000 sq. mi.; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban
or waste (1970)
Land boundaries: 2,805 mi.
WATER: ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 105 mi.
Railroads: 490 mi., 3''6" gage, single track
Inland waterways: 4,030 mi. navigable
Ports: 1 major
Civil air: 10 major transport aircraft
Airfields: 69 total, 46 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 16 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: all services only fair; barely adequate for government and
public; principal network is comprised of 30 low-capacity, low-powered radio
communication stations; few wire lines connect key centers of Brazzaville,
Pointe-Noire, and Dolisie with maximum of 2] channels; 10,000 telephones;
65,000 radio receivers; 1,800 TV receivers; 3 AM, no FM, and 1 TV stations
70
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','38178462f14e6f38d88419ee5ce8e61af47898ddcda0af0451ace5d3799a48ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b46fcad1ed608299f78139a2d18217c528065c96af329eefc3e7dfd90d27db9',1972,'CR','Costa Rica','communications',99,'D:
19,700 sq. mi.; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban,
and other (1964)
Land boundaries: 415 mi.
WATER : el
Limits of territorial waters (claimed): 12 n. mi. (fishing
200 n. mi.)
Coastline: 800 mi.','422baad81cc8b490cf053404843545e8cf68d51542787a4c8d97021bbd8add97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13e14d37976388d68fcc3f5a37e82a26bc9f2c449ed24fcd8b61de31c295751d',1972,'CU','Cuba','communications',100,'LAND:
44,200 sq. mi.; 35% cultivated, 30% meadow and pasture,
20% waste, urban, or other, 15% forested (1968)
WATER: : :
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 2,320 mi.
Railroads: 9,150 mi. government owned; 3,150 mi. common carrier lines (8 mi.
double track and 95 mi. electrified) and about 6,000 mi. plantation-
industrial lines; common carrier lines comprise 3,100 mi. 4''8 1/2" standard
gage, and about 50 mi. 3''0" and 2''6" narrow gage; plantation-industrial
lines comprise about 4,000 mi. standard gage and 2,000 mi. narrow gage
Highways: 11,600 mi.; 4,000 mi. (est.) paved, 2,500 mi. (est.) gravel or
otherwise improved hard surfaces, 5,100 mi. {est.) improved or unimproved
earth surface
Inland waterways: 50 mi.
Pipelines: natural gas, 47 mi.
Ports: 8 major, 44 minor; Guantanamo under U.S. control
Airfields: 376 total, 208 usable; 36 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 3] with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: modern facilities adequately serve military and most civil
needs; excellent international facilities, planned satellite ground station;
291,300 telephones in use; 1.5 million radio and 600,000 TV receivers,
90 AM, 30 FM, and 21 TV stations with nationwide coverage; 6 submarine cables,
including 1 coaxial
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1966, $213 million; about
7.8% of total budget
74
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','15f630efee374423f8d211f700634d8d30fd5a21213ce4de6f7190b1234aafda','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('145abae62631e68bdd7895460ad1940c58fd4193d0b13d819b5bfdf455fec3e2',1972,'CY','Cyprus','communications',104,'LAND:
3,570 sq. mi.; 47% arable and land under permanent crops,
18% forested, 10% meadows and pasture, 25% waste,
urban areas, and other (1968)
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 400 mi. (approx.
PEOPLE: eee
Population: 645,000, average annual growth rate .9%
(FY71); males 15-49, 154,000; 108,000 fit for
military service, about 7,000 reach military age
(18) annually
Ethnic divisions: 78% Greek; 18% Turkish; 4% British, Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Armenian Orthodox and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Labor force: 267,000 (1970 est.}, 38% agriculture, 23% industry, 9% conmerce,
2% mining, 28% other; 3,130 registered unemployed (December 1968)
Organized labor: 24% of labor force
Railroads: 8,269 mi.; 8,089 mi. standard gage, 70 mi. broad gage, 110 mi. narrow
gage; 1,745 mi. double track: 1,560 mi. electrified; government owned (1970)
Highways: 45,500 mi.; 600 mi. concrete; 20,700 mi. bituminous; 2,400 mi.
cobblestone, brick sett, stone block; 21,800 mi. crushed stone, gravel,
improved earth (1971)
Inland waterways: 517 mi. (1972)
Pipelines: crude of], 900 mi.; refined products, 535 mi.; natural gas, 1,450 mi.
Freight carried: rail -- 256.3 million short tons, 40.3 billion short ton/mi.
71970): highway -- 715 million short tons, 6.2 billion short ton/mi. (1970);
waterway -- 4.9 million short tons, 1.7 billion short ton/mi. (1970)
Ports: no maritime ports; outlets are Gdynia, Gdansk, Stettin in Poland; Rijeka,
Yugoslavia; Hamburg, West Germany; Rostock, East Germany; principal river
ports are Prague, Melnik, Usti nad Labem, Decin, Komarno, Bratislava (1972)
78
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
WATER:
Railroads: 360 mi., all meter gage (3''3 3/8")
Highways: 4,300 mi.; 470 mi. paved, 1,670 mi. otherwise improved earth, 2,160
mi. unimproved
Inland waterways: 400 mi. navigable
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 11 total, 10 usable: 1 with permanent-surface runway; 3 with runways
4,000-7,999 ft.
Telecommunications: telephone service concentrated in south; telegraph limited,
but more extensive than telephone; 6,500 telephones; 54,000 radio receivers;
2 AM, no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES:
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1970, $4,420,000; about
12.4% of total budget
80
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','dabd674552c9072996692cd4895c1a3c3950605403e543f6cba729859b925222','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe4355b668834eacd8ad6180d7d6bd7d49b21a7330551c40656bed77adf167fd',1972,'DK','Denmark','communications',108,'LAND:
16,600 sq. mi. (exclusive of Greenland and Faeroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17%
other (1966)
Land boundaries: 42 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing
12 n. mi.)
Coastline: 2,100 mi.
Railroads: 2,362 mi. Danish State Railways (DSB) 1,460 mi. standard gage (4''8 1/2"),
52 mi. electrified and 451 mi. double tracked; remaining 902 mi. of standard
gage lines are privately owned and operated
Highways: 38,275 mi.; 31,205 mi. concrete, bitumen, or stone block; 5,640 mi.
gravel and crushed stone; 1,430 mi. improved earth
Inland waterways: 259 mi.
Pipelines: refined products, 202 mi.
Ports: 16 major, 42 minor
Civil air: 54 major transport aircraft (including 2 based in Greenland)
Airfields: 123 total, 110 usable; 16 with permanent-surface runways; 8 with run-
ways 8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent telephone, telegraph, and broadcast services; major
relay point for international telecom traffic; 1,700,000 telephones; 1,517,133
radiobroadcast receivers; 1,340,563 TV receivers; 7 AM, 12 FM, and 20 TV
stations; 24 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1973, $457 million; about 7%
of central government budget
82
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','43307018566bc8320197c8710b005df2d755366e91a2b715ebf7122439e443b4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db8ea4e328f88b66200bc9c26e0c948e179d8abb626b8baa348db6839505d5f8',1972,'DM','Dominica','communications',112,'LAND:
305 sq. mi.; 24% arable, 2% pasture, 67% forests, 7%
other (1966)
WATER: ;
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 92 mi.','514766cb4cfeb56d0579ca9caf8f55845236486bd9c9f834462fc2fec65be6bc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcc3fee3674541e01f15081637a43e342d1cba7be6c2f2cc35cc442dbb75da10',1972,'DO','Dominican Republic','communications',114,'LAND:
18,800 sq. mi.; 14% cultivated, 4% fallow, 17% meadows
and pastures, 45% forested, 20% built-on or waste
(1967)
Land boundaries: 224 mi.
WATER ‘ . ae
Limits of territorial waters (claimed): 6 n. mi. (fishing
12 n. mi.)
Coastline: 800 mi.','64a1546582c5d9fb8325ea20588043c4ff74a5dba6d72f25b7068c81e7e8716a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27a9f932034ee6e724b85809ce469f20862eb5336fe951ea8f78130b244d75cb',1972,'EC','Ecuador','communications',115,'106,000 sq. mi. (including Galapagos Islands); 11%
cultivated, 8% meadows and pastures, 55% forested,
26% waste, urban, or other (1961)
Land boundaries: 1,200 mi.
WATER: ;
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 750 mi. (includes Galapagos Is.
Railroads: 710 mi.; 615 mi. 3''6" gage, 95 mi. 2''5 1/2" gage; all single track
Highways: 14,200 mi.; 1,900 mi. paved, 5,100 mi. gravel, 3,800 mi. improved
earth, 3,400 mi. unimproved earth
Inland waterways: 960 mi.
Pipelines: crude oi], 27 mi.; refined products, 407 mi.
Ports: 2 major, 11 minor
Civil air: 15 major transport aircraft
Airfields: 183 total, 159 usable; 14 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: radio relay system, facilities adequate only in Quito and
Guayaquil; 95,000 telephones; 650,000 radio and 70,000 TV receivers, 200 AM,
15 FM, and 11 TV stations
DEFENSE FORCES:
Supply: dependent primarily on U.S.; some major purchases from Western Europe
Military budget: for fiscal year ending 31 December 1971, $22.9 million; about
11.3% of central government budget
88
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','501880d4eb95bd8fab93014703b25e8b5a1d0d6ddcef9d47e6f9c788a7be63a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('641aaeeabc687dce8a3babc6a63c629dfb5ffd9c5c5bdda6ffe17d98f2e2f10c',1972,'EG','Egypt','communications',119,'LAND: ‘ = ean LIBYA
386,000 sq. mi. (including 22,200 sq. mi. occupied by
Israel); 2.8% cultivated (of which about 70% multiple
cropped); 96.5% desert, waste, or urban; 0.7% inland
water
Land boundaries: 1,635 mi. (1967), excludes occupied area
1,534 mi.
WATER: ;
Limits of territorial waters (claimed): 12 n. mi. :
Coastline: 2,140 mi. (1967), excludes occupied area 1,340 mi.
Railroads: 2,976 mi.; 570 mi. double track; 15 mi. electrified; 2,594 mi. 4''8 1/2"
gage, 156 mi. 3''3 3/8" gage, 226 mi. 2''5 1/2" gage
Highways: 29,000 mi.; 5,190 mi. paved, 7,130 mi. gravel, crushed stone, and
improved earth, 16,680 mi. unimproved earth, additional 1,500 mi. (mostly
paved) in territory (Sinai) occupied by Israel]
Inland waterways: 2,100 mi.; Suez Canal, 100 mi. long, temporarily closed to
navigation because of sunken vessels; normally used by ocean-going vessels
drawing up to 38 ft. of water; Alexandria-Cairo waterway navigable by barges
of 500-ton capacity; Nile and large canals by barges of 420-ton capacity;
Ismailia Canal by barges of 200- to 300-ton capacity; secondary canals by
sailing craft of 10- to 70-ton capacity
Freight carried: Suez Canal (1966) -- 242 million tons of which 175.6 million
tons were POL
Pipelines: crude oi], 226 mi.; refined products, 294 mi.; natural gas, 31] mi.
Ports: 5 major, 12 minor
Civil air: 17 major transport aircraft
Airfields: 146 total, 79 usable; 66 with permanent-surface runways; 42 with
runways 8,000-11,999 ft., 22 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: second best system of coaxial and multiconductor cables,
open-wire lines, and radio communication stations in Africa; principal centers
Alexandria and Cairo, secondary centers Al Mansinah, Ismailia, and Tanta;
365,000 telephones; 4.4 million radio and 560,000 TV receivers; 12 AM, 1 FM,
and 26 TY stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $1.5 billion; 30.5% of
total budget
90
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','b65b04d0d8af79a29425eeac74b07f809ba926175fcde33a92a36cd05359419b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69f2b9f6c461fe6478ba3b04659e7287a3480ec4c2b6adff52379045f017dfd6',1972,'SV','El Salvador','communications',123,'LAND:
8,260 sq. mi.; 32% cropland (9% corn, 5% cotton, 7%
coffee, 11% other), 26% meadows and pastures, 31%
nonagricultural, 11% forested (1965)
Land boundaries: 320 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 190 mi.
Railroads: 375 mi., 3''O" gage; single-tracked; 285 mi. privately owned, 90 mi.
government owned
Higivays 5,400 mi.; 750 mi. bituminous, 950 mi. gravel or crushed stone, 3,700 mi.
eart
Inland waterways: Lempa River partially navigable
Ports: 3 major, 1 minor
Civil air: 8 major transport aircraft
Airfields: 141 total, 111 usable; 3 with permanent-surface runway 4,000-7,999 ft.;
1 seaplane station
Telecommunications: nationwide trunk radio relay system completed; extensive
local telephone exchange improvements completed; connection to international
Central American microwave net began operating November 1971; 39,000 telephones;
460,000 radio and 75,000 TV receivers, 58 AM, 9 FM, and 4 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, $8.7 million; about
6% of central government budget (excludes public security forces)
92
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','ab8670f0d942a1bb8301930bc8df987f6d78c9a3b5dfb333445ccbaf553a3cdf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3667712da3f1c2b95bf4e87f0931d326687536eb4f2770e64610333bcedf4874',1972,'GQ','Equatorial Guinea','communications',127,'LAND:
10,800 sq. mi.; Rio Muni, about 10,000 sq. mi., largely
forested; Fernando Po, about 800 sq. mi.
Land boundaries: 335 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. (fishing
12 n. mi.)
Coastline: 184 mi.
Railroads: none
Highways: Rio Muni -- 1,553 mi.; Fernando Po -- 186 mi.
Inland waterways: Rio Muni has approximately 104 mi. of year-round navigable
waterway, used mostly by pirogues
Ports: 2 major, 3 minor
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: fairly adequate for the size and stage of development of the
country; international conmunications by radio from Bata and Santa Isabel
to Cameroon, Nigeria, and Spain; 1,500 telephones; 71,000 radio receivers;
2 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Military budget: for FY70, $3,475,000, 14.3% of total budget
94
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','65453072c8202528c1b74e9d41f6941bd7dbba79e797c50752d5ecd84b95ac81','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74476aaa82445810bb95f966155f1d18e9de8f398115d83a3ab6ae9c54ee59cd',1972,'ET','Ethiopia','communications',131,'D:
455,000 sq. mi.; 9.5% cropland and orchards, 54.6% meadows
and natural pastures, 6.5% forests and woodlands,
29.4% wasteland, built-on areas, and other
Land boundaries: 3,230 mi.
WATER: ‘
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 680 mi. (includes offshore islands)
Railroads: 630 mi.; 420 mi. 3''3 3/8" gage, 20 mi. 3''6" gage, 190 mi. 3''7
3/8" gage; all single track
Highways: 14,500 mi.; 1,250 mi. bituminous, 3,000 mi. crushed stone, gravel, or
stabilized earth, 10,250 mi. earth
Inland waterways: navigation possible on Lake Tana and on approx. 140 mi. of
unconnected and basically unimproved waterways, of which only 71 mi. are
navigable year round
Ports: 2 major, 1 minor
Civil air: 17 major transport aircraft
Airfields: 196 total, 116 usable; 7 with permanent-surface runways; 5 with run-
ways 8,000-11,999 ft., 52 with runways 4,000-7,999 ft.
Telecommunications: system better than in most African countries; composed of
open-wire lines, radiocommunication stations, and small number of multi-
conductor cable and radio-relay links; principal center Addis Ababa, secondary
center Asmara; 46,000 telephones; 500,000 radio receivers; 8,000 TV receivers;
5 AM, no FM, and 2 TV stations
96
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
WATER:
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less than 4,000 ft.
Civil air: no major transport aircraft
Telecommunications: good international radiocommunications; fair domestic
wire facilities; 6,300 telephones, 11,000 radio receivers, 1 AM, and 3 FM
stations; 1 submarine cable connection
98
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ee ee ee es
ac aE Rt an i” ah, ie i ae','9929a7b19d87fce0e717e5b412016413889ba5cc0f1e07bbd27dce04bee72958','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9472cbd67bc425e96f8ab39c819a49477c1eb57a9ece87c148cad7f05fd0b902',1972,'FJ','Fiji','communications',135,'LAND:
7,055 sq. mi.; landownership -- 83.6% Fijians, 1.7% Indians,
6.4% government, 7.2% European, 1.1% other; about 30%
of land area is suitable for farming
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing 3 n. mi.)
Coastline: 700 mi. (est.)
Railroads: none
Highways: 1,555 mi.s 150 mi. paved, 1,325 mi. gravel or crushed stone, 80 mi.
unimproved earth
101
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Inland waterways: 126 mi.; 76 mi. navigable by motorized craft and 200-ton barges
Ports: 6 major, numerous minor landings
Civil air: 6 major transport aircraft
Airfields: 16, 11 usable; 1 with runway 8,000-11,999 ft., 1 with runway 4,000-7,999
ft,, 2 seaplane stations
Telecommunications: modern local
integrated) public and special-purp
facilities; regional radio center;
U.S./Canada and New Zealand/Australia, et al;
radio receivers; 5 AM, no FM or TV stations
, interisland, and international (wire/radio
ose telephone, telegraph, and teleprinter
important COMPAC cable link between
16,860 telephones; 52,000
DEFENSE FORCES:
Military budget: the defense of the Fiji Islands was the responsibility of the
U.K. until 10 October 1970; the military budget for 1971 is $314,000
102
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','4dc22ece9f645dacbf42ec6a4729a303813b227b9a94dd6b236f996996951cc3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f176d6db6943967201a2686c8d94f62b73fff4e5dc75dd8e7041014bff0c725',1972,'FI','Finland','communications',139,'LAND:
130,000 sq. mi.; 8% arable, 65% forested, 27% other (1966)
Land boundaries: 1,575 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.;
Aland Islands, 3 n, mi.
Coastline: 700 mi. (approx.) includes istands
Railroads: 3,675 mi.; Finnish State Railways (VR) operate a total
3,648 mi. broad gage (5''0"), 288 mi. double track, and 41 mi. electrified;
14 mi. narrow gage (2'' 5 1/2") and 13 mi. broad gage are privately owned
Highways: 44,200 mi., 11,600 mi. bituminous, 31,900 mi. stablized gravel, 700
mi. gravel and earth; 12,400 mi. of private roads (surface type na)
Inland waterways: 4,100 mi. total (including Saimaa Canal); 2,300 mi. suitable
for steamers; canal locks (275 ft. by 42 ft. with a 16.7 ft. depth over sill)
can accommodate vessels of up to 225 ft. in length, 36 ft. beam, and 14.5
ft. draft
Ports: 1] major, 14 minor
Civil air: 35 major transport aircraft
Airfields: 93 total, 73 usable; 28 with permanent-surface runways; 15 with
runways 8,000-11,999 ft., 22 with runways 4,000-7,999 ft.
Telecommunications: facilities provide essential services for government and
industry; 1,181,000 telephones; 1,774,569 radiobroadcast receivers; 1,042,700
TV receivers; 11 AM, 39 FM, and 68 TV stations; 6 submarine cables
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1972, $213.9 million;
about 6% of central government budget
104
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','3081e0618b520d7e0dd1bd50e80307b69814510bfd2f169ce0194f5a6db9bf5a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01c26214a082d50f1d5f9a6da185a9dd3c72704ddda5647462fd91ce79a3d3fb',1972,'FR','France','communications',143,'LAND:
213,000 sq. mi.; 35% cultivated, 26% meadows and pastures,
14% waste, urban, or other, 25% forested (1969)
Land boundaries: 1,795 mi.
WATER: ; : abe
Limits of ae waters (claimed): 12 n. mi. (fishing
l2 n,m.
Coastline: 2,130 mi. (includes Corsica, 400 mi.)','29d63da7bb4586ab019af6f7c61ff66e336b9dfbae2f8f6b3fbbd32898c7cbe1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b7fbb38bffc0c8e7fac99c7ce5cd9e63b3fbbc91982856692e196bca5d54f9c',1972,'GF','French Guiana','communications',145,'LAND:
35,100 sq. mi.; 90% forested, 10% wasteland, built-on,
inland water, and other of which .05% is cultivated
and pasture (1970)
Land boundaries: 735 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 235 mi.
Railroads: 20 mi. private plantation line, 1''11 5/8" gage; 8 mi. abandoned
narrow-gage line
Highways: 450 mi.; 250 mi. paved, 200 mi. improved earth or gravel
Inland waterways: 290 mi.; navigable by smal] oceangoing vessels and river
and coastal steamers; 2,110 mi. possibly navigable by native craft
Ports: 1 major, 7 minor
Civil air: no major transport aircraft
Airfields: 15 total, 13 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft.; 1 seaplane station
Telecommunications: very limited open-wire telecom system with about 5,300
telephones; 25% connected to automatic exchanges; est. 7,000 radio receivers
and nearly 2,000 TV receivers, 1 AM, 2 FM and 2 TV stations; 1 satellite
tracking and control station
110
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
FRENCH TERRITORY OF THE AFARS AND ISSAS
LAND:
9,000 sq. mi.; 89% desert wasteland, 10% permanent pasture,
and less than 1% cultivated (1970)
Land boundaries: 321 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 195 mi. (includes offshore islands)
Railroads: 60 mi. meter gage
Highways: 620 mi.; 50 mi. paved, 570 mi. earth
Ports: 1 major, 1 minor
11]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Airfields: 27 total, 10 usable; 1 with permanent-surface runway; 1 with runway
g8,000-11,999 ft., & with runways 4,000-7 ,999 ft.; 1 seaplane station
Civil air: 5 major transport aircraft (registered in France)
Telecommunications: fair telephone services; poor telegraph facilities; 2,000
telephones; 7,000 radio receivers; 1,100 TV receivers; 1 AM, no FM, and
1 TV stations
DEFENSE FORCES:
Defense is responsibility of France
112
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND
WATER:','01a16f164b720a7cef1e80b113805e210eab942b4e9c8c837eb23cd13a42303e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('158715b2a842d6fb23f657744101af653abd1fa7a000b7ad21a09ae02f541117',1972,'GA','Gabon','communications',152,'Railroads: none
Highways: 3,820 mi.; 125 mi. paved, 1,960 mi. gravel or crushed stone, 1,425 mi.
improved earth, 310 mi. unimproved earth
Inland waterways: approximately 1,000 mi. perennially navigable
Pipelines: crude oi1, 39 m.
Ports: 3 major, 2 minor
Civil air: 1] major transport aircraft
Airfields: 180 total, 99 usable; 2 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: fair telephone and telegraph services; good broadcast
coverage in vicinity of Libreville; 2 AM and 2 TV stations; 7,000 telephones;
62,000 radio receivers; 1,200 TV receivers
DEFENSE FORCES:
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1971, 5,545,000; about 6.3%
of total budget
114
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
WATER:','01ea1f64453f8da25c295821c9ea9b0a69174ddf99a3d0fb89f095972fb67e1d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c26b168e2e712ed66ad152e85f55eb01378924de58077154b76f34002e609bf1',1972,'GM','Gambia','communications',156,'Railroads: none
Highways: 730 mi.; 170 mi. bituminous surface treated, 275 mi. gravel/laterite,
285 mi. unimproved earth
Inland waterways: 377 mi.
Ports: 7] major
Civil air: no major transport aircraft
Airfields: 4 total, 1 usable; 1 with permanent-surface runway; 1 with runway
4,000-7 ,999 ft.; 1 seaplane station
Telecommunications: good telephone and telegraph services; 1,600 telephones,
35,000 radio receivers; 2 AM, no FM or TV stations; 1 submarine cable
116
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
~@&
©
Next 3 Page(s) In Document Denied
Pod
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
STAT
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','bc5e3d4e4f3fae6e3aa612fb33a296203f6b7e20bd192758751c1ebed5c0de84','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e9c6e6de29882d4579dfd5052a0f8b7b499758ef2ad2b15e3c44a43aeab6302',1972,'GH','Ghana','communications',157,'LAND:
92,000 sq. mi.; 19% agricultural, 60% forest and brush,
21% other (1969)
Land boundaries: 1,420 mi.
WATER: : :
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 335 mi.','424d45d3dfc1832ec0035f793d36cf22fd3cdb62aa08b551c10410a86bc2c9b7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9df6f97384d5d0e2a2f54e6cdb1696b5a8caa6e3e640cd60bdf5bbf2758e8fa9',1972,'GR','Greece','communications',163,'51,200 sq. mi.; 29% arable and land under permanent crops,
40% meadows and pastures, 20% forested, 11% wasteland,
urban, other (1966)
Land boundaries: 740 mi.
WATER: : :
Limits of territorial waters (claimed): 6 n. mi. fet
Coastline: 8,500 mi.
Railroads: 1,620 mi.; 980 mi. standard gage (4''8 1/2"), 610 mi. meter gage
(3''3 3/8"), 20 mi. 1''1] 5/8" narrow gage, 10 mi. 2''5 1/2" narrow gage
Highways: 24,200 mi.; 7,100 mi. paved, 9,100 mi. crushed stone and gravel
4,800 mi. improved earth, 3,200 mi. unimproved earth
Inland waterways: system consists of 3 coastal canals and 3 unconnected rivers
which provide navigable length of just less than 50 mi.
Pipelines: crude oi], 16 mi., refined products, 340 mi.
Ports: 17 major, 37 minor
Merchant marine: 1,448 ships (1,000 GRT or over) totaling 13,763,600 GRT,
21,741,400 DWT; inctudes 52 passenger, 898 cargo, 238 tanker, 233 bulk,
25 specialized carrier; ethnic Greeks also own an estimated 19,547,000
GRT under other flags: about 17,038,000 GRT under Liberia, 744,000 under
Panama, 1,705,000 under Cyprus, 46,000 under Lebanon, 5,300 under Malta,
and 8,700 under Somali Republic
Airfields: 57 total, 48 usable; 35 with permanent-surface runways; 16 with
runways 8,000-11,999 ft., 12 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 35 major transport aircraft
Telecommunications: fairly modern networks reach all areas on mainland and
islands; however, services generally inadequate; 1,045,000 telephones; 1.4
million radio receivers; 280,000 TV receivers; 27 AM, 21 FM and 23 TV stations;
9 submarine cables; communications satellite ground station
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $552 million; 28%
of central government budget
126
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','ff776578f1620e9d9e0618d74634abfe83a6036a9cabb18752fb0265ffb9b555','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd61ee3359c846f3640b73ea9e3e7631c85f4526a0ab57bfa8a31bd01508d72a',1972,'GL','Greenland','communications',167,'LAND:
840,000 sq. mi.; less than 1% arable (of which only a
fraction cultivated), 83% permanent ice and snow,
16% other (1964)
WATER: ak,
Limits of territorial waters (claimed): 3 n. mi. (fishing,
12 on, mi,
Coastline: 27,400 mi. (approx., includes minor islands)
Railroads: none
Highways: none
Ports: 7 major, 16 minor
Civil air: 2 major transport aircraft registered in Denmark
Airfields: 11 total, 8 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 7 seaplane stations
127
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Telecommunications: adequate domestic and international service provided by
radio; 2,950 telephones; 7,100 radiobroadcast receivers; 5 AM, 1 FM, and
2 TV stations; 2 submarine cables
128
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
SOVIET SOCIALIST REPUBLICS
: MONGOLIA
eee 3 sia ie een
ALGERIA \\
SAUDI Mata
‘: DO ARABIA” age eee
+ LINITED STATES i ae 7 “ ete
xen) < ek ; REPUBLIC OF CHINA
in SRELANKA
MaLOIves user
ies C v Y
(00K 5 SOON ag i c lea >
2 | eran','1669413b278accb67751e25e46a4ab6859c24ccf1941025a3ebe18b3aefe986e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c85a29dfb46a1c8fe5b3cfa1b60623d72528216cac987aaee6df2e8ea627379',1972,'GD','Grenada','communications',171,'LAND:
133 sq. mi. (Grenada and southern Grenadines); 47%
cultivated, 3% pastures, 12% forests, 20% unused but
potentially productive, 18% built on, wasteland,
other (1964)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 75 mi.
VENEZUELA
PEOPLE: al
Population: 96,000, average annual growth rate 0.6%','f530efe8f76a5a55f06c2baa611be60055b8a80ba2baf08dda198f06bccc223a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5b480155b3dd33741757506eead35d9b9cd3a6324c217611f39088e25196a63',1972,'GP','Guadeloupe','communications',172,'LAND:
687 sq. mi.; 25% cropland, 8% pasture, 19% forest, 48%
wasteland, built on; area consists of two islands (1970)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 190 mi.','03215cd668fefb19dc7b2d95f20ee3b239bb05fae58b3b4aca3c117b8f881f8a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f16beb1c444b361ae14c6a2b6d1808e160bf347e893ae26965a2daf28a257eed',1972,'GT','Guatemala','communications',174,'LAND:
42,040 sq. mi.; 14% cultivated, 10% pasture, 57% forest,
19% other (1967)
Land boundaries: 1,010 mi.
WATER: nee oe
Limits of territorial waters (claimed): 12 n. mi. Bepriieg AS Ca eoueia
Coastline: 250 mi. :
SAGE COLOMBIA','ec10aad1896a4bcc267ac857d8402c3d5974fdd22c27035a04db8a6a52d736db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('311a28554455385fc807effc47f0344ea61e760dba97ee5b0f68a52265b005bb',1972,'GN','Guinea','communications',176,'LAND:
"95,000 sq. mi.; 3.3% cropland, 10% forest (1971)
Land boundaries: 2,160 mi.
WATER: ;
Limits of territorial waters (claimed): 130 n. mi.
Coastline: 215 mi.','bfda394ac45dac6d81f736f8d0b64b0aadf5422de1c4652173f845c5fe74b9a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc8e8609ec0d2c87e889b77630ed74f08a488598fe3e4eafb7f5cf6cbbf0a519',1972,'GY','Guyana','communications',183,'Railroads: 164 mi., all single track; 146 mi. 4''8 1/2" gage, 18 mi. 3''6" gage
Highways: 1,200 mi.; 450 mi. paved, 550 mi. otherwise improved, 200 mi. unimproved
Inland waterways: 3,700 mi.; Demerara River navigable to Mackenzie by ocean
steamers, others by ferryboats, small craft only
Ports: 1 major, 3 minor
Civil air: 6 major transport aircraft
Airfields: 102 total, 89 usable; 4 with permanent-surface runways; 12 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: highly developed telecom system with muitistation radio
relay network and over 14,600 telephones; tropospheric scatter link to
Trinidad; 200,000 radio receivers, 2 AM stations
DEFENSE FORCES:
Supply: mostly U.K., some U.S. equipment
Military budget: for fiscal year ending 31 December 1969, $2.35 million; 2.8%
of central government budget
138
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','7bb97092bb8ba5a82eab496421839dab8c93573b96339573c4b0dc7e63217845','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('614bca288118f08ee3f3c58d58afd4533a00c4aa31a4aeeea865e545be620385',1972,'HT','Haiti','communications',184,'LAND:
10,700 sq. mi.; 31% cultivated, 18% rough pastures,
10% forested, 44% unproductive (1960)
Land boundary: 224 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. VENEZUELA
Coastline: 1,100 mi.
Railroads: 120 mi. 2'' 6" gage, single-track, privately owned industrial line; 5
mi. dual-gage 2'' 6"-3° 6"; government line dismantled
Highways: 2,000 mi.; 350 mi. paved, 600 mi. otherwise improved, 1,050 mi.
unimproved
Inland waterways: negligible; about 60 mi. navigable
Ports: 2 major, 12 minor
Civil air: 4 major transport aircraft; 3 owned by the air force, 1 privately owned
Airfields: 31 total, 17 usable; 3 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: all domestic facilities inadequate, international facilities
only slightly better; slow progress in large-scale telephone expansion
program; only 4,450 telephones, est. 282,000 radio and 8,000 TV receivers,
25 AM, 3 FM, and 1 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1972, $5,800,000; about
18% of operational budget
140
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','c179d711f04042e44932d81daef6be92af7225532de0c49d069df4b647f08f77','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0b6278cf266e23a971f6bde2784a4f5e5e03a27b681d1c3641263987cac1258',1972,'HN','Honduras','communications',188,'LAND:
43,300 sq. mi.; 27% forested, 30% pasture, 36% waste,
7% cropland (1966)
Land boundaries: 950 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 510 mi.
Railroads: 743 mi.; 443 mi. of 3''6" gage, 300 mi. of 3''0" gage
Highways: 5,300 mi.; 600 mi. paved, 1,500 mi. otherwise improved, 3,200
unimproved
Inland waterways: 750 mi. navigable by small craft
Ports: 3 major, 9 minor
Merchant marine: 12 cargo ships (1,000 GRT or over) totaling 58,500 GRT, 54,800
DWT; all foreign owned and operated
Civil air: 25 major transport aircraft
Airfields: 212 total, 117 usable; 4 with permanent-surface runways; 8 with run-
ways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: improved, but still inadequate for ail requirements; instal-
lation of radio relay system completed; connection to international Central
American microwave net operational November 1971; 13,600 telephones; 300 ,000
radio and 21,000 TV receivers; 59 AM, 5 FM, and 6 TV stations
DEFENSE FORCES:
Supply: traditional dependence on U.S. has for the time being shifted to
Western Europe
Military budget: for fiscal year ending 31 December 1971, $11,400,000; about
9% of central government budget (includes the armed forces and the Special
Security Corps)
142
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','c41db3393c89ab197171c8a7bd140bd5bcff7bfc088c94f20750f83e7687adae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('045c025bc61dacb5bbbefaf32f8b66210fa3b763b72ea913d14638cb74e6b65f',1972,'HK','Hong Kong','communications',192,'LAND:
A400 sq. mi.; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country) (1970)
Land boundaries: 15 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 455 mi.
Railroads: 22 mi. standard gage; government owned
Highways: 600 mi.; 410 mi. paved, 190 mi. gravel and crushed stone, or earth
Freight carried: rail -- 903,180 short tons (FY68)
Ports: 1 major
Civil air: 10 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.; 1 seaplane station
DEFENSE FORCES:
Defense is the responsibility of U.K.
144
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','0c66796f7322c822d28c8725d78ce275ed95163e5fd1d0917d71daaa96857056','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a6ba6d5a9651842e2f7bc62917d4edbd53625b86cdf639311b7dabe67e7df41',1972,'LY','Libya','communications',199,'Railroads: 5,908 route mi.; 5,098 mi. standard gage, 788 mi. narrow gage
(mostly 2'' 5 7/8"), 22 mi. broad gage (5''0"), 688 mi. double track, 581
mi. electrified; government owned (1970)
Highways: 18,360 mi.; 11,048 mi. paved, 6,558 mi. crushed stone or gravel, 754
mi. earth (1970)
Pipelines: crude oi], 400 mi.; natural gas, over 1,500 mi.
Inland waterways: 1,320 mi. (1972)
Freight carried: rail -- 129.6 million short tons (1970), 13.5 billion short ton/mi.
(1970); highway -- 440 million short tons, 3.9 million short ton/mi. (1970);
waterway -- 3.5 million short tons, 1.9 billion short ton/mi. (1970)
River ports: 2 principal (Budapest, Dunaujvaros); no maritime ports; outlets are
Rostock, East Germany and ports in Poland (1972)
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, 9.72 billion forints;
about 4.5% of total budget
146
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ha
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
679,000 sq. mi.; 6% agricultural, 1% forested, 93%
desert, waste, or urban (1962)
Land boundaries: 2,700 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,100 mi.
Railroads: none
Highways: 8,915 mi.; 3,772 mi. bituminous or bituminous treated, 5,143
mi. improved and unimproved earth and gravel
Pipelines: crude of] 1,890 mi.; natural gas 311 mi.; refined products 143 m.
Ports: 4 major, 12 minor
Civil air: 8 major transport aircraft; an additional 27 major transports are
operated by external carriers engaged in charter work for several 071 companies
Airfields: 103 total, 80 usable; 13 with permanent-surface runways; 5 with runways
8,000-11,999 ft., 35 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: system is just within top one-third of African systems; con-
sists of radio-relay and tropospheric-scatter links, open-wire lines, and
radiocommunication stations; principal centers are Tripoli and Benghazi;
34,790 telephones; 225,000 radio and 12,500 TV receivers; 7 AM, 1 FM, and
2 TV stations; 3 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1972, $84,034,000; 21.3% of
announced budget; 15.0% of operating budget
190
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:','ae5e18324f9b6877d5bfce37205ad0feeecbd961c52a3e9b4ce7b14ded2ac4df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f27ad00f2c0d50f512b9120546b06bf120ed53b8277159cefbfeadb7b5f714c7',1972,'IS','Iceland','communications',200,'LAND : GREENLAND
39,750 sq. mi.; arable negligible, 22% meadows and
pastures, forested negligible, 78% other (1967)
WATER:
Limits of territorial waters (claimed): 4 n. mi. (fishing,
: 50 n. mi., effective 1 September 1972)
Os Coastline: 3,100 mi.
a PEOPLE:
Population: 208,000, average annual growth rate 1.1%
1 (December 65-70); males 15-49, 49,000; 41,000 fit Ns le
i for military service (Iceland has no conscription -
% or compulsory military service)
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 2%
no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 80,000; 22.6% agriculture and fishing; 25.6% mining and manufacturing;
10.7% construction; 12.8% commerce; 7.8% transportation and communications;
15.2% services; and 4.0% other; unemployment is insignificant
Organized labor: 60% of labor force
Railroads: none
Highways: 7,400 mi.; 4,760 mi. crushed stone (including lava) and gravel, 2,593
mi. unsurfaced roads and motorable tracks, 47 mi. concrete (some bituminous
stretches)
Ports: 5 major, 55 minor
Civil air: 15 major transport aircraft
Airfields: 108 total, 93 usable; 4 with permanent-surface runways; |] with
runway 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: adequate domestic service provided by wire telephone and
telegraph system which circles island; good international radiocommunica-
tion service; 70,900 telephones; 65,000 radiobroadcast receivers; 40,000 TV
receivers; main AM and FM station in Reykjavik is relayed by 5 AM, 15 FM,
and 59 TV stations; 2 submarine cables
148
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
a ee eT
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','127b05b248a1bf21b215323046b75a51e97e12920417fbf9d82f1e8e78eb7db2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('363f612da45867ba5149a9e68f662081a0fb937a1539114d07982419cdb73f06',1972,'IN','India','communications',203,'LAND:
1,211,000 sq. mi. (includes Indian part of Jammu-
Kashmir, Sikkim, Goa, Damao and Diu); 50% arable,
5% permanent meadows and pastures, 20% desert,
waste, or urban, 22% forested, 3% inland water (1968)
Land boundaries: 8,430 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing,
12 nh. mi.) (100 mi. is fisheries conservation zone,
December 1968)
Coastline; 3,300 mi.
Railroads: 37,276 mi.; 16,070 mi. meter (3''3 3/8") gage, 18,170 mi. broad gage,
2,625 mi. (2''6" and 2''0") narrow gage government owned; 411 mi. 2''6" and
2''0" gage privately owned; 6,484 mi. double track; 2,018 mi. electrified
Highways: 643,028 mi.; 106,854 mi. paved, 95,054 gravel or crushed stone, 184,631
improved earth, 256,489 mi. unimproved earth
Inland waterways: 8,410 mi.; 1,600 mi. navigable by river steamers
Ports: 7 major 53 minor
Airfields: 611 total, 372 usable; 190 with permanent-surface runways; 2 with
runway over 12,000 ft., 49 with runways 8,000-11,999 ft., 137 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: fair domestic telephone service where available in and
between major cities; facilities and services diminish in quantity and
quality as size of communities decreases and distance between increases;
telephone distribution is less than 2 per 1,000 population; telegraph
facilities widespread; AM broadcast adequate; TV limited to Delhi -- New
Delhi; international telephones and telegraph adequate; 1,245,352 telephones;
11.7 million radio and 24,833 TY sets; AM stations at 70 locations, 1 TV
station; submarine cables extend to Malaysia, Sri Lanka, and Aden
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1973, $2.1 billion; 25% of
total budget
150
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','2a787cc1d46383901d3efcda1284b1ca22cab29ac6d7b9a7483fb3a441c69084','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('585d29d6a0774cb467a6e6abd9dbe90a928580cc22cb5c4da8548d1fa21adc8d',1972,'ID','Indonesia','communications',207,'LAND:
736,000 sq. mi.; 11% small holdings and estates, 64% for-
ests, 25% inland water, waste, urban, and other (1970)
Land boundaries: 1,700 mi.
WATER:
Limits of territorial waters (claimed): under an archipelago
theory, claim is 12 n. mi., measured seaward from
straight baselines connecting the outermost islands
Coastline: 34,000 mi.','93acc0dcf0ee50fc0b65f0b971769cd3fcfd1f3ab3cd187d7f7dc041a382158d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11a60532b3acd6b99501bbaa76b28ef62ad1f704d5d39ff4657bd06029625536',1972,'IE','Ireland','communications',208,'LAND:
26,600 sq. mi.; 17% arable, 51% meadows and pastures,
3% forested, 2% inland water, 27% waste and urban
(1967)
Land boundaries: 224 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing,
12 n,m.)
Coastline: 900 mi.
PEOPLE: ALGERIA
Population: 2,993,000, average annual growth rate 0.6%
(April 66-71); males 15-49, 680,000; 535,000 fit for military service;
about 28,000 reach military age (17) annually
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Episcopalian, 2% other
Language: English and Gaelic official; English is generally spoken
Literacy: 98%-99%
Labor force: about 1,130,000; 28% agriculture, forestry, fishing; 19% manufac-
turing; 15% commerce; 6% construction; 5% transportation; 4% government;
18% other
Organized labor: 36% of labor force
Railroads: 1,333 mi., 5''3" gage; government-owned
Highways: 53,700 mi.; 46,950 mi. surfaced, 6,750 mi. earth
Inland waterways: approx. 650 mi.
Ports: 6 major, 38 minor
Civil air: 27 major transport aircraft
Airfields: 30 total, 25 usable; 7 with permanent-surface runways; T with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: small, modern system; all cities interconnected for telephone
and telegraph service and broadcast netting; 296,000 telephones; 566 ,000
radiobroadcast receivers; 416,000 TV receivers; 3 AM, 9 FM, and 22 TV stations;
12 submarine cables
DEFENSE FORCES:
Supply: formerly from the U.K. primarily, but since 1961 from other European
countries
Military budget: for fiscal year ending 31 March 1972, $45.9 million; about
3.7% of the central government budget
158
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
~@&
©
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
STAT
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','b4576d15c07138dd1c7f20dfb4ba597ca6aa15cc00f2088b53fdd6e48fcb3800','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1596635a2a62b3da73d451c75d807b0e676ae1f96f7eadd22e847c3a02b2d467',1972,'IT','Italy','communications',211,'LAND:
116,300 sq. mi.; 50% cultivated, 17% meadow and pasture, 21%
forest, 2% inland water, 10% waste or urban (1969)
Land boundaries: 1,058 mi.
WATER:
Limits of territorial waters (claimed): 6 n
12 n. mi.)
Coastline: 3,105 mi.
. mi. (fishing,
Railroads: 12,890 mi.; 11,390 mi. 4''8 1/2" gage, 1,490 mi. 3''1 3/8" gage, 2,860
mi. double track 4'' 8 1/2" gage, 120 mi. double track 3‘ 1 3/8" gage, 5,712
mi. electrified 4'' 8 1/2" gage, 320 mi. electrified 3'' 1 3/8" gage
Highways: 126,500 mi.; state highways 25,985 mi., provincial highways 45,850 mi.,
communal highways 54,665 mi.; 60,200 mi. concrete, bituminous, or stone block,
66,300 mi. gravel and crushed stone
Inland waterways: 2,547 mi. navigable routes; 1,780 mi. are rivers and
canals, 1,367 mi. are lake routes
Pipelines: crude oil], 1,300 mi.; refined products, 980 mi.; natural gas, 5,500
mi.
Ports: 16 major, 148 minor
162
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
sy
Cotpeeh Ogee TE Tp eer poe ee
er To
ener —:
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Civil air: 130 major transport aircraft
Airfields: 228 total, 151 usable; 79 with permanent-surface runways; 2 with
runways over 12,000 ft., 25 with runways 8,000-11,999 ft., 47 with runways
4,000-7,999 ft.; 11 seaplane stations
Telecommunications: well engineered, well constructed, and efficiently operated;
almost 8.53 million telephones; 12.5 million radio and 10.4 million TV
receivers; 68 AM, 160 FM, and 65 TY stations, each with numerous repeater
stations; 11 submarine cables; communication satellite ground stations
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1972, $3.2 billion;
about 12% of central government budget
163
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
IVORY COAST
LAND:
125,000 sq. mi.; 40% forest and woodland, 8% cultivated,
52% grazing, fallow, and waste, 200 mi. of lagoons
and connecting canals along eastern coast (1970)
Land boundaries: 2,005 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 320 mi.
Railroads: 408 mi. of the 728 mi. Abidjan to Ouagadougou, Upper Volta line, all
single track meter gage; only diesel locomotives in use
Highways: 24,600 mi.; 800 mi. bituminous and bituminous-surface treatment;
11,200 mi. gravel, crushed stone, laterite, and improved earth; 12,600
mi. unimproved earth roads
Inland waterways: 460 mi. navigable rivers and numerous coastal lagoons
Ports: 2 major, 1 minor
Civil air: 15 major transport aircraft
Airfields: 50 total, 44 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: system only slightly above African average; consists of
microwave relays, open-wire lines and radio relay links, which provide
incomplete coverage of country; Abidjan is only center; 24,800 telephones;
75,000 radio and 10,500 TV receivers; 3 AM, 2 FM, and 4 TY stations; 2
submarine cables; satellite earth station under construction
DEFENSE FORCES:
Supply: principally dependent on France; has purchased transport aircraft from','9cdc13d7f4bfef650a0b9fb6b5ec8bac4d096acc3bd95474f14dbc3cdfdb7f3a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85e73f444c4ac79e1d4fb53417cdc7bf4417733ef34fa3cd8baa0064e1e7f958',1972,'NL','Netherlands','communications',215,'Military budget: for fiscal year ending 31 December 1972, $21,431,400; about
8.0% of total budget
166
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
14,100 sq. mi.; 24% cultivated, 31% meadows and pastures,
31% waste or urban, 8% forested, 8% inland water (1969) ee
Land boundaries: 635 mi. (ren en
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 280 mi.
Railroads: 1,956 mi., standard gage; 970 mi. double track; 1,022 mi. electrified
Highways: 46,000 mi.; 26,000 mi. paved, 4,000 mi. crushed stone and gravel,
16,000 mi. earth
Inland waterways: 3,940 mi.; less than 962 mi. is natural river; more than 1,400
mi. navigable by craft of 1,000-ton capacity; 1,01] mi. will take 1,500-ton
vessels
Pipelines: crude oi], 254 mi.; refined products, 602 mi.; natural gas, 4,203 mi.
Ports: 8 major, 5 minor
Civil air: 91 major transport aircraft
Airfields: 27 total, 25 usable; 16 with permanent-surface runways; 12 with
runways 8,000-11,999 ft., 3 with runways 4,000-7,999 ft.
Telecommunications: highly developed, excellently maintained, and weil integrated;
extensive system of multiconductor cables, supplemented by radio relay links,
submarine cables, and radiocommunication stations; 3.41 million telephones;
4.81 million radiobroadcast and 3.04 million TV receivers; 5 AM, 12 FM, and
7 TV stations which provide countrywide service; 10 submarine cables
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1972, $1,433 million;
about 12% of central government budget
234
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
NETHERLANDS ANTILLES
LAND:
394 sq. mi.; 5% arable, 95% waste, urban, or other (1951)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 226 mi.
VENEZUELA
Railroads: none
Highways: 700 mi.; 350 mi. paved, 220 mi. otherwise improved, 130 mi, unimproved
Ports: 3 major, 6 minor
Civil air: 6 major transport aircraft
Airfields: 7 total, all usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1] seaplane station
Telecommunications: generally adequate telecom facilities; extensive inter-
island VHF links; plan troposcatter link to Curacao, Venezuela; 27,650
telephones, 105,000 radio and 30,000 TV receivers, 10 AM and 2 TV stations,
4 telegraph submarine cables
236
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','e54b2f4e78b12cf4e755071ca3c3de17b270b9621894310a9273f178cddcdad8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a69ae2c072041a36879016e5d7a33c33c506175422f5494909149175e951c213',1972,'JM','Jamaica','communications',216,'LAND:
4,410 sq. mi.; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other (1964)
WATER: ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 635 mi.
Railroads: 204 mi. government-owned, 43 mi. privately owned, all standard gage,
single track
Highways: 7,100 mi.; 1,200 mi. paved, 4,400 mi. gravel, 1,500 mi. unimproved
earth surfaces
Pipelines: refined products, 6 mi.
Ports: | major, 1] minor
Civil air: 3 major transport aircraft
Airfields: 47 total, 35 usable; 10 with permanent-surface runways; | with run-
way 8,000-11,999 ft., 2 with runway 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fully automatic domestic telephone network with 71,800
telephones intraisland VHF network; satellite ground station officially opened
February 1972; to be operational in 1971; 500,000 radio and 70,000 TV receivers;
8 AM, 5 FM, and 8 TV stations; 5 submarine cables, including 2 coaxial, with
third coaxial being laid and expected to be completed about the end of 1971
DEFENSE FORCES:
Supply: dependent on U.K. and U.S.
Military budget: for fiscal year ending 31 March 1972, $7.4 million; about 2.0%
of central government budget
168
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
~@&
V4
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
STAT
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','6e978bcf905730b9640c9d369f43fc9dba20b1cd3bb6175253169df9ecb44c17','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29e34d23fc1ebfd9ba75506c852f7b522c2365ab9eb74b2ad1c16e85ed5252d8',1972,'JO','Jordan','communications',220,'NOTE: The war between Israel and the Arab states in June 1967
ended with Israel in control of West Jordan. Although
approx. 930,000 persons resided in this area prior to the
start of the war, fewer than 750,000 of them remain there
under the Israeli occupation, the remainder having fled
to East Jordan. Over 14,000 of those who fled were
repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These and
certain other effects of the Arab-Israeli war are not
included in the data below.
LAND:
37,100 sq. mi. (including about 2,100 sq. mi. occupied by Israel); 11%
agricultural, 88% desert, waste, or urban, 1% forested (1964)
Land boundaries: 1,141 mi. (1967, 1,037 mi. excluding occupied areas)
WATER: .
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 16 mi.
Railroads: 227 mi. 3''5 3/8" gage, single track
Highways: 4,400 mi.; 3,486 mi. bituminous, 249 mi. improved, 665 unimproved earth
(these mileages include approximately 670 mi. -- mostly bituminous -- of
Jordanian territory held by Israel)
Pipelines: crude oil, 128 mi.
Ports: 1 major
Civil air: 5 major transport aircraft
Airfields: 52 total, 18 usable; 10 with permanent-surface runways; 2 with
runways over 12,000 ft., 9 with runways 8,000-11,999 ft., 4 with runways
4,000-7,999 ft.; 1] seaplane station
Telecommunications: adequate telecommunication system for the needs of the
country; 31,100 telephones; 150,000 radio and 55,000 TV receivers; 1 AM
and 2 TV stations; I] earth satellite station
172
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','dc4fb85fc04f5f040885b1352b941b86aee4f1e8872d651b7405ff464368dba8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc86688fe9788820b5f505075680381c34066bc3304751f08c33d6bab2f419de',1972,'KE','Kenya','communications',224,'LAND:
225,000 sq. mi.; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland
adequate for grazing (1970)
Land boundaries: 2,093 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 333 mi.
Railroads: 1,275 mi.; meter gage
Highways: 26,970 mi.; 1,532 mi. paved, 8,849 mi. gravel or improved earth, about
16,589 mi. unimproved or tracks
Inland waterways: part of Lake Victoria and Lake Rudolph are within boundaries
of Kenya
Ports: 1 major, 3 minor
Civil air: 10 major transport aircraft
Airfields: 262 total, 205 usable; 6 with permanent-surface runways 3 1 with
runway over 12,000 ft., 1 with runways 8,000-11,999 ft., 43 with runways
4,000-7,999 ft.; 3 seaplane stations
Telecommunications: in top group of African systems; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Nairobi, secondary centers Mombasa and Nakuru; 77,500 telephones; 774,000
radio and 16,400 TV receivers; 5 AM, 2 FM, and 3 TV stations; 2 submarine
cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1971, $16,392,000; about 5.0% of
ordinary budget
174
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
KOREA, NORTH
PEOPLE''S REP.
OF CHINA
LAND:
47,000 sq. mi.; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban (1971)
Land boundaries: 1,040 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,550 mi.
Railroads: 2,818 route mi. operating in 1968; 2,137 mi. standard gage, 681] mi.
2''6" narrow gage; 99 mi. double tracked, about 588 mi. electrified; government
owned
Highways: about 12,600 mi., 95% gravel or earth surface
Iniand waterways: 1,400 mi.; mostly navigable by small craft only
Freight carried (1969): rail -- 13 billion metric ton/km., 62 million metric
tons; highway -- 765 million metric ton/km., 116 million metric tons;
waterway -- 540 million metric ton/km., 7.7 million metric tons; coastal --
170 million metric ton/km., 0.4 million metric tons
Ports: 6 major, 26 minor
176
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
KOREA, SOUTH
LAND: OF CHINA —p
38,000 sq. mi.3; 23% arable (22% cultivated), 10% urban
and other, 67% forested (1968)
Land boundaries: 150 ini.
WATER: ;
Limits of territorial waters (claimed): 20-200 n. mi.
Coastline: 1,550 mi.
Railroads: 1,964 mi.; 1,887 mi. standard gage, 77 mi. (2''6") narrow gage; 280
mi. double track; government owned
Highways: 25,500 mi.; 1,845 mi. paved, 18,500 mi. gravel, 3,200 mi. improved
earth, 1,955 mi. unimproved earth
Inland waterways: 1,000 mi.; use restricted to small native craft
Freight carried: rail (1963) 2,708.2 million short ton/mi., 19.8 million short
tons; highway (1963) 21.9 million short tons; air (1959) 796,260 Ibs. carried
Pipelines: 255 mi., refined products, under construction
Ports: 10 major, 10 minor
Airfields: 258 total, 125 usable; 47 with permanent-surface runways; 9 with
runways 8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 2 seaplane stations
178
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Se eemeeeg ty J ah
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
6,200 sq. mi. (excluding neutral zone but including islands);
Land boundaries: 285 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 310 mi.','da15843c12ec1aacc78e6601b20e4be96039dc05a2e1659704206e38c5b49903','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3af8ae771ecaf9c465b035a2fb857b9830850975fcd9358c676875df30a30094',1972,'KW','Kuwait','communications',231,'Railroads: none
Highways: 1,550 mi.; 465 mi. bituminous; 1,085 mi. earth, sand, light gravel
Pipelines: crude oi], 254 mi.; refined products, 27 mi.; natural gas, 74 mi.
Ports: 2 major, 1 minor
Civil air: 5 major transport aircraft
Airfields: 13 total, 2 usable; 2 with permanent-surface runways; ] with runway
8,000-11,999 ft., 1 with runways 4,000-7 ,999 ft.
Telecommunications: excellent international radiocommunications; adequate
domestic telecommunication facilities; 58,000 telephones; 105,000 radio
and 100,000 TV sets; 3 AM and 3 TV stations
DEFENSE FORCES:
Supply: dependent on U.K.
Military budget: for fiscal year ending 31 March 1972, $86,800,000; about 11.7%
of total budget
180
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAOS
LAND:
91,430 sq. mi.; 7% agricultural, 60% forests, 33% urban,
waste, and other; except in very limited areas, soil
is very poor; most of forested area is not exploitable
(May 1969, est.)
Land boundaries: 2,700 mi.
Highways: about 9,200 mi. (including Communist-held areas); 500 mi. bituminous
or bituminous treated, 1,900 mi. gravel, crushed stone, or improved earth;
6,800 mi. unimproved earth and often impassable during rainy season
mid-May to mid-September
Inland waterways: about 2,850 mi., primarily Mekong and tributaries; 1,800
additional miles are sectionally navigable by craft drawing less than 1.5 ft.
Ports (river): 5 major, 4 minor
Airfields: 279 total, 212 usable; 5 with permanent-surface runways; 18 with
runways 4,000-7,999 ft., 1 with runway 8 ,000-11,999 ft.
Telecommunications: service to general public considered poor; radio network
provides generally erratic service to government users; poor international
service recently improved by radio relay link to Thailand; radiobroadcast
transmitters operate in a few towns; 1,148 telephones; 70,000 (est.) radio
receivers
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $17.9 million; about 51%
of total budget
182
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','940dcd0f396f022015174b2617b4c3f6d0315e9466ac22f0cefb5902d6f10343','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0556ac4208582ccddf759a6f29885ca1a53f3cf4a7030a4e68c7b0a6a7844d10',1972,'LB','Lebanon','communications',232,'LAND:
4,000 sq. mi.; 27% agricultural land, 64% desert, waste,
or urban, 9% forested
Land boundaries: 285 mi.
WATER:
Limits of territorial waters (claimed): no specific claims
(fishing, 6 n. mi.)
Coastline: 140 mi.
Highways: 5,133 mi.; 3,821 mi. paved, 342 mi. gravel and crushed stone, 373 mi.
improved earth, 597 mi. unimproved earth
Pipelines: crude oi], 85 mi.
Ports: 3 major, 5 minor
Civil air: 20 major transport aircraft
Airfields: 11 total, 3 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft.; 1 seaplane station
Telecommunications: excellent international telecommunication facilities include
aph service;
satellite ground station; good domestic telephone and telegr
150,500 telephones; 600,000 radio and 300,000 TV receivers; 7 TV, 2 FM, and
1 AM radiobroadcast stations; 1 submarine cable
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, $69.1 million; about
22.0% of proposed total budget
184
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','07f1750bb02b29734a642ed6d4d5ac830376a9edb15227d909465481dcc5cdec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77d782830bb7cad37669846ae13ec12500838bec02a49a10f2d1bfcc9b83c177',1972,'LS','Lesotho','communications',236,'LAND:
11,700 sq. mi. (1972); 15% cultivable; largely mountainous
Land boundaries: 500 mi.
Railroads: 1 mi.; owned, operated, and included in the statistics of the Republic
of South Africa
Highways: approx. 1,136 mi.; 76 mi. paved; 269 mi. crushed stone, gravel, or
stablized soil; 791 mi. improved or unimproved earth
Civil air: no major transport aircraft
Airfields: 36 total, 21 usable; 3 with runways 4,000-7,000 ft.
Telecommunications: system a modest one consisting of a few landlines, a small
radio-relay system, and minor radiocommunication stations; Maseru is the
center; 2,400 telephones; 5,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
None, police only
186
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','b2b13a6ff303016b29dbeec70c99244d0d7b92b0c20524cc9468bfb3c2c46612','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f2968d84d53c116d94bcc05bdc438425096371aee498bb04d2f5576ed5f039c',1972,'LR','Liberia','communications',240,'LAND:
43,000 sq. mi.; 20% agricultural, 30% jungle and swamps,
40% forested, 10% unclassified (1969)
Land boundaries: 830 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi.
Railroads: 310 mi.; 220 mi. standard gage, 90 mi. narrow gage (3''6"); all lines
single track; rail systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 4,150 mi.; 325 mi. bituminous treated, 875 mi. laterite, 2,950 mi.
unimproved
Inland waterways: 230 mi. navigable
Ports: 3 major, 4 minor
Civil air: 2 major transport aircraft
Airfields: 63 total, 51 usable; 3 with permanent-surface runways; ] with runway
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph limited; main center is Monrovia;
6,000 telephones; 155,000 radio and 6,500 TV receivers; 3 AM, no FM,
2 TV stations; 2 submarine cables
188
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','be4761df3cc7d11ea74bfa4edb81d8084d76a78d29c130607fc45c87c0da371f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('077d4f6876bb61a52258328c82eb383fcd1549d0a70e344781c7085d4c6e6c7b',1972,'LI','Liechtenstein','communications',248,'Railroads: 9.94 mi. 4''8 1/2" gage, electrified; owned, operated, and included in
statistics of Austrian Federal Railways
Highways: no information on total mileage
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serving about 9,500 telephones;
no broadcast facilities; 4,000 radio and 3,400 TV receivers (programed from
Switzerland)
191
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
DEFENSE FORCES:
Defense is responsibility of Switzerland
192
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','5de8ad7ded0b2f71b8875de8c54f611956b6c5f694bcd546198b8ef04c9174fe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0921f330741fbf6b1db7bc158528e717d29920a6bddc7214b79da4389f280484',1972,'LU','Luxembourg','communications',249,'LAND:
1,000 sq. mi.; 26% arable, 26% meadows and pasture, 16%
waste or urban, 32% forested, negligible amount of see
inland water (1969) te C east POLAND
° f 3
Land boundaries: 221 mi. me eo
LUXEMBOURG oo ASY NSEC
Railroads: 203 mi. standard gage; 100 mi. double track; 85 mi. electrified
Highways: 3,070 mi.; all paved
Pipelines: refined products, 30 mi.
Inland waterways: 23 mi.; Moselle River
Port: Mertert
Civil air: 7 major transport aircraft
Airfields: 2 total, 1 usable with permanent-surface runway 8,000-11,999 ft.
Telecommunications: adequate and efficient modern system, Serves as transfer
point for international European communications ; 111,500 telephones; 152,000
radiobroadcast receivers; 66,600 TV receivers; AM megawatt service of Radio
Luxembourg reaches most of Europe; 3 FM stations; | TV station with 6 relays
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, $10.1 million; 3.0% of
central government budget
194
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
*
’
——
ee err.
cae ge Imes “Pa eS mae: eT STEN Et ety cae pm eo serene cenmg r rm sm Teme . ee
= a CERTAIN a AR SM Tak it all a came mo
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','b732e9875a4ec7a6d35fa830b44e09741c9b472e081fa8091c35a9f8b345b465','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab1d33da32d0bf008a9aeab8c4271483d3ca36d6f589857a82fb96b176567ac5',1972,'MO','Macao','communications',253,'LAND:
6 sq. mi.; 10% agricultural, 90% urban (1968)
Land boundaries: 220 yds.
WATER:
Limits of territorial waters (claimed): 6 n. mi;
fishing, 12 n. mi.
Coastline: 25 mi.
Highways: 26 mi. paved
Ports: 1 major ;
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
DEFENSE FORCES:
Defense is responsibility of Portugal
196
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
WATER:
Railroads: 540 mi. of meter gage
Highways: 5,300 mi.; 1,550 m. paved 2,550 mi. crushed stone, gravel, or stabi-
lized soil; 1,200 mi. improved and unimproved earth; remainder are tracks
Inland waterways: 1,200 mi. navigable; Lac Alaotra (200 sq. mi.)
Ports: 4 major, 13 minor
Civil air: 1] major transport aircraft
Airfields: 363 total, 174 usable; 23 with permanent-surface runways; 3 with run-
ways 8,000-11,999 ft., 49 with runways 4,000-7,999 ft.; 6 seaplane stations
Telecommunications: telephone and telegraph generally adequate in urban areas;
27,000 telephones; 500,000 radio and 300 TV receivers; 4 AM, no FM, and
1] TV stations
DEFENSE FORCES:
Supply: largely dependent on France; has received some ground force materiel
from Israel and West Germany
198
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','43c1943b428998ed30a1be13b171f5455bb2a9004328b8d13378dbfa1927215e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1b12e6ba956efa4fdd93cfd2eb46293773664b0277b4f8ac2572f6200006d7b',1972,'MW','Malawi','communications',257,'D:
36,700 sq. mi.; about 31% of land area arable (of which
less than half is cultivated), nearly 25% forested,
6% meadow and pasture, 38% other (1966)
Land boundaries: 1,790 mi.
Railroads: 352 mi. (3''6" gage)
Highways: 6,610 mi.; 430 mi. paved; 555 mi. crushed stone, gravel, or stabilized
soil; 5,625 mi. earth
Inland waterways: Lake Nyasa (Lake Malawi), 800 route mi. and Shire River, 90 mi.
Ports: 2 minor
Civil air: 5 major transport aircraft
Airfields: 40 total, 38 usable; 1 with permanent-surface runway; 8 with
runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is barely above average for African countries
and consists of thinly spread open-wire lines, radio-relay links, and
radiocommunication stations; principal centers are Blantyre and Zomba;
13,000 telephones; 106,000 radio receivers: 5 AM, 4 FM and no TV stations
200
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','63915b48bc8c3d711602246d757eed6467ae0527886af7f268e83a68895e769e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c6f7af1c100a34659ac82d0ac356c69f8df4222c74c3a117d63761590449ef9',1972,'MY','Malaysia','communications',261,'NOTE:
Malaysia, which came into being on 16 September 1963,
consists of West Malaysia, which includes 11 states
of the former Federation of Malaya, plus East
Malaysia, which includes the 2 former colonies of
North Borneo (renamed Sabah) and Sarawak
LAND:
West Malaysia: 50,700 sq. mi.; 20% cultivated, 26%
forest reserves, 54% other (1965)
Sabah: 29,400 sq. mi.; 13% cultivated, 34% forest
reserves, 53% other (1966)
Sarawak: 48,300 sq. mi.; 21% cultivated, 24% forest reserves,
55% other (1966)
Land boundaries: West Malaysia 315 mi., East Malaysia 873 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: West Malaysia, 1,045 mi., East Malaysia 1,439 mi.
Railroads:
West Malaysia: 1,014 mi. 3''3 3/8" gage; 8 mi. double track; government-owned
East Malaysia: 96 mi. meter gage in Sabah
Highways :
West Malaysia: 10,500 mi.; 8,925 mi. hard surfaced (mostly bituminous surface
treatment), 1,150 mi. crushed stone/gravel, 425 mi. improved or unimproved
earth
East Malaysia: about 3,140 mi. (1,608 in Sarawak, 1,532 in Sabah); 520 mi.
hard surfaced (mostly bituminous surface treatment), 1,853 mi. gravel or
crushed stone, 767 mi. earth
Inland waterways:
West Malaysia: 1,985 mi.
East Malaysia: 2,540 mi. (975 mi. in Sabah, 1,565 mi. in Sarawak)
Ports:
West Malaysia: 3 major, 10 minor
East Malaysia: 4 major, 7 minor (3 major, 3 minor in Sabah; 1 major, 4 minor
in Sarawak)
Merchant marine: 12 ships (1,000 GRT or over) totaling 64,100 GRT, 76,500 DWT;
includes 10 cargo, 2 tanker
Civil air: 13 major transport aircraft
Pipelines: crude of], 90 mi.; refined products, 35 mi.
Airfields:
West Malaysia: 105 total, 70 usable; 15 with permanent-surface runways;
2 with runways 8,000-11,999 ft., 11 with runways 4,000-7,999 ft.; 3
seaplane stations
Sabah: 37 total, 32 usable; 5 with permanent-surface runways; 5 with runways
4,000-7,999 ft.; 3 seaplane stations
Sarawak: 49 total, 44 usable; 5 with permanent-surface runways; 4 with
runways 4,000-7,999 ft.
Telecommunications:
West Malaysia: good intercity service provided mainly by microwave relay;
international service good; good coverage by radio and television broad-
casts; 153,395 telephones; 430,000 radio and 150,000 TV receivers; 9 towns
have AM stations; no FM, 8 TV stations; submarine cables extend to India,
Ceylon, and Singapore; connected to SEACOM submarine cable terminal at
Singapore by microwave relay
Sabah: adequate intercity radio-relay network extends to Sarawak via Brunei;
10,246 telephones; 55,064 radio receivers; 3 AM, 1 FM, no TV stations;
SEACOM submarine cable links to Hong Kong and Singapore
Sarawak: adequate intercity radio-relay network extends to Sabah via Brunei;
13,365 telephones; 50,000 radio and no TV receivers; 2 AM, no FM, no TY
stations
204
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
DEFENSE FORCES:
External defense dependent on loose Five Power Defense Agreement (FPDA) whic
replaced Anglo-Malayan Defense Agreement of 1957 as amended in 1963; FPD
effective as of 1 November 1971, also provides for small ANZUK Joint For
composed of Australia, New Zealand, and U.K. ground, naval, and air eleme
headquarters in Singapore
Military budget: for fiscal year ending 31 December 1972, $314 million; 22%
of total budget
205
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND :
WATER:','e4aae62509e648999085cdaeb0c16d3e417f09ca03e73ae8305edd970194ec6a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee1fa0fd7c3e6b09202e11a0eae57212eca748111c8db5ec9a83fffb518730d1',1972,'MV','Maldives','communications',268,'Railroads: none
Highways: none
Ports: 2 minor ports (Male and Gan)
Civil air: no major transport aircraft
Airfields: 3 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: no domestic and international telecommunication facilities:
200 telephones; 1,250 radio sets; 1 AM station
207
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
MAL I
LAND:
465,000 sq. mi.; only about a fourth of area arable,
forests negligible, rest sparse pasture or desert
(1967)
Land boundaries: 4,635 mi.
Railroads: 400 mi. meter gage
Highways: approximately 7,500 mi.; 870 mi. bituminous, 3,215 mi. gravel, 580 mi.
improved earth, 2,835 mi. unimproved earth
Inland waterways: 1,141 mi. navigable
Civil air: 7 major transport aircraft
Airfields: 55 total, 39 usable; 6 with permanent-surface runways; 2 with runway
8,000-11,999 ft., 1] with runways 4,000-7,999 ft.
Telecommunications: system poor and provides only minimum service to government,
business, and public; open-wire and radiocommunication used for long distance
telecommunications; radio sometimes only Tink to outlying points; 6,670
telephones; 60,000 radio receivers; 2 AM, no FM, and no TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $6,100,000; about 14.5%
of total budget
210
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
WATER:','3aba8da3ce8808a4b528adf6b70b116cf5978556c57609c43f4deac2d7fc4f2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dfdc25883e19e58a23a4d2c075b15f105e4faaaadad0434487b5131adaedd51',1972,'MT','Malta','communications',272,'Highways: 743 mi., 625 mi. paved (asphalt), 85 mi. crushed stone, 15 mi. improved
earth, 18 mi. unimproved
Ports: 2 minor
Civil air: no major transport aircraft, 2 on lease from U.K.
Airfields: 4 total, al] usable; 4 with permanent-surface runways; 3 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: modern automatic telephone system centered in Valletta;
43,500 telephones; 80,000 radio receivers (including 59,800 subscribers to
the wired broadcast service of Rediffusion Malta, Ltd.); 65,000 television
receivers; 3 AM, 2 FM, and 1 TV stations; 10 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1971, $739,200; about 1.6% of
central government bugdet
212
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','8b3e573ed86d9edb195d877102a2ad2c731ea2028d2345e5c0303917035bc7b3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f808c494c4ad06f461f261dee48fbb8dc7d68bf3a9eb81037183460c137a7f89',1972,'MQ','Martinique','communications',273,'LAND:
425 sq. mi.; 31% cropland, 16% pasture, 29% forest, 24%
wasteland, built on (1970)
WATER: : ;
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 180 mi.
Railroads: none
Highways: 1,100 mi.; 600 mi. paved, 500 mi. gravel and earth
Ports: 1 major (Fort-de-France), 5 minor
Civil air: no major transport
Airfields: 2 usable; 1 with permanent-surface runway; | with runway 4,000-7 ,999
ft; 1 seaplane station
Telecommunications: domestic facilities inadequate; international facilities
approaching saturation point; 17,400 telephones, 72% automatic; international
radiotelegraph carriers, 25 telex circuits, direct radio link with St. Lucia
and other inter-island VHF radio links; satellite earth station operational
February 1972; 1 AM radio station and } TV station with 3 rebroadcast
transmitters; about 33,000 radio and 9,200 TV receivers
DEFENSE FORCES:
Defense is responsibility of France
214
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','97de2b9c970fee65829046691076555cc90e9f4a7063d9e02d88c476d1a6d277','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7baaff7e6c512932acb314271c781d37da004745dfb649b6140f27d1a4894c08',1972,'MR','Mauritania','communications',277,'LAND:
419,000 sq. mi.; less than 1% suitable for crops, 10%
pasture, 90% desert (1971)
Land boundaries: 3,180 mi.
WATER: ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 490 mi.
Railroads: 400 mi. standard gage, single track, privately owned
Highways: 3,785 mi.; 220 mi. paved; 500 mi. gravel, crushed stone, or otherwise
improved; 3,065 mi. unimproved
Inland waterways: 500 m7.
Ports: 3 major
Civil air: 5 major transport aircraft
Airfields: 40 total, 29 usable; 9 with permanent-surface runways; 16 with run-
ways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone poor, telegraph fair; 1,200 telephones; 55,000
radio receivers; 1 AM, no FM or TY stations
DEFENSE FORCES:
Supply: primarily dependent on France
Military budget: for fiscal year ending 31 December 1972, $6,117,600; 15.4%
of total budget
216
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
WATER:','ae00e869fb68c54abb666dbea8d9fc34cb1b2c6c3e5cb02fcaba5e8dd308cc3e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ba72f450672381f5ada12aa0648941a704473cd449a200d267ea5f2464d9020',1972,'MU','Mauritius','communications',284,'Highways: 1,100 mi.; 990 mi. paved, 110 mi. earth
Civil air: no major transport aircraft
Ports: 1 major, 2 minor
Airfields: 7 total, 6 usable; 1 with permanent-surface runway 8,000-11,999 ft.
Telecommunications: 18,100 telephones; radio telegraph service with Reunion,
Malagasy Republic, Seychelles, Zanzibar, and other places in Africa; 1 AM,
no FM, and 4 TV stations; 160,000 radio and 18,800 TV sets; submarine cables
extend to Republic of South Africa and Seychelles Is lands
DEFENSE FORCES:
Military budget: for fiscal year 1971-72, $2,864,000 (combined military and internal
Seay: 6.1% of total budget
218
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
~@&
©
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
STAT','7ee1fbea68a67b372fdd40e44ccc71a8f8240f67ae52b38a7b8d810850509b32','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('470e25395f969023bf17af552b79bd011de1cfccdf6e641de415f7d48c8da8c5',1972,'MC','Monaco','communications',288,'Railroads: 1 mi. (see France)
Highways: none; city streets
Ports: 1 minor
Merchant marine: 4 ships (1,000 GRT or over) totaling 27,400 GRT, 40,300 DWT;
includes 2 cargo, 2 tankers
Civil air: no major aircraft
Airfields: none
22]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d): ; : :
Telecommunications: served by the French wire communications system; automatic
telephone system with about 14,800 telephones; international AM broadcast;
FM and TV facilities; 30,500 radio and 15,100 TV receivers
DEFENSE FORCES:
France responsible for defense
222
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','0b1e793e8ba59b618460e3affd0c82f4afdd3af3175485d571406c11278a5b6a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11abfd2bec182595e64659782f22949f04165f008b08ca2ff5c009994f8fa3d6',1972,'MN','Mongolia','communications',289,'604,100 sq. mi.; almost 90% of land area is pasture or
desert wasteland, varying in usefulness, less than
1% arable, 10% forested (1971)
Land boundaries: 4,975 mi.
Raflroads: 1,130 route mi.; 800 mi. broad gage (5''O"), 330 mi. meter gage
(3''3 3/8") (1971)
Highways: 52,000 mi.; 125 mi. paved, 5,275 mi. improved natural surface and
gravel, 46,600 mi. unimproved earth (1972)
Inland waterways: 585 mi. navigable; used primarily for local transport (1972)
Freight carried: rail -- unknown; highway -- about 10 million short tons (1966);
et oe short ton/mi. (1966); waterway -- 2.5 million short ton/mi.
1970
DEFENSE FORCES:
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31 December 1969, 131.7 million tugriks,
7% of total budget; value in dollars $33 million (est.)
224
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
WATER:','a49907dee4967b60c321af6afa4021b9bb177bb078e1851a01fb753dfbabaa99','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d1bc36ce8faca8c3674aae03ec805cbbbdf309b0b14486f2e43eae233918c31',1972,'MA','Morocco','communications',296,'Railroads: 1,100 mi. standard gage, 93 mi. double track; 493 mi. electrified
Pipelines: crude of1, 86 mi.; refined products, 307 mi.; natural gas, 18 mi.
Ports: 8 major, 12 minor
Civil air: 10 major transport aircraft
Airfields: 139 total, 84 usable; 23 with permanent-surface runways; 2 with
runways over 12,000 ft., 10 with runways 8,000-11,999 ft., 38 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: supertor system by African standards composed of open wave
lines, coaxial multi-conductor and submarine cables and radio relay links;
principal centers Casablanca and Rabat, secondary centers Fes, Marrakech,
Qujda, Sebaa Aioun, Tangier and Ftetouan; 170,000 telephones; 934,689 radio
and 173,904 TV receivers; 24 Moroccan AM, 1 Voice of America AM, 3 FM, 17 TV
stations; 1] submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $143.9 million; 16.5%
of total budget
226
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
cael tills: diacloremta
Saud cn okt sis bianca ia
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','aaf3768314ea105e0a07f03fed3761ef21e6cb86d4ca5ac04fd0547924a31d4f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdc674bd3906b496199b923314c30b60211c469685b459240e488082e257ff97',1972,'MZ','Mozambique','communications',297,'LAND:
303,769 sq. mi.; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
966
Land boundaries: 2,691 mi.
WATER: ;
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,535 mi.
Railroads: 2,437 mi.; 2,345 mi, 3°6" gage (6 mi. double track), 92 mi. 2''5 1/2"
gage
Highways: 20,000 mi.; 1,000 mi. paved; 19,000 other (mostly earth)
Inland waterways: approx. 2,330 mi. of navigable routes
Pipelines: crude oil, 186 mi.
Ports: 3 major, 13 minor
Civil air: 17 major transport aircraft
Airfields: 340 total, 300 usable; 15 with permanent-surface runways; 5 with run-
ways 8,000-11,999 ft., 24 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: system ranks at the bottom of top two-fifths of African
systems and employs a basic low-capacity open-wire network supplemented
by numerous small radiocommunication stations and a single tropospheric
scatter system; important centers are Lourenco Marques, Beira, Nampula,
and Tete; 28,000 telephones; 110,000 radio receivers; 9 AM, 1 FM, and no
TV stations
DEFENSE FORCES:
Defense is responsibility of Portugal
Military budget: for fiscal year ending 31 December 1971, $34.6 million; about
12.6% of national budget
228
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','bce6e4bbcf138f618b37ad7680c27ab175dea36f73d7c82f1c7967bb22335ef9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca745f965746ccfdcc576b0a9567f23967f1f32b6c16d63d6c0293cabd2c1307',1972,'NR','Nauru','communications',301,'LAND:
8.2 sq. mi.; insignificant arable land, no urban areas,
extensive phosphate mines (1970)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 15 mi. | AUSTRALIA
Railroads: none
Highways: about 17 mi.; 13 mi. paved, 4 mi. improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 3 major transport aircraft (includes 2 leased)
Airfields: 1, coral-surfaced, 5,270 ft.
Telecommunications: adequate interisland and international radiocommunications
provided via Australian facilities; 525 telephones; 1 AM, but no TV or FM
radiobroadcasting facilities; number of radios unknown
229
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
DEFENSE FORCES:
No formal defense structure and no reqular armed forces
230
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','566d76ba58922827b5a03a6c9e678f1782c062c9aff9fbc6b440dcc2700b21b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('964cce6965a1bb3083263334fc236186a263f6182be5c3254da98932e2759aa6',1972,'NP','Nepal','communications',305,'LAND :
54,600 sq. mi.; 16% agricultural area, 14% ee meadows
and pastures, 38% alpine land (unarable), waste, or
urban; 32% forested (1966)
Land boundaries: 1,720 mi.
Railroads: 63 mi., all narrow gage (2''6"}; 50% government owned; all in Teraiarea
close to Indian border. only 15 mi. sector from border to Janakpur presently
in use
Highways: 1,660 mi.; 410 mi. paved, 255 mi. gravel or crushed stone, 475 mi.
improved earth; 525 mi. unimproved earth, 200 mi. of seasonally motorable
tracks
Airfields: 47 total, 45 usable; 4 with permanent-surface runways; 5 with runways
4,000-7 ,999 ft.
Telecommunications: poor telephone and telegraph service; good radioconmunication
and broadcast service; international radioconmmunication service is poor;
6,200 telephones, 60,000 radio and no TV sets, 2 AM, no FM, and no TV stations
232
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','4aff4cb517785deb1af0f2d301baa7717e35306c848853f72b3aa71359edb63d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0bc1aa1195fb7eac3305d31b1126a00e133d41aeec8748d02e086d9f86c9234',1972,'NC','New Caledonia','communications',312,'LAND:
8,500 sq. mi.; 6% cultivable, 22% pasture land, 15% forests,
57% waste or other (1971)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 3 n. mi.)
Coastline: 1,000 mi. AUSTRALIA
Railroads: none
Highways: 2,900 mi.; 180 mi. paved; 1,170 mi. gravel, crushed stone, or stabilized
surface; 1,550 mi. unimproved earth
Inland waterways: none
Ports: 1 major, 2] minor
Civil air: no major transport aircraft
Airfields: 34 total, 29 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft.; 1 airfield over 8,000 ft.; 1 seaplane station
Telecommunications: 9,265 telephones; 25,550 radio and 8,100 TV sets; 1 AM,
no FM, and 7 TV stations
238
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
~@&
©
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
STAT
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','d59e5b98a78373cbff0a44cfeae43303ece45e3a0b40c274fb19c9c2e4a7eee4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a4f6f035d1fec6e876a9657c2ab0a9517ab932ded1bfd57f6560bb15ed557ce',1972,'NI','Nicaragua','communications',316,'LAND: _ ,
57,100 sq. mi.; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other (1963)
Land boundaries: 760 mi.
WATER:
Limits of territorial waters (claimed): 3.n. mi. eee
(fishing, 200 n. mi.)
Coastline: 565 mi.','0cd9334f8f05eacca3b4250c5061da659ade96888bfa58f9ef97dc20b1f627fc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ed35b99d4de31f4ba1956d7f13d223259de7276b345b8974dff78cc5071a92a',1972,'NE','Niger','communications',318,'LAND:
489,000 sq. mi.; about 3% cultivated, perhaps 20% somewhat
arable, remainder desert (1971)
Land boundaries: 3,570 mi.
Railroads: none
Highways: approx. 4,300 mi.; 300 mi. bituminous, 1,850 mi. gravel, 2,150 mi.
unimproved earth
Inland waterways: Niger River navigable 185 miles from Niamey to Gaya on the
Dahomey frontier from mid-December through March
Ports: Niger landlocked; outlet to sea is Cotonou, Dahomey
Civil air: 5 major transport aircraft
Airfields: 74 total, 59 usable; 4 with permanent-surface runways ; 1 with runway
8,000-11,999 ft., 15 with runways 4 ,000-7 ,999 ft.
Telecommunications: principal telecommunication center Niamey; telephone poor,
telegraph fair, 3,300 telephones; 85,000 radio receivers; unknown number of
TY receivers; 4 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1972, $5,767,000; 12.3%
of total budget
244
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Ty
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','37210d1c5f9f93d1de3fd93c754527fb260188e8be7d76b15d27cbbe115c3d25','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdbd5e6b4d6cb0604dc1ddc4cb3dc91021df3b3ae83fbcb9ba0f7344505866c8',1972,'NG','Nigeria','communications',322,'LAND:
357,000 sq. mi.; 24% arable (13% of total land area
under cultivation), 35% forested, 41% desert, waste,
urban, or other (1969)
Land boundaries: 2,501 mi.
WATER:
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 530 mi.
Railroads: 2,180 route mi.; 3''6" gage
Highways: 55,400 mi.; 9,475 mi. paved (mostly bituminous surface treatment);
45,925 mi. laterite, gravel, crushed stone, improved earth
Inland waterways: 5,330 mi. consisting of Niger and Benue rivers and smaller
rivers and creeks; additionally, the newly formed Kainji Lake has several
hundred miles of navigable lake routes
Pipelines: crude oi], 581 mi.; natural gas, 56 mi.; refined products, 3 mi.
Ports: 4 major, 5 minor
Civil air: 10 major transport aircraft
Airfields: 90 total, 77 usable; 12 with permanent-surface runways; 5 with runways
8,000-11,999 ft., 25 with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: composed of radio-relay links, open-wire lines, and
radiocommunication stations; principal center Lagos, secondary centers Ibadan
and Kaduna; 81,400 telephones; 1,275,000 radio receivers, 75,000 TV receivers;
25 AM, 6 FM, and 8 TV stations; 2 submarine cables
246
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','490e32f93523102c9a9b69c912236a10f918d1f077685840e0da117a02eb0241','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75d8b6be3fb2e5cfd9a976b07cdf5c3fd7e61ab1d229ee346b631bbc7d81e524',1972,'NO','Norway','communications',326,'LAND:
Norway: 125,000 sq. mi.; Svalbard, 24,000 sq. mi.;
Jan Mayen, 144 sq. mi.; 3% arable, 2% meadows
and pastures, 21% forested, 74% other (1968)
Land boundaries: 1,603 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: mainland 2,125 mi.; islands 1,500 mi. (excludes
long fjords and numerous smal] islands and minor
indentations which total as much as 10,000 mi. overall)
Railroads: 2,634 mi.; 2,587 mi. single track standard gage; 1,515 mi. electrified,
including 47 mi. double track
Highways: 44,180 mi.; 7,135 mi. paved, 37,045 mi. crushed stone and gravel
Inland waterways: 980 mi.; 5'' draft vessels maximum
Pipelines: refined products, 33 mi.
Ports: 9 major, 69 minor
Civil air: 49 major transport aircraft
Airfields: 73 total, 68 usable; 37 with permanent-surface runways; 11 with
runways 8,000-11,999 ft., 14 with runways 4,000-7 ,999 ft.; 24 seaplane
stations
Telecommunications: high-quality domestic and international] telephone, telegraph,
-and telex service; 1,145,000 telephones; 1.9 million radiobroadcast receivers ;
816,941 TV receivers; 36 AM, 43 FM, and 41 TV stations (including many high
powered transmitters); 6 submarine cables
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1972, $487.5 million;
about 12% of central government budget
248
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','ac5ef3cf0349f30933733383ded8b8ce999d4b5273d1877a9121b1110a160c0e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('597960d0def4c87f4469e973e27e1ca4a04bdd85613819ee1cd4c2b712c9f939',1972,'OM','Oman','communications',330,'LAND:
About 82,000 sq. mi.; negligible amount forested,
remainder desert, waste, or urban
Land boundaries: 860 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 1,300 mi.
Pipelines: crude oi1 223 mi.
Ports: 7 minor
Civil air: no major transport aircraft
Airfields: 192 total, 111 usable; 2 with permanent-surface runways ; 3 with runways
8,000-11,999 ft., 37 with runways 4,000-7,999 ft,
Telecommunications: poor international radiocommunications (service to Bahrain
only); very poor domestic wire service; 800 telephones; 1 AM Station;
tropospheric scatter-link to Bahrain
DEFENSE FORCES:
Supply: mostly from U.K.
249
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','4d1b08cc49d046181bc0acd97093d2f5d9d7151dc47f84ac1d54cd66a8ace12e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b096981498f49926c79e63c1f54b2f78f37598edae5c7c23a9b40ce4673e47be',1972,'PK','Pakistan','communications',334,'LAND:
310,000 sq. mi. (includes Pakistani part of Jammu-Kashmir)
40% arable, including 24% cultivated; 24% unsuitable
for cultivation; 34% unreported, probably mostly waste
4% forested (1967)
Land boundaries: 5,350 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 650 mi.
Railroads: 5,322 mi.: 277 mi. meter gage, 4,665 broad gage, 380 narrow gage;
635 double track; government owned
Highways: 43,850 mi.; 12,700 mi. paved, 12,450 mi. gravel, 18,350 mi. earth
Inland waterways: 1,150 mi.
Pipelines: crude oi], 143 mi.; natural gas, 1,200 mi.
Ports: 2 major, 10 minor
Merchant marine: 74 ships (1,000 GRT or over) totaling 587,100 GRT, 791,100 DWT;
includes 6 passenger, 66 cargo, | bulk
Civil air: 19 major transport aircraft
Airfields: 260 total, 138 usable; 86 with permanent-surface runways; | with runway
over 12,000 ft., 22 with runways 8,000-11,999 ft., 67 with runways 4,000-
7,999 ft.; 3 seaplane stations
Telecommunications: excellent international radiocommunication service over
CENTO links; domestic wire and radiocommunication and broadcast service very
good; 207,281 telephones; 1,630,000 radio and 80,000 TV sets; 12 AM, no FM,
and 7 stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972 $714,000,000; about 23%
of total budget
252
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-010514000500010003-9','3304dce0b2b4b5486d676e0404bb0a775e23ede2b0ea93f331155735b844a309','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bc496039eacd8ba4721b5f289a948daec20fd55792eafbae4dddd44febdfd57',1972,'PA','Panama','communications',338,'LAND:
29,208 sq. mi. (excluding Canal Zone, 553 sq. mi.)3 24%
agricultural land (9% fallow, 4% cropland, 11% pasture),
20% exploitable forest, 56% other forests, urban, and
waste (1967 crop year)
Land boundaries: 390 mi.
WATER: BG coer
Limits of territorial waters (claimed): 200 n. mi. :
Coastline: 1,545 mi.','55c290a266f7e67f9da5d0210ba4950f42c7463111474c7d79b94c6797a59078','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa89d2ffd0005c0af185f0c71742353e6e63971a3b24e4662f0e6535aa122e15',1972,'PG','Papua New Guinea','communications',339,'LAND:
183.540 sq. mi. (Papua 90,540 sq. mi., New Guinea
93,000 sq. mi.)
Land boundaries: 600 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
. Coastline: about 2,000 mi.
Papua:
Railroads: none
Highways: approx. 2,480 mi.; about 1,360 mi. suitable for heavy and medium
traffic, and about 1,120 mi. suitable for light traffic .
Inland waterways: 800 mi., not including minor rivers
Ports: 1 principal (Port Moresby), 1 secondary :
Civil air: see New Guinea (below)
Airfields: 180 total, 128 usable; 7 with permanent-surface runways: 14 with
runways 4,000-7,999 ft.; 10 seaplane stations, inactive
Telecommunications: see New Guinea (below)
New Guinea:
Railroads: none
Highways: approx. 6,430 mi.; approx. 3,865 mi. suitable for heavy and medium
traffic, and 2,565 mi. suitable for light traffic only
Inland waterways: 1,350 mi., northeast New Guinea; minor rivers not included
Pipelines: crude oi], 87 mi.
Ports: 4 principal (Rabaul, Lae, Madang, Kavieng), 4 minor
Civil air: 18 major transport aircraft (plus 26 registered in Australia)
Airfields: 626 total, 422 usable; 13 with permanent-surface runways; 48 with
runways 4,000-7,999 ft.; 14 seaplane stations, inactive
Telecommunications: Papua New Guinea telecom services are adequate and are
being improved; principal telecom centers include Goroka, Lae, Madang,
Mount Hagen, and Wewak in New Guinea; and Daru, Port Moresby and Samarai in
Papua; facilities provide radiobroadcast, radiotelephone and telegraph,
coastal radio, aeronautical radio and international radiocommunication
services; numerous privately owned radio facilities exist; submarine
cables extend from Madang to Australia and Guam; 22,659 telephones, 80,000
radios, but no TV sets; 17 AM, no FM and no TV facilities
DEFENSE FORCES:
Defense is responsibility of Australia
256
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','b31e3662dcd512e90bdd3df0855bb5582fcb9c12b06cc85370e347b6370f2d0c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('436cd4fe35fdfc861db549ae95a77ae96148242469d7c249cef90fcd2dc94518',1972,'PY','Paraguay','communications',343,'157,000 sq. mi.; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other (1970
estimate)
Land boundaries: 2,140 mi.','3f9863c5713bd2d4ff698259dc318d01f085f6de0c54be13aaa11cc3355b51a5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d2d9917aa755170dd2fe366462233a873b7be7d23eb2986c68259b31fa11aba',1972,'PE','Peru','communications',347,'Railroads: approx. 2,144 mi.; 1,800 mi. 4'' 8 1/2" gage; 130 mi. gage less than
30"; 214 mi. 3'' O" gage; 9 mi. double track
Highways: 31,100 mi.; 3,000 mi. paved, 5,400 mi. gravel or crushed stone, 8,500
mi. improved earth, 14,200 mi. unimproved earth
Inland waterways: 5,400 mi. of navigable tributaries of Amazon River system and
130 mi. Lake Titicaca
Pipelines: crude of], 200 mi.; natural gas and natural gas liquids, 1,411 mi.
Ports: 7 major, 20 minor
Civil air: 35 major transport aircraft
Airfields: 324 total, 280 usable; 17 with permanent-surface runways; 2 with
runway over 12,000 ft., 18 with runways 8,000-11,999 ft., 47 with runways
4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fairly adequate for most requirements; new radio relay system
under construction; communications satellite ground station; 223,000 telephones;
est. 1.8 million radio and 450,000 TV receivers; 200 AM. 7 FM, and 29 TY
stations
DEFENSE FORCES:
Supply: produces some small arms ammunition; the U.S. has been the major source of
foreign military equipment; aircraft and ships from France and U.K. represent
three fourths of the total value of non-U.S. imports since 1953
Military budget: a biennial budget for 1 January 1971 through 31 December 1972,
$485.2 million; about 16.2% of central government biennial budget
260
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','943b0f99e489c95d4b313301ffc2df916bcf1606b33c358664edf551d25e58c8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d86c20a0d5cf2bf328adbd8330d141f24fa8aee48b5f95ef58073c5d1a634c67',1972,'PH','Philippines','communications',348,'PEOPLE''S REP
OF CHINA
LAND:
116,000 sq. mi.; 37% cropland, 41% forested, 22% other
6
(1968)
WATER:
Limits of territorial waters (claimed): under an archipelago
theory, waters within straight lines joining appropriate
points of outermost islands are considered internal
waters; waters between these baselines and the limits
described in the Treaty of Paris, December 10, 1898,
the U.S.-Spain Treaty of November 7, 1900, and the
U.S.-U.K. Treaty of January 2, 1930 are considered
to be the territorial sea
Coastline: about 14,000 mi.
Railroads: 2,160 mi.; 2 common-carrier systems (3''6" gage) totaling about 710
mi.; 19 industrial systems with 4 different gages totaling 1,450 mi.; 34%
government owned
Highways: 45,690 mi.; 8,886 mi. paved; 23,770 mi. gravel, crushed stone, or
stabilized soil surface; 13,034 mi. improved earth
Inland waterways: 2,000 mi.; limited to shallow-draft (Tess than 5 ft.) vessels
Pipelines: refined products, 157 mi.
Ports: 13 major, 89 minor
Civil air: 93 major transport aircraft
Airfields: 323 total, 216 usable; 36 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 24 with runways 4,000-7,999 ft.; 8 seaplane stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $111 million; about 15%
of total budget
262
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','ebb2610a8087636637161fa1d39aeb33b4c2adce76a4a64cbe121dd3edbde821','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c77bbb4e1b15f7d3f02b2f3dd0e207ff9e2f2536a5558087ac881f822ad87efe',1972,'PL','Poland','communications',352,'LAND:
120,600 sq. mi.; 49% arable, 14% other agricultural, 27%
forested, 10% other (1969)
Land boundaries: 1,920 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 305 mi.
PEOPLE: i: Ped,
Population: 33,000,000, average annual growth rate 0.9% ; were oven tail Ser
(current); males 15-49, 8,672,000; 6,850,000 fit for ;
military service; 355,000 reach military age (19)
annually
Ethnic divisions: 98.7% Polish, .6% Ukrainians, .5% Belorussians, less than
.05% Jews, .2% other
Religion: 95% Roman Catholic (about 75% practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26% industry, 36% other nonagricultural*
Railroads: 16,469 route mi.; 14,381 mi. standard gage, 2,088 mi. narrow gage;
4,644 mi. double track; 2,400 mi. electrified; government owned (1970)
Highways: 190,095 mi.; 40,389 mi. paved; 39,479 mi. crushed stone, gravel;
110,227 mi. earth (improved and unimproved) (1971)
Inland waterways: 3,158 mi. navigable streams and canals (1972)
Pipelines: 1,700 mi. for natural gas; 500 mi. for crude oi]; 117 mi. for refined
products
Freight carried: rail -- 421.4 million short ton, 67.9 million short ton/mi.
(1970); highway 920.7 million short tons, 9.8 billion short ton/mi. (1970);
waterway -- 7 million short tons, 1.6 billion short ton/mi. (1970)
264
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','3b93506f7c7256ac5b60b783f871014371abbf09e48bed01fec45b0ed146c04b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28abfd75116eac1c69933e577e09951bdd1d4cbbff140c18d4bc4283caaf9c4a',1972,'PT','Portugal','communications',355,'LAND:
Metropolitan Portugal: 35,520 sq. mi., including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and
other (1968)
Cape Verde Islands: 1,560 sq. mi., divided among 10 islands
and several islets (not a part of Metropolitan Portugal)
Land boundaries: 750 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. ai cai
(fishing, 12 n. mi.)
Coastline: 535 mi. (excludes Azores, Maderia, and Cape
Verde Islands, 1,180 mi.)
Railroads: 2,230 mi.; 472 mi. 3''3 3/8" meter gage, 1,758 mi. broad gage (5''5 9/16");
265 mi. double track; 274 mi. electrified
Highways: 18,500 mi.; 11,000 mi. bituminous, bituminous treatment, concrete and
stoneblock; 7,200 mi. gravel and crushed stone; 300 mi. improved earth; plus
an additional 10,500 mi. of unimproved earth roads (motorable tracks)
Inland waterways: 508 mi. navigable; relatively unimportant to national economy,
used by shallow-draft craft limited to 330-ton cargo capacity
Ports: 7 major, 33 minor
Civil air: 2] major transport aircraft
Airfields (including Azores, Cape Verde Islands, and Madeira Islands): 62 total,
54 usable; 26 with permanent-surface runways; 7 with runways over 12,000 ft.,
266
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Airfields (cont''d):
10 with runways 8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 7 seaplane
stations
Telecommunications: facilities are generally adequate; 720,000 telephones; 1.6
million radio receivers; 400,000 television receivers; 35 AM, 34 FM, and 24
TV stations; 18 submarine cables
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1972, $462 million;
about 34% of central government budget
267
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
WATER:
Railroads: none
Highways: approx. 2,000 mi. (205 mi. bituminous, remainder earth)
Inland waterways: 994 mi.
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 63 total], 60 usable; 4 with permanent-surface runways; 8 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: limited telephone and telegraph service; 2,000 telephones;
3,600 radio receivers; 1 AM. no FM or TV stations
DEFENSE FORCES:
Defense is responsibility of Portugal
270
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
PORTUGUESE TIMOR
LAND:
7,000 sq. mi.; 34% forest, 33% grassland, and 33%
cultivated (1968)
Land boundaries: 90 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. ~s
(fishing, 12 n. mi.) AUSTRALIA
Coastline: 1,600 mi.
Railroads: none
Highways: 463 mi.; 293 mi. gravel or crushed stone, 170 mi. improved and
unimproved earth
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 14 total, 10 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: domestic and international radio stations used primarily
for administrative and military purposes; | low-power radiobroadcast station;
unreliable open-wire lines and 12 smal] manual switchboards serve about 679
telephones; 3,000 radio sets
272
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','0e4921c9cd5632432aba0ceb85b4cc2f728e9a5f512d668eb35d844610a22ee8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2977d1c9eb218684f225dffbb97c1b19729c3308ff1e701e808780f809071522',1972,'PR','Puerto Rico','communications',359,'LAND:
3,440 sq. mi.; 33% arable, 35% meadow and pasture, 13%
forested, 19% waste, urban, or other (1964)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 300 mi.
Railroads: more than 450 mi. plantation lines; 6 gages from 1''8" to 3''3 3/8"
with latter predominating
Highways: 4,800 mi.; 3,900 mi. paved, 260 mi. gravel, 640 mi. improved and
unimproved earth
Inland waterways: negligible
Pipelines: refined products, 90 mi.
Ports: 3 major, 7 minor
Civil air: major transport aircraft are included in U.S. registered total
Airfields: 31 total, 27 usable; 17 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 9 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: highly developed telecom system of open-wire and radio relay
links; communications satellite ground station; 333,750 telephones; over
| million radio and 410,000 TV receivers; 48 AM, 18 FM, and 11 TV stations;
5 submarine cables, including 4 coaxial
DEFENSE FORCES:
Defense is responsibility of U.S.
274
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','4510643cdbd1bcf047c22d0106afb1ae76825a0c1eff733668fa172259e2e348','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b39c9878a9f2db15593ed0e1158821589d836da68c47790e372d19989e5db70',1972,'QA','Qatar','communications',363,'LAND:
About 4,000 sq. mi.; negligible amount forested; mostly
desert, waste, or urban (1963)
Land boundaries: 35 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 350 mi.
Railroads: none
Highways: 275 mi. bituminous; 225 mi. gravel; surfaced; undetermined mileage of
earth tracks
Pipelines: crude oi1, 73 mi.; natural gas, 60 mi.
Ports: 2 minor
Airfields: 10 total, 1 usable; 2 with permanent-surface runways
Civil air: no major transport aircraft :
275
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Telecommunications: all international telecom traffic is by radio thru Bahrain;
fair domestic wire facilities; 9,400 telephones; 25,000 radio and 20,000 TV
receivers; 1 AN and 7 TV stations
DEFENSE FORCES:
Supply: mostly from U.K.
276
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Railroads: none
Highways: 1,092 mi.; 814 mi. paved, 278 mi. gravel, crushed stone, or stabilized
earth
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 6 total, 6 usable; 1 with permanent-surface runway; | with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.
Telecommunications: adequate for size of island and fairly modern; international
communications by radio to France, Malagasy Republic, and Mauritius; 16,000
telephones; 71,000 radio and 17,700 TV receivers; 1 AM, no FM, and 8 TV
stations
278
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND
Railroads: 1,610 mi. narrow gage (3''6"); 26 mi. double track
Highways: 48,733 mi.; 4,968 mi. paved, 20,415 mi. crushed stone, gravel,
stabilized soil. or improved earth; 23,350 mi. unimproved earth
Inland waterways: 175 mi. on Lake Kariba
Airfields: 295 total, 206 usable; 7 with permanent-surface runways; ] with run-
way over 12,000 ft., 23 with runways 4,000-7,999 ft.
Civil air: 12 major transport aircraft
Telecommunications: system is one of the best in Africa; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Salisbury, secondary center Bulawayo; 132,000 telephones; 145,300 radio
and 50,000 TV receivers; 8 AM, no FM and 2 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $51,260,000; 15.5% of
total budget
280
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','168082d43820490c14b74c367f685653e7083479b9523d943d2abe1397e66606','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77f165875d02c5e14a7733cfe0b9ab44e50605ac8f32a2a019bbce6dcc0bb0dc',1972,'RO','Romania','communications',367,'LAND:
91,700 sq. mi.; 44% arable, 19% other agriculture, 27%
forested, 10% other (1969)
Land boundary: 1,845 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 140 mi.
Railroads: 9,700 mi.; 6,430 mi. standard gage, 3,252 mi. narrow gage, 18 mi.
Mone 243 mi. electrified, 783 mi. double track; government owned
1971
Highways: 48,000 mi.; 7,600 mi. paved; 16,300 mi. other improved surfaces,
24,100 mi. earth (1970)
Inland waterways: 1,445 mi. (1972)
Pipelines: crude oi], 1,600 mi.; refined products, 888 mi.; natural gas, 3,100
mi.
Freight carried: rail -- 178.6 million short tons, 32.3 billion short ton/m.
(1970); highway -- 435 million short tons, 4.8 billion short ton/mi. (1970);
waterway -- 3.4 million short tons, .77 billion short ton/mi. (1970)
282
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','7319c4f24a5b8d81e60ab9dafb5a14821707d2538ac393fdc5e859aadeb77a6c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8611e623be400b6f4a36a47c0aa7172f6ac495dde9eaf0daa02d526299318eed',1972,'RW','Rwanda','communications',371,'D:
10,000 sq. mi.; almost all the arable land, about 1/3
under cultivation, about 1/3 pastureland (1967)
Land boundaries: 545 mi.
Railroads: none
Highways: 3,728 mi.; 1,243 mi. primary roads (only 6 mi. paved), 2,485 mi.
secondary roads; most roads improved or unimproved earth
Inland waterways: Lake Kivu navigable by steamers and barges
Civil air: no major transport aircraft
Airfields: 20 total, 15 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
Telecommunications: telephone and telegraph limited; main center is Kigali;
2,000 telephones: 30,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $3,900,000; about
20.4% of total budget
284
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
LAND:
WATER:
; fo
PEOPLE: mown | 574 q
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ST. CHRISTOPHER-NEVIS
150 sq. mi.; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built-on (1962)
Limits of territorial waters (claimed): 3.n. mi.
Coastline: 120 mi.
Population: 66,000 (official estimate for 1 July 1972), Ke
average annual growth rate 1.2% (April 60-70) ewe
Ethnic divisions: mainly of African Negro descent Pe
Religion: Church of England, other Protestant sects, Roman
Catholic
Language: English
Literacy: about 80%
Labor force: not available
Organized labor: 6,700
Railroads: none
Highways: 180 mi.; 60 mi. paved, 90 mi. otherwise improved, 30 mi. unimproved
earth
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with asphalt runway 5,700 ft.
Telecommunications: good interisland VHF radio connections and international
link via Antigua; about 1,600 telephones; no data on radio, 6,000 TY
receivers; 2 AM and 1 TV stations
286
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ST. LUCIA
LAND:
238 sq. mi.3; 34% arable, 5% pasture, 21% forest, 22%
unused but potentially productive, 18% wasteland
and built-on (1964)
WATER: ae
Limits of territorial waters (claimed): 3 n. mi. yewezuete
Coastline: 98 mi.','8dff3616fbe3d528f2b190026fa3d359ebf2520c83033df1cf3179aa2427a7f5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc3e0025253f3474da402f07cd2417775b36ee76484dc84cd4622a7ca16b0636',1972,'SM','San Marino','communications',377,'LAND:
24 sq. mi.; 74% cultivated, 22% meadows and pastures, 4%
built-on (1964)
Land boundaries: 27 mi.
Railroads: none
Highways: about 65 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serving 2,700 telephones; no
radiobroadcasting or television facilities, 3,000 radio and 600 TV receivers
(Italian broadcasts)
292
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','cd56f3b753c021007db3cc77409986adf83588fc8b936e767e426a36e52abff2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dc0eb2a24197584eade1b1f4f7c5638be1676e3bd5e5cc7ecc3d382fb14dd6f',1972,'SA','Saudi Arabia','communications',381,'LAND:
618,000 sq. mi. (boundaries are poorly defined}; 1%
agricultural, 1% forested, 98% desert, waste, or
urban (1963)
Land boundaries: 2,820 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,560 mi.
Railroads: 350 mi., 4''8 1/2" gage
Highways: 7,767 mi.; 5,282 mi. bituminous, 2,485 mi. gravel and improved earth,
undetermined mileage of earth roads and tracks
Pipelines: crude oil, 1,792 mi.; refined products, 96 mi.; natural gas, 275 mi.
Ports: 3 major, 6 minor
Civil air: 23 major transport aircraft
Airfields: 229 total, 70 usable; 17 with permanent-surface runways; 11 with
runways 8,000-11,999 ft., 38 with runways 4,000-7,999 ft.
Telecommunications: excellent international radio communications; poor domestic
wire service; 44,250 telephones; 85,000 radio and 75,000 TV receivers; 11
TV, | FM, and 4 AM stations; 2 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 10 August 1972, $712.8 million; about
29.7% of total budget
294
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','5bf6f92b76faf33abe9dd2e2307322481325cc46a67e82cce68ea95a1342aea9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c9eec05bd087dfdc3a985051b5e32d813f3ba5af90fdd762000e51dbc9dcc82',1972,'SN','Senegal','communications',385,'LAND:
76,000 sq. mi.; 13% forested, 40% agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 1,665 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 330 mi.
Railroads: 640 mi. meter gage; 40 mi. double track
Highways: 8,725 mi.; 1,335 mi. bituminous, 990 mi. gravel, 400 mi. improved
earth, 6,000 mi. unimproved earth
Inland waterways: 935 mi.
Merchant marine: 3 ships (1,000 GRT and over) totaling 5,300 GRT, 6,500
DWT; includes 2 cargo, 1 tanker
Ports: 1 major, 4 minor
Civil air: 5 major transport aircraft, including 1 leased to Air Mauritanie
Airfields: 40 total, 25 usable; 8 with permanent-surface runways; | with runway
8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: relatively advanced for Africa; 29,300 telephones; 268,000
radio receivers; 1,400 TV receivers; 3 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Supply: primarily dependent on France
Military budget: for fiscal year ending 30 June 1972, $19,490,000; about 9.4%
of total budget
296
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','5ea54e4d6873ba5ad8f599f23f6ff3dd072a3c4e3d5ace0389833056712cff1a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bca80de45d7c4ceb822a66f14e45c6983b0bdb1388e9e07e10b11dfcb26e279e',1972,'SC','Seychelles','communications',389,'LAND:
156 sq. mi.; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other
(mainly reefs and other surfaces unsuited for
agriculture); 40 granitic and 43 coral islands (1970)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 305 mi. (Mahe Island 58 mi.)
Railroads: none
Highways: 14] mi.; 62 mi. bituminous, 79 mi. crushed stone or earth
Ports: 1 minor port (Victoria)
Civil air: no major transport aircraft
Airfields: 2 total, 1] usable on Astove Island, } permanent surface 8,000-11 ,999
ft.; former RAF seaplane station at Victoria, Mahe Island, although not in
present use, could be used in emergency
Telecommunications: direct radiotelegraph communications with other adjacent
islands and African coastal countries; 900 telephones; 11,000 radio sets;
no TV sets; 2 AM, no FM, and no TV stations; submarine cables extend to
Aden, Tanzania, and Sri Lanka
DEFENSE FORCES:
Defense is responsibility of U.K.; no U.K. troops present
298
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','77e2a9ba38211c2c3da82b87caa0a09db0f0d327b107c5860b7752505cbf158a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e4d8ead0dd942eb46eafc3761ecd04b00d2894100ff8cf909f3b777baa987f6',1972,'SL','Sierra Leone','communications',393,'LAND:
27,900 sq. mi.; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
(1971)
Land boundaries: 580 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
(no fishing claim)
Coastline: 250 mi.
Railroads: 370 route miles; 310 mi. narrow gage (2''6") Sierra Leone Government
Railroad (SLR), 60 mi. narrow gage (3''6") privately owned mineral line
operated by the Sierra Leone Development Company
Highways: 4,950 mi.; 450 mi. bituminous (including some bituminous treatment) ,
1,750 mi. laterite (some gravel), and 2,750 mi. earth
Inland waterways: 500 mi.; 372 mi. navigable year-round
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 15 total, 15 usable; 5 with permanent-surface runways; | with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph are adequate; 6,500 telephones;
35,000 radio and 3,050 TV receivers; 1 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Military budget: for year ending 30 June 1972, 6,122,000; 8.4% of total
budget
300
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','935730ebd14700fcef3d196e3b469f39ebc4610879b6b0b95dcd00674ec13b2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('763eac81924e522e2c5b60924f6605b509b64265d326d0905cdd27d341678b68',1972,'SG','Singapore','communications',397,'LAND:
225 sq. mi.; 31% built up area, roads, railroads, and
airfields, 22% agricultural, 47% other (1970)
WATER: :
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
Railroads: 24 mi. of meter gage
Highways: 1,080 mi.; 650 mi. paved, 260 mi. crushed stone, 170 mi. improved
earth
Ports: 3 major
Civil air: 17 major transport aircraft (includes 1 leased)
Airfields: 5 total, 5 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate domestic facilities; good international service;
good radio and television broadcast coverage; about 161,310 telephones;
est. 251,000 radio and 168,853 TV sets; 2 AM, 4 FM, and 2 TY stations; new
SEACOM submarine cable extends to Hong Kong via Sabah, Malaysia
DEFENSE FORCES:
Military budget: for fiscal year ending 3] March 1972, $211.5 million; 32% of
total budget
302
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','2245c6726c1d81ef69e552dbf10de9e8376a3491e64787a33a8297eb3c4f904f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0d89e0f8034d418e4c0c3115057b3a453c405f4729b94f604c5924a6892ec1c',1972,'SO','Somalia','communications',401,'LAND:
246,000 sq. mi.; 13% arable (0.3% cultivated), 32%
‘grazing, 14% scrub and forest, 41% mainly desert,
urban, or other (1970)
Land boundaries: 1,406 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,880 mi.
Railroads: none
Highways: 8,324 mi.; 492 mi. paved; 478 mi. crushed stone, gravel, or
stablized soil; 7,354 mi. improved or unimproved earth
Inland waterways: Fiume Giuba navigable 345 mi. from May to mid-June and
August to late November
Ports: 4 major, 17 minor
Civil air: 6 major transport aircraft
Airfields: 107 total, 57 usable; 2 with permanent-surface runways; 3 with
runways 8,000-11 ,999 ft., 11 with runways 4,000-7,999 ft.; 5 seaplane
stations
Telecommunications: telephone poor, telegraph fair; 5,000 telephones; 45,000
radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, 17,662,800; 40.9% of
total budget
304
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','9df3f40bfd35eedd97531f1fe6b4768828cf32a26ce0ff01e39f7f0e70e4c74c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0fcf1dd85501ed66a8c8e363e100924278e0e47035a424d7348226f1b56e6be',1972,'ZA','South Africa','communications',405,'D:
472,000 sq. mi. (includes enclave of Walvis Bay,
434 sq. mi.); 12% cultivable, 2% forested, 86% desert,
waste, or urban (1972)
Land boundaries: 1,270 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,790 mi.
Railroads: 12,277 mi.; 11,837 mi. 3''6" gage of which 1,323 mi. are multiple
track; 2,634 mi. electrified; 440 mi. 2''0" gage single track
Highways: 220,000 mi.; 27,300 mi. paved, 47,050 mi. crushed stone or gravel,
145,650 mi. improved and unimproved earth
Pipelines: crude oil, 520 mi.; refined products, 450 mi.; natural gas, 200 mi.
Ports: 5 major, 6 minor
Civil air: 49 major transport aircraft
Airfields: 743 total, 591 usable; 4] with permanent-surface runways; 1 with runway
over 12,000 ft., 6 with runways 8,000-11,999 ft., 132 with runways 4,000-7,999
ft.; 4 seaplane stations
Telecommunications: the system, except for the lack of television, is the best
developed, most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay links, and
radioconmunication stations; key centers are Bloemfontein, Cape Town,
Durban, Johannesburg, Port Elizabeth, and Pretoria; 1.6 million telephones;
2 geben radio receivers; 13 AM. 60 FM, and no TV stations; 4 submarine
cables
DEFENSE FORCES:
Military budget: for year ending 31 March 1971, $360,000,000; about 9.9%
of total budget
306
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
CRSA eee eet re ese IS
eae wise i
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
SOUTH-WEST AFRICA
LAND:
318,000 sq. mi.; mostly desert except for interior
plateau and area along northern border (1972)
Land boundaries: 2,360 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 925 mi.
Railroads: 1,454 mi., all 3''6" gage, single track
Highways: 21,000 mi., 2,344 mi. bituminous treated, 220 mi. gravel and 18,436 mi.
earth road and tracks
Ports: 1 major, 1 minor
Civil air: 3 major transport aircraft (registered in South Africa)
Airfields: 118 total, 91 usable; 10 with permanent-surface runways; 4 with
runways 8,000-11,999 ft., 39 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: system is a meager combination of open-wire lines, a single
short radio-relay link, and scattered radiocommunication stations; Windhoek
is the center; 33,400 telephones; unknown number of radio receivers; no
AM, 1 FM, and no TV stations
DEFENSE:
Defense is responsibility of Republic of South Africa
308
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','9e8ae836bd228c721e92699b6fab92d70c350a879eb62cd3aaa3c10ff7c89233','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dbe52423d467908e5417fdef37c2c2d994bb1c12740f92929c8c5650b00ff9f',1972,'ES','Spain','communications',409,'LAND:
195,000 sq. mi., including Canary (2,900 sq. mi.) and
Balearic Islands (1,940 sq. mi.); 41% arable and she
land under permanent crops, 27% meadow and pasture, : hen Geno
22% forest, 10% urban or other (1969) a:
Land boundaries: 1,180 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 3,085 mi. (includes Balearic Islands, 420 mi.,
and Canary Islands, 720 mi.)','ac901ff51c2ce50df683259d3ee710c2796c27c8afd2e9e33503a8182d2acecf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d90edf751079255ff8d12a30feaacfce18a1dbb5de53b2f34699c9478476c1e',1972,'SD','Sudan','communications',410,'ND:
967,000 sq. mi.; 37% arable (3% cultivated), 15% racing
33% desert, waste, or urban, 15% forest (1971
Land boundaries: 4,850 mi.
WATER: : :
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 530 mi.
Railroads: 2,950 mi.; 2,730 mi. 3''6" gage, 440 mi. 2! gage plantation line
Highways: 6,550 mi.; 680 mi. crushed stone or gravel, 190 mi. bituminous-treated,
and 5,680 mi. improved and unimproved earth roads; in addition, there are an
undetermined number of tracks
Inland waterways: 3,300 mi. navigable
Ports: 7 major, 7 minor
Civil air: 9 major transport aircraft
Airfields: 87 total, 67 usable; 5 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 29 with runways 4,000-7,999 ft.
Telecommunications: large system by African standards, but still barely adequate
for size of country; consists of open-wire lines, radio-relay links, multi-
conductor cables, radio communication stations and a tropospheric scatter
link; principal center of Khartoum, secondary centers at Al Fashir and
Port Sudan; 46,400 telephones; 650,000 radio and 35,000 TY receivers; 2 AM,
no FM, and 1 TV stations; 5 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1971, $133.3 million; 30.8% of
total budget
318
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
SURINAM
55,100 sq. mi.; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially
productive, 16% built-on area, wasteland, and other
(1964)
Land boundaries: 970 mi.
WATER: - ;
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 240 mi.
Railroads: 104 mi.; 54 mi. 3''3 3/8" gage (government owned) and 50 mi.
narrow gage (industrial lines); al] single track
Highways: 1,550 mi.; 300 mi. paved, 130 mi. gravel, 370 mi. improved earth,
750 mi. unimproved earth
Inland waterways: 2,850 mi.; most important means of transport; oceangoing
vessels with drafts ranging from 14 to 23 ft. can navigate many of the
principal waterways while native canoes navigate upper reaches
Ports: 1 major, 6 minor
Civil air: 2 major transport aircraft
Airfields: 31 total, 29 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.: 1 seaplane station
Telecommunications: international facilities good and domestic network under
improvement; 10,000 telephones; 60,000 radio and 25,000 Tv receivers, 5 AM,
1 FM, and 3 TV stations
DEFENSE FORCES:
Defense is responsibility of the Netherlands; the Netherlands maintains an army
force in Surinam; also available are naval, marine corps, and naval air
personnel located in the Netherlands Antilles
Ships: none
320
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
SWAZILAND
LAND:
6,700 sq. mi.; most of area suitable for crops or
pastureland (1970)
Land boundaries: 270 mi.
Railroads: 139 mi., 3''6" gage, single track
Highways: 1,660 mi.; 135 mi. paved; 840 mi. crushed stone, gravel, or stabilized
soil; 685 mi. improved or unimproved earth
Civil air: 5 major transport aircraft
Airfields: 29 total, 26 usable; 1 with permanent-surface runway; 2 with runways
4,000-7 ,999 ft.
Telecommunications: the system consists of a few open-wire lines and low-powered
radiocommunication stations; Mbabane is the center; 5,100 telephones; 30,000
radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
None, police only
322
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Pate
SERS | TPO ITE TE
cee errr
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','6b02270bea210bc05c98cba9bc56027c4368ad5cf83b76078708a91df4b8c468','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b1561bf2a4cc554367244c57b2baf1cd106aae106bdb2b063e23af82a93e346',1972,'SE','Sweden','communications',414,'D:
173,000 sq. mi.; 8% arable, 1% meadows and pastures, 55%
forested, 36% other (1968)
Land boundaries: 1,365 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: 2,000 mi.
PEOPLE: \\PS
Population: 8,133,000, average annual growth rate 0.4% uaa fecve salle
(January 71-72); males 15-49, 1,899,000; 1,630,000 fit
for military service; 59,000 reach military age (19) annually
Ethnic divisions: homogeneous white population; small Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant, Roman Catholic, Eastern
Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking minorities
Literacy: 99%
Labor force: 3.5 million; 11.8% agriculture, forestry, fishing; 33.5% mining
and manufacturing; 9.6% construction; 15.5% commerce; 7.2% transportation
and communications; 20.9% services; 4.0% unemployed
Organized labor: 70% of labor force
Railroads: 7,578 mi.; Swedish State Railways (SJ) 7,004 mi. standard
gage (4''8 1/2"), 4,373 mi. electrified, 725 mi. double tracked; 165 mi. narrow
gage (3''6" and 2''11"), and 311 mi. standard gage (4'' 8 1/2") and 98 mi. narrow
gage (2''11") are privately owned and operated
Highways: 60,925 mi.; 44,530 mi. are crushed stone, gravel, or improved
earth; and 16,395 mi. are bitumen, stone block, or cobblestone
Inland waterways: 1,268 mi. navigable for small steamers and barges
Ports: 17 major, and 23 minor
Civil air: 65 major transports registered
Airfields: 190 total, 162 usable; 89 with permanent-surface runways; 5 with
runways 8,000-11,999 ft., 59 with runways 4,000-7,999 ft.; 9 Seaplane
stations
Telecommunications: telephone the primary service, but extensive telegraph and
broadcast services are available; excellent domestic and international
facilities; 4,636,000 telephones; 42 AM, 82 FM, and 185 TV stations available
to over 99% of population; 5 million radio and 2.8 million TV receivers;
12 submarine cables
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 30 June 1973, $1.42 billion;
about 12% of proposed central government budget
324
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','3ae2953fd0e99fc1dd157e6189d989bcd7122b876855ea019c4af14d28a75807','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e32bab3745c93eb91950c8806950dab9f043c16df69d45b00cec76f9eb266ab2',1972,'CH','Switzerland','communications',417,'D:
16,000 sq. mi.; 10% arable, 42% meadows and pastures, 21%
waste or urban, 24% forested, 3% inland water (1970)
Land boundaries: 1,171 mi.
Railroads: 3,040 mi.; 2,195 mi. 4''8 1/2" gage, 780 mi. double track; 845 mi.
narrow gage (810 mi. at 3''3 3/8", 35 mi. at 2''7 1/2"); 3,040 mi. electrified
Highways: 31,300 mi.; 12,300 mi. paved, 19,000 mi. otherwise improved
Pipelines: crude oi], 195 mi.
Inland waterways: 41 mi.; Rhine River-Basel to Rheinfelden, Schaffhausen to
Constanz; in addition, there are 12 navigable Takes ranging in size from
Lake Geneva to Hallwi lersee
ee rail -- 34.8 million metric tons (1963); 4.59 billion ton/km.
Ports: 1] major, 2 minor
Civil air: 60 major transport aircraft
Airfields: 89 total, 73 usable; 34 with permanent-surface runways; 2 with
runways over 12,000 ft., 6 with runways 8,000-11,999 ft., 1] with runways
4,000-7,999 ft.
Telecommunications: excellent services; 2.8 million telephones; 1.9 million
radio and 1.4 million TV receivers; 8 AM, 78 FM, and 318 TV stations
including repeaters
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, $546.2 million; 24%
of central government budget
326
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
SYRIA
D:
78,700 sq. mi.; 47% arable, 29% grazing, 2% forest,
21% desert ; :
Land boundaries: 1,365 (1967) (excluding occupied area
TURKEY
1,340 mi.)
WATER: ‘
Limits of territorial waters (claimed): 12 n. mi. eke
Coastline: 120 mi.
SUDAN - :
PEOPLE: gl
Population: 6,665,000, average annual growth rate 3.3% ; erHioPiA”
(September 60-70); males 15-49, 1,515,000; 825,000 fit
for military service; about 73,000 reach military age (19) annually
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians, and other
Religion: 70.5% Sunni Muslim, 16.3% other Muslim sects, 13.2% Christians of
various sects
Language: Arabic, Kurdish, Armenian; French and English widely understood
Literacy: about 40%
Labor force: 1.2 million; 53% agriculture, 17% industry, 30% miscellaneous
services: majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Railroads: 649 mi.; 459 mi. standard gage, 190 mi. narrow gage (3''5 3/8")
Highways: 7,150 mi.; 4,300 mi. paved, 810 mi. gravel or crushed stone, 1,540 mi.
improved earth, 497 mi. unimproved earth
Inland waterways: 420 mi.; of little importance
Pipelines: crude oil], 1,577 mi.; refined products, 320 mi.
Ports: 3 major, 3 minor
Civil air: 7 major transport aircraft
Airfields: 86 total, 25 usable; 20 with permanent-surface runways; 1 with runway
over 12,000 ft., 15 with runways 8,000-11,999 ft., 4 with runways 4,000-
7,999 ft.
Telecommunications: fair international radioconmunication service; fair domestic
telecommunication service; 115,000 telephones; 1,000,000 radio and 112,000 TV
receivers; 5 TV and 5 AM stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, 180,772,000, 24.1% of
national budget
328
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
TANZANIA
362,800 sq. mi. (including islands of Zanzibar and Pemba,
1,020 sq. mi.); 6% inland water, 12% cultivated, 34%
grassland, 48% bush forest, woodland, on mainland; 60%
arable, of which 40% cultivated on islands of Zanzibar
and Pemba
Land boundaries: 2,413 mi.
WATER: f
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 885 (this includes Mafia Island, 70; Pemba
Island, 110; and Zanzibar, 132)
Railroads: 1,950 mi.; 312 mi. 3''6" gage; 1,638 mi., meter gage, 4 mi. double track;
Tanzania portion of Tan-Zam Railroad currently under construction
Highways: total 30,000 mi., including 390 mi. on Zanzibar Island and 277 mi. on
Pemba and Mafia Islands; about 1,400 mi. bituminous treated, (370 mi. on
Zanzibar and Pemba); 28,600 mi. gravel, crushed stone, or unimproved earth
Pipelines: refined products 610 mi.
Inland waterways: 730 mi, of navigable streams; several thousand mi. navigable
on Lakes Tanganyika, Victoria, and Nyasa
Ports: 4 major, 8 minor
Civil air: 9 major transport aircraft
Airfields: 101 total, 89 usable; 8 with permanent-surface runways; 1 with runway
8,000 to 11,999 ft., 37 with runways 4,000-7,999 ft. 1 with runway over 2,000
ft.; 4 seaplane stations
Telecommunications: telephone and telegraph good in main centers, only fair
outside main towns; 36,100 telephones; 150,000 radio receivers; 4 AM, no FM
or TV stations; 4 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $41.4 million; 11% of
total budget
330
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','b1a7be370b4645fa260bffbc5b21e152dc5d3658258f289dfdc8cafb6f11e570','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44c2d17cda84bd4f5ca2a00fa930ccb3711c107726370780736aff7a16ff4829',1972,'TH','Thailand','communications',421,'LAND:
198,000 sq. mi.; 24% in farms, 56% forested, 20% other
(1969)
Land boundaries: 3,025 mi.
WATER: ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,200 mi.
Railroads: 2,382 mi. meter gage; 60 mi. double track
Highways: 12,590 mi.; 5,440 mi. paved, 4,820 mi. crushed stone or gravel, 2,330
earth and laterite
Inland waterways: 2,485 mi. principal waterways; 2,300 mi. with navigable depths
of 3 ft. or more throughout the year; numerous minor waterways navigable by
shallow-draft native craft
Ports: 2 major, 16 minor
Airfields: 223 total, 185 usable; 41 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 23 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: service to general public being improved, but still inadequate;
bulk of service to government activities provided by numerous radiocommunica-
tion stations and radio-relay network; satellite ground station connects to
Intelsat II and will connect to Indian Ocean satellite; 152,959 telephones;
2,800,000 radios; 230,000 televisions; estimated 50 AM, 5 FM, and 6 TV
stations in two government-controlled networks; U.S. military submarine
cable to South Vietnam
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1972, $254 000,000; 18% of
total budget
332
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','6d0f3a3531caba07babd3a4f2f1c0b0395b0cb188ac64f71868d6fe8f28151f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd913e05edddac1e171103cd8a6dd4fbb9dc3d3445b7c152bdece4e8c72206bb',1972,'TG','Togo','communications',425,'LAND: ; ’
22,000 sq. mi.; nearly half total is arable, under 15%
cultivated (1970)
Land boundaries: 940 mi.
WATER: .
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 35 mi.
Railroads: 275 mi. meter gage, single track
Highways: approx. 4,475 mi.; 235 mi. paved, 120 mi. gravel, 910 mi.
improved earth, 3,210 mi. unimproved
Inland waterways: section of Mono River and about 30 mi. of coastal lagoons
and tidal creeks
Ports: 1 major, 1 minor
Civil air: 1 major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface runway 4,000-7,999 ft.
Telecommunications: Togo has poor system based on skeletal network of open-wire
lines, supplemented by a few radiocommunication stations; only center is
Lome; 4,600 telephones; 45,000 radio receivers; 1 AM, no FM or TV stations
334
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','37275974164b430f9833b04914080e4ed3e96d1be496e1128c92af7d9775c215','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9d9b63c3ef9334cf8263253256930dce96c117d1317966d145831dfc98492e3',1972,'TO','Tonga','communications',429,'LAND :
385 sq. mi. (150 islands); 77% arable, 3% pasture, 13%
forest, 3% inland water, 4% other
WATER: :
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 350 mi. (est.)
AUSTRALIA *
Railroads: none
Highways: 365 mi.; 132 mi. metalled all-weather, 233 mi. earth
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 3 total; 1 usable, with grass runway 7,000 ft.; 1 seaplane station
Telecommunications: 931 telephones; 8,000 radio sets; no TV setss 1 AM station
DEFENSE FORCES:
Ships: 1 coastal patrol
335
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','e413c411c205dff98508e20b575be0e1b8488107fa0d8da8f4bad2c4e896f07d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7175136ad7a3c2b53341c6ae971fe233896fe066cebead94466978f5d165bea4',1972,'TT','Trinidad and Tobago','communications',433,'LAND:
1,980 sq. mi.; 41.9% in farms (of which 25.7% cropped or
fallow, 1.5% pasture, 10.6% forests, 4.1% unused or
built-on), 58.1% outside of farms, including
grassland, forest, built-up area, and wasteland (1963)
WATER: ; VENEZUELA
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 225 mi. COLOMBIA
PEOPLE: BRAZIL
Population: 974,000, average annual growth rate 1.3%
(April 60-70); mates 15-49, 215,000; 150,000 fit for
military service
Ethnic divisions: 43% Negro, 36% East Indian, 16% mixed, 2% white, 3% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23% Hindu, 6% Muslim, 13% unknown
Language: English
Literacy: 80%
Labor force: about 368,400 (June 1969), at least 15% unemployed; about 20.4%
agriculture, 18.3% mining, quarrying, and manufacturing, 15.8% commerce;
14.6% construction and utilities; 6.9% transportation and communications;
20.8% services (1965); shortage of technical and managerial personnel
Organized labor: 24% of labor force
Railroads: none
Highways: 4,200 mi.; 2,500 mi. paved, 1,700-mi. gravel or otherwise improved
Pipelines: crude oil, 243 mi,; refined products, 12 mi.; natural gas, 130 mi.
Ports: 3 major, 6 minor
Civil air: 8 major transport aircraft
Airfields: 12 total, 6 usable; 3 with permanent-surface runways; | with runway
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international service via tropospheric scatter
link to Barbados and Guyana; good local service; satellite ground
station operational November 1971; 56,250 telephones; est. 250,000 radio
and 54,000 TV receivers; 2 AM, 2 FM, and 2 TV stations
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1969, $2,500,000;
about 1.5% of central government budget
338
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ee re er er als
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','736dc595ea213bca3323c11e096b2285c3fa38d4ee259511fbb1127029b0f37d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78aee5169ff2d3e928f6b11ec0865902ffc968221223dbfc2aa0a5a3f98ce933',1972,'TN','Tunisia','communications',436,'LAND:
63,400 sq. mi.; 28% arable land and tree crops, 23% range
and esparto grass, 6% forest, 43% desert, waste or
urban
Land boundaries: 875 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
. (fishing, 12 n. mi. follows 50 meter isobath in
south; maximum extent 80 n. mi.)
Coastline: 710 mi. (includes offshore islands)
Railroads: 1,273 mi.; 298 mi. standard gage (4''8 1/2"), mi. double track: 975
mi. meter gage (3''3 3/8")
Highways: 10,000 mi.; 4,560 mi. bituminous, 465 mi. gravel, 2,050 mi. improved
earth, 2,925 mi. unimproved earth
Pipelines: crude of], 496 mi.; refined products, 6 mi.; natural gas, 43 mi.
Ports: -4 major, 14 minor
Civil air: 6 major transport aircraft
Airfields: 60 total, 36 usable; 10 with permanent-surface runways; | with runway
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is above the African average in amount and
Capacity of facilities which consist of open-wire lines with multiconductor
cable or radio relay on trunk routes; key centers are Safagis, Susah, Bizerte,
and Tunis; 70,000 telephones; 400,000 radio and 51,000 TV receivers; 3 AM,
3 FM, and 7 TV stations; 2 submarine cables
340
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
TURKEY
LAND:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive (1968)
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mi.)
Coastline: 4,475 mi. made .
PEOPLE: rior
Population: 37,235,000, average annual growth rate 2.6%
(October 65-70); males 15-49, 9,421,000; 5,560,000 fit for military
service; about 378,000 reach military age (20) annually
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force
Railroads: 5,286 mi.; 5,266 mi. 4''8 1/2" gage, 51 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. paved, 17,398 mi. gravel or crushed stone, 1,553
mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx, 1,050 mi.
Pipelines: crude oi], 402 mi.; refined products, 1,277 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 569,700 GRT, 787,200 DWT;
includes 12 passenger, 55 cargo, 11 tanker, 7 bulk, 2 specialized carrier
Civil air: 18 major transport aircraft, plus 3 on leae from U.S.
Airfields: 117 total, 94 usable; 47 with permanent-surface runways; 3 with
runways over 12,000 ft., 18 with runways 8,000-11,999 ft., 25 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication and domestic
telecommunication services; 577,000 telephones; 3.1 million radio and 50,000
TV receivers; 39 AM, 3 FM, and 2 TV stations; communications satellite ground
station to be operational in 1972
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 28 February 1973, $579.3 million;
about 16% of central government budget
342
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','7ba047e970e6da27e36a2f143f6ed25e9cd0110dba4d01f60705e5c03e35cb1a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab748b1cc4d9389f693d966210eeba43bcfe263f32b672f0a16b6b7505d3bd07',1972,'UG','Uganda','communications',440,'LAND:
91,000 sq. mi.; 21% inland water and swamp, including
territorial waters of Lake Victoria, about 21%
cultivated, 13% national parks, forest, and game
reserves, 45% forest, woodland, and grassland (1970)
Land boundaries: 1,665 mi.
Railroads: 760 mi.; all meter gage, single track
Highways: 31,330 mi. total; 940 mi. bituminous surface treatment; 10,390 mi.
crushed stone, gravel, laterite, and improved earth; 20,000 mi. unimproved
earth roads and tracks
Inland waterways: Lake Victoria, Lake Albert, Lake Kyoga, Lake George, and
Lake Edward (6,010 mi.); Kagera River and Victoria Nile (380 mi.)
Ports: 1 major (Port Bell on Lake Victoria)
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 5,500 GRT, 9,100 OWT
Civil air: 6 major transport aircraft
Airfields: 49 total, 42 usable; 3 with permanent-surface runways ; 2 with runways
8,000-11,999 ft., 1] with runways 4,000-7 ,999 ft.; 3 seaplane stations
Telecommunications: telephone and telegraph services fair to good, intercity
connections based on 3 or 12 channel carrier systems; 30,200 telephones;
256,000 radio and 11,000 TV receivers; 2 AM, no FM, and 6 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $42.7 million; 16.6% of
total budget
344
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
U.S.S.R.
LAND:
8,600,000 sq. mi.; 9.3% cultivated, 37.1% forest and
brush, 2.6% urban, industrial, and transportation,
16.8% pasture and natural hay land, 34.2% desert,
swamp, or waste (1969)
Land boundaries: 12,595 mi.
WATER: ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 29,000 mi. (incl. Sakhalin)
Railroads: 84,008 mi.: 81,400 mi. broad gage, 2,609 mi. narrow gage; 58,608 mi.
broad gage single track; 21,064 mi. electrified; government owned (1970)
Highways: 934,000 mi.; 99,000 mi. paved, 266,000 mi. gravel, crushed stone,
569,000 mi. improved or unimproved earth (1970)
Inland waterways: 90,000 mi. navigable, exclusive of Caspian Sea; 27,100 mi.
principal routes (1972)
Pipelines: crude oil, 20,500 mi.; refined products, 5,000 mi.; natural gas,
43,000 mi.
Freight carried: rail -- 3,192.3 million short tons, 1,708.6 billion short
ton/mi. (January 1971); highways -- 15,620.0 million short tons, 148.0
billion short ton/mi. (January 1971); waterway -- 394.4 million short tons,
119.2 billion short ton/mi, (January 1971)
DEFENSE FORCES:
Nuclear weapons: satisfies major requirements of Soviet forces
Supply: fully supplies own needs
Military budget: estimated military expenditures for 1971 were 16.6 billion rubles,
approximately 5% of estimated GNP, or equivalent to about $60.4 billion; these
expenditures exclude research and development
346
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','44e4706bec902156ebf264074ef95fac284bd09452be01b035c5236416be1756','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('810d80b0a3d0437ab737a8efe4ddb0b3e98214883efbab06a4127f9d5ff6a122',1972,'AE','United Arab Emirates','communications',444,'LAND:
32,000 sq. mi. (1965); almost all desert, waste or urban
(1963
Land boundaries: 680 mi. (does not include boundaries
between adjacent U.A.E. states)
WATER:
Limits of territorial waters (claimed): Abu Dhabi 3 n. mi.,
Sharjah 12 n. mi., others not available
Coastline: 900 mi.
Railroads: none
Highways: 175 mi. bituminous, undetermined mileage of earth tracks
Pipelines: crude of1, 170 mi.
Ports: 2 major, 4 minor
Civil air: no major transport aircraft
Airfields: 88 total, 38 usable; 3 with permanent-surface runways; 1] with runway
8,000-11,999 ft., 15 with runways 4,000-7,999 ft.
Telecommunications: telephone system in Dubayy and Ash Shariqah, also links
these towns; Abu Dhabi Petroleum operates a telecom system throughout
the sheikhdom; key centers are at At Tarif, Habshan, and Az Zannah; 6,800
telephones; 250,000 radio and 10,000 TV receivers; 3 AM, | FM, and 1 TV
stations
348
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
~@&
&
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
STAT
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
UPPER VOLTA
LAND:
106,000 sq. mi.; 50% pastureland, 21% fallow, 10%
cultivated, 9% forest and scrub, 10% waste and other
uses (1967)
Land boundaries: 2,055 mi.
Railroads: 728 mi., 320 mi. meter gage, single track; Ouagadougou to Abidjan,
Ivory Coast line
Highways: 10,380 mi.; 200 mi. paved, 3,550 mi. improved, 6,630 mi. unimproved
Civil air: no major transport aircraft
Airfields: 58 total, 50 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runway 4,000-7,999 ft.
Telecommunications: all services generally poor; 2,600 telephones; 87,000 radio
receivers; 5,500 TV receivers; 2 AM, no FM, and 1 TV stations (broadcasts
temporarily suspended)
DEFENSE FORCES:
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1971, $4.6 million; 12.0% of
total budget
352
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','a4d8e5e348422fea8dfdab379e483b056f926051fc98a371801c13b8b10a514c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c8a323c4d69ad1fd757bc965e1ec670adf33d22761854daa881fc8270b75565',1972,'UY','Uruguay','communications',448,'ND:
72,200 sq. mi.; 90% agricultural land, 75% pasture, 15%
cropland, 10% urban and waste
Land boundaries: 840 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 410 mi.
Railroads: 1,870 mi., all standard gage and government owned (1970)
Highways: 32,200 mi.; 3,700 mi. paved, 4,600 mi. otherwise surfaced, 9,600 mi.
improved earth, 14,300 mi. earth tracks
Inland waterways: 1,068 mi.; used by coastal and shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail 15%, waterways 5%
Ports: 4 major, 6 minor
Airfields: 86 total, 63 usable; 6 with permanent-surface runways; | with runway
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: ten-year plan developed to improve telecom facilities
underway; most modern facilities concentrated in Montevideo; 215,000
telephones; 1 million radio and 250,000 TV receivers; 63 AM, 2 FM, and 21
TV stations; 9 submarine cables
DEFENSE FORCES:
Supply: dependent on U.S. for current supplies, with few exceptions
Military budget: for fiscal year ending 31 December 1970, $31.6 million; 8.7%
of central government budget
354
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
th atnceatt peeks Sey
fee eer eine inet mine eae ae
Se ee Re
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
VATICAN CITY
LAND:
0.169 sq. mi.
Land boundaries: 2 mi.
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Teleconmunications: 1 AM and 2 FM radiobroadcasting stations; 2,000-line automatic
telephone exchange
DEFENSE FORCES:
Defense is responsibility of Italy
356
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
VENEZUELA
ND:
352,000 sq. mi.; 4% cropland, 18% pasture, 21% forest,
57% urban, waste, and other (1961)
Land boundaries: 2,598 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,740 mi.
Railroads: 233 mi. 4''8 1/2" gage; all single track; 107 mi. government owned,
126 mi. privately owned
Highways: 34,600 mi.; 11,200 mi, paved, 9,200 mi. gravel, 4,200 mi. improved
earth, 10,000 unimproved (including trails)
Inland waterways: 4,450 mi.; Orinoco River and Lake Maracaibo accept oceangoing
vessels
Pipelines: crude of], 3,795 mi.; refined products, 245 mi.; natural gas, about
1,550 mi.
Ports: 6 major, 17 minor
Civil air: 59 major transport aircraft
Airfields: 446 total, 217 usable; 90 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 70 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: extensive radio relay; local telephone systems greatly expanded;
satellite ground station operational; planned troposcatter link to Curacao;
over 406,000 telephones; est. 3 million radio and 900,000 TV receivers; about
be AM, ” FM, and more than 30 TV stations; 6 submarine cables, including
coaxia
DEFENSE FORCES:
Supply: produces portion of smal] arms ammunition requirement; dependent upon
U.S. and Western Europe for all other materiel
Military budget: proposed for fiscal year ending 31 December 1972, $273 million;
about 9% of central government budget
358
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
VIETNAM, NORTH
LAND:
61,300 sq. mi.; 14% cultivated, 50% forested, 36% urban
inland water, and other (1969)
Land boundaries: 1,850 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 490 mi.
Railroads: 602 usable route mi., consists of about 25 mi. of standard gage
(4''8 1/2"), 438 mi. of meter gage (3''3 3/8"), and 139 mi. of dual gage
(4''8 1/2" and 33 3/8"); all single track, none electrified; al] government
owned and operated; new rail line under construction between Kep and port
of Hon Gai
Highways: 9,100 mi., plus about 1,600 mi. of seasonally motorable tracks; 900 to
1,000 mi. bituminous Surface-treated, remainder gravel, crushed stone, or earth
Inland waterways: 4,200 mi.; 1,800 mi, navigable perennially by craft drawing 6 ft.
Ports: 3 major, 12 minor
359
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
VIETNAM, SOUTH
LAND:
66,000 sq. mi.; 35% arable (17% cultivated), 32% forested,
33% other (1970)
Land boundaries: 1,025 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 10.8 n. mi.)
Coastline: 1,650 mi.
Railroads: 770 mi.
Highways: 12,100 mi.; 3,000 mi. bituminous, 1,717 mi. gravel and crushed stone,
1,483 mi. improved earth, 5,900 mi. unimproved earth
Inland waterways: about 6,800 mi. navigable; more than 1,400 mi. navigable at all
times by vessels up to 6 ft. draft
Ports: 6 major, 20 minor
Airfields: 340 total, 175 usable; 65 with permanent-surface runways, 8 with
runways 8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 4 seaplane stations
362
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
WESTERN SAMOA
LAND:
1,100 sq. mi.; comprised of 2 large islands of Savai''i and
Upolu and several smaller islands, including Manono
and Apolima; 65% forested, 24% cultivated, 11% industry,
waste, or urban (1971)
WATER: : :
Limits of territorial waters (claimed): 3 n. mi. RUSTAKCIA
Coastline: 250 mi.
Railroads: none
Highways: 477 mi.; 80 mi. bituminous, remainder mostly gravel, crushed stone,
or earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Civil air: 4 major transport aircraft (includes 1 leased)
Airfields: 4 total, all usable; 4 with runways 4,000-7,999 ft.; 1 seaplane
station
Telecommunications: 1,960 telephones; 32,000 radio receivers; 1 AM station
364
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
YEMEN (ADEN)*
LAND:
112,000 sq. mi. (border with Saudi Arabia undefined); only
about 1% arable (of which less than 25% cultivated)
Land boundaries: 1,060 mi.
WATER: ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 860 mi.
Railroads: none
Highways: 3,350 mi.; 120 mi. bituminous treated, 30 mi. crushed stone and gravel,
3,200 motorable track
Ports: 1 major
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,600 GRT, 2,600 DWT
Pipelines: refined products, 57 mm.
Civil air: 8 major transport aircraft
Airfields: 137 total, 85 usable; 2 with permanent-surface runways; 2 with
runways 8,000-11,999 ft., 41 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent international radiocommunications; excellent
domestic wire facilities; 9,400 telephones; 250,000 radio receivers; 21,000
TV receivers; 5 TV and 1 AM stations; 4 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1971, $13,400,000; about 25.1%
of total budget
366
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
YEMEN (SANA)
LAND:
about 75,000 sq. mi. (parts of border with Saudi Arabia
and Southern Yemen undefined); 20% agricultural,
1% forested, 79% desert, waste, or urban
Land boundaries: 950 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 325 mi.
Railroads: none
Ports: 3 major, 2 minor
Civil air: 6 major transport aircraft
Airfields: 35 total, 26 usable; 6 with permanent-surface runways; 1 with
Pee ce es ft., 5 with runways 8,000-11,999 ft., 13 with runways
367
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Telecommunications: fair international service by radio; poor domestic wire
service; 1,900 telephones; 10,000 radio receivers (approx.); 2 AM radio-
broadcast stations
368
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
YUGOSLAVIA
LAND:
98,700 sq. mi.; 32% arable, 25% meadows and pastures,
34% forested, 9% urban, waste, and other (1967)
Land boundaries: 1,865 mi.
WATER:
Limits of territorial waters (claimed): 10 n. mi.
(fishing, 12 n. mi.)
Coastline: 945 mi. (mainland), plus 1,500 mi. (offshore
islands)
PEOPLE: Ch
Population: 20,743,000, average annual growth rate 0.9%
(current); males 15-49, 5,562,000; 3,685,000 fit for military service;
203,000 reach military age (19) annually
Ethnic divisions: 43% Serb, 23% Croat, 8% Slovene, 6% Macedonian, 3% Montenegrin,
5% Albanian, 3% Hungarian, 9% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic, 12% Muslim, 3% other, 12%
none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Albanian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 13.5 million (1970); 49.6% agriculture, 16% mining and manufacturing,
34.4% other nonagricultural activities; reported unemployment averaged 8%
of registered labor force (social sector) in 1967
Railroads: 6,393 route mi.; 5,709 mi. standard gage, 684 mi. narrow gage;
463 mi. double track (1970)
Highways: 56,565 mji.; 14,850 mi. paved, 25,715 mi. gravel, crushed stone, 15,600
mi. improved earth, 400 mi. unimproved earth (1970)
Inland waterways: 1,231 mi. (1972)
Freight carried: rail -- 79.5 million short tons, 12.7 billion short ton/mi. (1970);
highway -- 64.7 million short tons, 4.5 billion short ton/mi. (1971);
waterway -- 24.5 million short tons, est. 5.4 billion short ton/mi. (1970)
Pipelines: crude oi], 200 mi.; natural gas, 580 mi.
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, 11,731 million new
dinars; about 48.4% of the central government budget
370
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
wheats
aap
a SE Ere patmegte
Tm meee pamela eset gett antie HD
Be area en ee i
Pir ec
: Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ZAIRE
LAND:
905,000 sq. mi.; 22% agricultural land (1% cultivated),
45% forested, 33% other (1971)
Land boundaries: 6,220 mi.
WATER:
| Limits of territorial waters (claimed): 12 n. mi.
; Coastline: 23 mi.
Railroads: 3,103 mi.; 2,419 mi. 3''6" gage, 78 mi. 3'' 3 3/8" gage, 85 mi.
2'' 0 1/4" gage, 636 mi. 1'' II 5/8" gage; 421 mi. of 3''6" gage electrified
Highways: 86,930 mi.; 1,095 mi. bituminous, 10,427 mi. gravel or crushed stone,
75,408 mi. earth
Inland waterways: comprising the Congo, its tributaries, and unconnected lakes,
the waterway system affords over 9,329 mi. of navigable routes
Ports: 2 major, | minor
Pipelines: refined products, 461 mi.
Civil air: 24 major transport aircraft
Airfields: 486 total, 320 usable; 19 with permanent-surface runways; 1 with
runway over 12,000 ft., 2 with runways 8,000-11,999 ft., 56 with runways
4,000-7,999 ft.; 5 seaplane stations
Telecommunications: limited, barely adequate telephone service, telegraph service
good; 23,000 telephones; 63,000 radio receivers; 7,100 TV receivers;
12 AM, 1 FM, and 2 TV stations
372
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
atl
4./
<
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','bc92202b1268e8cd68d967d07ec91bf5766f4684417c94cebb4958636b57502b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('808803ef35c512e8475fdb34714dd99dce16b0aac56524038d6fd517e23ca2e2',1972,'ZM','Zambia','communications',452,'LAND:
288,000 sq. mi.; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered
trees and grassland (1970)
Land boundaries: 3,730 mi.
Railroads: 764 mi., all narrow gage (3''6"); 8 mi. double track; 664 mi. are
government owned; 100 mi. privately owned
Highways: 21,220 mi.; 1,500 mi. paved, 3,120 mi. crushed stone, gravel, or
stabilized soil: 16,600 mi. improved and unimproved earth
Inland waterways: 1,409 mi. including Zambezi River, Luapula River, Lake Kariba,
Lake Bangweulu, Lake Tanganyika; principal port on Lake Tanganyika is Mpulungu
Pipelines: 450 mi. refined
Civil air: 11 major transport aircraft
Airfields: 190 total, 159 usable; 6 with permanent-surface runways; 1 with
runway over 12,000 ft., 19 with runways 4,000-7,999 ft.
Telecommunications: all services being modernized and increased; presently
adequate but must be expanded to permit growth; high-capacity wire and
radio relay connect centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 56,000 telephones; 100,000 radio and
17,000 TV receivers; 4 AM, 1 FM, and 2 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $26,400,000; about
4.8% of total budget
374
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ag?
~ om
»
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
This "Factsheet" on the U.S. is provided solely as a service to those
wishing to make rough comparisons of foreign country data with a U.S.
"vardstick." Information is from U.S. open sources and publications
and in no sense represents estimates by the U.S. intelligence community.
LAND:
3,615,211 sq. mi. (contiguous U.S. plus Alaska and Hawaii); 19% cultivated,
27% grazing and pasture, 32% forested, 22% waste, urban, and other
WATER:
Limits of territorial waters (claimed): 3.n. mi. (fishing, 12 n. mi.)
Railroads: 207,000 mi. (1969)
Highways: 3,730,000 mi. (1970); 2,411,000 mi. surfaced (1970)
Inland waterways: 25,260 mi. of navigable inland channels, exclusive of the
Great Lakes; freight carried 951 million short tons (1970)
375
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
COMMUNICATIONS (cont''d):
Pipelines: petroleum, 176,000 mi.
Ports: 25 major
Merchant marine: 1,478 ships (1,000 GRT or over) totaling 24,474,000 DWT (1971)
Civil air: 3,000 major transport aircraft (1969
Airfields: 11,261 (1970)
Teleconmunications: 4,370 AM, 2,722 FM, 1,035 TV operating stations (1970);
120,155,000 telephones (1970), 58.6 telephones per 100 population (1970)
DEFENSE FORCES:
Personnel: army 1,570,186, navy 765,232, air force 904,759, marines 307,252 (1968)
Military budget: $80.5 billion (1968)
376
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
yu
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','2e2c3531a7c6e08f920fff7f94f25423b1d32b1128decba4fb3de7e6eb55bb2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27bb9a5e2eb0c22beebb2a22ecd2afb496e1939bab3a2854d09c855d5f7fca58',1972,'AF','Afghanistan','communications',8,'Railroads: 0.6 km (single track) - 1.524-meter gage,
government-owned spur of Soviet line
Highways: 20,885 km total (1975); 2,460 km paved, 3,910
km gravel, 8,735 km improved earth, and 5,780 km
unimproved earth
Inland waterways: total navigability 1,200 km; steamers
use Amu Darya
Ports: only minor river ports
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
AFGHANISTAN/ ALBANIA
Civil air: 6 major transport aircraft
Airfields: 36 total, 35 usable; 9 with permanent-surface
runways; 6 with runways 2,440-3,659 m, 1] with runways
],220-2,489 m
Telecommunications: limited telephone, telegraph, and
radiobroadcast services; television to be introduced by 1979;
35,000 telephones (0.2 per 100 popl.); 2 AM, no FM, no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, about 4.1 million; 2.2
million fit for military service; about 162,000 reach military
age (22) annually
Supply: dependent on foreign sources, almost exclusively
the USSR. ~
Military budget: estimated expenditures for fiscal year
ending 31 March 1978, about $60.7 million; approximately
8.3% of central government budget
fran
Esfahan®
Al Basrah,''
wai Pais
suman Shiraz
(Bandar ‘Abbas
Riyadh,
ited Arab
Emirates','4624498f55c9525a38c031b6c387da35000740e4bbec0f631493990b3a6ccfc5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('177cbb8121489dbcf4656632a9d99077d9dd59e451392563a4ede2ab67fc383c',1972,'RO','Romania','communications',9,'i
Railroads: 13,186 km total; 12,881 km standard gage
(1.435 m), 112 km broad gage (1.524 m), 193 km narrow
gage (0.750 m and 0.760 m); 2,807 km double ‘track; 2,718
km electrified; government-owned (1977)
Highways: 73,677 km total;-60,157 km concrete, asphalt,
stone block; 13,520 km gravel, crushed stone (1976)
Inland waterways: 483 km (1977)
Pipelines: crude oil, 1,448 km; refined products, 861 km;
natural gas, 5,601 km
Freight carried: rail—274.3 million metric tons, .71.6
billion metric ton/km (1977);. highway—1,049.7 million
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a ae
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CZECHOSLOVAKIA/DENMARK
metric tons, 16.7 billion metric ton/km (1977); waterway—
6.8 million metric tons, 3.5 billion metric ton/km (excl. int’l.
transit traffic) in approximately 766 waterway craft with
454,370 metric ton capacity (1978)
Ports: no maritime ports; outlets are Gdynia, Gdansk, and
Szezecin in Poland; Rijeka and Koper in Yugoslavia;
Hamburg, FRG; Rostock, GDR; principal river ports are
Prague, Melnik, Usti nad ‘Labem, Decin, Komarno, Bra-
tislava (1977) é
DEFENSE FORCES
Military budget: announced for fiscal year ending 31
December 1978, est. 19.5 billion crowns, about 7.1% of total
budget
DEFENSE FORCES
Military manpower: males 15-49, 2,650,000; 2,314,000 fit
for military service; about 70,000 reach military age (18)
annually
Military budget: announced’ for fiscal year ending 31
December 1978, est. 14.4 billion forints; about 3.7% of total
budget
i a ROMANIA!
Bucharest ~“%
YUGOSLAVIA x
(See reference mop 1V)
LAND
237,503 km?*; 44% arable, 19% other agriculture, 27%
forested, 10% other
Land boundary: 2,969 km
WATER
Limits of territorial waters (claimed): 12 nm
173
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
fi ROMANIA
Coastline: 225 km
Railroads: 12,080 km total; 10,467 km standard gage
(1.435 m), 1,600 km narrow gage, 13 km broad gage; 1,407
km electrified, 2,040 km double track; government owned
(1976) .
Highways: 77,768 km total; 13,470 km concrete, asphalt,
stone block; 14,412 km asphalt treated, gravel, crushed stone;
49,886 km earth (1976)
Inland waterways: 1,660 km (1978)
Pipelines: 2,735 km crude oil; 1,429 km refined products;
5,149 km natural gas
Freight carried: rail—238.0 million metric tons, 67.6
billion metric ton/km (1976); highway—442.2 million
metric tons, 9.9 billion metric ton/km (1976); waterway—
7.9 million metric tons, 2.1 billion metric ton/km in
approximately 515 waterway craft, with 493,750 metric ton
capacity (1977)
Ports: 5 major (Constanta, Galati, Braila, Mangalia,
Tulcea), 1 minor; principal inland waterway ports are
Giurgiu, Turnu Severin, and Orsova (1978)
DEFENSE FORCES
Military budget (announced): for fiscal year ending 31
December 1978, 12.0 billion lei; about 3.8% of total budget
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Paar Re ee AAO AL AA nd A
RAR AAA RAR RA A mA A
ee ee eT ee: ee ee ee ee ee ee ee ee a
et ee.
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Bucharest Black
Belgrade, * ck Sea
Yugoslavia
Marseill&\\—
° , Ankara ,.
Madrid 2 - Corsica '' a
Barcelona ; \\ 5
N a
Turkey
Spain q
4 oO
. 2 f
© Balearic Is. 4
Gibraltar Algiers : —~ Saat
wn) ions ;
italta
valletla Mediterranean
Sardinia','e91b6b14448945df909409bd26fda9bb3974762e62833e026334e49e02caaab4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99d4a564d8f5bf3d9e5dc51a898debe9eeb5beaa2fe680fbe963ef85b565e065',1972,'BG','Bulgaria','communications',10,'Li
a
)
0
red
Mediterranean Sea
(See reference map (V}
LAND
28,749 km?; 19% arable, 24% other agricultural, 43%
forested, 14% other
Land boundaries: 716 km
WATER
Limits of territorial waters (claimed): 15 nm
Coastline: 418 km (including Sazan Island)
Railroads: 277 km-standard gage (1.435 m), single track,
government-owned (1975)
Highways: 4,989 km total; 1,287 km paved, 1,609 km
crushed stone and/or gravel, 2,093 km improved or
unimproved earth (1975) ;
Inland waterways: 43 km plus Albanian sections of Lake
Scutari, Lake Ohrid, and Lake Prespa (1977)
Freight carried: rail—2.8 million metric tons, 180 million
metric ton/km (1971); highways—39 million metric tons,
900 million metric ton/km (1971).
Ports: 1 major (Durres), 8 minor (1977)
Pipelines: crude oil, 117 km; refined products, 65 km;
natural gas, 64 km ;
Civil air: no civil airline
DEFENSE FORCES
Military budget (announced): for fiscal year ending 31
December 1978, 824 million leks; 10.7% of total budget
LAND
111,852 km?; 41% arable, 11% other agricultural, 33%
forested, 15% other
Land boundaries: 1,883 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 354 km
Railroads: 4,314 km total; about 4,069 km standard gage
27
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BULGARIA/BURMA
(1.435 m), 245 km narrow gage; 299 km double track; 1,446
km electrified; government-owned (1976)
Highways: 31,454 km total; 6,683 km concrete, asphalt,
stone block; 6,088 km asphalt treated, gravel, crushed stone;
18,683 km earth (1976)
Inland waterways: 471 km (1978) ;
Freight carried: rail—75.2 million metric tons, 17.1
billion metric ton/km (1977); highway—319 million metric
tons, 6.7 billion metric ton/km (1977); waterway—4.6
million metric tons, 2.5 billion metric ton/km (excl. int''l.
transit traffic) (1977); approximately 214 waterway craft
with 227,000 metric ton capacity (1976)
Ports: 3 major (Varna, Varna West, Burgas), 4 minor
(1977); principal river ports are Ruse and Lom (1978)
BURMA
Rangoon
Bay p
of Bengal
(See reference map Vii}
LAND
678,600 km?; 28% arable, of which 12% is cultivated, 62%
forest, 10% urban and other (1969)
Land boundaries: 5,850 km
WATER
Limits of territorial waters (claimed): 200 nm (200 nm
exclusive economic zone)
Coastline: 3,060 km
Railroads: 3,285 km total; 3,172 km meter gage (1.00 m),
113 km narrow-gage industrial lines; 328 km double track;
government-owned
Highways: 27,000 km total; 3,200 km bituminous, 17,700
km improved earth, gravel, 6,100 km unimproved earth
Inland waterways: 12,800 km; 3,200 km navigable by
large commercial vessels
Ports: 4 major, 6 minor
Civil air: about 20 major transport aircraft
Airfields: 80 total, 78 usable; 23 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 39 with runways
1,220-2,489 m
Telecommunications: provide minimum requirements
for local and intercity service; international service is poor;
radiobroadcast coverage is limited to the most populous
areas; 31,400 telephones (0.1 per 100 popl.); 1 AM, 1 FM,
and no TV stations; one ground satellite station U/C
DEFENSE FORCES
Military manpower: eligible 15-49, 7,309,000; 3,899,000
fit for military service; about 336,000 males and 330,000
females reach military age (18) annually; both are liable for
military service
Military budget: (announced) for fiscal year ending 31
March 1978; $148.9 million, 5% of central government
budget','d0bc025a4f1051957eed5d9d281f277a925daf7bee2ac0c92e8ff5002104ccc9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04236bb52366e6e4fe9d5c180547b8f99d756ae9cd6281733ca123ab1c5a3ff9',1972,'DZ','Algeria','communications',14,'Atlantic
* o
Meditorra, een
(See reference map V}
LAND ;
2,460,500 km?; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban
Land boundaries: 6,260 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,183 km
Railroads: 3,950 km total; 2,690 km standard gage (1.435
m), 1,140 km 1.055-meter gage, 120 km meter gage (1.000
m); 302 km electrified; 198 km double track
Highways: 78,410 km total; 45,070 km concrete or
bituminous, 33,340 km. gravel, crushed stone, unimproved
earth
Ports: 9 major, 8 minor
Pipelines: crude oil, 3,983 km; refined products, 298 km;
natural gas, 2,398 km
Civil air: 43 major transport aircraft
Airfields: 183 total, 170 usable; 55 with permanent-sur-
face runways; 22 with runways 2,440-3,659 m; 89 with
runways 1,220-2,439 m; 3 seaplane stations
Telecommunications: adequate domestic and interna-
tional service in the north; sparse in the south; Atlantic
Ocean satellite station plus domestic satellite system with 14
stations; 266,000 telephones (1.5 per 100 popl.); 18 AM and
40 TV stations; 5 submarine cables
DEFENSE FORCES .
Military manpower: males 15-49, 3,740,000; 2,233,000 fit
for military service; average number reaching military age
(19) annually 192,000
Military budget: for fiscal year ending 31 December
1978, $385 million; 5.7% ‘of national budget
Railroads: none
Highways: 56 km, mostly paved
Ports: 1 major (Gibraltar) *
Civil air: 1 major transport aircraft (leased in)
Airfields: 1 permanent-surface runway, 1,220-2,439 m; 1
seaplane station
Telecommunications: international radiocommunication
facilities; automatic telephone system serving 8,100 tele-
phones (27.1 per 100 popl.); 1 AM, 1 FM, and 2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 8,000; about
4,000 fit for military service
Defense is responsibility of United Kingdom
GILBERT ISLANDS
’ NOTE: On October 1, 1975, by Constitutional Order, the
Ellice Islands were formally separated from the British
colony of Gilbert and Ellice Islands, thus forming the new
colony of Tuvalu. The remaining islands in the former
Gilbert and Ellice Islands Colony were renamed the Gilbert
Islands.
77
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GILBERT ISLANDS/GREECE
united .
a STATES
Pacific Ocean
GILBERT
- ISLANDS
“tS: TUVALU
o \\
Boundary ‘epreseniation is
not necessanty authoritative
503984 1-79
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
U.S. S.R.
Tuapse
Black Sea
yw Ankara
Turkey
Adana
Cyprus +Aleppo
*Nicosia
Lebano:
Syria
Mediterranean Sea
§. Damascu
i Vi o
sta 4
in,
ae, Gyre
fJordan
Alexan
Jiddah
Port Sudan,| Red :
* Khartoum','123c01ed50c0fb29d238c43ed356047962ebcc5e6911ba13e6e0a7265db5f130','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e3b492f1d7e1c93791d4472390ee6e1d49235981f9549e853dced489ec660a1',1972,'AD','Andorra','communications',18,'Atlantic
Ocean
Mediterranean
Sea
(See reference map tV}
LAND
466 km?
Land boundaries: 105 km
Railroads: none
Highways: about 96 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international circuits to Spain and
France; 2 AM stations, 1 FM, 1 TV station; about 3,900
telephones (14.3 per 100 popl.)
DEFENSE FORCES
Andorra has no defense forces; Spain and France are
responsible for protection as needed','431eeeea1de8d280863b92bab57399ca9b86356d61979bd54ab92f2270f3760f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb561e15cdf601d743c3f53667bdc3ceeb9dac51f26860f9f6037a19807f2693',1972,'AO','Angola','communications',22,'‘LAND
1,245,790 km?*; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow)
Land boundaries: 5,070 km
WATER
Limits of territorial waters (claimed): 20 nm
Coastline: 1,600 km
Railroads: 3,108 km total; 2,798 km 1.067-meter gage,
310 km 0,.600-meter gage
Highways: 73,828 km total; 8,577 km bituminous-surface
treatment, 28,723 km crushed stone, gravel, or improved
earth, remainder unimproved earth
Inland waterways: 3,220 km _ navigable
Ports: 8 major (Luanda, Lobito, Mocamedes), 15 minor
Pipelines: crude oil, 179 km
Civil air: 22 major transport aircraft
Airfields: 563 total, 504 usable; 25 with permanent-
surface runways; 1 with runway over 3,660 m, 8 with
runways 2,440-3,659 m, 89 with runways 1,220-2,439 m
Telecommunications: fair network of open-wire and
radio-relay facilities; 1 Atlantic Ocean satellite station;
32,000 telephones (0.5 per 100 popl.); 24 AM, 12 FM, and 1
TV station
DEFENSE FORCES
Military manpower: males 15-49, 1,574,000; 791,000 fit
for military service; average number reaching military age
(20) annually, 59,000
ANTIGUA
(See reference map It}
LAND
280 km?; 54% arable, 5% pasture, 14% forested, 9% unused
but potentially productive, 18% wasteland and built on
WATER :
Limits of territorial waters (claimed): 3 nm
Coastline: 153 km
Railroads: 78 km narrow gage (0.760 m), employed
almost exclusively for handling cane
Highways: 380 km total; 240 km main, 140 km secondary
Ports: 1 major (St. John’s), 1 minor
Civil air: 10 major transport aircraft, including 1 leased ;
out ;
Airfields: 3 total, 3 usable; 1 with asphalt runway 2,745
m; 2 seaplane stations
Telecommunications: automatic telephone system; 3,500
telephones (4.9 per 100 popl.); tropospheric scatter links with
Tortola and St. Lucia; 3 AM stations, 1 FM station, and 1 TV
station; 1 coaxial submarine cable','5c2ffaead6be3c18ac1117c3f7a50d618f27a407b7359fff53345e0c44fb50be','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e781dc6c1a40fe7b2bfaae0467d7e69ad9807a0c7f725cff9f9773584528100',1972,'AR','Argentina','communications',26,'BOLIVIA
Pacific
Ocean
Buenos Aires
Atlantic Ocean
wz FALKLAND ISLANDS
(See reference map til}
LAND
2,771,300 km?*; 57% agricultural (11% crops, improved
pasture and fallow, 46% natural grazing land), 25% forested
18% mountain, urban, or waste ‘
Land boundaries: 9,414 km
>
WATER
Limits of territorial waters (claimed): 200 nm (continen-
tal shelf, including sovereignty over superjacent waters)
Coastline: 4,989 km
Railroads: 39,738 km total; 3,086 km standard gage (1.435
m), 22,788 km broad gage (1.676 m), 13,461 km meter gage
(1.000 m), 403 km 0.750-meter gage
Highways: 207,300 km total, of which 43,900 km paved,
39,500 km gravel, 104,000 km improved earth, 19,900 km
unimproved earth
Inland waterways: 11,000.km navigable
Ports: 7 major, 21 minor
Pipelines: 4,090 km crude oil; 2,200 km refined products;
8,172 km natural gas
Civil air: 39 major transport aircraft
Airfields: 2,400 total, 2,127 usable; 92 with permanent-
surface runways; 21 with runways 2,440-3,659 m, 313 with
runways 1,220-2,439 m; 6 seaplane stations
Telecommunications: extensive modern system; tele-
phone network has 2.54 million sets (9.8 per 100 popl.), radio
relay widely used, | satellite station with 2 Atlantic Ocean
antennas; 160 AM, 12 FM, and‘ 64 TV statioris
DEFENSE FORCES :
Military manpower: males 15-49, 6,535, 000: 5, 299, 000 fit
for military service; average number reaching military age
(20) annually about 226,000
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Military budget: proposed for fiscal year ending 31
December 1978, $1,742.2 million; about 15% of total central
government budget
Atlantic
Ocean
FALKLAND
E> ISLANDS
(See reference map til}
LAND
Colony—12,168 km?; area consists of some 200 small
'' The possession of the Falkland Islands has been disputed by the
U.K. and Argentina (which refers to them as the Islas Malvinas)
since 1833.
62
islands, chief of which are East Falkland (6,680 km*)-and
West Falkland (5,276 km?*); dependencies—consists of the
South Sandwich Islands, South Georgia, and the Shag and
Clerke Rocks
WATER
Limits of territorial waters (claimed): 8 nm
Coastline: 1,288 km
Railroads: none
Highways: 510 km total; 30 km paved, 80 km gravel, and
400 km
Ports: 1 major (Port Stanley), 4 minor
Civil air: no major transport aircraft
Airfields: 2 usable, 1 seaplane station
Telecommunications: government-operated and_ radio-
telephone networks providing effective service to almost all
points 6n both islands; approximately 650 telephones (est. 30
per 100 popl.); 1 AM station :
Atlantic
” Montevideo Ocean
{See reference map {V}
LAND -
186,998 km*; 84% agricultural land (73% pasture, 11%
cropland), 16% forest, urban, waste and other
Land boundaries: 1,352 km
WATER
Limits of territorial waters (claimed): 200 nm (fishing
200 nm) aot
Coastline: 660 km
Railroads: 2,795 km, all standard gage (1.485 m) and
government owned
Highways: 49,900 km total; 6,700 km paved, 3,000 km
gravel, 40,200 km earth
Inland waterways: 1,600 km; used by coastal and
shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail
15%, waterways 5%
Ports: 4 major (Montevideo, Colonia, Fray Bentos,
Paysandu), 6 minor .
Civil air: 6 major transport aircraft (including 2 leased in)
Airfields: 101 total, 63 usable; 10 with permanent-surface
runways; 1 with runway 2,440-3,659 m, il with runways
1,220-2,489 m; 2 seaplane stations
Telecommunications: most modern facilities concen-
trated in Montevideo; 258,000 telephones (9.0 per 100 popl.);
85 AM, 3 FM, and 27 TV stations:. 2 submarine cables
DEFENSE FORCES 7
Military manpower: males 15-49, 672,000; 544,000 fit for
military service; no conscription
Military budget: proposed for fiscal year ending 31
December 1977, $79.9 million; 17.3% of central government
budget
VATICAN CITY
Tyrrhenian
Sea
Mediterranean -
Sea
(See reference map V}
LAND
0.438 km?
Land boundaries: 3 km
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 3 AM stations and 2 FM stations;
2,000-line automatic telephone exchange
DEFENSE FORCES
Defense is responsibility of Italy
VENEZUELA .
LAND
911,680 km?;-4% cropland, 18% pasture, 21% forest, 57%
urban, waste, -and other.
Land boundaries: 4,181 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
220
Coastline: 2,800 km
Railroads: 373 km standard gage (1.435 m) all sacs
track; 171 km government owned, 202 km privately owned
Highways: 58,900 km total; 21,800 km paved, 21,900 km
otherwise improved and 15,200 km unimproved earth
Inland waterways: 7,100 km; Orinoco River and Lake
Maracaibo accept oceangoing vessels
Pipelines: 6,110 km crude oil; 400 km refined products;
2,495 km natural gas
. Ports: 6 major, 17 minor .
Civil air: 70 major transport aircraft (including 4 leased in
‘and 1 leased out)
Airfields: 292 total, 262 usable; 109 with permanent-sur-
face runways; 8 with runways 2,440-3,659 m, 80 with
runways 1,220-2,4839 m; 2 seaplane stations ,
Telecommunications: modern expanding telecom system;
satellite ground station; 649,000 telephones (5.3 per 100
popl.); 157 AM, 50 FM, and 43 TV stations; 2 submarine
cables; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,033,000; 2,156,000 fit
for military service; 158,000 reach military age (18) annually
’ Military budget: proposed for fiscal year ending 31
December 1979, $708.4 million; ‘about 6.7% of central
government budget
VIETNAM
os Falkland Is.
SMa as Malvinas)
(Admin. by ULK.,
claimed by
Argentina)
"$40 Paulo, ue
III. South America
North
Atlantic
Ocean
Paramaribo
( “"\\ cayenne
Frenc
f \\
Guiana
Recife
5* Salvador
ybrasilia
Rio de Janeiro
South
f i
Atlantic
Ocean
1000 Kilometers
1000 Miles
South Georgia
Sy (Fatkland fs.)
. Boundary representation is
not necessarily authoritative
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
IV Europe','32cd96c402c3b4f1118b7204c0c05ff70f8db770c130b37700f7fa99de0f274a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d54f64b3b667e2690d231aa5b31a2045b24e974a5346b67947cdc1798ecd289b',1972,'AU','Australia','communications',30,'c-
NDONESIA.
a 2
Se 0c
2.
Indian Ocean
. NEW ZEALAND GH
{See reference map Vill)
LAND
7,692,300 km*; 6% arable, 58% pasture, 2% forested, 34%
other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm; prawn and crayfish on continental shelf)
Coastline: about 25,760 km
Railroads: 40,636 km total (1976); 9,197 km 1.60-meter
gage, 13,894 km standard gage (1.435 m), 18,045 km
1.067-meter gage; 800 km electrified (June 1962); govern-
ment-owned (except for few hundred kilometers of privately
owned track)
Highways: 837,872 km total (1977); 207,650 km paved,
205,454 km gravel, crushed stone, or stabilized soil surface,
424,768 km unimproved earth
Inland waterways: 8,368 km; mainly by small, shallow-
draft craft
Ports: 12 major, numerous minor
Pipelines: crude oil, 740 km; refined products, 340 km;
natural gas, 6,947 km
Civil air: around 150 major transport aircraft
Airfields: 1,618 total, 1,546 usable; 198 with permanent-
surface runways, 2 with runways: over 3,660 m; 18 with
runways 2,440-3,659 m, 626 with runways 1,220-2,439 m
Telecommunications: very good international and do-
mestic service; 5.5 (39.5 per 100 popl.) million telephones;
204 AM stations, 5 FM stations, 112 TV stations and 66
repeaters; 3 earth satellite stations; submarine cables to New
Zealand, New Guinea, Singapore, Malaysia, Hong Kong, and
(See reference map VIII}
LAND
18,272 km?; landownership—83.6% Fijians, 1.7% Indians,
6.4% government, 7.2% European, 1.1% other; about 30% of
land area is suitable for farming
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,129 km
Railroads: 644 km narrow gage (0.610 m); owned by Fiji
Sugar Corp., Ltd.
Highways: 3,472 km total (1977); 346 km paved, 2,706
km gravel, crushed stone, or stabilized soil surface; 420 km
unimproved earth
Inland waterways: 203 km; 122 km _ navigable by
motorized craft and 200-metric ton barges
Ports: 1 major, 6 minor
Civil. air: 1 DC-8 and 1 light aircraft
Airfields: 15 total, 15 usable; 2 with permanent-surface
runways, 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m
Telecommunications: modern local, interisland, and
international (wire/radio integrated) public and special-pur-
pose telephone, telegraph, and teleprinter facilities; regional
radio center; important COMPAC cable link between
U.S./Canada and New Zealand/Australia, et al.; 30,700
telephones (5.3 per 100 popl.); 6 AM, 2 FM, and no TV
stations; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 163,000; 91,000 fit for
military service; 8,000 reach military age (18) annually
Military budget: the defense of the Fiji Islands was the
responsibility of the U.K. until 10 October 1970; military
budget for 1971, $314,000
(See reference map Vill}
The islands that comprise the Gilbert Islands Colony are
the Gilbert Islands; Fanning Atoll and Washington Island in
the Line Islands; Ocean Island; and those islands claimed by
the United States: Caroline, Christmas, Flint, Malden,
Starbuck, and Vostok in the Line Islands; and Birnie,
Gardner, Hull, McKean, Phoenix, and Sydney in the
Phoenix Islands.
LAND
About 684 km?
WATER
Limits of territorial waters: 3 nm (fishing 200 nm)
Coastline: about 1,143 km
Railroads: none
Highways: 483 km of motorable roads
Inland waterways: small network of canals, totaling 5
km, in Northern Line Islands
Ports: 1 minor
Civil air: 2 Trislanders, however, no major transport
aircraft
Telecommunications: 1 AM _ broadcast station; 250
telephones (0.1 per 100 popl.)
(See reference map Vil)
WATER
‘Limits of territorial waters (claimed): under an archi-
pelago theory, claim is 12 nm, measured seaward from
straight baselines connecting the outermost islands
Coastline: 54,716 km
Railroads: 7,843 km total (1977); 7,246 km 1.067-meter
gage, 505 km 0.750-meter gage, 92 km 0.600-meter gage;
211 km double track; 101 km electrified; government owned
Highways: 93,053 km total; 26,573 km paved, 41,521 km
gravel or crushed stone, 24,959 km improved or unimproved
earth — a
Inland waterways: 21,579 km; Sumatra 5,471 km, Java
and Madura 820 km, Borneo 10,460 km, Celebes 241. km,
and Irian Barat 4,587 km
Ports: 10 major, 66 minor
Civil air: approximately 110 major transport aircraft
Airfields: 38] total, 370 usable; 71 with permanent-
surface runways; 11 with runways 2,440-3,659 m, 66 with
runways 1,220-2,489 m
Telecommunications: interisland microwave system and
HF police net; domestic service poor, international service
good; radiobroadcast coverage good; 314,000 telephones (0.2
per 100 popl.); 291 AM, 1 FM, and 13 TV stations; 1 -
international ground satellite station (1 Indian Ocean
antenna and 1 Pacific Ocean antenna), and 40 domestic
ground satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 31,757,000; 18,138,000
fit for military service; about 1,594,000 reach military age
(18) annually
Military budget: for fiscal year ending 31 March 1979,
$1.7 billion; about 14.5% of central government budget
IRAN
ARABIA
Arabian
(See reference map V}
LAND ‘
1,647,240 km*; 14% agricultural, 11% forested, 16%
cultivable with adequate irrigation, 51% desert, waste, or
urban, 8% migratory grazing and other
Land boundaries: 5,318 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing, 50
nm)
Coastline: 3,180 km, including islands, 676 km
Railroads: 4,601 km total; 4,509 km standard gage (1.435
m), 92 km 1.676-meter gage
Highways: 81,800 km total; 36,000 km gravel and crushed
stone, 15,000 km improved earth ;
. Inland waterways: 904 km, excluding the Caspian Sea,
- 104 km on the Shatt al Arab
98
Pipelines: crude oil, 3,072 km; refined ‘products, 3,766
km; natural gas, 2,317 km
Ports: 7 major, 6 minor
Civil air: 60 major taispoteaieeentt (including 5 leased
in) :
Airfields: 178 total, 160 usable; 66 with permanent-
surface runways; 13 with runways over 3,660 m, 17 with
runways 2,440-3,659 m, 65 with runways 1,220-2,439 m
Telecommunications: advanced system of high-capacity
radio-relay links, open-wire lines, cables, and tropospheric
. links; principal center Tehran, secondary centers Isfahan,
Meshed, and Tabriz; 805,600 telephones (2.0 per 100 popl.);
85 AM, 2 FM, and 67 TV stations; 1 satellite station with
Atlantic Ocean and Indian Ocean antennas, extensive
upgrading in progress
DEFENSE FORCES
Military manpower: males 15-49, 7,826,000; 4,656,000 fit
for military service; about 345,000 reach military age (21)
annually
Caspian
Sea
(See reference map V}
LAND
445,480 km?; 18% cultivated, 68% desert, waste, or urban,
10% seasonal and other grazing land, 4% forest and
woodland
Land boundaries: 3,668 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 58 km
Railroads: 1,700 km total; 1,123 km standard gage (1.435
m), 577 km meter gage (1.00 m); 16 km meter gage double
track
Highways: 20,791 km total; 6,490 km paved, 4,645 km
improved earth, 9,656 km unimproved earth
Inland waterways: 1,015 km; Shatt al Arab navigable by
maritime traffic for about 104 km; Tigris and Euphrates
navigable by shallow-draft steamers
Ports: 3 major (Basra, Umm Qasr, Al Faw)
Pipelines: crude oil, 3,821 km; 585 km refined products;
1,360 km natural gas
Civil air: 25 major transport aircraft
Airfields: 76 total, 69 usable; 26 with permanent-surface
runways; 36 with runways 2,440-3,659 m, 18 with runways
1,220-2,489 m
Telecommunications: network consists of coaxial cables,
radio-relay links, and radiocommunication stations; 320,000
telephones (2.8 per 100 popl.); 9 AM, no FM and 10 TV
stations; ] satellite station with Atlantic Ocean and Indian
Ocean antennas; system expansion in process
DEFENSE FORCES
Military manpower: males 15-49, 2,721,000; 1,515,000 fit
for military service; about 137,000 reach military age (18)
annually
(See reference map Vill}
LAND
21.2 km?; insignificant arable land, no urban areas,
extensive phosphate mines
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 24 km
Railroads: none
Highways: about 27 km total; 2] km paved, 6 km
improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 8 major transport aircraft, one on order
Airfields: 1, coral-surfaced, over 1,220 m
Telecommunications: adequate intraisland and interna-
tional radiocommunications provided via Australian facili-
ties; 700 telephones; 3,600 radio receivers, 1 AM, no FM and
no TV stations; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, about 2,000; fit for
military service, about 1,000; average number reaching
military age (18) annually, 1978-82, less than 100
No formal defense structure and no regular armed forces
(See reference map Vill}
LAND
22,015 km?; 6% cultivable, 22% pasture land, 15% forests,
57% waste or other
WATER
Limits of territorial waters (claimed): 12 nm (fishing, 3
nm)
Coastline: 2,254 km
Railroads: none
Highways: 5,448 km total (1977); 558 km paved, 2,251
km improved earth, 2,639 km unimproved earth
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
§
ae a a eX
Aan AA,
eR Am na Ame kA a A Re RA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NEW CALEDONIA/NEW HEBRIDES/NEW ZEALAND
Inland waterways: none
Ports: 1 major (Noumea), 21 minor
Civil air: no major transport aircraft
Airfields:-31 total, 30 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m; 1 airfield over
2,440 m; 1 seaplane station
Telecommunications: 20,600 telephones (14.9 per 100
popl.); 5 AM, no FM, and 7 TV stations; 1 earth satellite
station
NEW HEBRIDES
Pacific
Ocean
sane
ce
»
=
a
AS
»
- Coral Sea :
Ww cy
HEBRIDES .
new Sy
CALEDONIA
3
(See reference map Vill}
LAND
About 14,763 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 2,528 km
Railroads: none
Highways: at least 240 km sealed or all-weather roads
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 27 total, 26 usable; 2 runways 1,220-2,439 m, 2
with permanent-surface runways
Telecommunications: 3 AM _ broadcast stations; 2,300
telephones (2.3) per 100 popl.); 1 ground satellite station
DEFENSE FORCES
Personnel: no military forces maintained; however, the
French and British maintain constabularies of about 100
men each
Railroads: 4,716 km total (1977); all 1.067-meter gage;
274 km double ‘track; 113 km electrified; over 99%
government owned
Highways: 92,617 km total (1977); 46,716 km paved,
45,901 km gravel or crushed stone
Inland waterways: 1,609:km; of little importance to
(See reference map Vill)
LAND
475,369 km?
Land boundaries: 966 km
162
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: about 5,152 km
Railroads: none
Highways: 19,200 km total; 640 km paved, 10,960 km
gravel, crushed stone, or stabilized soil surface, 7,600 km
unimproved earth
Inland waterways: 10,940 km
Ports::5 principal, 8 minor
Civil air: about 15 major transport aircraft
Airfields: 525 total, 482 usable; 18 with permanent-sur-
face runways; 2 with runways 2,440-3,659 m: 41 with
runways 1,220-2,439 m :
Telecommunications: Papua New Guinea telecom serv-
ices are adequate and are being improved; principal telecom
centers include Goroka, Lae, Madang, Mount Hagen, and
Wewak in New Guinea; and Daru, Port Moresby and
Samarai in Papua; facilities provide radiobroadcast, radio-
telephone and telegraph, coastal radio, aeronautical radio
and international radiocommunication services; numerous
privately owned radio facilities exist; .submarine cables
extend from Madang to Australia and Guam; 37,500
telephones (1.3 per 100 popl.); 31 AM, no FM and no TV
stations ,
DEFENSE FORCES
Military manpower: males 15-49, 720,000; about 398,000
fit for military service
Supply: dependent on Australia
Military budget: for fiscal year ending 30 June 1978,
$24.8 million; 3.7% of central government budget
(See reference map Vil)
colony of Tuvalu. The remaining islands in the former
Gilbert and Ellice Islands Colony were renamed the Gilbert
Islands.
The new colony of Tuvalu includes the islands of
Nanumanga, Nanumea, Nui, Niutao, Vaitupu, and. those
islands claimed by the United States: Funafuti, Nukufetau,
Nukulailai, and Nurakita.
LAND
26 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 24 km
Railroads: none
Highways: 8 km gravel
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
211
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TUVALU/UGANDA
Airfields: 1 total; 1 usable with runway 1,220-2,439 m; 1
seaplane station
Telecommunications: 1 AM station; about 300 telephones
(0.5 per 100 popl.); 4,000 radio sets
NEW
ZEALAND
{See reference map Vi}
Railroads: none
Highways: 784 km total; 375 km bituminous, remainder
mostly gravel, crushed stone, or earth
Inland waterways: none
Ports:
Civil air: 2 major transport aircraft
1 principal (Apia), 1 minor
Airfields: 4 total, all usable; 1 with permanent-surface
runway 1,220-2,439 m :
Telecommunications: 3,300 telephones (2.2 per 100
popl.); 20,000 radio receivers; 2 AM stations
YEMEN (ADEN) .
LAND
287,490 km? (border with Saudi Arabia ‘daetibeay only
about 1% arable (of which less than 25% aa)
Land boundaries: 1,802 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 1,383 km
Railroads: none
’ Highways: 5,311 km total; 392 km bituminous treated,
290 km crushed stone and gravel, 4,699 km motorable track
Ports: 1 major (Aden)
Pipelines: refined products, 32° km
Civil air: 6 major transport aircraft
Airfields: 94 total, 56 usable; 4 with permanent-surface
runways; 4 with runways 2,440-3,659 m, 31 with runways
1,220-2,489 m
Telecommunications: small system of open-wire line,
multiconductor cable, and radiocommunications stations;
only center Aden; 9,900 telephones (0.6 per 100 popl.); 1
AM, .no FM and 8 TV stations; 2 submarine cables
- DEFENSE FORCES
Military manpower: males 15-49, 420,000; 234 ,000 fit for
military service
Military budget: .for fiscal year ending 31 December
1977, $55 million; about 19% of central government budget
YEMEN (SANA):
LAND
194,250 km? (parts of border with Saudi Arabia and
Southern Yemen undefined); 20% agricultural, 1% forested,
79% desert, waste, or urban
Land boundaries: 1,528 km
226
SAUDI
ARABIA
Indian
Ocean
(See reference map V}
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 523 km
Railroads: none
Highways: 3,477 km total; 467 km bituminous; 435 km
crushed stone -and gravel; 2,575 km earth, sand, and light
gravel
Ports: ] major (Al Hudaydah), 2 minor
_ Civil air: 9 major transport aircraft (including 3 leased in)
Airfields: 27 total, 16 usable; 4 with permanent-surface
runways; 4 with runways 2,440-3,659 m, 8 with runways
1,220-2,489 m
Telecommunications: system inadequate; consists of
meager open-wire lines and low-power radiocommunication
stations; principal center Sana, secondary centers Al
Hudaydah and Taizz; 4,600 telephones (0.1 per 100 popl.); 2
AM stations, no FM, 1 TV station; 1 Indian Ocean satellite
station
DEFENSE FORCES :
Military manpower: males 15-49: 1,313,000; 728,000 fit
for military service; about 60,000 reach military age (18)
annually ;
Military budget: for fiscal yearsending..30 June 1975,
$50,402,000; 54:6% of central government budget
YUGOSLAVIA
{See reference map ill)
LAND
255,892 km?*; 32% arable, 25% meadows and pastures, 34%
forested, 9% other
Land boundaries: 3,001 km
WATER
Limits of territorial waters (claimed): 10 nm (fishing 12
nm)
Coastline: 1,52] km (mainland), plus 2,414 km (offshore
islands) 3
Railroads: 9,967 km total; 9,619 km standard gage
(1.435 m), 348 km narrow gage; 794 double track; 2,912 km
electrified (1977)
Highways: 104,891 km total; 44,733 km asphalt, concrete,
stone block; 35,057 km asphalt treated, gravel, crushed stone;
25,101 km earth (1977) :
Inland waterways: 2,600 km (1978)
Freight carried: rail—73.7 million metric tons, 21.0
billion metric ton/km (1976); highway—84.1 million metric
tons, 11.2 billion metric ton/km (1976); waterway—23.1
million metric tons, 6.0 billion metric ton/km (incl. int''l.
transit traffic) in approximately 1,225 waterway craft with
703,600 metric ton capacity
Pipelines: 623 km crude oil; 1,860 km natural gas
Ports: 9 major (most important: Rijeka, Split, Koper, Bar,
and Ploce), 24 minor; principal inland water port is Belgrade
(1978)
DEFENSE FORCES
Military manpower: males 15-49, 5,866,000; 4,724,000 fit
for military service; 191,000 reach military age (19) annually
Military budget (announced): for fiscal year ending 31
December 1978, 42:7 billion dinars; about 4.7% of Gross
Social Product (Yugoslavia’s measure of production)
ZAIRE
LAND
2,343,950 km?; 22% agricultural land (1% cultivated), 45%
forested, 33% other
Land boundaries: 9,902 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
{
‘
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ZAIRE
Atlantic
(See reference map V)}
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 37 km
Railroads: 5,256 km total; 3,970 km 1.067-meter gage
(851 km electrified), 125 km meter gage (1.000 m); 136 km
0.615-meter gage, 1,025 km 0.600-meter gage
Highways: 145,000 km total; 2,000 km_ bituminous,
66,000 km improved earth; 77,000 km unimproved
Inland waterways: comprising the Zaire, its tributaries,
and unconnected lakes, the waterway system affords over
15,000 km of navigable routes
229
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
ZAIRE/ZAMBIA
Ports: 2 major (Matadi, Boma), 1 minor
Pipelines: refined products, 390 km
Civil air: 49 major transport aircraft
Airfields: 339 total, 285 usable; 23 with permanent-sur-
face runways; 2 with runways over 3,660 m, 3 with runways
2,440-3,659 m, 60 with runways 1,220-2,439 m
Telecommunications: limited, barely adequate telephone
service, telegraph service good; 28,000 telephones (0.1 per
100 popl.); 12 AM, 1 FM, and 2 TV stations;.1 Atlantic
Ocean satellite station; domestic Comsat network
DEFENSE FORCES
Military manpower: males 15-49, 6,054,000; 3,059,000 fit
for military service
o
0534R000100140001-7
U.S.S.R. and Asia
Adelaide
Melbourne
.
2
(7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7 !
| VIII Oceania
FE - Hawaiian*>Mou!
% yet ws Islands Hawaii
O mariana
ISLANDS United States
Philippine Sea Honnston
: Saipan
''
: i
Philippines Guam wSi05)
: ;
1
Trust Territory of the Paci
rust Territory NORTH
Brunei /
WK)
G =
=a “ laker (U.S. g a oS
Nauru’ 5 (U.S.U.K. joint admin)
Canton“ PHOENIX IS.
Phoenix —*, U.K. admin.. U.S. claim)
Bougainville = r Gardner" Hull
INS Coen, Solomon tstands-D : lb ert
c
>
z
Java Sea o
Iistand
4Indonesi Ss (WK, admin,
5 Solomon Sea { osm, Senta sabe! US. claim)
ae
a ¥ “ .
ne eae Hokiara,, \\Waleita cata ds me ceo Anise by Now Zeatand
oS 3 #
==
? (Gained US,
Guadalcanal $2" Cristobal “CRUZ , Faicss : a
= 2S eer Us. ; ILES MARQUISES','dbb83af7439523b3beac11566dc4b5d5e100cc19027e2e68db33c80518f3494f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2580a6d70ae636a6598eb0e5282eea852ac584be8b95f91c3b5b72557be48947',1972,'GU','Guam','communications',34,'DEFENSE FORCES
Military manpower: males 15-49, 3,551,000; 3,142,000 fit
for military service; 130,000 reach military age (17) annually
Military budget: for fiscal year ending 30 June 1979,
$2,925,000,000; about 8.7%: of total central government
budget','38850e9f0f945a96a316638f33c287faf164ebc2f4ac2161ab54bc4b773fa43e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9ad7878cdcade52a1ffa536b0ecdaef4c0870ceb21f3bae4da290cc0551fa76',1972,'AT','Austria','communications',35,'LAND
83,916 km*; 20% cultivated, 26% meadows and pastures,
15% waste or urban, 38% forested, 1% inland water
Land boundaries: 2,582 km
Railroads: 6,517 km total; 5.877 km government-owned;
5,397 km standard gage (1.435 m) of which 2,730 km
electrified and 1,333 km double tracked; 480 km narrow
gage (0.760 m) of which 91 km electrified; 640 km prvately
owned (1.435- and 1.000-meter gage)
Highways: approximately 33,600 km_ total atonal
classified network, including 10,400 km federal and 23,200
km provincial roads; about 20,800 km paved (bituminous,
concrete, stone block) and 12,800 km unpaved (gravel,
crushed stone, stabilized soil); additional 60,800 km commu-
nal roads (mostly gravel, crushed stone, earth)
Inland waterways: 427 km
Ports: 2 major river (Vienna, Linz)
Pipelines: 554 km crude oil; 2,611 km natural gas; 171 km
refined products
Civil air: 16 major transport aircraft
Airfields: 51 total, 50 usable; 12 with permanent-surface
runways; 3 with runways 2,440-3,659 m, a with runways
1,220-2,489 m ~
Telecommunications: highly developed and efficient;
extensive TV and radiobroadcast systems with 90 AM, 94
FM, and 350 TV stations; 1 Comsat station U/C; 2.28 million
telephones (29.9 per 100 popl.)
DEFENSE FORCES
Military manpower: males 15-49, 1,766,000; 1,495,000 fit
for military service; average number reaching military age
(19) annually about 62,000
Military budget: for fiscal year ending 31 December
1978, $720 million; about 4.0% of the federal budget +
THE BAHAMAS
LAND
11,396 km?; 1% cultivated, 29% forested, 70% built on,
wasteland, and other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm) :
Coastline: 3,542 km (New Providence Is. 76 km)','c8c4f4dd9bdb4d1acc0dee7e42fffea7bf87b9fd9bd025741bd54ac183cad0e7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6d4fa144cdeede1c0a62936c1ceb66f1f0143bfbf30e785cffa346cc6dec3aa',1972,'HT','Haiti','communications',42,'Railroads: .none
Highways: 3,350 km total; 1,350 km paved, 2,000 km
gravel
Ports: 2 major (Freeport, Nassau), 9 minor
Civil air: 7 major transport aircraft _
Airfields: 54 total, 51 usable; 25 with permanent-surface
’ runways; 3 with runways 2,440-3,659 m, 22 with runways
1,220-2,489 m; 4 seaplane stations ;
Telecommunications: telecom facilities highly developed,
including 58,000 telephones (27.5 per 100 popl.) in totally
automatic system; tropospheric scatter link with Florida; 3
AM, 2 FM stations and 1 TV station; 3 coaxial submarine
cables
_ Atlantic Ocean
SCUBA > _
oa
OMINICAN
REPUBLIC
‘ost-au-
SS
JAMAICA "Prince
Caribbean Sea
2
{See reference map tl)
LAND
27,713 km; 31% cultivated, 18% rough pastures, 7%
forested, 44% unproductive
Land boundary: 361 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 1,771 km
Railroads: 80 km narrow gage (0.760 m), single-track,,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
eee ane
——
wR Am em Re ne RACER AR OORT SET OA
ry aa a oa
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
HAITI/HONDURAS
privately owned industrial line; 8 km dual-gage 0.760- to
1.065-meter gage, government line, dismantled
Highways: 3,200 km total; 600 km paved, 950 km —
otherwise improved, 1,650 km unimproved
Inland waterways: negligible; about 100 km navigable
Ports: 2 major (Port-au-Prince, Cap Haitian), 12 minor
Civil air: 6 major transport aircraft
Airfields: 14 total, 13 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 2 seaplane stations
Telecommunications: all domestic facilities inadequate,
international facilities slightly better; telephone expansion
program underway; 17,800 telephones (0.4 per 100 popl.); 40
AM, 5 FM, and 1 TV station; 1 Atlantic Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 1,056,000; 569,000 fit
for military service; about 53,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1979, $13.8 million','f529db0000f02cd6233c2c50dbc24ed342b39b8a5ea921e46fb7b88ca96105d7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9e1b79c88ecd1031914d1adc1e115de6cc3d5381846bea0ea39cae36d1aa42e',1972,'BH','Bahrain','communications',43,'LAND
596 km? plus group of 32 smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste, or urban
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Highways: 93 km bituminous surfaced; undetermined
mileage of ‘natural surface tracks
Ports: 1 major (Bahrain)
Pipelines: crude oil, 56 km; refined products, 16 km;
natural gas, 32 km
’ Civil air: 2 major transport aircraft
Airfields: 2 total, 2 usable; 1 with permanent-surface
runway; 1 with runway over 3,660 m; 1 with runway 1,220-
2,439 m; 1 seaplane station
Telecommunications: excellent international telecom-
munications; limited domestic services; 31,000 telephones
(11.6 per 100 popl.); 1 AM station, 1 TV station, 1 Indian
Ocean satellite station; tropospheric scatter and microwave
to Qatar and United Arab Emirates
DEFENSE FORCES
Military manpower: males 15-49, 64,000; fit for military
service, 37,000
Supply: mostly from U.K.
Military budget: for fiscal year ending 31 December
1978; $42.8 million, 6% of total budget','89bc2be787d4d53f9ea279a2f6e1ee97caed8a56022124cb01ff7a4ea854af54','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3cc82e2e91e4ca253a17061ab6cc8fa10b8577c637a9d2f76f1740a24cee138',1972,'BD','Bangladesh','communications',47,'LAND
142,500 km*; 66% arable (including cultivated and
fallow), 18% not available for cultivation, 16% forested
Land boundaries: 2,535 km
WATER
'' Limits of territorial waters (claimed): 12 nm; fishing 200
nm
Coastline: 580 km
Railroads: 2,909 km total (1977); 1,910 km meter gage
(1.000 m), 964 km broad gage (1.676 m), 35 km narrow gage
(0.762 m), 300 km double track; government-owned
Highways: 44,9380 km total; 4,044 km paved, 2,022 km
gravel, 38,864 km earth
Inland waterways: 7,000 km; river steamers navigate
main waterways
Ports: 1 major; 5 minor
Pipelines: 150 km natural gas
Civil air: 9 major transport aircraft
Airfields: 23 total, 16 usable; 18 with permanent surface
runways; 3 with runways 2,440-3,659 m, 8 with runways
],220-2,4389 m
Telecommunications: adequate international radiocom-
munications and landline service; fair domestic wire and
microwave service; fair broadcast service; 100,000 (est.)
telephones (0.1 per 100 popl.); 8 AM, 1 FM, 3 TV stations,
and 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 18,237,000; 10, 498,000
fit for military service
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BANGLADESH /BARBADOS
Military. budget: for fiscal year ending 30 June 1978,
$145.0 million; about 8.8% of the central government budget','044d81a7dfd17ebc2a186e39ca1e778767bf1f54b4df4874434b267fc729168a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42ef23436605bf589d7643f574c1378ddc6e4a9ca09c3dca64abaf60a885feed',1972,'BB','Barbados','communications',51,'DOMINICAN
=> REPUBLIC
Atlantic
+ Ocean
PUERTO™
RICO
(See reference map ti}
LAND
430 km?*; 60% cropped, 10% permanent meadows, 30%
built on, waste, other
WATER .
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 97 km
Railroads: none
Highways: 1,450 km total; 1,350 km paved, and 100 km
gravel, and earth
15
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BARBADOS /BELGIUM
Ports: 1 major (Bridgetown), 2 minor
Civil air: 6 major transport aircraft (including 4 leased in)
Airfields: 1 with permanent-surface runway 2,440-3,659
m; 1 seaplane station :
Telecommunications: islandwide automatic telephone
system with 44,000 telephones (17.8 per 100 popl.);
tropospheric scatter link to Trinidad; UHF/VHF links to St.
Vincent and St. Lucia; 2 AM stations, 1 FM station, ] TV
station; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 58,000; 42,000 fit for
military service; average number reaching military age (18) -
annually, 3,000; no conscription
*Grenada
= “Trinidad
Pegor ses land Tobago
Caribbean Sea
Netherlands Antilles
Py ow
Barranquilla *
es Caracas','fab1d7191665c037544a52d41ae35595b8889eace553cf3d0f74668e9f6a160b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d0dc024ebe404669a917503d486e22a6a8e57fe99aacf304ca78722ff18f683',1972,'BE','Belgium','communications',55,'UNITED
KINGDOM
FEDERAL
REPUBLIC
OF GERMANY
(See reference map IV}
LAND
- 30,562 km?*; 28% cultivated, 24% meadow and pasture,
28% waste, urban, or other; 20% forested
Land boundaries: 1,377 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 64 km
Railroads: 4,394 km total; 4,117 km standard gage (1.435
m) and government-owned, 2,536 km double track, 1,224
km electrified; 277 km privately owned, electrified meter
gage (1.000 m)
Highways: 104,612 km total; 1,051 km paved, limited
access, divided.autoroute; 51,780 km other paved; 51,781 km
unpaved
Inland waterways: 2,043 km, of which 1,528 km. are in
regular use by commercial transport
Ports: 5 major, 1 minor
Pipelines: refined products, 1,115 km; crude, 161 km;
natural gas, 3,218 km
Civil air: 55 major transport aircraft
Airfields: 46 total, 45 usable; 23 with permanent-surface
runways; 14 with runways 2,440-3,659 m, 4 with runways
J,220-2,489 m
Telecommunications: excellent domestic and interna-
tional telephone and telegraph facilities; 2.95 million
telephones (30.0 per 100 popl.); 14 AM, 21 FM, and 25 TV
stations, 5 coaxial submarine cables; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,369,000; 1,999,000 fit
for military service; average number reaching military age
(19) annually 78,000
Military budget: proposed for fiscal year ending 31
December 1978, $2.3 billion; about 7% of proposed central
government budget','704d15d25bf74012413cd2e9d2a4c243640f81e0cd63e7147e4df284404edc39','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('891fee51e8dcbd9a50f7262968b3f0c8a47ec1990e6e55d262f0dfb7d50a33dc',1972,'MX','Mexico','communications',59,'Caribbean
Sea
Pacific Ocean
{See reference mep tl}
LAND
108,880 km*;. 14% cultivated, 10% pasture, 57% forest,
19% other
Land boundaries: 1,625 km
WATER
Limits of territorial waters (claimed): 12. nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 400 km
LAND
1,978,800 km?; 12% cropland, 40% pasture, 22% forested,
26% other (including waste, urban areas and public lands)
Land boundaries: 4,220 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm), 200 nm exclusive economic’ zone
Coastline: 9,330 km
137
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Gulf
of Mexico
Pacific Ocean
(See reference map ft)
Railroads: 19,680 km total; 18,576 km standard gage
(1.485 m); 1,104 km narrow gage (0.914 m); 102 km
electrified; 19,573 km government-owned, 107 km
privately-owned
Highways: 200,000 km total; 62,000 km paved, 88,300:
‘km otherwise improved, 49,700 km unimproved
Inland waterways: 2,900 km navigable rivers and coastal
canals ;
Pipelines: crude oil, 3,910 km; refined products, 3,490
‘km; natural gas, 5,710 km
Ports: 9 major, 20 minor
Civil air: 117 major transport aircraft
Airfields: 2,125 total, 2,062 usable; 143 with permanent-
surface runways; 2 with runways over 3,660 m, 20 with
runways 2,440-3,659 m, 279 with runways 1,220-2,489 m; 9
seaplane stations
Telecommunications: highly developed telecom system
with extensive radio-relay links; connection into Central
American microwave net; 1 Atlantic Ocean satellite ground
station; 3.31 million telephones (5.2 per 100 popl.); 574 AM,
109 FM, and 163 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 14,641,000; 11,133,000
fit for military service; average number reaching military
age (18) annually, 745,000
Military budget: for year ending 31 December 1978,
$632.8 million; about 2.9% of direct federa] budget (includes
merchant marine and military industry)
eGuadalajara
* Mérida
t ; > e Puerto Rico yi-gi
* mexi Cayman ts. font ace ART yDO™ (US), <n ON SoS RD
Mexico WK) + ti }Rep. <7 Anguilla (U.K)
: jamaica Port-au- Pris Pesci WD. ey, St Christopher (ux
? Domingo
Acapulco
Honduras __
«Te iG
San Salvaddr&, 3
EI Salvador
400 800 Kilometers
: 400 800 Miles
Boundary representation is
not necessarily authoritative
°
SGalapagos Is.
(Peusdor)
S
Declassified and Approved For Release 2012/09/02 :
| ; II
Middie America
''Washington®™ -
Permuda
{U.K}
|
Atlantic
Ocean
\\ as
Miami +6
le
eee 4 Bahamas
o
\\
?- Turk and Caicos Is.
comment)
me Antigua (U.K.)
: ES In, Nevis (U.K)
Kingsfon fo Péuadeloupe (Fr.
iy os
* Dominica
oh, (Martinique (Fr)
O St. Lucia{u.k.)
& St. Vincent
UK)','a46095bd9f16fddf3759c3bfa532d8b1aa9d3c8c605808bf1392edf676bd642c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f41ded1729454845f7b12082e195c9c93a94d0a9b507aa4e3da893adbf78d69',1972,'HN','Honduras','communications',60,'As
Pacific
Ocean
(See reference map tl)
LAND
22,973 km?; 38% agricultural (5% cultivated); 46%
exploitable forest, 16% urban, waste, water, offshore islands
or other
Land boundaries: 515 km
WATER ©
Limits of territorial waters (claimed): 3 nm
Coastline: 386 km
Railroads: none
Highways: 2,550 km total; 300 km paved, 1,150 km
gravel, 950 km improved earth and 300 km unimproved
earth
Inland waterways: 800 km river network used by
shallow-draft craft
Ports: 1 major (Belize), 4 minor
Civil air: 5 major transport aircraft
Airfields: 36 total, 37 usable; 4 with permanent-surface
runways; 1 with runway 1,220-2,489 m
Telecommunications: 5,600 telephones in automatic and
manual network (4.3 per 100 popl.); radio-relay system; 6
AM sstations
DEFENSE FORCES
Military manpower: males 15-49, 34,000; 20,000 fit for
military service; 1,700 reach military age (18) annually
ONDURAS
Tegucigalpa
<<
eC
-» SALVADOR
Pacific Ocean
{See reference map fl}
LAND
112,150 km*; 27% forested, 30% pasture, 36% waste and
built-up, 7% cropland
Land boundaries: 1,530 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 820 km
Railroads: 574 km total; 325 km 1.067-meter gage, 249
km 0.914-meter gage
Highways: 7,300 km total; 1,450 km paved, 4,150 km
otherwise improved, 1,700 km unimproved earth
Inland waterways: 1,200 km navigable by. small] craft
Ports: 3 major (Puerto Cortes, La Ceiba, Tela), 9 minor
Civil air: 16 major transport aircraft
Airfields: 256 total, 226 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m; 6 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: improved, but still inadequate;
connection into Central American microwave net; 19,500
telephones (0.7 per 100 popl.); 104 AM, 12 FM, and 6 TV
stations
90
DEFENSE FORCES
Military manpower: males. 15-49, 643,000; 381,000 fit for
military service; about 32,000 reach military age (18)
annually ,
Military budget: proposed for fiscal year ending 31
December 1978, $31.4 million; about 7.5% of central
government budget (includes the armed forces and other','e46fe75dd4756c10f4e91619547f72c17fb47c5778548e5f72f411d1f67128fe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6880ad77990f61cbcfd11ef6f8204710c4baf3c122b5151588e39f0c10496022',1972,'BJ','Benin','communications',64,'(formerly Dahomey)
LAND
115,773 km*; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and game
preserves 19%, non-arable 1%
Land boundaries: 1,963 km
WATER
Limits of territorial waters (claimed): 200 nm (100 nm
mineral exploitation . limit)
Coastline: 121 km
Railroads: 579 km, all meter gage (1.00 m)
Highways: 3,303 km total; 705 km paved, 2,598 km
improved earth
Inland waterways: 645 km _ navigable
Ports: 1 major (Cotonou), 1 minor
Civil air: 1 major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface
runway; 4 with runways 1,220-2,439 m
Telecommunications: system .of open wire and radio
relay; 9,900 telephones (0.3 per 100 popl.); 2 AM, 1 FM, and
no TV stations
DEFENSE FORCES
Military manpower: eligible 15-49, 735,000; 370,000 fit
for military service; about 34,000 males and 35,000 females
reach military age (18) annually; both sexes liable for
military service
Supply: dependent on France and Guinea; aid from North
Korea and PRC is pending
Military budget: for fiscal year ending 31 December
1977, $10.9 million; about 9.7% of central government
budget','09de882f6e226374e91a97059b01e3017bd40116997e973a83f4c416a9b7f621','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44a34841780899738af8e15ea0acfa876255c73682c6eb02759388cbd12e6471',1972,'BM','Bermuda','communications',68,'LAND
54.4 km*; 8% arable, 60% forested, 21% built on,
-wasteland, and other, 11% leased for air and naval bases
19
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
‘January 1979
BERMUDA/BHUTAN
Atlantic
UNITED ~ Ocean
STATES
(See reference map tl)
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 103 km
Railroads: none
Highways: 190 km, all paved
Ports: 8 major (Hamilton, St. George Freeport, Ireland
Island)
Civil air: 2 major transport aircraft
Airfields: 1 with asphalt runway 2,945 m; 1 seaplane
station
Telecommunications: modern telecom system, includes
fully automatic telephone system with 38,600 sets (66.6 per
100 popl.); 8 AM, 1 FM, and 2 TV stations; 3 coaxial
submarine cables
BHUTAN |
LAND
46,600 km?; 15% agricultural, 15% desert, waste, urban,
70% forested
Land boundaries: about 870 km
Highways: 1,304 km total; 418 km surfaced, 515 km
improved, 371 km unimproved earth
Freight carried: not available, very light traffic
Civil air: no major transport aircraft
Airfields: 2 total, 1 asphalt runway 1,372 m, and 1 with
concrete runway 899 m ;
Telecommunications: facilities inadequate; 1,000 tele-
phones (0.1 per 100 popl.); 6,000 est. radio sets; no TV sets; 1
AM station and no TV stations :
DEFENSE FORCES
Military manpower: males 15-49, 299,000; 159,000 fit for
military service; about 14,000 reach military age (18)
annually
“Supply: dependent on India
BOLIVIA
LAND
1,098,160 km?; 2% cultivated and fallow, 11% pasture and
meadow, 45% urban, desert, waste, or other, 40% forest, 2%
inland water
Land boundaries: 6,083 km','572e9fa99aaffcc6b0e2d453813e49d67812a3edd9be7c320f9264a9df633285','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09e9c3da6763377c9404169bbba62bf0c8a46e679e2a3609c26ec8d883302af3',1972,'BR','Brazil','communications',75,'Railroads: 3,572 km total, goverment owned, single track;
3,540 km meter gage (1.000 m), 32 km 0.760-meter gage; in
addition, 96 km meter gage (1.000 m) privately owned
Highways: 37,300 km total; 1,150 km paved, 6,550 km
gravel, 5,950 km improved earth, 23,650 km unimproved
earth :
Inland waterways: officially estimated to be 10,000 km
of commercially navigable waterways
Pipelines: crude oil, 1,670 km; refined products, 1,495
km; natural gas, 580 km
Ports: none (Bolivian cargo moved through Arica and
Antofagasta, Chile, and Matarani, Peru)
Civil air: 48 major transport aircraft —
Airfields: 576 total, 535 usable; 5 with permanent-surface
runways; 1 with runway over 3,660 m, 6 with runways
2,440-3,659 m, 128 with runways 1,220-2,439 m
Telecommunications: radio-relay system from La Paz to
Santa Cruz; improved international services; 55,000 tele-
phones (1.2 per 100 popl.); 122 AM, 18 FM, and 5 TV
stations ,
DEFENSE FORCES
Military manpower: males 15-49, 1,142,000; 723,000 fit
for military service; average number reaching military age
(19) annually about 60,000
Military budget: proposed for fiscal year ending 31
December .1978, $90.2 million; about 13.2% of central
government budget
LAND :
8,521,100 km?; 4% cuiltivated, 18% pasture, 23% built-on
area, waste, and other, 60% forested
Land boundaries: 13,076 km
24
Atlantic
Brasilia
BOLIVIA
(See reference map tll}
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 7,491 km
Railroads: 30,300 km total; 26,543 km meter gage (1.000
m), 3,361 km 1.60-meter gage, 194 km standard gage (1.435
m), 202 km 0.76-meter gage; 2,249 km electrified
Highways: 1,510,900 km total; 75,900 km_ paved,
1,485,000 km gravel or earth
Inland waterways: 50,000 km navigable
Ports: 8 major, 23 significant minor
Pipelines: crude oil, 2,000 km; refined products, 465 km;
natural gas, 257 km
Civil air; 118 major transport aircraft
Airfields: 4,298 total, 3,908 usable; 162 with permanent-
surface runways; 16 with runways 2,440-3,659 m, 412 with
runways 1,220-2,439 m; 18 seaplane stations
Telecommunications: fair telecom system; good radio
relay facilities; 1 Atlantic Ocean satellite station with 2
antennas; 3 domestic satellite stations; 3.99 million tele-
phones (3.5 per 100 popl.); 1,100 AM stations, 150 FM, and
175 TV stations; 2 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 26,643,000; 17 ,338,000
fit for military service; 1,220,000 reach military age- (18)
annually :
Military budget: for fiscal year sain 31 December
1978, $2,150 million; 8.6% of central government budget
BRUNEI
LAND
5,776 km’; 3% cultivated; 22% industry; waste, urban or
other; 75% forested
Land boundaries: 381 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Railroads: 9.6 km narrow gage (0.610 m)
Highways: 1,206 km total; 376 km paved (bituminous
treated), 402 km gravel cr stone, 428 km unimproved
Inland waterways: 209 km; navigable by craft drawing
less than 1.2 meters
Ports: 2 minor (Bandar Seri Begawan, formerly Brunei,
and Kuala Belait)
Pipelines: crude oil, 185 km; refined products, 56 km;
natural gas, 56 km; crude oil and natural gas, 241 km under
construction :
Civil air: 4 major transport aircraft
Airfields: 3 total, 3 usable; 2 with ‘permanent-surface
runway; 1 with runway over 3,660 m; 2 with runways
1,220-2,439 m
Telecommunications: service throughout country is: ade-
quate for present needs; international service good to
adjacent Sabah and Sarawak; radiobroadcast coverage good;
11,000 telephones (0.3 per 100 popl.); Radio Brunei
broadcasts from 6 AM stations and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 41,000; 24,000 fit for
military service; about 1,900 reach military age (18)
annually
Pacific Ocean
(See reference map Il)
LAND
274,540 km? (including Galapagos Islands); 11% culti-
vated, 8% meadows and pastures, 55% forested, 26% waste,
urban, or other (excludes the Oriente and the Galapagos
Islands, for which information is not available)
Land boundaries: 1,931 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,237 km (includes Galapagos Is.)
{See reference map tl}
LAND
142,709 km?; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially
productive, 16% built-on area, wasteland, and other
Land boundaries: 1,561 km
196
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 386 km
Railroads: 166 km total; 86 km meter gage (1.00 m)
(government-owned) and 80 km narrow gage (industrial
lines); all single track |
Highways: 2,500 km total; 500.km paved, 200 km gravel,
600 km improved earth, 1,200 km unimproved earth
Inland waterways: 4,500 km; most important means of
transport; oceangoing vessels with drafts ranging from 4.2 m
to 7 m can navigate many of the principal waterways while
native canoes navigate upper reaches
Ports: 1 major (Paramaribo), 6 minor
Civil air: 1 major transport aircraft
1 Suriname guilder (S.
Airfields: 30 total, 29 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 2 with runways
1,220-2,489 m
Telecommunications: international facilities good; do-
mestic radio-relay system; 18,600 telephones (4.9 per 100
popl.); 6 AM, 1 FM, and 1 TV station with 4 relay
transmitters
DEFENSE FORCES
Military manpower: males 15-49, 86,000; 50,000 fit for
military service
SWAZILAND
SOUTHERN
RHODESIA','810bb2bd1fc37cbd7f7c6d4aa58c66d034543e54590399c6d8ca700fa51d9869','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5257867dabd601d0c687949bb15ae6c191dc0a91ef00ef18c64be1067b302189',1972,'BW','Botswana','communications',76,'Atlantic
Ocean
{See reference map Vi}
LAND .
569,800 km?; about 6% arable, less than 1% under
cultivation, mostly desert eM :
Land boundaries: 3,774 km
‘Railroads: 726 km 1.067-meter gage
Highways: 10,476 km total; 579 km paved; 1,453 km
crushed stone or gravel; 5,407 km improved earth and 3,037
km unimproved earth
Inland waterways: native craft only; of local.importance
Civil air: 2 major transport aircraft
Airfields: 83 total, 65 usable; 3 with permanent-surface
runways; 14 with runways 1,220-2,489 m
* Telecommunications: the system is a minimal combina-
tion of open-wire lines, radio-relay links, and a few
‘radiocommunication stations; Gaborone is the center; 7,900
telephones (1.2 per 100 popl.); 1 AM, 1 FM, and no TV
stations ;
DEFENSE FORCES
Military manpower: males 15-49, 142,000: 74,000 fit for
military service; 9,000 reach military age (18) annually
Indian Ocean
SOUTH AFRICA .
(See reference map Vi)
available for extensive cattle grazing; 39% European
alienated lands (farmed by modern methods), 48% African,
7% national land, 6% not alienated
Land ‘ boundaries: 3,017 km
Railroads: 3,434 km narrow gage (1.067 m); 42 km double
track
Highways: 78,428 km total; 7,995 km paved, 32,855 km
crushed stone, gravel, stabilized soil, or improved earth;
87,578 km unimproved earth (est.)
Inland waterways: 280 km. on Lake. Kariba
Pipelines: 8 km crude oil (nonoperating)
Airfields: 399 total, 392 usable; 17 with permanent-sur-
face runways; 2 with runways over 3,660 m, 3 with runways
2,440-3,659 m, 29 with runways 1,220-2,439 -m
Civil air: 11 major transport aircraft
Telecommunications: system is one of the best in Africa;
consists of radio-relay links, open-wire lines, and ‘radiocom-
munication stations; principal center Salisbury, secondary
center Bulawayo; 190,300 telephones (2.8 per 100 popl.); 8
AM, 1 FM, and 5 TV stations
DEFENSE FORCES .
Military manpower: males 15-49, 1,514,000; 928,000 fit’
for military service; average number reaching military age
(18) annually, 71,000','3eda0d3365f24a945322217c9f95aa2d31e5b9f6a46f72b41c7da095c264cbfa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef01468a20f27878c1a828076ef4c5d14338520052ec8a27020a3b183f639949',1972,'BI','Burundi','communications',81,'LAND
28,490 km?; about 37% arable (about 66% cultivated), 23%
pasture, 10% scrub and forest, 30% other
Land boundaries: 974 km
Railroads: none
Highways: 7,800 km total; 300 km bituminous, 2,500 km
crushed stone, gravel, or laterite, and 3,000 km improved
earth, and 2,000 km unimproved earth
Inland waterways: Lake Tanganyika navigable for lake
steamers and barges, 1 minor lake port
Civil air: 5 major transport aircraft
Airfields: 12 total, 12 usable; 1 with permanent-surface
runway; ] with runway 2,440-3,659 m
Telecommunications: sparse system of wire and low-
capacity radio-relax links; telegraph primary means of
communication; about 6,000 telephones (0.2 per 100 popl.);
2 AM, 1 FM, and no TV stations
DEFENSE - FORCES
Military manpower: males 15-49, 907,000; 469,000 fit for
military service; 45,000 reach military age (16) annually
Military budget: for fiscal year ending 31 December
1978, $21,278,000; about 17.4% of central government
budget','1e1d574f069c0ae60a24d0c59534b49aa3104c065007e86ba9cd8f00699a4088','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6777d48cb6f23b291998acb255fe06b914bae72c01b00296ae98b1411e5e87c2',1972,'CM','Cameroon','communications',85,'LAND
475,400 km?; 4% cultivated, 18% grazing, 13% fallow, 50%
forest, 15% other
‘Land boundaries: 4,554 km
30
CENTRAL
CAMEROON AFRICAN _EMPIRE
A) *y dé
EQUATORIAL vidio
Atlantic
Ocean
{See reference map Vi}
LAND
27,972 km?; Rio Muni, about 25,900 km?, largely forested;
Fernando Po, about 2,072 km?
Land boundaries: 539 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 296 km
59
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
EQUATORIAL GUINEA/ETHIOPIA
Railroads: none
Highways: Rio Muni—2,460 km, including approx. 185
km bituminous, remainder gravel and earth; Fernando Po—
300 km, including 146 km bituminous, remainder gravel and
earth
Inland waterways: Rio Muni has approximately 167 km
of year-round navigable waterway, -used mostly by pirogues
Ports: 2 major (Macias Nguema Biyogo, Rey Malabo), 3
minor
Civil air: 3 major transport aircraft (leased in)
Airfields: 5 total, 3 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m
Telecommunications: fairly adequate for the size and
stage of development of the country; international commu-
nications by radio from Bata and Malabo to Cameroon,
Nigeria, and Spain; 1,700 telephones (0.5 per 100: popl.); 2
AM stations, no FM stations, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 89,000; 44,000 fit for
military service
Military budget: for fiscal year ending 31 December
1970, $3,475,700; 14.8% of central government budget','b71a2b42270d115d20781443c98d22832dd323ee2fb6ea57890dc81418f1b377','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82a0cdb24e30e4bbfdc7a03089ff850ce373f00ec6568734bb2057fcc0fe706b',1972,'GA','Gabon','communications',86,'(See reference map Vi}
WATER
Limits of territorial waters (claimed): 18 nm
Coastline: 402 km
Railroads: 1,008 km total; 858 km meter gage (1.00 m),
145 km 0.600-meter gage
Highways: approximately 29,866 km total; including
2,155 km bituminous, 27,711 km gravel and earth
Inland waterways: 2,090 km
Ports: 1 major (Douala), 3 minor
Civil air: 5 major transport aircraft
Airfields: 63 total, 60 usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 21 with runways
1,220-2,489 m; 1 seaplane station
Telecommunications: fair telephone service; fair to good
telegraph service; 26,000 telephones (0.4 per 100 popl.); 4
AM, no FM, and no TV stations; 1 submarine cable; 1
Atlantic Ocean: satellite station
‘DEFENSE FORCES
Military manpower: males 15-49, 1,494,000; 751,000 fit
for military service; average number reaching military age
. (18) annually about 69,000
Military budget: for fiscal year ending 30 June 1978,
$62,534,667; 8.5% of central government budget-
LAND ’
264,180 km*; 75% forested, 15% savanna, 9% urban and
wasteland, less than 1% cultivated
Land boundaries: 2,422 km
WATER
Limits of territorial waters (claimed): 100 nm; fishing,
150 nm ‘
70
Atlantic
Ocean
{See reference map Vi}
Coastline: 885 km
Railroads: none
Highways: 6,797 km total; 308 km paved, 5,589 km
gravel and/or improved earth, 500 km unimproved earth
Inland waterways: approximately 1,600 km perennially
navigable
Pipelines: crude oil, 129 km
'' Ports: 3 major (Libreville, Port-Gentil, Owendo), 2 minor
Civil air: 24 major transport aircraft
Airfields: 163 total, 101 usable; 6 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 20 with runways
1,220-2,4389 m; 1 seaplane station
Telecommunications: system of open-wire, radio-relay,
tropospheric scatter links and radiocommunication stations;
1 Atlantic Ocean satellite station; 5 AM, no FM, and 3 TV
stations; 7,000 telephones (1.3 per 100 popl.)
DEFENSE FORCES
Military manpower: males 15-49, 127,000; 64,000 fit for
military service; 4,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1978, $52,627,100; 5.1% of central government budget
THE GAMBIA
(See reference map Vi}
LAND
10,360 km?*; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up areas, etc.
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 80 km
Railroads: none
Highways: 1,858 km total; 190 km_ bituminous-surface
treated, 1,330 km gravel/laterite, remainder unimproved
earth
Inland waterways: 605 km
Ports: 1 major (Banjul)
Civil air: no major transport aircraft
Airfields: 1 usable with permanent-surface runway
2,440-3,659 m; 1 seaplane station (non-operational)
Telecommunications: adequate network of radio-relay;
2,700 telephones (0.5 per 100 popl.); 1 AM station, 1 FM
station, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 131,000; 66,000 fit for
military service
.GERMAN DEMOCRATIC REPUBLIC
{See reference map IV}
LAND
108,262 km?; 43% arable, 15% meadows and pasture, 27%
forested, 15% other
Land boundaries: 2,309 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 901 km (including islands)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a ee Ry
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GERMAN DEMOCRATIC REPUBLIC
Railroads: 14,215 km total; 13,906 km standard gage
(1.4385 m), 309 km meter (1.00 m) or other narrow gage,
2,971 km double track standard gage (1.435 m); 1,511 km
overhead electrified (1977)
Highways: 127,530 km total; 47,530 km concrete, asphalt,
stone block, of which 1,679 km are autobahn and limited
access roads; over 80,000 km asphalt treated, gravel, crushed
stone, and earth (1976)
Inland waterways: 2,546 km (1978)
Freight carried: rail—298.6 million metric tons, 52.1]
billion metric ton/km (1977); highway—714.1 million
73
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GERMAN DEMOCRATIC REPUBLIC/GERMANY, FEDERAL REPUBLIC OF
metric tons, 18.4 billion metric ton/km (1976); waterway—
14.0 million metric tons, 2.0 billion metric ton/km (excl.
int''l. transit traffic) (1977); approximately 1,410 waterway
craft with 570,000 metric ton capacity (1978)
Pipelines: crude oil, 1,075 km; refined products, 350 km;
natural gas 483 km
Ports: 4 major (Rostock, Wismar, Stralsund, Sassnitz), 13
minor; principal inland waterway ports are E. Berlin, Riesa,
and .Magdeborg (1978) .
DEFENSE FORCES
Military budget: announced for fiscal year ending 31
December 1978, 11.6 billion marks; about 8.9% of total
budget
GERMANY, FEDERAL REPUBLIC OF
(See reference map iV)
LAND
248,640 km? (including West Berlin); 33% cultivated, 23%
meadows and pastures, 13% waste or urban, 29% forested,
2% inland water
Land boundaries: 4,232 km
WATER :
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 1,488 km (approx.)
Railroads: 33,453 km total; 29,082 km government-
owned, standard gage (1.435 m), 12,491 km double track;
9,760 km electrified; 4,421 km non-government owned;
3,997 km standard gage (1.435 m); 214 km electrified; 424
km meter gage (1.00 m); 186 km electrified
Highways: 398,720 km total; 161,400 km classified,
includes 153,160 km cement-concrete, bituminous, or stone
block (includes 5,792 km of autobahnen); 8,240 km gravel,
crushed stone, improved earth; in addition, 237,320 km of
unclassified roads of various surface types :
Inland waterways: 5,222 km of which almost 70% usable
by craft of 990 metric-ton capacity or larger
Pipelines: crude oil, 1,931 km; refined products, 1,942
km; natural gas, 95,414 km
Ports: 10 major, 11 minor
Civil air: 181 major transport aircraft (including 9 leased
out)
Airfields: 421 total, 382 usable; 213 with permanent-
surface runways; 3 with runways over 3,660 m, 33 with
runways 2,440-3,659 m, 40 with runways 1,220-2,439 m
Telecommunications: highly developed, modern tele-
communication service to all parts of the country; fully
adequate in all respects; 21.2 million telephones (34.4 per
100 popl.); 90 AM, 129 FM, and 2,350 TV stations; 6
submarine cables; satellite station with 1 Indian Ocean and 2
Atlantic Ocean antennas, and symphonie antenna
DEFENSE FORCES
Military manpower: males 15-49, 15,796,000; 13,054,000
fit for military service; 513,000 reach military age (18)
annually ; ,
Military budget: for fiscal year ending 31 December
1979, $19,130 million; about 18% of the proposed central
government budget
(See reference mep V)
LAND
964 km? (Sao Tome, 855 km? and Principe, 109 km?;
including small islets of Pedras Tinhosas)
WATER .
Limits of territorial waters: 6 nm (fishing 12 nm)
Coastline: estimated 209 km
Ports: 1 major (Sao Tome)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SAO TOME AND PRINCIPE/SAUDI ARABIA
Civil air: 1 ‘major transport aircraft
Airfields: 4 total, 4 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m
Telecommunications: minimal system; 750 telephones
(1.0 per 100 popl.); 2 AM, 1 FM, and no TV stations
4','ddeb043196f52e01c26f112762088b257eb44e4fd93bab313cdc065fd914fd08','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2f5c2ab3a44ef3c087289a2edb41e414700d2588703c09755c6f5a76cb03f4c',1972,'CA','Canada','communications',90,'10 Arctic Ocean
(See reference map |}
LAND
9,971,500 km!; 4% cultivated, 2% meadows and pastures,
44% forested, 42% waste or urban, 8% inland water
Land boundaries: 9,010 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 90,908 km
Railroads: 71,503 km total; 70,141 km standard gage
(1.435 m) (43 km electrified); 1,183 km 1.067-meter gage (in
Newfoundland); 179 km 0.914-meter gage
Highways: 829,325 km total; 640,850 km_ surfaced
(189,800 km paved), 188,475 km earth
Inland waterways: 3,000 km
Pipelines: oil, 23,564 km total crude and refined; natural
gas, 74,980 km
Ports: 19 major, 300 minor
Civil air: 551 major transport aircraft
Airfields: 1,801 total, 1,452 usable; 298 with permanent-
surface runways; 4 with runways over 3,659 m, 29 with
runways 2,440-3,659 m, 285 with runways 1,220-2,439 m; 58
seaplane stations
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
an KR AD Pt AR AA ATA RE
A A OMA
i i in
i 1 ee
bid
Side dl
SS a, a A re Oe ee ee ye ee, ee ee Oe ee ee a a ee
eS ey ee ee re en eg ONE ae > ae ae ee ee? ee.
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CANADA/CAPE VERDE
Telecommunications: excellent service provided by mod-
ern telecom media; 13.8 million telephones (60.4 per 100
popl.); countrywide AM, .FM, and TV coverage including
630 AM, 80 FM, and 500 TV stations; 8 coaxial submarine
cables; 3 major COMSAT stations and 70 domestic COMSAT
stations
DEFENSE FORCES
Military manpower: males 15-49, 6,201,000; 5,332,000 fit
for military service; average number reaching military age
(17) annually 235,000
Military’ budget: proposed for fiscal year ending 31
March 1979, $3.47 billion; about 8.3% of proposed central
government budget
CAPE VERDE
CAPE VERDE
o
Atlantic Ocean
(See reference map (IV)
LAND
4,040 km?, divided among 10 islands and several islets
WATER
Limits of territorial waters: 100 nm
Coastline: 965 km
Ports: 1 major (Mindelo), 3 minor
Civil air: 2 major transport aircraft
Airfields: 6 total, 6 usable; 4 permanent-surface runways;
1 with runway 2,440-3,659 m, 4 with runways 1,220-2,439
m; 1 seaplane station
Telecommunications: interisland radio-relay system, HF
radio to mainland Portugal, about 1,600 telephones (0.3 per
100 popl.); 1 FM and 5 AM stations; 2 coaxial submarine
cables
33
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
CAPE VERDE/CENTRAL AFRICAN EMPIRE
DEFENSE FORCES
Military manpower: males 15-49, 77,000; 43,000 fit for
military service -
Military budget: for fiscal year including 31 December
1978, $3 million; about 5% of central government budget
CENTRAL AFRICAN EMPIRE
CoS
(See reference map Vi}
LAND
626,780 km’; 10%-15% cultivated, 5% dense forests,
80%-85% grazing, fallow, vacant arable land, urban, waste
Land boundaries: 4,981 km
Railroads: none
Highways: 21,950 km total; 290 km bituminous, 7,500 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
|
¢
i
§
¢
:
TN AA
a a A i i rt all i
i i i i a i er ia at a in ii a an A A A i ne i a a ne ae nee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CENTRAL AFRICAN EMPIRE/CHAD
gravel and/or crushed stone, 14,160 km improved earth,
remainder unimproved earth
Inland waterways: 7,080 km; traditional trade carried on
by’ means of dugouts on the extensive system of rivers and
streams; the Oubangui River between Bangui and Brazza-
ville is navigable for about 8 months a year, and short
sections of the Sangha and the Lobaye Rivers are navigable
throughout year; during high-water period (July-December)
Oubangui navigable upstream from Bangui as far as Quango
Ports: Bangui, Ouango (river ports)
Civil air: 4 major transport aircraft
Airfields: 54 total, 46 usable; 3 with permanent-surface
runways; 1] with runway 2,440-3,659 m, 18 with runways
1,220-2,489 m
Telecommunications: facilities are meager; network is
composed of low-capacity, low-powered radiocommunica-
tion stations and radio-relay links; 5,540 telephones (0.3 per
100 popl.); 1 AM station, 1 FM station, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 427,000; 222,000 fit for
military service
Supply: mainly dependent on France, but has received
equipment from Israel, Italy, U.S.S.R., and FRG
Military budget: for fiscal year ending 31 December
1977, $7.5 million (current budget only); about 10.6% of
central government current budget
CAMEROON ’ , ae
bad
eo be
i-_
|
(See reference map Vi}
LAND ;
1,284,640 km*; 17% arable, 835% pastureland, 2% forest
and scrub, 46% other uses and waste
Land boundaries: 5,987 km
Railroads: none
Highways: 27,505 km total; 242 km bituminous, 4,385 km
gravel and laterite, and remainder unimproved
Inland waterways: approximately 2,090 km of year-
round navigability, increased to 4,830 km during high-water
period ,
Civil air: 4 major transport aircraft
Airfields: 67 total, 62 usable; 4 with permanent-surface
runways; | with runway 2,440-3,659 m, 22 with runways
1,220-2,489 m
Telecommunications: fair system of radiocommunication
stations only for intercity links; principal center N''Djamena,
secondary center Sarh; 5,480 telephones (0.1 per 100 popl.);
1 AM, no FM, and no TV stations; 1 Intelsat Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 999,000; 518,000 fit for
military service; average number reaching military age (20)
annually about 41,000
Supply: dependent on France primarily
Military budget: for fiscal year ending 31 December
1977, $22.2 million; about 38% of total budget','43c2b96d35f92023d85dd7c4039097922b20b7181b2036c0d59d6b15e4a56614','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dee147fb2cb1655ff5aaf95493841b5809065357dfd0e3e32786e6627cf301a',1972,'CL','Chile','communications',94,'LAND
756,626 km?; 2% cultivated, 7% other arable, 15%
36
g BOLIVIA
Pacific
{See reference map “My
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities
Land boundaries: 6,325 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 6,435 km
Railroads: 6,361 km total; 3,111 km 1.676-meter gage,
185 km standard gage (1.435 m), 3,115 km meter gage
(1.00 m)
Highways: 75,200 km total; 9,000 km paved, 38,200 km
gravel, 28,000 km improved and unimproved earth
Inland waterways: 725 km
Pipelines: crude oil, 755 km; refined products, 785 km;
natural gas, 320 km
Ports: 10 major, 20 minor
Civil air: 33 major transport aircraft
Airfields: 355 total 346 usable; 46 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 52 with
runways 1,220-2,439 m; 6 seaplane stations
Telecommunications: modern telephone system based on
extensive radio relay facilities; 473,000 telephones (4.5 per
100 popl.); 1 Atlantic Ocean satellite station; 180 AM, 30
FM, and 56 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 2,717,000; 2,048,000 fit
for military service; average number reaching military age
(19) annually about 116,000
37
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CHILE/CHINA
Military budget: for fiscal year ending 31 December
1978, US$732.6 million; about 26% of central government
budget
Valparaiso
Santi o*
Concepcién
503083 1-79
Declassified and Approved For Release 2012/09/02 : CIA-RDP0Q8-00534R000100140001-7
Fr
*Cardeas
a:','20cea8eff800c0bf2a44441da774704e818c46a0fef79ee38663fe9d9ef6725d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d46e36a076c8400d5cd77c951564cf01bdf2506c76fe6a3fd9eaf2f129b80e8a',1972,'CN','China','communications',98,'{See reference map Vil}
LAND
9.6 million km?; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of this area
consists largely of denuded wasteland, plains, rolling hills,
and basins from which about 3% could be reclaimed), 8%
forested; 2%-3% inland water
Land boundaries: 24,000 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 14,500 km
Railroads: networks total about 45,000 route km com-
mon-carrier lines; about 600 km meter gage (1.00 m); rest -
standard gage (1.435 m); all single track except 9,000 km
double track on standard gage lines; approximately 1,025 km
electrified; about 9,700 km industrial lines (gages range from
0.59 to 1.485 m)
Highways: about 835,000 km all types roads; almost half
(about 300,000 km) unimproved natural earth roads and
tracks; about 215,000 km improved earth roads about 2- to
5-meters wide and in poor to fair condition; remainder
(about 260,000 km) includes maiority. of principal roads
Ports: 10 major, 180 minor
Airfields: 379 total; 9 with runways 3,500 m and over: 45
with runways 2,500 to 3,499 m; 187 with runways 1,200 to
2,499 m; 124 with runways less than 1,200 m; 2 seaplane
stations; 12 airfields under construction, of these, 249 have
permanent surface runways
Telecommunications: urban and industrial areas served
by reasonably adequate facilities for domestic and interna-
tional communication needs; facilities) being expanded;
effective broadcast coverage is provided by radio, extensive
wired-broadcast networks, and an expanding TV network;
estimated 5 million telephones, 45 million radio receivers,
140 million wired-speakers and est. 500,000 TV receivers;
250 AM, 7 FM, and 120 TV transmitter and rebroadcast
stations; 3 standard international communications satellite
ground stations; coaxial cable links Canton to Hong Kong;
submarine cable links Shanghai to Japan; additional subma-
rine cables planned
DEFENSE FORCES
Military manpower: males 15-49, 233,823,000, about
130,711,000 fit for military service; about 9,635,000 reach
military age (18) annually
TAIWAN
Taipei
TAIWAN
South China
Sea PHILIPPINES
2 coe
(See reference mep Vil} ,
LAND
32,260 km? (Taiwan and Pescadores); 24% cultivated, 6%
pasture, 55% forested. 15% ,other (urban, industrial, de-
nuded, water area)
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 990 km Taiwan, 459 km offshore islands
Railroads: about 1,000 km common-carrier and 3,500 km
industrial lines, all on Taiwan; common-carrier lines consist
of West System: 825 km meter gage (1.00 m) with 325 km
double track, complete line under construction for electrifi-
cation; East Line: 175 km narrow gage (0.762 m) (presently
under construction to convert to meter gage compatible with
‘West System); common-carrier lines owned by government
and operated by Railway Administration (TRA) under
Ministry of Communications; industrial lines owned and
operated by government enterprises
Highways: network totals 16,900 km (construction of
North-South Freeway approximately 84%—250 km—com-
plete), plus 483 km on Penghu and offshore islands; 7,564
km paved, 6,276 km gravel and crushed stone, 2,736 km
earth
Pipelines: 615 km refined products, 97 km natural gas
Ports: 5 major, 5 minor :
Airfields: 39 total, 37 usable; 27 with permanent-surface
runways; 2 with runways over 3,659 m, 12 with runways
2,440-3,659 m, 10 with runways 1,220-2,439 m; 1 seaplane
station
DEFENSE FORCES
Military manpower: males 15-49, 4,248,000; 3,426,000 fit
for military service; about 199,000 currently reach military
age (19) annually
Military budget: for fiscal year ending 30 June 1978,
$1,814.7 million including personnel costs; about 52.5% of
central government budget
Railroads: 4,535 km total operating in 1976; 3,870 km
standard gage (1.435 m), 665 km narrow gage (0.762 m); 259
km double tracked; about 1,140 km electrified; govern-
ment-owned
Highways: about 20,280 km (1976); 98.5% gravel, crushed
stone, or earth surface: 1.5% concrete or bituminous
Inland waterways: 2,253 km; mostly navigable by small
craft only
Ports: 6 major, 26 minor
DEFENSE FORCES
Military manpower: males 15-49, 3,905,000; 2,392,000 fit
for military service; 192,000 reach military age (18) annually
Military budget: announced for fiscal -year ending 31
December 1978, $1.27 billion; about 16% of total govern-
ment budget
KOREA, SOUTH
(See reference map Vil)
LAND
98,400 km?*; 23% arable (22% cultivated), 10% urban and
other, 67% forested
Land boundaries: 241 km
KOREA, NORTH/KOREA, SOUTH
WATER
Limits of territorial waters: 12 nm
Coastline: 2,413 km
January 1979
Fiscal year: calendar year
Freight carried: rai] (1976) 9.2 billion metric ton/km,
43.6 million metric tons; highway 21.8 million metric tons;
air (1959) 361,184 kg carried
Pipelines: 515 km refined products
Ports: 10 major, .18 minor
-Civil air: 28 major transport aircraft
Airfields:. 120 total, 114 usable; 55 with permanent-
surface runways; 15 with runways 2,440-3,659 m, 16 with
runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 9,741,000; 6,340,000 fit
for military service; average number reaching military age
(18) annually 416,000
Military budget: proposed for fiscal year ending 31
December 1979, $3.2 billion; about 88. 2% of central
goyernment | budget
Ch''eng-tu
Hsi-an
* (Sian)
eK''un-ming
Yogyakarta
: CIA-RDPO8-0
VII
gv akutsk
habarovsk
‘.
Ha-erh-pin,
(Harbin)
Shen-yang, aaa
y ,f&,, P''ySngyang
sedift,
Dy. .
Sovth
area
Chiing-tao § ;
{Tsingtao} 5
- “DShang-hai
oWurhan
Kuang-cho
} ‘aipei
Taiwan
Luzon
ton Philippines
Ss Ppp
Brunei pgahd
(LK.','2561ab7f6f55894bdf70105c50b077270abb2927559c71eb20bfdf8a0dff8289','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71e4b2469c3fc0a9fd6a826f85d755affc843e69e82b0316447d228a63c5b389',1972,'CO','Colombia','communications',102,'LAND
1,139,600 km?; settled area 28% consisting of cropland and
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
7 an
A i A AR AA A Ae A TR an
ee) ee, wweew a errs
Ee ee a ee ee ee Se ee a ee ee ee ee ee a, ee ee ee ae See wr VEU lUDE
eS ee ee
ee ee
ON RE 5 Rm aT OE Na I ON ONE ee ea ee a
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
» Bogota
COLOMBIA ~
Pacific ¢
Ocean BRAZIL -
(See reference map til)
fallow 5%, pastures 14%, woodland, swamps, and water 6%,
urban and other 8%; unsettled area 72%—mostly forest. and
savannah
Land_ boundaries: 6,085 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 2,414 km
Railroads: 3,436 km, all 0.914-meter gage, single track, 35
km electrified ,
Highways: 52,100 km total; 8,200 km paved, 43,900 km
gravel and earth
Inland waterways: 14,300 km, navigable by river boats
Pipelines: crude oil, 3,585 km; refined products, 1,350
km; natural gas, 830 km; natural gas liquids, 125 km
Ports: 5 major, 5 minor
Civil air: 79 major transport aircraft
Airfields: .674 total, 673 usable; 44 with -permanent-
surface runways; 1 with runway over 3,660 m; 5 with
runways 2,440-3,659 m, 88 with runways 1,220-2,439 m; 11
seaplane stations :
Telecommunications: nationwide radio-relay system; 1
Atlantic Ocean satellite station; 1.34 million telephones (5.5
per 100 popl.); 325 AM, 130 FM, and 48 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 5,857,000, 3,833,000 fit
for military service; average number reaching military age
(18) annually about 297,000
’ Military budget: proposed for fiscal year ending 31
December 1978, $181.8 million; about 7.7% of ecatral
government budget
(See reference map ti}
LAND
1,020 km’; 5% arable, 95% waste, urban, or other
WATER
Limits of territorial waters (claimed): 3 nm
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Lye SS ary
* — Rg a wn ann =
ee - iy
ee ee ee
DB;
eee
cee I aN RS ae ee ee a ee ee
EE I ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NETHERLANDS ANTILLES
Coastline: 364 km
Railroads: none
Highways: 700 km total; 500 km paved, 200 km gravel
and earth
Ports: 3 major (Willemstad, Oranjestad, Caracasbaai,
Civil air: 12 major transport aircraft (including 4 leased
in)
Airfields: 7 total, all usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 2 with runways
1,220-2,489 m; 1 seaplane station
149
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NETHERLANDS ANTILLES/NEW CALEDONIA
Telecommunications: generally adequate telecom facili-
ties; extensive interisland radio-relay links; 48,000 telephones
(19.9 per 100 popl.); 11 AM, 1 FM and 5 TV stations; 2
submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 57,000; 33,000 fit for
military service; about 2,000 reach military age (20)
annually
Defense is responsibility of the Netherlands
Pacific Ocean
(See reference map tl}
LAND
75,650 km? (excluding Canal Zone, 1,430 km?); 24%
agricultural land (9% fallow, 4% cropland, 11% pasture),
20% exploitable forest, 56% other forests, urban, and waste
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979 -
Brazil °
CIA-RDP08-00534R000100140001-7
a
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
f Fauite
{ Ecuador
Guayaqaily, Y
{ Iquitos,
South
Antofagastar -
Pacific
Ocean','4ad3c7f4276769dd216f9e9e8344a7ed063f28ba6447b92b7b3dbeee501089f5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1106e82038376718e1738952110df157c558e14eb07ac08f70b300dc91a68817',1972,'KM','Comoros','communications',106,'LAND
2,170 km?; 4 main islands; forests 16%, pasture 7%,
cultivable area 48%, non-cultivable area 29% ~
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 340 km
Railroads: none
Highways: 999 km total; approximately 295 km bitumi-
nous, remainder crushed stone or gravel
Ports: 1 minor (Moroni on Grande Comore)
Civil air: 3 major transports (2 registered in France)
Airfields: 5 total, 5 usable; 5 with permanent surface
runways: 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,489 m
Telecommunications: sparse system of HF radiocom-
munication stations for interisland, island and external
communications to Malagasy and Reunion; 1,100 telephones
(0.3 per 100 popl.); 2 AM, 1 FM, and no TV stations
CENTRAL
AFRICAN EMPIRE
Atlantic
Ocean
(See reference map VI}
LAND F
349,650 km?; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban or waste
Land boundaries: 4,514 km
WATER
Limits of territorial waters (claimed): 30 nm
Coastline: 169 km
Railroads: 800 km, 1,067-meter gage, single track
Highways: 8,246 km total; 555 km bituminous surface
treated; 848 km gravel, laterite, 1,623 km improved earth,
and 5,220 km unimproved roads
Inland waterways: 6,485 km _ navigable
Pipelines: crude oil 25 km
Ports: 1 major (Pointe Noire)
Civil air: 4 major transport aircraft (including 1 leased in)
Airfields: 68 total, 51 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 20 with runways
1,220-2,489 m; 1 seaplane station
Telecommunications: services adequate for government
use; network is comprised of low-capacity, low-powered
radiocommunication stations, coaxial cables and wire lines;
key centers are Brazzaville, Pointe-Noire, and Loubomo;
10,500 telephones (0.7 per 100 popl.); 3 AM stations, 1 FM
station, and 1 TV station; 1 Atlantic Ocean COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 323,000; 164,000 fit for
military service; about 14,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1976, $37,517,400; about 17% of central government budget
44
gMoroni
r)
y Antananarivo
Namibia Mauritius
South Atrica }
) *
{Walvis Bay) | Windhoek] Gaborone
Port Louis.
Pe aiid
Reunion
Botswana (Fe)
‘A Pretoria
: Mbabane(“}
Swaziland
Maputo
" Moserus 4
\\, South Africa Ngsotho
Ca pe Town}
1000 Kilometers
500 1000 Miles
Boundary representation is
not necessarily authoritative
503986 1-79
Declassified and Approved For Release 2012/09/02
: CIA-RDPO8-00534R000100140001-7
\\
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
‘ tp Greenland
7 rv (Denmark)
Iceland e. .. &
K he
aKuybyshev es verdiovsk
Volgograd
. Omsk
Novosibirsk
C= f }
eTashkent Fey
Wu-lu-mu-ch’t
(Uru mehi)
\\ aa ladian claim
Ss :
Saudi
Arabia
j=
vemen \\.
(Adon) ¢','3234049d09967375d9371aa9674aade06f6282b5ede0e63559e36f32d9af686e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77ac1eb7be6ccf886e8765200528e7dd4c8ec4b1fb91ef4835c88a7da25e31cf',1972,'CK','Cook Islands','communications',112,'Pacific Ocean
* COOK
ISLANDS
(See reference map Vill}
LAND
About 240 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 120 km
Railroads: none
Highways: 187 km total (1977); 835 km paved, 35 km
gravel, 84 km improved earth, 33 km unimproved earth
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 6 total, 5 usable; 1 with permanent-surface
runway 2,317 m, 1 with natural surface runway; 1 seaplane
station
Telecommunications: 6 AM, no FM, and no TV stations;
7,000 radio receivers, and 956 telephones
‘jew Zealand)
Ce: ‘sRennell
mans, Western US.)
INDIAN ee N rii Samee (| Page
. : \\ °c Ss f
OCEAN Santo « Ful tsLanDS> po,
New Hebrides >* Vonua Levu? — {j Tonga eC
(Angle Freeh Condoninion) sPapeete
, Tsu Qo: Nive : Pe rabiti
{
. 1
New* QL: a
oatedini Se : Fiurvatotal Rosine!
New Caledonia Gb |. les Gambier
(Fr) : ; sont
‘ Polynesia ee: aT
B)) Pitcairn Islands
WK)
SOUTH OCEA
==
N
| Rapa’ .
{
{
\\
t
New
Zealand North Island
Tasmania
lobart
féllington
<= = Line of separation
{not a formal international
2 South Island boundary or territorial limit) «
1090 Kilom
Invercargill : 6 860 1000 Mites
Boundary representation is
not necessarily authoritative
503988 1-79
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7 |','023837f3bf5937ab197c602a865b920f888ef50191e8854f35af2793248baf3d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('569789fe17546e68b294410b8d13c2b36082cb8d635af3e9d2a95264249901fb',1972,'CR','Costa Rica','communications',116,'LAND ;
51,000 km?; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban, and
other
Land boundaries: 670 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; specialized competence over living resources to 200 nm)
Coastline: 1,290 km
Railroads: 563 km 1.067-meter gage, all single track, 115
km electrified
Highways: 26,050 km total; 2,000 km paved, 15,900 km
gravel 8,150 km unimproved earth
Inland waterways: about 730 km perennially navigable
46
Pipelines: refined products, 318 km
Ports: 3 major (Limon, Golfito, Puntarenas), 4 minor
Civil air: 18 major transport aircraft
Airfields: 196 total, 189 usable; 29 with permanent-
surface runways; | with runway 2,440-3,659 m; 9 with
runways 1,220-2,489 m; 2 seaplane stations
Telecommunications: good domestic telephone service;
127,000 telephones (6.2 per 100 popl.); connection into
Central American microwave net; 55 AM, 10 FM, and 12
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 514,000; 336,000 fit for
military service; average number reaching military age (18)
annually about 26,000
Supply: dependent on imports from U‘S.
Military budget: for fiscal year ending 31 December
1978, $16.2 million for Ministry of Public Security, including
the Civil Guard; about 3% of total central government
budget
j ; Atlantic
of Mexico f Ocean
THE
Havana \\ {BAHAMAS
S
CUBA :
JAMAICA eS
Caribbean Sea
{See reference map tl}
LAND
114,478 km*; 35% cultivated, 30% meadow and pasture,
20% waste, urban, or other, 15% forested
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 3,735 km
Railroads: 14,640 km total, government-owned; 5,040 km
common-carrier lines of which 4,960 km standard gage
(1.4385 m), 80 km 0.914-meter gage; about 9,600 km
plantation/industrial lines, 6,400 km standard gage (1.435
m), 3,200 km narrow gage
Highways: 20,700 km total; 8,800 km paved, 11,900 km
gravel and earth surfaced
Inland waterways: 240 km
Pipelines: natural gas, 80 km
Ports: 8 major (including U.S. Naval Base at Guantan-
amo), 44 minor; Guantanamo under U.S. control
Civil air: 87 major transport aircraft
Airfields: 193 total, 182 usable; 48 with permanent-
surface runways; 1 with runway over 3,660 m, 8 with
runways 2,440-3,659 m, 25 with runways 1,220-2,439 m; 10
seaplane stations
Telecommunications: modern facilities adequately serve
military, governmental, and some civilian needs; excellent
international facilities via HF and satellite; 380,000 tele-
phones (3.9 per 100 popl.); 100 AM, 25 FM, and 24 TV
stations; 4 submarine cables
DEFENSE FORCES
Military budget: for fiscal year ending 31 December
1978, $949 million; about 8.6% of total budget -','d23aa92c90b8da120e8bc2f3478e2de5c75663720f3dad204b1aa94ee3e1db98','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05dee75c686a35ece8bf94ff1ed2eafc52747dd8cbc794485ad96193c5325f2b',1972,'CY','Cyprus','communications',120,'LAND
9,251 km?; 47% arable and land under permanent crops,
47
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NCES
Mediterranean
{See reference map V)
18% forested, 10% meadows and pasture, 25% waste, urban
areas, and other
WATER
Limits of territorial waters (claimed): 12 nm
Railroads: none
Highways: 9,710 km total; 4,580 km bituminous surface
treated; 5,180 km gravel, crushed stone, and earth
Ports: 3 major (Famagusta, Larnaca, Limassol), 6 minor;
Famagusta under Turkish control
Civil air: 6 major transport aircraft (including 4 leased in)
Airfields: 13 total, 12 usable; 8 with permanent-surface
‘runways; 3 with runways 1,220-2,439 m; 4 with runways
2,440-3:656 m
Telecommunications: moderately good telecommunica-
tion system in both Greek and Turkish sectors; 77,000
telephones (11.2 per 100 popl.); 12 AM, 4 FM, and 7 TV
stations; tropospheric scatter circuits to Greece and Turkey;
2 submarine coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 158,000; 111,000 fit for
military service, about 7,000 reach military age (18)
annually
Military budget: for fiscal year ceeaaing 31 December
1978, $43.2 million about 18% of central government budget .
CZECHOSLOVAKIA
LAND ;
127,946 km’; 42% arable, 14% other serial 85%
forested, 9% other
Land boundaries: 3,540 km','7bf7d7bdac8fee313d9860547b913a441041aef0b7fecc650cb7d2231c9e56f6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('755aefbcd01a7859161e24c9006a95600958d707cf9af0fcb201d8f202ef3854',1972,'DK','Denmark','communications',126,'{See reference mep iV}
LAND
42,994 km? (exclusive of Greenland and Faroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17%
other
Land boundaries: 68 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm) ;
Coastline: 3,879 km
Railroads: 2,591 km standard gage (1.435 m); Danish
State Railways (DSB) operate 2,101 km (1,999. km rail line
and 102 km rail ferry services); 97 km electrified, 730 km
double tracked; 490 km of standard gage lines are
privately-owned and operated
Highways: approximately 66,482 km total; 64,551 km
concrete, bitumen, or stone block; 1,931 km gravel, crushed
stone, improved earth
Inland waterways: 417 km
Pipelines: refined products, 418 km
Ports: 16 maior, 44 minor
Civil air: 66 major transport aircraft, including 1 leased in
and 4 leased out
Airfields: 179 total, 136 usable; 23 with permanent-
surface runways; 9 with runways 2,440-3,659 m, 6 with
runways 1,220-2,489 m; 1 seaplane station
52
Telecommunications: excellent telephone, telegraph, and
broadcast services; 2.53 million telephones (48.9 per 100
popl.); 6 AM, 13 FM, and 34 TV stations; 14 submarine
coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 1,250,000; 1,096,000 fit
for military service; 39,000 reach military age (20) annually
Military budget: proposed for fiscal year ending 31
December 1979, $1,289 million; about 7% of proposed
central government budget','a13a89d72144e03ed7046d75e1c8eb8f932577e039bc61d4c292a6f4c318c1bf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7c38bfd0ca286159076b6c757715fe707f4e6dc2db1d789892dab5a5d92d94c',1972,'DJ','Djibouti','communications',130,'(formerly French Territory of the Afars
and Issas)
THIOPIA .
23,310 km?; 89% desert wasteland, 10% permanent
pasture, and less than 1% cultivated
Land boundaries: 517 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 314 km (includes offshore islands)
PEOPLE i
Population: 180,000 (official estimate for 1972)
Nationality: noun—Afar(s), Issa(s); adjective—Afar, Issa
{See reference map Vi)
Ethnic divisions: (approximate figures) 96,300 Somalis,
mostly Issas (large number of the Somalis are temporary
immigrants from Somalia, not citizens of territory), 90,500
Afars, 6,000 Arabs, 7,000 French (inclusive of French
military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely. used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at
port
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
DJIBOUTI/DOMINICA
Organized labor: some 3,000 railway workers organized
Railroads: 97 km meter gage (1.00 m)
Highways: 770 km total; 220 km paved, 550 km
improved earth
Ports: 1 major (Djibouti)
Airfields: 8 total, 8 usable; 1 with permanent-surface
runway; 1 with runway. 2,440-3,659 m, 4 with runways
1,220-2,489 m
Civil air: 1 major transport aircraft (leased in)
Telecommunications: fair system of urban facilities in
Djibouti and radiocommunication stations at outlying places;
3,600 telephones (2.0 per 100 popl.); 1 AM, no FM, and 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, about 43,000; about
25,000 fit for military service
Defense is responsibility of France','1fb1a7527851d4cdaa679eeb316a924c1ee9dd5adf390d9bd734cf958a308f84','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2653296ac0459b66cff5a58928900e4f5715a7fe3e273a0524438355f89814ee',1972,'DM','Dominica','communications',133,'Atlantic”
re
DOMINICAY
Caribbean Sea
{See reference map tt}
LAND
790 km?; 24% arable, 2% pasture, 67% forests, 7% other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 148 km
Railroads: none .
Highways: 750 km total; 500 km paved, 250 km gravel
and earth
Ports: 2 minor (Roseau, Portsmouth)
’ Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 1,472 m
Telecommunications: 3,600 telephones in fully automatic
network (4.8 per 100 popl.); VHF and UHF link to St. Lucia;
1 AM and 1 TV station
&
Fi Barbados
oGrenata
4 7
-F3Trinidad and Tobago
aes
‘Georgetown
SES','50ef27bf9fc26d5bc6fc9857e4f7eb9acfc68ff7f89f96f1d34dcc57704d50d8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e99626a2e864d470a016dfa96357ad2440ce7915edfc15e7b51de4c6fc759e8',1972,'DO','Dominican Republic','communications',137,'LAND
48,692 km?; 14% cultivated, 4% fallow, 17% meadows and
pastures, 45% forested, 20% built-on or waste
Land boundaries: 36] km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 200
nm); 200 nm exclusive economic zone
54
Atlantic
Ocean
DOMINICAN
BAe ;
a es mat]
i—)
Sn Sant
JAMAICA * Domingo
Caribbean Sea
VENEZUELA’
(See reference mep tl}
Coastline: 1,288 km
Railroads: 1,600 km total; 104 km government-owned
common-carrier 1.065-meter gage; 1,496 km_ privately
aa
owned plantation lines of 4 different gages ranging from
0.60 m to 1.43 m, 0.760-meter gage predominating
_ Highways: 11,400 km total; 5,800 km paved, 5,600 km
gravel and’ improved earth
Pipelines?’ refined products, 69 km
Ports: 5 major (Santo Domingo, Barahona, Haina, Las
Calderas, San Pedro de Macoris), 17 minor
Civil air: 18 major transport aircraft (including 1 leased
in) -
Airfields: 52 total, 45 usable; 11 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 9 with runways
1,220-2,439 m; 1 séaplane station
Telecommunications: relatively efficient domestic system
based on islandwide radio relay network; 127,000 telephones
(2.6 per 100 popl.); 135 AM, 31 FM, and 11 TV stations; 1
coaxial submarine cable; 1 Atlantic Ocean satellite station:
DEFENSE FORCES
Military manpower: males 15-49, 1,116,000; 712,000 fit
for military service; 59,000 reach military age (18) annually','7ed321d6f2724bbbd5736305ae199696bdd5927e1a8f4cb8cc9c8c4cd4645e81','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('000f47e63c96089215dce75c3483bef121ff4a6d41e14f0abcffd6c4619e28eb',1972,'EC','Ecuador','communications',141,'Galapagos
islands
‘Cy
Railroads: 1,121 km total; 966 km 1.067-meter gage, 155
km 0.750-meter gage; all single track
Highways: 22,250 km total; 3,300 km paved, 11,300 km
otherwise improved, 7,650 km unimproved earth
Inland waterways: 1,500 km
Pipelines: crude oil, 623 km; refined products, 1,358 km
Ports: 3 major (Guayaquil, Manta, Puerto Bolivar), 11
minor
Civil air: 25 major transport aircraft
Airfields: 173 total, 173 usable; 16 with permanent-
surface runways; 5 with runways 2,440-3,659 m, 22 with
runways 1],220-2,439 m; 8 seaplane stations
Telecommunications: facilities adequate only in largest
cities; 1 Atlantic Ocean satellite station; 174,000 telephones
(2.5 per 100 popl.); 250 AM, 38 FM, and 10 TV stations
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a TOS OC UTES CITT OU OT 0 OUT OF OS WF Or OU On Oy Oe UTE TN
ee a a ee Coe Cae ae Oe Cone we Ore
i i a SE Et i la i A, Re, SO ke
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
ECUADOR/EGYPT
DEFENSE FORCES
Military manpower: males 15-49, 1,743,000; 1,072,000 fit
for military service; average number reaching military age
(20) annually 84,000 a
Military budget: for fiscal year ending 3] December
1978, $169.8 million; about 17.5% of central government
budget ,
SAUDI
ARABIA
(See reference map V}
LAND
1,000,258 km? (including 57,498 km? occupied by Israel);
2.8% cultivated (of which about 70% multiple cropped);
96.5% desert, waste, or urban; 0.7% inland water
Land boundaries: 2,527 km (1967); approximately 2,580
km including border of occupied Sinai area (since September
1975)
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 2,450 km (1967); includes approximately 500
km within occupied Sinai area (since September 1975)
Railroads: 4,857 km total; 951 km double track; 25 km
electrified; 4,510 km standard gage (1.435-m), 347 km
0.750-meter gage . ;
Highways: 47,025 km total; 12,300 km paved, 2,500 km
gravel and crushed stone, 14,200 km improved earth, 18,025
km unimproved earth ;
Inland waterways: 3,360 km; Suez Canal, 160 km long,
used by ocean-going vessels drawing up to 11.5 meters of
water; Alexandria-Cairo waterway navigable by barges of
metric ton capacity; Nile and large canals by barges of
420-metric ton capacity; Ismailia Canal by barges of 200- to
300-metric ton capacity; secondary canals by sailing craft of
10- to 70-metric ton capacity
Freight carried: Suez Canal (1966)—242 million metric
tons of which 175.6 million metric tons were POL
Pipelines: crude oil, 675 km; refined products, 240 km;
natural gas, 365 km
Ports: 3 major (Alexandria, Port Said, Suez), 8 minor
Civil air: 27 major transport aircraft
Airfields: 99 total, 75 usable; 68 with permanent-surface
runways; 44 with runways 2,440-3,659 m, 1 with runway
over 3,660 m, 17 with runways 1,220-2,489 m
Telecommunications: second-largest system in Africa but
inadequate for needs and poorly maintained; principal
centers Alexandria and Cairo, secondary centers Al Man-
surah, Ismailia, and Tanta; intercity connections by coaxial
cable and microwave; extensive upgrading in progress;
500,000 telephones (1.3 per 100 popl.); 22 AM, no FM, and
29 TV stations; 1 Atlantic Ocean satellite station; Symphonie
satellite station; 2 submarine coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 9,724,000; 6,321,000 fit
for military service; about 420,000 reach military age (20)
annually','e963689ff1cdcf422df0b6a3b1acf0aaad575d19f14dc1490de4bd47f0f64597','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('024ca4d38ee1689ab2c2dfd5666caebb6b44fbe87715c78597abb497000d732d',1972,'SV','El Salvador','communications',145,'LAND
21,400 km?; 32% cropland (9% corn, 5% cotton, 7% coffee,
11% other), 26% meadows and pastures, 31% nonagricul-
tural, 11% forested
Land boundaries: 515 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 307 km
Railroads: 600 km 0.914-meter gage, single-tracked
Highways: 7,250 km total; 1,500 km paved, 1,300 km
gravel 4,400 km improved and unimproved earth
Inland waterways: Lempa River partially navigable
Ports: 2 major (Acajutla, La Union), 1 minor
Civil air: 8 major transport aircraft
Airfields: 160 total, 150 usable; 5 with permanent-
surfaced runways; 1 with runway 2,440-3,659 m; 9 with
runways 1,220-2,439 m; 1 seaplane station
Telecommunications: nationwide trunk radio relay sys-
tem; connection into Central American microwave net;
54,200 telephones (1.3 per 100 popl.); 60 AM, 9 FM, and 5
TV stations; 1 Atlantic Ocean COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 945,000; 580,000 fit for
military service; 51,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1978, $42.2 million; 8.4% of central government budget','e7282182ae9faa136a5f50859f2dc1114a37fad945ca6d82588a037247e5f0d3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd4c4f3fbe1f02b0262c8feacffc17b2b139adad705f3f9a34ad0c5f04953b31',1972,'ET','Ethiopia','communications',152,'LAND
1,178,450 km?; 10% cropland and orchards, 55% meadows
and natural pastures, 6% forests and woodlands, 29%
wasteland, built-on areas, and other
Land boundaries: 5,198 km
WATER
Limits of territorial waters (claimed): 12 nm; sedentary
fisheries extends to limit of fisheries
Coastline: 1,094 km (includes offshore islands)','daf6a9c6af00c1cc8e2a984728f4356092a3afb76a4f876a706dd795d9b054a6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('263df7e2cd153501a4cbc1973297e19819fc889326e6e5e0da2426d9e79bbbce',1972,'DE','Germany','communications',157,'Railroads: 1,014 km total; 676 km meter gage (1.00 m), 32
61
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ETHIOPIA/FALKLAND ISLANDS
km 1.067-meter gage, 306 km 0.95-meter gage; all single
track
Highways: 11,435 km total; 3,770 km bituminous, 7,665
km crushed stone, gravel, or stabilized earth, remainder
earth
Inland waterways: navigation possible on Lake Tana and
on.approx. 225 km of unconnected and basically unim-
proved waterways, of which only 114 km are navigable year
round
Ports: 2 major (Assab, Massawa)
Civil airy 19 major transport aircraft
Airfields: 192 total, 178 usable; 7 with permanent-surface
runways; 1 with runway over 3,660 m, 6 with runways
2,440-3,659 m, 48 with runways 1,220-2,439 m
Telecommunications: system composed of open-wire
lines, radiocommunication stations, and small number of
multiconductor cable and radio-relay links; principal center
Addis Ababa, secondary center Asmara; 73,000 telephones
(0.3 per 100 popl.); 4 AM stations, no FM stations, and 1 TV
station
DEFENSE FORCES :
Military manpower: males 15-49, 6,965,000; 3,734,000 fit
for military service; average number reaching military age
(18) annually 324,000
Military budget: for fiscal year ending 6 July 1977,
$104,445,000; 14.7% of central government budget
FALKLAND ISLANDS
(Islas Malvinas) !
Railroads: 947 km, 0.914-meter gage, single-tracked; 832
km government-owned, 115 km privately owned
Highways: 25,500 km total; 2,750 km paved, 11,350 km
gravel, and 11,400 km earth
Inland waterways: 260 km navigable year-round; addi-
tional 730 km navigable during high-water season
Pipelines: crude oil, 48 km
Ports: 2 major:(Puerto Barrios, Santo Tomas de Castilla), 3
minor
84
Airfields: 470 total, 469 usable; 7 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 17 with runways
1,220-2,489 m
Civil air: 8 major transport aircraft
Telecommunications: modern telecom facilities limited
to Guatemala City; 58,500 telephones (0.9 per 100 popl.); 97
AM, 20 FM, and 5 TV stations; connection into Central
American microwave’ net
DEFENSE FORCES
Military manpower: males 15-49, 1,529,000; 998,000 fit
for military service; about 69,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1978, $58.5 million; 6.2% of central government
budget
Railroads: 2,089 km total; 503 km standard gage (1.435
m), 1,586 km meter gage (1.000 m)
Highways: 17,140 km total; 7,940 km bituminous, 660 km
gravel; 2,000 km improved earth; 6,540 km unimproved
earth :
Pipelines: 797 km crude oil; 10 km refined products; 72
km natural gas
Ports: 4 major, 8 minor
Civil air: 16 major transport aircraft (including 1 leased
in)
Airfields: 27 total, 23 usable; 11 with permanent-surface
runways; 3 with runways 2,440-3,659 m; 11 with runways
1,220-2,4389 m; 1 seaplane station
Telecommunications: the system is above the African
average in amount and capacity of facilities which consist of:
open-wire lines with multicanductor cable or radio relay;
209
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TUNISIA/TURKEY
key centers are Safaqis, Susah, Bizerte, and Tunis; 100,000
telephones (1.7 per 100 popl.); 3 AM, 3 FM, and 7 TV
stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,273,000; 713,000 fit
for military service; about 75,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1978, $153 million; 6% of central government budget
TURKEY
» Ankara
TURKEY
(See reference map V}
LAND
766,640 km?*; 85% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm) .
Coastline: 7,200 km
Railroads: 8,253 km standard gage (1.435 m); 143 km
double track; 72 km electrified
Highways: 60,000 km total; 21,000 km_ bituminous;
28,000 km gravel or crushed stone; 2,500 km improved
earth; 8,500 km. unimproved earth
Inland waterways: approx. 1,689 km
Pipelines: 1,288 km crude oil; 2,055 km refined products
Ports: 10 major, 35 minor
Civil air: 24 major transport aircraft
Airfields: 120 total, 101 usable; 58 with permanent-sur-
face. runways; 3 with runways over 3,660 m, 23 with
runways 2,440-3,659 m, 22 with runways 1,220-2,439 m
Telecommunications: new trunk domestic radio-relay
net, good international service; 1.1 million: telephones (2.7
per 100 popl.); 40 AM, 4 FM, and 86 TV stations; 1 coaxial
submarine cable; COMSAT station near completion.
DEFENSE FORCES
Military manpower: males 15-49, 9,786,000; 5,778,000 fit
for military service; about .430,000 reach military age (20)
annually
Military budget: for fiscal year ending 28 February 1979,
$2.3 billion; about 20.7% of proposed central government
budget
°','967ede6d91f6c6d627d4f3b8bf43006e8ce271edf892a1105350cd2644a82ec2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be99ecaaf447c031f2a34d7fbfa1a1d56c31a1466eac356913afd0acfd7580e9',1972,'FO','Faroe Islands','communications',158,'; Norwegian
Ss
FAROE ¢
ISLANDS
Atlantic
Ocean
{See reference map iV}
LAND
1,340 km?; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited islands and
a few uninhabited islets
WATER
Limits of territorial waters (claimed): 12 nm; fishing
200 nm
Coastline: 764 km
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less than
1,220 m
Civil air; no major transport aircraft
Telecommunications: good international communica-
tions; fair domestic facilities, 15,000 telephones (35 per 100
popl.); 1 AM, and 3 FM stations; 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49 included with Denmark','6444b59eb5bd56192190493d684eb58b9f3585cdb8049d9308596793b47d7f78','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46c65fc9d428386024836ee3bc1c4630764500ebcb26f5f2f6520ec8b5a3d654',1972,'FI','Finland','communications',162,'Norwegian
{See reference map IV}
LAND
336,700 km?*; 8% arable, 58% forested, 34% other
Land boundaries: 2,534 km
WATER
Limits of territorial waters (claimed): 4 nm; fishing 12
nm; Aaland Islands, 3 nm
Coastline: 1,126 km (approx.) excludes islands and coastal
indentations
Railroads: 6,038 km total; Finnish State Railways (VR)
operate a total 6,010 km 1.524-meter gage, 477 km multiple
66
track, and 608 km electrified; 22 km 0.750-meter gage and 6
km 1.524-meter gage are privately owned
Highways: about 73,552 km total in national classified net
work, including 31,000 km paved (bituminous, concrete,
bituminous surface treated) and 42,552 km unpaved
(stabilized gravel, gravel, earth); additional 29,440 km of
private (state subsidized) roads
Inland waterways: 6,597 km total (including Saimaa
Canal); 3,700 km suitable for steamers; Saimaa Canal locks
(84 m by 13.2 m with a 5.2 m depth over sill) can
accommodate vessels of up to 82 m in length, 11.8 m beam,
4.4 m draft, and 24.5 m mast height
Pipelines: natural gas, 161 km
Ports: 11 major, 14 minor
Civil air: 41 major transport aircraft
Airfields: 134 total, 132 usable; 86 with permanent-
surface runways; 17 with runways 2,440-3,659 m, 24 with
runways 1,220-2.439 m
Telecommunications: good telecom service from cable
and radio-relay network; 1.94 million telephones (40.9 per
100 popl.); 15 AM, 40 FM, and 76 TV stations; 4 submarine
cables, including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 1,259,000; 1,022,000 fit
for military service; 39,000 reach military age (17) annually |
Military budget: proposed for fiscal year ending 31
December 1979, $520 million; about 4.8% of central
government budget','abf59cca0177da8712ad94b517aa2bf3458604df262f376d67f10e355b1d33a1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32c59c2f074356bc98afcfc3528028fea6e7854795ffac6490ce490ba4314a7e',1972,'FR','France','communications',166,'(See reference map {V)
LAND.
551,670 km*; 35% cultivated, 26% meadows and pastures,
14% waste, urban, or other, 25% forested
Land boundaries: 2,888 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
tts
TA
er on
AAT A A
stg Semen
a a ia
cai a A i Sar
ne i i ee, el ee le i el lk el a cle al I, ee el
?
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 3,427 km (includes Corsica, 644 km)
Railroads: 36,691 km total; French National Railways
(SNCF) operates 34,717 km standard gage (1.435 m); 9,374
km electrified, 15,630 km double or multiple track; 1,974
km of various gages (1,000 m to 1,445 m), privately owned
and operated
Highways: 788,580 km total; 128,745 km bitumen and
concrete (incl. 3,144 km of controlled access, divided
“AUTOROUTES”); 339,315 km_ bituminous _ treated;
301,000 km crushed stone and gravel; 19,520 km improved
‘earth; in addition, there are approximately 700,065 km of
local farm and forest roads
Inland waterways: 14,912 km; 5,604 km heavily traveled
Pipelines: crude oil. 2,253 km; refined products, 4,344
km; natural gas, 22,047 km ; :
Ports: 23 major, 165 minor
Civil air: 300 major transport aircraft
Airfields: 456 total, 437 usable; 223 with permanent-
surface runways; 2 with runways over 3,660 m, 31 with
runways 2,440-3,659 m, 122 with runways 1,220-2,439 m; 2
seaplane stations
Telecommunications: highly developed system provides
satisfactory telephone, telegraph, and radio and TV broad-
cast services; 15.5 million telephones (29.3 per 100 popl.); 55
AM, 94 FM, and 1,500 TV stations; 22 submarine cables; 2
communication satellite ground stations with 4 Atlantic
Ocean, and 2 Indian Ocean antennas
DEFENSE FORCES ‘
Military manpower: males 15-49, 18,246,000; fit for
military service 10,695,000; 425,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1979, $17.6 billion; about 18% of proposed
central government budget
68
(See reference map 1V)
Railroads: 2,009 km 1.600-meter gage; 1,894 km govern-
ment-owned; 115 km privately-owned |
Highways: 88,302 km total; 78,616 km surfaced, 9,686
km earth
Inland ‘waterways: approximately 1,000 km
Ports: 6 major, 38- minor
Civil air: 28 major transport aircraft (including 1 leased
and 5 leased out) |
Airfields: 38 total, 838 usable; 8 with permanent-surface
runways; ) with-runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: small, modern system; all cities
interconnected for telephone and telegraph service; 480,000
telephones (15.1 per 100 popl.); 6 AM, 7 FM, and 28 TV
stations; 4 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 733,000; 573,000 fit for
military service; about 31,000 reach military age (17)
annually
Military budget: for fiscal year ending 31 December
1978, $182.1 million; about 4.2% of the central government
budget
{See reference map tV}
we tne
LAND
2,590 km?; 25% arable, 27% meadows and pasture, 15%
waste or urban, 33% forested, negligible amount of inland
water
Land boundaries: 356 km
RHODESIA
LAND
391,090 km*; 40% arable (of which 6% cultivated); 60%
172','ac0e310b05efe5913d73cf126ed3b1e695a9d0da1b23994e66759a22c750fe96','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b793103c0127da42a0fdfa305d00d80265ee8cb2f30416d9585aad065d127456',1972,'GY','Guyana','communications',170,'(See reference map til}
LAND
90,909 km?; 90% forested, 10% wasteland, built-on, inland
water and other, of which .05% is cultivated and pasture
‘Land boundaries: 1,183 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 378 km
Railroads: 32 km private plantation line, 0.600-meter
gage
Highways: 600 km total; 450° km paved, 150 km
improved and unimproved earth
Inland waterways: 460 km, navigable by small ocean-
going vessels and river and coastal steamers; 3,300 km
possibly navigable by native craft
Ports: 1 major (Cayenne), 7 minor
Civil air: no major transport aircraft
Airfields: 13 total, 10 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m
Telecommunications: limited open-wire and radio-relay
system with about 8,906 telephones (17.8 per 100 popl.); 9
AM, 2 FM, and 2 TV stations; 1 Atlantic Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 14,000; 10,000 fit for
military service
Caribbean Atlantic
a
ea Ocean
(See reference map tit)
LAND
214,970 km?; 1% cropland, 3% pasture, 8% savanna, 66%
forested, 22% water, urban, and waste
Land boundaries: 2,575 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Coastline: 459 km
Railroads: 109 km total, all single track; 80 km 0.914-
meter gage, 29 km 1.067-meter gage
Highways: 5,700 km total; 550 km paved, 1,850 km
gravel, and 3,300 km earth
Inland waterways: 5,900 km; Demerara River navigable
to Mackenzie by ocean steamers, others by ferryboats, small
craft only
Ports: 1 major (Georgetown), 3 minor
Civil air: 6 major transport aircraft (including 1 leased in)
Airfields: 95 total, 88 usable; 4 with permanent-surface
runways; 12 with runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: highly developed telecom system
with radio-relay network and over 22,500 telephones (2.6
per 100 popl.); tropospheric scatter link to Trinidad; 5 AM, 1
FM and no TV stations; 1 COMSAT station
“DEFENSE FORCES
Military manpower: males 15-49, 189,000; 144,000 fit for
military service
87
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
Suriname’.
Manaus,
Bolivia
*Sucre
\\ Paraguay
; cordoba
f .
(Uruguay ¢
‘Buenos Aires : 2
Montevideo','93467dcfc00084d531ceae652f85f500e81f77ad3423679b98b8154b8967f3bf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9d63e9eb20279cdb5349d532712c6401a1e4f4d1ee450a7505274ab4460a0ce',1972,'PF','French Polynesia','communications',174,'Pacific Ocean
CHRISTMAS IS.
=, PRENCH
POLYNESIA
_ COOK Is.”
{See reference map Vill)
LAND
About 4,000 km?
WATER
Limits of territorial waters: 12 nm
Coastline: about 2,525 km
Highways: 3,700 km, all types
Ports: 1 major, 6 minor
Airfields: 32 total, 32 usable; 12 with permanent-surface
runways, 2 with runways 2,440-3,659 m, 14 with runways
1,220-2,439 m; 2 seaplane stations
Civil air: about 3 major transport aircraft
Telecommunications: 14,700 telephones (11.3 per 100
popl.); 72,000 radio and 14,000 TV sets; 5 AM, 2 FM, and 6
TV stations; 1 ground satellite station
DEFENSE FORCES
Defense is responsibility of France.','cd56ab4647d15dd1fa3aab190e957e0abf443ccacddf5d59383a9a90980635e7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5c3ca335867c933b719531043ed1812e58275feddbd6d7a6c1c70eeb939bd56',1972,'GN','Guinea','communications',178,'{See reference map Vi}
LAND
238,280 km?; 19% agricultural, 60% forest and brush, 21%
other
Land boundaries: 2,285 km
WATER
‘Coastline: 539 km a
Limits of territorial waters (claimed): 200 nm
Railroads: 953 km, all 1.067-meter gage; 32 km double
track; diesel locomotives gradually replacing steam engines
Highways: 32,200 km total; 4,524 km concrete or
bituminous surface, 27,676 km gravel or laterite, 9,242 km
unimproved earth
Inland waterways: Volta, Ankobra, and Tano rivers
provide 235 km of perennial. navigation for launches and
lighters; additional routes navigable seasonally by small
craft; Lake Volta reservoir provides 1,125 km of arterial and
feeder waterways
Pipelines: refined products, 3 km
Ports: 2 major (Tema, Takoradi), 1 naval base (Sekondi), 4
minor :
Civil air: 12 major transport aircraft
Airfields: 19 total, 18 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 9 with runways
1,220-2,489 m
Telecommunications: fair system of open-wire and cable,
radio-relay links and radiocommunication stations; 66,000
telephones (0.7 per 100 popl.); 6 AM, no FM, and 8 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 2,351,000; 1,309,000 fit
for military service; 130,000 reach military age (18) annually
Cs
IVORY
LIBERIA, COAST
Atlantic Ocean
(See reference map Vi}
LAND
246,050 km?; 3% cropland, 10% forest
Land: boundaries: 3,476 km
WATER
Limits of territorial waters (claimed): 130 nm
Coastline: 346 km
Railroads: 805 km meter gage (1.00 m), 8 km standard
gage
Highways: 7,604 km total; 4,949 km paved, remainder
unimproved earth
Inland waterways: 1,795 km; 500 km navigable by small
oceangoing vessels, 1,295 km navigable by shallow-draft
steamers and barges
Ports: 1 major (Conakry), 3 minor
Civil air: 10 major transport aircraft
Airfields: 17 total, 16 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 9 with runways
1,220-2,489 m; 3 seaplane landing areas
Telecommunications: inadequate system of -openwire
lines, small radiocommunication stations, and 1 radio-relay
link; principal center Conakry, secondary center Kankan;
8,300 telephones (0.2 per 100 popl.); 1 AM station, no FM,
and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,328,000; 667,000 fit
for military service
Military budget: for fiscal year ending 30 September
1970 (latest information available), $6,073,000; 8.0% of
central government budget
BISSAU
Atlantic
‘Ocean
(See reference map VI}
LAND :
196,840 km*, 13% forested, 40% agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 2,680 km
WATER
Limits of territorial waters (claimed): 150 nm (fishing
200 nm); 200 nm exclusive economic zone
Coastline: 531 km
Railroads: 1,033 km meter gage (1.00 m); 64 km double
track
Highways: 13,589 km total; 2,547 km paved, 11,042 km
other
Inland waterways: 1,505 km
Ports: 1 major (Dakar), 2 minor
Civil air: 4 major transport aircraft
Airfields: 27 total, 27 usable; 11 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 19 with runways
1,220-2,489 m; 3 seaplane stations
Telecommunications: above average urban system;
39,000 telephones (0.7 per 100 popl.); 3 AM stations, no FM
station, and 1 TV station; 2 submarine cables; 1 Atlantic
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,206,000; 624,000 fit
for military service; 49,000 reach military age (18) annually
Military budget: for fiscal year ending 30 June 1979,
$62,062,000; about 7.9% of central government budget','5bedfb50e8421958487985ce2fe9b9c62e32c1dcb4c35561fe23cb7cfb635844','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('619193042d217f4d10328886352a986625982a6b3ab77ffff46621cc079ff9c2',1972,'GI','Gibraltar','communications',182,'LAND
6.5 km?
Land boundaries: 1.6 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 12 km','95316d0c6f4c61ad7bc7c5f1b2bced964f663e6134e121ed5c2b452b8e968fe3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f026644e5eed29f651cbdee76298692ed09882eac39505dc319f21a44f3551b',1972,'GR','Greece','communications',184,'ek,
:
4 An
{See reference map iV)
LAND
132,608 km?; 29% arable and land under permanent
crops, 40% meadows and pastures, 20% forested, 11%
wasteland, urban, other :
Land boundaries: 1,191 km
WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 13,676 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Railroads: 2,476 km total; 1,565 km standard gage (1.435
m) of which 36 km electrified and 100 km double track, 889
km meter gage (1.000 m), 22 km narrow gage (0.750 m); all
government-owned
Highways: 38,938 km total; 16,090 km paved, 13,676 km
crushed stone and gravel, 5,632 km improved earth, 3,540
km unimproved earth
Inland waterways: system consists of 3 coastal canals and
83 unconnected rivers which provide navigable Jength of just .
less than 80 km
79
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GREECE/GREENLAND
Pipelines: crude oil, 26 km, refined products, 547 km
Ports: 17 major, 37 minor
Airfields: 70 total, 66 usable; 48 with permanent-surface
runways; 17 with runways 2,440-3,659 m, 22 with runways
1,220-2,439 m
Civil air: 833 major transport aircraft (including 1 leased
in)
Telecommunications: adequate modern networks reach
all areas on mainland and islands; 2.18 million telephones
(23.1 per 100 popl.); 31 AM, 30 FM, and 34 TV stations; 5
coaxial submarine cables; 1 satellite station with 1 Atlantic
Ocean antenna and 1 Indian Ocean antenna
DEFENSE FORCES
Military manpower: males 15-49, 2,156,000; 1,648,000 fit
for military service; about 76,000 reach military age (21)
annually
Military budget: for fiscal year ending 31 December
1978, $1,610 million; about 20% of central government
budget','87cb4a79ca3cb3504b47827adc234f7f025706abc669ca81b7eaad45e33b5e6d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecf5535b417f392bc9580a99b03701c5d0035207d6ab129b9403288e2a67eb54',1972,'GL','Greenland','communications',188,'Norwegian
Sea
oe
Godthaab
Atlantic Ocean
(See reference map I}
LAND
2,175,600 km?; less than 1% arable (of which only a
fraction cultivated), 84% permanent ice and snow, 15%
other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 44,087 km (approx., includes minor islands)
Railroads: none
Highways: 80 km
Ports: 7 major, 16, minor
Civil air: 2 major transport aircraft (registered in
Denmark)
Airfields: 11 total, 6 usable; 3 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 2 with runways
},220-2,489 m; 7 seaplane’ stations
Telecommunications: adequate domestic and _ interna-
tional service provided by cables and radio relay; 9,000
telephones (17.0 per 100 popl.); 5 AM, 6 FM, and 2 TV
stations; 2 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, included with Den-
mark
_ (Denmark)
Thule
United
Baffin Bay
States
Fairbanks «
Yukon
Godthaab
Territory \\ Bear Lake
, Whitehorse ; Sy
~~’ f
Yellowknife
Great
SS Slave Lake
~~
i
‘a . Prince Rupert / Pe ae
Pacific ( _ British 7 1
Ocean Columbia / |
Alberta ; * Churchill \\
\\ Santee / ¢ / 4 n Schettevillea~~,
‘ { Manitoba . i - Be a
Saskatchewan f 3 L
/ AA
: Quebec
<—.-
wi Saskatoon ! Fa
Prince
Edward
‘Ne ydney
; . ;__Lake {
pean beanies da Ontario
“Wi Tr 1
innipeg” | stn
. P8 a: lottetown
\\ Quebec f :
Halifax
x iMentreal''s Ni lage i
Otawek,
¢y} take
% 9 aa > Ontario
Boston®
New York a
Vancouver \\
\\ ecalga
3
=y
\\%,
l. Michigan
Milwaukee ie
o! or
Ne
Na Salt Lake City
Chicago
Atlantic Ocean
« Denver
Washington + {
Kansas City * ae
e Lous
States
» Los Angeles
United
Oklahoma City *
§03981 1-79
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
®
«Los Angeles
503982 1-79
N
EEE REeemeesemeenmmemmemeioees setae ced
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
(@enmark) 400 Kilometers.
400 Miles
dan Mayen
sat wor}
Murmansk
Norwegian
Reykjavik : ; a Atkangel''sk
Iceland Sea ; aol
Faroe Is.
(Den.)
sa Norway
r) 2 7 Leningrad
Bergen, Oslo a
¢ x Stockholm
“f “7 ce
Goteborg Baltic in KMescoM
Edinburgh North
Atlantic
U.S.S.R.
{
Federal ral Dem. Rep. \\
Bonn IN
Avex Republic','62f9abec346fd0e3f2bf5d6d91c2666a22c08924732f31f95320807f5a65d9a5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f9e9158be742924f4d86cb83358715fa2ed94cd8f7819af6dad22a616732785',1972,'GD','Grenada','communications',192,'PUERTO i
si te
e
°
: %
Carhbean 4
2
~>sFRENCH
GUIANA
(See reference map tt}
LAND
344 km? (Grenada and southern Grenadines); 44%
cultivated,. 4% pastures, 12% forests, 17% unused but
potentially productive, 23% built on, wasteland, other
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 121] km
Railroads: none
Highways: 1,000 km total; 600 km paved, 300 km
otherwise improved; 100 km unimproved
Ports: 1 major (St. Georges), 1 minor
Civil air: no major transport aircraft
Airfields: 3 total, 2 usable; 2 with permanent-surface -
runways, 1 with runway 1,220-2,439 m
Telecommunications: automatic, islandwide telephone
system with 5,100 telephones (4.5 per 100 popl.); VHF and
UHF links to Trinidad and Carriacou; 3 AM stations','3bdcdf7a51990d2745bf64d0cf6878846b3ed45af1a18ec5a703480c39b96c30','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27088e41b06aaad4ec4ce92c762d62900765f87ca5a762e827094cbaa5e661f9',1972,'GP','Guadeloupe','communications',196,'“DOMINICAN
REPUBLIC
PUERTO
C> kico
°
°
Caribbean Sea
(See reference mep tl}
. LAND
1,779 km?; 24% cropland, 9% pasture, 4% potential
cropland, 16% forest, 47% wasteland, built on;-area consists
of two islands”
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 306 km
Railroads: privately owned, narrow-gage plantation lines
Highways: 3,500 km total: 2,200 km paved, 1,300 km
gravel and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 8 major transport aircraft (leased in)
Airfields: 8 total, 8 usable, 8 with permanent-surface
runways; 1 with runway 2,440-3,659 m; 2 seaplane stations
Telecommunications: domestic facilities inadequate;
26,800 telephones (7.9 per 100 popl.); interisland VHF radio
‘links; 2 AM and 3 TV transmitters
DEFENSE FORCES
Military manpower: males 15-49, included with France','31f1ba773fc87a4a7e9aec3cf19c48ce8fe156f43cf3cd2092234ea0677f72e7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d12e1f058f1d0fa81f4aa953db3aed6f4e77b637c54abd40fc38328aac7b09b9',1972,'GW','Guinea-Bissau','communications',203,'(formerly Portuguese Guinea)
LAND
36,260 km? (includes Bijagos archipelago)
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 150 nm (fishing
200 nm)
Coastline: 274 km
Railroads: none
Highways: approx. 3,218 km (418 km_ bituminous,
remainder earth)
Inland waterways: 1,600 km
Ports: 1 major (Bissau), 2 minor
Civil air: 3 major transport aircraft
Airfields: 60 total, 59 usable; 4 with permanent-surface
runways; 8 with runways 1,220-2,439 m; 1] seaplane station
Telecommunications: limited system of open-wire lines
and radiocommunication stations; 2,700 telephones (0.5 per
100 popl.); 1 AM, 1 FM and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 125,000; 69,000 fit for
military service','99461523a07a911288080b20bdf83d6d88a103ac78d6a4f9a4b425d07b99fb0a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('beab4fbf739ad23fe8792b3961f4eb5dce08b9519bdae7cc252ac58953c98886',1972,'PH','Philippines','communications',211,'Railroads: 35 km standard gage (1.435 m); governnient
owned
Highways: 966 km total; 660 km paved, 306 km gravel
and crushed stone, or earth
Ports: 1 major
Civil air: 17 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m; 1 seaplane station
Telecommunications: modern facilities provide domestic
and international services; excellent broadcast coverage
provided by wired and radio broadcast stations; closed-cir-
cuit TV and TV broadcast facilities; 1.1 million telephones;
2.5 million radio receivers; 100,000 wired-speakers; 2 FM, 2
AM stations; wired-broadcast network; 859,000 TV receiv-
ers, 2 TV stations, 2 closed-circuit TV networks; radio relay
link to Taiwan; 2 international communications satellite -
ground stations; coaxial cable link to Canton; 5 submarine
cables; submarine cable to Japan and Philippines completed
DEFENSE FORCES
Military manpower: males 15-49, 1,244,000; 974,000 fit
for military service; about 55,000 reach military age (18)
annually
Defense, is the responsibility of U.K.
(See reference map Vil}
Highways: 42 km paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
Telecommunications: fairly modern communication fa-
cilities provide adequate services for domestic and interna-
tional requirements; broadcasting coverage is provided by
AM and FM radio facilities and a wired broadcast network;
11,765 telephones; 75,000 radio receivers; 2 AM, 2 FM and
no TV stations; no submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 35,000 fit for
military service ,
Defense is responsibility of Portugal
Personnel: there are no Portuguese military personnel in
Philippine Sea
(See reference map Vil}
LAND
300,440 km?, 53% forested, 30% arable land, 5%
permanent pasture, 12% other
WATER
Limits of territorial waters (claimed): 0-300 nm (under
an archipelago theory, waters within straight lines joining
appropriate points of outermost islands are considered
internal waters; waters between these baselines and the
limits described in the Treaty of Paris, December 10, 1898,
the U.S.-Spain Treaty of November 7, 1900, and the
U.S.-U.K. Treaty of January 2, 1930 are considered to be the
territorial - sea)
Coastline: about 22,540 km
Railroads: 3,510 km total (1977); 2 common-carrier
systems 1.067-meter gage totaling about 1,177 km; 19
industrial systems with 4 different gages totaling 2,333 km;
34% government owned
Highways: 119,218 km total (1977); 20,483 km paved:
51,643 km gravel, crushed stone, or stabilized soil surface;
47,092 km unimproved earth
Inland waterways: 3,219 km; limited to shallow-draft
(less than 1.5 m) vessels
Pipelines: refined products, 251 km
Ports: 11 major, numerous minor
Civil air: approximately 70 major transport aircraft
Airfields: 332 total, 304 usable; 58 with permanent-
surface runways; 7 with runways 2,440-3,659 m, 36 with
runways 1,220-2,489 m
DEFENSE FORCES
Military manpower: males 15-49, 10,393,000; 7,417,000
fit for military service; about 460,000 reach military age (20)
annually
Supply: limited small arms and small arms ammunition,
smal] patrol craft, and helicopter production; other materiel
obtained almost exclusively from U.S.; naval ships and
equipment from Australia, Japan, Singapore, U.S., and Italy;
aircraft and helicopters from West Germany and USS.
Military budget: for fiscal year ending 31 December
1979, $753.4 million; about 16% of central government
budget','8a6ba5029c8e605e9445bbb9990b0efa8e6ed17e43250691ac60bc7aee766ef8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3f543e83cde25c984654168bd6e9c07bbb42fb86063e29b3ce322d0164cf076',1972,'HU','Hungary','communications',212,'LAND
92,981 km?*; 60% arable, 14% other agricultural, 16%
forested, 10% other
Land boundaries: 2,245 km
Railroads: 8,669 km total; 7,750 km standard gage
(1.485 m), 405 km narrow gage (mostly 0.760 m), 35 km
broad gage (1.524 m), 1,162 km double track, 1,303 km
electrified; government owned (1977)
Highways: 99,595 km total; 32,583 km concrete, asphalt,
stone block; 10,408 km asphalt treated, gravel, crushed stone;
56,604 km earth (1977)
Inland waterways: 1,688 km (1977)
Pipelines: crude oil, 1,287 km; refined products, 500 km;
natural gas, 2,896 km
Freight carried: rail—134.8 million metric tons, 24.1
billion metric ton/km (1977); highway—563.5 million
metric tons, 10.4 billion metric ton/km (1977); waterway—
est. 14.2 million metric tons, 8.3 billion metric ton/km (incl.
int''l. transit traffic) in approximately 545 waterway craft
with 310,000 metric ton capacity
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
A al
KAA aA 28 AAA
~A ak A ee AA AAA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
HUNGARY/ICELAND
River ports: 2 principal (Budapest, Dunaujvaros); no
maritime ports; outlets are Rostock, GDR; and Gdansk,
Gdynia, and Szczecin in Poland; and Galati and Brails in','1cef61e173cf0cb55a87376fe0c5bc23475bf3e463f852188c0b10c79439f810','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('696f37b2d1b5bdc0c946ea793e0e650a5e39c874d0ce662ea50bfbdfcc369a6a',1972,'IS','Iceland','communications',216,'Jan Mayen
* Istand
Greenland :
Sea Norwegian
vit ICELAND Sea
Reykjavik
Atlantic
Ocean
{See reterence map 1V)
LAND
102,952 km?; arable negligible, 22% meadows and
pastures, forested negligible, 78% other
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm)
Coastline: 4,988 km
Railroads: none
Highways: 12,343 km total; 166 km bitumen and
concrete; 1,284 km bituminous treated and gravel; 10,893
km earth
Ports: 4 major (Akureyri, Hafnarfjordhur, Reykjavik,
Seydhisfjordhur), and about 50 minor
‘Civil air: 22 maior transport aircraft (including 4 leased in
and 1 leased out)
Airfields: 125 total, 101 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 10 with runways
1,220-2,4389 m; 1 seaplane station
Telecommunications: adequate domestic service, wire
and radio communication system; 93,700 telephones (42.4
per 100 popl.); 17 AM, 14 FM, and 80 TV stations; 2 coaxial
submarine cables; Comsat station under construction
DEFENSE FORCES
Military manpower: males 15-49, 58,000; 52,000 fit for
military service (Iceland has no conscription or compulsory
military service)','8160e51a457cf630c1efafb8e170033cd0a9cbcc1e125293b8be991a2b3ba7da','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08f68c49f5720f606d4698513b931c9126c0d6188dffd2a85792d840c6e8028c',1972,'IN','India','communications',220,'LAND
3,136,500 km? (includes Indian part of Jammu-Kashmir,
Sikkim, Goa, Damao and Diu); 50% arable, 5% permanent
meadows and pastures, 20% desert, waste, or urban, 22%
forested, 3% inland water
Land boundaries: 12,700 km?
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; additional 100 nm is fisheries conservation zone,
December 1968; archipelago concept. baselines); 200 nm
exclusive economic zone
Coastline: 7,000 km (includes offshore islands)
94
Arabian
Sea
{LANKA
Indian Ocean
(See reference map Vil)
Railroads: 61,313 km total (1977); 25,550 km meter gage
(1.00 m), 30,041 km broad gage (1.676 m), 4,476 km narrow *
gage (0.762 m and 0.610 m), government owned; 46 km
meter gage (1.00 m), 855 km broad gage (1.676 m), 345 km
narrow gage (0.762 m and 0.610 m), privately owned; 12,304
km double track; 4,191 km electrified
Highways: 1,327,450 km total; 415,250 km _ paved,
190,600 km gravel or crushed stone, 304,900 km improved _
earth, 416,700 km unimproved earth
Inland waterways: 14,300 km; 2,575 km navigable by
river steamers
Pipelines: crude oil, 1,767 km; refined products, 2,020
km; natural gas, 574 km
Ports: 9 major, 80 minor
Civil air: 93 major transport aircraft
Airfields: 355 total, 339 usable; 190 with permanent-
surface runways; 2 with runways over 3,660 m, 54 with
runways 2,440-3,659 m, 121 with runways 1,220-2,439 m
Telecommunications: fair domestic telephone service
where available, good internal microwave links; telegraph
facilities widespread; AM broadcast adequate; international
radio communications adequate; 2.1 million telephones (0.3
per 100 popl.); about 163 AM stations at 80 locations, 9 TV
stations, 4 earth satellite stations; submarine cables extend to
Sri Lanka. :
DEFENSE FORCES
Military manpower: males 15-49, 159,165,000;
93,891,000 fit for military service; about 7,566,000 reach
military age (17) annually ;
Military budget: for fiscal year ending 31 March 1979,
$3.6 billion; 16.6% of central government budget','06e5a4cddf8396185011d8a5a8bedc60bff9d9128d69486447f16fd963a2d3f8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a67005e2a1621a7f7387082ed22195db970380f785db8c69f7b303a237cdf65',1972,'ID','Indonesia','communications',224,'LAND ‘
1,906,240 km?; 12% small holdings and estates, 64%
forests, 24% inland water, waste, urban, and other
Land boundaries: 2,736 km
95
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
“OTe INDONESIA _
eS
Indian Ocean','494747c1b8d5e429d3f6c21d198b3a60c60ff60ca08c3816a5fcbebe5b741229','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c36f383d725b6bc2d7c85c0cb61f4656443862eca2e4d9ab63207b47165c30fe',1972,'IE','Ireland','communications',225,'LAND
68,894 km’; 17% arable, 51% meadows and pastures, 3%
forested, 2% inland water, 27% waste and urban
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 1,448 km
99
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
. January 1979
Atlantic
IRELAND?','b4939a30b67ec24b25304001054490af555b633fc35cecfa174700a195904958','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7159f4c7d63e6376618c0d982aec3f28e844cef36cc0cc950e36e3b44a0ca3a',1972,'IL','Israel','communications',226,'a
Mediterranean
Sea
ARABIA
{See reference map V)
NOTE: The Arab territories occupied since the 1967 war
are not included in the data below unless so indicated.
LAND
20,720 km? (excluding about 64,750 km? of occupied
territory in Jordan, Egypt, and Syria); 20% cultivated, 40%
pastureland and meadows, 4% forested, 4% desert, waste, or
urban, 3% inland water, 29% unsurveyed (mostly desert)
Land boundaries: 1,036 km (prior to 1967 war); including
occupied areas, approximately 1,050 km (1977)
WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 273 km (prior to 1967 war); including occupied
areas, approximately 848 km (1977)
Railroads: 767 km standard gage (1.485 m)
Highways: 4,459 km paved, 7 km gravel/crushed stone,
remainder unknown
Pipelines: crude oil, 708 km; refined products, 290 km;
natural gas, 89 km
Ports: 3 major (Haifa, Ashdod, Elat), 5 minor
Airfields: 55 total, 46 usable; 20 with permanent-surface
runways; 5 with runways 2,440-3,659 m, 7 with runways
’ 1,220-2,4389 m
Civil air: 25 major transport aircraft (including 5 leased
in)
Telecommunications: most highly developed in the
Middle East though not the largest; good system of coaxial
cable and radio relay; 870,000 telephones (24.0 per 100
popl.); 14 AM, 10 FM stations, 15 TV stations and 30
repeater stations; 2'' submarine cables; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: Jewish males 15-49, 859,000;
714,000 fit for military service; average number of Jews
reaching military age (18) annually—32,000 males, 30,000
females; both sexes liable for military service
4
ry na
Ay ipioee
Cairo* —','c392746ee19c70e10cbf8663c25302d39efc67166c5b2886b4b55afc44784d72','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ca516d807fc2f9e4a5df83128e2596df52154a173c062d22aceed7ffba7ac98',1972,'IT','Italy','communications',230,'LAND
301,217 km?; 50% cultivated, 17% meadow and pasture,
21% forest, 3% unused but potentially productive, 9% waste
or urban ,
Land boundaries: 1,702 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4,996 km
Railroads: 20,690 km total; 15,970 km government-
owned standard gage (1.435 m), 7,850 km electrified; 4,720
km non-government owned, 2,507 km standard gage (1.435
m), 1,270 km electrified; 2,218 km narrow gage (0.950 m),
517 km electrified
Highways: 286,400 km total; autostrade 4,800 km, state
highways 41,200 km, provincial highways 91,200 km,
communal highways 149,200 km; 254,400 km concrete,
bituminous, or stone block, 24,800 km gravel and crushed
stone, 7,200 km earth
Inland waterways: 2,500 km navigable routes
Pipelines: crude oil, 1,770 km; refined products, 2,179
km; natural gas, 13,079 km
Ports: 16 major, 22 significant minor
Civil air: 123 major transport aircraft (including 1 leased
in and 1] leased out)
Airfields: 151 total, 15] usable; 81 with permanent-
surface runways; 2 with runways over 3,660 m, 29 with
runways 2,440-3,659 m, 42 with runways 1,220-2,439 m; 11
seaplane stations
Telecommunications: well engineered, well constructed,
and efficiently operated; 15.2 million telephones (27.1 per
100 popl.); 185 AM, 660 FM, and 900 TV stations; 16 coaxial
submarine cables; 2 communication satellite ground stations
with Atlantic Ocean and Indian Ocean antennas
DEFENSE FORCES ;
Military manpower: males 15-49, 13,745,000; 11,547,000
fit for military service; 460,000 reach military age ane
annually
Military budget: for fiscal year ending 31 December
1978, $4,957.2 million; about 7.1% of proposed central
government budget
104
IVORY COAST
Gulf of
- Guinea
Atlantic Ocean
{See reference map Vi}
LAND
323,750 km?; 40% forest and woodland, 8% cultivated,
52% grazing, fallow, and waste; 322 km of lagoons and
connecting canals extend east-west along eastern part of the
coast
Land boundaries: 3,227 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm) :
Coastline: 515 km
Railroads: 657 km of the 1,173 km Abidian to Quagadou-
gou, Upper Volta line, all single track meter gage (1.00 m);
only diesel locomotives in use
Highways: 46,775 km total; 2,388 km bituminous and
bituminous-surface treatment; 33,097 km gravel, crushed
stone, laterite, and improved earth; 11,190 km unimproved
Inland waterways: 740 km navigable rivers and numer-
ous coastal lagoons
Ports: 2 major (Abidjan, San Pedro), 3 minor
Civil air: 20 major transport aircraft
Airfields: 50 total, 48 usable; 3 with permanent-surface
runways; 2 with runways 2,440-3,659 m; 8 with runways
1,220-2,489 m; 1 seaplane station.
Telecommunications: system only slightly above African
average; consists of open-wire lines and radio relay links,
which provide incomplete coverage of country; Abidjan is
only center; 58,700 telephones (0.9 per 100 popl.); 2 AM, 4
FM, and 6 TV stations; 1 Atlantic Ocean satellite station; 1
coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 1,680,000; 865,000 fit
for military service; 78,000 males reach military age (18)
annually ;
Military budget: for fiscal year ending 31 December
1978, $142,697,665; about 7.2% of total operating budget
Military budget: for fiscal year ending 31 March 1979,
$9,417,460 (includes funds for Pioneer Corps and the Arms
of Malta, totaling about $5.1 million); about 3.5% of central
government budget','c5a1e3797e78ebeccaadae9d64d9594dcd20912427270fbeff28208492ef7a62','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27dedd6c4121392f889e6f33ecc6ec4a74b69aefca12cdb05a329a9e671ed9ae',1972,'JM','Jamaica','communications',234,'LAND
11,422 km?; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,022 km
Railroads: 330 km, all standard gage (1.435 m), single
track
Highways: 11,250 km total; 7,600 km paved, 2,150 km
gravel, 1,500 km improved earth
Pipelines: refined products, 10 km
Ports: 3 major (Kingston, Montego Bay, Montego Free-
port), 10 minor
Civil air: 10 major transport aircraft
Airfields: 42 total, 22 usable; 12 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 1 with runway
1,220-2,489 m; 3 seaplane stations
Telecommunications: fully automatic domestic telephone
network with 109,000 telephones (5.4 per 100 popl.); 1
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
nn 2 ll a, a Ae Pe «OE. SN ee a ee ee” ae
Oe OM Ne ON ON Se ee SO ee ae. oe A RS: ™"
Se eS A SS ee
EE A es, Cee, ed, ee ee NT eee ee tn
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
JAMAICA/JAPAN
Atlantic Ocean satellite station; 8 AM, 11 FM, and 9 TV
stations; 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 438,000; 313,000 fit for
military service; no conscription; average number currently
reaching minimum volunteer age (18) 28,000
Supply: dependent on U.K. ‘and U.S.
Military budget: for fiscal year ending 31 March 1978,
$26.6 million; about 2.2% of central government budget
Pacific
Ocean
Philippine
Sea
(See reference map Vil}
LAND
370,370 km?; 16% arable and cultivated, 3% grassland,
12% urban and waste, 69% forested
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
“Coastline: 12,075 km Japan; 1,610 km Ryukyus
Railroads: 28,912 km total (1976); 1,077 km standard
gage (1.485 m), 27,8835 km predominantly narrow gage
(1.067 m), 6,195 km double track, 7,376 km or 26% of total
route length electrified; 73% government-owned
Highways: 1,067,643 km total (1976); 338,343 km paved,
most. of remainder gravel or crushed stone
Inland waterways: approx. 1,770 km; seagoing craft ply
all coastal “inland seas”
Pipelines: crude oil, 109 km; natural gas, 1,847 km -
Ports: 53 major, over 2,000 minor
Civil air: 24] major transport aircraft
Airfields: 186 total, 176 usable; 122 with permanent-
surface runways; 2 with runways over 3,660 m; 22 with
runways 2,440-3,659 m, 48 with runways 1,220-2,489 m, 5
seaplane stations
DEFENSE FORCES
Military manpower: males 15-49, 30,441,000; 25,522,000
fit for military service; about 815,000 reach military age (18)
annually .
Supply: defense industry potential is large, with capability
of producing the most sophisticated equipment; manufac-
tured equipment includes small arms artillery, armored
vehicles, and other types of ground forces materiel, aircraft
(jet and prop), naval vessels (submarines, guided missile and
108
other destroyers, patrol craft, mine warfare ships, and other
minor craft including amphibious, auxiliaries, service craft,
and small support ships), small amounts of all types of army
materiel
Military budget: for fiscal year ending 31 March 1979,
$9.5 billion; about 5.5% of total budget
-oflatdutas
Caribbean Sea
°
v
* Panama
Barranquilla,
Canal Zone q i
Venezuela
eMedeltin
Bogota','ea80b4974a1e49a0f6361cb0f39307254b18e5fd782472c16259c83ee812e3c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('000a20f687d96e7d5ed52f4e959e6bfb0c437fb67d18ea9214060fc1c418a520',1972,'JO','Jordan','communications',238,'_ ARABIA
(See reference map V)}
NOTE: The war between Israel and the Arab states in
June 1967 ended with Israel in control of West Jordan.
Although approximately 930,000 persons resided in this area
prior to the start of the war, fewer than 750,000 of them
remain there under the Israeli occupation, the remainder
having fled to East Jordan. Over 14,000 of those who fled
were repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These and
certain other effects of the 1967 Arab-Israeli war are not
included in the data below.
LAND
96,089 km? (including about 5,489 km? occupied by
Israel); 11% agricultural, 88% desert, waste, or urban, 1%
forested
Land boundaries: 1,770 km (1967, 1,668 km excluding
occupied areas)
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 26 km
Railroads: 817 km 1.050-meter gage, single track
Highways: 6,332 km total; 4,887 km paved, 1,495 km-
gravel and crushed stone
Pipelines: crude oil, 209 km
Ports: 1 major (Aqaba)
Civil air: 15 major transport aircraft
Airfields: 25 total, 16 usable; 14 with permanent-surface
runways; 4 with runways over 3,660 m, 10 with runways
2,440-3,659 m, 1 with runway 1,220-2,439 m
Telecommunications: adequate system of radio relay,
wire, and radio; 44,000 telephones (1.6 per 100 popl.); 5 AM,
no FM and 6 TV stations; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 674,000; 476,000 fit for .
military service; average number currently reaching military
age (18) annually 33,000 ,
Military budget: for fiscal year ending 31 December
1978, $266 million; 22% of central government budget
KAMPUCHEA
LAND
181,300 km?; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other
Land boundaries: 2,438 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
109
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
KAMPUCHEA/KENYA
Gull of
Thailend = \\
(See reference map Vil)
Coastline: about 443: km
Railroads: 612 km meter gage (1.00 m); govern-
ment-owned
Highways: 13,351 km total; 2,622 km bituminous, 7,105
km crushed stone, gravel, or improved earth; and 3,624 km
unimproved earth; some roads in disrepair
Inland waterways: 3,700 km navigable all year to craft
drawing 0.6 meters; 282 km navigable to craft drawing 1.8
meters
Ports: 2 major, 5 minor
Airfields: 54 total, 25 usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 6 with runways
],220-2,489 m; 1 seaplane station
DEFENSE FORCES
Military manpower: males 15-49, 1,815,000; 1,010,000 fit
for military service; 91,000 reach military age (18) annually
Military budget: unknown','ca341912eb43ac2839052baf8176f20bbc0345fe8451b2a7556802fad9b769f9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('100e2dcc4847bdf66497e85500db0772ef4f21f4e907923d816b8d0c15278ac2',1972,'KE','Kenya','communications',242,'LAND
582,750 km?; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland adequate for
grazing (1971)
Land boundaries: 3,368 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
—
A i all
ae
SNE ee ee ee ee er ee Nar
~
a a a
ee
ee I
ee, ee
ie a dd a ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Indian
Ocean
(See reference map Vi}
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 536 km
Railroads: 2,040 km meter gage (1.00 m)
Highways: 50,840 km total; 4,300 km paved, 12,160 km
gravel and/or -earth; 26,880 km improved earth and. 7,500
km unimproved earth
111
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
KENYA/KOREA, NORTH
Inland waterways: part of Lake Victoria and Lake
Rudolph systems are within boundaries of Kenya
Pipelines: refined products, 483 km
Ports: 1 major (Mombasa)
Civil air: 18 major transport aircraft
Airfields: 236 total, 218 usable; 8 with permanent-surface
runways; 1 with runway over 3,660 m, 3 with runways
2,440-3,659 m, 37 with runways 1,220-2,439 m
Telecommunications: in top group of African systems;
consists of radio-relay links, open-wire lines, and radiocom-
munication stations; ‘principal center Nairobi, secondary
centers Mombasa and Nakuru; 132,000 telephones (1.0 per
100 popl.); 4 AM, 2 FM, and 5 TV stations; 1 Indian Ocean -
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,218,000; 1,914,000 fit
for military service; no conscription
Military budget: for fiscal year ending 30 June 1978,
$201,600,000; about 13.4% of central goverriment budget
KOREA, NORTH
China Sea
(See reference map Vil)
LAND
121,730 km?; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban
Land boundaries: 1,675 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
200 nm, military 50 nm)
Coastline: 2,495 km
Railroads: none
Highways: 9,020 km total; 320 km paved, 2,700 km
gravel and/or improved earth, 6,000 km unimproved
Inland waterways: Lake Kivu navigable by barges and
native craft
Civil air: 1 major transport aircraft
Airfields: 8 total, 8 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m, 1 with runway
2,440-3,659 m
Telecommunications: low-capacity radio-relay- system
centered on Kigali; 3,600 telephones (0.1 per 100 popl.); 2
AM, 1 FM, no TV stations; Symphonie COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 924,000; 468,000 fit for
military service; no conscription; 43,000 reach military age
(18) annually
175
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
RWANDA/ST. CHRISTOPHER-NEVIS-ANGUILLA
Military budget: for fiscal year ending 31 December
1977, $12,436,450; 15.5% of central government budget
ST. CHRISTOPHER-NEVIS-ANGUILLA
Atlantic Ocean','9820360a26e57bebbf399d300d330c5508e97645b4b89e4c8f7bddf60e43c951','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8da34bfc30404a9e375805e0ce9eeb366310840973339722ddb3c383be4133fd',1972,'SA','Saudi Arabia','communications',246,'(See reference map V}
LAND 7 ; \\
16,058 km? (excluding neutral zone but including islands);
insignificant amount forested; nearly. all: desert, waste; or
_urban
Land boundaries: 459 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 499 km
Railroads: none
Highways: 2,545 km total; 2,255 km bituminous; 290 km
earth, sand, light gravel
Pipelines: crude oil, 877 km; refined products, 40 km;
natural gas, 121 km
Ports: 8 major (Ash Shuwaikh, Ash Shuaybah, Mina al
Ahmadi), 4 minor
Civil air: 18 major transport aircraft (including 6 leased
in)
Airfields: 11 total, 6 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 3 with runways
1,220-2,489 m
Telecommunications: excellent international and ade-
quate domestic telecommunication facilities; 140,000 tele-
phones (13.0 per 100 popl.); 3 AM, 1 FM and 3 TV stations;
1 satellite station with Indian and Atlantic Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, about 288,000; about
168,000 fit for military service
Military budget: for fiscal year ending 30 June 1978, $845
million; 10% of central government budget
LAOS
LAND
236,804 km*; 8% agricultural, 60% forests, 32% urban,
waste, and other; except in very limited areas, soil is very
poor; most of forested area is not exploitable
Land boundaries: 5,053 km
Highways: about 18,000 km total; 1,300 km bituminous
or bituminous treated, 5,900 km gravel, crushed stone, or
improved earth; 10,800 km unimproved earth and often
impassable during rainy season mid-May to mid-September
Inland waterways: about 4,587 km, primarily Mekong
and tributaries; 2,897 additional kilometers are sectionally
navigable by craft drawing less than 0.5 m
Ports (river): 5 major, 4 minor
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a
we ta na AA AA Ai ee A
Px
cred
ee RF Be RR ET er I ee: ee
>
]
3
$
,
>
>
5
>
*
»
>
>
>
x
>
;
>
:
I
i
:
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Airfields: 87 ‘total, 77 usable; 9 with permanent-surface
runways; 1] with runways 1,220-2,439 m, 1 with runway
2,440-3,659 m
DEFENSE FORCES
Military manpower: males 15-49, 776,000; 453,000 fit for
military service; average number currently reaching usual
military age (18) annually, 37,000; no conscription age
specified :
Lao People’s Liberation Army (LPLA): the LPLA
consists of an army with naval, aviation, and militia elements
Military budget: unknown
Railroads: none
Highways: 805 km total; 442 km bituminous; 362 km
gravel; undetermined mileage of earth tracks
Pipelines: crude oil, 169 km; natural gas, 97 km
Ports: 1 major (Ad Dawhah), 1 minor
Airfields: 2 total, 1 usable; 2 with permanent-surface
runways, 1 with runway over 3,660 m
Civil air: 2 major transport aircraft, 1 registered in the
U.K.
Telecommunications: good urban facilities; 24,000 tele-
phones (14.8 per 100 popl.); international service through an
Indian Ocean COMSAT station and a troposcatter link to
Bahrainu; 1 AM, 1 FM, and 2 TV stations.
DEFENSE FORCES
Military manpower: males 15-49, about 40,000; about
22,000 fit for military service
Military budget: for fiscal year ending 24 January 1974,
$53,680,900; 18% of central government budget
REUNION
LAND
2,512 km*; two-thirds of island extremely rugged,
consisting of volcanic mountains; 48,600 hectares (less than
one-fifth of the land) under cultivation
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 201 km
Indian
MAD AR
MOZAMBIQUE i ’
(See reference map V}
LAND
Estimated at about 2,331,000 km? (boundaries undefined
and disputed); 1% agricultural, 1% forested, 98% desert,
waste, or urban
Land boundaries: 4,537 km
WATER
Limits of territorial waters (claimed): 12:nm (plus 6 nm
“necessary supervision zone’’)
- Coastline: 2,510 km
Railroads: 575 km standard gage (1.435 m)
Highways: 30,100 km total; 16,500 km paved, 13,600 km
improved earth :
Pipelines: 2,430 km crude oil; 386 km refined products;
98 km natural gas
Ports: 3 major (Jidda, Ad Damman, Ras Tanura), 6 minor
Civil air: 73 major transport aircraft
181
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
SAUDI ARABIA/SENEGAL
Airfields: 119 total, 88 usable; 30 with permanent-surface
runways; 15 with runways 2,440-3,659 m, 38 with runways
1,220-2,439 m, 5 with runways over 3,660 m
Telecommunications: fair system exists, major expansion
program underway with microwave, coaxial cable, satellite
systems; 200,000 telephones (2.5 per 100 popl.): 6 AM, 1 FM,
11 TV stations, 1 submarine cable; 2 COMSAT stations,
several domestic satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 1,770,000; 1,014,000 fit
for military service; about 70,000 reach military age (18)
annually ;
Military budget: for fiscal year ending 1 July 1979,
$12,936 million; about 32% of central government budget
£
CIA-
Arabian Sea
© Rocotra
500 Kilometers
500 Miles
Boundary representation is
not necessarily authoritative
RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02
Ocean
ana Azores
{Port}
> ia
Canary Is. (Sp)
° 2
2''% 4
Western
Sahara
Partition line shown
by Mauritania-Morocey,
Accord, 1876 Se
ibraltar
Mediterranean Sea','8697a3674a8697933dd3bb4c1569701f52c7771750277d8fcb9ce1524200fc14','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4641c8cd6a9598fa32dda57d17c4534e3c8daa0e8980eaad4a5d880b7418f0a8',1972,'LB','Lebanon','communications',250,'(See reference map V}
LAND
10,360 km’; 27% agricultural land, 64% desert, waste, or
urban, 9% forested
Land boundaries: 531 km
WATER
Limits of territorial waters (claimed): no specific claims
(fishing, 6 nm)
Coastline: 225 km
Railroads: 378 km total; 296 km standard gage (1.435 m),
82 km 1.050-meter gage; all single track :
Highways: 7,370 km total; 6,270 km paved, 450 km
gravel and crushed stone, 650 km improved earth
Pipelines: crude oil, 72 km
Ports: 3 major (Beirut, Tripoli, Sayda), 5 minor
Civil air: 34 major transport aircraft
Airfields: 8 total, 6 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m; 2 with runways
1,220-2,439 m
Telecommunications: rebuilding program disrupted; in-
ternational facilities restored, domestic being rebuilt; fair
system of microwave, cable; approx 125,000 telephones (5.0
per 100 popl.); 2 FM, 7 AM, 7 TV stations; 1 Indian Ocean
satellite station; 8 submarine cables.
DEFENSE FORCES
Military manpower: males 15-49, 560,000; 341,000 fit for
military service; average of about 28,000 reach military age
(18) annually','3882e2df655f237c0018c147a574d4c7955cded5720c732d530bc80a351834f6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('216de3110433aa0264225b1e643bb88a0c8fdcdb6cf9d42afb86417ef3a812aa',1972,'LS','Lesotho','communications',254,'LAND
30,303 km?; 15% cultivable; largely mountainous
Land boundaries: 805 ‘km
118
{See reference map Vi}
Railroads: 1.6 km; owned, operated, and included in the
statistics of the Republic of South Africa
Highways: approx. 3,916 km total; 218 km paved; 993 km
crushed stone, gravel, or stabilized soil; 1,046 km improved,
1,659 km unimproved earth
Civil air: no major transport aircraft
Airfields: 21 total, 21 usable; 3 with runways 1,220-2,439
m, | with permanent surface runway
Telecommunications: system a modest one consisting of a
few landlines, a small radio-relay system, and minor
radiocommunication stations; Maseru is the center; 3,725
telephones (0.3 per 100 popl.); 2 AM, 1 FM, 1 TV station
planned
DEFENSE FORCES .
Military manpower: males 15-49, 256,000; fit for military
service 136,000','f70b4937fe00f8708ea4628648c014cf4a7ea1b363ff7b401bc7dc08300fe59c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('301d002dd3517283d939e1a34dd0239aaba005d2e17fa64d195b01dac73b0904',1972,'LR','Liberia','communications',258,'a
Monrovia
Atlantic Ocean
(See reference map Vi}
LAND
111,370 km?; 20% agricultural, 30% jungle and swamps,
40% forested, 10% unclassified
Land boundaries: 1,336 km
WATER
Limits of territorial waters (claimed): 22 nm
Coastline: 579 km
Railroads: 499 km total; 354 km standard gage (1.435 m),
145 km narrow gage (1.067 m); all lines single track; rail
systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 7,952 km total; 603 km bituminous treated;
2.055 km gravel, and 4,731 km improved and 563 km
unimproved earth
Inland waterways: 370 km
Ports: 3 major (Monrovia, Buchanan, Greenville-Sino
Harbor), 4 minor
Civil air: 4 major transport aircraft (including 1 leased in)
Airfields: 80 total, 78 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: telephone and telegraph limited;
main center is Monrovia; 3,400 telephones (0.2 per 100
popl.); 5 AM, 2 FM, and 3 TV stations; 1 Atlantic Ocean
Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 382,000; 204,000 fit for
military service; no conscription
Military budget: for year ending 30 June 1979, $8.5
million; 2.5% of central government budget','d4d008d9d496b139bb225cc249d3296c94a32983348708fdc609e1cbc575439b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee0d4fa6def5c64b9dd3835233be5f71d774d8a47f242da65211dafde5b205fd',1972,'LY','Libya','communications',262,'LAND
1,758,610 km?; 6% agricultural, 1% forested, 93% desert,
waste, or urban
Land boundaries: 4,345 km
WATER
Limits of territorial waters (claimed): 12 nm (except for
‘Gulf of Sidra where sovereignty is claimed and northern
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
I NES TE Ee ee ae eee
ES ee ae es, ae
i i Nn A Tn
Ne ee Ee ee es ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
limit of jurisdiction fixed at 82°30''N. and the unilaterally
proclaimed 100 nm zone around Tripoli)
Coastline: 1,770 km
Railroads: none :
Highways: 16,250 km total; 7,750 km bituminous and
bituminous treated, 8,500 km gravel, crushed stone and
earth
Pipelines: crude oil 3,251 km; natural gas 282 km; refined
products 443 km (includes 217 km liquid petroleum gas)
Ports: 8 major (Tobruk, Tripoli, Benghazi), 4 minor, and 5
petroleum terminals ©
Civil air: 39 major transport aircraft (including 8 leased
in)
Airfields: 86 total, 74 usable; 16 with permanent-surface
runways, 1 with runway over 3,660 m, 13 with runways
2,440-3,659 m, 28 with runways 1,220-2,439 m
121
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
LIBYA/LIECHTENSTEIN
Telecommunications: system is in top one-third of
African systems; consists of radio-relay and _ tropo-
spheric-scatter links, open-wire lines, and radiocommunica-
tion stations; principal centers are Tripoli and Benghazi;
49,800 telephones (1.8 per 100 popl.); 15 AM, 1 FM, and 12
TV stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 645,000; 382,000 fit for
military service; about 30,000 reach military age (17)
annually; conscription now being implemented
Military budget: for fiscal year ending 31 December
1978, $4389 million; 5% of central government budget','319986ace21a439596cc5b779d8d2af5f80f405bbe8110d47a16159772ba9286','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ab094e3c23aff8288b168b30c94bc234c3a4b37494c9b0bf486ac980503b459',1972,'LI','Liechtenstein','communications',266,'OF GERMANY
AUSTRIA -
(See reference map tV)}
LAND
168 km?
Land boundaries: 76 km
Railroads: 16.00 km, standard gage (1.435 m), electrified;
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Se eo el
ey
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
LIECHTENSTEIN/LUXEMBOURG
owned, operated, and included in statistics of Austrian
Federal Railways
Highways: no information on total kilometers
Civil air: 2 major transport aircraft registered and
operated in Switzerland
Airfields: none
Telecommunications: automatic telephone system serv-
ing about 16,200 telephones (67.7 per 100 popl.); no
broadcast facilities
DEFENSE FORCES
Defense is responsibility of Switzerland','12349687a7b3ef52d206fe0f1e3e86bfae6a68d1af6a270d25d0a83fd95a3f2d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6ab07b38e0208b5cfaf7d078a7a2f204e10c5c8c758dc8efe8ce351aa3ef03c',1972,'LU','Luxembourg','communications',270,'“FEDERAL REPUBLIC j
OF GERMANY
KEN BOURG
Railroads: 270 km standard gage (1.435 m); 160 km
double track; 136 km electrified :
Highways: 5,057 km total; 4,911 paved, 78 km gravel; 62
km earth; about 80 km limited access divided highway
completed or under construction
Inland waterways: 37 km; Moselle River
Pipelines: refined products, 48 km
Port: (river) Mertert
Civil air: 10 major transport aircraft
Airfields: 2 total, 2 usable; 1 with permanent-surface
runway; 1 with runway -2,440-3,659 m :
Telecommunications: adequate and efficient _system;
158,000 telephones (44.2 per 100 popl.); 4 AM, 3 FM, 2 TV
stations ;
DEFENSE FORCES .
Military manpower: males 15-49, 90,000; 75,000 fit for
military service; about 3,000 reach military age (19)
annually
Military budget: for fiscal year ending 31 December
1978, $32 million, 3% of the central government -budget','937caa9e699ec9a1d4d33e1041746a2f44f603d40a9ddd1b766cb054df369a11','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c2091da5a81701396b0d89d9e57456bf47ec63e58cf407214fb93b5ffeab982',1972,'MO','Macao','communications',271,'LAND
15.5 km?*; 10% agricultural, 90% urban
Land boundaries: 201 m
WATER
Limits of territorial waters (claimed): 6 nm; fishing, 12
nm
Coastline: 40 km
124
EJHONG KONG','31d9e43ebb01e6e7e4fb6e0f72d9564c2cde93e53128394d1795c6c0976de418','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('896016ef02abcb2a8595f2f1f797af66df02762c3ea3b05b6d0af8c8a37a4988',1972,'MG','Madagascar','communications',272,'LAND ¢
595,700 km’; 5% cultivated, 58% pastureland, 21%
forested, 8% wasteland, 2% rivers and lakes, 6% other
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 4,828 km
Railroads: 884 km of meter gage (1.00 m)
Highways: 27,500 km total; 4,525 km paved, 228 km
crushed stone, gravel, or stabilized soil; remainder improved
and unimproved earth (est.)
Inland waterways: of local importance only, Lake
Alaotra, isolated streams and portions of Canal des
Pangalanes
Ports: 4 major (Tamatave, Diego Suarez, Majunga,
Tulear)
Civil air: 3 major transport aircraft
Airfields: 194 total, 120 usable; 28 with permanent-sur-
face runways; 3 with runways 2,440-3,659 m, 42 with
runways ],220-2,489 m
Telecommunications: system above African average;
includes open-wire lines, some radio-relay and coaxial links
and 1 Atlantic Ocean satellite ground station; 28,000
telephones (0.4 per 100 popl.); 10 AM, no FM, and 4 TV
stations
DEFENSE FORCES .
Military manpower: males 15-49, 1,759,000; 1,041,000 fit
for military service; average number reaching military age
(20) annually about 80,000
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MADAGASCAR/MALAWI
Supply: nearly all from France in the past, now mostly
from West and East European countries; also PRC and
North Korea','7153993e8f986f755101a97de99135b6531f70d1dfad9846932ca844522d5163','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae93f7376e5f894efdc87e0a392923eef6001ee3eb3ad0d60c97c5e0f037e895',1972,'ZA','South Africa','communications',273,'Indian Ocean
{See reference map Vi}
NOTE: separate data on Transkei follows last entry for
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
NS ee ee
Se a ee ee ee ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SQUTHERN
RHODESIA
SOUTH
AFRICA
Ocean
(See reference map Vi}
LAND
1,222,480 km? (includes enclave of Walvis Bay, 1,124 km’;
and Transkei, 44,000 km®*); 12% cultivable, 2% forested, 86%
desert, waste, or urban
Land boundaries: 2,044 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 2,881 km, including Transkei
Railroads: 25,560 km total (includes Namibia); 24,854 km
1.067-meter gage of which 5,292 km are multiple track; over
5,000 km electrified; 706 km 0.610-meter gage single track
Highways: 202,922 km total; 57,4385 km paved, 145,487
km crushed stone, gravel, or improved earth
Pipelines: 836 km crude oil; 1,048 km refined products;
322 km natural gas
Ports: 8 major
Civil air: 78 major transport aircraft
Airfields: 657 total, 520 usable; 66 with permanent-sur-
face runways; 3 with runways over 3,660 m, 6 with runways
2,440-3,659 m, 126 with runways 1,220-2,489 m
Telecommunications: the system is the best developed,
most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay
links, and radiocommunication stations; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg, Port
Elizabeth, and Pretoria; 2.2 million telephones (8.3 per 100
popl.); 13 AM, 84 FM, and 34 TV stations; 1 submarine
cable; 1 satellite station with Atlantic Ocean and Indian
Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 5,762,000; 3,549,000 fit
for military service; obligation for service in Citizen Force or
Commandos begins at 18; volunteers for service’ in
permanent force must be 17; national service obligation is
two years
Military budget: for year ending 31 March 1979, $2.0
billion; 18% of central government budget
Transkei
NOTE: Formerly an ‘autonomous tribal homeland in
South Africa, Transkei was granted independence by South
Africa on 26 October 1976, but has not been recognized by
190
SOUTHERN
RHODESIA
SOUTH uesfiu)
EZ,
AFRICA
(See reference map VI)
any other government or any international organization. It
remains heavily dependent on South Africa for administra-
tive and economic support.
LAND
44,000 km? in one large and two small pieces separated
from each other by parts of South Africa
Land boundaries: 1,200 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 250 km
Railroads: less than 160 km
Highways: 725 km paved, 7,768 km unpaved
Ports: none; Transkei dependent on the South African
port of East London
Telecommunications: open-wire lines to Durban and East -
London
DEFENSE FORCES ;
Military manpower: males 15-49, 501,000; 279,000 fit for
military service
Personnel: 320 army (including 7 officers)
Major ground units: 1 infantry battalion
>
Atlantic
CANARY
ey ee ALGERIA
o ]
{See reference map tV)
LAND
505,050 km®, including Canary (7,511 km?) and Balearic
Islands (5,025 km?); 41% arable and land under permanent
crops, 27% meadow and pasture, 22% forest, 10% urban or
other
Land boundaries: 1,899 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 4,964 km (includes Balearic Islands, 677 km,
and Canary Islands, 1,158 km)','7e8bb4950909d4b6993272e75622b087ad678c2ff8ffa2aca28407f03bc49785','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60db350a3e71ccb59d0d95dabf706e0342954a983cd3ca61fa66ae122ab3b84a',1972,'MW','Malawi','communications',277,'Indian
Ocean
§ . MOZAMBIQUE
SOUTHERN
RHODESIA
{See reference map Vi}
LAND
95,053 km?; about 31% of land area arable (of which less
than half is cultivated), nearly 25% forested, 6% meadow
and pasture,. 38% other
Land boundaries: 2,881 km
Railroads: 668 km 1.067-meter gage
Highways: 14,913 km total; 1,385 km paved; 631 km
crushed stone, gravel, or stabilized soil; 8,714 km improved
earth, 4,183 km unimproved earth
Inland waterways: Lake Malawi, 1,290 km and. Shire
River, 144 km, 3 lake ports
127
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MALAWI/MALAYSIA
Ports: no maritime ports
Civil air: 4 major transport aircraft
Airfields: 48 total, 48 usable; 1 with permanent-surface
runway; 9 with runways 1,220-2,439 m
Telecommunications: the system is above average for
African countries and consists of open-wire lines, radio-relay
links, and radiocommunication stations; principal centers are
Blantyre, Zomba, Lilongwe, and Muzuzu; 19,800 telephones
(0.4 per 100 popl.); 6 AM, 4 FM and no TV stations; 1 Indian
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49,
558,000 fit for military service
Military budget: for fiscal year ending 31 March 1979,
$20.6 million; 6.8% of recurrent central government budget
1,104,000; about
Ports: 3 major (Dar es Salaam, Mtwara, Tanga)
Civil air: 10 major transport aircraft
Airfields: 103 total, 97 usable; 10 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 41 with runways
1,220-2,439 m
Telecommunications: fair system of open wire, radio
relay, and troposcatter; 68,400 telephones (0.4 per 100
popl.); 5 AM, no FM, 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 3,540,000; 2,040,000 fit
for military service
Military budget: for fiscal year ending 30 June 1979,
$148.2 million; 9.6% of central government budget','d880a9502efabbc2e2b3c7f766067d5363f5fbf68b14ea6790df360134f09096','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('683780ee9e6fe8c96c65cd6ce65ab2816b482955e2b59b319b7e2a70b9f94c98',1972,'MY','Malaysia','communications',281,'South China
. Sea
4
(See reference map Vil}
NOTE: Malaysia, which came into being on 16 September
1963, consists of Peninsular Malaysia, which includes 11
states of the former Federation of Malaya, plus East
Malaysia, which includes the 2 former colonies of North
Borneo (renamed Sabah) and Sarawak
LAND .
Peninsular Malaysia: 131,313 km?; 20% cultivated, 26%
forest reserves, 54% other
Sabah: 76,146 km?; 13% cultivated, 34% forest reserves,
53% other
Sarawak: 125,097 km*; 21% cultivated, 24% forest
reserves, 55% other
Land boundaries: 509 km Peninsular Malaysia, 1,786 km
East Malaysia
WATER
Limits of territorial waters (claimed): 12 nm
128
Coastline: 2,068 km Peninsular Malaysia, 2,607 km East','a17101798f6e398c47876a9183a4a4b44298c08785f6da5fbd8fdc74ee56eb8f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1aa1aa9360df7941cdf539335023e0aed9b5d281c33fe2c851c4b3c8c3e429b7',1972,'SG','Singapore','communications',286,'Railroads:
Peninsular Malaysia: 1,665 km 1.04-meter gage; 13 km
double track; government-owned
East Malaysia: 154 km meter gage (1.00 m) in Sabah
Highways: |
Peninsular Malaysia: 19,778 km total; 15,925 km hard
surfaced (mostly bituminous surface treatment), 2,970 km
crushed stone/gravel, 883 km improved or unimproved
earth ,
East Malaysia: about 5,426 km total (1,644 km in
Sarawak, 3,782 km in Sabah); 819 km hard surfaced (mostly
bituminous surface treatment), 2,986 km gravel or crushed
stone, 1,671 km earth
Inland waterways:
Peninsular Malaysia: 3,194 km
East Malaysia: 4,087 km (1,569 km in Sabah, 2,518 km
in Sarawak)
Ports:
Peninsular Malaysia: 3 major, 14 minor
East Malaysia: 1 major, 14 minor (5 minor in Sabah; 1
major, 9 minor in Sarawak)
Civil air: approximately 26 major transport aircraft
Pipelines: crude oil, 69 km; refined products, 56 km
Airfields:
Peninsular Malaysia: 62 total, 62 usable; 16 with
130
permanent-surface runways; 3 with runways 2,440-3,659 m,
11 with runways 1,220-2,439 m
Sabah: 34 total, 34 usable; 5 with permanent-surface
runways; 1 with runway 2,440-3,659 m; 4 with runways
1,220-2,489 m
Sarawak: 45 total, 45 usable; 5 with permanent-surface
runways; 4 with runways 1,220-2,439 m
Telecommunications:
Peninsular Malaysia: good intercity service provided
mainly by microwave relay; international service good; good
coverage by radio and television broadcasts; 278,000
telephones (2.7 per 100 popl.); 26 AM, 1 FM, and 16 TV
stations; submarine cables extend to India, Sri Lanka, and
Singapore; connected to SEACOM submarine cable terminal
at Singapore by microwave relay; 1 ground satellite station
Sabah: adequate intercity radio-relay network extends
to Sarawak via Brunei; 23,068 telephones (2.7 per 100 popl.);
5 AM, 1 FM, 5 TV stations, SEACOM submarine cable links
to Hong Kong and Singapore; 1 ground satellite station
Sarawak: adequate intercity radio-relay network ex-
tends to Sabah via Brunei; 28,000 telephones (2.4 per 100
popl.); 4 AM stations, no FM, and 1 TV station
DEFENSE FORCES
Military manpower:
Peninsular Malaysia: males 15-49, . 2,497,000; .
1,588,000 fit for military service; 112,000 reach military age
(21) annually
Sabah: males 15-49, 208,000; 122,000 fit for military
service; 10,000 reach military age (21) annually
Sarawak: males 15-49, 274,000; 163,000 fit for military
service; 11,000 reach military age (21) annually
External defense dependent on loose Five Power Defense
Agreement (FPDA) which replaced Anglo-Malayan Defense
Agreement of 1957 as amended in 1963
Military budget: for fiscal year ending 31 December
1978, $689 million; about 13.4% of central government
budget
(See reference map Vil)
LAND
583 km?; 31% built up area, roads, railroads, and airfields,
22% agricultural, 47% other
WATER -
Limits of territorial waters (claimed); 3 nm
Coastline: 193 km
Railroads: 38 km of meter gage
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
AY ial nn, nl i A RO A A Ae Aa ee Ue Shae GA AR Ra Ae
AR AR ARR
Ne ea a ge a a Ne ee
ee,
NO a
ee ee
> i i, Aa a i a ee
ew
EO Ee ee EE Ee a ei ES ee a OS
ee Ne a Ee ee, ee
i 2 i a MO ek a a
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SINGAPORE/SOLOMON ISLANDS
Highways: 2,218 km total (1977); 1,806 km paved, 412
km crushed stone or improved earth
Ports: 3 major
* Civil air: approximately 25 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 2 with runways
1,220-2,489 m
Telecommunications: good domestic facilities; good
international service; good radio and television broadcast
coverage; 374,000 telephones (16.3 per 100 popl.); 13 AM, 4
FM, and 2 TV stations; SEACOM submarine cable extends
to Hong Kong via Sabah, Malaysia; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 660,000; 481,000 fit for
military service
Military budget: for fiscal year ending 31 March 1979,
$411.2 million; about 16.6% of central government budget','d58c849cff712af9cc1508fbe2c2d172f1d4b7ace1251c7901570e0cb1a54de0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaf66ecbcad8cce5a4057db8136d326bbfbb368dc0ff63e09eceead835a2df4c',1972,'MV','Maldives','communications',287,'LAND
298 km; 2,000 islands grouped into 12 atolls, about 220
‘islands inhabited
WATER
Limits of territorial waters (claimed): the land and sea
between latitudes 7°9’N. and 0°45’S. and between longi-
tudes 72°30''E. and 73°48’E; these coordinates form a
rectangle of approximately 37,000 nm‘; territorial sea ranges
from 2.75 to 55 nm; fishing, approximately 100 nm
Coastline: 644 km (approx.)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
PS Ee, aD Oe ee ae =
ee a
x
~
pe ON OO
wh eet tee An AA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MALDIVES/MALI
Arabian
Sea:
F F SRI
*; leccadive LANKA:
| Sea
MALDIVES ; Me
Indian Ocean
{See reference mep Vil}
Railroads: none
Highways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways, 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m :
Telecommunications: minimal domestic and internation-
al telecommunication facilities; 480 telephones (0.4 per 100
popl.); 1 AM station; 1 Comsat station under construction
BamakorGpper
VOLTA
IVORY \\\\
eal |
Atlantic
Ocean
a
{See reference map Vi}
LAND
1,204,350 km?; only about a fourth of area arable, forests
negligible, rest sparse pasture or desert
131
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MALI/MALTA
Land boundaries: 7,459 km
Railroads: 642 km meter gage (1.00 m)
Highways: approximately 15,699 km total; 1,669 km
bituminous, 3,670 km gravel and improved earth, 10,360 km
unimproved earth
Inland waterways: 1,815 km navigable
Civil air: 8 major transport aircraft
Airfields: 42 total, 38 usable; 7 with permanent-surface’
runways; 2 with runways 2,440-3,659 m, 11 with runways
1,220-2,489 m
Telecommunications: domestic system poor and provides
only minimal service; open-wire and radiocommunication
used for long distance telecommunications; 78,000. tele-
phones (0.1 per 100 popl.); 2 AM, no FM, and no TV
stations; 1 Atlantic Ocean and 1 Indian Ocean satellite
, Station
DEFENSE FORCES
Military manpower: males 15-49, 1,419,000; 801,000 fit
for military service; no conscription
Military budget: for fiscal year ending 31 December
1978, $29,058,304; about 21.7% of central government
budget
Indian Ocean
1200 Kilometers
i. 1200 Miles
Boundary representation is
not necessarily authoritative
503987 1-79
Declassified and Approved For Release 2012/09/02
nay
Ulaanbaatar, te
Mongolia rm
a
atP ei-ching
Pao-t''oue (Pekin
Lan-chou,','bc22dd77ea71adae5bf9797fac938b4fcca78001043978f0c4d746d556f079a3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ed8e7a696eb2ad29e4afbde53201ba04bad707966480b45044f40f2cd4a86e6',1972,'MT','Malta','communications',291,'LAND
313 km?; 45% agricultural, negligible amount forested,
remainder urban, waste, or other (1965)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Mediterranéan Sea
(See reference map 1V}
WATER
Limits of territorial waters (claimed): 6 nm (fishing 20
nm)
Coastline: 140 km
Highways: 1,271 km total; 1,159 km paved (asphalt), 77
km crushed stone or gravel, 35 km improved and
unimproved earth
Ports: 1 major (Valletta), 2 minor
Civil air: 4 major transport aircraft (including 3 leased in)
133
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MALTA/MARTINIQUE
Airfields: 4 total, 2 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,489 m; 1 seaplane station
Telecommunications: modern automatic telephone sys-
tem centered in Valletta; 62,200 telephones (19.6 per 100
popl.); 1 TV, 5 AM, and 4 FM stations; 1 coaxial submarine
cable
DEFENSE FORCES
Military manpower: males 15-49, 79,000; 64,000 fit for
military service
Supply: has received 2 patrol boats, small arms, and
mortars from Libya; vehicles and engineer equipment from','5142d330eedeb65ec96a27d1a76819e02ad0914b58eb6595421af4374111c0e2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29acf90b01c020b32ecf51ce113d73d2c37eb0c05142ede41dcf5b4895931896',1972,'MQ','Martinique','communications',295,'(See reference map {1}
LAND ,
1,100 km?; 31% cropland, 16% pasture, 29% forest, 24%
wasteland, built on
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 290 km
Railroads: none
Highways: 1,606 km total; 1,200 km paved, 400 km
gravel and earth
‘Ports: 1 major (Fort-de-France), 5 minor
Civil air: 1 major transport aircraft (leased in)
Airfields: 3 usable; 1 with permanent-surface runway; 1
with runway 2,440-3,659 m; 1 seaplane station
Telecommunications: domestic facilities inadequate;
34,700 telephones (10.2 per 100 popl.); inter-island VHF and
UHF radio links; COMSAT ground station; ] AM, 1 FM, and
5 TV stations','32dbfbdf3ca8bf1592f03a6db2b40383d35a6a035550e29b9b6eb9dc4e6dec03','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be849bfaf557b19b42b17ee2c3c630785a01601085de7f82ad868de4876aee4e',1972,'MR','Mauritania','communications',299,'’
LGERIA
WESTERN
SAHARA
Atlantic
Ocean
(See reference map Vi}
LAND
1,085,210 km’; less than 1% suitable for crops, 10%
pasture, 90% desert
Land boundaries: 5,118 km
WATER
Limits of territorial waters (claimed): 30 nm (fishing, 36
nm)
Coastline: 754 km
Railroads: 650 km standard gage (1.435 m), single track,
privately owned
- Highways: 6,090 km total; 558 km paved; 607 km gravel,
crushed stone, or otherwise improved; 4,925 km unimproved
Inland waterways:. 800 km
Ports: 1 major (Nouadhibou), 2 minor
.Civil air: 7 major transport aircraft
Airfields: 29 total, 29 usable; 9 with permanent-surface
runways; 4 with runways 2,440-3,659 m; 13 with runways
1,220-2,439 m; 1] seaplane station
Telecommunications: poor system of fragmentary open-
wire lines, a minor radio-relay link, and radiocommunica-
tions stations; 2,000 telephones (0.1 per 100 popl.); 1 AM, no ,
FM or TV stations
DEFENSE FORCES ‘
Military manpower: males 15-49, 356,000; 171,000 fit for
military service; conscription law not implemented
136
Supply: primarily dependent on France; has also received
material from Algeria, Morocco, U.K., and Spain
Military budget: for fiscal year ending 31 December 1976
(revised), $29 million; 22% of central government ‘budget
{See reference map Vij
LAND
409,200 km?; about 32% arable and grazing land, 17%
forest and esparto, 51% desert, waste, and urban
Land boundaries: 1,996 km
WATER
Limits of territorial waters (claimed): 12 nm (200 nm
exclusive economic zone)
Coastline: 1,835 km
Railroads: 1,756 km standard gage (1.435 m), 161 km
double track; 708 km electrified
Highways: 55,970 km total; 24,700 km . bituminous
treated, 4,000 km gravel, crushed stone, and improved earth,
27,270 km unimproved earth
142
Pipelines: 362 km crude oil; 491 km (abandoned) refined
products; 24] km natural gas
Ports: 8 major (including Spanish-controlled Ceuta and
Melilla), 10 minor
Civil air: 2] major transport aircraft
Airfields: 78 total, 77 usable; 26 with permanent-surface
_ runways; 2 with runways over 3,660 m, 13 with runways
2,440-3,659 m, 29 with runways 1,220-2,439 m; 4 seaplane
stations : , :
Telecommunications: good system by African standards
composed of open-wire. lines, coaxial, multiconductor and
submarine cables and radio-relay links; principal centers
Casablanca and Rabat, secondary centers Fes, Marrakech,
Oujda, Sebaa Aioun, Tangier and Tetouan; 199,000 tele-
phones (1.1 per 100 popl.); 25 AM, 4 FM, 27 TV stations; 3
submarine cables; 1° Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,978,000; 2,373,000 fit
for military service; about 219,000 reach military age (18)
annually; limited conscription
{See reference map Vi)
LAND
266,770 km?, nearly all desert
Land boundaries: 2,086 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 1,110 km
Railroads: none
Highways: 6,100 km total; 500 km bituminous treated;
5,600 km unimproved earth roads and tracks
Ports: 2 major (El Aaiun, Villa Cisneros), 2 minor
Civil air: approximately 3 major transport aircraft
Airfields: 13 total, 12 usable; 3 with permanent-surface
runways; 1. with runway over 3,660 m; 5 with runways
1,220-2,489 m
Telecommunications: telephone and telegraph poor;
1,000 telephones (0.7 per 100 popl.); 2 AM, no FM, 5 TV
stations
" WESTERN SAMOA
LAND |
2,849 km?; oud of 2 large islands of Savai’i and
Upolu and several smaller islands, including Manono and
Apolima; 65% forested, 24% cultivated, 11% industry, waste,
or urban
WATER
Limits of territorial. waters (claimed): 12 nm ¢
Coastline: 403 km .
224
2, WESTERN
° SAMOA
aCape Verde ''e Nouakchott
2 0','10743796c1c8154138ad1d5517e3fd665a490132f201faa3f9888b7ed25e8667','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9be30e6d560a5f339ab5352c8b9d5b235b1a38ac90dcbe9a486e1dd14b2c8536',1972,'MU','Mauritius','communications',303,'"MADAGASCAR
REUNION
/ndian Ocean
(See reference map Vi}
LAND
1,856 km* (excluding dependencies); 50% agricultural,
intensely cultivated; 39% forests, woodlands, mountains,
river, and natural reserves; 3% built-up areas; 5% water
bodies, 2% roads and .tracks, 1% permanent wastelands
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 177 km
Highways: 1,786 km total; 1,636 km paved, 150 km earth
Civil air: 1 major transport aircraft
Ports: 1 major (Port Louis)
Airfields: 6 total, 5 usable; 1 with permanent surface
runway; 1 with runway 2,440-3,659 m
Telecommunications: ‘radio telegraph service with Re-
union, Malagasy Republic, Seychelles, Zanzibar, and other
places in Africa; 1 AM, no FM, and 4 TV stations; 26,500
telephones (2.9 per 100 popl.); 1 Indian Ocean Comsat
station :
DEFENSE FORCES
Military manpower: males 15-49, 238,000; 124,000 fit for
military service :
Military budget: for fiscal year ending 30 June 1973,
$3,981,038; 6.5% of central government budget
= e o
REUNION
Ocean
(See reference map Vi}
_ Railroads: none
Highways: 1,983 km total; 1,683 km paved, 300 km
gravel, crushed stone, or stabilized earth
Ports: 1 major (Port des Galets)
Civil air: no major transport aircraft
Airfields: 7 total, 7 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: adequate system for needs; fairly
modern open-wire lines and radiocommunication stations;
principal center Saint-Denis; radiocommunication to Co-
moros Islands, France, Madagascar, and Mauritius; 32,000
telephones (6.5 per 100 popl.); 1 AM, 1 FM, and 2 TV
stations; 1 Indian Ocean COMSAT station.
DEFENSE FORCES
Military manpower: military age males included with','70045e99a5adc7597bc8c40ee494eadc723d9336d6a41acd9a6ddff3cece3019','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4d46cfa8f3f36cc568bdf3545216acda3f1760444a92f614b7a66bc028b3d17',1972,'MC','Monaco','communications',307,'LAND.
1.5 km?
Land boundaries: 3.7 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4.1 km
Mediterranean Sea
(See reference map lV) °
‘Railroads: 1.6 km of 1.485 m gage
Highways: none; city streets
Ports: 1 minor
. Civil air: no major transport aircraft
Airfields: none
Telecommunications: served by the French communica-
tions system; automatic telephone system with about 23,700
telephones (96.5 per 100 popl.); 2 AM, 4 FM, and 3 TV
stations
DEFENSE FORCES
‘France responsible for defense','e414861a88937b0940bd3ab71e3d9a640188e1be3a79b9fbd95b3c4cb4dccdb8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dd4060d56604eebb42dff5eb6ad42cb984d8abd0dd6d94da25e532d970fbbd4',1972,'MN','Mongolia','communications',311,'2
Ulaanbaatar *
(See reference map Vil}
LAND
1,564,619 km?; almost 90% of land area is pasture or desert
wasteland, varying in usefulness, less than 1% arable, 10%
forested
’ Land boundaries: 8,000 km
Railroads: 1,516 km; all broad gage (1.524 m) (1976)
Inland waterways: 616 km of principal routes (1975)
, Freight carried: rail—8.1 million metric tons,. 2,718
million metric ton/km (1976); highway—15.2 million metric
tons, 1,060 million metric ton/km (1976); waterway—0.05
million metric tons, 0.04 billion metric ton/km (1975).
DEFENSE FORCES
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31 December
1977, 405 million tugriks, 12% of total budget','e8a3a24d1057fba92df95bff0d8651a6223e405e15f73ae9af5197d26cde4804','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2397770990d1d3ac3426785fffa240fac76c531a2d0f264971ac37f6c8faeeae',1972,'PT','Portugal','communications',315,'Atlantic
SAHARA
(See reference map {V}
LAND
Metropolitan Portugal: 94,276 km*, including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and other
Land boundaries: 1,207 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm); 200 nm exclusive economic zone
Coastline: 860 km (excludes Azores (708 km) and
Madeira (225 km))
Railroads: 3,593 km total: state-owned Portuguese Rail-
road Co. (CP) operates 2,807 km 1.665-meter gage (406 km
electrified and 426 km double track), 760 km meter-gage
_ (1.000 m); 26 km 1.665-meter gage double track, electrified,
privately-owned ;
Highways: 29,773 km total; 17,703 km_ bituminous,
bituminous treatment, concrete and stoneblock; 11,587 km
gravel and crushed stone; 483 km improved earth; plus an
additional 16,898 km of unimproved earth roads (motorable
tracks)
Inland waterways: 820 km navigable; relatively unimpor-
tant to national economy, used by shallow-draft craft limited
to 297 metric ton cargo capacity
Pipelines: crude oil, 11 km
Ports: 6 major, 34 minor
Civil air: 81 major transport aircraft (including 2 leased
out and 1 leased in)
Airfields (including Azores and Madeira Islands): 50
total, 48 usable; 3] with permanent-surface runways; 1 with
runway over 3,660 m, 11 with runways 2,440-3,659 m, 9
with runways 1,220-2,439 m; 6 seaplane stations
Telecommunications: facilities are generally adequate;
1.19 million telephones (12.9 per 100 popl.); 39 AM, 34 FM,
and 42 TV stations; 3 submarine coaxial cables; 2 Atlantic
Ocean satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 2,192,000; 1,781,000 fit
for military service; average number reaching age (20)
annually, about 85,000
Military budget: for fiscal year ending 3] December
1977, $575.8 million; about 14% of central government
budget','543453f72cde792eec1a700b77b97c39b6cd9d46729dd583498de729b7e77094','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f4d068c808ef248c7554be742f668ba7b46c823f159747b0c22d9163e3aa342',1972,'MZ','Mozambique','communications',316,'SOUTH O
AFRICA Indian Qcean .
{See reference map Vi}
Land .
786,762 km*; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
Land boundaries:. 4,627 km
WATER
Limits of territorial waters (claimed): 12 nm (200 nm
exclusive economic zone)
Coastline: 2,470 km
Railroads: 3,161 km total; 3,020 km 1.067-meter gage;
141 km narrow gage (0.750 m)
Highways: 26,477 km total; 4,322 km paved; 607 km
improved earth; 21,548 km unimproved earth, unconnected
Inland waterways: approx. 3,750 km of navigable routes
Pipelines: ¢rude oil, 306 km (not operating)
Ports: 3 major (Maputo, Beira, Nacala), 2 significant.
minor :
Civil air: 7 major transport aircraft (including 1 leased
out) :
Airfields: 325 total, 313 usable; 29 with permanent-sur-
face runways; 6 with runways 2,440-3,659 m; 35 with
runways 1,220-2,439 m
Telecommunications: fair system of troposcatter, open-
wire lines, and radiocommunications; principal centers
Maputo, Beira, and Nampula; 52,200 telephones (0.5 per 100
popl.); 10 AM, 2 FM, no TV «stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,192,000; 1,128,000 fit
for military service
Supply: mostly from the USSR and PRC, and to a lesser
extent from other Communist countries and Portugal
Military budget: for fiscal year ending 31 December
1978, $82.6 million; 21.7% of central government budget
a hb
SOUTH
AFRICA
{See reference map Vi}
LAND
17,364 km?; most of area suitable for crops or pastureland
Land boundaries: 485 km
Railroads: 222 km 1.067-meter gage, single track
Highways: 2,653 km total; 224 km paved, 1,114 km
crushed stone, gravel, or stabilized soil, and 1,315 km
improved earth
Civil air: 2 major transport aircraft
Airfields: 27 total, 21 usable; 1 with runway 1,220-
2,439 m :
Telecommunications: system consists of a few open-
wire lines and low-powered radiocommunication stations;
198
Mbabane is the center; 8,200 telephones (1.6 per 100 popl.);
1 AM, 2 FM, 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 109,000; 63,000 fit for
military service','128dfba7d53f17f8531ec465b09e7b5ddc7f41af55708e89e82de6c8829eeeaa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94c1305679dc7c776701053ea09c3cede2d5638c990101e4bb709d47d98d72cc',1972,'NA','Namibia','communications',320,'(South-West Africa)
LAND
823,620 km?; mostly desert except for interior plateau and
area along northern border
Land boundaries: 3,798 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 1,489 km
Railroads: 2,340 km 1.067-meter gage, single track
Highways: 33,800 km; 3,800 km paved, remainder gravel,
remainder earth roads and tracks
Ports: 2 major (Walvis Bay and Luderitz)
Civil air: 4 major transport aircraft (registered in South
Africa)
Airfields: 113 total, 84 usable; 13 with permanent-surface
runways; ] with runway over 3,660 m; 3 with runways
2,440-3,659 m, 33 with runways 1,220-2,439 m
Telecommunications: sparse system of open wire and
radio relay routes; out-lying areas connected by radiocom-
munication; Windhoek is the only major center; 46,400
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
An mat An Gi
1
AA
arg
‘ee
Rh eae Ae a Sk dee ew Re, A a a ee a Se
a
RAM AR AA
JAR AR AR_ARAA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NAMIBIA/NAURU/NEPAL
telephones (6.2 per 100 popl.); 1 FM, no AM and no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, about 218, 000; about
129,000 fit for military service
Defense is responsibility of Republic of South Africa','ed04fd45555b1a0219c973f6cf00f549ee78f854973a29be7e867a3b874aa16a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36e3e3ad85340c1c0af10f2b8b1743fc7397c7f1de0937014ec2f6afcfddcdb2',1972,'NP','Nepal','communications',324,'LAND
141,400 km’; 16% agricultural area, 14% permanent
meadows and pastures, 38% alpine land (unarable), waste, or
urban; 32% forested
145
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Bay
of Bengal
{See reference map Vil}
Land boundaries: 2,800 km
Railroads: 63 km (1977), all narrow gage (0.762 m); all in
Terai close to Indian border; 10 km from Raxaul to Biranj is
government owned
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Fy vr i ew Fe Vv ere eV ee er OTR RE TOE YELLS OOP lls lClCUDOUUCOCUN ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NEPAL/NETHERLANDS
Highways: 4;1386 km ‘total; 1,751 km paved, 556 km
gravel or crushed stone, 1,829 km improved and unim-
proved earth; additionally 322 km of seasonally motorable
tracks
Civil air: 5 major transport aircraft
Airfields: 52 total, 51 usable; 5 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 7 with runways
1,220-2,439 m .
Telecommunications: poor telephone and_ telegraph
service; good radiocommunication and broadcast service;
international radiocommunication service is poor; 14,000
telephones (0.1 per 100 popl.); 8 AM, no FM, and no TV
stations
DEFENSE FORCES :
Military manpower: males 15-49, 3,100,000; 1,612,000 fit
for military service; 145,000 reach military age (17) annually
Military budget: for fiscal year ending 14 July 1979,
$16.4 million; 5.2% of central government budget','f28ace303cd845e5243e68f7ecc13c4d6aa0ccfb002b71d03bf9964e366776c1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4193ecbba39b72c3130d0933727a4efc7e9898fc377891cdf04576fa2cd212c',1972,'NL','Netherlands','communications',328,'UNITED
KINGDOM
{See reference map 1V}
LAND
33,929 km*; 70% cultivated, 5% waste, 8% forested, 8%
inland water, 9% other
Land boundaries: 1,022 km
WATER .
Limits of territorial waters (claimed): 3 nm (fishing, 12
nm)
Coastline: 451 km
Railroads: 2,979 km standard gage (1.435 m); 2,813 km
government-owned (NS), 1,638 km electrified, 1,556 km
double track; 166 km _ privately-owned
Highways: 104,480 km total; 86,354 km paved (including
1,839 km of limited access, divided highways); 18,126 km
gravel, crushed stone
Inland waterways: 6,340 km, of which 35% is usable by
craft of 900 metric ton capacity or larger
Pipelines: 418 km crude oil; 965 km refined products;
4,489 km natural gas
Ports: 8 major, 5 minor
Civil air: 97 major transport aircraft (including 15 leased
out and 4 leased in)
Airfields: 29 total, 28 usable; 16 with permanent-surface
runways; 13 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: highly developed, well maintained,
and integrated; extensive system of multiconductor cables,
supplemented by radio-relay links; 5.41 million telephones
(39.2 per 100 popl.); 6 AM, 19 FM, and 16 TV stations; 12
coaxial submarine cables; 1 Atlantic Ocean and 1 Indian
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,564,000; 3,197,000 fit
for military service; average number reaching military age
(20) annually 120,000
Military budget: for fiscal year ending 31 December
1978, $4.232 million; about 10% of central government
budget
NETHERLANDS ANTILLES
Atlantic Ocean
Eb
NETHERLANDS .
Caribbean ANTILLES ~
Sea .','e2978f7799d21ffadd6d768d749def60e5184121f21bf82e6e104e4b0261427c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec57fd7562fa64edba9e8097c98bf3353174f0c00b3af7dd57de82acab21012e',1972,'NZ','New Zealand','communications',332,'LAND
268,276 km?; 3% cultivated, 50% pasture; 10% parks and
reserves; 20% waste, water, etc., 1% urban, 16% forested; 4
principal islands, 2 minor inhabited islands, several minor
uninhabited islands
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: about 15,134 km','111075223ef47efb52423e061355261ded1ba6a7ecab78d3f7e6933102e0fc85','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b7b3a04631ffa6ef177d69bfb5da7f9e1ac54f750bdfbfa4c8a27855be42441',1972,'NI','Nicaragua','communications',339,'Railroads: 318 km 1.067-meter gage, government owned
Highways: 18,150 km total; 1,550 km paved, 7,200 km
otherwise improved, 9,400 km unimproved
Inland waterways: 2,220 km, including 2 large lakes
Pipelines: crude oil, 56 km
. Ports: 4 major (Corinto, Puerto Cabezas, Puerto Somoza,
San Juan del Sur), 6 minor :
. Civil air: 12 major transport aircraft (including 2 leased
in)
Airfields: 426 total, 404 usable; 8 with permanent-surface
runways; 10 with runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: low-capacity wire and radio-relay
network; connection into Central American microwave. net;
satellite ground station; 55,800 telephones (2.5 per 100
popl.); 85 AM, 30 FM, and:7 TV -stations
154
DEFENSE FORCES
Military manpower: males 15-49, 507,000; 313,000 fit for
_military service; 26,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1978, $56.2 million for the Ministry of Defense, including
civil functions (e.g., police and civil air); 13% of central
government budget ,
{See reference map Vi}
LAND
1,266,510 km*; about 3% cultivated, perhaps 20% some-
what arable, remainder desert
Land boundaries: 5,745 km','5bb1302116d954d4c015b80e632810e956e21d1ddf084e9bdf4d2937fc33ca05','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('015c85c84a6239eae0a97d8811a02e915067179cf6be0148c53d723aa546e8b9',1972,'NE','Niger','communications',343,'Railroads: none
livestock; ©
Highways: 7,582 km total; 1,759 km bituminous, 2,79
km gravel, 3,082 km unimproved earth :
Inland waterways: Niger River navigable 300 km from
Niamey to Gaya on the Benin frontier from mid-December
through March
Ports: Niger landlocked; outlet to sea is Cotonou, Benin
Civil air: 3 major transport aircraft
Airfields: 66 total, 62 usable; 5 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 18 with runways
1,220-2,439 m
Telecommunications: sparse system of open-wire lines,
radio-relay links, and small radiocommunications stations;
principal telecommunication center Niamey; 8,000 tele-
phones (0.2 per 100 popl.); 10 AM stations, no FM, and 1 TV
‘Station; 1 Atlantic Ocean Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 1,105,000; 593,000 fit
for, military service; about 50,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1978, $16.8 million; about 9.3% of central government
budget','3f08be2f0fb747baf2c8ee5c9ad2f82606d4cf73a996c39028edd1692a120d99','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ef16c1fa6a84afb64eacd150d6c12401e2a2634af4cb4ade6961aa638214bac',1972,'NG','Nigeria','communications',344,'(See reference map VI)
LAND ;
924,630 km*; 24% arable (13% of total land area under
cultivation), 35% forested, 41% desert, waste, urban, or other
Land boundaries: 4,034 km
WATER :
Limits of territorial waters (claimed): 30 nm
Coastline: 853 km
155
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Railroads: 3,505 km 1.067-meter gage
Highways: 89,318 km total 15,300 km paved (mostly
bituminous surface treatment); remainder laterite, gravel,
crushed stone, improved earth ;
Inland waterways: 8,575 km consisting of Niger and
Benue rivers and smaller rivers and creeks; additionally,
Kainji Lake has several hundred miles of navigable lake
routes
Pipelines: 1,207 km crude oil; 97 km natural gas; 5 km
refined products
Ports: 2 major (Lagos/Apapa, Port Harcourt), 10 minor
Civil air: 89 major transport aircraft (including 6 leased
in)
Airfields: 83 total, 79 usable; 17 with permanent-surface
runways; 7 with runways 2,440-3,659 m, 22 with runways
1,220-2,439 m ,
Telecommunications: above average system composed of
tadio-relay links, open-wire lines, and radiocommunication
stations; principal center Lagos, secondary centers Ibadan
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ie ain i i a ae
eT ee ee ee ee ee ee Oe. a ee ee ee a ee eT ee ee a eT Ne. ee ee en a ee ae ee we
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NIGERIA/NORWAY
and Kaduna; 121,000 telephones (0.2 per 100 popl.); 25 AM,
6 FM, and 9 TV stations; ‘1 Atlantic Ocean and 1 Indian
Ocean satellite station and 19 domestic stations
DEFENSE FORCES
Military manpower: males 15-49, 15,551,000; 8,895,000
fit for military service; average number reaching military
age (18) annually 716,000
'' Military budget: for fiscal year ending 3] March 1979,
$2.1 billion; about 16.8% of central government budget','31884d99b1a21af7f1706c505cf10dd1845ff63bf3cd5bcb6b28cb595faa5ac0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d4f399a9e939730657e6d0ef6e5265d4a78ec8e8fb8bed20523aedc5ab862fd',1972,'NO','Norway','communications',348,'Norwegian
(See reference map iV}
LAND
Continental Norway, 323,750 km*; Svalbard, 62,160 km?;
Jan Mayen, 373 km*; 3% arable, 2% meadows and pastures,
21% forested, 74% other
Land boundaries: 2,579 km
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: mainland 3,419 km; islands 2,413 km (excludes
Jong fjords and numerous small islands and minor indenta-
tions which total as much as 16,093 .km_ overall)
Railroads: 4,257 km standard gage (1.435 m); Norwegian
State Railways (NSB) operates 4,241 km (2,440 km
electrified and 91 km double track); 16 km privately-owned
and .electrified
Highways: 78,116 km total; 17,699 km concrete and
bitumen; 19,277 km bituminous treated; 41,140 km gravel,
crushed stone, and earth -
Inland waterways: 1,577 km; 1.5-2.4 m draft vessels
maximum
Pipelines: refined products, 53 km
Ports: 9 major, 69 minor
Civil air: 49 major transport aircraft
Airfields: 101 total, 101 usable; 52 with permanent-
surface runways; 12 with runways 2,440-3,659 m, 15-with
runways 1,220-2,439 m; 20 seaplane stations ;
158
Telecommunications: high-quality domestic and interna-
tional telephone, telegraph, and telex service; 1.48 million
telephones (36.6 per 100 popl.); 40 AM, 357 FM, and 740 TV
stations; 5 coaxial submarine ‘cables; 2 domestic satellite
stations
DEFENSE FORCES
Military manpower: males 15-49, 938,000; 763,000 fit for
military service; average number reaching military age (20)
annually, 31,000
Military budget: proposed for fiscal year. ending 31
December 1979, $1.4 billion; about 9.3% of proposed central
government budget
WEMEN YEMEN
is) A)
Arabian Sea
(See reference map V)
LAND
About 212,380 km?; negligible amount forested, remain-
der desert, waste, or urban
Land boundaries: 1,384 km
WATER .
Limits of territorial waters (claimed): 12 nm (fishing 50
nm) ;
Coastline: 2,092 km
Highways: 2,816 km total; 5 km bituminous surface,
2,811 km motorable track ,
Pipelines: crude oil 370 km; natural gas 200 km
Ports: 1 major (Qaboos), 3 minor
Civil air: 21 major transport aircraft
Airfields: 164 total, 180 usable; 4 with permanent-surface
runways; ] runway over 3,660 m, 5 with runways
2,440-3,659 m, 46 with runways 1,220-2,439 m
Telecommunications: fair system of open-wire, radio-re-
lay and radiocommunications stations; 2 satellite ground —
stations; 7,300 telephones (1.3 per 100 popl.); 3 AM, no FM,
2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 124,000; 72,000 fit for
military service','0a8052c8add98b0b8ec2960497c6858ec81eca04c215e721f04c1bae77557589','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03fbbfbe9350e4a68f15d3bc46e4085e6dfadd946c01eafa9f63907fded908d8',1972,'PK','Pakistan','communications',352,'Arabian Sea
{See reference mep Vil}
LAND
803,000 km? (includes Pakistani part of Jammu-Kashmir),
40% arable, including 24% cultivated; 23% unsuitable for
cultivation; 34% unreported, probably mostly waste; 3%
forested
Land boundaries: 5,900 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; plus right to establish 100 nm conservation zones
beyond territorial sea); 200 nm exclusive economic zone
Coastline: 1,046 km
Railroads: 8,565 km total (1977); 446 km meter gage.
(1.000 m), 7,507 km broad gage (1.676 m), 612 km
narrow gage (0.762 m); 1,022 km double track; 286 km
electrified; government-owned
Highways: 70,424 km total (1977); 19,296 km paved,
13,019 km gravel, 1,854 km improved earth, 36,255 km
unimproved earth
Inland waterways: 1,850 km
Pipelines: 230 km crude oil; 1,931 km natural gas
Ports: 1 major, 5 minor
Civil air: 27 major transport aircraft
Airfields: 108 total, 102 usable; 63 with permanent-sur-
face runways; 1 with runway over 3,660 m, 25 with runways
2,440-3,659 m, 47 with runways 1,200-2,439 m
Telecommunications: good international radiocommuni-
cation service over CENTO microwave and intelsat satellite;
domestic radiocommunications poor; broadcast service very
good; 300,000 (est.) telephones (0.4 per 100 popl.); 27 AM,
no FM, 16 TV stations, and 4 repeaters; 1 ground satellite
station
DEFENSE
Military manpower: males 15-49, 17,054,000; 10,136,000
fit for military service; 858,000 reach military age (17)
annually
Military budget: for fiscal year ending 30 June 1978, $996
million; about 28.4% of central government budget','ea8e8b9ebcb09fb3007d0e31bfa2faeea83895ac748970ad4852cfb46801af0f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('762201870af226c3162245369bed5263f8bcde2d15d449ca92e7a29cd7455c09',1972,'PA','Panama','communications',356,'Land boundaries: 630 km
WATER
Limits of territorial waters (claimed): 200 nm (continen-
tal shelf including sovereignty over superjacent waters)
Coastline: 2,490 km :
Railroads: 249 km total; 77 km 1.524-meter gage, 172 km
0.914-meter gage ,
Highways: 7,700 km total; 2,500 km paved, 2,600 km
gravel or crushed stone, 2,600 km improved and: unim-
proved earth; Panama Canal Zone 240 km; 230 km paved
10 km gravel
>
Inland waterways: 800 km navigable by shallow draft _
vessels; 82 km Panama Canal
Pipelines: refined products, 96 km
Ports: 2 major (Cristobal/Colon/Coco Solo, Balboa/ .
Panama City), 10 minor
Civil air: 19 major transport aircraft (including 2 leased
in)
Airfields: (including Canal Zone) 152 total, 152 usable; 36
with permanent-surface runways; 2 with runways
2,440-3,659 m; 16 with runways 1,220-2,439 m; 2 seaplane
stations
Telecommunications: domestic and international telecom
facilities well developed; connection into Central American
microwave net; COMSAT ground station; 155,200 tele-
phones (9.0 per 100 popl.); 90 AM, 30 FM, and 13 TV
stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 425,000; 293,000 fit for
military service; no conscription
Military budget: for fiscal year ending 31 December
1976, $32.6 million; about 10% of central government
budget
Canal Zone
_ (U.S. juris)
Re
Venezuela
4 Bogota','ca7c6fbe7f344283f14b630ecf2dc2d182311c56ad6258c9774e112987fac129','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('215370bc9dafc42ce91f2286f8e18e8803824ecaf2d9bdc15ac658b3a212201d',1972,'PY','Paraguay','communications',360,'LAND
406,630 km?*; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other
Land boundaries: 3,444 km
BOLIVIA BRAZIL
d Atlantic Ocean -
(See reference map tit}
Railroads: 1,043 km total; 487 km standard gage (1.435
164
m), 186 km meter gage (1.00 m), 470 km various narrow
gage (privately owned)
Highways: 8,800 km total; 1,100 km paved, 7,700 km
earth
Inland waterways: 3,100 km
Ports: 1 major (Asuncion), 9 minor (all river)
Civil air: 4 major transport aircraft
Airfields: 953 total, 814 usable; 1 with permanent-surface
runway; 1 with runway 2,440-3,659 m, 16 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: local telecom facilities in Asuncion
good, intercity microwave net; 41,600 telephones (1.5 per
100 popl.); 25 AM, 9 FM stations, and 1 TV station; 1
Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 633,000; 483,000 fit for
military service; average number currently reaching military
age (17) annually, 33,000 ,
‘Military budget: for fiscal year ending 31 December
1978, $41.2 million; about 14.7% of central government
budget
Pacific
(See reference map til}
LAND
1,284,640 km? (other estimates range as low as 1,248,380
km?); 2% cropland, 14% meadows and pastures, 55%
forested, 29% urban, waste, other “>
Land boundaries: 6,131 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,414 km.','c590e9ccc0b1387e6ab5bac88c78b583e8822794fd6a05d33cb76e185914fd2b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff9c516f3e0d6a4e3513176b10fbfc84cec577d5988396ae3476e0731475ad3f',1972,'PE','Peru','communications',367,'Railroads: 2,148 km total; 1,776 km standard gage (1.435
m), 46 km 0.60-meter gage, 326 km 0.914-meter gage; 14 km
double track
Highways: 52,400 km total; 5,400 km paved, 9,900 km
gravel, 14,400 km improved earth, 22,700 km unimproved
earth
Inland waterways: 8,600 km of navigable tributaries of
Amazon River system and 208 km Lake Titicaca
Pipelines: crude oil, 730 km; natural gas and natural gas
liquids, 64 km
Ports: 7 major, 20 minor
Civil air; 29 major transport aircraft
Airfields: 305 total, 304 usable; 24 with permanent-sur-
face runways; 2 with runways over 3,660 m, 20 with
runways 2,440-3,659 m, 49 with runways 1,220-2,439 m; 3
seaplane stations
Telecommunications: fairly adequate for most require-
ments; new nationwide radio-relay system; 1 Atlantic Ocean
satellite station; 410,000 telephones (2.5 per 100 popl.); 200
AM, 7 FM, and 31 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 3,952,000; 2,664,000 fit
165
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
PERU/ PHILIPPINES
for military service; average number currently reaching
military age (20) annually, 175,000
Military budget: for fiscal year ending 31 December
1978, $254 million; about 11.4% of central government
budget','237a95e6f08697510e7e4ae25479edebbc62a56a705afa51688a018cf8818d89','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a5ecf2b9e3153f6627fb053593b29986013ccbb9586f965e96bbf6c8650eb32',1972,'PL','Poland','communications',368,'LAND
312,854 km*; 49% arable, 14% other agricultural, 27%
forested, 10% other
Land boundaries: 3,090 km
WATER
Limits of territorial waters (claimed): 3 nm (3 nm
contiguous zone claimed in addition to the territorial sea)
(fishing 12 nm)
Coastline: 491 km
PHILIPPINES /POLAND
(See reference map {V}
Railroads: 26,695 km total; 23,816 km standard gage
(1.435 m), 2,879 km other gage; 7,474 km double track;
6,308 km electrified; government owned (1977)
Highways: 305,863 km total; 65,000 km concrete, asphalt,
stone block; 98,000 km crushed stone, gravel; 142,863 km
earth (1977)
168
Inland waterways: 3,759 km navigable streams and
canals (1977)
Pipelines: 3,540 km for natural gas; 1,515 km for crude
oil; 322 km for refined products
Freight carried: rail—48] million metric tons (1977),
135.4 billion metric ton/km (1977); highway—2,039 million
metric tons, 40.3 billion metric ton/km (1977); waterway—
19.1 million metric tons, 3.0 billion metric ton/km;
approximately 1,650 waterway craft with 525,600 metric ton
capacity (1977)
Ports: 4 major (Gdansk, Gdynia, Szczecin, Swinoujscie), 6
minor (1977); principal inland waterway ports are Kozle,
Wroclaw, and Warsaw (1978)','a99588fc604c17659f0be5b27afb3f67b6d80ba4c8ca1e02b9a750f72a8b69e1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92c7478c637d893ce0e18ed8c298f62baf0c44ce2f22bdfd0c79003841ac6773',1972,'QA','Qatar','communications',375,'LAND
About 10,360 km?; negligible amount forested; mostly
desert, waste, or urban
Land boundaries: 56 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 563 km','217966ebc8b832c6e5ae17c7ed95c282f6d24ebb0166a19359b6336056336e76','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b26184a4c0c8383249888d24043b60d0693b342d1ca07e01892a7f25cd1f2ac2',1972,'RW','Rwanda','communications',377,'{See reference map Vi}
LAND
25,900 km*; almost all the arable land, about 1/3 under
cultivation, about 1/3 pastureland
Land boundaries: 877 km','8a62bfe3526526f505ef463279259a1e962bb6e584c6ec89dec510f3f64cdd54','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c6e5d2b4e855b61ff95a2f97f2bd1530c2e623aab1cdee8207eb3cf351e9c7c',1972,'AI','Anguilla','communications',381,'2
Co :
ST. CHRISTOPHER %
NEVIS ° ee
2
(See reference map Il}
LAND .
389 km?; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 193 km
Railroads: 57 km, narrow gage (0.760 m) on St. Kitts for
sugar cane
Highways: 300 km total; 100 km paved, 150 km otherwise
improved, 50 km unimproved. earth
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ST ATR
Ate PAR Le a Ue Re ee a
ATT Al A aA AA Ae. Ad.
a
AA RaaAA Asa RA aAR.AA OA AA,
Ce Se a ee ee Ee ee ee ee, ee er Te
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ST. CHRISTOPHER-NEVIS-ANGUILLA/ST. LUCIA
Ports: 3 minor (1 on each island)
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 3 with permanent-surface
runways; 1 with runway 1,220-2,439 m; 1 seaplane station
Telecommunications: good interisland VHF/UHF radio
connections and international link via Antigua; about 2,500
telephones (4.4 per 100 popl.); 8 AM and 5 TV stations
ST. LUCIA
Atlantic Ocean
nn
o
OOM.
REP.
oO
=>
Caribhean Sea %
: ° ST. LUCIA
Z|
(See reference map i)
LAND
616 km?; 50% arable, 3% pasture, 19% forest, 5% ‘unused
but potentially productive, 28% wasteland and _ built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 158 km
Railroads: none
Highways: 750 km total; 450 km paved; 300 km otherwise
improved
Ports: 1 major (Castries), 1 minor
Civil air; no major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways, 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m; 1 seaplane station
Telecommunications: fully automatic telephone system
with 6,600 telephones (5.8 per 100 popl.); direct radio-relay
link with Martinique; interisland tropospheric links to
Barbados and Antigua; 3 AM stations, 1 TV station
177
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ST. VINCENT/SAN MARINO
ST. VINCENT
Atlantic Ocean
REP.
oe A> o
(See reference map tl}
LAND
889 km? (including northern Grenadines); 50% arable, 3%
pasture, 44% forest, 8% wasteland and built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 84 km
Railroads: none ;
Highways: 600 km total; 300 km paved; 150 km otherwise
improved; 150 km unimproved earth
Ports: 1 major, 1 minor
Civil air: no major transport ‘aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface
runways, 1 with runway 1,220-2,439 m
Telecommunications: islandwide fully automatic tele-
phone system with 4,900 sets (4.8 per 100 popl.); VHF/UHF
interisland links to Barbados and the Grenadines; 2 AM
stations','88e72b890b6697f665a0ee607c48d08d060a576bc192397219489cb6e82f922f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4003fc26ae1725560571d3b084c05483d6e5ea06564ce939ee246384ccc2dc36',1972,'SM','San Marino','communications',385,'‘LAND
62 km?*; 74% cultivated, 22% meadows and pastures, 4%
built-on
Land boundaries:.34 km
Railroads: none
Highways: about 104 km
Civil air: no major transport aircraft
‘Airfields: none
Telecommunications: automatic telephone system serv-
ing 5,700 telephones (28.1 per 100 popl.); no radiobroadcast-
ing or television facilities
SAO TOME AND PRINCIPE -
- CAMEROON ,
Ak:
SAG TOME
ON EQUATORIAL','85bad307caa17b40ce62c631dd3e8883c5376b10262dbb2d01e651d160e9108a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82d698c183ba7d91869b27753bfdfaf6088ab36c397222e82115381b94238f24',1972,'SC','Seychelles','communications',389,'Indian Ocean
oe Vie toria
(See reference map Vij}
LAND
404 km*; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other (mainly
reefs and other surfaces unsuited for agriculture), 40 granitic
and 43 coral islands
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 12
nm)
Coastline: 491 km (Mahe Island 93 km)
Railroads: none
Highways: 215 km total; 145 km bituminous, 70 km
crushed stone or earth
Ports: 1 small port (Victoria)
Civil air: no major transport aircraft
Airfields: 7 total, 7 usable (on Praslin Island, Astove
Island, Bird Island, Mahe Island); with 1 permanent-surface
runway 2,440-3,659
Telecommunications: direct radiocommunications with
adjacent island and African costal countries; 3,900 tele-
phones (6.4 per 100 popl.); 2 AM, no FM, and no TV
stations; Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 14,000; 7,000 fit for
military service :
Supply: infantry-type weapons and ammunition from
Tanzania','eb89c0dc06cf02938ffc3e2092bf3561edb571440ab72b1ad81cdeb16366803e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f0d2c37429c8e1e9e83f841b7fbe833ae0423e511fb9079c572b06aa8911286',1972,'SL','Sierra Leone','communications',393,'GUINEET,
BISSAU
A tlantic
Ocean
(See reference map Vi}
LAND
72,261 km*; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
Land boundaries: 933 km
WATER
Limits of territorial waters (claimed): 200° nm
Coastline: 402 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a ag Sg "ggg a I gg age" =
a i i a cn a cn i i a A at el te es i tin a i i ni al
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Railroads: about 84 km narrow gage (1.067 m) jaiuataly
owned mineral line operated by the Sierra Leone Develop-
ment Company
Highways: 7,111 km total; 1,230 km biganiious 507 km
laterite (some gravel), and 5,374 km improved earth
Inland waterways: 800 km; 600 km navigable year-round
Ports: 1 major (Freetown), 2 minor
Civil air: no major transport aircraft 7
Airfields: 16 total, 16 usable; 6 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 5 with runways
1,220-2,489 m; 1 seaplane station
Telecommunications: telephone and tetegraph are inade-
quate; 15,000 telephones (0.5 per 100; popl.); 2 AM stations,
no FM, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 740,000; 357,000 fit for
military service; no conscription
'' Military budget: for year ending 30 June 1978,
$11,379,310 (excluding procurement funds); 8.5% of central
government budget —
185
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','8671aba31a265a314a6ebb3076eb51820a32b22bb4b4bf035ca40330ca5cca7d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b4dbf39fd8a6ec36e35a72601b4c8986361187b313a39438c0269a2a0d14d26',1972,'SB','Solomon Islands','communications',399,'SOLOMON
‘sy % ISLANDS
Honiaraty %
Coral Sea
‘AUSTRALIA ; - Pacific |
’ Ocean
(See reference map Viil}
NOTE: This newly independent (as of 7 July 1978)
archipelagec nation includes southern Solomon Islands,
primarily Guadalcanal, Malaita, San Cristobal, Santa Isabel,
* Choiseul. Northern Solomon Islands constitue part of Papua
New Guinea.
LAND |
About 29,785 km*
WATER
Limits of territorial waters: 3 nm (fishing 200 nm)
Coastline: about 5,313 km
Railroad: none
Highways: 834 km total; 241‘km sealed or all-weather
Inland waterways: none ;
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 24 total, 22 usable; 1 with permanent-surface
runway; 5 with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: 3 AM broadcast, no FM, and no
TV stations; 10,000 radio receivers, 1,726 telephones, no TV
187
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SOLOMON ISLANDS/SOMALIA/SOUTH AFRICA
sets; international connections with London, England, via
high frequency radio','ec66c402c1e5143f1df3ede23f8a7b86b08b9a90c03531eb82616abba1176877','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8155c972c5ef3ea8e1c6b846d38b69618d5422d34f21a33c1dadb0419a6b2fb2',1972,'SO','Somalia','communications',403,'(See reference map Vi}
LAND
‘637,140 km?; 13% arable (0.3% cultivated), 32% grazing,
14% scrub and forest, 41% mainly desert, urban, or other
Land boundaries: 2,263 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 3,025 km
Railroads: none
Highways: 13,540 km total; 1,900 km paved, 770 km
crushed stone, gravel, or stabilized soil, 10,870 km improved
or unimproved earth (est.)
Ports: 3 major (Mogadiscio, Berbera, Chisimaio)
Civil air: 6 major transport aircraft *
Airfields: 55 total, 49 usable; 6 with permanent-surface
runways, 2 with runways over 3,660 m; 4 with runways
2,440-3,659 m; 15 with runways 1,220-2,439 m
~ Telecommunications: _telephone poor, telegraph fair;
6,000 telephones (0.2 per 100 popl.); 2 AM; no FM, 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, 788,000; 439,000 fit for
military service; no conscription
Military budget: for fiscal year ending 31 December
1976, 34,650,357; 20.3% of central government budget','d1dcf8631252100c9fdf04cea7dcf58fa8024a0a60ef4facd6b92c9d5004da81','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58ffb87519025dc9d5ab497dd662babfb050c0441abd7c849cf3f70bdf4e216a',1972,'ES','Spain','communications',410,'Railroads: 15,975 km total; Spanish National Railways
(RENFE) operates 13,509 km 1.668-meter gage, 4,828 km
electrified and 2,162 km double track; FEVE (government-
owned narrow gage railways) operates 1,676 km, of
predominantly meter gage (1.000 m) and 310 km electrified;
privately-owned railways operate 790 km, of predominantly
‘meter gage (1.000 m), 245 km electrified and 56 km double
track
Highways: 139,350 km total; 78,585 km national—6,810
km bituminous, concrete, stone block; 56,650 km bituminous
treated; 15,125 km crushed stone; the remaining 60,765 km
are classified as provincial or local roads
Inland waterways: 1,045 km; of minor importance as.
transport arteries and contribute little to economy
Pipelines: 386 km crude oil; 1,030 km refined products;
98 km natural] gas
Ports: 23 major, 150 minor
Civil air: 174 major transport aircraft (including 1 leased
in)
Airfields (including Balearic and Canary Islands): 94
total, 86 usable; 51 with permanent-surface runways; 4 with
runways over 3,660 m, 19 with runways 2,440-3,659 m, 32
‘with runways 1,220-2,439 m; 4 seaplane stations
Telecommunications: generally adequate, modern facili-
ties; 8.6 million telephones (23.9 per, 100 popl.); 180 AM, 250
FM, and 791 TV stations; 14 coaxial submarine cables; 4
communication satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 8,577,000; 6,607,000 fit
for military service; 310,000 reach military age (20) annually
- Military budget: for fiscal year ending 31 December
1978, $4,214 million; about 23.8% of the proposed central
government budget','62ad0650963379c4827dbefb981b46c1f4a8ba41cf46f41e8735fe4d03debed5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afd346d0106182c351d5b96a028bdcfc7e42d51cc88bd209c23f5970723c5e55',1972,'LK','Sri Lanka','communications',411,'(formerly Ceylon)
Arabian ; :
Sea Kis _ Bay
; "of Bengaly *
sri a
: LANKA = ©
_ Colombo
Indian Ocean
{See reference map Vil}
LAND
65,500 km*; 25% cultivated; 44% forested; 31% waste,
urban, and other
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm, plus pearling in the Gulf of Mannar); 200 nm exclusive
economic zone
Coastline: 1,340 km
Railroads: 1,496 km total (1977); all broad gage (1.435 m);
102 km double track; no electrification; government owned —
Highways: 52,200 km total (1975); 24,300 km paved
(mostly bituminous treated), 18,800 km crushed stone or
gravel, 9,400 km improved earth or unimproved earth; in
addition several thousand km of tracks, mostly unmotorable
Inland waterways: 4380 km; navigable by shallow-draft
craft
Ports: 3 major, 9 minor
Civil air: 8 major transport (including 1 leased)
Airfields: 14 total, 12 usable; 12 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 7 with runways
1,220-2,489 m -
Telecommunications: good international service;._75,000
(est.) telephones (0.5 per 100 popl.); 530,000 radio sets, 500
TV sets; 14 AM stations, 2 FM stations, and 1 TV station;
submarine cables extend to India; 1. ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,603,000; 2,772,000 fit
for military service; 159,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1978, $24.7 million, 2% of central government budget','29011a1d39a776affdd848a6801137649aa3c9b0f2fa89af2d21a4d398e2f970','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5228ffc868b32762b9081ff48dfa2b9b2e5efe081f3eedd8d4d8cf509cf01f6',1972,'SD','Sudan','communications',415,'LAND
2,504,530 km?; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest
Land boundaries: 7,805 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
:
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
{See reference map Vi}
WATER :
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’’)
Coastline: 853 km
Railroads: 5,470 km total; 4,754 km 1.067-meter gage,
716 km 1.6096-meter gage plantation line
Highways: 10,550 km total; 600 km bituminous-treated,
800 km crushed stone or gravel, and 9,150 km improved and
unimproved earth roads; in addition, there are an undeter-
mined number of tracks ;
Inland waterways: 5,310 km navigable
Pipelines: refined products, 800 km
Ports: 1 major (Port Sudan)
Civil air: 11 major transport aircraft
Airfields: 80 total, 75 usable; 8 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 31 with runways
1,220-2,489 m :
Telecommunications: large system by African standards,
but barely adequate; consists of radio relay, cables,
radiocommunications, and troposcatter; domestic satellite
system with 14 stations under construction; centers are
Khartoum, Al Fashir, Port Sudan; 56,000 telephones (0.3 per
100 popl.); 2 AM, no FM, and 2 TV stations; 1 submarine
cable; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,803,000; 2,316,000 fit
for military service; average number reaching military age
(18) annually, 152,000
Military budget: for fiscal year ending 30 June 1979, $244
million; 11% of central government budget
Ethiopia.
Addis Ababa*
503985 1-79
Declassified and Approved For Release 2012/09/02 :
Mecca
q
Batumi
Kirkdk,
traq
Baghdad,
{raq-Saudi Arab
Neutral Zone
sata ae ess so ieniin abe
V The Middle East
‘,
Caspian
Sea
erabriz
Tehran ,.','30c3f4dd35c4aa66caa3031a95d9c0c7216ab711e3ac6d2439badc27615856b2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37a099a053375e98790b5b07d02198be7b1faa49805c5e13cbbb42463520bbc2',1972,'SE','Sweden','communications',419,'(See reference map 1V)
LAND
448,070 km?; 8% arable, 1% meadows and pastures, 55%
forested, 36% other
Land boundaries: 2,196 km
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm) .
Coastline: 3,218 km
Railroads: 12,220 km total; Swedish State Railways (SJ)—
11,179 km standard gage (1.435 m), 6,959 km electrified and
1,152 km double track; 182 km 0.891-meter gage: 159 km
rail ferry service; privately-owned railways—511 km stand-
ard gage (1.435 m), 332 km electrified; 189 km 0.891-meter
gage electrified ;
Highways: 97,400 km total; 51,899 km bitumen, concrete;
20,659 km bituminous treated, gravel, improved earth;
24,842 km unimproved earth
Inland waterways: 2,052 km navigable for small steamers
and barges :
Ports: 17 major, and 30 minor
Civil ‘air: 63 major transports (including 1 leased in)
Airfields: 246 total, 240 usable; 131 with permanent-sur-
face runways; 8 with runways 2,440-3,659 m, 85 with
runways 1,220-2,.439 m
Telecommunications: excellent domestic and interna-
tional facilities; 5.67 million telephones (68.9 per 100 popl.);
9 AM, 91 FM, and 240 TV stations; 10 submarine cables,
including 4 coaxial; 1 Atlantic Ocean satellite station
DEFENSE FORCES . ;
Military manpower: males 15-49, 1,953,000; 1,742,000 fit
for military service; 57,000 reach military age (19) annually
Military budget: for fiscal year ending 30 June 1979,
$2.99 billion; about 9.2% of central government budget
199
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','c4545e71fabae08fe6122b495ca5d53073a9c2dd50f3e9fd7aee4dd2aaf8f6e0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f84c5598f763d2c85b374d11f0e80c2da83884400737b7a258b15424c1ca0ee1',1972,'CH','Switzerland','communications',423,'flan |
FEDERAL ©
REPUBLIC
OF GERMANY
{See reference map {V)
LAND
41,440 km?; 10% arable, 43% meadows and pastures, 20%
waste or urban, 24% forested, 3% inland water
Land boundaries: 1,884 km
Railroads: 5,098 km total; 2,895 km government-owned
(SBB), 2,822 km standard gage (1.435 m); 73 km narrow
gage (1.00 m); 1,339 km double track, 99% electrified;
2,203 km non-government owned, 710 km standard gage
(1.435 m), 1,418 km meter-gage (1.00 m), 75 km 0.790-me-
ter gage, 100% electrified
Highways: 62,145 km total (all paved), of which 17,594
km are canton and 975 km are national highways
Pipelines: 314 km crude oil; 1,046 km natural gas
Inland waterways: 65 km; Rhine River-Basel to Rhein-
felden, Schaffhausen to Constanz; in addition, there are 12
navigable lakes ranging in size from Lake Geneva to
Hallwilersee
Ports: 1 major (Basel), 2 minor
Civil air: 80 major transport aircraft (including 2 leased
in)
Airfields: 80 total, 73 usable; 41 with permanent-surface
runways; 2 with runways over 3,660 m, 8 with runways
2,440-3,659 m, 12 with runways 1,220-2,439 m
Telecommunications: excellent domestic, international,
and broadcast services; 4.02 million telephones (63.8 per 100
popl.); 8 AM, 94 FM, and 350 TV stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,681,000; 1,455,000 fit
for military service; 49,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1978, $1,602 million; 19.5% of central government budget
SYRIA
LAND
186,480 km? (including 1,295 km? of Israeli-occupied
territory); 48% arable, 29% grazing, 2% forest, 21% desert
Land boundaries: 2,196 km (1967) (excluding occupied
area 2,156 km)
(See reference map Vj
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’’)
Coastline: 1938 km
Railroads: 1,543 km total; 1,281 km standard gage, 262
km narrow gage (1.050 m)
- Highways: 16,939 km total; 12,051 km paved, 2,625 km
’ gravel or crushed stone, 2,263 km improved earth
Inland waterways: 672 km; of little importance
Pipelines: 1,304 km crude oil; 515 km refined products
Ports: 3 major (Tartus, Latakia, Baniyas), 2 minor
202
Civil air: 10 ‘Major transport aircraft
Airfields: 41 total, 35 usable; 24 with permanent-surface
runways; 21 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: good international and domestic
service; 177,000 telephones (2.2 per 100 popl.); 9 AM, no FM
and 5 TV stations; 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,787,000; 992,000 fit
for military service; about 85,000 reach military age (19)
annually :
TAIWAN
(See p. 39. United States recognition of the People’s Republic
of China as the sole legitimate government of China
occurred just before this edition of the Factbook was printed,
too late to move the section on Taiwan to the end of the
Factbook where it will appear in the next and succeeding
editions.) ,
TANZANIA
TANZANIA
Dar es Salaam
(See reference map VI)
LAND .
939,652 km? (including islands of Zanzibar and Pemba,
2,642 km?); 6% inland water, 15% cultivated, 31% grassland,
48% bush forest, woodland; on mainland, 60% arable, of
which 40% cultivated on islands of Zanzibar and Pemba
Land boundaries: 3,883 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 1,424 km (this includes 118 km Mafia Island;
177 km Pemba Island; and 212 km Zanzibar)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
AO AALAA AR RA Re Ate
. ‘ a a we OE One
a a ar ae ae eae re line One Oe a, aa Oe ES OE a
i, SE i A ei a a a i i Bett ce i a i
a ee Sa
a i in EE Aas od
ann
ia i ial
NS Ne te
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TANZANIA
Railroads:. 3,555.km_ total; 960 km 1.067-meter gage;
2,595 km meter gage (1.00 m), 6.4 km double track; 962 km
Tan-Zam Railroad 1.067-meter gage in Tanzania
Highways: total 17,010 km, 2,581 km paved; 5,529 km
gravel or crushed stone; 8,900 km improved earth
Pipelines: 982 km crude oil
Inland waterways: 1,168 km of navigable streams; several
thousand km navigable on Lakes Tanganyika, Victoria, and','bdde5930b424fbc0c0617453320d646539ea480c6bdc244c37357006767cd0c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae7b378da1ffcef6ec6672be186eb4c8c74c6611b59201f6af5b57b52eb2eb5f',1972,'TH','Thailand','communications',427,'Bay
of Bengal
1
/ndian Ocean
LAND
512,820 km?; 24% in farms, 56% forested, 20% other
Land boundaries: 4,868 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,219 km
Railroads: 3,830 km meter gage (1.000 m), 97 km double
track
Highways: 28,806 km total; 14,773 km paved, 4,731 km
crushed stone or gravel, 9,302 km earth and laterite
Inland waterways: 3,999 km principal waterways; 3,701
km with navigale depths of 0.9 m or more throughout the
year; numerous minor waterways navigable by shallow-
draft native craft
Ports: 2 major, 16 minor
Civil air: 25 major transport aircraft
Airfields: 155 total, 151 usable; 55 with permanent- ~
surface runways; 10 with runways 2,440-3,659-m, 29 with
runways 1,220-2,439 m
Telecommunications: service to general public adequate;
bulk of service to government activities provided by multi-
channel cable and radio-relay network; satellite ground
station; 333,761 telephones; over 3 million radios; and over
650,000 televisions; approx. 150 AM, 15 FM, and 10 TV
transmitters in government-controlled networks
DEFENSE FORCES
Military manpower: males 15-49, 9,958,000; 6,099,000 fit
for military service; about 498,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1979, $950 million; 20.6% of central government budget
LAND
829,707 km?*; 14% cultivated, 50% forested, 36% urban
inland water, and other
22)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
VIETNAM
Land boundaries: 4,562 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,444 km (excluding islands)
Highways: 41,190 km total; 5,471 km bituminous, 27,030
km gravel or improved earth, 8,690 km unimproved earth
Inland waterways: about 17,702 km navigable; more than
5,149 km navigable at all times by vessels up to 1.8-m draft
Ports: 9 major, 23 minor
Civil air: military controlled
Airfields: 172 total, 183 usable; 57 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 18 with
runways 1,220-2,439 m; 2 seaplane stations —
DEFENSE FORCES
Supply: dependent on the U.S.S.R., and Eastern European
Communist countries, for virtually all new equipment;
produces negligible quantities of infantry weapons, ammuni-
tion and explosive devices (Vietnam possesses a huge
inventory of U.S.-manufactured weapons and equipment
captured from the RVN)
Military budget: no expenditure estimates are available;
military aid from the U.S.S.R. and PRC has been so
extensive that actual allocation of Vietnam’s domestic
resources to defense has not been indicative of total military
effort
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Se a eT ee er
ee eS A ee ee Oe ee Pe en aa A te ee i ee ee ee ed
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
WALLIS AND FUTUNA/WESTERN ‘SAHARA','f3a03aa7faffc00827d3a054bea4c3aa3193ea6454ced082299f5a1257abc8f6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9403f297527e38c9de04a771739cc93e0ead86132038223f4a1f333c6acfa0f',1972,'TG','Togo','communications',431,'LAND |
56,980 km?*; nearly one-half is arable, under 15%
cultivated
Land boundaries: 1,646 km
WATER is
Limits of territorial waters (claimed): 12 nm
Coastline: 56 km
Gulf of Guinea” |
f |
(See reference map Vi}
Railroads: 442 km meter gage (1.00 m), single track
Highways: 6,998 km total; 1,210 km paved, 166 km
improved earth, 4,575 km unimproved earth
Inland waterways: section of Mono River and about 50
km of coastal lagoons and tidal creeks
Ports: 1 major (Lome), 1 minor
Civil air; 2 major transport aircraft
Airfields: 11 total, 11 usable; 1 with permanent-surface
runway ''2,440-3,659 m
Telecommunications: fair system based on_ skeletal
network of open-wire lines supplemented by a radio relay
‘ route radiocommunication stations; only center is Lome;
6,300 telephones (0.3 per 100 popl.); 2 AM stations, 1 FM
radio station, 8 TV stations; 1 COMSAT ground station
\\
206
DEFENSE FORCES
Military manpower: males 15-49, 516,000; 268,000 fit for
military service; no conscription
Supply: most military materiel obtained from France
Military budget: -for fiscal year endirig 31 December
1978, $19,927,920; 7.8% of central government budget','a3959c3b1a1b2902474f6b164520a0e73dfc604d0af9ba8bb2c6c31005d6b738','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f613461a1178f4427f22ca828d323571708fa81f8593bb91007e3aaacfd1f5ed',1972,'TO','Tonga','communications',435,'o
ont
FIL: “ TONGA
Nuku''alofa
NEWS"
CALEDONIA
Pacific Ocean
NEW
ZEALAND’
(See reference mep wil)
LAND
997 km? (150 islands); 77% arable, 3% pasture, 13% forest,
3% inland water, 4% other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 419 km (est.)
Railroads: none
Highways: 249 km total (1974); 177 km rolled stone; 72
km coral base
Ports: 2 minor
‘Civil air: no major transport aircraft
Airfields: 4 total, 4 usable; 1 with grass runway
1,220-2,439 m; 1 seaplane station; 1 ground satellite station
Telecommunications: 552 telephones (2.2 per 100 popl.);
11,000 radio sets; no TV sets; 1 AM station; 1 ground satellite
station','75ecef62ed8c44a6e1090f3ee044d7a968c2e2c318791dd37333d985cb5bb89f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd2cf92c75f9aad2fc8ec496ddfb7123fc052e4513f0d4ef77fa1bc0f0011271',1972,'TT','Trinidad and Tobago','communications',439,'LAND :
5,128 km*; 41.9% in farms (25.7% cropped or fallow, 1.5%
‘pasture, 10.6% forests, and 4.1% unused or built-on), 58.1%
outside of farms, including grassland, forest, built- -up .area,
and wasteland
TONGA/TRINIDAD AND TOBAGO
Caribbean See
Atlantic Ocean
Ne of 5 ;
- TRINIDAD
33 AND TOBAGO
(See reference mag ti}
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 362 km
Railroads: none
Highways: 7,900 km total; 3,600 km paved, 1,100 km
improved earth, 3,200 km unimproved earth
Pipelines: 1,082 km crude oil and refined products; 832
km natural gas
Ports: 3 major (Port of Spain, Chaquaramars Bay, Point
Tembladora), 6 minor
Civil air: 12 major transport aircraft
Airfields: 8 total, 6 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 3 with runways
1,220-2,489 m; 2 seaplane stations
Telecommunications: excellent international service via
tropospheric scatter links to Barbados and Guyana; good
local service; 1 Atlantic Ocean satellite station; 70,400
telephones (6.6 per 100 popl.); 2 AM, 2 FM, and 8 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 254,000; 180,000 fit for
military service
'' Supply: mostly from U.K.
Military budget: proposed for fiscal year ending 31
December 1977, $48.4 million; about 4.8% of central
government budget','87d693889e5095287005869922b00b0891498ec18ff85273c0a9b27ca38a8159','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05a5a09ca30ac1efd37bba26057814ed8e5a63dfdb91dbc2ec33d2fa055e9da6',1972,'TN','Tunisia','communications',443,'LAND
164,206 km?; 28% arable land and tree crops, 23% range
and esparto grass, 6%: forest, 43% desert, waste or urban
Land boundaries: 1,408 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 12
nm exclusive fisheries zone follows the 50-meter isobath for
part of the coast, maximum 65 nm)
Coastline: 1,143 km (includes offshore islands)','19c9abc17c171424ac7921458027954a03ee06f30bdead472f9181472f9f7295','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('172ccb9f0a8031eab6204a50f291a4528453d4bb5be55b18e9b735cd84696f0c',1972,'TV','Tuvalu','communications',449,'(formerly Ellice Islands)
NOTE: On October 1, 1975, by Constitutional Order, the
Ellice Islands were formally separated from the British
colony of Gilbert and Ellice Islands, thus forming the new
TURKEY/TUVALU
unites":
‘ps o
Pacific Ocean alae
GILBERT
“|, ., ISLANDS
PAPUA “
\\NEW.GUINEA © -:. TUVALU
“SS','715beb3bb357ae670b0d53e1fcdbece5838c03615acf31a72d0284424a31d262','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4898e45c9b7b69216800b4b0e0b8e129d0c5f72ddba6003b6b5cd3e0cf6d3645',1972,'UG','Uganda','communications',450,'(Seé reference map Vi} -
LAND
235,690 km?; 21% inland water and swamp, including
territorial waters of Lake. Victoria, about 21% cultivated,
13% national parks, forest, and game reserves; 45% forest,
woodland, and grassland
Land boundaries: 2,680 km —
Railroads: 1,216 km; meter gage (1.00 m), single’ track
Highways: 6,763 km total; 1,934 km paved; 4,829 km
crushed stone, gravel, and laterite; remainder earth roads
and tracks (est.)
Inland -waterways: Lake Victoria, Lake Albert, Lake
Kyoga, Lake George, and Lake Edward (9,670 km); Kagera
River .and Victoria Nile (610 km) :
Civil air: 5 major transport aircraft (including 2 leased in)
Airfields: 49 total, 47 usable; 5 with permanent-surface
runways; 1 with runway over 3,660 m, 3 with runways
2,440-3,659 m, 12 with runways 1,220-2,439 m
Telecommunications: fair system based on open wire
lines and radio relay links; 46,000 telephones (0.4 per 100
popl.); 6 AM, no FM, 6 TV stations; 2 COMSAT stations
DEFENSE FORCES
’ Military manpower: males 15-49, about 2,853,000; about
1,533,000. fit for military service :
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
an Ak Oe ee AN a MR RAR 2A AA AN AR AR AR RA Ue eR ee OR A me nt Ot che Rta at setae candies as aah eae!
Ma A nA AA ann 8K MA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
U.S.S.R.
U.S.S.R.
{See reference map Vit}
LAND :
22,274,000 km?; 9.3% cultivated, 37.1% foie and brush,
2.6% urban, industrial, and transportation, 16. 8% pasture
and natural hay id. 34.2% desert, swamp, or waste
Land boundaries: 20,619 km
WATER ;
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 46,670 km incl.. Sakhalin)
Railroads: 139,805 km total; 187,972 km broad gage
(1.524 m); 1,833 km narrow gage (mostly 0.750 m); 109,316
km broad gage:single track; 40,399 km electrified: does not
include industrial lines (1977)
Highways: 1,564,000 km total; 322,000 km asphalt,
concrete, stone block; 372,000 km asphalt treated, gravel,
crushed stone; 870,000 km earth (1976)
Inland waterways: 146,400 km navigable, exclusive of
Caspian Sea (1978) ;
Pipelines: 57,000 km crude oil; 13,000 km refined
products; 115,000 km natural gas
Ports: 52 major (most important: Leningrad, Murmansk,
Odessa, Novorossiysk, Ilichevsk, Vladivostok, Nakhodka,
Arkhangel’sk, Riga, Tallinn, Kaliningrad, Liepaja, Ventspils,
Nikolayev, Sevastopol); 116 selected minor; major inland
ports: Rostov, Volgograd, Gorkiy, Khabarovsk, Kiev, and
Moscow (1978)
Freight carried: rail—3,705 million metric tons, 3,330.0
billion metric ton/km (1977); highways—22.7 billion metric
tons, 380 billion metric ton/km. (1977); waterway—520.0
million metric tons, 231.0 billion metric ton/km, excluding
Caspian Sea in approximately 16,000 waterway craft with
8,000,000 metric tons capacity (1977)','4092bcea535242cb9d1b55f6faec0d2e5e9f6fa797228e9d645aef5b795fc310','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f14ac85528a0a360157463cc17f6489558b1dfb5da7013663d7b7dd1cd9f5d6',1972,'AE','United Arab Emirates','communications',454,'LAND:
82,880 km?; almost all -desert, waste or urban
214
January 1979
Gulf
of Oman
NEMIRATES
SAUDI
ARABIA
(See reference map V}
Land boundaries: 1,094 km (does not include boundaries
between adjacent U.A.E. states)
WATER
Limits of territorial waters (claimed): 3 nm for all states
except Sharjah (12 nm) ,
Coastline: 1,448 km
Railroads: none
Highways: 780 km bituminous, undetermined mileage of
earth tracks
Pipelines: 282 km crude oil
Ports: 3 major, 1 minor
Civil air: 11 major transport aircraft (including 5 leased
in)
Airfields: 57 total, 40 usable; 12 with permanent-surface
runways, 3 with runways over 3,660 m, 1 with runway
2,440-3,659 m, 10 with runways 1,220-2,439 m
Telecommunications: adequate system of radio relay and
coaxial cable; key centers are Abu Dhabi and Dubai; 70,800
telephones (10.8 per 100 popl.); 4 AM, 2 FM, and 3 TV
stations; 2 COMSAT ground stations
DEFENSE FORCES
Military manpower: males 15-49, 151,000; 87,000 fit for
military service','490df180b41331dcc2ad40a17b67107becde1a0b37703090dc2189b587eeb97d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e74d28e207fd8e2ff4ec978a0115483886906049b5eeb375e8a64f8c6ba4800',1972,'GB','United Kingdom','communications',458,'Atlantic
Ocean
(See reference map (V}
LAND
243,978 km?*; 30% arable, 50% meadow and pasture, 12%
waste or urban, 7% forested, 1% inland water
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 12,429 km
Railroads: Great Britain—18,287 km total; British Rail-
ways (BR) operates 18,012 km standard gage (1.435 m)
(3,735 km electrified, 11,410 km double track, 2,366 km
multiple track) and 19 km 0.597-meter gage; 256 km of
standard gage (1.435 m) and several ‘narrow gages are
privately-owned; Northern Ireland Railways (NIR) operates
827 km 1.600-meter gage, 190 km double track
Highways: approx. 343,315 km paved and 23,175 km in
Northern Ireland, 22,227 km paved; 949 km gravel
Inland waterways: 1,770 km of commercial routes
Pipelines: 933 km crude oil, almost all insignificant; 2,907
km refined products; 1,770 km natural gas ,
Ports: 23 major, 350 minor ,
Civil air: 506 major transport aircraft (including 4 leased
in and 17 leased out) ,
Telecommunications: modern, efficient domestic and
international system; 22.4 million telephones (39.4 per 100
popl.); excellent countrywide broadcast; 97 AM, 120 FM,
and 300 TV stations; 42 submarine cables; 1 earth satellite
station with 2 Atlantic Ocean antennas and 1 Indian Ocean
antenna
DEFENSE FORCES
Military manpower: males 15-49, 12,994,000; 11,012,000
fit for military service; no conscription; 455,000 reach
military age (18) annually :
Military budget: proposed for fiscal year ending 31]
March . 1979, $12,800 million; about 15.1% of central
government budget
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a ar a. ars
Se ee. ee ee ee en ee SN ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
UPPER VOLTA
UPPER VOLTA
Atlantic
Ocean
(See reference map Vi) ,
LAND
274,540 km*; 50% pastureland, 21% fallow, .10% culti-
vated, 9% forest and scrub, 10% waste and other uses
Land boundaries: 3,307 km
Railroads: 1,173 km, 516 km meter gage (1.00 m), single
track; Ouagadougou to Abidjan, Ivory Coast line
Highways: 4,717 km total; 617 km paved, 4,100 km
improved
Civil air: no major transport aircraft
Airfields: 55 total, 54 usable; 2 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: all services generally poor; 3,400
telephones (0.1 per 100 popl.); 8 AM stations, 1 FM station,
and 1 TV station; 1 Atlantic Ocean Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 1,481,000; 746,000 fit
for military service; no conscription
Supply: mainly dependent on France
Military budget: for fiscal year ending 31 December
1978, $23,269,076; 18.4% of central government budget','a6d78886a838ea3dec445c96764e6d2cc1f0526f04c80aa9e31b69685fb05c6c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf97b783dd73205d0aa04eab7ff063886785599a9f6241fe0aaef224a789997a',1972,'WF','Wallis and Futuna','communications',462,'NEW X* WALLIS
CALEDONIA” = AND FUTUNA-
Pacific Ocean
NEW
_ZEALAND
(See reference map Vill}
LAND
About 207 km?
WATER
Limits of territorial waters: 12 nm
Coastline: about 129 km
Highways: 100 km of improved road on Uvea Island
(1977)
Ports: 2 minor
Airfields: 2 total, 2 usable; 1 with runway 1,220-2,439 m
Telecommunications: 85 telephones (0.9 per 100 popl.)
DEFENSE
No formal defense structure; no regular Armed Forces','ecaf8a2fa0046ea595da13615af9684b33b52efc5e567957d464d11b771297a5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a53493294de87d40dc5f8c1acee764a8748268e8ec4d6316aef52790d743a546',1972,'ZM','Zambia','communications',466,'Indian
Ocean
(See reference map Vi}
LAND
745,920 km*; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered trees and
grassland
Land boundaries: 6,003 km
Railroads: 2,014 km, all narrow gage. (1.067 m); 13 km
double. track ,
Highways: 34,869 km total; 4,456 km paved, 2,853 km
crushed stone, gravel, or stabilized soil; 4,660 km improved
and unimproved earth
Inland waterways: 2,250 km including Zambezi River,
Luapula River, Lake Kariba, Lake Bangweulu, Lake
Tanganyika; principal port on Lake: Tanganyika is
Mpulungu (of only local importance)
Pipelines: 724 km crude oil
Civil air: 10 major transport aircraft
Airfields: 172 total, 165 usable; 14 with permanent-sur-
face runways; 1 with runway over 3,660 m, 3 with runways
2,440-3,659 m, 22 with runways 1,220-2,439 m
Telecommunications: facilities being modernized and
expanded; high-capacity wire and radio relay connect
centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 77,400 telephones (1.7 per 100
popl.); 4 AM, 1 FM, and 3 TV stations; 1 Indian Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,099,000; 571,000 fit
for military service
Military budget: for fiscal year ending 31 December
1977, $79 million; 12.9% of central government budget','d25b1f851ab6858bd0c36d90fab83befff41d1cae03d5596e8eaf920f086d808','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43792a80194d17550f78ab93aa26eae090080a22c8d6aee7069f82431f6fab89',1972,'US','United States','communications',470,'This “Factsheet” on the U.S. is provided solely as a service
to those wishing to make rough comparisons of foreign
country data with a U.S. “yardstick.” Information is from
U.S. open sources and publications and in no sense represents
estimates by the U.S. intelligence community.
LAND
9,363,396 km? (contiguous U.S. plus Alaska and Hawaii);
19% cultivated, 27% grazing and pasture, 32% forested, 22%
waste, urban, and other
WATER :
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 19,924 km
Railroads: 277,686 km (1973)
Highways: 6,059,200 km (1972)
Inland waterways: 40,416 km of navigable inland
channels, exclusive of the Great Lakes; freight carried 951
million short tons (1970)
Pipelines: petroleum, 279,966 km (1972)
Ports: 25 major
Merchant marine: 600 ships (1,000 GRT or over) totaling
9,982,730 GRT, 14,722,666 DWT; includes 3 passenger, 5
short-sea passenger, 163 cargo, 119 container, 14 roll-on/
232
roll-off cargo,. 234 tanker, 1 liquefied gas, 17 bulk, 2
combination ore/oil, 23 LASH Seebee and barge carriers, 19
specialized carriers; in addition there are 178 ships in reserve
fleet
Civil air: 2,716 major transport aircraft (1976)
Airfields: 15,257 (1976)
Telecommunications: 155 million telephones (7.8 tele-
phones per 100 popl.); 4,500 AM, 3,600.FM, and 985 TV
broadcast stations; 486 million radio and 133 million TV.
receivers (1977)
DEFENSE FORCES
Personnel: army 1,133,000, navy and marines 1,029,000,
air force 827,000 (1976)
Military budget: $100.1 billion (1977)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ak A AA AR aka: &
a. ™!
ALARA BRA ALAA eR Rn A A A OA RA A A a A
the AL
AAA Le
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
I Canada
4
Ocean
Arctic
Ellesmere
Island
> Dall
El Paso fro
New Orleans@
Monterrey,
Gulf of Mexico -','9ccf3064a10e7ff2e1290ac02689f5fb83d7dd45d77977b748ab0af25a91547f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3094b75aaf47ac8d94f21441b755924ece9cf7b426e47854a8d821529b1d5165',1972,'ML','Mali','communications',474,'Senegal é
‘ Timbuktu
Oakar ji
The Gambiaypeagiul
Guinea xp;
Bissau. (7: ‘Guinea
Conake''
Freetowns
Sierre.
Leone “,
Monrovia’.
Liberta
Eq.Guinea* ff
Sao Tome and : STI
Principe ~~ & Libreville’
Sao Tomés+
Eq. Guinea~ . Gabon
Brdzzaville
South
Atlantic
Ocean
North ge
Atlantic ae Can
: CIA-RDP08-00534R000100140001-7
VI Africa
Sea
Caspian
Sea
Black Sea
¢
co” vO','9461768e6e5b514545ec3b61461ca706e8e0716975dc5d87803ab5316dd3db35','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fc1fe307b454a364ab98d52e51c7128b27775a856e1c866acd053835609d0d4',1972,'EG','Egypt','communications',475,'a
“
7)
Port Sudan
Khartoum,
“Mogadiscio
Nairobi
Lakes,
Victoria F 4
Burundi ~. {Mombasa Seychelles
1 Victoria’.
aed
ain
S ar es Salaam','ba2eb8d8410a4adc4680d0024289de0f5ee28176b8b7c0af5e80e163c623a720','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

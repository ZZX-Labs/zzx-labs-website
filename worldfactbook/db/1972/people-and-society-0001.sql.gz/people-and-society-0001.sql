SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d94b126b314efa79936abfd12072fa34683bf0da7f3ab9bfc131123bcbaecc17',1972,'','','people-and-society',2,'Population: 37,717,000, average annual growth rate 2.6%
(current) ,
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English ;
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force
ARABIA','f8b7605ba1b2a23088aac7fcfb362b6313b7efb6c969c93029fd1c2dc7706c95','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b0d7eaccd20524638c53339b4da1d555fafb870086298ccc0be4af8d8dee3ef',1972,'','','people-and-society',2,'Population: 38,198,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','49fded7edad1505d176731698caed4da46556420727747bae87bb3d1dba995fc','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49cc4ec34ac2fd3c0b84f1fda4c0d3d3b9a1796629f8d9b939e280f0ccf017a4',1972,'','','people-and-society',2,'Population: 38,198,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','49fded7edad1505d176731698caed4da46556420727747bae87bb3d1dba995fc','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23095c05cc283412ed5a24bea727e91fef02014ed6853dc1b372ed3760886dc4',1972,'AF','Afghanistan','people-and-society',2,'250,000 sq. mi.; 22% arable (including 6.5% cultivated) , PEOPLE''S REPUBLIC
5% pasture, 71% desert, waste or urban, 2% forested : OF CHINA
Land boundaries: 3,390 mi.
Population: 17,882,000, average annual growth rate
2.3% (FY71); males 15-49, about 4.7 million; 2.5
million fit for military service; about 165,000
reach military age (22) annually
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras, minor ethnic groups include Chahar,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11% Turkic languages (primarily
Uzbeki and Turkmeni), 10% 30 minor languages (primarily Baluchi and Pashai);
much bilingualism
Literacy: under 10%
Labor force: about 4.3 million (official est.); 75%-80% agriculture and animal
husbandry, 15%-25% commerce, small industry, services; massive shortage of
skilled labor
Organized labor: none','968955f44c705b644db07676437463e8a38efc6fd381da623ce415db4a5a8d1e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1dabf0863d426881bfadd6ade9a494cfe002e6078a5fe02b26d3e8920a4951a6',1972,'AL','Albania','people-and-society',7,'Population: 2,257,000, average annual growth rate 2.8%
(current); males 15-49, 533,000;. 441,000 fit for mili-
tary service; 24,000 reach military age (19) annually
Ethnic divisions: 96% Albanian, remaining 4% are Greeks, Vlachs, Gypsies, and
Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10% Roman Catholic (observances
prohibited; Albania claims to be the world''s first atheist state
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics available, but. probably
greatly improved
Labor force: 911,000 (1967); 60.5% agriculture, 17.9% industry, 21.6% other
nonagricultural','9f118ec16e6d691bcda00da5c01a735bb4406ce67f18851b72f59eb3adb5deb6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0ab28097d4c7f47af267c6130b883636b16e54eb003564492309dcfafe74d5a',1972,'DZ','Algeria','people-and-society',11,'Population: 15,222,000, average annual growth rate 3.1%
(FY71); males 15-49, 3,645,000; 2,090,000 fit for
military service; average number reaching military
age (19) annually 135,000
Ethnic divisions: 99% Arab-Berbers, less than 1% Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million; 47% agriculture, 8% industry, 24% other (military,
police, civil service, transportation workers, teachers, merchants ,
construction workers); 40% of urban labor unemployed
Organized labor: 17% of labor force claimed; General Union of Algerian
Workers (UGTA) is the only labor organization and is subordinate to the
National Liberation Front
Population: 34,494,000 (including the Balearic and Canary Islands; also including
Alhucemas, Ceuta, Chafarinas, Melilla, and Penon de Velez de la Gomera), average
annual growth rate 1.1% (current); males 15-49, 8,424,000; 6,470,000 fit for
military service; 289,000 reach military age (20) annually
Ethnic divisions: homogeneous composite of Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority; but 17% speak Catalan,
7% Galician, and 2% Basque
Literacy: about 90%
Labor force (1970): 12.7 million; 29.1% agriculture, 37.3% industry, 33.6%
services; registered unemployment is 1.5% of labor force
Organized labor: 90% of labor force in compulsory government-control led
syndicates
Population: 76,000 (preliminary total from the census of
31 December 1970); males 15-49, 15,000; 7,000-8,000
fit for military service
Ethnic divisions: 51.2% Arab, Berber, and Negro nomads; 48.8% Spanish
Religion: 51% Muslim, 49% Catholic
Language: Spanish (official), local Arabic or Hassania
Literacy: among Spanish, probably nearly 100%; among nomads, perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none
Population: 12,959,000, average annual growth rate 2.3%
(July 63-October 71); males 15-49, 3,121,000;
2,340,000 fit for military service; 143,000 reach
military age (18) annually
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor, 2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6% Muslim, 1% other
Language: Sinhala official, spoken by about 70% of population; Tamil spoken by
about 22%; English commonly used in government and spoken by about 10%
of the population
Literacy: 82% (1970 est.)
Labor force: 4 million; at least 14% unemployed or underemployed; employed
persons -~ 53.4% agriculture, 14.8% mining and manufacturing, 12.4% trade
and transport, 19.4% services and other
Organized labor: 43% of labor force, over 50% of which employed on tea, rubber,
and coconut estates','8d41e3ba8ab2cef932301e8bf5ac6cb1d1b8f3beb0c34203e64f609e51f2403a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c323adf7f785bdf44e0e35340dd24afe404d54bc2ffff04e81769415b5cb8c06',1972,'AD','Andorra','people-and-society',15,'Population: 25,000, average annual growth rate 9.6%
(FY65-69)
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian - ALGERIA
Labor force: unorganized; largely shepherds and farmers','305fc0b60b4cd3d9f7ff5705c47552252b6ac5303cf153200a3adb796a951178','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdcdb074f0123c6b29b64bd8c5ad28e871ec82b234a1585487c0800d3c12d6aa',1972,'AO','Angola','people-and-society',19,'Population: 5,814,000, average annual growth rate 1.6%
(December 60-70); males 15-49, 1,439,000, fit for
military service, 720,000; average number reaching military age (20) annually
about 60,000
Ethnic divisions: 93.6% African, 5% Europeans, 1.4% mulatto (1960)
Religion: about 84% animist, 12% Roman Catholic, 4% Protestant
Language: Portuguese (official), many native dialects
Literacy: 10%-15%
Labor force: 2.6 million economically active (1964); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)','b7390f5a6beea462c2c6a61db0d28d7890c899eba064e2b32aa38d01c6ffb2bf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9311b7ce1c732414dfcb2540fececf8a1316df898f832a22540065747add517',1972,'CO','Colombia','people-and-society',22,'Population: 74,000, average annual growth rate 2.6% rs
(April 60-70) fea
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other Protestant sects and some
Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000
Population: 105,000, average annual growth rate 1.6% Beagle
(April 60-70)
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 27,000 (1960); 50% agriculture
Organized labor: 20% of labor force','55400743cbc92df2f2aceb29f6f095fa0b426b772fc348580475ac54152353f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62c73f00231a3cc0403443508fb027aed459f9ac1dc4d78f25668cb536f321f0',1972,'AR','Argentina','people-and-society',29,'Population: 24,008,000, average annual growth rate 1.6%
(September 60-70); males 15-49, 6,172,000; 4,570,000
fit for military service; average number reaching military age (20) annually
about 215,000
Ethnic divisions: approximately 85% white, 15% mestizo, Indian, or other
nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20% practicing Roman Catholics),
2% Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 9.5 million; 19% agriculture, 25% manufacturing, 11% commerce,
35% other, 4%-5% unemployed
Organized labor: 25% of labor force (est.)','b05408571f9dc245994c4834728c5bd50ee3e49af9860b89ab1336854dc81c12','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd678f6eb558c61bea5272f414f808bb6301851131b55bbfd624753e8ab1e625',1972,'AT','Austria','people-and-society',33,'Population: 7,474,000, average annual growth rate 0.2%
(March 70-71); males 15-49, 1,675,000; 1,350,000 fit
for military service; average number reaching military
age (19) annually about 51,000
Ethnic divisions: 98.1% German, .7% Croatian, .3% Slovene, a
.9% other SLGE RIN
Religion: 85% Roman Catholic, 7% Protestant, 8% none or other
Language: German
Literacy: 98%
Labor force: 3,248,000 (of which 828,200 are self-employed); 18% agriculture
and forestry, 49% industry and crafts, 18% trade and communications, 7%
professions, 6% public service, 2% other; 2.4% registered unemployed; an
estimated 200,000 Austrians are employed in other European countries;
foreign labor about 75,000 (1970)
Organized labor: about 2/3 of wage and salary workers (1971)','785844f628d12004efbd59bb383528dce487d95e91ee0a5596c9878141629bb1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11899544deacd0cd95185133efe9a683f741b9af8057db4192d2061e2c85372b',1972,'BS','Bahamas','people-and-society',37,'Population: 191,000, average annual growth rate 4%
(November 63-April 70)
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: mainly Church of England; some Protestant, Greek Orthodox, and
Roman Catholic
Language: English
Labor force: 60,000 (1963)','3c458460aec41a88ca9e4aff1e1ce8ce38c048e80a21ad8b73a752bfae4b088c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('303f50d631e0db4ace27996f8a16062ee42ee2f6ab4a56087c401852545cee1d',1972,'BH','Bahrain','people-and-society',39,'Population: 224,000, average annual growth rate 2.8%
(February 65-April 71); males 15-49, 59,000; fit for
military service 32,000
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani, and Indian, 3% other
Religion: Muslim
Language: Arabic ;
Literacy: about 30% (1965)
Labor force: 53,274 (1965)','eda71a7c172c9c0a6a42b1c5dad40e3eca5d8fb3371c4abdaba073437361da09','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1d038a959f5b9efc94c5482989958167884ffb7555dea829c92f2689152b061',1972,'BD','Bangladesh','people-and-society',43,'Population: 62,994,000*, average annual growth rate 1.9%
(FY70); males 15-49, 15,148,000; 8,130,000 fit for
military service }
Ethnic divisions: predominantly Bengali; up to 1 million "Biharis" and fewer
than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1% Buddhist and other
Language: Bengali
Literacy: about 20%
Labor force: about 24 million; majority are unemployed or underemployed;
over 80% of labor force is in agriculture','1db381bc0a57395e7d31e5aed0c2f5f6fa141611938b6e8db1ed58bb841a7b8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6467bc16f4d611d03a6d28466393f1e9335fe2429ab154958ddae2d07dca8937',1972,'BB','Barbados','people-and-society',47,'Population: 239,000, average annual growth rate 0.2%
(April 60-70); males 15-49, 49,000; 35,000 fit for
military service; average number reaching military
age, (18) annually, 3,000; no conscription
Ethnic divisions: 80% African, 15% mixed, 5% European
Religion: Anglican, Roman Catholic, Methodist, and Moravian
Language: English
Literacy: over 90%
Labor force: 60,000 wage and salary earners
Organized labor: 19,300 (32%)','44f5906de3bac7e056cb220bb1e18e1f4b774d1e026cdc45dd6ba51564fbf900','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61fb4ea3de0c6a8fc89f36ba440c3118f3dc7adf00b1e609d0caacba886b657f',1972,'BE','Belgium','people-and-society',49,'Population: 9,742,000, average annual growth rate 0.3% eee
(current); males 15-49, 2,248,000; 1,795,000 fit for
military service; average number reaching military age (19) annually 71,000
Ethnic divisions: 55% Flemings, 33% Walloons, 12% mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch); divided along ethnic lines
Literacy: 97%
Labor force: 3.9 million; approximately 95% is found in the following sectors:
32% manufacturing, 24% services, 16% commerce, banking, and insurance, 8%
construction, 7% transportation and communication, 5% agriculture, forestry,
and fishing, 1.5% mining, .8% public utilities and sanitary services; 3%
unemployed
Organized labor: 48% of labor force (1969)','a8387e84e3a70317858d83eabb2f89f9d754c292cb9af261807e0eb370392538','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b9bf6a6f7735347161ec5342a57bef46611a5d7b0d3a381b04ab75d9bbff48e',1972,'CA','Canada','people-and-society',54,'Population: 55,000, average annual growth rate 2.1%
(October 60-70)
Ethnic divisions: approximately 63% African, 37% white
Religion: 47.5% Church of England, 10.2% Catholic, 38.2% other Protestant, 4.2%
other
Language: English
Literacy: virtually 100%
Labor force: 19,498 employed (1960)','d4d5fb445b82186d13be8d794254247a0e85acccc741a4703be09ef6ab115a9a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7186dbe3509fa1c02501efb50514d0e63bf7812a80840fa315fe819fb211008',1972,'BT','Bhutan','people-and-society',58,'Population: 874,000, average annual growth rate 2.3%
(current); males 15-49, 210,000; 120,000 fit for
military service; about 8,000 reach military age
(18) annually
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese,
15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Buddhist-influenced
Hinduism
Language: Bhotias speak various Tibetan dialects, most widely spoken dialect is
Druk-ke, the official language; Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry; massive lack of skilled
labor','a680991b972f4facfc50b8d26cfe4926f4c29003704fbcf6d35e37ae13aaba85','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac57f04ebd6aa317e5268f9fa15779250cb938a3ce47df1449e9706042ded8da',1972,'BR','Brazil','people-and-society',61,'Population: 4,891,000, average annual growth rate 2.5%
(current); males 15-49 1,145,000; 725,000 fit for
military service; average. number reaching military age
(19) annually about 54,000
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic
Language: Spanish and Indian (Aymara and Quechua)
Literacy: 35%-40%
Labor force: 1.9 million (1967); 69.1% agriculture, 3.3% mining, 9.6% services
and utilities, 8% manufacturing, 10% other
Organized labor: 40%-50% of labor force
Population: 96,202,000, average annual growth rate 2.9%
(September 1960-70); males 15-49, 22,346,000; 14,580,000
fit for military service; 1,130 reach military age (18) annually
Ethnic divisions: 61.8% white, 26.6% brown, 11% Negro, 0.6% yellow (Brazilian
census color classifications, 1950)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: about 61% over age 14
Labor force: 33 million in 1970 (est.); 41% agriculture, 12%
manufacturing industries, 33% commerce and services
Organized Tabor: about 50% of labor force; only about 1.5 million pay dues
Population: 141,000, average annual growth rate 4.4%
(August 60-September 71); males 15-49, 36,000; 19,000
fit for military service; about 1,000 reach military
age (18) annually
Ethnic divisions: 52% Malays, 28% Chinese, 15% indigenous tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8% Christian; 32% other (Buddhist
and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture, 32.8% industry, manufacturing, and
construction, 33.8% trade, transport, services, 2.9% other
Organized labor: 8.4% of labor force
Population: 23,274,000, average annual growth rate 3.2% ;
(current); males 15-49, 5,465,000; 3,305,000 fit for military service;
average number reaching military age (18) annually about 244,000
Ethnic divisions: 70% mestizo, 20% white, 5% Negro, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old :
Labor force: 5.6 million (1966); 42% agriculture, 15% manufacturing, 20% services,
23% other (1962)
Organized labor: 13% of labor force
Population: 284,000, average annual growth rate 2.7%
(September 66-70)
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor Force: mainly agricultural
Organized labor: information not available
Population: 1,836,000, average annual growth rate 2.8%
(FY71); males 15-49, 395,000; 265,000 fit for military service; average
number reaching military age (18) annually about 22,000
Ethnic divisions: 98% white (including mestizo), 2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: approximately 80%
Labor force: 530,000 (1970); 46.3% agriculture; 13.2% manufacturing; 11% commerce;
8% construction, transportation, and communications; 21.5% other; shortage
of skilled labor (1968)
Organized labor: about 6% of labor force
Population: 4,313,000, average annual growth rate 3.0% j
(FY71); males 15-49, 993,000; 630,000 fit for military service;
48,000 reach military age (18) annually
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 35% to 40% of adult population
Labor force: 1.3 million; 73% agriculture, 8% industry, 19% services and other
Organized labor: 12% of labor force
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 800 mi.
Population: 2,000 (official est. for 1 July 1970)
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); over 95% (est.) in agriculture, mostly sheepherding
Population: 1,523,000, average annual growth rate 3.1%
(December 60 - May 70); mates 15-49, 370,000; 255,000 fit for military
service; no conscription
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder mainly Protestant
Language: Spanish; about 14% speak English as native tongue; many Panamanians
bilingual
Literacy: 80% of population 10 years of age and over
Labor force: 468,000 (1969 est.); 40% agriculture, 19.9% services, 11% commerce,
12% manufacturing, 6% construction, 5% transportation and communications, 26%
other (1969 ty 5.6% Canal Zone; national average of 7%-8% unemployed; 25%
to 30% of unemployed in Panama and Colon; shortage of skilled Tabor but an
oversupply of unskilled labor
Organized labor: 5% of labor force
Population: 2,537,000, average annual growth rate 3.1%
(FY70); males 15-49, 611,000; 420,000 fit for military
service; average number currently reaching military
age (17) annually, 25,000
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
f Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but probably much lower (40%)
Labor force: 715,000 (1968 est.); 55% agriculture, forestry, fishing; 8%
transport and other services; 19% manufacturing and construction; 13%
commerce and professions; 5% miscellaneous (est. 1962)
Organized labor: about 6% of labor force','70536c2acc62d6b22a052b65c2fba72421f25d22063a4295f329622c4079738a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fc7b7b81ce207aa4d0f3d10546d518b128753d184a0d88c90e756ece627c4fb',1972,'BW','Botswana','people-and-society',63,'Population: 689,000, average annual growth rate 3.1%
(FY71); 98.9% Bantu; males 15-49, 165,000; 85,000
fit for military service; 8,000 reach military age
“ (18) annually
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% European
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana; less than 1% secondary
school graduates
Labor force: most are engaged in sheep raising and subsistence agriculture
(statistics unavailable); about 28,000 in internal cash economy, another
39,000 spend at least 6 to 9 months per year as wage earners in South
Africa (1964)
Organized labor: negligible','80d57a1a34a710946b8a475773ac4ef1513101fbb450316d386bd02f72db2897','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('301e4e0a2aa6f6cf89edc197c9a3dc33fed790e0f7c2090365e7278c76905d1a',1972,'IQ','Iraq','people-and-society',66,'Population: 8,595,000, average annual growth rate 0.7%
(current); males 15-49, 2,246,000; 1,875,000 fit for
military service; about 68,000 reach military age (19) annually
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6% Gypsies, 2.5% Macedonians ,
0.3% Armenians, 0.2% Russians, 0.6% other
Religion: regime promotes atheism; religious background of population is 85%
Bulgarian Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman Catholic, 0.5%
Protestant, Gregorian-Armenian and other
Language: Bulgarian; secondary languages closely correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.4 million (July 1970); 38% agriculture, 33% industry, 29% other
Population: 28,833,000, average annual growth rate 2.2%
(FY70); males 15-49, 6,910,000; 3,000,000 fit for
military service; about 275,000 males and 266,000 females reach military
age (18) annually; both are liable for military service
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2% Kachin, 2% Chin, 2% Chinese,
3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their own languages
Literacy: 60% (official claim)
Labor force: 10 million; 67% agriculture, 13% industry, 20% services, commerce,
and transportation
Organized labor: no figure available; old labor organizations have been
disbanded, and government is forming one central labor organization','15f1081367e9d665d0cff4fd2e20a1ada4ee0012ac307d08fab65a01b4f599b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('622e2568189c594948de92872a47a37ea40b1c24474f24d32f90868e4da920c5',1972,'BI','Burundi','people-and-society',71,'Population: 3,687,000, average annual growth rate 2.0%
(FY71); males 15-49, 858,000; 415,000 fit for
military service; 42,000 reach military age
(16) annually
Ethnic divisions: Africans -- 86% Hutu (Bantu), 13% Tutsi
(Hamitic), 1% Twa (Pigmy); non-Africans include (late
1968). 3,000 Europeans, 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10% Protestant); rest mostly animist
plus small number of Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili, or 6% in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of Burundi Workers (UTB), membership
about 30,000, affiliated with government party','c750be8b8d96f30996062058bb1ed6932bd7552d47d039c4a37115ca97b63bca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('610134be3bb33d5253b40a21cc2c9cdd5c86d4f5467ffb00e9a02dcedd8da405',1972,'KH','Cambodia','people-and-society',75,'Population: 7,152,000 average annual growth rate 2.2%
(FY69); males 15-49, 1,606,000; 895,000 fit for
military service; 83,000 reach military age (18) annually
Ethnic divisions: 89% Khmer (Cambodian), 3% Vietnamese, 5% Chinese, 3% other
minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian
Literacy: 55% (est.)
Labor force: 2.56 million; 80.9% agriculture, 5.5% sales, 4.7% manufacturing,
transport, communications, 3.9% professional, administrative, clerical,
3.5% defense; 1.5% unemployed
Organized labor: .5% of labor force','fa8e3297fc4b6a35fc2d8e6da27c9c2fae0bc85839075bf79b6cb209245815de','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9af21dd134e649d294c62c6b6e9501b44542b0c2f6ee3ebb76b804b2caa74e14',1972,'CM','Cameroon','people-and-society',78,'Population: 6,041,000, average annual growth rate 1.7%
(FY70); males 15-49, 1,364,000; 710,000 fit for
military service; average number reaching military
age (18) annually about 61,000
Ethnic divisions: about 200 tribes of widely differing background; 31% Cameroon
Highlanders, 19% Equatorial Bantu, 8% North West Bantu, 10% Fulani, 7%
Eastern Nigritic, 11% Kirdi, 13% other African, less than 1% non-African
Religion: about one-half animist, one-third Christian; rest Muslim
Language: English and French official, 24 major African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence agriculture and herding;
200 ,000 wage earners (maximum) including 22,000 government employees, 63,000
paid agricultural workers , 49,000 in manufacturing
Organized labor: under 45% of wage labor force','9ff98fbab772b1b9d385f9127c1faec52453ce2f53dfa191d62f22acde661547','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df088afea6ad4d3eaee03fb1982e14d3890fe1378fe3da87f795817b2a608988',1972,'CF','Central African Republic','people-and-society',82,'Population: 1,673,000, average annual growth rate 2.26
(FY68-71); males 15-49, 435,000; 210,000 fit for
military service
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and linguistic
characteristics; Banda (32%) and Baya-Mandjia (29%) are
largest single groups; 6,500 Europeans, of whom 6,000 are French and majority
of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27% animist, 5% Muslim; animistic
beliefs and practices strongly influence the Christian majority
Language: French official; Sangho, the lingua franca and unofficial national
language
Literacy: estimated at 5%-10%
Labor force: about half the population economically active, 80% of whom are in
agriculture; approximately 50,000 salaried workers
Organized labor: 1% of labor force','1b242e14abd7b877d2195bd3ad8499f7ba02f08e91522e552ac3bb6c122f7885','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86c34799912160207dd5089b5488e6b7cb2ed5d8e066bab66ffc63801fb5ecba',1972,'TD','Chad','people-and-society',86,'Population: 3,889,000, average annual growth rate 2.5%
(current); males 15-49, 944,000; 490,000 fit for mi litary
service; average number reaching military age (20)
annually about 35,000
Ethnic divisions: over 240 tribes representing 12 ethnic
groups -- white Muslims (Arabs, Toubou, and Fulani)
and black Muslims (Kotoko, Hausa, Kanembou, Baguirmi,
Boulala, and Wadai) in the north and center and non-Muslims (Sara, Mayo-Kebbi,
and Chari) in the south; some 150,000 nonindigenous, 5,000 of them French
Religion: about half Muslim, 5% Christian, remainder animist
Language: French official; Chadian Arabic is lingua franca in north, Sara and
Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically active group, of which 90%
are engaged in unpaid subsistence farming, herding, and fishing; 60,000
wage earners in industry and civil service
Organized labor: about 20% of wage labor force','96c708405b5044d3f2abc6fd5052da9b40e3da0cb7c19a623d21a89da68b400a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb951c2f3239f37fc4b54b9b3ca35e5a72eac450c10d2ad0458a2988255f86bf',1972,'AU','Australia','people-and-society',90,'Population: 874,415,000, average annual growth rate 2.3% (current)
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Pu-I, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have been pragmatic and eclectic,
not seriously religious; most important elements of religion are Confucian-
ism, Taoism, Buddhism, ancestor worship; about 2%-3% Muslim, 1% Christian
Language: Chinese (Mandarin mainly; also Cantonese, Wu, Fukienese, Amoy, Hsiang,
Kan, Hakka dialects), and minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture, 15% other; shortage of
skilled labor (managerial, technical, mechanics, etc.); surplus of unskilled
Tabor
Population: 15,158,000 (excluding the population of
Quemoy and Matsu Islands and foreigners), average
annual growth rate 2.2% (January 70-72); males 15-49,
3,632,000; 2,750,000 fit for military service; average number currently
reaching military age (19) annually 180,000
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese, 2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and Taoism; 4.5% Christian;
2.5% other
Language: Mandarin, Taiwanese, Japanese, English
Literacy: about 90%
Labor force: 4.5 million; 41% agriculture, forestry, fishing, 18% manufacturing,
15% services, 15% commerce, 5% transportation and communications,
4% construction, 2% mining (1968)
Organized labor: about 10% of 1968 labor force (government controlled)
Population: 125,507,000 (including West Irian), average
annual growth rate 2.5% (FY68); males 15-49, 28,596,000; 16,300,000 fit
for military service; about 1,486,000 reach military age (18) annually
Ethnic divisions: 45% Javanese, 14% Sundanese, 7.5% Madurese, 7.5% Coastal Malays,
26% other
Religion: 90% Muslim, 4% Christian, 2% Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay) official; English, and Dutch
leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 41 million; 70% agriculture, 15% industry, 15% miscellaneous and
unemployed
Organized jiabor: 10% of labor force
Population: 30,336,000, average annual growth rate 2.9%
(FY68-70); males 15-49, 7,152,000; 4,230,000 fit for
military service; about 310,000 reach military age (21) annually ;
Ethnic divisions: 63% Ethnic Persians, 3% Kurds, 13% other Iranian, 18% Turkic,
3% Arab and other Semitic, 1% other on
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2% Zoroastrians, Jews, Christians
and Baha''is
Language: Farsi (Persian). Turki, Kurdish, Arabic
Literacy: about 30% of those 10 years of age and older
Labor force: 7.5 million; 47% agriculture, 53% industry, commerce and services;
shortage of skilled labor substantial
Organized labor: 1.1% of labor force
Population: 9,978,000, average annual growth rate 3.3%
(October 70-71); males 15-49, 2,256,000; 1,220,000
fit for military service; about 119,000 reach military age (18) annually
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7% Assyrians, 2.4% Turkomans, 7.7%
other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry, 6.7% government,
16.8% other; rural underemployment high, but not serious because low
subsistence levels make it easy to care for unemployed; severe shortage
of technically trained personnel
Organized labor: 11% of labor force','581ab72ccd97a35ca84ebcd67168f1833fab046f60eebd484cb058f69cd8b5c6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5d2ff0413df13c6aedabbbc4572df33bb70ebe4c5f636779191f652919d82bf',1972,'CG','Congo','people-and-society',96,'Population: 962,000, average annual growth rate 2.0%
(current); males 15-49, 238,000; 114,000 fit for
military service; about 10,000 reach military age (20) annually
Ethnic divistons: about 15 ethnic groups divided into some 75 tribes, almost all
Bantu; most important ethnic groups are Kongo (48%) in south, Teke (17%) in
center, M''Bochi (12%) and Sangha (20%) in north; about 8,500 Europeans,
mostly French
Religion: about half animist, half nominally Christian, less than 1% Muslim
Language: French official, many African languages with Lingala and Kikongo
most widely used
Literacy: about 20%
Labor force: about 40% of population economically active, most engaged in
subsistence agriculture; 79,100 wage earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)','c2583462088c9a7cefb78b58b0a282f847acac65a1df9cdc7d029f8de5a155a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bd1f6f85ed18d54a38e9d2855dfedbc312c524edec14a664c76ebfe5e6aabcb',1972,'CU','Cuba','people-and-society',101,'Population: 8,778,000, average annual growth rate 1.6%
(current); males 15-49, 2,082,000; 1,165,000 fit for
military service; about 77,000 males and 74,000
females reach military age (17) annually
Ethnic divisions: 51% mulatto, 37% white, 11% Negro, 1% Chinese
Religion: at least 85% nominally Roman Catholic before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.6 million; 34% agriculture, 17% industry, 6% construction, 6%
transportation, 29% services, 8% unemployed and underemp1oyed
Organized labor: 70% of total force','c5869dffdbe804a7c23618456f36d7b955922fdbe272b3cf860b9bb01d6f472d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d082a2d0eb0b887d2a51387d9a82095a5728233a5c0ced58f271eebde4af84b',1972,'CY','Cyprus','people-and-society',107,'Population: 14,482,000, average annual growth rate 0.6%
(current); males 15-49, 3,646,000; 2,805,000 fit for -
military service; about 128,000 reach military age
(18) annually
Ethnic divisions: 64.5% Czechs, 29.6% Slovaks, 3.9% Magyars,
1% Germans, 1% Ukrainians, Jews, Poles
Religion: 77% Roman Catholic, 20% Protestant, 2% Orthodox,
1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18% agriculture, 37% industry, 11% services, 34%
construction, communications and others
AUDI ©
LIBYA EGYPT Aner
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
DAHOMEY
44,700 sq. mi.; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and
game preserves 19%, non-arable 1% (1968)
Land boundaries: 1,220 mi.
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 75 mi.
Population: 2,874,000, average annual growth rate 2.8%
(FY65-68); males 15-49, 671,000; 325,000 fit for
military service; about 29,000 males and 27,000 females reach military
age (18) annually; both sexes liable for military service
Ethnic divisions: 99% Africans (42 ethnic groups, most important being Fon, Adja,
Yoruba, Bariba), 5,500 Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most common vernaculars in south,
at least 6 major tribal languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture; 15% civil service,
artisans, and industry
Organized labor: approximately 75% of wage earners, divided among two major
and several minor unions','d31ae41e30177fac542c9a2002623f3f7a98f2f9b7a9458f36c8cf2e156f28ef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7bf1dca8da829039888e3dd07e5539a83c779964bb37f9a29e327877b2c5f44',1972,'DK','Denmark','people-and-society',109,'Population: 4,965,000, average annual growth rate 0.4%
(current); males 15-49, 1,187,000; 1,040,000 fit for military service;
38,000 reach military age (20) annually
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 1%
other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2.4 million; 14.5% agriculture, forestry, fishing, 29.4% mining and
manufacturing, 8.1% construction, 15.0% commerce, 6.6% transportation and
communications, 23.6% services, 0.2% other; 2.6% unemployed
Organized labor: 65% of labor force','1d54476f1151c0c7ecd6517e8c3e1cf13af6a809b3501c98285c843226f5cdbb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c900526418c11a6062385e4f0fc243f122a59de69149a3b86369adc05c37bd37',1972,'DM','Dominica','people-and-society',113,'Population: 73,000, average annual growth rate 1.6%
(April 60-70)
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: est. at 23,000 in 1960; about 50% in agriculture
Organized labor: 25% of the labor force','f2fa463e30609d4e09d8f77bafdf1bed806e18813713402f1de1b995e7ec40c6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('239ece8897bdbca1748997f674960ca99b230adc69892aaed35660ad41e9d831',1972,'EC','Ecuador','people-and-society',116,'Population: 6,508,000 (excluding nomadic Indian tribes),
average annual rate of growth 3.3% (FY71); males
15-49 1,516,000; 970,000 fit for military service; average number
reaching military age (20) annually 63,000
Ethnic divisions: 41% mestizo, 39% Indian, 10% white, 5% Negro, 5% Oriental and
other
Religion: 95% Roman Catholic (majority nonpracticing), trace of Evangelical
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 55% agriculture, 16% manufacturing, 4%
construction, 7% trade, 9% services, 9% other; shortage of skilled labor
Organized labor: 12% of labor force','8b2c2c713b608b08daf023269d5a9bc486dffccfe81d36b0d211dfa8c8a77a7f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('274af9aa7feaad0a93038af574ef9a8ed02dc459e196b0224dc4517c04e0b372',1972,'EG','Egypt','people-and-society',120,'Population: 34,950,000, average annual growth rate 2.4% (FY71); males 15-49,
7,990,000; 5,045,000 fit for military service; about 352,000 reach military
age (20) annually
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek, Italian, Syro-Lebanese
Religion: 94% Muslim, 6% Copt and other
Language: Arabic official, English and French widely understood by educated
classes
Literacy: around 40%
Labor force: 8 to 12 million; 45% to 50% agriculture, 10% industry, 10% trade
and finance, 30% services and other; serious shortage of skilled labor
Organized labor: 7 to 3 million','eab4bb08d70e304219693c1da2274d1f0d71d6ccb24073269d5248389e85ef10','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0adbde28e4f04810293f729db7fe365d37df6aba049729be8fe0a446ed6907d3',1972,'SV','El Salvador','people-and-society',124,'Population: 3,664,000, average annual growth rate 3.4%
(May 61-June 71); males 15-49, 845,000; 520,000 fit
for military service; 36,000 reach military age (18) annually
Ethnic divisions: 84%-88% mestizo; Indian and white minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably 97%-98%
Language: Spanish
Literacy: 50% of population 10 years of age and over (1966 est.)
Labor force: 1,126,000 (est. mid January 1971); 57% agriculture, 14% services,
14% manufacturing, 6% commerce, 9% other; shortage of skilled labor, but
manpower training programs improving large pool of unskilled labor
Organized labor: 4.5% of total labor force; 8% of nonagricultural labor force','1ee5fcbbf42f2bcadc128b133b4caca82e4ebed1263195a9df5e0419a040bbd3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9e25fba95b3387f2b6b9f1aa02d80e836b142cc00d518c3f9fbcc8407c6f6eb',1972,'GQ','Equatorial Guinea','people-and-society',128,'Population: 302,000, average annual growth rate 1.8%
(FY69); Rio Muni, 215,000, average annual growth rate
1.5% (FY69); Fernando Po, 87,000, average annual growth rate 2.6% (FY69);
males 15-49, 74,000; 35,000 fit for military service
Ethnic divisions: indigenous population of Fernando Po primarily Bubi, some
Fernandinos; of Rio Muni primarily Fang; some 10,000-20,000 Nigerians, mostly
on Fernando Po; less than 1,000 Europeans, primarily Spanish
Religion: natives all nominally Christian and predominantly Roman Catholic; some
pagan practices retained
Language: Spanish official language of government and business; also pidgin
English, Fang
Literacy: approximately 90% among younger generation
Labor force: most Equatorial Guineans involved in subsistence agriculture;
small wage labor force dominated by Nigerian contract laborers','7148e005192214eab8b7427e518baca31b0a3903a4119b524b8a6ed4e8b76e29','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ede40dc788589a6eaa59fe060cba1cf9a6a16837b0ec6aede7ef2656a8eefd42',1972,'ET','Ethiopia','people-and-society',132,'Population: 26,518,000, average annual growth rate 2.3%
(FY69); males 15-49, 6,715,000; 3,465,000 fit for
military service
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%, Sidamo 9%, Shankella 6%,
Somali 6%, Afar 4%, Gurage 2%, other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Muslims , 15%-20% animist, 5% other
Language: Amharic official; many local languages and dialects; English major
foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10% government, military,
and quasi-government
Organized labor: 60,000 registered labor union members
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
FAEROE ISLANDS
540 sq. mi.; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited
islands and a few uninhabited islets (1966)
Limits of territorial waters (claimed): 3 n. mi.;
fishing, 12 n. mi. (from extended base lines)
Coastline: 475 mi.
Population: 39,000, average annual growth rate 0.7%
(FY67-70); males 15-49 included with Denmark
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faeroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufacturing, transportation,
and commerce
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
FALKLAND ISLANDS (MALVINAS )*
LAND:
Colony -- 4,700 sq. mi.; area consists of some 200 small
islands, chief of which are East Falkland (2,580 sq.
mi.) and West Falkland (2,038 sq. mi.); dependencies --
consists of the South Sandwich Islands, South Georgia,
and the Shag and Clerke Rocks (1966)','0a1212316ba4c4d3e24541b9ad661c23bb5aebfe58639a29890f1322d05558aa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e38019f019dd5234761cd77d6a503a9c56aa3272a87c809091fa3d6a3066750f',1972,'FJ','Fiji','people-and-society',136,'Population: 542,000, average annual growth rate 2.1%
(FY71); males 15-49, 139,000; 75,000 fit for
military service; 6,000 reach military age (18) annual ly
Ethnic divisions: 42% Fijian, 50% Indian, 8% European, Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu with a Muslim minority
Language: English and Fijian (official), Hindustani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no breakdown on remainder
Organized labor: about 50% of labor force organized into 22 unions; unions
organized along lines of work, breakdown by ethnic origin causes further
fragmentation','e32f75554f76411428173b1d91bf4828c8ab5f56e323fef59f842692d2a31567','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('738e4dd96e47b8c1052d3aca09e4ab2ada4772750ee5012287b8c88d6123892b',1972,'FI','Finland','people-and-society',140,'Population: 4,688,000, average annual growth rate 0.4%
(January 71-72); males 15-49, 1,203,000; 900,000
fit for military service; 40,000 reach military age
(17) annually
Ethnic divisions: homogeneous white population, small Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and Russian-speaking minorities
Literacy: 99%
Labor force: 2.3 million; 28.1% agriculture, forestry, and Fishing, 24.2% mining
and manufacturing, 9.0% construction, 13.7% commerce, 6.6% transportation and
communications, 16.5% services; 1.9% unemployed
Organized Tabor: 60% of labor force','5b3445c457d2106839dc226daa2a5a1d460e0b529b6c84b81f5d2cb86a283d0e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaa554fa994c7bc2951b4364cc050cc98d51d3f88ade3f08949e074e7a095081',1972,'FR','France','people-and-society',144,'Population: 51,737,000, average annual growth rate 0.8%
(FY66-71); males 15-49, 12,525,000; fit for military
service 10,090,000; 422,000 reach military age (18) annually
Ethnic divisions: 45% Celtic; remainder Latin, Germanic, Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1% Muslim (North African
workers), 11% unaffiliated
Language: French (100% of population); rapidly declining regional patois --
Provencal, Breton, Germanic, Corsican, Catalan, Basque, Flemish
Literacy: 97%
Labor force: 20,002,240; 15.4% agriculture, 39.5% industry, 44.9% services,
2% unemployed
Organized labor: 17% of labor force, 23.4% of salaried labor force','f4e73bed9be1d9539ff4ba7fa6f087901bbfcf6e4d21c042a8a79b05ebf08d9b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3417fbfb1fee63617b2566a96bde12e92d92d724c1a71106e0a299437d272e2a',1972,'GF','French Guiana','people-and-society',146,'Population: 56,000, average annual growth rate 5.0%
(FY67-70); males 15-49, 13,000; 9,000 fit for
military service
Ethnic divisions: 95% Negro or mulatto, 5% caucasian or East Indian
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construction 21%, agriculture
18%, industry 8%, transportation 4%; information on unemployment unavallabile
Organized labor: 7% of labor force
Population: 125,000 (official estimate for 1 July 1967);
males 15-49, about 30,000; about 15,000 fit for
military service
Ethnic divisions: 59,350 Somalis (large number of the Somalis:are temporary
‘immigrants from Somalia -- not citizens of territory), 53,650 Afars, 6,000
Arabs, 7,000 French (inclusive of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely. used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at port
Organized labor: some 3,000 railway workers organized
102,000 sq. mi.; 75% forested, 15% savanna, 9% urban and
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','695029350db2850174a0bde1aceafe9f89843c3d31956835c0cbf3b94bad1d0e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdfa0b93e542dcb3eb600c67129aaac1d7f4e6a0a62c9fdfe1e41f2163d96258',1972,'GA','Gabon','people-and-society',149,'wasteland, less than 1% cultivated (1967)
Land boundaries: 1,505 mi.
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 550 mi.
Population: 517,000, average annual growth rate 1.7%
(FY67-70); males 15-49, 127,000; 63,000 fit for
military service; 5,000 reach military age (18)
annually
Ethnic divisions: about 40 Bantu tribes, including 4 major tribal groupings
(Fang, Eshira, Mbede, Okande); about 21,000 expatriate Africans and
Europeans, including 14,000 French
Religion: 55% to 75% Christian, less than 1% Muslim, remainder animist
Language: French official language and medium of instruction in schools; Fang
is a major vernacular Tanguage
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage earners in the modern sector
Organized labor: less than 30% of wage labor force
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','080d72faf199ceff3ed42358cd74c373b3e40bc925e3a4275894158d5b142c0a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15058bb61cb1981ff37de1045028cfaaf129d009b57945278a9979d87b5debbc',1972,'GM','Gambia','people-and-society',153,'4,000 sq. mi.; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up
areas, etc.
Land boundaries: 460 mi.
Limits of territorial waters (claimed): 50 n. mi.
(fishing, 18 n. mi.)
Coastline: 50 mi.
Population: 379,000, average annual growth rate 2.0%
(FY69-70); males 15-49, 90,000; 43,000 fit for military service
Ethnic divisions: over 99% Africans (Malinke 40.8%, Fulani 13.5%, Wolof 12.9%,
remainder made up of several smaller groups), fewer than 1% Europeans and
Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof most widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in subsistence farming; about
15,000 are wage earners (government, trade, services)
Organized labor: 25% to 30% of wage labor force at most','f27151fedacd2afe2689b37ccaa2f1172accaf4f92670185f53af16038015272','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdd083c8adaf5205e17813a8b359511e704695a28e070023420c243a2bf02901',1972,'GH','Ghana','people-and-society',158,'Population: 9,039,000, average annual growth rate 2.4%
(March 60-70); males 15-49, 2,060,000; 1,105,000 fit
for military service; 105,000 reach military age
(18) annually
Ethnic divisions: 99.8% Negroid African (major tribes Fanti, Ashanti, Ewe), 0.2%
European and other
Religion: 45% animists, 42.8% Christian, 12% Muslim
Language: English official; African languages include Akan 44%, Mole-Dagbani 16%,
Ewe 13%, and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing, 16.8% industry, 15.2%
sales and clerical, 4.1% services, transportation, and communications,
2.9% professional; 400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor force','43331b70007da2013674aa01228d911dd62d6d6195e82abbc5ebaf617c20414f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2ff6210fd219f681cfc8695fa50315e87e2b8ea640744826c639fffb9094a75',1972,'GI','Gibraltar','people-and-society',162,'Population: 27,000 (official estimate for 1 July 1971);
males 15- 4S , about 6,000; about 3,000 fit for military
service
Ethnic divisions: mostly Italian, English, Maltese, and
Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages; Italian, Portuguese, and
Russian also spoken; English used in the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian laborers
Organized labor: 3,369, in 27 registered trade unions','58fb7de83863ca6bc6c9b06f2801c86d7ef70d79c31435818c2e80dc2c991b29','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f1fb17557bc571518285a697ea782e5bb82f92d2e80bc071d32112fe8769ccc',1972,'GR','Greece','people-and-society',164,'Population: 8,783,000, average annual growth rate 0.4%
(March 61-71); males 15-49, 2,147,000; 1,730,000 fit
for military service; about 69,000 reach military age (21) annually
Ethnic divisions: 96% Greek, 2% Turkish, 1% Albanian, 1% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total about 82%
Labor force: 3,866,000 (1969 est.); 50% agriculture, 15% industry, 9% trade,
26% other; unemployment and underemployment, 20% total in all fields;
shortage of skilled labor in nonagricultural sectors aggravated by large-
scale emigration
Organized labor: 10% of labor force','d2faf51526bcfe25cd57dae2f0b8e876969a51c889cc7d47e6bd9a6eb5d6d16d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de2cbab647b0f7f2d5d2056a967d439ff2da0b5c98611dc968ed0b31b741c84e',1972,'GL','Greenland','people-and-society',168,'Population: 49,000, average annual growth rate 2.2%
(FY70); males 15-49, included with Denmark
Ethnic divisions: 86% Greenlander (Eskimos and Greenland-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep breeding','ccaf3adc9d4528dce87f7c2f1ddff87535f9f9a6b4fad7fa53cb3248f8d299df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b86a71603cd4bec49dd2421c0b1f2d28734cb1896912e89939e7732e42e63603',1972,'GP','Guadeloupe','people-and-society',173,'‘ Population: 337,000, average annual growth rate 1.5%
(FY71); males 15-49, included with France
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force','9dab2502434eb61c5c4ebb73c11382d731ea5ebdf97053f0e36178b43cc2aaa4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c6977f7602e142f45551dbcb045319382b2a2c17e16851c9a5d318b9bba6555',1972,'GT','Guatemala','people-and-society',175,'Population: 5,573,000, average annual growth rate 2,8%
(current); males 15-49, 1,367,000; 690,000 fit for
military service; about 60,000 reach military age
(18) annually
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks an Indian language as
a primary tongue
Literacy: about 30%
Labor force: 1.5 million (1969); 63.2% agriculture, 12.4% manufacturing, 11.8%
services, 12,6% other, 2% unemployed; severe shortage of skilled labor;
oversupply of unskilled labor; of this total an estimated 10% are unemployed
at any one time
Organized labor: 5% of labor force (1970)','575d6a656f089ceb2f8b6cd85e8f361f953f2ab8d16498a7a49018ef3d4886a1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2b728008737911d70ff58e545ec9d3d8cca40adb0fd8d81048b64a4693b7892',1972,'GN','Guinea','people-and-society',177,'Population: 4,016,000, average annual growth rate 2.6%
(FY67); males 15-49, 949,000; 455,000 fit for
military service
Ethnic divisions: 99% African (3 major tribes - Fulani,
Malinke, Soussou; and 13 smaller tribes)
Religion: 80% Muslim, 19% animist, 1% Christian
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written language
Labor force: 1.5 million, of which less than 10% are wage earners; most of
population engages in subsistence agriculture
Organized labor: virtually 100% of wage labor force loosely affiliated with the
National Confederation of Guinean Workers, which is closely tied to the PDG','c93a8e19eb93fa0bac1010401d9deff6f738fe7634222ddf3db9350eb4725c93','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c07ef6903198e77b23289f54025e082d3e95dd1a69ea81d9371b7147b4bdd2f',1972,'GY','Guyana','people-and-society',181,'Population: 754,000, average annual growth rate 2.5%
(April 60-70); males 15-49, 175,000; 120,000 fit
for military service
Ethnic divisions: 50% East Indians, 44% Negro and Negro mixed, 4% Amerindian, 2%
white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1% other
Language: English
Literacy: 86%
Labor force: 175,000; about 75% agriculture, 10% mining, services, and
manufacturing, 15% other; 21% unemployed; shortage of technical and
managerial personnel
Organized labor: 25% of labor force','e33eab8673506c646b5cd8307a1b1fc7c4f57cf4e9338ed9576e6d797811fb7e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e13f5f77f99420db93c7c2b68ccdee1930562818b60c7428358fedf37317fcff',1972,'HT','Haiti','people-and-society',185,'Population: 5,073,000, average annual growth rate 2.1%
(FY71); males 15-49, 1,269,000; 650,000 fit for
military service; about 47,000 reach military age
(18) annually j
Ethnic divisions: over 90% Negro, nearly 10% mulatto, few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of which an overwhelming
majority also practice Voodoo)
Language: French (official) spoken by only 10% of population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.6 million (est. January 1968); 86% agriculture, 12% industry,
2% unemployed; shortage of skilled Tabor; unskilled Tabor abundant
Organized labor: less than 1% of labor force','cc3ee87b754efb069e8073a0b6f1e2e7f78cc593d8f262913db1a94e936dd6a3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd488a32b29fc743f1d97ba21e0b40de216c073a5fb0314992c7f4f87f6a2dae',1972,'HN','Honduras','people-and-society',189,'Population: 2,765,000, average annual growth rate 3.5%
(FY70); males 15-49, 680,000; 400,000 fit for
military service; about 28,000 reach military age
(18) annually
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and 1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over
Labor force: approx. 900,000 (est. mid-1972); 66% agriculture, 12% services, 8%
manufacturing, 5% commerce, 6% unemployed, 3% unspecified
Organized labor: 5% of labor force (mid-1972)','06927062f2fc0758fff09679d32f4b6b0e7b58ef4bdf62b660ccf83ad8cd6388','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1698efe41551c0e2e87e1a7bc9bbcbadac8b51a26c03131c404b898f0b9be97',1972,'HK','Hong Kong','people-and-society',193,'Population: 4,073,000, average annual growth rate 2.3%
(March 61-71); males 15-49, 1,033,000; 800,000 fit
for military service; about 45,000 reach military age
(18) annually
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local religions
Language: Chinese, English
Literacy: 75%
Labor force (1969 est.): 1.52 million; 40% manufacturing, 28% services, 11%
construction, mining, quarrying and utilities, 11% commerce, 5% agriculture,
forestry, fisheries, and hunting, 6% communications, 2% other; under-
employment is a serious problem
Organized labor: 12% of 1969 labor force
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','4717a56d14607927b8b6b7f401a21382fcb2b086a74aeab729d2b8f4f9f9de79','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2f15147a3fef28e5a63b3fd699b901065230de6a7d297f9ee9f383c1a731216',1972,'HU','Hungary','people-and-society',196,'35,900 sq. mi.; 60% arable, 14% other agricultural, 16%
forested, 10% other (1968)
Land boundaries: 1,395 mi.
Population: 10,390,000, average annual growth rate 0.3%
(current); males 15-49, 2,658,000; 2,140,000 fit for
military service; about 94,000 reach military age
(18) annually
Ethnic divisions: 93.3% Magyar, 2.5% German, 2.4% Gypsy,
0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20% Calvinist, 5%
Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5.0 million; 26% agriculture, 44% industry and building, 30%
other nonagricultural
SAUOT Se,
EGYPE, ARABIA “Foy','a930137ada38d546f79f2631b03db40c738a7a9e3175570d777d4e56aa50df6b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('285da5307363a881872d51806647f8e62ca7beb6365c2bf31c0c366d1ad2cde4',1972,'IN','India','people-and-society',204,'Population: 564,235,000 (including Sikkim and the Indian-held part of disputed
Jammu-Kashmir, and excluding the several million refugees who entered India
from East Pakistan during 1971), average annual growth rate 2.5% (FY71);
males 15-49, 133,973,000; 76,730,000 fit for military service; about 6,014,000
reach military age (17) annually
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.5% Christian, .7% Buddhist,
.8% other
Language: 24 languages spoken by a million or more persons each; numerous
other languages and dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of 30% of the people;
English enjoys "associate" status but is the most important language for
national, political, and commercial communication; Hindustani, a popular
variant of Hindi/Urdu, is spoken widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971 census)
Labor force: about 184 million; 70% agriculture, more than 10% unemployed and
underemployed; shortage of skilled labor is significant and unemployment is
rising
Organized labor: about 2.5% of total labor force','740d6769bd2a8faea5c3396a22a3edfb03684b10e82a2dfc5cf7e7f8c2f2d51e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a46cacb9c6a62fd916b388901c6a5b638d864cf728bf6423fbe54d6202c0711d',1972,'IT','Italy','people-and-society',212,'Population: 54,379,000, average annual growth rate 0.8%
(FY60-67); males 15-49, 13,500,000; 11,355,000 fit
for military service; 407,000 reach military age (18) annually
Ethnic divisions: a composite of the Mediterranean, Alpine, Adriatic, and Nordic
racial types; Mediterranean type predominates in southern and insular Italy
Religion: almost 100% nominally Roman Catholic (de facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region (e.g., Bolzano) are
predominantly German speaking; significant French-speaking minority in Valle
d''Aosta Region; Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5-7% of population illiterate (1967); illiteracy varies widely by region
Labor force: 19,752,000 (October 1970); 18.9% agriculture, 42.0% industry,
37.2% other, 3.1% unemployed; underemployment, particularly in southern
Italy, remains widespread; 1.5 million Italians employed in other Western
European countries
Organized labor: 20% (est.) of labor force
Population: 4,934,000 (resident African population only),
average annual growth rate 3.3% (January 66-71); males
15-49, 1,679,00; 500,000 fit for military service
Ethnic divisions: 7 major indigenous ethnic groups; no single tribe more than
20% of population; most important are Agni, Baoule, Krou, Senoufou, Mandingo;
approx. 1 million foreign Africans, mostly Voltaics; about 33,000 non-Africans
(25,000 French)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in agriculture, forestry, livestock
raising; about 11% of labor force are wage earners, nearly half in agricul-
ture, remainder in government, industry, commerce, and professions
Organized Tabor: 20% of wage labor force','5524c2c887f3ed7352c3cbdbee7d02f45fcb30a22785ed03ad6158dbd17730a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a8770680352fc2f8e016c0f47597d38f3bea8f0f7e3028779836469f284ccc3',1972,'JM','Jamaica','people-and-society',217,'Population: 1,925,000, average annual growth rate 1.5%
(April 60-70); males 15-49, 404,000 270,000 fit for
military service; no conscription; average number
currently reaching minimum volunteer age (18) 22,000
Ethnic divisions: African 76.3%, Afro-European 15.1%, Chinese and Afro-Chinese
1.2%, East Indian and Afro-East Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman Catholic, some spiritualist cults
Language: English
Literacy: Ministry of Education estimates between 43% and 57% of adult population
functionally literate
Labor force: about 687,000; 33% in agriculture, 1% forestry and fishing, 13%
manufacturing, 7% construction, 8% commerce, 2% transportation and communi-
cations, 13% services, 23% unaccounted for; 16% to 20% (est.) unemployed
(seasonal unemployment in agriculture can push the unemployment figure to
25%); shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)','a4c5a92f2613190f62feb22dd18fcc959a6da2d8291976014cdfb34d86b38b18','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('038ad266815dcd7f7addb8abb40912b8b036757670144dd3234b527d6fac6e9b',1972,'JO','Jordan','people-and-society',221,'Population: 2,429,000, average annual growth rate 3.1% (current); males 15-49,
568,000; 435,000 fit for military service; average number currently reaching
military age (18) annually 25,000
Ethnic divisions: 97% Arab, 2% Circassian, 1% Armenian
Religion: 94% Sunni Muslim, 6% Christian
Language: Arabic official, English widely understood among upper and middle
classes
Literacy: 33% West Jordan, 32% East Jordan
Labor force: 434,000; 33% unemployed
Organized labor: 5% of labor force','5e29e80b80e7c958bb03ffd5bf0f03d974daa28dc6ff29d8a08f8feed7c9c84b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee78f3d8aed76ba9042eba0d56148ca3ad91021ae1c77be34c86a08f14ee45a7',1972,'KE','Kenya','people-and-society',225,'Population: 12,086,000, average annual growth rate 3.4%
(FY66-71); males 15-49, 2,694,000; 1,310,000 fit for
military service; no conscription
Ethnic divisions: 97% native African (including Bantu, Nilotic, Hamitic and
Nilo-Hamitic); 3% European, Asian, and Arab
Religion: 56% Christian, 36% animist, 7% Muslim, 1% Hindu
Language: English and Swahili official; each tribe has own language
Literacy: 20% to 25%
Labor force: 2.5 million; about 977,000, (39%) in monetary economy (1967)
Organized labor: about 215,000
Population: 14,975,000, average annual growth rate 2, 8%
(current); males 15-49, 3,319,000; 1,970,000 fit for
military service; 164,000 reach military age (18)
annually
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 47.7% agriculture, 52.3 non-agricultural; shortage of
skilled and unskilled labor
Population: 32,537,000, average annual growth rate 1.9%
(October 66-70); males 15-49, 7,850,000; 4,970,000 fit
for military service; average number reaching military
age (18) annually 338,000
Ethnic divisions: homogeneous; small Chinese minority (approx. 20,000)
Religion: strong Confucian tradition; pervasive folk religion (Shamanism) ;
vigorous Christian minority (5.5% of population); Buddhism (including
estimated 20,000 members of Soka Gakkai); Chondokyo (religion of the heavenly
way), eclectic religion with nationalist overtones founded in 19th century,
claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.2 million (1971); 46.2% agriculture, fishing, forestry,
32.3% services, 14% mining and manufacturing, 3% construction, 4.5% unemployed
Organized labor: about 10% of nonagricultural labor force
Population: 912,000, average annual growth rate 9.8%','1905ed7b35bd847a80dd1cacc2e69a92bd8c126994328402e194c374f8db5ce0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57516acf17daa16e484dfbd7df9b48e2381f9dc43984641deab05d46052f91db',1972,'KW','Kuwait','people-and-society',228,'insignificant amount forested; nearly all desert,
waste, or urban (1969)
(FY71); males 15-49, about 311,000; about 170,000
fit for military service
Ethnic divisions: 87% Arabs, 12% Iranians, Indians, and Pakistani, 1% other
Religion: 95% Muslim, 5% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign language
Literacy: about 55% (1965)
Labor force: 250,000 (1969); 9% manufacturing, 16% construction, 45% services,
13% commerce
Organized labor: labor unions, first authorized in 1964, formed in oi] industry
and among government personne]
Population: 3,106,000, average annual growth rate 2,4%
(FY71); males 15-49, 742,000; 395,000 fit for military
service; average number currently reaching usual
military age (18) annually, 33,000; no conscription
age specified
Ethnic divisions: 47% Lao; 14% Tai; 25% Phoutheng (Kha), Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign language also used in
administration
Literacy: about 12%
Labor force: about 1,268,000; 80%-90% agriculture; 159,286 engaged in
manufacturing and services; 11,864 government employees
Organized labor: only civil servants are organized','dd6c6f835ef1dc096152773c965ae3a7a08984ade62dc7878fd57852544e47f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e062a1b5c955a98b89dcf488689420a8d950a9c7d29b37c2ad951d325addca5d',1972,'LB','Lebanon','people-and-society',233,'Population: 2,963,000 (including Lebanese nationals living
outside the country who are on the population register,
but excluding registered Palestinian refugees numbering
176,000 on 30 June 1970), average annual growth rate 3.1% (current); males
15-49, 715,000; 420,000 fit for military service; average of about 30,000
reach military age (18) annually
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1% other (official estimates);
Muslims believed to constitute slight majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically active; 49% agriculture, 11% industry,
14% commerce, 26% other; moderate unemp]oyment
Organized Tabor: about 55,000','7c8e10c09346bd5d5dbf07fbd412ac47e59fc9ff0fa1975d7c85427fea250211','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b16b402d1666e8ac67617c7fca684bdc64830b3e5905846999da43417eb08cf',1972,'LS','Lesotho','people-and-society',237,'Population: 956,000, average annual growth rate 1.9%
(April 70-71); males 15-49, 194,000; fit for military
service 100,000
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800 Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in subsistence agriculture;
150,000 to 250,000 spend 6 months to many years as wage earners in South
Africa
Organized labor: negligible','a03a6aa4bbd590f0a2bd0a53b4d5ee7393e6f3aee8145807a37f2a6f2cf7936d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6b75292055dccb034c37435fd8a227f6cb674f53cdcd0bbbda7a49beace75e3',1972,'LR','Liberia','people-and-society',241,'Population: 1,632,000, average annual growth rate 3.5%
(current); males 15-49, 289,000; 160,000 fit for
military service; no conscription
Ethnic divisions: 5% coastal descendants of immigrant Negroes; 95% indigenous
Negroid African tribes including Gola, Kissi, Vai, Kpelle, Kru, and Mandingo
Religion: probably more Muslims than Christians; 80%-90% animist
Language: English official; 28 tribal languages or dialects, pidgin English used
by about 20%
Literacy: about 24% over age 5
Labor force: 450,000, of which 360,000 are in tribal, nonmonetary economy; of
90,000 in modern economy, 45% in agriculture; 23% government services; 20%
mining, construction, and manufacturing; and 12% in trade and transportation;
about 3,000 non-African foreigners hold about 95% of the top level manage-
ment and engineering jobs
Organized labor: 2% of labor force','a046e7536b821026c6711e54780ba42ce49d975fb4fb476d3bcdd1e757e41127','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c3e5c22b7c95fa593f919b208404bea1c61028ce533c01b075f786220a02bc4',1972,'LY','Libya','people-and-society',244,'Population: 2,083,000, average annual growth rate 3.6%
(FY71); males 15-49, 477,000; 285,000 fit for military
service; about 20,000 reach military age (17) annually;
conscription now being implemented
Ethnic divisions: 97% Berber and Arab with some Negroid stock; some Greeks,
Maltese, Jews, Italians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood in major cities
Literacy: 35%
Labor force: 458,000-500,000; between ages 15-64, 405,000-430,000; 61% of labor
force in agriculture (1964)
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','1b8294215bdeaca50cf349187f2040aa28f476f84e18741db24ac710305d8507','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('587c92c922e27a37dc8f62e6d4ce5427358ff683724f6a46886970fdd34b1cd5',1972,'LI','Liechtenstein','people-and-society',245,'65 sq. mi.
Land boundaries: 47 mi.
¢
FEO. ig
(7 REP.)
“GERMANY 5
oF
East POLAND
Population: 22,000, average annual growth rate 2.4%
(December 60-70)
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and
commerce, 13% professional and other, 8% agriculture','d4f412ab0adb812f67399df466b7638a5e1c997d14fa66f4462a886e13b4fb00','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8fc5abdf0dae44adbd61db8b830edae21aeaa2e350fe7f47d0ad9b00e866013',1972,'LU','Luxembourg','people-and-society',250,'Population: 342,000, average annual growth rate 0.5%
(FY66-71); males 15-49, 78,000; 62,000 fit for
military service; about 2,500 reach military age (19)
annually
Ethnic divisions: 83% Luxembourger, including an estimated
5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: 90% Roman Catholic, remaining 10% Protestant and Jewish
Language: Luxembourgish, German, French; most educated Luxembourgers also speak
English
Literacy: 98%
Labor force: (1969) 139,000; 11.1% agriculture (including forestry and fishing),
44.2% industry, 44.7% services, no significant unemployment; shortage of
skilled labor 800 (1970); 30% of labor force is foreign, comprising in almost
equal proportions, Italian, Belgian, and German workers
Organized labor: 45% of labor force','66b421baf0b16821fe2a942b161861969cfbd27c2ce491cb42df2b6a57ef1f15','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d19e447d4f2d08aee78388f424e20cb6e61a9ac3cdf93668795a9e817dcfe4c6',1972,'MO','Macao','people-and-society',254,'Population: 242,000 (official estimate for 31 December
1969); males 15-49, 67,000; 42,000 fit for military
service
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about one-half are Chinese
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and Macanese; no data on Chinese
population
Labor force: 5% agriculture, 30% manufacturing, 3% construction, 1% utilities,
27% commerce, 8% transportation and communications, 26% services (1960 data)
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
MALAGASY REPUBLIC
230,000 sq. mi.; 5% cultivated, 58% pastureland, 21%
forested, 8% wasteland, 2% rivers and lakes, 6% other
(1965)
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 3,000 mi.
Population: 7,060,000, average annual growth rate 2,3%
(FY70}; males 15-49, 1,592,000; 935,000 fit for
military service; average number reaching military age
(20) annually about 65,000
Ethnic divisions: basic split between highlanders of predominantly Malayo-Indonesian
origin, consisting of Merina (1,643,000) and related Betsileo (760,000), on
the one hand, and coastal tribes with mixed Negroid, Malayo-Indonesian, and
Arab ancestry on the other; coastal tribes include Betsimisaraka 941,000,
Tsimihety 442,000, Sakalava 375,000, Antaisaka 415,000; there are also 38,000
French, 66,000 other
Religion: more than half animist; about 35% Christian, less than 10% Muslim
Language: French and Malagasy official
Literacy: 30% to 35%
Labor force: about 3.4 million, of which 90% are nonsalaried family workers
engaged in subsistence agriculture; of 175,000 wage and salary earners,
26% agriculture, 17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscellaneous
Organized labor: 4% of labor force','ea48d648bd90492fc94ddfb95376f525c6933ea1e7a825e553d2b5d53aa043b4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0a7000f46135f74964db076f041a3675b094f9819243f20eddd35bde1aee633',1972,'MW','Malawi','people-and-society',258,'Population: 4,663,000, average annual growth rate 2.5%
(FY71); males 15-49, 968,000; about 485,000 fit for
military service
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is second African language
Literacy: 6% of population over 21. years old
Labor force: 180,000 wage earners (1966); 6,000 Europeans permanently employed;
300,000 live and work in Rhodesia, South Africa, and Zambia; 30% agriculture,
11% construction, 10% commerce, 13% manufacturing, 10% administration, 26%
miscellaneous services
Organized Tabor: small minority of wage earners are unionized','3aa2b87408b64e3dc236c31459d26f32b16ad3b0b5d2943357d3d8b5f0fbbc05','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cc1816de7f79f1d9ac086dc060e79a6a983d9a6c07d407d9dac3b9580a97e67',1972,'MY','Malaysia','people-and-society',262,'Population: 10,957,000, average annual growth rate 2.7% (current)
West Malaysia: 9,229,000, average annual growth rate 2.6% (June 57-August 70);
males 15-49, 2,158,000; 1,323,000 fit for military service
Sabah: 702,000, average annual growth rate 3.7% (August 60-70); males 15-49,
167,000; 100,000 fit for military service
Sarawak: 1,026,000, average annual growth rate 2.7% (June 60-August 70);
males 15-49, 244,000; 145,000 fit for military service; conscription age
for Malaysia is 21 -- an age reached by about 1121,000 annually
Ethnic divisions:
Malaysia: 44% Malay, 36% Chinese, 8% tribal, 10% Indian and Pakistani,
2% other
West Malaysia: 50.1% Malay, 36.9% Chinese, 11% Indian and Pakistani,
2% other
Sabah: 23.1% Chinese, 67.3% indigenous tribes, 9.6% other
Sarawak: 31.5% Chinese, 50% indigenous tribes, 17.5% Malay, 1% other
Religion:
West Malaysta: Malays nearly all Muslim, Chinese predominantly Buddhists,
Indians predominantly Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist, 16% Christian, 35%
tribal religion, 2% other
Language:
West Malaysia: Malay (official); English, Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dialects, Mandarin and Hakka dialects
predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal languages
Literacy:
West Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 3.45 million (1967)
West Malaysia: 2.9 million; 55% agriculture, forestry, and fishing, 11%
manufacturing and construction, 34% trade, transport, and services
20]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
PEOPLE (cont''d):
Labor force (cont''d):
Sabah: 213,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade and transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade, transportation, and services,
1% other
Organized labor: 370,000 (official 1967 est.) about 10.5% of total labor force;
28% of wage labor force; unemployment about 8% of total
labor force, but higher in urban areas
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','43bc1520dc2ee79838cd26d35ed90172c7b694a3b5cf536fb2031acdd7cfad79','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2002f819290b7c352bdd766cbf5d3fa6ac9315eda2982f0aeb3071d434f7ddf',1972,'MV','Maldives','people-and-society',265,'115 sq. mi.; 2,000 islands grouped into 12 atolls, about :
220 islands inhabited
Limits of territorial waters (claimed): the land and
sea between latitudes 7°9''N, and 0°45''S. and between
longitudes 72°30''E. and 73°48''E; these coordinates
form a rectangle of approximately 37,000 sq. n. mi.
Coastline: 400 mi. (approx.)
Population: 112,000, average annual growth rate 2% (current)
Ethnic divisions: admixtures of Sinhalese, Dravidian, Arab and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male population
Population: 5,269,000, average annual growth rate 2.4%
(FY69-70); males 15-49, 1,245,000; 700,000 fit for
military service; no conscription
id Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
. Language: French official; several African languages,
of which Mande group most widespread
Literacy: under 5%
Labor force: approximately 60,000 salaried, 40,000 of whom are civil servants;
most of population engaged in agriculture and animal husbandry ;
Organized labor: UNTM, which claimed all eligible employees, dissolved; thirteen
national unions currently directed by a government controlled Coordination
Committee of Mali Trade Unions (CCSM)
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','25ef25a0bcd2413e3831418df26bbcfcbf2e8f3b35438d5bfe168b7530e62aa9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('805ab84483ac0a7c8f396a5b52502fd00fd08f05ec060a8f689e86ccab579399',1972,'MT','Malta','people-and-society',269,'121 sq. mi.; 50% arable, negligible amount forested,
remainder urban, waste, or other (1965)
‘
Limits of territorial waters (claimed): 6 n. mi.
Coastline: 87 mi.
Population: 325,000 {official estimate for 30 June
1971); males 15-49, 86,000; 65,000 fit for military
service
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in 1946
Labor force: 99,000; 38% services, 28% government, 21% manufacturing, 7%
agriculture, 6% unemployed
Organized labor: approximately 33% of labor force','234b04a7d627f781fd0eb3d14537684c09b93359bbd6d321db581c687dd29910','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e42e30e712387d9b62e3de0be303399a5cc478116bc5884d809038c5361615a',1972,'MQ','Martinique','people-and-society',274,'Population: 346,000, average annual growth rate 1.6%
(FY68-70); males 15-49, included in France
Ethnic divisions: 90% African and African-Caucasian-Indian
mixture, less than 5% East Indian, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 25% agriculture, 25% unemployed
Organized labor: 17% of labor force','cce30bbd640a732967ab5fe421576b1a4ee89006fe1f0713491908f987f5bade','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6b6ee5a35bba218a9be6a605f00a19bddb6549f8badfbd246e890fb3ff9748e',1972,'MR','Mauritania','people-and-society',278,'Population: 1,227,000, average annual growth rate 2.3%
(FY67-68); males 15-49, 290,000; 142,000 fit for
military service; conscription law not implemented
Ethnic divisions: 70% Moor, 30% Negro
Religion: nearly 100% Muslim
Language: French and Arabic official
Literacy: under 5% ;
Labor force: about 18,000 wage earners (1964); remainder of population in
farming and herding
Organized labor: 18,000 union members claimed by single union, Mauritanian
Workers'' Union
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','1dfe7bf1655526f66426ac3cdf50e94af4e63ebc55b0780c14aaecb8e6b7d57a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('904511113aeab01f1400f63ea8529f30764f52e8434b55ae522deb2d9fe61b45',1972,'MU','Mauritius','people-and-society',281,'720 sq. mi. (excluding dependencies); 50% agricultural, in-
tensely cultivated; 39% forests, woodlands, mountains,
river, and natural reserves; 3% built-up areas; 5%
water bodies, 2% roads and tracks, 1% permanent
wastelands (1970)
Limits of territorial waters (claimed): 12 n, mi.
Coastline: 110 mi.
Population: 863,000, average annual growth rate 1.6%
(FY70); males 15-49, 203,000; 100,000 fit for military service
Ethnic divisions: Indians 67%, Creoles 29%, Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly Catholic with a few Anglican
Protestants), 16% Muslim
Language: English official language; Hindi, Chinese, French Creole
Literacy: estimated 60% for those over 21, and 90% for those of school age
Labor force: 120,000; 65% agriculture, 5% industry; 30% are unemployed, under-
employed, or self-employed
Organized labor: about 10% of labor force
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','cc7004b39119423872001344ffb24e1c57220abdaf0afb08d2252d0428c4c468','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fdefc2f81fd84fc918030256559b67d5f1a015d5c8f2e17d5b89e1defcda291',1972,'MC','Monaco','people-and-society',285,'0.6 sq. mi.
Land boundaries: 2.3 mi.
( \\
cast POLAND
(7 REA J
"GERMANY 5
oF \\
GERMANY \\ CZECH.
Limits of territorial waters (claimed): 3 n. mi. (fishing
12 n. mi.)
Coastline: 2.6 mi.
Lux
USTRIA
FRANCE SWITZY
4 LIECH,
Population: 24,000 (official estimate for 1 January 1970)
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete
Labor force: not available
Organized labor: not available','47b6c8ace3d712210bdc80bcb12bbd3ba1c3dde60716926b3e69c761f3546ecc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5093ae62f64338d4fc17cdcc5c264312b0a580ac6216f5ebe812966ac6bd0db1',1972,'MN','Mongolia','people-and-society',290,'Population: 1,319,000, average annual growth rate 2.8%
(current); males 15-49, 292,000; 185,000 fit for
military service; average number reaching military
age (18) annually, about 14,000 y
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese, 2% AUSTRALIA
Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4% Muslim, limited religious
activity because of Communist regime
Languages: Khalkha Mongol used by over 90% of population; minor languages
include Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the population is in the labor
force, including a large percentage of Mongolian women; acute shortage of
both skilled and unskilled labor (no reliable information available)
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','4ed1df7e599994c1c60c4b3b667cbba721428f4a7f9af920daf9bb580b621467','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29549407ca059b94f1570b35d13906d13a36f40fa5682ba770af7b26338d59c8',1972,'MA','Morocco','people-and-society',293,'158,000 sq. mi.; 19% farmland and orchard, 19% pasture,
20% forest and esparto, 42% desert, waste, or urban
(1965)
Land boundaries: 1,240 mi.
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,140 mi.
Population: 15,746,000, average annual growth rate 2.5%
(June 60-July 71); males 15-49, 3,759,000; 2,550,000 fit for military
service; about 180,000 reach military age (18) annually; limited conscription
Ethnic divisions: 98.9% Arab-Berber, .25% Jewish, 1% non-Moroccan
Religion: 99% Muslim, 1% Christian, .25% Hebrew
Language: Arabic (official); several Berber dialects; French is language of much
business, government, diplomacy, and education
Literacy: 20%
Labor force: 6.1 million; 70% agriculture, 15% industry, 15% other (military,
police, civil service, transportation, mines, teachers, merchants,
construction workers)
Organized labor: 5% to 10% of labor force','42ba42e5d8554c385951dc34909a1628b93858d6b58e9c9b167a3c33d6090dbc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47a01e6f21c2654c0a2141ab3c17310bc978b7c7fc0e924e37ded61c701a628d',1972,'MZ','Mozambique','people-and-society',298,'Population: 8,512,000, average annual growth rate 2.2%
(September 60-December 70); males 15-49, 1,974,000; 950,000 fit for
military service
Ethnic divisions: 97% African, 3% European, Asian, and Mulatto
Religion: primarily animist, 1,100,000 Muslims, 860 ,000 Christians
Language: Portuguese (official); many tribal dialects
Literacy: 10% (estimate)
Labor force: (1963 est.) 610,000; 50,000 non-African wage earners, 560,000
African wage earners in Mozambique; 290,000 additional African wage earners
temporarily working in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 44,000 (end of 1970); 75% are white','dafc1c33d6e446f1d21bfcf031b9c121b81c4e6c7e7739e21baf779f9bbe7e07','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fc2974b93ecbd5b08508f2906d597aadcc1f5a06a79dfee6f5e0185a80325e5',1972,'NR','Nauru','people-and-society',302,'Population: 7,000 (official estimate for 30 June 1969);
males 15-49, about 1,800; fit for military service,
about 950; average number reaching military age (18)
annually, 1971-75, less than 100
Ethnic divisions: 2,921 Nauruans, 1,167 Chinese, 428 Europeans, 1,532 other
Pacific Islanders
Religion: Christian (2/3 Protestant, 1/3 Catholic)
Language: Nauruan, a distinct Pacific Island tongue; English, the language of
school instruction, spoken and understood by nearly all
Literacy: nearly universal','7585dd4fa8736e89c969dc125b06e87cdbc11489731db5d6d418cd1531232c2b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64626566110be4dc05084df3822dc5effaa6e77051dc404e85192c465cc3f74f',1972,'NP','Nepal','people-and-society',306,'Population: 11,445,000, average annual growth rate 1.8%
(FY69); males 15-49, 2,821,000; 1,420,000 fit for
military service; 129,000 reach military age (17)
annually
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%),
representing considerable intermixture of Indo-Aryan and ;
Mongolian racial strains; country divided among many quasi-tribal communities
Religion: only official Hindu Kingdom in world, although no sharp distinction
between many Hindu and Buddhist groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided into numerous dialects;
Nepali official language and lingua franca for much of the country; same
script as Hindi
Literacy: about. 12%
Labor force: 4.1 million; 95% agriculture, 5% industry; great lack of skilled
labor','91efcd0a31d1632db984f93c8b86f1290f8fde14605006178080e8ce2671cccc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7992c3d5135daf71ef18e169e0960b561ae9b6408f433f7f829ac731f63e55ae',1972,'NL','Netherlands','people-and-society',309,'Population: 13,327,000, average annual growth rate 1.0%
(current); males 15-49, 3,337,000; 2,995,000 fit for
military service; average number reaching military age (20) annually 116,000
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 41% Protestant, 40% Roman Catholic, 19% unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24% services, 16% commerce, 10%
agriculture, 9% construction, 7% transportation and communications, 4%
other; 1.05% registered unemployed; no shortage of skilled labor but shortage
of semi-skilled labor; 129,000 unfilled vacancies reported by employers in
January, 197]
Organized labor: 33% of labor force
Population: 230,000, average annual growth rate 1.7% estonia
(January 70-71); males 15-49, 59,000; 30,000 fit
for military service; about 2,000 reach military Sasi
age (20) annually
Ethnic divisions: 85% largely mixed Negro stock except on
Aruba where 12% Negro and approx. 55% mixed Carib Indian and European;
rest European with some Chinese, especially on Aruba
Religion: predominantly Roman Catholic; sizable Protestant, smaller Jewish
minorities
Language: officially Dutch; predominantly English; colloquial “papiamento," a
Spanish-Portuguese-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry, 21% unemployed, 8%
construction, 41% government and services, 8% other
Organized labor: approx. 15% of labor force','1c1b950cfe32d8789d1ad929abca436d67f2151cff0b786c157be4dd095959d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b5eb252824b9bd851f6dd2f130f616a1a8be51021456f2154b9ee7960628174',1972,'NC','New Caledonia','people-and-society',313,'Population: 110,000, average annual growth rate 2.6% (May
63-March 69)
Ethnic divisions: Melanesian-Polynesian admixture, over
28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese laborers were imported for
plantations and mines in pre-World War II] period; immigrant labor now
coming from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized','877be0317923ee36c0cf2e1dd2575009fbbc689aae992723c1aca608f9c27ca1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ad8f05f7ea510c3f33149ccdd699d1b029d0e144ea331f784949fa28f164f33',1972,'NI','Nicaragua','people-and-society',317,'Population: 1,975,000, average annual growth rate 2.8%
(April 63-71); males 15-49, 518,000; 305,000 fit
for military service; 24,000 reach military age (18} annually
Ethnic divisions: 75% mestizo, 15% white, 10% Negro, Indian or mulatto
Religion: 96% Roman Catholic ;
Language: Spanish (official); small English-speaking minority on Atlantic coast
Literacy: 50% of population 10 years of age and over
Labor force: 650,000 (est. 1972); 57% agriculture, 12% manufacturing, 14%
services, 17% other; shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 5% of labor force','b158f57c1e5ff2eefb54751084f2e0a1f6bddbee03a368d490d2014bc5c1531b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('950d07ed4a42f6523d067bb891013d0f2de4ddbd690b86aad8f89e3e9b6ede1a',1972,'NE','Niger','people-and-society',319,'Population: 4,239,000, average annual growth rate 2.7%
(FY71); males 15-49, 1,000,000; 565,000 fit for military
service; about 33,000 reach military age (18) annually
Ethnic divisions: main Negroid groups 75% (of which, Hausa
50%, Djerma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a very few Christians
Language: French official, many African languages; Hausa used for trade
Literacy: about 5%
Labor force: 26,000 wage earners: bulk of population engaged in subsistence
agriculture and animal husbandry
Organized labor: negligible','f990e3285afb90b7e7536cdfa27bb8d476e0643b0b1230ea624cf9e205de0ee5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e67c5d0f59c0c3d4476b694400d7fc6a878f57f4bf886a9f50ddd38f2b814c8',1972,'NG','Nigeria','people-and-society',323,'Population: about 58,020,000, average annual growth rate
2.7% (current); males 15-49, 13,173,000; 6,380,000 fit
for military service
Ethnic divisions: 250 tribal groups, of which most important are Hausa-Fulani
(north), Ibo and Yoruba (south); these 3 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34.5% Christian, 18.3% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and Ibo also widely used
Labor force: approx. 26.6 million; about 48% of total population, 80% of those 11
to 55 years of age of both sexes, are accounted "economically active"; only
about 700,000 are wage earners, of whom 8% are in agriculture, forestry,
hunting, and fishing; 7% mining and quarrying; 8% manufacturing; 22%
construction; 2% electricity; 8% commerce; 8% transportation and communication;
37% services
Organized labor: about 530,000 wage earners, approx. 2% of total labor force,
belong to some 666 unions','36cb43464929a11e41045853840352586fa19546791dcb4fee3134ff7b166173','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf70ebaca8da0a07fbdbea37e3cacb344290529908c8634b48b98c1d98ba1bf0',1972,'NO','Norway','people-and-society',327,'Population: 3,949,000, average annual growth rate 0.9% (current); males 15-49,
912,000; 735,000 fit for military service; average number reaching military
age (20) annually, 31,000
Ethnic divisions: homogeneous white population, small Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant and Roman Catholic, 1%
other
Language: Norwegian, small Lapp and Finnish-speaking minorities
Literacy: 99%
Labor force: 1.6 million; 19.5% agriculture, forestry, fishing, 27.0% mining and
manufacturing, 9.5% construction, 13.3% commerce, 11.9% transportation and
communication, 17.7% services; 1.1% unemployed
Organized labor: 60% of Tabor force','2e02132c89e763751ea1b070dd83195991473b3458305a6002f4114a3ddf214f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db0b856baa2471111820dc7258cb61a956f37fb35f536527f9cffab80b3dfeb6',1972,'OM','Oman','people-and-society',331,'Population: 699,000 (official est. 1 July 1966), average
annual growth rate 3.2% (current); males
15-49, 169,000; 85,000 fit for military service
Ethnic divisions: almost entirely Arab with small] groups of Iranians, Baluchis,
and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','f51f45636ebeef88b8d74883dff6cdbb3d74fb371b6b99d09ab32b9e5b6c1fa2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('039ad8f6c4ba0d7c58f89b961d6baa4cc69907e33ec3c9aadb7f9b2eb8ff2182',1972,'PK','Pakistan','people-and-society',335,'Population: 56,064,000 (excluding Junagardh, Manavador, Gilgit, Battistan, and
the disputed area of Jammu-Kashmir), average annual growth rate 2.4% (FY70),
males 15-49, 13,481,000; 7,240,000 fit for military service; 1,484,000 reach
military age (17) annually
Ethnic divisions: West Pakistan -- 66.4% Punjabi, 12.6% Sindhis , 7.6% Urdu,
4.6% other; East Pakistan -- 98.4% Bengali, 1.6% other
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages -- 7% Urdu, 64% Punjabi, 12%
Sindhi, 8% Pushtu, 9% other; English is lingua franca
Literacy: about 14%
Labor force: 12.7 million (est. 1961); 60% agriculture, 16% industry, 7% commerce,
15% service, 2% unemployed
Organized labor: 5% of labor force','d9305e90ba8bc84f3266808bf0ddda7b96edc743cb29f356efa245fbfd2a82f8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75ce929c5ffc6cd1122aae6815985a8fb2195f4ef83a7bd5d9d0fba6e2ff31ec',1972,'PG','Papua New Guinea','people-and-society',340,'Population: 2,647,000, average annual growth rate 3.1%
(FY67-70); males 15-49, 689,000 (Papua 181,000, New
@ Guinea 508,000); about 360,000 fit for military service
(Papua 95,000, New Guinea 265,000)
Ethnic divisions: predominantly Melanesian and Papuan, some Negrito, Micronesian,
and Polynesian types
Religion: over one-half of population nominally Christian (490,000 Catholic,
320,000 Lutheran, other Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin English and 2 or 3 native languages
are linguae francae for over one-half of population; English spoken by
1% to 2% of poputation
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly subsistence farmers','40c5cd39d3a8bf874635ed36740bbcb0ceabd28badd00247e4adda33fb3d8db8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84946626b9f060b3dd83ada76846faaa842ceb0df1253488d5352a3aee0ace76',1972,'PE','Peru','people-and-society',345,'Population: 14,458,000 (excluding Indian jungle population
which was estimated at 101,000 in 1961), average annual :
growth rate 3.2% (FY71); males 15-49, 3,345,000; 2,265,000 fit for military
service; average number currently reaching military age (20) annually,
138,000
Ethnic divisions: 46% Indian; 38% mestizo (white-Indian); 15% white; 1% Negro,
Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Ouechua, Aymara
Literacy: 45% to 50%
Labor force: 3.5 million (1967); 46% agriculture, 17% services, 14% manufacturing,
9% trade, 4% construction, 4% transportation, 2% mining, 4% other
Organized labor: 25% of labor force','f06d906c38e54f23197a038b8505d035cb97563549b36d1dd1582326b34d232e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d01065593d457030f79ab686c1680738c9434e4c3b23e80bf657c59a367dd343',1972,'PH','Philippines','people-and-society',349,'Population: 39,445,000, average annual growth rate 3.1%
(February 60-May 70); males 15-49, 8,970,000; 5,865,000 fit for military
service; about 394,000 reach military age (20) annually
Ethnic divisions: 91.5% Filipino (Malay), 4% Moros (Malay), 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4% Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national language of the Philippine
Republic; English is the language of school instruction and government
business
Literacy: about 75%
Labor force: 11 million; 60% agriculture, forestry, fishing, 12% manufacturing,
10.5% commerce, 10.5% government and services (business, recreation, domestic,
personal), 3.5% transport, storage, communication, 3% construction; 0.5% other','009b5ccf0e32fba5eb8f64fd27a184d8086dcee7a75ee65f2b32d2027b100bbd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('011c6e901edf575c694706699fa565360c76e1d51849d5a9ae655641642a448f',1972,'PT','Portugal','people-and-society',356,'Population: metropolitan Portugal 8,668,000, (mid-1972) average annual growth
rate 0% (current); Cape Verde Islands 250,300 (1969); males 15-49, 2,199,000;
1,700,000 fit for military service; average number reaching military age (20)
annually, about 74,000
Ethnic divisions: homogeneous Mediterranean stock in mainland, Azores, Madeira
Islands; small number of black workers from the Cape Verde Islands
Religion: 97% Roman Catholic, 1% Protestant sects, 2% other
Language: Portuguese
Literacy: 65% (a figure considered very high by some sources)
Labor force: 3.3 million (1970); 32% agriculture, 34% industry, 34% services;
unemployment virtually nil, but underemployment widespread
Organized labor: 33.3% of labor force in syndicates subject to varying degrees
of government control
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
PORTUGUESE GUINEA
14,000 sq. mi. (includes Bijagos archipelago)
Land boundaries: 460 mi.
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 170 mi.
Population: 489,000, average annual growth rate 0.2%
(FY69); males 15-49, 116,000; 65,000 fit for
military service
Ethnic divisions: about 99% African (Balanta 30%, Fulani 20%, Mandyako 14%,
Malinke 13%, and 23% other tribes); Tess than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese official, numerous African languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in subsistence agriculture
Ore eyeere yee average annual growth rate 1.8%
FY66-69
Ethnic divisions: 95% indigenous Timorese belonging to
the Malay racial group; 9 ethnic divisions, each
speaking a distinct dialect of Malay structure;
approx. 4,600 Chinese and 10,000 halfcastes
Religion: 17% Christian (almost equally divided between Catholic and
Protestant), remainder practice animism
Language: an estimated 9-15 dialects, of Malay origin but mutually unintelligible;
75% of the population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but js very low; educational system being
expanded under first Five Year Development Plan; by 1967 total school
enroliment was 25,000 out of total school-age population of 80,000; 5% of
natives can speak Portuguese
Labor force: 90% engaged in primitive village subsistence economy, 10% engaged
as town laborers and domestics','b054868da0329d002f03d4bf243c69b570192b77092bb4139d9d02d34366e74f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3823ec3269a1cf22231b4ff7c7eacaa1904f481e4a6821822db2716167a1614',1972,'PR','Puerto Rico','people-and-society',360,'Population: 2,782,000, average annual growth rate 1.1% ren
(FY69)
Ethnic divisions: 80% white, 20% mixed (with Indian and
Negro elements )
Religion: predominantly Roman Catholic
Language: Spanish, English
Literacy: 88%
Labor force: 706,000; 19% agriculture, 14% manufacturing, 7% construction, 39%
government services and trade, 8% other, 13% unemployed
Organized labor: 45% of labor force','d5046667935efc9cea0d589f213175e59a4c701ad4adb1625c0177c8f96f2c13','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1376d3214cbba0d409797cf539117feb30caa391800fda0d7251f96539c26b17',1972,'QA','Qatar','people-and-society',364,'Population: 136,000, average annual growth rate 10.8%
(FY65-69); males 15-49, about 33,000; about 19,000
fit for military service
Ethnic divisions: 56% Arab; 23% [ranian; 14% Pakistani; 7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: 48,000 (1969)
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
REUNION
Y SAUDI
ARABIA
970 sq. mi.; two-thirds of island extremely rugged,
consisting of volcanic mountains; 120,000 acres (less
than one-fifth of the land) under cultivation
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 125 mi.
Population: 467,000, average annual growth rate 2.3% (FY70);
military age males included with France
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal unemployment
151,000 sq. mi.; 40% arable (of which 6% cultivated); 60%
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
RHODESIA
available for extensive cattie grazing; European
alienated lands (farmed by modern methods) 39%,
African 48%, national land 7%, 6% not alienated (1970)
Land boundaries: 1,875 mi.
Population: 5,689,000, average annual growth rate 3.5%
(FY71); males 15-49, 1,319,000; 805,000 fit for
military service; average number reaching military
age (18) annually, 53,000
Ethnic divisions: 96% African, 3% European, less than
1% Coloreds and Asians
Religion: 51% syncretic (part Christian, part animist), 24% Christian,
24% animist, a few Muslim
Language: English official; Chishona and Sindebele also widely used
Literacy: .25%-30%; of whites, nearly 100%
Labor force: (1971) 776,000 Africans (including some migrants from Zambia and
Malawi), Europeans, Asians, and coloreds (people of mixed heritage); 35%
agriculture, 25% mining, manufacturing, construction, 40% transport and
services
Organized labor: about one-third of European wage earners are unionized, but
only a smail minority of Africans (1966)','f1011b7dabc11eb4a070351e4b1cd5a1b30e77ab20103cf9efe4ec5ca7625c25','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3a192aa4ff247cf822a75f3f147df6cf37cf534abe83c429f3ad6665573bc5d',1972,'RO','Romania','people-and-society',368,'Population: 20,687,000, average annual growth rate 1.1%
(current); males 15-49, 5,451,000; 4,585,000 fit for
military service; 187,000 reach military age (20)
annually
Ethnic divisions: 87% Romanian, 8% Hungarian, 2% German, 3% other
Religion: 14,000,000 Romanian Orthodox, 1,000,000 Roman Catholic, 1,000,000
Protestants, 100,000 Jews, 30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.4 million (est. 1 July 1966); 57% agriculture, 19% industry,
24% other nonagricultural','41845fac4ea9afbdc28600b9bec38bff14b2513eacaf1ecae35c1f4cf0c803f2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fe27a7aa7ddc2e0f589363b0a985c8970b00c4cd4101e728aba8b8da41b60a0',1972,'RW','Rwanda','people-and-society',372,'Population: 3,848,000 (African population only), average
annual growth rate 3.1% (FY65-67); males 15-49,
893,000; 430,000 fit for military service; no
conscription; 36,000 reach military age (18) annually
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa (Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili language of African commerce,
Kinyarwanda language of interior and used in National Assembly
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','b62db7caf0646badfa98ea1e1b9f827a8f88fb8e8ea9147bf1c63fc8bb989fdf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('147ac06970702e84db6057736173f6a2545a2a25c6cb4a991749dd5f2dbdf178',1972,'SM','San Marino','people-and-society',378,'Population: 20,000, average annual growth rate 1.9%
(FY65-70)
Ethnic divisions: composite of Mediterranean, Alpine,
Adriatic, and Nordic racial types
Religion: Roman Catholic
Language: Italian :
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of Sanmarinese Workers (affiliated
with ICFTU) has about 1,800 members; Communist-dominated Camera del Lavoro,
about 1,000 members','2be6ac6650480f9e758b5dfdb73c43ab0cce48fa19811d83bfe051a42c81c786','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6b61c982abbf8d9d126fae1f41193ba0d5eb49d6156edc9894a2937f54277fa',1972,'SA','Saudi Arabia','people-and-society',382,'Population: 5,611,000, average annual growth rate 2.8%
(current); males 15-49, 1,350,000; 720,000 fit for
military service; about 69,000 reach military age (18) annually
Ethnic divisions: 90% Arab, 10% Afro-Asian (ese)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40% agriculture and herding, 12%
construction, 12% service, 12% government, 11% commerce','f299523cb50022bd9d04a15150faace5ec306770f60d3c6a3b7cb296c75b0aeb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c42404eaacea424ea0e3f330b844eaca2ad83bc9ee86ee637623016b2d52bbf',1972,'SN','Senegal','people-and-society',386,'Population: 4,080,000, average annual growth rate 2.6%
(FY69); males 15-49, 964,000; 460,000 fit for military
service; 42,000 reach military age (18) annually
Ethnic divisions: 36% Wolof, 17.5% Fulani, 16.5% Serer, 9% Tukulor, 9% Dyola,
6.5% Malinke, 3% other African, 1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly Roman Catholic)
Language: French official, but regular use limited to literate minority; most
Senegalese speak own tribal language; use of Wolof vernacular spreading --
now spoken to some degree by nearly half the population
Literacy: 5-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 90% subsistence agricultural workers; about 105,000
wage earners
Organized labor: majority of wage-labor force represented by unions; however,
dues-paying membership very limited','02d216d189cbcde71610ce9ce155966e0321e7ff35efe566b5409b5520aaaeb9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94b6947528458b1a97b1de49b45fdeb6fad83b5d30955ae3b13e2f0ad71ba347',1972,'SC','Seychelles','people-and-society',390,'Population: 54,000, average annual growth rate 2.0% (FY69);
males 15-49, 13,000; 7,000 fit for military service
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans )
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions','b5ccf2b961fc4cdb2ed37a9953611529a5ae39687dff58cb7451b11b8f4d54ac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53b67b9c962f522c3c34896693df61e5c587e6b2892fdd74c94ce62d6b0ef151',1972,'SL','Sierra Leone','people-and-society',394,'Population: 2,641,000, average annual growth rate 1.6%
(FY67-71); males 15-49, 624,000; 300,000 fit for military service; no
conscription
Ethnic divisions: over 99% native African, rest European and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to literate minority;
principal vernaculars are Mende in south and Temne in north; "Creole," a
form of pidgin English, is also widely spoken
Literacy: about 10%
Labor force: about 1.5 million; most of population engages in subsistence
agriculture; only small minority, some 100,000, earn wages
Organized labor: 35% of wage earners (35,000)','d9243b3d20a40b647f2c59b2cc2983c11d9799fd279b4df21397ea64313d9d9b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67c6f44cb6fbd1f23bbdf678e967da5d1376d08cbfb0e85968aaf14036c2fe35',1972,'SG','Singapore','people-and-society',398,'Population: 2,145,000, average annual growth rate 1.6%
(FY68-71); males 15-49, 496,000; 340,000 fit for military
service
Ethnic divisions: 78% Chinese, 12% Malay, 7% Indians and
Pakistani, 3% other
Religion: majority of Chinese are Buddhists or atheists; Malays nearly ali Muslim;
minorities include Christians, Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay, Tamil, and English are
official languages
Literacy: 88% (19675
Labor force: 577,000; 3% agriculture and fishing; 24% manufacturing and
construction; 67% trade, transportation, communications, and other services ;
6% other
Organized labor: 26% of labor force','cc9a1e6b91140bf9904f7d89311103a555c3581f8444374ea995f69a13b3a33c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcd5e68acb17518588e55e1c721639efbcd0c5672748afcf78508e885a0cc3fc',1972,'SO','Somalia','people-and-society',402,'Population: 2,930,000, average annual growth rate 2.3%
(FY66-71); males 15-49, 711,000; 370,000 fit for military
service; no conscription
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000 Arabs, 3,000 Europeans,
800 Asians
Religion: almost entirely Muslim
Language: Somali (but no written form); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled laborers; 70% pastoral
nomads, 30% agriculturists, government employees, traders, fishermen,
handicraftsmen, other
Organized labor: law providing for government-controlled labor union promulgated
in June 1971, but union so far not established','232b4a59743fb8cb882e3f96f227cb20275c511184e645c3dfb313148cc593ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dfdb84345b51a7d302057d7ab8d1a61041985888c8a7d817282540931e2a63b',1972,'ZA','South Africa','people-and-society',406,'Population: 22,550,000, average annual growth rate 2.4%
. (FY69); males 15-49, 5,159,000; 3,125,000 fit for military service;
obligation for service in Citizen Force begins at 18; volunteers for
service in permanent force must be 17
Ethnic divisions: 17.8% white, 69.9% Bantu, 9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and Bantu; 60% of Bantu are animists
Language: Afrikaans and English official, Bantu have many vernacular languages
Literacy: almost all white population literate; government estimates 35% of
Bantu literate
Labor force: 8.7 million (total of economically active, 1960); 53% agriculture,
8% manufacturing, 7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 5% of total labor force is unionized (mostly white
workers); nonwhites have no bargaining power
Population: 780,000, average annual growth rate 1.9%
(FY61-65); males 15-49, about 155,000; about 90,000
fit for military service
Ethnic divisions: 14% white, 81% Africans, 5% Coloured
(mulattoes); almost half the Africans belong to Ovambo
tribe; Herero, Okavango, Nama, and Damara tribes have
about 30,000 members each
Religion: whites predominantly Christian, nonwhites either animist or Christian
Language: Afrikaans principal language of about 70% of white population, German
of 22%, and English of 8%; several African languages
Literacy: high for white population; low for nonwhite
Labor force: 75,000 African wage earners (1964 est.); 68% agriculture, 15%
railroads, 13% mining, 4% fishing
Organized labor: no trade unions, although some white wage earners belong to
South African unions','c299c1b1126a79566327a043af7142cc3d177b450c9fbb9913ad1060bf11c957','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b3b250363a7916886aa18b48cd273dcbe61236e5e20537a32b48a4aac0dc4be',1972,'SD','Sudan','people-and-society',411,'Population: 16,490,000, average annual growth rate 2.5%
(FY70); males 15-49, 3,754,000; 2,225,000 fit for
military service; average number reaching military
age (18) annually, 160,000
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2% foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23% pagan, 4% Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects of Nilotic, Nilo-Hamitic,
and Sudanic languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry, commerce, services,
etc.; labor shortages exist for almost all categories of employment
Population: 432,000, average annual growth rate 3.5%
(FY65-70); males 15-49, 103,000; 57,000 fit for military service
Ethnic divisions: 35.5% Creole (Negro and mixed), 34.7% Hindustani (East Indian),
14.9% Javanese, 8.5% Bush Negro, 2.2% Amerindian, 1.6% Chinese, 1.3% Europeans,
1.3% other and unknown
Religion: Muslim, Hindu, Moravian, Roman Catholic, other -- in order of size
(% figures unknown)
Language: Dutch official; English widely spoken; Taki-Taki (Surinam Creole)
js native language of Creoles and lingua franca; Hindi; Javanese
Literacy: 70% to 75%
Labor force: 80,190 (1964); 24.9% agriculture, 6.9% mining, 10% industry, 2.8%
building trades, 13.5% trade and transport, 6.7% services, 22.2% government
employees, 3.1% unclassified, 9.9% unemployed and seeking work
Organized labor: approx. 10% of labor force
Population: 434,000 (African population only), average
annual growth rate 3.0% (FY68-70); males 15-49, 100,000;
50,000 fit for military service
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence agriculture; 55-60 ,000
wage earners, many only intermittently, with 31% agriculture, 11% government,
11% manufacturing, 12% mining and forestry, 35% other (1968 est.); 7,900
employed in South African mines (1969)
Organized labor: about 15% of wage earners are unionized','8173c093b0614d1a46d8d3d0bf804531cc7d882635510eab7e80d8b06f70baa9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('668a0173e6f8d48172c2c4337622417e8a297feaf3b49d7fc70d442803803d19',1972,'CH','Switzerland','people-and-society',418,'Population: 6,372,000, average annual growth rate 1.0%
(January 67-71); males 15-49, 1,521,000; 1,317,000
fit for military service; 45,000 reach military age (20)
annually
Ethnic divisions: total population -- 69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals -- 74% German, 20% French, 4% Italian,
1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals -- 74% German, 20% French, 4% Italian, 1% Romansch,
1% other; total population -- 69% German, 19% French, 10% Italian, 1%
Romansch, 1% other
Literacy: 98%
Labor force: 2.5 million; 16% agriculture and forestry, 47% industry and crafts,
20% trade and transportation, 5% professions, 2% in public service, 10%
domestic and other; no significant unemployment shortage of both skilled and
unskilled labor -- 4,400 unfilled vacancies in January 1971
Organized labor: 20% of labor force
Population: 14,005,000, average annual growth rate 2.7% ;
(FY71); males 15-49, 3,203,000; 1,775,000 fit for military service
Ethnic divisions: 99% native Africans consisting of well over 100 tribes; 1%
Asian, European, and Arab
Religion: Tanganyika -- 40% animist, 30% Christian, 30% Muslim; Zanzibar --
almost all Muslim
Language: Swahili English and official English primary language of commerce,
administration and higher education; Swahili widely understood and generally
used for communication between ethnic groups; first language of most people
is one of the local languages
Literacy: 15%-20%
Labor force: under 400,000 in paid employment, over 90% in agriculture
Organized labor: 15% of labor force','081b7b97f0b006e112ce23e9c86c1494f884b1c42f91afaf92b35ad2a183fb7b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('742082500743f9a1a85f34cbf0b4380ea184288cc41c35ac8173547fb8c11632',1972,'TH','Thailand','people-and-society',422,'Population: 36,248,000, average annual growth rate 2.7%
(April 60-70); males 15-49, 8,675,000; 5,290,000 fit
for military service; about 385,000 reach military age
(18) annually
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 88% agriculture, 9% commerce, 3% industry','66801c5bae08b76f64b1b0b3fb2a955c1f87130867071f6289f9e53d696c2490','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8cd901f1a3405536d3af34749d621825a8c090bfe4211d35700f56499543d44',1972,'TG','Togo','people-and-society',426,'Population: 2,073,000, average annual. growth rate 2.6%
(FY68-70); males 15-49, 489,000; 245,000 fit for
military services; no conscription
Ethnic divisions: some 40 tribes; largest and most important are Ewe in south and
Cabrais in north; under 1% European and Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of commerce; major African languages
are Ewe and Mina in south and Dagoma, Tim, and Cabrais in north
Literacy: 5% to 10%
Labor force: over 90% of population engaged in subsistence agriculture; about
30,000 wage earners, evenly divided between public and private sectors
Organized labor: less than half of wage earners divided among 2 major and several
minor unions','cca99c040931a48a232973fc8592649e68c58f027deabb86f2eba4ec70741301','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67c354758aa002029558b9c480d60e9dffa2d931bea592d80b6dd1cfc2881486',1972,'TO','Tonga','people-and-society',430,'Population: 91,000, average annual growth rate 2.9%
(FY68-70)
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','03191b02a8ef99f949a65719e3a41e4320119c67832bba5725eaefe74ed67431','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb26340489b585332b7b701ce86072265eb1645bb84a8d7dce121e152e59991b',1972,'TN','Tunisia','people-and-society',437,'- Population: 5,400,000, average annual growth rate 2.9%
(current); males 15-49, 1,292,000; 690,000 fit for military service; about
49,000 reach military age (20) annually
f Ethnic divisions: 98% Arab, 1% European, less than 1% Jewish
: Religion: 98% Muslim, 1% Christian, less than 1% Hebrew
i Language: Arabic (official), Arabic and French (commerce)
Literacy: about 30%
Labor force: 1.5 million; 70% agriculture, 10% manufacturing and construction,
20% other; 25% underemployed; shortage of skilled labor
Organized labor: 10% of labor force; General Union of Tunisian Workers (UGTT),
subordinate to Destourian Socialist Party','1bc1b7c2fe972328ced38be5f1cded3408bbe45d8d242d73f0f95110bef52331','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c330741c7722e253985b811c9c5f6dc8bc1124e2bfc693e659e3e8fd0bf00330',1972,'UG','Uganda','people-and-society',441,'Population: 10,429,000, average annual growth rate 3%
(FY70-71); males 15-49, about 2,416,000; about
1,340,000 fit for military service
Ethnic divisions: 98.7% African, 1.3% European, Asian,
Arab
Religion: about 60% nominally Christian, rest Muslim or pagan
Language: English official: Luganda and Swahili widely used; other Bantu and
Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which 256,799 in paid labor, remaining
in subsistence activities
Organized labor: 123,284 union members
Population: 247,513,000, average annual growth rate 1%
(current)
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim, 3% other
Language: more than 200 languages and dialects (at least 18 with more than 1
million speakers); 76% Slavic group, 8% other Indo-European, 11% Altaic,
3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: 126 million (1971), 32% agriculture, 68% industry and other non-
agricultural fields, unemployed not reported, shortage of skilled labor
not reported, no shortage of unskilled labor','ea9a6a8accaa7672f6a4041d3d88a8329b888a23a5eb85717ca9a72d3e2055f6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e08356eecd984e64472c1b5b760b631cd0b267cb808120b4658e071b9736a944',1972,'AE','United Arab Emirates','people-and-society',445,'Population: 179,000 (census of 15 March - 16 April 1968);
males 15-49, about 43,000; about 22,000 fit for military service
Ethnic divisions: Arabs 72%; others include Iranians, Pakistanis, and Indians
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 20% est. (1968)
Labor force: 77,000 (1968)
Population: 5,602,000, average annual growth rate 2.0%
(FY70); males 15-49, 1,323,000; 635,000 fit for
military service; no conscription
Ethnic divisions: more than 50 tribes; principal tribe
is Mossi (about 2.5 million); other important groups
are Gurunst, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20% Muslim, 5% Christian
(mainly Catholic)
Language: French official; tribal languages belong to Sudanic family, spoken
by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active population engaged in animal
husbandry, subsistence farming, and related agricultural pursuits; about
30,000 are wage earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 3 primary and several small specialized unions','0f1ed25a3c7c7ccf56d31ac9d7e20e3fc4b1d6ec36dca40eaa2430e089bed62a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d65e0eddaf1845c7c5fcc76563a4c2c3ceed85e269c5394f786d6e3b2a2e821a',1972,'UY','Uruguay','people-and-society',449,'Population: 2,955,000, average annual growth rate 1.2%
(FY70); males 15-49, 730,000; 570,000 fit for
military service; no conscription
Ethnic divisions: 85%-90% white, 5% Negro, 5%-10% mestizo
Religion: 66% Roman Catholic (less than half adult population attends church
regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed in important sectors --
25% government; 53% trade and service; 28% manufacturing and construction;
19% agriculture, forestry, fishing and mining; no shortage of skilled labor
Organized labor: about 25% of labor force (largely Communist influenced)
Population: 1,000 (official estimate for 1 July 1964)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees divided
into 3 categories -- executives, officeworkers ,
and salaried employees
Organized labor: none
Population: 11,167,000 (excluding Indian jungle population
estimated at 32,000 in 1961), average annual growth
rate 3.6% (FY70); males 15-49, 2 559 000; 1,760,000 :
fit for military service; 120,000 reach military age (18) annually
Ethnic divisions: 67% mestizo, 21% white, 10% Negro, 2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 72% (claimed)
Labor force: 3 million (1969); 24% agriculture, 6% construction, 17% manufacturing,
6% transportation, 18% commerce, 25% services, 4% petroleum, utilities, and
other
Organized labor: 45% of labor force
Population: 20,205,000, average annual growth rate 1.2%
(current)
Ethnic divisions: 85%-90% predominantly Vietnamese; ethnic
minorities include Muong, Thai, Meo, and Man
Religion: Confucianism, Buddhism, Taoism, Catholicism
Language: closely corresponds to the breakdown of ethnic groups
Literacy: claimed to be 95% (1964)
Labor force: (1 January 1970) 9.6 million, not including military; about 70%
agriculture and 10% industry
Population: 19,299,000, average annual growth rate 2.6%
(FY70}; males 15-49, 4,517,000; 2,600,000 fit for
military service; 143,000 reach military age (18) annually
Ethnic divisions: 87.7% Vietnamese, 6% Chinese, 3.2% mountain tribesmen, 2.9%
Khmer, 2% Cham
Religion: 70% Buddhist (at least 5% Hoa Hao), 5% Cao Dai, and 10% Catholic; others
include animist, and smal] numbers of Protestant, Muslim and Hindu; most
Buddhists are of Mahayana school or practice combination of Buddhism, Taoism,
and Confucianism
Language: Vietnamese, French, Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian) , Cham (Malayo-Polynesian dialect)
Labor force: civilian work force 5.8 million (not including armed forces);
67% agriculture, fishing, and forestry; 17% industry and commerce; 3%
domestic and personal services; 3% employed by U.S.; 5% government; 5%
unemp loyed
Organized labor: unknown
eye 149,000, average annual growth rate 2.1%
FY71
Ethnic divisions: Polynesians, about 12,000 Euronesians (persons of European
and Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of population associated with the London
Missionary Society)
Language: Samoan (Polynesian). English
Literacy: 85%-90% (education compulsory for all children from 7-15 years)
Labor force: agriculture 19,148; mining and manufacturing 1,716 (1961)
Organized Tabor: unorganized
Population: 1,515,000**, average annual growth rate 2.7%
(FY71); males 15-49, 367,000; 200,000 fit for military
service
Ethnic divisions: almost all Arabs; a few Indians, Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 6,074,000, average annual growth rate 3%
(current); males 15-49, 1,470,000; 780,000 fit for
military service; about 50,000 reach military age (18) annually; universal
military conscription law (10 January 1963) makes military service
obligatory for all Yemeni males 18-30
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding
Population: 23,424,000, average annual growth rate 4.2%
8 (FY71); males 15-49, 5,715,000; 2,745,000 fit for
i military service
! Ethnic divisions: over 200 African ethnic groups, the majority are Bantu; four
largest tribes -- Mongo, Luba, Kongo (a11 Bantu), and the Mangbetu-Azande
(Hamitic) make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo, and Chiluba are all
classified as official languages
: Literacy: 5% fluent in French, about 35% have an acquaintance with French
Labor force: about 8 imillion, but only about 13% in wage structure','e305f68208c92d86bacd51f98479421f1ef2055d3c29d92b866c47c4bfbda7ef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b8bdced69be3aeadc308a3fc0dbb3e83073873173b707524114371e1a69510c',1972,'ZM','Zambia','people-and-society',453,'Population: 4,346,000, average annual growth rate 2.4%
(May 63-August 69); males 15-49, 1,008,000; 485,000
fit for military service
Ethnic divisions: 98.7% African, 1.1% European, .2% other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and MusTim
Language: English official; wide variety of indigenous languages
Literacy: 28%
Labor force: 374,000 wage earners; 347,000 Africans, 27,000 non-Africans;3
15% mining, 9% agriculture, 9% domestic service, 19%
construction, 9% commerce, 10% manufacturing, 23% government and miscellaneous
services, 6% transport
Organized labor: 100,000 wage earners, primarily in industrial sector, are
unionized (early 1968)
Population: 209,009,000, average annual growth rate 1.1% (current)
Ethnic divisions: population basically of West European extraction, modified
by subsequent waves of immigration
Religion: total membership in religious bodies, 128,470,000; Protestant
69,424,000, Roman Catholic 47,873,000, Jewish 5,780,000, other religions
5,393,000
Language: English, predominantly
Literacy: almost complete
Labor force: 86 million (1972)
Organized labor: 28.8% of total','d4d48e5022d46b133f9a7b7222f82592d6e583dcd0ca5023ad97ee1b5eda50cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad25a3c09c6771c7dd4b040a3f28873a4acd39a66745ab39daea9d015004aec9',1972,'AF','Afghanistan','people-and-society',5,'Population: 14,541,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Afghan(s); adjective—Afghan
Ethnic divisions: 50% Pushtuns, 25% Taiiks, 9% Uzbeks,
9% Hazaras; minor ethnic groups include Chahar Aimaks,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbek and Turkmen), 10%
thirty minor languages (primarily Baluchi and Pashai); much
bilingualism
Literacy: under 10%
Labor force: about 5.88 million (FY78 est.); 75%-80%
agriculture-and animal husbandry, 20%-25% commerce,
small industry, services; massive shortage of skilled labor
Organized labor: none','e00a96ef1d2491d3d68bd982c4ed3e80c4e7bd5f68ae6a4674978caa3418d70b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76ab3c191b7b0e14c02a32b7eee4f9698e3728da50a65fbd4fc74130306e4ee8',1972,'BG','Bulgaria','people-and-society',11,'Population: 2,597,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Albanian(s); adjective—Albanian
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
January 1979
Religion: 70% Muslim, 20% Albanian Orthodox, 10%
Roman Catholic; observances prohibited; Albania claims to
be the world’s first atheist state
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics avail-
able, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9%
industry, 21.6% other nonagricultural
Population: 8,871,000 (January 1979), average annual
growth rate 0.5% (current)
Nationality: noun—Bulgarian(s); adjective—Bulgarian.
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Sik cal ee aS
wane Beet AL een ay
Oe ee Oe Oe =O
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Sofia
(See reference map IV)
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsiés, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians,
0.6% other
Religion: regime promotes atheism; religious background
of population is 85% Bulgarian Orthodox, 18% Muslim, 0.8%
Jewish, 0.7% Roman Catholic, 0.5% Protestant, Gregorian-
Armenian and other
Language: Bulgarian; secondary languages closely corre-
spond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 5.0 million (1974); 32% agriculture, 33%
industry, 35% other
Population: 33,123,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Burman(s); adjective—Burmese
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2%
Kachin, 2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their
own languages :
Literacy: 70% (official claim)
28
Labor force: 12.2 million (1976); 67% agriculture, 9%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old Jabor organiza-
tions have been disbanded, and government is forming one
central labor organization','f7a47dde8ce59a4f9b1840e55391f9347627456c99429dbf4a71d11230bb4a4d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a68406cf0d945c0f83416b4ff44d8d3a0b4adf239adcba5ff7769a09e32215f',1972,'DZ','Algeria','people-and-society',15,'Population: 17,944,000 (January 1979), average annual
growth rate 3.4% (current)
Nationality: noun—Algerian(s); adjective—Algerian
Ethnic divisions: 99% Arab-Berbers, less than 1%
Europeans i
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 4.0 million; 50% agriculture, 20% industry,
25% other (military, police, civil service, transportation
workers, teachers, merchants, construction workers); at least
20% of urban labor unemployed
“Organized labor: 25% of labor force claimed; General
Union of Algerian Workers (UGTA) is the only labor
organization and is subordinate to the National Liberation
Front
(See reference map lV}
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages;
Italian, Portuguese, and Russian also spoken; English used in
the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian
laborers
Organized labor: over 6,000','908de9af355d76f65617ee95e50880e5409e86f1a2d29e8b05db87a2e99c732c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae2603ad2aecc0127741b32fa414ab13df47b39de3349351fed44a91b4bd8895',1972,'AD','Andorra','people-and-society',19,'Population: 29,000 (official estimate for 1 July 1976)
Nationality: noun—Andorran(s); adjective—Andorran
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian
--Labor force: unorganized; largely shepherds and farmers','249984b2e7fcbf3e39e8c2569017c09c023341170e97d7e0a51a6c0dd498512c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('980c38a9b60d4e32325ad4c1d3ae7ef1c1d7853cff460c67a8cd2a00e80cfcdb',1972,'AO','Angola','people-and-society',23,'Population: Angola (including Cabinda), 6,527,000 (Janu-
ary 1979), does not take into account emigration from
Atlantic
Ocean
O
{See reference map Vi)
Angola, average annual growth rate 2.4% (current); Cabinda,
105,000 (January 1979), average annual growth rate 3.3%
(12-60 to 12-70)
Nationality: noun—Angolan(s); adjective—Angolan
Ethnic divisions: 93% African, 5% European, 1% mestizo
Religion: about 84% animist, 12% Roman Catholic, 4%
Protestant
Language: Portuguese (official), many native dialects
Literacy: 10-15%
Labor force: 2.6 million economically active (1964);
531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 73,000 (January 1979), average annual
growth rate 1.3% (7-70 to 7-77)
Nationality: noun—Antiguan(s),; adjective—Antiguan
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects, and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000, 20% unemployment','013b15de4fae2e6c40bb29ee3d4c7bce1613764d1612814d09184e9d9416451f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12600fb0d0eb6ad6b46b0b3c3893bafd4472380c61e1ed1893e80029aac694d6',1972,'AR','Argentina','people-and-society',27,'Population: 26,658,000 (January 1979), average annual
growth rate 1.38% (current)
Nationality: noun—Argentine(s); adjective—Argentine
Ethnic divisions: approximately 85% white, 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20%
practicing), 2% Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 10 million; 19% agriculture, 25% manufac-
turing, 20% services, 11% commerce, 6% transport and
communications, 19% other; 4-5% estimated unemployment
Organized labor: 25% of labor force (est.)
Population: 2,000 (official estimate for 31 December
1977)
Nationality: noun—Falkland Islander(s); adjective—Falk-
land Island
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in agriculture,
mostly sheepherding ,
Population: 2,902,000 (January 1979), average annual
growth rate 0.6% (current)
218
Nationality: noun—Uruguayan(s); adjective—Uruguayan
Ethnic divisions: 85-95% white, 5% Negro, 5-10% mestizo
Religion: 66% Roman Catholic (less than half adult
population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed
in important sectors—25% government; 34% industry; 10%
service; 23% other; 8% agriculture, forestry, fishing and
mining; no shortage of skilled labor
Organized ‘labor: about 25% of labor force
Population: 1,000 (official estimate for 1 July 1977)
Ethnic divisions: primarily Italians but also many other
nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees
divided into 3 categories—executives, officeworkers, and
salaried employees
Organized labor: none
Population: 14,541,000, excluding Indian jungle popula-
tion (January 1979), average. annual growth rate 2.2%
(current) ,
Nationality: _noun—Venezuelan(s); adjective—Vene-
zuelan
Ethnic divisions: 67% mestizo, 21% white, 10% Negro,
2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish ,
Literacy: 74% (claimed, 1970 est.)
Labor force: 3.7 million (1975); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation, 18%
commerce, 25% services, 4% petroleum, utilities, and other
Organized labor: 45% of labor force','73f33745df21df10d5bd44ba485208f93a9c1847de7baad4fbefcb087106e661','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce039af0d122f4dbb168c53c6f5d370dca26b401da92e9e451692ed61192d76b',1972,'AU','Australia','people-and-society',31,'Population: 14,298,000 (January 1979), average annual
growth rate 1.1% (current) 4
Nationality: noun—Australian(s); adjective—Australian
Ethnic divisions: 99% Caucasian, 1% Asian and aborigine
Religion: 98% Christian
Language: English
Literacy: 98.5%
Labor force: 6 million; 14% agriculture, 32% industry,
37% services, 15% commerce, 2% other; 6% unemployment
Organized labor: 44% of labor force’
- Population: 615,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun—Fijian(s); adjective—Fijian
Ethnic divisions: 44% Fijian, 50% Indian, 6% European,
Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu
with a Muslim minority
Language: English and Fijian (official), Hindustani
spoken among Indians
64
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force organized into
22 unions; unions organized along lines of work, breakdown
by ethnic origin causes further fragmentation
Population: 52,000 (preliminary total from census of 8
December 1973) ,
Nationality: noun—Gilbertese or Gilbert Islander(s);
adjective—Gilbertese, or Gilbert Islander
Ethnic divisions: Micronesian
Religion: Catholic
Literacy: less than 50%
Population: 145,958,000, including East Timor and West
Irian (January 1979), average annual growth rate 2.1%
. (current)
Nationality: noun—lIndonesian(s); adjective—Indonesian
_ Ethnic divisions: majority of Malay stock comprising 45%
Javanese, 14% Sundanese, 7.5% Madurese, 7.5% coastal
Malays, 26% other
Religion: 90% Muslim, 5% Christian, 3% Hindu, 2% other
Language: Indonesian (modified form of Malay) official;
English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 55 million; 64% agriculture, 12% trade, 7%
industry, 17% other
Organized labor: 10% of labor force
Population: 35,808,000 (January 1979), average annual
growth rate 3.0% (current)
Nationality: noun—Iranian(s); adjective—Iranian
Ethnic divisions: 63% ethnic Persians, 3% Kurds, 18% °
other Iranian, 18% Turkic, 83% Arab and other Semitic, 1%
other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2%
Zoroastrians, Jews, Christians and Baha’is—
Language: Persian (Farsi), Turkish dialects, Kurdish,
Arabic ,
Literacy: about 37% of those 7 years of age and older
(1976 est.)
Labor force: 10.1 million est. 1976; 36% agriculture, 21%
manufacturing; shortage of skilled labor substantial
Population: 12,689,000 (January 1979), average annual
growth rate 3.4% (current)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
—
eS =
ee
AAA a em RA a
Pua.
\\
Pa
4
e
4
C4
“4
Thala.
poe
Ng er ey
Ne Nag NN a a EE ta — ar” sg =
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
IRAQ/IRELAND
Nationality: ‘noun—Iraqi(s); adjective—Iraqi
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslim (50% Shiah Muslim, 40% Sunni
Muslim), 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry,
6.7% government, 16.8% other; rural underemployment .
high, but not serious because low subsistence levels make it
easy to care for unemployed; severe shortage of technically
trained personnel
Organized labor: 11% of labor force
Population: 7,000 (official estimate for 30 June 1969)
Nationality: noun—Nauruan(s); adjective—Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Religion: Christian (two-thirds Protestant, one-third
Catholic)
Language: Nauruan, a distinct Pacific Island tongue;
English, the language of school instruction, spoken and
understood by nearly all
Literacy: nearly universal
Population: 140,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun—New Caledonian(s); adjective—New
Caledonian ;
_ Ethnic divisions: Melanesian 42%; French 40%; remain-
der Vietnamese, Indonesian, Chinese, Polynesian
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese
laborers were imported for plantations and mines in
pre-World War II period; immigrant labor now coming
from Wallis Islands, New Hebrides, and French Polynesia
“Organized labor: unorganized
150
Population: 102,000 (January 1979), average annual
growth rate 2.2% (7-74 to 7-77)
Nationality: noun—New Hebridean(s); adjective—New
Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3% Euro-
pean, remainder Vietnamese, Chinese, and various Pacific
Islanders
Religion: most at least nominally. Christian
Literacy: probably 10%-20%
Tasman
Sea
: NEW %
aw, 7, Wellington
(See reference map Vill}
Nationality: noun—New Zealander(s); adjective—New
Zealand
Ethnic divisions: 98% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified; 1%
Hindu, Confucian, and other ;
Literacy: 98%
Labor force: 1,207,700; 13% agriculture, 33% manufac-
turing and construction, 9% transportation and communica-
tions, 24% commerce and finance, 21% administrative and
professional; unemployment 5.7% (1976)
Organized labor: 52% of labor force
Population: 3,024,000 (January 1979), average annual
growth rate 2.6% (7-73 to 7-77)
Nationality: noun—Papua New Guinean(s); adjective—
Papua New Guinean
Ethnic divisions: predominantly Melanesian and Papuan,
some Negrito, Micronesian, and Polynesian types
Religion: over one-half of population nominally Christian
(490,000 Catholic, 320,000 Lutheran, other Protestant sects);
remainder animist
Language: 700 indigenous languages; pidgin English and
2 or 3 native languages are linguae francae for over one-half
of population; English spoken by 1% to 2% of population
Literacy: 15%; in English, 0.1%
Labor force: no available figures; mostly subsistence
farmers ,
Population: 6,000 (preliminary total from census of 8
December 1973)
Ethaic divisions: Polynesian
Religion: Protestant
Literacy: less than 50%
Population: 155,000 (January 1979),
growth rate 1.0% (1-76 to 1-77)
Nationality: noun— Western Samoan(s); pave ests
ern Samoa
Ethnic divisions: Polynesians, about 12,000 Euronesians
(persons of European and Polynesian blood), 700 Europeans
Religion:—99.7% Christian (about half of population
associated with the London Missionary Society)
Language: Samoan (Polynesian), . English
‘Literacy: 85%-90% (education compulsory for all children
from 7-15 years)
average annual
Labor force: agriculture 19,148; mining and manufactur-
ing 1,716 (1961)
Organized labor: unorganized .
Population: 1,765,000, excluding the fends of Perim and
Arabian
Sea .
Indian
_ Ocean
{See reference map VV) -
Kamaran for which no data are available (January 1979),
average annual growth rate’ 1.9% (current)
Nationality: noun—Yemeni(s); adjective—Yemeni _
Ethnic divisions: almost all Arabs; a few Indians, Somalis,
and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 5,078,000 (January 1979), average annual
growth rate 1.9% (current)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding
Population: 22,074,000 (January 1979), average annual
growth rate 0.9% (current)
Nationality: noun—Yugoslav(s); adjective—Yugoslav
Ethnic divisions: 39.7% Serb, 22.1% Croat, 8.4% Muslims,
8.2% Slovene, 5.8% Macedonian, 2.5% Montenegrin, 6.4%
Albanian, 2.3% Hungarian, 4.6% other (197] census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic,
12% Muslim, 3% other, 12% none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Alba-
nian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 9.2 million (1976); 36% agriculture, 20%
mining and manufacturing, 44% other nonagricultural
activities; estimated unemployment averaged 5% of domes-
tic labor force in 1976
Population: 27,474,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Zairian(s); adjective—Zairian
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes—Mongo, Luba,
Kongo (all Bantu), and the Mangbetu-Azande (Hamitic)
make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo,
and Chiluba are all classified as official. languages
Literacy:. 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 13% in wage
structure','3d29fb16d595b09f582d83387e8dbf77d02d4a5323b26b969c9090092f8c337e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ca754ee6ede85dd4637423ad92d66c594bf86b16f25e0fd4e247269c72ff13d',1972,'AT','Austria','people-and-society',36,'Population: 7,511,000 (January 1979), average annual
growth rate —0.0% (1-77 to 1-78)
Nationality: noun—Austrian(s); adjective—Austrian
10
CZECHOSLOVAKIA
(See reference map iV)
Ethnic divisions: 98.1% German, 0.7% Croatian, 0.3%
Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
Labor force: 2,784,635 (1977); 18% agriculture and
forestry, 49% industry and crafts, 18% trade and communi-
cations, 7% professions, 6% public service, 2% other; 2.4%
registered unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in
Austria number more than 200,000 (1972); unemployment
1.2% (September 1977)
Organized labor: about two-thirds of wage and salary
workers (1971)
Population: 229,000 (January 1979), average annual
growth rate 2.8% (7-76 to 7-77) :
Nationality: noun—Bahamian (sing., pl.); adjective—
Bahamian
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: Baptists 29%, Church of England 23%, Roman
Catholic 23%, smaller groups of other Protestant, Greek
Orthodox, and Jews
Il
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
THE BAHAMAS/BAHRAIN
UNITED
STATES
Atlantic Ocean
THE
4 \\ eAMas','ffee1729d7f1299bfd558b980d056696b537f2c99ce8ff71684f9789108ad912','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f781a1caa2659f10294d3a5c94a9302b93a0155dfaf834f9374aa4c5998731f',1972,'HT','Haiti','people-and-society',39,'—\\
= q
DOMINICAN _
REPUBLIC ~
Caribbean Sea
(See reterence map tl}
Language: English
Labor force: 84,228 (1976), 25% organized; 25% unem-
ployment (1977)
Population: 5,600,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Haitian(s); adjective—Haitian
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of
which an overwhelming majority also practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.3 million (est. 1975); 79% agriculture, 14%
services, 7% industry, 5% unemployed; shortage of skilled
labor; unskilled labor abundant ~
Organized labor: less than 1% of labor force','ac8837c19fbdaf677881cd52ecd0f7f2f8288594464467ae5984e837145041d5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95657752aa81021188c72228849f20d40b5f84f555cc94b85266d009ec7ab079',1972,'BH','Bahrain','people-and-society',44,'Population: 289,000 (January 1979), average annual
growth rate 3.5% (7-75 to. 7-76) ;
Nationality: noun—Bahraini(s); adjective—Bahraini
_ Ethnic divisions: 90% Arab, 7% Yranian, Pakistani, and
Indian, 3% other; native Bahrainis are a minority
Religion: Muslim
Language: Arabic, English also widely spoken
- Literacy: about 40% (1970)
Labor force: 78,507 (1976)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BAHRAIN/BANGLADESH
Arabian
Sea
(See reference map V}','24623dbc2f683797c9283085817b5799b513d4c6b79a681adb0d5e835b04ba1b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('097c7a1b05f737cb7bca6fc5e125c90f303c347c6e3ffcf31ae1ba6c809a7e1e',1972,'BD','Bangladesh','people-and-society',48,'Population: 86,931,000 (January 1979), average annual
growth rate 2.7% (current)
’ Nationality: noun—Bangladeshi(s), adjective—Bangla-
desh
13
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
(See reference map Vil}
Ethnic divisions: predominantly Bengali; fewer than 1
“Biharis” and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1%
Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 20 million; extensive export of labor to
U.A.E., Qatar, Kuwait, Iraq, and Oman; over 75% of labor
force is in agriculture
million','53fcdc752066b94ca25802782ff7ae35f3b02157b5ff1fc3194250bf14943f24','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3101782fe1433e5c83a7dd3422efe9b2b01d866249d8fbbf082759b6fd5b78f2',1972,'BB','Barbados','people-and-society',52,'Population: 260,000 (January 1979), average annual
growth rate 1.5% (1-76 to 1-77)
Nationality: noun—Barbadian(s); adjective—Barbadian
Ethnic divisions: 80% African, 17% mixed, 4% European
Religion: Anglican (70%), Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1973 est.) wage and salary earners;
unemployment 20-25% (1976) -
Organized labor: 32%','88d38d862766294960a57c49311219788f87578f94e17899f6dd5a030d9b45db','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7b004568e82738014c24c7d929731acf687790a4f299311a092de9f2871a6f2',1972,'BE','Belgium','people-and-society',56,'Population: 9,842,000 (January 1979), average annual
growth rate 0.0% (current)
Nationality: noun—Belgian(s); adjective—Belgian
Ethnic divisions: 55% Flemings, 33% Walloons, 12%
mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in small
area of eastern Belgium; divided along ethnic lines
16
Literacy: 97%
Labor force: 4.09 million (July 1978); in June 1976, 46.7%
in services, 28.0% in mining and manufacturing, .7.4% in
construction, 6.6% in transportation, 3.2% in agriculture,
1.0% commuting foreign workers, 0.4% in public works,
6.7% unemployed; 8.1% unemployed first quarter 1978,
seasonally adjusted
Organized labor:. 48% of labor force (1969)','9fcb6b14817332a9574075255d1fc24c565face1fae275cd9e0eab3eecca317e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b15e11be61de49e542764f50bb0e33cb023fd49e95054bc879fd01d72b2f5a14',1972,'HN','Honduras','people-and-society',61,'Population: 154,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Belizean(s); adjective—Belizean
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerin-
dian, 8% other
17
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BELIZE/BENIN
'' Religion: 50% Roman Catholic; Anglican, Seventh-day
Adventist, Methodist, Baptist, Jehovah’s Witnesses, Men-
nonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
- Labor force: 34,500; 39% agriculture, 14% manufactur-
ing, 8% commerce, 12% construction and transport, 20%
services, 7% other; shortage of skilled labor and all types of
technical personnel; over 15% are unemployed
Organized labor: 8% of labor force
Population: 3,578,000 (January 1979), average annual
growth rate 3.4% (current)
Nationality: noun—Honduran(s); . adjective—Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over (est.
1970)
Labor force: approx. 900,000 (est. mid-1972); 66%
agriculture, 12% services, 8% manufacturing, 5% commerce,
6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-1972)','d5b705cce152e676127f029ead84b1266418516f01ad20ff1fb6bda612d5086d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80ecc75807fd5d47b700d4523e6efcc7b600fd2c5401fc8b420547323ec4c036',1972,'BJ','Benin','people-and-society',65,'Population: 3,333,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Beninese (sing. & pl.); adjective—
Beninese
Ethnic divisions: 99% Africans (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba), 5,500
Europeans ,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a
=e ne Ne ee Nn Oe ee), OO ee ae oe:
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
2 *
BENIN/BERMUDA
i UPPER VOLTA
0
Gulf of Guinea
(See reference map Vi}
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture;
15% civil service, artisans, and industry
Organized labor: approximately 75% of wage earners,
divided among two major and several minor unions','ad24746651041086748bcf16d4111f07d02dd88f197a59462d5af287bdd23008','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35d2c9cf11ac06747d9229a8206c617548a515bc794904b8c280b88d28ab4af8',1972,'BM','Bermuda','people-and-society',69,'Population: 60,000 (January 1979), average annual
growth rate 1.2% (7-70 to 7-76)
Nationality: noun—Bermudian(s); adjective—Bermudian
" Ethnic divisions: approximately 59% black, 41% white
Religion: 47.5% Church of England, 38.2% other Protes-
tant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force: 25,200 (1975)
Population: 1,282,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Bhutanese (sing., pl.); adjective—
Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese, 15%
indigenous or migrant tribes
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
eR ALA LAL nae Ba ake:
ek te a A a en a AT AA en en A ee ee a a A A a i.
Rte Gt ee tee oe
a ee ee eee ee ee ae eS ee ee a ee ee ee
SE er ee ee ae, ee,
ee eee ee | ee ee a a ee ee ee
et i i i in A Il
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BHUTAN/BOLIVIA
(See reference map Vil)
Religion: 75% lLamaistic Buddhism, 25% Buddhist-
influenced Hinduism
Language: Bhotias speak various Tibetan dialects, most
widely spoken dialect is Dzongkha, the official language;
Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry;
massive lack of skilled labor
Population: 5,149,000 (January 1979), average annual
growth rate 2.6% (current)
’ Nationality: noun—Bolivian(s); adjective—Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active Protes-
tant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.8 million (1977); 70% agriculture, 3%
mining, 10% services and utilities, 7% manufacturing, 10%
other
21
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BOLIVIA','757ee4bed3a8c90672354ee5a2198881e168d62c04d5bfbf4da664d0bb452fa5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6820fd55b54fbdc1aec3856a4fe1780e23b32cd30b84395de2015063884c70cc',1972,'BR','Brazil','people-and-society',72,'Pacific
(See reference map til)
Organized labor: 150,000-200,000, concentrated in min-
ing, industry, construction, and transportation
Population: 122,602,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Brazilian(s); adjective—Brazilian
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and
2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 83% of the population 15 years or older (1978)
Labor force: about 30 million in 1970 (est.); 44.2%
agriculture, livestock, forestry, and fishing, 17.8% industry,
15.3% services, transportation, and communication, 8.9%
commerce, 4.8% social activities, 3.9% public administration,
5.1% other
Organized labor: about 50% of labor force; only about 1.5
million pay dues
Population: 190,000 official estimate for 1 July 1977
Nationality:. noun—Bruneian(s); adjective—Bruneian
Ethnic divisions: 52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
25
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BRUNEI/BULGARIA
ARR
South China Sea We Dy
: BRUNEI
Bandar Seri Begawa''
0
INDONESEA
(See reference map Vil}
Religion: 60% Muslim (Islam official religion); 8%
Christian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture; 32.8% industry,
manufacturing, and construction; 33.8% trade, transport,
services; 2.9% other
Organized labor: 8.4% of labor force
Population: 7,665,000, excluding nomadic Indian tribes,
‘(January 1979), average annual growth rate 3.0% (current)
Nationality: noun—Ecuadorean(s); adjective—Ecuador-
ean
55
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Population: 388,000 (January 1979), average annual
growth rate 1.5% (1-68 to 1-77)
Nationality: noun—Surinamer(s); adiective—Surinamese
Ethnic divisions: 31% Creole (Negro and mixed), 37%
Hindustani (East Indian), 15.3% Javanese, 10.3% Bush
Negro, 2.6% Amerindian, 1.7% Chinese, 1.0% Europeans,
1.7% other and unknown
Religion: Hindu, Muslim, Roman Catholic, Moravian,
other
Language: Dutch official; English widely spoken; Sranan
Tongo (Surinamese, sometimes called Taki-Taki) is native
language of Creoles and much of the younger population,
_and is lingua franca among others; Hindi; Javanese
Literacy: 80%
Labor force: 118,000
Organized labor: approx. 33% of labor force','058b2431a9b74e6d5fa795487e33b08789c7b653c284ae9b639332b0320e19ed','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baf4c128797399c2021f2d49829feec5f5dee1d758e821185e5efd0f27301802',1972,'BW','Botswana','people-and-society',77,'Population: 760,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Botswana (sing.), Batswana (pl.);
adjective—Botswana
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% Euro-
pean :
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana; less
than 1% secondary school . graduates
Labor force: 385,000; most are engaged in cattle raising
and subsistence agriculture; about 51,000 in internal cash
economy, another 60,000 spend at least 6 to 9 months per
year as wage earners in South Africa (1971)
Organized labor: eight trade unions organized with a total
membership of approximately 9,000 (1972 est.)
Population: 7,431,000 (January 1979), average annual
growth rate 3.5% (current)
Nationality: noun—Rhodesian(s); adjective—Rhodesian
Ethnic divisions: 96% African, less than 4% European,
less than 0.5% coloreds and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and Sindebele also
widely used
Literacy: 25%-30%; of whites, nearly .100%
Labor force: (1972) 778,000 Africans (including some
migrants from Zambia and Malawi), 108,000 Europeans,
Asians, and coloreds (people of mixed heritage); 35%
agriculture, 25% mining, manufacturing, construction, 40%
transport and services
Organized labor: about one-third of. European wage
earners are unionized, but only a small minority of Africans
(1966)','493f2d6b76af1981bc2c869398669eb52fe6576f3365082824f703ca6f77af5f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b3d5893e10452a8a22dfd59d3e34b282296190f607d7370d5e413c0e7ca8347',1972,'RO','Romania','people-and-society',80,'Black Sea
(See reference map 1V)
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.4 million; 14% agriculture, 38.6% industry,
11% services, 36.4% construction, communications and
others
Population: 21,964,000 (January 1979), average annual
growth rate 0.8% (current)
Nationality: noun—Romanian(s); adjective—Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian, 2%
German, 3% other
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, 1 million Protestants, 60,000 Jews, 30,000 "
Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.2 million (1975); 38% agriculture, 31%
industry, 31% other nonagricultural','dcfe6e9c7029c073414cf8f4bb3bc33aaefab316164bd30accd328869076e8f1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d94ddb9be1b9f2b5f1da38065352b242b0645e0971d74e2c2b42bf7b3c5c9da8',1972,'BI','Burundi','people-and-society',82,'Population: 4,263,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Burundian(s); adjective—Burundian
Ethnic divisions: Africans—85% Hutu (Bantu), 14% Tutsi
(Hamitic), 1% Twa (Pigmy); other Africans include perhaps
50,000 Zairians and 40,000 Rwandans; non-Africans include
about 3,000 Europeans and 1,000 South Asians
Religion: about 60% Christian (53% Catholic, 7%
Protestant); rest mostly animist plus perhaps 2% Muslims
~ TANZANIA
LO
{See reference map Vi)
Language: Kirundi and French official plus Swahili
(along Lake Tanganyika and in the Bujumbura area)
Literacy: about 15% in Kirundi, 3% in French, no
serviceable estimate for Kiswahili
Labor force: about 2 million (1976 est.)
_ Organized labor: sole group is the. Union of Burundi
Workers (UTB); by charter, membership is extended to all
Burundi workers (informally); figures denoting “‘active
membership” have been unobtainable','95a3ea14edc16e612b126fa75ee0933f4eaeac38af3f313febb989753f082366','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e94f1655fc0dc5da4660f5ef313fc1e582e4f73b0d462852c328f7a4d213ddb3',1972,'GA','Gabon','people-and-society',87,'Population: 8,088,000 (January 1979), average annual
growth rate 2.0% (current)
Nationality: mnoun—Cameroonian(s); adjective—Came-
roonian
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial
Bantu, 8% Northwestern Bantu, 10% Fulani, 7% Eastern
Nigritic, 11% Kirdi, 13% other African, less than 1%
non- African ;
Religion: about one-half animist, one-third Christian; rest
Muslim
Language: English and French official, 24 major African
language groups ;
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence
agriculture and herding; 200,000 wage earners (maximum)
including 22,000 government employees, 63,000 paid
agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force
Population: 575,000 (January 1979), average annual
growth rate 1.7% (7-66 to 7-70)
Nationality: noun—Gabonese (sing., pl.); adjective—
Gabonese ;
Ethnic divisions: about 40 Bantu tribes, including 4 major
tribal groupings (Fang, Eshira, Mbede, Okande); about
100,000 expatriate Africans and Europeans, including 30,000
French
Religion: 55% to 75% Christian, less than 1% Muslim,
remainder animist
Language: French official language and medium of
instruction in schools; Fang is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage
earners in the modern sector
Organized labor: less than 30% of wage labor force
Population: 576,000 (January 1979), average annual
growth rate 2.7% (7-76 to 7-77)
Nationality: noun—Gambian(s); adjective—Gambian
Ethnic divisions: over 99% Africans (Mandinka 40.8%,
Fulani 13.5%, Wolof 12.9%, remainder made up of several
smaller groups), fewer than 1% Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Mandinka and Wolof most
widely used vernaculars
Literacy: about 10%
71
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
THE GAMBIA/GERMAN DEMOCRATIC REPUBLIC
Labor force: approx. 165,000, mostly engaged in subsist-
ence farming; about 15,000 are wage earners (government,
trade, services)
Organized labor: 25% to 30% of wage labor force at most
Population: 16,783,000, including East Berlin (January
1979), average annual growth rate 0.1% (current)
Nationality: noun—German(s); adjective—German
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 58% -Protestant, 8% Roman Catholic, 39%
unaffiliated or other; less than 5% of Protestants and about
25% of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7% handi-
crafts; 6.8% construction, 11.9% agriculture; 6.8% transport
and communications; 10.1% commerce; 16.8% services; 2.5%
other
Organized labor: 87.7% of total labor force
Population: 61,262,000, including West Berlin (January
1979), average annual growth rate —0.1% (current)
Nationality: noun—German(s); adjective—German
Ethnic divisions: 99% Germanic, 1% other
Religion: 48.9% Protestant, 44.7% Roman Catholic, 7.7%
other (as of 1975)
Language: German
Literacy: 99%
74
Labor force: 26.7 million; 42.9% in manufacturing and
construction, 18.0% services, 12% commerce, 9.9% govern-
ment, 6.3% agriculture, 5.9% communication and transpor-
tation, 1% mining; 4.2% average unemployed as of 1977,
excluding self employed
Organized labor: 32.6% of total labor force; 41.4% of
wage and salary earners
Population: 82,000 (January 1979), .average annual
growth rate 1.2% (current)
Nationality: noun—Sao Tomean(s): adjective—Sao
Tomean ; .
Ethnie divisions: native Sao Tomeans, migrant Cape
Verdians, Portuguese °.
Religion: Roman -Catholic,
Seventh Day Adventist
Language: Portuguese official
Literacy: estimated at 5%-10%
Evangelical Protestant,
180
Labor force: most of population engaged in subsistence
agriculture and fishing; nearly half the island’s work force,
about 10,000 people, are unemployed, the other half work
on cocoa plantations','9f654fba3c0da45520df3ba7d34ebce3b9a57d7dec800c4b2aa8a60889dcd63c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cba70f74a80b868f593c50581792f7479fd91bbf71090b5ceadec313751722e2',1972,'CA','Canada','people-and-society',91,'Population: 23,712,000 (January 1979), average annual
growth rate 1.1% (1-77 to 1-78)
Nationality: noun—Canadian(s); adjective—Canadian
Ethnic divisions: 44% British Isles origin, 30% French
origin, 26% other - :
” Religion: 48% Protestant,. 47% Catholic, 5% other
31
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Language: English and French official
Labor force: 11.1 million; 29% service, 22% manufactur-
ing, 16% trade, 8% transportation and utilities, 6% agricul-
ture, 6% construction, 8% other; 8.5% unemployment
(September 1978)
Organized labor: 30% of labor force
Population: 318,000 (January 1979), average annual
growth rate 1.9% (12-70 to 7-76)
Nationality: noun—Capeverdean(s); adjective—Capever-
dian
Ethnic divisions: about 28% African; 70% mulatto; 2%
European
Religion: Catholicism, fused with local superstitions
Language: Portuguese and crioula, a blend of Portuguese
and West African words,
Literacy: 14% .
Labor force: bulk of population engaged in subsistence
agriculture
Population: 1,934,000 (January 1979), average annual
growth rate 2.38% (current)
Nationality: noun—Central African(s); adjective—Cen-
tral African
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and_ linguistic
characteristics; Banda (32%) and Baya-Mandiia (29%) are
largest single groups; 6,500 Europeans, of whom 6,000 are
French and majority of the rest Portuguese
Religion: 40% Protestant, 28%-Catholic, 24% animist, 8%
Muslim; animistic beliefs and practices strongly influence
the Christian majority
, Language: French official; Sangho, lingua franca and
national language |
Literacy: estimated at 5%-10%
* ’ Labor force: about half the population economically
active, 80% of whom are in agriculture; approximately
64,000 salaried workers
Organized labor: 1% of labor force
Population: 4,472,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun—Chadian(s); adjective—Chadian
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups—Muslims (Arabs, Toubou, Fulani, Kotoko,
Hausa, Kanembou, Baguirmi, Boulala, and Wadai) in the
north and center and non-Muslims (Sara, Mayo-Kebbi, and
Chari) in the south; some 150,000 nonindigenous, 5,000 of
them French
Religion: about half Muslim, 5% Christian, remainder
animist
Language: French official; Chadian Arabic is lingua
franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically
active group, of which 90% are engaged in unpaid
subsistence farming, herding, and fishing; 47,000 wage
earners in industry and civil service
Organized labor: about 20% of wage labor force','09e8debd1ee77ca6b2238ccb2a5c38af2b780ed2c26fb2268e8eef54841ed71e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7c17ac70e4af953be37e70f4590251bc81d5d8161987fb99d49b680dbdb080d',1972,'CL','Chile','people-and-society',95,'Population: 10,770,000 (January 1979), average annual
.-growth rate 1.5% (current)
Nationality: noun—Chilean(s); adjective—Chilean
.Ethnic. divisions: 95% European stock and mixed
European with some Indian admixture, 3% -Indian, 2% other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 90% (1977)
Labor force: 3.7 million economically active (1977); 30%
agricultural, 29% industry and construction, 7% services,
10% commerce, 7% mining, 9% transportation, 8% other
(1977)
Organized labor: 25% of labor force (1973)','ada27ae09446c1e38106a8e8746a3860796d6b9ea328b0f588714b759a8258d0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73caf31bfc742a063617c5a2cfd27a21849dd3a15339813966a39a1babeb4aed',1972,'CN','China','people-and-society',99,'Population: 1,014,074,000 (January 1979), average annual
growth rate 1.9% (current)
Nationality: noun—Chinese (sing., pl.); adjective—
Chinese
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur,
Hui, Yi, Tibetan, Miao, Manchu, Mongol, Pu-I, Korean, and
numerous lesser nationalities
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most impor-
tant elements of religion are Confucianism, Taoism,
Buddhism, ancestor worship; about 2%-3% Muslim, 1%
Christian
Language: Chinese (Mandarin mainly; also Cantonese,
Wu, Fukienese, Amoy, Hsiang, Kan, Hakka dialects), and
minority languages (see ethnic divisions above)
Literacy: at least 25%
38
Labor force: 335 million (mid-1966); 85% agriculture,
15% other; shortage of skilled labor (managerial, technical,
mechanics, etc.); surplus of unskilled labor
Population: 17,124,000, excluding the population of
Quemoy and Matsu Islands and foreigners (January 1979),
average annual growth rate 1.8% (1-77 to 1-78)
Nationality: noun—People of Taiwan; adjective—Taiwan
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese,
2% aborigines
* Religion: 98% mixture of Buddhism, Confucianism, and
Taoism; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language), also
Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 6.12 million (1978); 26.2% primary industry
(agriculture), 39% secondary industry (including manufac-
turing, mining, construction), 34.8% tertiary industry (in-
cluding commerce and services) 1977; 2% unemployment
(1976)
39
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TAIWAN/COLOMBIA
Organized labor: about 12% of 1972 labor force
(government controlled)
Population: 39,206,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: homogeneous; smal] Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk
religion (Shamanism); vigorous Christian minority (16.6%
Christian population); Buddhism (including estimated
20,000 members of Soka Gakkai); Chondokyo (religion of
the heavenly way), eclectic religion with nationalist over-
tones founded in 19th century, claims about 1.5 million
adherents
Language: Korean
Literacy: about 90%
Labor force: about 12.9 million (1977); 42% agriculture,
fishing, forestry; 22% mining and manufacturing; 36%
services and other; average unemployment 3.8% (1977)
Organized labor: about 13% of nonagricultural labor
force','e12c6344322d725f03b8efcd5cd9a0cec5b18afaa7dfc6335b8292e79c244444','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81f930759ef716a4c70081c2ae8ed4de99a126ec27b15b1a167b5ae31340ad57',1972,'CO','Colombia','people-and-society',103,'Population: 25,837,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Colombian(s); adjective—Colombian
Ethnic divisions: 58% mestizo, 20% caucasian, 14%
mulatto, 4% Negro, 3% mixed Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13%
manufacturing, 18% services, 9% commerce, 13% other
(1964); 10%-13% unemployment (1975)
Organized labor: 13% of labor force (1968)
Population: 249,000 (January 1979), average annual
growth rate 1.3% (1-76 to 1-77)
Nationality: noun—Netherlands Antillean(s); adjective—
Netherlands Antillean
Ethnic divisions: racial mixture with African, Caribbean
Indian, European, Latin, and oriental influences; negroid
characteristics are dominant on Curacao, Indian on Aruba
Religion: predominantly Roman Catholic; sizable Protes-
tant, smaller Jewish _minorities
Language: officially Dutch; Papiamento, a Spanish-
Portuguese-Dutch-English dialect predominates; English
widely spoken
Literacy: 95%
Labor force: 76,000 (1972); 2% agriculture, 20% industry,
10% construction, 65% government and services, 3% other
Organized labor: 60%-70% of labor force','b70b11db19e70a318bf6e80b0e715fa375e5b41de4b821233eac9cb4728f9055','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f9943f1cc5f89fc314ec0a0e09b2c910cf5cc365a0a312674f7c5bf09a2d153',1972,'KM','Comoros','people-and-society',107,'-Population: 320,000 (January 1979), average annual
growth rate 2.1% (current)
_ Nationality: noun—Comoran(s); Sdiseive- Comoran
42
January 1979
Indian Ocean
Moroni, ComoRoS ‘
-4
.
Population: 1,484,000 (January 1979),. average annual
growth rate 2.7% (current).
Nationality: noun—Congolese (sing., pl.); adjective—
Congolese or Congo
‘Ethnic divisions: about 15 ethnic groups divided into
some 75 tribes, almost all Bantu; most important ethnic
groups are Kongo (48%) in south, Teke (17%) in center,
M’Bochi (12%) and Sangha (20%) in north, about 8,500
Europeans, mostly French
Religion: about half animist, half nominally Christian, less
than 1% Muslim
Language: French official, many African languages with
Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 40% of population economically
active, most engaged in subsistence agriculture; 79,100 wage
earners; 40,000-60,000 unemployed.
Organized labor: 16% of total labor force (1965 est.)','4a330afdf7b8e03717e1e092fb1a6ebf0298677831506c4cc6408e44e00a662c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48112c2ed33d326c632ac1369f8fed2c93d8db3e5e33e5ab426b8a7ff6ccdf67',1972,'MG','Madagascar','people-and-society',108,'(See reference map Vi}
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
" Literacy: presumably low
Labor force: mainly agricultural','9e8c65e2411252914935ab1b1e191b8d6be5ea6fc8a49cfb6e11f615af10b582','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('238277e96353402d6dee7114b143b8b6aa3eefef98c31944d30aea686b8dc800',1972,'CK','Cook Islands','people-and-society',113,'Population: 18,000 (total from the census of 1 December
1976)
Nationality: noun—Cook Islander(s); adjective—Cook
Islander ;
Ethnic divisions: 81.3% Polynesian (full blood), 7.7%
Polynesian and European, 7.7% Polynesian and other, 2.4%
European, 0.9% other
Religion: Christian, majority of populace members of
Cook Islands Christian Church','511ba9476ca78dd38f25177836b9d963b74d53f23b23cf221f60b6a9d8fe4009','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6af5ff1b78930ccf3e632e41d2088ef4b953df751f082bf4e326887dfa594c98',1972,'CR','Costa Rica','people-and-society',117,'Population: 2,144,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun—Costa Rican(s); adjective—Costa
Rican
{See reference map fl)
Ethnic divisions: 98% white (including mestizo), 2%
Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 90%
Labor force: 657,709 (1976); 32.6% agriculture; 13.8%
manufacturing; 15.3% commerce; 6.1% construction; 5.2%
transportation, utilities; 20.3% service (government, educa-
tion, social); 0.5% other; 6.2% unemployment (1976)
Organized labor: about 11.5% of labor force
Population: 9,874,000 (January 1979), average annual
growth rate 1.6%. (current)
Nationality: noun—Cuban(s); adjective—Cuban
Ethnic divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese :
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
4
a ttl a i i i a a ee ae —
ee RE SE Se a ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CUBA/CYPRUS
Religion: at least 85% nominally Roman Catholic before
Castro assumed power
'' Language: Spanish
Literacy: about 96%
Labor force: 2.7 million in 1976;»33% agriculture, 17%
industry, 9% construction, 7% transportation, 32% services,
2% unemployed','604eaad25f6d5214518c9059d4202b3c1dddaebcbc36703748f1b94747a76f12','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2058861201ba648051aeaf9924a171af4c0450559c59be21d91cf34125d2ec8a',1972,'CY','Cyprus','people-and-society',121,'Population: 642,000 (January 1979), average annual
growth rate 0.2% (7-76 to 7-77)
Nationality: noun—Cypriot(s); adjective—Cypriot
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Maron-
ite, Armenian, Apostolic, and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Greek Sector labor force: 207,700 (1976), 22% agricul-
ture, forestry, fishing; 14% manufacturing; 6% construction;
1% mining and quarrying; 14% services; 10% trade and
finance; 3% transportation and communications; 5% public
administration, 25% other; unemployment 4% (1977)
Turkish Sector labor force: 179,400 (145,900 employed,
33,500 unemployed); 31% agriculture, 18% services, 17%
manufacturing, 12% wholesale and retail trade, 22% other
(1975)
Population: 15,189,000 (January 1979), average annual
growth rate 0.7% (current)
Nationality: noun—Czechoslovak(s); adjective—Czecho-
slovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks, 4.0%
Magyars, 0.6% Germans, 0.5% Poles, 0.4% Ukrainians, 0.2%
others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant, 2%
Orthodox, 1% other
49
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CZECHOSLOVAKIA
REPUBLIC CZECHOSLOVAKIA
OF GERMANY','bdf026027aec3b26e7e2067628cc7767a2d4544cd6d69f6114386bd8d9482341','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14f9726144562f947cd4eef3301e058cef857e45f0e09cdb37454640773d1b65',1972,'DK','Denmark','people-and-society',127,'Population: 5,112,000 (January 1979), average annual
growth rate 0.3% (current)
Nationality: noun—Dane(s); adjective—Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 1% other
Language: Danish; small German-speaking minority
Literacy: 99% ,
Labor force: 2,579 million (October 1977); 8.6% -agricul-
ture, forestry, fishing, 24.6% manufacturing, 8.1% construc-
tion, 15.4% commerce, 6.6% transportation, 5.4% services, .
29.3% government, 2.0% other; 6.4% (164,000) registered
unemployed as percentage of total labor force (1977 annual
average)
Organized labor: 65% of Jabor force','64c88a59aaea3b0f16bad1b3dd2212edeaed6d428e9b163b948f6b3121898d55','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b888cb6e42e272136224c5d734933e1dfcfb70b4d75f3f0353ca8a831c369528',1972,'DM','Dominica','people-and-society',134,'Population: 78,000 (January 1979), average annual
growth rate 0.7% (1-75 to 1-77)
Nationality: noun—Dominican(s); adjective—Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist ‘
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture; 24%
unemployment
Organized labor: 25% of: the labor force','8ccaea5bae31b084d182236cb55958b29523c2782a87da5b2787e0e78a1e11e4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3af9bc1b51c6d146379ea2ed2b14a321e62b1a7d860cc23df15030dba3d9c37f',1972,'DO','Dominican Republic','people-and-society',138,'Population: 5,466,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Dominican(s); adjective—Dominican
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8% industry,
19% services and other
Organized labor: 12% of labor force','71d384beb24332779497dfa64c69f857bea20c946fa880df4cc0b1fec03ba3c2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63637c96fec23e9c52bef1811c72eece7fe77fb561c93ad2df64d1e62a25b8c4',1972,'EC','Ecuador','people-and-society',142,'Ethnic divisions: 40% mestizo, 40% Indian, 10% white,
5% Negro, 5% Oriental and other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Ouschiva:
Literacy: 57% :
Labor force: 2 million, of which 56% agriculture, 13%
manufacturing, 4% construction, 7% commerce, 4% public
administration, 16% other servicés and activities
Organized labor: less*than 15% of labor force
Population: 40,424,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Egyptian(s); adjective—Egyptian or
Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek,
Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and
other
Language: Arabic official, English and French widely
understood by educated classes
Literacy: around 40%
Labor force: 12 million; 45 to 50% agriculture, 10%
industry, 10% trade and finance, 30% services and other;
shortage of skilled labor
Organized labor: 1 to 3 million','ca8ed967ff99e7b1f1e6f6c046ebe8dc606a0647460bcf8efa92d82347d7c675','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e9e8d97170e275958097dea4e02ee480f88b4152e0a34c0e8a62480b3385f4d',1972,'SV','El Salvador','people-and-society',146,'Population: 4,580,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Salvadoran(s); adjective—Salvadoran
58
HONDURAS.
NICARAGUA |
(See reference map ti)
Ethnic divisions: 84%-88% mestizo; Indian and white
minorities, 6%-8% each a
Religion: predominantly. Roman Catholic, probably
97%-98%
Language: Spanish
Literacy: 50% literacy in urban areas, 30% in rural areas
Labor force: 1,500,000 (est. 1977); 57% agriculture, 14%
services, 14% manufacturing, 6% commerce, 9% other;
shortage of skilled labor and large pool of unskilled labor,
but manpower training programs improving situation
Organized labor: 5% of total labor force; 10% of
nonagricultural labor force (1977)','2cef4da3c9cb2b0f02a78e32e229db82ddb5c33d157c732eef9bd04d20be92ce','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddea44bdd2a2560010802435d41f9ad51fd172d7eb9d6c922662cf0a26810b2e',1972,'CM','Cameroon','people-and-society',149,'Population: 339,000 (January 1979), this estimate does not
take into account emigration from Equatorial Guinea during
the last several years, average annual growth rate 1.8% (7-68
to 7-69); Rio Muni, 237,000, average annual growth rate
1.5% (7-68 to 7-69); Fernando Po, 102,000, average annual
growth rate 2.6% (7-68 to 7-69)
Nationality: noun—Equatorial Guinean(s); adjective—
Equatorial Guinean
Ethnic divisions: -indigenous population of Province
Macias Nguema Biyogo, primarily Bubi, some Fernandinos;
of Rio Muni primarily Fang; less than 1,000 Europeans,
primarily Spanish
Religion: natives all nominally Christian and predomi-
nantly Roman Catholic; some pagan practices retained
Language: Spanish official language of government and
business; also pidgin English, Fang
Literacy: 20% ;
Labor force: most Equatorial Guineans involved in
subsistence agriculture','88e5a61c6dad7d3d9e1feacd8f7f9dd4a17955175d76b854e6ccadf07dce0212','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cc32cbd49d4f12742b897f988077fba042f2be067422c8dfa7066923c0b4974',1972,'ET','Ethiopia','people-and-society',153,'Population: 31,341,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Ethiopian(s); adjective—Ethiopian
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
fa Pret
a Oe VP” Oe aE OES OO
4
ALAA
RA MAL RL ARAL AA RA RA Rk AN ek NR A AN ERA A AR AAR AA Ae
a
SS es ee me ee
| Sait Ae tar a
!
bi. ss i A eo AU te, A Ria Sa Re A i i ll Ee a A ee ll lle ee, a
i a A dE I el Mi ee ee ii Se a i A ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
(See reference map Vi}
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%,
Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%, Gurage 2%,
other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Mus-
lims, 15%-20% animist, 5% other :
Language: Amharic official; many local languages and
dialects; English major foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10%
government, military, and quasi-government
Organized Jabor: All Ethiopian Trade Union formed
January 1977 to represent 273,000 registered trade union
members','b120e4ff77dba8e6b1e667de35faac370f140bce46197e39879a8642a5c37fd5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62f67603aed2a9e0ae63eb6377267ad4ed91dd9ad005c305524baafe38ae93e5',1972,'FO','Faroe Islands','people-and-society',159,'Population: 43,000 (January 1979), average annual
growth rate 1.4% (1-75 to 1-77) :
Nationality: noun—Faroese (sing., pl.); adjective—
Faroese
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufac-
turing, transportation, and commerce','7a948852209e9f8fd0735279ec605688dd7df799f2a93f8fb2dad05e6a3ee815','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb58b7c13e0f2acf6f61151575f812b5db5d900710fbdde68363d09056a9634f',1972,'FI','Finland','people-and-society',163,'Population: 4,755,000 (January 1979), average annual
growth rate 0.3% (1-77 to 1-78)
Nationality: noun—Finn(s); adjective—Finnish
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox,
1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and
Russian-speaking minorities
Literacy: 99%
Labor force: 2.2 million; 16.6% agriculture, forestry, and
fishing, 26.4% mining and manufacturing, 8.4% construc-
tion, 15.4% commerce, 6.8% transportation and communica-
tions, 4.0% banking and finance, 20.1% services; 6.1%
(186,000) unemployed 1977 annual coverage
Organized labor: 60% of labor force','94b4d640ee63af9fde02e8cfe3f7e3807bb33ae404ed9908745ae00d81410a26','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a24162e9da8e2c77d5d618a9bfe0e542bef6230f995f445bf2e07bfb60bb796c',1972,'FR','France','people-and-society',167,'Population: 53,536,000 (January 1979), average annual
growth rate 0.6% (current)
Nationality: noun—Frenchman (men); adjective—
French
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1%
Muslim (North African workers), 18% unaffiliated
Language: French (100% of population); rapidly declin-
ing regional patois—Provencal, Breton, Germanic, Corsican,
Catalan, Basque, Flemish
Literacy: 97%
Labor force: 22 million (est. in mid-1977); 47% services,
38% industry, 11% agriculture, 5% unemployed
Organized labor: approximately 17% of labor force, 23%
of salaried labor force’
Population: 3,242,000 (January 1979), average annual
growth rate 1.0% (7-75 to 7-77)
Nationality: noun—Irishman(men), Irish (collective pl.);
adjective—Irish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2% other
Language: English and Gaelic official; English is gen-
erally spoken
Literacy: 98%-99%
Labor force: about 1,143,000 (1976); 26% agriculture,
forestry, fishing; 19% manufacturing; 15% commerce; 7%
construction; 5% transportation; 4% government; 24% other;
9.8% unemployment (February 1976)
Organized labor: 36% of labor force
Population: 358,000 (January 1979), average annual
growth rate 0.4% (current)
Nationality: noun—Luxembourger(s); adjective—Luxem-
bourg
Ethnic divisions: 83% Luxembourger, including an
estimated 5% of Italian descent; remainder French, German,
Belgian, etc. ;
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish :
Language: Luxembourgish, German, French; most edu-
cated Luxembourgers also speak English
Literacy: 98%
Labor force: (1977) 147,300; one-third of labor force is
foreign, comprised mostly of workers from Portugal, Italy,
France, Belgium, and West Germany (1977); unemployment
0.2% (1977)','52af2b0b382ad9718123d5d3a85297115f17570aef030d868753f4517b5a5deb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37e90528ca26d3c7c87fc7595912633ff81a8f7951e09b0b16762124e54ebb9c',1972,'GY','Guyana','people-and-society',171,'Population: 60,000 (January 1979), annual growth rate
2.2% (10-74 to 11-77)
Nationality: noun—French Guianese (sing., pl.); adjec-
tive—French Guiana
Ethnic divisions: 95% Negro or mulatto, 5% caucasian,
10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construc-
tion 21%, agriculture 18%, industry 8%, transportation 4%;
information on unemployment unavailable
Organized labor: 7% of labor force
Population: 818,000 (January 1979), average annual
growth rate 1.3% (current)
Nationality: noun—Guyanese (sing., pl.); adjective—
Guyanese ;
Ethnic divisions: 51% East Indians, 43% Negro and
Negro mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1%
other
Language: English
Literacy: 86% .
Labor force: 242,000 (1975); 29% agriculture, 31%
manufacturing/mining, 40% services; 21% unemployed
Organized labor: 34% of labor force','a5f51911ebaef32913c23ef37bf760bb81b501522370e1d73267d257c50ebffd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('302f9c422e2117d17c618db08c6422faaad89d59b3102ece742ea2d4b87b7f2a',1972,'PF','French Polynesia','people-and-society',175,'Population: 143,000 (January 1979), annual growth rate
2.3% (current)
Nationality: noun—French Polynesian(s); adjective—
French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chinese, 6% local
French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32% Catholic','9626f88d901fa2e43c55161f586d2c035bd4994306deef3fb8be42a429510ef7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8c6e8188ac5b1881c25326739c3a938e373da323975c2de8cd544a7ea08874f',1972,'GN','Guinea','people-and-society',179,'Population: 11,553,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Ghanaian(s); adjective—Ghanaian
Ethnic divisions: 99.8% Negroid African (major tribes
Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12% Muslim
Language: English official; African languages include
Akan 44%, Mole-Dagbani 16%, Ewe 13%, and Ga-Adangbe
8%
75
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GHANA/GIBRALTAR
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing,
16.8% industry, 15.2% sales and clerical, 4.1% services,
transportation,- and communications, 2.9% professional;
400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor
force
Population: 5,973,000 (January 1979), average arinual
growth rate 2.6% (current)
Nationality: noun—Guinean(s); adjective—Guinean
‘Ethnic divisions: 99% African (8 major tribes—Fulani,
Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less than
1%
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written
language ,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GUINEA/GUINEA-BISSAU
Labor force: 1.8 million, of whom less than 10% are wage
earners; most of population engages in subsistence agricul-
ture
Organized labor: virtually 100% of wage labor force
loosely affiliated with the National Confederation of
Guinean Workers, which is closely tied to the PDG
Population: 5,450,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Senegalese (sing. & pl.); adjective—
Senegalese
Ethnic divisions: 36%-Wolof, 17.5% Fulani, 16.5% Serer,
9% Tukulor, 9% Dyola, 6.5% Malinke, 4.5% other African,
1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly
Roman Catholic)
182
Language: French official, but regular use limited to
literate minority; most Senegalese speak own tribal language;
use of Wolof vernacular spreading—now spoken to some
degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricul-
tural workers; about 170,000 wage earners
Organized labor: majority of wage-labor force repre-
sented by unions; however, dues-paying membership very
limited, three labor central] unions, major central is CNTS,
an affiliate of governing party','57b95551dd421a23304b3f3762126c126c7e789ede67e09014f4348f57366c82','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c41e5d2ad2f146d425e3f9764bfdd4fe3613f5c10ed56ced6e8d4e74e1489ba',1972,'GI','Gibraltar','people-and-society',183,'Population: 30,000 (official estimate for 1 July 1977)
Nationality: noun—Gibraltarian; adjective—Gibraltar,
Ethnic divisions: mostly Italian, English, Maltese, Portu-
guese and Spanish descent
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GIBRALTAR/GILBERT ISLANDS
Atlantic Ocean','30cbb791d3e85520367c2191118f94e903035a60d1952ba19acbc707c96dff32','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee74ecedafaab69fd93df512855fccd6a36a91f170bb244d010f50044faffdc8',1972,'GR','Greece','people-and-society',185,'Population: 9,372,000 (January 1979), average annual
growth rate 0.6% (7-67 to 7-77)
Nationality: noun—Greek(s); adjective—Greek
Ethnic divisions: 96% Greek, 2% Turkish, 2% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total
about 82%
Labor force: 3,400,000 (1975 est.); 40.5% agriculture,
25.6% industry, 33.7% services; unemployment 3%, but there
is substantial underemployment in agriculture
Organized labor: 20% of labor force est.','3ba7d8d2b8201f004a597b7495a81bad8a9a51a7f37343f09ac949685fffe1b7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2464771922fa27fe007a53289eb0dcffc56ff38a59cfbb29b51460265ebc508e',1972,'GL','Greenland','people-and-society',189,'Population: 50,000 (January 1979), average annual
growth rate 0.2% (1-75 to 1-77)
80
Nationality: noun—Greenlander(s); adjective—Green-
land
Ethnic divisions: 86% Greenlander (Eskimos and Green-
Jand-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep
breeding','0f614e969f2a9f6dbffb159cc78c6781e6ac88cfb2af3e39a30aca1881a4c0b0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99cb81e3bce786f677b2b8b4c8a03654188aa1a59de4bd7252cbb1a36e9486e7',1972,'GD','Grenada','people-and-society',193,'Population: 106,000 (January 1979), average annual
growth rate 1.4% (4-70 ‘to 7-77)
Nationality: noun—Grenadian(s); adjective—Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects;
Roman Catholic
Language: English; some French _ patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force','45cd8f8204ccbfa0148db208ad939642a046114cf21e45b00b24141be6c8c59a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b049d28fe899eb8038900f3b32d3a65ec706138385554cb71cce644bfc1e5297',1972,'GP','Guadeloupe','people-and-society',197,'Population: 324,000 (January 1979), average annual
growth rate 0.3% (10-67 to 1-76)
Nationality: noun—Guadeloupian(s); adjective—Guade-
loupe
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian ,
82
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force','6aa25801fec8d40657e64a078788593ec29f85df4a333cdad74cae1277e661f4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f20bb9c2b9b88dcf0d23182b5844aa9928483f38f25f246f7aca55d7c00301ea',1972,'MX','Mexico','people-and-society',200,'Population: 6,716,000 (January 1979), average annual
growth rate 2.9% (7-76 to 7-77)
Nationality: noun—Guatemalan(s); adjective—Guatema-
lan
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo
and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks
an Indian language as a primary tongue
Literacy: about 50%
Labor force (1974): 1.8 million; 52.5% agriculture, 10.1%
manufacturing, 21.7% services, 7.9% commerce, 3.9%
construction, 2.1% transport, 0.7% mining, 1.2% electrical,
0.8% other. Unemployment estimates vary from 3% to 25%
Organized labor: 6.4% of labor force (1975)
Population: 66,938,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Mexican(s); adjective—Mexican
Ethnic divisions: 60% mestizo, 30% Indian or predomi-
nantly Indian, 9% white or predominantly white, 1% other
Religion: 97% nominally Roman Catholic, 3% other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force: 17.6 million (1977) (defined as those 12 years
of age and older); 33.0% agriculture, 16.0% manufacturing,
16.6% services, 16.8% construction, utilities, commerce, and
transport, 3% government, 5.4% unspecified activities; 10%
unemployed, 40% underemployed
Organized labor: 20% of total labor force','36f887d5491460d92c72a8f6b5a6444372596da506433fb21498f6da3d613b39','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('163475242f482ebb7e0eb49c3a4187952ea669eafaec3ac577898be038b58bf5',1972,'GW','Guinea-Bissau','people-and-society',204,'Population: 625,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun—Guinean(s); adjective—Guinean
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes);
less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
85
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GUINEA-BISSAU/GUYANA
Se
Atlantic Ocean
(See reference map Vi}
Language: Portuguese and numerous African languages
Literacy: 3% to 5%
Labor force: 90% of economically active population
engaged in subsistence agriculture','133dc8294a34cd5ddc1cdf26910767de0bea110f99a4ed4dd097ea70b5598da4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('572c381a53765f3292063f50768b8b0a256ca16c71a880a3a83040843f94d4cd',1972,'PH','Philippines','people-and-society',208,'Population: 4,622,000 (January 1979), average annual
growth rate 1.6% (7-76 to 7-77)
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local
~ religions
Language: Chinese, English
Literacy: 75%
Labor force (1976 Census): 1.87 million; 45.3% manufac-
turing, 18.6% services, 6.0% construction, mining, quarrying
and utilities, 19.4% commerce, 2.6% agriculture, forestry,
fisheries, and hunting, 7.3% communications, 0.7% other;
underemployment is a serious problem
Organized labor: 21% of 1976 labor force
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
HONG KONG/HUNGARY
Population: 285,000 (January 1979), average annual
growth rate 1.5% (current)
Nationality: noun—Macaon(s); adjective—Macaon
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about
one-half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese and Macanese;
no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing, 3%
construction, 1% utilities, 27% commerce, 8% transportation
and communications, 26% services (1960 data)
Population: 46,388,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Filipino(s); adjective—Philippine
Ethnic divisions: 91.5% Christian Malay, 4% Muslim
Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4%
Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national
language of the Philippine Republic; English is the language
of school instruction and government business
Literacy: about 83%
Labor force: 15.4 million (1976); 60% agriculture,
forestry, fishing, 12% manufacturing, 10.5% commerce,
166
January 1979
10.5% government and services (business, recreation, domes-
tic, personal), 3.5% transport, storage, communication, 3%
construction; 0.5% other','77379b1c1ac1a12b914f6f3bacc933707fc43bb81c89ac21a6ce20a5b0c5bafa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e4a2712c0c67cd6b3b5d4f563c7dc02d3c8af7ab7ba820e8522672ebd1fed0a',1972,'HU','Hungary','people-and-society',213,'Population: 10,715,000 (January 1979), average annual
growth rate 0.4% (current)
Nationality: noun—Hungarian(s); adjective—Hungarian
Ethnie divisions: 92.4% Magyar, 2.5% German, 3.3%
Gypsy, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0% Calvinist, 5.0%
Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5,230,000 (1977); 20% agriculture, 34%
industry and building, 46% other non-agriculture
91
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
{See reference map IV}','3ac7cd669526bb59d4899b147992032972ac07afc075a30b933b170cd968fb4d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81930ad6ebc3a035e029042a21834cdc5a19e54fbc182c60d87bf6488edfc0ca',1972,'IS','Iceland','people-and-society',217,'Population: 224,000 (January 1979),. average annual
growth rate 0.7% (12-76 to 12-77) :
Nationality: noun—Icelander(s); adjective—Icelandic
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 90,000; 22.6% agriculture and fishing; 25.6%
mining and manufacturing; 10.7% construction; 12.8%
commerce; 7.8% transportation and communications; 15.2%
services; and 5.7% other; unemployment 1977, 0.6%
Organized: labor: 60% of labor force','057138990ef5c28a7f1afc5da930df37d46d999bea587947cde0df14b1ac702a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8488fe7f4e663b81fc7e0145c4f5f11cbc80180f54835ed3ca13301b47b5cd2a',1972,'IN','India','people-and-society',221,'Population: 667,907,000, including Sikkim and_ the
Indian-held part of disputed Jammu-Kashmir (January
1979), average annual growth rate 2.2% (current)
Nationality: noun—Indian(s); adjective—Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3%
Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6%
Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or more
persons each; numerous other languages and dialects, for the
most part mutually unintelligible; Hindi is the national
language and primary tongue of 30% of the people; English
enjoys “associate” status but is the most important language
for national, political, and commercial communication;
Hindustani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 839%; females 18%; both sexes 29% (1971
census)
Labor force: about 197 million; 70% agriculture, more
than 10% unemployed and underemployed; shortage of
skilled labor is significant and unemployment is rising
Organized labor: about 2.5% of total labor force','40af836fd609b5c35c06069984350a89bf5236c10b16c9b135c1f8ed446ebb6c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e4da603171b031c9006252a7f413bb910d7e9cc4db84181b45b7777f1c023f8',1972,'IL','Israel','people-and-society',227,'Population: 3,712,000, excluding East Jerusalem and the
other occupied territories (January 1979), average annual
growth rate 2.4% (1-77 to 1-78)
Nationality: noun—Israeli(s); adjective—Israel
Ethnic divisions: 85% Jews, 15% non-Jews (mostly Arabs)
Religion: 85% Judaism, 11% Islam, 4% Christian and
other
Language: Hebrew official; Arabic used officially for
Arab minority; English most commonly used foreign
language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,133,000; 6.5% agriculture, forestry and
fishing; 25.3% manufacturing (mining, industry); 0.9%
electricity and water; 8.1% construction and public works;
12.2% commerce; 7.7% transport, storage, and communica-
tions; 6.5% finance and business; 26.1% public services; 6.7%
personal and other services (1974)
Organized labor: 90% of labor force','f5d9450bc3de79c2cf4230a9c2a95ac739c973c8fca827b4d5bc543d3eb9ef62','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c2bd369cf53f888ba9e6532f29cc3c993bab6137a7184014f86533e5c513233',1972,'IT','Italy','people-and-society',231,'Population: 56,867,000 (January 1979), average annual
growth rate 0.5% (current) .
Nationality: noun—lItalian(s); adjective—Italian
Ethnic divisions: primarily Italian but population in-
cludes small clusters of German-, French-, and Slovene-Ital-
ians in the north and of Albanian-Italians in the south
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ce ae Oe Se
i Oe Oe eS ee,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
(See reference map IV}
Religion: almost 100% nominally Roman Catholic (de
facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region
(e.g., Bolzano) are predominantly German speaking; signifi-
cant French-speaking minority in Valle d’Aosta Region;
Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5%-7% of population allterate (1972); illiteracy
varies widely by region
Labor force: 20,125,000 (July 1978); 15.0% sericea:
42.9% industry, 39.0% other (1975); 7.1% unemployment
(1978); 1.5 million Italians employed in other Western
European countries
Organized labor: 50-55% (est.) of labor force
Population: 7,365,000, resident African population only,
(January 1979), average annual growth rate 2.7% (current)
Nationality: noun—Ivorian(s); adjective—Ivorian
- Ethnic divisions: 7 major indigenous ethnic groups; no
single tribe more than 20% of population; most important
are Agni, Baoule, Krou, Senoufou, Mandingo; approximately _
2 million foreign Africans, mostly Upper Voltans; about
75,000 to 90,000 non-Africans (50,000 to 60,000 French and
25,000 to 30,000 Lebanese)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula
most widely spoken
Literacy: about 65% at primary school level
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of labor
force are wage earners, nearly half in agriculture, remainder
in‘ government, industry, commerce, and professions
Organized -labor: 20% of wage labor force','a3b58a2525f5094a6a5e2a6fc177ba020f8e7f036da6080ed59412f9ab9290ae','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7112c530f8c1eb7d6688f55d1eda381de2688ce1db4a28efe3fb134093b13df',1972,'JM','Jamaica','people-and-society',235,'Population: 2,217,000 (January 1979), average annual
growth rate 1.4% (current)
Nationality: noun—Jamaican(s); . adiective—Jamaican
Ethnic divisions: African 76.3%, Afro-European 15.1%,
Chinese and Afro-Chinese 1.2%, East Indian and Afro-East
Indian 3.4%, white 3.2%, other 0.9%
105
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Atlantic
Ocean
\\ |
os
> CUBR © DOMINICAN
REPUBLIC
HAITI.
N
JAMAICA Kingston
Ba Caribbean Sea
ICARAGUA
{See reference map il}
Religion: predominantly Protestant, some Roman Catho-
lic, some spiritualist cults
Language: English
Literacy: government claims 82%, but probably only
about one-half of that number are functionally literate
Labor force: 672,000 (1975); 29% in agriculture, forestry,
fishing and mining, 12% manufacturing/mining, 8% public
administration, 5% construction, 10% commerce, 3% trans-
portation and utilities, 33% services; 25% unemployed;
shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)
Population: 115,493,000, including Ryukyus (January
1979), average annual growth rate 1.0% (current)
Nationality: noun—Japanese (sing., pl.); adjective—
Japanese
Ethnic divisions: 99.2% Japanese, 0.8% other (mostly
Korean)
Religion: most Japanese observe both Shinto and Buddhist
rites; about 16% belong to other faiths, including 0.8%
Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and above (1960
data)
‘Labor force (1977): 54.5 million; 11% agriculture
forestry, and fishing; 34% manufacturing, mining, and
construction; 48% trade and services; 5% government; 2.0%
unemployed
Organized labor: 33.7% of labor force','0cc0a76fda25b23bd767ad8d2cd3ca59282c0c33e68202d256ffa44a408d59db','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca27ac7aa2b84dd5a5fa68bdb7406801a1433ed3b9ad2bc5004804d90f262278',1972,'JO','Jordan','people-and-society',239,'Population: 3,008,000, including West Bank and East
Jerusalem (January 1979), average annual growth rate 3.2%
(7-70 to 7-76); East Bank, 2,224,000, average annual growth
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
JORDAN/KAMPUCHEA
rate 3.6% (7-70 to 7-76); West Bank, including East
Jerusalem, 784,000, average annual growth rate 1.9% (1-71
to 1-77)
Nationality: noun—Jordanian(s); adjective—Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 90%-92% Sunni Muslim, 8%-10% Christian
Language: Arabic official, English widely understood
among upper and middle classes
Literacy: about 50%-55% in East Jordan; somewhat less
than 60% in West Jordan
Labor force: 638,000; less than 5% unemployed
Organized labor: 9.8% of labor force
Population: 8,087,000 (January. 1979), average annual
growth rate 1.6% (current)
Nationality: noun—Kampuchean(s); adjective—Kampu-
chean
Ethnic divisions: 90% Khmer (Kampuchean), 5% Chi-
nese, 5% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian','667b00f65221132f0fa8d26668d9ca172c75a678c2dbe21aff8ef9559340f236','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8669430a9630eb21e2d9bbf6a00acf405d0a13e74e55817dbca5f90c5aba9660',1972,'KE','Kenya','people-and-society',243,'Population: 15,096,000 (January 1979), average annual
growth rate 3.6% (current),
Nationality: noun—Kenyan(s); adjective—Kenyan
Ethnic divisions: 97% native African (including Bantu,
Nilotic, Hamitic and Nilo-Hamitic); 2% Asian; 1% Euro-
pean, Arab, and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1%
Hindu
Language: English and Swahili official; each tribe has
own language ;
Literacy: 27%
Labor force: 2.5 million; about 977,000, (39%) in
monetary economy (1967)
Organized labor: about 215,000
Population: 18,421,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Korean(s); adjective—Korean
112
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities
now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 48% agriculture, 52% non-agri-
cultural; shortage of skilled and unskilled labor','78248f58b1640895a4676c497f8ff47e8297b7be1942099b0ee4ff3a8b149784','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('750435c2dce0375532d2a8b28bb4d12fb2048779b662ab2c4f60e9ba63d7b3b1',1972,'SA','Saudi Arabia','people-and-society',247,'Population: 1,241,000 (January 1979), average annual
growth rate 5.9% (current)
RE it EE
Ft i a a ae
Th,
}
ay ON ON eae ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
KUWAIT/LAOS
Nationality: noun—Kuwaiti(s); adjective—Kuwaiti
Ethnic divisions: 85% Arabs, 13% Iranians, Indians, and
Pakistani; native Kuwaitis are a minority
Religion: 99% Muslim, 1% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign
language
Literacy: about 60% _
Labor force: 340,000 (1976 est.); 26% manufacturing, 25% -
services, 35% government and professions, 9% commerce,
_ 5% oil industry; two-thirds of labor force is non-Kuwaiti
Organized labor: labor unions, first authorized in 1964,
formed in oil industry and among government personnel
. Population: 3,587,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Lao (sing., Lao or Laotian); adjec-
tive—Lao or Laotian
Ethnic divisions: 48% Lao; 14% Tribal Tai; 25%
Phoutheung (Kha); 138% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
5
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
LAOS
(See reference map Vil}
Language: Lao official, French predominant foreign
language
Literacy: about 12%
Labor force: about 1-1.5 million; 80%-90% agriculture
Organized labor: only labor organization is subordinate to
the Communist Party
(See reference mep V)
Nationality: noun—Qatari(s); adjective—Qatari
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani;
7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: primarily foreign
Population: 7,984,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality: noun—Saudi(s); adjective—Saudi Arabian or
Saudi ,
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% -(est.)
Labor force: about 33% (one-half foreign). of population;
40% agriculture and herding, 12% construction, 12% service,
12% government, 11% commerce, 13% other','5f369ed115119d03da3649212cf6ee4b28d4055acb1b7558fb3bd2e9c49080e1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a14b1cfdad09502875c7286b1f9c3a248684efce518213703793d517667cc725',1972,'LB','Lebanon','people-and-society',251,'Population: 2,568,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun—Lebanese (sing. and pl.); adjective—
Lebanese ,
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1%
other (official estimates); Muslims, in fact, constitute a
majority :
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically. active; 49%
agriculture, 11% industry, 14% commerce, 26% other;
moderate unemployment
LAOS/LEBANON
Organized labor: about 65,000','96a91807f24aca756fbc05a1a472ec6b7155cded627becee9c1eef92a206ea05','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80bab27a9d029e220269018365aeb6febc4f906da8e8ee3500ff2843cb5583fb',1972,'LS','Lesotho','people-and-society',255,'Population: 1,291,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Mosotho (sing.), Basotho (pl); adjec-
tive—Basotho
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800
Asians -
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months
to many years as wage earners in South Africa
Organized labor: negligible','198d2b2b7c5c1029093b522ef47f06b59f230af81e59be17820b528ab0ff2b10','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dc2c218e24ba8a41d911e09b8a3dd50e604f858becd4341bdcf0eec6d532015',1972,'LR','Liberia','people-and-society',259,'Population: 1,761,000 (January 1979), average annual
growth rate 3.8% (current)
Nationality: noun—Liberian(s); adjective—Liberian
Ethnic divisions: 5% descendants of immigrant Negroes;
95% indigenous Negroid African tribes including Kpelle,
Bassa, Kru, Grebo, Gola, Kissi, Krahn, and Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official; 28 tribal languages or dialects,
pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 600,000, of which 120,000 are in monetary
economy; about 2,000 non-African foreigners hold about
95% of the top level management and engineering jobs
Organized labor: 2% of labor force
119
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
LIBERIA/LIBYA','48f02cb723fab066d9774bb67c4b0c309eda4b44f55bf608decdacc84dce169c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9526821c6a7adade1bd53d7f73bfaabc9bcba3fbbe631ba9a57746f7206ac79',1972,'LY','Libya','people-and-society',263,'Population: 2,816,000 (January 1979), average annual
growth rate 4.1% (current)
Nationality: noun—Libyan(s); adjective—Libyan
Ethnic divisions: 97% Berber and Arab with some Negro
stock; some Greeks, Maltese, Jews, Italians, Egyptians,
Pakistanis, Turks, Indians, and Tunisians ;
Religion: 97% Muslim
'' Language: Arabic; Italian and English widely understood
in major cities
Literacy: 35%
Labor force: 900,000 of which about 350,000 are resident
foreigners (est. 1977)','58cdd651e5d28896eafb11548d57a9ab42bac8456cf43ee5463baa2f5334609f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e4d07ea2f37be228cc8a69435a2b06a50cff70b1e11736f3213d47d8233389e',1972,'LI','Liechtenstein','people-and-society',267,'Population: 22,000 (January’ 1979), average annual
growth rate 0.5% (current)
Nationality:
noun—Liechtensteiner(s); adjective—
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and commerce, ©
138% professional and other, 8% agriculture','1d89bd1cdad549feb2d49de19bd0691733d242e1752e54bdb8a551cd53198c2a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('169bc6a485d719e36f36265fd998d0e393b75a9821a765803ce707ffc2b499a7',1972,'ZA','South Africa','people-and-society',274,'Population: 8,258,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Malagasy (sing. and pl.); adjective—
Malagasy
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting of Mer-
ina (1,643,000) and related Betsileo (760,000), on the one
hand, and coastal tribes with mixed Negroid, Malayo-Indo-
nesian, and Arab ancestry on the other; coastal tribes include
Betsimisaraka 941,000, Tsimihety 442,000, Sakalava
375,000, Antaisaka 415,000; there are also 10-12,000
European French, 5,000 Indians of French nationality, and
5,000 Creoles
Religion: more than half animist; about 41% Christian,
7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence agricul-
ture; of 175,000 wage and salary earners, 26% agriculture,
17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscel-
laneous
Organized labor: 4% of labor force
Population: 27,754,000, including Bophuthatswana and
Transkei (January 1979), average annual growth rate 2.5%
(7-75 to 7-76); Bophuthatswana 1,123,000 (January 1979),
average annual growth rate 2.2% (current); Transkei
2,214,000 (January 1979), average annual growth rate 2.2%
(current)
Nationality: noun—South African(s); adjective—South
African
Ethnic divisions: 17.8% white, 69.9% African, 9.4%
Colored, 2.9% Asian
Religion: most whites and coloreds and roughly 60% of
Africans are Christian; roughly 60% of Asians are Hindu,
20% are Muslim
Language: Afrikaans and English official, Africans have
many vernacular languages :
Literacy: almost all white population literate; government
estimates 50% of Africans literate
Labor force: 8.7 million (total of economically active,
1970); 538% agriculture, 8% manufacturing, 7% mining, 5%
commerce, 27% miscellaneous services
Organized labor: about 7% ‘of total labor force is
unionized (mostly white workers); relatively small African
unions have no bargaining power
Population: 2,214,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Transkeian(s); adjective—Transkeian
Ethnic divisions: 98.9% African, 0.6% white, 0.5%
colored. (mulatto); Africans belong to Xhosa ethnic group
Religion: whites and coloreds predominantly Christian;
Africans either animist or Christian
Language: whites, coloreds, and educated minority of
Africans speak Afrikaans or English; bulk of Africans speak
Xhosa
Literacy: high for: whites and coloreds; low for Africans
Labor force: roughly 400,000 of whom only 50,000 are
regularly employed in Transkei; bulk are migrant workers in
Organized labor: no trade union, although some Trans-
keians employed in South Africa belong to South African
unions
Population: 37,774,000, including the Balearic and
Canary Islands; also including Alhucemas, Ceuta, Chafar-
inas, Melilla, and Penon de Velez de la Gomera (January
1979), average annual growth rate 1.2% (current)
Nationality: noun—Spaniard(s): adjective—Spanish
Ethnic divisions: homogeneous composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great maiority;
but 17% speak Catalan, 7% Galician, and 2% Basque
Literacy: about 97% ,
Labor force (1976): 13.3 million; 21% agriculture, 38%
industry, 41% services; unemployment now estimated at 8%
of labor force
Organized labor: labor unions legalized April 1977
experiencing surge in membership; probably represent about
25% of the labor force','80f4337c884e61ffad37104c393604d4296e40f49e09c384a25c6c90a4078785','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('562020daaa6b890f72c994274a9402f402866ede3dc755c4946397d2243d5620',1972,'MW','Malawi','people-and-society',278,'Population: 5,777,000 (January 1979), average annual
growth rate 2.9% (8-66 to 10-77)
Nationality: noun—Malawian(s); adjective—Malawian
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is
second African language
Literacy: 15% of population
‘Labor force: 225,000 wage earners employed in Malawi
(1974); 30% agriculture, 11% construction, 10% commerce,
13% manufacturing, 10% administration, 26% miscellaneous
services; 6,000 Europeans permanently employed
Organized labor: small minority of wage earners are
unionized','7b6e60b376be3497b2ae3abb95689204fabf40e4326f364543c2099412d861a4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2a6a440575226dc5f71d1fd19b94184d42cf6f501f963de3003fd62a1cb9c7',1972,'MY','Malaysia','people-and-society',282,'Population: 13,099,000 (January 1979), average annual
growth rate 2.8% (current)
Peninsular Malaysia: 10,926,000,
growth rate 2.6% (8-70 to 1-77)
Sabah: 967,000, average annual growth rate 4.8% (8-70
to 1-77)
Sarawak: 1,206,000, average annual growth rate 2.6%
average annual
(8-70 to 1-75)
Nationality: noun—Malaysian(s); adjective—Malaysian
Ethnic divisions:
Malaysia: 50% Malay, 35% Chinese, 10% Indian
Peninsular Malaysia: 58% Malay, 35% Chinese, 11%
Indian and Pakistani, 1% other
Sabah: 21% Chinese, 69% indigenous tribes, 10% other
Sarawak: 30% Chinese, 50% indigenous tribes, 19%
Malay, 1% other
Religion:
Peninsular Malaysia: Malays nearly all Muslim,
Chinese predominantly Buddhists, Indians predominantly
Hindu
Sabah: 38% Muslim, 17% Christian, 45%. other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist,
16% Christian, 35% tribal religion, 2% other
Language:
Peninsular Malaysia: Malay (official); English, Chinese
dialects, .Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal
languages
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 4.2 million (1975)
Peninsular Malaysia: 3.6 million; 46.2% agriculture,
forestry, and fishing, 10.9% manufacturing and construction,
31.9% trade, transport, and services (1975)
Sabah: 213,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 13% trade and
transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 13% trade,
transportation, and services, 1% other
Organized labor: 500,000 (1975 est.), about 15% of total
labor force; unemployment about 7% of total labor force, but
higher in urban areas
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','cb79ca8d68de2db185880575116f6268d90e4dbd38fb3a5890e53eb538bbb094','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dec87325277d7077c3338ed8829cd7266620f6d274ce55d000741924e27231c',1972,'MV','Maldives','people-and-society',288,'Population: 143,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Maldivian(s); adjective—Maldivian
Ethnic divisions: admixtures of Sinhalese, Dravidian,
‘Arab, and Negro
Religion: official Sunni Muslim
Language: Divehi ‘(dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male
population aa
Population: 6,287,000 (January 1979), average annual
growth rate 2.0% (current)
Nationality: noun—Malian(s); adjective—Malian
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages, of
which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried, 50,000 of
whom are employed by the government; most of population
engaged in agriculture and animal husbandry
Organized labor: Union National des Travailleurs Maliens
(UNTM) is umbrella organization over thirteen national
unions','44c76c02ba826e6db8504dff650d0952a490bcd726f22f97a82bc9ebe2e9ce4b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9baec7156a38db8246136abae3d21c0f4216b5d8384e720fbdde964783639db7',1972,'MT','Malta','people-and-society',292,'Population: 326,000 (official estimate for 31 December
1977) —
‘Nationality: noun’ Maltese (sing. and pl.); adjec-
tive Maltese
Ethnic ‘divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in
1946
Labor force: 119,554 (November 1977); 32% services
(except government), 18% government (except job corps),
5% job corps, 26% manufacturing, 6% agriculture, 3%
construction, 5% utilities and drydocks; 4% registered
unemployed
Organized labor: approximately 40% of labor force','0249f802ce81819db8c8e79c057453cbc95db3911df1632cecff2d3b91df50b0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd2d64f9036d8213d44dbf22b3c0788ee71aaf1c9553f56af462dd63b39c1ac1',1972,'MQ','Martinique','people-and-society',296,'Population: 319,000 (January 1979), average annual
growth rate —0.0% (10-67 to 1-77)
Nationality: noun Martiniquais (sing. and pl.); adjective
Martiniquais
Ethnic divisions: 90% African and African-Caucasian-
Indian mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
134
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10% commerce
and banking, 10% services, 9% industry, 17% other
Organized labor: 11% of labor force','7e58f20790424b0279e739dd054235fddc729ad83c562d6dff46da3c04a26d51','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d7ae0a60748f7f61638cff1d8c9631d0f12cade6e412e929d8ad97ad28345e6',1972,'MR','Mauritania','people-and-society',300,'Population: 1,562,000 (January 1979), average annual
growth rate 2.7% (7-72 to 7-75)
Nationality: noun—Mauritanian(s); adjective—Maurita-
nian
Ethnic divisions: nearly one third Moor, at least one third
Negro, one third mix Moor/Negro
Religion: nearly 100% Muslim
Language: Hassaniya Arabic is the national language
spoken by some 80% of the population, French is the
working language for government and commerce
Literacy: about 10%
Labor force: about 35,000 wage earners (1976); remain-
der of population in farming and herding; considerable
unemployment
Organized labor: 18,000 union members claimed by
single union, Mauritanian Workers’ Union
Population: 19,199,000 (January 1979), average annual
growth rate 3.0% (7-75 to 7-76)
Nationality: noun—Moroccan(s); adjective—Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish, 0.7%
non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government, diplo-
macy, and postprimary education
Literacy: 20%
Labor force: 5 million (1977 est.); 50% agriculture, 15%
industry, 26% services, 9% other; 10-20% unemployment
Organized labor: about 5% of the labor force, mainly in
the Union of Moroccan Workers (UMT)
Population: 75,000 (total from the census of 1974)
Nationality: noun—Saharan(s); adjective—Saharan
Ethnic divisions: Arab, Berber, and Negro nomads
Religion: Muslim
Language: Hassaniya Arabic
Literacy: among Spanish, probably nearly 100%; among
nomads, perhaps 5% :
Labor force: 12,000; 50% animal husbandry and subsist-
ence farming, 50% other
Organized labor: none','05c7edd865bac7b1ee53e7bb0c041a1bf7fe9d8d5530a8e21f722ab19c1d6e9b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ad6e99f5c8faf0f659031a533fbdbd82a7a1f61ded90f7e4a3e7ac582853c8a',1972,'MU','Mauritius','people-and-society',304,'Population: 927,000 (January 1979), average annual
growth rate 1.3% (7-71 to 7-77)
Nationality: noun—Mauritian(s); adjective—Mauritian
Ethnic divisions: 67% Indians, 29% Creoles, 3.5%
Chinese, 0.5% English and French
Religion: 51% Hindu, 33% Christian (mostly Catholic
with a few Anglican Protestants), 16% Muslim
Language: English official language; Hindi, Chinese,
French Creole
Literacy: estimated 60% for those over 21, and 90% for
those of school age
Labor force: 175,000; 50% agriculture, 6% industry; 20%
government services; 14% are unemployed, underemployed,
or self-employed, 10% other
Organized labor: about 35% of labor force
Population: 505,000 (January 1979), average annual
growth rate 1.3% (1-74 to 1-78)
Nationality: noun—Reunionese (sing. & pl.); adjective—
Reunionese ;
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese,
Pakistani, and Indian. origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal
unemployment','26e6a90d6da766f8e501b2914bbb2515661763e5af6e8579a1c0b9d1b6313b4c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ef575be8a6e3588207a52022fb89d84b0d2eef8cb8fa07e9c44aac5fbb60f4f',1972,'MC','Monaco','people-and-society',308,'Population: 25,000 (official estimate for 1 July 1976)
Nationality: noun—Monacan(s) or Monegasque(s); adjec-
tive—Monacan or Monegasque
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
‘Literacy: almost complete','2531f6d4b1199713f401c2374dff14d98a37309c4b7d81fbd3549e387a58ce33','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47232fcd064c6939a060f18d5af907393a6002a8df14d3b98484f8deea8a247c',1972,'MN','Mongolia','people-and-society',312,'Population: 1,612,000 (January 1979), average annual
growth rate 3.3% (current) ,
Nationality: noun—Mongolian(s); adjective—Mongolian
140
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese,
2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4%
Muslim, limited religious activity because of Communist
regime ;
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian, and
Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is in the labor force, including a Jarge percentage
of Mongolian women; shortage of skilled labor (no reliable
information available)','81671fd0dbf111e81ba577cd4b9dcd5776c7055dcbfcc437c87518c35f2dec46','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('772f8922cbf648190639100ef5dd44c78848a5590691b677947c10ee030c36d4',1972,'MZ','Mozambique','people-and-society',317,'Population: 9,987,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Mozambicar(s); adjective—Mozam-
bique ;
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
wiA_aAK_AA_»AA_A Aa AAA AKL _
Paina.
a=
pe aA __AL__A.
x
Sn Te AA an in ad
A
AA
ee
ro"
7
SE ee ee ee ae
January 1979
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
MOZAMBIQUE/NAMIBIA
Ethnic divisions: over 99% native African, less than 1%
European and Asian _
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim,
2.4% other ;
Language: Portuguese (official); many tribal dialects
Literacy: 7%-10% (est.)
Labor force: (1963 est.) 610,000; 50,000 non-African wage
earners, 560,000 African wage earners in Mozambique;
290,000 additional African wage earners temporarily work-
ing in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled labor or
remain in subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970); 75% are
white
Population: 533,000 (January 1979), average annual
growth rate 2.8% (5-66 to 8-76)
Nationality: noun—Swazi(s); adjective—Swazi
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence
agriculture; 55,000-60,000 wage earners, many only inter-
mittently, with 31% agriculture, 11% government, 11%
manufacturing, 12% mining and forestry, 35% other (1968
est.); 22,000 employed in South African mines (1976)
Organized labor:
unionized','f9bedbce5ac73499b2fa4a958375141de18e3c5968cf5103b4b120f167e97410','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edeae730ddade8b2ef740dd733781253a750029f5e1c11a2a356e45e661e28fa',1972,'NA','Namibia','people-and-society',321,'Population: 978,000 (January 1979), average annual
growth rate 2.9% (current)
143
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Atlantic
Ocean
Windhoek
; 1
SOUTH AFRICA»? *
(WALVIS BAY)
3
{See reference map Vi}
Nationality: noun—Namibian(s); adjective—Namibian
Ethnic divisions: 12% white, 6% mulatto, 82% African;
over half the Africans belong to Ovambo tribe
Religion: whites predominantly Christian, nonwhites
either animist or Christian
Language: Afrikaans principal language of about 70% of
white population, German of 22% and English of 8%; several
African languages ,
Literacy: high for white population; low for nonwhite
Labor force: 203,300 (total of economically active, 1970);
68% agriculture, 15% railroads, 18% mining, 4% fishing
Organized labor: no trade unions, although some white
wage earners belong to South African unions','f0babfd2ddf6db9c75da106049699e4b613853d853a3746d910d3201b4eff735','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c52219d3a6ef7d5fbc032959a5a5bf342cdb9fd258b0d7687834f975930366f1',1972,'NP','Nepal','people-and-society',325,'Population: 13,854,000 (January 1979), average annual
growth rate 2.5% (current)
. Nationality: noun—Nepalese (sing. and pl.); adjective—
Nepalese
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%), representing
considerable intermixture of Indo-Aryan and Mongolian
racial strains; country divided among many quasi-tribal
communities
Religion: only official Hindu Kingdom in world, although
no sharp distinction between many Hindu and Buddhist
groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided
into numerous dialects; Nepali official language and lingua
franca for much of the country; same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95%: agriculture, 5% industry;
great lack of skilled labor','8571d4db9301916af1ebdfc09f01a3f19db13ebcaf5d516f0c95249623586d6a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5a3a0b0049e15650bb66dba44ce1f50265004a9e824ca4f6c6b320d364ad754',1972,'NL','Netherlands','people-and-society',329,'Population: 13,976,000 (January- 1979), average annual
growth rate 0.6% (current)
Nationality: noun—Netherlander(s); adjective—Nether-.
lands
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 81% Protestant, 40% Roman Catholic, 24%
unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9% construction,
7% transportation and communications, 4% other; 5.1%
unemployment, March 1977
Organized labor: 33% of labor force','96ebace5fed92310e3888c6b2bdcef0e3bff0c926cb76730b550780340f5f44c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('751f932f3c0d13976eb8669f78835a03927cee46ec3b6c6e89a67e229362dd45',1972,'NZ','New Zealand','people-and-society',333,'Population: 3,176,000 (January 1979), average annual:
growth rate 0.8% (1-75 to 1-78)
151
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
a
* Pacific
\\ Ocean
Coral Sea','162c021581540374ad45f70eff3b2b409aa6b83377948002315128070d064242','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce38dba8372713589042fb3c93057f1ff8357d79f48ccc0f34053f72515671b4',1972,'NI','Nicaragua','people-and-society',336,'Population: 2,447,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality: noun—Nicaraguan(s);
guan
Ethnic divisions: 69% mestizo, 17% white, 9% Nesta, 5%
Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English speaking sHinoniy
on Atlantic coast
Literacy: 52% of population 10 years of age and over
Labor force: 728,419 (1977 est.); 43% agriculture, 15%
manufacturing, 13% commerce, 29% other; shortage of
adjective—Nicara-
skilled labor, but underemployment of unskilled labor
except during harvest
Organized labor: about 5.6% of labor force
Population: 5,064,000 (January 1979), average annual
growth rate 2.8% (7-76 to 7-77)
Nationality: noun—Nigerien (sing. and pl.); adjective—','8f2185f4321a9e74cc948ad5e8b06b404bc5fca8f7d80bd2549fc69eb31d2d20','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80d44f0ed2d0f0dfeb8517d0ffdea3f8b6a2a0611264e2cd1643143115b30485',1972,'NE','Niger','people-and-society',340,'Ethnic divisions: main Negroid groups 75% (of which,
Hausa 50%, Dierma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official, many African languages;
Hausa used for trade
Literacy: about 6%
Labor force: 26,000 wage earners; bulk of population
engaged in subsistence agriculture and animal husbandry
Organized labor: negligible ;','66b5a60f99843200b5aaceee8c97df4479300a774186c264f384bbeafcbacd78','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbcc904b018d27b30c28eb8ad8922060ad76f6fb729da8204c7c0bfd88955fa0',1972,'NG','Nigeria','people-and-society',345,'Population: 69,492,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Nigerian(s); adjective—Nigerian
Ethnic divisions: of the more than 250 tribal groups, the
Hausa and Fulani of the north, the Yoruba of the south, and
the Ibos of the east comprise 60% of the population; about
27,000 non-Africans .
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and Ibo also
widely used
Labor force: approx. 22.5 million; about 41% of total
population; roughly 1.3 million wage earners, of whom
560,000 work in modern enterprises
Organized labor: between 800,000 and 1 million wage
earners, approx. 2.4% of total labor force, belong to some 70
unions"','1976557148117846f47993c4fe8fc6fe6a4d636d3a8b3ebcdc0037ff45962f5c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6655ac5719484eea2b175416312a69fd1a49c3cbdc0c90f965f8a6d43b09f7c0',1972,'NO','Norway','people-and-society',349,'Population: 4,067,000 (January 1979), average annual
growth rate 0.4% (1-77 to 1-78)
Nationality: noun—Norwegian(s); adjective—Norwegian
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant
and Roman Catholic, 1% other
Language: Norwegian, smal] Lapp and Finnish-speaking
minorities
Literacy: 100%
Labor force: 1.9 million; 11.4% agriculture, forestry,
fishing, 25.3% mining and manufacturing, 8.1% construc-
tion, 16.38% commerce, 9.9% transportion and communica-
tion, 28.5% services; 1.4% unemployed (average annual
1977)
Organized labor: 60% of labor force
Population: 558,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Omani(s); adjective—Omani
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','204b41b67315f123ae927a7f279013515a49bf0ea543b4cb36e07972afc34ab9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7fc97cc9ca5cad4c3a410ced167e0ce4ab7c231f98970e57b18d49606fd8dbd',1972,'PK','Pakistan','people-and-society',353,'Population: 78,978,000, excluding Junagadh, Manavadar,
Gilgit, Baltistan, and the disputed area-of Jammu-Kashmir,
(January 1979), average annual growth rate 3.0% (current)
Nationality: noun—Pakistani(s); adjective—Pakistani
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages—7%
Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu, 9% other;
English is lingua franca
Literacy: about 17%
Labor force: 22 million (1978 est.); 60% agriculture, 16%
industry, 7% commerce, 15% service, 2% unemployed ,
Organized labor: 5% of labor force','50f7cb7e9fdba8f9ab3eccd4d2d7f9eb45adfd2852cf70ba738498341d453dbe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c6258727006b29ecb1d3eb4389f5203491726bdcb4cfb999fb66b277fcea226',1972,'PA','Panama','people-and-society',357,'Population: 1,837,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: adjective—Pana-
manian
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7%
Indian and other
noun—Panamanian(s);
Religion: over 90% Roman Catholic, remainder mainly
Protestant
Language: Spanish; about 14% speak English as native
tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and over
Labor force: 482,200 (1972 est.); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and fishing;
9.7% manufacturing and mining; 6.8% construction; 5%
Canal Zone; 3.9% transportation and communications; 1.2%
utilities; unemployment estimated at 10%. to 18%; shortage
of skilled labor but an oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','87571f4bc2cf2d92e77f5dd5b13ec80a5fb2cdd3cb60120724160c65a2c85b2f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b350f81014846defcbb39ea3c675b406439df76896255ba52071ad5ee3763a1e',1972,'PY','Paraguay','people-and-society',361,'Population: 3,143,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality:| noun—Paraguayan(s); adjective—Para-
guayan . ;
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman’ Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 800,000 (1971 est.); 52.6% agriculture,
forestry, fishing; 28.2% services; 19.2% manufacturing and
mining (1970)
Organized labor: about 5% of labor force
Pepulation: 17,053,000 (January 1979), average annual
growth rate 2.8% (current)
Nationality: noun—Peruvian; adjective—Peruvian
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Lm am A
mK Am RA A RR AA ERA RR Ke A A ee
Sm
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','c90da50b1e6bf235599c0bebe6b1486a8909ca8d390e1b5c9298e44f5445e5fa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f4f26a137d75b06e915ca1a08aa67b3c76d12f5ca278ab305ab8f17be8b6dce',1972,'PE','Peru','people-and-society',364,'Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish,. Quechua, Aymara
Literacy: 45% to 50%
Labor force: 5.0 million (1975); 42.1% agriculture, 17%
services, 14% manufacturing, 9% trade, 4% construction, 4%
transportation, 2% mining, 4% other
Organized labor: 37.1% of labor force','ee000242b5b933cae632c5fc67af0f797143804a1f885d908861014aa48a99fe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('305fc9046dd49ce4887af787358456ecf28d5a734a104ee5874a9ca2e4550b77',1972,'PL','Poland','people-and-society',369,'Population: 35,210,000 (January 1979), average annual
growth rate 1.0% (current)
. Nationality: noun—Pole(s); adjective—Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians, 0.5%
Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75% practicing),
5% Uniate, Greek Orthodox, Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 18.8 million; 32% agriculture, 25% aaaUsiey,
43% other non-agricultural (1977)','9e5d2c6e98595e2e4531e04444a9cf42f00090dc890dd8f080372a0258f945ed','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b42ba3d932c2f335d6211b374b5667e4f3f891b9ade97d8c57f0baf7ba60f59b',1972,'PT','Portugal','people-and-society',372,'Population: metropolitan Portugal (including the Azores
and Madeira Islands), 9,833,000 (January 1979), average
annual growth rate 0.7% (current)
Nationality: noun—Portuguese (sing. & pl.); adjective—
Portuguese
Ethnic divisions: homogeneous Mediterranean stock in
mainland, Azores, Madeira Islands; citizens of black African
descent who immigrated to mainland during decolonization
‘number less than 100,000
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Religion: 97% Roman Catholic, 1% Protestant sects, 2%
other
Language: Portuguese
Literacy: 70%
Labor force: (1976) 3.2 million; 27% agriculture, 36%
industry, 37% services; unemployment—now more than
14%—is largely due to influx of refugees from former
colonies, returning migrant workers, and military cutbacks
Organized labor: the Communist-dominated General
Confederation of Portuguese Workers—National Intersindi-
cal (CJTP-IN) claims to represent 85% of the labor force; the
Socialists and Social Democrats have Jost ground over the last
year despite efforts to improve their standing with organized
labor','17246c5bf59dcd0dd16f345dcd63da30f9fee568c3614dc85b3141ef3e14949e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b9d38cbb2a12527be89e77b29867c9e427861efe27576b0291381efe15e768c',1972,'QA','Qatar','people-and-society',376,'Population: 165,000 (January 1979), average annual
growth rate 3.2% (current)
170','88b6401ee0e5960d4c5fa414f3031e8563c78979c68bcdd7a4f0d2c9b727f9c9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fa57045716037fbab0a7ab96623e4e216ea5ca466bb884fd4cbd1108dde00e8',1972,'RW','Rwanda','people-and-society',378,'Population: 4,508,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun Rwandan(s); adjective—Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili
used in commercial centers
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','02fa453d5ee27f1742f677f7adb3658553d83a26d75c70dfb06ccada2eff8e70','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e49fa27102d0095565b1b07c905abb3bac7510dfd563a92c9e13534a36e1a5b5',1972,'AI','Anguilla','people-and-society',382,'Population: 57,000 (January 1979), average annual
growth rate 1.1% (7-76 to 7-77)
Ethnic divisions: mainly of African Negro descent
Nationality: noun—Kittsian(s), Nevisian(s), Anguillan(s);
adjective—Kittsian, Nevisian, Anguillan
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor: 6,700
Population: 120,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun—St. Lucian(s); adjective—St. Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about. 80%
Labor force: 38,000 (1969); 50% agriculture; 30%-35%
unemployment (1975)
Organized labor: 20% of labor force
Population: 112,000 (January 1979), average annual
growth rate 1.8% (4-60 to 1-76)
Nationality: noun—St. Vincentian(s) or Vincentian(s);
adjectives—St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian and
Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60% unemployed
Organized labor: 10% of. labor force','ee5f5ea3f4298fb05242ef1251c106afcc41dc5621d6d5f74aff4ad6b53e7c1b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40e9b5ee8d3bd6a756589f979d82c700c91abf84fa641870ef6a9df4d8a78e96',1972,'SM','San Marino','people-and-society',386,'Population: 21,000 (official estimate for 30 June 1977)
Nationality: noun—Sanmarinese (sing. & pl.); adjective—
Sanmarinese
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Mediterranean Sea
(See reference mop IV)
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Communist-dominated Camera del Lavoro,
about 1,000 members a','5b6861c622367bdccfe9d25985a89743d414b1e691be899db94ee2221b3cf6c6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd46a7c119cb7522685aae9191d0d98943b893b334bf8f5f192071c380429007',1972,'SC','Seychelles','people-and-society',390,'Population: 64,000 (January 1979), average annual
growth rate 2.4% (7-72 to 7-77) =,
Nationality: noun—Seychellois (sing. & pl.); adjective—
Seychelles :
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans) ,
Religion: 90% Roman Catholic
. Language: English official; Creole most widely spoken
Literacy: limited; 90% of school-age population is
attending school
Labor force: 15,000 in monetized sector (excluding self-
employed, domestic servants, and workers on small farms);
83% public sector employment, 20% private sector employ-
ment in agricuture, 20% private sector employment in
construction and catering services
Organized labor: 3 major trade unions','b5f1ffc788ac1dcb2ad8a96b26f429bff5ca68e8a9a11d965d7e024fc5d0dc3f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a04ca4a6ca53a367a55646ed40ec0e120466514619f202a1631f3b838100ba7d',1972,'SL','Sierra Leone','people-and-society',394,'Population: 3,293,000 (January 1979), average annual
growth rate 2.3% (12-74 to 7-76)
Nationality: -.noun—Sierra Leonean, adjective—Sierra
Leonean
Ethnic divisions: over 99% native African, rest European
and Asian; 13. tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to
literate minority; principal vernaculars are Mende in south
and Temne in north; “Krio,” the language of the resettled
ex-slave population of the Freetown area, is used as a lingua
franca
Literacy: about 10%
Labor force: about 1.5 million; most of population
engages in subsistence agriculture; only small minority, some
70,000, earn wages
Organized labor: 35% of wage earners','3d71d9407c3587fc790d1ec017c05f708d344c31fb58e03aa4b6242d2a7f81e3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36a488cd8988d212fa3ba2d410a2c51ecc709eb763aad0066b4539885922a883',1972,'SG','Singapore','people-and-society',397,'Population: 2,354,000 (January 1979), average annual
growth rate 1.8% (7-76 to 7-77) a
Nationality: noun—Singaporean(s), adjective—Singapore
Ethnic divisions: 76.2%. Chinese, 15% Malay, 7% Indians
and Pakistani, 1.8% other _
Religion: majority of Chinese are Buddhists or atheists;
Malays nearly all Muslim; minorities include Christians,
Hindus, Sikhs, Taoists, Confucianists ;
Language: national language is Malay; Chinese, Malay,
Tamil, and English are official languages’
Literacy: 70% (1970)
Labor force: 919,000; 2.2% agriculture, forestry, and
fishing, 0.2% mining and quarrying, 27.2% manufacturing,
30.5% services, 4.6% construction, 23.5% commerce, 11.7%
transport, storage, and communications
Organized labor: 24% of labor force','c918e3221ce116e1ee6b6bf0a4bb31cdac16f1dee0d3974c9b4be3fbde83a192','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e73c86deb5fe089e2323ac0fad28dfb1c700f855a20929a8bf3d6ec9ad39a12',1972,'SB','Solomon Islands','people-and-society',400,'Population: 215,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Solomon Islander(s); adjective—Solo-
mon Islander
Nn
Ethnic divisions: 93.0% Melariesians, 4.0% Polynesians,
1.5% Micronesians, 0.3% Chinese, 0.8% Europeans, 0.4%
others
Religion: almost all at least nominally Christian; Roman
Catholic, Anglican, and Methodist churches dominant
Literacy: 60% ‘','848fa29fb22107a9a8400ab4f03ee7ae103a7cc3cbe47125a1f080f0953132ce','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18ef81995e7907cab844313985d12148f150a044be32d39a3e5e0700b7220c12',1972,'SO','Somalia','people-and-society',404,'Population: 3,428,000 (January 1979), average annual
srowth rate 2.4% (current)
Nationality: noun—Somali(s); adjective—Somali ;
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000
Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form instituted by government
in 1976); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled
laborers; 70% pastoral nomads, 30% agriculturists, govern-
ment employees, traders, fishermen, handicraftsmen, other
Organized labor: General Federation of Somali Trade
Unions, a government-controlled organization, established in
1977 :','cd785174ec3705fa45d09b58d7b4e806b6bffc9b81bc1d2a73a873ec2014f744','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ae742521dde0011e7959fa7198cf657c7a9596fefb25500e3569b60bf46bd23',1972,'LK','Sri Lanka','people-and-society',412,'Population: 14,393,000 (July 1978), average annual
growth rate 1.5% (current)
Nationality: noun—Sri Lankan(s); adjective—Sri Lankan
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor,
2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6%
Muslim, 1% other , :
Language: Sinhala official, spoken by about 70% of
population; Tamil] spoken by about 22%; English commonly
used in government and spoken by about 10% of the
population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed
persons—53.4% agriculture, 14.8% mining and manufactur-
ing, 12.4% trade and transport, 19.4% services and other;
.extensive underemployment
Organized labor: 43% of labor force, over 50% of which
employed on tea, rubber, and coconut estates
193
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
SRI LANKA/SUDAN','222425cd12a782d708c75bab14000c5342a01a134cd68437290a522ef6b1c7b0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ac168608743dd50b7b2ae0bd175a622c64445fb43142f73f6bc6257367e1383',1972,'SD','Sudan','people-and-society',416,'Population: 17,912,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Sudanese (sing. and pl.); adjective—
Sudanese
Ethnic divisions: 89% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other a
Religion: 73% Sunni Muslims in north, 23% pagan, 4%
Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects
of Nilotic, Nilo-Hamitic, and Sudanic languages, English;
program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry,
commerce, services, etc.; labor shortages exist for almost all:
categories of employment','e935d061a7be8165292b085571ee81e844060f6f54fc0fd46cf5279982238133','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7725f61b8de04464cddbec8240cbfc2bda8961c944124f1a07f45e9de37f659',1972,'SE','Sweden','people-and-society',420,'Population: 8,285,000 (January 1979), average annual.
growth rate 0.2% (current) ;
Nationality: noun—Swede(s); adjective—Swedish
Ethnic divisions: homogeneous white population; small
Lappish minority ,
Religion: 92% Evangelical Lutheran, 7% other Protestant,
Roman Catholic, Eastern Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking
minorities —
Literacy: 99%
Labor force: 4.2 million; 6.4% agriculture, forestry,
fishing; 29.2% mining. and manufacturing; 7.2% construc-
tion; 13.6% commerce; 6.5% transportation and communica-
tions; 29.8% services including government; 5% banking;
75,000 or 1.8% unemployed (average annual 1977)
Organized labor: 80% of labor force
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Re eg I RN gg gy A=
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','f511cbe827cd46c35fb25d9cd3f2dfa51de66a12c934985e21f855f1ef9bd277','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74d8ee0acd5e3e3403d488792758265fe44deac46977c4c11c8678509afe88f6',1972,'CH','Switzerland','people-and-society',424,'Population: 6,286,000 (January 1979), average annual
growth rate —0.1% (1-77 to 1-78)
Nationality: noun—Swiss (sing. & pl.); adjective—Swiss
Ethnic divisions: total population—69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals—74% German, 20% French, 4% Italian, 1%
Romansch, 1% other :
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals—74% German, 20% French,
4% Italian, 1% Romansch, 1% other; total population—69%
German; 19% French, 10% Italian, 1% Romansch, 1% other
Literacy: 98%
Labor force: 2.6 million, about one-tenth foreign workers,
mostly Italian; 16% agriculture and forestry, 47% industry
and crafts, 20% trade and transportation, 5% professions, 2%
in public service, 10% domestic and other; approximately
0.3% unemployed in July 1978
Organized labor: 20% of labor force
Population: 8,260,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Syrian(s); adjective—Syrian
Ethnie divisions: 90.3% Arab; 9.7% Kurds, Armenians,
and other
Religion: 70.5% Sunni Muslim, 16.3% Alawites, Druze,
and other Muslim sects, 13.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 1.8 million; 32% agriculture, 26% industry
(including construction), 42% miscellaneous services; major-
ity unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 17,098,000 (January 1979), average annual
growth rate 3.0% (current) —
Nationality: noun—Tanzanian(s); adjective—Tanzanian
Ethnic divisions: 99% native Africans consisting of . well
_ over 100 tribes; 1% Asian, European, and Arab
Religion: Mainland—40% Animist, 30% Christian, 30%
Muslim; Zanzibar—almost all Muslim
Language: Swahili and English official, English primary
language of commerce, administration and higher education;
Swahili widely understood and generally used for communi-
cation between ethnic groups; first language of most people
is one of the local languages
Literacy: 61%
Labor force: under 400,000 in paid employment, over
90% in agriculture
Organized labor: 15% of: labor force','5781503e49edd4ff1560601f1d4086e58a3a13b8d7f45adee2330c3cbeae4ed5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d29b01151982e1f52bc8db3150a7513d9edcf49e9074fb477d45b8e07f1b17c8',1972,'TH','Thailand','people-and-society',428,'Population: 46,443,000 (January 1979), average annual
growth rate 2.6% (current)
204
Nationality: noun—Thai (sing. & pl.); adjective—Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 78% agriculture, 15% services, 7% industry
Population: 51,883,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Vietnamese (sing. & pl.); adjective—
Vietnamese
Ethnic divisions: 85%-90% predominantly Vietnamese;
3% Chinese; ethnic minorities include Muong, Thai, Meo,
Khmer, Man, Cham, and mountain ttibesman
Religion: Buddhism, Confucianism, Taoism, Catholicism,
Animism, Islam, and Protestantism
Language: Vietnamese, French, Chinese, English, Khmer,
tribal languages (Mon-Khmer and Malayo-Polynesian)
Labor force: approximately 15 million, not including
military; about 70% agriculture and 8% industry','39e8cddf032daedd331405c676b7993043b1129030be5c32f303f2e07047b493','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f06ee1bea1a77813895ec91ee9af3e1ea0ae8cd59c9095ef01458c58f944967',1972,'TG','Togo','people-and-society',432,'Population: 2,493,000 (January 1979), average annual
growth rate 2.8% (current) ;
Nationality: noun—Togolese (sing. & pl.); adijective—
Togolese
Ethnic divisions: 37 tribes; largest and most important are
Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of com-
merce; major African languages are Ewe and Mina in the
south and Dagomba and Kabie in the north
Literacy: 54.9% of school age (7-14) currently in school
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage earners, evenly
divided between public and private sectors
Organized labor: 1 national union, the CNTT organized
in 1972','68d8cae9e52d65560f9acb717a5a80fe9574112ee6cbce1869fe76f101777a71','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71870b5a636f165c2ea548b4804fba96ae5b445889a349bc182e4350debe3b5a',1972,'TO','Tonga','people-and-society',436,'Population: 91,000 (January 1979), average annual
growth rate 0.8% (current)
Nationality: noun—Tongan(s); adjective—Tongan
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free: Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children
between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: ‘unorganized','2700249dcfefd34ecd5f17cf484a2d2dab23324d268229b98b56524cd85acfcd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebe97a4a1dbad2c345a83ca4465590fc963d2fa970b16d7748a00d25851c1e22',1972,'TT','Trinidad and Tobago','people-and-society',440,'Population: 1,129,000 (January 1979), average annual
growth rate 1.1% (7-70 to 7-76).
Nationality: noun—Trinidadian(s), Tobagonian(s); adjec-
tive—Trinidadian
Ethnic divisions: 43% Negro, 40% East Indian, 14%
mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23.0%
Hindu, 6.0% Muslim, 13.0% unknown
Language: English
Literacy: 95%
Labor force: 393,800 (July 1975), 13.5% agriculture,
20.0% mining, quarrying, and manufacturing, 17.4% com-
merce; 15.7% construction and utilities; 7.5% transportation
and communications; 23.0% services, 2.9% other
Organized labor: 30% of labor force','3102506b42cd032246e3b96ebcb74a5cc9b967a920a9d78c57369bbb56df351d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b366c9a9f5fc305f428ffe1f59568f6e0bd5f9cd9f114239929cd25515dc0b2',1972,'TN','Tunisia','people-and-society',444,'Population: 6,327,000 (January 1979), average annual
growth rate 2.7% (current)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
A RA RA AA A AS any, Waa eae ee, a
RR an oe ek ne ee RR A
AD AR A aA mA AA A ne!
TSR A AM RA A AL
a a a. a Or ae as
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
(See reference map Vi}
Nationality: noun—Tunisian(s); adjective—Tunisian
Ethnic divisions: 98% Arab, 1% European, less than 1%
Jewish
Religion: 95% Muslim, 4% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
Literacy: about 32%
Labor force: 1.4 million; 45% agriculture, 19% manufac-
turing and construction, 5% trade and finance, 3%
transportation, communications, and utilities, 2% mining;
10%-20% unemployed; shortage of skilled labor
Organized labor: 25% of labor force; General Union of
‘Tunisian Workers (UGTT), quasi-independent of Destourian
Socialist Party','d66d82b29b3c35da39ece40020d43b03b48770d34abf83131189e54c7a2e2d7d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83f69a94043e4a95702fff4250fcb7cba5f7774b37f77fb50254dbd3986bb12d',1972,'DE','Germany','people-and-society',447,'Population: 43,767,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 8% . other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55% ; :
Labor force: 16.4 million; 61% agriculture, 13% industry,
25% service; substantial shortage of skilled labor; ample
unskilled labor (1978)
Organized labor: 12% of labor force','936938c7b9d196bb13c61174976ca6d23e6b99eba080a91d8718244c9cee8882','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49a5cb55c3ce0e33c4fa48aaae2dabc89befaf0e5932869e2916ec4e50f4a5ba',1972,'UG','Uganda','people-and-society',451,'Population: 13,002,000 (January 1979), average annual
growth rate 3.5% (current)
Nationality: noun—Ugandan(s); Aieiive ganda
Ethnic divisions: 99% African, 1%.Européan, Asian, Arab
Religion: about 60% nominally Christian, 5%-10% Mus-
lim, rest animist ,
Language: English official; Luganda and Swahili widely
used; other Bantu and Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which about
250,000 in paid labor, remaining in subsistence activities
Organized labor: 125,000 union members
Population: 262,586,000 (January 1979), average annual
growth rate’ 0.9% (current) -
Nationality: noun—Soviet(s); adjective—Soviet
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic
groups,
Religion: 70% atheist, 18% Russian Orthodox, 9% Musi,
3% other
Language: more ‘had 200 languages and dialects (at least
18 with more than 1 million speakers); 76% Slavic group, 8%
othe: Indo-European, 11% Altaic, 3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 138 million (mid-year 1978), 25%
agriculture, 75% industry and other non-agricultural fields,
unemployed not reported, shortage of skilled labor reported','8c29a2f4948db36dca161ff3408063593c5948539fbf186afcb570bf1e976960','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2478545899e5fff4b93ea638c6642dbc9d16a197fd938330ffa8e9b418c508e1',1972,'AE','United Arab Emirates','people-and-society',455,'Population: 656,000 (preliminary total from the census of
29 August 1975) .
Ethnic divisions: Arabs 42%, South Asians 50% (fluctuat-
ing), other expatriates (includes Westerners and East Asians)
8%
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 25% est. (1975)
Labor force: 203,000 (1975 est.); 85% in industry; 2%
U.A.E. Arabs, 7% non-U.A.E. Arabs, 91% Indians, Pakistanis,
Iranians','d38f5aeeffe3cddec61bbad4f587fdf88d1e3c0992022e61449650695df5b2fb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56c951c14d1719bbb0ecc19502b0d8bd7456e0fc1a1785be8ec5db39d64413ad',1972,'GB','United Kingdom','people-and-society',459,'Population: 55,846,000 (January 1979) average annual
growth rate —0.1% (current)
Nationality: noun—Briton(s),
adjective—British
Ethnic divisions: 88% English, 9% Scottish, 5% Welsh, 3%
Irish :
Religion: 27.0 million Church of England, 5.3 million
Roman Catholic, 2.0 million Presbyterians, 760,000 Method-
ist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of population of
Wales), Scottish form of Gaelic (about 60,000 in Scotland)
Literacy: 98% to 99%
Labor force: (1974) 25.6 million; 1.6% agriculture, 1.4%
mining, 30.7% manufacturing, 6.2% government, 7.2%
transportation and utilities, 5.2% construction, 10.6% dis-
tributive trades, 25.3% all services, 9.7% other; 2.1%
unemployed :
Organized labor: 40% of labor force
Population: 6,582,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Upper Voltan(s); adjective—Upper
‘Voltan
Ethnic divisions: more than 50 tribes; principal tribe is
Mossi (about 2.5 million); other important groups are
Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to
Sudanic family, spoken .by 50% of the population
Literacy: 5%-10% a .
Labor force: about 95% of the - economically active
population engaged in animal husbandry, subsistence farm-
ing, and related agricultural pursuits; about 30,000 are wage
earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 4 principal trade union . groups','ecdfd3dfe54ae20636a18be8b59fae8cf2d3441d87a38953873b7c61c859af76','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('300a4b425166e581c8932360482ac4e350d269b7d96bc8e5988f9f76fbaacb58',1972,'WF','Wallis and Futuna','people-and-society',463,'Population: 9,000 (official estimate for 1 July 1973)
Nationality: noun—Wallisian(s), Futunan(s), or Wallis
and Futuna Islander; adjective—Wallisian, Futunan, or
Wallis and Futuna Islanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','eee2ded006719b315e3ecd4d0f9059021c8b24cfd43bd59d59294889fe8428ed','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78e2552cb005695d278eb025a636fb3c16640aa4f9e44b4a2629fe52db6e2525',1972,'ZM','Zambia','people-and-society',467,'Population: 5,559,000 (January 1979), average annual
growth rate 3.2% (7-76 to 7-77)
Nationality: noun—Zambian(s); adjective—Zambian
Ethnic divisions: 98.7% African, 1.1% European, 0.2%
other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans,
27,000 non-Africans; 15% mining, 9% agriculture, 9%
230
domestic service, 19% construction, 9% commerce, 10%
manufacturing, 23% government and miscellaneous services,
6% transport
Organized labor: 100,000 wage earners, primarily in
industrial sector, are unionized (early 1968)','7a1c39b19c9f11adb5da0ef73ac3e2bf8fe4b929342f332dca1287f938b9436e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e780c5a41d8f73c02589f025179b6d6566743a20a00ddf78ee932629feb500e6',1972,'US','United States','people-and-society',471,'Population: 219,334,000 (January 1979), average annual
growth rate 0.8% (current)
ZAMBIA/UNITED STATES
Ethnic divisions: 86.5% white, 11.7% black, 1.9% other
Religion: total membership in religious bodies,
129,714,000; Protestant 69,743,000, Roman Catholic
48,882,000, Jewish 6,115,000, other religions 4,973,000 -
(1975) ; : ,
Language: English, predominantly
Literacy: almost complete
Labor force: 96.9 million, unemployment 7.7% (1976)
Organized labor: 20.1% of total (1976 prelim.)','bb7ecf2dd4d3fd7ff27200269fb07b510ad077184d25aba2708254951aaccc8f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

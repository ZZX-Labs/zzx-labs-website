SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e566b8b88d093e7f7265d5bcb1cf96dc95786e62cacf38c0de688dff1776dbad',1972,'','','economy',4,'GNP: $12,016 million (1971), about $330 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electrtc power: 2.6 million kw, capacity (1971); 9,724 million kw.-hr. produced
(1971), 267 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 192, U.S. 102, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $1,602 million assistance disbursed 1963-69 by the Aid of Turkey Consortium
consisting of the U.S., 13 additiona) OECD member countries, the IMF, IBRD,
and European Fund of the EMA; $390.5 million extended by Communist countries
1955-December 1971; none extended in 1971; total U.S. economic, $2,727.9
million (July 1946-Ju : total U.S. military $3,250.2 million
(July 1946-June 1971)
Monetary conversion rate: urkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','1de57ea31cf866407b6e812547f4485a4e5342ee730fa5f2945b98c2595fcb1c','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee135ba0e1096d1a1d1478e4da018f6265dd41e8bd24eee13c5bd1b89bc9a667',1972,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $390.5 million extended by Communist countries 1955-December 1971; none
extended in 1971; total U.S. economic, $2,727.9 million (1946-71); total
U.S. military $3,250.2 million (July 1946-June 1971); $603 million in aid
commitments from international tes (1946-71); $657 million in bilateral
aid from other sources 1960-70
Monetary conversion rate: 14 Turkish liras=US$1 (official rate)
Fiscal year: 1 March - 28 February','4c5921c18d539de60f8b6e157cd7b171fa7672f2c9502dc3d789c30404de55ea','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43db54240de317e7ea9c22cbb0f9331ac573a1ace544856448109ee2134690ce',1972,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971 :
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.o.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
Mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Monetary conversion rate: 14 Turkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','a893c8676599b7e8f9599afa88721528d836b28df6ec5629e7a51b3407d7a703','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76800a12d9d8d6eb1dd754c94d2d45d24337104a89832d7505a91bf10af1b184',1972,'AF','Afghanistan','economy',4,'GNP: $1.0 billion (FY71), well below $100 per capita; real growth rate probably
near zero in 1970-71
Agriculture: agriculture and animal husbandry account for over 50% of GNP and
occupy nearly 90% of the labor force; main crops -- wheat, cotton, fruits,
nuts; largely self-sufficient; food shortages -- wheat, sugar, tea
Major industries: cottage industries, food processing, textiles, cement, coal
mining
Electric power: 275,000 kw. capacity (1971); 450 million kw.-hr. produced
(1971), 25 kw.-hr. per capita
Exports: $83.7 million (f.o.b., 1970-71); fruits and nuts, karakul, natural gas,
carpets and rugs, wool, cotton
Imports: $117.4 million (c.i.f., 1970-71); wheat, textiles, sugar, tea, petroleum,
transportation equipment
Major trade partners: exports -- U.S., U.K., U.S.S.R., and India; imports --
about one-third from U.S.S.R.
Monetary conversion rate: 45 Afghanis per US$1 (official); 78.25 Afghanis per
US$1 (January 1972)
Fiscal year: 2] March - 20 March','511556e225d6b94db520ee18304abcd3bbd9a8a6d5fe17bdbe3e951e1befaefe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfd922ed0b1cadf139ea912f4aaeeefc02b87c472ecca263a433e13f3f3c9d72',1972,'AL','Albania','economy',9,'GNP: $0.84 billion in 1970 (at 1970 prices), $390 per capita
Agriculture: food deficit area; main crops -- corn, wheat, tobacco, sugar beets,
cotton; food shortages -- wheat; caloric intake, 2,100 calories per day per
capita (1961/62)
Major industries: agricultural processing, textiles and clothing, lumber, and
extractive industries
Shortages: spare parts, machinery and equipment, wheat
Exports: $80 million (1969 est.); 1964 trade -- 55% minerals, metals, fuels;
17% agricultural materials (except foods); 23% foodstuffs (including
cigarettes); 5% consumer goods
3
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Imports: $143 million (1969 est.}; 1964 trade -- 50% machinery, equipment, and
spare parts; 16% minerals, metals, fuels, construction materials; 7%
fertilizers, other chemicals, rubber; 4% agricultural materials (except
foodstuffs}; 16% foodstuffs; 7% consumer goods
Monetary conversion rate: 5 leks=US$1 (commercial); 12.5 Teks=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year
1 duly - 30 June','785719b28f6467e1681e52fbc6e161810f778d861ef90d9e4cf1472499dd163e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36eb48ea86465f8781003b2b15b6d90f6650e9b4880cc7e2cb3043f2ae6589f9',1972,'DZ','Algeria','economy',13,'GNP: $5.0 billion (est. 1971), $350 per capita; real average annual increase
Since 1968, 8%
Agriculture: main crops -- wheat, barley, wine, citrus fruits
Major industries: petroleum, light industries, natural gas, mining, petrochemical
and steel plants under construction
Electric power: 1,100,000 kw. capacity (1971); 1.8 billion kw.-hr. produced
(1971), 125 kw.-hr. per capita
5
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $996 million (f.o.b., 1970); crude petroleum 66%, other items -- wine,
citrus fruit, iron ore, vegetables; 54% of exports to France (1970)
Imports: $1,241 million (c.i.f., 1970); major items -- capital goods, foodstuffs,
textiles; 42% from France (1970)
Monetary conversion rate: 4.547 dinars=US$1
Fiscal year: calendar year
GNP: $177.9 billion (1971 est.), $3,470 per capita; 60% consumption, 28% investment
(including government), 11% government consumption; 1% net foreign balance;
1971 estimated growth rate 5.7%, 1963 constant prices
Agriculture: Western Europe''s foremost producer; main crops -- cereals, sugar
beets, potatoes, wine grapes; self-sufficient for most temperate zone food-
stuffs; food shortages -- fats and oils, tropical produce; caloric intake,
3,270 calories per day per capita (1969-70) i
Fishing: catch 746,300 metric tons, $227 ,449,000 (1969); exports $27,158,000
(1969), imports $165,963,000 (1969) ‘
Major industries: steel, machinery and equipment, textiles and clothing,
chemicals, food processing, metallurgy .
Shortages: crude oil, textile fibers, most nonferrous ores, coking coal, fats
and oils
Crude steel: 22.9 million metric tons produced (1971 est.), 450 kilograms per
capita (1971 est.)
Electric power: 36,500,000 kw. capacity (1970); 140.7 billion kw.-hr. produced
(1970), 2,600 kw.-hr. per capita
Exports: $22.5 billion (f.0.b., 1971); principal items -- textiles and clothing,
iron and steel products, machinery and transportation equipment, foodstuffs
and agricultural products, alcoholic beverages
Imports : $23.1 billion (c.i.f., 1971}; principal items -- machinery and
equipment, crude petroleum, iron and steel products, textile fibers, coal
and coke, foodstuffs, alcoholic beverages
Major trade partners: (1970) EC 49%; West Germany 21%; Belgium-Luxembourg 11%;
Italy 10%; Netherlands 6%; EFTA 13%; U.S. 8%; Eastern Europe 2%; U.S.S.R. 1%;
franc zone 10%
Aid:
economic (received) -- U.S., $5,215.4 million authorized (FY46-70), 58.5
million in FY70;
military -- U.S., $4,259 million authorized (FY46-70); net official economic
aid to less developed areas and multilateral agencies -- $7,431 million
(FY60-70), $951.7 million (FY70)
Monetary conversion rate: 5.1157 francs=US$1 (central rate)
Fiscal year: calendar year
Economic activity in Gibraltar centers on commerce and large British naval and
air bases. Nearly all trade in the well-developed port is transit trade and
port serves also as important supply depot for fuel, water, and ships'' wares.
Recently built dockyards and machine shops provide maintenance and repair
services to 3,500-4,000 vessels that call at Gibraltar each year.
U.K. military establishments and civil government employ nearly half the insured
labor force. Local industry is confined to manufacture of tobacco, roasted
coffee, ice, mineral waters, candy, and canned fish. Some factories for
manufacture of clothing are being developed. A small segment of local
population makes its livelihood by fishing. In recent years tourism has
increased in importance.
123
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Electric power: 29,170 kw. capacity (1970); 47 million kw.-hr. produced (1970),
1,500 kw.-hr. per capita
Exports: $4.0 million (f.o.b., 1968); principally reexports of tobacco,
petroleum, and wine
Imports: $19.8 million (1967)
Major trade partners: U.K., France, Spain, Netherlands, Italy, West Germany
Monetary conversion rate: 1 Gibraltar pound=US$2.40
GNP: $34.0 billion; $1,010 per capita (1971); 68.5% consumption, 24.3% investment,
10.4% government; -3.2% net export of goods and services (1969); 1971 (est.)
real growth rate 5.5%, in 1964 constant prices
Agriculture: main crops -- cereals, oranges, grapes for wine, potatoes, olives,
sugar beets; virtually self-sufficient in good crop years; caloric intake,
2,680 (1968-69) calories per day per capita
Fishing: catch 1.2 million tons, $326.8 million (1969); exports $67.2 million
(1969 fish and fish products); imports $41.1 million (1969 fish and fish
products)
Major industries: food processing, textiles and apparel (including footwear),
metal manufacturing, chemicals, shipbuilding
Shortages: crude petroleum
Crude steel: 7.4 million metric tons produced, 220 kilograms per capita (1970
Electric power: 17,906,000 kw. capacity (1970); 56,397 million kw.-hr. produced
(1970), 1,400 kw.-hr. per capita
Exports: $3,050 million (f.o.b., 1971); principal items -- oranges and other
fruits, iron and steel products, textiles, wines, mercury, ships, canned
fruits, vegetables
Imports: $4,600 million (f.o.b., 1971); principal items -- machinery and
transportation equipment, petroleum and petroleum products, grains, cotton,
iron and steel
Major trade partners: (1971) 16.0% U.S., 12.0% West Germany, 10.4% France,
8.4% U.K., 6.0% Italy, 3.5% Netherlands; 34.0% EC; 15.8% EFTA; 8.7% Latin
America; 1.5% Eastern European countries and U.S.S.R.
Aid:
economic -- U.S., $1,647.2 million authorized (FY49-70), $50.5 million
authorized (FY69), $64 million authorized (FY70}; IBRD, $224 million
authorized (FY64-70), $37 million authorized (FY70);
military -- U.S., $771.4 million authorized (FY53-70), $130.9 million
authorized in FY70
Monetary conversion rate: 64.47 pesetas=US$1 (1971)
Fiscal year: calendar year
Agriculture: practically none; some barley is grown in nondrought years; fruit
and vegetables in the few oases; food imports are essential; camels, sheep,
and goats are kept by the nomadic natives; cash economy exists largely for
the garrison forces
Major industries: confined to fishing and handicrafts; exploitation of huge
phosphate deposit is planned
Shortages: water
Electric power: 300 kw. capacity (1971); 0.2 million kw.-hr. produced (1971),
3 kw.-hr. per capita
Exports: $445,600 (1968); dried fish, goatskins
Imports: $1,443,000 (1968); fuel for fishing fleet, foodstuffs
Major trade partners: monetary trade largely with Spain and Spanish possessions
Aid: small amounts from Spain
Monetary conversion rate: 64.47 pesetas=US$1 (official)
GNP: $2.12 billion (1970 current prices), $165 per capita; real growth rate 4.1%
(1970)
Agriculture: agriculture accounts for about 35% of GNP; main crops -- rice,
rubber, tea, coconuts; 60% self-sufficient in food; food shortages -- rice,
wheat, sugar, fish
Fishing: catch 140,000 tons (1970), $64 million; exports $0.4 million, imports
$11.7 million
Major industries: processing of rubber, tea, and other agricultural commodities;
consumer goods manufacture
Electric power: 323,000 kw. capacity (1971); 880 million kw.-hr. produced
(1971), 69 kw.-hr. per capita
Exports: $342 million (f.o.b., 1970); tea, rubber, coconut products
Imports: $398 million (c.i.f., 1970)
Major trade partners: (1969) exports -- U.K. 20.2%, China 12.8%, U.S. 8.0%,
Australia 4.2%, South Africa 4.5%, U.S.S.R. 4.8%, West Germany 4.1%, Canada
2.6%; imports -- U.K. 17.4%, China 11.1%, India 8.3%, Australia 4.5%,
U.S.S.R. 2.0%, U.S. 8.4%, Japan 7.4%, Burma 1.2%
Monetary conversion rate: 5.95 rupees=US$1
Fiscal year: 1] October - 30 September','d308728a8684be58c419fc5dde44e4ef8253c4e1973fd2b072c9eaa6c9e3330d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40ab8446c5e25b4e788a46aa474bc0e9ceeef2316c718ce2f8d5c0eef08daa0c',1972,'AD','Andorra','economy',17,'Agriculture: sheep raising; small quantities of tobacco, rye, wheat, barley,
oats, and some vegetables (only 25% of land can be used for agriculture)
Major industries: tourism ($1 million annually), one cigarette factory (annual
output $1 million), handicrafts, smuggling (tobacco to France; manufactured
items, including automobiles and cameras, to Spain)
Shortages: food
Electric power: 25,000 kw. capacity (1970); 100 million kw.-hr. produced (1970),
400 kw.-hr. per capita; power is mainly exported to Spain and France
Major trade partners: Spain, France','4be493daf7d2262743cabe372ccf43a21acde814ae33a271694a239998df415b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74bc86a03913bfc8afe20c5c5ba99dfa226d30a793f114bda6092a6f4a7cab3b',1972,'AO','Angola','economy',21,'GNP: $1.2 billion (1970 est.), about $220 per capita
Agriculture: cash crops -- coffee, sisal, corn, cotton, sugar, manioc, and
tobacco; food crops -- cassava, corn, vegetables, plantains, bananas, and
other local foodstuffs; largely self-sufficient in food
Fishing: catch 378,000 metric tons (1970); exports 73,000 tons, $11 million (1968)
Major industries: mining (iron, of], diamonds), fish processing, brewing, tobacco,
sugar processing, cement, food processing plants, building construction
Electric power: 433,000 kw. capacity (1971); 694 million kw.-hr. produced
(1971), 125 kw.-hr. per capita
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $422.6 million (f.0.b., 1970); coffee (50%), diamonds, sisal, fish and
fish products, iron ore, oi], timber, and corn
Imports: $368 million (c.i.f., 1970); capital equipment (machinery and electrical
equipment), wines, bulk iron and ironwork, steel and metals, vehicles and
Spare parts, textiles and clothing, medicines
Major trade partners: main partner Portugal, followed by West Germany, U.S.,
U.K., EC countries (primarily coffee to last three)
Aid: Portugal only donor
Monetary conversion rate: 27.25 escudos=US$1 (approximate realigned rate)
Fiscal year: calendar year','5e3abab8668917cd8abd9da8f2f0b7443cfa1b272a3fb8dead5c75ee1a4fe025','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75942c5b7d9a0a0924ca1fd7f643d02865288ccc962ccba644c1b3c672214b7e',1972,'BR','Brazil','economy',25,'GDP: $27.2 million (at factor cost, 1967 est.), $470 per capita
Agriculture: main crops -- sugar, cotton
Major industries: sugar processing, tourism
Shortages: electric power
Electric power: 14,040 kw. nameplate capacity (1970); less than 4,000 kw. operating;
12 million kw.-hr. produced (1969 est.), 189 kw.-hr. per capita
Exports: $2.9 million (f.o.b., 1967); sugar, molasses, cotton
Imports: $22.2 million (c.i.f., 1967); food, clothing, oi1, wood
Major aa oe U.K. 30%, U.S. 25%, Commonwealth Caribbean countries
18% (1966
Monetary conversion rate: 1.84 East Caribbean dollars=US$1 (6 October 1971)
11
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
GNP: not available
Agriculture: main crops -- fruits, vegetables
Major industries: tourism, cement, oi] refining, lumber, salt production
Electric power: 99,750 kw. capacity (1971); 288.9 million kw.-hr. produced
(1971 est.), 1,560 kw.-hr. per capita (est.)
Exports: $89.6 million (f.0.b., 1970); fuel o11, cement, rum, pulpwood, fruits,
and vegetables
Imports: $337.5 million (c.i.f., 1970); foodstuffs, manufactured goods, crude oil
Major trade partners: exports -- U.S. 61%, U.K. 22%, other 17%; imports -- U.S.
68%, U.K. 9%, Italy 6%, Canada 4%, other 13%
Aid: economic -- authorizations from U.S. (FY56-70) -- $38.6 million in loans,
$0.3 million in grants
Monetary conversion rate: 0.97 Bahamian dollars (B$)=US$1
Fiscal year: calendar year
GDP: $139.5 million (1970), $580 per capita; real growth rate 1970, 6.5% (est.)
Agriculture: main products -- sugar, subsistence foods
Major industries: tourism, sugar milling, manufacturing, edible oils and fats
Electric power: 39,950 kw. capacity (1969, est.); 143.7 million kw.-hr. produced
(1969 est.), 595 kw.-hr. per capita
Exports: $39.8 million (f.0.b., 1970); sugar, molasses, rum
ES $116.3 million (c.i.f., 1970); foodstuffs, lumber, machinery, manufactured
goods
Major trade partners: exports -- U.K. 38%, U.S. 21%, CARIFTA 19%, other 22%;
imports -- U.K. 29%, U.S. 22%, Canada 11%, CARIFTA 11%, other 27%
25
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Aid: economic -- extensions from U.S. (FY67-70), $0.1 million in grants; from
international organizations (FY63-70), $0.7 million
Monetary conversion rate: 1.84 East Caribbean dollars=US$1
Fiscal year: 1 April - 31 March
GNP: $1.4 billion (purchasing power parity estimate, 1971), $290 per capita;
78% private consumption, 11% public consumption, 13% gross domestic
investment, -2% net foreign balance (1970); real growth rate 1971, 3.8%
Agriculture: main crops -- potatoes, corn, rice, sugarcane, yucca, bananas; ;
imports significant quantities of foodstuffs including lard, vegetable oils,
and wheat; caloric intake, 2,100 calories per day per capita (1966)
Major industries: mining, smelting, petroleum refining, food processing, textiles,
and clothing
Electric power: 268,000 kw. capacity (1970); 792 million kw.-hr. produced
(1970), 166 kw.-hr. per capita
Exports: $175.4 million (f.o.b., 1971 est.); tin, petroleum, lead, zinc, silver,
tungsten, antimony, bismuth, gold, coffee, and sugar
Imports: $187.7 million (f.0.b., 1971 est.); foodstuffs, chemicals, capital goods,
pharmaceuticals
Major trade partners: exports -- U.K. 46%, U.S. 39%, West Germany 5%, Argentina 2%;
imports -- U.S, 41%, West Germany 12%, Japan 11%, Argentina 6% (1970)
Aid:
economic -- extensions from U.S. (FY46-70) $1,226.7 million in loans, $298.5
million in grants; from international organizations (FY46-70), $152.9
million; from other Western countries (1960-66), $12.6 million; Communist
countries (1954-71), $55.5 million; military -- assistance from U.S. (FY58-70),
$23.9 million
Monetary conversion rate: 11.88 pesos=US$1 (selling rate)
Fiscal year: calendar year
GNP: $49.5 billion (purchasing power parity estimate, 1971), $520 per capita;
18.5% gross investment, 83% consumption, -1.5% foreign balance (est. 1971);
real growth rate 1971, 11.3%
Agriculture: main products -- coffee, rice, beef, corn, milk, sugarcane, beans;
fae self-sufficient; caloric intake, 2,900 calories per day per capita
pa cae 500,000 metric tons (1968); exports $10.2 million, imports $28.6
million
Major industries: textiles and other consumer goods, cement, Jumber, steel,
motor vehicles, other metalworking industries
Crude steel: 6.5 million metric tons capacity (1971 est.); 6 million metric
tons produced (1971); 60 kilograms per capita (1971)
37
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Electric power: 12.7 million kw. capacity (1971); 52.5 billion kw.-hr. produced
(1971), 525 kw.-hr. per capita
Exports: $2,900 million (f.0.b., 1971); coffee, manufactures, iron ore, cotton,
sugar, wood, cocoa
Imports: $3,225 million (f.o.b., 1971); machinery, chemicals, pharmaceuticals,
petroleum, wheat
Major trade partners: exports -- U.S. 23%, Hest Germany 10%, Italy 7%, Argentina
7%, Netherlands 6%, Japan 5%, U.K. 5%; imports -- U.S. 31%, West Germany 13%,
Argentina 6%, U.K. 5%, Italy 3% (1970)
Aid: economic -- extensions from U.S. (FY46-70) -- loans $3,023.4 million,
grants $599.8 million; from international organizations (FY46-72) $1,651.2
million; from other Western countries (1960-66) -- $343.6 million; from
Communist countries (1954-71) $330.6 million; drawings $124.4 million
Monetary conversion rate: 5.5 cruzeiros=US$1 (February 1972, changes frequently)
Fiscal year: calendar year
GNP: $65.6 million (est. 1970), $540 per capita; 78% private consumption, 17%
public consumption, 36% domestic investment, -31% net foreign balance
(1968); real growth rate 1970 7% (est.)
Agriculture: main products -- citrus fruits, sugar, corn, rice, beans, livestock
products; net importer of food; caloric intake, 2,500 calories per day
per capita
Major industries: timber and forest products, food processing, furniture, rum,
soap
Electric power: 8,030 kw. capacity (1970 est.}; 21.6 million kw.-hr. produced
(1969 est.), 180 kw.-hr. per capita
39
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $19 million (f.0.b., 1970 est.); sugar, lumber, citrus fruits, fish
Imports: $35 million (c.i.f., 1970 est.); vehicles, petroleum, food, textiles,
machinery
Major trade partners: exports -- U.K. 31%, U.S, 29%, Mexico 16%, Canada 15%;
imports -- U.S. 33%, U.K. 29%, Jamaica 7% (1968)
Aid: economic -- extensions from U.S. (FY46-70), $5.5 million, grants; from
international organizations (1946-70), $1.2 million
Monetary conversion rate: $BH1.59=US$1 (official)
Fiscal year: calendar year
GNP: $132 million (estimated 1968), $1,180 per capita
Agriculture: main crops -- rubber, rice, sago
Major industry: crude petroleum
Electric power: 85,000 kw. capacity (1971); 140 million kw.-hr. produced (1971),
1,129 kw.-hr. per capita
Exports: $85 million (f.o.b. 1969); almost all crude petroleum
Imports: $77 million (c.i.f. 1970)
Major trade partners: exports of crude petroleum go to Sarawak for refining
and reexport; 30% imports from U.K., Singapore 16%, Japan 13%
Monetary conversion rate: 2.82 Brunei dollars=US$1
Fiscal year: calendar year
4]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
GNP: $9.4 billion (purchasing power parity estimate, 1970), $1,040 per capita;
76% private consumption, 11% government consumption, 13% gross investment
(1971 est.)3; real growth rate 1971, GDP 8.5%, GNP 9.5%
Agriculture: main crops -- wheat, other cereals, potatoes; about 75% self-
sufficient; 2,600 calories per day per capita (1970 est.)
Fishing: catch 1.04 million metric tons; exports $25.4 million, imports $0.2
million (1970)
Major industries: copper, nitrates, foodstuffs, fish processing, textiles and
apparel, iron and steel, pulp and paper
Crude steel: 0.7 million metric tons capacity (1967); 0.6 million metric tons
produced (1969), 60 kg. per capita
Electric power: 2.6 million kw. capacity (1971 est.); 9 billion kw.-hr.
produced (1971 est.)}, 900 kw.-hr. per capita
Exports: $1,040 million (f.0.b., 1971 est.); copper, iron ore, fishmeal, nitrates,
and jodine
Imports: $1,124 million (c.i.f., 1971 est.); foodstuffs, machinery and equipment,
chemicals
Major trade partners: exports -- EC 42%, U.K. 12%, U.S. 14%, Japan 12%, LAFTA
10%; imports -- U.S. 37%, EC 21%, U.K. 6%, Japan 3%, LAFTA 21% (1970)
Aid:
economic -- extensions from U.S. (FY46-70) -- $1,559.7 million ($1,354.2
million loans, $205.6 million grants); from international organizations
(FY46-70) -- $566.3 million (of which IBRD $232.7 million, IDB $253.9
million); from other Western countries (1960-66) -- $170.6 million; from
Communist countries (1967-71) -- $193.3 million;
military (FY53-70) -- from U.S.. $20.1 million in loans, $123.8 million in
grants
Monetary conversion rate: multiple exchange rate system; range from 12.23 to
25.0 escudos=US$1 trade rate; 28.03 escudos=US$1 nontrade (broker) rate;
varying taxes drive effective rate as high as 43 escudos=US$1 for some
purposes; black market rate is upwards of 65 escudos=US$1 (September 1971)
Fiscal year: calendar year
GNP: $10.4 billion (purchasing power parity estimate, 1970), $480 per capita;
72% private consumption, 7% public consumption, 21% gross investment (1969);
real growth rate 1970, 7.0% .
Agriculture: main crops -- coffee, rice, corn, sugarcane, plantains, bananas,
cotton, potatoes, yucca; caloric intake, 2,220 calories per day per capita :
(1965)
Fishing: catch 70,600 metric tons 1969; exports $2.9 million (1969), imports $5 ,
million (1969) “
Major industries: textiles, food processing, clothing and footwear, beverages,
chemicals, and metal products
Crude steel: 0.4 million metric tons capacity (1965); 0.26 million metric tons
production (1969), 10 kilograms per capita
Electric power: 22 million kw. capacity (1970); 8.8 billion kw.-hr. produced
(1970), 296 kw.-hr. per capita
Exports: $727 million (f.o.b., 1970); coffee, petroleum, bananas, tobacco,
cotton, sugar, textiles, cattle and hides
Imports: $755 million (c.i.f., 1970); industrial metals and raw materials,
transportation equipment, machinery, fuels, fertilizers, paper and paper
products, wheat
Major trade partners: U.S. 44%, West Germany 11%, other EC 9%, EFTA 9% Latin
America 6%, Communist countries 4% (1968)
Monetary conversion rate: 21.0 pesos=US$1 (December 1971, changes frequently)
Fiscal year: calendar year
Agriculture: food crops -- rice, manioc, potatoes, fruits, vegetables; export
ae -- essential oils for perfumes (mainly ylang-ylang), vanilla, copra,
sisa
Exports: $3.8 million (1967) perfume oils, vanilla, copra, sisal
Imports: $7.5 million (1967) foodstuffs, cement, fuels, chemicals, textiles
Major trade partners: France, Malagasy Republic, Italy, Kenya, Tanzania and U.S.
Electric power: est. 1,000 kw. capacity (1971); est. 2 million kw.-hr. produced
(1971); 7 kw.-hr. per capita
Aid: French aid in 1971 was about $2.7 million, or about 50% of the island''s
entire budget
Monetary conversion rate: 255.79 CFA francs=US$1
GNP: $982 million (purchasing power parity estimate, 1971), $550 per capita;
14% government consumption, 67% private consumption, 23% domestic investment,
cs peepee: -10% net foreign balance (1970); real growth rate 1971, 5.5%
est.
Agriculture: main products -- bananas, coffee, sugarcane, rice, corn, cocoa,
livestock products; caloric intake, 2,610 calories per day per capita (1966)
7]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Fishing: catch 4,100 metric tons (1970); exports, $1.4 million (1969), imports
$0.4 million (1969)
Major industries: food processing, textiles and clothing, construction
materials, fertilizer
Electric power: 237,000 kw. capacity (1969); 965 million kw.-hr. produced
(1970), 536 kw.-hr. per capita
Exports: $231.1 million (f.o.b., 1971); coffee, bananas, sugar, beef, fertilizers,
cacao
Imports: $347.9 million (c.i.f., 1971 est.); manufactured products, machinery,
transportation equipment, chemicals, fuels, foodstuffs
Major trade partners: exports -- 41% U.S., 20% CACM, 8% West Germany, 5%
Netherlands; imports -- 35% U.S., 22% CACM, 8% West Germany, 9% Japan (1970)
Aid:
economic -- extensions from U.S. (FY46-70), $116.7 million loans, $91.5
million grants: from international organizations (FY46-70), $137.2 million;
from other Western countries (1960-68), $1.8 million;
military -- assistance from U.S. (FY60-70) $1.8 million
Monetary conversian rate: 6.62 calones=US$1 (official buying rate); 6.65
colones=US$1 (official selling rate)
Fiscal year: calendar year
GDP: $15.8 million (1968 est.), $230 per capita; economy is virtually stagnant
in real terms :
Agricultural products: bananas, citrus, coconuts, cocoa
Major industries: agricultural processing, tourism
Electric power: 3,000 kw. capacity (1969 est.); 9 million kw.-hr. produced
(1969 est.), 120 kw.-hr. per capita
Exports: $6.2 million (f.o0.b., 1970) : bananas, lime juice and of1, cocoa and
reexports
Imports: $15.9 million (c.i.f., 1970); foodstuffs, manufactured articles
Major trade partners: U.K. 53%, Commonwealth Caribbean countries 15%, Canada
10%, U.S. 7% (1963)
Monetary conversion rate: 1.84 East Caribbean dollars=US$1
GNP: $1.5 billion (purchasing power parity estimate, 1970), $350 per capita; real
growth rate 1970, 6.5%
Agriculture: main crops -- sugarcane, coffee, cocoa, tobacco, rice, corn; self-
sufficient in rice; caloric intake, 2,200 calories per day per capita (1966)
Major re Bg sugar processing, bauxite mining, peanut processing, textiles,
cemen
85
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Electric power: 254,000 kw. capacity (1970 est.}; 710 million kw.-hr. produced
(1970 est.), 175 kw.-hr. per capita
Exports: $213.5 million (f.0.b., 1970); sugar, coffee, cocoa, tobacco, bauxite
Imports: $306 million (c.i.f., 1970); foodstuffs, petroleum, industrial raw
materials, capital equipment
Major trade partners: exports -- U.S. 89%, Europe 8%; imports -- U.S. 56%,
Europe 25% (1968)
Aid:
economic -- extensions from U.S. (FY46-70), $198.8 million in grants,
$257.4 million in loans; from international organizations (FY46-70),
$82.2 million;
military -- assistance from U.S. (FY53-70), $26.9 million
Monetary conversion rate: 1 peso=US$1
Fiscal year: calendar year
Government budget: Colony -- revenues, $1.0 million (FY68); expenditures ,
$1.1 million (FY68)
Agriculture: Colony -- predominantly sheep farming; dependencies -- whaling
and sealing
Major industries: Colony -- wool processing; dependencies -- whale and seal
processing
Electric power: 1,327 kw. capacity (1970); 4 million kw.-hr. produced (1970),
2,000 kw.-hr. per capita
Exports: Colony -- $2.28 million (1969); wool, hides and skins, and other;
dependencies -- no exports in 1968 or 1969
Imports: Colony -- $1.22 million (1969); food, clothing, fuels, and machinery ;
dependencies -- $8,368 (1969); mineral fuels and lubricants, food,
and machinery
Major trade partners: nearly all exports to the U.K., 77% of imports from the
U.K.; dependencies -- exports to the Netherlands (63%) and Japan (37%),
imports from Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island pound=US $2.60
GDP: $22.0 million (1967), $220 per capita
Agriculture: main crops -- cocoa, spices, bananas
Electric power: 2,500 kw. capacity (1969); 8.75 million kw.-hr. produced (1969
est.), 82 kw.-hr. per capita
Exports: $5.1 million (f.o.b., 1968); cocoa beans, bananas, nutmeg, mace
Imports: $13.2 million (c.i.f., 1968); textiles, flour, clothing, miscellaneous
manufactured goods
Major trade partners: U.K. 37%, U.S. 9%, Canada 9% (1966)
Monetary conversion rate: 1.84 West Indies dollars=US$1
GDP: $206 million (1968), $650 per capita; real growth rate (1968 est.) 1%
Agriculture: main crops, sugarcane and bananas
bs Major industry: agricultural processing, sugar milling and rum distillation
* Electric power: 27,800 kw. capacity (1970); 72 million kw.-hr. produced (1970),
213 kw.-hr. per capita
Exports: $38 million (f.0.b., 1970), sugar, bananas, rum
Imports: $128 million (c.i.f., 1970), foodstuffs, clothing and other consumer
goods, raw materials and supplies, and petroleum
131
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major trade partners: exports -- France 71%, U.S. 17%, Germany 7%, other
5%; imports -- France 70%, U.S. 9%, Germany 3%, Netherlands Antilles 3%,
Netherlands 3%, other 12% (1968)
Monetary conversion rate: 5.1157 francs=US $1
Fiscal year: calendar year
GNP: $2.2 billion (purchasing power parity estimate, 1971), $410 per capita; 79%
private consumption, 8% government consumption, 14% domestic investment, -1%
net foreign balance; real growth rate 1971, 5.1%
Agriculture: main products -- coffee, cotton, corn, beans, sugarcane, bananas,
livestock; caloric intake, 2,200 calories per day per capita (1967)
Fishing: catch 2,100 metric tons (1969)
133
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major industries: food processing, textiles and clothing, furniture, chemicals,
nonmetallic minerals, metals
Electric power: 178,600 kw. capacity (1971 est.); 1,050 million kw.-hr. produced
(1971 est.}, 180 kw.-hr. per capita
Exports: $296 million (f.o.b., 1971); coffee, cotton, meat, bananas, sugar,
textiles, tires
Imports: $281 million (f.o.b., 1971); manufactured products, machinery, trans-
portation equipment, chemicals, fuels
Major trade partners: exports -- U.S. 28%, CACM 29%, West Germany 10%, Japan
11%; imports -- U.S. 41%, CACM 20%, West Germany 10%, U.K. 17% (1968)
Aid:
economic -- extensions from U.S. (FY46-70), $171.3 million loans, $170.8
million grants; from international organizations (FY46-70), $126.1 million;
from other western countries (1960-68) $7.6 million;
military -- assistance from U.S. (FY53-70), $17.6 million
Monetary conversion rate: 1 quetzal=US$1 (official)
Fiscal year: calendar year
GNP: $933 million (purchasing power parity estimate, 1970), $470 per capita; 73%
private consumption, 10% government consumption, 19% domestic investment, -2%
net foreign balance; real growth rate 1970, 4.5%
24]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Agriculture: main crops -- cotton, coffee, sugarcane, rice, corn, beans; caloric
intake, 2,300 calories per day per capita (1966)
Fishing: catch 7,200 metric tons (1970)
Major industries: food processing, textiles and clothing, chemicals, petroleum
products
Electric power: 173,000 kw. capacity (1969 est.); 550 million kw.-hr. produced
(1969 est.), 290 kw.-hr. per capita
Exports: $179 million (1970); cotton, coffee, cottonseed, meat, sugar
Imports: $199 million (1970); machinery, equipment, vehicles, manufactures ,
chemicals, foods, fuels
Major trade partners: exports -- U.S. 33%, Japan 19%, CACM 21%; imports -- U.S.
38%, CACM 24%, West Germany 7% (1969)
Aid:
economic -- extensions from U.S. (FY46-70), $105.8 million loans, $61.4
million grants; international organizations (1946-70), $124.2 million;
military -- from U.S. (FY53-70), $12.8 million (1946-70)
Monetary conversion rate: 7 cordobas=US$] (official)
Fiscal year: calendar year
GNP: $1.49 billion (purchasing power parity estimate, 1971), $1,010 per capita;
72% private consumption, 11% government consumption, 26% gross fixed
investment, -9% net foreign balance (1970); real growth rate 1971, 8.0% (est.)
Agriculture: main crops -- bananas, rice, corn, coffee, sugarcane; self-sufficient
in most basic foods; 2,450 calories per day per capita (1969)
Fishing: catch 32,000 metric tons, $8 million (1970); exports $10.9 million (1969);
imports $1.5 million (1969)
Major industries: food processing, metal products, construction materials,
petroleum products, clothing
Electric power: 218,000 kw. capacity (1970 est.); 860 million kw.-hr. produced
(1970 est.), 600 kw.-hr. per capita
Exports: $140 million (f.0.b., 1971 est.); bananas, petroleum products, shrimp,
sugar, coffee
Imports: $396 million (c.i.f., 1971 est.); manufactures, transportation equipment, F
crude petroleum, foodstuffs, chemicals
Major ie ees U.S. 43%, Venezuela 15%, Canal Zone 9%, Colon Free Zone
6% (1969
economic -- extensions from U.S. (FY46-70), $153.1 million loans, $101.6
million grants; from international organizations (FY46-70), $53.5 million;
from other Western countries (1960-69). $14.5 million;
military -- assistance from U.S. (FY61-70), $4 million
Monetary Conversion rate: 1 balboa=US$1 (official)
Fiscal year: calendar year
Aid:
GNP: $790 million (purchasing power parity estimate, 1971), $320 per capita;
88% consumption; 16% gross domestic investment; -4% net foreign balance (1971);
real growth rate 1971, 4.8%
Agriculture: main crops -- oilseeds, cotton, wheat, manioc, sweet potatoes,
tobacco, corn, rice, sugarcane; self-sufficient in most foods; caloric
intake, 2,580 calories per day per capita (1963-64); protein intake,
70 grams per day per capita (20 grams of animal origin)
Major industries: meat packing, oilseed crushing, milling, brewing, textiles,
Vight consumer goods, cement
257
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Electric power: 150,000 kw. capacity (1970 est.); 201 million kw.-hr. produced
(1970 est.), 84 kw.-hr. per capita
Exports: $64 million (f.0.b., 1970); meat, timber, oilseeds, tobacco, cotton,
quebracho extract, hides, yerba mate
Imports: $76 million (c.i.f., 1970); foodstuffs, machinery, transport equipment,
engines, consumer durables, fuels and jubricants, textiles
Major trade partners: U.S. 29%, Argentina 20%, West Germany 8%, U.K. 8%
Aid:
economic -- extensions from U.S. (FY46-70), $79.3 million loans, $53.9 million
grants: from international organizations (FY46-70), $147.4 million; from other
Western countries (1960-66), $7.4 million;
military -- assistance from U.S. (FY58-70), $11.0 million
Monetary conversion rate: 126 guaranies=US$1 (official rate)
Fiscal year: calendar year
COMMUNTCATIONS:
Railroads: 652 mi.; 273 mi. standard gage, 85 mi. 3''3 3/8'''' gage, 294 mi. various
narrow gage (privately owned)
Highways: 9,900 mi.; 400 mi. bituminous treated, 3,100 mi. otherwise improved,
6,400 mi unimproved earth
Inland waterways: 1,970 mi.
Ports: I major, 7 minor (all river)
Merchant marine: 14 ships (1,000 GRT or over) totaling 15,700 GRT. 14,900 DWT;
includes 2 passenger, 9 cargo, 2 tanker, 1 specialized carrier; domestic
ships are operated mostly in river traffic; most international waterborne trade
is carried by foreign flag ships
Civil air: 5 major transport aircraft
Airfields: 797 total, 660 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 25 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: local telecom facilities in Asuncion good, but intercity net
still poor; 24,000 telephones; est. 720,000 radio and 18,000 TV receivers:
18 AM, 5 FM, and 1 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, $17.2 million; about
17% of proposed central government budget
258
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Finis randegenanapeeaasas lad ress acest nel tenured: atenecden.staaitnas ndaananateeetaantiive rte: keamsateatnaamatcarmandt caatendne-tns anmemanalineemeaiied
ne ar ee ee Ste
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
GDP: $16.','95129018d97726cc14b755c5e59ca8aadc6582e6a98c1a03fb3a99318723050d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2326c6c78425a5cfbc2dd1cf8fa006b2820a1afe02fef754cc2cec0e2a66ad37',1972,'BR','Brazil','economy',26,'9 million (1969), $180 per capita
Agriculture: main crops -- bananas, arrowroot, coconut
Major industries: food processing
Electric power: 1,700 kw. capacity (1969); 5.1 million kw.-hr. produced (1969
est.), 53 kw.-hr. per capita
Exports: $3.7 million (f.o.b., 1968); bananas, arrowroot, copra, cotton
Imports: $1.0 million (c.i.f., 1968); fertilizer, flour, transportation
equipment, lumber, textiles
Major trade partners: U.K. 39%, U.S. 10%, Canada 10% (1967)
Monetary conversion rate: 1.84 East Caribbean dollars=US$1','b9ca8c0519775244de7ef1d2277cce2863a7c558f01742f3fc78a2581b84c148','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a9a6ff21a79479d5dfc08ef2ed40cac793ec6b390f59ff88b0fc285c4980d1e',1972,'AR','Argentina','economy',31,'GNP: $32.4 billion (purchasing power parity estimate, 1971), $1,370 per capita;
68% private consumption, 12% public consumption, 18% gross domestic investment,
2% net foreign balance (1968); real growth rate 1971, 3.8%
Agriculture: main products -- cereals, oilseeds, livestock products; Argentina
iS a major world exporter of temperate zone foodstuffs
Fishing: catch 202,800 metric tons, $15,486,000; exports $1,158,000, imports
$3,659,000 (1970)
Major industries: food processing (especially meatpacking), motor vehicles,
consumer durables, textiles, chemicals, printing, and metallurgy
Crude steel]: 1.91 million metric tons produced (1971); 80 kilograms per capita
Electric power: 6,318,000 kw. capacity (1970); 20.9 billion kw.-hr.
produced (1970), 853 kw.-hr. per capita
Exports: $1,750 million (f.0.b., 1970) -- meat, wheat, corn, wool, hides, oil-
seeds
Imports: $1,550 million (c.i.f., 1970) -- machinery and vehicles, fuel and
lubricating oils, iron and steel, textiles, intermediate industrial products
Major trade partners: exports -- EC 37%, LAFTA 25%, U.S. 11%, U.K. 8%:
imports -- EC 24%, LAFTA 24%, U.S. 23%, U.K. 7%
Aid: economic -- extensions from U.S. (FY46-70), $764.4 million in loans;
$17.6 million in grants; from international organizations (FY46-70), $860.3
million; from other Western countries (1960-66), $315.5 million; from
Communist countries (1954-71) $56 million (drawn, $41.0 million);
military -- assistance from U.S. (FY46-70), $129.6 million
Monetary conversion rates: commercial -- 5.00 pesos = US$1; financial -- floating
(9.68 pesos = US$] on 8 March 1972)
Fiscal year: calendar year','87ac5d078f75dc3a743bb26ee3c0940ea4352fd1c8683918da842b80d5f1c547','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('270dc8563b80d08013a4496836d6d258a3a8359b4d662274189308f950b09618',1972,'AT','Austria','economy',35,'GNP: $17.6 billion (1971), $2,360 per capita; 56.1% consumption, 29.3% investment,
14.4% government, .2% net foreign balance; 1971 growth rate 5.5% 1964
constant prices
Agricuiture: livestock, cereals, potatoes, sugar beets; 84% self-sufficient;
caloric intake 2,920 calories per day per capita (1967-68)
Fishing: catch 4,000 metric tons, $3,846,000 (1968); exports $530,418 (1970),
imports $16,688,000 (1970)
Major industries: foods, iron and steel, machinery, textiles, chemicals,
electrical, paper and pulp
17
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Crude steel: 4.1 million metric tons produced (1970), 550 kilograms per capita
(1970)
Electric power: 7,530,000 kw. capacity (1970); 30,036 million kw.-hr produced
(1970), 3,460 kw. “hr, per capita
Exports: $2. 86 billion (f.o.b., 1970); iron and steel products, machinery and
equipment, lumber, textiles and clothing, paper products, chemicals
Imports: $3.55 billion (c,i.f., 1970); machinery and equipment, chemicals,
textiles, coal, petroleum, "foods tuffs
Major trade partners (1970) West Germany 33%, Italy 8%, Switzerland 92,
U.K. » U.S. 4%; EC 49%; EFTA 23%; Communist countries 11%
Aid:
economic -- received - U.S. $1,166.9 million authorized through FY70; IBRD
$104.9 million authorized, none since FY62;
military -- U.S., $144.6 million authorized (FY52-70); net official economic
aid to less developed areas and multilateral agencies -- $189 million
(FY60-70), $24.2 million in FY70
Monetary conversion rate: 23.30 shillings=US$1 (central rate)
Fiscal year: calendar year','3f47032e0b22d2ef13a6f5d8dd2dfd98a2b3bc707442d8767216cfd9218939d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad144eb754599732a8c9d7abd67fdbf1a1bca456092b923bc8c2eaf74bf32145',1972,'BH','Bahrain','economy',41,'Agriculture: produces dates, alfalfa, vegetables; dairy and poultry farming;
fishing; not self-sufficient in food
Major industries: petroleum refining, boatbuilding, shrimp fishing, and
sailmaking on a small scale; major development projects include aluminum
smelter, flourmil], and ISA town
Electric power: 108,000 kw. capacity (1970); 270 million kw.-hr. produced (1970),
1,250 kw.-hr. per capita
Imports: $168 million (1970)
Major trade partners: U.K., Japan, U.S., EC
Aid: economic -- multilateral Western $360,000 (annual average 1967-69)
Monetary conversion rate: 1 Bahrain dinar=US$2.27 (as of March 1972)
Fiscal year: 1 April - 31 March','9f1beebb4111c8b4b14eef4027dd8d55a1bd57931f6193162bcb09f64d5e7e9e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ef65df2922ed97a9646135ba36c02ebcdd8e7620e4c60bbc739285dbdc54fb7',1972,'BD','Bangladesh','economy',45,'GNP: $5.8 billion (FY70), less than $100 per capita; real growth (FY70) 5.8%
Agriculture: largely subsistence farming, heavily dependent on monsoon rainfall;
main crops are jute and rice; shortages -- rice, wheat, and cotton
Fishing: catch 273 thousand tons, $115 million (estimate, 1969)
Major industries: jute manufactures, food processing and cotton textiles
Electric power: 680,000 kw. capacity (1971) 5 1 billion kw.-hr. produced (1971),
16 kw.-hr. per capita
Exports: $359 million (f.0.b., FY71); raw and manufactured jute, tea, paper and
paperboard, hides and skins
Imports: $505 million (c.i.f. FY71); chemicals, machinery and other manufactured
products, transport equipment, foodgrains, fuels, oils and fats
Major trade partners: West Pakistan (until December 1971), U.S., U.K., Japan,
India (since December 1971)
*Does not take account of refugees who entered India from Bangladesh during 1971, most
of whom presumably have returned.
23
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Aid: Bangladesh received roughly one-third of the estimated $8 billion in total
economic aid received by Pakistan between 1950 and 1971; the U.S. was by
far the largest contributor
Monetary conversion rate: 7.29 takas=US$1 (effective January 1972)
Fiscal year: 1 July - 30 June','872bcb30633c96cdb5891b38005971d8352a42672988fce69ada8804a460445c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52bc105c124eda82283197664419bc509c8b952e7067445d03431c39d68a4497',1972,'BE','Belgium','economy',51,'GNP: $31.5 billion (1971), $3,230 per capita (1971), 60% consumption,
24% investment, 14% government, 2% net foreign balance; 1971 growth rate
3.7%, 1970 constant prices
27
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Agriculture: livestock production predominates; main crops ~- grains, beets,
potatoes; 80% self-sufficient in food; food shortages -- edible and coarse
doen: ue and oj1s; caloric intake, 3,150 calories per day per capita
1968-69
Fishing: catch 58,700 metric tons, $16,766,000 (1969); exports $19,783,000
(including Luxembourg, 1969), imports $70,940,000 (including Luxembourg, 1970)
Major industries: engineering and metal products, processed food and beverages,
chemicals, basic metals, textiles, and petroleum
Shortages: iron ore, nonferrous minerals, petroleum, cotton, wool, wood
Crude steel: capacity 16.6 million metric tons (1971}; 12.4 million metric tons
produced (1971); 1,270 kilograms per capita
Electric power: 6,855,000 kw. capacity (1970); 29,306 million kw.-hr. produced
(1970), 2,910 kw.-hr. per capita
Exports: $13,700 million (f.o.b., 1971) motor vehicles, refined copper, iron and
steel products, finished or semifinished precious stones, textile products
Imports: $13,300 million (c.i.f., 1971) crude materials, food, fuels, automotive
parts, nonelectrical machinery and appliances, clothing
Major trade partners: (Belgium-Luxembourg Economic Union, 1971) West Germany
25%, Netherlands 18%, France 19%, U.S. 7%, U.K. 5%, Italy 4%; EC 66%, EFTA
10%, Communist countries 2%
Aid:
economic -- received - U.S., $767.4 million authorized (FY46-70); $15.8 million
in FY70;
military -- received - $1,253.6 million authorized (FY46-70), $1.9 million
in FY68; net official economic aid to less developed areas and multilateral
agencies -- $1,003.6 million (FY60-70), $119.6 million in 1970
Monetary conversion rate: 44.8159 francs=US$1 (official central)
Fiscal year: calendar year','d5cc0283ce673bdc59b91c95c54d1b1641ad680451250985b76c24ea9c1ea478','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7977ec6cda1dea7e00535f235306f97efe1ddea4f9b22d17791c5a428b203199',1972,'CA','Canada','economy',56,'GNP: not available
Agriculture: main products -- bananas, vegetables, Easter lilies, dairy products,
citrus fruits
Major industries: tourism, ship repair, small boat building
Electric power: 51,740 kw. capacity (1969); 181.6 million kw.-hr. produced (1969),
3,425 kw.-hr. per capita
Exports: $70.0 million (f.0.b., 1969); mostly reexports of drugs and bunker fuel
Imports: $85.5 million (f.o.b., 1969); fuel, foodstuffs, machinery
Major trade partners: U.S. 46%, U.K. 22%, Canada 9% (1968)
Monetary conversion rate: 1 Bermuda dollar=US$1 (14 August 1971)
Fiscal year: 1 April-31 March','55a2e4ad74308587990611e438363260895e71b9bed6e78e19d57519c15e9080','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a400cacca8fcf790982f7d0f98d5a56557f36261632325385527d5b5f7cb8b13',1972,'BT','Bhutan','economy',60,'GNP: under $100 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 400 kw. capacity
Exports: about $1 million annually; rice, dolomite, and handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic -- India (FY61-68) $35.2 million
Monetary conversion rate: 7.5 Indian rupees=US$1
Fiscal year: 1 April - 31 March','4c25ca6513748dd49cc6dd941ba2bd18ca96b35fae6973d44ac8fb0a1089f7ab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d22a8934a43f0595a8a40c5cf71716d74a6abbf20d4986e6c6e199b8e531c0b5',1972,'BW','Botswana','economy',65,'t Agriculture: principal crops are corn and sorghum; livestock raised and exported
Major industries: livestock processing, mining of asbestos, manganese, diamonds
Electric power: 8,000 kw. capacity (1971); 0.3 million kw.-hr. produced (1971),
.5 kw.-hr. per capita
Exports: $18.3 million (f.0.b., 1969); cattle, animal products, minerals
Imports: $43.2 million (f.o.b., 1969); foodstuffs, vehicles, textiles
Major trade partner: South Africa
35
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: 1 SA Rand=US$1.33 (Botswana uses the South African
Rand) (official); 0.75 SA Rand=USS1
Fiscal year: 7 April - 31] March','2325a39e4b9b7cf746c34be763c5f307f5e1657109b79b386df97e8e93282ce2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a265a87781f8b993b9cf3dde5bd6155121f8fe5b1a27d20c09623da41bd620b',1972,'IQ','Iraq','economy',68,'GNP: $12.7 billion, 1971 (at 1970 prices), $1,490 per capita; 1971 growth rate
7.3% (current)
Agriculture: mainly self-sufficient; main crops--grain, vegetables; no food
shortages; caloric intake, 3,000 calories per day per capita (1969/70)
Major industries: agricultural processing, machinery, textiles and clothing,
mining, ore processing, timber
43
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Shortages: some raw materials, metal products
Crude steel: 2 million metric tons produced (1971), 230 kg. per capita
Exports: $2,180 million (f.0.b., 1971); in 1970, 29% machinery, equipment, and
transportation equipment; 13% fuels, minerals, raw materials, metals, and
other industrial material: 8% agricultural raw materials; 35% foodstuffs
and animals; 15% industrial consumer goods
Imports: $2,169 million (f.0.b., 1971); in 1970, 41% machinery, equipment, and
transportation equipment; 38% fuels, minerals, raw materials, metals, other
materials; 10% agricultural raw materials; 6% foodstuffs and animals: 5%
industrial consumer goods
Major trade partners: $4,349 million in 1971; 21% with non-Communist countries;
79% with Communist countries
Monetary conversion rate: (commercial) 1.08 leva, (noncommercial) 1.85 Teva=US$1
Fiscal year: calendar year; economic data reported for calendar years except for
caloric intake, which is reported for consumption year 1 July - 30 June
GDP: $2.2 billion (FY71), approximately $80 per capita; real growth rate 6% (FY70)
Agriculture: main crops -- paddy, sugarcane, peanuts; almost 100% self-sufficient;
most rice grown in deltaic land
Major industries: agricultural processing; textiles and footwear, wood and
wood products; petroleum refining
Electric power: 260,000 kw. capacity (1971); 600 million kw.-hr. produced (1971),
21 kw.-hr. per capita
Exports: $118 million (f.o.b., 1971); rice, teak
Imports: $150 million (c.i.f., 1971 est.) machinery and transportation equipment,
textiles, other manufactured goods
45
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major trade partners: exports -- India, Western Europe, U.K., Japan; imports --
Japan, Western Europe, India, U.K.
Monetary conversion rate: 5.35 kyat=US$1
Fiscal year: 1 October - 30 September','95f950ec035757c6a3cc51bf420a42b7dda266cb66e5dd349f94f66a517e041a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2129b8b380e2b1665770ccea847d36ee5989eac77b709b346f6321dc8d5781cc',1972,'BI','Burundi','economy',73,'GNP: about $207.4 million (1970 est.), $60 per capita; estimated real GDP
growth 17%
Agriculture: major cash crops -- coffee, cotton; main food crops -- manioc,
yams, corn, sorghums, bananas, haricot beans; not self-sufficient
Industries: light consumer goods such as beverages, shoes, soap
Electric power: 13,100 kw. capacity (1971); 26 million kw.-hr. produced (1971),
7 kw.-hr. per capita
Exports: $21.7 million (f.o.b., 1970); coffee, cotton, hides, skins
Imports: $20.9 million (c.i.f., 1970); textiles, foodstuffs, transport equipment,
petroleum products
Major trade partners: U.S., Belgium, Congo; much trade unrecorded
Aid: $14.9 million (1969) includes U.S. $100,000 (U.S. $7.5 million FY62-70),
Belgium $7.6 million, U.N. $2.4 million, EDF $2.2 million; France $1.7
million (1970)
47
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: 87.5 Burundi francs=US$1 (official)
Fiscal year: calendar year','3aabf98cf9c2db46633426b3f7ee37f565eda22929fc7eec6270d54075fb8c96','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b87f2b5830d9d010af153b8e6414017fa800b28e7fad5958ff325befee0921d',1972,'CM','Cameroon','economy',80,'GDP: $872 million (1970 est.), per capita about $150; real growth rate about 7%
per annum
Agriculture: commercial and food crops -- cocoa, coffee, timber, cotton, rubber,
bananas, peanuts, palm oil and palm kernels; root starches, livestock, millet,
sorghum, and rice
Fishing: catch about 73,000 tons (1970), value not available; exports -- none
(1970), imports $1.6 million (1970)
5]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major industries: smal] aluminum plant; food processing and light consumer goods
industries, sawmills
Electric power: 262,400 kw. capacity (1971); 1.2 billion kw.-hr. produced
(19715, 206 kw.-hr. per capita
Exports: $226 million (f.0.b., 1970) cocoa and coffee about 55%; other exports
include timber, aluminum, cotton, natural rubber, bananas, peanuts, tobacco,
and tea
Imports: $242 million (c.i.f., 1970) consumer goods, machinery, transport equipment,
alumina for refining, petroleum products, food and beverages; about 2% from
Communist countries
Major trade partners: about 70% of total trade with France and other EC countries;
less than 10% of total trade with U.S.
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; prior to 13 August 1971, 255.785 CFA francs = US$1 (official)
Fiscal year: 1 July - 30 June','9abc2f8aae40d8ce5b6c2f148931df85ab20c0920537ed1fb3596b8f01aff5bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d299c37133fa7d9191ec37f399927eb65825abef9083c2ec178b532226bc9798',1972,'CF','Central African Republic','economy',84,'GDP: $213 million (est. 1971), about $140 per capita
Agriculture: commercial -- cotton, coffee, peanuts, sesame, wood; main food
crops -- manioc, corn, peanuts, rice, potatoes, beef; requires wheat, flour,
rice, beef, and sugar imports
Major rea sawmills, cotton textile mills, brewery, diamond mining and
splitting
Electric power: 16,850 kw. capacity (1971); 47 million kw.-hr. produced (1971),
29 kw.-hr. per capita
Exports: $33 million (f.o.b., 1970); diamonds (43%), coffee, cotton, lumber
Imports: $41 million (c.i.f., 1970); textiles, petroleum products, machinery
and electrical equipment, motor vehicles and equipment, chemicals and
pharmaceuticals ,
55
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major trade partner: France; preferential tariff applied to EC countries and
franc zone; U.S.
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$]
(official)
Fiscal year: calendar year','5f4f5330178afdfcaf9f8db12cc63015853562582278b215a8d86e6580812d4b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2584e9ebd19777acf393bac4a0269bd62408d986fc743a1d0a87057c1734e70a',1972,'TD','Chad','economy',88,'GDP: about $209 million (1967), about $60 per capita; annual growth rate 5.7%
Agriculture: commercial -- cotton, gum arabic, livestock, fish; food crops -~
peanuts, mitlet, sorghum, rice, dates, manioc, wheat; imports food
Fishing: catch 100,000-110,000 metric tons annually; exports $300,000 (1969)
Major industries: agricultural and livestock Processing plants (cotton textile
mill, slaughterhouses, brewery), natron
Electric power: 16,660 kw. capacity (1971); 54 million kw.-hr. produced (1971),
14 kw.-hr. per capita
57
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $39.9 million (c.i.f., 1970) including trade with members of the
Economic and Customs Union of Central Africa (UDEAC); cotton 58%, livestock 17%
Imports: $69.3 million (c.i.f., 1970) including UDEAC trade; cement, petroleum,
foodstuffs, machinery, textiles, and motor vehicles; $1.3 million from Communist
countries (1967)
Major trade partners: France (about 40% in 1969) and UDEAC countries; preferential
tariffs to EC and franc zone countries
Aid: major source France, FY61-67 $49.1 million; EC (FY60-67) $28.6 million;
U.S. (FY62-70) $9.2 million; U.S.S.R. $2.2 million (1968); military aid
(1954-68) -- $5.4 million, from France $4.1 million, remainder from West
Germany and Israel
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year','ac1f90421c9d060bdfe9480d22d2ac4314abdd8d3826778eae91bf6ead4dae81','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb65abc9e686a2631fb597259149f557be024317d824d7d75efa65781ab8bb4c',1972,'AU','Australia','economy',92,'GNP: about $130 billion (1971), $150 per capita
Agriculture: main crops -- rice, wheat, miscellaneous grains, cotton; caloric
intake, 2,000 calories per day per capita (1971); agriculture mainly
subsistence; grain imports 4-5 million tons annually (1961-70) and 3.2 million
tons in 197]
Major industries: iron and steel, coal, machine building, armaments, textiles
Shortages: complex machinery and equipment, highly skilled scientists and
technicians
Crude steel: 21 million tons produced (1971), 25 kilograms per capita (1971)
Exports: $2.4 billion (f.o.b., 1971), agricultural products, minerals and metals,
manufactured goods
Imports: $2.2 billion (c.i.f., 1971), grain, chemical fertilizer, industrial
raw materials, machinery and equipment
Major trade partners: Japan, Hong Kong, West Germany, U.K., Singapore, Malaysia,
Canada (1971)
Monetary conversion rate: 2.27 yuan=U5$1 (arbitrarily established)
Fiscal year: calendar year
GNP: $6.2 billion (1971), $420 per capita; real growth, 11%
Agriculture: most arable land intensely farmed -- 60% cultivated land under
irrigation; main crops -- rice, sweet potatoes, sugarcane, bananas,
pineapples, citrus fruits; 90% self-sufficient; food shortages -- wheat
Fishing: catch 613,000 tons, $179 million (1971)
Major industries: textiles, clothing, chemicals, plywood, electronics, sugar
milling, food processing, cement
Electric power: 2,730,000 kw. capacity (1971); 15.2 billion kw.-hr. produced
(1971); 1,024 kw.-hr. per capita
Exports: 2,136 million (f.o.b., 1971); textiles 18%, clothing and footwear 15%,
T.V. and radios 8%, other machinery and equipment 10%, metals and manufactures
14%, canned foods 7%, lumber and plywood 6%, sugar 4%, seafood 4%
Imports: $1,950 million (c.i.f., 1971) machinery and equipment 33%, basic metals
10%, grains and soybeans 8%
Major trade partners: exports -- 37% U.S., 15% Japan; imports -- 38% Japan,
30% U.S.
Aid:
economic -- U.S. (FY53-70) $1.4 billion committed; IBRD (1964-70) $244
million committed; Japan (1965-70) $137 million committed
military -- U.S. (FY49~70) $3.4 billion committed
Monetary conversion rate: NT$40 (New Taiwan)=US$1
Fiscal year: 1 July - 30 June
GNP: $9.5 billion (1970), less than $100 per capita; real average annual growth
(1965-70) 3%
Agriculture: subsistence food production, and smallholder and plantation
production for export; main crops -- rice, rubber, copra, other tropical
products; substantially self-sufficient; food shortage -- rice
Fishing: catch 1.2 million tons (1969); exports $1.5 million (1969), imports $0.6
million (1969)
Major industries: processing agricultural products and petroleum, textiles,
cement, mining
Electric power: 1,010,000 kw. capacity (1971); 2.65 billion kw.-hr. produced (1971),
22 kw.-hr. per capita
Exports: $1,181 million (f.o.b., 1970); petroleum, rubber, tin, copra, tea, coffee,
tobacco, palm oil
Imports: $1,145 million (f.o.b., 1970); rice, other foodstuffs, textiles, chemicals,
iron and steel products, machinery, transport equipment, consumer durables
Major trade partners: exports (1970) -- 16% U.S., 55% Japan, 4% Singapore, 9%
West Germany; imports -- 22% U.S., 55% Japan, 9% West Germany, 13% Singapore
Monetary conversion rate: 415 rupiah=US$1
Fiscal year: ] Apri] - 31 March
GNP: $12 billion (FY71-72 est.), $400 per capita; real GNP growth, FY71-72,
10%-11% est.
Agriculture: dates, fruit, nuts, vegetables, grains, sugar beets, cotton, gum,
rice, sheep, and goats
Electric power: 2,842,000 kw. capacity (1970); 12 billion kw.-hr. produced
(1970), 410 kw.-hr. per capita
Exports: $2,360 million (f.0.b., 1970); 89% petroleum; also carpets, raw cotton,
fresh and dried fruits, hide and leather items, ores; Communist countries
(primarily U.S.S.R.) took about 4.6% of total exports
Imports: $1,632 million (c.i.f., 1970); machinery, fron and steel products,
chemicals, pharmaceuticals, electrical equipment; Communist countries
supplied about 12% of commodity imports
Major trade partners: exports -- U.K.. Japan, U.S.. South Africa, U.S.S.R. and
other Communist countries; imports -- West Germany, U.S.. U.S.S.R.. U.K...
Japan, Italy, France, Netherlands
Monetary conversion rate: 75.75 rials=US$1
Fiscal year: 21 March - 20 March
GNP: $2,693 million in 1969, $300 per capita
galt dates, wheat, barley, rice, livestock; largely self-sufficient
in foo
Major industry: crude petroleum (fourth largest producer in Middle East)
Electric power: 740,000 kw. capacity (1970); 2 billion kw.-hr. produced (1970),
220 kw.-hr. per capita
Exports: $63 million (f.o.b., 1970), not including oi] revenue of $513.3 million
Imports: $509 million (c.i.f., 1970); 26% from Communist countries (1969)
155
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major trade partners: exports (non oi1) -- U.S. 7%, Western European countries 42,
Communist countries 15%, Arab countries 54%, other 20%; imports -- U.S. 4%,
Western European countries 44%, Japan 3%, Communist countries 26%, Arab
countries 7%, other 16%
Monetary conversion rate: 1 Iraqi dinar=US$3.04 (freely convertible); 0.329
Tragi dinar=US$1
Fiscal year: 7 April - 31 March','1436f6f2c0781f2bff69fc72306d024bb8c4a083fd3e5db2bb640f0630714fee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('592fff8442fdba26b283080a1a5052c7d6729996e10165b2ac1252d10a4740cb',1972,'CG','Congo','economy',98,'GDP: about $228 million (1967 est.), about $260 per capita, real growth rate
about 4% per year
Agriculture: cash crops -- sugarcane, wood, coffee, cocoa, palm kernels, peanuts,
tobacco; food crops -- root crops, rice, corn, bananas, manioc, fish
Fishing: catch 30,000 metric tons (1970 est.)
Major industries: sawmills, brewery, cigarettes, sugar mill, soap
69
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Electric power: 43,600 kw. capacity (1971); 71 million kw.-hr. produced (1971),
73 kw.-hr. per capita
Exports: $60 million (f.0.b., 1968); lumber, sugar, tobacco, veneer, and plywood;
diamonds smuggled from Zaire
Imports: $86 million (c.i.f., 1968); machinery, transport equipment, manufactured
consumer goods, iron and steel, foodstuffs, petroleum products
Major trade partners: France and other EC countries on preferential basis
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year','d96511c44937c78edfe301a1eeb477067bf427f68fc58f6e077742beef9a5430','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('194a41a708d28b2dc280a1192a8f45bbd64d2f5f7cc095fa4d0c399db8d11a70',1972,'CU','Cuba','economy',103,'GDP: $4.8 billion (est. 1971 at 1971 prices), $560 per capita; 60% private
consumption, 20% public consumption, 20% gross investment; real growth
rate 1971, -4%
Agriculture: main crops -- sugar, tobacco, coffee, rice, potatoes, tubers,
citrus fruits
Fishing: catch 125,900 metric tons (1971); exports $21.7 million (1971), imports
$13 million (1970)
Major industries: sugar milling, petroleum refining, food and tobacco processing,
textiles, chemicals, paper and wood products, metals
Shortages: spare parts for transportation and industrial machinery, consumer goods
Crude steel: 0.35 million metric tons capacity (planned 1969); 165,000 metric
tons produced (1970); 20 kg. per capita
Electric power: 1.35 million kw. capacity (1971); 5.1 billion kw.-hr. produced
(1970), 600 kw.-hr. per capita
Exports: $825 million (f.o.b., 1971 est.); sugar, nickel, tobacco
73
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Imports: $1,375 million (c.i.f., 197] est.); petroleum, industrial raw
materials, capital goods, food
Major trade partners: exports -- U.S.S.R. 35%, China 8%, other Communist
countries 19%, Japan 10%, Spain 3%; imports -- U.S.S.R. 55%,
China 5%, other Communist countries 13%, U.K. 5%, Japan 4% (1971 est.)
Monetary conversion rate: 1 peso=US$1 (nominal)
Fiscal year: calendar year','0298f1ffa31ba368261e86cd65d6c6074f513986178c62e0462486600661462f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4734e9f548e0439c9ecabac003ff46ef65192eb1695be33f3b7f0eacbd3d8d7e',1972,'CY','Cyprus','economy',106,'GNP: $540 million (1970), $850 per capita; 1970 growth 3%, 1958 constant prices
Agriculture: main crops -- vine products, citrus, potatoes, other vegetables;
food shortages -- grain, dairy products, meat, fish; caloric intake, 2,590
calories per day per capita (1961)
Major industries: mining (cupreous and iron pyrites, asbestos), manufactures
principally for local consumption -- food, beverages, footwear
Shortages: water, petroleum
Electric power: 196,300 kw. capacity (1970); 553 million kw.-hr. produced (1970),
850 kw.-hr. per capita
Exports: $114 million (f.o.b., 1971); principal items -- copper, pyrites, citrus,
raisins, and other agricultural products
Imports: $260 million (c.i.f., 1971); principal items -- manufactured goods,
machinery and transport equipment, petroleum products, foods
Major trade partners: (1970) U.K. 32%, West Germany 11%, Italy 9%, EC 28.1%,
Communist countries 7.7%
Aid: economic -- U.S., $22.2 million authorized (1961-70), none authorized in
1970; IBRD, $34.2 million (1963-70); U.N. Technical Assistance, $1.5 million
(1953-70); U.N. Special Fund, $8 million (1953-70)
Monetary conversion rate: 1 Cyprus pound=US$2.61 (as of March 1972)
Fiscal year: calendar year
COMMUNTCATIONS:
Railroads: none
Highways: 5,000 mi.; 2,100 mi. bituminous surface treated; 2,900 mi. gravel,
crushed stone, and earth
Ports: 3 major, 6 minor
Civil air: 7 major transport aircraft
Airfields: 19 total, 11 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft.; 3 with runways 4,000-7 ,999 ft,
Telecommunications: modest but expanding telecommunication system; 42,500
telephones; 150,000 radio receivers; 45,800 TV receivers; 2 TV, 12 AM, and
4 FM stations; tropospheric scatter to Europe
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $7.5 million about
9.7% of central government budget
76
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
CZECHOSLOVAKIA
D:
49,400 sq. mi.; 42% arable, 14% other agricultural, 35%
forested, 9% other (1968)
Land boundaries: 2,205 mi.
GNP: pee pytien in 1971 (at 1970 prices), $2,360 per capita; 1971 real growth
rate 4.1%
Agriculture: diversified agriculture; main crops -- wheat, rye, potatoes, sugar
beets; net food importer -- meat, wheat, vegetable oils, fresh fruits and
vegetables; caloric intake, 3,100 calories per day per capita (1967)
Major industries: machinery, food processing, metallurgy, textiles, chemicals
Shortages: ores, crude oil, grain
Crude steel: 12 million metric tons produced (1971), 830 kg. per capita
7]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $4,174 million (f.o.b., 1971); 50% machinery, equipment; 29% fuels,
raw materials; 4% foods, food products, and live animals; 17% consumer goods ,
excluding foods (1970)
Imports: $3,810 million (f.0.b., 1971); 33% machinery, equipment; 44% fuels, raw
materials; 15% foods, food products, and live animals; 8% consumer goods,
excluding foods (1970)
Major trade partners: $7,984 million (1971); 69% Communist countries, 31% other
Monetary conversion rate: commercial 6.55 crowns=US$1, noncommercial 13.05
crowns=US$1, tourist rate 14.73 crowns=US$1
Fiscal year: calendar year
GDP: $250 million (1970 est.) $90 per capita; real growth rate, 5.5% per annum
Agriculture: major cash crop is o71 palms; peanuts, cotton, coffee, sheanuts,
tobacco also produced commercially; main food crops -- corn, cassava, yams,
sorghum and millet; livestock, fish
Fishing: catch 35,000 tons (1970); exports none, imports 4,000 metric tons
Major industries: palm oil and palm kernel oil processing
Electric power: 9,330 kw. capacity (1971); 50 million kw.-hr. produced (1971),
18 kw.-hr. per capita
Exports: about $46 million (f.o.b., 1970); palm products (41%); other
agricultural products
79
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Imports: about $68 million (f.o.b., 1970); clothing and other consumer goods,
cement, lumber, fuels, foodstuffs, machinery, and transport equipment
Major trade partners: France, EC, franc zone; preferential tariffs to EC and
franc zone countries
Aid:
economic (1970) -- France, $8 million; EC, $4.2 million; U.N., $2 million;
West Germany, $1 million; Taiwan, $1 million; U.S., (FY1960-70) $12.4 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; 255.785 CFA francs=US$1
Fiscal year: calendar year','8c8ac6a337d966bf326a37191382346c0171d8a0cb587b9d622c22d6a1543949','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('642629369993191c346e8cbe20de9eeec68c87028bbf7254e051945a9c5465f3',1972,'DK','Denmark','economy',111,'GNP: $17.2 billion (1971), $3,470 per capita; 57.0% private consumption, 21.3%
investment, 23.8% government, -2.1% net foreign balance; 1971 growth 2.7%,
1969 current prices ,
Agriculture: highly intensive, specializes in dairying and animal husbandry;
main crops -- cereals, root crops; food shortages -- oi1, seeds; caloric
intake, 3,180 calories per day per capita (1968-69)
8]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Fishing: catch 1,259,314 metric tons (1969}, $100 million; exports $13.3 million,
imports $43 million
Major industries: food and food processing, textiles, clothing, footwear, en-
gineering and electrical equipment, transportation equipment, chemicals
Shortages: fuels, basic metals, fertilizers, grains
Crude steel: 549,800 metric tons produced (1970), 110 kg. per capita
Electric power: 4,780,000 kw. capacity (1971); 17.1 billion kw.-hr. produced
(197), 3,400 kw.-hr. per capita
Exports: 3,611 million (f.o.b., 1971); principal items -- meat, dairy products,
fish, machinery and transport equipment, chemicals
Imports: $4,458 million (c.i.f., 1971); principal items -- machinery and trans-
port equipment, petroleum and coal, textile fibers and yarns, iron and steel
products, chemicals, food
Major trade partners: U.K. 16%, West Germany 17%, Sweden 16%, U.S. 7%, Norway 5%;
EC 29%; EFTA 45%: Communist countries 4%
Aid:
economic -- (received) U.S., $301.8 million authorized 1946-70, none since
1958; IBRD -- $85.0 million through June 1970, none since 1964; net official
economic aid given to less developed areas and multilateral agencies,
$241.4 million (1960-70), $54.3 million (1969), $59.1 million (1970)
Monetary conversion rate: 6.98 Kroner=US$1
Fiscal year: 1 April - 31 March','21591e49f820e1de64463edcd94ca48ca096f77514f9fe8be9823bdf7a1850d3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13891d310cc358c79656191907d0f208f5b5833bb62a90d46c3fc7c5077b8272',1972,'EC','Ecuador','economy',118,'GNP: $3 billion (purchasing power parity estimate, 1971), $480 per capita;
72% private consumption, 14% public consumption, 14% gross investment (1970
est.); real growth rate 1971 est., 6%
Agriculture: main crops -- sugarcane, beans, coffee, cotton, corn, bananas,
cocoa, rice; nearly self-sufficient; caloric intake, 2,100 calories per day
per capita (1964)
Fishing: catch 91,500 tons (1970), $12.1 million (1970); exports $10.2 million
(1970), imports negligible
Major industries: food processing, textiles, cement, leather and rubber products,
drugs, fishing, petroleum
87
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Electric power: 270,000 kw. capacity (1970 est.); 950 million kw.-hr. produced
(1970), 160 kw.-hr, per capita
Exports: $235 million (f.o.b., 1971 est.); bananas, coffee, cocoa
Imports: $275 million (c.i.f., 1971 est.); agricultural and industrial machinery,
petroleum products, chemical products, transportation and communication
equipment
Major trade partners: U.S. 37%, EC 22%, Japan 14% (1970)
Aid:
economic -- extensions from U.S. (FY46-70), $192.0 million loans, $95.2
million grants; from international organizations (FY46-70), $152.4 million;
from Communist countries (1954-71), $15.4 million loans;
military -- assistance from U.S. (FY49-70), $53.6 million
Monetary conversion rate: 25.25 sucres=US$1 (official selling rate)
Fiscal year: calendar year','321fb92fdd16a74a9b74ea1234b15b01177cd5f5f6dc3b2c0b39108590a4342f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3d99c588e7e5adc81ef0e0b459d488348e606cffe9eab937ad41c7f22a62891',1972,'EG','Egypt','economy',122,'Agriculture: main cash crop -- cotton; other crops -- rice, onions, beans, wheat,
corn, barley; not self-sufficient in food, but agriculture a net earner of
foreign exchange
Major a lepenvaee textiles, food processing, chemicals, petroleum, construction,
cemen
Electric power: 4,350,000 kw. capacity (1971); 10,000 million kw.-hr. produced
(i971), 265 kw.-hr. per capita
89
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Aid:
economic -- Communist countries, $1,900 million in credits through December
1971; U.S., $911.8 million in credits and grants through June 1967
(diplomatic relations and aid suspended June 1967); sizable credits from
international agencies, West Germany, Italy; large grant from Libya since
1969; $250 million annual subsidy from Arab states while canal is closed;
military -- Communist countries, about $2,800 million through December 1971
Monetary conversion rate: | Egyptian pound=US$2. 30 (selling rate); 0.435 Egyptian
pound=US$1 (selling rate)
Fiscal year: 1 July - 30 June','4b4c3d7a93cb2aae98fcf981fa4a32c264370f376c27f4db08d42a209ea371a9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6f178bf302c6f6c9748dcd9457e76c6b9bc25586d28bfb77d55406be32d4205',1972,'SV','El Salvador','economy',126,'GNP: $1.49 billion (purchasing power parity estimate, 1971), $440 per capita;
80% private consumption, 9% government consumption, 11% domestic investment
(1970 est.); real growth rate 1970 est., 4.5%
Agriculture: main crops -- coffee, cotton, corn, sugar, rice, beans; caloric
intake, 2,000 calories per day per capita (1963-64)
Fishing: catch 16,100 metric tons (1969); exports $4.2 million (1969), imports
$0.2 million (1969)
Major industries: food processing, textiles, clothing, petroleum products
Electric power: 172,000 kw. capacity (1970); 740 million kw.-hr. produced
(1970 est.), 220 kw.-hr. per capita
Exports: 228.4 million (f.o0.b., 1971); coffee, cotton, sugar, chemicals,
other manufactures
Imports: $249.2 million (f.0.b., 1971); machinery, automotive vehicles, petroleum,
foodstuffs
Major trade partners: exports -- U.S. 19%, CACM 30%, West Germany 27%, Japan
12%; imports -- U.S. 29%, CACM 29%, West Germany 8%, Japan 10% (1970)
Aid:
economic -- extensions from U.S. (FY46-70), $86.5 million loans, $55.1
million grants; from international organizations (FY49-70), $99.0 million;
from other Western countries (1960-68) $3.7 million;
military -- assistance from U.S. (FY53-70), $6.6 million
Monetary conversion rate: 2.5 colones=US$1 (official)
Fiscal year: calendar year','03567b25426c5a0541691d67ed227d7af6c49cbb6102ba57572bb4c376d2fac0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd6402348ca6f36b028c94c6acef65b8ee47c1fccd8aaac0c51171b27f6001b2',1972,'GQ','Equatorial Guinea','economy',130,'GDP: $40 million (1968 est.); Rio Muni nearly $100 per capita, Fernando Po
about $250 per capita
Agriculture: major cash crops -- Rio Muni, timber, coffee; Fernando Po, cocoa;
main food crops -- rice, yams, cassava, bananas, oi] palm nuts, manioc, and
livestock
Fishing: exports $86,000 (1970)
Major industries: fishing, sawmilling
Electric power: 2,800 kw. capacity (1971); 9 million kw.-hr. produced (1971),
about 30 kw.-hr. per capita
Exports: $24.9 million (1970); cocoa, coffee, and wood
Imports: $21.0 million (1970); foodstuffs, chemicals and chemical products,
textiles
Major trade partner: Spain
Aid: Spain, $14.0 million (1969); Libya, $1 million (1971)
Monetary conversion rate: 64.47 Guinean pesetas=US$1 (official)
93
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','cbbd888b89c8313e1ebbc3b2502b8340d5ea8061513e6c81853bb0d97f5eeff2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('564300b83ef370fb3aee1d08de88ea7ed436930d7116fef0228409d2f2deb32b',1972,'ET','Ethiopia','economy',134,'GDP: $1,629 million (1970 in current prices), $60 per capita; 1970 average annual
growth rate 6.1% (current prices)
Agriculture: main crops -- coffee, teff, durra, barley, wheat, corn, sugarcane,
cotton, pulses, oilseeds, livestock; almost self-sufficient in food
peu haa 6,927 metric tons (1970), $1.4 million (1970); exports $348,000
70
Major industries: cement, sugar refining, cotton textiles, food processing,
oil refinery
Electric power: 206,000 kw. capacity (1971); 453 million kw.-hr. produced
(1971), 18 kw.-hr. per capita
Exports : $122 million (f.0.b., 1970); coffee 59.4%, hides and skins 8.1%, oilseeds,
oilcakes, and nuts 10.3%, pulses 6.1%; $2.0 million to Communist countries (1970)
95
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Imports: $172 million (c.i.f., 1970); machinery and transport equipment 34.3%,
fuels 7.6%, chemicals 11.6%, manufactured goods 34.3%; $10 million
from Communist countries (1970)
Major trade partners: imports -~ Italy, Japan, West Germany, and U.S.;
exports -- U.S., West Germany, Italy, Saudi Arabia, Japan
Monetary conversion rate: 2.3026 Ethiopian dollars=US$1 (official)
Fiscal year: 8 July - 7 July
GDP: $57.1 million (1969), about $1,460 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 173,780 tons (1969); exports $23.6 million
Major industry: fishing
Electric power: 27,500 kw. capacity (1970); 59 million kw.-hr. produced (1970),
1,590 kw.-hr. per capita
Exports: $26.1 million (f.o.b., 1969); fish and fish products
Imports: $34.9 million (c.i.f., 1969); machinery and transport equipment, pet-
roleum and petroleum products, food products
Major trade partners: (1969) Denmark 42%, U.K. 7%, Sweden 4%, U.S. 8%, Norway
_ 13%; EC 10%; EFTA 68%; Communist countries 1%
Monetary conversion rate: 6.98 Danish kroner=US$1
Fiscal year: 1 April - 31 March
97
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','304ef7c66fca12faba9c949886d1150a628256e12ac14d3455e9696e6532df0f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d8ecb185ee5b6c0f10466ba36a5311ca551ff66e4412b6e235ca9d6946c2b11',1972,'FJ','Fiji','economy',138,'Sees an (1970), $370 per capita; 5% (est.) average annual growth rate
Agriculture: main crops -- Sugar, coconut products, bananas, rice; major
deficiency, grains
Major industries: tourism, sugar process ing
Electric power: 47,500 kw. capacity (1971); 145 million kw.-hr. produced (1971),
267 kw.-hr. per capita
Exports: $67.7 million (f.o.b., 1970 excluding reexports); sugar, copra, copper
Imports: $101.8 million (c.i.f., 1970)
Major trade partners: U.K. , Australia, U.S., Japan, New Zealand
Aid: disbursed 1968 -- Australia $1.5 million, U.S. $600,000, U.K. $4.2 million
Monetary conversion rate: 0.87 Fijian dol lar=US $1
Fiscal year: calendar year','8d269bcae41c170b498f96625b3a503a50d7bafa484b8a5d72a1cf25652a0183','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('861c017d54e2207509f56cd4e3b856810ff11c0ca3c61996aa73896d08e2f4ed',1972,'FI','Finland','economy',142,'GNP: $11.2 billion (1971), $2,390 per capita; 53.4% consumption, 29.7%
investment, 17.5% government, -0.6% net exports of goods and services; 197]
growth rate 1.59%, current prices
Agriculture: animal husbandry, especially dairying, predominates; forestry
important secondary occupation for rural population; main crops -- cereals,
sugar beets, potatoes; 85% self-sufficient; shortages -- food and fodder
grains; caloric intake 2,890 calories per day per capita (1968-69)
Major industries: include metal manufacturing and shipbuilding, forestry and
wood processing (pulp, paper), copper refining
Shortages: fossil fuels; industrial raw materials, except wood, and iron ore
Crude steel: 1,168,837 metric tons produced (1970), 250 kilograms per capita
Electric power: 5,200,000 kw. capacity (1971); 22 billion kw.-hr. produced
(1971), 4,185 kw.-hr. per capita
Exports: $2,356 million (f.o.b., 1971); timber, paper and pulp, ships, machinery,
iron and steel, clothing and footwear
Imports: $2,775 million (c.i.f., 1971); foodstuffs, petroleum and petroleum
products, chemicals, transport equipment, iron and steel, machinery, textile
yarn and fabrics
Major trade partners (1970): 25% EC. 41% EFTA, 14% West Germany, 15% U.K...
16% Sweden, 5% U.S., 12% U.S.S.R., 16% Communist countries
Aid: U.S. $158.3 million authorized 1946-70, none in 1968 or 1969, $7.6 million
in 1970; IBRD -- $221.5 million authorized through 1946-68, $22 million in 1969,
$13 million in 1971; Finnish foreign aid programs have amounted to $23 million
1961-69, $15,000 in 1970
Monetary conversion rate: new markka (Fmk) 4,.20=US$1 (official 1970); 4.1=US$1
(official 1971)
Fiscal year: calendar year','e1ae91929138cae9a67958c82b44951273e09f80ff6bc12495b4cae019d38232','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('697bc6ca8971969c04af88b019dce54e0be766138807146c1fcf2c462f60f055',1972,'GF','French Guiana','economy',148,'GNP: $32 million (1966), $840 per capita
Agriculture: main crops -- rice, corn, manioc, cocoa, bananas, sugarcane
Fishing: catch 800 metric tons (1968); exports $2.4 million (1968), imports $2.2
million (1967)
Major industries: timber, rum, gold mining, production of rosewood essence and
space center
Electric power: 18,300 kw. capacity (1970); 54.9 million kw.-hr.
produced (1970), 1,058 kw.-hr. per capita
Exports: $3.4 million (fF. o.b. 1968); shrimp, timber, rum, rosewood essence
Imports: $52.0 million (c.i.f., 1968); food (grains, processed meat), other
consumer goods, producer goods and petroleum
Major trade partners: exports -- U.S. 78%, France 11%, Martinique 5%; imports --
France 72%, U.S. 13%, Trinidad and Tobago 3% (1967)
109
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: 5.1157 francs=US$1
Fiscal year: calendar year
Agriculture: livestock; desert conditions limit commercial crops to about 15
acres
Industry: ship repairs
Electric power: 18,300 kw, capacity (1971); 18 million kw.-hr. produced (1971),
222 kw.-hr. per capita
Imports: almost all domestically needed goods
Exports: hides and skins
Aid: $2.4 million in 1967 from France
Monetary conversion rate: 197.11 Djibouti francs=US$1 (official)
Fiscal year: probably same as that for France (calendar year)','4877a529cf2ca2e579f3806a19dbf32498eb691a034ba3812951e400d8aff6c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf88b8f96b5b3bec73f799f624e81928ebe97ca90fff59575d8ff72a70680605',1972,'GA','Gabon','economy',151,'GDP: $326 million (1970), about $660 per capita; 1967-70 real growth 8% average
annual rate
Agriculture: commercial -- cocoa, coffee, wood, palm oi1, rice; main food crops
-- bananas, manioc, peanuts, root crops; imports food
Fishing: catch 4,000 metric tons (1969); exports $600,000 (1970), imports -- not
available
Major industries: sawmills, petroleum refinery, natural gas, agricultural
processing; mining of increasing importance; major minerals -- manganese,
uranium, gold, and iron :
Electric power: 34,000 kw. capacity (1971); 114 million kw.-hr. produced (1971),
222 kw.-hr. per capita
113
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $174 million (f.o.b., 1970) excluding trade with other members of the
Economic and Customs Union of Central Africa (UDEAC); wood and wood products
about 40%; minerals (manganese, uranium concentrates, gold, crude oil)
Imports: $113 million (c.i.f., 1970) excluding UDEAC trade; mining, roadbui lding
machinery, electrical equipment, transport vehicles, foodstuffs, textiles
Major trade partners: France, U.S., West Germany, and Curacao; preferential
tariffs to EC and franc zone
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; 255.785 CFA francs=U5$1
Fiscal year: calendar year','9f6cdbfdda97ca84393dd41955c719e43a9c4b54204b20ed7edbcc5b010046bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a82228df9caa922875e66e9e164a9570d7efa671f99b34fb5a8f45f776bb008',1972,'GM','Gambia','economy',155,'GDP: $46 million (FY71 est.), about $120 per capita
Agriculture: main crops -- peanuts, rice, palm kernels
Fishing: catch 4,500 tons (1970); exports $94,000 (1970)
Major industry: peanut processing
Electric power: 5,000 kw. capacity (1971); 12 million kw.-hr. produced (1971),
32 kw.-hr. per capita
Expos a Def million (1970); peanuts and peanut products 90% to 95%, palm
ernels
Imports: $17 million (1970); textiles, foodstuffs, tobacco, machinery,
petroleum products
Major trade partners: exports -- U.K.; imports -- U.K. and Japan
Aid: economic -- U.K. (1968-71) about $8 million commitment
115
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: 1.92 Gambian dalasi=US$1 (official)
Fiscal year: 1 July - 30 June','2f89c4151a6b8fb8bf61f1dd994ea2c23728e841eaea6f7f90150ed0b8dd4933','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6179e8fdc95584babfef5a6677a84a1e6b52b20b9b32d4a2cbe2162e6766b8b7',1972,'GH','Ghana','economy',160,'GDP: $2.5 billion (1970) at current prices, about $280 per capita; real growth
rate about 3.6%
Agriculture: main crop -- cocoa; other crops include root crops, corn, sorghum
and millet, peanuts; not self-sufficient, but can become so
Fishing: catch 163,000 metric tons (1969), $35 million
Major industries: mining, lumbering, light manufacturing, fishing, aluminum
Electric power: 675,000 kw. capacity (1971); 2.8 billion kw.-hr. produced
(i971), 320 kw.-hr. per capita
Exports: $424 million (f.o.b., 1970); cocoa (about 76%), wood, gold, diamonds,
Manganese, bauxite, and aluminum (aluminum regularly excluded from balance
of payments data)
12]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Imports: $384 million (c.i.f., 1970); textiles and other manufactured goods,
food, fuels, transport equipment
Major trade partners: U.K., EC, and U.S.
Monetary conversion rate: 1 Cedi=US$0.78 (official); 1.28 Cedi=US$1
Fiscal year: 1 July - 30 June
COMMUNTCATIONS:
Railroads: 599 mi. -- all 3''6" gage; 20 mi. double track; diesel locomotives
gradually replacing steam engines
Highways: 21,350 mi., 3,100 mi, concrete or bituminous surface, 3,750 mi. gravel
or laterite, 3,700 mi. improved earth, 10,800 mi. unimproved earth
Inland waterways: Volta, Ankobra, and Tano rivers provide 145 mi. of perennial
navigation for launches and lighters; additional routes navigable seasonally
by small craft; Lake Volta reservoir provides 700 mi. of arterial and
feeder waterways
Pipelines: refined products, 2 mi.
Ports: 2 major, 1 naval base (Sekondi), 4 minor
Civil air: 6 major transport aircraft
Airfields: 22 total, 19 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 8 with runways 4,000-7 ,999 ft.; 1 seaplane station
Telecommunications: telephone fair to good in urban areas; fairly good telegraph
services; 61,200 telephones; about 703,000 radio receivers; 16,000 TV
receivers; 2 AM, no FM, and 5 TV stations; 2 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $38,300,000; 3.5% of
total budget
122
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','a9a74637133d02e52b7fcbab287b3bbb71fa2950a636eda24e4fbdb01929b1b3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9729e332fd04d4d102b0553a10c9493b5ba72fec96b185a4f5768aa27277785',1972,'GI','Gibraltar','economy',161,'LAND:
2.5 sq. mi.
Land boundaries: 1 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 7.5 mi.','ca66c786ff38e2fc2527ea8278641b01255c00fe133be6903cf77df048ea5fee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9955e147061c8f3f3692fb2f3f7045fff5785de3393b668e137cdc62647390f',1972,'GR','Greece','economy',166,'GNP: $9.3 billion (1970), $1,040 per capita; 78% consumption, 22% investment;
1970 growth rate 9.1%, 1958 constant prices
125
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Agriculture: subject to droughts; main crops -- wheat, olives, tobacco, cotton;
nearly self-sufficient; food shortages -- livestock products; caloric intake,
2,960 calories per day per capita (1963)
Major industries: food processing, tobacco, chemicals, textiles, petroleum
refining, aluminum processing
Shortages: petroleum, minerals, feed grains
Crude steel: 210,000 metric tons produced (1969), 20 kg. per capita
Electric power: 2,810,000 kw. capacity (1971); 10.78 billion kw.-hr. produced
(1971), 1,094 kw.-hr. per capita
Exports: $612 million (f.0.b., 1970}; principal items -- tobacco, cotton, fruits,
metals
Imports: $1,696 million (c.i.f., 1970); principal items -- machinery and
automotive equipment, manufactured consumer goods, petroleum and
petroleum products, chemicals
Major trade partners: (1970) imports -- 43% EC, 14.5% sterling area, 15% U.S.,
6.4% CEMA countries; exports -- 40.4% EC, 10.7% sterling area, 15.6% U.S.,
16.5% CEMA countries
Aid:
economic (authorized) -- U.S., $1,887 million (1946-70), $4 million in 1970;
International Finance Corporation, $14.9 million through 1970; U.N. Technical
Assistance, $3.9 million through 1970; U.N. Special Fund, $8.2 million through
1970; IBRD, $32.5 million (1968-70), $20 million in 1970; Consortium, $40
million in 1966; EC (1964-70) $69.2 million;
military -- U.S., $2,020 million (1946-70)
Monetary conversion rate: 30 drachmae=US$1 (official)
Fiscal year: calendar year','6ad5f049820945fb3ca18b73ef230bab8d873be20229225876f9fd4203b0e11e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfd935686204ed5a71a27a9532007449f58b18662da6243081073ee19a38420d',1972,'GL','Greenland','economy',170,'GNP: included jn that of Denmark
Agriculture: arable areas largely in hay; sheep grazing; garden produce
Fishing: catch 39,200 tons, $4.5 million (1969)
Major industries: mining, slaughtering, fishing, sealing
Electric power: 25,000 kw. capacity (1970); 49 million kw.-hr. produced (1970),
580 kw.-hr. per capita
Exports: $2.62 million (f.o.b., 1969); fish and fish products, nonmetallic minerals
Imports: $54.0 million (f.o.b., 1969); machinery and transport equipment,
petroleum and petroleum products, food products
Major trade partners: (1968) Denmark 86%, U.S. 4%, Venezuela 5%
Monetary conversion rate: 6.98 Danish Kroner=US$1
Fiscal year: 1] April - 31 March','a46477d6c4a182641385840dcd6a17f374cc5ed56f23bcd6f824af7b5619ca7a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae57a0c879a190c228c2e67a413b9dbef64aac00866ab552fe706dff8065c6b9',1972,'GN','Guinea','economy',179,'GDP: about $275 million (1965), $80 per capita
Agriculture: cash crops -- coffee, bananas, palm products, peanuts, and pine-
apples; staple food crops -- cassava, rice, millet, corn, sweet potatoes;
livestock raised in some areas
er Pages, alumina, light manufacturing and processing industries,
auxite
Electric power: 99,700 kw. capacity (1971); 239 million kw.-hr. produced (1971),
60 kw.-hr. per capita
Exports: export receipts, $56 million (FY69-70); alumina, bauxite, coffee,
pineapples, bananas, palm nuts
Imports: $66 million (FY69-70); petroleum products, metals, machinery and
transport equipment, foodstuffs, textiles
135
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major trade partners: Communist countries, Western Europe (including France),
U.S.
Monetary conversion rate: 227 Guinea francs=US$1
Fiscal year: 1 October - 30 September
COMMUNIECATIONS:
Railroads: 500 mi. meter gage, 5 mi. standard gage
Highways: 6,000 mi.; 300 mi. paved, 2,000 mi. all weather, 3,700 mi. seasonal
(dry)
Inland waterways: 1,115 mi.; 310 mi. navigable by small oceangoing vessels,
805 mi. navigable by shallow-draft steamers and barges
Ports: 1] major, 2 minor
Civil air: 5 major transport aircraft
Airfields: 20 total, 16 usable; 1 with permanent-surface runway; 3 with runways
8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: limited telephone service; fair telegraph facilities;
6,500 telephones; 91,000 radio receivers; 1 AM, no FM, and no TV stations;
3 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1970, $6,073,000; 8.0%
of total budget
136
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','5d313398d232fbbff9eae75fc5cc4136d7b203f4838a0b464da2acdb1c6d316f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0cc102fe9da0a51313fd103c18cac0e040b792c84faf5fa7dce4470076584c4',1972,'GY','Guyana','economy',180,'LAND:
83,000 sq. mi.; 1% cropland, 3% pasture, 9% savanna,
77% forested, 10% water, urban, and waste (1968 est.)
Land boundaries: 1,600 mi.
WATER: ;
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 285 mi.
GNP: $270 million (1971 est.), $340 per capita; real growth rate 197] {est.) 3%
Agriculture: main crops -- sugarcane, rice, other food crops; food shortages --
wheat flour, potatoes, processed meat, dairy products; caloric intake, 2,180
calories per day per capita (1967)
Fishing: catch 16,600 metric tons, $12 million (1970); exports $4.8 million (1970),
imports $1.5 million (1970)
137
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major industries: bauxite mining, alumina production, sugar and rice milling
Electric power: 112,000 kw. capacity (1970); 448 million kw.-hr. produced
(1970), 600 kw.-hr. per capita
Exports: $141 million (f.o.b., 1971); bauxite, sugar, alumina, rice, shrimp,
molasses, timber, diamonds, rum
Imports: $135 million (c.i.f., 1971); manufactures, machinery, food, petroleum
Major trade partners: U.K. 28%, U.S. 23%, Canada 14%, Commonwealth Caribbean
countries 13% (1969)
Aid: economic -- extensions from U.S. (1953-70), $41.1 million loans, $21.3
million grants; from international organizations (FY46-70), $19.0 million
Monetary conversion rate: 2 Guyana dollars=US$1
Fiscal year: calendar year','4d076f5ba881841947780203ffd78ac07ab20a3a67ff63156b0f9c73f6b3bab6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50350ee69337190821790427acfcc0dc01d3c4840647f9feb47ab79a97ebda6d',1972,'HT','Haiti','economy',187,'GDP: about $380 million (1970), $80 per capita; economy has been stagnant in
recent years, but some growth probably occurred in 1969-7]
Agriculture: main crops -- coffee, sugarcane, rice, corn, sorghum, pulses;
caloric intake, 1,850 calories per day per capita
Major industries: sugar refining, textiles, flour milling, cement manufacturing,
copper and bauxite mining, tourism
Electric power: 49,000 kw. capacity (1971); 91 million kw.-hr produced (1971 est.),
17 kw.-hr. per capita
Exports: $40 million (f.o.b., 1970 est.); coffee, bauxite, light industrial
products, sisal, sugar, copper
139
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Imports: $42.0 million (f.o.b., 1970 est.); wheat, fish, vegetable oils, textiles,
petroleum products, industrial equipment, medical supplies, construction
materials
Major trade partners: U.S. 59%, EC 15%, Japan 6% (1967 est.)
Aid:
economic -- extensions from U.S.. $34.1 million loans, $84.2 million grants
(FY46-70); international organizations, $26.0 million (FY49-70);
military -- U.S.. $4.3 million (FY53-63)
Monetary conversion rate: 5 gourdes=US$1
Fiscal year: 1 October - 30 September','9704ed6d8e47523ed533e99c158f4fd80de731386fc26f08e36a5d6813618b2d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efd9f72d8ccaa51efc7dba564af280c36116bcb0728fcb15dbf384a308b8ad90',1972,'HN','Honduras','economy',191,'GNP: $838 million (purchasing power parity estimate, 1971), $310 per capita; 77%
private consumption, 9% government consumption, 19% domestic investment; 2%
inventory, -7% net foreign balance (1970); real growth rate 1971, 2.5%
Agriculture: main crops -- bananas, coffee, corn, beans, cotton, sugarcane,
tobacco; caloric intake, 2,300 calories per day per capita (1964-65)
141
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Fishing: exports $1.4 million (1970); imports $0.5 million (1970)
Major industries: agricultural processing, textiles, clothing, wood products
Electric power: 113,000 kw. capacity (1970 est.); 310 million kw.-hr. produced
(1970 est.), 112 kw.-hr. per capita
Exports: $182 million (f.o.b., est. 1971); bananas, coffee, corn, cotton, lumber,
minerals, beef
Imports: $194 million (c.i.f., est. 1971); manufactured products, machinery,
transportation equipment, chemicals, fuels
Major trade partners: exports -~- U.S. 53%, West Germany 11%, CACM 11%; imports
-- U.S. 41%, CACM 25%, West Germany 5% Japan 8% (1970)
Aid:
economic -- extensions from U.S. {FY46-70), $65.6 million loans, $54.8
million grants; from international organizations (FY46-70), $132.6 million;
from other Western countries (1960-68) , $5.3 million;
military -- assistance from U.S. (FY46-70), $8.1 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year','379908bb8d9f2b2f67fdfa1d5806bf24e8bef9557d641baf4282a00ee8197b4e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e383bb51f29315ef46699d82bd8016a0f48efadcaafaa63a3bf5e0583d115697',1972,'HK','Hong Kong','economy',195,'GNP: $4 billion 1971 (est.), $960 per capita (est.)
Agriculture: agriculture occupies a minor position in the economy; main crops --
rice, vegetables, dairy products; less than 20% self-sufficient; food
shortages -- rice, wheat
Major industries: textiles and clothing, tourism, plastics, electronics, light
metal products, food processing
143
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Shortages: industrial raw materials, water, food
Electric power: 1,487,500 kw. capacity (1971); 4.6 billion kw.-hr. produced
(1971), 1,102 kw.-hr. per capita
Exports: $3.0 billion (f.o.b., 1971), including $630 million reexports; principal
products clothing, plastic articles, textiles, electrical goods, wigs,
footwear, light meta] manufactures
Imports: $0.5 billion {c.i.f., 1971)
Major trade partners: 1971 exports -- U.S. 37%, U.K. 15%, West Germany 7%; imports
-- Japan 24%, China 16%, U.S. 13%
Monetary conversion rate: HK$5.9=US$1
Fiscal year: 1 April - 31 March','eb01ce5599a3482eec24ec4b6fdd0dfd538d897fdaf85dd1fb5f627ee0d28ec9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4b2bdbdeb3c96a42b86d3b72ae94927787e7cd62e265636214013af6c1a4978',1972,'LY','Libya','economy',198,'GNP: $16.7 billion in 1971 (at 1970 prices), $1,610 per capita; 1971 growth
rate 4.6%
Agriculture: normally self-sufficient; main crops -- corn, wheat, potatoes,
sugar beets, wine grapes; caloric intake 3,140 calories per day
per capita (1970)
Major industries: mining, metallurgy, engineering industries, processed foods,
textiles, chemicals (especially pharmaceuticals)
Shortages: metallic ores (except bauxite), copper, high grade coal, forest
products
Crude steel: 3.11 million metric tons produced (1971), 300 kg. per capita
145
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $2,500 million (f.0.b., 1971); 26% machinery, 23% industrial consumer
goods, 27% raw materials and semimanufactures, 24% food and raw materials
for the food industry (distribution for 1971)
Imports: $2,990 million (1971); 26% machinery, 9% industrial consumer goods,
54% raw materials and semimanufactures, 11% food and raw materials for the
food industry (distribution for 1971)
Major trade partners: $5,490 million (1971); 67% with Communist countries, 35%
with non-Communist countries
Monetary conversion rate: 11.74 forints=US$1 (arbitrary commercial); 27.63
forints=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data reported for calendar years
eae ee (1970 est.), $1,500 per capita, approximately constant over
GDP: $3.5 billion (1970 est.), $1,800 per capita
Agriculture: main crops -- wheat, barley, olives, dates, citrus fruits, peanuts;
not self-sufficient in food
189
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major industries: petroleum production averaged 2.8 million b.p.d. (1970);
astimated oi] revenues for FY71 about $2.0 billion; food processing,
textiles, handicrafts
Electric power: 300,000 kw. capacity (1971); 800 million kw.-hr. produced (1971),
390 kw.-hr. per capita
Exports: $2,541 million (1970); over 99% petroleum
Imports: $1,640 million (1970 est.)
Major trade partners: imports -- Italy, West Germany, U.S.
Mid: economic -- $17.4 (FY52-70); no Communist country assistance; U.S. aid
extended $212.6 million (1949-70)
military -- arms obtained by cash purchase; chief suppliers France, U.S.S.R.,
Czechoslovakia; U.S. suspended since September 1969
Monetary conversion rate: 1 Libyan pound=US$3.04 (January 1972)
Fiscal year: 1 April - 3) March','caa20674f2539b9836ab5e6cc4f77f6d7710bf777f691149735f176b400679ab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a9922d9ecf4cf8adc3c5af94a70183ec4849a92cdbc62278408cd090d4706e4',1972,'IS','Iceland','economy',202,'GNP: $591 million (1971), $2,830 per capita; 65.3% consumption, 32.5%
investment, 9.8% government, -7.6% net foreign balance (1971); 1971 growth
rate 9.20%, 1970 constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes, turnips; food shortages --
grains, sugar, vegetable and other fibers; caloric intake, 2,900 calories
per day per capita (1964-66)
147
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Fishing: catch 729,300 metric tons; exports $114.6 million (1970)
Major industries: fish processing, aluminum smelting, diatomite production
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 356,000 kw. capacity (ov): 1.6 billion kw.-hr. produced
(ov), 7,700 kw.-hr. per capita
Exports: $149.7 million (f.0.b., 1971); fish and fish products, animal products,
aluminum, diatomite
Imports: $220.0 million (c.i.f., 1971); machinery and transportation equipment,
petroleum, foodstuffs, textiles
Major trade partners: (1971) Exports: EFTA 33%, EC 11%, U.S. 39%, Communist
countries 8%; Imports: EFTA 43%, EC 26%, U.S. 9%, Communist countries 11%
Aid: economic -- U.S. authorized (1949-70) $89.3 million, $2.0 million
(1968) $2.3 million (1969), none in 1970; IBRD $30.0 million through
December 1971
Monetary conversion rate: 88 kronur=US$1 (official)
Fiscal year: calendar year','1517cb581d2a875d0578aaec1758f0260078041473e37b9438ee49314571a266','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d04e4142c5428e990e5f362a49eca164163b3515c85fd467a25623a00d95ab3a',1972,'IN','India','economy',206,'GNP: $54 billion in current prices (year ending 31 March 1972}, less than $100
per capita; real growth (1971), 3.5% est.
Agriculture: main crops -- rice, other cereals, pulses, oilseeds,
cotton, jute, sugarcane, tobacco, tea, and coffee; largely self-sufficient
in foodgrains, but caloric intake is still low and diet is deficient in
protein
Fishing: catch 1.6 million tons (1970), $275 million (1969); exports 26.9 million
(1969), imports $61 thousand (1969)
Major industries: textiles, food processing
Crude steel: 5.8 million metric tons produced (1971)
Electric power: 16,850,000 kw. capacity (1971); 62 billion kw.-hr. produced
(1971), 110 kw.-hr. per capita
Exports: $2 billion (f.o.b., FY70); tea, jute manufactures, iron ore, cotton
textiles, leather and leather products, iron and steel
Imports: $2.2 billion (c.i.f., FY70); machinery and transport equipment, grains
and flour
Major trade partners: U.S., U.K., U.S.S.R. and Eastern Europe, Japan
Monetary conversion rate: 7.5 rupees=US$1
Fiscal year: 1 April, stated year - 31 March','f3c8b41e7b54a09e373f5d1a5e01a49e7433d61e4db3ece405dc5804ff77777d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd2a44f2df7a56575f329dac3f8bab90081fe6af3707a7a8c71244cb1de75048',1972,'IE','Ireland','economy',210,'GNP: $4,830 million (1971), $1,630 per capita; 67% consumption, 22%
investment, 14% government; -4% net export of goods and services;
1971 real growth rate 3% est.
Agriculture: about 2/3 of agricultural area used for permanent hay and pasture;
main products -- livestock and dairy products, barley, potatoes, sugar beets,
wheat; 85% self-sufficient: food shortages -- grains, fruits, vegetables;
caloric intake 3,450 calories per day per capita (1968)
Fishing: catch 66,200 tons, $13.7 million (1969); exports of fish and fish products
$6.7 million (1968), imports of fish and fish products $6.2 million (1968)
157
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d): ; ;
Major industries: food products, brewing, textiles and clothing, machinery and
transportation equipment
Shortages: coal, petroleum, timber and woodpulp, steel and nonferrous metals,
fertilizers, cereals and animal feeds, textile fibers and textiles
Crude steel: 67,000 metric tons produced in 1968, 20 kilograms per capita
Electric power: 1,551,000 kw. capacity (1970); 5,921 million kw.-hr. produced
(1970), 1,990 kw.-hr. per capita
Exports: $1,408 million (f.0.b., 1971); live animals, meat, textile products,
clothing, machinery, dairy products, chemicals
Imports: $1,962 million (c.i.f., 1971); machinery, chemicals, textiles,
transportation equipment, petroleum, metal manufactures, cereals
Major trade partners: 14.5% EC, 5.4% West Germany, 62.7% EFTA, 58.4% U.K., 8.24 U.S..
1.5% Communist countries (1970)
Aid: economic -- U.S.. $193 million authorized (FY49-70), no activity (FY55-66) ,
$46.5 million authorized (FY67-70), $14.7 million authorized in FY69, none
authorized in FY70; IBRD $14.5 million authorized (FY69), none authorized in
FY70
Monetary conversion rate: 3 Irish pound=US$2.60 (official)
Fiscal year: 1 April - 31 March','cc7b0a8d125a379b0bbc1cc2c4129e43cce887978a8d6742342ec97db667fcc2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77b934a89b3bb24000479dadf7d7386989e46a5bdde8c5fcf5a5035a399a521f',1972,'IT','Italy','economy',214,'GNP: $108 billion (1971), $2,000 per capita; 63.6% consumption, 20.9% investment,
13.7% government, net. foreign balance 1.8% (1971 provisional); 1971 provisional
growth rate 1.4%, 1963 constant prices
Agriculture: important producer of fruits and vegetables; main crops -- cereals,
potatoes, olives; 95% self-sufficient; food shortages -- fats, meat, fish,
and eggs; caloric intake, 3,100 calories per capita (1970)
Fishing: catch 353,100 metric tons (1969), $196,558,000 (1969); exports $8,142,000
(1969), imports $131,715,000 (1969)
Major industries: machinery and transportation equipment, iron and steel,
chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 17.4 million metric tons produced (1971), 320 kilograms per capita
Electric power: 35 million kw. capacity (1971); 120 billion kw.-hr.
produced (1971), 2,200 kw.-hr. per capita
Exports: $16.1 billion (f.0.b., 1971); principal items -- machinery and
transport equipment, textiles, foodstuffs, chemicals
Imports: $17.0 billion (c.i.f., 1971); principal items -- machinery and
transport equipment, foodstuffs, ferrous and nonferrous metals, wool, cotton
Major trade partners: (1971) 21% West Germany, 9% U.S., 14% France, 4% U.K...
4% Belgium-Luxembourg, 5% Netherlands, 3% Switzerland; 44% EC; 12% EFTA; 6%
Communist countries
Aid:
economic -- U.S., $3,893 million (FY46-70), $121.8 million authorized FY70;
IBRD, $398 million authorized through FY70, none since FY65; International
Finance Corporation, $1 million authorized through FY70, none since FY60;
military -- U.S., $2,290 million (FY46-70), $38 million authorized in
FY68 (Export-Import Bank credits), none in FY69
Monetary conversion rate: 581.5 lira=US$1 (central rate)
Fiscal year: calendar year
GDP: $1.6 billion (1971), $312 per capita (1971); average annual growth
rate 1960-70, 8.3% :
Agriculture: commercial -- coffee, wood, cocoa, bananas, pineapples, palm oi1;
food crops -- corn, millet, yams, rice; other commodities -- cotton, rubber,
tobacco, fish; self-sufficient in most foodstuffs, but rice, sugar, and meat
imported
Fishing: catch 70,000 metric tons (1970), $12.7 million (1969); exports $1.6
million (1969), imports $1.9 million (1969)
165
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major industries: food and lumber processing, oi] refinery, automobile assembly
plant, texiltes, soap, flour mill, matches, three small shipyards, fertilizer
plant, and battery factory
Electric power: 180,000 kw. capacity (1971); 540 million kw.-hr. produced (1971),
128 kw.-hr. per capita
Exports: $470 million (f.0.b., 1970); coffee, tropical woods, cocoa, 76% of total;
bananas, pineapples, palm oi]
Imports: $389 million (c.i.f., 1970); consumer goods 44%, raw materials and fuels
8%, manufactured goods and semi-finished products, 48%
Major trade partners: France and other EC countries about 65%, U.S. 13%, Conmunist
countries about 1%
Aid:
economic -- France (1960-69) $312 million; EC $123 million, including 1971
commitments; U.S. (FY61-70), $85.6 million; others (1960-71), $76 million,
including $18.5 million comitted:; no Communist aid programs
military -- non-Communist countries, $7.3 million (1954-67)
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; 255.78 CFA francs=US$1
Fiscal year: calendar year','87aaa4bf0a9186a4ce41acc000b2580995e69cba994ca2790925ec601839ca8c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70cbdef8cf86cee4c88da868b2f1a8ce5391990e5d94415965a8f303c478706d',1972,'JM','Jamaica','economy',219,'GNP: $1,300 million est. (1971), $680 per capita; real growth rate 1969, 4%
Agriculture: main crops -- sugarcane, citrus fruits, bananas, pimento, coconuts,
coffee, cocoa
Major industries: bauxite, textiles, food processing, light manufactures, tourism
167
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Electric power: 550,000 kw. capacity (1971 est.); 1,550 million kw.-hr. produced
(1970), 780 kw.-hr. per capita
Exports: $370 million (f.o.b., 1971); alumina, bauxite, sugar, bananas, citrus
fruits and fruit products, rum, cocoa
Imports: $550 million (c.i.f., 1971); machinery, transportation and electrical
equipment, food, fuels, fertilizer
Major trade partners: exports -- U.S. 52%, U.K. 16%, Canada 8%, Norway 8%;
imports -- U.S. 43%, U.K. 19%, Canada 9% (1970)
Aid:
economic -- extensions from U.S. (FY56-70), $43.2 million in loans; (AID
$10.7 million, Import-Export Bank $32.5 million), $38.4 million grants (AID
technical assistance $14.2 million, Food for Freedom $24.2 million); from
international organizations (FY46-70), $55.6 million; from other Western
countries (FY46-69), $63.4 million;
military -- assistance from U.S. (FY63-70), $1.1 million
Monetary conversion rate: 1 Jamaican dollar=US$1.30
Fiscal year: 1 April - 31 March','9ac2d08daa319f1c4698122fb378e1bdf8a932e8430146c69b628677459866f7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('928001a002aaf0ae1872e1c05f50dd77adf4b9bf66ae0e175880235741da305c',1972,'JO','Jordan','economy',223,'GNP: $570 million (1971 est.), $240 per capita
Agriculture: main crops -- cereals, fruits, vegetables, olive oil; not self-
sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining, and cement
Electric power: 46,260 kw. capacity (1971); 131 million kw.-hr. produced (1971),
60 kw.-hr. per capita
Exports: $34 million (f.0.b., 1970); major items -- fruits and vegetables,
phosphate rock; Communist share 9% of total (1970)
Imports: $183 million (c.i.f., 1970); major items -- petroleum products, textiles,
capital goods, motor vehicles, foodstuffs; Communist share 16% of total (1970)
Aid:
economic -- U.S., $601 million economic assistance (FY51-70), of which $31
million loans, $570 million grants; technical assistance
military -- $191 million total from U.S. (July 1949-March 1971) including
$72 million in MAP grants
Monetary conversion rate: 1 Jordanian dinar=US$2.80, freely convertible; 0.357
Jordanian dinar=US$1
Fiscal year: 1 January - 31 December','0aa9625faf3207b7a7dab9c9f0c292b6a4ed0d068dad5ec950b8b351b215686a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('764981e1c82a4d588ac655ac5ce80a07e62d00a8ec3211379a6e229ec790e4bf',1972,'KE','Kenya','economy',227,'GNP: $1.45 billion (1970), $130 per capita; 6.3% real growth per year between
1964 and 1970
Agriculture: main cash crops -~ coffee, sisal, tea, pyrethrum, cotton, livestock;
food crops -- corn, wheat, rice, cassava; largely self-sufficient in food
Fishing: $4.2 million (1970)
Major industries: small-scale consumer goods (plastic, furniture, batteries,
textiles, soap, agricultural processing, cigarettes, flour), oi] refining,
cement
Electric power: 198,000 kw. Capacity (1971); 515 million kw.-hr. produced (1971),
43 kw.-hr. per capita
173
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $304.6 million (f.o.b., 1970); coffee, tea, livestock products, pyrethrum,
soda ash, wattle-bark tanning extract
Imports: $442.4 million (c.i-f., 1970); machinery, transport equipment, crude oil,
paper and paper products, jron and steel products, and textiles
Major trade partners: U.K. and EC, also Uganda and
Tanzania, which are part of East African Economic Community
Monetary conversion rate: | Kenya shilling=US$0.14 (official); 7.143 Kenya
shillings=US$1
Fiscal year: 1 July - 30 June
GNP: roughly $300 per capita (1971)
Agriculture: main crops -- rice, corn, vegetables; food shortages -- meat,
cooking oils; production of foodstuffs adequate for domestic needs at low
levels of consumption
oe Urea machine building, electric power, chemicals, mining, metallurgy,
extiles
Sr cages heavy machinery and equipment, bituminous and coking coal, petroleum,
rubber
Exports: minerals, chemical and metallurgical products
Imports: machinery and equipment, petroleum, foodstuffs, coking coal
Major trade partners: total trade turnover about $735 million (1971); 16% with
non-Communist countries, 84% with Communist countries (53% with the U.S.S.R.)
Monetary conversion rate: 2,37 won=US$1 (arbitrarily established)
Fiscal year: calendar year
175
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
GNP: $8.7 billion (1971), $270 per capita; real growth 11% (1965-71)
Agriculture: 50% of the population live on the land, but agriculture constitutes
97% GNP; main crops -- rice, barley, wheat; not self-sufficient; food
shortages -- barley, wheat, dairy products, rice, corn
Fishing: catch 1,031,160 tons, $173 million (1970)
Major industries: textiles and clothing, food processing, chemical fertilizers,
chemicals, plywood, coal
Shortages: base metals, fertilizer, petroleum, lumber and certain food grains
Electric power: 2,333,000 kw. capacity (1971); 10.54 billion kw.-hr. produced
(1971), 334 kw.-hr. per capita
Exports: $1.1 billion (f.0.b., 1971); clothing and textiles, veneer and plywood,
silk, wigs
Imports: $2.4 billion (c.i.f., 1971)
Major trade partners: 1971 exports -- U.S. 50%, Japan 24%; imports -- Japan
40%, U.S. 28%
Aid:
economic -- U.S. (FY46-70), $5.1 billion extended; Japan (1965-70), $620
million comitted;
military -- U.S. (FY46-70), $3.1 billion extended
Monetary conversion rate: 358.75 won=US$1 (floating-rate average value in 1971),
373 won=US$1 by end of December 1971
Fiscal year: calendar year','423885c22c87b0dc279358ad43f07d7b27e4e5b3b97635a90d5e462dde3658e9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2afafbf7d3042bcfa1019ecabd6d0502fff6622d215d5efc7a7d540b104b5fc',1972,'KW','Kuwait','economy',230,'OPEC, OAPEC. Seabeds Committee, U.N., UNESCO, UPU. WHO. WMO
Agriculture: virtually none, dependent on imports for food; approx. 75% of
potable water must be distilled or imported
Major industries: crude petroleum production averaging 3.2 million b.p.d.
(includes Kuwait''s share of neutral zone) (1971); government revenues from
taxes and royalties on production, refining, and consumption was $960 million
in FY70; refinery capacity est. at 504,000 bbls. per day (1970); other major
industries include fishing, processing of building materials, fertilizers,
chemicals, and flour
Electric power: 1.2 million kw. capacity (1970); 2.3 billion kw.-hr. produced
(1970), 2,800 kw.-hr. per capita
Exports: $1,580 million (1970), of which petroleum accounted for about 98%;
nonpetroleum exports are mostly reexports
Imports: $625 million (1970) exclusive of of] company imports; major suppliers --
U.S., Japan, U.K., West Germany
Aid: $50 million loan from Export-Import Bank, 1967; $2.6 million from international
organizations (FY63-70); extended about $50 million
in credits to other Arab nations from 1961 to January 1969
Monetary conversion rate: 1 Kuwaiti dinar=US$2.80 (freely convertible)
Fiscal year: 1 April - 31 March
179
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
GNP: $211 million, $70 per capita (1969 est.)
Agriculture: main crops -- rice (overwhelmingly dominant), corn, coffee, cotton
and tobacco; largely self-sufficient; food Shortages (due in part to
distribution deficiencies) including rice
18]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Fishing: catch data unavailable; imports fish and fish products 200 tons,
$128,000 (1970)
Major industries: tin mining, timber
Shortages: capital equipment, petroleum, transportation system
Electric power: 53,200 kw. capacity (1971); 40 million kw.-hr. produced (1971),
13 kw.-hr. per capita
Exports: $3.5 million (f.o.b., 1970); tin concentrates; forest products, coffee,
undeclared exports of opium significant but value unknown
Imports: $55.7 million (c.i.f., 1970); rice and other foodstuffs, petroleum
products, machinery, transportation equipment, textiles
Major trade partners: imports from Thailand, Japan, U.S., France, U.K., Indonesia,
Hong Kong; exports to Malaysia and Thailand; trade with Communist countries
insignificant; Laos a major transit point in world gold trade; gold imports
and approx. offsetting gold exports excluded from official trade data; value
of 1970 gold imports $46.6 million
Monetary conversion rate: 240 kip=US$1; open market rate approx. 600 kip=US$1
(1971); all but restricted list of developmental commodities now imported
at open market rate
Fiscal year: 1 July - 30 June','4727bbd9ee658a2de03c18d31ff4c05e23a662a69270506f88fed0b0c33608aa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b78325e78c465149b0019fcb6fc756a64a9469c0ab3159a960b3122b998723b5',1972,'LB','Lebanon','economy',235,'tobacco, olives, onions; not
Agriculture: fruits, wheat, corn, barley, potatoes,
self-sufficient in food ; ;
Major industries: service industries, food processing, textiles, cement, oil
refining, chemicals, some metal fabricating, tourism
Electric power: 804,500 kw. capacity (1971); 1,378 million kw.-hr. produced
(971), 472 kw.-hr. per capita
Major trade partners: exports $184 million (f.o.b., 1970); most to Arab
countries; imports $559 million (c.i.f., 1970); chiefly from EC, U.K.,
and Arab countries; trade deficit covered by large net receipts from
invisibles (particularly tourism and transportation) and private capital inflow
Monetary conversion rate: | Lebanese pound=US$0.29 as of March 1972
Fiscal year: calendar year','d5b8c856d181c90e5b3fe3e102360645e7f6f222086d130ca1a0f0a7f23f019f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e12f2ebdc4cdf60ed1c397e0b5084278230d20782e430a2bfa154bb673c3677d',1972,'LS','Lesotho','economy',239,'GNP: $90 million (1968), about $100 per capita
Agriculture: exceedingly primitive, mostly subsistence farming and livestock;
principal crops are corn, wheat, pulses, sorghum, barley
Major industries: none
Electric power: 2,820 kw. capacity (1971); 3 million kw.-hr. produced (1971),
3 kw.-hr. per capita
Exports: labor to South Africa (remittances $15 million in 1969); $5 million
(f.0.b., 1970), wool, mohair, wheat, cattle, diamonds, peas, beans, corn,
hides, skins
Imports: $32 million (f.0.b., 1970); mainly corn, building materials, clothing,
vehicles, machinery, POL
185
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major trade partner: South Africa
Aid: economic aid; U.K. $9.4 million (plan FY71-75); other $17.5 million (plan
FY71-75); no military aid
Monetary conversion rate: Lesotho uses the South African rand; 1 SA rand=US$1.33
(official); 0.75 SA rand=US$1
Fiscal year: 1 April - 31 March','db2e42f1061ef4913047db4a6f591785a74c0a10a6b58c3e8f1be1784dd30cf4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5856e106bf2e7d45bc430a94032d7df877aff1960a22b45a0d1818e5e465c27',1972,'LR','Liberia','economy',243,'GDP: $450.3 million (1970), 5.3% current growth rate, $360 per capita
Agriculture: rubber, oi] palm, cassava, coffee, rice; imports of rice, wheat,
and meat are necessary for basic diet
Fishing: catch 18,500 metric tons, $6.1 million (1969)
Industry: rubber processing, food processing, construction materials, furniture,
palm oi] processing, mining (iron ore, diamonds), 10,000 b/d oil refinery
Electric power: 152,000 kw. capacity (1971); 540 million kw.-hr. produced (1971),
470 kw.-hr. per capita
Exports: $214 million (f.o.b., 1970); iron ore, diamonds, rubber, palm kernels,
coffee, cocoa
Imports: $150 million (c.i.f., 1970); machinery, transportation equipment,
foodstuffs, manufactured goods
Major trade partners: U.S.. West Germany, Japan, U.K.
Aid:
economic -- (FY62-70) U.S.. $158.3 million;
military -- (FY62-70) U.S.. $6.8 million; other aid sources include IBRD,
U.N., IMF, and West Germany
Monetary conversion rate: Liberia uses U.S. currency
Fiscal year: calendar year','67e1c9ffcd4e9f8b6a72fbeb79c9cafb032796a5366025815b1de41e3b23c667','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4657b155c2bdd15f940bbaaa6bd424f8c41411c364514c640adab3b2a0046471',1972,'LI','Liechtenstein','economy',247,'Despite its small size and sparse natural resources, Liechtenstein has a
prosperous economy based primarily on small-scale light industry and farming.
Textiles, ceramics, precision instruments, pharmaceuticals, and canned foods
are the principal manufactures produced, almost entirely for export. Live-
stock raising and dairying are.the main sources of farm income; cereals and
potatoes are the most important farm crops. The Liechtenstein economy is
tied closely to that of Switzerland in a virtual customs union. No national
accounts data are available.
Major eae partners: exports (1967) -- $45.5 million; 41% Switzerland, 28% EC,
56.1% EFTA
Electric power: 22,600 kw. capacity (1970); 55 million kw.-hr. produced (1970),
1,800 kw.-hr. per capita; power is exchanged with Switzerland, but net
exports average 35 million kw. yearly','4af94693cdf5d11cf661a86a992a5176613eceb1035345887ca34b7558bc59ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('151361bd7b5c6b52cbd14cfea4b8b4ab8d6c9e0a9d583ecbbc4f5b05920aed75',1972,'LU','Luxembourg','economy',252,'GNP: $995.7 million (1970), $2,910 per capita; 56.4% consumption, 29.8% investment,
11.0% government, 2.8% net exports of goods and services, 1970 growth rate
3.5% at 1963 constant prices
Agriculture: mixed farming; main crops -- grains, potatoes, fodder beets; food
shortages -- sugar, bread grains, fats; caloric intake, 3,150 calories per
day per capita (1968-69)
Major industries: iron and steel, food processing, chemicals, metal products and
engineering, tires
Shortages: crude petroleum, coal, textile materials
Crude steel: 5.5 million metric tons produced (1970), about 16,080 kg. per capita
Electric power: 1,177,000 kw. capacity (1970); 2,520 million kw.-hr. produced
(1970), 6,290 kw.-hr. per capita
Exports: $869.0 million (f.o.b., 1970)
Imports: $686.4 million (c.i.f., 1970)
Major trade partners: Luxembourg and Belgium form an economic and customs union
and report their foreign trade jointly (see Belgium); Luxembourg''s principal
exports are iron and steel products; principal imports are coal and consumer
products; most foreign trade is with Germany, Belgium, and other EC countries
Aid: foreign aid to Luxembourg is included in aid to Belgium
Monetary conversion rate: 44.8159 Luxembourg francs=US$1 (central rate); under the
BLEU agreement, the Luxembourg franc is equal to the Belgian franc which
circulates freely in Luxembourg
Fiscal year: calendar year','2041792929a01312682d99eaffa2dc4db740ebfc69af8a41d52be0c0ff4f6b81','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f3cbd1646d5de733353e719839d1ba9423bad50d9e0699604e74beedae8d62c',1972,'MO','Macao','economy',256,'Agriculture: main Crops -- rice, vegetables; food shortages -- rice, vegetables,
meat; depends mostly on imports for food requirements
Major industries: textiles, fireworks
Electric power: 28,500 kw. capacity (1971); 75 million kw.-hr. produced (1971),
295 kw.-hr. per capita
Exports: $43 million (f.0.b., 1970); textiles and clothing, foodstuffs, fireworks
Imports: $67 million (f.0.b., 1970)
Major trade partners: exports -- Portuguese colonies 19%, Hong Kong 18%, West
Germany 15%; imports -- Hong Kong 65%, China 27%
Monetary conversion rate: 5.9 Patacas=US$1 (December 1971)
Fiscal year: calendar year
195
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
GNP: $888.5 million (1970), about $130 per capita; a real increase of 6% between
1969 and 1970
Agriculture: cash crops -- coffee, vanilla, sugar, tobacco, sisal, rice, cloves,
raphia; food crops -- rice, cassava, cereals, potatoes, corn, beans,
bananas, coconuts, and peanuts; animal husbandry widespread; self-
sufficient in foodstuffs, but some milk and cereals imported
Fishing: catch 50,000 metric tons (1970)
Major industries: agricultural processing (meat canneries, soap factories,
brewery, tanneries, sugar refining), light consumer goods industries
(textiles, glassware), cement plant, auto assembly plant, paper mill, o7]
refinery
Electric power: 58,000 kw. capacity (1971); 175 million kw.-hr. produced (1971),
25 kw.-hr. per capita
Exports: $145 million (f.0.b., 1970); coffee 27%, rice 8%, vanilla 9%, sugar
4%, petroleum products 4%, cloves 12%, mineral products (graphite, mica, and
chromite) 4%; agricultural and livestock products account for about 85% of
export earnings
Imports: $170 million (f.o.b., 1970); consumer goods 30%, foodstuffs 11%, primary
products (crude oil, fertilizers, metal products) 34%, capital goods 25% (1970)
Major trade partners: France (in 1970 accounted for 34% of exports and 55% of
imports); U.S., preferential tariffs to EC and franc zone countries; trade
with Communist countries remains a minute part of total trade
Monetary conversion rate: 255.78 Malagasy francs=US$1 (official); member of
French franc zone
Fiscal year: calendar year','eb1e973fc47906f24e5ca990883fc4549f22d231bf3f5929c5b0b180187aaffb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec8fa76c7870d8a9c1f4cd9234e067fa4f60264c1dfd6a0124d70c5511292f26',1972,'MW','Malawi','economy',260,'GDP: $319 million (1970), $70 per capita; average annual growth rate in constant
prices 5.3% (1964-70)
Agriculture: cash crops -- tea, tobacco, peanuts, cotton, tung; subsistence
crops -- corn, sorghum, millet, pulses, root crops, fruit, vegetables, rice
Electric power: 38,200 kw. capacity (1971); 133 million kw.-hr. produced (1971);
30 kw.-hr. per capita
Major industries: agricultural processing (tea, tobacco, sugar), sawmilling,
cement, consumer goods
Exports: $48.9 million (f.0.b., 1971); tobacco, tea, groundnuts, cotton
Imports: $74.9 million (c.i.f., 1971); manufactured goods, machinery and transport
equipment, food, fuels
Major trade partners: exports -- U.K.. Zambia, Rhodesia, U.S.; imports -- U.K..
Rhodesia, South Africa
Aid:
economic -- U.K. provides both budgetary and development support, about
$96 million (1966-71); U.S. aid commitments, $26 million (1962-70);
military -- U.K.. $0.9 million (1954-68)
Monetary conversion rate: 1 Malawi kwacha=US$1.30286 (middle rate)
Fiscal year: 1 April - 31 March
199
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','2c28f139343c637707902720a9df62592b44967510b3c46b75be679fcc6348ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('367bf85e2413b62c82f66a2730ec2074ea29d4dd22d22f1d9af89516ade8bba2',1972,'MY','Malaysia','economy',264,'GNP:
Malaysia: $3.9 billion (1970), $360 per capita; average annual real growth
(1966-70) 6%
Agriculture:
West Malaysia: mixed plantation and subsistence; main crops -- rubber, rice,
oil palm; 25% of rice requirements imported
Sabah: mainly subsistence; main crops -- rubber, coconut, rice; food deficit
-- rice
Sarawak: main crops -- rubber, pepper; food deficit -- rice
Fishing: catch 406,000 tons, $93.2 million (1968)
Major industries:
West Malaysia: rubber and 071 palm processing and manufacturing, tin mining
and smelting, logging and processing timber, light consumer goods
Sabah: logging
Sarawak: agriculture processing, petroleum refining, logging
Electric power:
West Malaysia: 914,400 kw. capacity (1971); 3.48 billion kw.-hr. produced
(1971), 383 kw.-hr. per capita
Sabah: 56,400 kw. capacity (1971); 135 million kw.-hr. produced (1971); 135
kw.-hr. per capita
Sarawak: 52,300 kw. capacity (1971); 120 million kw.-hr. produced (1971),
115 kw.-hr. per capita
203
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $1,680 million (f.o.b., 1970); 40% rubber, 18% tin, 15% timber
Imports: $1,393 million (c.i.f. 1970)
Major trade partners: exports -- Singapore, Japan, U.S.; imports -- Japan, U.S.,
Singapore, China
Monetary conversion rate:
Malaysia: 2.82 Malaysian dollars=US$1
Fiscal year: calendar year','8418731919ec4a497b61a3930aa0088e0931452d96e7c30406ca30096b193f8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08b82a0e2ca54cf6b356c47f78e47295714dd9f1658d00b76ab70cd4a45229b8',1972,'MV','Maldives','economy',267,'GNP: under $100 per capita
Agriculture: crops -- coconut and millet; shortages -- rice, wheat
Fishing: catch 32,000 tons (1970)
Major industries: fishing; some coconut processing
Electric power: 2,500 kw. capacity (1971); 8.5 million kw.-hr. produced (1971),
76 kw.-hr. per capita
Exports: $2.5 million (f.o.b., 1967); fish
Imports: $2.5 million (c.i.f., 1967)
Major trade partner: Ceylon
Aid: U.K. (1960-65), $1.4 million drawn; Ceylon (1967), $1 million comnitted
Monetary conversion rate: 4.76 rupees=US$1
Fiscal year: calendar year
GDP: about $245 million (FY69), per capita about $50
. Agriculture: main crops -- millet, sorghum, rice, corn, peanuts; cash crops --
peanuts, cotton, livestock
. Fishing: exports $1,399,000 (1969); imports $6,000 (1969)
Major industries: small local consumer goods and processing
Electric power: 18,400 kw. capacity (1971); 43 million kw.-hr. produced (1971),
8 kw.-hr. per capita
ee $30.2 million (f.o.b., 1970); livestock, peanuts, dried fish, cotton,
skins
Imports: $35.8 million (c.i.f., 1970); textiles, vehicles, petroleum products,
machinery, and sugar
eae partners: mostly with franc zone and Western Europe; also with U.S.S.R.,
ina
209
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: since August 1969, 511.57 Mali francs=US$1
Fiscal year: calendar year','7172db4dbf9ff9dc78cb821fed29e27617b2a35deeba288cab01bbdbee7b21c8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dec708e2ccf8b8052cfa6c03fad41d289269ff9f21d80378b4d4716da9f11fb',1972,'MT','Malta','economy',271,'GNP: $255 million (1970 current prices), $780 per capita; 71% private
consumption, 29% gross investment; 1970 growth rate 8% in current prices
Agriculture: overall, 20% self-sufficient; adequate supplies of vegetables, poultry,
milk and pork products; shortages in beef, grain, animal fodder, and fruits
at various seasons; main products -- potatoes, cauliflowers, grapes, wheat,
barley, tomatoes, citrus, cut flowers, green peppers, hogs, poultry, eggs
Major industries: ship repair yard, building industry, food manufacturing,
textiles, tourism
Shortages: most consumer and industrial needs (fuels and raw materials) must be
imported
Electric power: 115,000 kw. capacity (1971); 287 million kw.-hr. produced (1971),
900 kw.-hr. per capita
Exports: $38.2 million (1969); textiles, scrap metal, wine, agricultural
products, and footwear
211
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Imports: $147.6 million (1969)
Major trade partners: U.K, 44%, Italy 15.7%; EFTA 48%; EC 28.2%; Communist
countries 2.5%; North and Central America 3.8%
Aid: economic -- U.S., $8.3 million (1949-70), of which $0.3 million authorized
in 1968, $1.7 million authorized 1969 and $0.1 million authorized in 1970;
U.K. Financial Agreement (loans and grants) 1964-74, $140 million; IBRD $6
million through 1970, none since 1964; U.N. Special Fund $2.1 million through
1970, none since 1966; U.N. Technical Assistance $1.1 million through 1970, of
which $0.1 million in 1970
Monetary conversion rate: 1 Maltese Pound=US82.67 (official)
Fiscal year: 1 April - 31 March','22acf5a1d68f97a57eec3b2272c083999ae2c6f259ae67cfeaef2a4c7b737650','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3065b206549eeb99660c5a66ff66ad5eab0c50874a5fac818f2009c737a7cb5c',1972,'MQ','Martinique','economy',276,'GDP: $245 million (1968), $750 per capita; real growth rate 8% (1968, est.)
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, particularly sugar milling and rum
distillation; cement, oi] refining and tourism
Electric power: 26,400 kw. capacity (1970); 74 million kw.-hrs. produced (1970),
219 kw.-hrs. per capita
Exports: $30 million (f.0.b., 1970), bananas, sugar, rum, pineapples
Imports: $146 million (c.i.f., 1970), foodstuffs, clothing and other consumer
_ goods, raw materials and supplies, and petroleum
Major trading partners: exports -- France 82%, Italy 9%, other 9%; imports --
Tae (ieee) United States 6%, Netherlands Antilles 3%, Netherlands 3%, other
213
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: 5.1157 francs=US$1
Fiscal year: calendar year','597ad59be2d514ec458b69846039176af81b8a3a87d8439f6961d29c11d3b44d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ebaaff93b95b17fe0e43a76f2635b86d926ac92ab5721cbe695f732f275145e',1972,'MR','Mauritania','economy',280,'GDP: about $170 million (1968), about $150 per capita
Agriculture: most Mauritanians are nomads or subsistence farmers; main crops
-- livestock, small grains, dates; cash crops --_ livestock, gum arabic
Fishing: catch, traditional river fishing, 15,000 metric tons (1969), traditional
sea fishing, 2,750 metric tons (valued at $437,000); fish supplied to processing
plants by foreign fishing fleets from France, Spain, Canary Islands using
Mauritanian waters; exports 21,090 metric tons, $7.3 million (1970)
Major industries: mining of iron ore, salt fishing, exploitation of copper
resources planned
Electric power: 36,000 kw. capacity (1971); 41 million kw.-hr. produced (1971),
34 kw.-hr. per capita
Exports: $74 million (f.0.b., 1969); iron ore, fish, gum arabic
Imports: $42 million (c.i.f., 1969); sugar, cloth, tea, and fuels
215
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major trade partners: (trade figures not complete because Mauritania has a form
of customs union with Senegal and much local trade unreported) France and
other EC members, U.K., and U.S. are main overseas partners
Monetary conversion rate: 255.78 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year','4b618b29f16f6f62f60b7eb2f1388d96be23263a2839fa324f2a7ff5b87e9aa4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a456dd34b074c7ae52f400e231816131fe393305638587f587c698767bc2dcf',1972,'MU','Mauritius','economy',283,'GNP: est. $157 million (1969), approximately $200 per capita
Agriculture: sugar crop is major economic asset; about 40% of land area is planted
to sugar; tea production rising slowly; most food imported -- rice is the
staple food -- and since cultivation is already intense and expansion of
cultivable areas is unlikely, heavy reliance on food imports except sugar
and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea; some small-scale,
simple manufactures; tobacco fiber: some fishing; tourism, diamond cutting,
weaving and textiles
Electric power: 61,340 kw. capacity (1971); 135 million kw.-hr. produced (1971),
154 kw.-hr. per capita
Exports: $69 million (f.0.b., 1970); mainly sugar, tea, molasses
Imports: $75.6 million (1970); foodstuffs 30%, manufactured goods 23%
Major trade partners: U.K. has preferential treatment, buys over 50% of Mauritius''
sugar export at heavily subsidized prices; small amount of sugar exported to
Canada, U.S., and Italy; imports from U.K. and EC primarily, also from South
Africa, Australia, and Burma; some minor trade with China
Aid: U.K. financed 40% of 1960-66 development programs with loans and grants
totaling $33 million; U.K.''s sugar subsidies amount to approx. $30 million
annually; U.S. $4.1 million FY58-70 (P.L. 480); Soviet Union made some
small-scale offers in 1969
Monetary conversion rate: 5.12 Mauritian rupees=US$1
Fiscal year: 1 July - 30 June','d5b24dfe69e1b49e50286b7d04c3ae0bb82eff2a1c2ed0e032443423bf64b48a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17311978a1b20c210ea936b93d54a447232caff26c3c57f838cfae5e9b2411bf',1972,'MC','Monaco','economy',287,'GNP: 55% tourism; 25%-30% industry (small and primarily tourist oriented); 10%-15%
registration fees and sales of postage stamps; about 4% traceable to the Monte
Carlo casino
Major industries: chemicals, food processing, precision instruments, glassmaking,
printing
Electric power: 8,000 kw. capacity (1970); 60 million kw.-hr. supplied by France
(1970), 2,500 kw.-hr. per capita
Trade: full customs integration with France, which collects and rebates Monacan
trade duties
Monetary conversion rate: 5.1157 francs=US$1 (central rate)','910f1e1d6380ce1bcd184ba179d25b0db60fee541a809ae70b1bfb060d3c9bc3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('200d2e8a8714a9229132a856653b4e90a8c454b4bc25fc2e0112ece578b365e7',1972,'MN','Mongolia','economy',292,'pe eas self-sufficient in animal products; main crops -- wheat, oats,
arley
Industries: processing of animal products and building materials; mining
Exports: animal and dairy products, fluorspar, woolen textiles, leather shoes,
glass, and paper
Imports: machinery and equipment, petroleum, cloth, coal, and building materials,
sugar, and tea
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 4 tugriks=US$1 (arbitrarily established)
Fiscal year: calendar year
223
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','171fbbb9a71f14b7b1c608fa7f6024cfde36a0f7a0de8ba5f8a1c8302c35488a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24b6012509b8b8c57c039abc9695f021d88c43915360478694eb78dfaa04ff4e',1972,'MA','Morocco','economy',295,'Agricuiture: cereals farming and livestock raising predominate; main crops --
wheat, barley, citrus fruit, wine, vegetables, olives
Major industries: mining and mineral processing, food processing, textiles
Electric power: 748,000 kw. capacity (1971); 1.9 billion kw.-hr. produced
(1971), 116 kw.-hr. per capita
Monetary conversion rate: 5.03 dirhams=US$1 (selling rate)
Fiscal year: calendar year','a8996615ee4607f180343de7762c2b4ce1af5ff0405fdcb5f8251bddb774d3ca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc37c29a4d2c91538660fdf3921f08842083afc90b5e7a61b008d114ca0b3a97',1972,'MZ','Mozambique','economy',300,'GNP: $1.3 billion (est. 1970), about $170 per capita
Agriculture: cash crops -- raw cotton, cashew nuts, Sugar, tea, copra, sisal;
other crops -- corn, wheat, peanuts, potatoes, beans, sorghum, and cassava;
self-sufficient in food except for wheat which must be imported
Major industries: food processing (chiefly sugar, tea, wheat, flour, cashew
kernels); chemicals (vegetable oi1, oilcakes, soap, paints); petroleum
products; beverages; textiles; nonmetallic mineral products (cement, glass,
asbestos, cement products); tobacco
227
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Electric power: 232,000 kw. capacity (1971); 464 million kw.-hr. produced (1971),
64 kw.-hr. per capita
Exports: $158 million (f.o.b., 1970); cotton, sugar, cashew nuts, mineral products,
timber products, tea, copra, petroleum products
Imports: $326 million (c.i.f., 1970); machinery and electrical equipment, cotton
textiles, vehicles, petroleum products, wine, iron and steel
Major trade partners: over one-third of foreign trade with Portugal; South Africa,
U.S., U.K.. West Germany
Aid: from Portugal only
Monetary conversion rate: 27.25 escudos=US$1 (approximate realigned rate)
Fiscal year: calendar year','e22d386051b4a120eb5cef0a5db5c07e39114943759cc1d1de5c7fe83c59b394','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32282aa37c17047ff41e9dba917d438825c545bdba22e5fead8de8ad602c9abd',1972,'NR','Nauru','economy',304,'GNP: $25 million (1970), $3,570 per capita
Agriculture: negligible; almost completely dependent on imports for food, water
Major industries: mining of phosphates, about 2 million tons per year (1966)
Electric power: 7,600 kw. capacity (1971); 18 million kw.-hr. produced (1971),
2,571 kw.-hr. per capita
Exports: $17 million (f.o.b., 1968), consisting entirely of phosphates
Imports: $5 million (c.i.f., 1968)
Major trade partners: Australia, New Zealand, and United Kingdom
Monetary conversion rate: 1 Australian dollar=US$1.19 (official)
Fiscal year: 1 July - 30 June','0cdcfbe6d4d11e86beba0de3189dd975270179036a9413e56babb046de23e4f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd1145acc92623acf23eb8a145a9d3d631f26b3e05dd7ba61d4bb646c0af48f4',1972,'NP','Nepal','economy',308,'GDP: $1 billion (1970), less than $100 per capita
Agriculture: over 90% of population engaged in agriculture; main crops -- rice,
_ corn, wheat, sugarcane, oilseeds; largely self-sufficient
Major industries: small rice, jute, sugar, and oilseed mills; match, cigarette,
and brick factories
231
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Electric power: 44,000 kw. capacity (1971); 65 million kw.-hr. produced (1971),
6 kw.-hr. per capita
Exports: $55 million (FY69 est.); rice and other food products, jute, timber
Imports: $62 million (FY69 est.); manufactured consumer goods, food grains and
food products
Major trade partner: over 90% India
Monetary conversion rate: 10.1 Nepalese rupees=US$1
Fiscal year: 15 July - 14 July','dfb4c89b8523c2a3d15ef40e62fc4cb8841fe5c4b9c8fc1dacfab52183d449d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a435c19b080ecbec15b56b3a2530ec665be4015c0f9648c3a25d097563d0bc1',1972,'NL','Netherlands','economy',311,'GNP: $39.1 billion (1971 preliminary), $2,970 per capita; 56% consumption, 28%
investment, 17% government, -1% net foreign balance; 1971 growth rate 4%, in
1963 constant prices
Agriculture: animal husbandry predominates; main crops -- horticultural crops,
grains, potatoes, sugar beets; food shortages -- grains, fats, oils; caloric
intake, 3,030 calories per day per capita (1968-69)
Fishing: catch 323,100 metric tons, $66,938,000 (1969); exports $94,542,000
(1969), imports $82,531,000 (1969)
Major industries: food processing, metal and engineering products, electrical and
electronic machinery and equipment, chemicals, and petroleum products
Shortages: crude petroleum, raw cotton, base metals and ores, pulp, pulpwood,
Jumber, feedgrains, and oilseeds
Crude steel: 5 million metric tons produced (1970), 380 kilograms per capita
Electric power: 10,682,000 kw. capacity (1970); 38.7 billion kw.-hr. produced
(1970), 2,869 kw.-hr. per capita
Exports: $15,065 million (f.0.b., 1971); foodstuffs, machinery, transportation
equipment, consumer manufactures, chemicals, petroleum products, textiles
Imports: $16,729 million (c.i.f., 1971); machinery, transportation equipment,
consumer manufactures, crude petroleum, foodstuffs, chemicals, raw cotton,
base metals and ores, pulp
Major trade partners: (1970) 58.7% EC, 29.7% W. Germany, 15.5% Belgium-
Luxembourg, 8.7% France, 12.9% EFTA. 6.3% U.K.. 7.2% U.S.. 1.7% Eastern
Europe
Aid:
economic -- (received) U.S.. $1,279 million authorized (FY46-70); none
since FY58; IBRD. $236 million authorized (FY46-70), none since 1958;
military -- (received) U.S.. $1,240 million authorized (FY46-70), none since
FY67; net official aid given to less developed areas and multilateral
agencies -- $1,005 million (FY60-70), $200 million (FY70)
Monetary conversion rate: 3.2447 guilders=US$1 (central rate)
Fiscal year: calendar year
GNP: $250 million (1967), $1,170 per capita; real growth rate 1967, 3.6%
Agriculture: little production
Major industries: petroleum refining on Curacao and Aruba; tourism on Curacao,
Aruba, and St. Martin; phosphate mining on Curacao
Electric power: 288,500 kw. capacity (1969); 1.3 billion kw.-hr. produced (1969
est.), 5,909 kw.-hr. per capita
Exports: $655 million (f.o.b., 1970 est.}); petroleum products, phosphate
Imports: $920 million (c.i.f., 1970 est.); crude petroleum, food manufactures
Major trade partners: exports -- U.S. 43%, EC 16%, Latin America 13%, U.K. 10%,
Canada 7%; imports -- Venezuela 72%, U.S. 10%, Netherlands 4% (1968)
Monetary conversion rate: 1.79 Netherlands Antillean florins (NAF)=US$1 (official)
Fiscal year: calendar year','e2d669557a4565b5968454467d84e90967cf61639b304c380fac2a6e472f50cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90ec8aad3ee3405867d6f9bc169d6e9bf59886212e6efec592d2bdd4676d647e',1972,'NC','New Caledonia','economy',315,'GNP: $190 million, $1,780 per capita (1969 est.)
Agriculture: large areas devoted to cattle grazing; major products -- coffee and
vegetables; 60% self sufficient in beef; must import grains and vegetables
Industry: mining of nickel
Electric power: 105,000 kw. capacity (1971); 780 million kw.-hr. produced (1971),
7,290 kw.-hr. per capita
Exports: $204 million (f.0.b., 1970) 98% nickel
Imports: $245 million (c.i.f., 1970)
Major trade partners: (1970) exports -- France (42%), Japan (48%); imports --
France (50%), Australia (13%)
Monetary conversion rate: 95 CFP francs=US$1
237
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','9716e551229ae2941fd9ef22bddabae6f38dc036441f0fc60f4cc22a273291b4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c786d302307ada716c12028269a705c25329bddbcf05e8b85403567289a8bfd9',1972,'NE','Niger','economy',321,'GDP: $319 million (1966 est.), less than $100 per capita
Agriculture: commercial -- peanuts, cotton, livestock; main food crops --
millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice mill, small cotton gins, of1
presses, slaughterhouse, and a few other small light industries; uranium
production began in 1971
Electric power: 40,000 kw. capacity (1971); 42 million kw.-hr. Produced (1971),
10 kw.-hr. per capita
Exports: $31.4 million (f.0.b., 1968-69 est.); about 74% peanuts and related
products, rest largely livestock, hides, skins; exports badly understated
because much regional trade not recorded
Imports: $31.2 million (c.i.f., 1968-69 est.); fuels, machinery, transport equip-
ment, foodstuffs, consumer goods (largely for European residents); sizable
imports unrecorded
243
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major trade partners: France (about 50%), other EC countries, Nigeria, UDEAC
countries, U.S.; preferential tariff to EC and franc zone countries
Aid:
economic -- France (1960 to mid-1967) $68 million; EC (1966-67) $51.3 million;
U.S. (FY62-70) $15.8 million; West Germany, Israel, Republic of China, and U.N.
have also extended aid;
military -- $2.8 million (1954-68)
Monetary conversion rate: 255.78 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: 1 October - 30 September','b21e38a587bad5c57d04e90fb6118e1f2488b6f910db2363da2dd45bd99713a9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c3638c5177baef3c2a0d8c0e997696884e7889fbdbcb46af82521d6d78d4a06',1972,'NG','Nigeria','economy',325,'GDP: $5.2 billion (1971 est.), probably about $90 per capita; 9.6% growth rate
assumed FY69-70
Agriculture: main crops -- peanuts, cotton, cocoa, rubber, yams, cassava,
sorghum, palm kernels, millet, corn, rice; livestock; almost self-sufficient
Fishing: catch 130,000 metric tons (1970 est.); imports $4 million (1970)
245
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major industries: processing industries -- oil palm, peanut, cotton, rubber,
petroleum, wood, hides, skins; manufacturing industries -- textiles, cement,
building materials, food products, footwear, chemical, printing, ceramics;
mining -- crude oil, natural gas, coal, tin, columbi te
Electric power: 1,111,000 kw. capacity (1971); 1.7 billion kw.-hr. produced
(1971), 30 kw.-hr. per capita
Exports: $1,240 million (f.o.b., 1970); oil, peanuts, palm products, cocoa, rubber,
cotton, timber, tin
Imports: $1,059 million (c.i.f., 1970); machinery and transport equipment, manu-
factured goods, textiles, chemicals
Major trade partners: U.K., EC, U.S.
Monetary conversion rate: 1 Nigerian pound=US$3.04 (official)
Fiscal year: 1 April - 31 March','9b223a9b5e2609861f1392ce3b03b778f9d05e5e0ed8ec69738f707161adaf8f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4285e46739ce3c09fd78ae2b87b71b44f1707b358c16ffd76a54b351f1e025dd',1972,'NO','Norway','economy',329,'GNP: $14.0 billion (1971), $3,570 per capita; 55.1% consumption; 28.8% investment,
including government; 17.8% government, including defense (current); net
foreign balance -1.7%; 1969 growth rate 5.1%, in 1969 constant prices
Agriculture: animal husbandry predominates; main crops -- feed grains, potatoes,
fruits, vegetables; 40% self-sufficient; food shortages -- food grains, sugar;
caloric intake, 2,910 calories per day per capita (1968-69)
Fishing: catch 2,695,633 metric tons (1970), $14.7 million; exports $190 million,
imports $11 million
Major industries: food processing, wood pulp, paper products, metals, machinery,
chemicals, shipbuilding
Shortages: feed and bread grains, coal, petroleum and petroleum products, cotton,
woo!
Crude steel: 870,133 metric tons produced (1970), 220 kilograms per capita
Electric power: 13,850,000 kw. capacity (1971); 64 billion kw.-hr. produced
(1971), 15,000 kw.-hr. per capita
Exports: 2,520 million (f.o.b., 1971); principal items -- fish and fish
products, metal and metal products, pulp and paper, chemicals, ships
Imports: $4,020 million (c.i.f., 1971); principal items -- ships, machinery,
fuels, foodstuffs
Major trade partners: 18.2% Sweden, 15.1% U.K., 16.1% West Germany, 6.9% U.S.,
6.7% Denmark; 27.3% EC; 45.4% EFTA; 2.6% Communist countries (1970)
Aid:
economic -- U.S., $355.2 million authorized (1946-70), $1.2 million in 1967,
$2.1 million in 1970; IBRD, $145 million authorized through 1970,
none since 1964; net official economic aid given to less developed areas and
multilateral agencies, $134.2 million (1960-69), $26.6 million (1968), $37.7
million (1969); $36.8 million (1970)
military -- U.S., $900 million authorized (1946-70), $24.2 million (1968),
$11.0 million (1969), $0.3 million (1970)
Monetary conversion rate: 6.65 kroner-US$1 (official 1972)
Fiscal year: calendar year','8f7621ad48b6b06d2432f050f62d2314252bb27562fc2cd97480dd6f32f6b137','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ed03a91c230e2b9f9aeadbe48e02b8ae6f4e6b932a6472dc09d067d48914c83',1972,'OM','Oman','economy',333,'Agriculture: based on subsistence farming (fruits, dates, cereals, cattle, camels,
fish) and trade
Major industries: petroleum discovery in 1964; production began in 1967; production
1971 equaled 289,000 b.p.d.; pipeline capacity 400,000 b.p.d.3; revenue for
1971 about $112 million
Electric power: 24,000 kw. Capacity (1970); 70 million kw.-hr. produced (1970),
120 kw.-hr. per capita
Exports: petroleum exports worth $221 million (1970); dates, fish, limes, hides,
wool $3 million (1970)
Imports: $80 million (1970 est.)
Major trade partners: U.K., Gulf states, India, Australia, China, Japan
Aid: multilateral annual average 1967-69 $350,000
Monetary conversion rate: 1 Riyal Said=US$2.59 (as of March 1972)
Fiscal year: no budget year','f25014f415fb5d3d05544383b51a84f7430daf7455e0d4e9aa3ed227c58491db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05a410789f2ea1c7d07b25bd57d4b821013d7e8143ba00d37d228f4baaa1f607',1972,'PK','Pakistan','economy',337,'GNP: $8.8 billion (FY71), $140 per capita; real growth (FY71) 2%
Agriculture: extensive irrigation; main crops -- wheat and cotton; largely
self-sufficient
Fishing: catch 183,000 tons, $77 million (1969 est.)
Major industries: cotton textiles, food processing, engineering, chemicals,
natural gas
Electric power: 2,050,000 kw. capacity (1971); 7.3 billion kw.-hr. produced
(1971) ,130 kw.-hr. per capita
Exports: $564 million (f.o.b., FY71); cotton (raw and manufactured)
Imports: $841 million (c.i.f., FY71) machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West Germany
Monetary conversion rate: 4.762 rupees=US$1
Fiscal year: 1 July - 30 dune','d43ff8eb9c95ea9ae2558e81ce5526f38fad0e56dbbbaa06e86e195904e41108','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57f88d0c3df3c26298c77e4aa7d05747ac3816989bb329c8777da08266cbfe17',1972,'PG','Papua New Guinea','economy',342,'GNP: $550 million (FY70 estimate), $220 per capita; real average annual growth
rate (1960-69) 7.5%
Agriculture: main crops -- coconuts, coffee, cocoa, tea
Major industries: sawmilling and timber processing, copper mining (Bougainville)
Electric power: 78,000 kw. capacity (1971); 220 million kw.-hr. produced (1971),
90 kw.-hr. per capita
255
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $105.0 million (f.o.b., FY70); principal products -- coconut products,
coffee beans, cocoa beans, timber
Imports: $239.9 million (f.o.b., FY70)
Major trade partners: Australia, U.K.. Japan
Aid: economic -- Australia (FY46-69) $909 million extended; World Bank group
(1968-September 1969) -- $7.5 million committed
Monetary conversion rate: 0.84 Australian dol lar=US$1
Fiscal year: 1 July - 30 June','2a8c2115f83fca66977b0e2184c637e0368918486094556f186d88972730c894','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f569f46eecda21644af4c13b9482ef554ceaa97ef636807912293d4dca4e90f',1972,'PE','Peru','economy',344,'LAND:
496 ,000 sq. mi. (other estimates range as low as 482,000
sq. mi.); 2% cropland, 14% meadows and pastures, 55% no ant
forested, 29% urban, waste, other (1962)
Land boundaries: 3,810 mi.
WATER: :
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,500 mi.
GNP: $9.1 billion (purchasing power parity estimate, 1971), $640 per capita; 72%
private consumption, 10% public consumption, 13% gross investment (1970); 5%
net foreign balance; real growth rate 1971, 5.2%
Agriculture: main crops -- wheat, corn, potatoes, beans, barley, coffee, cotton,
sugarcane; imports wheat, meat, lard and oils, rice, corn; caloric intake,
2,300 calories per day per capita (1964)
Fishing: catch 12.6 million metric tons (1970); exports $300.3 million (1970),
imports $0.3 million (1969)
259
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major industries: mining of metals, petroleum, fishing, textiles and clothing,
food processing, cement
Electric power: 2 million kw. capacity (1970); 5.3 billion kw.-hr. produced
(1970), 390 kw.-hr. per capita
Exports: $883 million (f.o.b., 1971}; fish and fish products, copper, silver,
iron, cotton, sugar, lead, zinc, petroleum, coffee
Imports: $743 million (f.o.b., 1971); foodstuffs, machinery, transport equipment,
iron and steel semimanufactures, chemicals, pharmaceuticals
Major trade partners: exports -- U.S. 33%, Western Europe 42%, Japan 14%, Latin
America 6%; imports -- U.S. 32%, Western Europe 33%, Latin America 17%,
Japan 6% (1970)
Aid:
economic -- extensions from U.S. (FY46-70), $452.8 million loans, $178
million grants; from international organizations (FY46-70), $371.9 million;
from other Western countries (1960-66), $43.4 million; Communist countries
(1954-71) $125.5 million;
military -- assistance from U.S. (FY49-70), $141 million
Monetary conversion rate: 38.70 soles=US$] (trade); 43.38 soles=US$1 (non-trade)
Fiscal year: calendar year','4998f51f0b6bbcd4bbb89c27de3423301d56df3bf6c968d32a0e0a3e6bf17ac1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d05dd058a8a6f1913c7f036d02369ab47dd704997c2e4116b7beb42f7cb5389b',1972,'PH','Philippines','economy',351,'GNP: $7.5 billion (1971), $190 per capita
Agriculture: main crops -- rice, corn, coconut, sugarcane, abaca, tobacco
Fishing: catch 978,000 tons, $332 million (1969)
Major industries: agricultural processing, textiles, chemicals and chemical
products
Electric power: 2,455,000 kw. capacity (1971); 9.1 billion kw.-hr. produced
(1971), 228 kw.-hr. per capita
Exports: $1,033 million (f.o.b., 1970); copra, sugar, logs and lumber, coconut
oil, copper concentrates, abaca
Imports: $1,186 million (f.0.b., 1970)
Major trade partners: (1971) exports -- 42% U.S.. 39% Japan; imports -- 24%
U.S., 30% Japan
Aid:
economic -- U.S. (FY46-70), $1.6 billion committed; Japan (reparations),
$550 million extended in 1956, $337 million drawn through July 1969; IBRD
(1953-70), $217 million committed;
military -- U.S. (FY46-70), $567.7 million committed
Monetary conversion rate: 6.43 pesos=US$I (duly, 1970) (floating rate)
Fiscal year: 1 July - 30 June','9589290a99c8d2d032145788a184325dc0344afc9904aff5c3e9d0bc0b716843','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43ce1e85444e0fbf5480c5adbce6677f36c2ad406158d3208ec8941a475b1552',1972,'PL','Poland','economy',354,'ee billion in 1971 at 1970 prices, $1,480 per capita; 1971 growth rate
Agriculture: self-sufficient for minimum requirements; main crops -- grain,
sugar beets, oilseeds, potatoes, exporter of livestock products and sugar;
importer of grains; 3,200 calories per day per capita (1970)
*Excludes armed forces and other classified categories of employment.
263
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major industries: chemistry, food processing, transportation equipment, machine
building, iron and steel, textiles, and shipbuilding
Crude steel: 12.7 million metric tons produced (1971), about 390 kg. per capita
Exports: $4,209 million (f.0.b., 1971); 38% machinery and equipment, 33% fuels,
raw materials, and semimanufactures, 13% agricultural and food products,
16% industrial consumer goods
Imports: $4,389 million (f.0.b., 1971); 36% machinery and equipment; 48% fuels,
raw materials, and semimanufactures; 10% agricultural and food products;
6% industrial consumer goods (1970)
Major trade partners: $8,598 million (1970); 65% with Communist countries, 35%
with West (1971)
Monetary conversion rate: 3.68 zlotys=US$1 (commercial); 22.08 zlotys=US$1
(noncommercial)
Fiscal year: same as calendar year; economic data are reported for calendar
years except for caloric intake which is reported for the consumption year,
1] July - 30 June','5b19c99549f3687e01dd9d20c297459621542c0561f3fef7d7aa8e83b4f3fd48','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('575ac2b5dbb4bb11385237bc13e4f432b534cfe37eab2e1e4c16818701021dfb',1972,'PT','Portugal','economy',358,'GNP: continental Portugal -- $6,970 million, $850 per capita (1971 est.); 75.6%
consumption, 16.9% investment, 14.7% government, -7.2 net exports of goods and
services (1971), growth rate 5.3% (1971) in 1963 constant prices
Agriculture: generally underdeveloped; main crops -- grains, potatoes, olives,
grapes for wine; food shortages -- sugar, wheat; caloric intake, 2,930
calories per day per capita 11968)
Fishing: catch 365,000 tons, $77.4 million; exports $46.7 million, imports $32.6
million, trade includes fish and fish products (1970)
Major industries: cotton textiles, cork processing, fish canning, petroleum
refining, pulp and paper, chemical fertilizer
Shortages: coal, petroleum, cotton, steel
Crude steel: .38 million metric tons produced (1970), 40 kg. per capita (1970)
Electric power: 2,700,000 kw. capacity (1970); 7,400 million kw.-hr. produced
(1970), 700 kw.-hr. per capita
Exports: $946 million (f.0.b. 1970); principal items -- cotton textiles, cork
and cork products, canned fish, wine, timber and timber products, resin
Imports: $1,556 million (c.i.f., 1970); principal items -- petroleum, cotton,
industrial machinery, iron and steel, chemicals
Major trade partners: (1970) 16.5% U.K., 12% West Germany, 6.1% France, 7.6%
U.S.. 10.7% Angola, 6% Mozambique; 27.5% EC; 28.2% EFTA; .7% Communist
countries
Aid:
economic ~- U.S.. $180.7 million (1949-70), $4.7 million authorized 1969,
$4.3 million authorized 1970; IBRD, $57.5 million authorized (1964-66), none
since 1966; net official aid to less developed areas and multilateral agencies
$462 million (1961-70), $79.5 million (1969), $57.1 million (1970);
military -- U.S., $328.1 million authorized (1949-70), $2.7 million authorized
in 1969, $1.3 million authorized in 1970
Monetary conversion rate: 27.25 escudos=US$1 (official)
Fiscal year: calendar year
GNP: $107 million (1969, in 1963 constant prices), $200 per capita
Agriculture: main crops -- palm oi], root crops, rice, coconuts, peanuts
Electric power: 1,200 kw. capacity (1971); 2 million kw.-hr. produced (1971),
4 kw.-hr. per capita
Exports: $3.6 million (f.0.b., 1969); principally peanuts, coconuts
Imports: $23.3 million (c.i.f., 1969); manufactured goods, fuels, transport
equipment, rice
Major trade partners: mostly Portugal, also immediate neighbors
Aid: Portugal, smal] amounts
269
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: 27.25 escudos=US$1 (approximate realigned rate)
Fiscal year: probably is the calendar year
GNP: Tess than $100 per capita
Agriculture: principal crops -- corn, rice, rubber, coffee, copra
Electric power: 2,000 kw. capacity (1971); 8.5 million kw.-hr. produced (1971),
14 kw.-hr. per capita
Exports: $2.6 million (f.0.b., 1967); coffee, copra
Imports: $5.2 million (c.i.f., 1967)
Major trade partners: Portugal and its possessions, Singapore, and Hong Kong
2/1
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: Portuguese escudo known in Timor as pataca; 28.75
patacas=US$1
Fiscal year: calendar year','dc6f32256cfed82cbc7ab5d1850858d19dd00a0225a14f89dce4532c28a23722','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1934dc2b620f617d51d7d54f5c09a720172f63e32f72cf81650a4100b4b82257',1972,'PR','Puerto Rico','economy',362,'GNP: $4.6 billion (FY70), $1,650 per capita
Agriculture: main crops -- sugar, coffee, tobacco, bananas
Major industries: textiles, clothing manufacture, food processing, petroleum
refining, petro-chemicals
Electric power: 1.2 million kw. capacity (1969); 5.9 billion kw.-hr. produced
(1969 est.), 2,010 kw.-hr. per capita
Exports: $1,680 million (f.o.b., 1970) ; sugar, pineapple, citrus fruits, coffee,
rum, textiles
Imports: $2,680 million (f.0.b., 1970); food, machinery, transportation equip-
ment, fuels, minerals
Major trade partner: exports -- U.S. 93%; imports -- U.S. 77%
273
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: uses U.S. currency
Fiscal year: 1 July - 30 June','2c191304bfc5b3aaac748b1f4fdfdba09341f82b24438bfb7137d8a3e2988992','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb6b5d2b2a8eb26e3ba88455d440103f7c6c5103406d83be9492deae08217ca3',1972,'QA','Qatar','economy',366,'GNP: $65 million (1969 est.)
Agriculture: farming and grazing on small scale; commercial fishing increasing
in importance; most food imported; rice and dates staple diet .
Major industries: 071 production and refining; crude oi] production from onshore
and offshore averaged 430,000 bbls. per day in 1971; oi] revenues estimated
$195 million est. in 1971, representing 99% of government/royal
family income; major development projects include $7 million harbor at Ad Dawhah,
fertilizer plant, 2 desalting plants, refrigerated storage for fishing, and
a cement plant
Electric power: capacity 80,000 kw. (1970); 200 million kw.-hr. produced (1970),
1,709 kw.-hr. per capita
Exports: crude oil dominates; reexports $56 million (1968)
Imports: approx. $53 million in 1969
Aid: multilateral annual average $170,000 (1967-69)
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.23 (as of March 1972)
Fiscal year: 1 April - 317 March
Agriculture: cash crops -- almost entirely sugarcane, small amounts of vanilla
and perfume plants; food crops -- tropical fruit and vegetables, manioc,
bananas, corn, market garden produce, also some tea, tobacco, and coffee;
food crop inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling plants, cigarette
factory, 2 tea plants, fruit juice plant, canning factory, a slaughterhouse,
and a number of small shops producing handicraft items
Electric power: 54,400 kw. capacity (1971); 108 million kw.-hr. produced (1971),
246 kw.-hr. per capita
Exports: $50 million (f.o.b., 1970); 90% sugar, 4% perfume essences, 5% rum and
molasses, 1% vanilla and tea
Imports: $162.6 million (c.i.f., 1970); manufactured goods, food, beverages,
and tobacco, machinery and transportation equipment, raw materials and
petroleum products
Major trade partners: France (in 1970 supplied 62% of Reunion''s imports, purchased
76% of its exports); Mauritius (supplied 12% of imports)
277
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: 255.78 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: probably calendar year
GDP: $1,438 million (1970), $270 per capita; real growth rate 4.5% (1970)
279
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Agriculture: main crops -- tobacco, corn, sugar, cotton, citrus fruits; live-
stock; self-sufficient in foodstuffs except wheat
Major industries: mining and steel, textiles
Electric power: 1,187,000 kw. capacity (1971); 5,580 million kw.-hr. produced
(1971), 1,160 kw.-hr. per capita
Exports: $384 million (f.o.b., 1970), including net gold sales and reexports;
tobacco, asbestos, copper, clothing, meat, chrome, sugar
Imports: $329 million (f.o.b., 1970); textiles, machinery, petroleum products,
wheat, transport equipment
Major trade partners: South Africa, Portugal, and Portuguese territories
Aid: no substantial military or economic aid
Monetary conversion rate: 1 Rhodesian dollar=US$1.40 (official); 0.714 Rhodesian
dollar=US$1
Fiscal year: 1] July - 30 June','efb97e857da574993dacc48491db1f050c4dfb4dcd603a5fe401720ccb8f208e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('375763b49a280ad3e5f9572ebb5851eef78cd50545233b46925496d361196293',1972,'RO','Romania','economy',370,'GNP: pee billion in 1971 (at 1970 prices), $1,300 per capita; 1970 growth rate
9.9%
Agriculture: net exporter; main crops -- corn, wheat, oilseed; livestock --
cattle, hogs, sheep; caloric intake, 3,000 calories per day per capita (1967-68)
Major industries: machinery, metals, fuels, chemicals, textiles, food processing,
timber processing
ae iron ore, coking coal, metallurgical coke, cotton fibers, natural
rubber
Crude steel: 6.7 million metric tons produced (1971), 330 kg. per capita
281
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $2,295 million (f.0.b., 1970); 23% machinery and equipment; 43% fuels,
raw lee cae semifinished products; 16% foodstuffs; and 18% consumer goods
(1970
Imports: $2,040 million (mixture f.o.b. and c.i.f., 1971}; 40% machinery and
equipment; 50% fuels, raw materials, semifinished products; 5% foodstuffs;
and 5% consumer goods (1970)
Major trade partners: $4,335 million in 1970; 45% non-Communist countries, 55%
Communist countries (1970)
Monetary conversion rate: 5.43 lei=US$1 (commercial); old rate 12 1ei=US$1
(noncommercial); 16 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year, 1 July -
30 June','72f6403dddf7f71e99677f8ec19c0526df399730ce713e848fb69ef7539fb4a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3f66a539d01dfac212cedee38b8200931d5576804ec912e7c97d87a22240356',1972,'RW','Rwanda','economy',374,'GDP: $195 million (1970), $50 per capita
Agriculture: cash crops -- mainly coffee, tea, cotton, some pyrethrum; main
food crops -- bananas, cassava; stock raising; self-sufficiency increasing
but country still imports some foodstuffs
Major industries: mining of cassiterite (tin ore), agricultural processing, and
light consumer goods
Electric power: 21,460 kw. capacity (1971); 100 million kw.-hr. produced (1971),
28 kw.-hr. per capita
Exports: $24.6 million (f.o.b., 1970); mainly coffee, tea, pyrethrum, cassiterite
Imports: $26.4 million (c.i.f., 1970); textiles, foodstuffs, machines, equipment
Major trade partners: U.S., Belgium, Zaire ;
Aid: U.S., FY62-70, $7.5 million; Belgium, France. Germany, and Canada, FY64-67,
$33.4 million obligated
Monetary conversion rate: 92.105 Rwanda francs=US$1 (official)
Fiscal year: calendar year
283
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
GDP: $15.2 million (1969), $230 per capita
Agriculture: main crops -- sugar on St. Christopher, cotton on Nevis
Major industries: sugar processing, salt extraction
Electric power: 147,500 kw. capacity (1969 est.); 260 million kw.-hr. produced
(1969 est.), 437 kw.-hr. per capita
Exports: $4.3 million (f.o.b., 1969); sugar, molasses, cotton, salt, copra
Imports: $9.6 million (c.i.f., 1969); foodstuffs, fuel, manufactures
Major trade partners: U.K. 45%, Canada 14%, U.S. 12% (1966)
Monetary conversion rate: 1.84 East Caribbean dollars=US$1
285
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','085167c41513192c223bfe71bf1680020456c9943fbf0c17fe4b554efb6024f8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40d650608299c11aa72656f9a3d293539b847a38e2fabac03c9c4102d75895a5',1972,'CO','Colombia','economy',376,'GDP: $28.2 million (1969), $230 per capita
Agriculture: main crops -- bananas, copra, sugar, cocoa, spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 4,565 kw. capacity (1969); 9.3 million kw.-hr. produced (1969
est.); 82 kw.-hr. per capita
Exports: $6.2 million (f.0.b., 1968); sugar, bananas, cocoa
Imports: $14.7 million (c.i.f., 1968); foodstuffs, machinery and equipment,
fertilizers, petroleum products
Major trade partners: U.K. 49%, Canada 9%, U.S. 8% (1964)
Monetary conversion rate: 1.84 East Caribbean dollars=US$1 (6 October 1971)','8c85ff77ddb9d6d160308427154e622604789594f5723f0a04359ee8c515a8bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14d7e8413f34f7951bbf37174320000f63bcd568c5623683ed7e8d66026d4dcf',1972,'SM','San Marino','economy',380,'Principal economic activities of San Marino are farming, livestock raising, light
manufacturing, and tourism; the government''s total budget for FY71 is about
$12 million, with the largest share of revenue derived from the sale of
postage stamps throughout the world and from payments by the Italian
government in exchange for Italy''s monopoly in retailing tobacco, gasoline,
and a few other goods; main problem is finding an additional $3 million to
finance badly needed water and electric power systems expansions
Agriculture: principal crops are wheat (average annual output about 4,400 metric
tons/year) and grapes (average annual output about 700 metric tons/year);
other grains, fruits, vegetables, and animal feedstuffs are also grown;
livestock population numbers roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock products
Electric power: obtained from Italy
Manufacturing: consists mainly of cotton textile production at Serravalle, brick
and tile production at Dogane, cement production at Acquaviva, Dogane, and
Fiorentino, and pottery production at Borgo Maggiore; some tanned hides,
paper, candy, baked goods, Moscato wine, and gold and silver souvenirs are
also produced
Foreign transactions: dominated by tourism; in summer months 20,000 to 30,000
foreigners visit San Marino every day; a number of hotels and restaurants
have been built in recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign inflow; commodity
trade consists primarily of exchanging building stone, lime, wood, chestnuts,
wheat, wine, baked goods, hides, and ceramics for a wide variety of consumer
manufactures','bb2d397f69fcffdf8f9e0fd74fb8483082bc7a0a9bb5fd16a27448547525a622','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b00d9a9667d0aad4335bc98f125d968c22a7bc200ff3d3511522d05b01983f48',1972,'SA','Saudi Arabia','economy',384,'GNP: $3.1 billion (FY70-71 prelim.), $560 per capita
Agriculture: dates, grains, livestock; not self-sufficient in food
Major industries: petroleum production 4.8 million barrels per day (1971); est.
payments to Saudi Arabian Government, $2,100 million (preliminary est.), in
1971; cement production and small steel-rolling mill and oi1 refinery; several
other light industries, including factories producing detergents, plastic
products, furniture, etc.; PETROMIN. a semipublic agency associated with the
Ministry of Petroleum, has recently completed a major fertilizer plant
Electric power: 290,000 kw. capacity (1970); 1 billion kw.-hr. produced (1970),
180 kw.-hr. per capita
Exports: $2,185 million (f.0.b., 1970); 99% petroleum and petroleum products
Imports: $842 million (c.i.f., 1970); manufactured goods, transportation equipment,
construction materials, and processed food products
Major trade partners: exports -- U.S., Western Europe, Japan; imports -- U.S.,
Japan, West Germany
Monetary conversion rate: 1 Saudi riyal=US$0.25 as of March 1972 (IMF par value,
freely convertible)
Fiscal year: follows Islamic year; the 1970-71 Saudi fiscal year covers the
period 2 September 1970 through 20 August 1971
293
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','bb7530c1a994d13f5b5461aa961ed9f0efe22fd1cb1bca739b56810ab4cfd401','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f596f7e4c0eced2eadba83f2ce5d6115d2db64a878f544c3dff1392646f19ce3',1972,'SN','Senegal','economy',388,'GDP: $713 million (1969); $180 per capita; real growth rate 2% (per annum)
Agriculture: main crops -- peanuts, millet, sorghum, manioc, rice; peanuts
primary cash crop; production of food crops increasing but still
insufficient for domestic requirements
Fishing: catch 169,000 metric tons, $31 million (1970); exports $151,000 (1969),
imports (not available)
Major industries: fishing, agricultural processing plants, light manufacturing,
mining
Electric power: 130,000 kw. capacity (1971); 354 million kw.-hr. produced (1971),
88 kw.-hr. per capita
Exports: $152 million (f.o.b., 1970); approx. 50% peanuts and peanut products;
phosphate rock; canned fish
Imports: $193 million (f.o.b., 1970); food, consumer goods, machinery, transport
equipment
Major trade partners: France, EC (other than France), and franc zone
Aid: economic -- France (1964-67) $93.1 million; U.S. (1961-70) $37.3 million;
U.S.S.R. $6.7 million loan negotiated; EC (1962-70) $100.5 million;
military -- U.S. (FY61-70) $2.8 million
Monetary conversion rate: 1 Conmunaute Financiere Africaine franc=0.02 French
francs; 255.78 CFA francs=US$1
Fiscal year: 1 July - 30 June','433f33230fbad9e70287bfde283dff80e79961e3e5ca7d4718798301d98e8eff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea01b7bf3ba556a0e157f81acca4823c5bcfac1e344138e2b6c094fc8addfcd7',1972,'SC','Seychelles','economy',392,'Agriculture: islands depend largely on coconut production and export of copra;
cinnamon, vanilla, and patchouli (used for perfumes) are other cash crops;
food crops -- small quantities of sweet potatoes, cassava, sugarcane, and
bananas; islands not self-sufficient in foodstuffs and the bulk of the
supply must be imported
Major industries: processing of coconut and vanilla, fishing, small-scale
manufacture of consumer goods, coir rope factory, tea factory
Electric power: 3,500 kw. capacity (1971); 9 million kw.-hr. produced (1971),
179 kw.-hr. per capita
Exports: $2.1 million (f.0.b., 1970); cinnamon (bark and 011) and vanilla account
for almost 50% of the total, copra accounts for about 40%, the remainder
consisting of patchouli, fish, and guano
Imports: $10.1 million (c.i.f., 1970); food, tobacco, and beverages account for
about 40% of imports, manufactured goods about 25%, machinery and transport
equipment, petroleum products, textiles
Major trade partners: exports -- India, U.S.; imports -- U.K., Burma, India,
South Africa, Kenya, Australia
297
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Aid: $1.2 million in aid in both 1965 and 1966 from U.K.
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year','770be66644b55e746ea98fe626e7fa866ee49eabf57b65af14b8b963f2a9c4d8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b51b4bff33e6adf3d939325f9dbd197e4bddb32b42b3e22b3c41d96c95c4db3',1972,'SL','Sierra Leone','economy',396,'GDP: $425 million (FY70), approx. $170 per capita; real growth rate 1970, 2%-3%
Agriculture: main crops -- palm kernels, coffee, cocoa, rice, yams, millet,
cassava; much of cultivated land devoted to subsistence farming; food crops
insufficient for domestic consumption
Fishing: catch 25.5 thousand metric tons (1969), $3.8 million (1969)
299
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major industries: mining -- diamonds, iron ore, bauxite, rutile; manufacturing
-- beverages, textiles, cigarettes, construction goods; ] oi] refinery
Electric power: 45,000 kw. capacity (1971); 125 million kw.-hr. produced (1971),
50 kw.-hr. per capita
Exports: $101 million (f.0.b., 1970); 61% diamonds; iron ore, palm kernels, cocoa,
coffee
Imports: $116 million (c.i.f., 1970); machinery and transportation equipment,
manufactured goods, foodstuffs, petroleum products
Major trade partners: U.K., EC, Japan, U.S., Communist countries
Monetary conversion rate: 1 leone=US$1.30 (official); 0.768 leone=US$1
Fiscal year: 1 July - 30 June (since 1 July 1966)','d7a0d8eeef291b55faa2b8c3e59a90b8ccbae43b89d98bbca60cd4fea4d51c96','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6029c645790479d2587d5a6d5096a25e6a9512a5e58acc3aa8b11fa8d3aa658',1972,'SG','Singapore','economy',400,'GNP: $1.9 billion (1970), $910 per capita; 11% average annual real growth
Agriculture: occupies a position of minor importance in the economy, main crops
-- poultry, hogs, small truck farming; food shortages -- grains, sugar,
dairy products
Fishing: catch 170,000 tons (1970), $5.8 million (1969)
Major industries: rubber processing and rubber products, processed food and
beverages, electronics, ship repair, entrepot trade
Electric power: 706,000 kw. capacity (1971); 2.6 billion kw.-hr. produced (1971),
1,247 kw.-hr. per capita
Exports: $1.8 billion (f.o.b., 1971); almost 90% reexports; rubber, fuels, food
301
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Imports: $2.8 billion (c.i.f., 1971); over 40% goods reexported
Major trade partners: exports -- Malaysia, Indonesia, U.S.. Japan, U.K.;
imports -- Malaysia, Japan, Indonesia, China, U.K.. U.S.
Aid: U.K. -- (1960-September 1969) $254 million disbursed; (1969-73) $120
million extended: IBRD -- (1963-June 1970) $114 million committed, $61
million disbursed
Monetary conversion rate: 2.82 Singapore dollars=US$1
Fiscal year: converted to 1 April - 31 March fiscal year on 1 April 1970;
formerly on calendar year basis','e502cb3cc53495adbda0e5029529f137022e5ede6be9993b19163e4ed0161d33','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3ad52c1abf3ebc1a53cfa2addea779768c354bba1446b885465bc0b28d96b2d',1972,'SO','Somalia','economy',404,'GDP: $137 million (1968 est.), about $50 per capita
Agriculture: mainly a pastoral country; main crops -- bananas, livestock,
sugarcane, cotton, cereals
Major industries: a few small industries, including a sugar refinery, tuna
and beef canneries, iron rod plant
Electric power: 9,000 kw. capacity (1971); 18 million kw.-hr. produced (1971),
6 kw.-hr. per capita
Exports: $35.7 million (f.0.b., 1970, est.); bananas, livestock, hides, skins
Imports: $51.8 million (c.i.f., 1970, est.); textiles, cereals, transport
equipment
Major trade partners: Italy and U.K.; Arab countries; $6.9 million imports from
Communist countries (1970 est.)
Monetary conversion rate: 6.9252 Somali shillings=US$1 (official)
Fiscal year: 1 January - 31 December
303
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','c1f3d890d0f99ca12168e3cceb7c945c8482ccce270a55cbd166d330f2366feb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d31253255583b4cac8bf7312deff71397ea68892abcab307daa297559d22c064',1972,'ZA','South Africa','economy',408,'GNP: $16.7 billion (1970), $830 per capita; real growth rate 5.1% (1970)
Agriculture: main crops -- corn, wool, dairy products, wheat, sugarcane,
tobacco, citrus fruits; self-sufficient in foodstuffs
Fishing: catch 1,079,000 metric tons (1968); exports $45 million (1970), imports
$10 million (1970)
Major industries: mining, automobile assembly, metal working, machinery,
textiles, iron and steel, chemical, fertilizer, fishing
Electric power: 11,635,000 kw. capacity (1970); 48.8 billion kw.-hr. produced
(1970), 2,430 kw.-hr. per capita
Exports: $2.2 billion (f.0.b., 1970 excluding gold); wool, diamonds, corn,
uranium, Sugar, fruit, hides, skins, metals, metallic ores, asbestos,
fish products; gold output $1.1 billion (1970)
Imports: $3.6 billion (f.0.b., 1970); motor vehicles, machinery, metals,
petroleum products, textiles, chemicals
Major trade partners: U.K. and other Commonwealth nations, U.S.. Germany, Japan
Aid: no substantial military or economic aid
Monetary conversion rate: 1 SA Rand=US$1.33 (official); 0.750 SA Rand=US$1
Fiscal year: 1 April - 37 March
Agriculture: livestock raising (cattle and sheep) predominates, subsistence
crops (millet, sorghum, corn, and some wheat) are raised but most food
must be imported
Fishing: catch 586,600 metric tons (1971) (processed mostly in South African
enclave of Walvis Bay)
Major industries: meatpacking, fish processing, copper, lead, and diamond
mining, dairy products
Flectric power: 95,200 kw. capacity (1971); 295 million kw.-hr. produced (1971),
470 kw.-hr. per capita
Aid: South Africa is only major donor
Monetary conversion rate: 1 South African Rand=US$1.33 (official); 0.750 SA
Rand=US$1
Fiscal year: 1 April - 31 March','0e41254b350f4d0558568c5769476bddec0740484cddc20e65fbc6368412c192','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d27613169b3351733c10de918dfe95ae7c17c0f22c87e68ddbed40f40d19110d',1972,'SD','Sudan','economy',413,'GDP: $1.4 billion (1968 provisional), under $100 per capita; 7% growth at
current prices 1967-68
317
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Agriculture: main crops -- sorghum, millet, wheat, sesame, peanuts, beans,
barley; not self-sufficient in food production; main cash crops -- cotton,
gum arabic
Major industries: cotton ginning, textiles, brewery, cement, edible oils, soap,
distilling, shoes, pharmaceuticals
Electric power: 197,000 kw. capacity (1971); 453 million kw.-hr. produced (1971),
28 kw.-hr. per capita
Exports: $287 million (f.o.b., FY70); cotton (64%), gum arabic, peanuts,
sesame; $64.7 million exports to Communist countries (FY70)
Imports: $268 million (c.i.f., FY70); textiles, petroleum products, vehicles,
tea, wheat; $22.2 million imports from Communist countries (1968)
Major trade partners: U.K.. West Germany, Italy, India, U.S.S.R.
Monetary conversion rate: 1 Sudanese pound=US$2.87 (official); 0.348 Sudanese
pound=US $1
Fiscal year: 1 July - 30 June
GNP: $255 million (1970 est.); $640 per capita; real growth rate 1970, 8%
Agriculture: main crops -- rice, sugarcane, bananas; self-sufficient in major
staple (rice); caloric intake 2,350 calories per day per capita (1968)
Major industries: bauxite mining, alumina and aluminum production, lumbering,
food processing
Electric power: 220,000 kw. capacity (1970); 1.2 billion kw.-hr. production
(1970), 3,190 kw.-hr. per capita
Exports: $138 million (f.0.b., 1970); bauxite, alumina, wood and wood products ,
rice
Imports: $115 million (c.i.f., 1970); capital equipment, petroleum, iron and
steel, cotton, flour, meat, dairy products
Major trade partners: exports -- U.S. 53%, Canada 5%, Netherlands 10%; imports
-- U.S. 38%, Netherlands 24%, Europe 18% (1968)
Aid: economic -- extensions from U.S. (FY54-70), $5.0 million loans, $4.7 million
grants; from international organizations (FY49-70), $33.2 million
Monetary conversion rate: 1.77 Surinam guilders (S. f1?.)=US$1 (31 December 1971)
Fiscal year: calendar year
oan Oe million (1968), about $190 per capita; real growth rate about
Agriculture: main crops -- maize, cotton, rice, sugar, and citrus fruits
Major industry: mining
Electric power: 63,300 kw. capacity (1971); 204 million kw.-hr. produced (1971),
490 kw.-hr. per capita
321
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $70 million (f.o.b., 1970); iron ore, asbestos, sugar, wood and forest
products, citrus, meat products, cotton
Imports: $60 million (f.o.b., 1970); food products, manufactured goods, machinery,
fertilizer, fuel
Major trade partners: Japan, U.K., South Africa
Aid: economic aid -- U.K. $14.7 million (budgeted, 1971-73), others approximately
$1.3 million; no military aid
Monetary conversion rate: 1 South African Rand=US$1.33 (Swaziland uses the South
African Rand) (official); 0.750 SA Rand=US$1
Fiscal year: 1 April - 31 March','3f8b7758ef0f4700da06950dd75aabfabe414341e1ca0b03bf3d802aa7d94414','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5dd1ab47204fef62ab29726f49d75806f034cf9f0563c6284af890ef987e316',1972,'SE','Sweden','economy',416,'GNP: $35.0 billion, $4,300 per capita (1971); 52.3% consumption, 23.9% investment,
23.1% government; 0.7% net exports of goods and services; 1971 growth rate
0.3% in constant prices
323
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Agriculture: animal husbandry predominates with milk and dairy products
accounting for 40% of farm income; main crops -- grains, sugar beets,
potatoes; 90% self-sufficient; food shortages -- oils and fats, tropical
products; caloric intake, 2,880 calories per day per capita (1967-68)
Major industries: iron and steel, precision equipment (bearings, radio and
telephone parts, armaments), shipbuilding, wood pulp and paper products,
processed foods, textiles, chemicals
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 5.3 million metric tons produced (1971), 650 kilograms per capita
Electric power: 16.5 million kw. capacity (1971); 65 billion kw.-hr. produced
(1971), 7,780 kw.-hr. per capita ‘
Exports: $7,375 million (f.0.b., 1971}; machinery, motor vehicles
and ships, wood pulp, paper products, iron and steel products, metal ores
and scrap, chemicals :
Imports: $6,997 million (c.i.f., 1971); machinery, motor vehicles, petroleum and
petroleum products, textile yarn and fabrics, iron and steel, chemicals, food,
and live animals
Major trade partners: (1970) West Germany 15.4%, U.K. 13.4%, U.S. 7.4%, Norway
7.9%, Denmark 8.8%; EFTA 40%; EC 31.0%; Communist countries 5.4%
Aid: economic -- U.S.. $188.1 million authorized (FY46-70); none since 1968;
net official aid to less developed countries and multilateral agencies, $662.4
million (1960-70), $71.4 million in 1968, $120.8 million in 1969, $154.6
million in 1970, $180 million in 1971
Monetary conversion rate: 4.81 kronor=US$1 (1971)
Fiscal year: 1 July - 30 June','30bd71f69bd2f8cdd82207ccbc5ed1120bf87a7dd8b14f9542666edd60af2fdf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1102c6c5beebe89c704d69155207546d8bdfc8141ca041eb1e0ba1778617f414',1972,'CH','Switzerland','economy',420,'GNP: $26.2 billion (1971), $4,110 per capitas 57% consumption, 29% investment,
12% government, net foreign balance 2% (1970); 1971 growth rate 4%, 1958
constant prices
325
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Agriculture: dairy farming predominates; less than 50% self-sufficient; food
shortages -- fish, refined sugar, fats and oils {other than butter), grains,
eggs, fruits, vegetables, meat; caloric intake, 2,990 calories per day per
capita (1967-68 est.)
Major industries: machinery, chemicals, watches, textiles, precision instruments
Shortages: practically all important raw materials except hydroelectric energy
Crude steel: 453,000 metric tons produced (1969), 70 kg. per capita
Electric power: 10.3 million kw. capacity (1971); 35,245 million kw.-hr. produced
(1970), 4,220 kw.-hr. per capita
Exports: $5.8 billion (f.o.b., 1971); principal items -- machinery and equip-
ment, chemicals, precision instruments, textiles, foodstuffs
Imports: $7.2 billion (c.i.f., 1971); principal items -- machinery and trans-
portation equipment, metals and metal products, foodstuffs, chemicals,
textile fibers and yarns
Major trade partners: West Germany 23%, France 11%, U.S. 8%, Austria 5%, Italy
9%, U.K. 8%; EC 50%; EFTA 20%; Communist countries 4% (1971)
Aid: some disbursed; none received
Monetary conversion rate: 4.0841 Swiss francs=US$1 {central rate)
Fiscal year: calendar year
NDP: $1.30 billion (1970), $220 per capita; real NDP growth rate 3.4%
Agriculture: main crops -- cotton, wheat, sugar beets and barley; sheep and goat
raising; self-sufficient in food in years of average weather
Major industries: textiles, cement, glass, petroleum (118,000 bpd. production,
refining capacity 54,000 bbis. per day, 1971) food processing, soap
Electric power: 360,000 kw. capacity (1970); 1.2 billion kw.-hr. produced
(1970), 193 kw.-hr. per capita
327
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Exports: $203 million (1970); 40% cotton, grain and wool in good years,
livestock (Eastern Europe and U.S.S.R. received about 27%)
Imports: $360 million (c.i.f., 1970); machinery and metal products, textiles,
fuels, foodstuffs (Communist countries supply about 26%)
Monetary conversion rate: 3.82 Syrian pounds=US$1 (controlled rate); 4.32 Syrian
pounds=US$1 (free rate) (January 1972)
Fiscal year: calendar year
Mainland: ; :
GDP: $1,083 million at 1966 prices (1970), about $80 per capita; growth rate in
constant 1966 prices for 1967-70 4.4%
Agriculture: main crops -- cotton, coffee, sisal on mainland; largely self-
sufficient in food
Fishing: catch 182,000 tons, $23.8 million (1970)
Major industries: primarily agricultural processing (sugar, beer, cigarettes,
sisal twine), diamond mine, oi] refinery, shoes, cement, textiles, wood
products
Electric power: 119,500 kw. capacity (1971); 460 million kw.-hr. produced (1971),
34 kw.-hr. per capita
Exports: $259 million (f.0.b., 1970); coffee, cotton, sisal, cashew nuts, meat,
diamonds, cloves, tobacco, tea
Imports: $318.4 million (c.i.f., 1970); manufactured goods, machinery and transport
equipment, cotton piece goods, crude oi1, foodstuffs (mainly for Zanzibar)
Major trade partners: exports -- China, U.K., Hong Kong, India, Kenya, U.S.;
imports -- U.K., China, Kenya, West Germany, U.S., Japan
Monetary conversion rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian
shillings=US$1
Fiscal year: 1 July - 30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops -- cloves, coconuts
Industries: agricultural processing
Electric power: see Tanganyika (above)
Exports: $12.6 million (1968); cloves and clove products, coconut products
Imports: $5.6 million (1968); mainly foodstuffs and consumer goods
Major trade partners: imports -- China, Japan, and mainland Tanzania;
exports -- Singapore, China, Hong Kong, Indonesia, India, Pakistan
Aid: U.K. principal source of aid until 1964; China is currently major source
Exchange rate: 1] Tanzanian shilling=US$0.14; 7.143 Tanzanian shillings=US$1
Fiscal year: 1 July - 30 June','d420c31a39b044c257922ba51b9059a899782c5c44184b4237bf7e38bc7e78b9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f076e8c82cd28566b7dba098b9c89239232820f4feae10308fb9440b84297d0',1972,'TH','Thailand','economy',424,'GDP: $6.5 billion (1970 est. in current prices), $175 per capita; estimated 6%
real growth in 1970
Agriculture: world''s second largest rice exporter; main crops -- rice, rubber,
corn; almost 100% self-sufficient in food
Fishing: catch 1.27 million tons, $220 million (1969); exports -- none, imports--
none (1969)
Major industries: agricultural processing, textiles, wood and wood products,
cement, tin mining; non-Communist world''s third largest tin producer
Shortages: fuel sources, including coal and petroleum
Electric power: 1,326,000 kw. capacity (i971) 5 5.5 billion kw.-hr. produced
(1971), 149 kw.-hr. per capita
Exports: $833 million (f.o.b., 1971); rice, corn, rubber, tin, cassava, kenaf
33]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Imports: $1,283 million (c.i.f., 1971); excluding U.S. military imports;
machinery and transport equipment, textiles, fuels and lubricants, base
metals, chemicals
Major trade partners: exports -- Japan, U.S.. Singapore, Hong Kong, Netherlands,
Malaysia; imports -- Japan, U.S.. West Germany, U.K.; about 1% or Jess trade
with Communist countries
Monetary conversion rate: 20.8 baht=US$1
Fiscal year: 1 October - 30 September','07b827e92cc464c35edd08f14aa131013c6e94106651ba102c2ec8c51799ea45','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d282d28a6ba7a674d6b0d80625ed0eaf993348fc080460851b6c403b92482234',1972,'TG','Togo','economy',428,'GDP: $267 million (FY70), about $140 per capita; estimated real growth 1966-70, 5.3%
average annual rate
Agriculture: main cash crops -- coffee, cocoa; major food crops -- yams, cassava,
corn, beans, rice, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural processing, handicrafts,
textiles, beverages
Electric power: 18,750 kw. capacity (1971); 63 million kw.-hr. produced (1971),
30 kw.-hr. per capita
Exports: $54.8 million (f.o.b., 1970); phosphates, cocoa, coffee, palm
kernels, and cassava
Imports: $64.7 million (c.i.f., 1970); consumer goods,
fuels, machinery, tobacco, foodstuffs
333
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Major trade partners: mostly with France and other EC countries
Aid: (1970 disbursements) France $2.3 million, West Germany $2.0 million, U.S.
$0.7 million (FY60-70 total commitments $16.2 million), EC $5.5 million,
U.N. $1.8 million, others $1.1 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; 255.78 CFA francs=US$1
Fiscal year: calendar year','bcd4ccd3f95e4c9795b5f5fd410ea52b8080bd84a70526f6ac99cb89f28a5400','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83f0cdde8e94dc34d90571bf182a35db9fe183fb4d79f42e154ca7a4464f4e13',1972,'TO','Tonga','economy',432,'Agriculture: largely dominated by coconut production with subsistence crops of
taro, yams, sweet potatoes, and bread fruit
Electric power: 1,500 kw. capacity (1971); 4.5 million kw.-hr. produced (1971),
50 kw.-hr. per capita
Exports: $3.8 million (f.0.b., 1969); copra, coconut products 71%, bananas 20%
Imports: $5.7 million (c.i.f., 1969)
Major trade partners: (1969) exports -- 30% New Zealand, 30% Norway, 15%
Netherlands; imports -- 32% New Zealand, 25% Australia, 13% U.K.
Monetary conversion rate: 0.893 Tonga dollar=US$1','612f1f9e5ceb01624c2689f6b1221c149699927f8fccea24b7ed810ce74f868b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4ea9cab71c9c921dbbd55b39df6fe55b8c406de0b2a902f682c69262f25bac1',1972,'TT','Trinidad and Tobago','economy',435,'GDP: $858.5 million (1970 est.), $820 per capita; real growth rate 1970, 1.9% est.
Agriculture: main crops -- sugarcane, cocoa, coffee, rice, citrus, bananas;
largely dependent upon imports of food
Fishing: catch 4,000 metric tons (1969); exports $1.5 million (1969),
imports $2.3 million (1969)
Major industries: petroleum, tourism, food processing, cement
Electric power: 285,000 kw. capacity (1969); 1.21 billion kw.-hr. produced (1969),
1,170 kw.-hr. per capita
Exports: $482 million (f.o.b., 1970 est.); petroleum and petroleum products,
sugar, cocoa
Imports: $544 million (c.i.f., 1970 est.); crude petroleum, machinery,
transportation equipment, manufactured goods, food
Major trade partners: exports -- U.S. 46%, U.K. 10%, CARIFTA 10%; imports --
Venezuela and Colombia 25%, U.S. 16%, U.K. 13%, CARIFTA 2% (1970)
Aid: economic -- extensions from U.S. (FY56-70) $22.7 million loans, $40.1
million grants; from international organizations (FY53-70), $60.2 million
Monetary conversion rate: TT$1.84=US$1
Fiscal year: calendar year','ac1d0a28b884f25185ed7bad61266dab57cf21c1ff0c83554932dffb46270d79','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7fc180006230178c14d2781a75d717af6a65a0c2945eaddb51961413a4ac44d',1972,'TN','Tunisia','economy',439,'« - Agriculture: cereal farming and livestock herding predominate; main crops --
eae barley, olives, fruits (especially citrus), viticulture, vegetables,
ates
Major industries: mining, food processing, textiles and leather, light
manufacturing, construction materials, chemical fertilizers
Electric power: 270,000 kw. capacity (1971); 680 million kw.-hr. produced (1971),
127 kw.-hr. per capita
Monetary conversion rate: 0.48 dinar=US$1
Fiscal year: calendar year
339
cers
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
GNP: $12,016 million (1971), about $330 per capita; 6.5% average annual real
growth 197]
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2,172,000 kw. capacity (1970); 7,897 million kw.-hr. produced
(1970), 218 kw.-hr. per capita
Exports: $588.5 million (f.o.b., 1970); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $447.7 million (c.i.f., 1970); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: EC 37.3%, EFTA 18.1%, North America 16.9%, Communist
countries 13.8% (1969)
Monetary conversion rate: 15 Turkish Tiras=US$1 (official rate)
Fiscal year: 1 March - 28 February','51a5c91126b2d95ad223340d00ef7d22e148e13f65eb3f58d8135b76e96bdd9a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f1a903c659cf8282a408dab990554651c9e9d50cad26744bb1290f786d46a4c',1972,'UG','Uganda','economy',443,'GDP: $1,017 million (1970), $100 per capita; 7.3% real growth between 1965 and
1970
Agriculture: main cash crops -- coffee, cotton; other cash crops -- sugar,
tobacco, fish, tea, livestock; self-sufficient in food
Fishing: catch 124,500 metric tons
Major industries: agricultural processing (textiles, Sugar, coffee, plywood,
beer), cement, copper smelter, corrugated iron sheet, shoes, fertilizer
Electric power: 150,000 kw. Capacity (1971); 793 million kw.-hr. produced
(1971), 78 kw.-hr. per capita
Exports: $261.4 million (f.0.b., 1970); coffee, cotton, copper, tea; $7.6 million
to Communist countries (c.i.f., 1968)
Imports: $204.8 million (c.i.f., 1970); petroleum products, machinery, cotton
piece goods, metals, transport equipment; $7 million From Communist countries
(c.i.f., 1968)
Major trade partners: U.K., U.S., Kenya (Uganda, Kenya, and Tanzania form
East African Economic Community)
343
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d): ; ee
Monetary conversion rate: 7.143 Uganda shi llings=US$1; 1 Uganda shill ing=US$0.14
Fiscal year: | July - 30 June
Agriculture: principal food crops -- grain (especially wheat), potatoes; main
industrial crops -- sugar beets, cotton, sunflowers, and flax; degree of
self-sufficiency depends on fluctuations in crop yields; given normal yields,
U.S.S.R. is self-sufficient; caloric intake, 3,000-3,200 calories per day
per capita in recent years
345
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Fishing: catch 7,900,100 tons (1970); exports $80,866 ,000 (1970), imports
$16 ,546 ,501 (1970)
Major industries: diversified, highly developed capital goods industries; consumer
goods industries comparatively less developed
Shortages: natural rubber, bauxite and alumina, tantalum, tin, and tungsten
Crude steel: 130 million metric ton capacity as of 1 January 1972; 120.7
million metric tons produced ¢in 1971, 490 kilograms per capita
Exports: fuels (particularly petroleum and derivatives), metals, agricultural
products (timber, grain) and a wide variety of manufactured goods (primarily
capital goods); $12,800 million (f.o.b., 1970)
Imports: specialized and complex machinery and equipment, textile fibers, consumer
manufactures, and any significant shortages in domestic production (for
oe vee imported following poor domestic harvests); $11,738.9 million
f.o.b., 1970
Major trade partners: $24.5 billion (1970); trade 65% with Communist countries,
21% with industrialized West, and 14% with less developed countries
Official monetary conversion rate: 0.823 rubles=US$1; 1 ruble=US$1.215]
Fiscal year: calendar year','b192545a9e8c9715307988940396bfca6a591630cc4d1e2861ed0431486c2c18','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0882726e733a22cfcddf3dee2a07437cecc3884ee5c959e5fdb07236aec0c5ca',1972,'AE','United Arab Emirates','economy',447,'Agriculture: food imported, but some dates, alfalfa, vegetables, fruit, tobacco
raised
Major industries: fishing, trading, oi] production; oi] production began in Abu
Dhabi in 1962, and in 1971 reached 934,000 bbls. per day; oi] revenues
accruing to Abu Dhabi estimated $385 million in 1971; Dubai has best port
and is commercial center -- oi1 was discovered in commercial quantities in
1966; production began in 1969, 1971 production 125,000 b.p.d.; oi] revenues
for 1970 estimated at $33 million; small fishing, some boat building,
handicrafts, animal husbandry, pearling throughout area
Electric power: 36,000 kw. capacity (1970); 90 million kw.-hr. produced (1970),
676 kw.-hr. per capita
Exports: crude petroleum, pearls, fish; Abu Dhabi crude exports $244 million (est.
1968) and Dubai $20 million total, of which $18.8 million reexports (1968)
Imports: food, consumer and capital goods; Abu Dhabi $120 million estimated
(1969) and Dubai $197 million total (1970)
Major trade partners: Japan, U.K., India
Aid: multilateral annual average (1967-69) $1.17 million
Monetary conversion rate: 1 Oatar-Dubai riyal=US$0.23; Abu Dhabi, 1 Bahrain
dinar=US$2.27 (as of March 1972)
347
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
GDP: $308 million (1970 est.), $60 per capita
Agriculture: cash crops -- peanuts, shea nuts, sesame, cotton; food crops --
sorghum, millet, corn, rice; livestock; largely self-sufficient
Fishing: catch 5,000 tons (1969), $2.7 million
Major industries: agricultural processing plants, brewery, bottling, and brick
plants; a few other light industries
35]
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Electric power: 13,530 kw. capacity (1971); 38 million kw.-hr. produced (1971),
7 kw.-hr. per capita
Exports: $21 million (f.0.b., 1970); livestock (on the hoof), peanuts, shea
nut products, cotton, sesame
Imports: $54 million (c.i.f., 1970); textiles, food, and other consumer goods,
transport equipment, machinery, fuels
Major trade partners: volume understated because much regional trade is unrecorded;
Ivory Coast and Ghana; overseas trade mainly with France and other EC
countries; preferential tariff to EC and franc zone countries
Aid:
economic -- France (1964-September 1970) $46 million; EC (1960-70) $56.7
million; U.S.S.R., Ghana, West Germany, and Israel have also extended aid;
U.S. (FY61-70) $14.5 million; international organizations (1960-70) $12.1 million;
military -- France, $3.7 million (1964-70); U.S., $0.1 million (1962-70)
Monetary conversion rate: 255.785 Conmunaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year','0a0eafc45801c924341c561b3d253eeaccefe15e80b425a6bcd242f3fd1b2978','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a92d929be4b4c0771a1d0ac172f3f38d6343f4d5424a50d12cf1041af658f274',1972,'UY','Uruguay','economy',451,'GNP: $3.2 billion (purchasing power parity estimate, 1970); $1,110 per capita;
74% private consumption, 12% public consumption, 14% gross investment (1969);
real growth rate 1970, 4.4% Men,
Agriculture: large areas devoted to extensive livestock grazing (22 million
sheep, 8 million cattle); main crops -- wheat, rice, corn; self-sufficient
in most basic foodstuffs; caloric intake, 3,000 calories per day per capita,
with high protein content
Major industries: meat processing, wool and hides, textiles, footwear, cement,
petroleum refining
Crude steel: 24,000 metric tons produced (1966), 10 kilograms per capita
Electric power: 575,000 kw. capacity (1970 est.); 2.1 billion kw.-hr. produced
(1970 est.), 724 kw.-hr. per capita
Exports: $233 million (f.o.b., 1971); beef, wool, hides
Imports: $222 million (c.i.f., 1971); fuels, metals, machinery, transportation
equipment
Major trade partners: exports -- EC 27%, U.K. 25%, U.S. 12%, LAFTA 11%;
imports -- LAFTA 26%, U.S. 22%, U.K. 14%, EC 13% (1968)
Aid:
economic -- extensions from U.S. (FY46-70), loans $115.5 million, grants
$21.6 million; from international organizations, IBRD $108.5 million, IDB
$67.2 million, U.N. $9.4 million; $6 million credit from East Germany (1966),
$10 million credit from Hungary (1969), $20 million credit from U.S.S.R.
(1969), $5 million credit from Czechoslovakia (1970), $.4 million credit from
Bulgaria (1969); military -- U.S. (FY53-70), grants $42.4 million, $0.3 million
credits
Monetary conversion rate: trade -- 500 pesos=US$1; financial -- floating (795
pesos=US$1 on 24 March 1972)
Fiscal year: calendar year
The banking and financial activities of the Vatican are worldwide; the Institute
for Religious Agencies carries out fiscal operations and invests and transfers
funds of Roman Catholic religious communities throughout the world; the
355
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
GNP: $12.3 billion (purchasing power parity estimate, 1971), $1,140 per capita;
64% private consumption, 14% public consumption, 22% gross investment (1970),
real growth rate 1971 est. 5%
Agriculture: main crops -- cotton, sugarcane, corn, coffee, rice; self-sufficient
in most basic foods; caloric intake 2,600 calories per day per capita (1964)
357
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Fishing: catch 135,000 tons metric, $26.4 million (1970); exports $10 million
(1970 est.), imports $0.6 million (1970 est.)
Major industries: petroleum, iron-ore mining, construction, food processing,
textiles
Crude steel: 923,000 metric tons produced (1970), 90 kilograms per capita
Electric power: 3.9 million kw. capacity (1970); 12.9 billion kw.-hr. produced
(1970), 1,290 kw.-hr. per capita
Exports: 2,656 million (f.0.b., 1970); petroleum, iron ore, coffee, cocoa
Imports: $1,994 million (c.i.f., 1970); industrial machinery and equipment,
chemicals, manufactures, wheat
Major trade partners: U.S. 41%, Canada 9%, U.K. 5% (1969)
Aid:
economic -~ extensions from U.S. (FY46-70), $345.9 million loans; $57.4
million grants; from international organizations (FY46-70), $517.0 million;
from Communist countries (1954-71), $10 million;
military -- assistance from U.S. (FY53-70), $105.8 million
Monetary conversion rate: 4.40 bolivares=US$1 (selling rate)
Fiscal year: calendar year
Agriculture: mainly subsistence; main crops -- rice, corn, sweet potatoes,
manioc, sugarcane; food shortages -- rice, meat, sugar; caloric intake,
1,700-2,200 calories per day per capita
Major industries: food processing, textiles, machine building, mining, cement
Shortages: petroleum, complex machinery and equipment, fertilizer, foodstuffs
Monetary conversion rate (nominal): 3.7 dong=US$1
Fiscal year: calendar year
GNP: $2.0-2.5 billion (est. 1971), $110-130 per capita; 1.4% average annual real
growth (1966-71)
Agriculture: main crops -- rice, rubber, peanuts, corn, sugarcane, sweet potatoes,
copra; major food imports -- rice, dairy products, sugar, wheat flour
Fishing: catch 577,450 metric tons (1970 est.); trade in fish and fish products
insignificant
Major industries: manufacturing on small scale, mainly light manufacturing and
processing of local agricultural and forest products; factories produce
textiles, beer, cigarettes, glass, tires, sugar, paper, cement, soft drinks;
there are also limited mining operations
Shortages: capital goods
Electric power: 765,000 kw. capacity (1971); 1.7 billion kw.-hr. produced (1971),
90 kw.-hr. per capita
Exports: $13 million (f.0.b., 1970); major commodities -- rubber, scrap metal,
duckfeathers
Imports: $779 million (c.i.f., 1970); major commodities -- machinery and trans-
portation equipment, rice, textile fabrics and yarn, petroleum products, base
metals and manufactures
Major trade partners: exports -- France, U.K., West Germany, Japan; imports --
U.S.. Japan, Taiwan; no trade with Communist countries
Monetary conversion rate: multiple exchange rate system with flexible rates; as
of 1 April 1972 rates were as follows: 285 piasters=US$1 for U.S.-financed
merchandise imports; 410 piasters=US$1 for other merchandise imports, exports,
and most invisible transactions such as personal currency conversions, foreign
investment, and government transfers; black market rate of 429 piasters=US$1
during first quarter of 1972
Fiscal year: calendar year
GNP: $25 million (1967 est.), $170 per capita
poe eS: cocoa, bananas, copra; staple foods include coconut, bananas, taro,
and yams
Electric power: 6,900 kw. capacity (1971); 17 million kw.-hr. produced (1971),
123 kw.-hr. per capita
Exports: $6.3 million (1971); copra, cocoa, bananas
Imports: $12.8 million (1971)
Major trade partners: exports -- New Zealand, West Germany, the Netherlands; imports
-- New Zealand, Australia, Japan
Aid: New Zealand, $2.5 million committed; U.S.. $2 million extended (FY67-70)
Monetary conversion rate: WS$l=approximately US$1.50
Major industries: timber, tourism
363
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Agriculture (all outside Aden): cotton is main cash crop; cereals, dates, kat
(gat), coffee, and livestock are raised and there is a small fishing
industry; large amount of food must be imported (particularly for Aden);
cotton, hides, skins, dried and salted fish are. exported
Major industries: petroleum refinery (production 150,000 bb1s. per day) mid 1971;
capacity 178,000 bbis. per day at Little Aden operates on imported crude; oi]
exploration activity
Exports: $146 million (f.o.b., 1970)
Imports: $201 million (c.i.f., 1970)
Electric power: 108,000 kw. capacity (1970); 378 million kw.-hr. produced (1970),
290 kw.-hr. per capita
Major trade partners: Yemen, East Africa, but some cement and sugar imported from
Communist countries; crude oil imported from Persian Gulf, exported mainly
to U.K. and Japan
*Includes Aden and 16 members of the former Protectorate of South Arabia.
**Excluding the islands of Perim and Kamaran for which no data are available.
365
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Monetary conversion rate: 1S. Yemeni dinar=US$2.61
Fiscal year: 7 April - 31 March
Agriculture: sorghum and millet, qat (a mild narcotic), cotton, coffee, fruits
and vegetables; largely self-sufficient in food
Major industries: cotton textiles and leather goods produced on a small scale;
handicraft and some fishing; small aluminum products factory
Electric power: 4,000 kw. capacity (1970); 14 million kw.-hr. produced (1970),
2 kw.-hr. per capita
Exports: about $6 million (1970), qat, cotton, coffee, hides, vegetables
Imports: about $88 million (1970), textiles and other manufactured consumer goods ,
petroleum products, sugar, grain, flour, other foods tuffs, and cement
Major trade partners: exports -- over half to or through Aden, one-third to
pen countries; imports -- Aden, Communist countries (20%), Egypt,
apan
Monetary conversion rate: 1 Yemeni rial=US$0.20 as of March 1972
Fiscal year: 1 July - 30 June
GNP: $21.2 billion (est.) in 1971 (at 1970 prices), $1,030 per capita; 1971 growth
rate approx. 9%
Agriculture: diversified agriculture with many small private holdings and large
agricultural combines; main crops -- corn, wheat, tobacco, sugar beets, and
sunflowers; generally a net exporter of foodstuffs and live animals; self-
sufficient in food except for tropical products, cotton, wool, and vegetable
meal feeds; caloric intake, 3,210 calories per day per capita (1967)
Major industries: metallurgy, machinery and equipment, textiles, wood
processing, food processing
Shortages: fuels, steel, textile fibers, chemicals
Crude steel: 2.7 billion metric tons produced (1971), 130 kg. per capita
Exports: $1,816 million (f.o.b., 1971); 18% foodstuffs and tobacco; 17% raw
materials, fuels, and chemicals; 24% machinery and equipment; 41% other
manufactures
Imports: $3,253 million (c.i.f., 1971); 9% foodstuffs and tobacco; 26% raw
materials, fuels, chemicals; 31% machinery and equipment; 34% other
manufactures
Major trade partners: $5,069 million (1971); 71% non-Communist countries (35%
EC, 6% U.S.. 30% other non-Communist countries), 29% Communist countries
Aid: postwar credits extended mainly by the U.S. ($about 3 billion, including grants
and $700 million in military aid); Western Europe (over $950 million); IBRD
($585 million); IMF (over $400 million); Communist countries extended credits
totaling $464 million in 1956 ($125 million drawing balance suspended in 1958)
and $140 million during 1962-66 and $130 million in 1971; Yugoslavia has
extended credits totaling about $600 million to 27 less developed countries
of Africa, Asia, and Latin America
Monetary conversion rate: 17 dinars=US$1
Fiscal year: same as calendar year {all data refer to calendar year or to middle
or end of calendar year as indicated)
GDP: $2.1 billion (1971), about $90 per capita; real growth rate
« 6.5% p.a. 1968-7]
Agriculture: main cash crops -- coffee, palm oil, rubber; main food crops --
manioc, bananas, root crops, corn; some provinces self-sufficient
e Major industries: mining, mineral processing, light industries
Electric power: 751,380 kw. capacity (1971); 3.23 billion kw.-hr. produced
(1971), 143 kw.-hr. per capita
Exports: $798 million (f.0.b., 1970); copper, cobalt, diamonds , other minerals,
coffee, palm of]
Imports: $626 million (c.i.f., 1970); consumer goods , foodstuffs, mining
| and other machinery, transport equipment, fuels
Major trade partners: Belgium, U.S., and West Germany
371
| Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Aid: economic -- U.S. (FY62-70) $344 million; (1970 estimated disbursements )
Belgium, $27.4 million; France, $6.9 million; other bilateral aid $3 million;
U.N., $7.1 million; EC, $14.1 million military -- U.S., $25.8 million (FY62-70)
Monetary conversion rate: 1 zaire=US$2
Fiscal year: calendar year','3ce12d72abe9b91a0c4e1ab96fc72907c85d8f4341fa07cf9deae45b1a0ad1bf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9bf4f49d3d127fb90abc4fb4668e3aab7dbf9917a06be4813d8fdc2b34c5113',1972,'ZM','Zambia','economy',455,'GNP: ole aon nee (1970 est.), $410 per capita; real growth rate 11% between 1965
an
Agriculture: main crops -- corn, tobacco, cotton; net importer of all major
agricultural products
Fishing: catch 44,700 metric tons, $3.4 million (1969)
Major industries: copper mining and processing
Electric power: 788,200 kw. capacity (1971); 4,430 million kw.-hr. consumed
(1971), 1,030 kw.-hr. per capita
Exports: $756 million (f.o.b. 1971 est.); copper, zinc, cobalt, lead, tobacco
Imports: $532 million (f.0.b., 1971 est.); consumer goods , machinery, transport
equipment, foodstuffs, fuels
Major trade partners: U.K., South Africa, Japan, Western Europe
373
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ECONOMY (cont''d):
Aid:
economic -- China $200 million credit for Tanzam railroad (1970);
(1964-67) U.K, $63 million; IBRD $99 million (1970); U.S. $12 million;
U.S.S.R. $6 million; China extended $37 million;
military -- $9 million (1964-69), mainly U.K. and Canada
Monetary conversion rate: 1 Zambia kwacha-US$1.40 (official), 0.714 Zambia
kwacha=US$1
Fiscal year: calendar year
GNP: $1,047 billion (1971); 63% consumption, 14% private investment, 22% government,
-0.4% foreign; $5,060 per capita; 1971 growth rate 2.7%
Fishing: catch 2.4 million tons (1970)
Crude steel: 119 million metric tons produced (1970)
Electric power: 360,000,000 kw. capacity (1970); 1,638,000 million kw.-hr.
produced (1970), 7,980 kw.-hr. per capita
Exports: $44,137 million (f.0.b., 1971); machinery and transport equipment,
chemicals, cereals, mineral fuels
Imports: $49,190 million (c.i.f., 1971); transport equipment, machinery, mineral
fuels, steel, nonferrous metals, metal ores
Major trade partners: (1970) Canada 24%, EC 18%, Japan 13%, U.K. 6%
Official development assistance (aid): net disbursements $3,119 million (1970)
Fiscal year: 1 July - 30 June','e3fb56836915666a01bde91a9804a5364cb783ea98b4aed18fe8e6345341fe7b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f87a525f1dc9dc51edb05e3b56f860ba4444109c11735f0bc55a896f51d8502f',1972,'AF','Afghanistan','economy',7,'GNP: $2.8 billion (FY78 est.), $130 per capita;.real growth
rate about 3.7% (1970-78)
Agriculture: agriculture and animal husbandry account
for over 50% of GNP and occupy nearly 85% of the labor
force; main crops—wheat and other grains, cotton, fruits,
nuts; largely self-sufficient; food shortages—wheat, sugar,
tea
Major industries: cottage industries, food processing,
textiles, cement, coal mining
Electric power: 360,000 kW capacity (1977); 585 million
kWh produced (1977), 30 kWh per capita.
Exports: $340 million (f.o.b., FY78); fresh and dried
fruits, natural gas, karakul skins, carpets, hides, wool and
cotton
Imports: $410 million (f.o.b., FY78); non-metallic miner-
als, sugar, tires and tubes, textiles, tea, used clothing,
tobacco, transportation, and wheat
Major trade partners: exports—U.S.S.R., India, U.K.,
Pakistan, West Germany, Switzerland, U.S.; imports—Japan,
U.S:S.R., India, West Germany, U.K., U.S.
Budget: current expenditures $158 million, capital
expenditures $163 million for FY76
Monetary conversion rate: 45 Afghanis=US$1 (official,
early June 1978)
Fiscal year: 2] March-20 March','e3783af8f88da7d29c26372600cd65d44efe983e02170d28154d9a8d12378059','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4bba50d6359d81ed8a128cf06a9affb86400a62560bb6ccf5e6fb4d9b67c243',1972,'BG','Bulgaria','economy',13,'GNP: est. $748 million in 1970 (at 1970 prices), $300 per
capita
Agriculture: food’ deficit area; main crops—corn, wheat,
tobacco, sugar beets, cotton; food shortages—wheat; caloric
intake, 2,100 calories per day per capita (1961/62)
Major industries: agricultural processing, textiles and
clothing, lumber, and extractive industries
Shortages: spare parts, machinery and equipment, wheat
Electric power: 500,000 kW capacity (1977); 1.8 billion
kWh produced (1977), 710 kWh per capita
Exports: $746 million (1971-75 est.); 1964 trade—55%
minerals, metals, fuels; 23% foodstuffs (including cigarettes);
17% agricultural materials (except foods); 5%. consumer
goods
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
i TE et, ie, Ete, Mi I, i eR i ii, Be Ne el, ME Se ii lll
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ALBANIA/ALGERIA
Imports: $1,238 million (1971-75 est.); 1964 trade—50%
machinery, equipment, and spare parts; 16% minerals,
metals, -fuels, construction materials; 16% foodstuffs; 7%
consumer goods; 7% fertilizers, other chemicals, rubber; 4%
agricultural materials (except foodstuffs)
Monetary conversion rate: 5 leks=US$1 (commercial);
12.5 leks=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for consumption year 1 July-30 June
GNP: $20.9 billion, 1977 (at 1976 dollars), $2,360 per
capita; 1977 real growth rate, 0.4%
Agriculture: mainly self-sufficient; main crops—grain,
vegetables; caloric intake, 3,000 calories per day per capita
(1969/70)
Fishing: catch 160,000 metric tons (1976)
Major industries: agricultural processing, machinery,
textiles and- clothing, ‘mining, ore processing, timber
Shortages: some raw materials, metal products, meat and
dairy products; fodder ;
Crude steel: 2.6 million metric tons produced (1977), 290
kg per capita :
Electric power: 7,300,000 kW capacity (1977); 29.7
billion kWh produced (1977), 3,850 kWh per capita
Exports: $6,288 million (f.o.b., 1977); 46% machinery,
equipment, and transportation equipment; 15% fuels,
minerals, raw materials, metals, and other industrial
material; 2% agricultural raw materials; 29% foodstuffs, raw
materials for food industry, and animals; 10% industrial
consumer goods (1977)
- Imports: $6,198 million (f.0.b., 1977 est.); 89% machinery,
equipment, and transportation equipment; 45% fuels,
minerals, raw materials, metals, other materials; 7% agricul-
tural raw materials; 4% foodstuffs and animals; 5% industrial
consumer goods (1977)
Major trade partners: $12,486 million in 1977; 20% with
non-Communist countries, 56% with U.S.S.R., 24% with
other Communist countries
Monetary conversion rate: 0.948 leva=US$1 (1977)
Fiscal year: calendar year; economic data reported for
calendar years except for caloric intake, which is reported
for consumption year 1 July-30 June
NOTE: Foreign trade figures were converted at the 1977
rate of 0.911 leva=US$1
GDP: $3.7 billion (FY77, in current prices), $120 per
capita; real growth rate 6% (FY77); 2.5% over past decade
Agriculture: accounts for nearly 70% of total employment
and about 27% of GDP; main crops—paddy, sugarcane,
corn, peanuts; almost 100% self-sufficient; most rice grown
in deltaic land ;
Fishing: catch 501,560 metric tons (1976)
Major industries: agricultural processing; textiles and
footwear; wood and wood products; petroleum refining
Electric power: 450,000 kW capacity (1977); 890 million
kWh produced (1977), 30 kWh per capita
Exports: $208 million (f.0.b., 1977); rice, teak
Imports: $299 million (c.if., 1977); machinery and
transportation equipment, textiles, other manufactured
goods. SA Ms
Major trade partners: exports—Singapore, Western Eu-
rope, China, U.K., Japan; imports—Japan, Western Europe,
Singapore, U.K.
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Aa A Kh wa A ATA AT
Ae ee bh ee AR AA A om km Ae An Rene oe A A
oy eee, a Ow On
ee OD >
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BURMA/BURUNDI
Budget: (FY78) $2.765 billion revenues; $2.975 billion
expenditures; $210 million deficit; 30% military, 70%
civilian
Monetary conversion rate: 6.8608 kyat=US$] (market
rate July 1978)
Fiscal year: 1 April-31 March','c7b815bd624a71bd5b334e12c757d22dfb8cecce7a64919a5a1a35a5ff4a0114','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25ad2c81858ad4859500eca823385b8a93b3b822fc12fefd0269ef446e5538ad',1972,'DZ','Algeria','economy',17,'GDP: $19.6 billion (1977), $1,100 per capita; in real
terms, 8.8% growth in 1977
Agriculture: main crops—wheat, barley, grapes, citrus
fruits
Major industries: petroleum, light industries, natural gas,
mining, petrochemical, electrical, and automotive plants
under construction
Electric power: 1,700,000 kW capacity (1977); 4.5 billion
kWh produced (1977), 355 kWh per capita
Exports: $5.8 billion (f.0.b., 1977 est.); 90% hydrocarbons,
also wine, citrus fruit, iron ore, vegetables; U.S. took 56.2%
of Algerian crude oil, supplanting France as Algeria’s leading
trade partner
Imports: $6.9 billion (c.i.f., 1977); major items—capital
goods 35%, semi-finished goods 38%, foodstuffs 25%; from
France 23%, U.S. 9%
Monetary conversion rate: 1 DA=US$0.24
Fiscal year: calendar year
Economic activity in Gibraltar centers on commerce and
large British naval and air bases; nearly all trade in the
well-developed port is transit trade and port serves also as
important supply depot for fuel, water, and ships’ wares;
recently ‘built dockyards and machine shops provide
maintenance and repair services to 3,500-4,000 vessels that
call at Gibraltar each year.
U.K. military establishments and civil government employ
nearly half the insured labor force; local industry is confined
to manufacture of tobacco, roasted coffee, ice, mineral
waters, candy, beer, and canned fish; some factories for
manufacture of clothing are being developed; a small
segment of Jocal population makes its livelihood by fishing;
in recent years tourism has increased in importance.
Electric power: 40,000 kW capacity (1977); 80 million
kWh produced (1977), 2,760 kWh per capita
Exports: $23.87 million (1975-76), at exchange rate of 1]
pound =US$2.22; principally rexports of tobacco, petroleum,
and wine; 13% to U.K.
Imports: $60.0 million (1975-76), at exchange rate of 1
pound=US$2.22; 60% from U.K.
Major trade partners: U.K., Morocco, Portugal, Nether-
lands
Budget: (1975-76) revenue, $26.22 million; expenditure
$22.91 million, at exchange rate of 1 pound=US$2.22
Monetary conversion rate: 1 Gibraltar pound=
US$1.8062 (1976)','d6939b770e1a62d1fec821018f64feea3ec66baf338f30248244642e9405e78b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('346d4d8d531f2f5f5c218826c24d6c19a559eeeeaec6889a40f9b777442dfebf',1972,'AD','Andorra','economy',21,'Agriculture: sheep raising; small quantities of tobacco,
rye, wheat, barley, oats,-and some vegetables (less than 4% of
land is arable)
Major industries: tourism, sheep, timber, tobacco, and
smuggling
Shortages: food
Electric power: 25,000 kW capacity (1977); 100 million
kWh preduced (1977), 3,448 kWh per capita; power is
mainly exported to Spain and France
Major trade partners: Spain, France','48c9d3e8af7e1ad00c159e6da7e77a53bf79ca3b712cd85e68602bda71857751','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8ffdb25f2662e19633cfca2facc1f09f0a63b3d85f082cd5f8595e7202b4ee2',1972,'AO','Angola','economy',25,'GDP: $2.8 billion (1977), $440 per capita, 6.1% real
growth (1970-72); real GDP growth has declined by at least
15% since independence
Agriculture: cash crops—coffee, sisal, corn, cotton, sugar,
manioc, and tobacco; food crops—cassava, corn, vegetables,
plantains, bananas, and other local foodstuffs; largely
self-sufficient in food
Fishing: catch 153,580 metric tons (1975); exports $53.0
million; imports $5.6 million (1973)
Major industries: mining (oil, diamonds), fish processing,
brewing, tobacco, sugar processing, textiles, cement, food
processing plants, building construction
Electric power: 525,000 kW capacity (1977); 1.3 billion
kWh produced (1977), 210 kWh per capita
Exports: est. $900 million (f.o.b., 1977); oil, coffee,
diamonds, sisal, fish and fish products, iron ore, timber, corn,
and cotton; exports down sharply 1975-77
Imports: est. $720 million (f.o.b., 1977); capital equip-
ment (machinery and electrical equipment), wines, bulk iron
and ironwork, steel and metals, vehicles and spare parts,
textiles and clothing, medicines; military deliveries partially
offset drop in imports in 1975-77
Major trade partners: Cuba; U.S.S.R., Portugal, Eastern
Europe, and USS.
Budget: (1975) balanced at about $740 million by former
Portuguese administration; budget not yet published by new
GDP: $52 million (1977 est.), $720 per capita; 2.0% real
growth
Agriculture: main crop, cotton
Major industries: oil refining, tourism
“Shortages: electric power
Electric power: 31,200 kW capacity (1977); 60 million
kWh produced (1977), 780 kWh per capita
Exports: $22 million (f.0.b., 1975); petroleum products,
cotton
Imports: $54 million (c.i.f., 1975); crude oil, food, clothing
Major trade partners: 30% U.K., 25% U.S., 18%
Commonwealth Caribbean countries (1975)
Aid: economic—bilateral commitments, including Ex-Im
(1970-76) from Western (non-U.S.) countries, $13.9 million;
no military aid
Budget: (current) revenues, $12 million; current expendi-
tures, $15 million (1977/78)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)
Fiscal year: 1 April-30 March','71dc45c9414fd9186b37eeef92081f183757e3e55c09d5eedac62f4c2e6d9f3c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f75b02afb9a2061f29b99749416c2f03114c4c17ce57954554c072e7734be05',1972,'AR','Argentina','economy',29,'GNP: $48 billion (1977), $1,840 per capita; 18%
government consumption, 62% private consumption, 22%
investment, —2% net foreign demand (1975); real GDP
growth rate 1977, 4.4%
Agriculture: main products—cereals, oilseeds, livestock
products; Argentina is a major world exporter of temperate
zone foodstuffs
Fishing: catch 281,727 metric tons (1976); exports $42
million (1976 est.)
Major industries: food processing (especially meatpack-
ing), motor vehicles, consumer durables, textiles, chemicals,
printing, and metallurgy
Crude steel: 2.7 million metric tons produced (1977), 90
kg per capita
Electric power: 9.16 million kW capacity (1977); 27
billion kWh produced (1977), 1,040 kWh per capita
Exports: $5.7 billion (f.0.b., 1977); meat, corn, wheat,
wool, hides, oilseeds
Imports: $4.2 billion (c.if., 1977); machinery, fuel and
lubricating oils, iron and steel, intermediate industrial
products
Major trade partners (1977): exports—10% Netherlands,
8% Brazil, 8% Italy, 7% U.S., 5% Japan; imports—19% U.S.,
10% FRG, 9% Japan, 9% Brazil
Aid: (FY70-76) economic—from U.S. $248 million; from
other Western countries $797 million; from Communist
countries $458 million; military—from U.S. $137 million
Budget: (1978) 8,000 billion pesos=$9.4 billion at
exchange rate of mid-September 1978
Monetary conversion rate: 850 pesos=US$1 (mid-
September 1978)
Fiscal year: calendar year
Government budget: Colony—revenues, $1.0 million
‘(FY68); expenditures, $1.1. million (FY68)
Agriculture: Colony—predominantly sheep farming; de-
pendencies—whaling and sealing
Major industries: Colony—wool processing; depend-
encies—whale and seal processing
Electric power: 1,250 kW capacity (1977); 2.5 million
kWh produced (1977), 1,150 kWh per capita
Exports: Colony—$2.28 million (1969); wool, hides and
skins, and other; dependencies—no exports in 1968 or 1969
Imports: Colony—$].22 million (1969); food, clothing,
fuels, and machinery; dependencies—$8,368 (1969); mineral
fuels and lubricants, food, and machinery
Major trade partners: nearly all exports to the U.K., also
some to the Netherlands and to Japan; imports from
Curacao, Japan, and the U.K.
Aid: economic—Western (non-U.S.) countries, $13 million
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
~
PLU A A AAR AAD AA ee ee
We. EN ae
i A 7
ae
Ae ee ee ay Re Ne Ce Oe eS Ce Eee eR ee ee ee ee es ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FALKLAND ISLANDS/FAROE ISLANDS
Monetary conversion rate: 1 Falkland Island
pound = US$2.60
GNP: $3.1 billion (1976), $1,110 per capita; 74% private
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
A AAA ee A
ARAL AL AR AAA A AAA RA AR AAR A AA dO A A UO
ee Se ee eT ae ee
ra S
a te | A nd fe ie
GN TL FL I LI NINN I a NG Ne UL
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
URUGUAY/VATICAN CITY
consumption, 13% public consumption, 138% gross invest-
ment; real growth rate 1976, 1.5% e
Agriculture: large areas devoted to extensive livestock
grazing (17 million sheep, 11 million cattle); main crops— -
wheat, rice, corn; self-sufficient in most basic foodstuffs;
caloric intake, 3,000 calories per day per capita, with high
protein content
Major industries: meat processing, wool and_ hides,
textiles, footwear, cement, petroleum refining
Crude steel: rolled products 34,841 metric-tons produced,
castings 263 metric tons (1976)
Electric power: 700,000 kW capacity (1977); 3 billion
kWh produced (1977), 1,070 kWh per capita
Exports: $608 million (f.0.b., 1977); wool, hides
Imports: $730 million (c.i.f., 1977); fuels, metals, machin-
ery, transportation equipment
Major trade partners: exports—34% EC, 7% U.S., 29%
LAFTA; imports—29% LAFTA, 10% U.S., 20% EC (1975)
Aid: (FY70-76) economic—extensions from U.S. $60
million; from other Western countries $44 million; from
Communist countries $57 million; military—U.S. $39
million
Budget: (1977 est.) revenue, $623 million; expenditure,
$671 million ;
Monetary conversion rate: 5.46 pesos=US$! (January
1978)
Fiscal year: calendar year
‘The Vatican City, seat of the Holy See, is supported
financially by contributions (known as Peter’s pence) from
Roman Catholics throughout the world; some income
derived from sale of Vatican postage stamps and tourist
mementos, fees for admission to Vatican museums, and sale
of publications; industrial activity consists solely of printing
and production of a small amount of .mosaics and _ staff
uniforms ©
The banking and financial activities of the Vatican are
worldwide; the Institute’ for Religious Agencies carries out
fiscal operations and invests and transfers funds of Roman
Catholic religious communities throughout the world; the
Cardinal’s Commission controls the administration of ordi-
nary assets of the Holy See and a Special Administration
manages the Holy See’s capital. assets ,
Electric power: obtained from Rome city grid; standby
diesel: powerplant with 2,100 kW capacity (1977)
GNP: $33 ‘billion (1977, in. 1977 dollars), $2,590 per
capita; 48% private consumption, 15% public consumption,
31% gross investment, 6% foreign sector (1976); Teal growth
rate 6.5% (1974-77)
Agriculture: main crops—sugarcane, corn, coffee, rice;
imports wheat (U.S.), corn (South Africa), sorghum (Argen-
tina, U.S.); caloric intake 2,600 calories per day per capita
(1972) .
Fishing: catch 145,727 metric tons (1976); exports $28.4
million (1976), imports $2.0 million (1976)
Major industries: petroleum, iron-ore mining, construc-
tion, food processing, textiles
'' Crude steel: 750,000 metric tons produced (1976), 60 kg
per capita
Electric power: 6,540,000 kW capacity (1978); 28 billion
kWh produced (1978), 2,200 kWh per -capita
Exports: $9.5 billion (f.o.b., 1977); petroleum $9.0 billion,
iron ore, coffee ,
Imports: $8.9 billion (f.o.b., 1977); industrial machinery
and equipment, chemicals, manufactures, wheat
Major trade partners: imports—39% U.S., 11% Japan,
12% West Germany; exports—36% U.S., 13% Canada
Aid: economic — assistance—extensions from + U.S.
(FY46-76), $128 million loans; $73 million grants; from
international organizations (FY46-75), $658 million; from
Communist countries (1954-76), $10 million; military—
assistance from U.S. (FY46-76), $153 million
Budget: 1978—revenues $10.7 billion; expenditures, $10.4
billion, capital $4.2 billion
Monetary conversion rate: 5.3207 bolivares=US$1 (sell-
ing rate), June 1978
Fiscal year: calendar year','def38cf53f763a8cfba4b37b0c919308bb46c052b065f8af0f6581d5ffe9340d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('452ada15a78998037e5e53eaaa698160fd2f57b66f27a055ea01ee08b2b22720',1972,'AU','Australia','economy',33,'GNP: $95.2 billion (1977), $6,830 per capita; 60% private
consumption, 16% government current expenditure, 24%
investment (1975); 2% rea] average annual growth (1975-77)
Agriculture: large areas devoted to livestock grazing; 60%
of area used for crops is planted in wheat; major products—
wool, livestock, wheat, fruits, sugarcane; self-sufficient in
food; caloric intake, 3,300 calories per day per capita
Fishing: catch 113,961 metric tons (1976); exports $94.5
million (FY75), imports $86.2 million (FY75)
Major industries: mining, industrial and transportation
equipment, food processing, chemicals
Crude steel: 7.8 million metric‘tons produced (FY76), 570
kg per capita
Electric power: 22,457,000 kW capacity (1977); -84.1
billion kWh produced (1977), 6,070 kWh per capita
Exports: $13.4 billion (f.o.b., 1977); principal products
(1977)—44% agricultural products, 14% ‘metalliferous ores,
13% wool, 12% coal ; :
Imports: $13.6 billion (c.i.f., 1977); principal products
(1977)—41% manufactured raw materials, 28% capital
equipment, 25% consumer goods
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
AUSTRALIA/AUSTRIA
FEDERAL Son 2
. REPUBLIC
OF GERMANY
Major trade partners: (1977) exports—34% Japan, 9%
U.S., 5% New Zealand, 4% U.K.; imports—21% U.S., 11%
U.K., 21% Japan
Aid: economic—Australian aid abroad $2.3 billion
(FY65-75); $430 million (FY75), 55% for Papua New Guinea
Budget: expenditures, A$26.7 billion; receipts A$24.4
billion (FY78)
Monetary conversion rate: 0.87 Australian dollar=US$1
(A$1=US$1.15), September 1978
Fiscal year: ] July-30 June
GNP: $644 million (1975), $1,130 per capita; 5.8% real
growth rate (1971-75)
Agriculture: main crops—sugar, coconut products, ba-
nanas, ginger, rice; major deficiency, grains
Major industries: sugar processing, .tourism
Electric power: 90,000 kW capacity (1977); 270 million
kWh produced (1977), 450 kWh per capita
Exports: $187 million (f.o.b., 1977, including reexports);
70% sugar, 11% coconut oil, 9% gold
Imports: $279 million (f.o.b., 1977); 20% manufactured
goods, 19% food, 16% machinery, fuels, chemicals (1977)
Major trade partners: U.K., New Zealand, U.S., Canada,
Australia, Japan
Aid: disbursed 1968—Australia $1.5 million, U.S. $0.6
million, U.K. $4.2 million :
Budget: (FY75) revenues $107 million, expenditures $129
million
Monetary conversion rate: Fijian dollar=US$1.2119
(September 1978)
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
————SS
a,
EN Ne ee ee ee ee a eee ee ee ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FIJI/FINLAND
Fiscal year: calendar year
GDP: $740 per capita (1974)
Agriculture: copra, ‘subsistence crops of vegetables,
supplemented by domestic fishing
Industry: phosphate production, expected to:cease in 1978
Electric power: 16,000 kW capacity (1977); 45 million
kWh produced (1977), 820 kWh per capita
Exports: $8.6 million (1970 est.); 70% phosphate, copra
Imports: $3.1 million (1970 est.); foodstuffs, fuel
Budget: (est.) revenue 5.877 million NZ$, expenditure
4.577 million NZ$
Monetary conversion rate: 0.80 Australian$=US$1
March 1976
GNP: $43 billion (1977) about $310 per capita; real
average annual growth (1972-77), 7.7%
Agriculture: subsistence food production, and smallholder
and plantation production for export; main crops—rice,
rubber, copra, other tropical products; food shortage—rice,
wheat ;
Fishing: catch 1.6 million tons (1977); exports $150
million (1977), imports $8 million (1977)
Major industries: petroleum, agricultural processing,
textiles, mining
Electric power: 3,128,000 kW capacity (1977); 8.7 billion
kWh produced (1977), 65 kWh per capita
Exports: $10.9 billion (f.0.b., 1977); petroleum ($7.1
‘billion; 530 million bbls), timber, coffee, rubber, tin, palm
oil, tea, pepper, tobacco
Imports: $6.2 billion (c.i.f., 1977); rice, wheat, textiles,
chemicals, iron and -steel products, machinery, transport
equipment, consumer durables
Maior trade partners: exports (1977)—40% Japan, 28%
U.S., 9% Singapore; imports—30% Japan, 14% U.S., 8% West
Germany .
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
my
it
}
a
es a ee a ee” a
at oe os
we ae ee ee ee SS ee ee, a a a ee ee ee, ee ee ee eee
wr
x
a”
i is OE 2 tl i ll A cl. i a a eae i md | sa a
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
INDONESIA/IRAN
Budget: (1978-79) expenditures, $11.6 billion; planned
receipts, $9.6 billion domestic, $2.0 billion foreign
Monetary conversion rate: 415 rupiah=US$1
Fiscal year: 1 April-31 March ;
GNP: $75.9 billion (1977), $2,170 per capita; 1977 real
GNP growth, 2.8%
Agriculture: wheat, barley, rice, sugar beets, cotton, dates,
raisins, tea, tobacco, sheep, and goats
Major industries: crude oil production (2,080 million bbls
in 1977) and refining, textiles, cement and other building
materials, food processing (particularly sugar refining and
vegetable oil production), metal fabricating (steel and
copper)
Electric power: 6,300,000 kW capacity (1978); 20 billion
kWh produced (1978), 570 kWh per capita
Exports: $24.3 billion (f.0.b., 1977); 97% petroleum; also
carpets, raw cotton, fruits, and nuts, hide and leather items,
ores
Imports: $15.5 billion (f.0.b., 1977); machinery, iron and
steel products, chemicals, pharmaceuticals, electrical equip-
ment, agricultural products
Major trade partners: exports—Japan, U.S., West Ger-
many, Netherlands, Italy, U.K., Spain, France; imports—
U.S., West Germany, Japan, U.K., Italy
Budget: (FY78-79) $59.3 billion
Monetary conversion rate: 70.5 rials=US$1
Fiscal year: 21 March-20 March
GNP: $19 billion (1977 est.), $1,610 per capita
Agriculture: dates, wheat, barley, rice, livestock
Major industry: crude petroleum (third largest producer
in Middle East); 2.3 million b/d (1977); petroleum revenues
for 1977, $10.3 billion
Electric power: 2,300,000 kW capacity (1978); 7 billion
kWh produced (1978), 560 kWh per capita
Exports: $11.8 billion (f.0.b., 1978 est.); net receipts from
oil, $11.5 billion; non-oil, $300 million est.
Imports: $6.4 billion (f.o.b. 1978 est.); 26% from
Communist countries (1973)
Major trade partners: exports—France, Italy, Brazil,
Japan, Turkey, U.K., U.S.S.R., other Communist countries;
imports— West Germany, Japan, France, U.S., U.K., U.S.S.R.
and other Communist countries (1977)
Budget: $15.8 billion (FY78), estimated
Monetary conversion rate: 1 Iraqi dinar=US$3.39 (end
of December 1977)
Fiscal year: 1 January-31 December
GNP: over $120 million (1975), $17,140 per capita (est.)
Agriculture: negligible; almost completely dependent on
imports for food, water
Major industries: mining of phosphates, about 2 million
tons per year :
Electric power: 9,000 kW capacity (1977); 26 million °
kWh produced (1977), 3,710 kWh per capita
Exports: $120 million (f.0.b., 1975 est.); consisting entirely
of phosphates
Imports: $5 million (c.i.f., FY70)
Major trade partners: exports—75% Australia and New
Zealand; imports—Australia, U.K., New Zealand, Japan
Monetary conversion rate: 1 Australian dol-
lar=US$1.2375 (July 1976)
Fiscal year: 1 July-30 June
GNP: $193 million, $1,800 per capita (1971 est.)
Agriculture: large areas devoted to cattle grazing; major
products—coffee and vegetables; 60% self-sufficient in beef;
must import grains and vegetables
Industry: mining of nickel
Electric power: 320,000 kW capacity (1977); 1.7 billion
kWh produced (1977), 12,310 kWh per capita
Exports: $289 million (f.o.b., 1975); 99% nickel
Imports: $348 million (c.if,, 1975); machinery, transport
equipment, food :
Major trade partners: (1972) exports—55% France, 24%
Japan, 11% U.S.; imports—52% France, 13% Australia, 12%
rest of EC
Monetary conversion rate: 86 CFP francs=US$1 (1972)
Agriculture: export crops of copra, cocoa, coffee, some
livestock and fish production; subsistence crops of copra,
taro, yams
Electric power: 4,000 kW capacity (1977); 13 million
kWh produced (1977), 180 kWh per capita
Exports: $27 million (1974); 24% copra, 59% frozen fish
Imports: $44 million (1974)
Monetary conversion rate: 1 pound=US$2.37 (official
currency), 0.74 Australian $=US$1, 86 Colonial Franc
Pacifique (CFP)=US$1 (1972)
GNP: $12.8 billion (1976), $4,060 per capita; real average
annual growth (1975-77), 1.4%
Agriculture: fodder and silage crops about one-half of
area planted in field crops; main products—wool, meat,
dairy products; New Zealand is food surplus country; caloric
intake, 3,500 calories per day per capita (1964)
Fishing: catch 70,449 metric tons (1976)
Major industries: food processing, textile production,
machinery, transport equipment; wood and paper products
Electric power: 5,380,000 kW capacity (1977); 22.1
billion kWh produced (1977), 7,060 kWh per capita
Exports: $3.2 billion (f.o.b., 1977); principal products
(trade year 1977)—24% meat, 14% dairy products, 20% wool
Imports: $3.4 billion (c.if., 1977); 29% machinery, 23%
manufactured goods, 11% chemicals (trade year 1977)
Major trade partners: (trade year 1977) exports—20%
U.K., 18% Japan, 12% Australia, 11% U.S.; imports—21%
Australia, 17% U.K., 15% Japan, 18% US.
Aid: gross official aid deliveries to LDC and multilateral
agencies FY75, $80.1 million
Budget: expenditures, 3,827 million NZ$, receipts, 3,330
million NZ$ (FY75)
Monetary conversion rate: NZ$1 =US$1.0571, September
1978 ,
Fiscal year: 1 April-31 March
NOTE: trade data are for year ending 30 June; trade year
and fiscal year do not correspond
GNP: $1.5 billion (FY77 est.); real average annual growth
rate (1969-74) 7% est.
Agriculture: main crops—coconuts, coffee, cocoa, tea
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Pe eS ea ee an Sa aes
Fue an ak nk eee
Ta mF
ae a a tN a kt mlm
en i ee eS
em A a tn
ee
Ate sd dos db oe bd oe 4 ot Oh wb oan ke
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
PAPUA NEW GUINEA/PARAGUAY
Major industries: sawmilling and timber processing,
copper mining (Bougainville)
Electric power: 284,000 kW capacity (1977); 700 million
kWh produced (1977), 250 kWh per capita
Exports: $636 million (f.0.b., FY77); principal Droducts—
copper, coconut products, coffee beans, cocoa, copra, timber
Imports: $484 million (f.0.b., FY77)
Major trade partners: Australia, U.K., Japan
Aid: economic—Australia, $1,158 million committed
(1976-81); World Bank group (1968-September 1969), $7.5
million committed; U.S. (FY70-74), $32.5 million extended
Budget: (75-76) receipts 400 million Australian dollars,
expenditures 408 million Australian dollars
Monetary conversion rate: Kina $1 =US$1.45 (September
1978)
Fiscal year: 1 July-30 June
See Gilbert Islands for economic data
GNP: $490 million (1976 est.), $290 per capita
Agriculture (all outside Aden): cotton is main cash crop;
cereals, dates, kat (qat), coffee, and livestock are raised and
there is a growing fishing industry; large amount of food
must be imported (particularly for Aden); cotton, hides,
skins, dried and salted fish are exported
Major industries: petroleum refinery (production 150, 000
b/d) mid-1971; capacity 178,000 b/d at Little Aden operates
on imported crude; oil exploration activity
Electric power: 150,000 kW capacity (1977); 300 million
kWh produced (1977), 165 kWh per capita
Exports: $29 million (1977), excluding petroleum prod-
ucts. but including re-exports
Imports: $346 million (1977)
Major trade partners: Yemen, East Africa, but some
cement and sugar imported from Communist countries;
crude oil imported from Persian Gulf, exported mainly to
U.K. and Japan
Budget: (FY75-76)—revenues $40 million, expenditures
$102 million
Monetary conversion rate: 1 S. Yemeni dinar=US$2.90
Fiscal year: 1 April-31 March
GNP: $1,630 million (1976 est.), $300 per capita
Agriculture: sorghum and millet, qat (a mild narcotic),
cotton, coffee, fruits and vegetables; largely self-sufficient in
food
Major industries: cotton textiles and leather goods
produced on a small scale; handicraft and some fishing;
small aluminum products factory
Electric power: 50,000 kW capacity (1977); 100 million
kWh produced (1977), 20 kWh per capita
Exports: $19 million (f.o.b., 1976/77); qat, cotton, coffee,
hides, vegetables
Imports: $730 million (c.i.f., 1976/77); textiles and other
manufactured consumer goods, petroleum products, sugar,
grain, flour, other foodstuffs, and cement
Major trade partners: China, Yemen (Aden), U.S.S.R.,
Japan, U.K., Australia, Saudi Arabia
Budget: (FY75/76) $124 million revenue, $133 million
expenditures, $75 million development —
Monetary conversion rate: 1 Yemeni rial=US$0.22 as of
October. 1973
Fiscal year: 1 July-30 June
GNP: $48.0 billion (1977 est., at 1977 prices), $2,210 per
capita; real growth rate 5.7% (1971-77)
Agriculture: diversified agriculture with many small
private holdings and large agricultural combines; main
crops—corn, wheat, tobacco, sugar beets, and sunflowers;
occasionally a net exporter of foodstuffs and live animals;
imports tropical products, cotton, wool, and vegetable meal
feeds; caloric intake, 3,539 calories per day per capita (1975)
Major industries: metallurgy, machinery and equipment,
oil refining, chemicals, textiles, wood processing, food
processing
Shortages: electricity, fuels, steel
Crude steel: 3.2 million metric tons produced (1977), 150
kg per capita
‘Electric power: 10,800,000 kW capacity (1977); 48.6
billion kWh produced (1977), 2,230 kWh per capita
228
Exports: $5.25 billion (f.0.b., 1977); 32% machinery and
equipment; 23% intermediate goods; 45% other
Imports: $9.63 billion (c.i.f., 1977); 23% raw materials,
fuels; 35% machinery and equipment; 18% intermediate
goods; 24% other goods
Major trade partners: 67% non-Communist countries (6%
U.S., 44% other developed Western countries), 35% Commu-
nist countries
Aid: Yugoslav outstanding external debt (medium/long-
term) end 1976, $7 billion, of which $2.7 billion official,
largely non-Communist (U.S. $350 million, FRG $400
million, U.S.S.R. $200 million, IBRD $560 million end 1975);
Yugoslavia has extended aid totalling about $1.2 billion
(outstanding in 1976) to developing countries, largely since
the late 1960''s
Monetary conversion rate: (official) 18.25 new dinars=
US$1
Fiscal year: same as calendar year (all data refer to
calendar year or to middle or end of calendar year as
indicated)
GDP: $3.59 billion (1976 prices), $140 per capita; 1.8%
real annual growth rate 1970-77
Agriculture: main cash crops—coffee, palm oil, rubber;
main food crops—manioc, bananas, root crops, corn; some
provinces self-sufficient
Fishing: catch 124,580 metric tons (1975); imports $38
million (1974)
Major industries: mining, mineral processing, light
industries
Electric power: 117,858 kW capacity (1976); 5.1 billion
kWh produced (1977), 190 kWh per capita
Exports: $1.2 billion (f.o.b., 1977 projected); copper,
cobalt, diamonds, other minerals, coffee
Imports: $1 billion (f.o.b., 1977 projected); consumer
goods, foodstuffs, mining and other machinery, transport
equipment, fuels
Major trade partners: Belgium, U.S., and West Germany
Budget: 1977 proposed—revenue, 770 million; expendi-
tures, $976 million
Monetary conversion rate: ] zaire=US$0.831
Fiscal year: calendar year','2565dada40784b0c3642ba84ffe583702cdb8b7471015f0a0bb1ab52de2d3ba3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a455bd6702ec18045eaa2436ec2aa7d12006c4de5c914510b0714c8861c5270',1972,'AT','Austria','economy',38,'GNP: $47.8 billion (1977), $6,360 per capita; 58.4%
private consumption, 16.2% public consumption, 27.0%
investment, 1.7% stock building; —3.3% net foreign balance;
1977 real GNP growth rate, 3.5%
Agriculture: livestock, cereals, potatoes, sugar beets; 84%
self-sufficient; caloric intake 3,230 calories per day per
capita (1969-70)
Major industries: foods, iron and steel, machinery,
textiles, chemicals, electrical, paper and pulp
Crude steel: 4.1 million metric tons produced (1977), 550
kg per capita (1977)
Electric power: 11,500,000 kW capacity (1977); 38.3
billion kWh produced (1977), 5,015 kWh per capita
Exports: $11.0 billion (1977); iron and steel products,
machinery and equipment, lumber, textiles, paper products,
chemicals
Imports: $15.4 billion (1977); machinery and equipment,
chemicals, textiles and clothing, petroleum, foodstuffs
Major trade partners: (1977) 35.9% West Germany, 8.9%
Italy, 6.4% Switzerland, 3.9% U.K., 3.1% U.S.; 76.8% OECD,
59.0 EC; 11.4% Communist countries
Aid: (1970-76) bilateral economic aid authorized (ODA
and OOF), $364 million
Budget: expenditures, $14.3 billion; revenues, $11.8
billion; deficit, $2.5 billion (1977 est.)
Monetary conversion rate: 16.53 shillings=US$1, 1977
average
Fiscal year: calendar year','19c0dd0d6ee6b85b445c9f355c333085c2c3c2e077a5f95ec6f0ef6beb115ea1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bff1324e0aed78a7f3f469a558129f4f40967dd3ff5ee290961a14f4113603f5',1972,'HT','Haiti','economy',41,'GNP: $758 million (at market prices, 1977), $3,510 per
capita; real growth rate 1977, 3.5%
Agriculture: food importer, main crops—fish, fruits,
vegetables
Major industries: tourism, cement, ‘oil refining, }umber,
salt production, rum, aragonite, pharmaceuticals, spiral
weld, and steel pipe
12
Electric power: 250,000 kW capacity (1977); 680 million
kWh produced (1977), 3,150 kWh per capita
Exports: $2.4 billion (f.0.b., 1977); fuel oil, pharmaceuti-
cals, cement, rum
Imports: $2.1 billion (c.i.f., 1977); crude oil, foodstuffs,
manufactured goods
Major trade partners: non-oil exports—U.S. 41%, U.K.
12%, Canada 3%; non-oil imports—U.S. 73%, U.K. 13%,
Canada 2% (1973)
Aid: economic—bilateral commitments including Ex-Im
(1970-76) from U.S. $34.3 million; from other Western
countries, $136.6 million; no military aid
Budget: (1978 projected), revenues, $186 million; expend-
itures, $199 million
Monetary conversion rate: 1 = Bahamian dollar
(B$1)=US$1
Fiscal year: calendar year
GNP: $1.1 billion (1977), $230 per capita; real growth rate
1977, 1.9%
Agriculture: main crops—coffee, sugarcane, rice, corn,
sorghum, pulses; caloric intake, 1,850 calories per day per
capita
Major industries: sugar refining, textiles, flour milling,
cement manufacturing, bauxite mining, tourism, light
assembly industries
Electric power: 90,000 kW capacity (1977); 175 million
kWh produced (1977), 40 kWh per capita
Exports: $143 million (f.0.b., 1977); coffee, light industrial
products, bauxite, sugar, essential oils, sisal
Imports: $245 million (f.0.b., 1977); consumer durables,
foodstuffs, industrial equipment, petroleum products, con-
struction materials
Major trade partners: exports—77% U.S.; imports—51%
U.S. (1977)
Aid: economic—bilateral commitments including Ex-Im
(FY70-76) from U.S., $77.2 million; from other Western
countries, $51.7 million; military—U.S., $0.1 million
Budget: (1978/79 est.) revenue, $140 million; expendi-
ture, $257 million
Monetary conversion rate: 5 gourdes=US$1
Fiscal year: 1 October-80 September','a916be6b35462ae86da15f03fbcf11b607c1c32a1c4aba2d3f01436a594b0ec9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83bf66c0f4eb6ccd1a6e050babbf94c420ec8ef2e689e1f93da1988db656c78f',1972,'BH','Bahrain','economy',46,'GNP: $600 million (1976 est.), annual growth rate 4.1%
(1975-85 projected average), $2,430 per capita, dominated
by oil industry; 1977 average daily crude oil production,
56,000 bbls (oil expected to last 15° years if no new
discoveries are made); 1975 nonassociated natural gas
production, 102 billion ft?; government oil revenues for 1976
are estimated at $395.7 million -
Agriculture: produces dates, alfalfa, vegetables; dairy and
poultry farming; fishing; not self-sufficient in food
Major industries: petroleum refining, aluminum smelt-
ing, boatbuilding, shrimp fishing, pearls and sailmaking on a
smal] scale; major development projects include flourmill,
and ISA town; OAPEC dry dock to be built by 1977
. Electric power: 600,000 kW capacity (1977); 2.4 billion
kWh produced (1977), 8,450 kWh per capita
Exports: $1,840 million (f.o.b., 1977); non-oil exports
(including reexports), $396.8 million (1977); oil exports,
$1,443 million (1977)
Imports: $2,023 million (c.i.f., 1977)
Major trade partners: Saudi Arabia, U.K., U.S., Japan,
EC
Aid: received $110 million in bilateral commitments and
committed itself $8.5 million to multilateral agencies in
CY74
Budget: (1976) $489 million, 72% of revenues from oil
Monetary conversion rate: ] Bahrain dinar=US$2.52
(since January 1978)
Fiscal year: calendar year','71c8b7564db6299285c14a7fd26d70c4972df8794624341b93a669c8d6c99a91','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e351b886c29e74f93501782ba5dd50c584a08fc29e49fd8ab9bfd9b700af4883',1972,'BD','Bangladesh','economy',50,'GNP: $7.2 billion est. (FY78, current prices), $90 per
capita; real growth, 8% (FY78)
Agriculture: large subsistence farming, heavily dependent
on monsoon rainfall; main crops are jute and rice;
shortages—grain, cotton, and oilseeds
Fishing: catch 821,000 metric tons (FY76)
Major industries: jute manufactures, food processing and
cotton textiles
Electric power: 915,000 kW capacity (1977); 1.6-billion
kWh produced (1977), 20 kWh per capita
Exports: $498 million (FY78); raw and manufactured jute,
leather, tea —
Imports: $1,274 million (FY78 est.); foodgrains, fuels, raw
cotton, fertilizer, manufactured products
Major trade partners: exports—U.S. 14%, U.K. 13%;
imports—Japan 22%, U.S. 10% (FY77)
Budget: (FY78 est.) domestic revenues, $823 million;
expenditures, $1,578 million
Monetary conversion rate: 14.787 taka=US$1 (July 1978)
Fiscal year: 1 July-30 June','abcfc4b8769f76c9e91a44143b7bbfc4577a35fbcdf75f95371ae263ae24dcee','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e508f7d12429914f408c91880b09b9509b58ec17d06f331758c80dbadd742d8',1972,'BB','Barbados','economy',54,'GDP: $440 million (1977), $1,840 per capita; real growth
. rate 1977,. 3.0%
Agriculture: main products—sugarcane, subsistence foods
Major industries: tourism, sugar milling, light manu-
facturing
Electric power: 107,000 kW capacity (1977);.220 million
kWh produced (1977), 920 kWh per capita
Exports: $95 million (f.0.b., 1977); sugar and sugarcane
byproducts, clothing
Imports: $274 million (c.i.f., 1977); foodstuffs, machinery,
manufactured goods
Major trade partners: exports—34% U.S., 27% CARI-
COM, 10% U.K., 29% other; imports—25% U.S., 19% U.K.,
16% CARICOM, 7% Canada, 33% other’ (1977)
Aid: economic—bilateral commitments including Ex-Im
(1970-76) from U.S., $3.7 million; from other Western
countries, $41.4 million; no military aid:
Budget: (1978/79) revenues, $129 million; expenditures,
$191 million
Monetary conversion rate: 2 Barbados dollars=US$1
Fiscal year: 1 April-81 March','712d92a7afa5febb064807e437a9f59cae2575411dceb366c0c8475d74a0fb20','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30599a596b6c6bdb6457f1a85cff4eebd0366a806ade9079e1b94046bb31c8d7',1972,'BE','Belgium','economy',58,'GNP: $79 billion (1977), $8,040 per capita; 61.9%
consumption, 21.1% investment, 17.4% government, 0.3%
stock building, — 0.7% net foreign balance; 2.0%: real growth
rate in 1977
Agriculture: livestock production predominates; main
crops—grains, beets, potatoes; 80% self-sufficient in food;
caloric intake, 3,230 calories per day per capita (1969-70)
Fishing: catch 44,410 metric tons (1976); exports, $37
million (1975), imports $178 million (1975)
Major industries: engineering and metal products,
processed food and beverages, chemicals, basic metals,
textiles, and petroleum
Crude steel: 11.3 million metric tons produced; 1,150 kg
per capita (1977)
Electric power: 11,100,000 kW capacity (1977); 47.1
billion kWh produced (1977), 4,791 kWh per capita
‘Exports: (Belgium-Luxembourg Economic Union) $37.5
billion (f.o.b., 1977); iron and steel products, finished or
semifinished precious stones, textile products
Imports: (Belgium-Luxembourg Economie Union) $40.3
billion (c.i.f., 1977); nonelectrical machinery, motor vehicles,
textiles, chemicals, fuels
Major trade partners: (Belgium-Luxembourg Economic
Union, 1977) 69.3% EC (22.3% West Germany, 17.5%
France, 16.8% Netherlands, 7.3% U.K., 4.2% Italy), 5.1%
US.
Aid: (1970-76) bilateral economic aid authorized (ODA
and OOF), $1,580 million
Budget: (1977) revenues, $21.9 billion; expenditures,
$24.0 billion; deficit, $2.1 billion
Monetary conversion rate: (1977 average) Belgian Franc
35.841 =US$1
Fiscal year: calendar year','48a420a0b58be0acb06b0d76bbc20237813774bd272f07419f916c3ef1ec898d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6abd65356c363588b8bcadb729d955cbe4f1a1cdc3d0f520edeaf97be50927d7',1972,'HN','Honduras','economy',63,'GDP: $96 million (1975), $700 per capita; 78% private
consumption, 17% public consumption, 36% domestic
investment, —31% net foreign balance (1968)
Agriculture: main products—sugarcane, citrus fruits,
corn, molasses, rice, beans, bananas, livestock products; net
importer of food; caloric intake, 2,500 calories per day per
capita
Major industries: timber and forest products, food
processing, furniture, rum, soap
Electric: power: 16,000 kW capacity (1977); 32 million
kWh produced (1977), 230 kWh per capita
18
Exports: $73 million (f.0.b., 1975); sugar, molasses,
clothing, lumber, citrus fruits, fish
Imports: $86 million (c.if., 1975); vehicles, building
materials, petroleum, food, textiles, machinery
Major trade partners: exports—U.S. 30%, U.K. 24%,
Mexico 22%, Canada 13%; imports—U.S. 34%, U.K. 25%,
Jamaica 7% (1970)
Aid: economic—bilateral commitments, including Ex-Im
(FY70-76), from Western (non-U.S.) countries, $56.5 million;
from U.S., $2.5 million; no military aid
Monetary conversion rate: 2 Belize dollars=US$1
Fiscal year: calendar year
GDP: $1,421 million (1977), $490 per capita; 79% private
consumption, 10% government consumption, 22% domestic
investment; —11% net foreign balance (1975); real growth
rate, average 1971-75, 2.6%; real growth rate 1977, 8:3%
Agriculture: main crops—bananas, coffee, corn, beans,
cotton, sugarcane, tobacco; caloric intake, 2,200 calories per
day per capita (1970)
Fishing: catch 3,262 metric tons (1976); exports est. $0.8
million (1976); imports $0.8 million (1974)
Major industries: agricultural processing, textiles, cloth-
ing, wood products
Electric power: 172,500 kW capacity (1977); 450 million
kWh produced (1977), 155 kWh per capita
Exports: $520 million (f.o.b., 1977); bananas, coffee,
lumber, meat, petroleum products
Imports: $545 million (f.o.b. 1977); manufactured prod-
ucts, machinery, transportation equipment, chemicals,
petroleum
Major trade partners: exports—51% U.S., 12% CACM,
11% West germany; imports—42% U.S., 16% Venezuela, -
13% CACM, 7% Japan, 3% West Germany (1975)
Aid: economic—extensions from U.S. (FY46-76), $122
million loans, $96 million grants; from international
organizations (FY46-73), $291 million; from other Western
countries (1960-73), $7.0 million; military—assistance from
U.S. (FY46-75), $20 million
Budget (1978): expenditures, $416 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year','e03a1223c6168af1dbce03f6ab456adadc0a3715b1f4d6e90b04c866e2b94f6c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eba379af43f38d6c892833460fbdf2a68cd1ea52e87678dd614ee64ea4282215',1972,'BJ','Benin','economy',67,'GNP: $660 million (1977 est.), $200 per capita; 1.5% real
growth during 1970-1977
Agriculture: major cash crop is oil palms; peanuts, cotton,.
coffee, sheanuts, and tobacco also produced commercially;
main food crops—corn, cassava, yams, rice, sorghum and
millet; livestock, fish
Fishing: catch 25,504 metric tons (1976); exports 600
metric tons, imports 8,875 metric tons (1975)
Major industries: palm oi] and palm kernel oil processing
Electric power: 11,000 kW capacity (1977); 55 million
kWh produced (1977), 20 kWh per capita
Exports: $106 million (f.0.b., 1977); palm products (34%);
other agricultural products
Imports: $264 million (c.i.f., 1977); clothing and other
consumer goods, cement, lumber, fuels, foodstuffs, machin-
ery, and transport equipment
Major trade partners: France, EC, franc zone; preferen-
tial tariffs to EC and franc zone countries
Budget: 1977 est.—receipts $110 million, expenditures
$109 million :
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine (CFA) francs=US$1 (1977)
Fiscal year: calendar year','d6b2fe1ccc724f84fcffeff63777e52dd9f386c1b22c56ef79c528ad33966c50','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bdd5ce26c70937b1b514c1d3797a9a0a61575cf5a8a9345146686b69c875ddd',1972,'BM','Bermuda','economy',71,'GNP: $430 million (1976 est.), $7,540 per capita; real
growth rate 1976, est. 2.0%
Agriculture: main products—bananas, vegetables, Easter
lilies, dairy products, citrus fruits
Major industries: tourism, finance
Electric power: 86,200 kW capacity (1977); 300 million
kWh produced (1977), 5,170 kWh per capita
Exports: $47 million (f.o.b., 1976); mostly reexports of
drugs and bunker fuel
Imports: $165 million (f.0.b., 1976); fuel, foodstuffs,
machinery
Major trade partners: 45% U.S., 22% U.K., 9% Canada
(1976)
Aid: economic—bilateral commitments, including Ex-Im
(1970-76), from U.S. $34 million; from other Western
countries $109 million; no military aid
Budget: revenues, $87 million; expenditures $89 million;
expenditures $89 million (proposed 1978/79)
Monetary conversion rate: 1 Bermuda dollar=US$1
Fiscal year: 1 April-3] March
GNP: $90 million (1976); $70 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 3,000 kW capacity (1977); 8 million kWh
produced (1977), 6 kWh per capita
Exports: about $1 million annually; rice, dolomite, and
handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic—India (FY61]-72), $180 million
Monetary conversion rate: both ngultrums and Indian
rupees are legal tender; 8.77 ngultrums=8.77 Indian
rupees=US$1 as of October 1975
Fiscal year: 1 April-31 March','f3609337b5bd81c042a8f34736375316037d4de63e66ba77b1bd9109353589e1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('369b2ffb91348a2ebac90f334547fb2bd5648681f5e45df755e97aa1b9cf6315',1972,'BR','Brazil','economy',74,'GNP: $3.5 billion (1977, in 1977 dollars), $730 per capita;
69% private consumption, 17% public consumption, 20%
_ gross domestic investment, —6% net foreign balance (1976);
real growth rate (1972-76), average 6.4%; 1976 growth, 6.0%
Agriculture: main crops—potatoes, corn, rice, sugarcane,
yucca, bananas; imports significant quantities of wheat;
caloric intake, 70% of requirements (1976)
Major industries: mining, smelting, petroleum refining,
food processing, textiles, and clothing
Electric power: 367,000 kW capacity (1977); 1.1 billion
kWh produced (1977), 230 kWh per capita
Exports: $640 million (f.o.b., 1977 est.); tin, petroleum,
lead, zinc, silver, tungsten, antimony, bismuth, gold, coffee,
sugar, cotton, natural gas
Imports: $670 million (c.i.f., 1977); foodstuffs, chemicals,
capital goods, pharmaceuticals, transportation
Major trade partners: exports—Western Europe, 19% (of
which UK is largest market); Latin America, 38%; U.S., 30%;
Japan, 3.9%; imports—U.S., 24%; Western Europe, 15.4% (of
which West Germany is largest supplier); Japan, 15.7%;
Latin America, 33.6% (1975)
Aid: economic—extensions from U.S. (FY46-76), $335
million in loans, $342 million in grants; from international
organizations (FY46-75), $372 million; from other Western
countries (1960-75), $53.8 million; Communist countries
(1970-74), $59.7 million; military—assistance from U.S.
(FY52-76), $70 million
Budget: $474 million revenues, $583 million expenditures
(1978)
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
rm a ae oe A ALAR ee Ae
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BOLIVIA/BOTSWANA
Monetary conversion rate: 20 pesos=US$1
Fiscal year: calendar year
GNP: $163 billion (est. 1977 in 1977 prices), $1,450 per
capita; 25% gross investment, 80% consumption, —5% net
foreign balance (1976); real growth rate 4.78% (1977)
Agriculture: main products—coffee, rice, beef, corn,
milk, sugarcane, soybeans; nearly self-sufficient; caloric
intake, 2,900 calories per day per capita (1962)
Fishing: catch 950,000 metric tons (1976 est.); exports,
$53.8 million (f.o.b., 1976); imports, $60.8 million (f.o.b.,
1976) :
Major industries: textiles and other consumer goods,
chemicals, cement, lumber, steel, motor vehicles, other
metalworking industries .
Crude steel: 12.0 million metric tons capacity (1977 est.);
11.2 million metric tons produced (1977); 100 kg per capita
Electric power: 24,500,000 kW capacity (1977); 85 billion
kWh produced (1977), 760 kWh per capita
Exports: $12,141 million (f.0.b., 1977); coffee, manufac-
tures, iron ore, cotton, soybeans, sugar, wood, cocoa, beef,
shoes
Imports: $13,257 million (c.i.f., 1977); machinery, chemi-
cals, pharmaceuticals, petroleum, wheat, copper, aluminum
Major trade partners: exports—17.7% U.S., 8.8% West
Germany, 7.7% Netherlands, 5.6% Japan, 5.6% Italy, 4%
Spain; imports (non-oil)—20% U.S., 8.6% West Germany, 7%
Japan, 2.5% Italy, (1977)
Aid: economic—bilateral, including Ex-Im (FY70-76),
from U.S., $1,670.6 million; from other Western countries,
$3,069.4 million; from Communist countries, $303.5 million;
military—from U.S. (FY70-76), $214.1 million
Budget: (1977) revenues $17.2 billion, expenditures $17.1
billion
Monetary conversion rate: 18.69 cruzeiros=US$1 (Au-
gust 1978, changes frequently)
Fiscal year: calendar year
GNP: $460 million (1975 est.), $2,970 per capita
Agriculture: main crops—rubber, rice, pepper, must
import most food
Major industry: crude petroleum, liquefied natural gas
Electric power: 84,000 kW capacity (1977); 230 million
kWh produced (1977), 1,300 kWh per capita
26
Exports: $1,000 million (f.0.b., 1975); 95% crude petro-
leum and liquefied natural. gas
Imports: $200 million (c.i.f., 1975); 25% machinery and
transport equipment, 46% manufactured goods, 16% food
Major trade partners: exports of crude petroleum and
liquefied natural gas to Japan; imports from Japan 30%, U.S.
24%, U.K. 15%, Singapore 9%
Budget: (1976) revenues $640 million, expenditures $250
million, surplus $390 million; 20% defense
Monetary conversion rate: 2.5 Brunei dollars=US$1
Fiscal year: calendar year
GNP: $529 million (1977 est.); $1,240 per capita; real
growth rate 1977, 0.0%
Agriculture: main crops—rice, sugarcane, bananas; self-
sufficient in major staple (rice)
Communists:
Major industries: bauxite mining, alumina and aluminum
production, lumbering, food. processing
Electric power: 189,000 kW capacity (1977); 1 billion
kWh produced (1977), 2,850 kWh per capita
Exports: $303 million (f.0.b., 1976); bauxite, alumina,
aluminum, wood and wood products, rice
Imports: $282 million (c.i.f., 1976); capital equipment,
petroleum, iron and steel, cotton, flour, meat, dairy products
Major trade partners: exports—35% U.S., 34% EC, 18%
other European countries; imports—34% U.S., 838% EC, 13%
Caribbean ‘countries, 18% Europe (1975)
Aid: economic—bilateral commitments including Ex-Im
(FY70-76) from U.S., $1.9 million, from other Western
countries, $423.9 million; no military aid
Budget: revenue, $352 million; expenditure, $367 million
(1978 est.)
Monetary conversion rate:
fl.)=US$0.560 (average 1977)
Fiscal year: calendar year','bafb0e50a04f105020cdd609fe7fbaf444585035a403adfdecf2e75090ae6d5a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a03859b6a435afe3c59f0379922a8ca752afedfe8e8545f6876d274c3c73c9da',1972,'BW','Botswana','economy',79,'GDP: ‘$300 million (1975 est.), growth in constant prices,
less than 5% in 1977
Agriculture: principal crops are corn and sorghum;
livestock raised and exported
Major industries: livestock processing, mining of dia-
monds, coppér, nickel, and coal
Electric power: 75,000 kW capacity (1977); 85 million
kWh produced (1977), 120 kWh per capita
Exports: $176 million (1976); cattle, animal products,
minerals
Imports: $209 million (1976); foodstuffs, vehicles, textiles,
petroleum products
Major trade partners: South Africa and U.K.
Budget: (1977) revenue $107 million ($78 million from
domestic taxes and $29 million from borrowing and foreign
aid), current expenditures $70 million, investment expendi-
tures $44 million :
Monetary conversion rate: 1 pula=about US$1.20 as of
October 1977
Fiscal year: 1 April-31 March
GDP: $3.5 billion (1977), $520 per capita; economy
contracting since 1974 with estimated drop of 6% in 1978
Agriculture: main crops—tobacco, corn, sugar, cotton;
livestock; self-sufficient in foodstuffs
Major industries: mining, steel, textiles, chemicals, and
vehicles
Electric power: 1,453,000 kW capacity (1977); 7.5 billion
kWh produced (1977), 1,110 kWh per capita
Exports: $652 million (f.o.b., 1973), including net gold
sales and reexports; tobacco, asbestos, copper, meat, chrome,
gold, nickel, clothing, sugar
Imports: $541 million (c.i.f., 1973); machinery, petroleum
products, wheat, transport equipment
Net merchandise earnings: $264 million (1976)
Major trade partner: South Africa
Aid: economic—(1970-76) Western (non-U.S.) countries,
$19.1 million
Budget: FY77— revenues $797 million, expenditures $887
million, deficit $40 million
Monetary conversion rate: 1 Rhodesian dollar=US$1.50
Fiscal year: 1 July-30 June','bce054e88727096721a6cbe171edc747efcc11604a4a00bcfc2e69c92e4aca30','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9c38bf6018adc653d41c37990c088124910c3babe18c73f003458cf7554a0ec',1972,'BI','Burundi','economy',84,'GNP: about $450 million (1976), $120 per capita; 2% real
growth (1970-74); real GDP growth ‘in 1976, 7.8%
Agriculture: major cash crops—coffee, cotton, tea; main
food crops—manioc, yams, corn, sorghums, bananas, haricot
beans; marginally self-sufficient
Industries: light consumer goods such as beverages,
blankets, shoes, soap, assembly of imports
Electric power: 7,500 kW capacity (diesel generator
1977); 25 million kWh produced (1977); 6 kWh per capita
Exports: $94.6 million (f.0.b., 1977); coffee (90%), tea,
cotton, hides, skins
Imports: $74.2 million (c.i.f., 1977); textiles, foodstuffs,
transport equipment, petroleum products
Major trade partners: U.S., EEC countries
Budget: FY77—revenue $47 million, current expenditure
$48 million
Monetary conversion rate: 90 Burundi francs=US$1
(official)
Fiscal year: calendar year','394c457ec30018ee6ce3aea4c61a947a489d6c235b0977a8ac6110c35ecee8eb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43ff1828fff3f1f773da260ed37fe28a5c706057ed3e2ff3a82617b62647589d',1972,'GA','Gabon','economy',89,'GDP: $2,500 million (mid 1977), per capita about $380;
real growth rate, 3.2% (1970-77)
Agriculture: commercial and food crops—cocoa, coffee,
timber, cotton, rubber, bananas, peanuts, palm oil and palm
kernels; root starches, livestock, millet, sorghum, and rice
Fishing: imports 7,024 metric tons, $2.2 million; exports
909 metric tons (largely shrimp), $3.5 million (1975)
Major industries: small aluminum plant, food processing
and light consumer goods industries, sawmills
Electric power: 358,000 kW capacity (1977); 1,347
million kWh produced (1977), 200 kWh per capita
Exports: $615 million (£.0.b., FY77); cocoa and coffee
about 60%; other exports include timber, aluminum, cotton,
natural rubber, bananas, peanuts, tobacco, and tea
Imports: $658 million (f.0.b., FY77); consumer goods,
machinery, transport equipment, alumina for refining,
petroleum products, food and beverages
Major trade partners: about 70% of total trade with
France and other EC countries; about 5% of total trade with
US.
Budget: FY78 budget est. balanced at $560 million
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine francs=US$1 as of November 1977
Fiscal year: 1 July-30 June
GDP: $2,802 million (1977 est.), $4,990 per capita; 10%
growth (1970-77)
Agriculture: commercial—cocoa, coffee, wood, palm oil,
rice; main food crops—bananas, manioc, peanuts, root crops;
imports food
Fishing: catch 6,056 metric tons (1975)
Major industries: petroleum production, sawmills, petro-
leum refinery, natural gas, agricultural processing; mining of
increasing importance; major minerals—manganese, uran-
ium, gold, and iron
Electric power: 125,400 kW capacity (1977); 376 million
kWh produced (1977), 670 kWh per capita -
Exports: $1.0 billion (f.0.b., 1977); crude petroleum, wood |
and wood products, minerals (manganese, uranium concen-
trates, gold), coffee
Imports: $831 million (c.i.f. est., 1977); excluding UDEAC
trade; mining, roadbuilding machinery, electrical equip-
ment, transport vehicles, foodstuffs, textiles
Major trade partners: France, U.S., West Germany, and
Curacao; preferential tariffs to EC and franc zone
Aid: Western (non-U.S.) countries (1970-76), $387.6
million, Communist countries (1975), $25.0 million; U.S.
(1970-76), $22.1 million; military—U.S. (1970-76), $2.0
million
Budget: 1978 est.—receipts $1.0 billion, current expend-
itures $500 million, investment expenditures $350 million
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine francs=US$1 (1977)
Fiscal year: calendar year
GNP: $115 million (FY76-77 est.), about $210 per capita
Agriculture: main crops—peanuts, rice, palm kernels
Fishing: catch 10,795 metric tons (1975); exports $956,000
(1974)
Major industry: peanut processing
Electric power: 10,000 kW capacity (1977); 30 million
kWh produced (1977), 50 kWh per capita
Exports: $48 million (f.o.b. 1977); peanuts. and peanut
products 90% to 95%, palm kernels
Imports: $66 million (f.o.b. 1977); textiles, foodstuffs,
tobacco, machinery, petroleum products
Major trade partners: exports—U.K. and France; ‘im- -
ports—U.K. and Japan :
Aid: économic—Western (non-U.S.) countries (1970-76),
$36.1 million; Communist countries (1970-76), $16.2 million;
OPEC (ODA) (1973-76), $15.9 million; U.S. (1970-76), $8.3
million :
72
Budget: (FY77 est.) current expenditures $25 million,
receipts $30 million; development expenditures $14 million,
development receipts $7.2 million
Monetary conversion rate: 1 Dalasi=US$0.49 (September
1978)
Fiscal year: 1 July-30 June
GNP: $69.2 billion in 1977 (1976 prices), $4,120 per
capita; 1977 growth rate 4.0%
Agriculture: food deficit area; main crops—potatoes, rye,
wheat, barley, oats, industrial crops; shortages in grain,
vegetables, vegetable oil, beef; caloric intake, 3,000 calories
per day per capita (71) :
Fish catch: 210,000 metric tons (1977) _
Major industries: metal fabrication, chemicals, light
industry; brown coal, and shipbuilding
Shortages: coking coal, coke, crude oil, rolled steel
products, nonferrous metals
Crude steel: 7.00 million metric tons produced (1977,
preliminary estimate), approx. 420 kg per capita
Electric power: 17,882,000 kW capacity (1977); 92 billion
kWh produced (1977), 5,500 kWh per capita
Exports: $12.7 billion, est. (f.0.b., 1977)
Imports: $14.3 billion, est. (f.0.b., 1977)
Major trade partners: $25,200 million (1976); 65%
Communist countries, 35% non-Communist countries
Monetary conversion rate: 3.48 DME=US$1 for trade
data (1976 rate)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for the consumption year 1 July-30 June
GNP: $517.1 billion (1977), $8,400 per capita (1977); 56%
consumption, 23% investment, 18% government .consump-
tion; net foreign balance 3% (distribution based’ on constant
‘price series)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Nn KA A AN A AA RA AM AR AA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GERMANY, FEDERAL REPUBLIC OF/GHANA
Agriculture: main crops—grains, potatoes, sugar beets;
75% self-sufficient; food shortages—fats and oils, pulses,
tropical products; caloric intake, 2,980 calories per day per
capita (1975-76)
Fishing: catch 394,452 metric tons, $155 million (1977):
exports $130 million, imports $352 million (1977)
Major industries: among world’s largest producers of
iron, steel, coal, cement, chemicals, machinery, ships,
vehicles
Shortages: fats and oils, sugar, cotton, wool, rubber,
petroleum, iron ore, bauxite, nonferrous metals, sulfur
Crude steel: 60 million metric tons capacity; 38.9 million
metric tons produced (1977); 630 kg per capita
Electric power: 78,000,000 kW capacity (1977); 335
billion kWh produced: (1977), 5,445 kWh per capita
Exports: $120 billion (f.0.b., 1977); manufactures 90.9%
(machines and machine tools, chemicals, motor vehicles, iron
and stee] products), agricultural products 5.3%, fuels 2.1%,
raw materials 1.7%
Imports: $103 billion (c.i.f., 1977); manufactures 60.2%,
fuels 8.1%, agricultural products 16.7%, raw materials 15.0%
Major trade partners: EC 45.7% (France 11.8%, Nether-
lands 11.3%, Belgium-Luxembourg 7.9%, Italy 7.6%); other
Europe 12.7%; OPEC 9.4%; Communist economic 7.0%;
US. 6.8%; (data include interzonal trade
_Aid: donor—(1970-76) bilateral economic aid authorized
(ODA and OOF), $11,659 million
Budget: (1977) expenditures $73.8 billion, revenues $64.1
billion, deficit $9.7 billion
Monetary conversion rate: DM 2.32 (West German
marks)=US$1] (1977 average)
Fiscal year: calendar year
GNP: $20 million (1975 estimate); per capita income $250
(1975 ést.) . .
Agriculture: cash crops—cocoa, copra, coconut, coffee,
palm oil, bananas
Major industries: food processing on small scale, timber
Electric power: 3,000 kW capacity (1977); 5 million kWh
produced (1977), 70 kWh per capita
Exports: $8.5 million (f.0.b., 1976); mainly cocoa (90%),
copra (7%), coffee, palm oil
Imports: $10 million (c:if., 1976); communications
equipment, light and heavy vehicles, food products,
beverages, fuels and lubricants :
Major trade partners: main partner, Portugal; followed
by Netherlands, West Germany, African neighbors
Aid: economic—(1970-76) Western (non-U.S.) countries,
$567.0 million .
Budget: balanced at an estimated $6.6 million (1975)
Monetary conversion rate: 40.64 escudos=US$1 (Novem-
ber 1977) .
Fiscal year: probably calendar year','ea90b17a4c991fe22bd3749a77729ca2d586776307f7e85624ed36b1e81b2c62','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2af52a4baa0a8c775f94fc77147a3f837034ff28a4c91998b89256ba5e973348',1972,'CA','Canada','economy',93,'GNP: $195.3 billion (1977, in 1977 prices), $8,330 per
capita (1977); 59.6% consumption, 22.3% investment, 18.1%
government (1977); growth rate 4.8% (1970-77, real terms)
32
Agriculture: main products—livestock, grains (principally
wheat), dairy products; food shortages—fresh fruits and
vegetables; caloric intake, 3,180 calories per day per capita
(1966-67)
Fishing: catch 800,809 million metric tons; exports
383,602 metric tons (1977)
Major industries: mining, metals, food products, wood
and paper products; transportation equipment, chemicals
Shortages: rubber, rolled steel, fruits, precision
instruments
Crude steel: 13.6 million metric tons. produced (1977)
Electric power: 73,000,000 kW capacity (1977); 316,500
million kWh produced (1977), 18,347 kWh per capita
Exports: $43,373 million (f.0.b., 1977, source: I.F.S.);
principal items—transportation equipment, wood and wood
products including paper, ferrous and nonferrous ores, crude
petroleum, wheat; Canada is a major food exporter
Imports: $42,052 million (c.if., 1977, source: I.F.S.);
principal machinery,
crude petroleum, communication equipment, textiles, steel,
fabricated metals, office machines, fruits and vegetables
Major trade partners: 70% U.S., 10% EC, 5% Japan
(1977)
Aid: economic—(received U.S., $380.9 million Ex-Im
Bank); Canada commitments to LDCs (1970-76), bilateral
ODA and OOF commitments, $6.5 billion
Budget: total revenues $33,781 million; current expendi-
tures $39,930 million; gross capital formation $6,833 million;
budget deficit $6,149 million (1977) (National Accounts
Basis)
Monetary conversion rate: there is no designated par
value for the Canadian dollar, which was allowed to float
items—transportation equipment,
freely on the exchanges beginning 1 June 1970; since then
the Canadian dollar has moved between US$0.86-1.04 in
value, 1C$=US$0.9403 (official rate)
Fiscal year: 1 ApriJ-31 March
GDP: $50 million (1975 est.); $170 per capita income
Agriculture: main crops—corn, beans, manioc, sweet
potatoes; barely self-sufficient in food
Fishing: catch, 4,400 metric tons (1976 est.); largely
undeveloped but provides major source of export earnings
Major industries: salt mining
Electric power: 6,000 kW capacity (1977); 7 million kWh
produced (1977);.20 kWh per capita
Exports: $2.5 million (f.o.b., 1975); fish, bananas, salt
Imports: $31 million (c.if., 1975); machinery, textiles
Major trade partners: Portugal, U.K., Japan, African
neighbors
Budget: (est. 1976) $30 million expenditures, $15 million
revenues
Monetary conversion rate: 40.643 escudos=US$1
(November 1977)
Fiscal year: calendar year
GDP: $394 million (1976), $220 per capita
Agriculture: commercial—cotton, coffee, peanuts, ses-
ame, wood; main food crops—manioc, corn, peanuts, rice,
potatoes, beef; requires wheat, flour, rice, beef, and sugar
imports ;
Major industries: sawmills, cotton textile mills, brewery,
diamond mining and splitting
Electric power: 44,000 kW capacity (1977); 106 million
kWh produced (1977), 60 kWh per capita
Exports: $80 million (f.o.b., 1978 est.); cotton, coffee,
diamonds, timber
Imports: $100 million (f.o.b., 1978 est.); textiles, petrole-
um products, machinery and electrical equipment, motor
vehicles and equipment, chemicals and pharmaceuticals
Major trade partners: France, Yugoslavia, Japan, U.S.
Budget: 1978 proposed budget receipts and grants $78
million, expenditures $80 million
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine francs=US$1 (1977)
Fiscal year: calendar year
GDP: $296 million (1977), $70 per capita; estimated real
annual growth rate 2.0%
Agriculture: commercial—cotton, gum arabic, livestock,
fish; food crops—peanuts, millet, sorghum, rice, sweet
potatoes, yams, cassava, dates; imports food
Fishing: catch 115,000 metric tons (1976 est.)
Major industries: agricultural and livestock processing
plants (cotton textile mill, slaughterhouses, brewery), natron
Electric power: 22,000 kW capacity (1977); 60 million
kWh produced (1977), 15 kWh per capita
Exports: $61 million (f.0.b., 1976); cotton 80%, livestock
and animal products
Imports: $114 million (c.i.f., 1976); cement, petroleum,
foodstuffs, machinery, textiles, and motor vehicles
Major trade partners: France (about 40% in 1973) and
UDEAC countries; preferential tariffs to EC and franc zone
countries
Budget: (1977) $73 million
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine francs=US$1 (1977)
Fiscal year: calendar year','2eb94da330704c4ed92c534fa836cdf09e89673fe4bd8996b8787392b08b1e26','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83e59c05408a60c276a61e44019cd48cf0f52617750143af398d9da9115e8643',1972,'CL','Chile','economy',97,'GDP: $10.3 billion (1977), $970 per capita; 76.0% private
consumption, 15.8% government consumption; 9.2% gross
investment, — 1:0% net imports and factor payments abroad;
real growth rate, 1977, 8.6%; 1972-77 average annual
increase, negligible
Agriculture: main crops—wheat, other cereals, potatoes,
corn, sugar beet, fruits; about 85% self-sufficient; 2,650
calories per day per capita (1971 est.)
Fishing: catch 1.5 million metric tons (1977); exports $94
million (1977)
Major industries: copper, nitrates, foodstuffs, fish proc-
essing, transportation equipment, iron and steel, pulp and
paper
Crude steel: 0.7 million metric tons capacity (1967);
450,000 metric tons produced (1976), 42 kg per capita
Electric power: 2,775,000 kW capacity (1977); 9.73
billion kWh produced (1977), 910 kWh per capita
Exports: $2.2 billion (f.o.b., 1977); copper, iron ore, paper
products, foodstuffs
Imports: $2.3 billion (c.if., 1977); petroleum, capital
goods, consumer products
Major trade partners: exports—30% EC, 28% LAFTA,
14% US., 13% Japan; imports—34% LAFTA, 21% U.S., 15%
EC, 11% Japan
Aid: economic—bilateral ODA and OOF (1970-76), U.S.
$381 million; Western (non-U.S.) countries, $384.8 million;
Communist countries, $386.2 million; military—U.S. (1970-
76), $50.4 million
Budget: $2.5 billion revenues, $2.8 billion expenditures
(1977)
Monetary conversion rate: 33.05 pesos=US$1 (Septem-
ber 1978), changes daily
Fiscal year: calendar year','d07e0e2e6cc052ec89d956d147aa63a605ecaa34e7c472919dcb765238cd5e0d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dacf68fcd83b2bd05d5fdf7f65c83a2ee58f7313cb9aafdfc1a8b9678fb6506',1972,'CN','China','economy',101,'GNP: $373 billion (1977), $390 per capita
Agriculture: main crops—rice, wheat, miscellaneous
grains, cotton; caloric intake, 2,000 calories per day per
capita (1977); agriculture mainly subsistence; grain imports
6.9 million metric tons in 1977
Major industries: iron and steel, coal, machine building,
armaments, textiles, petroleum
Shortages: complex machinery and equipment, highly
skilled scientists and technicians
_ Crude steel: 24 million metric tons produced, 25 kg per
capita (1977) ;
Electric power: 42,000,000 kW capacity (1977); 150
billion kWh produced (1977), 155 kWh per capita
Exports: $8.1 billion (f.0.b., 1977); agricultural products,
oil, minerals and metals, manufactured goods
$7.2 billion (ci.f., 1977); chemical
fertilizer, steel, industrial raw materials, machinery and
equipment
Imports: grain,
Major trade partners: Japan, Hong Kong, West Germany,
Australia, Romania, Canada, East Germany, U.S., U.S.S.R.,
Singapore (1977) ;
Monetary conversion rate: as of 30 June 1978, about 1.72
yuan=US$1 (arbitrarily established)
Fiscal year: calendar year.
GNP: $19.5 billion (1977, in 1977 prices), $1,170 per
capita; real growth, 8.3% (1970-76 average)
Agriculture: most arable land intensely farmed—60%
cultivated land under irrigation; main crops—rice, sweet
potatoes, sugarcane, bananas, pineapples, citrus fruits; food
shortages—wheat, corn, soybeans
Fishing: catch 854,784 metric tons (1977)
Major industries: textiles, clothing, chemicals, plywood,
electronics, sugar milling, food processing, cement, ship
building
40
Electric power: 7,100,000 kW capacity (1977); 30 billion
kWh produced (1977), 1,780 kWh per capita
Exports: $9,361 million (f.0.b., 1977); 25% textiles, 15.9%
‘electrical machinery, 7.5% plywood and wood products, 7%
machinery and metal products, 7.5% plastics, 5% sugar
Imports: $8,511] million (c.i.f., 1977); 18% machinery, 9%
electrical machinery, 9% basic metals, 10% crude oil, 10%
chemical products
Major trade partners: exports—38.8% U.S., 11.9% Japan;
imports—31% Japan, 23% U.S. (1977)
Aid: economic—U.S. (FY46-76), $2.2 billion committed;
IBRD (1964-75), $311 million committed; Japan (1965-74),
$247 million committed; ADB (1968-75), $93 million
committed; . military—U.S. (FY46-76), $4.3 billion com-
mitted
Central government budget: $3.5 billion (FY78)
Monetary conversion rate: NT$38 (New Taiwan)=US$1
Fiscal year: 1 July-30 June
Monetary conversion rate: 1.94 won=US$1, non-com-
mercial rate
Fiscal year: calendar year
GNP: $31.5 billion (1977, in 1977 prices), $880 per capita;
real growth 10.8% (1977); real growth 11.7% (1972-77
- average)
. Agriculture: 40% of the Sesiatiae live on the land, but
agriculture, forestry and fishery constitute 24% of GNP;
main crops—rice, barley; not self-sufficient; food short-
ages—wheat, dairy products, corn
‘ Fishing: catch 2,421,273 metric tons (1977)
Major industries: textiles and clothing, food processing,
chemical fertilizers, chemicals, plywood, steel, electronics
Shortages: base metals, petroleum, lumber and certain
food grains
Electric power: 5,790,180 kW capacity (1977); .26.5
billion kWh produced (1977), 720 kWh per capita .
: Exports: $10.0 billion (f.0.b., 1977); textiles and clothing,
electrical machinery, plywood, footwear, steel, ships
Imports: $10.8 billion (c.i.f., 1977); oil, ships, steel, wood,
wheat, organic chemicals, machinery
Major trade partners: exports—31% U.S., 21% Japan;
imports—36% Japan, 23% U.S. (1977)
Aid: economic—U.S. (FY46-77), $5.8 billion committed;
Japan (1965-75), $1.8 billion extended; military—U.S. (FY
46-77) $7.0 billion committed ,
Budget: $7.3 billion (1978)
Monetary conversion rate: rate fixed at 484 won=US$1
since December 1974
114
‘
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7','a445502d80f937b641c3cb6de4097802223b6349d532daa1cc5f45acc09bca2a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a55d8f04172592c91d9df27fd8283e860fdb7383bd72ad5158cf84c8592d3b11',1972,'CO','Colombia','economy',105,'GNP: $20.7 billion, est. (1977, in 1977 prices), $830 per
capita; 75% private consumption, 6% public consumption,
18% gross investment, 1.0% net foreign balance (1977)
Agriculture: main crops—coffee, rice, corn, sugarcane,
plantains, bananas, cotton, tobacco; caloric intake, 2,140
calories per day per capita (1970)
Fishing: catch 75,107 metric tons 1976; exports $10.6
million (1973), imports $10.3 million (1973)
Major industries: textiles, food processing, clothing and
footwear, beverages, chemicals, and metal products
Crude steel: 356,000 metric tons produced (1976), 14 kg
per capita aa
Electric power: 4,650,000 kW capacity (1977); 13.8
billion kWh produced (1977), 550 kWh per capita
Exports: $2,433 million (f.o.b., 1977); coffee, fuel oil,
cotton, tobacco, sugar, textiles, cattle and hides
Imports: $1,880 million (c.if., 1977); transportation
equipment, machinery, industrial metals and raw materials,
chemicals and pharmaceuticals, fuels, fertilizers, paper and
paper products, foodstuffs and beverages
Major trade partners: exports—48% Japan, 27% U.S.,
16% Germany, 10% Venezuela, 6% Netherlands; imports—
38% US., 9% Germany, 8% Japan, 5% Ecuador (1976)
41
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
COLOMBIA/COMOROS
Aid: economic—extensions from U.S. (FY46-76), $991
million loans, $325 million grants; from international
organizations (FY46-75), $1.8 billion; from other Western
countries (1970-76), $249.8 million; from Communist
countries (1970-76), $275.4 million; military—assistance
from U.S. (FY46-76), $130 million :
Budget: (1978) revenues $2.09 billion; expenditures $2.30
billion
Monetary conversion rate: 39.02 pesos= US81 (June 1978,
changes frequently)
Fiscal year: calendar year
GNP: $652 million (1976), $2,680 per capita; real growth
rate, —1% (est.)
Agriculture: little production
Major industries: petroleum refining on Curacao and
Aruba; petroleum transshipment facilities on Curacao,
Aruba, and Bonaire; tourism on Curacao, Aruba, and St.
Martin; light manufacturing on Curacao and Aruba
Electric power: 300,000 kW capacity (1977); 1.7 billion
kWh produced (1977), 6,880 kWh per capita
Exports: $2.6 billion (f.o.b., 1977); 96% petroleum
products, phosphate
Imports: $3.1 billion (c.i.f., 1977); 64% crude petroleum,
food, manufactures
Major trade partners: exports—46% U.S., 2% Canada, 1%
Netherlands; imports—35% Venezuela, 11% U.S., 4% Neth-
erlands (1977)
Aid: bilateral commitments (1970-76), economic—West-
ern (non-U.S.) countries $203.6 million
Budget: (1977) public sector current revenues, $278
million; public sector expenditures, $306 million
Monetary conversion rate: 1.8 Netherlands Antillean
florins (NAF)=US$1, official
Fiscal year: calendar year','27056eba57d7b0115a0d1f3821ebda07df77370d7cd652ea98afeba0183e3556','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c6aac3bd4b77a172fc9269c568f0f1eeba4e5d94491b3488816ceb6ac3b3512',1972,'KM','Comoros','economy',111,'GDP: about $700 million (1977 est.), $490-per capita; real
growth rate 2.5% per year (1970-77)
Agriculture: cash crops—sugarcane, wood, coffee, cocoa,
palm kernels, peanuts, tobacco; food crops—root crops, rice
corn, bananas, manioc, fish
Fishing: catch 19,447 metric tons (1976)
Major industries: crude oil, sawmills, brewery, cigarettes,
sugar mill, soap
Electric power: 63,200 kW capacity (1977); 130 million
kWh produced (1977), 90 kWh per capita
Exports: $214 million (f.0.b., 1977 est.); oil (58%), lumber,
tobacco, veneer, and plywood
Imports: $266 million (f.o.b., 1977 est.); machinery,
transport equipment, manufactured consumer goods, iron
and stéel, foodstuffs, petroleum products, sugar
>
Major trade partners: France and other EC countries
Budget: 1977 est.—revenue $216 million, expenditure
$240 million “
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine francs=US$1 (1977)
Fiscal year: calendar year','693e9bd182cdae1aa283f15fcd6d2e807f1c5a8036b303ec68ff7a97d493ade4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a580fefe80613f5fb1ab9349c6591514838c218db3381998d944cd2c3b6d9d35',1972,'CK','Cook Islands','economy',115,'GDP: $400 per capita (1973)
Agriculture: export crops include copra, citrus fruits,
pineapples, tomatoes, and bananas, with subsistence crops of
yams and taro
Industry: fruit processing
Electric power: 3,000 kW capacity (1977); 10 million
kWh produced (1977), 560 kWh per capita
Exports: $2.7 million (1971); fruit juice, clothing, citrus
fruits
Imports: $5.8 million (1971)
Major trade partners: (1970) exports—98% New Zealand,
imports—76% New Zealand, 7% Japan
Monetary conversion rate: 1 NZ$=US$0.9947 (July
1976)','5f5be5ab3654944a6f93e0806a0483cf21602c2b32e41bfe1d061748dca93303','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9212bd9d72e8e22736464a5da8324a608059455bafd03a2556927824e7778bb1',1972,'CR','Costa Rica','economy',119,'GDP: $2.8 billion (1978, in current prices), $1,370 per
capita; 66% private consumption, 16% public consumption,
22% gross domestic investment, —4% net foreign balance
(1976); real growth rate 1977, 6.9%; average growth
(1972-77), 6.2%
Agriculture: main products—bananas, coffee, sugarcane,
rice, corn, cocoa, livestock products; caloric intake, 2,610
calories per day per capita (1966)
Fishing: catch 12,728 metric tons (1976); exports, $5.1
million (1976), imports, $0.3 million (1976)
Major industries: food processing, textiles and clothing,
construction materials, fertilizer
Electric power: 410,000 kW capacity (1977); 1.7 billion
kWh produced (1977), 830 kWh per capita
Exports: $815 million (f.0.b., 1977); coffee, bananas, beef,
sugar, cacao
Imports: $1,010 million (c.i.f., 1977); manufactured prod-
ucts, machinery, transportation equipment, chemicals, fuels,
foodstuffs, fertilizer
Major trade partners: exports—38% U.S., 22% CACM,
11%. West Germany; imports—35% U.S., 18% CACM, 5%
West Germany, 11% Japan (1976)
Aid: (1970-76) economic bilateral commitments: U.S. $72
million, other Western countries $78 million, Communist
$17 million; military commitments negligible
Budget: (1977) $410 million current revenues, ~ $530
million total expenditures including debt amortization
Monetary conversion rate: 8.57 colones=US$1
Fiscal year: calendar year','4abdba3cfff587a6d6b3886bea482ce49acce213efc2b5dfdadcddfe6f8714d1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c55bd9067f13bb0604e3d2cc9e299d79f73550181057d6bf458660953719ebe4',1972,'CY','Cyprus','economy',123,'GNP: $789.3 million (1976), $1,580 per capita; 1976 real
growth rate 14.6%
Agriculture: main crops—vine products, citrus, potatoes,
other vegetables; food shortages—grain, dairy products,
meat, fish; caloric intake, 2,460 calories per day per capita
(1964-66)
Major industries: mining (cupreous and iron pyrites,
asbestos), manufactures principally for local consumption—
food, beverages, footwear, clothing, cement
Shortages: water, petroleum
Electric power: 338,000 kW capacity (1977); 888 million
kWh produced (1977), 1,390 kWh per capita
Exports: $318 million (f.0.b., 1977, converted at average
trade conversion factor of 1 Cyprus pound=US$2.451);
principal items—asbestos, copper, pyrites, citrus, raisins, and
other agricultural products, potatoes, cement, clothing,
footwear, wine
Turkish Sector exports: $15.7 million (f.0.b., 1976, con-
verted at average conversion factor of 16.053 Turkish
lira=US$1); principal items—citrus fruits, potatoes, manu-
factured goods
Imports: $623 million (c.i.f., 1977, converted at average
trade conversion factor of 1 Cyprus pound=US$2.451);
principal items—manufactured goods, machinery and trans-
port equipment, petroleum products, foods
Turkish Sector imports: $65.9 million (c.i.f., 1976, con-
verted at average trade conversion factor of 16.053 Turkish
lira=US$1); principal items are foodstuffs, livestock, raw
materials, oil, machinery
Major trade partners: (1977) imports—19% U.K., 9%
Italy, 8% Greece, 8% West Germany, 6% U.S., 5% France;
exports—29% U.K., 18% Saudi Arabia, 9% Lebanon, 5%
Libya, 4% Egypt, 3% U.S.S.R., 3% Greece, 3% Syria
Turkish Sector major trade partners: (1976) imports—
48% Turkey, 22% U.K., 7% West Germany, 5% France, 3% .
Netherlands, 3% Italy; exports—33% U.K., 29% Turkey, 18%
Netherlands, 10% Italy
Aid: economic—U.S., $49 million authorized (FY70-76);
other Western bilateral authorizations (ODA and OOF), $34
million (1970-76); Greece, $79 million (1976)
Turkish Sector aid: Turkey, $70 million (1974-76)
Budget: 1977—revenues $167.6 million, expenditures
$229.4 million, deficit $61.8 million
Turkish Sector budget: revenues $38 million, expendi-
tures $78 million, deficit $40 million
Monetary ‘conversion rate: 1 Cyprus pound=US$2.61
(December 1971 through January 1973), 1 Cyprus
pound=US$$2.4510 (trade conversion factor for 1977)
Turkish Sector monetary conversion rate: 18.002 Turk-
ish lira=US$1 (trade conversion factor for 1977)
Fiscal year: calendar year
NOTE: 1974, 1975, 1976, and 1977 GNP, import, export,
and budget figures are Government of Cyprus figures which
include 100% of island until August 1974 and 60% of island
thereafter; the Turkish sector of island for last 4 months of
1974 is part of Turkish mainland economy; with the passage
of time, some information on the Turkish sector of the island
has become available.','69a28f3a132c8189d473b650bbe4f0ad8855cbe87fbca1c01699fc197efdbe83','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('880e66c2dd031daf3b2fa790130c50c7ebf374a7c4ce4eb1c9e7ef10d97327e8',1972,'RO','Romania','economy',125,'GNP: $63.2 billion in 1977 (in 1977 dollars), $4,200 per
capita; 1977 réal growth rate 3.4%
Agriculture: diversified agriculture; main crops—wheat,
rye, potatoes, sugar beets; net food importer—meat, wheat,
vegetable oils, fresh fruits and vegetables; caloric intake,
8,100 calories per day per capita (1967)
Major industries: machinery, food processing, metal-
lurgy, textiles, chemicals
Shortages: ores, crude oil
Crude steel: 15.1 million metric tons produced (1977),
1,000 kg per capita
Electric power: 15,200,000 kW capacity (1977); 66.4
billion kWh produced (1977), 4,410 kWh per capita
Exports: $10,495 million (f.0.b., 1977); 51% machinery,
equipment; 28% fuels, raw materials; 3% foods, food
products, and live animals; 18% consumer goods, excluding
foods (1977)
Imports: $10,888 million (f.0.b., 1977); 39% machinery,
equipment; 45% fuels, raw materials; 10% foods, food
products, and live animals; 6% consumer goods, excluding
foods (1977)
Monetary noncommercial
crowns=US$1, commercial 5.64 crowns=US$1
conversion _ rate: 10.15
Fiscal year: calendar year
NOTE: foreign trade figures were converted at the rate of
5.81 crowns=US$1
GNP: $57.0 billion (1977, in 1976 prices), $2,630 per
capita; 1977 real growth rate, 3.6%
174
Agriculture: net exporter; main crops—corn, wheat,
oilseed; livestock—cattle, hogs, sheep; caloric intake, 118%
of requirements
Fish catch: 127,197 metric tons (1976)
Major industries: machinery, metals, fuels, chemicals,
textiles, food processing, timber processing
Shortages: iron ore, coking coal, metallurgical coke,
cotton fibers, natural rubber
Crude steel: 11.5 million metric tons produced (1977),
530 kg per capita :
Electric power: 13,200,000 kW capacity (1977); 59.8
billion kWh produced (1977), 2,760 kWh per capita
Exports: $7.0 billion (f.0.b., 1977); 26% machinery and
equipment; 16% foodstuffs; 16% consumer goods; 24% fuels,
metals, materials; 18% other (1976)
Imports: $7.0 billion (mixture f.o.b. and c.i.f., 1977); 82%
machinery and equipment; 41% fuels, metals, raw materials; ,
8% foodstuffs; 19% other (1976)
Major trade partners: $14.0 billion in 1977; 57%
non-Communist countries, 43% Communist countries (18%
U.S.S.R.) (1976)
Monetary conversion rate: 4.47 lei=US$1 (commercial),
12 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for consumption year, 1 July-30 June','3dbf9e3e1f6c72b17ea9f5b669f4899e23ee90f02d7a1c723223f26600719096','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b37dfe93d2b220346d7ae54b45a698ccbac01a467b69d3fc1a4d2675805f067b',1972,'DK','Denmark','economy',129,'GNP: $42.2 billion (1977), $8,290 per capita; 58% private
consumption, 20% investment, 25% government, — 2.5% net
foreign sector and stock building (1977); 1977 growth rate
1.2%, constant prices
51
‘
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
DENMARK/ DJIBOUTI
Agriculture: highly intensive, specializes in dairying and
animal husbandry; main crops—cereals, root crops; food
imports—oilseeds, grain, feedstuffs; caloric intake, 3,180
calories per day per capita (1968-69)
Fishing: catch 1.91 million metric tons (1976), exports
$462 million (1977)
Major industries: food processing, machinery and equip-
ment, textiles and clothing, chemical products, electronics,
transport equipment, metal products, brick and mortar,
furniture and other wood products
Crude steel: 685,000 metric tons produced (1976), 180 kg
per capita
Electric power: 7,400,000 kW capacity (1977); 23.9
billion kWh produced (1977), 4,690 kWh per capita
Exports: $10.1 billion (f.0.b., 1977); principal items—
meat, dairy products, industria] machinery and equipment,
textiles and clothing, chemical products, transport equip-
ment, fish, furs, and furniture
Imports: $13.3 billion (c.i.f., 1977); principal items—
industrial machinery, transport equipment, petroleum,
textile fibers and yarns, iron and steel products, chemicals,
grain and feedstuffs, wood and paper
Major trade partners: 46.1% EC-nine (17.7% West
Germany, 12.3% U.K.); 13.6% Sweden; 5.9% Norway; 5.7%
U.S.; 4.6% Netherlands; .4.4% Communist countries (1977)
Aid: donor—bilateral economic aid authorized (ODA and
OOF) $717 million (1970-76)
Budget: (FY77) expenditures $20.3 billion, revenues $20.1
billion
Monetary conversion rate: 6.0032 Kroner=US$1 (1977,
average exchange rate)
Fiscal year: calendar year, beginning 1] January 1979','ca125d4a7273f6ae056864e7ff75d3107ac86b0a69f5a53f9cc59bccb9d8fc7d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07a8743d571e8cc07a7ae8a77d80730f5380a8d9d4287c1fa473241ebca58058',1972,'DJ','Djibouti','economy',132,'GNP: $65 million (1972)
Agriculture: livestock; desert conditions limit commercial
crops to about 15 acres, including fruits and vegetables
Industry: ship repairs and services of port and railroad
drastically reduced with war in Ethiopia’s Ogaden that cut
the railroad line
Electric power: 23,500 kW capacity (1977); 55 million
kWh produced (1977), 310 kWh per capita
Imports: $74 million (1973); almost all domestically
needed goods—foods, machinery, transport equipment
Exports: $20 million, including transit trade (1973);. hides
and skins, and transit of coffee; since railroad line has been
cut, values have plummeted
Monetary conversion rate: 182 Djibouti francs=US$1
Fiscal year: probably same as that for France (calendar
year)','53378201f1c678ff1decf64a931f0549e93cc343d0d89816e976bf7a0fa57d95','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f9f1a8925f7389d8fb62b0469303eeb39d86811fc438ec31ef3858a5cb64305',1972,'DM','Dominica','economy',136,'GNP: $32 million (1977 est.), $410 per capita; real growth
rate, 1977, 2.0% est.
Agricultural products: bananas, citrus, coconuts, cocoa
Major industries: agricultural processing, tourism
Electric power: 10,000 kW capacity (1977); 7 million
kWh produced (1977), 90 kWh per capita
Exports: $10 million (f.0.b., 1976); bananas, lime juice and
oil, cocoa, reexports
Imports: $18 million (c.i.f., 1976); machinery and
equipment, foodstuffs, manufactured articles, cement
Major trade partners: 47% U.K., 15% Commonwealth
Caribbean countries, 7% U.S., 6% Canada (1975)
Aid: economic—bilateral including Ex-Im (1970-76),
from Western (non-U.S.) countries, $57 million; no military
aid d
Budget: revenues, $8 million; expenditures, $11 million
(1977/78 est.)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1
Fiscal year: 1 July-30 June','59fded14bfc38d37ba59a29470ab6c9158d6a7a752315d5d39a3ae871f3c5999','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6407aa9f6cde3235258e8df757f5e85698a75343dd813ffefd5544e1e7b626c3',1972,'DO','Dominican Republic','economy',140,'GNP: $4.4 billion (1977), $880 per capita; real growth rate
1977, 3.3%
Agriculture: main crops—sugarcane, coffee, cocoa, to-
bacco, rice, corn
.
Major industries: sugar processing, nickel mining, bauxite
mining, gold mining, textiles, cement
Electric power: 662,000 kW capacity (1977): 2 billion
kWh produced (1977), 400 kWh per capita
Exports: $780 million (f.0.b., 1977); sugar, nickel, coffee,
tobacco, cocoa, bauxite
Imports: $848 million (f.o.b., 1977); foodstuffs, petroleum,
industrial raw materials, capital equipment
Major trade partners: exports—81% U.S. (1977); im-
ports—50% U.S. (1977)
Aid: economic—bilateral commitments, including Ex-Im
(FY70-76), from U.S., $252 million; other Western countries,
$78 million; military—from U.S., $12 million
Budget: revenues, $600 million; expenditures, $635
million (1978 est.)
Monetary conversion rate: 1 peso=US$]
Fiscal year: calendar year','105a2400b19bf5bbb232751c85f5ba2260e803a4958fb3eff37cbf8054268cc6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5db38ae63c8f906e575cd32cc48f7eab396661621dabcba0f22d2a1e198ab28e',1972,'EC','Ecuador','economy',144,'GNP: $5.6 billion est. (1977), $780 per capita; 70% private
consumption, 10% public consumption, 20% gross invest-
ment; average annual real growth rate 1974-77, 6.8%
Agriculture: main crops—bananas, coffee, cocoa, sugar-
cane, fruits, corn, potatoes, rice; caloric intake, 1,970 calories
per day per capita (1970)
Fishing: catch 233,400 metric tons (1975); exports $73
million (1977), imports negligible
Major industries: food processing, textiles, chemicals,
fishing, petroleum
Electric power: 552,000 kW capacity (1977); 2.1 billion
kWh produced (1977), 290 kWh per capita
Exports: $1.2 billion (f.0.b., 1977); petroleum, bananas,
coffee, cocoa, sugar, fish products
Imports: $1.5 billion (c.i''f., 1977); agricultural and
industrial machinery, industrial raw materials, building
supplies, chemical products, transportation and communica-
tion equipment . :
Major trade partners: exports (1977)—41% U.S., 20%
LAFTA, 15% EC; imports (1977)—41% U.S., 22% EC, 18%
Japan, 14% LAFTA
Aid: economic—bilateral ODA and OOF (1970-76), U.S.,
$117.5 million; other Western countries, $157.9 million;
OPEC, $22 million; Communist countries, $9.4 million;
military—(1970-76) U.S., $13.6 million
Budget: (1977) revenues, $885 million; expenditures,
$1,095 million
Monetary conversion rate: 25 sucres=US$1
Fiscal year: calendar year
GNP: $14.5 billion (1976), $380 per capita; average
annual growth rate of 9% in 1976
Agriculture: main cash crop—cotton; other crops—rice,
onions, beans, citrus fruit, wheat, corn, barley; not self-suffi-
cient in food, but agriculture a net earner of foreign
exchange ;
Major industries: textiles, food processing, chemicals,
petroleum, construction, cement
Electric power: 5,300,000 kW capacity (1977); 14 billion
kWh produced (1977), 350 kWh per capita
Monetary conversion rate: official rate—] Egyptian
pound=US$2.54 (selling rate); 0.394 Egyptian pound=
US$1 (selling rate); parallel market rate—1 Egyptian
pound=US$1.43, 0.699 Egyptian pound=US$1
Fiscal year: calendar year, beginning in 1975
57
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
EGYPT/EL SALVADOR','f11b994f99197f37d41f4883cb71a309c45d89fb45b620f8e5dc350d55fc3571','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25b07798cf1419684f7284dae8386cb0acd39aad9520373164c3d62634edf90e',1972,'SV','El Salvador','economy',148,'GNP: $2.6 billion (1977), $610 per capita; 70% private
consumption, 11% government consumption, 19% domestic
investment; real growth rate, 4.9% (1977)
Agriculture: main crops—coffee, cotton, corn, sugar; rice,
beans; caloric intake, 2,000 calories per day per capita
(1963-64)
Fishing: catch 9,130 metric tons (1976)
Major industries: food processing, textiles, clothing,
petroleum products
Electric power: 557,000 kW capacity (1977); 1.2 billion
kWh produced (1977), 280 kWh per capita
Exports: $968 million (f.o.b., 1977); coffee, cotton, sugar
Imports: $947 million (c.if., 1977); machinery, auto-
motive vehicles, petroleum, foodstuffs, fertilizer
Major trade partners: exports—33% U.S., 24% CACM,
11% other (1976); imports—29% U.S., 24% CACM, 7%
Venezuela, 14% West Germany, 8% Netherlands, 40% other
(1976)
Aid: economic—(FY70-76) from U.»., $60 million; from
other Western countries, $36 million; military—from U.S.
$10 million
Budget: (1978) $500 million
Monetary conversion rate: 2.5 colones=US$1 (official)
Fiscal year: calendar year','0c525b39dd649a49e7411d0f3c8b8e729c4342044cd22893650b825fcdc4ea89','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac4dc655b48538bbba4a304407ea86998b222f4fe41a9a235bd322b3164ceef8',1972,'CM','Cameroon','economy',151,'GNP: $70 million (1972); $240 per capita
Agriculture: major cash crops—Rio Muni, timber, coffee;
Fernando Po, cocoa; main food products—rice, yams,
cassava, bananas, oil palm nuts, manioc, and livestock
60
Major industries: fishing, sawmilling
Electric power: 5,000 kW capacity (1977); 17 million
kWh produced (1977), 50 kWh per capita
Exports: $36 million (1974); cocoa, coffee, and wood
Imports: $20 million (1974); foodstuffs, chemicals and
chemical products, textiles
Major trade partner: Spain
Budget: (1973) receipts $9 million, expenditures $12
million
Monetary conversion rate: 68.85 Ekuele=US$1 (January
1977)','9269cc225f69c06029aa658aa8cc9215fcf457e09bc5afb078475ef5bc3089b0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2548875a884c9cafa891bff686017d9c68ffc8475e5b2e7fdeb6e4cde4d6b5f9',1972,'ET','Ethiopia','economy',155,'GDP: $2,891 million (1977 est.), $100 per capita; average
annual real growth rate 4% (1967-73), zero (1974 and in
1975)
Agriculture: main crops—coffee, teff, durra, barley,
wheat, corn, sugarcane, cotton, pulses, oilseeds; livestock
Major industries: cement, sugar refining, cotton textiles,
food processing, oil refinery
Electric power: 297,000 kW capacity (1977); 500 million
kWh produced (1977), 20 kWh per capita
Exports: $329 million (f.0.b., 1977); 75% coffee, 7% hides
and skins, 6% pulses, 2% oilseeds
Imports: $348 million (c.if.,. 1977); 18% petroleum
Major trade partners: imports—Saudi Arabia, Japan,
Italy, West Germany, Iran, U.K., France, and US:
exports—U.S., Djibouti, Saudi Arabia, Japan, Italy, West','eae83d2615dfe06d768a1f63343a686ce716f7b75f1540eb7553e1fc54fcaa2b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e1588b9a70b4e6922726475e95aecb2d39b62fef733561a7be416682f18280c',1972,'DE','Germany','economy',156,'Monetary conversion rate: 2.07 Ethiopian Birr=US$)
Fiscal year: 8 July-7 July
. Aid: economic—from U.S. (FY46-76), $129 million loans,
$236 million grants; from international organizations
(FY46-75), $246 million; from other Western countries
(1960-71), $12.3 million: military—assistance from USS.
(FY46-75), $41 million
Central government budget (1978 est.): expenditures,
$943 million; revenues, $943 million
Monetary conversion rate: 1 quetzal=US$1 (official)
Fiscal year: calendar year
Monetary conversion rate: 1 Tunisian dinar (TD)=
US$2.32
Fiscal year: calendar year
GNP: $45.0 billion (1977), $1,070 per capita; 3.8% real
growth 1977, 7%-8% average annual real growth 1970-76
Agriculture: main products—cotton, tobacco, cereals,
sugar beets, fruits, nuts, and livestock products; self-suffi-
cient in food in average years
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
-a.
ls rs
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 5,000,000 kW capacity (1977); 22.0
billion kWh produced (1977), 510 kWh per capita
Exports: $2,671 million -(f.0.b., 1977); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $6,999 million (f.0.b., 1977); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals ,
Major trade partners: 22% West Germany, 9% U.S., 9%
Iraq, 7% U.K., 7% Italy (1976)
Budget: (FY77) revenues $11.2 billion, Secinisel $12.2
billion, deficit $1.01 billion
Monetary conversion rate: 25.25 Turkish liras=US$1
(July 1978)
Fiscal year: 1 March-28 February','26b0e75e55bca1654ccb543107c43113464a749df981a49bccdefc7ed1710621','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bcdcffd6ffb9c4e00fd657b61b00e85cc7c2a1040375b4e827c27a13997a112',1972,'FO','Faroe Islands','economy',161,'GDP: $173.4 million (1974), about $4,340 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 341,962 metric tons (1976); exports, $94.7
million (1976)
Major industry: fishing
Electric power: 28,500 kW capacity (1977); 90 million
kWh produced (1977), 2,140 kWh per capita
Exports: $104.4 million (f.0.b., 1976); mostly fish and fish
products
Imports: $180.7 million (c.i.f., 1976); machinery and
transport equipment, petroleum and petroleum products,
food products
Major trade partners: 50.2% Denmark, 13.7% Norway,
7.9% U.K., 7.2% U.S., 4.4% Italy (1976)
Budget: (FY76) expenditures $52.8 million, revenues
$52.8 million
Monetary conversion rate: 6.00382 Danish Kroner=US$1
(1977, average)
Fiscal year: calendar year beginning 1 January 1979
63
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FAROE ISLANDS/FIJ1','772899fe021c563c86b0dc1fe1a0d4a03eb76796484bd3970f49598c8a33c89d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2257c9d96d1c101c3ef2ab2679d099553a1214579516b015cd33a78edc15dca6',1972,'FI','Finland','economy',165,'GNP: $29 billion (1977), $6,110 per capita; 53%
consumption, 27% investment, 21% government; —1% net
exports of goods and services; 1976 growth rate 0.3%,
constant prices, 1977 growth rate —0.1%
Agriculture: animal husbandry, especially dairying, pre-
dominates; forestry important secondary occupation for
rural population; main crops—cereals, sugar beets, potatoes;
85% self-sufficient; shortages—food and fodder grains;
caloric intake 2,940 calories per day per capita (1970-71)
Major industries: include metal manufacturing and
shipbuilding, forestry and wood processing (pulp, paper),
copper refining :
Shortages: fossil fuels; industrial raw materials, except
wood, and iron ore
Crude steel: 1.7 million metric tons produced (1976), 360
kg per capita
Electric power: 9,400,000 kW capacity (1977); 33.1
billion kWh produced (1977), 6,975 kWh per capita
Exports: $7.7 billion (f.0.b., 1977); timber, paper and
pulp, ships, machinery, iron and steel, clothing and footwear
Imports: $7.6 billion (c.i.f., 1977); foodstuffs, petroleum
and petroleum products, chemicals, transport equipment,
iron and steel,. machinery, textile yarn and fabrics
Major trade partners: (1976) 37% EC-nine (13% West
Germany, 11% U.K.); 19% U.S.S.R., 16% Sweden; 5% U.S.
Aid: economic authorizations—U.S. $64 million (FY70-76)
Budget: (1976) expenditures $8.4 billion, revenues $7.8
billion
Monetary conversion rate: new markka (Fmk)
4.03=US$1 (1977 average, IMF)
Fiscal year: calendar year','8a72af6b45768f337cbb4692b449b9c0b7ebe34d8ae4e73ef227c3502594edcd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29f84ab7a10501e8a08e5712d5c8f4bd6753916ad0fb6013647d7ce9f9a76eb5',1972,'FR','France','economy',169,'GNP: $381 billion (1977), $7,150 per capita; 6].2% private
consumption, 22.6% investment (including government),
15.8% government consumption; 1977 real growth rate,
2.4%; average annual growth rate, 4.8% (1966-76)
Agriculture: Western Europe’s foremost producer; main
products—beef, cereals, sugar beets, potatoes, wine grapes;
self-sufficient for most temperate zone foodstuffs; food
shortages—fats and oils, tropical produce; caloric intake,
3,270 calories per day per capita (1969-70)
Fishing: catch 805,925 metric tons (1976); exports
(includes shellfish, etc.) $122 million, imports $506 million
(1976)
Major industries: steel, machinery and equipment,
textiles and clothing, chemicals, food processing, metallurgy,
aircraft, motor vehicles
Shortages: crude oil, textile fibers, most nonferrous ores,
coking coal, fats and oils
Crude steel: 22.1 million metric tons produced (1977),
410 kg per capita
Electric power: 54,000,000 kW capacity (1977); 21]
billion kWh produced (1977), 3,955 kWh per capita
67
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FRANCE/FRENCH GUIANA
Exports: $65.0 billion (f.0.b., 1977); principal items—
machinery and transportation equipment, foodstuffs, agri-
cultural products, iron and steel products, textiles and
clothing, chemicals
Imports: $70.5 billion (c.i.f., 1977); principal items—
crude petroleum, machinery and equipment, chemicals, iron
and steel products, foodstuffs, agricultural products
Major trade partners: 18% West Germany; 9% Belgium-
Luxembourg; 10% Italy;.6% U.S.; 5% Netherlands; 6% U.K.;
2% Eastern Europe; 2% U.S.S.R.; 8% Franc Zone (1977)
Aid: donor—bilateral economic aid authorized (ODA and
OOF), $13,384 million (1970-76)
Budget: (1977) expenditures 355 billion francs, revenues
336 billion francs, deficit 19 billion francs
Monetary conversion rate: 1 franc=US$$0.2035 (1977
average)
Fiscal year: calendar year
GNP: $9.3 billion prelim. est. (1977, at 1977 prices),
$2,930 per capita; 63.4% consumption, 25.9% investment,
18.8% government, 2.0% inventories; — 10.2% net export of
goods and services; 1970-77 (inclusive) real growth rate,
average 3.1%
Agriculture: 70% of agricultural area used for permanent
hay and pasture; main products—livestock and dairy
products, turnips, barley, potatoes, sugar beets, wheat; 85%
self-sufficient; food shortages—grains, fruits, vegetables;
caloric’ intake 3,510 calories per day per capita (1970)
Fishing: catch 94,319 metric tons (1976); exports of fish
and fish products $37.3 million (1976), imports of fish and
fish products $15.7 million (1976)
Major industries: food products, brewing, textiles and
clothing, chemicals and pharmaceuticals, machinery and
transportation equipment
Shortages: coal, petroleum, timber and woodpulp, steel
‘and nonferrous metals, fertilizers, cereals and animal feeds,
textile fibers and textiles
Crude steel: 85,000 metric tons produced in 1975, 30 kg
per capita
Electric power: 2,400,000 kW capacity (1977); 9.8 billion
kWh produced (1977), 2,910 kWh per capita
Exports: $4,395 million (f.o.b., 1977); live animals, meat,
dairy products, textiles, clothing, chemicals, machinery
Imports: $5,377 million (c.if., 1977); petroleum and
petroleum products, machinery, chemicals, cereals, textiles
Major trade partners: 66% EC (42% U.K.); 8% USS.
(January-November 1977)
Aid: economic—EC Common Borrowing Facility, $300
million (1976)
Budget: (1978 projected) 2,368 million pounds expendi-
tures, 1,963 million pounds revenues, 405 million pounds
deficit, public sector borrowing requirement 82] million
pounds
Monetary conversion rate: 1 Irish pound=US$].7448
(1977) annual average, floating)
Fiscal year: calendar year
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ee
Ow TW
ee ee eee
NN NN ar a
et A a a i A a a a ei ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
IRELAND/ISRAEL
GNP: $2.5 billion, $6,900 per capita (1977); 58.1% private
consumption, 14.5% government consumption, 28.3% invest-
ment, 2.8% change in stocks; —3.7% net foreign balance
Agriculture: mixed farming; main crops—grains, pota-
toes, fodder beets; food shortages—sugar, bread grains, fats
Major industries: iron and steel (25% of GNP), food
processing, chemicals, metal products and engineering, tires
123
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
LUXEMBOURG/MACAO
Crude steel: 4.28 million metric tons produced (1977), 12
metric tons per capita
Electric power: 1,850,000 kW capacity (1977); 1,300
million kWh produced (1977), 3,591 kWh per capita
Exports, Imports, Major trade partners: Luxembourg has
‘a customs union with Belgium under which foreign trade is
recorded jointly for the two countries; Luxembourg’s
principal exports are iron and steel: products, principal
imports are coal and consumer goods; most of its foreign
trade is with Germany, Belgium, France, and other EC
countries (for totals, see Belgium)
Budget: (1977) expenditures $1,056 million, revenues
$1,066 million, surplus. $10 million :
Monetary conversion rate: LF35.841=US$1, 1977 aver-
age; under the BLEU agreement, the Luxembourg franc is
equal in value to the Belgian franc which circulates freely in','4dab4bfc650f24895004fa5f121f59ea86546b2287b35c39459faa2f947748c0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e76db20a2744a433429d421a6e773d5e9f7e3641843cdcf2234e7423d4355082',1972,'GY','Guyana','economy',173,'GNP: $100 million (at market prices, 1975), $800 per
capita :
Agriculture: main crops—rice, corn, manioc, cocoa,
bananas, sugarcane ,
Fishing: catch 1,113 metric tons (1976)
Major industries: timber, rum, gold mining, production
of rosewood essence, and space center
Electric power: 29,000 kW capacity, (1977); 60 million
kWh produced (1977), 1,000 kWh per capita
Exports: $7.2 million (1977); shrimp, timber, rum
rosewood essence .
’
Imports: $143.4 million (1977); food (grains, processed
meat), other consumer goods, producer goods, and
petroleum
Major trade partners: exports—78% U.S., 11% France,
5% Martinique; imports—49% France, 10% US., 3%
Trinidad and Tobago (1969) .
Aid: economic—bilateral commitments including Ex-Im
(FY70-76), from Western (non-U.S.) countries, $356 million,
no ‘military aid’
Monetary conversion rate: 4.92 French francs=US$1
Fiscal year: calendar year
GNP: $418 million (1977), $510 per capita; real growth
rate 1977, —6.2%
Agriculture: main crops—sugarcane, rice, other food
crops; food shortages—wheat flour, cooking oil, processed
meat, dairy products
Major industries: bauxite mining, alumina production,
sugar and rice milling, timber
Electric power: 175,000 kW capacity (1977); 370 million:
kWh produced (1977), 450 kWh per capita
Exports: $258 million (f.o.b., 1977); bauxite, sugar,
alumina, rice, shrimp, molasses, timber, diamonds, rum
Imports: $314 million (c.if., 1977); manufactures, ma-
chinery, food, petroleum
Major trade partners: exports—31% U.K., 19% U.S., 16%
CARICOM, 5% Canada; imports—26% U.S., 21% U.K., 26%
CARICOM, 4% Canada (1977)
Aid: economic—bilateral commitments including Ex-Im
(FY70-76), from U.S., $36.7 million; from other Western
countries, $63.9 million; from OPEC, $15 million; from
Communist countries, $46 million; no military aid
Budget: revenue, $189 million; expenditure, $252 million
(1978)
Monetary conversion rate: floating with US dollar, 1
US$=G$2.55
Fiseal year: calendar year','706764afa16d94b7abbc9e3d830eace3c302bae1037d853cbb5f9122921b5dd1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0b191d96ae9f754ce105f289553bb6c3212602130d9d1283943a139dfcaeb53',1972,'PF','French Polynesia','economy',177,'GDP: $259 million (1970) $1,960 per capita
Agriculture: coconut main crop
Major industries: maintenance of French nuclear test
base, tourism
Electric power: 36,000 kW capacity (1977); 105 million
kWh produced (1977), 750 kWh per capita
Exports: $19 million (1973); principal products—coconut
products (79%), mother-of-pearl (14%) (1971)
Imports: $211 million (1973)
Major trade partners: imports—59% France, 14% U.S.;
exports—86% France |
Aid: France’ $16 million (1973)
Monetary conversion rate: 100 CFP=1NZ$ (1971)','b7f9f3ed95554fadf3facec97ccd5d7bd152df2ba5d57d28c2078a6bed9d3370','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4f2a5c4307f44cc27ad1347b4a7089371ec46b2b9acbbc29e4bb3512a96d8a3',1972,'GN','Guinea','economy',181,'GNP: $8 billion (1976 est.) at current prices, about $790
per capita; real growth rate less than 1% (1970-77)
Agriculture: main crop—cocoa; other crops include root
crops, corn, sorghum and millet, peanuts; not self-sufficient,
but can become so ;
. Fishing: catch 237,697 metric tons (1976 est.)
Major industries: mining, lumbering, light manufactur-
ing, fishing, aluminum
Electric power: 1,157,000 kW capacity (1977); 4.0 billion
kWh produced (1977), 390 kWh per capita
Exports: $804 billion (f.0.b., 1976); cocoa (about 70%),
wood, gold, diamonds, manganese, bauxite, and aluminum
76
(aluminum regularly excluded from balance of payments
data)
Imports: $845 billion (c.i.f., 1976); textiles and other
manufactured goods, food, fuels, transport equipment
Major trade partners: U.K., EC, and USS.
Budget: FY78 (proposed)—revenue $1,619 million includ-
ing grants, current expenditure $1,570 million, capital
expenditure $487 million
Monetary conversion rate: 1 Cedi=US$0.87
Fiscal year: 1 July-30 June
GNP: $1.1 billion (1977 est.), $240 per capita
Agriculture: cash crops—coffee, bananas, palm products,
peanuts, and pineapples; staple food crops—cassava, rice,
millet, corn, sweet potatoes; livestock raised in some areas
Major industries: bauxite mining, alumina, light manu-
facturing and processing industries
Electric power: 101,500 kW capacity (1977); 500 million
kWh produced (1977), 110 kWh per capita
Exports: $330 million (f.0.b., 1977 est.); bauxite, alumina,
coffee, pineapples, bananas, palm kernels
Imports: $280 million (f.o.b., 1977 est.); petroleum
products, metals, machinery and transport equipment,
foodstuffs, textiles
Major trade partners: Communist countries, Western
Europe’ (including France), U.S.
Budget: (FY77 est.) current revenue $238 million, current
expenditures $176 million
Monetary conversion rate: 21.25 syli=US$1 floating (end
1977)
Fiscal year: 1 October-30 September
GDP: $1.9 billion (1977), we per capita; real growth
—2.3% in 1976
Agriculture: main crops—peanuts, millet, sanchlin. man-
ioc, rice; peanuts primary cash crop; production of food
crops increasing but still insufficient for domestic re-
quirements
Fishing: catch 361,673 metric tons (1975); exports $30.9
million (1974)
Major industries: fishing, seneiltaed processing —e
light manufacturing, mining
Electric power: 183,850 kW capacity (1977); 603 million
kWh produced (1977), 120 kWh per capita -
Exports: $411 million (f.o.b., 1976/77); peanuts and
peanut products; phosphate . rock; canned fish
Imports: $605 million (c.i.f., 1976/77); food, consumer
goods, machinery, transport equipment
Major trade partners: France, EC (other than France),
and france zone
Aid: economic—Western (non-U.S.) countries (1970-76),
$526.5 million; Communist countries (1970-76), $87.7
million; OPEC (ODA) (1973-76), $81.0 million; U.S. (1970-
76), $42.3 million
Budget: 1978 revised estimate $378 million
Monetary conversion rate: francs; about 242.69 Com-
munaute Financiere Africaine francs=US$1 as of November
1977, floating
Fiscal year: 1 July-30 June','ae1c4b8c204f603b6b54ce6b4611611fa5fe69e56a090f1aa96c8302f61aa09c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e58ee8223a646ada932851f202be709b2c6e768cace7b1ffc42a10c22584514',1972,'GR','Greece','economy',187,'GNP: $26.7 billion (1977 est.), $2,920 per capita; 65.7%
consumption, 22.7% investment, 15.5% government; 1.9%
change in stocks; net foreign balance —5.8%; real growth
rate 4.0% (1977)
Agriculture: main crops—wheat, olives, tobacco; cotton;
nearly self-sufficient; food shortages—livestock products
Major industries: food and tobacco processing, textiles,
chemicals, metal products ,
Shortages: petroleum, minerals, feed grains
Crude steel: 899,750 metric tons produced (1976), 100 kg
per capita
Electric power: 4,800,000 kW capacity (1977); 18 billion
kWh produced (1977), 1,945 kWh per capita
Exports: $2,756 million (f.o.b., 1977); principal items—
tobacco, cotton, fruits, textiles
Imports: $6,853 million (c.i.f., 1977); principal items—
machinery and automotive equipment, petroleum and —
petroleum products, manufactured consumer goods, chemi-
cals, meat and live animals
Major trade partners: (1976)—41.6% EC, 9.2% CEMA
countries, 8.0% other European countries, 16.6% U.S.
Aid: economic (authorized)—U.S., $139 million
(FY70-76); other Western bilateral (ODA and OOF), $649
million (1970-76); military—U.S., $672 million (FY70-76)
Budget: (1978) expenditures $8.2 billion, revenues $6.8
billion
Monetary conversion rate: 1 drachma=US$0.027 (1977
average)
Fiscal year: calendar year','bce90468afda3548e3c16d8374357cc64c860a81e739989d727ad4bf3fb9e334','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e45c7a066ee218c3e41a17feb2a17ee1f6ae43107569d2cdbe993ca586957b44',1972,'GL','Greenland','economy',191,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing;
garden produce
Fishing: catch 44,675 tons (1976); exports $39.8 million
(1976)
Major industries: mining, slaughtering, fishing, sealing --
Electric power: 57,500 kW capacity (1977); 120 million
kWh produced (1977), 2,355 kWh per capita
Exports: $85.4 million (f.0.b., 1976); fish and fish
products, metallic ores and concentrates
Imports: $128.7 million (c.i.f., 1976); petroleum and
’ petroleum products, machinery and transport equipment,
food products
Major trade partners: (1976) Denmark 76.4%, Finland
5.8%, U.S. 4.9%, West Germany 3.0%, France and Monaco
2.7%
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
i i Oe a ee a a i a i id i i ad |
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GREENLAND/GRENADA
Monetary conversion rate: 6.0032 Danish Kroner=US$1
(1977, average)
Fiscal year: calendar year beginning 1 January 1979','f3f8f1ce10a2817397ab43cbbefde44f53901f107fe8447b158ce94b12ebecf9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6d1f1a6eaf3dfbfc5e99a3d32b1ee1075a24f6d5df7463c54b54da31bea8b88',1972,'GD','Grenada','economy',195,'GDP: $54 million (in current prices, 1977), $500 per
capita; real growth rate 1977, 5.8%
Agriculture: main crops—spices, cocoa, bananas |
Electric power: 7,000 kW capacity (1977); 25° million
kWh produced (1977), 230 kWh per capita
Exports: $13 million (f.o.b., 1977); nutmeg, cocoa beans,
bananas, mace
Imports: $32 million (c.if., 1977); food, machinery,
building materials
Major trade partners: exports—33% U.K., 19% West
Germany, 13% Netherlands; imports—27% West Indies,
27% U.K., 9% U.S. (1976)
Aid: economic—bilateral commitments, including Ex-Im
(FY70-76), from Western (non-U.S.) countries, $37.5 million;
from OPEC, $1.2 million; no military aid.
81
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GRENADA/GUADELOUPE
Budget: (est. 1978) revenues, $18 million; expenditures,
$28 million
Monetary conversion rate: 2.70 East Caribbean dollars=
US$1
Fiscal year: calendar year','1229d93112a4ff360fec90b9c6f7b1ca8ab5ca7457e7ddbd4595d7836c7c1e7b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3344d3ba10cf9eb5ee4cd2c1f9418667b3f554a87ed47750ed5f6f63420af46',1972,'GP','Guadeloupe','economy',199,'GDP: $470 million (1975), $1,340 per capita; real growth
‘rate (1975) 1.4%
Agriculture: main crops, sugarcane and bananas
Major industries: agricultural processing, sugar milling
and rum distillation :
Electric power: 50,000 kW capacity (1977); 200 million
kWh produced (1977), 610 kWh per capita
Exports: $90 million (f.o.b., 1976); sugar, fruits- and
vegetables, bananas
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GUADELOUPE/GUATEMALA
Imports: $309 million (c.i.f., 1976); foodstuffs, clothing
and other consumer goods, raw materials and supplies, and
petroleum
Major trade partners: exports—71%, France, 17% U.S.,
7% Germany, 5% other; imports—70% France, 9% U.S., 3%
Germany, 3% Netherlands Antilles, 3% Netherlands, 12%
other (1968)
Aid: economic—bilateral commitments including Ex-Im
(FY70-76), from Western (non-US) countries, $1.2 billion; no
military aid
Monetary conversion rate: 4.75 French francs=US$1
(1976)
Fiscal year: calendar year','072ffb023249c772c17b102f354ac8193122844d52bc64a73d4f2a03377e84a9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b87545938d546a8aa9e7052daefaf713ce5e1c46ae3d701e1802e776a6504f5',1972,'MX','Mexico','economy',202,'GNP: $5,445 million (1977 est.), $880 per capita; 77%
private consumption, 6% government consumption, 19%
domestic investment (1977), —2% net foreign balance
(1976); average annual real growth rate (1971-77), 5.8%
Agriculture: main products—coffee, cotton, corn, beans,
sugarcane, bananas, livestock; caloric intake, 2,200 calories
per day per capita (1967)
Fishing: catch 3,653 metric tons (1976); exports $2.6
million (1973), imports $0.7 million (1973)
Major industries: food processing, textiles arid clothing,
furniture, chemicals, nonmetallic minerals, metals
Electric power: 365,000 kW capacity (1977); 1.5 billion
kWh produced (1977), 240 kWh per capita
Exports: $782 million (f.0.b., 1976); coffee, cotton, sugar,
bananas, meat
Imports: $839 million (c.i.f., 1976); manufactured prod-
ucts, machinery, transportation equipment, chemicals, fuels
Major trade partners: exports (1974)—34% US., 28%
CACM, 11% West Germany, 5% Japan; imports (1974)—
31% U.S., 17% CACM, 12% Venezuela, 9% Japan, 8% West
GDP: $74.2 billion (1977 prelim.), $1,150 per capita; 68%
private consumption, 12% public consumption, 12% private
investment, 8% public investment (1977); net foreign
balance —0%; real growth rate 1977, 3.2%
Agriculture: main crops—corn, cotton, wheat, coffee,
sugarcane, sorghum, oilseeds, pulses, and vegetables; general
self-sufficiency with minor exceptions in meat and dairy ~
products; caloric intake, 3,110 calories per day per capita
- (1968)
Fishing: catch 562,106 metric tons (1977); exports valued
. at $151.3 million, imports at $17.8 million (1975)
Major industries: processing of food, beverages, and
tobacco; chemicals, basic metals and metal products,
petroleum products, mining, textiles and clothing, and
transport equipment :
Crude steel: 9.0 million metric tons capacity (1977); 5.5
million metric tons produced (1977)
Electric power: 13,900,000 kW capacity (1977); 50.1
billion kWh produced (1977), 780 kWh per capita
Exports: $4,166 million (f.0.b., 1977); cotton, coffée,
nonferrous minerals (including lead and zinc), sugar, shrimp,
petroleum, sulfur, salt, cattle and meat, fresh fruit, tomatoes,
machinery and equipment
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
EN ee ee ae ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MEXICO/MONACO
Imports: $5,489 million (c.i.f., 1977); machinery, equip-
ment, industrial vehicles, and intermediate goods
Major trade partners: exports—63% U.S., 5% EC, 2%
Japan (1977); imports—64% U.S., 15% EC, 5% Japan
Aid: economic—(iricluding Ex-Imp Credits) extensions
(1970-76), from U.S. $804 million; from Communist
countries, $12 million; from other Western (non-U.S.)
countries, $1,106.5 million
Budget: 1978 federal, revenues $434 billion pesos,
expenditures $634 billion pesos
Monetary conversion rate: floating
Fiscal year: calendar year','15b192b3796ead1b7d4f1f48ef277767f3246d29e98c940410276441b196f077','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54d23cbf0a158bd86e22fb98eade37c57c49f7a40df5a67312ccbb0f456ef9fc',1972,'GW','Guinea-Bissau','economy',206,'GDP: $112 million (est. 1975), $230 per capita
Agriculture: main crops—palm oil, root crops, rice,
coconuts, peanuts
86
Electric power: 11,000 kW capacity (1977); 17 million
kWh produced (1977), 30 kWh per capita
Exports: $11 million (f.o.b., 1977); principally peanuts,
coconuts, shrimp, fish, wood
Imports: $31 million (c.if., 1977); foodstuffs, manufac-
tured goods, fuels, transport equipment
Major trade partners: mostly Portugal, also immediate
neighbors
Monetary conversion rate: using Portuguese currency;
40.643 escudos=US$1 (November 1977)
Fiscal year: probably is the calendar year','c68d8ed8c581480876df772bb0de5f307e985c77ca78841788b868c0aad6f810','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa815205f49129bd51623f5e310f9d765263243fc3ca8d805d358e5fb55305c2',1972,'PH','Philippines','economy',210,'GDP: $9.5 billion ( 1976, in 1976 prices), $2,130 per
capita (est.); average real growth~4.8% (1970-75)
Agriculture: agriculture occupies a minor position in the
economy; main products—rice, vegetables, dairy products;
less than 20% self-sufficient; food shortages—rice, wheat
Major industries: textiles and clothing, tourism, plastics,
electronics, light metal products, food processing
Shortages: industrial raw materials, water, food
Electric power: 3,127,000 kW capacity (1977); 8,375
million kWh produced (1977), 1,880 kWh per capita
Exports: $9.7 billion (f.0.b., 1977), including $1.4 billion
reexports; principal products clothing, plastic articles,
textiles, electrical goods, wigs, footwear, light metal
manufactures
Imports: $10.5 billion (c.if., 1977)
Major trade partners: (1977) exports—38.7% U.S., 10.5%
West Germany, 8.7% U.K.; imports—23.7% Japan, 16.6%
China, 12.5% USS.
Budget: (77/78) $1.82 billion
Monetary conversion rate: HK$4.62=US$1 (December
1977) \\
Fiseal year: 1 April-31 March
Agriculture: main crops—rice, vegetables; food short-
ages—rice, vegetables, meat; depends mostly on imports for
food requirements
Major industries: textiles, fireworks
Electric power:-116,000 kW capacity (1977); 210 million
kWh produced (1977), 840 kWh per capita
Exports: $185 million (f.0.b., 1976); textiles and clothing,
foodstuffs
Imports: $160 million (c.if., 1976)
Major trade partners: exports—23% West Germany, 17%
France, 10% U.K.; imports—68% Hong Kong, 24% China
(1976)
Monetary conversion rate: 5.4 patacas=US$1 (December
1975); pataca has been pegged to Hong Kong dollar starting
in 1977
Fiscal year: calendar year
GNP: $20.5 billion (1977), $460 per capita; 6.3% real
growth, 1976
Agriculture: main crops—rice, corn, coconut, sugarcane,
bananas, abaca, tobacco ‘
Fishing: catch 1.4 million metric tons (1976)
Major industries: mining, agricultural processing, textiles,
chemicals and chemical products
Electric power: 4,186,000 kW capacity (1977); 15.2
billion kWh produced (1977), 335 kWh per capita
Exports: $3,151 million (f.0.b., 1977); coconut products,
sugar, logs and lumber, copper concentrates, bananas,
garments, nickel, abaca
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Imports: $3,915 million (f.o.b., 1977); petroleum, indus-
trial equipment, wheat
Major trade partners: (1977) exports—35% U.S., 23%
Japan; imports—25% Japan, 20% USS.
Aid: commitments 1970-76: U.S. economic, $467.3 mil-
lion, military, $204.8 million; Western (except U.S.), $996.3
million; Eastern Europe, $35.5 million; OPEC, $61.0 million
Budget: (CY78) revenues $3.8 billion, expenditures $4.6
billion, deficit $0.8 billion; 11% military, 89% civilian
Monetary conversion rate: 7.87 pesos=US$1, July 1978
Fiscal year: calendar year','0587c6499389c029efede3bb8589f09c149810670fecdd7fb9d6fd0587e00994','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d1229e270f6d94c316959277baa701f015afe2d942c0d9e3f755e1308b7f0ac',1972,'HU','Hungary','economy',215,'GNP: $29.4 billion in 1977 (at 1977 prices), $2,750 per
capita; 1977 growth rate, 4.8%
Agriculture: normally self-sufficient; main crops—corn,
wheat, potatoes, sugar beets, wine grapes; caloric intake
3,140 calories per day per capita (1970)
Major industries: mining, metallurgy, engineering indus-
tries, processed foods, textiles, chemicals (especially pharma-
ceuticals) .
Shortages: metallic ores (except bauxite), copper, high
grade coal, forest products, crude oil
Crude steel: 3.72 million metric tons produced (1977),
350 kg per capita
Electric power: 5,100,000 kW capacity (1977); 23.4
billion kWh produced (1977), 2,190 kWh. per capita
Exports: $7,959 million (f.o.b., 1977); 27% machinery,
°18% industrial consumer goods, 30% raw materials and
semimanufactures, 23% food and raw materials for the food
industry, energy sources 2% (distribution for 1977)
Imports: $8,558 million (c.i.f., 1977); 21% machinery, 8%
industrial consumer goods, 49% raw materials and semi-
manufactures; 11% food and raw materials for the food
industry, energy sources 11% (distribution for 1977)
Major trade partners: $16,517 million (1977); 57% with
Communist countries, 43% with non-Communist countries
Aid: U.S.S.R.—$338 million extended (1956-66), $10
million extended in 1967, $167 million extended in 1968; to
jess developed non-Communist countries—$764 million
(1954-77)
Monetary conversion rate: 37.83 forints=US$1 (commer-
cial); 18.90 forints=US$1, noncommercial (June 1978)
Fiscal year: same as calendar year; economic data
reported for calendar years','3e85b6f21e9157ec70eb4e69c8286867e6bed6e701b4e63363434ad724ae71e7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aacac41bdbc420fc63a19c959bc7fa5f8d7d321687bcdc8a337cdf83f5530cef',1972,'IS','Iceland','economy',219,'GNP: $1,415 million (1976), $6,350 per capita; 61.7%
consumption, 28.3% investment, 10.6% government, 1.9%
change in stocks; —2.5% net foreign balance (1977); 1977
growth rate 4.8%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes, turnips;
food shortages—grains, sugar, vegetable and other fibers;
caloric intake, 2,900 calories per day per capita (1964-66)
Fishing: landed 1,375,900 metric tons; exports $233.7
million (1977)
Major industries: fish processing, aluminum smelting,
diatomite production, hydro-electricity
93
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ICELAND/INDIA
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 653,000 kW capacity (1977); 2.5 billion
kWh produced (1977), 11,210 kWh per capita
Exports: $512.3 million (f.0.b., 1977); fish and fish
products, animal products, aluminum, diatomite
Imports: $608.3 million (c.if., 1977); machinery and.
transportation equipment, petroleum, foodstuffs, textiles
Major trade partners: (1977) exports—U.S. 30%, EC 31%,
U.S.S.R. 7%; imports—EC 47%, U.S. 6.5%, U.S.S.R. 9%
Aid: economic authorizations: U.S., $10 million (FY70-76)
Budget: (1977, approved) expenditures $448 million,
revenues $452 million
Monetary conversion rate: 198.9 kronur=US$1 (1977);
182.2 kronur=US$1 (1976)
Fiseal year: caleudar year','1e579f54d69becbb68098798e9ff0c629156bd5d7b7f3458f05ad5ba0800567a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('965d65d69b480815b05f1ab2ae665c5d68bcf059afd45a43100bb187201c7cc3',1972,'IN','India','economy',223,'GNP: $88 billion (CY77 at current prices), $140 per
capita; real growth 6.0% in FY78
Agriculture: main crops—rice, other cereals, pulses,
‘oilseeds, cotton, jute, sugarcane, tobacco, tea, and coffee
‘Fishing: catch 2.5 million metric tons (FY78); exports
* $145 million (FY75), imports $3.3 million (1974).
Major industries: textiles, food processing, steel, machin-
ery, transportation equipment, cement, jute manufactures
Crude steel: 9.83 million metric tons of ingots (CY77)
Electric power: 24,910,000 kW capacity (1977); 99.6
billion kWh produced (1977), 155 kWh per capita
Exports: $6.1 billion (f.0.b., 1977); engineering goods,
textiles and clothing, tea
Imports: $6.8 billion (cif., 1977); machinery and
transport equipment, petroleum, grains and flour, fertilizers
Major trade partners: U.S., U.K., U.S.S.R., Japan
Budget: (FY79) central government receipts, $21.0 billion;
expenditures, $22.8 billion
Monetary conversion rate: 8.1 rupees=US$1 (August
1978)
Fiscal year: fiscal year ends 31 March of stated year','4f865dbfcb1cfb221dba053712c3dc3debb16765bf299c29f37471f858f280ba','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4a85ec70b83e7414df2a6ad11651e951ff5479b9ac88d0aa0f9f71e4b203b48',1972,'IL','Israel','economy',229,'GNP: $13.3 billion (1977, in 1977 prices), $3,720 per
capita; 1977 growth of real GNP 1.0%
Agriculture: main products—citrus and. other fruits,
vegetables, beef and dairy products, poultry products
. Major industries: food processing, diamond cutting and
polishing, textiles and clothing, chemicals, metal products,
transport equipment, electrical equipment, miscellaneous
machinery, rubber and plastic products, potash mining
Electric power: 2,800,000 kW capacity (1978); 13.5
billion kWh produced (1978), 3,700 kWh per capita
Exports: $3.4 billion (f.0.b., 1977); major items—polished
diamonds, citrus and other fruits, textiles and clothing,
processed foods, fertilizer and chemical products; tourism is
leading foreign exchange earner
Imports: $5.4 billion (f.0.b., 1977); major items—military
equipment, rough diamonds, chemicals, machinery, iron and
steel, cereals, textiles, vehicles, ships, and aircraft
102
Major trade partners: exports—EC, U.S., U.K., Japan,
Hong Kong, Switzerland; imports—EC, U.S., U.K., Switzer-
land, Japan
Budget: FY ending 81 March 1979—$11 billion (con-_
verted at 18.5 Israeli pounds=US$1)
Monetary conversion rate: the Israeli pound was allowed
to float on 31 October 1977 and as of 12 October 1978 it was
roughly 18 Israeli pounds=US$1
Fiscal year: 1 April-31 March','3433769fe8b04512fadbdbcc4b72aea5ead7e538082c14dafc38b5f5a73cfe28','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbc64e5783470a4c1b05f70d73a16c70396bea72ca3ba733e8dba41619e78605',1972,'IT','Italy','economy',233,'GDP: $196 billion (1977), $3,470 per capita; 65.5%
private consumption, 19.8% gross fixed investment, 14.0%
government, 1.4% inventory change, net foreign balance
—0.7%; 1977 growth rate 1.7% (1970 constant prices)
Agriculture: important producer of fruits and vegetables;
main crops—cereals, potatoes, olives; 95% self-sufficient;
food shortages—fats, meat, fish, and eggs; daily caloric
intake, 3,835 calories per capita (1974)
Fishing: catch 337,994 metric tons (1977); exports $43
million (1977), imports $386 million (1977)
Major industries: machinery and transportation equip-
ment, iron and steel, chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 23.3 million metric tons produced (1977),
410 kg per capita
103
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ITALY/IVORY COAST
Electric power: 46,000,000 kW capacity (1977); 166.5
billion kWh produced (1977), 2,985 kWh per capita
Exports: $45.0 billion (f.o.b., 1977); principal items—
machinery and transport equipment, textiles, foodstuffs,
chemicals, footwear
Imports: $47.6 billion (c.if., 1977); principal items—
machinery and transport equipment, foodstuffs, ferrous and
nonferrous metals, wool, cotton, petroleum
Major trade partners: (1977) 48.5% EC-nine (20% West
Germany, 16% France, 5% U.K., 4% Netherlands, 3%
Belgium-Luxembourg); 7% U.S.; 3% U.S.S.R. and 2% other
Communist countries of Eastern Europe
Aid: donor—bilateral economic aid authorized (ODA and
OOF), $4,991 million (1970-76)
Monetary conversion rate: Smithsonian rate as of
December 1973, 650.4 lire=US$1; average of Friday closing
rates in 1977—882 lire=US$1
Fiscal year: calendar year
GDP: $6.7 billion (1978 est.), $940 capita; average annual
growth rate in constant prices, 7.5% (1975-78)
Agriculture: commercial—coffee, cocoa, wood, bananas,
pineapples, palm oil; food crops—corn, millet, yams, rice;
other commodities—cotton, rubber, tobacco, fish; self-
sufficient in most foodstuffs, but rice, sugar, and meat
imported
Fishing: catch 76,995 metric tons (1976); exports $12.8
million (1975), imports $33.6 million (1975)
Major industries: food and lumber processing, oil
refinery, automobile assembly plant, textiles, soap, flour
mill, matches, three small shipyards, fertilizer plant, and
battery factory
Electric power: 525,000 kW capacity (1977); 1.2 billion
kWh produced (1977), 170 kWh per capita
Exports: $2.5 billion (f.o.b., 1978 est.); cocoa (80%),
coffee, tropical woods, cotton, bananas, pineapples, palm oil
Imports: $1.9 billion (f.0.b., 1978 est.); manufactured
goods and semi-finished products (50%), consumer goods
(40%), raw materials and fuels .(10%)
Major trade partners: France and other EC countries
about 65%, U.S. 13%, Communist countries about 1%
Aid: economic—(1970-76) Western (non-U.S.), $818.16
million; U.S., $91.0 million; Communist countries, $0.2
million
Budget: 1978, proposed—revenues $1.7 billion, current
expenditures $1.0 billion, investment expenditures $900
million
Monetary conversion rate: about 245.67 Communaute
Financiere Africaine francs=US$1 (1977)
Fiseal year: calendar year','ecac54d3906c5c073aa67f9b4988fa7c6a40d5361d75104e87586e9fbfb2cbc4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aeb72b49e1d022cd1ae5ae1732a1257f0d9bbd6f542e6cd0d2070fbb9f3e681d',1972,'JM','Jamaica','economy',237,'GDP: $3.4 billion (1977), $1,610 per capita; real growth
rate 1977, —4.0%
Agriculture: main crops—sugarcane, citrus fruits, ba-
nanas, pimento, coconuts, coffee, cocoa
Major industries: bauxite mining, textiles, food process-
ing, light manufactures, tourism
Electric power: 850,000 kW capacity (1977); 2.6 billion
kWh produced (1977), 1,230 kWh per capita
Exports: $745 million (f.0.b., 1977); alumina, bauxite,
sugar, bananas, citrus fruits and fruit products, rum, cocoa
Imports: $863 million (c.i.f., 1977); fuels, machinery,
transportation and electrical equipment, food, fertilizer
Major trade partners: exports—U.S. 44%, U.K. 20%,
Norway 11%, Canada 8%; imports—U.S. 36%, U.K. 10%,
Canada 6% (1977)
Aid: economic—bilateral commitments including Ex-Im
(FY70/76) from U.S., $127.2 million; from other Western
countries, $197.1 million; from OPEC, $9 million; from
Communist countries, $9.7 million; no military aid
Budget: (1978/79)—revenue $803 million, expenditure
$1,119 million —
Monetary conversion rate: 1 Jamaican dollar=US$$0.645
Fiscal year: 1 April-31 March
GNP: $685 billion (1977, at 268.2 yen=US$1); $6,010 per
capita (1976); 53% personal consumption, 33% investment,
9% government current expenditure; real growth rate 5.2%
(1977); average annual growth rate (1974-76), 2.4%
Agriculture: land intensively cultivated—rice, sugar,
vegetables, fruits, 72% self-sufficient in food (1974); food
107
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
JAPAN/JORDAN
shortages—meat, wheat, feed grains, edible oi] and fats;
caloric intake, 2,502 calories per day per capita (1974)
Fishing: catch 10.6 million metric tons (1976)
Major industries: metallurgical and engineering indus-
tries, electrical and electronic industries, textiles, chemicals
Shortages: fossil fuels, most industrial raw materials
Crude steel: 102 million metric tons produced (1977)
Electric power: 123,793,000 kW capacity (1977); 537
billion kWh produced (1977), 4,690 kWh per capita
Exports: $79.3 billion (f.o.b., 1977); 68% machinery and
equipment, 18% metals and metal products, 6% textiles
Imports: $62.0 billion (f.0.b., 1977); 44% fossil fuels, 7%
metals and metal products, 14% foodstuffs, 7% machinery
and equipment
Major trade partners: exports—25% U.S., 6% Communist
countries, 11% EC, 3% Australia, 41% other; imports—18%
U.S., 8% Australia, 6% EC, 5% Communist countries
Aid: Japanese official foreign economic aid disbursements
3975, $1,148 million
Budget: revenues $120 billion, expenditures $177 billion,
deficit $57 billion (general account for fiscal year ending
March 1979)
Monetary conversion rate: 190.2 yen=US$1 (September
1978 average rate), floating since February 1973
Fiscal year: 1 April-31 March','6312d437ceed4232b892fe53cb4d6cce552cf8b3dd27c7a8e58d8b997e81198a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('943ddbc90d97535867c4e61b7bbb972569318ffca23561a539f78c2cbcd80278',1972,'JO','Jordan','economy',241,'GNP: $1.9 billion (East Bank only, 1977 est.), $870 per
capita; real growth rate (1973-77), 14% .
Agriculture: main crops—fruits, vegetables, olive oil,
wheat; not self-sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining,
and cement production, light manufacturing
Electric power: 250,000 kW capacity (1978); 700 million
kWh produced (1978), 200 kWh per capita, East Bank only
Exports: $249 million (f.o.b., 1977); fruits and vegetables,
phosphate rock; Communist share 5% of total (1977)
Imports: $1,376 million (c.i.f., 1977); petroleum products,
textiles, capital goods, motor vehicles, foodstuffs; Communist
share 9% of total (1977)
Aid: economic—OPEC (ODA) (1973-76), $1,143.1 mil-
lion; U.S.. (1970-76), $486.3 million; Communist countries
(1970-76), $26.5 million; Western countries (1970-76),
$213.4 million; military—U.S. (1970-76), $459.6 million
Budget: (1977 est.)—expenditures $1,005 million (non-
military, $800 million, military $205 million), development
$412 million; deficit $45 million
Monetary conversion rate: 1 Jordanian dinar=US$3.04,
freely convertible (1977 average); 0.3300 Jordanian din-
ar=US$1 (August 1978); 1 Jordanian dinar=US$3.32
Fiscal year: calendar year
GNP: less than $500 million (1971), probably less than $50
per capita (1977)
Agriculture: mainly subsistence except for rubber planta-
tions; main crops—rice, rubber, corn; food shortages—rice,
meat, vegetables, dairy products, sugar, flour
Major industries: rice milling, fishing, wood and wood
products
Shortages: fossil fuels ;
Electric power: 120,000 kW capacity (1977), 260 million
kWh produced (1977), 30 kWh per capita
Exports: probably less than $1 million est. (1977); natural
rubber, rice, pepper, wood
Imports: probably less than $20 million (1976); food, fuel,
machinery
Trade partners: exports—China; imports—China, North
Korea °
Aid: commitments (1970-76): U.S. economic, $652 mil-
lion; military, $1,260 million; Western (except U.S.), $10.8
million; Eastern Europe, $17 million; U.S.S.R., $25 million;
China, $90 million; military—U.S., $1,334 million (FY46-76)
Budget: no budget data available since Communists took
over government
Monetary conversion rate: no currency in use
Fiscal year: calendar year','7f1cfc45b38a90a04e5e789e883458635a59433c8d195ad9ac30da7f776aa26b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd6493bbac2e0ff367bb93711af04fd119b3f1d537d904ba39f280b904fc5845',1972,'KE','Kenya','economy',245,'GDP: $3,905 million at current prices (est. 1977), $270 per
capita; real average annual growth rate, 4.8% (1970-77)
Agriculture: main cash crops—coffee, sisal, tea, pyre-
thrum, cotton, livestock; food crops—corn, wheat, sugar-
cane, rice, cassava; largely self-sufficient in food
Fishing: 40,883 metric tons (1976)
Major industries: small-scale consumer goods (plastic,
furniture, batteries, textiles, soap, agricultural processing,
cigarettes, flour), oil refining, cement
Electric power: 420,000 kW capacity (1977); 1.3 billion
kWh produced (1977), 90 kWh per capita
Exports: $1,361 million (f.o.b., 1977); coffee ($524
million), tea, livestock products, pyrethrum, soda ash,
wattle-bark tanning extract
Imports: $1,290 million (c.i.f., 1977); machinery, trans-
port equipment, crude oil, paper and paper products, iron
and steel products, and textiles
Major trade partners: EC, Japan, Iran, U.S., Zambia,
Uganda, Tanzania
Budget: (FY77/78) current revenues $1,046 million;
current expenditures $918 million; development expendi-
tures $440 million
Monetary conversion rate: 7.94 Kenya shillings=US$1
Fiscal year: 1 July-30 June
GNP: $10.0 billion (1976 in 1975 dollars), $590 per capita
Agriculture: main crops—corn, rice, vegetables; food
shortages—meat, cooking oils; production of foodstuffs
adequate for domestic needs at low levels of consumption
Major industries: machine building, electric power,
chemicals, mining, metallurgy, textiles, food processing
Shortages: complex machinery. and equipment, coking
coal, petroleum
Crude steel: 2.8 million metric tons produced (1976), 106
kg per capita
Electric power: 4,750,000 kW capacity (1977); 28 billion
kWh produced (1977), 1,570 kWh per capita
Exports: $655 million (1977); minerals, chemical, and
metallurgical products
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
:
ue Ln ALAR ROR CACR AEM.
ae
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Imports: $777 million (1977); machinery and equipment,
petroleum, foodstuffs, coking coal
'' Major trade partners:-total trade turnover $1.4 billion;
38% with non-Communist countries, 62% with Communist
countries (1977)
Aid: economic and military aid from the U.S.S.R. and
Budget: revenues $71 million; expenditures $53.8 million
(1976 provisional)
Monetary conversion rate: 92.84 Rwanda francs=US$1
(official) since January 1974
Fiscal year: calendar year','114327bbd1f213c2865d580390bb9e15882d763e9dafbb8a1495e9966758ed83','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55c83897695d7431da69c8f5ff0fbc4753e83302277eec48647a9365e128755f',1972,'SA','Saudi Arabia','economy',249,'GNP: $13.9. billion (1976), $18,080 per capita est.
Agriculture: virtually none, dependent on imports for
food; approx. 75% of potable water must be distilled or
imported
Major industries: crude petroleum production average
for 1977, 1.92 million b/d; government revenues from taxes
and royalties on production, refining, and consumption, $8.5
billion, preliminary est. for 1976; refinery production 132
million bbls (1976), average b/d refinery capacity equaled
645,000 bbls at end of 1976; other major industries include
processing of fertilizers, chemicals; building materials; flour
Electric power: 2,200,000 kW capacity (1978); 7 billion
kWh produced (1978), 5,815 kWh per capita
Exports: $9.8 billion (f.0.b., 1977), of which petroleum
accounted for about 98%; nonpetroleum exports are mostly
reexports, $727 million (1976 est.)
Imports: $4.8 billion (c.i.f., 1977 est.); major suppliers—
US., Japan, U.K., West Germany
Aid: Western (non-U.S.) countries (1970-76), $2.0 million
Budget: (FY77/78) $7.9 billion revenues
Monetary conversion rate: 1 Kuwaiti dinar=US$3.68
(1978)
Fiscal year: 1 July-30 June
GNP: $250 million, $70 per capita (1976 est.)
Agriculture: main crops—rice (overwhelmingly domi-
nant), corn, vegetables; formerly self-sufficient; food short-
ages (due in part to distribution deficiencies), including rice
Major industries: tin mining, timber, tobacco, textiles,
electric power
Shortages: capital equipment, petroleum, transportation
system, trained personnel
Electric power: 61,000 kW capacity (1977); 295 million
kWh produced (1977), 80 kWh per capita
Exports: $8.5 million (f.o.b., 1977 est.); electric power,
forest products, tin concentrates; coffee, undeclared exports
of opium and tobacco
Imports: $55 million (c.i.f., est. 1977); rice and other
foodstuffs, petroleum products, machinery, transportation
equipment
Major trade partners: imports from Thailand, U.S.S.R.,
Japan, France, China, Vietnam; exports to Thailand and
Malaysia; trade with Communist countries insignificant;
Laos was once a major transit point in world gold trade,
value of 1973 gold reexports $55 million
Aid: economic—Communist: Eastern Europe, $4.0 mil-
lion (1974-75); U.S.S.R., $66 million committed (1975-76),
China, $42 million committed (1975-76); OPEC, $1.0
million (1975); Western: $151.4 million (1970-76); U.S.,
economic, $272.3 million (1970-75), military, $1,119.5
million (1970-75) : ,
Budget: (1973-74) receipts, 13.3 billion kip; expenditures,
36.0 billion kip; deficit 22.7 billion kip (provisional totals),
45% military, 55% civilian; no data available since
Communists fully took over government in 1975
Monetary conversion rate: 400 Liberation Kips
(K)=US$1.00, as of 5 May 1978
Fiscal year: 1 July-30 June
GNP: $4.0 billion (1976), $25,320 per capita
Agriculture: farming and grazing on small scale; commer-
cial fishing increasing in importance; most food imported;
‘rice and dates staple diet
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
OR AR oe RA A A on LARA AAA A AA A
ee or - 20
a Te ae TE ee a A aa eS a
kk
eS ee ae EE Sa OE aE ee Nee
ee a Se ee re ae
a ee i i i a
ee A i ad
ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
QATAR/REUNION
Major industries: oil production and refining; crude oil
production from onshore and offshore averaged 435,141 b/d
(1977); 100% takeover was announced in October 1976 of
the Qatar Petroleum Company, still negotiating with Qatar
Shell about offshore fields; oil revenues accrued $2 billion in
1976, representing 95% of government/royal family income;
major development projects include $7 million harbor at Ad
Dawhabh, fertilizer plant, 2° desalting plants, refrigerated
storage for fishing, and a cement plant
Electric power: capacity 560,000 kW (1977); 1.0 billion .
kWh produced (1977), 6,175 kWh per capita
Exports: crude oil dominates; exports $2.2 billion (1976)
of which petroleum is $2 billion
Imports: $817 million (c.i.f., 1976)
Aid: economic—(1970-76), Western (non-U.S.) countries,
$2.2 million
Budget: (1977) revenue $2.0 billion, expenditure $1.83
billion
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.25
(1977)
Fiscal year: 1 April-31 March
GDP: $58 billion (1977), $9,210 per capita; annual growth
in real non-oil GNP approx. 15% (1973/77 average, non-oil)
Agriculture: dates, grains, livestock; not self-sufficient in
food
Major industries: petroleum production 8.6 million b/d
_ (1976); payments to Saudi Arabian Government, $31 billion
(1976 est.); cement production and small steel-rolling mill
and oil refinery; several other light industries, including
factories producing detergents, plastic products, furniture,
etc.; PETROMIN, a semipublic agency associated with the
Ministry of Petroleum, has recently completed a major
fertilizer plant
Electric power: 4,100,000 kW capacity (1977); ‘8 billion
kWh produced (1977), 1,020 kWh per capita
Exports: $41.2 billion (f.0.b., 1977); 99% petroleum and
petroleum products
Imports: $17.4 billion (c.i.f., 1977); manufactured goods,
transportation equipment, construction materials, and proc-
essed food products
Major trade partners: exports—U.S., Western Europe,
Japan; imports—U.S., Japan, West Germany
Monetary conversion rate: 1 Saudi riyal=US$0.28 as of
February 1976 (linked to SDR, freely convertible)
Fiscal year: follows Islamic year; the 1973-74 Saudi fiscal
year covers the period 30 June 1973 through 1 July 1974','8b2080b80ab4e815a9614e6062dcb23022fda5459b805db17c4c0eab30e518a5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50eb9f223e837263d23c506c70fd7e55739b4294cb17436212706af1ee73d328',1972,'LB','Lebanon','economy',253,'Agriculture: fruits, wheat, corn, barley, potatoes, tobacco,
olives, onions; not self-sufficient in food
Major industries: service industries, food processing,
textiles, cement, oil refining, chemicals, some metal fabricat-
ing, tourism
Electric power: 540,000 kW capacity (1977); 1.2 billion
kWh produced (1977), 490 kWh per capita
Exports: $632 million (1977)
Imports: $1.5 billion (1977)
Budget: (1977) expenditures $539 million, revenues $332
million
Monetary conversion rate: 2.95 Lebanese pounds=
US$1 as of August 1978
Fiscal year: calendar year','c1c5ed04cc395cac03dfe967d4258fc3ea39f80ef48b7e58d65fc06bbcf6328f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bdd3941705cc5dc4acd1c13606237957ac2808a91c78a1664d829b090c9ddbe',1972,'LS','Lesotho','economy',257,'GNP: $315 million (FY74 est.), $270 per capita
Agriculture: exceedingly primitive, mostly subsistence
farming and livestock; principal crops are corn, wheat,
pulses, sorghum, barley
Major industries: none
Electric power: approximately 20 million kWh imported
from South Africa (1977)
Exports: labor to South Africa (remittances $120 million
est. in 1976); $12.4 million (est. f.0.b., 1976), wool, mohair,
wheat, cattle, diamonds, peas, beans, corn, hides, skins
Imports: $154.3 million (est. c.if,, 1976); mainly corn,
building materials; clothing, vehicles, machinery, POL
Major trade partner: South Africa
Aid: economic—Western (non-U.S.) countries (1970-76),
$95.0 million; U.S. (1970-76), $25.7 million; OPEC (ODA)
(1973-76), $1.0 million
Budget: (FY76) revenues, $63 million; current expendi-
tures, $38 million; development budget, $25 million
- Monetary conversion rate: Lesotho uses the South
African rand; 1 SA rand=US$1.15 (as of March 1978)
Fiscal year: 1 April-31 March','d860e95706adaea55fda67a5bf780ab04503dd4790c2a96a3e80cd0bb45f019c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('548d42f192b33aad1772b31c05bd36f8e83629f21a67e583383354f59d02450d',1972,'LR','Liberia','economy',261,'GDP: $923-million (1976 est.), $600 per capita; 4%
current annual growth rate (1967-76)
Agriculture: rubber, rice, oil palm, cassava, coffee, cocoa;.
imports of rice, wheat, and live cattle and beef are necessary .
for basic diet
Fishing: catch 23,000 metric tons
Industry: rubber processing, food processing, construction
materials, furniture, palm oil processing, mining (iron ore,
diamonds), 10,000 b/d oil refinery
120
Electric power: 327,000 kW capacity (1977); 980 million
kWh produced (1977), 620.kWh per capita
Exports: $460 million (f.0.b., 1976); iron ore, rubber,
diamonds, lumber and logs, coffee, cocoa
Imports: $399 million (c.i.f., 1976); machinery, transpor-
tation equipment, petroleum products, manufactured goods,
foodstuffs
Major trade partners: U.S., West Germany, Netherlands,
Italy, Belgium
Aid: economic—(1970-76), Western (non-U.S.), $229.5
million; U.S.,’ $107.2 million; military—U.S., $7.6 million
Budget: (FY77) revenues $167 million, expenditures $167
million; development budget $39 million
Monetary conversion rate: Liberia uses U.S. currency
Fiscal year: 1 July-30 June','0cf8c53fe3632acfbfb3d99dc7cc7b91504fe8193030eb0a962814d2449a02ea','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ff3d5ca7e6bea54edc4a27017cab172bb2a20ca5f1fdb77261ea0717e1421c5',1972,'LY','Libya','economy',265,'GDP: $16.6 billion (1977-at current prices), $6,260 per.
capita
Agriculture: main crops—wheat, barley, olives, dates,
citrus fruits, peanuts; approaching self-sufficiency in food
Major industries: petroleum, food processing, textiles,
handicrafts
Electric power: 1,300,000 kW capacity (1977); 2.1 billion.
kWh produced (1977), 760 kWh per capita
Exports: $11.4 billion (f.0.b., 1977); over 99% petroleum
Imports: $5.8 billion (c.i.f., 1977)
Major trade partners: imports—Italy, West Germany,
U.S.; exports—Italy, West Germany, U.K., U.S., France
Monetary conversion rate: 1 Libyan pound=US$3.38
Fiscal year: ] January-31 December (beginning 1974)','0aad8719479ceff56d2ce30ea87194f73a9b0207d3dd5b837ac0604f5df9ca71','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('428e8a931d886eab8c784aba20c8861e039c8c2bb3eae19c7744d319771eb302',1972,'LI','Liechtenstein','economy',269,'Liechtenstein has a prosperous economy based primarily
on small-scale light industry and some farming. Textiles,
ceramics, precision instruments, pharmaceuticals, and
canned foods are the principal manufactures, intended
almost entirely for export. Industry accounts for 95 percent
of total employment. Livestock raising and dairying are the
main sources of income in the small farm sector. A major
source of income to the government is the sale of postage
stamps to foreign collectors, estimated at $6 million
annually. In addition, low business taxes and easy incorpo-
rated rules have induced between 20,000 and 30,000 holding
companies, so-called letter box companies, to establish
nominal offices in the principality. The average tax paid by
one of these companies is about $400 a year.
The Liechtenstein economy is tied closely to that of
Switzerland in a customs union. No national accounts data
are available.
GNP: $291 million (1977 provisional)
Major trade partners: exports (1975)—$202 million;
50.6% EFTA, 41.4% Switzerland, 26.7%. EEC; exports
(1977) —$273 million
Electric power: 23,000 kW capacity (1977); 56 million
kWh produced (1977), 2,240 kWh per capita; power is
exchanged with Switzerland, but net exports average 35
million kWh yearly
Budget: (1978 est.) revenues $104.1 million, expenditures
$75.2 million, surplus $28.9 million','90be9db8d1d9fa898a0357c611ba1536b1294a24911e478a207ffedc7e226228','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b93479b2de94f8ca22f7a66142cbfc1fa7d7ce3e8071f7e5aa327275ab68ee08',1972,'MG','Madagascar','economy',276,'GDP: $2.0 billion (1977), about $250 per capita; real
growth less than. 1% (1970-75)
126
Agriculture: cash crops—coffee, vanilla, cloves, sugar,
tobacco, sisal, rice, raphia; food crops—rice, cassava, cereals,
potatoes, corn, beans, ‘bananas, coconuts, and peanuts;
animal husbandry widespread; imports some rice, milk, and
cereal
Fishing: catch 54,950 metric tons (1976); exports $16.5
million (1974)
Major industries: agricultural processing (meat canneries,
soap factories, brewery, tanneries, sugar refining), light
consumer goods industries (textiles, glassware), cement plant,
auto assembly plant, paper mill, oil refinery
Electric power: 95,000 kW -capacity (1977); 465 million
kWh produced (1977), 60 kWh per capita
Exports: $294 million (f.0.b., 1977 est.); 30% coffee, 8%
vanilla, 7% sugar, 6% cloves; agricultural and livestock
products account for about 85% of export earnings
Imports: $318 million (c.i.f., 1977 est.); about 19%
consumer goods, 21% foodstuffs, 41% primary products
(crude oil, fertilizers, metal products), 19% capital goods
(1974)
Major trade partners: France (in 1974 accounted for 37%
of exports and 48% of imports), U.S., EC; trade with
Communist countries remains a minute part of total trade
Budget: (1977) revenues $331 million, expenditures $344
million
Monetary conversion rate: 248 Malagasy francs=US$1
Fiscal year: calendar year','ec960665226ff44933d29742866ae7d20bafc0a25c0a96877719914507a54283','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79828c59a58c55fd55a2c04e5f1afcc012cc50c944b9bc6858e9dbb01917f354',1972,'MW','Malawi','economy',280,'GDP: $683.1 million (1977), $130 per capita; real average
annual’ growth rate (1970-77) 8.6%
Agriculture: cash crops—tobacco, tea, sugar, peanuts,
cotton, tung, maize; subsistence crops—corn, sorghum,
millet, pulses, root crops, fruit, vegetables, rice
Electric power: 105,000 kW capacity (1977); 315 million
kWh produced (1977), 60 kWh per capita
Major industries: agricultural processing (tea, tobacco,
sugar), sawmilling, cement, consumer goods
Exports: $215.30 million (f.0.b., 1977 est.); tobacco, tea,
sugar, peanuts, cotton :
Imports: $256 billion (c.if., 1977 est.); manufactured
goods, machinery and transport equipment, building and
construction materials, fuel, fertilizer
Major trade partners: exports—U.K., U.S., South Africa,
Netherlands; imports—South Africa, U.K., Japan, U.S., FRG,
Netherlands :
Aid: economic—(1970-76) Western (non-U.S.) countries,
$256.1 million; U.S., $7.3 million
Budget: FY77/78 revenues $92 million; expenditures $86
million
Monetary conversion rate: 1 Malawi kwacha=US$1.16
Fiscal year: 1 April-3] March','3dd6110bbfb9d4dd34207e00a9066663ad9bab3cd96138a13bca6f2e32906738','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b449e5eeec9b087196900157ab400bbc03eba1adce2289f71145063c1358dace',1972,'MY','Malaysia','economy',284,'GNP:
Malaysia: $12.4 billion (1977), $990 per capita; average
annual real growth 7.8% (1970-76); 8.0% (1977)
Agriculture:
Peninsular Malaysia: natural rubber, oil palm, rice;
10%-15% of rice requirements imported
Sabah: mainly subsistence; main crops—rubber, tim-
‘ber, coconut, rice; food deficit—rice
Sarawak: main crops—rubber, timber, pepper; food
- deficit—rice
Fishing: catch 516,903 metric tons (1976)
Major industries:
Peninsular Malaysia: rubber and oil palm processing
and manufacturing, light manufacturing industry, elec-
tronics, tin mining and smelting, logging and processing
timber ;
129
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
MALAYSIA/MALDIVES
Sabah: logging, petroleum production
Sarawak: agriculture processing, petroleum production
and refining, logging
Electric power:
Peninsular Malaysia: 1,595,000 kW capacity (1977);
7.0 billion kWh .produced (1977), 655 kWh per capita
Sabah: 131,700 kW capacity (1977); 355 million kWh
produced (1977), 400 kWh per ‘capita
Sarawak: 91,000 kW capacity (1977); 250 million kWh
produced (1977), 215 kWh per capita ,
Exports: $6.1 billion (f.o.b., 1977); natural rubber, palm
oil, tin, timber, petroleum
Imports: $5.0 billion (c.i.f., 1977)
Major trade partners: exports—19% Singapore, 18% U.S.,
20% Japan; imports—21% Japan, 11% U.K.., 12% US., 9%','a250070db16c8450179a0daf878d28b414d9a6e0438c6400616fa932f638ff3f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9fd5a5a810d789b7652da9a57d5883376e1386e1bddb2f405b4bb19dd439de8',1972,'SG','Singapore','economy',285,'Aid: U.S. economic 1970-76, $23.1 million; military $64.7
million; Western (except U.S.), $562.6 million; OPEC, 1974-
76, $186.5 million
Budget: 1978 revenues $3.4 billion; expenditures $4.6
billion; deficit $1.2 billion; 20% military, 80% civilian
Monetary conversion rate: 2.30 ringgits= US$1 (August
1978) |
Fiscal year: calendar year
GDP: $6.65 billion (1977), $2,830 per capita; 10.5%
average annual real growth (1966-77), 8% (1977)
Agriculture: occupies a position of minor importance in
the economy, self-sufficient in pork, poultry, and eggs, must
import much of its other food requirements; major crops—
rubber, copra, fruit and vegetables
Fishing: catch 14,350 metric tons (1977), imports—69,729
metric tons (1977) .
Major industries: petroleum refining, oil drilling equip-
ment, rubber processing and rubber products, processed
food and beverages, electronics, ship repair, entrepot trade,
financial services
Electric power: 1,390,000 kW capacity (1977); 5 billion
kWh produced (1977), 2,210 kWh per capita
- Exports: $8.2 billion (f.0.b., 1977); 40% reexports;
petroleum products, rubber, manufactured goods
Imports: $10.5 billion (c.i.f., 1977); 23% goods reexported;
major retained imports—capital equipment, manufactured
goods, petroleum
Major trade partners: exports—Malaysia, U.S., Japan,
Hong Kong, U.K., Indonesia; imports—Japan, Malaysia,
U.S., Saudi Arabia
Aid: Western (except U.S.) (1970-76), $172.8 million
committed; U.S. (1970-76), $1.9 million committed
Budget: (FY77/78) revenues $1.6 billion, expenditures
$2.6 billion, deficit $800 million; 12% military, 83% civilian
Monetary conversion rate: 2.30 Singapore dollars=US$1]
(July 1978)
Fiscal year: 1 April-31 March','4de0eca71477b91c8e95bd7d29e5557dbc24c6407ea28a4e8102a1e4ccd84ae3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e74c0d5c01bd134d115dbcee592669fb508386cd1a498d0c30ca015047df5a34',1972,'MV','Maldives','economy',290,'GNP: $17.4 million (1974), $150 per capita
Agriculture: crops—coconut and millet; shortages—rice,
wheat
Fishing: catch 32,300 metric tons (1976) -
Major industries: fishing; some coconut processing
Electric power: 4,000 kW capacity (1977): 6 million kWh
produced (1977), 40 kWh per capita —
Exports: $3 million (1975); fish
Imports: $9.3 million (1975)
Major trade partners: Sri Lanka, Japan
Aid: U.K. (1960-65), $1.4 million drawn; Sri Lanka (1967),
$1 million committed; Kuwait $5 million; other OPEC
countries, Japan and India (amounts not known)
Monetary conversion rate: 3.93 Maldivian rupees=US$1,
official rate; 8.5 rupees=US$1, market rate (February 1978)
Fiscal year: calendar year
‘GDP: estimated about $645 million (1977), $110 per
capita; annual real growth rate 5.8% - (1973-76)
Agriculture: main crops—millet, sorghum, rice, corn,
peanuts; cash crops—peanuts, cotton, and livestock
Fishing: catch 100,000 metric tons (1975)
Major industries: small local consumer goods and
processing
Electric power: 42,000 kW capacity (1977); 105 million
kWh produced (1977), 20 kWh per capita
Exports: estimated $125 million (f.0.b., 1977); livestock,
peanuts, dried fish, cotton, and skins
Imports: estimated $170 million (c.if., 1977); ‘textiles,
vehicles, petroleum products, machinery, and sugar
Major trade partners: mostly with franc zone and
Western Europe; also with U.S.S.R., China
Budget: (1976) expenditures $102 million; revenues $82
million
Monetary conversion rate: 491.34 Mali francs=US$1,
1977 ;
Fiscal year: calendar year','0d3ac3e2a6e11f6760286f8638d1c1408522dc019051ffdfe4803a77efdaec3f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b89fee49f0e7e4dda33cc695cb37046bd5628f97cca65fb84ea3421ddade75c',1972,'MT','Malta','economy',294,'GNP: $609 million (1977), $1,850 per capita; 72% private
consumption, 26% gross investment; 17% government
consumption, — 15% net foreign sector; in 1977 real GNP
growth was 9% (1977 prelim.); 12.5% (1971-76 average)
Agriculture: overall, 20% self-sufficient; adequate sup-
plies of vegetables, poultry, milk and pork products;
shortages in beef, grain, animal fodder, and fruits at various
seasons; main products—potatoes, cauliflowers, grapes,
wheat, barley, tomatoes, citrus, cut flowers, green peppers,
hogs, poultry, eggs; 2,680 calories per day per capita
Major industries: ship repair yard, clothing, building
industry, food manufacturing, textiles, tourism
Shortages: most consumer and industrial needs (fuels and
raw materials) must be imported
'' Electric power: 120,000 kW capacity (1977); 420 million
kWh produced (1977), 1,280 kWh per capita
Exports: $289 million (f.o.b., 1977); clothing, textiles,
ships, printed matter :
Imports: $516 million (c.i.f.; 1977)
Major trade partners: 68% EC-nine (23% U.K., 18% West
Germany, 13% Italy); 6% U.S. (1977)
Aid: economic authorizations: U.S., $55 million (FY70-
76); other Western bilateral (ODA and OOF), $112 million
(1970-76); China, $45 million (1972); OPEC, $22 million
(1974-76)
Budget: (1978/79) projects $259 million in expenditures,
$237 million in revenues
Monetary conversion rate: 1 Maltese pound=US$2.37
(average 1977)
Fiscal year: 1 April-31 March
’','9e4e2443cd9cf4ef149dbc91e0c220d2a09ce5a4cbbd893a2fc3427dda5c504b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87f8eabd0f136b67e4ca24e3ba0504d1eaad86c9fe711ba4d5097fe9dbd348e3',1972,'MQ','Martinique','economy',298,'GNP: $1,169 million (1977 at current prices), $3,600 per
capita
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, particularly
sugar milling and rum distillation; cement, oil refining and
tourism
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
AA RA RRLAR AAR RAR RR AN RR AR AO RO
ae, ge SR OR RS
ee ee ee, eee ee ee ee ee ee ae Oe a ee EE OM OE ae See ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
_ January 1979
MARTINIQUE/MAURITANIA
Electric power: 95,500 kW capacity (1977); 150 million
kWh produced (1977), 430 kWh per capita
Exports: $128.1 million (f.o.b., 1977); bananas, refined
petroleum products, rum, sugar, pineapples
_Imports: $426.5 million (c.i.f., 1977); foodstuffs, clothing
and other consumer goods, raw materials and supplies, and
petroleum
Aid: economic—bilateral commitments including Ex-Im
(FY70-76) from Western (non-U.S.) countries, $1.4 billion;
no military aid ;
Major trading partners: exports—82% France, 9% Italy,
9% other; imports—70% France, 6% United States, 3%
Netherlands Antilles, 3% Netherlands, 18% other (1968)
Monetary conversion rate: 4.75 French francs=US$1
(1976)
Fiscal year: calendar year','c4efe17ebde46156e0a411435000bf4f34d4486efadd7554b72fe049e8efbaa2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa3701ccb6be77560f59e0dbf0c9f881b9279980b7b27676b6744b8ead99e8a6',1972,'MR','Mauritania','economy',302,'GDP: about $328 million (1978 prov.), $240 per capita,
average annual increase in current prices about 2% (1971-78)
Agriculture: most Mauritanians are nomads or subsistence
farmers; main products—livestock, small grains, dates; cash
crops—gum arabic; livestock
Fishing: catch, 34,170 metric tons; exports, 29,891 metric
tons (1975)
Major industries: mining of iron ore and copper, fishing ~
Electric power: 70,000 kW capacity (1977); 100 million
kWh produced (1977), 70 kWh per capita
Exports: $136 million (f.o.b., 1978 prov.); iron ore, fish,
copper
Imports: $314 million (f.0.b., 1978 prov.); foodstuffs,
capital goods
Major trade partners: (trade figures not complete because
Mauritania has a form of customs union with Senegal and
much local trade unreported) France and other EC
members, U.K., and U.S. are main overseas partners
Budget: 1978 prov. $267 million expenditures, $44 million
grants, $138 million revenue
Monetary conversion rate: 45.68 Ouguiyas=US$1 as of
November 1977
Fiscal year: calendar year
-GNP: $9.7 billion (1977), about $530 per capita; average
annual real growth 4% during 1970-73, 9% in 1974, under
3% in 1975-77 :
Agriculture: cereal farming and livestock raising predomi-
nate; main products—wheat, barley, citrus fruit, wine,
vegetables, olives; some fishing
Fishing: catch 281,434 metric tons (1976); exports $64.5
million (1975) ,
’ Major sectors: mining and mineral processing (phos-
phates, smaller quantities of iron, manganese, lead, zinc, and
other minerals), food processing, textiles, construction and
tourism
Electric power: 1,200,000 kW capacity (1977); 3.1 billion
kWh produced (1977), 165 kWh per capita
Exports: $1,302 million (1977); 33% phosphates, 77%
other
Imports: $3.0 billion (1977); 34.0% capital goods, 13.5%
foodstuffs, 11.0% petroleum products
Major trade partners: France, West Germany, Italy
Budget: (1978) revenue $2.7 billion, expenditure $2.0
billion
Monetary conversion rate: 4.5 dirhams=US$1
Fiscal year: calendar year
Agriculture: practically none; some barley is grown in
nondrought years; fruit and vegetables in the few oases; food
imports are essential; camels, sheep, and goats are kept by
the nomadic natives; cash economy exists largely for the
garrison forces .
Major phosphate mining, fishing, and
handicrafts
Shortages: water
Electric power: 4,000 kW capacity (1975); 9 million kWh
produced (1975), 80 kWh per capita
Exports: in 1975, up to $75 million in phosphates, all other
exports valued at under $1 million
Imports: $1,443,000 (1968); fuel for . fishing fleet,
foodstuffs
Major trade partners: monetary trade largely with Spain
and Spanish possessions ©
industries:
Aid: small amounts from Spain in prior years
Monetary conversion rate: see Moroccan and Mauritan-
ian currencies','28de1acb0e23f6778cf07afe0bb72f58e47251fc7f09902489000aa9bbd060ef','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52b65ce27f94482bf7615ce6b1646a01f8cda11b6a73fa2e32a309a7a67792fc',1972,'MU','Mauritius','economy',306,'GNP: $570 million (1977), $640 per capita; real growth
(1970-76), 6%
Agriculture: sugar crop is major economic asset; about
40% of land area is planted to sugar; most food imported—
rice is the staple food—and since cultivation is already
intense and expansion of cultivable areas is unlikely, heavy
reliance on food imports except sugar and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea;
some small-scale, simple manufactures; tobacco fiber; some
MAURITIUS /MEXICO
fishing; tourism, diamond cutting, weaving and textiles,
electronics
Electric power: 81,000 kW capacity (1977); 312 million
kWh produced (1977), 8340 kWh per capita
Exports: $312 million (f.0.b., 1977); $268 million sugar, $4
million tea, $5 million molasses
Imports: $442 million (c.if., 1977); foodstuffs 30%,
manufactured goods about 25%
Major trade partners: all EC-nine countries and U.S.
have preferential treatment, U.K. buys over 50% of
Mauritius’ sugar export at heavily subsidized prices; small
amount of sugar exported to Canada, U.S., and Italy; imports
from U.K. and EC primarily, also from South Africa,
Australia, and Burma; some minor trade with China
Aid: economic—(1970-76) Western (non-U.S.) countries,.
$75.5 million, Communist countries, $40.2 million; U.S.,
$14.7 million
‘Budget: revenues $174 million, current expenditures $261
million (1977)
Monetary conversion rate: 6.6 Mauritian rupees=US$1
1977 (floating with pound sterling)
Fiscal year: 1 July-30 June
Agriculture: cash crops—almost entirely sugarcane, small
amounts of vanilla and perfume plants; food crops—tropical
fruit and vegetables, manioc, bananas, corn, market garden
produce, also some tea, tobacco, and coffee; food crop
inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling
plants, cigarette factory, 2 tea plants, fruit juice plant,
canning factory, a slaughterhouse, and a number of small
shops producing handicraft items
Electric power: 75,000 kW capacity (1977); 185 million
- . kWh produced (1977), 370 kWh per capita
Exports: $62 million (f.0.b., 1975); 90% sugar, 4% perfume
* essences, 5% rum and molasses, 1% vanilla and tea (1974)
Imports: $410 million (c.i-f., 1975); manufactured goods,
food, beverages, and tobacco, machinery and transportation
equipment, raw materials and petroleum products
Major trade partners: France (in 1970 supplied 62% of
Reunions imports, purchased 76% of its exports); Mauritius
(supplied 12% of imports)
‘Aid: economic—(1970-76) Western (non-U.S.) countries,
$2,106 million
Monetary conversion rate: 4.705 French francs=US$1
Fiscal year: probably calendar year ,','b3c5beb428f9cb199667acd43f0f6cf4188f4ccec1572d6a6de04cf6e30581e6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e1f2615be74945864dbcef013d561b858c54616919ba7d8f5b8e5152a302d59',1972,'MC','Monaco','economy',310,'GNP: 55% tourism; 25%-30% industry (small and primar-
ily tourist oriented); 10%-15% registration fees and sales of
postage stamps; about 4% traceable to the Monte Carlo
casino
139
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MONACO/MONGOLIA
Major industries: chemicals, food processing, precision
instruments, glassmaking, printing
Electric power: 8,000 (standby) kW capacity (1977); 100
million kWh supplied by France (1977)
Trade: full customs integration with France, which
collects and rebates Monacan trade duties
Monetary conversion rate: ]1 franc=US$0.2102 (1977
average)','d5c2ce17f75d522ae363cd61f338be3514352e25d50d577341c1dd2da405cec5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2b6439488d5b883629c3bfe0568634dbfe5c4bddf6481b73e5eb3b3fc878482',1972,'MN','Mongolia','economy',314,'Agriculture: livestock raising predominates; main crops—
wheat, oats, barley
Industries: processing of animal products; building
materials; mining , . ,
Electric power: 307,400 kW capacity (1977); 995 million.
kWh produced (1977), 650 kWh per capita
Exports: beef for slaughter meat products, wool, fluorspar,
other minerals
Imports: machinery and equipment, petroleum, clothing,
building materials, sugar, and tea
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ee ee EE eS. a ee ee ee a OS a ee ee
Dn EE SE RE ES, OE
eee ee We ee OL ee, PG Mg a ee
COE ee nee Se ET, ae eee ee Ee ee! OS Oe, ee ee ee Te pe eee fe) Mee eee CM CS te ee eae. @ BY
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MONGOLIA/MOROCCO
Major trade partners: nearly all trade with Communist
countries (approx. 85% with U.S.S.R.); total turnover about
$1.0 billion (1977)
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 3.11 tugriks=US$1 (June
1978); arbitrarily established
Fiscal year: calendar year','c2dc2987411c31de790b8bdc5f120eacc2941c0370938fe372e48fb2b41414f0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73652f59d7aa72bb7676e8d2860bb168e02ffc2142fcb10a952a27b69ab68857',1972,'MZ','Mozambique','economy',319,'GNP: $2.0 billion (1975 est.), about $220 per capita;
average annual growth probably negative in 1975-77
Agriculture: cash crops—raw cotton, cashew nuts, sugar,
tea, copra, sisal; other crops—corn, wheat, peanuts, potatoes,
beans, sorghum, and cassava; self-sufficient in food except
for wheat which must be imported
Major industries: food processing (chiefly sugar, tea,
wheat, flour, cashew kernels); chemicals (vegetable oil,
oilcakes, soap, paints); petroleum products; beverages;
textiles; nonmetallic mineral products (cement, glass, asbes-
tos, cement products); tobacco
Electric power: 1,664,000 kW capacity (1977); 4.6 billion
kWh produced (1977), 490 kWh per capita
Exports: $155 million (1977 est.); cashew nuts, cotton,
sugar, mineral products, timber products, tea, copra
Imports: $420 million (1977 est.); machinery and electri-
cal equipment, cotton textiles, vehicles, petroleum products,
wine, iron and steel
Major trade partners: Portugal, South Africa, U.S., U.K.,
West Germany
Budget: (FY76) expenditures, $310 million, revenues,
$237 million
Monetary conversion rate: 40.643 escudos= US$] as of
November 1977 ,
Fiseal year: calendar year
GDP: approximately $224 million (FY74), about $470 per
capita; growth rate in current prices as much as 11%
(FY71-74)
Agriculture: main crops—maize, cotton, rice, sugar, and
citrus fruits
Major industry: mining
Electric power: 75,000 kW capacity (1977); 130 million
kWh produced (1977), 250 kWh per capita
Exports: $191 million. (f.0.b., 1976); sugar, iron ore,
asbestos, wood and forest products, citrus; meat products,
cotton
Imports: $200 million (f.0.b., 1976); motor . vehicles,
petroleum products, foodstuffs, and clothing
Major trade partners: South Africa, U.K., U.S.
Aid: economic—Western (non-U.S.) countries (1970-76),
$90.7 million; U.S. (1970-76), $10.2 million
Budget: FY77—revenue $86 million, recurrent expendi-
ture $47 million, development expenditure $39 million
Monetary conversion rate: 1 Lilangeni=US$1.15 (as of
March 1978)
Fiscal year: 1 April-31 March','1711bc629207cc4dbd69b6b00388dc67d18f4b92b812cb6eeb6f1b25a7fa2798','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acb2c0a3549b3304b010976e2a9c9a55f2bae15e9ac0efb80f07265addbb176d',1972,'NA','Namibia','economy',323,'Agriculture: livestock raising (cattle and sheep) predomi-
nates, subsistence crops (millet, sorghum, corn, and some
wheat) are raised but most food must be imported
Fishing: catch 86,650 metric tons (1975) (processed
mostly in South African enclave of Walvis Bay)
Major industries: meatpacking, fish processing, copper,
lead, diamond, and uranium mining, dairy products
Electric power: 297,400 kW. capacity (1977); 1,110
million kWh produced (1977), 1,110 kWh per capita
Aid: South Africa is only donor
Monetary conversion rate: 1 South African Rand=
US$1.15 (as of March 1978); 0.87 SA Rand=US$1
Fiscal year: 1 April-31 March','46c0cf9cab8b2e8f5b7cfb59c5cb974ddbc5ab0ddb404482a0f6e078d4a4838a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8acd2553c1a3fb9bc28b1c223781e640738e0a7be7f22c32fedd0b31c2969611',1972,'NP','Nepal','economy',327,'GDP: $1.3 billion (FY77, at current prices), $100 per
capita; 1% real growth in FY77
Agriculture: over 90% of population engaged in agricul-
ture; main crops—rice, corn, wheat, sugarcane, oilseeds
Major industries: small rice, jute, sugar, and oilseed mills;
match, cigarette, and brick factories
Electric power: 60,600 kW capacity (1977); 144 million
kWh produced (1977), 10 kWh per capita
Exports: $82 million est. (FY78); rice and other food
products, jute, timber
Imports: $206 million est. (FY78); manufactured con-
sumer goods, fuel, construction materials, food products
Major trade partner: over 80% India
Aid: economic commitments 1970-76: U.S.S.R., $3 mil-
lion; China, $118 million; OPEC, $18.1 million; U.S., $71
million; $78 million disbursements FY78
Budget: (FY78 est.) domestic revenues $128 million,
expenditures $231 million
Monetary conversion rate: 12 Nepalese rupees=US$1
Fiscal year: 15 July-14 July','7fae992d9244042d41f32c9b6a40b51f3932826f202cb0b53824b23353961c02','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db722a8719477351b494b7fc511a69d39669d06bbc83f3dbe75b9d4033a0b8e5',1972,'NL','Netherlands','economy',331,'GNP: $105.3 billion (1977 est. in 1977 prices), $7,590 per
capita; 57.7% consumption, 21.7% investment, 17.6% gov-
ernment, 2.7% foreign balance; 0.8% net income from
abroad
husbandry predominates; main
crops—horticultural crops, grains, potatoes, sugar beets; food
Agriculture: animal
shortages—grains, fats, oils; calorie intake, 3,186 calories per
day per capita (1970-71)
Fishing: catch 302,000 metric tons (1977); exports of fish
and fish products $251.2 million (1977), imports $125.8
million (1977) °
Major industries: food processing, metal and engineering
products, electrical and electronic machinery and equip-
ment, chemicals, petroleum products, and natural gas
Shortages: crude petroleum, raw cotton, base metals and
ores, pulp, pulpwood, lumber, feedgrains, and oilseeds
Crude steel: 7.7 million metric ton capacity; 5.2 million
metric tons produced (1976), 380 kg per capita
Electric power: 16,900,000 kW capacity (1977); 59 billion
kWh produced (1977), 4,245 kWh per capita —
Exports: $43.7 billion (f.0.b., 1977); foodstuffs, machinery,
chemicals, petroleum products, natural gas, textiles
Imports: $46.6 billion (c.i.f., 1977); machinery, transpor-
tation equipment, crude petroleum, foodstuffs, chemicals,
raw cotton, base metals and ores, pulp
Major trade partners: (1977) 62.2% EC, 27.6% West
Germany, 13.1% Belgium-Luxembourg, 6.1% U.S.
Aid: donar: bilateral economic aid authorized, $2,731
million (1970-76)
Budget: (1979 est.) revenues $40.2 billion, expenditures
$47.6 billion, deficit $7.4 billion at exchange rate of 2.21
guilders=$1 ,
Monetary conversion rate: 2.4543 guilders=US$1, aver-
age 1977 floating
Fiscal year: calendar year
148','2c089e369beee4a479f7fda2bf2f2564b365d31f91519953f9c559c49703a36b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b88ab01a2239d165bfedfc95bcfa9464a60f7426ef61082c80628092fb8f655',1972,'NI','Nicaragua','economy',338,'GDP: $2,242 million (1977 prelim.), $980 per capita; 70%
private consumption, 8% government consumption, 27%
domestic investment, —5% net foreign balance (1977); real
growth rate 1977, 5.9% prelim.
Agriculture: main’ crops—cotton, coffee, sugarcane, rice,
corn, beans, cattle; caloric intake, 2,300 calories per day per
capita (1966)
Fishing: catch 15,200 metric tons (1977); exports valued
at $22.7 million (1977)
Major industries: food processing, chemicals, metal
products, textiles and clothing
Electric power: 358,000 kW capacity (1977); 1.2 billion
kWh produced (1977), 520 kWh per capita
Exports: $630 million (f.o.b., 1977); cotton, coffee,
chemical products, meat, sugar
Imports: $758 million (c.i.f., 1977); food and non-food
agricultural products, chemicals and pharmaceuticals, trans-
portation equipment, machinery, construction materials,
clothing, petroleum oe
Major trade partners: exports—19% U.S., 22% CACM,
28% EC, 31% other; imports—22% U.S., 26% CACM, 14%
EC, 37% other (1976)
Aid and Ex-Im Credits: economic—extensions (1970-76)
from U.S., $145.3 million; other Western countries, $26.8
million; military—(1970-76) from U.S., $17 million
Budget: 1978 expenditures $480 million, revenues $300
million
Monetary conversion rate: 7.0263 cordobas=US$1
(official)
Fiscal year: calendar year','052907be827bd096feb9482cf8e921fbeeadb890e38401629093de27a8fc3c47','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec107c5c020d5b09151dc5937daabdbc9f99f96ed7b2ca65712445868e04197c',1972,'NE','Niger','economy',342,'GDP: $510 million (1976), $100 per capita, annual growth
estimated by U.S. Embassy at 9.8% (1973-76)
Agriculture: commercial—peanuts, cotton,
main food crops—millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice mill,
small cotton gins, oil presses, slaughterhouse, and a few other
smal] light industries; uranium production began in 1971
Electric power: 20,000 kW capacity (1977); 70 million
kWh produced (1977), 10 kWh per capita
Exports: $118 million (f.0.b., 1976); about 65% uranium,
rest peanuts and related products, livestock, hides, skins;
exports understated because much regional trade not
recorded
Imports: $177 million (c.i.f., 1976); fuels, machinery,
transport equipment, foodstuffs, consumer goods
Major trade partners: France (over 50%), other EC
countries, Nigeria, UDEAC countries, U.S.; preferential
tariff to EC and franc zone countries -
Aid: economic—Western (non-U.S.) companies (1970-76),
$372.1 million; U.S. (1970-76), $107.4 million; Communist
countries (1970-76), $54.4 million, OPEC (ODA) (1973-76),
$24.3 million
Budget: (FY76-77) revenue $131 million, expenditure $96
million, surplus $35 million
Monetary conversion rate: about 242.69 Communaute
Financiere Africaine=US$1 as of November 1977, floating
Fiscal year: 1 October-30 September','8b359d010bff034c1208da2144d61ae9ab8dd4b352f01c396d34ace9065ba01d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d82441535e7869463a853ebb1fd15e5fd7b995f33f3c069e1cc5c37695420d4',1972,'NG','Nigeria','economy',347,'GDP: $33 billion (FY77 current prices), $500 per capita;
7.5% growth rate (1970-76)
Agriculture: main crops—peanuts, cotton, cocoa, rubber,
yams, cassava, sorghum, palm kernels, millet, corn, rice;
livestock; almost self-sufficient
Fishing: catch 494,767 metric tons (1976); imports $14.5
million (1974)
Major industries: mining—crude oil, natural gas, coal,
tin, columbite;. processing industries—oil palm, peanut,
cotton, rubber, petroleum, wood, hides, skins; manufacturing
industries—textiles, cement, building*materials, food prod-
ucts, footwear, chemical, printing, ceramics
Electric power: 1,367,000 kW capacity (1977); 4 billion
kWh produced (1977), 60 kWh per capita
Exports: $10.2 billion (f.0.b., 1978 est.); oil (95%), cocoa,
palm products, rubber, timber, tin
Imports: $12 billion (c.if., 1978 est.); machinery and
transport equipment, manufactured goods, chemicals
Major trade partners: U.K., EC, U.S.
Budget: FY78-79 proposed—current revenue $10.9 bil-
lion, current expenditures, $4.2 billion; capital expenditures,
$7.0 billion
Monetary conversion rate: 1 Naira=US$1.59 (June 1978)
Fiscal year: 1 April-31 March','5ca2bac23ba4873ef5235412802ef43ee6b63bb94f6cc2a178e473bd6d58e928','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('448c6c4aa870e435e3733807018fa7c423ebac1f76c92e434204e53e21f1b2e5',1972,'NO','Norway','economy',351,'GNP: $35.8 billion in 1977, $8,850 per capita; 56% private
consumption; 36% investment; 19% government; net foreign
balance — 11%; 1976 growth rate 3.9%, in constant prices;
4.8% average (1970-76)
Agriculture: animal husbandry predominates; main
crops—feed grains, potatoes, fruits, vegetables; 40% self-suf-
ficient; food shortages—food grains, sugar; caloric intake,
2,940 calories per day per capita (1969-70)
Fishing: catch 3.4 million metric tons (1976); value $476
million (1976); exports $467 million (1976)
Major industries: oil and gas, food processing, shipbuild-
ing, wood pulp, paper products, metals, chemicals
Shortages: most.raw materials with the exception of
timber, petroleum, iron, copper, and ilmenite ore, dairy
products and fish
Crude steel: 732,779 metric tons produced (1977), 180 kg
per capita
Electric power: 18,200,000 kW capacity (1977); 72.5
billion kWh produced (1977), 17,885 kWh per capita
Exports: $8,712 million (f.0.b., 1977); principal items—
metals, pulp and paper, fish products, ships, chemicals, oil
Imports: $12,874 million (c.i.f., 1977); principal items—
foodstuff, ships, fuels, motor vehicles, iron and_ steel,
chemical compounds, textiles
Major trade partners: 49% EC (19% U.K., 12% West
Germany, 6% Denmark); 16% Sweden; 5% U.S.; 3% East
Bloc countries (1977)
_ Aid: donor, bilateral economic aid authorized (ODA and
OOF), $503 million (1970-76)
Budget: (1977) revenues $8.8 billion, expenditures $9.3
billion
_Monetary conversion rate: 1 kroner=US$0.188 (1977)
Fiscal year: calendar year
GNP: $2.6 billion’ (1977); $4,880 per capita est.
Agriculture: based on subsistence farming (fruits, dates,
cereals, cattle, camels), fishing, and trade
Major industries: petroleum discovery in 1964; produc-
tion began in 1967; production 1977, 340,000 b/d; pipeline
capacity, 400,000 b/d; revenue for 1976 est. at $1.4 billion
Electric power: 240,000-kW capacity (1977); 380 million
kWh produced (1977), 690 kWh per capita
Exports: $1.6 billion (f.0.b., 1977), mostly petroleum;
non-oil exports (mostly agricultural)
Imports: $813 million (c.i.f., 1977)
Major trade partners: U.K., U.S., other European, Gulf
states, India, Australia, China, Japan
Aid: economic—OPEC (ODA) (1973-76), $857.2 million;
Western (non-U.S.) countries (1970-76), $9.9 million; U.S.
(1970-76), $1.0 million
Budget: (1977) revenues $2.082 billion; expenditures $2.2
billion
Monetary conversion rate: ] Riyal Omani=US$2.93 (as
of October 1978)
Fiscal year: calendar year','a4f953d7edd6e73b7697b5fbfd4e31971593f77dc4c504e4843761259e0a47bc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ffcbcc313feb03cae51638c50b55b3a3924eb11996c5302c1d52a0ef5099077',1972,'PK','Pakistan','economy',355,'GNP: $15.0 billion (FY78 est.), $200 per capita; average
annual real growth, 4.0% (1970-78) ‘
Agriculture: extensive irrigation; main crops—wheat, rice,
‘and cotton; foodgrain shortage, about 1 million tons
imported in FY78
Fishing: catch 197,550 metric tons (1978 est.)
Major industries: cotton textiles, food processing, tobacco,
engineering, chemicals, natural gas
Electric power: 3,430,000 kW capacity (1977); 13.5
billion kWh produced (1977), 175 kWh per capita
Exports: $1,342 million (f.o.b., 1978); cotton (raw and
manufactured), rice
Imports: $2,738 million (c.i.f., 1978); foodgrains, edible
oil, crude oil,machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West Germany
Budget: expenditures, FY78—current expenditures,
$2,048.7 million; capital expenditures, $1,717.2 million
160
. Monetary conversion rate: 9.9 rupees=US$1 (since
February 1973)
Fiscal year: 1 July-30 June','c96c8592b09b7f9a3a001c2b37eeef5515475c7724f1476f673df87db5320d86','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dd47ec99ac5fb35ba51975a16c52ba0db8539d3704c98fb16844f6f80a73e35',1972,'PA','Panama','economy',359,'GNP: $2,215 million (1977), $1,250 per capita; 72%
private consumption, 15% government consumption, 21%
gross fixed investment, — 8% net foreign balance (1977); real
growth (1977), 1.6%
Agriculture: main crops—bananas, rice, corn, coffee,
sugarcane; self-sufficient in most basic foods; 2,450 calories
per day per capita (1969 )
Fishing: catch 171,641 metric tons (1976); exports $18.8
million (1974); imports $2.2 million (1974)
Major industries: food processing, metal products,
construction materials, petroleum products, clothing, furni-
ture
Electric power (including Canal Zone): 600,000 kW
capacity (1977); 2.5 billion kWh produced (1977), 1,410
kWh per capita
Exports: $253 million (f.o.b., 1977); bananas, petroleum
products, shrimp, sugar, meat, coffee
Imports: $862 million (c.i.f., 1977); manufactures, trans-
portation equipment, crude petroleum, chemicals, foodstuffs
Major trade partners: exports—45% U.S., 12% Canal
Zone, 9% West Germany, 7% Italy, 6% Netherlands;
imports—31% U.S:, 18% Ecuador, 8% Venezuela, 8% Colon
Free Zone, 5% Japan, 4% Saudi Arabia, 3% Trinidad and
Tobago (1976)
Aid: economic—(FY70-76) U.S., $284 million; . other
Western countries, $266 million; military—U.S., $7 million
16]
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
PANAMA/PAPUA NEW GUINEA
Budget: (1978) $538 million
Monetary conversion rate: 1 balboa=US$1 (official)
Fiscal year: calendar year','7a4a411637e98e773873c13926bf8cbe44709389ade60d9a94a75349f7ee72c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d744b4094e3230f52772d3dd7e2e8f6c22981963ffd8888b32b35f7223919871',1972,'PY','Paraguay','economy',363,'GDP: $2.1 billion (1977, at current prices), $750 per
capita; 7.0% public consumption; 74.8% private consump-
tion, 29.4% gross domestic investment, — 11.2% net foreign
balance (1977); real growth rate 1977, 11.8%
Agriculture: main crops—oilseeds, cotton, wheat, manioc,
sweet potatoes, tobacco, corn, rice, sugarcane; self-sufficient
in most foods; caloric intake, 2,580 caloriés per day per
capita (1963-64); protein intake, 70 grams per day per capita
(20 grams of animal origin)
Major industries: meat packing, oilseed crushing, milling,
brewing, textiles, light consumer goods, cement
Electric power: 230,000 kW capacity (1977); 550 million
kWh produced (1977), 200 kWh per capita
Exports: $278.9 million (f.o.b., 1977); cotton, oilseeds,
meat products, tobacco, timber, coffee, essential oils, tung oil
Imports: $255.4 million (f.0.b., 1977); fuels and lubricants,
machinery and motors;—motor—vehicles; beverages~—and:
tobacco, foodstuffs
Major trade partners: exports—15% Netherlands, 14%
United States, 18% Argentina, 10% West Germany; im-
ports—21% Brazil, 16% Argentina, 12% U.S., 9% West
Germany (1977)
Aid: (1970-76) economic bilateral commitments, U.S. $54
million, other Western countries $69 million; military
commitments, U.S. $17 million
Budget: (1977) $250 million current revenues, $190
million total expenditures including amortizations
Monetary conversion rate: 126 guaranies=US$1 (official
rate, December 1978)
Fiscal year: calendar year','8c6cce21872986841efa7e00c4380130910c8abb6ca05cb69c7adcd02ac6a41e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('092772b4b88602486f490f6b5ac032300e33e20d8e1453ac401ce77c796cc9f8',1972,'PE','Peru','economy',366,'GNP: $12.1 billion (1977, in current prices), $730 per
capita; 72.5% private consumption, 11.8% public consump-
tion, 20.1% gross investment; —4.4% net foreign balance
(1976); ‘real growth rate (1977), —1.24%
Agriculture: main crops—wheat, potatoes, beans, rice,
barley, coffee, cotton, sugarcane; imports—wheat, meat,
Jard and oils, rice, corn; caloric intake, 2,200 calories per day
per capita (1967)
Fishing: catch 2.5 million metric tons (1977); exports $215
million (1977)
’ Major industries: mining of metals, petroleum, fishing,
textiles and clothing, food processing, cement, auto assem-
bly, steel, ship-building, metal fabrication
Electric power: 2,073,000 kW capacity (1977); 8 billion
kWh produced (1977), 480 kWh per capita
Exports: $1,726 million (f.0.b., 1977); copper, fish and fish
products, copper, silver, iron, cotton, sugar, lead, zinc,
petroleum, coffee
Imports: $2,164 million (f.0.b., 1977); foodstuffs, machin-
ery, transport equipment, iron and steel semimanufactures,
chemicals, pharmaceuticals
Major trade partners: exports—24% U.S., 15% Latin
America, 21% EC, 14% Japan, 2% U.S.S.R. (1976); imports—
31% US., 28% EC, 17% Latin America, 12% Japan (1974)
Budget: (1977) $2.3 billion current revenues, $3.8 billion
total expenditures including debt amortization
Monetary conversion rate: 174 soles=US$1 (12 October
1978); floats against U.S. dollar
Fiscal year: calendar year','c5b3e96e04464277ae8188c1ee14a95304950d1a8b0f228d976b0596eafe2ee3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df1d948d097632554cd09950c4b4a7b0ce6e6ba72e7cfff86ba7bc1b23cb02d6',1972,'PL','Poland','economy',371,'GNP: $95.2 billion in 1977, at 1976 prices, $2,740 per
capita; 1977 growth rate, 5.1%
Agriculture: self-sufficient for minimum requirements;
main crops—grain, sugar beets, oilseeds, potatoes, exporter
of livestock products and sugar; importer of grains; 3,200
calories per day per capita (1970)
Fishing: catch 659,000 metric tons (1977)
Major industries: machine building, iron and _ steel,
extractive industries, chemicals, shipbuilding, and food
processing
Crude steel: 17.8 million metric tons produced (1977),
about 510 kg. per capita
Electric power: 21,749,000 kW capacity (1977); 109.4
billion kWh produced (1977), 3,150 kWh per capita
Exports: $12,405 million (f.o.b., 1977); 46% machinery
and equipment, 35% fuels, raw materials, and semimanufac-
tures, 10% agricultural and food products, 9% light industrial
products
Imports: $14,767 million (f.o.b., 1977); 41% siichiniery
and equipment; 41% fuels, raw materials, and semimanufac-
tures; 13% agricultural and food products; 5% light industrial
products
Major trade partners: $27,172 million (1977); 56% with
Communist countries, 44% with West
Monetary conversion rate: 3.32 zlotys=US$1 (commer-
cial); 33.20 zlotys=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data are
reported for calendar years except for caloric intake whichis
reported for the consumption year, 1 July-30 June','562181d88322564285d971f2b3f38972eebabfbe322ad4a18ada4f458fcdcd00','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e58e016f2d78a5c240a3dca00630bc280dd809c82e7705051430c07a81fd2d2',1972,'PT','Portugal','economy',374,'GNP: $14.8 billion est. (1977); 18% government consump-
tion, 84% private consumption; 10% gross fixed investment;
— 12% net exports; average annual real GNP growth 1970-
74, 8%; the Portuguese government puts the change in real
GNP at —2.7% in 1975 and 5.8% in 1976, but —7.0%-and
+3.3% appear more realistic; growth in real GNP in 1977
est. at 5.5%
Agriculture: generally underdeveloped; main crops—
grains, potatoes, olives, grapes for wine; deficit foods—sugar,
grain, meat, fish, oil seeds; caloric intake
Fishing: landed 339,191 metric tons (1976)
Major industries: textiles and footwear; wood pulp,
paper, and cork; metalworking; oil refining; chemicals; fish
canning; wine
Crude steel: 460,000 tons produced (1976), 50 kg per
capita
Electric power: 4,600,000 kW capacity (1977); 13.9
billion kWh produced (1977), 1,415 kWh per capita
Exports: $2.0 billion (f.0.b. 1977); principal items—cotton
textiles, cork and cork products, canned fish, wine, timber
and timber products, resin
Imports: $4.9 billion (f.0.b., 1977); principal items—
petroleum, cotton, industrial machinery, iron and steel,
chemicals
Major trade partners: 45% EC (12% U.K., 11% W.
Germany, 9% France, 4% Italy); 12% EFTA, 8% U.S., 4%
Spain, 3% Iraq, 3% Saudi Arabia, 3% Japan (1976)
Aid: economic authorizations: U.S:, $178 million
(FY70-76) ;
169
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
PORTUGAL/QATAR .
Budget: 1977—receipts, $2.7 billion; expenditures, $4.2
billion; deficit, $1.5 billion
Monetary conversion rate: ] escudo=US$0.0261 (average
1977)
Fiscal year: calendar year','9e0bd7e19f287bdc69eea7561dc33ea5c93761c2b66897d57721fddd55adf8ad','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6848231fdab20bb2258644d899be4c1d29d671b37c6c0d4e88f46029b9f6b815',1972,'RW','Rwanda','economy',380,'GDP: $603 million (1976 provisional), $140 per capita;
real average annual growth rate (1970-77), 5.5%
Agriculture: cash crops—mainly coffee, tea, some pyre-
thrum; main food crops—bananas, cassava; stock raising;
self-sufficiency declining; country imports foodstuffs
Major industries: mining of cassiterite (tin ore), wolfram
(tungsten ore), agricultural processing, and light consumer
goods
Electric power: 35,000 kW capacity (1977); 142 million
kWh produced (1977), 30 kWh per capita
Exports: $104 million (f.o.b., 1976); mainly coffee, tea,
cassiterite, wolfram, pyrethrum
Imports: $103.7 million (c.i.f., 1976); textiles, foodstuffs,
machines, equipment
Major trade partners: U.S., Belgium, West Germany,','90ab976e984c1356f6e34b1781b705e7f01b4d0dcca4d57fb16ad333752317c6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93cc31d3c270d552a84976daee593115445ae6f6ca18ac4bbb8d965eab960e75',1972,'AI','Anguilla','economy',384,'GDP: $30.4 million (at normal prices, 1976), $210 per
capita
Agriculture: main crops—sugar on St. Christopher, cotton
on Nevis
Major industries: sugar processing, salt extraction
Electric power: 15,000 kW capacity (1977); 32 million
kWh produced (1977), 460 kWh per capita
Exports: $17.8 million (f.o.b., 1975); sugar, molasses,
cotton, salt, copra
Imports: $19.5 million (ci-f., 1975); foodstuffs, fuel;
manufactures :
Major trade partners: exports—50% U.S., 35% U.K.;
imports—21% U.K., 17% Japan, 11% U.S. (1973)
Aid: economic—bilateral commitments including Ex-Im
(FY70-76) from Western (non-U.S.) countries, $64.6 million;
no military aid
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)
GNP: $57 million (in market prices, 1976)
Agriculture: main crops—bananas, copra, sugar, cocoa,
spices :
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 14,000 kW capacity (1977); 40 million
kWh produced (1977), 365 kWh per capita
Exports: $17 million (f.o.b., 1976); sugar, bananas, cocoa
Imports: $47 million (c.i.f., 1976); foodstuffs, machinery
and equipment, fertilizers, petroleum products
Aid: economic—bilateral commitments including Ex-Im
(FY70-76), from Western (non-U.S.) countries, $16.7 million;
no military aid
Major trade partners: 51% U.K., 9% Canada, 17% U.S.
(1970)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)
GNP: $335 million (at market prices, 1976)
Agriculture: main crops—bananas, arrowroot, coconut
Major industries: food processing
Electric power: 6,500 kW capacity (1977); 18 million
kWh produced (1977), 190 kWh per capita
Exports: $9.3 million (f.o.b., 1976); bananas, arrowroot,
copra
Imports: $23.7 million (c.i.f., 1976); fertilizer, flour,
transportation equipment, lumber, textiles ;
Major trade partners: exports—61% U.K., 30% CARI-
COM, 9% U.S.; imports—29% CARICOM, 28% U.K., 9%
Canada, 9% U.S. (1972)
Aid: economic—bilateral economic commitments includ-
ing Ex-Im (FY 70-76), from Western (non-U.S.) countries, -
$46.2 million; no military aid
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)','078f53733c29402b4982e1773772854af72d315c072d3843951d806ea72930fb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c397c287347dbd943bbbecb909db1ba74217058ff0ff31f24cbc1d3f0feaac1',1972,'SM','San Marino','economy',388,'. Principal economic activities of San Marino are farming,
livestock raising, light manufacturing, and tourism; the
largest share of government revenue is derived from the sale
of postage stamps throughout the world and from payments
by the Italian government in exchange for Italy’s:monopoly
_in retailing tobacco, gasoline, and a few other goods; main
problem is finding additional funds to finance badly needed
'' water and electric power systems expansions
Agriculture: principal crops are wheat (average annual
output about 4,400 metric tons/year) and grapes (average
annual output about 700 metric tons/year); other grains,
fruits, vegetables, and animal feedstuffs are also grown;
- livestock population numbers roughly 6,000 cows, oxen, and
sheep; cheese and hides are most important livestock
products ,
Electric power: imported from Italy
Manufacturing: consists mainly of cotton textile produc-
tion at Serravalle, brick and tile production at Dogane,
‘cement production at Acquaviva, Dogane, and Fiorentino,
and pottery production at Borgo Maggiore; some tanned
hides, paper, candy, baked goods, Moscato wine, and gold
and silver souvenirs are also produced ©
Foreign transactions: dominated by tourism; in summer
months 20,000 to 30,000 foreigners visit San Marino every
“179
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SAN MARINO/SAO TOME AND PRINCIPE
day; a number of hotels and restaurants have been built in
recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign
inflow; commodity trade consists primarily of exchanging
building stone, lime, wood, chestnuts, wheat, wine, baked
goods, hides, and ceramics for a wide variety of consumer
manufactures :','276fe25310ab1d210cc4fa79f32948837ef94c5c2e632dce4f97f7356e8530d8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08c25f17db798de783eb1a517ca76ec9afeee11d304d78bf2bec962c229a6f9c',1972,'SC','Seychelles','economy',392,'GDP: $43.1 million (1976); $710 per capita; 4.6% growth
rate (1974)
Agriculture: islands depend largely on coconut production
and export of copra; cinnamon, vanilla, and patchouli (used
for perfumes) are other cash crops; food crops—small
quantities of sweet potatoes, cassava, sugarcane, and
bananas; islands not self-sufficient in foodstuffs and the bulk
of the supply must be imported; fish is an important food
source :
Major industries: processing of coconut and vanilla,
fishing, small-scale manufacture of consumer goods, coir
rope factory, tea factory, tourism
Electric power: 11,000 kW capacity (1977); 25 million
kWh produced (1977), 410 kWh per capita
Exports: $8.7 million (f.0.b., 1977); cinnamon (bark and
oil) and vanilla account for almost 50% of the total, copra
accounts for about 40%, the remainder consisting of
patchouli, fish; and guano :
Imports: $37.1 million (c.if., 1977); food, tobacco, and
beverages account for about 40% of imports, manufactured
goods about 25%, machinery and transport equipment,
petroleum products, textiles
Major trade parterns: exports—India, U.S.; imports—
U.K., Kenya, South Africa, Burma, India, Australia -
Aid: economic—(1970-76) Western (non-U.S.) countries,
$72.4 million; US., $0.6 million
184
Budget: (1978) revenue $24 million, expenditure $15
million
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year','34821d6efb9dadcee1027f305d5851a11ae7f5a7e4ed11314c85106330339d92','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63e40b98f4e65e94c5420844852ad6ba184df3ff7951753d90373a8b43d9ab8a',1972,'SL','Sierra Leone','economy',396,'GDP: $657 million (mid 1977), $230 per capita; growth
rate 1.8% (mid-1971 to mid-1975)
Agriculture: main crops—palm kernels, coffee, cocoa,.
rice, yams, millet, ginger, cassava; much of cultivated land
devoted to subsistence farming; food crops insufficient for
domestic consumption
Fishing: catch 67,797 metric tons (1975); imports $2.7
million (1974)
Major industries: mining—diamonds, iron ore, bauxite,
rutile; manufacturing—beverages, textiles, cigarettes, con-
struction goods; 1 oil refinery .
Electric power: 85,000 kW capacity (1977); 264 million
kWh produced (1977), 90 kWh per capita
Exports: $118 million (f.0.b., 1977); diamonds, iron ore,
palm kernels, cocoa, coffee
Imports: $150 million (f.0.b., 1977); machinery and
transportation equipment, manufactured goods, foodstuffs,
petroleum products
Major trade partners: U.K., EC, U.S., Japan, Communist
countries ; a
Budget: (FY77 est.) current revenues $102 million, total
expenditures $145 million oh,
Monetary conversion: rate: 1 leone=US$0:95 (1978)
Fiscal year: 1 July-30 June','596e418a27a2dc85b963758875b481a7bae2b39504c4921dbb5ec0928a949599','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47ea8c7a3a305360ade55ccb3a9729024ec3cc5e55c9939e1e43b6d11b33244d',1972,'SB','Solomon Islands','economy',402,'’ GDP: $64.1 million (1976) a
Agriculture: largely dominated by coconut production
with subsistence crops of yams, taro, bananas; self-sufficient
in rice :
Electric power: 10,000 kW capacity (1977); 22 million
kWh produced (1977), 105 kWh. per capita
Exports: $15.5 million (1975); 39% copra, 27% timber,
23% fish
Imports: $29.2 million (1975)
Major trade partners: exports—EEC excluding U.K. 42%,
Japan 29%; imports—Australia 34%, U.K. 14%, Japan 13%
(1975)
Budget: (1971) revenues $9.8 million, expenditures $9.9
million :
Monetary conversion rate: 1 Australian dol-
lar=US$1.1532 (September 1978) ''','89b748bfc4d79e319f1f31d08a915dca2e7f2decd9fcff0bf615ce224eb7634c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8ea9c0f8d6dd83530d0a0068ed66c657ed007511cc6feb75878a9e2f865ab13',1972,'SO','Somalia','economy',406,'GDP: $340 million (1975 est.), $110 per capita
Agriculture: mainly a pastoral country, raising livestock;
crops—bananas, sugarcane, cotton, cereals
Major industries: a few small industries, including a sugar
refinery, tuna and beef canneries, textiles,” iron rod plant,
and petroleum refining
Electric power: 18,000 kW capacity (1977); 45 million
kWh produced (1977), 10 kWh per capita
Exports: $84 million (f.0.b., 1977); livestock, hides, skins,
and bananas _
Imports: $201 million (f.0.b., 1977); textiles, cereals,
transport equipment, machinery, construction materials and
equipment, petroleum products; also: military materiel in
1977
Major trade partners: Arab countries and Italy; $21.4
million imports from Communist countries (1975. est.)
Monetary conversion rate: 6.295 Somali shillings=US$1
Fiscal year: 1 January-31 December','21a7edc6a267f342d313e55451fad8e8a77db636d861f3c2adb8c67303c0903e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6917aa40c4c2348d400d1e0e801f3513b841ad2e0cdf0364838088ea938841d',1972,'ZA','South Africa','economy',407,'GDP: $38.9 billion (1977), about $1,450 per capita; real
growth rate 0.5% (1977)
Agriculture: main crops—corn, wool, wheat, sugarcane,
tobacco, citrus fruits; dairy products; self-sufficient in
foodstuffs
Fishing: catch 638,035 metric tons (1976)
Major industries: mining, automobile assembly, metal-
working, machinery, textiles, iron and steel, chemical,
fertilizer, fishing
189
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a''s
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
Electric power: 15,272,800 kW capacity (1977); 87 billion
kWh produced (1977), 3,240 kWh per capita
Exports: $10.0 billion (f.o.b., 1977, excluding gold); wool,
diamonds, corn, uranium, sugar, fruit, hides, skins, metals,
metallic ores, asbestos, fish products; gold output $3.2 billion
(1977)
Imports: $6.3 billion (c.if., 1977); motor vehicles,
machinery, metals, petroleum products, textiles, chemicals
Major trade partners: U.S., West Germany, Japan, U.K.
Aid: no military or economic aid
Budget: FY79—revenue $8.8 billion, expenditures $10.3
billion
Monetary conversion rate: 1 SA Rand=US$1.15, 0.87 SA
Rand=US$1''
Fiscal year: 1 April-31 March
GDP: estimated at $150 million, $86 per capita
Agriculture: cash crops—tea, phormium tenax, small
amount of coffee; food crops—corn, sorghum, dry beans;
imports over half its foodstuffs from South Africa; two-thirds
of Transkei devoted to grazing—1.2 million cattle, 2.5
million sheep, 1.3 million goats
Major industries: forestry, textiles, tourism
Exports: timber, labor to South Africa, tea, sacks
Imports: foodstuffs, machines, equipment
Major trade partners: South Africa
Aid: South Africa, almost $500 million since 1970
Budget: $156 million (1976-77), about 70% of which is
provided by the South African government
Monetary conversion rate: 1 South African Rand=
US$1.15
Fiscal year: 1 April-31 March','d12cedf4fbc874ce4fc628fcf12934e7620e9a403409df3dbfb90d8bed6ac0b6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3733eae26e6ce590f1cbefd4a8db79c1ff47584ab1424fbc80e605303fb6cfd3',1972,'ES','Spain','economy',409,'GNP: $116 billion (1977), $3,190 per capita; 69.7% private
consumption, 10.2% public consumption, 22.5% gross fixed
investment; — 2.4% foreign balance (1976); real growth rate
2.4% (1977)
Agriculture: main crops—cereals, oranges, grapes for
wine, potatoes, olives, sugar beets; virtually self-sufficient in
good crop years; caloric intake, 2,750 calories per day per
capita (1969-70) , ;
Fishing: landed 1.48 million metric tons valued at $1,152
million in 1976
Major industries: food processing, textiles and apparel
(including footwear), metal manufacturing, chemicals, ship-
building, automobiles
Shortages: crude petroleum, natural gas
Crude steel: 11.1 million metric tons produced (1977),
300 kg per capita ,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ee a ee Oe, ee ee ee ee ee ee eee ee ee, |,
Ri Mr tit te i a a ee a a ot Ree ii ol i i eh il Sn Lee all
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SPAIN/SRI LANKA
Electric power: 29,100,000 kW capacity (1977); 93.7
billion kWh produced (1977), 2,565 kWh per capita
Exports: $10,208 million (f.0.b., 1977); principal items—
oranges and other fruits, iron and steel products, textiles,
wines, mercury, ships, canned fruits, vegetables, and
footwear .
Imports: $17,779 million (c.i.f., 1977); principal items—
machinery and transportation equipment, petroleum and
petroleum products, grains, cotton, iron and steel
Major trade partners: (1977) 11.3% U.S., 11.2% France,
10.2% West Germany, 5.7% U.K:, 38.7% EC, 60.6% OECD,
6.8% Latin America, 3.6% Communist countries _
Aid: economic authorizations—U.S., $1,246 million author-
ized (FY70-77); other Western bilateral (ODA and OOF),
$448 million (1970-76); military authorizations—U.S., $375
million (FY70-77)
Budget: (1978 central government)—budgeted revenues
$17,846 billion, budgeted expenditures $17,846 billion
Monetary conversion rate: 1 peseta=US$0.0124 (1977
average)
Fiscal year: calendar year','05402b0f3d254aa2770a673d4f76364ea61e6ab2be5801e05b49edfb8d77cfc1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af65287226e8034e0ed656ee190b35d182a072b18a3d93ffece3ae9a2c012faf',1972,'LK','Sri Lanka','economy',414,'GNP: $3.2 billion in 1977 (1977 prices), $220 per capita;
real growth rate 4.4% (1977), 3.0% (1976) . .
Agriculture: agriculture accounts for about 39% of GNP;
main crops—rice, rubber, tea, coconuts; 60% self-sufficient
in food; food shortages—rice, wheat, sugar
Fishing: catch 138,528 metric tons (1977)
Major industries: processing of rubber, tea, and other
agricultural commodities; consumer goods manufacture
Electric power: 430,000 kW capacity (1977); 1.4 billion
kWh produced (1977), 100 kWh per capita
Exports: $754 million (1977); tea, rubber, coconut
products :
Imports: $696 million (1977); food, petroleum, fertilizer
Major trade partners: (1977) exports—8% Pakistan, 8%
U.K.; imports—12.4% Saudi Arabia, 9.8% Iran
Budget: (1978) revenue $730 million, expenditure $1,061
million
Monetary conversion rate: 15.6 rupees=US$1 (July 1978)
Fiscal year: 1 January-31 December (starting 1973)','986491d5da5f7e642b2dad11b4894a013321631efeb1b25600c508a761017551','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46d2c71ed4ade498eb73690b3f39ed46f03d2af56f71cbbeb0c9272bf1da31c8',1972,'SD','Sudan','economy',418,'GDP: $4.3 billion at current prices (1977), $230 per capita
at current prices
Agriculture: main crops—sorghum, millet, wheat, sesame,
peanuts, beans, barley; not self-sufficient in food production;
main cash crops—cotton, gum arabic, peanuts, sesame
Major industries: cotton ginning, textiles, brewery,
cement, edible oils, soap, distilling, shoes, pharmaceuticals
Electric power: 231,800 kW capacity (1977); 672 million
kWh produced (1977), 40 kWh per capita
Exports: $660 million (f.o.b., 1977); cotton (51%), gum
arabic, peanuts, sesame; $57.5 million exports to Communist
countries (FY76)
Imports: $1.058 billion (c.i.f., 1977); textiles, petroleum
products, vehicles, tea, wheat; $75 million imports from
Communist countries (FY76)
Major trade partners: U.K., West Germany, Italy, India,
China, France, Japan
Monetary conversion rate: 1 Sudanese pound=US$2.87
(official); 0.348. Sudanese pound=US$1
Fiscal year: 1 July-30 June
195
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SUDAN/SURINAME','c889384213207941ac1fe93da8a2039406388ef7b6aac9390fa3d2f319ea3872','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a65380e3119de704f2ebb640e6df1e63f5fd160ea1a9e356e330ef27b2cdd53c',1972,'SE','Sweden','economy',422,'GDP: $78.5 billion, $9,530 per capita (1977); 53.8%
consumption, 20.3% investment, 28.7% government; —0.4%
inventory change; — 2.4% net imports of goods and services;
1977 growth rate —2.5% in constant prices
Agriculture: animal husbandry predominates with milk
and dairy products accounting for 40% of farm income;
main crops—grains, sugar beets, potatoes; 80% self-suffi-
cient; food shortages—oils and fats, tropical products; caloric
intake, 2,903 calories per day per capita (1975)
Fishing: catch 173,700 metric tons (1977), exports $36
million, imports $169 million
Major industries: iron and steel, precision equipment
(bearings, radio and telephone parts, armaments), shipbuild-
ing, wood pulp and paper products, processed foods, textiles,
chemicals
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 4.0 million metric tons produced (1977), 490
kg per capita
Electric power: 25,000,000 kW capacity (1977); 91.0
billion kWh produced (1977), 11,025 kWh per capita
Exports: $18,839 million (f.0.b., 1977); machinery, motor
vehicles and ships, wood pulp, paper products, iron and steel
products, metal ores and scrap, chemicals
Imports: $20,022 million (c.i-f., 1977); machinery, motor
vehicles, petroleum and petroleum products, textile yarn
and fabrics, iron and steel, chemicals, food, and live animals
Major trade partners: (1977) 15% West Germany, 11%
U.K., 6% U.S., 9% Norway, 8% Denmark; 49% EC-9; 6%
U.S.S.R. and Eastern Europe
Aid: donor: economic aid authorized (ODA and OOF),
$1,978 million (1970-76)
Budget: (1976/77) revenues $22.7 billion, expenditures
$23.8 billion
Monetary conversion rate: 4.4816 kroner=US$1 average
exchange rate 1977
Fiscal year: 1 July-30 June','5b471c99fd161fb25a8e17e5df4206ce1d43e48732bd1910f2c2495d69dc7c79','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('656a412c552841902555189b22036a17f3fbafeb7939fab005866135fafc1f93',1972,'CH','Switzerland','economy',426,'GNP: $63.37 billion (1977 at 1977 prices), $9,870 per
capita; 60.4% consumption, 20.3% investment, 12.8% gov-
ernment, net foreign balance 6.5% (1977); 1970-76 average
growth rate 1.8%, constant prices
Agriculture: dairy farming predominates; less than 50%
self-sufficient; food shortages—fish, refined sugar, fats and
oils (other than butter), grains, eggs, fruits, vegetables, meat;
caloric intake, 3,190 calories per day per capita (1969-70)
Major industries: machinery, chemicals, watches, textiles,
precision instruments
- Shortages: practically ail important raw materials except
hydroelectric energy
Electric power: 12,000,000 kW capacity (1977); 44.7
billion kWh produced (1977), 7,090 kWh per capita
Exports: $17.54 billion (f.o.b., 1977); principal items—
machinery and equipment, chemicals, precision instruments,
metal products, textiles, foodstuffs
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SWITZERLAND/SYRIA
Imports: $17.90 billion (c.if., 1977); principal items—
machinery and transportation equipment, metals and metal
products, foodstuffs, chemicals, textile fibers and yarns
Major trade partners: 56% EC (22% West Germany, 11%
France, 9% Italy, 7% U.K.); 9% EFTA (5% Austria); 7% U.S.;
5% Communist countries (1977)
Aid: donor: bilateral economic aid authorized (ODA and
OOF), $321 million (1970-76)
Budget: receipts, $5,836 million, expenditures, $6,446
million, deficit, $610 million (1977)
Monetary conversion rate: 2.4035 Swiss francs=US$1
(average 1977, floating)
Fiscal year: calendar year
GDP: $5.9 billion (1976), $780 per capita; real GDP
growth rate 8%, 1976
Agriculture: main crops—cotton, wheat, barley and
tobacco; sheep and goat raising; self-sufficient in most foods
in years of good weather
Major industries: textiles, food processing, beverages,
tobacco; petroleum (180,000 b/d production (1977), 117,000
b/d refining capacity)
Electric power: 1,700,000 kW capacity (1977); 2.5 billion
kWh produced (1977), 310 kWh per capita
Exports: $1.1 billion projected (f.0.b., 1977); petroleum,
textiles and textile products, tobacco, fruits and vegetables,
cotton ,
Imports: $2.6 billion (c.i.f., 1977); machinery and metal
products, textiles, fuels, foodstuffs
Major trade partners: exports—Italy, West Germany,
U.S.S.R., Yugoslovia; imports—Switzerland, West Germany,
Italy, Saudi Arabia
Budget: 1978 official plan—revenues $4.6 billion (includ-
ing Arab aid payments), expenditures $4.6 billion
Monetary conversion rate: 3.95 Syrian pounds=US$1
Fiscal year: calendar year
Mainland:
GDP: $2.8 billion (1977), about $170 per capita; real
average annual growth rate, 4.2% (1970-77)
Agriculture: main crops—cotton, coffee, sisal. on mainland
Fishing: catch 180,746 metric tons (1975); exports valued
at $638,000, imports $1.1 million (1975)
Major industries: primarily agricultural processing
(sugar, beer, cigarettes, sisal twine), diamond mine, oil
refinery, shoes, cement, textiles, wood products
Electric power: 365,000 kW capacity (1977); 1,278
million kWh produced (1977), 80 kWh per capita
Exports: $168 million (f.0.b., 1978 projected); coffee,
cotton, sisal, cashew nuts, meat, diamonds, cloves, tobacco,
tea
Imports: $574 million (c.if., 1978 projected); manufac-
tured goods, machinery and transport equipment, cotton
piece goods, crude oil, foodstuffs
Major trade partners: exports—China, U.K., Hong Kong,
India, U.S.; imports—U.K., China, West Germany, U.S.,
Japan .
Budget: (1977 est.) receipts including grants, $872 million,
expenditures, $833 million; recurrent and development
expenditure $1,014 million
Monetary conversion rate: 7.96 Tanzanian _ shil-
lings=US$1
Fiscal year: 1 July-30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops—cloves, coconuts
Industries: agricultural processing
Electric power: see Tanzania (above)
Exports: $504 million (f.0.b., .1977); cloves and clove
products, coconut products
Imports: $723 million (c.i.f., 1977); mainly foodstuffs and
consumer goods
Major trade partners: imports—China, Japan, and
mainland Tanzania; exports—Singapore, China, Hong Kong,
Indonesia, India, Pakistan ; ;
Aid: U.K. principal source of aid until 1964; U.S. $86
million FY58-73; China is currently major source
Exchange rate: 7.96 Tanzanian shillings=US$1
Fiscal year: 1 July-30 June
203
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TANZANIA/THAILAND','cb4882dc236d5b57d0d245a140200ee2c85f9d33acc84932ac50b9af0a77648c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a31d234ccd001eb89d27a64b76915e9064705d79a047d8adc30d0b53c4317123',1972,'TH','Thailand','economy',430,'GNP: $18.1 billion (1977), $410 per capita; 5.8% real
growth in 1977 (6.6% real growth, 1973-77)
Agriculture: main crops—rice, sugar, corn, rubber,
tapioca
Fishing: catch 1.6 million metric tons (1976); major
fishery export, shrimp, 15,218 metric tons, about $66
million, total marine export, about $118 million (1976)
Major industries: agricultural] processing, textiles, wood
and wood products, cement, tin and tungsten ore mining;
world’s second largest tungsten producer and third largest tin
producer
Shortages: fuel] sources, including coal, petroleum; scrap
iron, and fertilizer :
Electric power: 2,904,000 kW capacity (1977); 11.3
billion kWh produced (1977), 255 kWh per capita
Exports: $3.6 billion (f.o.b., 1977); rice, sugar, corn,
rubber, tin, tapioca, kenaf-
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Da nc et a i a et i ae en i, a
eS ae
eT ON OE OE Ere
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
THAILAND/TOGO
Imports: $4.6 billion (c.if., 1977); machinery and
transport equipment, fuels and lubricants, base metals,
chemicals, and fertilizer ;
Major trade partners: exports—Japan, U.S., Singapore,
Netherlands, Hong Kong, Malaysia; imports—Japan, U.S.,
West Germany, U.K.; about 1% or less trade with
Communist countries
Budget: (FY79) planned receipts $4,509 million; 20.6%
military, 79.4% civilian
Monetary conversion rate: 20.2 baht=US$1 (September
1978)
Fiscal year: 1 October-30 September
GNP: $7.3 billion (1977), approximately $140 per capita;
real growth less than 5% annually ,
222
Agriculture: main crops—rice, rubber, fruits and vegeta-
bles, mainly in the south; some corn, manioc,-and sugarcane;
major food imports—wheat, dairy products
Fishing: catch 1,013,500 metric tons (1976), of which
600,000 metric tons sea
Major industries: food processing, textiles, machine
building, mining, cement, chemical fertilizer, glass, tires
Shortages: foodgrains, petroleum, capital goods and
’ machinery, fertilizer
Electric power: 1,392,700 kW capacity (1977); 3.4 billion
kWh produced (1977), 70 kWh per capita
Exports: $300 million (1977); agricultural and handicraft
products, coal, minerals, ores
Imports: $900 million (1977); petroleum, steel products,
railroad equipment, chemicals, medicines, raw cotton,
’ fertilizer, grain
Major trade partners: exports—U.S.S.R., East European
countries, Japan, other Asian markets; imports—U.S.S.R.,
’ East Europe, China, Japan
Aid: accurate data on aid since April 1975 unification
. unavailable; estimated annual commitments of economic aid
are—U.S.S.R., $500 million; East European countries, $150
million; China, $300 million; non-Communist countries,
$230 million; international institutions, $75 million; military
aid deliveries since end of war in April 1975 are minimal
Monetary conversion rate (official): 2.19 dong=US$1
Fiscal year: calendar year','0c2439855e4264c5521dc85c2075ac314b27c2bc7a7983270f5703e085f51b51','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b41bd98beeebe4ad762d9d44971e7ca3b99abce5f04b4daa41482a5d27bf71bb',1972,'TG','Togo','economy',434,'GDP: $780 million (1978 est.), about $300 per capita;
estimated real growth 1970-77, 2.2%
Agriculture: main cash crops—coffee, cocoa, cotton;
major food crops—yams, cassava, corn, beans, rice, millet,
some
sorghum, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural process-
ing, handicrafts, textiles, beverages
‘Electric power: 30,000 kW capacity (1977); 110 million
kWh produced (1977), 50° kWh per capita
Exports: $202 million (f.0.b., 1977); phosphates, cocoa,
coffee, palm kernels, and cassava
Imports: $298 million (c.i.f., 1977); consumer goods, fuels,
machinery, -tobacco, foodstuffs
Major trade partners: mostly with France and other EC’
countries
Budget: (1978 proposed), revenues and expenditures,
$247 million :
Monetary conversion rate: Communaute Financiere
Africaine 245.67 francs=US$1 (1977)
Fiscal year: calendar year','5946d9a5872c474e994610e0c9e3ee0a526ec2257d5feaa0098c4e61c8ee35f1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22cdb68af6f995995fea0f168bc191d6596084e50da53e4cf397a1485a3424b5',1972,'TO','Tonga','economy',438,'GNP: $39 -million (1975), $400 per capita
Agriculture: largely dominated by coconut and banana
production with subsistence crops of taro, yams, sweet
potatoes, and bread fruit
Electric power: 4,000 kW capacity (1977); 8 million kWh
produced (1977), 70 kWh per capita
Exports: $10 million (f.0.b., 1975); 65% copra, 7% coconut
: products, 8% bananas
Imports: $28 million (c.i.f., 1975); food, machinery, and
petroleum
Major trade partners: (FY74) exports—25% Netherlands,
22% Australia, 20% New Zealand, 11% Norway; imports—
63% New Zealand and Australia
Budget: (FY76) revenues $6.7 million, expenditures $8.3
million :
Monetary conversion rate: 1 Tonga dollar=US$1.40
(1976)
Fiscal year: 1 July-30 June','ca4368d3d3192a67c471d810e21d0ee5628c0d078659bac0c8d092f20ee2c59a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f2e93aadc94ccd16682c5f4d5cd887f341edfabb00a5f7317b6703e2d6894d3',1972,'TT','Trinidad and Tobago','economy',442,'GDP: $3,159 million (1977), $3,040 per capita; 49%
mining and petroleum, 6% manufacturing, 4% agriculture,
41% other; growth rate 1977, 7.7% est.
Agriculture: main crops—sugarcane, cocoa, coffee, rice,
’ citrus, bananas; largely dependent upon imports of food
Fishing: catch 4,322 metric tons (1976); exports $1.1
million (1975), imports $4.5 million (1975)
Major industries: petroleum, tourism, food processing,
cement _ ; ; ,
Electric power: 375,000 kW capacity (1977); 1.6 billion
kWh produced (1977), 1,540 kWh per capita
_Exports: $2.2 billion (f.0.b., 1977); petroleum and
petroleum products (91%), sugar, cocoa (2.0%)
‘Imports: $1.9 billion (c.i.f., 1977); crude petroleum (46%),
machinery, fabricated metals, transportation equipment,
manufactured goods, food
Major trade partners: imports—Saudi Arabia 24%, U.S.
21%, Indonesia 10%, U.K. 10%, Iran 9%, Japan 4%; exports—
U.S. 72%, U.K. 2%, Netherlands 2%
208 °
Aid: economic—bilateral commitments including Ex-Im
(1970-76), U.S., $50.6 million; other Western countries,
$23.8 million
Budget: (1977) central government revenues $1 billion,
expenditures $1 billion (current $487 million, investment
$156 million, development project funds, $371 million)
Monetary conversion rate: tied to US dollar in 1976;
TT$2.40=US$1
Fiscal year: calendar year','49d9e18e999a5eb7b2c1cb2971e33184d1c7ba04bc58d9793b8735e339f419b8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c0f1ce29a2dfe25431e44b2c6cb1825fe9e06487b56fb093694281a6ad53ef4',1972,'TN','Tunisia','economy',446,'GDP: $5.7 billion (1978 est.), $930 per capita; average
annual growth (1973-76), 7.2%
Agriculture: cereal farming and livestock herding pre-
dominate; main crops—wheat, barley, olives, fruits (espe-
cially citrus), viticulture, vegetables, dates
Major sectors: tourism, mining, food processing, textiles
and leather, light manufacturing, construction materials,
chemical fertilizers, petroleum
Electric power: 540,000 kW capacity (1977); 1.7 billion
kWh produced (1977), 270 kWh per capita
Exports: $1.1 billion (f.o.b., 1978); 25% petroleum, 20%
phosphates, 18% olive oil
Imports: $2.1 billion (c.i.f., 1978); 36% raw materials, 23%
machinery and equipment, 14% consumer goods, 19% food
and beverages, 3% energy, 5% other .
Major trade partners: exports—France, Italy, West','a8421010d10c2df6938bfa20194496dd6127bf071e2f22a6881c41128d3fb903','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed46b01f05d9634da96fdd0c2b14bd56352eea78a363f8c2aeed56582eec37ce',1972,'UG','Uganda','economy',453,'GDP: $886 million (1976, at constant prices), $70 per
capita; 0% real growth between 1970-74
‘Agriculture: main cash crops—coffee, cotton; other cash
’ crops—tobacco, tea, sugar, fish, livestock
Fishing: catch 152,400 metric tons (1976)
Major industries: agricultural processing (textiles, sugar,
coffee, plywood, beer), cement, copper smelter, corrugated
iron sheet, shoes, fertilizer
Electric power: 228,500 kW capacity (1977); 1,028
million kWh produced (1977), 80 kWh per capita
. Exports: $339 million (f.o.b., 1976); coffee, cotton, tea,
copper (1971)
Imports: $249 million (c.i.f., 1976); petroleum products,
machinery, cotton piece goods, metals, transport equipment
Major trade partners: U.K., U.S., Kenya
Monetary conversion rate: 7.95 Uganda shillings=US$1
Fiscal year: 1 July-30 June
- GNP: $1,034.3 billion (197, in 1977 U. S. prices), $3,990
per capita; in 1977 percentage shares were—57% consump-
tion, 29% investment, 14% government and other, including
defense (based on 1970 GNP in rubles at adjusted factor
cost); average annual growth rate of real GNP (1971-77),
3.8%, average annual growth rate (1976-77), 3.8%
Agriculture: principal food crops—grain (especially
wheat), potatoes; main industrial crops—sugar, cotton,
sunflowers, and flax; degree of self-sufficiency depends.on
fluctuations in crop yields; calorie intake, 3,250 calories per
day per capita in recent: years
Fishing: catch 9.7 million metric tons (1977); exports
403,800 metric tons (1977), imports 32,500 metric tons
(1977)
. Major industries: diversified, highly developed capital
goods industries; consumer goods industries comparatively
less developed :
Shortages: natural rubber, bauxite and alumina, tantalum,
tin, tungsten, fluorspar, and molybdenum
Crude steel: 160 million metric ton capacity as of 1
January 1978; 147 million metric tons produced in 1977, 570
kg per capita
Electric power: 239,800,000 kW capacity (1977); 1,152
billion kWh produced (1977), 4,440 kWh per capita
213
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
U.S.S.R./;UNITED ARAB EMIRATES
Exports: $45,228.6 million (f.0.b., 1977); fuels (particu-
larly petroleum and derivatives), metals, agricultural prod-
ucts (timber, grain), and a wide variety of manufactured
goods (primarily capital goods)
Imports: $40,931.9 million (f.0.b., 1977); specialized and
complex machinery and equipment, textile fibers, consumer
manufactures, steel products (particularly large diameter
pipe), and any significant shortages in domestic production
(for example, grain imported following poor domestic
harvests)
Major trade partners: $86.2 billion (1977 total turnover);
trade 57% with Communist countries, 30% with industrial-
ized West, and 13% with less developed countries
Aid: economic—to less developed countries (total ex-
tended 1977) $392 million; recipients included India $340
million; Jamaica, $30 million; Tanzania, $19 million;
economic extensions, $12.9 ‘billion (1954-77); military—
(total extended 1977) $4.0 billion; principal recipients were
Syria, $0.9 billion; Algeria, $0.8 billion; Ethiopia, $0.7
billion; India, $0.6 billion; Libya, $0.5, billion; military
extensions, $26 billion (1955-77)
Official monetary conversion rate: 0.6641 rubles=US$1:
(September 1978)
Fiscal year: calendar year','1550c290ae85914650695dcaad409fe670257214546f5ccd987775844e9709c6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d09902671862557c67737b1beced4d858675621717e5e7b7c74fcffc5983c3ad',1972,'AE','United Arab Emirates','economy',457,'GNP: $11.9 billion est. (1977), $18,140 per capita;
Agriculture: food imported, but some dates, alfalfa,
vegetables, fruit, tobacco raised
Electric power: 1,100,000 kW capacity (1977); 2.2 billion
kWh produced (1977), 2,355 kWh per capita
Exports: $9.5 billion (f.0.b., 1977); ($9.1 billion in oil, $0.4
billion non-oil); crude petroleum, pearls, fish
Imports: $4.5 billion (c.i.f., 1977); food, consumer and
capital goods
Major trade partners: U.K., U.S., Japan, India, EC
Aid: 1974-75 foreign aid totaled $1 billion; the 1975-76
budget committed $875 million to direct foreign aid; Abu
Dhabi Fund for Arab Economic and Social Development in
1975 lent $175 million to LDC’s
Budget: total budget (1977), $2.6 billion
Monetary conversion rate: 1 U.A.E. Dirham=US$0.25
Fiscal year: calendar year','fb410ccda8da3ee33e5767958aa4787e3ac91cc08050da6ff7e92c3b413991c2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e096b37eae4d204209e01cf4fee178f0e11c715491d9cdde5e0833cd68d79630',1972,'GB','United Kingdom','economy',461,'GNP: $243.9 billion (1977 est. in 1977 prices), $4, 360 per
capita; 59.8% consumption, 18.1% investment, 21.4% gov-
ernment; 0.5% inventories, 0.2% net foreign balance, real
‘growth 0.07% (1977)
'' Agriculture: mixed farming predominates; main prod-
‘ucts—wheat, barley, potatoes, sugar beets, livestock, dairy
products; 52.2% self-sufficient; food shortages—meat, fruits,
vegetables, cereals, dairy products; caloric intake, 2,910
‘ calories per day per capita, 1975
Fishing: catch 1.06 million metric tons (1976), valued at
$332 million; 1976 exports $146.2 million, mapetts $492.5
million
Major industries: machinery and transport equipment,
metals, food processing, paper and paper products, textiles,
chemicals, clothing
216
Shortages: rubber, timber and woodpulp, textile fibers,
nonferrous metals, foodstuffs
Crude steel: 20.4 million metric tons produced (1977);
28.1 million metric tons capacity (1975), 360 kg per capita
Electric power: 83,800,000 kW capacity (1977); 283.5
billion kWh produced (1977), 5,070 kWh per capita
Exports: $58.2 billion (f.o.b., 1977); machinery, transport
equipment, chemicals, metals, nonmetallic mineral manu-
factures, textiles, beverages
Imports: $64.6 billion (f.0.b., 1977); foodstuffs, petroleum,
machinery, crude materials, chemicals, nonferrous metals
Major trade partners: 37.5% EC, 13.4% Commonwealth,
9.7% U.S., 4.2% Ireland, 3.9% Switzerland
Aid: donor: bilateral economic aid authorized (ODA and
OOF), $5,058 million (1970-76) ,
Budget (central government): forecast for FY79, $80.6
billion expenditures, $71.9 billion revenues; public sector
borrowing requirement, $16.6 billion :
Monetary conversion ‘rate: - pound sterling floating,
average daily exchange rate 1977, 0.57 pounds=US$1
Fiscal year: 1 April-31 March
GNP: $684 million (1976 est.), $110 per capita, real-
growth, 5.8% (1976) ne
Agriculture: cash crops—peanuts, shea nuts, sesame,
cotton; food crops—sorghum, millet, corn, rice; livestock;
largely self-sufficient
Fishing: catch 3,500 metric tons (1975)
Major industries: agricultural processing plants, brewery,
bottling, and brick plants; a few other light industries
Electric power: 21,500 kW capacity (1977); 57 million
kWh produced (1977), 9 kWh per capita
Exports: $92.8 million (1978 est.); livestock (on the hoof),
peanuts, shea nut products, cotton, sesame :
Imports: $246 million (1978 est.); textiles, food, and other
consumer goods, transport equipment, machinery, fuels
Major trade partners: Ivory Coast and Ghana; overseas
trade’ mainly with France and other EC countries;
preferential tariff to EC and franc zone countries |
Aid: economic—Western (non-U.S.) countries (1970-76),
$218.1 million, OPEC (ODA) (1973-76), $59.2 million;
Communist countries (1970-76) $53.4 million; U.S. (1970-76)
$39.3 million ; Sos Ae
217
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
UPPER VOLTA/URUGUAY
Budget: (1978) balanced at $131 million
Monetary conversion rate: about 245.67 Communaute
Financiere Africaine francs=US$] as of November 1977
Fiscal year: calendar year','8cfb1a914a2116f58cc3f695923f1f9417e7d2a0fd152cc9f3a1f78b507c8e6f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96dbf6406a4b41fbdd177a93d2d02af8551bb3f8e7629a381a84428574d3177a',1972,'WF','Wallis and Futuna','economy',465,'Agriculture: dominated by coconut production with
subsistence crops of yams, taro, bananas
Exports: negligible
Imports: $1.4 million (1972); largely foodstuffs and some
equipment associated with development programs
Monetary conversion rate: 70 Colonial Franc Pacifique
(CFP)=US$1','f8fd40b7a42b8cc74997bc83b305ca0ffd327eeda1a36ae94f96befff016d03f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25382ab5faf9ed6511b4ea300a6541fe8644991073c264804b7810119e7c0683',1972,'ZM','Zambia','economy',469,'GNP: $2.5 billion (1977), $480 per capita; real annual
average growth rate, 0.7% (1970-77)
Agriculture: main crops—corn, tobacco, cotton; net
importer of most major agricultural’ products
Major industries; copper mining and processing
Electric power: 1,563,400 kW capacity (1977); 7.2 billion
kWh produced (1977), 1,340 kWh per capita.
Exports: $898 million (f.o.b., 1977); copper (92%), zinc,
cobalt, lead, tobacco
Imports: $817 million (c.i.f., 1977); machinery, transport
equipment, foodstuffs, fuels, manufactures
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
A ae en na
= me RRR A A eR
AA a A
AON ALA
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
Major trade partners: EEC, Japan, China, South Africa
Budget: 1976 est.—revenue. $510 million, expenditures
$665 million
Monetary conversion rate: 1 Zambia kwacha=US$1.12
(official)
Fiscal year: calendar year','e688fc3b30152fb3732a6b38912a36e772929ac1cf268d9b424c6030efb77a46','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a0a12a2b8a820cfdb4d0151c20d8016b4dcc221b215bcece62c1381171ee515',1972,'US','United States','economy',473,'GNP: $1,691.6 billion (1976); 64% private consumption,
-13.5% private investment, 21% government; $7,860 per
capita; 1976 growth rate, 10.2%
Fishing: catch 2.8 million metric tons (1975); imports
$1,381 million (1975); exports $298 million (1975)
Crude steel: 116.1 million metric tons produced (1976;,
540 ke per capita
Electric power: 557,012,300 kW capacity (1977); 2
trillion (net) kWh produced (1977), 9,750 kWh per capita
est.
Exports: $114.8 billion (f.o.b., 1976); machinery and
transport equipment, chemicals, cereals, mineral fuels
Imports: $129.6 billion (c.i.f., 1976); transport equipment,
machinery, mineral fuels, steel, nonferrous metals, metal
ores
Major trade partners: 22% Canada, 8% Japan, 5% West
Germany, 5% U.K. (1975)
Official development assistance (aid): obligations and
loan authorizations (FY76), economic $3.9 billion, military
$2.7 billion
231
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January. 1979
Budget: National Accounts Basis, expenditures $323.7
billion, revenues $287.6 billion
Fiscal year: -1 October-30 September','ca24e91eb515ce06b06ee9cefc42bab8c847f1110ac68c74e4f911ebe4a2adab','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74d7eca2f5d649bee3cccf2e101b721487a791b90c426628e3767cda9387ee97',1972,'','','raw',1,'A pproved for Release: 2018/04/27 C06726997 =
NATIONAL INTELLIGENCE SURVEY
; BASIC INTELLIGENCE FACTBOOK
JANUARY 1973
$
Py
; CHIVAL RECORD
des t 1972 i f this Factbook, ''ARCHIV. ,
Supersedes the July 1972 issuance of this Factboo i PLEASE RETURN TO |
copies of which should be destroyed. AGEN i ARCHIVES,
a ORT
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
“SECRE—
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entitics worldwide, is coordinated and published
scmiamnually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by components of the Defensc Intelligence
Agency and the Central Intelligence Agency. Comments and
suggestions should be addressed to the Office of Basic and
Geographic Intelligence (Attn: NIS Factbook), Central Intel-
ligence Agency, Washington, D.C. 20505.
Additional copics of the Factbook, both classificd and un-
classificd issucs, are obtainable through established channels for
disscmination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF TIIE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTIIORIZED PERSON IS PROHIBITED BY LAW.
CLASSIFIED BY 58-0001, EXEMPT FROM GENERAL DECLASSIFICATION SCHEDULE
OF €. O. 11652 EX zea CATEGORIES SB (2) AND (3). DECLASSIFIED ONLY
ON APPROVAL OF OCI
Approved for Release: 2018/04/27 C06726997
em det
ee ee
Approved for Release: 2018/04/27 C06726997
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(2) ee Confidential
(S)...... Secret
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
SECRET
Table of Contents (cont''d):
SENEGAL. oe be so ec bs Bate oor Ra we ee el ee SO ale le or SP es
SEYCHELLES =o) 5.95. et te ee A fe ee ee Sa es oa hte erie eae
Sharjah (see UNITED ARAB EMIRATES)
STERRA LEONE: 3. 3. 3,6: jose aoe koe: eee eo Aca 4 be ee RE are
SIKKIM esol aoe Wn ea ey eee ae ee SO We we Aaa ter eS ete
SOMALT As. for) ec se coh Oe ewe se ee Gc ce ites) Srl a as ae ew ele
SOUTHARRIGCA |e. oi: eh ee il el oe ere ww Bea ch Swe wwe als
Southern Rhodesia (see RHODESIA)
SOUTH=WEST |AFRIGAS: e555 55 Soke, Woe les ae ec OS es
SPAIWNs o.oo oe lertene ce mar Cove! Cee oh Wow LSS? o> He Rua coy See ee Ged Saas
SRT LANKA si i50c3. oe hate faa tes. a ER a ee EK ey
i i i i i i |
2Tz
|
Middl (see peace
THAILAND... .... B Meas i) Ate ha kak oA Gheeiued Ma, Mor iy ode te melee fo
TONGA. ee, ee rare
TRINTOAD AND TOBAGOs 2 3 Gav 0 Soba actbnoe and fo aces a
TUNISIA. 2... ww ee Sol Gat cat anh oy Weel oe aoe ol Ga Sakae fee be oh Oe
TURKEY, |, 5353-6 co: sic ae Ges Gos 0 as a te ec Bye Pol Gn eS Tecate faire a
-U-
S.R
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm "al Qaiwain. .. 1. ee ew eee
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 2 we ee ee ee
UNITED: STATES > 5. eas ce. Ss ber evs ie el en a eee ee
UPPER ‘VOLTA S. a ten ves és ce ete oe Nel ie Sele a? ec ee ea Mee ea
URUGUAY 6 ese ccs aise Melee yee og oo ley ty ce: Sa i a ea ey tea eS La ee
-\\-
VATICAN CLIN io a oe dee ae ht a Rees ae es I ae ae cas
VENEZUELA cece seas ol a as $05 ar dk a ce ave dap Pe ay Sa a Se, lw Ae
VIETNAM, NORTH... ....., BS Ae Sia Bye ROSENT RS Jet te be a dh, ae eect, ye
VIETNAM, SOUTH . . 1 eee ee eee we ee eee tt tts
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
—~Sterer—
NIS 27 TURKEY
LAND:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER: Pare
Limits of territorial waters (claimed): 6 n. mi. .
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mt.)
Coastline: 4,475 mi.','3d010a63a9223686fb0d93a0591b381470714a42cab3b49d027269a6eff5c8a9','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f3f047f2cb87dbb5278646b6e6bca7b3a8b8ad529791eb4b0dd0935eb1d7645',1972,'','','raw',1,'Approved for Release: 2018/04/27 C06727039
>
“NATIONAL INTELLIGENCE SURVEY
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this “ ARCHIVAL RECOR!
Factbook, copies of which should be destroyed FLEAS? RETURN TO ;
AGENCY ARCHIVES, ELDG. 4+.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entities worldwide, is coordinated and published
semiannually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by Office of the Geographer, Department of
State and by components of the Defense Intelligence Agency
and the Central Intelligence Agency. Comments and suggestions
should be addressed to the Office of Basic and Geographic
Intelligence (Attn: NIS Factbook), Central Intelligence Agency,
Washington, D.C. 20505.
Additional copies of the Factbook, both classified and un-
classified issues, are obtainable through established channels for
dissemination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF THE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTHORIZED PERSON IS PROHIBITED BY LAW.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(OC) testes Confidential
(S)ve. 32) Secret
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
“SECRET.
Table of Contents
Page
SAN: MARINO: ce 6 cee See ge Sere Se a lade Gee an A ee ie a ae 383
SAUDE ARABIA g:o5 3 sd. ceed & Reel Se) eS ee es 385
SENEGAL 2. fms oe So te a te Se at ee LE Si eh aes PE eee 387
SEYCHELLES cigar ee eas oe be este eS he Ge so es eee Sa ae So Be 389
Sharjah (see UNITED ARAB EMIRATES)
STERRA (LEONE: ~) 05. &. gee Sees ete A Sa ae te Re ey ne ye pe en ee 391
ST KKEM 3.2 caste see A es ce sl ee Gave Con Be eee, Ree ee We eS 393
STINGAPORE 6 ~ eieccoe otesecs desea We: obo eG" Annee Moh ee io oes nao es Wee eee 395
SOMALTA Sic: senor SBS ee Pa EE ne ae ie een ee eee “al GE ws Rees of? 397
SOUTH: AFRICA? oc. cei eo 8 See eer te ar ee Ss Tee 0 We ee Se 399
Southern Rhodesia (see RHODESIA)
SOUTH-WEST AFRICA. . . 2. 2 1 ee we ee te we te 403
SPAINGG se Se oe Se ee ls Ba Sera tS re wl hee os tay Janine 8s 405
SPANTSH ‘SAHARA 5. 232-0. ee kee ee ee see ee eee ww Ce 409
SRE LANKA Ses setae ib tie es re ote Sore a wren ie) eo ee tated See ae 411
SUDAN o. ie-.g. oe sehen Sek mol as he Bh “Seer se tgs Sha tah re win et ems NS Ge tee eh oe 415
SURINAME. 02 xsc260 ve sei Soro ce A SE ee eR he ee as ar tar Sh eee eee 419
SWAZILAND =. 2.62 ccs S) nO ee Fe Oo Se Blea Mek % Bee, Byway teu ke 421
SWEDEN cue ce nea caetot le conte on medic phase, Gti Gams Mean Se 423
SWITZERUAND sc od ce ''o: 1,006 os van ts Fen Saas Ag Be, eae! Tey Cage 427
SYR TRG oy ec secs etek be ee ek eng es areas 429
-T:
Tanganyika (see TANZANIA)
TANZANTAS ob cake. oie eh ce etn eh nin 8 Case a a te cle Ca aS wate Se 431
Tasmania (see AUSTRALIA)
THAILAND 3. wc -8 we ees eR ee be aoe & ie we ee 495
TOGO a: yee UR Ow aw ae ee wd Se ee A Se wee ee 439
TONGA © 6. edge ee Se Sc ae eS rae ; : ‘ 44]
oe AND TOBAGO. F Bae bode al eh awe hare ee ss . . =. 443
iia Bah GPL Baa aE ND ON Cie DER ea vs ect aay ce Fs 445
TURKEY gn eh weet Ai APS ae i sg ge eet, BMG ee eit te aa Sk: 447
-U-
UGANDA 555 io oe eo do reser ree ee nse ae a eles wes es ee 451
nes al Qaiwain (see UNITED ARAB EMIRATES)
Sk, ake Byles Be Sw Gon Ey fa els NDR ne Ot age, ee 453
ED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain. ........2... 457
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 1 we ee ee ee we tt ee te et 459
UNETED “STATES. o°-2 oc. se? Gece oe an ce ere Vel Gh ewe Sal Bek ele ne a 497
UPPER: VOLTA so: o:ce) te tee es oe I ee Be BO be Oe bes 463
URUGUAY cei eo ie eho eae Ser ay Boal ww Boer SP Gee: Be, Sas 82 weer 8 465
-V-
VATICAN: CLI a: 22-2, ecg: sés fortes Se et Se ea SCR te. ae a Gales 469
VENEZUELA se 5- ower ver era RS, “eee eee te yee el HS Bey Sere Re 471
VIETNAM, ‘NORTH gees detec tee ca eel ceive ei Ba ee ee 475
VEETNAM,. “SQUTHD ec. ce ios wee ae Se ee ee ae ee EP 479
v
SEGRE.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
““SRCRET.
NIS 27 TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mi.)
Coastline: 4,475 mi.','d81506181d04ffbecc364831122ff5a940f94bbc6ccef504917bcbbdae630814','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4bbdc5e9ba9d843497b645b2698e95c77daca9c27cd05c0e0deb18154d26993',1972,'','','raw',1,'Approved for Release: 2018/04/27 C06726998
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this
Factbook, copies of which should be destroyed.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998 :
ae
teow
i
{
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data on political
entitics worldwide, is coordinated and published semiannually as part of the NIS
Program by the Office of Basic and Geographic Intelligence, Central Intelli-
_» gence Agency. The data are prepared by Office of the Geographer, Department
of State and by componcnts of the Defense Intelligence Agency and the Central
Intelligence Agency. Comments and canuestions should be addressed to the
Office of Basic ana Geographic Intelligence (Attn: NIS Factbook), Central
Intelligence Agency, Washington, D.C. 20505.
Additional copies of the Factbook are obtainable through established
~ channels for dissemination of the NIS.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
This edition is a compilation of the unclassified
information in the classified version of the Factbook.
It is issued for use by U. S. Government departments
and agencies.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
Table of Contents
Page
SAN MARINO. 2... 2 ee ee ee ee ee ee eS 293
SAUDI ARABIA... - ee ee eee tee et ee eee 295
SENEGAL. . 2-2 ee et et ee te ee eee te eee 297
SEYCHELLES . 2. ee ee eet te ee te ee 299
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE. 2. we ee ee ee ee ee et 301
SIKKIM... 2 ee ee ee ee tt eet te HE 303
SINGAPORE. . .- - 2 es © eng aoe: Re a Meas lee SARI a NES, TEES Ms 305
SOMALIA. . .. 2. - eee ponies ee Yornlg vies Ro eee dats tet Se wee We 2 . . 307
SOUTH AFRICA... ee ee ee te ee ee 309
Southern Rhodesia (see RHODESTAJ
Sil aaah AFRICA. .... > bees Je ghigs vate Go are em 6 ieee ise uy
SPANISH SAHARA... .- hc le wale “ae ae Gah tae ee ogi Cee SS 317
SRI LANKA. 2. ee ee te et ee ee 319
SUDAN. . .. 2 ss eo eel Wes eee ce tat gi rel cal get, Ser ton ah Say va Sg, ea nes 321
SURINAM. » 2 ee ee ee te ee 323
SWAZILAND be gy ose ental a: atctah eae pO) be bg Wik en WE TES Be ew TS 325
SWEDEN . 2. we ee te ee te ee ewe ee ee ee 327
SWITZERLAND. . 2... 2 ee ee ee te ee eee ee eS oe « 329
SYRIA. 2. ew ee et te tee we ee ES 331
-T-
Tanganyika (see TANZANIA)
TANZANIA. wc eee te ee ee et ee ee & 333
Tasmania (see AUSTRALIA)
THAILAND... 2... ee ee te ee te ees gf ehhiig ig fe eel eh % 3330
TOGO... . es cia, ais tae ong. And Keen oper ae Pah te NS a ject wy eS
TONGA, . 2 ee ee et tte ett we eet we ee ee . . 339
TRINIDAD AND TOBAGO. ....-+.-s Se clbt ee hg seh ke Tal yor et to? ow) Ca seas . 341
TUNISIA. 2 2. ew ee ee eee te ee ee Sag Se 2849
TURKEY . 2... ee ee ee ee Band May US Sain EPS Mee tay seh ain aie S. te es TORO GS 345
-U-
UGANDA. 2. we ee ee te ee te ee wee ee 347
Umm al Qaiwain (see UNITED ARAB EMIRATES)
| ee eee ee PP To a 349
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Unm al Qaiwain . . 2 2 6 eee ees 351
United Arab Republic (see EGYPT)
UNITED KINGDOM... . eee ee eee te ee ee eee 353
UNITED STATES. . 2. eee ee te eee eet ee he eH 379
UPPER VOLTA, . . 2. ee ee eee et ee ee ee ee eee 355
URUGUAY. . .. 2 «> Ly cgi gh tortie. Ue dies Nel vas Meneses Sept ere, ee? cote ree. 357
-y-
VATICAN CITY 2. 2 we ee ee ee ee 359
VENEZUELA. . 2. 1 ee ee ee et ee ee ee he eee 361
VIETNAM, NORTH. . 2... - ee ee we ee Sree nds. Ghceear barr") sat War 0 eso fe 363
VIETNAM, SOUTH . 2. 6 6 we ee te ee eee te eh ee ee 365
v
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive SPRY
Land boundaries: 1,600 mi. Seat
cover SAUDI
WATER: "Sy nama
Limits of territorial waters (claimed): 6 n. mi. Be
except in Black Sea where it is 12 n. mi. SUDAN ‘
(fishing, 12 n. mi.) £ RSS
Coastline: 4,475 mi. ETHIOPYA','a24946e0eda2487814d38bc598fdbba53715746ebaacc57387c8bc055ad24a8d','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dd109fb51454f5401275cd92a33aab25661d5f489f3bbe7988b5a2c71a0ed7a',1972,'','','raw',1,'Gat
DP79-01051A000500010003-9
- Approv
BASIC INTELLIGENCE FACTBOOK
JULY 1972
DIA review completed.
Supersedes the December 1971 issuance of this Factbook,
copies of which should be destroyed.
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data on political
entities worldwide, is coordinated and published semiannually as part of the NIS
Program by the Office of Basic and Geographic Intelligence, Central Intelli-
gence Agency. The data are prepared by components of the Defense Intelligence
Agency and the Central Intelligence Agency. Comments and suggestions should
be addressed to the Office of Basic and Geographic Intelligence (Attn: NIS
Factbook), Central Intelligence Agency, Washington, D.C. 20505.
Additional copies of the Factbook are obtainable through established
channels for dissemination of the NIS.
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
‘ This edition is a compilation of the unclassified
information in the classified version of the Factbook.
It is issued for use by U. S. Government departments
and agencies.
ee
“ss
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
~@&
©
Next 5 Page(s) In Document Denied
Pod
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
STAT
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
AAPSO
ADB
ANZUS
ASA
ASPAC
BENELUX
BLEU
CACM
CARIFTA
CEMA
CENTO
DAC
EAMA
EC
ECAFE
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
TADB
ICFTU
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
Afro-Asian People''s Solidarity Organization
Asian Development Bank
ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
Association of Southeast Asia
Asian and Pacific Council
Belgium, Netherlands , Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Free Trade Association
Council for Mutual Economic Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC. ECSC, EURATOM)
Economic Commission for Asia and the Far East
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey,
Niger, Upper Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Inter-American Defense Board
International Confederation of Free Trade Unions
vii
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
IDB
IFCTU
IHB
TRC
La Francophonie
LAFTA
LICROSS
NATO
OAPEC
OAS
OAU
OCAM
ODECA
OECD
OPEC
SEATO
UAM
UEAC
UDEAC
WEU
WFTU
WPC
Inter-American Development Bank
International Federation of Christian Trade Unions
International Hydrographic Bureau
International Red Cross
Agency for Cultural and Technical Cooperation
Latin American Free Trade Association
League of Red Crass Societies
North Atlantic Treaty Organization
Organization of Arab Petroleum Exporting Countries
Organization of American States
Organization of African Unity
Afro-Malagasy Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
Organization of Petroleum Exporting Countries
South-East Asia Treaty Organization
Union Africaine et Malgache
Union of Central African States
Economic and Customs Union of Central Africa
Western European Union
World Federation of Trade Unions
World Peace Council
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc
GA
ECOSOC
TC
IJ
Security Council
General Assembly
Economic and Social Council
Trusteeship Council
International Court of Justice
Secretariat
viii
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
UNITED NATIONS (U.N,): STRUCTURE AND RELATED AGENCIES (cont''d)
Operating Bodies:
UNCTAD U.N. Conference for Trade and Development
TDB Trade and Development Board
UNICEF U.N. Children''s Fund
Regional Economic Commissions:
ECA Economic Commission for Africa
ECAFE Economic Commission for Asia and the Far East
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development
(World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural
Organization
UPU Universal Postal Union
UNCTAD U.N. Conference on Trade and Development
WHO World Health Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
ix
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES (cont''d)
Commi ttees :
Seabeds Committee United Nations Committee on the Peaceful Uses of the
Sea-Bed and Ocean Floor beyond the Limits of National
Jurisdiction
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9
NOTE:
Political, sociological, and economic data, including monetary conversion
rates, generally reflect information through mid-April 1972, except for population
estimates, which have been projected to 1 July 1972. Estimates of males fit for military
service are as of 1 July 1972; estimates for average number of males reaching military
age, are projected averages for the 5-year period 1972-76. Military and communications
data are as of 1 April 1972 unless otherwise indicated.
Most of the land utilization estimates are rough approximations, and most of
the statistical data are rounded (thousands and millions). Figures for "arable" may
reflect only the area actually under crops rather than the potential cultivable.
Fishing limits are included only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference between the
two is in the addition or subtraction of the value of return on foreign investment.
GDP equals GNP plus income earned in the country but sent abroad, minus income earned
abroad but sent into the country. GDP thus tends to exceed GNP in debtor countries,
and the reverse is true in creditor countries. The dollar sign refers to U.S. dollars
unless otherwise stated. The abbreviation FY stands for U.S. fiscal year; all years
are calendar years unless otherwise indicated.
Defense forces data in this edition of the Factbook are generally limited to
supply and military budget information. Military budgets are in U.S. dollar equivalents.
Major ports are the largest maritime ports of the country, relative to other
ports of the same country, on the basis of estimated port capacity, alongside berthing
accommodations, and commercial or naval importance. Minor ports are the remaining
ports of a country which have, relative to the major ports, significantly lower
estimated port capacity, fewer alongside berthing accommodations, are of less
commercial or naval importance. Major transport aircraft are those weighing over 20,000
pounds.
xi
Approved For Release 2008/01/14 : CIA-RDP79-01051A000500010003-9','4eee4f624282c615ccc2b50715298d9d857166eb440618eaf457cf949535391a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010003-9','txt','a7e74d5cd3a381050047bba866d5a7f2f75ab3b17968ab32180fe8769d0000dd','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010003-9/cia-rdp79-01051a000500010003-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4c29198ad864b383001bba25ea0f777b9294c22a26a8e37d827332029ffa641',1972,'','','raw',1,'STAT
Approved For Release 2007/01/17 : Cla. RDP77Mo0144ROCO6O RBIS oye
Journal ~ Office of Legislative Counsel Page 2
Friday - 29 August 1975
CIA INTERNAL USE ONLY
5. (Unclassified - WPB) INTELLIGENCE BRIEFING After
“consulting with[ SS —*Y(OR), T stopped
by Representative J, Edward Roush''s (D., Ind.) office to discuss with
Timothy Leeth, Staff Assistant, the Agency methodolopy in forecasting
Soviet grain yields. I outlined for him the various sources of information
the Agency uses in forecasting, stressing that the Department of Agriculture
has access to everything the Agency does. I told ifm that weather data was
the most important information used in forecasting and that this was
supplemented by other kinds of intclligence such as press reports, attache
reports, and ERTS, Leeth was primarily interested in the utility of ER''TS
as an intelligence tool. I told him that ERTS was useful, but was collateral
to and not central to these forecasting exercises. He seemed satisfied at
this very general exposition.
6. (Unclassified - DFM) LEGISLATION Received a call from
Bill Jones, INR/State Department, regarding the Agency''s letter to OMB
on H.R, 131). Jones suggested we solve our problems with the bill by
requesting additional definitions rather than changing the text of the bill,
as we had proposed in our letter. I told Jones we would consider his
suggestion, and I would be back in touch next week. :
STAT
CIA INTERNAL USE ONLY
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
a al
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
Journal - Office of Legislative Counsel Page 3
Wednesday - 27 August 1975
CIA INTERNAL USE ONLY
9. (Unclassified - PLC) LEGISLATION Ralph Malvik, OMB,
called and inguired as to whether we had submitted an Inflationary
Impact Statement with our revised proposal to amend CIARDS Act. I
told him that we had submitted such a statement to OMB with our
prior draft earlier this year. Malvik said no further statement will
be necessary.
10. (Internal Use Only - PLC) CONSTITUENT Cathy Paxham,
secretary to Representative Bob Wilson (R., Calif.} called and said
that she would be handling the request by Mr. Wilson for the Director
to meet with a constituent, Ee I gave her the hackground STAT
of the case and she said she would call us back next week after she has
discussed the matter with Mr. Wilson.
ll. (Unclassified - PLC) LIAISON After a discussion with
STAT [t™t~té‘“C;CCC«dztCOSS,- A called Mark Jones, Personnel Officer, Federal
Res apd, in response to his call of Monday inquiring as to
whether the Black Muslims was included in a listing of organizations
that we require applicants to review for possible affiliation. J] explained
that under a recent order for all Government agencies, no listing of
organizations such as the "Attorney General''s List" is to be used in
the processing of persons for employment. Therefore, we have no
such listing.
STAT
CIA INTERNAL USE ONLY.
Acting Legislative Counsel
cc:
O/DDCI
STAT SSS
Ex. Sec.
DDI
DDA
DDS&T
Mr. Warner
Mr. Thuermer
Mr. Parmenter
Ic Staff
EA/DDO
Compt
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
Journal - Office of Legislative Counsel Page 2
Friday - 22 August 1975 ;
CIA INTERNAL USE ONLY
7 (Unclassified - DFM) LIAISON Received a call from John Schwat,
of the Library of Congress. Schwat was interested in opinion polls regarding
public awareness of various parts of the intelligence community. After
STAT checking with ere |: gave Schwat cites to four opinion polls dealing
with intelligence matters. However, none of them were exactly on the point
Schwat was researching.
8. (Unclassified - DEM) LEGISLATION Called the House Cormmittee
on the Judiciary and was told the names of the agencies which had been asked
to comment on the bills requiring financial dis closure.
9. (Unclassified - DFM) LEGISLATION Called Tom: Moyer and Dave Reitch,
both in the General Counsel of the Civil Service Commussion, regarding the
numerous bills requiring financial statements by Federal employees. Civil
Service has been asked for their comments on these bills by the House Judiciary
Committee. Reitch said the Commission was not planning to respond to the
Committee, because they get hundreds of requests every Congress for comments
and can only respond when a bill becomes active, However, we discussed the
merits of the bills, and he agreed that the Agency''s special problems would
require an exemption,
10. (Unclassified - DFM) LEGISLATION In connection with the
preparation of Agency comments on S. 1481, Senator Birch Bayh''s (D., Ind.)
proposal to ban the use of the polygraph, I called[ J General CounselSTAT
STAT of NSA, [_joffered to send me material on NSA''s use of the polygraph.
ll. (Unclassified - PLC) FOIA Called Jim.Hyde, OMB, and asked if
he would want us to clear with them our reply to a letter from Representative
Ashbrook''s (R., Ohio) inquiry as to whether we are having any problems in
implementing the recent amendments to the Freedom of Information Act.
Hyde requested that we clear our response with him and asked that I send
him our draft for their preliminary review before the Director''s approval.
12. (Unclassified - PLC) FOIA Called John Casciotti, in the office
of Senator Richard Schweiker (R., Pa.), and inquired as to whether an FOI
STAT reguest from a constituent, ae to the FBI, which was
sent to us ty their office had been misdirected. We said they intended that
the Agency act on the request. IRS was advised to process the request.
CIA INTERNAL USE ONLY STAT
ce:
O/DDCI
: DYpI DDS &''L r als : a 3 a is
TUE Sa apprved For & lease 20071017: cla RDB 77d a4ntadgon090009F ne
ix. Sec. Le Mer tC Stat
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
Journal - Office of Legislative Counsel Page 2
Friday - 22 August 1975 a
CIA INTERNAL USE ONLY
7. (Unclassified - DIEM) LIAISON Received a call from John Schwat,
of the Library of Congress, Schwat was interested in opinion polls regarding
public awareness of various parts of the intelligence community. After
STAT checking with[ st fave Schwat cites to four opinion polls dealing
with intelligence matters. However, none of them were exactly on the point
Schwat was researching.
8. (Unclassified - DFM) LEGISLATION Called the House Cornmittee
on the Judiciary and was told the names of the agencies which had been asked
to comment on the bills requiring financial disclosure.
9. (Unclassified - DIM) LEGISLATION Called Tom: Moyer and Daye Reitch,
both in the General Counsel of the Civil Seyvi mmission, regarding the
numerous bills requiring financial statements by Federal employees. Civil
Service has been asked for their comments on these bills by the House Judiciary
Comunittee. Reitch said the Commission was not planning to respond to the
Committee, because they get hundreds of requests every Congress for comments
and can only respond when a bill becomes active, However, we discussed the
merits of the bills, and he agreed that the Agency''s special problems would
require an exemption,
10. (Unclassified - DFM) LEGISLATION In connection with the
preparation of Agency comments on S,. 1481, Senator Birch Bayh''s (D., Ind. }
proposal to ban the use of the polygraph, I called [____ ]General CounselgT aT
STAT of NSA, [_Joffered to send me material on NSA''s use of the polygraph.
iL. (Unclassified - PLC) FOIA Called Jim Hyde, OMB, and asked if
he would want us to clear with them our reply to a letter from Representative
Aghbrook''s (R., Ohio) inguiry as to whether we are having any problems in
implementing the recent amendments to the Freedom af Information Act.
fHyde requested that we clear our response with him and asked that I send
bim our draft for their preliminary review before the Director''s approval.
12. (Unclassified ~ PLC) FOIA Called John Casciotti, in the office
of Senator Richard Schweiker (R., Pa.),and inquired as to whether an FOL
STAT - request from a constituent, ae addressed to the FBI, which was
sent to us by their office had been misdirected. Tle said they intended that
the Agency act on the request. IRS was advised to process the request.
CIA INTESNAL USE ORLY STAT
CC:
O/DDCI Acting Legislative Counsel
STAT Earbud por Melense re Parmenter, MALIDO
So Apprbvetl Yor Release 2007/01/17 CIARBBT Tiida a4RRO0GGON02000%8 cc
Tox. AEN LOL St
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
Journal ~- Office of Legislative Counsel Page 3
Tuesday - 19 August 1975
25X1 9. [ LIAISON Mrs. Josephine Weber, Staff
Assistant, House International Relations Committee, called and said the
Chairman wanted to know, immediately, if the Agency had "different area
desks for Africa--is North Africa included in the South African desk?"
After checking, I told her they were separated,
25X11
10. ADMINISTRATIVE John epley, Purchasing
Clerk, House of Representatives, called to advise he had mistakenly received
an invoice which belongs to CIA. Itold him to send it to me and Jj would get
it inthe right hands. (This was sentto[ _——~CCOJ Key’ Busi ding upon 25X1
receipt. )
25X1
12, re CONSTITUENT. In response to her
request, provided Margaret Keller, in the office of Representative Gilbert
Gude (R., Md.), suggestions for responding to questions raised by a
constituent concerning the Agency''s budgetary and appropriations process,
25X1 13. See Oi Les Janka, NSC, called and
advised that the material we had sent him on the Mayapuez (Post Mortem
and Situation Reports) were being sent to Dr. Kissinger. Janka was highly
complimentary of the Post Mortem but felt it had more than may be
necessary to respond to Chairman John Sparkman''s (D., Ala.) letter.
Dr. Kissinger and the Director will discuss this matter before the Director
s wit airman arkman.
25X1
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
STAT
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1 i a
Journal - Office of Legislative Counsel Page 2
Friday - 15 August 1975
CIA INTERNAL USE ONLY
7. (Internal Use Only - PLC) LIAISON/FOIA George C. Armstrong,
Research Assistant to Representative John M. Ashbrook (R., Ohio),
called and asked for the telephone number of retired Agency employce,
David Phillips. Armstrong said he wanted to discuss with Phillips a
resolution supporting CIA which Representative Ashbrook is contemplating
submitting to the American Legion Convention now being held in
Minnesota, I gave him the telephone number of Phillips after checking
with Angus Thuermer''s office.
I told Armstrong that we hope within the next few days to get
a reply to Representative Ashbrook''s letter as to our problems in
implementing Freedom of Information within the Agency. Armstrong said
anytime this week or the next would be fine as they are also writing to
other agencies and had not yet heard from all of them and also the
Congressman is now out of town.
; STAT
8. (Internal Use Only - PLG) CONSTITUENT Gordon H, Hayes,
Staff Assistant to Representative Tohn J. Lalralce (D., N.¥.)}, called
to discuss a case of a constituent,
The letter dated 7 January 1975 had been
mistakenly overlooked in their office. See Memorandum for the Record,
9. (Internal Use Only - RJK) ADMINISTRATIVE - DELIVERIES
Delivered a package to Al Tarabochia, Senate Judiciary Internal Security
Subcommittee staff, per arrangements made by[ STAT
STAT
10. (Unclassified - DFM) LIAISON Called John Seibert, Special
Litigation Section, Criminal Division, Department of Justice. [Ds
OQGC, gave me Mr. Seibert''s name and encouraged me to call him. I
explained to Seibert that we had received a congressional inguiry on behalf of
a constitucnt for the names of all plaintiffs suing the Agency over our
domestic activities, I asked Seibert if there would be any Justice Department
position or objection to us providing the names, After checking with some
colleagues, Seibert phoned back and encouraged us to release the names,
explaining that they were a matter of public record.
ll. (Unclassified - DIM) LIAISON Called the congressional
liaison office at the Enerpy Research and Development Administration, J
spoke with Ray Marble who explained certain procedures regarding their
association with the Joint Committee on Atomic Enerpy. .These matt2rs
were of interest to the task force now developing the policy on Government
Accounting Office audits of the Agency. Marble could not answer all my
questions end referred me to George Murphy, Staff Director of the Joint
Committee, I called Murphy later in the day and he was very helpful, on
the sarfpproved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
CIA INTERNAL USE ONLY
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
JOURNAL
OFFICE OF LEGISLATIVE COUNSEL
. Tuesday - 12 August 1975
-CIA INTERNAL USE ONLY
1, {Internal Use Only-RC) [CO R, briefed STAT
Michael McLeod, Henry Casso, and Carl Rose onthe staff of the Senate
Agriculture Committee, on the Soviet grain situation. J advised them that
the briefing should be treated as classified but should they need to use
any of our discussion they could check with OLC. Two pertinent questions
from them were whether the Agency got together with the
; Agricult our grain estimates and the validity of the 200 million ton
STAT: aE eres [___|fielded these questions very adroitly.
‘The staff members were quite pleased and said they looked forward to
further discussions in the future.
2. (Unclassified - RC) Called Susan Holloway, Legislative Secretary
to Senator Walter Mondale (D., Minn.), and explained that I didn''t
know what she wanted us to do with the constituent inquiry she had sent us
since Senator Mondale was a member of the Senate Select Committee. She
thought we should be answering the part on the National Park Service. I
explained that this should be forwarded to the Department of the Interior. She
said to simply send the material back to her attention. ;
3. (Unclassified - PLC) Met with Al Tarabochia, Chief. Investigator,
on the staff of the Judiciary Subcommittee on Internal Security, and retusned
to him the study "Estudio Sobre Las Relaciones Entre El Partido Socialista
Puertorriqueno Y El Movimiento Obrero" which related Communist influences
in Puerto Rico, I explained that our people saw no significant foreign
intelligence interest to warrant the Subcommittee''s publication of the study
in Spanish. I suggested that he should contact the FBI since it appeared to
be more a matter of internal security.
Tarabochia said that the article by Jack Anderson in the 10 August
issue of the Washington Post reporting Cuban Communist influences in
Portugal was based on unclassified information which Tarabochia had
given to Les Whitten, Anderson''s reporter, The information came mostly
from unclassified reports by the Coast Guard provided to the Committee.
Tarabochia wanted to make it clear that he does not have a close relationship
with Whitten, however, he felt that the story should be told: and knew that
Whitten would want to publish it,
CIA INTERNAL USE ONLY slat
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1 |
Journal - Office of Legislative Counsel Page 2
Tuesday -~ 12 August 1975 ,
CIA INTERNAL USE ONLY
4, (Internal Use Only - LLM) Tom Sullivan, in the office of
Representative Sam Steiger (R., Ariz.), who also doubles as Minority
staff of the House Government Operations Subcommittee on Government
Information and Individual Rights, called to review the status of our
response to the Subcommittee request for certain Agency documents
STAT relating to the case.
5, (Unclassified ~ I.L.M) Tim Ingrarn, on the staff of the House
Government Operations Subcommittee on Government Information and
Individual Rights, called to review the status of our work on the material
to be provided the Subcommittee. I told him that I thought it would be
ready before Friday the 15th and that we were aware of the illness of
Representative Bella Abzug''s (D., N.Y.) mother and I would try to give
him an alert beforehand if there is any reason I would feel her presence
in Washington, D.C. is required to review our material. Ingram was
appreciative of this consideration, Under the circumstances he thought
it would not be necessary for[_————S—S—=C*idOOGG,, to. le available on the STAT
15th. Itold Ingram that we were also working on the follow-up requirements
from other testimony before the Subcommittee and he would be provided ~
that material as it was completed. Ingram said that if the material
to be provided this week was classified, it could be provided to Nancy
Wenzel, who possessed a security clearance,
6. (Unclassified - DFM) Called Natalie Desmond, secretary to
Mr. Brown at the Department of Transportation. I gave her several.
references to statements, hearings, and reports which would provide
her the legislative history of the section of the National Security Act.
proscribing domestic activities.
7. (Unclassified - SDK) Calledl_ CSO MB, to alert STAT
him that our response on S, 244 would be delivered tomorrow.
8, (Unclassified - RJK) Met with Betsy Kaugliak, on the staff
of Representative Ralph S, Regula (R., Ohio), and gave her a copy of
the National Basic Intelligence Fact Book per her request,
GIA INTERNAL USE ORLY
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
Journal - Office of Legislative Counsel Page 3
Friday - 8 August 1975
STAT re Received a call from Ralph Preston,
Staff Assistant, Defense Subcommittee, House Appropriations Committee,
concerning a letter Chairman George H. Mahon (D., Texas) has received
from the Assistant Attorney General requesting access to certain
Committee documents. (See Memorandum for the Record.)
20 il. [ The Director called to advise of a telephone
conversation he had today with Joseph Sisco, Under Secretary for Political
Affairs, State Department, regarding events which transpired during the
testimony of Deputy Secretary Robert S. Ingersoll before a subcommittee
of the Senate Foreign Relations Committee last week. (See Memorandum
for the Record.)
25X1 7
12. During the course of the afternoon, I
again had several conversations with Howard Feldman, Chief Counsel,
Permanent Subcommittee on Investigations, Senate Government Operations
Committee. The conversation began with Feldman advising me that
Senator Henry M. Jackson (D., Wash.) was putting out a press release
today stating that there would be a significant shortfall in Soviet grain
production this year and on the basis of new information he (Jackson) had
received there were indications that the shortfall might double that of 1972.
(See Memorandum for the Record.)
a 13. [ Called Natalie Desmond, secretary to
a Mr. Brown who is the Special Assistant to the Secretary of Transportation,
25X11 Ms, Desmond had called[ «dO, regarding the legislative
history of the section in the National Security Act proscribing police,
subpoena, and law enforcement powers of internal security functions, and
25X11 [asked me if I would call Ms. Desmond. I gave her the numbers of
the reports and hearings on the 1947 Act, but none of them touched upon
the domestic activities section. I told her I would see what else we had
and get back to her next week,
v *
OTe stative Counsel
cc:
25X11 o/ppci[(____—i”d — CONFIDENT! AL
Ex,Sec. DDI DDA DDS&T
Mr. Warner Mr. Parmenter
Mr. Thuermer IC Staff
RA/DDO Compt
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1
Journal ~- Office of Legislative Counsel Page 2
Thursday - 7 August 1975 anlar
28x" Se Gre!
25X1
Called Floyd Lupton, Administrative Assistant
to Representative ones (D., N.Car.), and told him that in the
absence of the oe ah i cr our office would be down 25X1
to see him soon to provide him information for relay to Mr. Jones.
(This concerns Mr. Jones'' staternent in the 3 August 1975 Daily Advance. ye
Neither our records nor those of OTR [Jer DOD (Mr. Fryklund} 25X1
indicate any prior briefing of Mr. Jones[-i(‘“‘™éOOOOOOOO#O#C(#«dz 25X1
25X1 ae, |
25X11 | .
8. Fe eee Emerson, Legislative Assistant
to Senator Barry Goldwater (R., Ariz.), called to determine what public
legal papers might exist concerning Section 32 of the Foreign Assistance
Act of 1974 and we discussed this subject generally. Emerson indicated
he might be preparing a law review article in conjunction with the
Senator on this issue.
25X11
: 9. Stuart Statler, Minority Counsel, Permanent
Subcommittee on Investigations, Senate Government Operations Committee, —
called on behalf of Senator Charles Percy (R., Il.) to raise objections of
their inability to obtain the Soviet grain figure from the Agency. He said
Senator Percy had been told by a Chicago grain dealer that the Soviet crop-
was estimated to come in at about 170 million tons and he (Statler) has
indications that the Agency has already arrived at a number. He understood
there may be constraints on our reporting this information and wanted to know
where these points were so he could apply pressure, Subsequently, I
provided, on a confidential basis, the figure 165 as the Agency''s estimate
and not necessarily the Executive Branch position. He wanted to know if
the Department of Agriculture agreed with our figure and I said I did not
know, He also observed that a shoreat such as this had a number of “25X14
significant implications.
Approved For Release 2007/01/17 : CIA-RDP77M00144R000600090009-1','a04e542b3b3443176173e0caf9d660d3b2a09af4476941d4ce782497bed178ce','internet-archive','cia-readingroom-document-cia-rdp77m00144r000600090009-1','txt','f166aa2793f1d372de607940569285312bd5e3005e6012ccec2d5f34bf9ad4f7','https://archive.org/download/cia-readingroom-document-cia-rdp77m00144r000600090009-1/cia-rdp77m00144r000600090009-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caec0a284ad43fc7844e043fd5459ceadbd987d87f307cbb468a9b2d3e0d2088',1972,'','','raw',1,'Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
q a
LISTING OF AGENCY UNCLASSIFIED PUBLICATIONS
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
OO
Approved For Release 2008/01/30 : os RDP85M00363R000901960031-7
Directorate of
Intelligence
CIA Publications
Released to the Public
Listing for 1972-81
DI 82-10029
(Supersedes NF 81-10007)
May 1982
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
3 1
This publication is prepared for the use of US Government
officials, and the format, coverage, and content are designed to
meet their specific requirements. US Government officials may
obtain additional copies of this document directly or through
liaison channels from the Central Intelligence Agency.
Requesters outside the US Government may obtain subscriptions to
CIA publications similar to this one by addressing inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Requesters outside the US Government not interested in subscription
service may purchase specific publications either in paper copy or
microform from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
(To expedite service call the
NTIS Order Desk (703) 487-4650)
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release eo Oee : CIA-RDP85M00363R000901960031-7
Preface Publications of the Central Intelligence Agency are prepared to support US
policymaking officials. However, the Agency releases its unclassified publications
to improve public understanding of key policy issues and to provide additional
research aids to academic and business communities. This program began in 1972
with CIA participation in the Document Expediting (DOCEX) Project of the
Library of Congress. Since that time a large number of unclassified Agency
publications have been distributed through this subscription service. The majority
of these reports concern foreign or international economic and political affairs, or
are directories of foreign officials. Publications have been included in the
Government Printing Office’s Depository Library program since late 1977 and,
beginning in 1979, are also available from the Department of Commerce, National
Technical Information Service (NTIS).
This catalogue, issued annually since 1978, lists Central Intelligence Agency
publications released through DOCEX from 1972 through 1979 and through
NTIS since 1979, It is arranged alphabetically. by country or geographic area with
the titles of the reports in chronological order. The entries for the People’s
Republic of China and the Soviet Union are further subdivided by broad subject
headings; for example, political, economic, and so forth. Reports concerning more
than one country or area are listed in the international section of the catalogue.
Publications issued semiannually or more frequently are listed separately as
serials.
Selected maps and atlases produced by CIA since 1971 are available through the
Superintendent of Documents and are listed in the GPO Monthly Catalog. Maps
produced since 1 January 1982 are available through DOCEX or NTIS.
Publications are not available to the public from the Central Intelligence Agency.
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7','2044ff70e57ef30f3bde8d469b26830f006ff753b8550b43da4740ad15435ab1','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7be9f6b45680f5d6b31d36b8c08cb6b0cccb2b27e6c518276473034620d3b31c',1972,'AL','Albania','raw',2,'Albanian Worker’s Party,
CR 81-10095, June 1981, wall chart
Government of the People’s Socialist Republic of Albania,
CR 81-10094, June 1981, wall chart
Directory of Officials of the People’s Socialist Republic of Albania,
CR 80-14733, December 1980
Directory of Officials of the People’s Socialist Republic of Albania,
CR 79-12598, May 1979
Directory of Officials of the People’s Socialist Republic of Albania,
CR 77-10848, March 1977
People’s Socialist Republic of Albania: Government and Party Structure,
CR 77-11802, April 1977, wall chart
Directory of Officials of the People’s Republic of Albania,
A (CR) 74-22, June 1974','6b20c76131eb849eae55990531184b870ff5faaf1b50d41214957775e0bc507d','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a37de8b7bb5d2bfb69feacd3060a38e3790c4e5a2c136a743fde0bad4381c795',1972,'BG','Bulgaria','raw',3,'Directory of Officials of the Bulgarian People’s Republic,
CR 79-10008, January 1979
Bulgarian Communist Party Leadership,
CR 78-15135, November 1978, wall chart
Government of the People’s Republic of Bulgaria,
CR 78-15136, November 1978, wall chart
Bulgarian People’s Republic Government and Party Structure,
CR 76-10051, January 1976, wall chart
Directory of Officials of the Bulgarian People’s Republic,
A (CR) 75-38, September 1975
Directory of Bulgarian Officials,
A 72-5, March 1972
China, People’s Republic of
Geographic
Beijing City Brief,
GS 81-10141, June 1981
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
y) q
China, People’s Republic of (continued)
A Perspective on the Pinyin
Romanization of Chinese Characters
GS 81-10250, September 1981','1d8abd875b914c93b3d043e07b94fc58a488f0bf8674ca830eedffb4dd1dd10a','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dab619a56be565f94d354f7e2b4d170fd3b555d1d405ebacf598b4367eb373d',1972,'','','raw',1,'iP eae ma
WW | Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
d sawIvuary 2£yugfT J ''
erro amen ll
ee
rile dey
Ploase aokun to FIFCT Book STAFE
a
ee Sine OS
6Z6T Asenuest - YOOSLOVA 22uUsdHy 19}; D1ISeg JEUONeN
_National. Basic Intelligence
FACTBOOK
ea Saisie nan sh! eT Set oak Sake ale dared
: GC BIF 79-001
January 1979
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
NUN
. FOREWORD
The National Basic Intelligence Factbook, a compilation of
basic data on political entities worldwide, is coordinated and .
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central: Intelligence Agency,
Washington, D.C. 20505. :
The publication is prepared for the use of U.S. Government E
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of
. specific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users may also purchase hard copies
of this publication from:
Superintendent of Documents
US. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00103-5
\\ -___ Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
i oie, ie
i tien) oe ae
pet
PO snc
aaceth ot eile
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
National Basic Intelligence
FACTBOOK
January 1979
Supersedes the July. 1978 ‘issuance of this
Factbook, copies of which should be destroyed.
For sale by the Superintendent of Documents, U.S. Government Printing Office
- Washington, D.C. 20402
Stock: Number ''041-015-00103-5.
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TABLE OF CONTENTS
Entries in all capital letters refer to
basic data sheets included in this Factbook
Page
Abbreviations for International Organizations 20.0.0... ccc cece c cette nreee tees xX
United Nations (U.N.): Structure and Related Agencies ........0...0.:0.cccceeetees xii
po oe
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN: tess cte hese there OM cotta s dah sleMaacn lane lin facie eat mnet Bs ids 3h ke ]
‘Ajman (see UNITED ARAB EMIRATES)
ALBANIA \\ vescccseeestectigosceceteaeveevectea ie eeevie. f uh Bfact Woveseledee.dviaed is ae MW aed 2
ALGERIA: st tcsnaraaniotves taritatarventete ps earl Batt vite feu eOi ec Sh eancet Mt Gnas 6 leila dE Rea ds 3
ANDORRA ooccccscccsssscsssssesesssvesssseetesseee ets De hes Dace 0 ite jan ocd hie iacaare 4
ANGOLA ones Sala aid AL OP anaes nudes 5
Anguilla (see ST. CHRISTOPHER-NEVIS) oe
ANTIGUAS ois ett met alece ete ok Daath dd rated Sansome eaten a eee 6
ARGENTINA | 055: betssdiiech 82) oa oat ek eythananlicht leh sd Stren tde boule salt alee ist dalla tal ty Mian 7
AUSTRALIA © 2205-9, Fa cy wees co ses cavegs ndeseenbanaannd diced tedesdatsal goa dedeter sveglvnedds -Pipany sea santteesoetes 9
AUSTRIA. ssesieccesiua ceorthic adedidsn obser dag tulad Meeddate aoage hawt gy soonhehaghet esta ta nadtteek isi estas 10
Azores (see PORTUGAL)
—B—
BAHAMAS; THE? <2. advo ene a ese) AR eh air tate de as VW
BAHRAIN | (2ctec ios fn ete eenerlesientatidees Ancatlin gal cable alert danetind bbs hithna ian tna agee Rte 12
Balearic Islands (see SPAIN)
BANGLADESH. ...... Be ha Na uN eat hatin eo aad tea teat An Ds aon bonne SE aoe Beats alt a eat tet as 13
BARBADOS ©0020 cee SSaedetes spas Sha thn Mec tase oh eee escent aia lteh Shenae 15
BELGIUM ooo... Colts sendin aah nasal ce Spegiash stggu san uae sagt soea ne e-moase op ese onee 16
BELIZE peer ieMte sinter ihacy cnt Most hate taa tah aete Macscutael dk hance te Rae eet eaa tues anas Re 17
BENING giiesetes carla ch ate rt eon aoe sat eG iue anal os eur Batten atic geet a2 Bat Mods Su lasat sh ents 18
BERMUDA 4.520 utios cht Oe eet eho ad cpt ght oh ATOM eects heh ne fh al ih vnaeo te 19
BHUTAN ser eh Res tel ION SUG code Bal ads ie san atiyn even cicero nes sensed oleate ee 20
BOLIVIA: - cs.cveistcentiie dh deed chti we haeeny Ae Ae iA eae Plan Bie eed 21
BOTS WANA is cies iettett lat lel ai Se ald eee Ace ediead otto ah Ge a ees ithe 23
BRA Zs cee ated rate raatliiee cedectlgst sstcse osteo vstaual diem aie ateains Ooies ao eceton eatstonies soy Pas oo saab mbeohe take teeh ales 24
British Honduras (see BELIZE)
British Solomon Islands (see SOLOMON ISLANDS)
BRUNE | 26205 6 Sanauetipeecs age Pe i aesad ashe cues ent et end eens 25
BULGARIA. sscs23scesecaed eiadectes le tedaennnes Au eves anes viadatts anaes ae Fauey ane acamaeene dees Se beatae 26
BURMA 3:30.55 825 tied igen vis abecta cbt bi dette basil eaaeans ah awted ema chad paaeeses eee vals 28
BURUNDI: esos sot etl oe eterna netsh aad by deer atialh ane Satteasasent weemna Rt sade see steeds de 29
pen geet
Cabinda (see ANGOLA)
Cambodia (see KAMPUCHEA)
CAMEROON) cee Norcet a Sot Bo creatine de talelel Aitd eda ek edi i he tat oes Jed, aelraciowns 30
CANA DAT sips ctesss ct ra otaceatinaa naa Reese is areas tnt ee ee dare coaset a cay ate 31
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
iil
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
{
January 1979
ie Page
Canary Islands (see SrAIN)
CAPE: VERDE? oi see a A ah ea cy cana ali eons dhe catia deedbeades aiaay dai geiauala® 33
CENTRAL AFRICAN EMPIRE 0000.00.00. cece ceeceeceee cee ceeteeeceeeesetesesenstescsteteeseees 34
Ceylon (see SRI LANKA)
CHAD.............. sheet cele had ea Ne AN ants Pace tleta Coaches la bathe Cateye ME 35
CHILE: ttc Nahi tatu a inet ttre shred at NR i dec he cunts tetnetas dents Ataitt 36
GEINA® ocseecestisceaestiesteries acetal analeney onal alt old dead cat obhcand tie a, Oe ONG ae A eatin il et at 38
COLOMBIA 0s. cists cottons toe anandshae tum idee od ened dive otha dasr alee Malate 40
COMOROS 8 hs 8.2. Sinaia se ce oth atures Uaretoentts, crtvacetas ately ecdtenareneontautt Glee nt oe 42
CONGO (Brazzaville) oo cccccec cece tees t eee tices eesetcescasesteseesettesteetcereeeteres 43
Congo (Kinshasa) (see ZAIRE)
COOK ISLANDS: 2s ssa te eee tres rd teaeevnsencnbeal’ qidelincetehiseecdadis San aedtven alice 44
COSTA RICA: 2.3 chat ne ate oliteie et cake Adios reenter at ee inet ee ehttates & onmenatstalaieied 45
CUBA. si.) tisraestccat nateiyan dint vesw tale sale e Mee oy al atane ttle De Saris aaluinesteddeaieat es 46
CYPRUS sc cases tsetse tesa Seah Seen a estauling Goh a Ee desi ease eat htt teen atatty Ca A oa 47
CZECHOSLOVAKIA. sectscsttectissectacrevtalte teltneats ivesete Nie aise dane. dseie gles teitaev oie hana 49
—D—
Dahomey (see BENIN)
DENMARK). c0o.0 sinensis elcid Se eat scaraedea leh oe eeenns nts dead auetcad ab ideas 51
DJIBOUTI (formerly French Territory of the Afars and Issas) ..0..000.00. 52
DOMINICA ig cotielet SOM Ae oe autveswelatdusdasl fala ldure ensued bis glues tout db etbaicomeriubenemetetthe 53
DOMINICAN REPUBLIC ooo. cece eeeetenenseeceseeeetsetesnesetsetestesieeeiittsteeteniees 54
Dubai (see UNITED ARAB EMIRATES)
—E—
ECUADOR » css. ses. center Myernto teeta inabh eb tagenthanss Lente) niin Mie et: Advosecaeitivian tsvean asta ets 55
BON PT cs itacsttes tecdecesinauages chee faeaapanoreraiekase er Pale calves eed at asthe, Niudttdy Moot als 57
Ellice Islands (see TUVALU)
DiEL= SALVADOR ais ooo cd sate ie Maleacds, mode taecs catch teguaternsatdtann chdabie agian muutande alten ay 58
EQUATORIAL “GUINEA fo scsieet isidincasin tear Setonp mniisiecaniomedediadeddath dies ue 59
ETHIOPIA) fein) AOA Se idly 2 leh, Sead Sum ten oad Sti ole ak ha ta te lea bat Ul tase 60
a a
FALKLAND ISLANDS (MALVINAS) 000.00... ccc eer teteteeetenees Sot ciletiatoes tt 62
FAROE “ISLANDS 25 icc.tee cities saved ceyies ak ade aoe iit ate ais oat, SOA leeds 63
Fernando Po {see EQUATORIAL GUINEA)
BUI scittat set Shs a ace an vies en Ad Cetetecting Pay Ged cere lees ica stat angst day ocot Sees Cll athsselnr ea 64
65
66
68
69
Frénch Territory of the Afars and Issas (see DJIBOUTI)
Fujairah (see UNITED ARAB EMIRATES)
=G-—
GABON. «5 cecoss hilt dso uiintiaiass bs vb ettaeeU vel sasdass cog aeena ek ua ataACoe aM atau eR a ed yeteetoshiendeedse IS 70
GAMBIA, “THE: «2: co es3¢s 60, 8 vsosen atte tania io) heal ved pallens peak rapide dade pete or lands Meade 71
GERMAN DEMOCRATIC REPUBLIC ooo... tee ects ceee tee betesttitettttteneen 72
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
_ Page
GERMANY, FEDERAL REPUBLIC OF ooo... cce ents ccceceteeeeesenenieerens 74
GHANA. | e623: oh eradicating sscsdeceom dutta teens Hoes fogs heuskec eatin Maun Mic « Sereda igeuds aaadbear artes tied anna 75
GIBRALTAR scsi ceccocc Get oh ie Sd he Et th ae Mh CEL Beat oa ''ot lo caine halite, 76
GILBERT: ISLANDS tise 1a, hater arn Mies a es Sat Nia Ala d ules Sess Sta 77
GREECE ico 25 ion cae ten ale lA S belts filles veal sete Ads wpa ietides Seen shl ah kuiesbealt 78
GREENLAND» g23 cceneetan ey inl cree Aa at No eats Ananth at Ie 80
GRENADA: sti ie hi eM ag a Me Ngee A A a eh Sage Seti aa ted At hecho 81
GUADELOUPE® a. dcesscsecerdcitotncectanei mt ect ga steettenenta thoes acinde Me i ea or 82
GUATEMALA sesso heeceectheeghat Skee decors aves olette wtiaae ews alae eh dace cy el Ohl et hg, 83
GUINEAS: ssa a cesta lil nical a ehende iia oe 8s Mle eal Sahiess trl uM fucks flat kes Me us 84
GUINEA-BISSAU! 2 foie d ris oc aren once aia anced eA A ented 85
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA oes MLN ae, earl 200 otal con Set Ms oleh eS laa See Sol alas a eat Se 86
—H—
PHAT oes scsi ates eA ln A Me eid oe eM oil, Bansal lak A ek Gah ates at en Sale 88
HONDURAS whe cesescss te aoded Weseibartalaceltee Meat hice alt absageady vt shneeraetedatatantaestvh reek haat ds 89
HONG” KONG §o5.0 scl ot ose antettent ts dates tote eerie ald. Sag veda Aides Jucoddnduntiidl otugedveidas Souls 90
HUNGARY, once caresses ios id ce ie Arrested eth eta OO aha cies fo Fas 91
ye
PETRI te tara ict ete eerie etcneesene e e Tit ck atl, 93
IN DIAS? oslecesescetctl neg el tet cause hacen see Dalle Bal tae tel A onal Je ne tne as 94
INDONESIAS sie:8.82.cechiistote ccs rita tate aden en odeaG Molen hd tn dette eels 95
VRAIN ish oF sa ctee Ph ettet ladies eld Mactan sail oclecotentean tes teelev ale tns Delta cea os Taw ean urge chasuetucn dite 97
NRA QS a ecaicistcctashuces stat cette awn cecleneatantieeerie id Mubuce alot hated ta weuta lan att tie cadets 98
IRELAND yc iectre ct scceh ted clic tte cr ned Sis vata a cuc don fats ain sac shemales tnt hea ehcp us Gas el dat 99
ISRAEL, ~oeicsg ce scien cocecunt evetsn tate eed con de da adn aren ee wears aeauae ee Aeine 101
VEAL s soc ho oan reve aera narsaee tant odd adi tact cee eyes Me testa hate oe RSE ate A Packs Ys be 102
IVORY SCOAS Terncstis ceteris sek ai aie ee ei lest rte i teens tet Al on tases da eel ad 104
ee ae
JAMAICA 6 crises techs tat Sele teal tll tc ad th UCM CN oe atte detec tin eect ol 105
JAPAN gsshecees a speeeeste ates ieactorend sialyl, Me dedi ta cien died lew tad NO aed cude cess saetttvaeceldiaamuanenaites 107
JORDAN cis 55 ocho peas ha socaceceantect ens cs saat teerens dade Mets adt dbl eet tin satle ia atdal eben hte 108
an ae
KAMPUCHEA (formerly Cambodia) 00.00.0000. cccccccccccccccccccccceeeseeetensttuctserevenseeees 109
KENYA ost hal lei tne cute Legh ae eR! iS hialn bh oN chk ch bate leet nthe alls Mac, 110
KOREAS. “NORTH: sides 220% inchs Bais caked eeesec tetas lat cn hedheca tet cansl gullhc Sl data tn iaae 112
KOREA SOUT sie oc eg soda Be ened lS screnutdald cust dep mies oee eh Gaia Leos 113
KU WADE is teases ec d nar emettenle, tthe okt tah TS, ot hile SIM oPalenrpns Mats wa wea cee Mk 114
p=
EA OS +2 resonant neal sated a cates Sock ey ee ane teeh uct naden Soceiehs Alan Ai ha ie hee cnet aE, 115
LEBANON i! essstiac alice gai actntalee MN aol Cale peas deeleg oie wet ai hd, ONG da ARAM AAD aol 117
ESOT Oct eA RG taste sta aici Prd Sacto f MRE EE eR A Ae 118
LIBERIA S c0ts i425 27, Casei a mira tiacl stax neve aes mega Mateos hae Ne eo 119
PAY ikeShict ihe atin cyt tele cbt eclectic hah Mode eh col clon tendadt 120
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Sofi Page
LIEGHTENSTIEIN: crete seats eis 8 i gS finacaleiennctaars peat dy lne dv aveh to slams cont dane és 122
LUXEMBOURG ideo ee ee ERA Ged a ih da ld of dhe wad eee bi ata Mog 123
Me
MACAO sie Second otingtauidess cack cdc oen fess nt obs cela rest aoeie ect dead eg etait Sarah Ae ont sett aad Be 124
MADAGASCAR: <stehcchit Wont ANS ac islet lata Ek, oe case He Mee a eal eas, a 125
Madeira Islands (see PORTUGAL)
Malagasy Republic (see MADAGASCAR)
MALAWI he oA ecieek ea oe Oe ia, ald te ehh ie duty watie al alee ah CN oh 8 od Dates ia 127
MALAY STA. ei vgeticscs aCe 8 te hese Naat t ia) Rees Mae a Ee eee tha ciate 9 dah ete bent nl oa 128
MALDIVES :< gectrssonencsteitenvndteaidile becdainn Qs Didnt stem dH vielen Gramagie vant medi ne ted nraeon sens 130
IA BRED, oasis he ee ee cn tencoe ase atts aed ns Rae ca Ves Peels ek eat es dk A OM Soke cles Pentlcaetace ante Sea 131
MALTA: 2 oe naher ds es ee peaball inten ae ces Masta teat amauta Maevthh tl adswetutatundt a taste uel es Se 132
MARTINIQUE. cote loci inteiash Aah cestiih dais ed ehh Mle iene cel ahd A a a en sh elie aaa 134
(MAURITANIA 005.050 .s0e-get peed aceaereaibes beaten at cavanseesi eciedtouneas dase EE aR erent ee 135
MAURITIUS rt cca ten eel od ace ddl hae hast Mokau Lat teed ol | ele bth ot oadad Stud hand os 136
MEXICO seis cnet siectis ei veraa one desc stv eye ou bach ec cesat (Al aceres aber te heater hae clcteae DANIEL 2 137
MONACO esseolctetee tins tesa habatestincs nah des Wheaten ocsis nasctaa th irsityn cana auditlas ta adeeme tes oacuennaads 139
TAOS QUA eres Nahe rah rea taleculiyn Sunnah Mie A caleta en te hema ead 140
MOROCCO™ oa gei etch tec tavicnco laters beds cas bite buasebh ayd Sdoeatephcat ualdolenduansiayeteexiatlin bAietsats 14]
MOZAMBIQUE 3: 3 cre Boch tasies Bee taes tenia dee ox visage wabehiudl esnptan satel Geaednade uae aabeieerronsss 142
—N—
NAMIBIA (South-West Africa) ......cccccccsssssssssssssssssvsssssivesstvevtssssssessevsesevesessveeseeee 143
NA UR sore: aon naan tats uscmesincnattlan scbteaw sobbing eos! ecause trae add uns svatengtieeal tea edies wletenncayse 145
INE PAD Foor oiteen te Oi eacten Sena eideenta cowl a de AEN i dR ten SNe aac AE re cl fe ht an So Nek 145
NETHERLANDS ©6035 ca tec8 cs eeaesapaa deca viet Quebec vce eee Se cir ov ened cetsghe Reveomaeleatedn 147
NETHERLANDS ANTILLES 200i ccecennteeercivapeeveneteesenetecenrateess 148
NEW: :CALEDONIA®: 35-c.detenaa citer vleeten ected sta Aad dedeatuedi us en teh kN es 150
NEW HEBRIDES: je) be chu nee clltaktd waa heel oh wo Stash Ne lay evuoneuagda baat Rates 151
NEW ZEALAND uu Sea teh es dae stoop estes hain Rae kadai cea tha hte 151
NICARAGUA 4) sce casasere creshontntsaele hdl Obie, os Se tdaatds gud iudia nye mea alesinma ne beevaatenaes 153
IER fia as easier see careee sanity tc Aevaceit pace Deena tea ea natal aes matted rs acon dh 154
NIGERIA ooo. Soa hiteath dauslnsts bem teu eden Medtids ten netneenierotdan Men ads. 155
Northern Rhodesia (see ZAMBIA)
BUA asst relies yt Caceres ee SOO et hte een eh alae eah 157
—o—
OMAN 95 ccse aise aoaereisteaviet dette ecraeed cence alates dae eae eauented dl aeaetitan iota cin aie 158
—p—
PPAKISTANG: dices. t5e copped oceiaa cde niu te sna press tghian dues seisdewcensastiete na @iaspeegs Seuinbbre Gadseanthsaenandasheene 159
PANAMA «2th cichictteitats tie 9 Ed eee Mel a eo AG Se cua eiys Mnonadense stegttaces audios 160
pa
PAPUA NEW GUINEA. ooo occcccccccccccccccecsecceceseceevessevevtnevevivsvevesevetevebevevevetbeevees 162
PARAGUAY © ec ccdcecsltet ences Reaphioat Seon veatia cable eh verghtiesleh hfs deleediebSla ie Louledes aevedeeaguauanbetecn cubes 163
Pemba (see TANZANIA) ge
PER ae ee ee rehce a cna ured RN coh Saat Mera et Meter tiued: Tasaand alt Maceo tOtudy Gholi 164
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ips Page
PHILIPPINE Sic ccsocsees su ssneyn cactereeaeh ete ene sauennere that eounald sh tats he i aee ln a Relate cvs edieaaats 166
PORAIN Di sreestcisesss55. nase aap des Oost neg ih Gasca pce eee esata eer cla ltt 167°
PORTUGAL ccc Mentors a tunnie Bea id le neti a Rote Sane ete Pa atecbe ss 168
Portuguese Guinea (see GUINEA- -BISSAU)
Portuguese Timor (see INDONESIA)
GO
RT ceca epee anaes ee agers aN aetae taelaes 170
ip
Ras al Khaimah (see UNITED ARAB EMIRATES) _
RECRUON 2.3 matdvssiteacenrna isin tecncaun Gaeee YAN il dl beast vasenmnamnlal alacant hay 171
RHODESIA? 32. ccbswsennes eee RSet lek ae Ste Mag sed eae aie ig baad hic densete nee Mula eeieciens 172
Rio Muni (see EQUATORIAL GUINEA)
ROMANIA 2 derhs referee ete ete ieee cota Seances ate een nee 173
RWANDA ci, fulinntrairsneliainauet cineca ada he Baa tant Beads 175 —
—s—
ST. CHRISTOPHER-NEVIS-ANGUILLA ooo... ect e te vtetetetttenetetes 176
és STs LU CIA. te A tiacke Saag cere iia G cxevec hina ee avila kaa ean Gace Pccanetech aerbeoncltclnl DS, ‘177.
Sie MIINGENT sigetnsttiasinabas oldie taa sa lacey eden tere irae aeeheneati tha vananiedigaeabtsytecestes 178
SAN: MARINO? soecctcscklenes.cerlvac et ueavaese deere Madi ected tbnatrddy eek Wass bet es Mea 178
SAO TOME and PRINCIPE oo... tec et cect teeter ct tteteesfetcteritsttterneeee 180
SAUDY ARABIA 2 S echcciess taazases ae atts greta cuithl ashe chisiehz ts beaais ined lur hotasei is “181
SEINE GA scien eae uest akg tas nes Mea ee Teed naeats feasted mqsoh occ td eslog sna soot co ensta asad apenc Bae 182
SEV. CHELLES: ei, Fe tectaud cnc auctiiay doacle ttt pt Riad au2t veins selma diene staal satdv ent ta votanaescbamertaat eaten 183
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE Seat : 184
SINGAPORE: 535 sores secdrnsipet alent Bhareshtyiatonicstuadn del iaaueeneana sa es : ce “186 |
SOLOMON ISLANDS (formerly British Solomon Islands) © .0.2!2.0000 oh. .. 187
SOA IA aoe eet Os GB a Sl dete veg ue Me naurtena iarnigr on Geer snenetiees Se One ee 188°
SOUTH ABRIGCA coerce cused Mhe haath Batu coheed amt Lak 4 den ha fod, and deb Galt dee 188
Southern Rhodesia (see RHODESIA)
South-West Africa (see Ee ca
SPAIN 2c: Sevccehacnaisaageceoneaadivechegete diced alan oh A ie MP a1 loot aes es totaled a tae -191
Spanish Sahara (see WESTERN SAHARA) : vey,
SRI LANKA (formerly Ceylon) oo... ccc ccc cece ette ete ee ee ceececteeetesecnsesteentiesteectees 193
SUDAN © 2eccds sswin nadine, daidqubetticimiss teeta odintes dee Rnd cde ena rasa Mas eedbaeiio ma? - 194
SURINAME 665. ddessSdavrsnaden nbn Te ended GGG UNO se Pe Sa opt 196
SWAZILAND rsa secassca tes i veatay esses hen aah ahve stars Leen opsictaacts Soy ceelle haces sven
SWEDEN? fee cnineiieraceatciei aoe eran Aad eaens Datel ne eesctuds eee 198
SWITZERLAND: ete tet cone ath hed did Se ad foe pa uated a amet abate ah .... 200
SYIRUA 15.2255 fabccnsica sgt setae eae areas ga dS ooalgas tek aakyaetee Haass ea detaaeeetaa elite M eddn papemaaaneeeAneeaniares seace: 201
a
TELIA WINE soe treo tcacsadea es ok Ecce ae, Saati dotcent ane aN leat od aaa ees 202
Tanganyika (see TANZANIA)
TAINZANIAS ono re tice te tet 8a ads Oe hae csc ln 2 Cac das Wee aR Nia aes tc aa a 202
Tasmania (see AUSTRALIA)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
pa cae Page
THAILAND ® ec toed ese slchte des eta hdgils BOdriahs Pea awed ag ifs te ae heeded ti oh caine se aeneecnens 204
TOGO serena hiieets asthanneiaie at Be ees 2iar elena lh ial, tt AEN at cul At ule Gic ON kel dalle lea te Et 205
TONGA? seine ciety a bPentag ces hemes pec te te dR Cant Ste wie fa Mah 206
Transkei (see SOUTH AFRICA)
TRINIDAD “AND: TOBAGO: gros. cc sn ssteterncteanntearies etashsdideed eeaaetl ive dhdeaaturedtads 207
TONS IA ch sash sta ay Cte ciae ane nee ah yee aa geri epancaes pele wee eee 208
TORRE tbl rut ca ssten sitet etna Maeno tin tht Sa shad UM toe deed Ide ant ee Ciath de a A AA 210
TUVALU (formerly Ellice Islands) 2.0.00... eeeeeetecsseteepenseeettenteetecnsenes 211
—y—
UGANDA? osc5 Zonta sd Sate atte net gs te ca cate ata ttl ae an cantinedbenten: 212
Umm al Qaiwain (see UNITED ARAB EMIRATES)
USS eRe chao sean a anatt southern ateite decid Ran apni Ne weet Mts lahat anil eR i Uae, bee da 213
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain ooo... ccc 214
United Arab Republic (see EGYPT)
WINITED: KIBIGDOMG sccscaas ht slasatts-cctstaa ly adees dayashe teacnemnutmne eo eamenends 215
UNITED: “STATES, 2233s toh acts eeect aries lee dev aie Nenths iee cern aed ea hae dent 231
UPPERS VOLTA istic Ws Te lode 1 PSR oat deta oie ht ED Akl ais 217
WRUGUAY® cs ctttesieat nec teenie ain oat Sea PAU celine nee SR deca saasi dol eedeteen ton 218
—Vv—
VATICAN ES CITY = Shcgs xectates tenis atta a ea ied athale, Bea arcs canon 219
VENEZUELA 3, -45.}ocsagasdsacepstochacatsctencdteaihotsent da obanvesidGhee ple baiuetiushvals daadeetesla td eoeieton tls 220
VIETNAM o.cccccceeeeeeteeeerees Tate heat ies estteee cases Oa CARNAL A ad 221
—w—
WALLIS: arid? FUTUNA: soccccsincseecsosneesias scales Causudeegesnatansenierseninncduencanasdeatendeveevuseanspacengs 223
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara) .......0..0.. ccc eeteeeeee 223
“WESTERN = SAMOA: 3205.20: 8so.onincces ew are ten Pelee Oe ota betes aia Sedpaesne aed: 224
a
NEMEN:= (Aden) ossescssc:.acr3: ausuace snots coetsentery feeaaauetenaae ce eeah eta le pe ate Dl bl all 225
YEMEN (Sanna) © 9) cotse5- Soren lie ee eet aden ur Ta an tu eeneecaataien hee 226
YUGOSLAVIA? os asia het ere cehtel eh, ial ue MRA te a Racal uta aed det lets A 227
—7=5
LAIRE oe, isc 2st ster ithe tect al ih Salse MLS itde ht RAIN Leg, cal tdires ot events Seas rte thai 228
ZAMBIA cceicsecciter a tate rencncidi eld ee ie ee ee 08 aioe ee ease eects 230
Zanzibar (see TANZANIA)
Vili
ee ee ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Se eee eS ee ne EO ey eee 6a 8
Oe et ee gee Oe Se oie SA ee ee ee Se ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Vill
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
MAPS','fc55bb8284f3122e48f2449d5b97d3eb204b50cbba30635e185ddd78b07ad7db','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc2b742278c772b7e8ff88be96404b01804d47b186de54f31cd2644559fd1c78',1972,'CA','Canada','raw',2,'. MIDDLE AMERICA
SOUTH AMERICA
EUROPE
THE MIDDLE EAST
AFRICA
U.S.S.R. and ASIA
OCEANIA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
AAPSO
ADB
AFDB
ANZUS
ASEAN
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECOWAS
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
G-77
{ADB
ICES
IDB
IEA
IHO
IPU
IRC
LAFTA
LICROSS
NAM
NATO
OAS
OAU
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
Afro-Asian People’s Solidarity Organization
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand, and the','9615eaeba672b95a00c73cb071438af636e2d49a0ddf519274f8e8b75e040f56','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('253a0f64d5334bb91d3b51f019a8ee101c7faa837ba4aafb4342ec26028d3c8f',1972,'US','United States','raw',3,'Association of Southeast Asian Nations
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market *
Caribbean Free Trade Association
West African Economic Community
Council for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Community of West African States
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Space Vehicle Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey, Niger, Upper
Volta, and Togo :
European Space Research Organization
European Atomic Energy Community
Group of 77
Inter-American Defense Board
International Cooperation in Ocean Exploration
Inter-American Development Bank
International Energy Agency (Associated with OECD)
International Hydrographic Organization
Inter-Parliamentary Union
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
Non-Aligned Movement
North Atlantic Treaty Organization
Organization of American States
Organization of African Unity
January 1979
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Pe on
|
EE ME Ee a eg
Ee Oe Oe a eee ee er ee EN ee See, a ae ae ee, oe
a pe ae es
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
OCAM
ODECA
OECD
SELA
UDEAC
UEAC
WEU |
wPC
WTO
AIOEC
* ANRPC
APC
ASSIMER
CIPEC
IATP
IBA
ICAC
IcCCO
ICO
1IOOC
ISO
ITC
IwC
IwC
OAPEC
OPEC
UPEB
WSG
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Afro-Malagasy and Mauritian Common Organization
Organization of Central American States —
Organization for Economic Cooperation and Development
Latin American Economic System
Economic and Customs Union of Central Africa
Union of Central African States
Western European Union
World Peace Council
World Tourism Organization
!
‘COMMODITY ORGANIZATIONS
Association of Iron .Ore Exporting Countries
Association of Natural’ Rubber Producing Countries
African Peanut (Groundnut) Council
International Mercury Producers Association
Intergovernmental Council of Copper Exporting Countries
International Association of Tungsten Producers
International
International
International
International
International
International
International
International
International
International
Bauxite Association
Cotton Advisory Committee
Cocoa Council
Coffee Organization
lead and Zinc ‘Study Group
Olive Oil Council
Sugar Organization
Tin Council .
Whaling Commission
Wheat Council
Organization of Arab Petroleum Exporting Countries
Organization of Petroleum Exporting Countries
Union of Banana Exporting Countries
International
Wool Study Group .—
xi
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc Security Council
GA General Assembly
ECOSOC Economic and Social Council
Tc Trusteeship Council
ICJ International Court of Justice
oe ales Secretariat
Operating Bodies:
UNCTAD U.N. Conference on Trade and Development
TDB Trade and Development Board
UNDP U.N. Development Program
UNICEF U.N. Children’s Fund
UNIDO U.N. Industrial Development Organization
Regional Economic Commissions:
ECA Economic Commission for Africa
ECE ‘Economic Commission for Europe
ECLA Economic Commission for Latin America
ECWA Economic Commission for Western Asia
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization |
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development (World Bank)
ICAO International Civil Aviation Organization
IDA | International Development Association (IBRD Affiliate)
IFAD International Fund for Agricultural Development
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural Organization
-UPU Universal Postal Union
WFC World Food Council
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Ne alt
ALK i te OR LT ce eR Nh lh
ea ee ee
AL
ee er ees
Se =e
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Political, sociological, and economic data, including monetary conversion rates, generally
reflect information through mid-October 1978, except for population estimates, which have
been projected to 1 January 1979. Military manpower estimates are as of 1 July 1978 except .
for average number of males reaching military age, which are projected averages for the 5-
year period 1978-82. Military and communications data are as of 31 October 1978 unless
otherwise indicated.
Most of the land utilization estimates are rough approximations, and most of the
statistical data are rounded (thousands and millions). Figures for ‘arable’ may reflect only
the area actually under crops rather than the potential cultivable. Fishing limits are included
only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference between the two is
in the addition or subtraction of the value of return on foreign investment. GDP equals GNP
plus income earned in the country but sent abroad, minus income earned abroad but sent into
the country. GDP thus tends to exceed GNP in debtor countries, and the reverse is true in
creditor countries.
Mogijor ports are the largest maritime ports of the country, relative to other ports of the
"same country, on the basis of estimated port capacity, alongside berthing accommodations,
Declassified and Approved For Release 2012/09/02
and commercial or naval importance. Minor ports are the remaining ports of a country which
have, relative to the major ports, significantly lower estimated capacity, fewer alongside
berthing accommodations, are of less commercial or naval importance. Major transport
aircraft are those weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The dollar sign refers to U.S. dollars unless otherwise stated. The abbreviation FY
stands for U.S. fiscal year; all years are calendar years unless otherwise indicated.
Approximate Metric Conversions
Symbol When You Know Multiply by To Find Symbol Symbol When You Know Multiply by To Find Symbol
LENGTH LENGTH
mm millimeters 0.04 inches in in inches 2.5 centimeters om
cm centimeters 0.4 inches in ft feet 30 centimeters em
m meters 3.3 feet ft yd yards 0.9 meters m
m meters 11 yards yd mi miles 1.6 kilometers ken
km kilometers 0.6 miles mri AREA .
AREA in? square inches 6.5 squate centimeters cm?
cm? = square centimeters 0.16 = square inches in? 1? square feet 0.09 = square meters m?
m? square meters 1.2 square yards yd? yd? square yards 0.8 square meters m?
km? — square_ kilometers 0.4 square miles mi? mi? square miles 2.6 square kilometers km?
ha ___hectares (10,000 m?) 2.5 acres acres A hectores ht
MASS (weight) MASS (weight)
qa gram 0.035 ounces oz oz ounces 28 grams 9
kg kilograms 2.2 pounds Ib fb pounds 0.45 kilograms kg
t tonnes (1000 kg) Ww short tons short tons 09 tonnes t
VOLUME ; (2000 _Ib)
vi
mi milliliters 0.03 fluid ounces fl oz OLUME
'' liters 2.1 pints pt tsp teaspoons 5 millititers ml
t liters 1.06 quarts qt Tbsp tablespoons 5 milliliters mi
{ liters 0.26 — gallons gal fl oz fluid ounces 30 milliliters mi!
m cubic meters 35 cubic feet fr? c cups 0.24 liters t
m? cubic meters 1.3 cubic yards y@? pt pints 0.47 liters i
qt quarts 0.95 liters |
gol gallons 3.8 liters t
fr cubic feet 0.03 — cubic_ meters m
yd —cubic_ yards 0.76 — cubic_meters m
: CIA-RDPO8-00534R000100140001-7
a Fe 7
a a a A at al ot i a ee el a el cre i a er tiene En i ae lial
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','a32968c870199c289b3b271d5fa240e1933f518df63a3c7b90d1e4f7661a5b6a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dd4d1e3a726573fcdc2154b163bcda8ee34df700de5d22729397d5e8b5c6d66',1972,'AF','Afghanistan','raw',4,'Arabian Sea
(See reference map Vil}
LAND
647,500 km*; 22% arable (12% cultivated, 10% pasture),
75% desert, waste, or urban, 3% forested
Land boundaries: 5,510 km','f60ee5b8a2b1360e99c3a106ddecf009d8afe9f6e38cc5b49468403ba0922e7e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

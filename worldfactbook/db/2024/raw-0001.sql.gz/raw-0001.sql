SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7103110bdc1b910d1db8dbced379267ef6a818286f20326476e3a3e881c6c0b9',2024,'','','raw',1,'theworldfactbook_en_all_2024-05
texts
opensource
CIA
2024-05
CIA The World FactBook May 2024<div><br /></div><div>kiwix zim format</div><div><br /></div><div>best viewed offline or with the Kiwix-javascript viewer</div><div><br /></div><div>https://kiwix.org</div>
eng
https://creativecommons.org/publicdomain/mark/1.0/
Internet Archive HTML5 Uploader 1.7.0
CIA
CIA THE WORLD FACTBOOK
World Factbook
Kiwix
iwanttobeagmo@gmail.com
2026-02-06 07:36:22
2026-02-06 07:36:22
[curator]validator@archive.org[/curator][date]20260206074228[/date][comment]checked for malware[/comment]
http://archive.org/details/theworldfactbook_en_all_2024-05
ark:/13960/s2wv1tqq7j3','dfd2f1dce4f024710939b8996e7b98380faf202495c72ed9e529ca29399be964','internet-archive','theworldfactbook_en_all_2024-05','xml','e56dd1cdd5bfd6ea4d5c39a04a21e09ea2d3bb66846e124696c9bda89812a3c6','https://archive.org/download/theworldfactbook_en_all_2024-05/theworldfactbook_en_all_2024-05_meta.xml','xml') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

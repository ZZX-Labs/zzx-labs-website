SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd2faec88d91b73e22376fbc6ee2e14e43f19b3face884f151ff82c907d692f5',1965,'','','raw',1,'JOHN H. BUCHANAN, JR. ADMINISTRATIVE ASSISTANT
Wit Disrrict, ALABAMA JAMES T. AP? =
Approved For Release 2004/07/08 : CIA-RDP81MO0980RO0080008001Z-tesunes
MEMBER;
WASHINGTON, D... 20519
wrensehithatmerinens Congress of the United States ceca
SUBCOMMITTEES:
IMEDIASIONAU Oren AniONs House of Representatives chnoe Ne a onces
eoUSeMMT TES ON on Washington, D.C. 20515 peoenlepenen testa
SUBCOMMITTEES: ee eee 35203
ELEMENTARY, SECONDARY AND 17 October 1978
VOCATIONAL EDUCATION
POST-SECONDARY EDUCATION
COMPENSATION, HEALTH, AND
SAFETY
[¢ on eerie tat
amen 9
[ #78 3547|
COMMISSION ON SECURITY }
AND COOPERATION IN EUROPE F Lease
A pee )
Tce of Legtstative Counsel
STAT
Central Intelligence Agency
Washington, D.C. 20505 -
Please be so kind as to forward me the following publications:
China: International Trade, 1976-77, ER 77-10674, November 1977
China Oil Production Prospects, ER 77-10030U, June 1977
China: Real Trends in Trade with Non-Communist Countries Since 1970, ER 77-3.9477,
October 1977
China''s Economy, ER 77-10738, November 1977
Foreign Trade Organizations of the People''s Republic of China, CR 77-10303".
July 1977, wall chart
Chinese Communist Party Organizations, CR 77-13125, September 1977, wall chart
Foreign Affairs Organization of the People''s Republic of China, CR 77-1284.
June 1977, wall chart
Military Organizations of the People''s Republic of China, CR 76-12748, June 1976,
wall chart
Organization and Management in the Soviet Economy: The Ceaseless Search for
Panaceas, ER 77-10769, December 1977
Prospects for Soviet Oi] Production: A Supplemental Analysis, ER 77-10425,
July 1977
Reconciliation of Soviet and Western Foreign Trade Statistics, ER 77-10132, May
1977
Prospects for Soviet 011 Production, ER 77-10270, April
Soviet Economic Problems and Prospects, ER 77-10436U, July 1977
The Soviet State Budget Since 1965, ER 77-10529, December 1977
USSR Ministry of Freign Trade, CR 77-13114, June 1977, wall chart
Directory of USSR Ministry of Defense and Armed Forces Officials, CR 77-129°0,
~ May 1977
A Dollar Cost Comparison of Soviet and US Defense Activities, 1966-76, SR 7i-
10001U, January 1977
Communist Party of the Soviet Union (CPSU) Central Committee: Executive and
Administrative Apparatus, CR 77-13211, October 1977, wall chart
Communist Party of the Soviet Union (CPSU) Politburo and Secretariat: Positions
Teas and Responsibilities, CR 77-10225, January 1977, wall chart
‘= USSR Council of Ministers, CR 77-13213, September, 1977, wall chart
Communist Aid to the Less Developed Countries of the Free World, 1976. ER 7/-
10296U, August 1977
Approved For Release 2004/07/08 : CIA-RDP81M00980R000800080012-3
STAT
Approved For Release 2004/07/08 : CIA-RDP81M00980R00080008001 2-3
The International Energy Situation: Outlook to 1985, ER 77-10240U, April 1977
International Terrorism in 1976, RP 77- 10034U, July 1977
Major Oi] and Gas Fields of the Free World, ER 77-10313, June 1977
Natural Gas, ER 77-10062, February 1977
Nuclear Energy, ER 77-10468, August 1977
World Shipbuilding: Facing up to Overcapacity, ER 77-10678, November 1977
World Steel Market: Continued Trouble Ahead, ER 77-10351U, May 1977
National Basic Intelligence Factbook, published semiannualy - January and July
Please forward the above to the attention of Martin William Christie, my Research
Assistant. =
With kind regards, I am,
ceapenainc tain arate rel aa At ta
TT ee See
VY Member of Congress
JHB:mwec
Approved For Release 2004/07/08 : CIA-RDP81M00980R000800080012-3','57e2d65a3d1a7b65649c31f0482df3fe68341468653000bb74e21bed8d708c86','internet-archive','cia-readingroom-document-cia-rdp81m00980r000800080012-3','txt','58a039c8d41af2d2d5a757b93e0507ac5efba591c154be887035ccb0573a3b41','https://archive.org/download/cia-readingroom-document-cia-rdp81m00980r000800080012-3/cia-rdp81m00980r000800080012-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25585542cc52ff6798da062ac0dff7e0323ed31bd125356975094c37e8682a58',1965,'','','raw',1,'STAT
STAT
JOHN H. BUCHANAN HOVved For Release 2006/07/27 : CIA-RDP81M00980R0012000 1 002 4ug snare sesicrawr
6rH District, ALAg. ES T. APPLE
24159 HAYBURN HOUSE
OFFICE BUILDING
MEMBER:
WASHINGTON, D.C. 20515
nrentitenaincinens — Congress of the United States ae
SUBCOMMITTEES:
Neuen House of Representatives CAROLYN F, GOLDEN
COMMITTEE ON Washington, D.C. 20515 ROOM 105, FEDERAL BUILDING
EDUCATION AND LABOR 1800 FIFTH AVENUE NORTH
BIRMINGHAM, ALABAMA 33203
SUBCOMMITTEES: 205-254-1525
ELEMENTARY, SECONDARY AND 17 October 1978
>
VOCATIONAL EDUCATION
POST-SEGONDARY EDUCATION _
COMPENSATION, HEALTH, AND Nhe a ve ce Sore Ta
GLO 4678. 3507 |
Ree es be era ae
ce tg tae
COM MISSION ON SECURITY
ANID COOPERATION IN EUROPE ry
[ spect
Office of Legislative Counsel
Central Intelligence Agency
Washington, D.C. 20505 -
Please be so kind as to forward me the following publications:
China: International Trade, 1976-77, ER 77-10674, November 1977
China O11] Production Prospects, ER 77-10030U, June 1977
China: Real Trends in Trade with Non-Communist Countries Since 1970, ER 77-10477,
October 1977
China''s Economy, ER 77-10738, November 1977
Foreign Trade Organizations of the People''s Republic of China, CR 77-103037,
July 1977, wall chart
Chinese Communist Party Organizations, CR 77-13125, September 1977, wall chart
Foreign Affairs Organization of the People''s Republic of China, CR 77-12843,
June 1977, wall chart
Military Organizations of the People''s Republic of China, CR 76-12748, June 1976,
wal] chart
Organization and Management in the Soviet Economy: The Ceaseless Search for
Panaceas, ER 77-10769, December 1977
Prospects for Soviet 017 Production: A Supplemental Analysis, ER 77-10425,
July 1977
Reconciliation of Soviet and Western Foreign Trade Statistics, ER 77-10132, May
1977 —
Prospects for Soviet Oi] Production, ER 77-10270, April
Soviet Economic Problems and Prospects, ER 77-10436U, July 1977
The Soviet State Budget Since 1965, ER 77-10529, December 1977
USSR Ministry of Freign Trade, CR 77-13114, June 1977, wall chart
Directory of USSR Ministry of Defense and Armed Forces Officials, CR 77-12060,
'' May 1977
A Dollar Cost Comparison of Soviet and US Defense Activities, 1966-76, SR 77-
10001U, January 1977
Communist Party of the Soviet Union (CPSU) Central Committee: Executive and
Administrative Apparatus, CR 77-13211, October 1977, wall chart
Communist Party of the Soviet Union (CPSU) Politburo and Secretariat: Positions
am and Responsibilities, CR 77-10225, January 1977, wall chart
~ USSR Council of Ministers, CR 77-13213, September 1977, wall chart
Communist Aid to the Less Developed Countries of the Free World, 1976, ER 77-
10296U, August 1977
MORICD
Approved For Release 2006/07/27 : CIA-RDP81M00980R001200010024-2
Approved For Release 2006/07/27 : CIA-RDP81M00980R001200010024-2
~ | |
The International Energy Situation: Outlook to 1985, ER 77-10240U, April 1977
International Terrorism in 1976, RP 77~ 10034U, July 1977
Major Oi} and Gas Fields of the Free World, ER 77-10313, June 1977
Natural Gas, ER 77-10062, February 1977
Nuclear Energy, ER 77-10468, August 1977
World Shipbuilding: Facing up to Overcapacity, ER 77-10678, November 1977
World Steel Market: Continued Trouble Ahead, ER 77~10351U, May 1977
National Basic Intelligence Factbook, published semiannually - January and July
Please forward the above to the attention of Martin William Christie, my Research
Assistant. 2
With kind regards, I am,
canmpgiasiact 2 AREA toe RA tere
ona
i JOHN H. BUCHANAN , JR.
Member of Congress
JHB: mwe
Approved For Release 2006/07/27 : CIA-RDP81M00980R001200010024-2','fad573bde251161d8947a76d3aa3c8c779b6bf3dc101cb7b04460480bbb11717','internet-archive','cia-readingroom-document-cia-rdp81m00980r001200010024-2','txt','d24b7c0c382760c2686c95249101cd60a17fd7ec6a03d1809928c37288c9e361','https://archive.org/download/cia-readingroom-document-cia-rdp81m00980r001200010024-2/cia-rdp81m00980r001200010024-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('773d3f47c4dad42f60fc7e254dda4488160e55d01fe4b16e4d964384c6414073',1965,'','','raw',1,'J. BENNETT JOHNSTON
Rech ae Approved For Release 2004/07/16 : CIA-RDP81M00980R000800090047-4
Wlnited Blates Senate —|_ WS HIRI Z|
WASHINGTON, D.C. 20810 wy A w
7 jf Hope 4 a ay
JatheHe 7
{=
October 10, 1978
Congressional Liaison Office
Central Intelligence Agency
Washington, D. C.
Dear Sir or Madam:
It has recently been brought to my attention that there are
a number of publications available for use by Members of Congress
and their staffs. I am enclosing a list of materials I would like
to receive and would appreciate your forwarding these to my office
as soon as possible.
With kindest regards,
J. Bennett Johnston
United Stafes Senator
JBJ: Sbb
Approved For Release 2004/07/16 : CIA-RDP81M00980R000800090047-4
Approved For Release 2004/07/16 : CIA-RDP81M00980R000800090047-4
The Cuban Economy: A statistical review ER 76-10708
Prospects for Soviet 0i1 Production ER 77-10270
Prospects for Soviet Oi] Production: A supplemental analysis
ER 77-10425
Reconcialiation of Soviet and Western Foreign Trade Statistics
ER 77-10132
Soviet Economic Problems and Prospects ER 77-10436U
The Soviet State Budget Since 1965 ER 77-10529
USSR Ministry of Agriculture CR 77-11900
A Dollar Cost Comparison of Soviet and US Defense Activities
1966-76 SR 77-1000]
Soviet Long Range Energy Forecasts A (ER) 75-71
The Soviet Grain Balance, 1960-73 (ER) 75-68
Communist Aid to the Less Developed Countries of the Free World
ER 77-10296U
The International Energy Situation: Outlook to 1985 ER 77-102401)
Major Oi] and Gas Fields of the Free World ER 77-10313
Major Petroleum Refining Center for Export ER 77-10140
Natural Gas ER 77-10062
Nuclear Energy ER 77-10468
Handbook of Economic Statistics ER 76-1048]
An analysis of the Cyclical Dunamics of Industrialized Countries
PR 76-10009
Major Oi] and Gas Fields of the Free World ER 76-10481
Methods of Constructing Economic Indexes from Incomplete Data A
(ER) 74-64
Profile of Violence: Analytical Model PR 76-100025
Approved For Release 2004/07/16 : CIA-RDP81M00980R000800090047-4
Approved For Release 2004/07/16 : CIA-RDP81M00980R000800090047-4
22. Potential Implications of Trends in World Population, Food
Production and Climate OPR 401, August 1974
In addition, please add my office to your mailing list for the
following serials:
1. Economic Indicators
2. International Energy Biweekly Statistical Review
3. National Basic Intelligence Factbook
Approved For Release 2004/07/16 : CIA-RDP81M00980R000800090047-4','7bbb14fd38e530d10418f3fa6ff57ea4a9dd1da3b31cda640e183d02efa784f6','internet-archive','cia-readingroom-document-cia-rdp81m00980r000800090047-4','txt','283e736d28081443cd352ca4d1c24fdd5cb8e6fc5f45896132caaf29f95f3403','https://archive.org/download/cia-readingroom-document-cia-rdp81m00980r000800090047-4/cia-rdp81m00980r000800090047-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e348c45daf7dc362bf8932b2acccfc88fe6db918a875a71feb671ee33d5cacd4',1965,'','','raw',1,'Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
q a
LISTING OF AGENCY UNCLASSIFIED PUBLICATIONS
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
OO
Approved For Release 2008/01/30 : os RDP85M00363R000901960031-7
Directorate of
Intelligence
CIA Publications
Released to the Public
Listing for 1972-81
DI 82-10029
(Supersedes NF 81-10007)
May 1982
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
3 1
This publication is prepared for the use of US Government
officials, and the format, coverage, and content are designed to
meet their specific requirements. US Government officials may
obtain additional copies of this document directly or through
liaison channels from the Central Intelligence Agency.
Requesters outside the US Government may obtain subscriptions to
CIA publications similar to this one by addressing inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Requesters outside the US Government not interested in subscription
service may purchase specific publications either in paper copy or
microform from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
(To expedite service call the
NTIS Order Desk (703) 487-4650)
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release eo Oee : CIA-RDP85M00363R000901960031-7
Preface Publications of the Central Intelligence Agency are prepared to support US
policymaking officials. However, the Agency releases its unclassified publications
to improve public understanding of key policy issues and to provide additional
research aids to academic and business communities. This program began in 1972
with CIA participation in the Document Expediting (DOCEX) Project of the
Library of Congress. Since that time a large number of unclassified Agency
publications have been distributed through this subscription service. The majority
of these reports concern foreign or international economic and political affairs, or
are directories of foreign officials. Publications have been included in the
Government Printing Office’s Depository Library program since late 1977 and,
beginning in 1979, are also available from the Department of Commerce, National
Technical Information Service (NTIS).
This catalogue, issued annually since 1978, lists Central Intelligence Agency
publications released through DOCEX from 1972 through 1979 and through
NTIS since 1979, It is arranged alphabetically. by country or geographic area with
the titles of the reports in chronological order. The entries for the People’s
Republic of China and the Soviet Union are further subdivided by broad subject
headings; for example, political, economic, and so forth. Reports concerning more
than one country or area are listed in the international section of the catalogue.
Publications issued semiannually or more frequently are listed separately as
serials.
Selected maps and atlases produced by CIA since 1971 are available through the
Superintendent of Documents and are listed in the GPO Monthly Catalog. Maps
produced since 1 January 1982 are available through DOCEX or NTIS.
Publications are not available to the public from the Central Intelligence Agency.
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7','2044ff70e57ef30f3bde8d469b26830f006ff753b8550b43da4740ad15435ab1','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff2fc31fec237a46f593ed6e622a059caf6f9b028f09c7055e9c65df9412aa33',1965,'AL','Albania','raw',2,'Albanian Worker’s Party,
CR 81-10095, June 1981, wall chart
Government of the People’s Socialist Republic of Albania,
CR 81-10094, June 1981, wall chart
Directory of Officials of the People’s Socialist Republic of Albania,
CR 80-14733, December 1980
Directory of Officials of the People’s Socialist Republic of Albania,
CR 79-12598, May 1979
Directory of Officials of the People’s Socialist Republic of Albania,
CR 77-10848, March 1977
People’s Socialist Republic of Albania: Government and Party Structure,
CR 77-11802, April 1977, wall chart
Directory of Officials of the People’s Republic of Albania,
A (CR) 74-22, June 1974','6b20c76131eb849eae55990531184b870ff5faaf1b50d41214957775e0bc507d','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d380546d23b13bbd615e929a21e3977858f2b42054a4e188ffe5cb34bdccf0e',1965,'BG','Bulgaria','raw',3,'Directory of Officials of the Bulgarian People’s Republic,
CR 79-10008, January 1979
Bulgarian Communist Party Leadership,
CR 78-15135, November 1978, wall chart
Government of the People’s Republic of Bulgaria,
CR 78-15136, November 1978, wall chart
Bulgarian People’s Republic Government and Party Structure,
CR 76-10051, January 1976, wall chart
Directory of Officials of the Bulgarian People’s Republic,
A (CR) 75-38, September 1975
Directory of Bulgarian Officials,
A 72-5, March 1972
China, People’s Republic of
Geographic
Beijing City Brief,
GS 81-10141, June 1981
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
y) q
China, People’s Republic of (continued)
A Perspective on the Pinyin
Romanization of Chinese Characters
GS 81-10250, September 1981','1d8abd875b914c93b3d043e07b94fc58a488f0bf8674ca830eedffb4dd1dd10a','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

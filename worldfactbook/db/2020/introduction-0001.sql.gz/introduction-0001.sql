SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0738cb46a225bc62c2ec88dcd54d0b0bb7a9b5fcf519fdcf4080a477f94bc26',2020,'','','introduction',2,'A Brief History of Basic Intelligence and The World Factbook
Definitions and Notes
Guide to Country Profiles
Guide to Country Comparisons','4f5b860c16296c459fa37c6eaac2d89f420145f6e564a13d8227126a1b0ba6f6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaa6af632a305e0b040a47af7b060538876669a71aa319bfc7d632a5b0cf0c6c',2020,'BT','Bhutan','introduction',3,'Bolivia
Background: Following Britain’s victory in the 1865 Duar
War, Britain and Bhutan signed the Treaty of Sinchulu,
under which Bhutan would receive an annual subsidy in
exchange for ceding land to British India. Ugyen
WANGCHUCK—who had served as the de facto ruler of an
increasingly unified Bhutan and had improved relations
with the British toward the end of the 19th century—was
named king in 1907. Three years later, a treaty was signed
whereby the British agreed not to interfere in Bhutanese
internal affairs, and Bhutan allowed Britain to direct its
foreign affairs. Bhutan negotiated a similar arrangement
with independent India in 1949. The Indo-Bhutanese Treaty
of Friendship returned to Bhutan a small piece of the
territory annexed by the British, formalized the annual
subsidies the country received, and defined India’s
responsibilities in defense and foreign relations. Under a
succession of modernizing monarchs beginning in the
1950s, Bhutan joined the UN in 1971 and slowly continued
its engagement beyond its borders.
In 2005, King Jigme Singye WANGCHUCK unveiled the
draft of Bhutan’s first constitution—which introduced major
democratic reforms—and held a national referendum for its
approval. The King abdicated the throne in 2006 in favor of
his son, Jigme Khesar Namgyel WANGCHUCK. In 2007,
India and Bhutan renegotiated their treaty, eliminating the
clause that stated that Bhutan would be “guided by” India
in conducting its foreign policy, although Thimphu
continues to coordinate closely with New Delhi. In 2008,
Bhutan held its first parliamentary election in accordance
with the constitution. Bhutan experienced a_ peaceful
turnover of power following a parliamentary election in
2013, which resulted in the defeat of the incumbent party.
In 2018, the incumbent party again lost the parliamentary
election. Of the more than 100,000 ethnic Nepali—
predominantly Lhotshampa—refugees who fled or were
forced out of Bhutan in the 1990s, about 6,500 remain
displaced in Nepal.','785daca557373f161403a2608c7cc1a46ebb4d500f4feb4ab550b812ab801345','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62a223c7b03edfcd41882823bd02149fdf29697ca186b4a39dc64f4a39d6714c',2020,'IO','British Indian Ocean Territory','introduction',4,'British Virgin Islands
Brunei
Background: Formerly administered as part of the British
Crown Colony of Mauritius, the British Indian Ocean
Territory (BIOT) was established as an overseas territory of
the UK in 1965. A number of the islands of the territory
were later transferred to the Seychelles when it attained
independence in 1976. Subsequently, BIOT has consisted
only of the six main island groups comprising the Chagos
Archipelago. Only Diego Garcia, the largest and most
southerly of the islands, is inhabited. It contains a joint UK-
US naval support facility and hosts one of four dedicated
ground antennas that assist in the operation of the Global
Positioning System (GPS) navigation system (the others are
on Kwajalein (Marshall Islands), at Cape Canaveral, Florida
(US), and on Ascension Island (Saint Helena, Ascension,
and Tristan da Cunha)). The US Air Force also operates a
telescope array on Diego Garcia as part of the Ground-
Based Electro-Optical Deep Space Surveillance System
(GEODSS) for tracking orbital debris, which can be a
hazard to spacecraft and astronauts.
Between 1967 and 1973, former agricultural workers,
earlier residents in the islands, were relocated primarily to
Mauritius, but also to the Seychelles. Negotiations between
1971 and 1982 resulted in the establishment of a trust fund
by the British Government as compensation for the
displaced islanders, known as Chagossians. Beginning in
1998, the islanders pursued a series of lawsuits against the
British Government seeking further compensation and the
right to return to the territory. In 2006 and 2007, British
court rulings invalidated the immigration policies contained
in the 2004 BIOT Constitution Order that had excluded the
islanders from the archipelago, but upheld the special
military status of Diego Garcia. In 2008, the House of
Lords, as the final court of appeal in the UK, ruled in favor
of the British Government by overturning the lower court
rulings and finding no right of return for the Chagossians.
In March 2015, the Permanent Court of Arbitration
unanimously held that the marine protected area (MPA)
that the UK declared around the Chagos Archipelago in
April 2010 was in violation of the UN Convention on the
Law of the Sea.
Background: First inhabited by Arawak and later by Carib
Indians, the Virgin Islands were settled by the Dutch in
1648 and then annexed by the English in 1672. The islands
were part of the British colony of the Leeward Islands from
1872-1960; they were granted autonomy in 1967. The
economy is closely tied to the larger and more populous US
Virgin Islands to the west; the US dollar is the legal
currency. On 6 September 2017, Hurricane Irma
devastated the island of Tortola. An estimated 80% of
residential and business structures were destroyed or
damaged, communications disrupted, and local roads
rendered impassable.','7c620eaaafe71b30b54ca0c1bea03146532c4ff149693419586553f875e00a38','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d82afe177c41f152e5816ecd4e89aa1666c28fda25e0e803b05852d5d87267de',2020,'BF','Burkina Faso','introduction',5,'Burma
Background: Close ties to France following independence in
1960, the development of cocoa production for export, and
foreign investment all made Cote d’Ivoire one of the most
prosperous of the West African states but did not protect it
from political turmoil. In December 1999, a military coup—
the first ever in Cote d’Ivoire’s history—overthrew the
government. Junta leader Robert GUEI attempted to rig the
elections held in late 2000 and declared himself the winner.
Popular protest forced him to step aside and an election
brought Laurent GBAGBO into power. Ivoirian dissidents
and disaffected members of the military launched a failed
coup attempt in September 2002 that developed into a
rebellion and then a civil war. In 2003, a cease-fire resulted
in the country being divided with the rebels holding the
north, the government the south, and peacekeeping forces
a buffer zone between the two. In March 2007, President
GBAGBO and former New Forces rebel leader Guillaume
SORO signed an agreement in which SORO joined
GBAGBO’s government as prime minister and the two
agreed to reunite the country by dismantling the buffer
zone, integrating rebel forces into the national armed
forces, and holding elections. Difficulties in preparing
electoral registers delayed balloting until 2010. In
November 2010, Alassane Dramane OUATTARA won the
presidential election over GBAGBO, but GBAGBO refused
to hand over power, resulting in a five-month resumption of
violent conflict. In April 2011, after widespread fighting,
GBAGBO was formally forced from office by armed
OUATTARA supporters with the help of UN and French
forces. OUATTARA won a second term in 2015 and is
focused on rebuilding the country’s economy and
infrastructure while reforming the security forces. The UN
peacekeeping mission departed in June 2017. GBAGBO was
in The Hague on trial for crimes against humanity, but was
acquitted in January 2019. Cote d’Ivoire is scheduled to
hold presidential elections in November 2020.
Background: The lands that today comprise Croatia were part
of the Austro-Hungarian Empire until the close of World
War I. In 1918, the Croats, Serbs, and Slovenes formed a
kingdom known after 1929 as Yugoslavia. Following World
War II, Yugoslavia became aé federal independent
communist state consisting of six socialist republics under
the strong hand of Marshal Josip Broz, aka TITO. Although
Croatia declared its independence from Yugoslavia in 1991,
it took four years of sporadic, but often bitter, fighting
before occupying Yugoslav forces, dominated by Serb
officers, were mostly cleared from Croatian lands, along
with a majority of Croatia’s ethnic Serb population. Under
UN supervision, the last Serb-held enclave in eastern
Slavonia was returned to Croatia in 1998. The country
joined NATO in April 2009 and the EU in July 2013.','6a25c7c67d17056d2818b3193519caf1b25178453bf76a9f3e0eb3e08f109e47','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7827c6f3f606dd500983981ed65f5f36bed6744c5e913631439d8bad4aeb22d',2020,'KM','Comoros','introduction',6,'Congo, Democratic Republic of the
Congo, Republic of the
Background: Madagascar was one of the last major habitable
landmasses on earth settled by humans. While there is
some evidence of human presence on the island in the
millennia B. C., large-scale settlement began between A. D.
350 and 550 with settlers from present-day Indonesia. The
island attracted Arab and Persian traders as early as the
7th century, and migrants from Africa arrived around A. D.
1000. Madagascar was a pirate stronghold during the late
17th and early 18th centuries, and served as a slave
trading center into the 19th century. From the 16th to the
late 19th century, a native Merina Kingdom dominated
much of Madagascar. The island was conquered by the
French in 1896 who made it a colony; independence was
regained in 1960.
During 1992-93, free presidential and National
Assembly elections were held ending 17 years of single-
party rule. In 1997, in the second presidential race, Didier
RATSIRAKA, the leader during the 1970s and 1980s,
returned to the presidency. The 2001 presidential election
was contested between the followers of Didier RATSIRAKA
and Marc RAVALOMANANA, nearly causing secession of
half of the country. In 2002, the High Constitutional Court
announced RAVALOMANANA the winner.
RAVALOMANANA won aé second term in 2006 _ but,
following protests in 2009, handed over power to the
military, which then conferred the presidency on the mayor
of Antananarivo, Andry RAJOELINA, in what amounted to a
coup d’etat. Following a lengthy mediation process led by
the Southern African Development Community,
Madagascar held UN-supported presidential and
parliamentary elections in 2013. Former de facto finance
minister Hery RAJAONARIMAMPIANINA won a runoff
election in December 2013 and was inaugurated in January
2014. In January 2019, RAJOELINA was declared the
winner of a runoff election against RAVALOMANANA,; both
RATSIRAKA and RAJAONARIMAMPIANINA also ran in the
first round of the election, which took place in November
2018.','c7f92cbf0826f09dfffe3aa16fd82f0078969bef0b3bb5e1dec1e3697f63cfed','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3b2e8917af8dcb0647004f88cfa02cf94786742718ec4a72bf684197859fcf3',2020,'CR','Costa Rica','introduction',7,'Cote d’Ivoire
Background: The Pacific coast of Nicaragua was settled as a
Spanish colony from Panama in the early 16th century.
Independence from Spain was declared in 1821 and the
country became an independent republic in 1838. Britain
occupied the Caribbean Coast in the first half of the 19th
century, but gradually ceded control of the region in
subsequent decades. Violent opposition to governmental
manipulation and corruption spread to all classes by 1978
and resulted in a short-lived civil war that brought a civic-
military coalition, spearheaded by the Marxist Sandinista
guerrillas led by Daniel ORTEGA Saavedra to power in
1979. Nicaraguan aid to leftist rebels in El Salvador
prompted the US to sponsor anti-Sandinista contra
guerrillas through much of the 1980s. After losing free and
fair elections in 1990, 1996, and 2001, former Sandinista
President Daniel ORTEGA was elected president in 2006,
2011, and most recently in 2016. Municipal, regional, and
national-level elections since 2008 have been marred by
widespread irregularities. Democratic institutions have
weakened under the ORTEGA administration as_ the
president has garnered full control over all branches of
government, especially after cracking down on a
nationwide antigovernment protest movement in 2018.','080c6831922cab347dcbc1da5d3577947be77cd5e30dce970b0199303fe474f4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e609fbb2d1fdc220680108f4ed9d55231aa920d4c94631714b707adde690cf39',2020,'CU','Cuba','introduction',8,'Curacao
Background: This desolate, arctic, mountainous island was
named after a Dutch whaling captain who indisputably
discovered it in 1614 (earlier claims are inconclusive).
Visited only occasionally by seal hunters and trappers over
the following centuries, the island came under Norwegian
sovereignty in 1929. The long dormant Beerenberg
volcano, the northernmost active volcano on _ earth,
resumed activity in 1970 and the most recent eruption
occurred in 1985.
Background: In 1603, after decades of civil warfare, the
Tokugawa shogunate (a military-led, dynastic government)
ushered in a long period of relative political stability and
isolation from foreign influence. For more than two
centuries this policy enabled Japan to enjoy a flowering of
its indigenous culture. Japan opened its ports after signing
the Treaty of Kanagawa with the US in 1854 and began to
intensively modernize and industrialize. During the late
19th and early 20th centuries, Japan became a regional
power that was able to defeat the forces of both China and
Russia. It occupied Korea, Formosa (Taiwan), and southern
Sakhalin Island. In 1931-32 Japan occupied Manchuria, and
in 1937 it launched a full-scale invasion of China. Japan
attacked US forces in 1941—triggering America’s entry
into World War II—and soon occupied much of East and
Southeast Asia. After its defeat in World War II, Japan
recovered to become an economic power and an ally of the
US. While the emperor retains his throne as a symbol of
national unity, elected politicians hold actual decision-
making power. Following three decades of unprecedented
growth, Japan’s economy experienced a major slowdown
starting in the 1990s, but the country remains an economic
power. In March 2011, Japan’s strongest-ever earthquake,
and an accompanying tsunami, devastated the northeast
part of Honshu island, killed thousands, and damaged
several nuclear power plants. The catastrophe hobbled the
country’s economy and its energy infrastructure, and
tested its ability to deal with humanitarian disasters. Prime
Minister Shinzo ABE was reelected to office in December
2012, and has since embarked on ambitious economic and
security reforms to improve Japan’s economy and bolster
the country’s international standing.
Background: Jersey and the other Channel Islands represent
the last remnants of the medieval Duchy of Normandy that
held sway in both France and England. These islands were
the only British soil occupied by German troops in World
War II. The Bailiwick of Jersey is a British crown
dependency, which means that it is not part of the UK but is
rather a self-governing possession of the British crown.
However, the UK Government is_ constitutionally
responsible for its defense and international
representation.','98ec8067c7ede85e56b458239b383af0afa562d4698706502fd048f4a6546a15','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61039f6e46c689cc24ef643b2e2abeedddff8aa9fda2ea2c662f09981b1b126e',2020,'DK','Denmark','introduction',9,'Dhekelia
Background: Once the seat of Viking raiders and later a major
north European power, Denmark has evolved into a
modern, prosperous nation that is participating in the
general political and economic integration of Europe. It
joined NATO in 1949 and the EEC (now the EU) in 1973.
However, the country has opted out of certain elements of
the EU’s Maastricht Treaty, including the European
Economic and Monetary Union, European’ defense
cooperation, and issues concerning certain justice and
home affairs.
Background: Fiji became independent in 1970 after nearly a
century as a British colony. Democratic rule was
interrupted by two military coups in 1987 caused by
concern over a government perceived as dominated by the
Indian community (descendants of contract laborers
brought to the islands by the British in the 19th century).
The coups and a 1990 constitution that cemented native
Melanesian control of Fiji led to heavy Indian emigration;
the population loss resulted in economic difficulties, but
ensured that Melanesians became the majority. A new
constitution enacted in 1997 was more equitable. Free and
peaceful elections in 1999 resulted in a government led by
an Indo-Fijian, but a civilian-led coup in 2000 ushered in a
prolonged period of political turmoil. Parliamentary
elections held in 2001 provided Fiji with a democratically
elected government led by Prime Minister Laisenia
QARASE. Reelected in May 2006, QARASE was ousted in a
December 2006 military coup led by Commodore Voreqe
BAINIMARAMA, who initially appointed himself acting
president but in January 2007 became interim prime
minister. Following years of political turmoil, long-delayed
legislative elections were held in September 2014 that
were deemed “credible” by international observers and
that resulted in BAINIMARAMA being reelected. He was
reelected in November 2018 in elections deemed free and
fair.
Background: Carib Indians inhabited Grenada when
Christopher COLUMBUS discovered the island in 1498, but
it remained uncolonized for more than a century. The
French settled Grenada in the 17th century, established
sugar estates, and imported large numbers of African
slaves. Britain took the island in 1762 and vigorously
expanded sugar production. In the 19th century, cacao
eventually surpassed sugar as the main export crop; in the
20th century, nutmeg became the leading export. In 1967,
Britain gave Grenada autonomy over its internal affairs.
Full independence was attained in 1974 making Grenada
one of the smallest independent countries in the Western
Hemisphere. In 1979, a leftist New Jewel Movement seized
power under Maurice BISHOP ushering in the Grenada
Revolution. On 19 October 1983, factions within the
revolutionary government overthrew and killed BISHOP
and members of his party. Six days later the island was
invaded by US forces and those of six other Caribbean
nations, which quickly captured the ringleaders and their
hundreds of Cuban advisers. The rule of law was restored
and democratic elections were reinstituted the following
year and have continued since then.
Background: Two centuries of Viking raids into Europe
tapered off following the adoption of Christianity by King
Olav TRYGGVASON in 994; conversion of the Norwegian
kingdom occurred over the next several decades. In 1397,
Norway was absorbed into a union with Denmark that
lasted more than four centuries. In 1814, Norwegians
resisted the cession of their country to Sweden and
adopted a new constitution. Sweden then invaded Norway
but agreed to let Norway keep its constitution in return for
accepting the union under a Swedish king. Rising
nationalism throughout the 19th century led to a 1905
referendum granting Norway independence. Although
Norway remained neutral in World War I, it suffered heavy
losses to its shipping. Norway proclaimed its neutrality at
the outset of World War II, but was nonetheless occupied
for five years by Nazi Germany (1940-45). In 1949, Norway
abandoned neutrality and became a member of NATO.
Discovery of oil and gas in adjacent waters in the late
1960s boosted Norway’s economic fortunes. In referenda
held in 1972 and 1994, Norway rejected joining the EU.
Key domestic issues include immigration and integration of
ethnic minorities, maintaining the country’s extensive
social safety net with an aging population, and preserving
economic competitiveness.
Background: The inhabitants of the area of Oman have long
prospered from Indian Ocean trade. In the late 18th
century, the nascent sultanate in Muscat signed the first in
a series of friendship treaties with Britain. Over time,
Oman’s dependence on British political and military
advisors increased, although the sultanate never became a
British colony. In 1970, QABOOS bin Said Al-Said
overthrew his father, and has since ruled as sultan. Sultan
QABOOS has no children and has not designated a
successor publicly; the Basic Law of 1996 outlines Oman’s
succession procedure. Sultan QABOOS’ _ extensive
modernization program opened the country to the outside
world, and the sultan has prioritized strategic ties with the
UK and US. Oman’s moderate, independent foreign policy
has sought to maintain good relations with its neighbors
and to avoid external entanglements.
Inspired by the popular uprisings that swept the Middle
East and North Africa beginning in January 2011, some
Omanis staged demonstrations, calling for more jobs and
economic benefits and an end to corruption. In response to
those protester demands, QABOOS in 2011 pledged to
implement economic and _ political reforms, such as
granting Oman’s bicameral legislative body more power
and authorizing direct elections for its lower house, which
took place in November 2011. Additionally, the Sultan
increased unemployment benefits, and, in August 2012,
issued a_ royal directive mandating the speedy
implementation of a national job creation plan for
thousands of public and private sector Omani jobs. As part
of the government’s efforts to decentralize authority and
allow greater citizen participation in local governance,
Oman successfully conducted its first municipal council
elections in December 2012. Announced by the sultan in
2011, the municipal councils have the power to advise the
Royal Court on the needs of local districts across Oman’s
11 governorates. Sultan QABOOS, Oman’s longest reigning
monarch, died on 11 January 2020. His cousin, HAYTHAM
bin Tarig bin Taimur Al-Said, former Minister of Heritage
and Culture, was sworn in as Oman’s new sultan the same
day.
Background: The Pacific Ocean is the largest of the world’s
five oceans (followed by the Atlantic Ocean, Indian Ocean,
Southern Ocean, and Arctic Ocean). Strategically important
access waterways include the La Perouse, Tsugaru,
Tsushima, Taiwan, Singapore, and ‘Torres Straits. The
decision by the International Hydrographic Organization in
the spring of 2000 to delimit a fifth ocean, the Southern
Ocean, removed the portion of the Pacific Ocean south of
60 degrees south.','bc32665c6ba827192e13132417384344ab5deb54afdd35718637234dfd9e4cc3','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6da5fa869e306465cb5c5f2cab7787a115ed82c2fdb1648a3631b498d1e25f9',2020,'ET','Ethiopia','introduction',10,'European Union
Falkland Islands (Islas Malvinas)
Background: Bermuda was ffirst settled in 1609 by
shipwrecked English colonists heading for Virginia. Self-
governing since 1620, Bermuda is the oldest and most
populous of the British overseas territories. Vacationing to
the island to escape North American winters first
developed in Victorian times. Tourism continues to be
important to the island’s economy, although international
business has overtaken it in recent years. Bermuda has also
developed into a highly successful offshore financial center.
A referendum on independence from the UK was soundly
defeated in 1995.
Background: Britain withdrew from British Somaliland in
1960 to allow its protectorate to join with Italian
Somaliland and form the new nation of Somalia. In 1969, a
coup headed by Mohamed SIAD Barre ushered in an
authoritarian socialist rule characterized by _ the
persecution, jailing, and torture of political opponents and
dissidents. After the regime’s collapse early in 1991,
Somalia descended into turmoil, factional fighting, and
anarchy. In May 1991, northern clans declared an
independent Republic of Somaliland that now includes the
administrative regions of Awdal, Wogqooyi Galbeed,
Togdheer, Sanaag, and Sool. Although not recognized by
any government, this entity has maintained a_ stable
existence and continues efforts to establish a constitutional
democracy, including holding municipal, parliamentary, and
presidential elections. The regions of Bari, Nugaal, and
northern Mudug comprise a neighboring semi-autonomous
state of Puntland, which has been self-governing since
1998 but does not aim at independence; it has also made
strides toward reconstructing a legitimate, representative
government but has suffered some civil strife. Puntland
disputes its border with Somaliland as it also claims the
regions of Sool and Sanaag, and portions of Togdheer.
Beginning in 1993, a two-year UN humanitarian effort
(primarily in south-central Somalia) was able to alleviate
famine conditions, but when the UN withdrew in 1995,
having suffered significant casualties, order still had not
been restored.
In 2000, the Somalia National Peace Conference (SNPC)
held in Djibouti resulted in the formation of an interim
government, known as_ the’ Transitional National
Government (TNG). When the TNG failed to establish
adequate security or governing institutions, the
Government of Kenya, under the auspices of the
Intergovernmental Authority on Development (IGAD), led a
subsequent peace process that concluded in October 2004
with the election of Abdullahi YUSUF Ahmed as President
of a second interim government, known as the Transitional
Federal Government (TFG) of the Somali Republic. The TFG
included a 275-member parliamentary body, known as the
Transitional Federal Parliament (TFP). President YUSUF
resigned late in 2008 while UN-sponsored talks between
the TFG and the opposition Alliance for the Re-Liberation of
Somalia (ARS) were underway in Djibouti. In January 2009,
following the creation of a TFG-ARS unity government,
Ethiopian military forces, which had entered Somalia in
December 2006 to support the TFG in the face of advances
by the opposition Islamic Courts Union (ICU), withdrew
from the country. The TFP was doubled in size to 550 seats
with the addition of 200 ARS and 75 civil society members
of parliament. The expanded parliament elected Sheikh
SHARIF Sheikh Ahmed, the former ICU and ARS chairman
as president in January 2009. The creation of the TFG was
based on the Transitional Federal Charter (TFC), which
outlined a five-year mandate leading to the establishment
of a new Somali constitution and a transition to a
representative government following national elections. In
2009, the TFP amended the TFC to extend TFG’s mandate
until 2011 and in 2011 Somali principals agreed to institute
political transition by August 2012. The transition process
ended in September 2012 when clan elders replaced the
TFP by appointing 275 members to a new parliament who
subsequently elected a new president.
Background: Originally settled by Polynesian emigrants from
surrounding island groups, the Tokelau Islands were made
a British protectorate in 1889. They were transferred to
New Zealand administration in 1925. Referenda held in
2006 and 2007 to change the status of the islands from that
of a New Zealand territory to one of free association with
New Zealand did not meet the needed threshold for
approval.
Background: Tonga—unique among Pacific nations—never
completely lost its indigenous governance. The
archipelagos of “The Friendly Islands” were united into a
Polynesian kingdom in 1845. Tonga became a constitutional
monarchy in 1875 and a British protectorate in 1900; it
withdrew from the_ protectorate and =joined_ the
Commonwealth of Nations in 1970. Tonga remains the only
monarchy in the Pacific; in 2008, King George TUPOU V
announced he was relinquishing most of his powers leading
up to parliamentary elections in 2010. TUPOU died in 2012
and was succeeded by his brother ‘Aho’eitu TUPOU VI.
Tropical Cyclone Gita, the strongest-ever recorded storm to
impact Tonga, hit the islands in February 2018 causing
extensive damage.','34a5a8e041bdaa42873972eb3cc3348703547e501573a6df443a1b06c1aa0ce0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('819200ec1593b92d8746c8972c8e00bbe604ea8821520f7311fb7ac41627e88c',2020,'PF','French Polynesia','introduction',11,'French Southern and Antarctic Lands
Background: The French annexed various Polynesian island
groups during the 19th century. In 1966, the French
Government began testing nuclear weapons on _ the
uninhabited Mururoa Atoll; following mounting opposition,
the tests were moved underground in 1975. In September
1995, France stirred up widespread protests by resuming
nuclear testing after a three-year moratorium. The tests
were halted in January 1996. In recent years, French
Polynesia’s autonomy has been considerably expanded.
Background: In February 2007, the Iles Eparses became an
integral part of the French Southern and Antarctic Lands
(TAAF). The Southern Lands are now divided into five
administrative districts, two of which are archipelagos, Iles
Crozet and Iles Kerguelen; the third is a district composed
of two volcanic islands, Ile Saint-Paul and Ile Amsterdam;
the fourth, Iles Eparses, consists of five scattered tropical
islands around Madagascar. They contain no permanent
inhabitants and are visited only by researchers studying
the native fauna, scientists at the various scientific stations,
fishermen, and military personnel. The fifth district is the
Antarctic portion, which consists of “Adelie Land,” a thin
slice of the Antarctic continent discovered and claimed by
the French in 1840.
Ile Amsterdam: Discovered but not named in 1522 by the
Spanish, the island subsequently received the appellation
of Nieuw Amsterdam from a Dutchman; it was claimed by
France in 1843. A short-lived attempt at cattle farming
began in 1871. A French meteorological station established
on the island in 1949 is still in use.; [le Saint Paul: Claimed
by France since 1893, the island was a fishing industry
center from 1843 to 1914. In 1928, a spiny lobster cannery
was established, but when the company went bankrupt in
1931, seven workers were abandoned. Only two survived
until 1934 when rescue finally arrived.; Iles Crozet: A large
archipelago formed from the Crozet Plateau, Iles Crozet is
divided into two main groups: LOccidental (the West),
which includes Ile aux Cochons, Ilots des Apotres, Ile des
Pingouins, and the reefs Brisants de l’Heroine; and
LOriental (the East), which includes Ile d’Est and Ile de la
Possession (the largest island of the Crozets). Discovered
and claimed by France in 1772, the islands were used for
seal hunting and as a base for whaling. Originally
administered as a dependency of Madagascar, they became
part of the TAAF in 1955.; Iles Kerguelen: This island
group, discovered in 1772, consists of one large island (Ile
Kerguelen) and about 300 smaller islands. A permanent
group of 50 to 100 scientists resides at the main base at
Port-aux-Francais.; Adelie Land: The only non-insular
district of the TAAF is the Antarctic claim known as “Adelie
Land.” The US Government does not recognize it as a
French dependency.; Bassas da India: A French possession
since 1897, this atoll is a volcanic rock surrounded by reefs
and is awash at high tide.; Europa Island: This heavily
wooded island has been a French possession since 1897; it
is the site of a small military garrison that staffs a weather
station.; Glorioso Islands: A French possession since 1892,
the Glorioso Islands are composed of two lushly vegetated
coral islands (Ile Glorieuse and Ile du Lys) and three rock
islets. A military garrison operates a weather and radio
station on Ile Glorieuse.; Juan de Nova Island: Named after
a famous 15th-century Spanish navigator and explorer, the
island has been a French possession since 1897. It has
been exploited for its guano and phosphate. Presently a
small military garrison oversees a meteorological station.;
Tromelin Island: First explored by the French in 1776, the
island came under the jurisdiction of Reunion in 1814. At
present, it serves as a Sea turtle sanctuary and is the site of
an important meteorological station.
Background: Following, independence from France in 1960,
El Hadj Omar BONGO Ondimba—one of the longest-ruling
heads of state in the world—dominated the country’s
political scene for four decades (1967-2009). President
BONGO introduced a nominal multiparty system and a new
constitution in the early 1990s. However, allegations of
electoral fraud during local elections in December 2002
and the presidential election in 2005 exposed the
weaknesses of formal political structures in Gabon.
Following President BONGO’s death in 2009, a new
election brought his son, Ali BONGO Ondimba, to power.
Despite constrained political conditions, Gabon’s small
population, abundant natural resources, and considerable
foreign support have helped make it one of the more stable
African countries.
President Ali BONGO Ondimba’s controversial August
2016 reelection sparked unprecedented opposition protests
that resulted in the burning of the parliament building. The
election was contested by the opposition after fraudulent
results were flagged by international election observers.
Gabon’s Constitutional Court reviewed the election results
but ruled in favor of President BONGO, upholding his win
and extending his mandate to 2023.
Background: The Gambia gained its independence from the
UK in 1965. Geographically surrounded by Senegal, it
formed a short-lived Confederation of Senegambia between
1982 and 1989. In 1991, the two nations signed a
friendship and cooperation treaty, although tensions flared
up intermittently during the regime of Yahya JAMMEH.
JAMMEH led a military coup in 1994 that overthrew the
president and banned political activity. A new constitution
and _ presidential election in 1996, followed _ by
parliamentary balloting in 1997, completed a nominal
return to civilian rule. JAMMEH was elected president in
all subsequent elections including most recently in late
2011. After 22 years of increasingly authoritarian rule,
President JAMMEH was defeated in free and fair elections
in December 2016. Due to The Gambia’s poor human rights
record under JAMMEH, international development partners
had distanced themselves, and substantially reduced aid to
the country. These channels have now reopened under the
administration of President Adama BARROW, who took
office in January 2017. The US and The Gambia currently
enjoy improved relations. US assistance to the country has
supported military education and training programs, as
well as various capacity building and democracy
strengthening activities.
ej oley v Va
Location: Western Africa, bordering the North Atlantic Ocean
and Senegal
Geographic coordinates: 13 28 N, 16 34 W
Map references: Africa
Area: total: 11,300 sq km
land: 10,120 sq km
water: 1,180 sq km
country comparison to the world: 166
Area—comparative: Slightly less than twice the size of
Delaware
Land boundaries: total: 749 km
border countries (1): Senegal 749 km
Coastline: 80 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 18 nm
continental shelf: extent not specified
exclusive fishing zone: 200 nm
Climate: tropical; hot, rainy season (June to November);
cooler, dry season (November to May) Terrain: flood plain of
the Gambia River flanked by some low hills
Elevation: mean elevation: 34 m
lowest point: Atlantic Ocean 0 m
highest point: unnamed elevation 53 m
Natural resources: fish, clay, silica sand, titanium (rutile and
ilmenite), tin, zircon Land use: agricultural land: 56.1%
(2011 est.)
arable land: 41% (2011 est.) / permanent crops: 0.5% (2011
est.) / permanent pasture: 14.6% (2011 est.) forest: 43.9%
(2011 est.)
other: 0% (2011 est.)
Irrigated land: 50 sq km (2012)
Population distribution: settlements are found scattered along
the Gambia River; the largest communities, including the
capital of Banjul, and the country’s largest city, Serekunda,
are found at the mouth of the Gambia River along the
Atlantic coast Natural hazards: droughts
Environment—current issues: deforestation due to slash-and-
burn agriculture; desertification; water pollution; water-
borne diseases Environment—international agreements: Darty to:
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling signed, but not ratified: none
of the selected agreements
Geography—note: almost an enclave of Senegal; smallest
country on the African mainland PEOPLE AND SOCIETY
Population: 2,173,999 (July 2020 est.)
country comparison to the world: 146
Nationality: NOUN: Gambian(s)
adjective: Gambian
Ethnic groups: Mandinka/Jahanka 34%,
Fulani/Tukulur/Lorobo 22.4%, Wolof 12.6%, Jola/Karoninka
10.7%, Serahuleh 6.6%, Serer 3.2%, Manjago 2.1%,
Bambara 1%, Creole/Aku Marabout 0.7%, other 0.9%, non-
Gambian 5.2%, no answer 0.6% (2013 est.) Languages:
English (official), Mandinka, Wolof, Fula, other indigenous
vernaculars
Religions: Muslim 95.7%, Christian 4.2%, none 0.1%, no
response 0.1% (2013 est.)
Demographic profile: The Gambia’s youthful age structure—
almost 60% of the population is under the age of 25—is
likely to persist because the country’s total fertility rate
remains strong at nearly 4 children per woman. The overall
literacy rate is around 55%, and is significantly lower for
women than for men. At least 70% of the populace are
farmers who are reliant on rain-fed agriculture and cannot
afford improved seeds and fertilizers. Crop failures caused
by droughts between 2011 and 2013 have increased
poverty, food shortages, and malnutrition.
The Gambia is a source country for migrants and a
transit and destination country for migrants and refugees.
Since the 1980s, economic deterioration, drought, and high
unemployment, especially among youths, have driven both
domestic migration (largely urban) and migration abroad
(legal and illegal). Emigrants are largely skilled workers,
including doctors and nurses, and provide a significant
amount of remittances. The top receiving countries for
Gambian emigrants are Spain, the US, Nigeria, Senegal,
and the UK. While the Gambia and Spain do not share
historic, cultural, or trade ties, rural Gambians have
migrated to Spain in large numbers because of its
proximity and the availability of jobs in its underground
economy (this flow slowed following the onset of Spain’s
late 2007 economic crisis).
The Gambia’s role as a host country to refugees is a
result of wars in several of its neighboring West African
countries. Since 2006, refugees from the Casamance
conflict in Senegal have replaced their pattern of flight and
return with permanent settlement in The Gambia, often
moving in with relatives along the Senegal-Gambia border.
The strain of providing for about 7,400 Casamance
refugees has increased poverty among Gambian villagers.
Age structure: 0-14 years: 35.96% (male 392,714/female
389,027) 15-24 years: 20.09% (male 216,307/female
220,514)
25-54 years: 35.85% (male 382,138/female 397,324)
95-64 years: 4.4% (male 45,614/female 50,143)
65 years and over: 3.69% (male 36,773/female 43,445)
(2020 est.)
Dependency ratios: total dependency ratio: 92.3 (2015 est.)
youth dependency ratio: 87.8 (2015 est.)
elderly dependency ratio: 4.5 (2015 est.)
potential support ratio: 22.3 (2015 est.)
Median age: total: 21.8 years
male: 21.5 years
female: 22.2 years (2020 est.)
country comparison to the world: 182
Population growth rate: 1.87% (2020 est.)
country comparison to the world: 52
Birth rate: 27 births/1,000 population (2020 est.)
country comparison to the world: 44
Death rate: 6.7 deaths/1,000 population (2020 est.)
country comparison to the world: 136
Net migration rate: -1.6 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 155
Population distribution: settlements are found scattered along
the Gambia River; the largest communities, including the
capital of Banjul, and the country’s largest city, Serekunda,
are found at the mouth of the Gambia River along the
Atlantic coast Urbanization: urban population: 62.6% of total
population (2020) rate of urbanization: 4.07% annual rate
of change (2015-20 est.)
Major urban areas—population: 451,000 BANJUL (capital) (2020)
note: includes the local government areas of Banjul and
Kanifing
Sex ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1.01 male(s)/female (2020 est.)
15-24 years: 0.98 male(s)/female (2020 est.)
25-54 years: 0.96 male(s)/female (2020 est.)
55-64 years: 0.91 male(s)/female (2020 est.)
65 years and over: 0.85 male(s)/female (2020 est.)
total population: 97.6 male(s)/female (2020 est.)
Mother’s mean age at first birth: 20.9 years (2013 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 597 deaths/100,000 live births (2017
est.)
country comparison to the world: 13
Infant mortality rate: total: 54.9 deaths/1,000 live births
male: 60.1 deaths/1,000 live births
female: 49.6 deaths/1,000 live births (2020 est.)
country comparison to the world: 18
Life expectancy at birth: total population: 65.8 years
male: 63.5 years
female: 68.3 years (2020 est.)
country comparison to the world: 190
Total fertility rate: 3.21 children born/woman (2020 est.)
country comparison to the world: 46
Contraceptive prevalence rate: 9% (2013)
Drinking water source:
improved:
urban: 94.2% of population
rural: 84.4% of population
total: 90.2% of population
unimproved:
urban: 5.8% of population
rural: 15.6% of population
total: 9.8% of population (2015 est.)
Current Health Expenditure: 4.4% (2016)
Physicians density: 0.11 physicians/1,000 population (2015)
Hospital bed density: 1.1 beds/1,000 population (2011)
Sanitation facility access:
improved:
urban: 61.5% of population (2015 est.)
rural: 55% of population (2015 est.)
total: 58.9% of population (2015 est.)
unimproved:
urban: 38.5% of population (2015 est.)
rural: 45% of population (2015 est.)
total: 41.1% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 1.9% (2018 est.)
country comparison to the world: 26
HIV/AIDS—people living with HIV/AIDS: 26,000 (2018 est.)
country comparison to the world: 76
HIV/AIDS—deaths: <1000 (2018 est.)
Major infectious diseases: degree of risk: very high (2016)
food or waterborne diseases: bacterial and _ protozoal
diarrhea, hepatitis A, and typhoid fever (2016) vectorborne
diseases: malaria and dengue fever (2016)
water contact diseases: schistosomiasis (2016)
animal contact diseases: rabies (2016)
respiratory diseases: meningococcal meningitis (2016)
Obesity—adult prevalence rate: 10.3% (2016)
country comparison to the world: 139
Children under the age of 5 years underweight:
16.5% (2013)
country comparison to the world: 37
Education expenditures: 2.1% of GDP (2016)
country comparison to the world: 167
Literacy: definition: age 15 and over can read and write
total population: 50.8%
male: 61.8%
female: 41.6% (2015)
School life expectancy (primary to tertiary education): total: 9 years
male: 9 years
female: 9 years (2010)
Unemployment, youth ages 15-24: total: 13.1%
male: 9.1%
female: 17.2% (2012 est.)
country comparison to the world: 107
COUNTRY NAME: GOVERNMENT
conventional long form: Republic of The Gambia
conventional short form: The Gambia
etymology: named for the Gambia River that flows through
the heart of the country
Government type: presidential republic
Capital: name: Banjul
geographic coordinates: 13 27 N, 16 34 W
time difference: UTC 0 (5 hours ahead of Washington, DC,
during Standard Time)
etymology: Banjul is located on Saint Mary’s Island at the
mouth of the Gambia River; the Mandinka used to gather
fibrous plants on the island for the manufacture of ropes;
“bang julo” is Mandinka for “rope fiber”; mispronunciation
over time caused the term became the word Banjul
Administrative divisions: 5 regions,1 city*, and 1
municipality**; Banjul*, Central River, Kanifing**, Lower
River, North Bank, Upper River, West Coast Independence: 18
February 1965 (from the Uk)
National holiday: Independence Day,18 February (1965)
Constitution: history: previous 1965 (Independence
Act),1970; latest adopted 8 April 1996, approved by
referendum 8 August 1996, effective 16 January 1997; note
—referendum on new constitution planned over the next 2
years amendments: proposed by the National Assembly;
passage requires at least three-fourths majority vote by the
Assembly membership in each of several readings and
approval by the president of the republic; a referendum is
required for amendments affecting national sovereignty,
fundamental rights and freedoms, government structures
and authorities, taxation, and public funding; passage by
referendum requires participation of at least 50% of
eligible voters and approval by at least 75% of votes cast;
amended 2001, 2004, 2010 (2017) Legal system: mixed legal
system of English common law, Islamic law, and customary
law International law organization _ participation: accepts
compulsory IC] jurisdiction with reservations; accepts ICCt
jurisdiction Citizenship: citizenship by birth: yes
citizenship by descent only: yes
dual citizenship recognized: no
residency requirement for naturalization: 5 years
Suffrage: 18 years of age; universal
Executive branch: Chief of state: President Adama BARROW
(since 19 January 2017); Vice President Isatou —TOURAY
(since 15 March 2019); note—the president is both chief of
state and head of government head of government: President
Adama BARROW (since 19 January 2017); Vice President
Isatou TOURAY (since 15 March 2019) cabinet: Cabinet
appointed by the president
elections/appointments: president directly elected by
simple majority popular vote for a 5-year term (no term
limits); election last held on 1 December 2016 (next to be
held in 2021); vice president appointed by the president
election results: Adama BARROW elected president;
percent of vote—Adama BARROW (Coalition 2016) 43.3%,
Yahya JAMMEH (APRC) 39.6%, Mamma KANDEH (GDC)
17.1%
Legislative branch: description: unicameral National Assembly
(58 seats; 53 members directly elected in single-seat
constituencies by simple majority vote and 5 appointed by
the president; members serve 5-year terms) elections: last
held on 6 April 2017 (next to be held in 2022)
election results: percent of vote by party—UDP 37.5%, GDC
17.4%, APRC 16%, PDOIS 9%, NRP 6.3%, PPP 2.5%, other
1.7%, independent 9.6%; seats by party—UDP 31, APRC 5,
GDC 5, NRP 5, PDOIS 4, PPP 2, independent 1; composition
—men 52, women 6, percent of women 10.3%
Judicial branch: Highest courts: Supreme Court of The Gambia
(consists of the chief justice and 6 justices; court sessions
held with 5 justices) judge selection and term of Office:
justices appointed by the president after consultation with
the Judicial Service Commission, a 6-member independent
body of high-level judicial officials, a presidential
appointee, and a National Assembly appointee; justices
appointed for life or until mandatory retirement at age 75
subordinate courts: Court of Appeal; High Court; Special
Criminal Court; Khadis or Muslim courts; district tribunals;
magistrates courts; cadi courts Political parties and leaders:
Alliance for Patriotic Reorientation and Construction or
APRC [Fabakary JATTA]
Coalition 2016 [collective leadership] (electoral coalition
includes UDP, PDOIS, NRP, GMC, GDC, PPP, and GPDP)
Gambia Democratic Congress or GDC [Mama KANDEH]
Gambia Moral Congress or GMC [Mai FATTY]
Gambia Party for Democracy and Progress or GPDP [Sarja
JARJOU]
National Convention Party or NCP [Yaya SANYANG and
Majanko SAMUSA (both claiming leadership) ]
National Democratic Action Movement or NDAM [Lamin
Yaa JUARA]
National Reconciliation Party or NRP [Hamat BAH]
People’s Democratic Organization for Independence and
Socialism or PDOIS [Sidia JATTA]
People’s Progressive Party or PPP [Yaya CEESAY)]
United Democratic Party or UDP [Ousainou DARBOE]
International organization participation: ACP AfDB, AU, ECOWAS,
FAO, G-77, IBRD, ICAO, ICCt, ICRM, IDA, IDB, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Interpol, IOC, IOM, IPU, ISO
(correspondent), ITSO, ITU, ITUC (NGOs), MIGA,
MINUSMA, NAM, OIC, OPCW, UN, UNAMID, UNCTAD,
UNESCO, UNIDO, UNMIL, UNOCI, UNWTO, UPU, WCO,
WFTU (NGOs), WHO, WIPO, WMO, WTO
Diplomatic representation in the US: Ambassador Dawda D.
FADERA (since 24 January 2018) chancery: 5630 16th
Street NW, Washington, DC 20011
telephone: [1] (202) 785-1399
FAX: [1] (202) 342-0240
Diplomatic representation from the US: chief of mission:
Ambassador Richard “Carl” PASCHALL (since 9 April 2019)
telephone: [220] 439-2856
embassy: Kairaba Avenue, Fajara, P. M. B.19, Banjul
mailing address: P. M. B.19, Banjul
FAX: [220] 439-2475
Flag description: three equal horizontal bands of red (top),
blue with white edges, and green; red stands for the sun
and the savannah, blue represents the Gambia River, and
green symbolizes forests and agriculture; the white stripes
denote unity and peace National symbol(s): lion; national
colors: red, blue, green, white
National anthem: Name: For The Gambia, Our Homeland
lyrics/music: Virginia Julie HOWE/adapted by Jeremy
Frederick HOWE
note: adopted 1965; the music is an adaptation of the
traditional Mandinka song “Foday Kaba Dumbuya”
ele} ‘Teli b 4
Economy—overview: The government has invested in the
agriculture sector because three-quarters of the population
depends on the sector for its livelihood and agriculture
provides for about one-third of GDP making The Gambia
largely reliant on sufficient rainfall. The agricultural sector
has untapped potential—less than half of arable land is
cultivated and agricultural productivity is low. Small-scale
manufacturing activity features the processing of cashews,
groundnuts, fish, and hides. The Gambia’s reexport trade
accounts for almost 80% of goods exports and China has
been its largest trade partner for both exports and imports
for several years.
The Gambia has sparse natural resource deposits. It
relies heavily on remittances from workers overseas and
tourist receipts. Remittance inflows to The Gambia amount
to about one-fifth of the country’s GDP. The Gambia’s
location on the ocean and proximity to Europe has made it
one of the most frequented tourist destinations in West
Africa, boosted by private sector investments in eco-
tourism and facilities. Tourism normally brings in about
20% of GDP, but it suffered in 2014 from tourists’ fears of
Ebola virus in neighboring West African countries.
Unemployment and underemployment remain high.
Economic progress depends on sustained bilateral and
multilateral aid, on responsible government economic
management, and on continued technical assistance from
multilateral and bilateral donors. International donors and
lenders were concerned about the quality of fiscal
management under the administration of former President
Yahya JAMMEH, who reportedly stole hundreds of millions
of dollars of the country’s funds during his 22 years in
power, but anticipate significant improvements under the
new administration of President Adama BARROW, who
assumed power in early 2017. As of April 2017, the IMF,
the World Bank, the European Union, and the African
Development Bank were all negotiating with the new
government of The Gambia to provide financial support in
the coming months to ease the country’s financial crisis.
The country faces a limited availability of foreign
exchange, weak agricultural output, a border closure with
Senegal, a slowdown in tourism, high inflation, a large
fiscal deficit, and a high domestic debt burden that has
crowded out private sector investment and driven interest
rates to new highs. The government has committed to
taking steps to reduce the deficit, including through
expenditure caps, debt consolidation, and reform of state-
owned enterprises.
GDP (purchasing power parity):
$5.556 billion (2017 est.)
$5.314 billion (2016 est.)
$5.292 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 176
GDP (official exchange rate):
$1.482 billion (2017 est.)
GDP—real growth rate: 4.6% (2017 est.)
0.4% (2016 est.)
5.9% (2015 est.)
country comparison to the world: 62
GDP—per capita (PPP): $2,600 (2017 est.)
$2,600 (2016 est.)
$2,700 (2015 est.)
note: data are in 2017 dollars
cou','6e5524483eee6c8c3eb1b5d3df0a3485f4c90841fdf2f35a15558694d3a2f6ea','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0a01ba958e962c381b112c00aa9532d8a0f02ee1a523e2bbe8ff95f6c8f249f',2020,'PF','French Polynesia','introduction',12,'ntry comparison to the world: 197
Gross national saving:
6.8% of GDP (2017 est.)
7.1% of GDP (2016 est.)
3.7% of GDP (2015 est.)
country comparison to the world: 172
GDP—composition, by end use:
household consumption: 90.7% (2017 est.)
government consumption: 12% (2017 est.)
investment in fixed capital: 19.2% (2017 est.)
investment in inventories: -2.7% (2017 est.)
exports of goods and services: 20.8% (2017 est.)
imports of goods and services: -40% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 20.4% (2017 est.)
industry: 14.2% (2017 est.)
services: 65.4% (2017 est.)
Agriculture—products: rice, millet, sorghum, peanuts, corn,
sesame, cassava (manioc, tapioca), palm kernels; cattle,
sheep, goats Industries: peanuts, fish, hides, tourism,
beverages, agricultural machinery assembly, woodworking,
metalworking, clothing Industrial production growth rate:
-0.8% (2017 est.)
country comparison to the world: 175
Labor force: 777,100 (2007 est.)
country comparison to the world: 150
Labor force—by occupation: agriculture: 75%
industry: 19%
services: 6% (1996 est.)
Unemployment rate: NA
Population below poverty line: 48.4% (2010 est.)
Household income or consumption by percentage share: Jowest 10%:
2%
highest 10%: 36.9% (2003)
Budget: revenues: 300.4 million (2017 est.)
expenditures: 339 million (2017 est.)
Taxes and other revenues:
20.3% (of GDP) (2017 est.)
country comparison to the world: 148
Budget surplus (+) or deficit (-): -2.6% (of GDP) (2017 est.)
country comparison to the world: 117
Public debt:
88% of GDP (2017 est.)
82.3% of GDP (2016 est.)
country comparison to the world: 28
Fiscal year: Calendar year
Inflation rate (consumer prices): 8% (2017 est.)
7.2% (2016 est.)
country comparison to the world: 196
Current account balance:
-§194 million (2017 est.)
-$85 million (2016 est.)
country comparison to the world: 97
Exports: $72.9 million (2017 est.)
$106.6 million (2016 est.)
country comparison to the world: 201
Exports—partners: Guinea-Bissau 51.9%, Vietnam 14.6%,
Senegal 8.8%, Mali 7.2% (2017) Exports—commodities: peanut
products, fish, cotton lint, palm kernels
Imports: $376.9 million (2017 est.)
$310.5 million (2016 est.)
country comparison to the world: 201
Imports—commodities: foodstuffs, manufactures, fuel,
machinery and transport equipment Imports—partners: Cote
dIvoire 11.5%, Brazil 10.6%, Spain 10.2%, China 7.8%,
Russia 6.4%, Netherlands 5.3%, India 5% (2017) Reserves of
foreign exchange and gold:
$170 million (31 December 2017 est.)
$87.64 million (31 December 2016 est.)
country comparison to the world: 179
Debt—external:
$586.8 million (31 December 2017 est.)
$571.2 million (31 December 2016 est.)
country comparison to the world: 175
Exchange rates: dalasis (GMD) per US dollar—
49.74 (2017 est.)
43.8846 (2016 est.)
43.8846 (2015 est.)
41.89 (2014 est.)
41.733 (2013 est.)','bbaacdb61299d730e2b534d826d80bb9671f93cdfb63e4f463481447813222ad','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('841c9f0860b02e26aaa7c654ef5559dfe76667662e5d619cc69913a260e37a6f',2020,'GT','Guatemala','introduction',13,'Guernsey.
Background: El Salvador achieved independence from Spain
in 1821 and from the Central American Federation in 1839.
A 12-year civil war, which cost about 75,000 lives, was
brought to a close in 1992 when the government and leftist
rebels signed a treaty that provided for military and
political reforms. El Salvador is beset by one of the world’s
highest homicide rates and pervasive criminal gangs.','53673b36717bab69d5ed9bf5629f3ecf6a6108ee5fbc377788c71a556bf277af','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d28c3cc17685aca0eeb5d8cec6bf6b495b034b855092534c312e8e177ab1c834',2020,'HN','Honduras','introduction',14,'Hong_Kong
Background: Belize was the site of several Mayan city states
until their decline at the end of the first millennium A.D.
The British and Spanish disputed the region in the 17th and
18th centuries; it formally became the colony of British
Honduras in 1862. Territorial disputes between the UK and
Guatemala delayed the independence of Belize until 1981.
Guatemala refused to recognize the new nation until 1992
and the two countries are involved in an ongoing border
dispute. Both nations have voted to send the dispute for
final resolution to the International Court of Justice.
Tourism has become the mainstay of the economy. Current
concerns include the country’s heavy foreign debt burden,
high crime rates, high unemployment combined with a
majority youth population, growing involvement in the
Mexican and South American drug trade, and one of the
highest HIV/AIDS prevalence rates in Central America.
Background: Present day Benin was the site of Dahomey, a
West African kingdom that rose to prominence in about
1600 and over the next two and a half centuries became a
regional power, largely based on its slave trade. France
began to control the coastal areas of Dahomey in the
second half of the 19th century; the entire kingdom was
conquered by 1894. French Dahomey achieved
independence in 1960; it changed its name to the Republic
of Benin in 1975.
A succession of military governments ended in 1972
with the rise to power of Mathieu KEREKOU and the
establishment of a government based on Marxist-Leninist
principles. A move to representative government began in
1989. Two years later, free elections ushered in former
Prime Minister Nicephore SOGLO as president, marking
the first successful transfer of power in Africa from a
dictatorship to a democracy. KEREKOU was returned to
power by elections held in 1996 and 2001, though some
irregularities were alleged. KEREKOU stepped down at the
end of his second term in 2006 and was succeeded by
Thomas YAYI Boni, a political outsider and independent,
who won a second five-year term in March 2011. Patrice
TALON, a wealthy businessman, took office in 2016 after
Campaigning to restore public confidence in the','373b9f22073308c22a5d1123cf8fd14e71c248a13fad9bb937e15e1c68ff291d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe0ed249968b4e46dc3c6b645f1477eaa8db29f66b73b866d6f4d5c2bcffe34b',2020,'IN','India','introduction',15,'Indian Ocean
Background: The huge delta region formed at the confluence
of the Ganges and Brahmaputra River systems—now
referred to as Bangladesh—was a loosely incorporated
outpost of various empires centered on the Gangetic plain
for much of the first millennium A.D. Muslim conversions
and settlement in the region began in the 10th century,
primarily from Arab and Persian traders and preachers.
Europeans established trading posts in the area in the 16th
century. Eventually the area known as Bengal, primarily
Hindu in the western section and mostly Muslim in the
eastern half, became part of British India. Partition in 1947
resulted in an eastern wing of Pakistan in the Muslim-
majority area, which became East Pakistan. Calls for
greater autonomy and animosity between the eastern and
western wings of Pakistan led to a Bengali independence
movement. That movement, led by the Awami League (AL)
and supported by India, won the independence war for
Bangladesh in 1971.
The post-independence AL government faced daunting
challenges and in 1975 it was overthrown by the military,
triggering a series of military coups that resulted in a
military-backed government and subsequent creation of the
Bangladesh Nationalist Party (BNP) in 1978. That
government also ended in a coup in 1981, followed by
military-backed rule until democratic elections occurred in
1991. The BNP and AL have alternated in power since
1991, with the exception of a military-backed, emergency
caretaker regime that suspended parliamentary elections
planned for January 2007 in an effort to reform the political
system and root out corruption. That government returned
the country to fully democratic rule in December 2008 with
the election of the AL and Prime Minister Sheikh HASINA.
In January 2014, the incumbent AL won the national
election by an overwhelming majority after the BNP
boycotted the election, which extended HASINA’s term as
prime minister. In December 2018, HASINA secured a third
consecutive term (fourth overall) with the AL coalition
securing 96% of available seats, amid widespread claims of
election irregularities. With the help of international
development assistance, Bangladesh has reduced the
poverty rate from over half of the population to less than a
third, achieved Millennium Development Goals _ for
maternal and child health, and made great progress in food
security since independence. The economy has grown at an
annual average of about 6% for the last two decades and
the country reached World Bank lower-middle income
status in 2014.','90bf01f32a7d7f8092051ad677a91f834a6c4dbde6cf8048805485e05a939fba','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('866e88a3fceb5184a27728961dc3751c95d21ec2045616bc64f0b3e8b674c201',2020,'ID','Indonesia','introduction',16,'Iran
Background: The Philippine Islands became a Spanish colony
during the 16th century; they were ceded to the US in 1898
following the Spanish-American War. In 1935. the
Philippines became a_e self-governing commonwealth.
Manuel QUEZON was elected president and was tasked
with preparing the country for independence after a 10-
year transition. In 1942 the islands fell under Japanese
occupation during World War II, and US forces and
Filipinos fought together during 1944-45 to regain control.
On 4 July 1946 the Republic of the Philippines attained its
independence. A 21-year rule by Ferdinand MARCOS ended
in 1986, when a “people power” movement in Manila
(“EDSA 1”) forced him into exile and installed Corazon
AQUINO as president. Her presidency was hampered by
several coup attempts that prevented a return to full
political stability and economic development. Fidel RAMOS
was elected president in 1992. His administration was
marked by increased stability and by progress on economic
reforms. In 1992, the US closed its last military bases on
the islands. Joseph ESTRADA was elected president in
1998. He was succeeded by his vice-president, Gloria
MACAPAGAL-ARROYO, in January 2001 after ESTRADA’s
stormy impeachment trial on corruption charges broke
down and another “people power” movement (“EDSA 2”)
demanded his resignation. MACAPAGAL-ARROYO- was
elected to a six-year term as president in May 2004. Her
presidency was marred by several corruption allegations
but the Philippine economy was one of the few to avoid
contraction following the 2008 global financial crisis,
expanding each year of her administration. Benigno
AQUINO III was elected to a six-year term as president in
May 2010 and was succeeded by Rodrigo DUTERTE in May
2016.
The Philippine Government faces threats from several
groups, some of which are on the US Government’s Foreign
Terrorist Organization list. Manila has waged a decades-
long struggle against ethnic Moro insurgencies in the
southern Philippines, which led to a peace accord with the
Moro National Liberation Front and a separate agreement
with a break away faction, the Moro Islamic Liberation
Front. The decades-long Maoist-inspired New People’s
Army insurgency also operates through much of the
country. In 2017, Philippine armed forces battled an ISIS-
Philippines siege in Marawi City, driving DUTERTE to
declare martial law in the region. The Philippines faces
increased tension with China over disputed territorial and
maritime claims in the South China Sea.
Background: Although sighted by Christopher COLUMBUS in
1493 and claimed for Spain, it was the Dutch who occupied
the island in 1631 and began exploiting its salt deposits.
The Spanish retook the island in 1633, but the Dutch
continued to assert their claims. The Spanish finally
relinquished the island of Saint Martin to the French and
Dutch, who divided it between themselves in 1648. The
establishment of cotton, tobacco, and sugar plantations
dramatically expanded African slavery on the island in the
18th and 19th centuries; the practice was not abolished in
the Dutch half until 1863. The island’s economy declined
until 1939 when it became a free port; the tourism industry
was dramatically expanded beginning in the 1950s. In
1954, Sint Maarten and several other Dutch Caribbean
possessions became part of the Kingdom of the
Netherlands as the Netherlands Antilles. In a 2000
referendum, the citizens of Sint Maarten voted to become a
self-governing country within the Kingdom of the
Netherlands, effective October 2010. On 6 September
2017, Hurricane Irma hit Saint Martin/Sint Maarten,
causing extensive damage to roads, communications,
electrical power, and housing. The UN estimated the storm
destroyed or damaged 90% of the buildings, and Princess
Juliana International Airport was heavily damaged and
closed to commercial air traffic for five weeks.
Background: The Portuguese began to trade with the island
of Timor in the early 16th century and colonized it in mid-
century. Skirmishing with the Dutch in the _ region
eventually resulted in an 1859 treaty in which Portugal
ceded the western portion of the island. Imperial Japan
occupied Portuguese Timor from 1942 to 1945, but
Portugal resumed colonial authority after the Japanese
defeat in World War II. East Timor declared itself
independent from Portugal on 28 November 1975 and was
invaded and occupied by Indonesian forces nine days later.
It was incorporated into Indonesia in July 1976 as the
province of Timor Timur (East Timor). An unsuccessful
Campaign of pacification followed over the next two
decades, during which an estimated 100,000 to 250,000
people died. In an August 1999 UN-supervised popular
referendum, an overwhelming majority of the people of
Timor-Leste voted for independence from _ Indonesia.
However, in the next three weeks, anti-independence
Timorese militias—organized and supported by the
Indonesian military—commenced a large-scale, scorched-
earth campaign of retribution. The militias’ killed
approximately 1,400 Timorese and forced 300,000 people
into western Timor as refugees. Most of the country’s
infrastructure, including homes, irrigation systems, water
supply systems, and schools, and nearly all of the country’s
electrical grid were destroyed. On 20 September 1999,
Australian-led peacekeeping troops deployed to the country
and brought the violence to an end. On 20 May 2002,
Timor-Leste was internationally recognized as an
independent state.
In 2006, internal tensions threatened the new nation’s
security when a military strike led to violence and a
breakdown of law and order. At Dili’s request, an
Australian-led International Stabilization Force (ISF)
deployed to Timor-Leste, and the UN Security Council
established the UN Integrated Mission in Timor-Leste
(UNMIT), which included an authorized police presence of
over 1,600 personnel. The ISF and UNMIT restored
stability, allowing for presidential and parliamentary
elections in 2007 in a largely peaceful atmosphere. In
February 2008, a rebel group staged an unsuccessful
attack against the president and prime minister. The
ringleader was killed in the attack, and most of the rebels
surrendered in April 2008. Since the attack, the
government has enjoyed one of its longest periods of post-
independence stability, including successful 2012 elections
for both the parliament and president and a successful
transition of power in February 2015. In late 2012, the UN
Security Council ended its peacekeeping mission in Timor-
Leste and both the ISF and UNMIT departed the country.
Early parliamentary elections in the spring of 2017 finally
produced a majority goovernment after months of impasse.
Currently, the government is a coalition of three parties
and the president is a member of the opposition party. In
2018 and 2019, this configuration stymied nominations for
key ministerial positions and slowed progress on certain
policy issues.','15fd0b8e3d7823cae99fd2a9e723d1691655fb7ef3960b6537a292b8ec9fc68c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1f282b186837c5d32743c3e12478c17892c19f87c34139989401613735350f5',2020,'LU','Luxembourg','introduction',17,'Macau
Background: Founded in 963, Luxembourg became a grand
duchy in 1815 and an independent state under the
Netherlands. It lost more than half of its territory to
Belgium in 1839 but gained a larger measure of autonomy.
In 1867, Luxembourg attained full independence under the
condition that it promise perpetual neutrality. Overrun by
Germany in both world wars, it ended its neutrality in 1948
when it entered into the Benelux Customs Union and when
it joined NATO the following year. In 1957, Luxembourg
became one of the six founding countries of the EEC (later
the EU), and in 1999 it joined the euro currency zone.
Background: Colonized by the Portuguese in the 16th century,
Macau was the first European settlement in the Far East.
Pursuant to an agreement signed by China and Portugal on
13. April 1987, Macau became the Macau _ Special
Administrative Region of the People’s Republic of China on
20 December 1999. In this agreement, China promised
that, under its “one country, two systems” formula, China’s
political and economic system would not be imposed on
Macau, and that Macau would enjoy a “high degree of
autonomy” in all matters except foreign affairs and defense
for the subsequent 50 years.','f20484d90419527da8961e3bfad98edce442ae47ac840a7145ba518f76c6c169','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49dfad9fa70ccd8ef3d475aa55b1f3dc58fc88ae7d232c4918eb4da1974d234c',2020,'FM','Micronesia, Federated States of','introduction',18,'Moldova
Background: The Caroline Islands are a widely scattered
archipelago in the western Pacific Ocean; they became part
of a UN Trust Territory under US administration following
World War II. The eastern four island groups adopted a
constitution in 1979 and chose to become the Federated
States of Micronesia (FSM). (The westernmost island group
became Palau.) Independence came in 1986 under a
Compact of Free Association (COFA) with the US, which
was amended in 2004. The COFA has been a force for
stability and democracy in the FSM since it came into force
in 1986. Present concerns include economic uncertainty
after 2023 when direct US economic assistance is
scheduled to end, large-scale unemployment, overfishing,
overdependence on US foreign aid, and state perceptions
of inequitable allocation of US aid. As a signatory to the
COFA with the US, eligible Micronesians can live, work,
and study in any part of the US and its territories without a
visa—this privilege reduces stresses on the island economy
and the environment. Micronesians serve in the US armed
forces and military recruiting from the Federated States of
Micronesia, per capita, is higher than many US states.','70ec707f5a3147506444bc25965a9d3e7ecdf00a9a2e6d26c9133a506161a51d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df14bcff34863eb3f21f6827d9f6436176c975dacc559ca8d237897886521610',2020,'NR','Nauru','introduction',19,'Navassa Island
Background: The exact origins of the Nauruans are unclear
since their language does not resemble any other in the
Pacific region. Germany annexed the island in 1888. A
German-British consortium began mining the _ island’s
phosphate deposits early in the 20th century. Australian
forces occupied Nauru in World War I; it subsequently
became a League of Nations mandate. After the Second
World War—and a brutal occupation by Japan—Nauru
became a UN trust territory. It achieved independence in
1968 and joined the UN in 1999 as the world’s smallest
independent republic.
Background: This uninhabited island was claimed by the US
in 1857 for its guano. Mining took place between 1865 and
1898. The lighthouse, built in 1917, was shut down in 1996
and administration of Navassa Island transferred from the
US Coast Guard to the Department of the Interior, Office of
Insular Affairs. A 1998 scientific expedition to the island
described it as a “unique preserve of Caribbean
biodiversity.” The following year it became a National
Wildlife Refuge and annual scientific expeditions have
continued.','52e62002865057155aa7c1dfd59c0f615b4297b0f363ca3e0b194a17a18b4bde','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dac4680d3e4e2fefcb702c815c7689d637808ba4bd73153f306210dd60030a97',2020,'PH','Philippines','introduction',20,'Pitcairn Islands
Background: Pitcairn Island was discovered in 1767 by the
British and settled in 1790 by the Bounty mutineers and
their Tahitian companions. Pitcairn was the first Pacific
island to become a British colony (in 1838) and today
remains the last vestige of that empire in the South Pacific.
Outmigration, primarily to New Zealand, has thinned the
population from a peak of 233 in 1937 to less than 50 today.','f1b907c8d84fe552ee4475243f53e1e2744b56b2a0ee191c1b2a6bc8e8ef0d11','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6917dc191e32e84dd336e2bc099803c83fc9a6c75131e1ca20cf5ea7358089de',2020,'RW','Rwanda','introduction',21,'Saint Barthelemy
Saint Helena, Ascension, and Tristan da Cunha
Background: Burundi is a small country in Central-East Africa
bordered by Tanzania, Rwanda, the Democratic Republic of
Congo, and Lake ‘Tanganyika. Burundi gained its
independence from Belgium in 1962 as the Kingdom of
Burundi, but the monarchy was overthrown in 1966 and a
republic established. Political violence and non-democratic
transfers of power have marked much of its history;
Burundi’s first democratically elected president, a Hutu,
was assassinated in October 1993 after only 100 days in
office. The internationally brokered Arusha Agreement,
signed in 2000, and subsequent ceasefire agreements with
armed movements ended the 1993-2005 civil war.
Burundi’s second democratic elections were held in 2005.
Pierre NKURUNZIZA was elected president in 2005 and
2010, and again in a controversial election in 2015.
Burundi continues to face many economic and _ political
challenges.','19b33649c139da4b4b8e2c0972f5d411acca28ab7e552523295531cc4b269c8d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ba66f82100b656a3960d31fd0c99f8d04ec35ad2062d015a9fa8354c0aaaba2',2020,'ZA','South Africa','introduction',22,'South Georgia and South Sandwich Islands
Background: Formerly the _ British protectorate’ of
Bechuanaland, Botswana adopted its new name at
independence in 1966. More than five decades of
uninterrupted civilian leadership, progressive social
policies, and significant capital investment have created
one of the most stable economies in Africa. The ruling
Botswana Democratic Party has won every national election
since independence; President Mokgweetsi Eric MASISI
assumed the presidency in April 2018 following the
retirement of former President Ian KHAMA due _ to
constitutional term limits. MASISI won his first election as
president in October 2019, and he is Botswana’s fifth
president since independence. Mineral extraction,
principally diamond mining, dominates economic activity,
though tourism is a growing sector due to the country’s
conservation practices and extensive nature preserves.
Botswana has one of the world’s highest rates of HIV/AIDS
infection, but also one of Africa’s most progressive and
comprehensive programs for dealing with the disease.
Background: This uninhabited, volcanic, Antarctic island is
almost entirely covered by glaciers making it difficult to
approach; it is recognized as the most remote island on
Earth. (It is furthest in distance from any other point of
land, 1,639 km from Antarctica.) Bouvet Island was
discovered in 1739 by a French naval officer after whom it
is named. No claim was made until 1825, when the British
flag was raised. A few expeditions visited the island in the
late 19th century. In 1929, the UK waived its claim in favor
of Norway, which had occupied the island two years
previously. In 1971, Norway designated Bouvet Island and
the adjacent territorial waters a nature reserve. Since
1977, Norway has run an automated meteorological station
and studied foraging strategies and distribution of fur seals
and penguins on the island. In February 2006, an
earthquake weakened the station’s foundation causing it to
be blown out to sea in a winter storm. Norway erected a
new research station in 2014 that can hold six people for
periods of two to four months.
Background: Following more than three centuries under
Portuguese rule, Brazil gained its independence in 1822,
maintaining a monarchical system of government until the
abolition of slavery in 1888 and the _ subsequent
proclamation of a republic by the military in 1889. Brazilian
coffee exporters politically dominated the country until
populist leader Getulio VARGAS rose to power in 1930. By
far the largest and most populous country in South
America, Brazil underwent more than a half century of
populist and military government until 1985, when the
military regime peacefully ceded power to civilian rulers.
Brazil continues to pursue industrial and agricultural
growth and development of its interior. Having successfully
weathered a period of global financial difficulty in the late
20th century, Brazil was seen as one of the world’s
strongest emerging markets and a contributor to global
growth. The awarding of the 2014 FIFA World Cup and
2016 Summer Olympic Games, the first ever to be held in
South America, was seen as symbolic of the country’s rise.
However, from about 2013 to 2016, Brazil was plagued by a
sagging economy, high unemployment, and high inflation,
only emerging from recession in 2017. Former President
Dilma ROUSSEFF (2011-2016) was removed from office in
2016 by Congress for having committed impeachable acts
against Brazil’s budgetary laws, and her vice president,
Michel TEMER, served the remainder of her second term.
In October 2018, Jair BOLSONARO won the presidency
with 55 percent of the vote and assumed office on 1
January 2019.
Background: Basutoland was renamed the Kingdom of
Lesotho upon independence from the UK in 1966. The
Basotho National Party ruled the country during its first
two decades. King MOSHOESHOE II was exiled in 1990,
but returned to Lesotho in 1992 and was reinstated in 1995
and subsequently succeeded by his son, King LETSIE III, in
1996. Constitutional government was restored in 1993
after seven years of military rule. In 1998, violent protests
and a military mutiny following a contentious election
prompted a brief but bloody intervention by South African
and Botswana military forces under the aegis of the
Southern African Development Community. Subsequent
constitutional reforms restored relative political stability.
Peaceful parliamentary elections were held in 2002, but the
National Assembly elections in 2007 were hotly contested
and aggrieved parties disputed how the electoral law was
applied to award proportional seats in the Assembly. In
2012, competitive elections involving 18 parties saw Prime
Minister Motsoahae Thomas THABANE form a coalition
government—the first in the country’s history—that ousted
the 14-year incumbent, Pakalitha MOSISILI, who peacefully
transferred power the following month. MOSISILI returned
to power in snap elections in February 2015 after the
collapse of THABANE’s coalition government and an
alleged attempted military coup. In June 2017, THABANE
returned to become prime minister.','1965a6a62cfbf19fb9f61fb347d556e37813273a537122fbea35679fab4c1c3e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('861819a673d77aa0d959f73cd019094e327264a5660475bcd17b55757a8e3f71',2020,'SS','South Sudan','introduction',23,'Southern Ocean
Background: British explorer Samuel BAKER established the
colony of Equatoria in 1870, in the name of the Ottoman
Khedive of Egypt who claimed the territory. Headquartered
in Gondokoro (near modern day Juba), Equatoria in theory
composed most of what is now South Sudan. After being
cut off from colonial administration during the Mahdist War
from 1885-1898, Equatoria was made a state under the
Anglo-Egyptian condominium in 1899. It was largely left to
itself over the following decades, but Christian missionaries
converted much of the population and facilitated the spread
of English, rather than Arabic. Equatoria was ruled by
British colonial administrators separately from what is now
Sudan until the two colonies were combined at the 1947
Juba Conference, as part of British plans to prepare the
region for independence. When Sudan_ gained its
independence in 1956, it was with the understanding that
the southerners would be able to participate fully in the
political system. When the Arab Khartoum government
reneged on its promises, a mutiny began that led to two
prolonged periods of conflict (1955-1972 and 1983-2005) in
which perhaps 2.5 million people died—mostly civilians—
due to starvation and drought. Ongoing peace talks finally
resulted in a Comprehensive Peace Agreement, signed in
January 2005. As part of this agreement, the south was
granted a six-year period of autonomy to be followed by a
referendum on final status. The result of this referendum,
held in January 2011, was a vote of 98% in favor of
secession.
Since independence on 9 July 2011, South Sudan has
struggled with good governance and nation building and
has attempted to control opposition forces operating in its
territory. Economic conditions have deteriorated since
January 2012 when the government decided to shut down
oil production following bilateral disagreements with
Sudan. In December 2013, conflict between government
and opposition forces killed tens of thousands and led to a
dire humanitarian crisis with millions of South Sudanese
displaced and food insecure. The warring parties signed a
peace agreement in August 2015 that created a transitional
government of national unity in April 2016. However, in
July 2016, fighting broke out in Juba between the two
principal signatories, plunging the country back into
conflict. A “revitalized” peace agreement was signed in
September 2018 ending the fighting. Under the agreement,
the government and various rebel groups agreed that the
sides would form a unified national army and create a
transitional government by May 2019. The agreement was
extended until November 2019 and then subsequently to
February 2020. However, implementation has been stalled,
in part by a failure to agree on the country’s internal
political boundaries.
Background: The colonial boundaries created by Britain to
delimit Uganda grouped together a wide range of ethnic
groups with different political systems and cultures. These
differences complicated the establishment of a working
political community after independence was achieved in
1962. The dictatorial regime of Idi AMIN (1971-79) was
responsible for the deaths of some 300,000 opponents;
guerrilla war and human rights abuses under Milton
OBOTE (1980-85) claimed at least another 100,000 lives.
The rule of Yoweri MUSEVENI since 1986 has brought
relative stability and economic growth to Uganda. In
December 2017, parliament approved the removal of
presidential age limits, thereby making it possible for
MUSEVENI to continue standing for office. Uganda faces
numerous challenges, however, that could affect future
stability, including explosive population growth, power and
infrastructure constraints, corruption, underdeveloped
democratic institutions, and human rights deficits.
Background: Ukraine was the center of the first eastern
Slavic state, Kyivan Rus, which during the 10th and 11th
centuries was the largest and most powerful state in
Europe. Weakened by internecine quarrels and Mongol
invasions, Kyivan Rus was incorporated into the Grand
Duchy of Lithuania and eventually into the _ Polish-
Lithuanian Commonwealth. The cultural and religious
legacy of Kyivan Rus laid the foundation for Ukrainian
nationalism through subsequent centuries. A new
Ukrainian state, the Cossack Hetmanate, was established
during the mid-17th century after an uprising against the
Poles. Despite continuous Muscovite pressure, the
Hetmanate managed to remain autonomous for well over
100 years. During the latter part of the 18th century, most
Ukrainian ethnographic territory was absorbed by the
Russian Empire. Following the collapse of czarist Russia in
1917, Ukraine achieved a_ short-lived’ period of
independence (1917-20), but was reconquered and endured
a brutal Soviet rule that engineered two forced famines
(1921-22 and 1932-33) in which over 8 million died. In
World War II, German and Soviet armies were responsible
for 7 to 8 million more deaths. Although Ukraine achieved
independence in 1991 with the dissolution of the USSR,
democracy and prosperity remained elusive as the legacy
of state control and endemic corruption stalled efforts at
economic reform, privatization, and civil liberties.
A peaceful mass protest referred to as the “Orange
Revolution” in the closing months of 2004 forced the
authorities to overturn a rigged presidential election and to
allow a new internationally monitored vote that swept into
power a reformist slate under Viktor YUSHCHENKO.
Subsequent internal squabbles in the YUSHCHENKO camp
allowed his rival Viktor YANUKOVYCH to stage a comeback
in parliamentary (Rada) elections, become prime minister
in August 2006, and be elected president in February 2010.
In October 2012, Ukraine held Rada elections, widely
criticized by Western observers as flawed due to use of
government resources to favor ruling party candidates,
interference with media access, and harassment of
opposition candidates. President YANUKOVYCH’s
backtracking on a trade and cooperation agreement with
the EU in November 2013—in favor of closer economic ties
with Russia—and subsequent use of force against students,
civil society activists, and other civilians in favor of the
agreement led to a three-month protest occupation of
Kyiv’s central square. The government’s use of violence to
break up the protest camp in February 2014 led to all out
pitched battles, scores of deaths, international
condemnation, a failed political deal, and the president’s
abrupt departure for Russia. New elections in the spring
allowed pro-West president Petro POROSHENKO to assume
office in June 2014; he was succeeded by Volodymyr
ZELENSKyY in May 2019.
Shortly after YANUKOVYCH’s departure in late February
2014, Russian President PUTIN ordered the invasion of
Ukraine’s Crimean Peninsula falsely claiming the action
was to protect ethnic Russians living there. Two weeks
later, a “referendum” was held regarding the integration of
Crimea into the Russian Federation. The “referendum” was
condemned as illegitimate by the Ukrainian Government,
the EU, the US, and the UN General Assembly (UNGA). In
response to Russia’s illegal annexation of Crimea, 100
members of the UN passed UNGA resolution 68/262,
rejecting the “referendum” as baseless and invalid and
confirming the sovereignty, political independence, unity,
and territorial integrity of Ukraine. In mid-2014, Russia
began supplying proxies in two of Ukraine’s eastern
provinces with manpower, funding, and materiel driving an
armed conflict with the Ukrainian Government that
continues to this day. Representatives from Ukraine,
Russia, and the unrecognized Russian proxy republics
signed the Minsk Protocol and Memorandum in September
2014 to end the conflict. However, this agreement failed to
stop the fighting or find a political solution. In a renewed
attempt to alleviate ongoing clashes, leaders of Ukraine,
Russia, France, and Germany negotiated a follow-on
Package of Measures in February 2015 to implement the
Minsk agreements. Representatives from Ukraine, Russia,
the unrecognized Russian proxy republics, and the
Organization for Security and Cooperation in Europe also
meet regularly to facilitate implementation of the peace
deal. More than 13,000 civilians have been killed or
wounded as a result of the Russian intervention in eastern
Ukraine.','f86891dae7b72cdfb914cb2d4414fa1481f6d99ced4f41eb00cb9d8e66b9ea6c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b586f1aab90c24921d777352666c155f2fc2e0519249b2a6e7f80836655e0c0d',2020,'CH','Switzerland','introduction',24,'Syria
Taiwan
Background: The Swiss Confederation was founded in 1291
as a defensive alliance among three cantons. In succeeding
years, other localities joined the original three. The Swiss
Confederation secured its independence from the Holy
Roman Empire in 1499. A _ constitution of 1848,
subsequently modified in 1874 to allow voters to introduce
referenda on proposed laws, replaced the confederation
with a _ centralized federal government. Switzerland’s
sovereignty and neutrality have long been honored by the
major European powers, and the country was not involved
in either of the two world wars. The political and economic
integration of Europe over the past half century, as well as
Switzerland’s role in many UN _ and_ international
organizations, has strengthened Switzerland’s ties with its
neighbors. However, the country did not officially become a
UN member until 2002. Switzerland remains active in
many UN and international organizations but retains a
strong commitment to neutrality.','fd7453776bbf330356bec0f1a5e0aa93eb1eab70173cc547a2eefb369ba2ce1d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3735a6a8b0d623dae8651e5b1c5ed6b31afa16f941086d9268dfbf6d8e7964b7',2020,'US','United States','introduction',25,'United States Pacific Island Wildlife Refuges
World Oceans
The World Factbook is prepared by the Central Intelligence
Agency for the use of US Government officials, and the
style, format, coverage, and content are designed to meet
their specific requirements. Information is provided by
Antarctic Information Program (National Science
Foundation), Armed Forces Medical Intelligence Center
(Department of Defense), Bureau of the Census
(Department of Commerce), Bureau of Labor Statistics
(Department of Labor), Central Intelligence Agency,
Council of Managers of National Antarctic Programs,
Defense Intelligence Agency (Department of Defense),
Department of Energy, Department of State, Fish and
Wildlife Service (Department of the Interior), Maritime
Administration (Department of Transportation), National
Geospatial-Intelligence Agency (Department of Defense),
Naval Facilities Engineering Command (Department of
Defense), Office of Insular Affairs (Department of the
Interior), Office of Naval Intelligence (Department of
Defense), US Board on Geographic Names (Department of
the Interior), US Transportation Command (Department of
Defense), United Nations Population Division (World
Urbanization Prospects: The 2018 Revision and World
Population Prospects: The 2019 Revision urbanization and
population data used with permission), International
Telecommunication Union, International Institute for
Strategic Studies, Oil & Gas Journal, and other public and
private sources.
The Factbook is in the public domain. Accordingly, it may
be copied freely without permission of the Central
Intelligence Agency (CIA). The official seal of the CIA,
however, may NOT be copied without permission as
required by the CIA Act of 1949 (50 U.S.C. section 403m).
Misuse of the official seal of the CIA could result in civil
and criminal penalties.
Citation model: The World Factbook 2020. Washington,
DC: Central Intelligence Agency, 2020.
https://www.cia.gov/library/publications/resources/the-
world-factbook/index.html
Comments and queries are welcome and may be addressed
to: Central Intelligence Agency Attn: Office of Public
Affairs Washington, DC 20505
A BRIEF HISTORY OF BASIC
INTELLIGENCE AND THE WORLD
FACTBOOK
The Intelligence Cycle is the process by which information
is acquired, converted into intelligence, and made available
to policymakers. Information is raw data from any source,
data that may be fragmentary, contradictory, unreliable,
ambiguous, deceptive, or wrong. Intelligence is information
that has been collected, integrated, evaluated, analyzed,
and interpreted. Finished intelligence is the final product of
the Intelligence Cycle ready to be delivered to the
policymaker.
The three types of finished intelligence are: basic, current,
and estimative. Basic intelligence provides the fundamental
and factual reference material on a country or issue.
Current intelligence reports on new _ developments.
Estimative intelligence judges probable outcomes. The
three are mutually supportive: basic intelligence is the
foundation on which the other two are constructed; current
intelligence continually updates the inventory of
knowledge; and estimative intelligence revises overall
interpretations of country and issue prospects for guidance
of basic and current intelligence. The World Factbook, The
President’s Daily Brief and the National Intelligence
Estimates are examples of the three types of finished
intelligence.
The United States has carried on foreign intelligence
activities since the days of George Washington but only
since World War II have they been coordinated on a
government-wide basis. Three programs have highlighted
the development of coordinated basic intelligence since
that time: (1) the Joint Army Navy Intelligence Studies
(JANIS), (2) the National Intelligence Survey (NIS), and (3)
The World Factbook.
During World War II, intelligence consumers realized that
the production of basic intelligence by different
components of the US Government resulted in a great
duplication of effort and conflicting information. The
Japanese attack on Pearl Harbor in 1941 brought home to
leaders in Congress and the executive branch the need for
integrating departmental reports to national policymakers.
Detailed and coordinated information was needed not only
on such major powers as Germany and Japan, but also on
places of little previous interest. In the Pacific Theater, for
example, the Navy and Marines had to launch amphibious
operations against many islands about which information
was unconfirmed or nonexistent. Intelligence authorities
resolved that the United States should never again be
caught unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train
(Office of Naval Intelligence—ONI), and Gen. William J.
Donovan (Director of the Office of Strategic Services—OSS)
decided that a joint effort should be initiated. A steering
committee was appointed on 27 April 1943 that
recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish
the Joint Army Navy Intelligence Studies (JANIS). JANIS
was the first interdepartmental basic intelligence program
to fulfill the needs of the US Government for an
authoritative and coordinated appraisal of strategic basic
intelligence. Between April 1943 and July 1947, the board
published 34 JANIS studies. JANIS performed well in the
war effort, and numerous letters of commendation were
received, including a statement from Adm. Forrest
Sherman, Chief of Staff, Pacific Ocean Areas, which said,
“JANIS has become the indispensable reference work for
the shore-based planners.”
The need for more comprehensive basic intelligence in the
postwar world was well expressed in 1946 by George S.
Pettee, a noted author on national security. He wrote in The
Future of American Secret Intelligence (Infantry Journal
Press, 1946, page 46) that world leadership in peace
requires even more elaborate intelligence than in war. “The
conduct of peace involves all countries, all human activities
—not just the enemy and his war production.”
The Central Intelligence Agency was established on 26 July
1947 and officially began operating on 18 September 1947.
Effective 1 October 1947, the Director of Central
Intelligence assumed operational responsibility for JANIS.
On 13 January 1948, the National Security Council issued
Intelligence Directive (NSCID) No. 3, which authorized the
National Intelligence Survey (NIS) program as a peacetime
replacement for the wartime JANIS program. Before
adequate NIS country sections could be _ produced,
government agencies had to develop more comprehensive
gazetteers and better maps. The US Board on Geographic
Names (BGN) compiled the names; the Department of the
Interior produced the gazetteers; and CIA produced the
maps.
The Hoover Commission’s Clark Committee, set up in 1954
to study the structure and administration of the CIA,
reported to Congress in 1955 that: “The National
Intelligence Survey is an invaluable publication which
provides the essential elements of basic intelligence on all
areas of the world. There will always be a continuing
requirement for keeping the Survey up-to-date.” The
Factbook was created as an annual summary and update to
the encyclopedic NIS studies. The first classified Factbook
was published in August 1962, and the first unclassified
version was published in June 1971. The NIS program was
terminated in 1973 except for the Factbook, map, and
gazetteer components. The 1975 Factbook was the first to
be made available to the public with sales through the US
Government Printing Office (GPO). The Factbook was first
made available on the Internet in June 1997. The year 2019
marks the 72nd anniversary of the establishment of the
Central Intelligence Agency and the 76th year of
continuous’ basic intelligence support to the US
Government by The World Factbook and its’ two
predecessor programs.
The Evolution of The World Factbook National Basic
Intelligence Factbook produced semiannually until 1980.
Country entries include sections on Land, Water, People,
Government, Economy, Communications, and Defense
Forces.
1981—Publication becomes an annual product and is
renamed The World Factbook. A total of 165 nations are
covered on 225 pages.
1983—Appendices (Conversion Factors, International
Organizations) first introduced.
1984—Appendices expanded; now include: A. The United
Nations, B. Selected United Nations Organizations, C.
Selected International Organizations, D. Country
Membership in Selected Organizations, E. Conversion
Factors.
1987—A new Geography section replaces the former
separate Land and Water sections. UN Organizations and
Selected International Organizations appendices merged
into a new International Organizations appendix. First
multi-color-cover Factbook.
1988—More than 40 new geographic entities added to
provide complete world coverage without overlap or
omission. Among the new entities are Antarctica, oceans
(Arctic, Atlantic, Indian, Pacific), and the World. The front-
of-the-book explanatory introduction expanded and retitled
to Notes, Definitions, and Abbreviations. Two new
Appendices added: Weights and Measures (in place of
Conversion Factors) and a Cross-Reference List of
Geographic Names. Factbook size reaches 300 pages.
1989—Economy section completely revised and now
includes an “Overview” briefly describing a country’s
economy. New entries added under People, Government,
and Communications.
1990—The Government section revised and considerably
expanded with new entries.
1991—A new International Organizations and Groups
appendix added. Factbook size reaches 405 pages.
1992—Twenty new successor state entries replace those of
the Soviet Union and Yugoslavia. New countries are
respectively: Armenia, Azerbaijan, Belarus, Estonia,
Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan; and Bosnia and Hercegovina, Croatia,
Macedonia, Serbia and Montenegro, Slovenia. Number of
nations in the Factbook rises to 188.
1993—Czechoslovakia’s split necessitates new Czech
Republic and Slovakia entries. New Eritrea entry added
after it secedes from Ethiopia. Substantial enhancements
made to Geography section.
1994—Two new appendices address Selected International
Environmental Agreements. The gross domestic product
(GDP) of most developing countries changed to a
purchasing power parity (PPP) basis rather than an
exchange rate basis. Factbook size up to 512 pages.
1995—The GDP of all countries now presented on a PPP
basis. New appendix lists estimates of GDP on an exchange
rate basis. Communications category split; “Railroads,”
“Highways,” “Inland waterways,” “Pipelines,” “Merchant
marine,” and “Airports” entries now make up a new
Transportation category. The World Factbook is first
produced on CD-ROM.
1996—Maps accompanying each entry now present more
detail. Flags also introduced for nearly all entities. Various
new entries appear under Geography and Communications.
Factbook abbreviations consolidated into a new Appendix
A. Two new appendices present a Cross-Reference List of
Country Data Codes and a Cross-Reference List of
Hydrogeographic Data Codes. Geographic coordinates
added to Appendix H, Cross-Reference List of Geographic
Names. Factbook size expands by 95 pages in one year to
reach 652.
1997— The World Factbook introduced onto the Internet. A
special printed edition prepared for the CIA’s 50th
anniversary. A schema or Guide to Country Profiles
introduced. New color maps and flags now accompany each
country profile. Category headings distinguished by shaded
backgrounds. Number of categories expanded to nine with
the addition of an Introduction (for only a few countries)
and ‘Transnational Issues (which includes “Disputes-
international” and “Illicit drugs”).
1998—The Introduction category with two. entries,
“Current issues” and “Historical perspective,” expanded to
more countries. Last year for the production of CD-ROM
versions of the Factbook.
1999—“Historical perspective” and “Current issues”
entries in the Introduction category combined into a new
“Background” statement. Several new Economy entries
introduced. A new physical map of the world added to the
back-of-the-book reference maps.
2000—A new “country profile” added on the Southern
Ocean. The Background statements dramatically expanded
to over 200 countries and possessions. A number of new
Communications entries added.
2001—Background entries completed for all 267 entities in
the Factbook. Several new HIV/AIDS entries introduced
under the People category. Revision begun on individual
country maps to include elevation extremes and a partial
geographic grid. Weights and Measures appendix deleted.
2002—New entry on “Distribution of Family income—Gini
index” added. Revision of individual country maps
continued (process still ongoing).
2003—In the Economy category, petroleum entries added
for “oil production,” “consumption,” “exports,” “imports,”
and “proved reserves,” as well as “natural gas proved
reserves.”
yw a
2004—Bi-weekly updates launched on The World Factbook
website. Additional petroleum entries included for “natural
gas production,” “consumption,” “exports,” and “imports.”
In the Transportation category, under “Merchant marine,”
subfields added for foreign-owned vessels and _ those
registered in other countries. Descriptions of the many
forms of government mentioned in the _ Factbook
incorporated into the Definitions and Notes.
my tt yw
2005—In the People category, a “Major infectious
diseases” field added for countries deemed to pose a higher
risk for travelers. In the Economy category, entries
included for “Current account balance,” “Investment,”
“Public debt,” and “Reserves of foreign exchange and
gold.” The Transnational issues category expanded to
include “Refugees and internally displaced persons.” Size
of the printed Factbook reaches 702 pages.
2006—In the Economy category, national GDP figures now
presented at Official Exchange Rates (OER) in addition to
GDP at purchasing power parity (PPP). Entries in the
Transportation section reordered; “Highways” changed to
“Roadways,” and “Ports and harbors” to “Ports and
terminals.”
2007—In the Government category, the “Capital” entry
significantly expanded with up to four subfields, including
new information having to do with time. The subfields
consist of the name of the capital itself, its geographic
coordinates, the time difference at the capital from
coordinated universal time (UTC), and, if applicable,
information on daylight saving time (DST). Where
appropriate, a special note is added to highlight those
countries with multiple time zones. A “Trafficking in
persons” entry added to the Transnational issues category.
A new appendix, Weights and Measures, (re)introduced to
the online version of the Factbook.
2008—In the Geography category, two fields focus on the
increasingly vital resource of water: “Total renewable
water resources” and “Freshwater withdrawal.” In the
Economy category, three fields added for: “Stock of direct
foreign investment—at home,” “Stock of direct foreign
investment—abroad,” and “Market value of publicly traded
shares.” Concise descriptions of all major religions
included in the Definitions and Notes. Responsibility for
printing of The World Factbook turned over to the
Government Printing Office.
2009—The online Factbook site completely redesigned
with many new features. In the People category, two new
fields provide information on education in terms of
opportunity and resources: “School Life Expectancy” and
“Education expenditures.” Additionally, the “Urbanization”
entry expanded to include all countries. In the Economy
category, five fields added: “Central bank discount rate,”
“Commercial bank prime lending rate,” “Stock of narrow
money,” “Stock of broad money,” and “Stock of domestic
credit.”
2010—Weekly updates inaugurated on The World Factbook
website. The dissolution of the Netherlands Antilles results
in two new listings: Curacao and Sint Maarten. In the
Communications category, a “Broadcast media” field
replaces the former “Radio broadcast stations” and “TV
broadcast stations” entries. In the Geography section,
under “Natural hazards,” a Volcanism subfield added for
countries with historically active volcanoes. In the
Government category, a new “National anthems” field
introduced. Concise descriptions of all major Legal systems
incorporated into the Definitions and Notes. In order to
facilitate comparisons over time, dozens of the entries in
the Economy category expanded to include two (and in
some cases three) years’ worth of data.
2011—The People section expanded to People and Society,
incorporating ten new fields. The Economy category added
“Taxes and other revenues” and “Budget surplus (+) or
deficit (-),” while the Government section introduced
“International law organization participation” and
“National symbols.” A new African nation, South Sudan,
brings the total number of countries in The World Factbook
to 195.
2012—A new Energy category introduced with 23 energy-
related fields. Several distinctive features added to The
World Factbook website: 1) playable audio files in the
Government section for the National Anthems entry, 2)
online graphics in the form of a Population Pyramid feature
in the People and Society category’s Age Structure field,
and 3) a Users Guide enabling visitors to navigate the
Factbook more easily and efficiently. A new and distinctive
Map of the World Oceans highlights an expanded array of
regional and country maps. Size of the printed Factbook’s
50th anniversary edition reaches 847 pages.
2013—In the People and Society section five fields
introduced: “Demographic profile,” “Mother’s mean age at
first birth,” “Contraceptive prevalence rate,” “Dependency
ratios,” and “Child labor—children ages 5-14.” In the
Transnational Issues category, a new stateless persons
subfield embedded under the “Refugees and internally
displaced persons” entry. In the Economy section two fields
added: “GDP - composition by end use” and “Gross national
saving.” In the Government category the “Judicial branch”
entry revised and expanded to include three new subfields:
highest court(s), judge selection and term of office, and
subordinate courts.
2014—In the Transportation category, the “Ports and
terminals” field substantially expanded with subfields for
major seaport(s), river port(s), lake port(s), oil/gas
terminal(s), LNG terminal(s), dry bulk cargo port(s),
container port(s), and _ cruise/ferry port(s). In_ the
Geography section, the “Land boundaries entry” revised for
all countries, including the total country border length as
well as the border lengths for all neighboring countries.
2015—In the Government category, the first part of the
“Legislative branch” field thoroughly revised, expanded,
and updated for all countries under a new description
heading. This subentry includes the legislative structure,
the formal name(s), the number of legislative seats, the
types of voting constituencies and voting systems, and the
member term of office. In the Geography category, the
“Land use” entry expanded to include agricultural land,
forest land, and other uses. Area Comparison Maps
introduced online for about half of the world’s countries.
These graphics show the size of a country in relation to a
part of the United States. (More maps to follow as they
become available.) 2016—In the Government section for all
countries, a new “Citizenship” field added to describe
policies related to the acquisition of citizenship and to the
recognition of dual citizenship. Also, under the “Country
name” entry, etymologies (historical origins) added to
explain how countries acquired their names. In the Energy
section, an “Electricity access” field introduced with
subfields summarizing total access to electricity within a
country, as well as for urban and rural populations. In the
Transportation category, an expansive National air
transport system field presents info on the number of
registered air carriers, number of operating aircraft,
annual passenger traffic, and annual freight traffic 2017—
In the Government category, the “Constitution” entry
revised and expanded with new subfields for history and
amendments. Information on piracy moved from the
Transportation category to a new “Maritime threats” field
in the Military and Security category. In the Transportation
section, the “Merchant marine” entry revised to not only
include the total number of ships, but also the major types:
bulk carrier, container ship, general cargo, oil tanker, and
other. A new “Population distribution” field added to both
the Geography and People and Society categories. The
Government Printing Office discontinued printing The Word
Factbook, but annual online editions may be downloaded
from the Factbook site.
2018—One-Page Country Summaries introduced for
selected countries in the Factbook; more to follow in the
future. The Summaries highlight key information from
lengthier World Factbook entries and are intended for use
by teachers, students, travelers, researchers, news
reporters, or anyone with an interest in geography. Dozens
of additional area comparison maps added; about two-
thirds of country entries now include these popular maps.
In the Communications category, a “Broadband—fixed
subscriptions” entry now included.
2019—The Factbook’s World entry acquires many new Top
Ten listings including those for the largest forests, largest
deserts, longest mountain ranges, and climate extremes
(Top Ten driest, wettest, coldest, and hottest places on
earth).
Also in the World entry, seven new continent area
comparison maps compare their size to that of the US. In
each of the five ocean entries, under the Economy section,
a “Maritime fisheries” field includes info on major fishing
regions, total tonnage caught, and principal fish catches.
DEFINITIONS AND NOTES
Abbreviations This information is included in Appendix
A: Abbreviations, which includes all abbreviations and
acronyms used in the Factbook, with their expansions.
Acronyms An acronym is an abbreviation coined from the
initial letter of each successive word in a term or phrase. In
general, an acronym made up solely from the first letter of
the major words in the expanded form is rendered in all
capital letters (NATO from North Atlantic Treaty
Organization; an exception would be ASEAN for
Association of Southeast Asian Nations). In general, an
acronym made up of more than the first letter of the major
words in the expanded form is rendered with only an initial
capital letter (Comsat from Communications Satellite
Corporation; an exception would be NAM from Nonaligned
Movement). Hybrid forms are sometimes used _ to
distinguish between initially identical terms (ICC for
International Chamber of Commerce and ICCt for
International Criminal Court).
Administrative divisions This entry generally gives
the numbers, designatory terms, and first-order
administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been
reported but not yet acted on by the BGN are noted.
Geographic names conform to spellings approved by the
BGN with the exception of the omission of diacritical marks
and special characters.
Age structure This entry provides the distribution of the
population according to age. Information is included by sex
and age group as follows: 0-14 years (children), 15-24 years
(early working age), 25-54 years (prime working age), 55-
64 years (mature working age), 65 years and over (elderly).
The age structure of a population affects a nation’s key
socioeconomic issues. Countries with young populations
(high percentage under age 15) need to invest more in
schools, while countries with older populations (high
percentage ages 65 and over) need to invest more in the
health sector. The age structure can also be used to help
predict potential political issues. For example, the rapid
growth of a young adult populatio','acaff24f081da970ef948ef058eb2af1d90fef326659633f0095892df67d2836','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdc42526fb72699d422b2b4ef39cabe217c3ffb3a08eeeb877b97b9b1c117a3e',2020,'US','United States','introduction',26,'n unable to find
employment can lead to unrest.
Agriculture—products This entry is an ordered listing
of major crops and products starting with the most
important.
Airports This entry gives the total number of airports or
airfields recognizable from the air. The runway(s) may be
paved (concrete or asphalt surfaces) or unpaved (grass,
earth, sand, or gravel surfaces) and may include closed or
abandoned installations. Airports or airfields that are no
longer recognizable (overgrown, no facilities, etc.) are not
included. Note that not all airports have accommodations
for refueling, maintenance, or air traffic control.
Airports—with paved runways This entry gives the
total number of airports with paved runways (concrete or
asphalt surfaces) by length. For airports with more than
one runway, only the longest runway is included according
to the following five groups—(1) over 3,047 m (over 10,000
ft), (2) 2,438 to 3,047 m (8,000 to 10,000 ft), (3) 1,524 to
2,437 m (5,000 to 8,000 ft), (4) 914 to 1,523 m (3,000 to
9,000 ft), and (5) under 914 m (under 3,000 ft). Only
airports with usable runways are included in this listing.
Not all airports have facilities for refueling, maintenance,
or air traffic control. The type aircraft capable of operating
from a runway of a given length is dependent upon a
number of factors including elevation of the runway,
runway gradient, average maximum daily temperature at
the airport, engine types, flap settings, and take-off weight
of the aircraft.
Airports—with unpaved runways This entry gives
the total number of airports with unpaved runways (grass,
dirt, sand, or gravel surfaces) by length. For airports with
more than one runway, only the longest runway is included
according to the following five groups—(1) over 3,047 m
(over 10,000 ft), (2) 2,438 to 3,047 m (8,000 to 10,000 ft),
(3) 1,524 to 2,437 m (5,000 to 8,000 ft), (4) 914 to 1,523 m
(3,000 to 5,000 ft), and (5) under 914 m (under 3,000 ft).
Only airports with usable runways are included in this
listing. Not all airports have facilities for refueling,
maintenance, or air traffic control. The type aircraft
capable of operating from a runway of a given length is
dependent upon a number of factors including elevation of
the runway, runway gradient, average maximum daily
temperature at the airport, engine types, flap settings, and
take-off weight of the aircraft.
Appendixes This section includes Factbook-related
material by topic.
Area This entry includes three subfields. Total area is the
sum of all land and water areas delimited by international
boundaries and/or coastlines. Land area is the aggregate of
all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs,
rivers). Water area is the sum of the surfaces of all inland
water bodies, such as lakes, reservoirs, or rivers, as
delimited by international boundaries and/or coastlines.
Area—comparative This entry provides an area
comparison based on total area equivalents. Most entities
are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by
the US Bureau of the Census. The smaller entities are
compared with Washington, DC (178 sq km, 69 sq mi) or
The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146
acres).
Area-rankings This entry, which appears only in the
World, Geography category, provides rankings for the
earth’s largest (or smallest) continents, countries, oceans,
islands, mountain ranges, or other physical features.
Background This entry usually highlights major historic
events and current issues and may include a statement
about one or two key future trends.
Birth rate This entry gives the average annual number of
births during a year per 1,000 persons in the population at
midyear; also known as crude birth rate. The birth rate is
usually the dominant factor in determining the rate of
population growth. It depends on both the level of fertility
and the age structure of the population.
Broadband—fixed subscriptions This entry gives the
total number of fixed-broadband subscriptions, as well as
the number of subscriptions per 100 inhabitants. Fixed
broadband is a physical wired connection to the Internet
(e.g., Coaxial cable, optical fiber) at speeds equal to or
greater than 256 kilobits/second (256 kbit/s).
Broadcast media This entry provides information on
the approximate number of public and private TV and radio
stations in a country, as well as basic information on the
availability of satellite and cable TV services.
Budget This entry includes revenues, expenditures, and
capital expenditures. These figures are calculated on an
exchange rate basis, i.e., not in purchasing power parity
(PPP) terms.
Budget surplus (+) or deficit (-) This entry records
the difference between national government revenues and
expenditures, expressed as a percent of GDP. A positive (+)
number indicates that revenues exceeded expenditures (a
budget surplus), while a negative (-) number indicates the
reverse (a budget deficit). Normalizing the data, by
dividing the budget balance by GDP enables_ easy
comparisons across countries and indicates whether a
national government saves or borrows money. Countries
with high budget deficits (relative to their GDPs) generally
have more difficulty raising funds to finance expenditures,
than those with lower deficits.
Capital This entry gives the name of the seat of
government, its geographic coordinates, the’ time
difference relative to Coordinated Universal Time (UTC)
and the time observed in Washington, DC, and, if
applicable, information on daylight saving time (DST).
Where appropriate, a special note has been added to
highlight those countries that have multiple time zones.
Carbon dioxide emissions from consumption of
energy This entry is the total amount of carbon dioxide,
measured in metric tons, released by burning fossil fuels in
the process of producing and consuming energy.
Children under the age of 5 years underweight
This entry gives the percent of children under five
considered to be underweight. Underweight means weight-
for-age is approximately 2 kg below for standard at age
one, 3 kg below standard for ages two and three, and 4 kg
below standard for ages four and five. This statistic is an
indicator of the nutritional status of a community. Children
who suffer from growth retardation as a result of poor diets
and/or recurrent infections tend to have a greater risk of
suffering illness and death.
Citizenship This entry provides information related to
the acquisition and exercise of citizenship; it includes four
subfields: citizenship by birth—describes the acquisition
of citizenship based on place of birth, known as Jus soli,
regardless of the citizenship of parents.
citizenship by descent—only describes the acquisition
of citizenship based on the principle of Jus sanguinis, or
by descent, where at least one parent is a citizen of the
state and being born within the territorial limits of the
state is not required. The majority of countries adhere to
this practice. In some cases, citizenship is conferred
through the father or mother exclusively.
dual citizenship recognized—indicates whether a
state permits a citizen to simultaneously hold citizenship
in another state. Many states do not permit dual
citizenship and the voluntary acquisition of citizenship in
another country is grounds for revocation of citizenship.
Holding dual citizenship makes an individual legally
obligated to more than one state and can negate the
normal consular protections afforded to citizens outside
their original country of citizenship.
residency requirement for naturalization—lists the
length of time an applicant is required to live in a state
before applying for naturalization. In most countries
citizenship can be acquired through the legal process of
naturalization. The requirements for naturalization vary
by state but generally include no criminal record, good
health, economic wherewithal, and aé_ period of
authorized residency in the state. This time period can
vary enormously among states and is often used to make
the acquisition of citizenship difficult or impossible.
Civil aircraft registration country code prefix
This entry provides the one- or two-character alphanumeric
code indicating the nationality of civil aircraft. Article 20 of
the Convention on International Civil Aviation (Chicago
Convention), signed in 1944, requires that all aircraft
engaged in international air navigation bear appropriate
nationality marks. The aircraft registration number consists
of two parts: a prefix consisting of a one- or two-character
alphanumeric code indicating nationality and a registration
suffix of one to five characters for the specific aircraft. The
prefix codes are based upon radio call-signs allocated by
the International Telecommunications Union (ITU) to each
country. Since 1947, the International Civil Aviation
Organization (ICAO) has managed code standards and their
allocation.
Climate This entry includes a brief description of typical
weather regimes throughout the year; in the Word entry
only, it includes four subfields that describe climate
extremes: ten driest places on earth (average annual
precipitation) describes the annual average precipitation
measured in both millimeters and inches for selected
countries with climate extremes.
ten wettest places on earth (average annual
precipitation) describes the annual average precipitation
measured in both millimeters and inches for selected
countries with climate extremes.
ten coldest places on earth (lowest average monthly
temperature) describes temperature measured in both
degrees Celsius and Fahrenheit as well as the month of
the year for selected countries with climate extremes.
ten hottest places on earth (highest average monthly
temperature) describes the temperature measured both
in degrees Celsius and Fahrenheit as well the month of
the year for selected countries with climate extremes.
Coastline This entry gives the total length of the
boundary between the land area (including islands) and the
sea.
Communications This category deals with the means of
exchanging information and includes the telephone, radio,
television, and Internet host entries.
Communications—note This entry includes
miscellaneous communications information of significance
not included elsewhere.
Constitution This entry provides information on a
country’s constitution and includes two subfields. The
history subfield includes the dates of previous constitutions
and the main steps and dates in formulating and
implementing the latest constitution. For countries with 1-3
previous constitutions, the years are listed; for those with
4-9 previous, the entry is listed as “several previous,” and
for those with 10 or more, the entry is “many previous.”
The amendments subfield summarizes the process of
amending a country’s constitution—from proposal through
passage—and the dates of amendments, which are treated
in the same manner as the constitution dates. Where
appropriate, summaries are composed from’ English-
language translations of non-English constitutions, which
derive from official or non-official translations or machine
translators.
The main steps in creating a constitution and amending it
usually include the following steps: proposal, drafting,
legislative and/or executive branch review and approval,
public referendum, and entry into law. In many countries
this process is lengthy. Terms commonly used to describe
constitutional changes are “amended,” “revised,” or
“reformed.” In countries such as South Korea and
Turkmenistan, sources differ as to whether changes are
stated as new constitutions or are amendments/revisions to
existing ones.
A few countries including Canada, Israel, and the UK have
no single constitution document, but have various written
and unwritten acts, statutes, common laws, and practices
that, when taken together, describe a body of fundamental
principles or established precedents as to how their
countries are governed. Some special regions (Hong Kong,
Macau) and countries (Oman, Saudi Arabia) use the term
“basic law” instead of constitution.
A number of self-governing dependencies and territories
such as the Cayman Islands, Bermuda, and Gibraltar (UK),
Greenland and Faroe Islands (Denmark), Aruba, Curacao,
and Sint Maarten (Netherlands), and Puerto Rico and the
Virgin Islands (US) have their own constitutions.
Contraceptive prevalence rate This field gives the
percent of women of reproductive age (15-49) who are
married or in union and are using, or whose sexual partner
is using, a method of contraception according to the date of
the most recent available data. The contraceptive
prevalence rate is an indicator of health services,
development, and women’s empowerment. It is also useful
in understanding, past, present, and future fertility trends,
especially in developing countries.
Coordinated Universal Time (UTC) UTC is the
international atomic time scale that serves as the basis of
timekeeping for most of the world. The hours, minutes, and
seconds expressed by UTC represent the time of day at the
Prime Meridian (0° longitude) located near Greenwich,
England as reckoned from midnight. UTC is calculated by
the Bureau International des Poids et Measures (BIPM) in
Sevres, France. The BIPM averages data collected from
more than 200 atomic time and frequency standards
located at about 50 laboratories worldwide. UTC is the
basis for all civil time, with the world divided into time
zones expressed as positive or negative differences from
UTC. UTC is also referred to as “Zulu time.” See the
Standard Time Zones of the World map included with the
Reference Maps.
Country data codes See Data codes.
Country map Most versions of the Factbook provide a
country map in color. The maps were produced from the
best information available at the time of preparation.
Names and/or boundaries may have changed subsequently.
Country name This entry includes all forms of the
country’s name approved by the US Board on Geographic
Names (Italy is used as an example): conventional long
form (Italian Republic), conventional short form (Italy),
local long form (Repubblica Italiana), local short form
(Italia), former (Kingdom of Italy), as well as_ the
abbreviation. Also see the Terminology note.
Crude oil—exports This entry is the total amount of
crude oil exported, in barrels per day (bbl/day).
Crude oil—imports This entry is the total amount of
crude oil imported, in barrels per day (bbl/day).
Crude oil—production This entry is the total amount of
crude oil produced, in barrels per day (bbl/day).
Crude oil—proved reserves This entry is the stock of
proved reserves of crude oil, in barrels (bbl). Proved
reserves are those quantities of petroleum which, by
analysis of geological and engineering data, can be
estimated with a high degree of confidence to be
commercially recoverable from a given date forward, from
known reservoirs and under current economic conditions.
Current account balance This entry records a
country’s net trade in goods and services, plus net earnings
from rents, interest, profits, and dividends, and net transfer
payments (such as pension funds and worker remittances)
to and from the rest of the world during the period
specified. These figures are calculated on an exchange rate
basis, i.e., not in purchasing power parity (PPP) terms.
Current Health Expenditure = Current Health
Expenditure (CHE) describes the share of spending on
health in each country relative to the size of its economy. It
includes expenditures corresponding to _ the final
consumption of health care goods and services and
excludes investment, exports, and intermediate
consumption. CHE shows the importance of the health
sector in the economy and indicates the priority given to
health in monetary terms. Note: Current Health
Expenditure replaces the former Health Expenditures field
and is calculated differently.
Data codes This information is presented in Appendix
D: Cross-Reference List of Country Data Codes and
Appendix E: Cross-Reference List of Hydrographic
Data Codes.
Date of information In general, information available
as of January in a given year is used in the preparation of
the printed edition.
Daylight Saving Time (DST) This entry is included for
those entities that have adopted a policy of adjusting the
official local time forward, usually one hour, from Standard
Time during summer months. Such policies are most
common in mid-latitude regions.
Death rate This entry gives the average annual number
of deaths during a year per 1,000 population at midyear;
also known as crude death rate. The death rate, while only
a rough indicator of the mortality situation in a country,
accurately indicates the current mortality impact on
population growth. This indicator is significantly affected
by age distribution, and most countries will eventually
show a rise in the overall death rate, in spite of continued
decline in mortality at all ages, as declining fertility results
in an aging population.
Debt—external This entry gives the total public and
private debt owed to nonresidents repayable in
internationally accepted currencies, goods, or services.
These figures are calculated on an exchange rate basis, i.e.,
not in purchasing power parity (PPP) terms.
Demographic profile This entry describes a country’s
key demographic features and trends and how they vary
among regional, ethnic, and socioeconomic sub-
populations. Some of the topics addressed are population
age structure, fertility, health, mortality, poverty, education,
and migration.
Dependency ratios Dependency ratios are a measure
of the age structure of a population. They relate the
number of individuals that are likely to be economically
“dependent” on the support of others. Dependency ratios
contrast the ratio of youths (ages 0-14) and the elderly
(ages 65+) to the number of those in the working-age
group (ages 15-64). Changes in the dependency ratio
provide an _ indication of potential social support
requirements resulting from changes in population age
structures. As fertility levels decline, the dependency ratio
initially falls because the proportion of youths decreases
while the proportion of the population of working age
increases. As _ fertility levels continue to _ decline,
dependency ratios eventually increase because the
proportion of the population of working age starts to
decline and the proportion of elderly persons continues to
increase.
total dependency ratio—The total dependency ratio is
the ratio of combined youth population (ages 0-14) and
elderly population (ages 65+) per 100 people of working
age (ages 15-64). A high total dependency ratio
indicates that the working-age population and the
overall economy face a greater burden to support and
provide social services for youth and elderly persons,
who are often economically dependent.
youth dependency ratio—The youth dependency ratio
is the ratio of the youth population (ages 0-14) per 100
people of working age (ages 15-64). A high youth
dependency ratio indicates that a greater investment
needs to be made in schooling and other services for
children.
elderly dependency ratio—The elderly dependency
ratio is the ratio of the elderly population (ages 65+) per
100 people of working age (ages 15-64). Increases in the
elderly dependency ratio put added pressure on
governments to fund pensions and healthcare.
potential support ratio—The potential support ratio is
the number of working-age people (ages 15-64) per one
elderly person (ages 65+). As a population ages, the
potential support ratio tends to fall, meaning there are
fewer potential workers to support the elderly.
Dependency status This entry describes the formal
relationship between a particular nonindependent entity
and an independent state.
Dependent areas This entry contains an alphabetical
listing of all nonindependent entities associated in some
way with a particular independent state.
Diplomatic representation The US Government has
diplomatic relations with 190 independent states, including
188 of the 193 UN members (excluded UN members are
Bhutan, Cuba, Iran, North Korea, and the US itself). In
addition, the US has diplomatic relations with 2
independent states that are not in the UN, the Holy See
and Kosovo, as well as with the EU.
Diplomatic representation from the US This entry
includes the chief of mission, embassy address, mailing
address, telephone number, FAX number, branch office
locations, consulate general locations, and consulate
locations.
Diplomatic representation in the US This entry
includes the chief of mission, chancery address, telephone,
FAX, consulate general locations, and consulate locations.
The use of the annotated title Appointed Ambassador refers
to anew ambassador who has presented his/her credentials
to the secretary of state but not the US president. Such
ambassadors fulfill all diplomatic functions except meeting
with or appearing at functions attended by the president
until such time as they formally present their credentials at
a White House ceremony.
Disputes—international This entry includes a wide
variety of situations that range from traditional bilateral
boundary disputes to unilateral claims of one sort or
another. Information regarding disputes over international
terrestrial and maritime boundaries has been reviewed by
the US Department of State. References to other situations
involving borders or frontiers may also be included, such as
resource disputes, geopolitical questions, or irredentist
issues; however, inclusion does not necessarily constitute
official acceptance or recognition by the US Government.
Drinking water source This entry provides information
about access to improved or unimproved drinking water
sources available to segments of the population of a
country. Improved drinking water—use of any of the
following sources: piped water into dwelling, yard, or plot;
public tap or standpipe; tubewell or borehole; protected
dug well; protected spring; or rainwater collection.
Unimproved drinking water—use of any of the following
sources: unprotected dug well; unprotected spring; cart
with small tank or drum; tanker truck; surface water, which
includes rivers, dams, lakes, ponds, streams, canals or
irrigation channels; or bottled water.
Economy This category includes the entries dealing with
the size, development, and management of productive
resources, i.e., land, labor, and capital.
Economy—overview This entry briefly describes the
type of economy, including the degree of market
orientation, the level of economic development, the most
important natural resources, and the unique areas of
specialization. It also characterizes major economic events
and policy changes in the most recent 12 months and may
include a statement about one or two key future
macroeconomic trends.
Education expenditures This entry provides the
public expenditure on education as a percent of GDP.
Electricity—consumption This entry consists of total
electricity generated annually plus imports and minus
exports, expressed in kilowatt-hours. The discrepancy
between the amount of electricity generated and/or
imported and the amount consumed and/or exported is
accounted for as loss in transmission and distribution.
Electricity—exports This entry is the total exported
electricity in kilowatt-hours.
Electricity—from fossil fuels This entry measures the
capacity of plants that generate electricity by burning fossil
fuels (such as coal, petroleum products, and natural gas),
expressed as a share of the country’s total generating
Capacity.
Electricity—from hydroelectric plants This entry
measures the capacity of plants that generate electricity by
water-driven turbines, expressed as a share of the
country’s total generating capacity.
Electricity—from nuclear fuels This entry measures
the capacity of plants that generate electricity through
radioactive decay of nuclear fuel, expressed as a share','7f44e6ca9ee58efe5cb9c9f8e22e786c228b35b515814240f3ef89e2998c1285','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df7500e5cee470e343ce89027b01b053c79a229d0b42d011280cdcd6b252672c',2020,'US','United States','introduction',27,'of
the country’s total generating capacity.
Electricity—from other renewable sources This
entry measures the capacity of plants that generate
electricity by using renewable energy sources other than
hydroelectric (including, for example, wind, waves, solar,
and geothermal), expressed as a share of the country’s
total generating capacity.
Electricity—imports This entry is the total imported
electricity in kilowatt-hours.
Electricity—installed generating capacity This
entry is the total capacity of currently installed generators,
expressed in kilowatts (kW), to produce electricity. A 10-
kilowatt (kW) generator will produce 10 kilowatt hours
(kWh) of electricity, if it runs continuously for one hour.
Electricity—production This entry is the annual
electricity generated expressed in kilowatt-hours. The
discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported
is accounted for as loss in transmission and distribution.
Electricity access This entry provides information on
access to electricity. Electrification data—collected from
industry reports, national surveys, and _ international
sources-consists of four subfields. Population without
electricity provides an estimate of the number of citizens
that do not have access to electricity. Electrification—total
population is the percent of a country’s total population
with access to electricity, electrification—urban areas is the
percent of a country’s urban population with access to
electricity, while electrification—rural areas is the percent
of a country’s rural population with access to electricity.
Due to differences in definitions and methodology from
different sources, data quality may vary from country to
country.
Elevation This entry includes the mean elevation and
elevation extremes, Jowest point and highest point.
Energy This category includes entries dealing with the
production, consumption, import, and export of various
forms of energy including electricity, crude oil, refined
petroleum products, and natural gas.
Entities Some of the independent states, dependencies,
areas of special sovereignty, and governments included in
this publication are not independent, and others are not
officially recognized by the US Government. “Independent
state” refers to a people politically organized into a
sovereign state with a definite territory. “Dependencies”
and “areas of special sovereignty” refer to a broad category
of political entities that are associated in some way with an
independent state. “Country” names used in the table of
contents or for page headings are usually the short-form
names as approved by the US Board on Geographic Names
and may include independent states, dependencies, and
areas of special sovereignty, or other geographic entities.
There are a total of 267 separate geographic entities in The
World Factbook that may be categorized as _ follows:
INDEPENDENT STATES 195 Afghanistan, Albania,
Algeria, Andorra, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy
See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Irag, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kosovo, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia,
Moldova, Monaco, Mongolia, Montenegro, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, South Sudan, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga,
Trinidad and ‘Tobago, Tunisia, Turkey, Turkmenistan,
Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,
Zimbabwe OTHER
2 Taiwan, European Union DEPENDENCIES AND AREAS
OF SPECIAL SOVEREIGNTY
6 Australia—Ashmore and Cartier Islands, Christmas
Island, Cocos (Keeling) Islands, Coral Sea Islands, Heard
Island and McDonald Islands, Norfolk Island 2 China—
Hong Kong, Macau 2 Denmark—Faroe Islands, Greenland 8
France—Clipperton Island, French Polynesia, French
Southern and Antarctic Lands, New Caledonia, Saint
Barthelemy, Saint Martin, Saint Pierre and Miquelon, Wallis
and Futuna 3 Netherlands—Aruba, Curacao, Sint Maarten
3 New Zealand—Cook Islands, Niue, Tokelau 3 Norway—
Bouvet Island, Jan Mayen, Svalbard 17 UK—Akrotiri,
Anguilla, Bermuda, British Indian Ocean Territory, British
Virgin Islands, Cayman Islands, Dhekelia, Falkland Islands,
Gibraltar, Guernsey, Jersey, Isle of Man, Montserrat,
Pitcairn Islands, Saint Helena, South Georgia and the
South Sandwich Islands, Turks and Caicos Islands 14 US—
American Samoa, Baker Island*, Guam, Howland Island*,
Jarvis Island*, Johnston Atoll*, Kingman Reef*, Midway
Islands*, Navassa Island, Northern Mariana _ Islands,
Palmyra Atoll*, Puerto Rico, Virgin Islands, Wake Island (*
consolidated in United States Pacific Island Wildlife
Refuges entry) MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands,
West Bank, Western Sahara OTHER ENTITIES
5 oceans—Arctic Ocean, Atlantic Ocean, Indian Ocean,
Pacific Ocean, Southern Ocean 1 World
267 total
Environment—current issues This entry lists the
most pressing and important environmental problems. The
following terms and abbreviations are used throughout the
entry: Acidification—the lowering of soil and water pH
due to acid precipitation and deposition usually through
precipitation; this process disrupts ecosystem nutrient
flows and may kill freshwater fish and plants dependent on
more neutral or alkaline conditions (see acid rain).
Acid rain—characterized as containing harmful levels of
sulfur dioxide or nitrogen oxide; acid rain is damaging
and potentially deadly to the earth’s fragile ecosystems;
acidity is measured using the pH scale where 7 is
neutral, values greater than 7 are considered alkaline,
and values below 5.6 are considered acid precipitation;
note—a pH of 2.4 (the acidity of vinegar) has been
measured in rainfall in New England.
Aerosol—a collection of airborne particles dispersed in
a gas, smoke, or fog.
Afforestation—converting a bare or agricultural space
by planting trees and plants; reforestation involves
replanting trees on areas that have been cut or
destroyed by fire.
Asbestos—a naturally occurring soft fibrous mineral
commonly used in fireproofing materials and considered
to be highly carcinogenic in particulate form.
Biodiversity—also biological diversity; the relative
number of species, diverse in form and function, at the
genetic, organism, community, and ecosystem level; loss
of biodiversity reduces an ecosystem’s ability to recover
from natural or man-induced disruption.
Bio-indicators—a plant or animal species whose
presence, abundance, and health reveal the general
condition of its habitat.
Biomass—the total weight or volume of living matter in
a given area or volume.
Carbon cycle—the term used to describe the exchange
of carbon (in various forms, e.g., as carbon dioxide)
between the atmosphere, ocean, terrestrial biosphere,
and geological deposits.
Catchments—assemblages used to capture and retain
rainwater and runoff; an important water management
technique in areas with limited freshwater resources,
such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane)—a
colorless, odorless insecticide that has toxic effects on
most animals; the use of DDT was banned in the US in
1972.
Defoliants—chemicals which cause plants to lose their
leaves artificially; often used in agricultural practices for
weed control, and may have detrimental impacts on
human and ecosystem health.
Deforestation—the destruction of vast areas of forest
(e.g., unsustainable forestry practices, agricultural and
range land clearing, and the over exploitation of wood
products for use as fuel) without planting new growth.
Desertification—the spread of desert-like conditions in
arid or semi-arid areas, due to overgrazing, loss of
agriculturally productive soils, or climate change.
Dredging—the practice of deepening an _ existing
waterway; also, a technique used for collecting bottom-
dwelling marine organisms (e.g., shellfish) or harvesting
coral, often causing significant destruction of reef and
ocean-floor ecosystems.
Drift-net fishing—done with a net, miles in extent, that
is generally anchored to a boat and left to float with the
tide; often results in an over harvesting and waste of
large populations of non-commercial marine species (by-
catch) by its effect of “sweeping the ocean clean.”
Ecosystems—ecological units comprised of complex
communities of organisms and_ their specific
environments.
Effluents—waste materials, such as smoke, sewage, or
industrial waste which are released into’ the
environment, subsequently polluting it.
Endangered species—a species that is threatened with
extinction either by direct hunting or habitat
destruction.
Freshwater—water with very low soluble mineral
content; sources include lakes, streams, rivers, glaciers,
and underground aquifers.
Greenhouse gas—a gas that “traps” infrared radiation
in the lower atmosphere causing surface warming;
water vapor, carbon dioxide, nitrous oxide, methane,
hydrofluorocarbons, and ozone are _ the_ primary
greenhouse gases in the Earth’s atmosphere.
Groundwater—water sources found below the surface
of the earth often in naturally occurring reservoirs in
permeable rock strata; the source for wells and natural
springs.
Highlands Water’ Project—a_ series of dams
constructed jointly by Lesotho and South Africa to
redirect Lesotho’s abundant water supply into a rapidly
growing area in South Africa; while it is the largest
infrastructure project in southern Africa, it is also the
most costly and controversial; objections to the project
include claims that it forces people from their homes,
submerges farmlands, and squanders economic
resources.
Inuit Circumpolar Conference (ICC)—represents the
roughly 150,000 Inuits of Alaska, Canada, Greenland,
and Russia in international environmental issues; a
General Assembly convenes every three years to
determine the focus of the ICC; the most current
concerns are long-range transport of pollutants,
sustainable development, and climate change.
Metallurgical plants—industries which specialize in
the science, technology, and processing of metals; these
plants produce highly concentrated and toxic wastes
which can contribute to pollution of ground water and
air when not properly disposed.
Noxious substances— injurious, very harmful to living
beings.
Overgrazing—the grazing of animals on plant material
faster than it can naturally regrow leading to the
permanent loss of plant cover, a common effect of too
many animals grazing limited range land.
Ozone shield—a layer of the atmosphere composed of
ozone gas (O03) that resides approximately 25 miles
above the Earth’s surface and absorbs solar ultraviolet
radiation that can be harmful to living organisms.
Poaching—the illegal killing of animals or fish, a great
concern with respect to endangered or threatened
species.
Pollution—the contamination of a healthy environment
by man-made waste.
Potable water—water that is drinkable, safe to be
consumed.
Salination—the process’ through which _ fresh
(drinkable) water becomes salt (undrinkable) water;
hence, desalination is the reverse process; also involves
the accumulation of salts in topsoil caused by
evaporation of excessive irrigation water, a process that
can eventually render soil incapable of supporting crops.
Siltation—occurs when water channels and reservoirs
become clotted with silt and mud, a side effect of
deforestation and soil erosion.
Slash-and-burn agriculture—a_ rotating cultivation
technique in which trees are cut down and burned in
order to clear land for temporary agriculture; the land is
used until its productivity declines at which point a new
plot is selected and the process repeats; this practice is
sustainable while population levels are low and time is
permitted for regrowth of natural vegetation; conversely,
where these conditions do not exist, the practice can
have disastrous consequences for the environment.
Soil degradation—damage to the land’s productive
capacity because of poor agricultural practices such as
the excessive use of pesticides or fertilizers, soil
compaction from heavy equipment, or erosion of topsoil,
eventually resulting in reduced ability to produce
agricultural products.
Soil erosion—the removal of soil by the action of water
or wind, compounded by poor agricultural practices,
deforestation, overgrazing, and desertification.
Ultraviolet (UV) radiation—a _ portion of the
electromagnetic energy emitted by the sun and naturally
filtered in the upper atmosphere by the ozone layer; UV
radiation can be harmful to living organisms and has
been linked to increasing rates of skin cancer in
humans.
Waterborne diseases—those in which bacteria survive
in, and are transmitted through, water; always a serious
threat in areas with an untreated water supply.
Environment—international agreements This
entry separates country participation in international
environmental agreements into two levels—party to and
signed, but not ratified. Agreements are listed in
alphabetical order by the abbreviated form of the full
name.
Environmental agreements This information is
presented in Appendix C: Selected International
Environmental Agreements, which includes the name,
abbreviation, date opened for signature, date entered into
force, objective, and parties by category.
Ethnic groups This entry provides an ordered listing of
ethnic groups starting with the largest and normally
includes the percent of total population.
Exchange rates This entry provides the average annual
price of a country’s monetary unit for the time period
specified, expressed in units of local currency per US
dollar, as determined by international market forces or by
official fiat. The International Organization for
Standardization (ISO) 4217 alphabetic currency code for
the national medium of exchange is presented in
parenthesis. Closing daily exchange rates are _ not
presented in The World Factbook, but are used to convert
stock values—e.g., the market value of publicly traded
shares—to US dollars as of the specified date.
Executive branch This entry includes five subentries:
chief of state; head of government; cabinet;
elections/appointments; election results. Chief of state
includes the name, title, and beginning date in office of the
titular leader of the country who represents the state at
official and ceremonial functions but may not be involved
with the day-to-day activities of the government. Head of
government includes the name, title of the top executive
designated to manage the executive branch of the
government, and the beginning date in office. Cabinet
includes the official name of the executive branch’s high-
ranking body and the method of member selection.
Flections/appointments includes the process for accession
to office, date of the last election, and date of the next
election. Election results includes each candidate’s political
affiliation, percent of direct popular vote or indirect
legislative/parliamentary percent vote or vote count in the
last election.
The executive branches in approximately 80% of the
world’s countries have separate chiefs of state and heads of
government; for the remainder, the chief of state is also the
head of government, such as in Argentina, Kenya, the
Philippines, the US, and Venezuela. Chiefs of state in just
over 100 countries are directly elected, most by majority
popular vote; those in another 55 are indirectly elected by
their national legislatures, parliaments, or _ electoral
colleges. Another 29 countries have a monarch as the chief
of state. In dependencies, territories, and collectivities of
sovereign countries—except those of the US—
representatives are appointed to serve as chiefs of state.
Heads of government in the majority of countries are
appointed either by the president or the monarch or
selected by the majority party in the legislative body.
Excluding countries where the chief of state is also head of
government, in only a few countries is the head of
government directly elected through popular vote.
Most of the world’s countries have cabinets, the majority of
which are appointed by the chief of state or prime minister,
many in consultation with each other or with the
legislature. Cabinets in only about a dozen countries are
elected solely by their legislative bodies.
Exports This entry provides the total US dollar amount of
merchandise exports on an f.o.b. (free on board) basis.
These figures are calculated on an exchange rate basis, i.e.,
not in purchasing power parity (PPP) terms.
Exports—commodities This entry provides a listing of
the highest-valued exported products; it sometimes
includes the percent of total dollar value.
Exports—partners This entry provides a rank ordering
of trading partners starting with the most important; it
sometimes includes the percent of total dollar value.
Fiscal year This entry identifies the beginning and
ending months for a country’s accounting period of 12
months, which often is the calendar year but which may
begin in any month. All yearly references are for the
calendar year (CY) unless indicated as a noncalendar fiscal
year (FY).
Flag description This entry provides a written flag
description produced from actual flags or the _ best
information available at the time the entry was written. The
flags of independent states are used by their dependencies
unless there is an officially recognized local flag. Some
disputed and other areas do not have flags.
Flag graphic Most versions of the Factbook include a
color flag at the beginning of the country profile. The flag
graphics were produced from actual flags or the best
information available at the time of preparation. The flags
of independent states are used by their dependencies
unless there is an officially recognized local flag. Some
disputed and other areas do not have flags.
GDP (official exchange rate) This entry gives the
gross domestic product (GDP) or value of all final goods
and services produced within a nation in a given year. A
nation’s GDP at official exchange rates (OER) is the home-
currency-denominated annual GDP figure divided by the
bilateral average US exchange rate with that country in
that year. The measure is simple to compute and gives a
precise measure of the value of output. Many economists
prefer this measure when gauging the economic power an
economy maintains vis-a-vis its neighbors, judging that an
exchange rate captures the purchasing power a nation
enjoys in the international marketplace. Official exchange
rates, however, can be artificially fixed and/or subject to
manipulation—resulting in claims of the country having an
under- or over-valued currency—and are not necessarily
the equivalent of a market-determined exchange rate.
Moreover, even if the official exchange rate is market-
determined, market exchange rates are _ frequently
established by a relatively small set of goods and services
(the ones the country trades) and may not capture the
value of the larger set of goods the country produces.
Furthermore, OER-converted GDP is not well suited to
comparing domestic GDP over time, since
appreciation/depreciation from one year to the next will
make the OER GDP value rise/fall regardless of whether
home-currency-denominated GDP changed.
GDP (purchasing power parity) This entry gives the
gross domestic product (GDP) or value of all final goods
and services produced within a nation in a given year. A
nation’s GDP at purchasing power parity (PPP) exchange
rates is the sum value of all goods and services produced in
the country valued at prices prevailing in the United States
in the year noted. This is the measure most economists
prefer when looking at per-capita welfare and when
comparing living conditions or use of resources across
countries. The measure is difficult to compute, as a US
dollar value has to be assigned to all goods and services in
the country regardless of whether these goods and services
have a direct equivalent in the United States (for example,
the value of an ox-cart or non-US military equipment); as a
result, PPP estimates for some countries are based on a
small and sometimes different set of goods and services. In
addition, many countries do not formally participate in the
World Bank’s PPP project that calculates these measures,
so the resulting GDP estimates for these countries may lack
precision. For many developing countries, PPP-based GDP
measures are multiples of the official exchange rate (OER)
measure. The differences between the OER- and PPP-
denominated GDP values for most of the wealthy
industrialized countries are generally much smaller.
GDP—composition, by end use This entry shows
who does the spending in an economy: consumers,
businesses, government, and foreigners. The distribution
gives the percentage contribution to total GDP of
household consumption, government consumption,
investment in fixed capital, investment in inventories,
exports of goods and services, and imports of goods and
services, and will total 100 percent of GDP if the data are
complete.
household consumption—consists of expenditures by
resident households, and by nonprofit institutions that
serve households, on goods and services that are
consumed by individuals. This includes consumption of
both domestically produced and foreign goods and
services.
government consumption—consists of government
expenditures on goods and services. These figures
exclude government transfer payments, such as interest
on debt, unemployment, and social security, since such
payments are not made in exchange for goods and
services supplied.
investment in fixed capital—consists of total business
spending on fixed assets, such as factories, machinery,
equipment, dwellings, and inventories of raw materials,
which provide the basis for future production. It is
measured gross of the depreciation of the assets, i.e., it
includes investment that merely replaces worn-out or
scrapped capital. Earlier editions of The World Factbook
referred to this concept as Investment (gross fixed) and
that data now have been moved to this new field.
investment in inventories—consists of net changes to
the stock of outputs that are still held by the units that
produce them, awaiting further sale to an end user, such
as automobiles sitting on a dealer’s lot or groceries on
the store shelves. This figure may be positive or
negative. If the stock of unsold output increases during
the relevant time period, investment in inventories is
positive, but, if the stock of unsold goods declines, it will
be negative. Investment in inventories normally is an
early indicator of the stat','66613438943b3487c45aa04e7911eb4b7cef36a7a8a502bc3224d10c1ab0f765','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4494cc5792134bf1a578a48f4b58fd0a1f9e7d8dfa5aaef20bea644e11fbfc55',2020,'US','United States','introduction',28,'e of the economy. If the stock
of unsold items increases unexpectedly—because people
stop buying—the economy may be entering a recession;
but if the stock of unsold items falls—and goods “go
flying off the shelves”—businesses normally try to
replace those stocks, and the economy is likely to
accelerate.
exports of goods and _ services—consist of sales,
barter, gifts, or grants of goods and services from
residents to nonresidents.
imports of goods and services—consist of purchases,
barter, or receipts of gifts, or grants of goods and
services by residents from nonresidents. Exports are
treated as a positive item, while imports are treated as a
negative item. In a purely accounting sense, imports
have no direct impact on GDP, which only measures
output of the domestic economy. Imports are entered as
a negative item to offset the fact that the expenditure
figures for consumption, investment, government, and
exports also include expenditures on imports. These
imports contribute directly to foreign GDP but only
indirectly to domestic GDP. Because of this negative
offset for imports of goods and services, the sum of the
other five items, excluding imports, will always total
more than 100 percent of GDP. A surplus of exports of
goods and services over imports indicates an economy is
investing abroad, while a deficit indicates an economy is
borrowing from abroad.
GDP—composition, by sector of origin This entry
shows where production takes place in an economy. The
distribution gives the percentage contribution of
agriculture, industry, and services to total GDP, and will
total 100 percent of GDP if the data are complete.
Agriculture includes farming, fishing, and forestry. Industry
includes mining, manufacturing, energy production, and
construction. Services cover government activities,
communications, transportation, finance, and all other
private economic activities that do not produce material
goods.
GDP—per capita (PPP) This entry shows GDP on a
purchasing power parity basis divided by population as of 1
July for the same year.
GDP—real growth rate This entry gives GDP growth
on an annual basis adjusted for inflation and expressed as a
percent. The growth rates are year-over-year, and not
compounded.
GDP methodology In the Economy category, GDP
dollar estimates for countries are reported both on an
official exchange rate (OER) and a purchasing power parity
(PPP) basis. Both measures contain information that is
useful to the reader. The PPP method involves the use of
standardized international dollar price weights, which are
applied to the quantities of final goods and services
produced in a given economy. The data derived from the
PPP method probably provide the best available starting
point for comparisons of economic strength and well-being
between countries. In contrast, the currency exchange rate
method involves a variety of international and domestic
financial forces that may not capture the value of domestic
output. Whereas PPP estimates for OECD countries are
quite reliable, PPP estimates for developing countries are
often rough approximations. In developing countries with
weak currencies, the exchange rate estimate of GDP in
dollars is typically one-fourth to one-half the PPP estimate.
Most of the GDP estimates for developing countries are
based on extrapolation of PPP numbers published by the
UN International Comparison Program (UNICP) and by
Professors Robert Summers and Alan Heston of the
University of Pennsylvania and their colleagues. GDP
derived using the OER method should be used for the
purpose of calculating the share of items such as exports,
imports, military expenditures, external debt, or the
current account balance, because the dollar values
presented in the Factbook for these items have been
converted at official exchange rates, not at PPP One should
use the OER GDP figure to calculate the proportion of, say,
Chinese defense expenditures in GDP, because that share
will be the same as one calculated in local currency units.
Comparison of OER GDP with PPP GDP may also indicate
whether a currency is over- or under-valued. If OER GDP is
smaller than PPP GDP, the official exchange rate may be
undervalued, and vice versa. However, there is no strong
historical evidence that market exchange rates move in the
direction implied by the PPP rate, at least not in the short-
or medium-term. Note: the numbers for GDP and other
economic data should not be chained together from
successive volumes of the Factbook because of changes in
the US dollar measuring rod, revisions of data by statistical
agencies, use of new or different sources of information,
and changes in national statistical methods and practices.
Geographic coordinates This entry includes rounded
latitude and longitude figures for the centroid or center
point of a country expressed in degrees and minutes; it is
based on the locations provided in the Geographic Names
Server (GNS), maintained by the National Geospatial-
Intelligence Agency on behalf of the US Board on
Geographic Names.
Geographic names This information is presented in
Appendix F: Cross Reference List of Geographic
Names. It includes a listing of various alternate names,
former names, local names, and regional names referenced
to one or more related Factbook entries. Spellings are
normally, but not always, those approved by the US Board
on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.
Geographic overview This entry, which appears only in
the World, Geography category, provides basic geographic
information about the earth’s oceans and continents. The
entry also lists all of the countries that compose each
continent.
Geography This category includes the entries dealing
with the natural environment and the effects of human
activity.
Geography—note This entry includes miscellaneous
geographic information of significance not included
elsewhere.
Gini index See entry for Distribution of family income
—Gini index GNP Gross national product (GNP) is the
value of all final goods and services produced within a
nation in a given year, plus income earned by its citizens
abroad, minus income earned by foreigners from domestic
production. The Factbook, following current practice, uses
GDP rather than GNP to measure national production.
However, the user must realize that in certain countries net
remittances from citizens working abroad may be
important to national well-being.
Government This category includes the entries dealing
with the system for the adoption and administration of
public policy.
Government-note This entry includes miscellaneous
government information of significance not included
elsewhere.
Government type This entry gives the basic form of
government. Definitions of the major governmental terms
are as follows. (Note that for some countries more than one
definition applies.): Absolute monarchy—a form of
government where the monarch rules unhindered, i.e.,
without any laws, constitution, or legally organized
opposition.
Anarchy—a_ condition of lawlessness or _ political
disorder brought about by the absence of governmental
authority.
Authoritarian—a form of government in which state
authority is imposed onto many aspects of citizens’ lives.
Commonwealth—a nation, state, or other political
entity founded on law and united by a compact of the
people for the common good.
Communist—a system of government in which the state
plans and controls the economy and a single—often
authoritarian—party holds power; state controls are
imposed with the elimination of private ownership of
property or capital while claiming to make progress
toward a higher social order in which all goods are
equally shared by the people (i.e., a classless society).
Confederacy (Confederation)—a union by compact or
treaty between states, provinces, or territories, that
creates a central government with limited powers; the
constituent entities retain supreme authority over all
matters except those delegated to the_ central
Investment (gross fixed) This entry records total
business spending on fixed assets, such as _ factories,
machinery, equipment, dwellings, and inventories of raw
materials, which provide the basis for future production. It
is measured gross of the depreciation of the assets, i.e., it
includes investment that merely replaces worn-out or
scrapped capital.
Irrigated land This entry gives the number of square
kilometers of land area that is artificially supplied with
water.
Judicial branch This entry includes three subfields. The
highest court(s) subfield includes the name(s) of a country’s
highest level court(s), the number and titles of the judges,
and the types of cases heard by the court, which commonly
are based on_ civil, criminal, administrative, and
constitutional law. A number of countries have separate
constitutional courts. The judge selection and term of office
subfield includes the organizations and associated officials
responsible for nominating and appointing judges, and a
brief description of the process. The selection process can
be indicative of the independence of a country’s court
system from other branches of its government. Also
included in this subfield are judges’ tenures, which can
range from a few years, to a specified retirement age, to
lifelong appointments. The subordinate courts subfield lists
the courts lower in the hierarchy of a country’s court
system. A few countries with federal-style governments,
such as Brazil, Canada, and the US, in addition to their
federal court, have separate state- or province-level court
systems, though generally the two systems interact.
Labor force This entry contains the total labor force
figure.
Labor force—by occupation This entry lists the
percentage distribution of the labor force by sector of
occupation. Agriculture includes farming, fishing, and
forestry. Industry includes mining, manufacturing, energy
production, and construction. Services cover government
activities, communications, transportation, finance, and all
other economic activities that do not produce material
goods. The distribution will total less than 100 percent if
the data are incomplete and may range from 99-101
percent due to rounding.
Land boundaries This entry contains the total length of
all land boundaries and the individual lengths for each of
the contiguous border countries. When available, official
lengths published by national statistical agencies are used.
Because surveying methods may differ, country border
lengths reported by contiguous countries may differ.
Land use This entry contains the percentage shares of
total land area for three different types of land use:
agricultural land, forest, and other; agricultural land is
further divided into arable land—land cultivated for crops
like wheat, maize, and rice that are replanted after each
harvest, permanent crops—land cultivated for crops like
citrus, coffee, and rubber that are not replanted after each
harvest, and includes land under flowering shrubs, fruit
trees, nut trees, and vines, and permanent pastures and
meadows—land used for at least five years or more to grow
herbaceous forage, either cultivated or growing naturally;
forest area is land spanning more than 0.5 hectare with
trees higher than five meters and a canopy cover of more
than 10% to include windbreaks, shelterbelts, and
corridors of trees greater than 0.5 hectare and at least 20
m wide; land classified as other includes built-up areas,
roads and other transportation features, barren land, or
wasteland.
Languages This entry provides a listing of languages
spoken in each country and specifies any that are official
national or regional languages. When data is available, the
languages spoken in each country are broken down
according to the percent of the total population speaking
each language as a first language. For those countries
without available data, languages are listed in rank order
based on prevalence, starting with the most-spoken
language.
Legal system This entry provides the description of a
country’s legal system. A statement on judicial review of
legislative acts is also included for a number of countries.
The legal systems of nearly all countries are generally
modeled upon elements of five main types: civil law
(including French law, the Napoleonic Code, Roman law,
Roman-Dutch law, and Spanish law); common law
(including United State law); customary law; mixed or
pluralistic law; and religious law (including Islamic law). An
additional type of legal system—international law, which
governs the conduct of independent nations in their
relationships with one another—is also addressed below.
The following list describes these legal systems, the
countries or world regions where these systems are
enforced, and a brief statement on the origins and major
features of each.
Civil Law—The most widespread type of legal system in
the world, applied in various forms in approximately 150
countries. Also referred to as European continental law,
the civil law system is derived mainly from the Roman
Corpus Juris Civilus, (Body of Civil Law), a collection of
laws and legal interpretations compiled under the East
Roman (Byzantine) Emperor Justinian I between A.D.
928 and 565. The major feature of civil law systems is
that the laws are organized into systematic written
codes. In civil law the sources recognized as
authoritative are principally legislation—especially
codifications in constitutions or statutes enacted by
governments—and secondarily, custom. The civil law
systems in some countries are based on more than one
code.
Common Law—A type of legal system, often
synonymous with “English common law,” which is the
system of England and Wales in the UK, and is also in
force in approximately 80 countries formerly part of or
influenced by the former British Empire. English
common law reflects Biblical influences as well as
remnants of law systems imposed by early conquerors
including the Romans, Anglo-Saxons, and Normans.
Some legal scholars attribute the formation of the
English common law system to King Henry II (r.1154-
1189). Until the time of his reign, laws customary among
England’s various manorial and ecclesiastical (church)
jurisdictions were administered locally. Henry II
established the king’s court and designated that laws
were “common” to the entire English realm. The
foundation of English common law is “legal precedent”—
referred to as stare decisis, meaning “to stand by things
decided.” In the English common law system, court
judges are bound in their decisions in large part by the
rules and other doctrines developed—and supplemented
over time—by the judges of earlier English courts.
Customary Law—A type of legal system that serves as
the basis of, or has influenced, the present-day laws in
approximately 40 countries—mostly in Africa, but some
in the Pacific islands, Europe, and the Near East.
Customary law is also referred to as “primitive law,”
“unwritten law,” “indigenous law,” and “folk law.” There
is no single history of customary law such as that found
in Roman civil law, English common law, Islamic law, or
the Napoleonic Civil Code. The earliest systems of law in
human society were customary, and usually developed in
small agrarian and hunter-gatherer communities. As the
term implies, customary law is based upon the customs
of a community. Common attributes of customary legal
systems are that they are seldom written down, they
embody an organized set of rules regulating social
relations, and they are agreed upon by members of the
community. Although such law _ systems _ include
sanctions for law infractions, resolution tends to be
reconciliatory rather than punitive. A number of African
states practiced customary law many centuries prior to
colonial influences. Following colonization, such laws
were written down and incorporated to varying extents
into the legal systems imposed by their colonial powers.
European Union Law—A sub-discipline of international
law known as “supranational law” in which the rights of
sovereign nations are limited in relation to one another.
Also referred to as the Law of the European Union or
Community Law, it is the unique and complex legal
system that operates in tandem with the laws of the 27
member states of the European Union (EU). Similar to
federal states, the EU legal system ensures compliance
from the member states because of the Union’s
decentralized political nature. The European Court of
Justice (ECJ), established in 1952 by the Treaty of Paris,
has been largely responsible for the development of EU
law. Fundamental principles of European Union law
include: subsidiarity—the notion that issues be handled
by the smallest, lowest, or least centralized competent
authority; proportionality—the EU may only act to the
extent needed to achieve its objectives; conferral—the
EU is a union of member states, and all its authorities
are voluntarily granted by its members; legal certainty—
requires that legal rules be clear and precise; and
precautionary principle—a moral and political principle
stating that if an action or policy might cause severe or
irreversible harm to the public or to the environment, in
the absence of a scientific consensus that harm would
not ensue, the burden of proof falls on those who would
advocate taking the action.
French Law—A type of civil law that is the legal system
of France. The French system also serves as the basis
for, or is mixed with, other legal systems in
approximately 50 countries, notably in North Africa, the
Near East, and the French territories and dependencies.
French law is primarily codified or systematic written
civil law. Prior to the French Revolution (1789-1799),
France had no single national legal system. Laws in the
northern areas of present-day France were mostly local
customs based on privileges and exemptions granted by
kings and feudal lords, while in the southern areas
Roman law predominated. The introduction of the
Napoleonic Civil Code during the reign of Napoleon I in
the first decade of the 19th century brought major
reforms to the French legal system, many of which
remain part of France’s current legal structure, though
all have been extensively amended or redrafted to
address a modern nation. French law distinguishes
between “public law” and “private law.” Public law
relates to government, the French Constitution, public
administration, and criminal law. Private law covers
issues between private citizens or corporations. The
most recent changes to the French legal system—
introduced in the 1980s—were the decentralization
laws, which transferred authority from _ centrally
appointed government representatives to locally elected
representatives of the people.
International Law—The law of the _ international
community, or the body of customary rules and treaty
rules accepted as legally binding by states in their
relations with each other. International law differs from
other legal systems in that it primarily concerns
sovereign political entities. There are three separate
disciplines of international law: public international law,
which governs the relationship between provinces and
international entities and includes treaty law, law of the
sea, international criminal law, and_ international
humanitarian law; private international law, which
addresses legal jurisdiction; and supranational law—a
legal framework wherein countries are bound by
regional agreements in which the laws of the member
countries are held inapplicable when in conflict with
supranational laws. At present the European Union is
the only entity under a supranational legal system. The
term “international law” was coined by Jeremy Bentham
in 1780 in his Principles of Morals and Legislation,
though laws governing relations between states have
been recognized from very early times (many centuries
B.C.). Modern international law developed alongside the
emergence and growth of the European nation-states
beginning in the early 16th century. Other factors that
influenced the development of international law
included the revival of legal studies, the growth of
international trade, and the practice of exchanging
emissaries and establishing legations. The sources of
International law are set out in Article 38-1 of the
Statute of the International Court of Justice within the
UN Charter.
Islamic Law—The most widespread type of religious
law, it is the legal system enforced in over 30 countries,
particularly in the Near East, but also in Central and
South Asia, Africa, and Indonesia. In many countries
Islamic law operates in tandem with a civil law system.
Islamic law is embodied in the sharia, an Arabic word
meaning “the right path.” Sharia covers all aspects of
public and private life and organizes them into five
categories: obligatory, recommended, permitted,
disliked, and forbidden. The primary sources of sharia
law are the Qur’an, believed by Muslims to be the word
of God revealed to the Prophet Muhammad by the angel
Gabriel, and the Sunnah, the teachings of the Prophet
and his works. In addition to these two primary sources,
traditional Sunni Muslims recognize the consensus of
Muhammad’s companions and Islamic jurists on certain
issues, called ijmas, and various forms of reasoning,
including analogy by legal scholars, referred to as qiyas.
Shia Muslims reject ijmas and giyas as sources of sharia
law.
Mixed Law—Also referred to as pluralistic law, mixed
law consists of elements of some or all of the other main
types of legal systems-civil, common, customary, and
religious. The mixed legal systems of a number of
countries came about when colonial powers overlaid
their own legal systems upon colonized regions but
retained elements of the colonies’ existing legal systems.
Napoleonic Civil Code—A type of civil law, referred to
as the Civil Code or Code Civil des Francais, forms part
of the legal system of France, and underpins the legal
systems of Bolivia, Egypt, Lebanon, Poland, and the US
state of Louisiana. The Civil Code was established under
Napoleon I, enacted in 1804, and officially designated
the Code Napoleon in 1807. This legal system combined
the Teutonic civil law tradition of the northern provinces
of France with the Roman law tradition of the southern
and eastern regions of the country. The Civil Code bears
similarities in its arrangement to the Roman Body of
Civil Law (see Civil Law above). As enacted in 1804, the
Code addressed personal status, property, and the
acquisition of property. Codes added over the following
six years included civil procedures, commercial law,
criminal law and procedures, and a penal code.
Religious Law—A legal system which stems from the
sacred texts of religious traditions and in most cases
professes to cover all aspects of life as a seamless part
of devotional obligations to a transcendent, imminent, or
deep philosophical reality. Implied as the basis of
religious law is the concept of unalterability, because the
word of God cannot be amended or legislated against by
judges or governments. However, a detailed legal
system generally requires human elaboration. The main
types of religious law are sharia in Islam, halakha in
Judaism, and canon law in some Christian groups.
Sharia is the most widespread religious legal system
(see Islamic Law), and is the sole system of law for
countries including Iran, the Maldives, and Saudi
Arabia. No country is fully governed by halakha, but
Jewish people may decide to settle disputes through
Jewish courts and be bound by their rulings. Canon law
is not a divine law as such because it is not found in
revelation. It is viewed instead as human law inspired by
the word of God and applying the demands of that
revelation to the actual situation of the church. Canon
law regulates the internal ordering of the Roman
Catholic Church, the Eastern Orthodox Church, and the
Anglican Communion.
Roman Law—A type of civil law developed in ancient
Rome and practiced from the time of the city’s foundi','63c72af1770a8cf596e28140b1b6a1eec01fee426e8651d2708e77ac51ee8328','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6a2820e2afac2bf60576685fb9906d03bd850c53ce0a3741b71c6b36247bb59',2020,'US','United States','introduction',29,'ng
(traditionally 753 B.C.) until the fall of the Western
Empire in the 5th century A.D. Roman law remained the
legal system of the Byzantine (Eastern Empire) until the
fall of Constantinople in 1453. Preserved fragments of
the first legal text, known as the Law of the Twelve
Tables, dating from the 5th century B.C., contained
specific provisions designed to change the prevailing
customary law. Early Roman law was drawn from
custom and statutes; later, during the time of the
empire, emperors asserted their authority as the
ultimate source of law. The basis for Roman laws was
the idea that the exact form—not the intention—of
words or of actions produced legal consequences. It was
only in the late 6th century A.D. that a comprehensive
Roman code of laws was published (see Civil Law
above). Roman law served as the basis of law systems
developed in a number of continental European
countries.
Roman-Dutch Law—A type of civil law based on
Roman law as applied in the Netherlands. Roman-Dutch
law serves as the basis for legal systems in seven
African countries, as well as Guyana, Indonesia, and Sri
Lanka. This law system, which originated in the province
of Holland and expanded throughout the Netherlands (to
be replaced by the French Civil Code in 1809), was
instituted in a number of sub-Saharan African countries
during the Dutch colonial period. The Dutch
jurist/philosopher Hugo Grotius was the first to attempt
to reduce Roman-Dutch civil law into a system in his
Jurisprudence of Holland (written 1619-20, commentary
published 1621). The Dutch historian/lawyer Simon van
Leeuwen coined the term “Roman-Dutch law” in 1652.
Spanish Law—A type of civil law, often referred to as
the Spanish Civil Code, it is the present legal system of
Spain and is the basis of legal systems in 12 countries
mostly in Central and South America, but also in
southwestern Europe, northern and western Africa, and
southeastern Asia. The Spanish Civil Code reflects a
complex mixture of customary, Roman, Napoleonic,
local, and modern codified law. The laws of the Visigoth
invaders of Spain in the 5th to 7th centuries had the
earliest major influence on Spanish legal system
development. The Christian Reconquest of Spain in the
11th through 15th centuries witnessed the development
of customary law, which combined canon (religious) and
Roman law. During several centuries of Hapsburg and
Bourbon rule, systematic recompilations of the existing
national legal system were attempted, but these often
conflicted with local and regional customary civil laws.
Legal system development for most of the 19th century
concentrated on formulating a national civil law system,
which was finally enacted in 1889 as the Spanish Civil
Code. Several sections of the code have been revised,
the most recent of which are the penal code in 1989 and
the judiciary code in 2001. The Spanish Civil Code
separates public and private law. Public law includes
constitutional law, administrative law, criminal law,
process law, financial and tax law, and international
public law. Private law includes civil law, commercial
law, labor law, and international private law.
United States Law—A type of common law, which is
the basis of the legal system of the United States and
that of its island possessions in the Caribbean and the
Pacific. This legal system has several layers, more
possibly than in most other countries, and is due in part
to the division between federal and state law. The United
States was founded not as one nation but as a union of
13 colonies, each claiming independence from the
British Crown. The US Constitution, implemented in
1789, began shifting power away from the states and
toward the federal government, though the states today
retain substantial legal authority. US law draws its
authority from four sources: constitutional law, statutory
law, administrative regulations, and _ case _ law.
Constitutional law is based on the US Constitution and
serves as the supreme federal law. Taken together with
those of the state constitutions, these documents outline
the general structure of the federal and_ state
governments and provide the rules and limits of power.
US statutory law is legislation enacted by the US
Congress and is codified in the United States Code. The
50 state legislatures have similar authority to enact
state statutes. Administrative law is the authority
delegated to federal and state executive agencies. Case
law, also referred to as common law, covers areas where
constitutional or statutory law is lacking. Case law is a
collection of judicial decisions, customs, and general
principles that began in England centuries ago, that
were adopted in America at the time of the Revolution,
and that continue to develop today.
Legislative branch This entry has three subfields. The
description subfield provides the legislative structure
(unicameral—single house; bicameral—an upper and a
lower house); formal name(s); number of member seats;
types of constituencies or voting districts (single seat,
multi-seat, nationwide); electoral voting system(s); and
member term of office. The elections subfield includes the
dates of the last election and next election. The election
results subfield lists percent of vote by party/coalition and
number of seats by party/coalition in the last election (in
bicameral legislatures, upper house results are listed first).
In general, parties with less than four seats and less than 4
percent of the vote are aggregated and listed as “other,”
and non-party-affiliated seats are listed as “independent.”
Also, the entries for some countries include two sets of
percent of vote by party and seats by party; the former
reflects results following a formal election announcement,
and the latter—following a mid-term or byelection—reflects
changes in a legislature’s political party composition.
Of the approximately 240 countries with legislative bodies,
approximately two-thirds are unicameral, and_ the
remainder, bicameral. The selection of legislative members
is typically governed by a country’s constitution and/or its
electoral laws. In general, members are either directly
elected by a country’s eligible voters using a defined
electoral system; indirectly elected or selected by its
province, state, or department legislatures; or appointed by
the country’s executive body. Legislative members in many
countries are selected both directly and indirectly, and the
electoral laws of some countries reserve seats for women
and various ethnic and minority groups.
Worldwide, the two predominant direct voting systems are
plurality/majority and proportional representation. The
most common of the several plurality/majority systems is
simple majority vote, or first-past-the-post, in which the
candidate receiving the most votes is elected. Countries’
legislatures such as Bangladesh’s Parliament, Malaysia’s
House of Representatives, and the United Kingdom’s House
of Commons use this system. Another common
plurality/majority system—absolute majority or two-round—
requires that candidates win at least 50 percent of the
votes to be elected. If none of the candidates meets that
vote threshold in the initial election, a second poll or
“runoff” is held soon after for the two top vote getters, and
the candidate receiving a simple vote majority is declared
the winner. Examples of the two-round system are Haiti’s
Chamber of Deputies, Mali’s National Assembly, and
Uzbekistan’s Legislative Chamber. Other plurality/majority
voting systems, referred to as preferential voting and
generally used in multi-seat constituencies, are block vote
and single non-transferable vote, in which voters cast their
ballots by ranking their candidate preferences from highest
to lowest.
Proportional representation electoral systems—in contrast
to plurality/majority systems—generally award legislative
seats to political parties in approximate proportion to the
number of votes each receives. For example, in a 100-
member legislature, if Party A receives 50 percent of the
total vote, Party B, 30 percent, and Party C, 20 percent,
then Party A would be awarded 50 seats, Party B 30 seats,
and Party C 20 seats. There are various forms of
proportional representation and the degree of reaching
proportionality varies. Some forms’ of proportional
representation are focused solely on achieving the
proportional representation of different political parties
and voters cast ballots only for political parties, whereas in
other forms, voters cast ballots for individual candidates
within a political party.
Many countries—both unicameral and bicameral—use a
mix of electoral methods, in which a portion of legislative
seats are awarded using one _ system, such as
plurality/majority, while the remaining seats are awarded
by another system, such as proportional representation.
Many countries with bicameral legislatures use different
voting systems for the two chambers.
Life expectancy at birth This entry contains the
average number of years to be lived by a group of people
born in the same year, if mortality at each age remains
constant in the future. Life expectancy at birth is also a
measure of overall quality of life in a country and
summarizes the mortality at all ages. It can also be thought
of as indicating the potential return on investment in
human capital and is necessary for the calculation of
various actuarial measures.
Literacy This entry includes a definition of literacy and
UNESCO’s percentage estimates for populations aged 15
years and over, including total population, males, and
females. There are no universal definitions and standards
of literacy. Unless otherwise specified, all rates are based
on the most common definition—the ability to read and
write at a specified age. Detailing the standards that
individual countries use to assess the ability to read and
write is beyond the scope of the Factbook. Information on
literacy, while not a perfect measure of educational results,
is probably the most easily available and valid for
international comparisons. Low levels of literacy, and
education in general, can impede the economic
development of a country in the current rapidly changing,
technology-driven world.
Location This entry identifies the country’s regional
location, neighboring countries, and adjacent bodies of
water.
Major infectious diseases This entry lists major
infectious diseases likely to be encountered in countries
where the risk of such diseases is assessed to be very high
as compared to the United States. These infectious
diseases represent risks to US government personnel
traveling to the specified country for a period of less than
three years. The degree of risk is assessed by considering
the foreign nature of these infectious diseases, their
severity, and the probability of being affected by the
diseases present. The diseases listed do not necessarily
represent the total disease burden experienced by the local
population.
The risk to an individual traveler varies considerably by the
specific location, visit duration, type of activities, type of
accommodations, time of year, and _ other factors.
Consultation with a travel medicine physician is needed to
evaluate individual risk and recommend appropriate
preventive measures such as vaccines.
Diseases are organized into the following six exposure
categories shown in italics and listed in typical descending
order of risk. Note: The sequence of exposure categories
listed in individual country entries may vary according to
local conditions.
food or waterborne diseases acquired through eating
or drinking on the local economy: Hepatitis A—viral
disease that interferes with the functioning of the liver;
spread through consumption of food or _ water
contaminated with fecal matter, principally in areas of
poor sanitation; victims exhibit fever, jaundice, and
diarrhea; 15% of victims will experience prolonged
symptoms over 6-9 months; vaccine available.
Hepatitis E—water-borne viral disease that interferes
with the functioning of the liver; most commonly spread
through fecal contamination of drinking water; victims
exhibit jaundice, fatigue, abdominal pain, and dark
colored urine.
Typhoid fever—bacterial disease spread through
contact with food or water contaminated by fecal matter
or sewage; victims exhibit sustained high fevers; left
untreated, mortality rates can reach 20%.
vectorborne diseases acquired through the bite of an
infected arthropod: Malaria—caused by _ single-cell
parasitic protozoa Plasmodium; transmitted to humans
via the bite of the female Anopheles mosquito; parasites
multiply in the liver attacking red blood cells resulting in
cycles of fever, chills, and sweats accompanied by
anemia; death due to damage to vital organs and
interruption of blood supply to the brain; endemic in
100, mostly tropical, countries with 90% of cases and
the majority of 0.4-0.8 million estimated annual deaths
occurring in sub-Saharan Africa.
Dengue fever—mosquito-borne (Aedes aegypti) viral
disease associated with urban environments; manifests
as sudden onset of fever and severe headache;
occasionally produces shock and hemorrhage leading to
death in 5% of cases.
Yellow fever—mosquito-borne (in urban areas Aedes
aegypti) viral disease; severity ranges from influenza-
like symptoms to severe hepatitis and hemorrhagic
fever; occurs only in tropical South America and sub-
Saharan Africa, where most cases are reported; fatality
rate is less than 20%.
Japanese Encephalitis—mosquito-borne (Culex
tritaeniorhynchus) viral disease associated with rural
areas in Asia; acute encephalitis can progress to
paralysis, coma, and death; fatality rates 30%.
African Trypanosomiasis—caused by the _ parasitic
protozoa Trypanosoma; transmitted to humans via the
bite of bloodsucking Tsetse flies; infection leads to
malaise and irregular fevers and, in advanced cases
when the parasites invade the central nervous system,
coma and death; endemic in 36 countries of sub-Saharan
Africa; cattle and wild animals act as reservoir hosts for
the parasites.
Cutaneous Leishmaniasis—caused by the _ parasitic
protozoa Jeishmania; transmitted to humans via the bite
of sandflies; results in skin lesions that may become
chronic; endemic in 88 countries; 90% of cases occur in
Iran, Afghanistan, Syria, Saudi Arabia, Brazil, and Peru;
wild and domesticated animals as well as humans can
act as reservoirs of infection.
Plague—bacterial disease transmitted by fleas normally
associated with rats; person-to-person airborne
transmission also possible; recent plague epidemics
occurred in areas of Asia, Africa, and South America
associated with rural areas or small towns and villages;
manifests as fever, headache, and painfully swollen
lymph nodes; disease progresses rapidly and without
antibiotic treatment leads to pneumonic form with a
death rate in excess of 50%.
Crimean-Congo hemorrhagic fever—tick-borne viral
disease; infection may also result from exposure to
infected animal blood or tissue; geographic distribution
includes Africa, Asia, the Middle East, and Eastern
Europe; sudden onset of fever, headache, and muscle
aches followed by hemorrhaging in the bowels, urine,
nose, and gums; mortality rate is approximately 30%.
Rift Valley fever—viral disease affecting domesticated
animals and humans; transmission is by mosquito and
other biting insects; infection may also occur through
handling of infected meat or contact with blood;
geographic distribution includes eastern and southern
Africa where cattle and sheep are raised; symptoms are
generally mild with fever and some liver abnormalities,
but the disease may progress to hemorrhagic fever,
encephalitis, or ocular disease; fatality rates are low at
about 1% of cases.
Chikungunya—mosquito-borne (Aedes aegypti) viral
disease associated with urban environments, similar to
Dengue Fever; characterized by sudden onset of fever,
rash, and severe joint pain usually lasting 3-7 days, some
cases result in persistent arthritis.
water contact diseases acquired through swimming or
wading in freshwater lakes, streams, and _ rivers:
Leptospirosis—bacterial disease that affects animals
and humans; infection occurs through contact with
water, food, or soil contaminated by animal urine;
symptoms include high fever, severe headache,
vomiting, jaundice, and diarrhea; untreated, the disease
can result in kidney damage, liver failure, meningitis, or
respiratory distress; fatality rates are low but left
untreated recovery can take months.
Schistosomiasis—caused by _ parasitic trematode
flatworm Schistosoma; fresh water snails act as
intermediate host and release larval form of parasite
that penetrates the skin of people exposed _ to
contaminated water; worms mature and reproduce in
the blood vessels, liver, kidneys, and intestines releasing
eggs, which become trapped in tissues triggering an
immune response; may manifest as either urinary or
intestinal disease resulting in decreased work or
learning capacity; mortality, while generally low, may
occur in advanced cases usually due to bladder cancer;
endemic in 74 developing countries with 80% of infected
people living in sub-Saharan Africa; humans act as the
reservoir for this parasite.
aerosolized dust or soil contact disease acquired
through inhalation of aerosols contaminated with rodent
urine: Lassa fever—viral disease carried by rats of the
genus Mastomys; endemic in portions of West Africa;
infection occurs through direct contact with or
consumption of food contaminated by rodent urine or
fecal matter containing virus particles; fatality rate can
reach 50% in epidemic outbreaks.
respiratory disease acquired through close contact
with an infectious person: Meningococcal meningitis
—bacterial disease causing an inflammation of the lining
of the brain and spinal cord; one of the most important
bacterial pathogens is Neisseria meningitidis because of
its potential to cause epidemics; symptoms include stiff
neck, high fever, headaches, and vomiting; bacteria are
transmitted from person to person by _ respiratory
droplets and facilitated by close and prolonged contact
resulting from crowded living conditions, often with a
seasonal distribution; death occurs in 5-15% of cases,
typically within 24-48 hours of onset of symptoms;
highest burden of meningococcal disease occurs in the
hyperendemic region of sub-Saharan Africa known as
the “Meningitis Belt” which stretches from Senegal east
to Ethiopia.
animal contact disease acquired through direct
contact with local animals: Rabies—viral disease of
mammals usually transmitted through the bite of an
infected animal, most commonly dogs; virus affects the
central nervous system causing brain alteration and
death; symptoms initially are non-specific fever and
headache progressing to neurological symptoms; death
occurs within days of the onset of symptoms.
Major urban areas—population This entry provides
the population of the capital and up to six major cities
defined as urban agglomerations with populations of at
least 750,000 people. An urban agglomeration is defined as
comprising the city or town proper and also the suburban
fringe or thickly settled territory lying outside of, but
adjacent to, the boundaries of the city. For smaller
countries, lacking urban centers of 750,000 or more, only
the population of the capital is presented.
Map references This entry includes the name of the
Factbook reference map on which a country may be found.
Note that boundary representations on these maps are not
necessarily authoritative. The entry on Geographic
coordinates may be helpful in finding some smaller
countries.
Marine fisheries This entry describes the major
fisheries in the world’s oceans in terms of the area covered,
their ranking in terms of the global catch, the main
producing countries, and the principal species caught.
Information provided by the Fisheries and Aquaculture
Department of the UN Food and Agriculture Organization
(FAO).
Maritime claims This entry includes the following
claims, the definitions of which are excerpted from the
United Nations Convention on the Law of the Sea
(UNCLOS), which alone contains the full and definitive
descriptions: territorial sea—the sovereignty of a coastal
state extends beyond its land territory and internal waters
to an adjacent belt of sea, described as the territorial sea in
the UNCLOS (Part II); this sovereignty extends to the air
space over the territorial sea as well as its underlying
seabed and subsoil; every state has the right to establish
the breadth of its territorial sea up to a limit not exceeding
12 nautical miles; the normal baseline for measuring the
breadth of the territorial sea is the mean low-water line
along the coast as marked on large-scale charts officially
recognized by the coastal state; where the coasts of two
states are opposite or adjacent to each other, neither state
is entitled to extend its territorial sea beyond the median
line, every point of which is equidistant from the nearest
points on the baseline from which the territorial seas of
both states are measured; the UNCLOS describes specific
rules for archipelagic states.
contiguous zone—according to the UNCLOS (Article
33), this is a zone contiguous to a coastal state’s
territorial sea, over which it may exercise the control
necessary to: prevent infringement of its customs, fiscal,
immigration, or sanitary laws and regulations within its
territory or territorial sea; punish infringement of the
above laws and regulations committed within its
territory or territorial sea; the contiguous zone may not
extend beyond 24 nautical miles from the baselines from
which the breadth of the territorial sea is measured
(e.g., the US has claimed a 12-nautical mile contiguous
zone in addition to its 12-nautical mile territorial sea);
where the coasts of two states are opposite or adjacent
to each other, neither state is entitled to extend its
contiguous zone beyond the median line, every point of
which is equidistant from the nearest points on the
baseline from which the contiguous zone of both states
are measured.
exclusive economic zone (EEZ)—the UNCLOS (Part
V) defines the EEZ as a zone beyond and adjacent to the
territorial sea in which a coastal state has: sovereign
rights for the purpose of exploring and exploiting,
conserving and managing the natural resources,
whether living or non-living, of the waters superjacent to
the seabed and of the seabed and its subsoil, and with
regard to other activities for the economic exploitation
and exploration of the zone, such as the production of
energy from the water, currents, and winds; jurisdiction
with regard to the establishment and use of artificial
islands, installations, and structures; marine scientific
research; the protection and preservation of the marine
environment; the outer limit of the exclusive economic
zone shall not exceed 200 nautical miles from the
baselines from which the breadth of the territorial sea is
measured.
continental shelf—the UNCLOS (Article 76) defines
the continental shelf of a coastal state as comprising the
seabed and subsoil of the submarine areas that extend
beyond its territorial sea throughout the natural
prolongation of its land territory to the outer edge of the
continental margin, or to a distance of 200 nautical
miles from the baselines from which the breadth of the
territorial sea is measured where the outer edge of the
continental margin does not extend up to that distance;
the continental margin comprises the submerged
prolongation of the landmass of the coastal state, and
consists of the seabed and subsoil of the shelf, the slope
and the rise; wherever the continental margin extends
beyond 200 nautical miles from the baseline, coastal
states may extend their claim to a distance not to exceed
350 nautical miles from the baseline or 100 nautical
miles from the 2,500-meter isobath, which is a line
connecting points of 2,500 meters in depth; it does not
include the deep ocean floor with its oceanic ridges or
the subsoi','5a67cc6f230026c86c7ee762c3f41f2c94ee0f2481cbfd06fa08f064a2855cbb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf504c15d4ca8b12fada78fa419698b0c74030380785889fbfb7abfec6533fa9',2020,'US','United States','introduction',30,'l thereof.
exclusive fishing zone—while this term is not used in
the UNCLOS, some states (e.g., the United Kingdom)
have chosen not to claim an EEZ but rather to claim
jurisdiction over the living resources off their coast; in
such cases, the term exclusive fishing zone is often used;
the breadth of this zone is normally the same as the EEZ
or 200 nautical miles.
Maritime threats This entry describes the threat of
piracy, as defined in Article 101, UN Convention on the Law
of the Sea (UNCLOS), or armed robbery against ships, as
defined in Resolution A. 1025 (26) adopted on 2 December
2009 at the 26th Assembly Session of the International
Maritime Organization. The entry includes the number of
ships on the high seas or in territorial waters that were
boarded or attacked by pirates, and the number of
crewmen abducted or killed, as compiled by the
International Maritime Bureau. Information is also supplied
on the geographical range of attacks.
Maternal mortality rate The maternal mortality rate
(MMR) is the annual number of female deaths per 100,000
live births from any cause related to or aggravated by
pregnancy or its management (excluding accidental or
incidental causes). The MMR includes deaths during
pregnancy, childbirth, or within 42 days of termination of
pregnancy, irrespective of the duration and site of the
pregnancy, for a specified year.
Median age This entry is the age that divides a
population into two numerically equal groups; that is, half
the people are younger than this age and half are older. It
is a single index that summarizes the age distribution of a
population. Currently, the median age ranges from a low of
about 15 in Niger and Uganda to 40 or more in several
European countries and Japan. See the entry for “Age
structure” for the importance of a young versus an older
age structure and, by implication, a low versus a higher
median age.
Member states This entry, which appears only in the
European Union, Government category, provides a listing of
all of the European Union member countries, as well as
their associated overseas countries and territories.
Merchant marine This entry provides the total and the
number of each type of privately or publicly owned
commercial ship for each country; military ships are not
included; the five ships by type include: bulk carrier—for
cargo such as coal, grain, cement, ores, and gravel;
container ship—for loads in _ truck-size containers, a
transportation system called containerization; general
cargo-also referred to as break-bulk containers—for a wide
variety of packaged merchandise, such as textiles, furniture
and machinery; oil tanker—for crude oil and petroleum
products; other—includes chemical carriers, dredgers,
liquefied natural gas (LNG) carriers, refrigerated cargo
ships called reefers, tugboats, passenger vessels (cruise
and ferry), and offshore supply ships Military This
category includes the entries dealing with a country’s
military structure, manpower, and expenditures.
Military—note This entry includes’ miscellaneous
military information of significance not included elsewhere.
Military and security forces This entry lists the
military and security forces subordinate to defense
ministries or the equivalent (typically ground, naval, air,
and marine forces), as well as those belonging to interior
ministries or the equivalent (typically gendarmeries,
border/coast guards, paramilitary police, and other internal
security forces).
Military expenditures This entry gives spending on
defense programs for the most recent year available as a
percent of gross domestic product (GDP); the GDP is
calculated on an exchange rate basis, i.e., not in terms of
purchasing power parity (PPP). For countries with no
military forces, this figure can include expenditures on
public security and police.
Military service age and obligation This entry gives
the required ages for voluntary or conscript military
service and the length of service obligation.
Money figures All money figures are expressed in
contemporaneous US dollars unless otherwise indicated.
Mother’s mean age at first birth This entry
provides the mean (average) age of mothers at the birth of
their first child. It is a useful indicator for gauging the
success of family planning programs aiming to reduce
maternal mortality, increase contraceptive use—
particularly among married and unmarried adolescents—
delay age at first marriage, and improve the health of
newborns.
National air transport system This entry includes
four subfields describing the air transport system of a given
country in terms of both structure and performance. The
first subfield, number of registered air carriers, indicates
the total number of air carriers registered with the
country’s national aviation authority and issued an air
operator certificate as required by the Convention on
International Civil Aviation. The second subfield, inventory
of registered aircraft operated by air carriers, lists the total
number of aircraft operated by all registered air carriers in
the country. The last two subfields measure the
performance of the air transport system in terms of both
passengers and freight. The subfield, annual passenger
traffic on registered air carriers, includes the total number
of passengers carried by air carriers registered in the
country, including both domestic and_ international
passengers, in a given year. The last subfield, annual
freight traffic on registered air carriers, includes the
volume of freight, express, and diplomatic bags carried by
registered air carriers and measured in metric tons times
kilometers traveled. Freight ton-kilometers equal the sum
of the products obtained by multiplying the number of tons
of freight, express, and diplomatic bags carried on each
flight stage by the stage distance (operation of an aircraft
from takeoff to its next landing). For statistical purposes,
freight includes express and diplomatic bags but not
passenger baggage.
National anthem A _ generally patriotic musical
composition—usually in the form of a song or hymn of
praise—that evokes and eulogizes the history, traditions, or
struggles of a nation or its people. National anthems can be
officially recognized as a national song by a country’s
constitution or by an enacted law, or simply by tradition.
Although most anthems contain lyrics, some do not.
National holiday This entry gives the primary national
day of celebration—usually independence day.
National symbol(s) A national symbol is a faunal, floral,
or other abstract representation—or some distinctive object
—that over time has come to be closely identified with a
country or entity. Not all countries have national symbols; a
few countries have more than one.
Nationality This entry provides the identifying terms for
citizens—noun and adjective.
Natural gas—consumption This entry is the total
natural gas consumed in cubic meters (cu m). The
discrepancy between the amount of natural gas produced
and/or imported and the amount consumed and/or exported
is due to the omission of stock changes and other
complicating factors.
Natural gas—exports This entry is the total natural
gas exported in cubic meters (cu m).
Natural gas—imports This entry is the total natural
gas imported in cubic meters (cu m).
Natural gas—production This entry is the total
natural gas produced in cubic meters (cu m). The
discrepancy between the amount of natural gas produced
and/or imported and the amount consumed and/or exported
is due to the omission of stock changes and other
complicating factors.
Natural gas—proved reserves This entry is the stock
of proved reserves of natural gas in cubic meters (cu m).
Proved reserves are those quantities of natural gas, which,
by analysis of geological and engineering data, can be
estimated with a high degree of confidence to be
commercially recoverable from a given date forward, from
known reservoirs and under current economic conditions.
Natural hazards This entry lists potential natural
disasters. For countries where volcanic activity is common,
a volcanism subfield highlights historically active
volcanoes.
Natural resources This entry lists a country’s mineral,
petroleum, hydropower, and other resources of commercial
importance, such as rare earth elements (REEs). In
general, products appear only if they make a significant
contribution to the economy, or are likely to do so in the
future.
Net migration rate This entry includes the figure for
the difference between the number of persons entering and
leaving a country during the year per 1,000 persons (based
on midyear population). An excess of persons entering the
country is referred to as net immigration (e.g., 3.56
migrants/1,000 population); an excess of persons leaving
the country as net emigration (e.g., -9.26 migrants/1,000
population). The net migration rate indicates’ the
contribution of migration to the overall level of population
change. The net migration rate does not distinguish
between economic migrants, refugees, and other types of
migrants nor does it distinguish between lawful migrants
and undocumented migrants.
Obesity—adult prevalence rate This entry gives the
percent of a country’s population considered to be obese.
Obesity is defined as an adult having a Body Mass Index
(BMI) greater to or equal to 30.0. BMI is calculated by
taking a person’s weight in kg and dividing it by the
person’s squared height in meters.
People—note This entry includes’ miscellaneous
demographic information of significance not included
elsewhere.
People and Society This category includes entries
dealing with national identity (including ethnicities,
languages, and religions), demography (a variety of
population statistics) and societal characteristics (health
and education indicators).
Personal Names—Capitalization The Factbook
capitalizes the surname or family name of individuals for
the convenience of our users who are faced with a world of
different cultures and naming conventions. The need for
capitalization, bold type, underlining, italics, or some other
indicator of the individual’s surname is apparent in the
following examples: MAO Zedong, Fidel CASTRO Ruz,
George W. BUSH, and TUNKU SALAHUDDIN Abdul Aziz
Shah ibni Al-Marhum Sultan Hisammuddin Alam Shah. By
knowing the surname, a short form without all capital
letters can be used with confidence as in President Castro,
Chairman Mao, President Bush, or Sultan Tunku
Salahuddin. The same system of capitalization is extended
to the names of leaders with surnames that are not
commonly used such as Queen ELIZABETH II. For
Vietnamese names, the given name is capitalized because
officials are referred to by their given name rather than by
their surname. For example, the president of Vietnam is
Tran Duc LUONG. His surname is Tran, but he is referred
to by his given name—President LUONG.
Personal Names—Spelling The romanization of
personal names in the Factbook normally follows the same
transliteration system used by the US Board on Geographic
Names for spelling place names. At times, however, a
foreign leader expressly indicates a preference for, or the
media or official documents regularly use, a romanized
spelling that differs from the transliteration derived from
the US Government standard. In such cases, the Factbook
uses the alternative spelling.
Personal Names—tTitles The Factbook capitalizes any
valid title (or short form of it) immediately preceding a
person’s name. A title standing alone is not capitalized.
Examples: President PUTIN and President OBAMA are
chiefs of state. In Russia, the president is chief of state and
the premier is the head of the government, while in the US,
the president is both chief of state and head of government.
Petroleum See entries under Refined petroleum
products.
Petroleum products See entries under Refined
petroleum products.
Physicians density This entry gives the number of
medical doctors (physicians), including generalist and
specialist medical practitioners, per 1,000 of the
population. Medical doctors are defined as doctors that
study, diagnose, treat, and prevent illness, disease, injury,
and other physical and mental impairments in humans
through the application of modern medicine. They also
plan, supervise, and evaluate care and treatment plans by
other health care providers. The World Health Organization
estimates that fewer than 2.3 health workers (physicians,
nurses, and midwives only) per 1,000 would be insufficient
to achieve coverage of primary healthcare needs.
Pipelines This entry gives the lengths and types of
pipelines for transporting products like natural gas, crude
oil, or petroleum products.
Piracy Piracy is defined by the 1982 United Nations
Convention on the Law of the Sea as any illegal act of
violence, detention, or depredation directed against a ship,
aircraft, persons, or property in a place outside the
jurisdiction of any State. Such criminal acts committed in
the territorial waters of a littoral state are generally
considered to be armed robbery against ships. Information
on piracy may be found, where applicable, under Maritime
threats.
Political parties and leaders This entry includes a
listing of significant political parties, coalitions, and
electoral lists as of each country’s last legislative election,
unless otherwise noted.
Political structure This entry, which appears only in the
European Union, Government category, provides a
definition for the entity that is the European Union.
Population This entry gives an estimate from the US
Bureau of the Census based on statistics from population
censuses, vital statistics registration systems, or sample
surveys pertaining to the recent past and on assumptions
about future trends. The total population presents one
overall measure of the potential impact of the country on
the world and within its region. Note: Starting with the
1993 Factbook, demographic estimates for some countries
(mostly African) have explicitly taken into account the
effects of the growing impact of the HIV/AIDS epidemic.
These countries are currently: The Bahamas, Benin,
Botswana, Brazil, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Central African Republic,
Democratic Republic of the Congo, Republic of the Congo,
Cote d’Ivoire, Ethiopia, Gabon, Ghana, Guyana, Haiti,
Honduras, Kenya, Lesotho, Malawi, Mozambique, Namibia,
Nigeria, Rwanda, South Africa, Swaziland, Tanzania,
Thailand, Togo, Uganda, Zambia, and Zimbabwe.
Population below poverty line National estimates of
the percentage of the population falling below the poverty
line are based on surveys of sub-groups, with the results
weighted by the number of people in each group.
Definitions of poverty vary considerably among nations. For
example, rich nations generally employ more generous
standards of poverty than poor nations.
Population § distribution This entry provides a
summary description of the population dispersion within a
country. While it may suggest population density, it does
not provide density figures.
Population growth rate The average annual percent
change in the population, resulting from a surplus (or
deficit) of births over deaths and the balance of migrants
entering and leaving a country. The rate may be positive or
negative. The growth rate is a factor in determining how
great a burden would be imposed on a country by the
changing needs of its people for infrastructure (e.g.,
schools, hospitals, housing, roads), resources (e.g., food,
water, electricity), and jobs. Rapid population growth can
be seen as threatening by neighboring countries.
Population pyramid A population pyramid illustrates
the age and sex structure of a country’s population and
may provide insights about political and social stability, as
well as economic development. The population is
distributed along the horizontal axis, with males shown on
the left and females on the right. The male and female
populations are broken down into 5-year age groups
represented as horizontal bars along the vertical axis, with
the youngest age groups at the bottom and the oldest at
the top. The shape of the population pyramid gradually
evolves over time based on fertility, mortality, and
international migration trends.
Some distinctive types of population pyramids are: * A
youthful distribution has a broad base and narrow peak
and is characterized by a high proportion of children and
low proportion of the elderly. This population distribution
results from high fertility, high mortality, low life
expectancy, and high population growth. It is typical of
developing countries where female education and
contraceptive use are low and health care and sanitation
are poor.
¢ A transitional distribution is caused by declining
fertility and mortality rates, increasing life expectancy,
and slowing population growth. The population has a
larger proportion of working-age people relative to
children and the elderly and produces a barrel-shaped
pyramid, where the mid-section bulges and the base and
top are narrower. The large proportion of working-age
people can create a “demographic bonus” if it is
educated and productively employed.
¢ A mature distribution has _ fairly balanced
proportions of the population in the child, working-age,
and elderly age groups and will gradually form an
inverted triangle population pyramid as population
growth continues to fall or ceases and the proportion of
older people increases. Low fertility, low mortality, and
high life expectancy—made possible by the availability
of advanced healthcare, family planning, sanitation, and
education—lead to aging populations in industrialized
countries.
Ports and terminals This entry lists major ports and
terminals primarily on the basis of the amount of cargo
tonnage shipped through the facilities on an annual basis.
In some instances, the number of containers handled or
ship visits were also considered. Most ports service
multiple classes of vessels including bulk carriers (dry and
liquid), break bulk cargoes (goods loaded individually in
bags, boxes, crates, or drums; sometimes palletized),
containers, roll-on/roll-off, and passenger ships. The listing
leads off with major seaports handling all types of cargo.
Inland river/lake ports are listed separately along with the
river or lake name. Ports configured specifically to handle
bulk cargoes are designated as oil terminals or dry bulk
cargo ports. LNG terminals handle liquefied natural gas
(LNG) and are differentiated as either export, where the
gas is chilled to a liquid state to reduce its volume for
transport on specialized gas carriers, or import, where the
offloaded LNG undergoes a regasification process before
entering pipelines for distribution. As break bulk cargoes
are largely transported by containers today, the entry also
includes a listing of major container ports with the
corresponding throughput measured in _ twenty-foot
equivalent units (TEUs). Some ports are significant for
handling passenger traffic and are listed as cruise/ferry
ports. In addition to commercial traffic, many seaports also
provide important military infrastructure such as naval
bases or dockyards.
Preliminary statement This entry, which appears only
in the European Union, Introduction category, provides an
explanation and justification for the inclusion of a separate
European Union geographic entity.
Principality A sovereign state ruled by a monarch with
the title of prince; principalities were common in the past,
but today only three remain: Liechtenstein, Monaco, and
the co-principality of Andorra.
Public debt This entry records the cumulative total of all
government borrowings less repayments that are
denominated in a country’s home currency. Public debt
should not be confused with external debt, which reflects
the foreign currency liabilities of both the private and
public sector and must be financed out of foreign exchange
earnings.
Railways This entry states the total route length of the
railway network and of its component parts by gauge,
which is the measure of the distance between the inner
sides of the load-bearing rails. The four typical types of
gauges are: broad, standard, narrow, and dual. Other
gauges are listed under note. Some 60% of the world’s
railways use the standard gauge of 1.4 m (4.7 ft). Gauges
vary by country and sometimes within countries. The
choice of gauge during initial construction was mainly in
response to local conditions and the intent of the builder.
Narrow-gauge railways were cheaper to build and could
negotiate sharper curves, broad-gauge railways gave
greater stability and permitted higher speeds. Standard-
gauge railways were a compromise between narrow and
broad gauges.
Rare earth elements Rare earth elements or REEs are
17 chemical elements that are critical in many of today’s
high-tech industries. They include lanthanum, cerium,
praseodymium, neodymium, promethium, samarium,
europium, gadolinium, terbium, dysprosium, holmium,
erbium, thulium, ytterbium, lutetium, scandium, and
yttrium. Typical applications for REEs include batteries in
hybrid cars, fiber optic cables, flat panel displays, and
permanent magnets, as well as some defense and medical
products.
Reference maps This section includes world and
regional maps.
Refined petroleum products—consumption This
entry is the country’s total consumption of refined
petroleum products, in barrels per day (bbl/day). The
discrepancy between the amount of refined petroleum
products produced and/or imported and the amount
consumed and/or exported is due to the omission of stock
changes, refinery gains, and other complicating factors.
Refined petroleum products—exports This entry is
the country’s total exports of refined petroleum products,
in barrels per day (bbl/day).
Refined petroleum products—imports This entry is
the country’s total imports of refined petroleum products,
in barrels per day (bbl/day).
Refined petroleum products—production This
entry is the country’s total output of refined petroleum
products, in barrels per day (bbl/day). The discrepancy
between the amount of refined petroleum products
produced and/or imported and the amount consumed
and/or exported is due to the omission of stock changes,
refinery gains, and other complicating factors.
Refugees and internally displaced persons This
entry includes those persons residing in a country as
refugees, internally displaced persons (IDPs), or stateless
persons. Each country’s refugee entry includes only
countries of origin that are the source of refugee
populations of 5,000 or more. The definition of a refugee
according to a UN Convention is “a person who is outside
his/her country of nationality or habitual residence; has a
well-founded fear of persecution because of his/her race,
religion, nationality, membership in a particular social
group or political opinion; and is unable or unwilling to
avail himself/herself of the protection of that country, or to
return there, for fear of persecution.” The UN established
the Office of the UN High Commissioner for Refugees
(UNHCR) in 1950 to handle refugee matters worldwide.
The UN Relief and Works Agency for Palestine Refugees in
the Near East (UNRWA) has a different operational
definition for a Palestinian refugee: “a person whose
normal place of residence was Palestine during the period
1 June 1946 to 15 May 1948 and who lost both home and
means of livelihood as a result of the 1948 conflict.”
However, UNHCR also assists some 400,000 Palestinian
refugees not covered under the UNRWA definition. The
term “internally displaced person” is not specifically
covered in the UN Convention; it is used to describe people
who have fled their homes for reasons similar to refugees,
but who remain within their own national territory and are
subject to the laws of that state. A stateless person is
defined as someone who is not considered a national by any
state under the operation of its law, according to UN
convention.
Religions This entry is an ordered listing of religions by
adherents starting with the largest group and','6846ef31dcf483b988540f849bfc0b1131eb04f118bf97726b526edf9eae086a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcf65aed6a6c93442b7c46c323051a1bf5886545e587b85e265c297fd499cc97',2020,'US','United States','introduction',31,'sometimes
includes the percent of total population. The core
characteristics and beliefs of the world’s major religions
are described below.
Baha’i—Founded by Mirza MHusayn-Ali (known as
Baha’u’llah) in Iran in 1852, Baha’i faith emphasizes
monotheism and believes in one eternal transcendent
God. Its guiding focus is to encourage the unity of all
peoples on the earth so that justice and peace may be
achieved on earth. Baha’i revelation contends the
prophets of major world religions reflect some truth or
element of the divine, believes all were manifestations of
God given to specific communities in specific times, and
that Baha’u’llah is an additional prophet meant to call all
humankind. Bahais are an open community, located
worldwide, with the greatest concentration of believers
in South Asia.
Buddhism—Religion or philosophy inspired by the 5th
century B.C. teachings of Siddhartha Gautama (also
known as Gautama Buddha “the enlightened one”).
Buddhism focuses on the goal of spiritual enlightenment
centered on an understanding of Gautama Buddha’s
Four Noble Truths on the nature of suffering, and on the
Eightfold Path of spiritual and moral practice, to break
the cycle of suffering of which we are a part. Buddhism
ascribes to a karmic system of rebirth. Several schools
and sects of Buddhism exist, differing often on the
nature of the Buddha, the extent to which enlightenment
can be achieved—for one or for all, and by whom—
religious orders or laity.
Basic Groupings Theravada Buddhism: The _ oldest
Buddhist school, Theravada is practiced mostly in Sri
Lanka, Cambodia, Laos, Burma, and Thailand, with
minority representation elsewhere in Asia and the West.
Theravadans follow the Pali Canon of Buddha’s
teachings, and believe that one may escape the cycle of
rebirth, worldly attachment, and suffering for oneself;
this process may take one or several lifetimes.
Mahayana Buddhism, including subsets Zen and Tibetan
(Lamaistic) Buddhism: Forms of Mahayana Buddhism
are common in East Asia and Tibet, and parts of the
West. Mahayanas have additional scriptures beyond the
Pali Canon and believe the Buddha is eternal and still
teaching. Unlike Theravada Buddhism, Mahayana
schools maintain the Buddha-nature is present in all
beings and all will ultimately achieve enlightenment.
Hoa Hao: a minority tradition of Buddhism practiced in
Vietnam that stresses lay participation, primarily by
peasant farmers; it eschews expensive ceremonies and
temples and relocates the primary practices into the
home.
Christianity—Descending from Judaism, Christianity’s
central belief maintains Jesus of Nazareth is the
promised messiah of the Hebrew Scriptures, and that
his life, death, and resurrection are salvific for the
world. Christianity is one of the three monotheistic
Abrahamic faiths, along with Islam and Judaism, which
traces its spiritual lineage to Abraham of the Hebrew
Scriptures. Its sacred texts include the Hebrew Bible
and the New Testament (or the Christian Gospels).
Basic Groupings
Catholicism (or Roman Catholicism): This is the oldest
established western Christian church and the world’s
largest single religious body. It is supranational, and
recognizes a hierarchical structure with the Pope, or
Bishop of Rome, as its head, located at the Vatican.
Catholics believe the Pope is the divinely ordered head
of the Church from a direct spiritual legacy of Jesus’
apostle Peter. Catholicism is comprised of 23 particular
Churches, or Rites—one Western (Roman or Latin-Rite)
and 22 Eastern. The Latin Rite is by far the largest,
making up about 98% of Catholic membership. Eastern-
Rite Churches, such as the Maronite Church and the
Ukrainian Catholic Church, are in communion with
Rome although they preserve their own worship
traditions and their immediate hierarchy consists of
clergy within their own rite. The Catholic Church has a
comprehensive theological and moral doctrine specified
for believers in its catechism, which makes it unique
among most forms of Christianity.
Mormonism (including the Church of Jesus Christ of
Latter-Day Saints): Originating in 1830 in the United
States under Joseph Smith, Mormonism is_ not
characterized as a form of Protestant Christianity
because it claims additional revealed Christian
scriptures after the Hebrew Bible and New Testament.
The Book of Mormon maintains there was an
appearance of Jesus in the New World following the
Christian account of his resurrection, and that the
Americas are uniquely blessed continents. Mormonism
believes earlier Christian traditions, such as the Roman
Catholic, Orthodox, and Protestant reform faiths, are
apostasies and that Joseph Smith’s revelation of the
Book of Mormon is a restoration of true Christianity.
Mormons have a_ hierarchical religious leadership
structure, and actively proselytize their faith; they are
located primarily in the Americas and in a number of
other Western countries.
Jehovah’s Witnesses structure their faith on the
Christian Bible, but their rejection of the Trinity is
distinct from mainstream Christianity. They believe that
a Kingdom of God, the Theocracy, will emerge following
Armageddon and usher in a new earthly society.
Adherents are required to evangelize and to follow a
strict moral code.
Orthodox Christianity: The oldest established eastern
form of Christianity, the Holy Orthodox Church, has a
ceremonial head in the Bishop of Constantinople
(Istanbul), also known as a Patriarch, but its various
regional forms (e.g., Greek Orthodox, Russian Orthodox,
Serbian Orthodox, Ukrainian Orthodox) are
autocephalous (independent of Constantinople’s
authority, and have their own Patriarchs). Orthodox
churches are highly nationalist and ethnic. The Orthodox
Christian faith shares many theological tenets with the
Roman Catholic Church, but diverges on some key
premises and does not recognize the governing
authority of the Pope.
Protestant Christianity: Protestant Christianity
originated in the 16th century as an attempt to reform
Roman Catholicism’s practices, dogma, and theology. It
encompasses several forms or denominations which are
extremely varied in structure, beliefs, relationship to
state, clergy, and governance. Many protestant
theologies emphasize the primary role of scripture in
their faith, advocating individual interpretation of
Christian texts without the mediation of a final religious
authority such as the Roman Pope. The oldest Protestant
Christianities include Lutheranism, Calvinism
(Presbyterians), and Anglican Christianity
(Episcopalians), which have established liturgies,
governing structure, and formal clergy. Other variants
on Protestant Christianity, including Pentecostal
movements and independent churches, may lack one or
more of these elements, and their leadership and beliefs
are individualized and dynamic.
Hinduism— Originating in the Vedic civilization of India
(second and first millennium B.C.), Hinduism is an
extremely diverse set of beliefs and practices with no
single founder or religious authority. Hinduism has many
scriptures; the Vedas, the Upanishads, and _ the
Bhagavad-Gita are among some of the most important.
Hindus may worship one or many deities, usually with
prayer rituals within their own home. The most common
figures of devotion are the gods Vishnu, Shiva, and a
mother goddess, Devi. Most Hindus believe the soul, or
atman, is eternal, and goes through a cycle of birth,
death, and rebirth (samsara) determined by one’s
positive or negative karma, or the consequences of one’s
actions. The goal of religious life is to learn to act so as
to finally achieve liberation (moksha) of one’s soul,
escaping the rebirth cycle.
Islam—tThe third of the monotheistic Abrahamic faiths,
Islam originated with the teachings of Muhammad in the
7th century. Muslims believe Muhammad is the final of
all religious prophets (beginning with Abraham) and
that the Qu’ran, which is the Islamic scripture, was
revealed to him by God. Islam derives from the word
submission, and obedience to God is a primary theme in
this religion. In order to live an Islamic life, believers
must follow the five pillars, or tenets, of Islam, which are
the testimony of faith (shahada), daily prayer (salah),
giving alms (zakah), fasting during Ramadan (sawm),
and the pilgrimage to Mecca (hajj).
Basic Groupings
The two primary branches of Islam are Sunni and Shia,
which split from each other over a religio-political
leadership dispute about the rightful successor to
Muhammad. The Shia believe Muhammad’s cousin and
son-in-law, Ali, was the only divinely ordained Imam
(religious leader), while the Sunni maintain the first
three caliphs after Muhammad were also legitimate
authorities. In modern Islam, Sunnis and Shia continue
to have different views of acceptable schools of Islamic
jurisprudence, and who is a proper Islamic religious
authority. Islam also has an active mystical branch,
Sufism, with various Sunni and Shia subsets.
Sunni Islam accounts for over 75% of the world’s
Muslim population. It recognizes the Abu Bakr as the
first caliph after Muhammad. Sunni has four schools of
Islamic doctrine and law—Hanafi, Maliki, Shafi’i, and
Hanbali—which uniguely interpret the Hadith, or
recorded oral traditions of Muhammad. A Sunni Muslim
may elect to follow any one of these schools, as all are
considered equally valid.
Shia Islam represents 10-20% of Muslims worldwide,
and its distinguishing feature is its reverence for Ali as
an infallible, divinely inspired leader, and as the first
Imam of the Muslim community after Muhammad. A
majority of Shia are known as “Twelvers,” because they
believe that the 11 familial successor imams after
Muhammad culminate in a 12th Imam (al-Mahdi) who is
hidden in the world and will reappear at its end to
redeem the righteous.
Variants Ismaili faith: A sect of Shia Islam, its adherents
are also known as “Seveners,” because they believe that
the rightful seventh Imam in Islamic leadership was
Isma’il, the elder son of Imam Jafar al-Sadig. Ismaili
tradition awaits the return of the seventh Imam as the
Mahdi, or Islamic messianic figure. Ismailis are located
in various parts of the world, particularly South Asia and
the Levant.
Alawi faith: Another Shia sect of Islam, the name reflects
followers’ devotion to the religious authority of Ali.
Alawites are a closed, secretive religious group who
assert they are Shia Muslims, although outside scholars
speculate their beliefs may have a syncretic mix with
other faiths originating in the Middle East. Alawis live
mostly in Syria, Lebanon, and Turkey.
Druze faith: A highly secretive tradition and a closed
community that derives from the Ismaili sect of Islam;
its core beliefs are thought to emphasize a combination
of Gnostic principles believing that the Fatimid caliph,
al-Hakin, is the one who embodies the key aspects of
goodness of the universe, which are, the intellect, the
word, the soul, the preceder, and the follower. The Druze
have a key presence in Syria, Lebanon, and Israel.
Jainism—Originating in India, Jain spiritual philosophy
believes in an eternal human soul, the eternal universe,
and a principle of “the own nature of things.” It
emphasizes compassion for all living things, seeks
liberation of the human soul from reincarnation through
enlightenment, and values personal responsibility due to
the belief in the immediate consequences of one’s
behavior. Jain philosophy teaches non-violence and
prescribes vegetarianism for monks and laity alike; its
adherents are a highly influential religious minority in
Indian society.
Judaism—One of the first known monotheistic religions,
likely dating to between 2000-1500 B.C., Judaism is the
native faith of the Jewish people, based upon the belief
in a covenant of responsibility between a_ sole
omnipotent creator God and Abraham, the patriarch of
Judaism’s Hebrew Bible, or Tanakh. Divine revelation of
principles and prohibitions in the Hebrew Scriptures
form the basis of Jewish law, or halakhah, which is a key
component of the faith. While there are extensive
traditions of Jewish halakhic and theological discourse,
there is no final dogmatic authority in the tradition.
Local communities have their own religious leadership.
Modern Judaism has three basic categories of faith:
Orthodox, Conservative, and Reform/Liberal. These
differ in their views and observance of Jewish law, with
the Orthodox representing the most traditional practice,
and Reform/Liberal communities the most
accommodating of individualized interpretations of
Jewish identity and faith.
Shintoism—A native animist tradition of Japan, Shinto
practice is based upon the premise that every being and
object has its own spirit or kami. Shinto practitioners
worship several particular kamis, including the kamis of
nature, and families often have shrines to _ their
ancestors’ kamis. Shintoism has no fixed tradition of
prayers or prescribed dogma, but is characterized by
individual ritual. Respect for the kamis in nature is a key
Shinto value. Prior to the end of World War II, Shinto
was the state religion of Japan, and bolstered the cult of
the Japanese emperor.
Sikhism—Founded by the Guru Nanak (born 1469),
Sikhism believes in a non-anthropomorphic, supreme,
eternal, creator God; centering one’s devotion to God is
seen as a means of escaping the cycle of rebirth. Sikhs
follow the teachings of Nanak and nine subsequent
gurus. Their scripture, the Guru Granth Sahib—also
known as the Adi Granth—is considered the living Guru,
or final authority of Sikh faith and theology. Sikhism
emphasizes equality of humankind and disavows caste,
class, or gender discrimination.
Taoism—Chinese philosophy or religion based upon Lao
Tzu’s Tao Te Ching, which centers on belief in the Tao,
or the way, as the flow of the universe and the nature of
things. Taoism encourages a principle of non-force, or
wu-wei, as the means to live harmoniously with the Tao.
Taoists believe the esoteric world is made up of a perfect
harmonious balance and nature, while in the manifest
world—particularly in the body—balance is distorted.
The Three Jewels of the Tao—compassion, simplicity, and
humility—serve as the basis for Taoist ethics.
Zoroastrianism—Originating from the teachings of
Zoroaster in about the 9th or 10th century B.C.,
Zoroastrianism may be the oldest continuing creedal
religion. Its key beliefs center on a transcendent creator
God, Ahura Mazda, and the concept of free will. The key
ethical tenets of Zoroastrianism expressed in_ its
scripture, the Avesta, are based on a dualistic worldview
where one may prevent chaos if one chooses to serve
God and exercises good thoughts, good words, and good
deeds. Zoroastrianism is generally a closed religion and
members are almost always born to Zoroastrian parents.
Prior to the spread of Islam, Zoroastrianism dominated
greater Iran. Today, though a minority, Zoroastrians
remain primarily in Iran, India (where they are known as
Parsi), and Pakistan.
Traditional beliefs
Animism: the belief that non-human entities contain
souls or spirits.
Badimo: a form of ancestor worship of the Tswana
people of Botswana.
Confucianism: an ideology that humans are perfectible
through self-cultivation and _ self-creation; developed
from teachings of the Chinese philosopher Confucius.
Confucianism has strongly influenced the culture and
beliefs of East Asian countries, including China, Japan,
Korea, Singapore, Taiwan, and Vietnam.
Inuit beliefs are a form of shamanism (see below) based
on animistic principles of the Inuit or Eskimo peoples.
Kirant: the belief system of the Kirat, a people who live
mainly in the Himalayas of Nepal. It is primarily a form
of polytheistic shamanism, but includes elements of
animism and ancestor worship.
Pagan is a blanket term used to describe many
unconnected belief practices throughout history, usually
in reference to religions outside of the Abrahamic
category (monotheistic faiths like Judaism, Christianity,
and Islam).
Shamanism: beliefs and practices promoting
communication with the spiritual world. Shamanistic
beliefs are organized around a shaman or medicine man
who—as an intermediary between the human and spirit
world—is believed to be able to heal the sick (by healing
their souls), communicate with the spirit world, and help
souls into the afterlife through the practice of entering a
trance. In shaman-based religions, the shaman is also
responsible for leading sacred rites.
Spiritualism: the belief that souls and _ spirits
communicate with the _ living’ usually through
intermediaries called mediums.
Syncretic (fusion of diverse religious beliefs and
practices) Cao Dai: a nationalistic Vietnamese sect,
officially established in 1926, that draws practices and
precepts from Confucianism, Taoism, Buddhism, and
Catholicism.
Chondogyo: or the religion of the Heavenly Way, is based
on Korean shamanism, Buddhism, and Korean folk
traditions, with some elements drawn from Christianity.
Formulated in the 1860s, it holds that God lives in all of
us and strives to convert society into a paradise on
earth, populated by believers’ transformed into
intelligent moral beings with a high social conscience.
Kimbanguist: a puritan form of the Baptist denomination
founded by Simon Kimbangu in the 1920s in what is now
the Democratic Republic of Congo. Adherents believe
that salvation comes through Jesus’ death and
resurrection, like Christianity, but additionally that living
a spiritually pure life following strict codes of conduct is
required for salvation.
Modekngei: a hybrid of Christianity and ancient Palauan
culture and oral traditions founded around 1915 on the
island of Babeldaob. Adherents simultaneously worship
Jesus Christ and Palauan goddesses.
Rastafarian: an afro-centrist ideology and movement
based on Christianity that arose in Jamaica in the 1930s;
it believes that Haile Selassie I, Emperor of Ethiopia
from 1930-74, was the incarnation of the second coming
of Jesus.
Santeria: practiced in Cuba, the merging of the Yoruba
religion of Nigeria with Roman Catholicism and native
Indian traditions. Its practitioners believe that each
person has a destiny and eventually transcends to merge
with the divine creator and source of all energy, Olorun.
Voodoo/Vodun: a form of spirit and ancestor worship
combined with some Christian faiths, especially
Catholicism. Haitian and Louisiana Voodoo, which have
included more Catholic practices, are separate from
West African Vodun, which has retained a focus on spirit
worship.
Non—religious Agnosticism: the belief that most things
are unknowable. In regard to religion it is usually
Characterized as neither a belief nor non belief in a
deity.
Atheism: the belief that there are no deities of any kind.
Reserves of foreign exchange and gold This entry
gives the dollar value for the stock of all financial assets
that are available to the central monetary authority for use
in meeting a country’s balance of payments needs as of the
end-date of the period specified. This category includes not
only foreign currency and gold, but also a country’s
holdings of Special Drawing Rights in the International
Monetary Fund, and its reserve position in the Fund.
Roadways This entry gives the total length of the road
network and includes the length of the paved and unpaved
portions.
Sanitation facility access This entry provides
information about access to improved or unimproved
sanitation facilities available to segments of the population
of a country. Improved sanitation—use of any of the
following facilities: flush or pour-flush to a piped sewer
system, septic tank or pit latrine; ventilated improved pit
(VIP) latrine; pit latrine with slab; or a composting toilet.
Unimproved sanitation—use of any of the following
facilities: flush or pour-flush not piped to a sewer system,
septic tank or pit latrine; pit latrine without a slab or open
pit; bucket; hanging toilet or hanging latrine; shared
facilities of any type; no facilities; or bush or field.
School life expectancy (primary to tertiary
education) School life expectancy (SLE) is the total
number of years of schooling (primary to tertiary) that a
child can expect to receive, assuming that the probability of
his or her being enrolled in school at any particular future
age is equal to the current enrollment ratio at that age.
Caution must be maintained when utilizing this indicator in
international comparisons. For example, a year or grade
completed in one country is not necessarily the same in
terms of educational content or quality as a year or grade
completed in another country. SLE represents the expected
number of years of schooling that will be completed,
including years spent repeating one or more grades.
Sex ratio This entry includes the number of males for
each female in five age groups—at birth, under 15 years,
15-64 years, 65 years and over, and for the total population.
Sex ratio at birth has recently emerged as an indicator of
certain kinds of sex discrimination in some countries. For
instance, high sex ratios at birth in some Asian countries
are now attributed to sex-selective abortion and infanticide
due to a strong preference for sons. This will affect future
marriage patterns and fertility patterns. Eventually, it could
cause unrest among young adult males who are unable to
find partners.
Stateless person Statelessness is the condition
whereby an individual is not considered a national by any
country. Stateless people are denied basic rights, such as
access to employment, housing, education, healthcare, and
pensions, and they may be unable to vote, own property,
open a bank account, or legally register a marriage or
birth. They may also be vulnerable to arbitrary treatment
and human trafficking. In at least 30 states, women cannot
pass their nationality on to their children. In these
countries, if a child’s father is foreign, stateless, or absent,
the child usually becomes stateless. Estimates of the
number of stateless people are inherently imprecise
because few countries have procedures to identify them;
the UN approximates that there are 12 million stateless
people worldwide. Stateless people are counted in a
country’s overall population figure if they have lived there
for a year.
Suffrage This entry gives the age at enfranchisement and
whether the right to vote is universal or restricted.
Taxes and other revenues This entry records total
taxes and other revenues received by the national
government during the time period indicated, expressed as
a percent of GDP. Taxes include personal and corporate
income taxes, value added taxes, excise taxes, and tariffs.
Other revenues include social contributions—such as
payments for social security and hospital insurance—
grants, and net revenues from _ public’ enterprises.
Normalizing the data, by dividing total revenues by GDP
enables easy comparisons across countries, and provides
an average rate at which all income (GDP) is paid to the
national level government for the supply of public goods
and services.
Telephone numbers All telephone numbers in The
World Factbook consist of the country code in brackets, the
city or area code (where required) in parentheses, and the
local number. The one component that is not presented is
the international access code, which varies from country to
country. For example, an international direct dial telephone
call placed from the US to Madrid, Spain, would be as
follows: 011 [34] (1) 577-xxxx, where O11 is the
international access code for station-to-station calls; 01 is
for calls other than station-to-station calls, [34] is the
country code for Spain, (1) is the city code for Madrid, 577
is the local exchange, and xxxx is the local telephone
number. An international direct dial telephone call placed
from another country to the US would be as follows:
international access code + [1] (202) 939-xxxx, where [1] is
the country code for the US, (202) is the area code for
Washington, DC, 939 is the local exchange, and xxxx is the
local telephone number.
Telepho','851b14c00a7cf3de4baa468a8eefc903e8eb438cfa9c2f7873d815cef387060d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e1230954cbb59a8af9d5e081dbd34dc7e5ce7eb135a86281c4a1f6a609aebe0',2020,'US','United States','introduction',32,'ne system This entry includes a brief general
assessment of the system with details on the domestic and
international components. The following terms and
abbreviations are used throughout the entry: Arabsat—
Arab Satellite Communications Organization (Riyadh, Saudi
Arabia).
Autodin—Automatic Digital Network (US Department of
Defense).
CB—citizen’s band mobile radio communications.
Cellular telephone system—the telephones in this
system are radio transceivers, with each instrument
having its own private radio frequency and sufficient
radiated power to reach the booster station in its area
(cell), from which the telephone signal is fed to a
telephone exchange.
Central American Microwave System—a_§ trunk
microwave radio relay system that links the countries of
Central America and Mexico with each other.
Coaxial cable—a multichannel communication cable
consisting of a central conducting wire, surrounded by
and insulated from a cylindrical conducting shell; a large
number of telephone channels can be made available
within the insulated space by the use of a large number
of carrier frequencies.
Comsat—Communications Satellite Corporation (US).
DSN—Defense Switched Network (formerly Automatic
Voice Network or Autovon); basic general-purpose,
switched voice network of the Defense Communications
System (US Department of Defense).
Eutelsat—European ‘Telecommunications Satellite
Organization (Paris).
Fiber-optic cable—a multichannel communications
cable using a thread of optical glass fibers as a
transmission medium in which the signal (voice, video,
etc.) is in the form of a coded pulse of light.
GSM—a_ global system for mobile (cellular)
communications devised by the Groupe Special Mobile
of the pan-European standardization organization,
Conference Europeanne des Posts et
Telecommunications (CEPT) in 1982.
HF—high frequency; any radio frequency in the 3,000-to
30,000-kHz range.
Inmarsat—International Maritime Satellite
Organization (London); provider of global mobile
satellite communications for commercial, distress, and
safety applications at sea, in the air, and on land.
Intelsat—International Telecommunications Satellite
Organization (Washington, DC).
Intersputnik—International Organization of Space
Communications (Moscow); first established in the
former Soviet Union and the East European countries, it
is now marketing its services worldwide with earth
stations in North America, Africa, and East Asia.
Landline—communication wire or cable of any sort that
is installed on poles or buried in the ground.
Marecs—Maritime European Communications Satellite
used in the Inmarsat system on lease from the European
Space Agency.
Marisat—satellites of the Comsat Corporation that
participate in the Inmarsat system.
Medarabtel—the Middle East Telecommunications
Project of the International Telecommunications Union
(ITU) providing a modern telecommunications network,
primarily by microwave radio relay, linking Algeria,
Djibouti, Egypt, Jordan, Libya, Morocco, Saudi Arabia,
Somalia, Sudan, Syria, Tunisia, and Yemen; it was
initially started in Morocco in 1970 by the Arab
Telecommunications Union (ATU) and was known at that
time as the Middle East Mediterranean
Telecommunications Network.
Microwave radio relay—transmission of long distance
telephone calls and television programs by highly
directional radio microwaves that are received and sent
on from one booster station to another on an optical
path.
NMT—Nordic Mobile Telephone; an analog cellular
telephone system that was developed jointly by the
national telecommunications authorities of the Nordic
countries (Denmark, Finland, Iceland, Norway, and
Sweden).
Orbita—a Russian television service; also the trade
name of a packet-switched digital telephone network.
Radiotelephone communications—the two-way
transmission and reception of sounds by broadcast radio
on authorized frequencies using telephone handsets.
PanAmSat—PanAmSat Corporation (Greenwich, CT).
SAFE—South African Far East Cable Satellite
communication system—a communication system
consisting of two or more earth stations and at least one
satellite that provide long distance transmission of
voice, data, and television; the system usually serves as
a trunk connection between telephone exchanges; if the
earth stations are in the same country, it is a domestic
system.
Satellite earth station—a communications facility with
a microwave radio transmitting and receiving antenna
and required receiving and transmitting equipment for
communicating with satellites.
Satellite link—a radio connection between a satellite
and an earth station permitting communication between
them, either one-way (down link from satellite to earth
station—television receive-only transmission) or two-way
(telephone channels).
SHF—super high frequency; any radio frequency in the
3,000- to 30,000-MHz range.
Shortwave—radio frequencies (from 1.605 to 30 MHz)
that fall above the commercial broadcast band and are
used for communication over long distances.
Solidaridad—geosynchronous satellites in Mexico’s
system of international telecommunications in the
Western Hemisphere.
Statsionar—Russia’s geostationary system for satellite
telecommunications.
Submarine cable—a cable designed for service under
water.
TAT—Trans-Atlantic Telephone; any of a number of high-
Capacity submarine coaxial telephone cables linking
Europe with North America.
Telefax—facsimile service between subscriber stations
via the public switched telephone network or the
international Datel network.
Telegraph—a telecommunications system designed for
unmodulated electric impulse transmission.
Telex—a communication service involving
teletypewriters connected by wire through automatic
exchanges.
Tropospheric scatter—a form of microwave radio
transmission in which the troposphere is used to scatter
and reflect a fraction of the incident radio waves back to
earth; powerful, highly directional antennas are used to
transmit and receive the microwave signals; reliable
over-the-horizon communications are realized for
distances up to 600 miles in a single hop; additional
hops can extend the range of this system for very long
distances.
Trunk network—a network of switching centers,
connected by multichannel trunk lines.
UHF—ultra high frequency; any radio frequency in the
300- to 3,000-MHz range.
VHF—very high frequency; any radio frequency in the
30- to 300-MHz range.
Telephones—fixed lines This entry gives the total
number of fixed telephone lines in use, as well as the
number of subscriptions per 100 inhabitants.
Telephones—mobile cellular This entry gives the
total number of mobile cellular telephone subscribers, as
well as the number of subscriptions per 100 inhabitants.
Note that because of the ubiquity of mobile phone use in
developed countries, the number of subscriptions per 100
inhabitants can exceed 100.
Terminology Due to the highly structured nature of the
Factbook database, some collective generic terms have to
be used. For example, the word Country in the Country
name entry refers to a wide variety of dependencies, areas
of special sovereignty, uninhabited islands, and other
entities in addition to the traditional countries or
independent states. Military is also used as an umbrella
term for various civil defense, security, and defense
activities in many entries. The Independence entry
includes the usual colonial independence dates and former
ruling states as well as other significant nationhood dates
such as the traditional founding date or the date of
unification, federation, confederation, establishment, or
state succession that are not strictly independence dates.
Dependent areas have the nature of their dependency
status noted in this same entry.
Terrain This entry contains a brief description of the
topography.
Terrorist groups—foreign based This entry provides
information on the US State Department’s designated
Foreign Terrorist Organizations operating in countries
other than where a particular group is headquartered.
Details on each organization’s aim(s) and area(s) of
operation are provided.
Terrorist groups—home based This entry provides
information on the US State Department’s designated
Foreign Terrorist Organizations headquartered in a specific
country, which may or may not be a group’s country of
origin. Details on each organization’s aim(s) and area(s) of
operation are provided.
Time difference This entry is expressed in The World
Factbook in two ways. First, it is stated as the difference in
hours between the capital of an entity and Coordinated
Universal Time (UTC) during Standard _ Time.
Additionally, the difference in time between the capital of
an entity and that observed in Washington, D.C., is also
provided. Note that the time difference assumes both
locations are simultaneously observing Standard Time or
Daylight Saving Time.
Time zones Ten countries (Australia, Brazil, Canada,
Indonesia, Kazakhstan, Mexico, New Zealand, Russia,
Spain, and the United States) and the island of Greenland
observe more than one official time depending on the
number of designated time zones within their boundaries.
An illustration of time zones throughout the world and
within countries can be seen in the Standard Time Zones of
the World map included in the Reference Maps section of
The World Factbook.
Total fertility rate This entry gives a figure for the
average number of children that would be born per woman
if all women lived to the end of their childbearing years and
bore children according to a given fertility rate at each age.
The total fertility rate (TFR) is a more direct measure of the
level of fertility than the crude birth rate, since it refers to
births per woman. This indicator shows the potential for
population change in the country. A rate of two children per
woman is considered the replacement rate for a population,
resulting in relative stability in terms of total numbers.
Rates above two children indicate populations growing in
size and whose median age is declining. Higher rates may
also indicate difficulties for families, in some situations, to
feed and educate their children and for women to enter the
labor force. Rates below two children indicate populations
decreasing in size and growing older. Global fertility rates
are in general decline and this trend is most pronounced in
industrialized countries, especially Western Europe, where
populations are projected to decline dramatically over the
next 50 years.
Trafficking in persons Trafficking in persons is
modern-day slavery, involving victims who are forced,
defrauded, or coerced into labor or sexual exploitation. The
International Labor Organization (ILO), the UN agency
charged with addressing labor standards, employment, and
social protection issues, estimated in 2011 that 20.9 million
people worldwide were victims of forced labor, bonded
labor, forced child labor, sexual servitude, and involuntary
servitude. Human trafficking is a multi-dimensional threat,
depriving people of their human rights and freedoms,
risking global health, promoting social breakdown,
inhibiting development by depriving countries of their
human capital, and helping fuel the growth of organized
crime. In 2000, the US Congress passed the Trafficking
Victims Protection Act (TVPA), reauthorized in 2003 and
2005, which provides tools for the US to combat trafficking
in persons, both domestically and abroad. One of the law’s
key components is the creation of the US Department of
State’s annual Trafficking in Persons Report, which
assesses the government response (i.e., the current
situation) in some 150 countries with a significant number
of victims trafficked across their borders who are recruited,
harbored, transported, provided, or obtained for forced
labor or sexual exploitation. Countries in the annual report
are rated in three tiers, based on government efforts to
combat trafficking.
The countries identified in this entry are those listed in
the 2010 Trafficking in Persons Report as “Tier 2 Watch
List’ or ‘Tier 3’ based on the following tier rating
definitions: Tier 2 Watch List countries do not fully
comply with the minimum standards for the elimination
of trafficking but are making significant efforts to do so,
and meet one of the following criteria: 1. they display
high or significantly increasing number of victims, 2.
they have failed to provide evidence of increasing efforts
to combat trafficking in persons, or, 3. they have
committed to take action over the next year.
Tier 3 countries neither satisfy the minimum standards
for the elimination of trafficking nor demonstrate a
significant effort to do so. Countries in this tier are
subject to potential non-humanitarian and non-trade
sanctions.
Transnational tssues This category includes four
entries—Disputes-international, Refugees and
internally displaced persons, Trafficking in persons,
and Illicit drugs—that deal with current issues going
beyond national boundaries.
Transportation This category includes the entries
dealing with the means for movement of people and goods.
Transportation—note This entry includes
miscellaneous transportation information of significance
not included elsewhere.
Unemployment rate This entry contains the percent of
the labor force that is without jobs. Substantial
underemployment might be noted.
Unemployment, youth ages 15-24 This entry gives
the percent of the total labor force ages 15-24 unemployed
during a specified year.
Union name This entry, which appears only in the
European Union, Government category, provides the full
name and abbreviation for the European Union.
Urbanization This entry provides two measures of the
degree of urbanization of a population. The first, urban
population, describes the percentage of the total population
living in urban areas, as defined by the country. The
second, rate of urbanization, describes the projected
average rate of change of the size of the urban population
over the given period of time. It is possible for a country
with a 100% urban population to still display a change in
the rate of urbanization (up or down). For example, a
population of 100,000 that is 100% urban can change in
size to 110,000 or 90,000 but remain 100% urban.
Additionally, the World entry includes a list of the ten
largest urban agglomerations. An urban agglomeration is
defined as comprising the city or town proper and also the
suburban fringe or thickly settled territory lying outside of,
but adjacent to, the boundaries of the city.
UTC (Coordinated Universal Time) See entry for
Coordinated Universal Time.
Waterways This entry gives the total length of navigable
rivers, canals, and other inland bodies of water.
Weights and Measures This information is presented
in Appendix G: Weights and Measures and includes
mathematical notations (mathematical powers and names),
metric interrelationships (prefix; symbol; length, weight, or
Capacity; area; volume), and standard conversion factors.
Years All year references are for the calendar year (CY)
unless indicated as fiscal year (FY). The calendar year is an
accounting period of 12 months from 1 January to 31
December. The fiscal year is an accounting period of 12
months other than 1 January to 31 December.
GUIDE TO COUNTRY PROFILES
These are the Categories, Fields, and subfields of
information generally recorded for each country. Links are
to the Definitions and Notes about each entry.
Background: Britain’s American colonies broke with the
mother country in 1776 and were recognized as the new
nation of the United States of America following the Treaty
of Paris in 1783. During the 19th and 20th centuries, 37
new states were added to the original 13 as the nation
expanded across the North American continent and
acquired a number of overseas possessions. The two most
traumatic experiences in the nation’s history were the Civil
War (1861-65), in which a northern Union of states
defeated a secessionist Confederacy of 11 southern slave
states, and the Great Depression of the 1930s, an economic
downturn during which about a quarter of the labor force
lost its jobs. Buoyed by victories in World Wars I and II and
the end of the Cold War in 1991, the US remains the
world’s most powerful nation state. Since the end of World
War II, the economy has achieved relatively steady growth,
low unemployment and inflation, and rapid advances in
technology.
Background: All of the following US Pacific island territories
except Midway Atoll constitute the Pacific Remote Islands
National Wildlife Refuge (NWR) Complex and as such are
managed by the Fish and Wildlife Service of the US
Department of the Interior. Midway Atoll NWR has been
included in a Refuge Complex with the Hawaiian Islands
NWR and also designated as part of Papahanaumokuakea
Marine National Monument. These remote refuges are the
most widespread collection of marine- and terrestrial-life
protected areas on the planet under a single country’s
jurisdiction. They sustain many endemic species including
corals, fish, shellfish, marine mammals, seabirds, water
birds, land birds, insects, and vegetation not found
elsewhere.
Baker Island: The US took possession of the island in 1857.
Its guano deposits were mined by US and British
companies during the second half of the 19th century. In
1935, a short-lived attempt at colonization began on this
island but was disrupted by World War II and thereafter
abandoned. The island was established as a NWR in 1974.;
Howland Island: Discovered by the US early in the 19th
century, the uninhabited atoll was officially claimed by the
US in 1857. Both US and British companies mined for
guano deposits until about 1890. In 1935, a short-lived
attempt at colonization began on this island, similar to the
effort on nearby Baker Island, but was disrupted by World
War II and thereafter abandoned. The famed American
aviatrix Amelia EARHART disappeared while seeking out
Howland Island as a refueling stop during her 1937 round-
the-world flight; Earhart Light, a day beacon near the
middle of the west coast, was named in her memory. The
island was established as a NWR in 1974.; Jarvis Island:
First discovered by the British in 1821, the uninhabited
island was annexed by the US in 1858 but abandoned in
1879 after tons of guano had been removed. The UK
annexed the island in 1889 but never carried out plans for
further exploitation. The US occupied and reclaimed the
island in 1935. It was abandoned in 1942 during World War
II. The island was established as a NWR in 1974.; Johnston
Atoll: Both the US and the Kingdom of Hawaii annexed
Johnston Atoll in 1858, but it was the US that mined the
guano deposits until the late 1880s. Johnston and Sand
Islands were designated wildlife refuges in 1926. The US
Navy took over the atoll in 1934. Subsequently, the US Air
Force assumed control in 1948. The site was used for high-
altitude nuclear tests in the 1950s and 1960s. Until late in
2000 the atoll was maintained as a storage and disposal
site for chemical weapons. Munitions destruction, cleanup,
and closure of the facility were completed by May 2005.
The Fish and Wildlife Service and the US Air Force are
currently discussing future management options; in the
interim, Johnston Atoll and the three-mile Naval Defensive
Sea around it remain under the jurisdiction and
administrative control of the US Air Force.; Kingman Reef:
The US annexed the reef in 1922. Its sheltered lagoon
served as a way Station for flying boats on Hawaii-to-
American Samoa flights during the late 1930s. There are no
terrestrial plants on the reef, which is frequently awash,
but it does support abundant and diverse marine fauna and
flora. In 2001, the waters surrounding the reef out to 12
nm were designated a NWR.; Midway Islands: The US took
formal possession of the islands in 1867. The laying of the
transpacific cable, which passed through the _ islands,
brought the first residents in 1903. Between 1935 and
1947, Midway was used as a refueling stop for transpacific
flights. The US naval victory over a Japanese fleet off
Midway in 1942 was one of the turning points of World War
II. The islands continued to serve as a naval station until
closed in 1993. Today the islands are a NWR and are the
site of the world’s largest Laysan albatross colony.; Palmyra
Atoll: The Kingdom of Hawaii claimed the atoll in 1862, and
the US included it among the Hawaiian Islands when it
annexed the archipelago in 1898. The Hawaii Statehood
Act of 1959 did not include Palmyra Atoll, which is now
partly privately owned by the Nature Conservancy with the
rest owned by the Federal government and managed by the
US Fish and Wildlife Service. These organizations are
managing the atoll as a wildlife refuge. The lagoons and
surrounding waters within the 12-nm US territorial seas
were transferred to the US Fish and Wildlife Service and
designated a NWR in January 2001.','3307edb03062e211c3604444d6fef661588089e5c6fdbd72056633facef50e17','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16f0867f02a2663e040d8aca588606ebc3cc4aeeaaf6fb494eaf09293f795c77',2020,'VU','Vanuatu','introduction',33,'Venezuela
Vietnam
Virgin Islands
Wake Island
Background: Settled by both Britain and France during the
first half of the 19th century, the island became a French
possession in 1853. It served as a penal colony for four
decades after 1864. Agitation for independence during the
1980s and early 1990s ended in the 1998 Noumea Accord,
which over two decades transferred an increasing amount
of governing responsibility from France to New Caledonia.
In a referendum held in November 2018, residents rejected
independence and decided to retain their territorial status,
although two additional referendums may occur in 2020
and 2022, per the Noumea Accord.','a99f86dfbd8a27a64acefeb210672ba53ea5c84ea5c7361fbc9fd1c370c4c83f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7a36717523c0db531e199a1e06ef4bdbd93e3737bc72914ef754292c95b1a1c',2020,'WF','Wallis and Futuna','introduction',34,'West Bank
Background: The Futuna island group was discovered by the
Dutch in 1616 and Wallis by the British in 1767, but it was
the French who declared a protectorate over the islands in
1842, and took official control of them between 1886 and
1888. Notably, Wallis and Futuna was the only French
colony to side with the Vichy regime during World War II, a
phase that ended in May of 1942 with the arrival of 2,000
American troops. In 1959, the inhabitants of the islands
voted to become a French overseas territory and officially
assumed that status in 1961. In 2003, Wallis and Futuna’s
designation changed to that of an overseas collectivity.
Background: Inhabited since at least the 15th century B.C.,
the West Bank has been dominated by many different
peoples throughout its history; it was incorporated into the
Ottoman Empire in the early 16th century. The West Bank
fell to British forces during World War I, becoming part of
the British Mandate of Palestine. Following the 1948 Arab-
Israeli War, the West Bank was captured by Transjordan
(later renamed Jordan), which annexed the West Bank in
1950; it was captured by Israel in the Six-Day War in 1967.
Under a series of agreements known as the Oslo Accords
signed between 1994 and 1999, Israel transferred to the
newly created Palestinian Authority (PA) security and
civilian responsibility for many Palestinian-populated areas
of the West Bank as well as the Gaza Strip. In 2000, a
violent intifada or uprising began, and in 2001 negotiations
to determine the permanent status of the West Bank and
Gaza Strip stalled. Subsequent attempts to re-start direct
negotiations have not resulted in progress toward
determining final status of the area.
Roughly 60% of the West Bank, remains under exclusive
Israeli military control. In early 2006, the Islamic
Resistance Movement (HAMAS) won a majority in the
Palestinian Legislative Council election and since 2007, the
PA has administered areas of the West Bank under its
control while HAMAS maintains de facto control of Gaza.
Fatah, the dominant Palestinian political party in the West
Bank, and HAMAS have made several attempts at
reconciliation, but the factions have been unable to
implement any agreements reached; a_ reconciliation
agreement signed in October 2017 remains
unimplemented. In December 2018, the Palestinian
Constitutional Court dissolved the Palestinian Legislative
Council and called for new Legislative Council elections to
be held.','cbced718b28dcb44f2815f0985d853e456d3a3a46e909624a6d1105e868328c7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baaba23b4da524a2b25f24f037cf86bbc3dd1f6955e2f0ca7378f80e7f8f42c4',2020,'ZW','Zimbabwe','introduction',35,'A: Abbreviations
B: International Organizations and Groups
C: Selected Environmental Agreements
Africa
Antarctic Region
Arctic Region
Asia
Central America and the Caribbean
Europe
Middle East
North America
Oceania
Physical Map of the World
Political Map of the World
South America
Southeast Asia
Standard Time Zone of the World
Background: Multiple waves of Bantu-speaking groups moved
into and through what is now Zambia over the past
thousand years. In the 1880s, the British began securing
mineral and other economic concessions from various local
leaders and the territory that is now Zambia eventually
came under the control of the former British South Africa
Company and was incorporated as the protectorate of
Northern Rhodesia in 1911. Administrative control was
taken over by the UK in 1924. During the 1920s and 1930s,
advances in mining spurred development and immigration.
The name was changed to Zambia upon independence in
1964. In the 1980s and 1990s, declining copper prices,
economic mismanagement, and a prolonged drought hurt
the economy. Elections in 1991 brought an end to one-party
rule and propelled the Movement for Multiparty Democracy
(MMD) to government. The subsequent vote in 1996,
however, saw increasing harassment of opposition parties
and abuse of state media and other resources. The election
in 2001 was marked by administrative problems, with three
parties filing a legal petition challenging the election of
ruling party candidate Levy MWANAWASA. MWANAWASA
was reelected in 2006 in an election that was deemed free
and fair. Upon his death in August 2008, he was succeeded
by his vice president, Rupiah BANDA, who won a special
presidential byelection later that year. The MMD and
BANDA lost to the Patriotic Front (PF) and Michael SATA in
the 2011 general elections. SATA, however, presided over a
period of haphazard economic management and attempted
to silence opposition to PF policies. SATA died in October
2014 and was succeeded by his vice president, Guy SCOTT,
who served as interim president until January 2015, when
Edgar LUNGU won the presidential byelection and
completed SATA’s term. LUNGU then won a full term in
August 2016 presidential elections.','453711fcfd5ae4f9367c6e85a1db560173ae942cca3bb04a39b1d9375407da54','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('198556f89eb1a4fa0b9fcbb014b08f7b402af390535c1fb8886abf86a84b0d9f',2020,'PK','Pakistan','introduction',46,'Background: Ahmad Shah DURRANI unified the Pashtun
tribes and founded Afghanistan in 1747. The country
served as a buffer between the British and Russian Empires
until it won independence from notional British control in
1919. A brief experiment in increased democracy ended in
a 1973 coup and a 1978 communist countercoup. The
Soviet Union invaded in 1979 to support the tottering
Afghan communist regime, touching off a long and
destructive war. The USSR withdrew in 1989 under
relentless pressure by internationally supported anti-
communist mujahidin rebels. A series of subsequent civil
wars saw Kabul finally fall in 1996 to the Taliban, a
hardline Pakistani-sponsored movement that emerged in
1994 to end the country’s civil war and anarchy. Following
the 11 September 2001 terrorist attacks, a US, Allied, and
anti-Taliban Northern Alliance military action toppled the
Taliban for sheltering Usama BIN LADIN.
A UN-sponsored Bonn Conference in 2001 established a
process for political reconstruction that included the
adoption of a new constitution, a presidential election in
2004, and National Assembly elections in 2005. In
December 2004, Hamid KARZAI became the first
democratically elected president of Afghanistan, and the
National Assembly was inaugurated the _ following
December. KARZAI was reelected in August 2009 for a
second term. The 2014 presidential election was the
country’s first to include a runoff, which featured the top
two vote-getters from the first round, Abdullah ABDULLAH
and Ashraf GHANI. Throughout the summer of 2014, their
Campaigns disputed the results and traded accusations of
fraud, leading to a US-led diplomatic intervention that
included a full vote audit as well as political negotiations
between the two camps. In September 2014, GHANI and
ABDULLAH agreed to form the Government of National
Unity, with GHANI inaugurated as_ president and
ABDULLAH elevated to the newly-created position of chief
executive officer. The day after the inauguration, the
GHANI administration signed the US-Afghan Bilateral
Security Agreement and NATO Status of Forces Agreement,
which provide the legal basis for the _ post-2014
international military presence in Afghanistan. After two
postponements, the next presidential election was held in
September 2019.
The Taliban remains a serious challenge for the Afghan
Government in almost every province. The Taliban still
considers itself the rightful government of Afghanistan, and
it remains a capable and confident insurgent force fighting
for the withdrawal of foreign military forces from
Afghanistan, establishment of sharia law, and rewriting of
the Afghan constitution. In 2019, negotiations between the
US and the Taliban in Doha entered their highest level yet,
building on momentum that began in late 2018. Underlying
the negotiations is the unsettled state of Afghan politics,
and prospects for a sustainable political settlement remain
unclear.
Background: The Indus Valley civilization, one of the oldest in
the world and dating back at least 5,000 years, spread over
much of what is presently Pakistan. During the second
millennium B.C., remnants of this culture fused with the
migrating Indo- Aryan peoples. The area underwent
successive invasions in subsequent centuries from the
Persians, Greeks, Scythians, Arabs (who brought Islam),
Afghans, and Turks. The Mughal Empire flourished in the
16th and 17th centuries; the British came to dominate the
region in the 18th century. The separation in 1947 of
British India into the Muslim state of Pakistan (with West
and East sections) and largely Hindu India was never
satisfactorily resolved, and India and Pakistan fought two
wars and a limited conflict—in 1947-48, 1965, and 1999
respectively—over the disputed Kashmir territory. A third
war between these countries in 1971—in which India
assisted an indigenous movement reacting to the
marginalization of Bengalis in Pakistani politics—resulted
in East Pakistan becoming the separate nation of
Bangladesh.
In response to Indian nuclear weapons testing, Pakistan
conducted its own tests in mid-1998. India-Pakistan
relations improved in the mid-2000s but have been rocky
since the November 2008 Mumbai attacks and have been
further strained by attacks in India by militants believed to
be based in Pakistan. Imran KHAN took office as prime
minister in 2018 after the Pakistan Tehreek-e-Insaaf (PTT)
party won a plurality of seats in the July 2018 general
elections. Pakistan has been engaged in a decades-long
armed conflict with militant groups that target government
institutions and civilians, including the Tehreek-e-Taliban
Pakistan (TTP) and other militant networks.
Background: After three decades as part of the UN Trust
Territory of the Pacific under US administration, this
westernmost cluster of the Caroline Islands opted for
independence in 1978 rather than join the Federated States
of Micronesia. A Compact of Free Association with the US
was approved in 1986 but not ratified until 1993. It entered
into force the following year when the islands gained
independence.','a97eebe2c9f7b4c0b4c0542318d417f199213f5fec231cd042df852c9a177292','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d05b576aade9ddb07e1517a6ce92a0727c70799f6129feb92b5cd7a044dc5ed',2020,'CY','Cyprus','introduction',54,'Background: By terms of the 1960 Treaty of Establishment
that created the independent Republic of Cyprus, the UK
retained full sovereignty and jurisdiction over two areas of
almost 254 square kilometers—Akrotiri and Dhekelia. The
southernmost and smallest of these is the Akrotiri
Sovereign Base Area, which is also referred to as the
Western Sovereign Base Area.
Background: A former British colony, Cyprus became
independent in 1960 following years of resistance to British
rule. Tensions between the Greek Cypriot majority and
Turkish Cypriot minority communities came to a head in
December 1963, when violence broke out in the capital of
Nicosia. Despite the deployment of UN peacekeepers in
1964, sporadic intercommunal violence continued, forcing
most Turkish Cypriots into enclaves throughout the island.
In 1974, a Greek Government-sponsored attempt to
overthrow the elected president of Cyprus was met by
military intervention from Turkey, which soon controlled
more than a third of the island. In 1983, the Turkish
Cypriot administered area declared itself the “Turkish
Republic of Northern Cyprus” (“TRNC”), but it is
recognized only by Turkey. An UN-mediated agreement, the
Annan Plan, failed to win approval by both communities in
2004. In February 2014, after a hiatus of nearly two years,
the leaders of the two communities resumed formal
discussions under UN auspices aimed at reuniting the
divided island. The most recent round of negotiations to
reunify the island were suspended in July 2017 after failure
to achieve a breakthrough. The entire island entered the
EU on 1 May 2004, although the EU acquis—the body of
common rights and obligations -applies only to the areas
under the internationally recognized government, and is
suspended in the “TRNC.” However, individual Turkish
Cypriots able to document their eligibility for Republic of
Cyprus citizenship legally enjoy the same rights accorded
to other citizens of EU states.
Background: By terms of the 1960 Treaty of Establishment
that created the independent Republic of Cyprus, the UK
retained full sovereignty and jurisdiction over two areas of
almost 254 square kilometers—Akrotiri and Dhekelia. The
larger of these is the Dhekelia Sovereign Base Area, which
is also referred to as the Eastern Sovereign Base Area.','b9089d3976590ec00ee7095a6bed377a2c9acb89425af4d081542d4264af2a27','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e3df9d70c970a23fc83aba9a25fc648234b9194c699d3199eb9c3ecb5ff7d95',2020,'GR','Greece','introduction',63,'Background: Albania declared its independence from the
Ottoman Empire in 1912, but was conquered by Italy in
1939 and occupied by Germany in 1943. Communist
partisans took over the country in 1944. Albania allied itself
first with the USSR (until 1960), and then with China (to
1978). In the early 1990s, Albania ended 46 years of
isolated communist rule and established a multiparty
democracy. The transition has proven challenging as
successive governments have tried to deal with high
unemployment, widespread corruption, dilapidated
infrastructure, powerful organized crime networks, and
combative political opponents.
Albania has made _ progress in _ its democratic
development since it first held multiparty elections in 1991,
but deficiencies remain. Most of Albania’s post-communist
elections were marred by claims of electoral fraud;
however, international observers judged elections to be
largely free and fair since the restoration of political
stability following the collapse of pyramid schemes in 1997.
Albania joined NATO in April 2009 and in June 2014
became an EU candidate. Albania in April 2017 received a
European Commission recommendation to open EU
accession negotiations following the passage of historic EU-
mandated justice reforms in 2016. Although Albania’s
economy continues to grow, it has slowed, and the country
is still one of the poorest in Europe. A large informal
economy and a weak energy and_ transportation
infrastructure remain obstacles.
Background: After more than a century of rule by France,
Algerians fought through much of the 1950s to achieve
independence in 1962. Algeria’s primary political party, the
National Liberation Front (FLN), was established in 1954
as part of the struggle for independence and has since
largely dominated politics. The Government of Algeria in
1988 instituted a multi-party system in response to public
unrest, but the surprising first round success of the Islamic
Salvation Front (FIS) in the December 1991 legislative
elections led the Algerian army to intervene and postpone
the second round of elections to prevent what the secular
elite feared would be an extremist-led government from
assuming power. The army began a crackdown on the FIS
that spurred FIS supporters to begin attacking government
targets. Fighting escalated into an insurgency, which saw
intense violence from 1992-98, resulting in over 100,000
deaths—many attributed to indiscriminate massacres of
villagers by extremists. The government gained the upper
hand by the late-1990s, and FIS’s armed wing, the Islamic
Salvation Army, disbanded in January 2000.
Abdelaziz BOUTEFLIKA, with the backing of the military,
won the presidency in 1999 in an election that was
boycotted by several candidates protesting alleged fraud,
and won subsequent elections in 2004, 2009, and 2014.
The government in 2011 introduced some political reforms
in response to the Arab Spring, including lifting the 19-
year-old state of emergency restrictions and increasing
women’s quotas for elected assemblies, while also
increasing subsidies to the populace. Since 2014, Algeria’s
reliance on hydrocarbon revenues to fund the government
and finance the large subsidies for the population has fallen
under stress because of declining oil prices. Protests broke
out across the country in late February 2019 against
President BOUTEFLIKA’s decision to seek a fifth term.
BOUTEFLIKA resigned on 2 April 2019, and the speaker of
the upper house of parliament, Abdelkader BENSALAH,
became interim head of state on 9 April. BENSALAH
remained in office beyond the 90-day constitutional limit
until Algerians elected former Prime Minister Abdelmadjid
TEBBOUNE as the country’s new president in December
2019.
Background: The Bulgars, a Central Asian Turkic tribe,
merged with the local Slavic inhabitants in the late 7th
century to form the first Bulgarian state. In succeeding
centuries, Bulgaria struggled with the Byzantine Empire to
assert its place in the Balkans, but by the end of the 14th
century the country was overrun by the Ottoman Turks.
Northern Bulgaria attained autonomy in 1878 and all of
Bulgaria became independent from the Ottoman Empire in
1908. Having fought on the losing side in both World Wars,
Bulgaria fell within the Soviet sphere of influence and
became a People’s Republic in 1946. Communist
domination ended in 1990, when Bulgaria held its first
multiparty election since World War II and began the
contentious process of moving toward political democracy
and a market economy while combating inflation,
unemployment, corruption, and crime. The country joined
NATO in 2004 and the EU in 2007.
Background: Burkina Faso (formerly Upper Volta) achieved
independence from France in 1960. Repeated military
coups during the 1970s and 1980s were followed by
multiparty elections in the early 1990s. Former President
Blaise COMPAORE (1987-2014) resigned in late October
2014 following popular protests against his efforts to
amend the constitution’s two-term presidential limit. An
interim administration organized presidential and
legislative elections—held in November 2015—where Roch
Marc Christian KABORE was elected president. The
country experienced terrorist attacks in its capital in 2016,
2017, and 2018 and continues to mobilize resources to
counter terrorist threats mainly in its northern and eastern
regions. It experienced over 100 attacks by violent
extremists in the first quarter of 2019. Growing insecurity
resulted in nearly 500,000 internally displaced persons and
more than 2,000 closed schools. The Government of
Burkina Faso has made numerous arrests of terrorist
suspects, augmented the size of its special terrorism
detachment Groupement des. Forces’ Anti-Terroristes
(GFAT) in the country’s north, and joined the newly-created
GS Sahel Joint Force to fight terrorism and criminal
trafficking groups with regional neighbors Chad, Mali,
Mauritania, and Niger. In 2017, the Sahara Branch of al-
Qa’ida in the Islamic Maghreb, al-Murabitoun, Ansar al-
Dine, and the Macina Liberation Front came together to
form Jama’at Nusrat al-Islam wal-Muslimin (JNIM). JNIM
and other groups like Ansarul Islam and ISIS in the Greater
Sahara operate in Burkina Faso. Burkina Faso’s high
population growth, recurring drought, pervasive and
perennial food insecurity, and limited natural resources
result in poor economic prospects for the majority of its
citizens. (2019) GEOGRAPHY
Location: Western Africa, north of Ghana
Geographic coordinates: 13 00 N, 2 00 W
Map references: Africa
Area: total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
country comparison to the world: 76
Area—comparative: Slightly larger than Colorado
Land boundaries: total: 3,611 km
border countries (6): Benin 386 km, Cote d’Ivoire 545 km,
Ghana 602 km, Mali 1325 km, Niger 622 km, Togo 131 km
Coastline: 0 km (landlocked)
Maritime claims: None (landlocked)
Climate: three climate zones including a hot tropical savanna
with a short rainy season in the southern half, a tropical hot
semi-arid steppe climate typical of the Sahel region in the
northern half, and small area of hot desert in the very north
of the country bordering the Sahara Desert Terrain: Mostly
flat to dissected, undulating plains; hills in the west and
southeast. Occupies an extensive plateau with savanna that
is grassy in the north and gradually gives way to sparse
forests in the south. (2019) Elevation: mean elevation: 297 m
lowest point: Mouhoun (Black Volta) River 200 m
highest point: Tena Kourou 749 m
Natural resources: gold, manganese, zinc, limestone, marble,
phosphates, pumice, salt
Land use: agricultural land: 44.2% (2016 est.)
arable land: 22% (2016 est.) / permanent crops: 37% (2016
est.) / permanent pasture: 21.93% (2016 est.) forest: 19.3%
(2016 est.)
other: 36.5% (2016 est.)
Irrigated land: 550 sq km (2016)
Population distribution: Most of the population is located in the
center and south. Nearly 31 percent of the population lives
in cities. The capital and largest city is Ouagadougou
(Ouaga), with a population of 1.8 million.
(2019)
Natural hazards: recurring droughts
Environment—current issues: recent droughts and
desertification severely affecting agricultural activities,
population distribution, and the economy; overgrazing; soil
degradation; deforestation (2019) Environment—international
agreements: Party to: Biodiversity, Climate Change, Climate
Change-Paris Agreement, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Ozone Layer Protection, Wetlands (2019)
signed, but not ratified: none of the selected agreements
(2019)
Geography—note: landlocked savanna cut by the _ three
principal rivers of the Black, Red, and White Voltas
Background: North Macedonia gained its independence
peacefully from Yugoslavia in 1991 under the name of
“Macedonia.” Greek objection to the new country’s name,
insisting it implied territorial pretensions to the northern
Greek province of Macedonia, and democratic backsliding
for several years stalled the country’s movement toward
Euro-Atlantic integration. Immediately after Macedonia
declared independence, Greece sought’ to _ block
Macedonian efforts to gain UN membership if the name
“Macedonia” was used. The country was_ eventually
admitted to the UN in 1993 as “The former Yugoslav
Republic of Macedonia,” and at the same time it agreed to
UN-sponsored negotiations on the name dispute. In 1995,
Greece lifted a 20-month trade embargo and the two
countries agreed to normalize relations, but the issue of the
name remained unresolved and negotiations for a solution
continued. Over time, the US and over 130 other nations
recognized Macedonia by its constitutional name, Republic
of Macedonia. Ethnic Albanian grievances over perceived
political and economic inequities escalated into a conflict in
2001 that eventually led to the internationally brokered
Ohrid Framework Agreement, which ended the fighting and
established guidelines for constitutional amendments and
the creation of new laws that enhanced the rights of
minorities. In January 2018, the government adopted a new
law on languages, which elevated the Albanian language to
an official language at the national level, with the
Macedonian language remaining the sole official language
in international relations. Relations between _ ethnic
Macedonians and ethnic Albanians remain complicated,
however.
North Macedonia’s pro-Western government has used its
time in office since 2017 to sign a historic deal with Greece
in June 2018 to end the name dispute and revive Skopje’s
NATO and EU membership prospects. This followed a
nearly three-year political crisis that engulfed the country
but ended in June 2017 following a_ six-month-long
government formation period after a closely contested
election in December 2016. The crisis began after the 2014
legislative and presidential election, and escalated in 2015
when the opposition party began releasing wiretapped
material that revealed alleged widespread government
corruption and abuse. Although an EU candidate since
2005, North Macedonia has yet to open EU accession
negotiations. The country still faces challenges, including
fully implementing reforms to overcome years. of
democratic backsliding and stimulating economic growth
and development. In June 2018, Macedonia and Greece
signed the Prespa Accord whereby the Republic of
Macedonia agreed to change its name to the Republic of
North Macedonia. Following ratification by both countries,
the agreement went in to force on 12 February 2019. North
Macedonia signed an accession protocol to become a NATO
member state in February 2019.','51fcd3d14af328ab5e043e989539758bef9772d391d39761d144e15a15c309ad','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8dbd520b20bc95fd7b203415f8e2783e343e07804c752f720fc0fc76a41be6e',2020,'AS','American Samoa','introduction',79,'Background: Settled as early as 1000 B. C., Samoa was not
reached by European explorers until the 18th century.
International rivalries in the latter half of the 19th century
were settled by an 1899 treaty in which Germany and the
US divided the Samoan archipelago. The US formally
occupied its portion—a smaller group of eastern islands
with the excellent harbor of Pago Pago—the following year.
Background: The landlocked Principality of Andorra is one of
the smallest states in Europe, nestled high in the Pyrenees
between the French and Spanish borders. For 715 years,
from 1278 to 1993, Andorrans lived under a unique
coprincipality, ruled by French and Spanish leaders (from
1607 onward, the French chief of state and the Bishop of
Urgell). In 1993, this feudal system was modified with the
introduction of a modern constitution; the co-princes
remained as titular heads of state, but the government
transformed into a parliamentary democracy.
Andorra has become a popular tourist destination visited
by approximately 8 million people each year drawn by the
winter sports, summer climate, and duty-free shopping.
Andorra has also become aé_ewealthy international
commercial center because of its mature banking sector
and low taxes. As part of its effort to modernize its
economy, Andorra has opened to foreign investment, and
engaged in other reforms, such as advancing tax initiatives
aimed at supporting a broader infrastructure. Although not
a member of the EU, Andorra enjoys a special relationship
with the bloc that is governed by various customs and
cooperation agreements and uses the euro as its national
currency.','a43502909b9df35b4c96f11c0fa7128c126dc5581a21634c624083bdfc7455d7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b384c4bd21cc0843020827ce311c9ab4037286c0397a04be1d3b5ca9d82b3e5',2020,'NA','Namibia','introduction',93,'Background: Angola scores low on human development
indexes despite using its large oil reserves to rebuild since
the end of a 27- year civil war in 2002. Fighting between
the Popular Movement for the Liberation of Angola (MPLA),
led by Jose Eduardo DOS SANTOS, and the National Union
for the Total Independence of Angola (UNITA), led by Jonas
SAVIMBI, followed independence from Portugal in 1975.
Peace seemed imminent in 1992 when Angola held national
elections, but fighting picked up again in 1993. Up to 1.5
million lives may have been lost—and 4 million people
displaced—during the more than a quarter century of
fighting. SAVIMBI’s death in 2002 ended UNITA’s
insurgency and cemented the MPLA’s hold on power. DOS
SANTOS stepped down from the presidency in 2017,
having led the country since 1979. He pushed through a
new constitution in 2010. Joao LOURENCO was elected
president in August 2017 and became president of the
MPLA in September 2018.
Background: Colonized by English settlers from Saint Kitts in
1650, Anguilla was administered by Great Britain until the
early 19th century, when the island—against the wishes of
the inhabitants—was incorporated into a single British
dependency along with Saint Kitts and Nevis. Several
attempts at separation failed. In 1971, two years after a
revolt, Anguilla was finally allowed to secede; this
arrangement was formally recognized in 1980, with
Anguilla becoming a separate British dependency. On 7
September 2017, the island suffered extensive damage
from Hurricane Irma, particularly to communications and
residential and business infrastructure.
Background: Speculation over the existence of a “southern
land” was not confirmed until the early 1820s when British
and American commercial operators and British and
Russian national expeditions began exploring the Antarctic
Peninsula region and other areas south of the Antarctic
Circle. Not until 1840 was it established that Antarctica
was indeed a continent and not merely a group of islands or
an area of ocean. Several exploration “firsts” were
achieved in the early 20th century, but generally the area
saw little human activity. Following World War II, however,
the continent experienced an upsurge in_ scientific
research. A number of countries have set up a range of
year-round and seasonal stations, camps, and refuges to
support scientific research in Antarctica. Seven have made
territorial claims, but most countries do not recognize
these claims. In order to form a legal framework for the
activities of nations on the continent, an Antarctic Treaty
was negotiated that neither denies nor gives recognition to
existing territorial claims; signed in 1959, it entered into
force in 1961. Also relevant to Antarctic governance are
the Environmental Protocol to the Antarctic Treaty and the
Convention for the Conservation of Antarctic Marine Living
Resources.
Background: The Siboney were the first people to inhabit the
islands of Antigua and Barbuda in 2400 B.C., but Arawak
Indians populated the islands when COLUMBUS landed on
his second voyage in 1493. Early Spanish and French
settlements were succeeded by an English colony in 1667.
Slavery, established to run the sugar plantations on
Antigua, was abolished in 1834. The islands became an
independent state within the British Commonwealth of
Nations in 1981. On 6 September 2017, Hurricane Irma
passed over the island of Barbuda devastating the island
and forcing the evacuation of the population to Antigua.
Almost all the structures on Barbuda were destroyed and
the vegetation stripped, but Antigua was spared the worst.
Background: The Arctic Ocean is the smallest of the world’s
five oceans (after the Pacific Ocean, Atlantic Ocean, Indian
Ocean, and the Southern Ocean). The Northwest Passage
(US and Canada) and Northern Sea Route (Norway and
Russia) are two important seasonal waterways. In recent
years the polar ice pack has receded in the summer
allowing for increased navigation and raising the possibility
of future sovereignty and shipping disputes among the six
countries bordering the Arctic Ocean (Canada, Denmark
(Greenland), Iceland, Norway, Russia, US).
ej] ole) ¥V ah
Location: body of water between Europe, Asia, and North
America, mostly north of the Arctic Circle Geographic
coordinates: 90 00 N, 0 OO E
Map references: Arctic Region
Area: total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort Sea,
Chukchi Sea, East Siberian Sea, Greenland Sea, Hudson
Bay, Hudson Strait, Kara Sea, Laptev Sea, Northwest
Passage, and other tributary water bodies Area—comparative:
slightly less than 1.5 times the size of the US
Coastline: 45,389 km
Climate: polar climate characterized by persistent cold and
relatively narrow annual temperature range; winters
Characterized by continuous darkness, cold and stable
weather conditions, and clear skies; summers
characterized by continuous daylight, damp and foggy
weather, and weak cyclones with rain or snow Terrain:
central surface covered by a perennial drifting polar
icepack that, on average, is about 3 m thick, although
pressure ridges may be three times that thickness; the
icepack is surrounded by open seas during the summer, but
more than doubles in size during the winter and extends to
the encircling landmasses; the ocean floor is about 50%
continental shelf (highest percentage of any ocean) with
the remainder a central basin interrupted by three
submarine ridges (Alpha Cordillera, Nansen Cordillera, and
Lomonosov Ridge) major surface currents: two major, slow-
moving, wind-driven currents (drift streams) dominate: a
clockwise drift pattern in the Beaufort Gyre in the western
part of the Arctic Ocean and a nearly straight line
Transpolar Drift Stream that moves eastward across the
ocean from the New Siberian Islands (Russia) to the Fram
Strait (between Greenland and Svalbard); sea ice that lies
close to the center of the gyre can complete a 360 degree
circle in about 2 years, while ice on the gyre periphery will
complete the same circle in about 7-8 years; sea ice in the
Transpolar Drift crosses the ocean in about 3 years
Elevation: mean depth: -1,205 m
lowest point: Molloy Deep—5,607 m
highest point: sea level
Natural resources: sand and gravel aggregates, placer
deposits, polymetallic nodules, oil and gas fields, fish,
marine mammals (seals and whales) Natural hazards: ice
islands occasionally break away from northern Ellesmere
Island; icebergs calved from glaciers in western Greenland
and extreme northeastern Canada; permafrost in islands;
virtually ice locked from October to June; ships subject to
superstructure icing from October to May Environment—
current issues: Climate change; changes in biodiversity; use of
toxic chemicals; endangered marine species include
walruses and whales; fragile ecosystem slow to change and
slow to recover from disruptions or damage; thinning polar
icepack Geography—note: major cChokepoint is the southern
Chukchi Sea (northern access to the Pacific Ocean via the
Bering Strait); strategic location between North America
and Russia; shortest marine link between the extremes of
eastern and western Russia; floating research stations
operated by the US and Russia; maximum snow cover in
March or April about 20 to 50 centimeters over the frozen
ocean; snow cover lasts about 10 months PEOPLE AND
SOCIETY
Education expenditures:','2705bdf106cec9470b4cce08a8107062ae6e909dc3ea054371e0451e2d36fae9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf43ec61fbef5aab1e9ab21550cbd275c2d88f90b01a72c7eb8c15a288c45463',2020,'UY','Uruguay','introduction',107,'Background: In 1816, the United Provinces of the Rio Plata
declared their independence from Spain. After Bolivia,
Paraguay, and Uruguay went their separate ways, the area
that remained became Argentina. The country’s population
and culture were heavily shaped by immigrants from
throughout Europe, with Italy and Spain providing the
largest percentage of newcomers from 1860 to 1930. Up
until about the mid-20th century, much of Argentina’s
history was dominated by periods of internal political
unrest and conflict between civilian and military factions.
After World War II, an era of Peronist populism and
direct and indirect military interference in subsequent
governments was followed by a military junta that took
power in 1976. Democracy returned in 1983 after a failed
bid to seize the Falkland Islands (Islas Malvinas) by force,
and has persisted despite numerous challenges, the most
formidable of which was a severe economic crisis in 2001-
02 that led to violent public protests and the successive
resignations of several presidents. The years 2003-15 saw
Peronist rule by Nestor and Cristina FERNANDEZ de
KIRCHNER, whose policies isolated Argentina and caused
economic stagnation. With the election of Mauricio MACRI
in November 2015, Argentina began a period of reform and
international reintegration.','5fb4a740a44e4ba59bde56bca9ed58ffbb95167111ece4292cab17e76b2295e5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('055213b4851f59eed3076ce73f375e9caae5d70345583a627f59ed6b2d0abe63',2020,'AM','Armenia','introduction',116,'Background: Armenia prides itself on being the first nation to
formally adopt Christianity (early 4th century). Despite
periods of autonomy, over the centuries Armenia came
under the sway of various empires including the Roman,
Byzantine, Arab, Persian, and Ottoman. During World War I
in the western portion of Armenia, the Ottoman Empire
instituted a policy of forced resettlement coupled with
other harsh practices that resulted in at least 1 million
Armenian deaths. The eastern area of Armenia was ceded
by the Ottomans to Russia in 1828; this portion declared its
independence in 1918, but was conquered by the Soviet
Red Army in 1920.
Armenia remains involved in the protracted Nagorno-
Karabakh conflict with Azerbaijan. Nagorno-Karabakh was
a primarily ethnic Armenian region that Moscow
recognized in 1923 as an autonomous oblast within Soviet
Azerbaijan. In the late Soviet period, a_ separatist
movement developed which sought to end Azerbaijani
control over the region. Fighting over Nagorno-Karabakh
began in 1988 and escalated after Armenia and Azerbaijan
attained independence from the Soviet Union in 1991. By
the time a ceasefire took effect in May 1994, separatists,
with Armenian support, controlled Nagorno-Karabakh and
seven surrounding Azerbaijani territories. The 1994
ceasefire continues to hold, although violence continues
along the line of contact separating the opposing forces, as
well as the Armenia-Azerbaijan international border. The
final status of Nagorno-Karabakh remains the subject of
international mediation by the Organization for Security
and Cooperation in Europe (OSCE) Minsk Group, which
works to help the sides settle the conflict peacefully. The
OSCE Minsk Group is co-chaired by the US, France, and
Russia.
Turkey closed the common border with Armenia in 1993
in support of Azerbaijan in its conflict with Armenia over
control of Nagorno-Karabakh and surrounding areas,
further hampering Armenian economic growth. In 2009,
Armenia and Turkey signed Protocols normalizing relations
between the two countries, but neither country ratified the
Protocols, and Armenia officially withdrew from the
Protocols in March 2018. In 2015, Armenia joined the
Eurasian Economic Union alongside Russia, Belarus,
Kazakhstan, and Kyrgyzstan. In November 2017, Armenia
signed a Comprehensive and Enhanced Partnership
Agreement (CEPA) with the EU. In spring 2018, Serzh
SARGSIAN of the Republican Party of Armenia (RPA)
stepped down and Civil Contract party leader Nikol
PASHINYAN became prime minister.
Background: Discovered and claimed for Spain in 1499,
Aruba was acquired by the Dutch in 1636. The island’s
economy has been dominated by three main industries. A
19th century gold rush was followed by prosperity brought
on by the opening in 1924 of an oil refinery. The last
decades of the 20th century saw a boom in the tourism
industry. Aruba seceded from the Netherlands Antilles in
1986 and became a separate, semi-autonomous member of
the Kingdom of the Netherlands. Movement toward full
independence was halted at Aruba’s request in 1990.','8560ed79413987179c3719d36f940d006dbdc4f19434fcd837921d3104f3479d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd851deb9d69f92b7733e64387cc606dbdc7b353a3a82dd51cf7be2ffb3e1035',2020,'AU','Australia','introduction',126,'Background: These uninhabited islands came _ under
Australian authority in 1931; formal administration began
two years later. Ashmore Reef supports a rich and diverse
avian and marine habitat; in 1983, it became a National
Nature Reserve. Cartier Island, a former bombing range,
became a marine reserve in 2000.
Background: The Atlantic Ocean is the second largest of the
world’s five oceans (after the Pacific Ocean, but larger than
the Indian Ocean, Southern Ocean, and Arctic Ocean). The
Kiel Canal (Germany), Oresund (Denmark-Sweden),
Bosporus (Turkey), Strait of Gibraltar (Morocco-Spain), and
the Saint Lawrence Seaway (Canada-US) are important
strategic access waterways. The decision by _ the
International Hydrographic Organization in the spring of
2000 to delimit a fifth world ocean, the Southern Ocean,
removed the portion of the Atlantic Ocean south of 60
degrees south latitude.
Background: Prehistoric settlers arrived on the continent
from Southeast Asia at least 40,000 years before the first
Europeans began exploration in the 17th century. No
formal territorial claims were made until 1770, when Capt.
James COOK took possession of the east coast in the name
of Great Britain (all of Australia was claimed as British
territory in 1829 with the creation of the colony of Western
Australia). Six colonies were created in the late 18th and
19th centuries; they federated and became _ the
Commonwealth of Australia in 1901. The new country took
advantage of its natural resources to rapidly develop
agricultural and manufacturing industries and to make a
major contribution to the Allied effort in World Wars I and
I.
In recent decades, Australia has become _ an
internationally competitive, advanced market economy due
in large part to economic reforms adopted in the 1980s and
its location in one of the fastest growing regions of the
world economy. Long-term concerns include an aging
population, pressure on infrastructure, and environmental
issues such as floods, droughts, and bushfires. Australia is
the driest inhabited continent on earth, making it
particularly vulnerable to the challenges of climate change.
Australia is home to 10% of the world’s biodiversity, and a
great number of its flora and fauna exist nowhere else in
the world.
Background: Scattered over more than three-quarters of a
million square kilometers of ocean, the Coral Sea Islands
were declared a territory of Australia in 1969. They are
uninhabited except for a small meteorological staff on the
Willis Islets. Automated weather stations, beacons, and a
lighthouse occupy many other islands and reefs. The Coral
Sea Islands Act 1969 was amended in 1997 to extend the
boundaries of the Coral Sea Islands Territory around
Elizabeth and Middleton Reefs.
Background: The Polynesian Maori reached New Zealand
sometime between A.D. 1250 and 1300. In 1840, their
chieftains entered into a compact with Great Britain, the
Treaty of Waitangi, in which they ceded sovereignty to
Queen Victoria while retaining territorial rights. That same
year, the British began the first organized colonial
settlement. A series of land wars between 1843 and 1872
ended with the defeat of the native peoples. The British
colony of New Zealand became an independent dominion in
1907 and supported the UK militarily in both world wars.
New Zealand’s full participation in a number of defense
alliances lapsed by the 1980s. In recent years, the
government has sought to address longstanding Maori
grievances.
Background: The eastern half of the island of New Guinea—
second largest in the world—was divided between Germany
(north) and the UK (south) in 1885. The latter area was
transferred to Australia in 1902, which occupied the
northern portion during World War I and continued to
administer the combined areas until independence in 1975.
A nine-year secessionist revolt on the island of Bougainville
ended in 1997 after claiming some 20,000 lives. Since
2001, Bougainville has experienced autonomy; a
referendum asking the population if they would like
independence or greater self rule is tentatively scheduled
for October 2019.
Le} ole) y Va
Location: Oceania, group of islands including the eastern
half of the island of New Guinea between the Coral Sea and
the South Pacific Ocean, east of Indonesia Geographic
coordinates: 6 00 S, 147 OO E
Map references: Oceania
Area: total: 462,840 sq km
land: 452,860 sq km
water: 9,980 sq km
country comparison to the world: 56
Area—comparative: Slightly larger than California
Land boundaries: total: 824 km
border countries (1): Indonesia 824 km
Coastline: 5,152 km
Maritime claims: territorial sea: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 200 nm
measured from claimed archipelagic baselines
Climate: tropical; northwest monsoon (December to March),
southeast monsoon (May to October); slight seasonal
temperature variation Terrain: mostly mountains with coastal
lowlands and rolling foothills
Elevation: mean elevation: 667 m
lowest point: Pacific Ocean 0 m
highest point: Mount Wilhelm 4,509 m
Natural resources: gold, copper, silver, natural gas, timber, oil,
fisheries
Land use: agricultural land: 2.6% (2011 est.)
arable land: 0.7% (2011 est.) / permanent crops: 1.5%
(2011 est.) / permanent pasture: 0.4% (2011 est.) forest:
63.1% (2011 est.)
other: 34.3% (2011 est.)
Irrigated land: 0 sq km (2012)
Population distribution: population concentrated in the
highlands and eastern coastal areas on the island of New
Guinea; predominantly a rural distribution with only about
one-fifth of the population residing in urban areas Natural
hazards: active volcanism; the country is subject to frequent
and sometimes severe earthquakes; mud slides; tsunamis
volcanism: severe volcanic activity; Ulawun (2,334 m), one
of Papua New Guinea’s potentially most dangerous
volcanoes, has been deemed a Decade Volcano by the
International Association of Volcanology and Chemistry of
the Earth’s Interior, worthy of study due to its explosive
history and close proximity to human populations; Rabaul
(688 m) destroyed the city of Rabaul in 1937 and 1994;
Lamington erupted in 1951 killing 3,000 people; Manam’s
2004 eruption forced the island’s abandonment; other
historically active volcanoes include Bam, Bagana,
Garbuna, Karkar, Langila, Lolobau, Long Island, Pago, St.
Andrew Strait, Victory, and Waiowa; see note 2 under
“Geography—note”
Environment—current issues: rain forest loss as a result of
growing commercial demand for tropical timber;
unsustainable logging practices result in soil erosion, water
quality degredation, and loss of habitat and biodiversity;
large-scale mining projects cause adverse impacts on
forests and water quality (discharge of heavy metals,
cyanide, and acids into rivers); severe drought;
inappropriate farming practices accelerate land degradion
(soil erosion, siltation, loss of soil fertility); destructive
fishing practices and coastal pollution due to run-off from
land-based activities and oil spills Environment—international
agreements: Party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands signed, but not ratified: none
of the selected agreements
Geography—note: note 1: shares island of New Guinea with
Indonesia; generally east-west trending highlands break up
New Guinea into diverse ecoregions; one of world’s largest
swamps along southwest coast note 2: Papua New Guinea
is one of the countries along the Ring of Fire, a belt of
active volcanoes and earthquake epicenters bordering the
Pacific Ocean; up to 90% of the world’s earthquakes and
some 75% of the world’s volcanoes occur within the Ring of
Fire PEOPLE AND SOCIETY
Population: 7,259,456 (July 2020 est.)
country comparison to the world: 102
Nationality: N0un: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic groups: Melanesian, Papuan, Negrito, Micronesian,
Polynesian
Languages: Tok Pisin (official), English (official), Hiri Motu
(official), some 839 indigenous languages spoken (about
12% of the world’s total); many languages have fewer than
1,000 speakers note: Tok Pisin, a creole language, is widely
used and understood; English is spoken by 1%-2%; Hiri
Motu is spoken by less than 2%
Religions: Protestant 64.3% (Evangelical Lutheran 18.4%,
Seventh Day Adventist 12.9%, Pentecostal 10.4%, United
Church 10.3%, Evangelical Alliance 5.9%, Anglican 3.2%,
Baptist 2.8%, Salvation Army .4%), Roman Catholic 26%,
other Christian 5.3%, non-Christian 1.4%, unspecified 3.1%
(2011 est.) note: data represent only the citizen population;
roughly .3% of the population are non-citizens, consisting
of Christian 52% (predominantly Roman Catholic), other
10.7%, none 37.3%
Age structure: 0-14 years: 31.98% (male 1,182,539/female
1,139,358)
15-24 years: 19.87% (male 731,453/female 711,164)
25-54 years: 37.68% (male 1,397,903/female 1,337,143)
55-64 years: 5.83% (male 218,529/female 204,717)
65 years and over: 4.64% (male 164,734/female 171,916)
(2020 est.)
Dependency ratios: total dependency ratio: 67.4 (2015 est.)
youth dependency ratio: 61.3 (2015 est.)
elderly dependency ratio: 6.1 (2015 est.)
potential support ratio: 16.4 (2015 est.)
Median age: total: 24 years
male: 24 years
female: 24 years (2020 est.)
country comparison to the world: 171
Population growth rate: 1.6% (2020 est.)
country comparison to the world: 63
Birth rate: 22.5 births/1,000 population (2020 est.)
country comparison to the world: 63
Death rate: 6.7 deaths/1,000 population (2020 est.)
country comparison to the world: 137
Net migration rate: 0 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 93
Population distribution: population concentrated in the
highlands and eastern coastal areas on the island of New
Guinea; predominantly a rural distribution with only about
one-fifth of the population residing in urban areas
Urbanization: urban population: 13.3% of total population
(2020) rate of urbanization: 2.51% annual rate of change
(2015-20 est.)
Major urban areas—population: 383,000 PORT MORESBY
(capital) (2020)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.04 male(s)/female (2020 est.)
15-24 years: 1.03 male(s)/female (2020 est.)
25-54 years: 1.05 male(s)/female (2020 est.)
55-64 years: 1.07 male(s)/female (2020 est.)
65 years and over: 0.96 male(s)/female (2020 est.)
total population: 103.7 male(s)/female (2020 est.)
Maternal mortality rate: 145 deaths/100,000 live births (2017
est.)
country comparison to the world: 58
Infant mortality rate: total: 33.2 deaths/1,000 live births
male: 36.4 deaths/1,000 live births
female: 29.8 deaths/1,000 live births (2020 est.)
country comparison to the world: 46
Life expectancy at birth: total population: 67.8 years
male: 65.6 years
female: 70 years (2020 est.)
country comparison to the world: 179
Total fertility rate: 2.84 children born/woman (2020 est.)
country comparison to the world: 60
Drinking water source:
improved:
urban: 88% of population
rural: 32.8% of population
total: 40% of population
unimproved:
urban: 12% of population
rural: 67.2% of population
total: 60% of population (2015 est.)
Current Health Expenditure: 2% (2016)
Physicians density: 0.05 physicians/1,000 population (2010)
Sanitation facility access:
improved:
urban: 56.4% of population (2015 est.)
rural: 13.3% of population (2015 est.)
total: 18.9% of population (2015 est.)
unimproved:
urban: 43.6% of population (2015 est.)
rural: 86.7% of population (2015 est.)
total: 81.1% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.8% (2018 est.)
country comparison to the world: 55
HIV/AIDS—people living with HIV/AIDS: 45,000 (2018 est.)
country comparison to the world: 62
HIV/AIDS—deaths: 1,100 (2017 est.)
country comparison to the world: 60
Major infectious diseases: degree of risk: very high (2016)
food or waterborne diseases: bacterial diarrhea, hepatitis
A, and typhoid fever (2016)
vectorborne diseases: dengue fever and malaria (2016)
note: active local transmission of Zika virus by Aedes
species mosquitoes has been identified in this country (as
of August 2016); it poses an important risk (a large number
of cases possible) among US citizens if bitten by an
infective mosquito; other less common ways to get Zika are
through sex, via blood transfusion, or during pregnancy, in
which the pregnant woman passes Zika virus to her fetus
Obesity—adult prevalence rate: 21.3% (2016)
country comparison to the world: 91
Children under the age of 5 years underweight:
27.8% (2010)
country comparison to the world: 14
Education expenditures: NA
Literacy: definition: age 15 and over can read and write
total population: 64.2%
male: 65.6%
female: 62.8% (2015)
Unemployment, youth ages 15-24: total: 3.6%
male: 4.3%
female: 3% (2010 est.)
country comparison to the world: 172
People—note: the indigenous population of Papua New
Guinea (PNG) is one of the most heterogeneous in the
world; PNG has several thousand separate communities,
most with only a few hundred people; divided by language,
customs, and tradition, some of these communities have
engaged in low-scale tribal conflict with their neighbors for
millennia; the advent of modern weapons and modern
migrants into urban areas has greatly magnified the impact
of this lawlessness GOVERNMENT
Country name: conventional long form: Independent State of
Papua New Guinea conventional short form: Papua New','daa664782c47bcc0bb18c449be1c2476f3ad958bb1ad8174fe17c3397d596df1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('570a6179b3957e542456870d24c00538b71e2bd4b7b3b7b0917db8a30464bfde',2020,'NF','Norfolk Island','introduction',141,'Background: Once the center of power for the large Austro-
Hungarian Empire, Austria was reduced to a small republic
after its defeat in World War I. Following annexation by
Nazi Germany in 1938 and subsequent occupation by the
victorious Allies in 1945, Austria’s status remained unclear
for a decade. A State Treaty signed in 1955 ended the
occupation, recognized Austria’s independence, and
forbade unification with Germany. A constitutional law that
same year declared the country’s “perpetual neutrality” as
a condition for Soviet military withdrawal. The Soviet
Union’s collapse in 1991 and Austria’s entry into the EU in
1995 have altered the meaning of this neutrality. A
prosperous, democratic country, Austria entered the EU
Economic and Monetary Union in 1999.
ej ole) v- Vea
Location: Central Europe, north of Italy and Slovenia
Geographic coordinates: 47 20 N, 13 20 E
Map references: Europe
Area: total: 83,871 sq km
land: 82,445 sq km
water: 1,426 sq km
country comparison to the world: 115
Area—comparative: about the size of South Carolina; slightly
more than two-thirds the size of Pennsylvania Land
boundaries: total: 2,524 km
border countries (8): Czech Republic 402 km, Germany 801
km, Hungary 321 km, Italy 404 km, Liechtenstein 34 km,
Slovakia 105 km, Slovenia 299 km, Switzerland 158 km
Coastline: 0 km (landlocked)
Maritime claims: None (landlocked)
Climate: temperate; continental, cloudy; cold winters with
frequent rain and some snow in lowlands and snow in
mountains; moderate summers with occasional showers
Terrain: mostly mountains (Alps) in the west and south;
mostly flat or gently sloping along the eastern and northern
Margins Elevation: mean elevation: 910 m
lowest point: Neusiedler See 115 m
highest point: Grossglockner 3,798 m
Natural resources: Oil, coal, lignite, timber, iron ore, copper,
zinc, antimony, magnesite, tungsten, graphite, salt,
hydropower Land use: agricultural land: 38.4% (2016 est.)
arable land: 16.5% (2016 est.)/permanent crops: 0.8%
(2016 est.)/permanent pasture: 21.1% (2016 est.) forest:
A7.2% (2016 est.)
other: 14.4% (2016 est.)
Irrigated land: 1,170 sq km (2012)
Population distribution: the northern and eastern portions of
the country are more densely populated; nearly two-thirds
of the populace lives in urban areas Natural hazards:
landslides; avalanches; earthquakes
Environment—current issues: Some forest degradation caused
by air and soil pollution; soil pollution results from the use
of agricultural chemicals; air pollution results from
emissions by coal- and oil-fired power stations and
industrial plants and from trucks transiting Austria
between northern and southern Europe; water pollution;
the Danube, as well as some of Austria’s other rivers and
lakes, are threatened by pollution Environment—international
agreements: party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulphur 94, Air Pollution-
Volatile Organic Compounds, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling signed, but not
ratified: none of the selected agreements
Geography—note: note 1: landlocked; strategic location at the
crossroads of central Europe with many easily traversable
Alpine passes and valleys; major river is the Danube;
population is concentrated on eastern lowlands because of
steep slopes, poor soils, and low temperatures elsewhere
note 2: the world’s largest and longest ice cave system at
42 km (26 mi) is the Eisriesenwelt (Ice Giants World) inside
the Hochkogel mountain near Werfen, about 40 km south of
Salzburg; ice caves are bedrock caves that contain year-
round ice formations; they differ from glacial caves, which
are transient and are formed by melting ice and flowing
water within and under glaciers PEOPLE AND SOCIETY
Population: 8,859,449 (July 2020 est.)
country comparison to the world: 97
Nationality: N0un: Austrian(s)
adjective: Austrian
Ethnic groups: Austrian 80.8%, German 2.6%, Bosnian and
Herzegovinian 1.9%, Turkish 1.8%, Serbian 1.6%,
Romanian 1.3%, other 10% (2018 est.) note: data represent
population by country of birth
Languages: German (official nationwide) 88.6%, Turkish
2.3%, Serbian 2.2%, Croatian (official in Burgenland) 1.6%,
other (includes Slovene, official in southern Carinthia, and
Hungarian, official in Burgenland) 5.3% (2001 est.)
Religions: Catholic 57%, Eastern Orthodox 8.7%, Muslim
7.9%, Evangelical Christian 3.3%, other/none/unspecified
23.1% (2018 est.) note: data on Muslim is a 2016 estimate;
data on other/none/unspecified are from 2012-2018
estimates Age structure: 0-14 years: 14.01% (male
635,803/female 605,065) 15-24 years: 10.36% (male
466,921/female 451,248)
25-54 years: 41.35% (male 1,831,704/female 1,831,669)
95-64 years: 14.41% (male 635,342/female 641,389)
65 years and over: 19.87% (male 768,687/female 991,621)
(2020 est.)
Dependency ratios: total dependency ratio: 50.6
youth dependency ratio: 21.7
elderly dependency ratio: 28.9
potential support ratio: 3.5 (2020 est.)
Median age: total: 44.5 years
male: 43.1 years
female: 45.8 years (2020 est.)
country comparison to the world: 14
Population growth rate: 0.35% (2020 est.)
country comparison to the world: 167
Birth rate: 9.5 births/1,000 population (2020 est.)
country comparison to the world: 195
Death rate: 9.8 deaths/1,000 population (2020 est.)
country comparison to the world: 39
Net migration rate: 3.6 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 33
Population distribution: the northern and eastern portions of
the country are more densely populated; nearly two-thirds
of the populace lives in urban areas Urbanization: urban
population: 58.7% of total population (2020) rate of
urbanization: 0.59% annual rate of change (2015-20 est.)
Major urban areas—Population: 1.930 million VIENNA (capital)
(2020)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.03 male(s)/female (2020 est.)
25-54 years: 1 male(s)/female (2020 est.)
95-64 years: 0.99 male(s)/female (2020 est.)
65 years and over: 0.78 male(s)/female (2020 est.)
total population: 96 male(s)/female (2020 est.)
Mother’s mean age at first birth: 29 years (2014 est.)
Maternal mortality rate: 5 deaths/100,000 live births (2017
est.)
country comparison to the world: 163
Infant mortality rate: total: 3.3 deaths/1,000 live births
male: 3.7 deaths/1,000 live births
female: 3 deaths/1,000 live births (2020 est.)
country comparison to the world: 204
Life expectancy at birth: total population: 81.9 years
male: 79.2 years
female: 84.7 years (2020 est.)
country comparison to the world: 25
Total fertility rate: 1.49 children born/woman (2020 est.)
country comparison to the world: 203
Contraceptive prevalence rate: 65.7% (2012/13)
note: percent of women aged 18-49
Drinking water source:
improved:
urban: 100% of population
rural: 100% of population
total: 100% of population
unimproved:
urban: 0% of population
rural: 0% of population
total: 0% of population (2015 est.)
Current Health Expenditure: 10.4% (2016)
Physicians density: 5.14 physicians/1,000 population (2016)
Hospital bed density: 7.6 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 100% of population (2015 est.)
rural: 100% of population (2015 est.)
total: 100% of population (2015 est.)
unimproved:
urban: 0% of population (2015 est.)
rural: 0% of population (2015 est.)
total: 0% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.1% (2017 est.)
country comparison to the world: 117
HIV/AIDS—people living with HIV/AIDS: 7,400 (2017 est.)
country comparison to the world: 111
HIV/AIDS—deaths: <100 (2017 est.)
Obesity—adult prevalence rate: 20.1% (2016)
country comparison to the world: 105
Education expenditures: 5.5% of GDP (2016)
country comparison to the world: 38
School life expectancy (primary to tertiary education):
total: 16 years
male: 16 years
female: 16 years (2016)
Unemployment, youth ages 15-24:
total: 9.8%
male: 10.8%
female: 8.7% (2017 est.)
country comparison to the world: 131
Background: Azerbaijan—a secular nation with a majority-
Turkic and majority-Shia Muslim population—was briefly
independent (from 1918 to 1920) following the collapse of
the Russian Empire; it was subsequently incorporated into
the Soviet Union for seven decades. Azerbaijan remains
involved in the protracted Nagorno-Karabakh conflict with
Armenia. Nagorno-Karabakh was a primarily ethnic
Armenian region that Moscow recognized in 1923 as an
autonomous oblast within Soviet Azerbaijan. In the late
Soviet period, a separatist movement developed which
sought to end Azerbaijani control over the region. Fighting
over Nagorno-Karabakh began in 1988 and escalated after
Armenia and Azerbaijan attained independence from the
Soviet Union in 1991. By the time a ceasefire took effect in
May 1994, separatists, with Armenian support, controlled
Nagorno-Karabakh and seven surrounding Azerbaijani
territories. The 1994 ceasefire continues to hold, although
violence continues along the line of contact separating the
opposing forces, as well as the Azerbaijan-Armenia
international border. The final status of Nagorno-Karabakh
remains the subject of international mediation by the
Organization for Security and Cooperation in Europe
(OSCE) Minsk Group, which works to help the sides settle
the conflict peacefully. The OSCE Minsk Group is co-
Chaired by the United States, France, and Russia.
In the 25 years following its independence, Azerbaijan
succeeded in significantly reducing the poverty rate and
has directed revenues from its oil and gas production to
develop the country’s infrastructure. However, corruption
remains a problem, and the government has been accused
of authoritarianism. The country’s leadership has remained
in the Aliyev family since Heydar ALIYEV became president
in 1993 and was succeeded by his son, President Ilham
ALIYEV in 2003. Following two national referendums in the
past several years that eliminated presidential term limits
and extended presidential terms from 5 to 7 years,
President ALIYEV secured a fourth term as president in
April 2018 in an election that international observers noted
had serious shortcomings. Reforms are underway to
diversify the country’s non-oil economy and additional
reforms are needed to address weaknesses in government
institutions, particularly in the education and _ health
sectors, and the court system.
Background: Lucayan Indians inhabited the islands when
Christopher COLUMBUS first set foot in the New World on
San Salvador in 1492. British settlement of the islands
began in 1647; the islands became a colony in 1783. Piracy
thrived in the 17th and 18th centuries because of The
Bahamas close proximity to shipping lanes. Since attaining
independence from the UK in 1973, The Bahamas has
prospered through tourism, international banking, and
investment management, which comprise up to 85% of
GDP. Because of its proximity to the US—the nearest
Bahamian landmass being only 80 km (50 mi) from Florida
—the country is a major transshipment point for illicit
trafficking, particularly to the US mainland, as well as
Europe. US law enforcement agencies cooperate closely
with The Bahamas, and the US Coast Guard assists
Bahamian authorities in coastal defense through Operation
Bahamas, Turks and Caicos, or OPBAT.
Background: In 1783, the Sunni Al-Khalifa family took power
in Bahrain. In order to secure these holdings, it entered
into a series of treaties with the UK during the 19th
century that made Bahrain a British protectorate. The
archipelago attained its independence in 1971. A steady
decline in oil production and reserves since 1970 prompted
Bahrain to take steps to diversify its economy, in the
process developing petroleum processing and refining,
aluminum production, and hospitality and retail sectors. It
has also endeavored to become a leading regional banking
center, especially with respect to Islamic finance. Bahrain’s
small size, central location among Gulf countries, economic
dependence on Saudi Arabia, and proximity to Iran require
it to play a delicate balancing act in foreign affairs among
its larger neighbors. Its foreign policy activities usually fall
in line with Saudi Arabia and the UAE.
The Sunni royal family has long struggled to manage
relations with its large Shia-majority population. In early
2011, amid Arab uprisings elsewhere in the region, the
Bahraini Government confronted similar pro-democracy
and reform protests at home with police and military
action, including deploying Gulf Cooperation Council
security forces to Bahrain. Failed political talks prompted
opposition political societies to boycott 2014 legislative and
municipal council elections. In 2018, a law preventing
members of political societies dissolved by the courts from
participating in elections effectively sidelined the majority
of opposition figures from taking part in national elections.
As a result, most members of parliament are independents.
Ongoing dissatisfaction with the political status quo
continues to factor into sporadic clashes between
demonstrators and security forces.
Background: Two British attempts at establishing the island
as a penal colony (1788-1814 and 1825-55) were ultimately
abandoned. In 1856, the island was resettled by Pitcairn
Islanders, descendants of the Bounty mutineers and their
Tahitian companions.','8d20271623d2019900f6947a2062df61711d166ef37d5350600bcac8ee530a10','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb2a378210be5b5e5d19912e8fa655bac3b08652d29436268b2633b41b2b42a1',2020,'BB','Barbados','introduction',158,'Background: The island was uninhabited when first settled by
the British in 1627. African slaves worked the sugar
plantations established on the island, which initially
dominated the Caribbean sugar industry. By 1720 Barbados
was no longer a dominant force within the sugar industry,
having been surpassed by the Leeward Islands and
Jamaica. Slavery was abolished in 1834. The Barbadian
economy remained heavily dependent on sugar, rum, and
molasses production through most of the 20th century. The
gradual introduction of social and political reforms in the
1940s and 1950s led to complete independence from the
UK in 1966. In the 1990s, tourism and manufacturing
surpassed the sugar industry in economic importance.
Background: After seven decades as a constituent republic of
the USSR, Belarus attained its independence in 1991. It
has retained closer political and economic ties to Russia
than have any of the other former Soviet republics. Belarus
and Russia signed a treaty on a two-state union on 8
December 1999 envisioning greater political and economic
integration. Although Belarus agreed to a framework to
carry out the accord, serious implementation has yet to
take place and current negotiations on further integration
have been contentious. Since his election in July 1994 as
the country’s first and only directly elected president,
Aleksandr LUKASHENKO has steadily consolidated his
power through authoritarian means and a centralized
economic system. Government restrictions on political and
civil freedoms, freedom of speech and the press, peaceful
assembly, and religion have remained in place.','72e46e8517b4d488a6aa85da88ea1155e9250039e7555b65a21d2ef98b704967','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1c97eb49a6e80f12636bb5c3b99ce216f62c608daf5286d06a8805dafc02240',2020,'FR','France','introduction',168,'Background: Belgium became independent from _ the
Netherlands in 1830; it was occupied by Germany during
World Wars I and II. The country prospered in the past half
century as a modern, technologically advanced European
state and member of NATO and the EU. In recent years,
political divisions between the Dutch-speaking Flemish of
the north and the French-speaking Walloons of the south
have led to constitutional amendments granting these
regions formal recognition and autonomy. The capital city
of Brussels is home to numerous international
organizations including the EU and NATO.
Background: France today is one of the most modern
countries in the world and is a leader among European
nations. It plays an influential global role as a permanent
member of the United Nations Security Council, NATO, the
G-7, the G-20, the EU, and other multilateral organizations.
France rejoined NATO’s integrated military command
structure in 2009, reversing DE GAULLE’s 1966 decision to
withdraw French forces from NATO. Since 1958, it has
constructed a hybrid presidential-parliamentary governing
system resistant to the instabilities experienced in earlier,
more purely parliamentary administrations. In recent
decades, its reconciliation and cooperation with Germany
have proved central to the economic integration of Europe,
including the introduction of a common currency, the euro,
in January 1999. In the early 21st century, five French
overseas entities—French Guiana, Guadeloupe, Martinique,
Mayotte, and Reunion—became French regions and were
made part of France proper.
Background: Spain’s powerful world empire of the 16th and
17th centuries ultimately yielded command of the seas to
England. Subsequent failure to embrace the mercantile and
industrial revolutions caused the country to fall behind
Britain, France, and Germany in economic and political
power. Spain remained neutral in World War I and II, but
suffered through a devastating civil war (1936-39). A
peaceful transition to democracy following the death of
dictator Francisco FRANCO in 1975, and rapid economic
modernization (Spain joined the EU in 1986) gave Spain a
dynamic and rapidly growing economy, and made it a
global champion of freedom and human rights. More
recently, Spain has emerged from a severe economic
recession that began in mid-2008, posting four straight
years of GDP growth above the EU average. Unemployment
has fallen, but remains high, especially among youth. Spain
is the Eurozone’s fourth largest economy. The country has
faced increased domestic turmoil in recent years due to the
independence movement in its restive Catalonia region.
Background: The Spratly Islands consist of more than 100
small islands or reefs surrounded by rich fishing grounds—
and potentially by gas and oil deposits. They are claimed in
their entirety by China, Taiwan, and Vietnam, while
portions are claimed by Malaysia and the Philippines.
About 45 islands are occupied by relatively small numbers
of military forces from China, Malaysia, the Philippines,
Taiwan, and Vietnam. Since 1985 Brunei has claimed a
continental shelf that overlaps a southern reef but has not
made any formal claim to the reef. Brunei claims an
exclusive economic zone over this area.','affaa95db54822e482fa6bc1628eb4bd63771463ebeaf851fd91a74ed0dbc302','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31f43f64c080684a5634afd39f0714d36f2c859a65bd6db2e230e9a15c74bacb',2020,'BR','Brazil','introduction',202,'Background: Bolivia, named after independence fighter
Simon BOLIVAR, broke away from Spanish rule in 1825;
much of its subsequent history has consisted of a series of
coups and countercoups, with the last coup occurring in
1978. Democratic civilian rule was established in 1982, but
leaders have faced difficult problems of deep-seated
poverty, social unrest, and illegal drug production.
In December 2005, Bolivians elected Movement Toward
Socialism leader Evo MORALES president—by the widest
margin of any leader since the restoration of civilian rule in
1982—after he ran on a promise to change the country’s
traditional political class and empower the nation’s poor,
indigenous majority. In December 2009 and October 2014,
President MORALES easily won reelection. His party
maintained control of the legislative branch of the
government, which has allowed him to continue his process
of change. In February 2016, MORALES narrowly lost a
referendum to approve a constitutional amendment that
would have allowed him to compete in the 2019
presidential election. However, a 2017 Supreme Court
ruling stating that term limits violate human rights
provided the justification for MORALES to be chosen by his
party to run again in 2019. MORALES attempted to claim
victory in the 20 October 2019 election, but widespread
allegations of electoral fraud, rising violence, and pressure
from the military ultimately forced him to flee the country.
An interim government is preparing new elections for 2020.
Background: Colombia was one of the three countries that
emerged after the dissolution of Gran Colombia in 1830
(the others are Ecuador and Venezuela). A decades-long
conflict between government forces, paramilitaries, and
antigovernment insurgent groups heavily funded by the
drug trade, principally the Revolutionary Armed Forces of
Colombia (FARC), escalated during the 1990s. More than
31,000 former United Self Defense Forces of Colombia
(AUC) paramilitaries demobilized by the end of 2006, and
the AUC as a formal organization ceased to operate. In the
wake of the paramilitary demobilization, illegal armed
groups arose, whose members include some former
paramilitaries. After four years of formal peace
negotiations, the Colombian Government signed a final
peace accord with the FARC in November 2016, which was
subsequently ratified by the Colombian Congress. The
accord calls for members of the FARC to demobilize,
disarm, and reincorporate into society and politics. The
accord also committed the Colombian Government to
create three new institutions to form a ‘comprehensive
system for truth, justice, reparation, and non-repetition,’ to
include a truth commission, a special unit to coordinate the
search for those who disappeared during the conflict, and a
‘Special Jurisdiction for Peace’ to administer justice for
conflict-related crimes. The Colombian Government has
stepped up efforts to expand its presence into every one of
its administrative departments. Despite decades of internal
conflict and drug-related security challenges, Colombia
maintains relatively strong democratic institutions
Characterized by peaceful, transparent elections and the
protection of civil liberties.
Background: The archipelago of the Comoros in the Indian
Ocean, composed of the islands of Mayotte, Anjouan,
Moheli, and Grande Comore declared independence from
France on 6 July 1975. Residents of Mayotte voted to
remain in France, and France now has classified it as a
department of France. Since independence, Comoros has
endured political instability through realized and attempted
coups. In 1997, the islands of Anjouan and Moheli declared
independence from Comoros. In 1999, military chief Col.
AZALI Assoumani seized power of the entire government in
a bloodless coup; he initiated the 2000 Fomboni Accords, a
power-sharing agreement in which the federal presidency
rotates among the three islands, and each island maintains
its local government. AZALI won the 2002 federal
presidential election as president of the Union of the
Comoros from Grande Comore Island, which held the first
four-year term. AZALI stepped down in 2006 and President
Ahmed Abdallah Mohamed SAMBI was elected to office as
president from Anjouan. In 2007, Mohamed BACAR
effected Anjouan’s de-facto secession from the Union of the
Comoros, refusing to step down when Comoros’ other
islands held legitimate elections in July. The African Union
(AU) initially attempted to resolve the political crisis by
applying sanctions and a naval blockade to Anjouan, but in
March 2008 the AU and Comoran soldiers seized the
island. The island’s inhabitants generally welcomed the
move. In 2009, the Comorian population approved a
constitutional referendum extending the term of the
president from four years to five years. In May 2011,
Ikililou DHOININE won the _ presidency in _ peaceful
elections widely deemed to be free and fair. In closely
contested elections in 2016, former President AZALI
Assoumani won aé second term, when the _ rotating
presidency returned to Grande Comore. A new constitution
was passed in July 2018, in a vote boycotted by the
opposition, which allowed for two consecutive five-year
presidential terms and abolished the island specific vice
presidents. Under the new constitution, the incumbent
president can run for a second term against candidates
from the next island in line for the rotation. In August 2018,
President AZALI formed a new - government and
subsequently ran and was elected president in March 2019.
Background: Originally a Dutch colony in the 17th century, by
1815 Guyana had become a British possession. The
abolition of slavery led to settlement of urban areas by
former slaves and the importation of indentured servants
from India to work the sugar plantations. The resulting
ethnocultural divide has persisted and has led to turbulent
politics. Guyana achieved independence from the UK in
1966, and since then it has been ruled mostly by socialist-
oriented governments. In 1992, Cheddi JAGAN was elected
president in what is considered the country’s first free and
fair election since independence.
After his death five years later, his wife, Janet JAGAN,
became president but resigned in 1999 due to poor health.
Her successor, Bharrat JAGDEO, was elected in 2001 and
again in 2006. Early elections held in May 2015 resulted in
the first change in governing party and the replacement of
President Donald RAMOTAR by current President David
GRANGER.
After a December 2018 no-confidence vote against the
GRANGER government, national elections will be held
before the scheduled spring 2020 date.
Background: The native Taino—who inhabited the island of
Hispaniola when Christopher COLUMBUS first landed on it
in 1492—were virtually wiped out by Spanish settlers
within 25 years. In the early 17th century, the French
established a presence on Hispaniola. In 1697, Spain ceded
to the French the western third of the island, which later
became Haiti. The French colony, based on forestry and
sugar-related industries, became one of the wealthiest in
the Caribbean but relied heavily on the forced labor of
enslaved Africans and environmentally degrading practices.
In the late 18th century, Toussaint LOUVERTURE led a
revolution of Haiti’s nearly half a million slaves that ended
France’s rule on the island. After a prolonged struggle, and
under the leadership of Jean-Jacques DESSALINES, Haiti
became the first country in the world led by former slaves
after declaring its independence in 1804, but it was forced
to pay an indemnity to France for more than a century and
was shunned by other countries for nearly 40 years. After
the US occupied Haiti from 1915-1934, Francois “Papa
Doc” DUVALIER and then his son Jean-Claude “Baby Doc”
DUVALIER led repressive and corrupt regimes that ruled
Haiti from 1957-1971 and 1971-1986, respectively. A
massive magnitude 7.0 earthquake struck Haiti in January
2010 with an epicenter about 25 km (15 mi) west of the
capital, Port-au-Prince. Estimates are that over 300,000
people were killed and some 1.5 million left homeless. The
earthquake was assessed as the worst in this region over
the last 200 years. On 4 October 2016, Hurricane Matthew
made landfall in Haiti, resulting in over 500 deaths and
causing extensive damage to crops, houses, livestock, and
infrastructure. Currently the poorest country in the
Western Hemisphere, Haiti continues to experience bouts
of political instability.
Background: The UK transferred these uninhabited, barren,
sub-Antarctic islands to Australia in 1947. Populated by
large numbers of seal and bird species, the islands have
been designated a nature preserve.
Background: First explored by the Spaniards in the 16th
century and then settled by the English in the mid-17th
century, Suriname became a Dutch colony in 1667. With
the abolition of African slavery in 1863, workers were
brought in from India and Java. The Netherlands granted
the colony independence in 1975. Five years later the
civilian government was replaced by a military regime that
soon declared Suriname a socialist republic. It continued to
exert control through a succession of nominally civilian
administrations until 1987, when international pressure
finally forced a democratic election. In 1990, the military
overthrew the civilian leadership, but a democratically
elected government—a four-party coalition—returned to
power in 1991. The coalition expanded to eight parties in
2005 and ruled until August 2010, when voters returned
former military leader Desire BOUTERSE and _ his
Opposition coalition to power. President BOUTERSE was
reelected unopposed in 2015.
Background: The archipelago may have been first discovered
by Norse explorers in the 12th century; the islands served
as an international whaling base during the 17th and 18th
centuries. Norway’s’ sovereignty was _ internationally
recognized by treaty in 1920, and five years later it
officially took over the territory. In the 20th century coal
mining started and today a Norwegian and a Russian
company are still functioning. Travel between the
settlements is accomplished with snowmobiles, aircraft,
and boats.
Background: Montevideo, founded by the Spanish in 1726 as
a military stronghold, soon took advantage of its natural
harbor to become an important commercial center. Claimed
by Argentina but annexed by Brazil in 1821, Uruguay
declared its independence four years later and secured its
freedom in 1828 after a _ three-year struggle. The
administrations of President Jose BATLLE in the early 20th
century launched widespread _ political, social, and
economic reforms that established a statist tradition. A
violent Marxist urban guerrilla movement named the
Tupamaros, launched in the late 1960s, led Uruguay’s
president to cede control of the government to the military
in 1973. By yearend, the rebels had been crushed, but the
military continued to expand its hold over the government.
Civilian rule was restored in 1985. In 2004, the left-of-
center Frente Amplio Coalition won national elections that
effectively ended 170 years of political control previously
held by the Colorado and National (Blanco) parties.
Uruguay’s political and labor conditions are among the
freest on the continent.
Background: Venezuela was one of three countries that
emerged from the collapse of Gran Colombia in 1830 (the
others being Ecuador and New Granada, which became
Colombia). For most of the first half of the 20th century,
Venezuela was ruled by generally benevolent military
strongmen who promoted the oil industry and allowed for
some social reforms. Democratically elected governments
have held sway since 1959, although the re-election of
current disputed President Nicolas MADURO in an election
boycotted by most opposition parties was widely viewed as
fraudulent. Under Hugo CHAVEZ, president from 1999 to
2013, and his hand-picked successor, MADURO, the
executive branch has exercised increasingly authoritarian
control over other branches of government. National
Assembly President Juan GUAIDO is currently recognized
by more than 50 countries—including the United States—as
the interim president while MADURO retains control of all
other institutions within the country and has the support of
security forces. Venezuela is currently authoritarian with
only one democratic institution—the National Assembly—
and strong restrictions on freedoms of expression and the
press. The ruling party’s economic policies expanded the
state’s role in the economy through expropriations of major
enterprises, strict currency exchange and price controls
that discourage private sector investment and production,
and overdependence on the petroleum industry for
revenues, among others. However, Caracas in 2019 relaxed
some economic controls to mitigate some impacts of the
economic crisis driven by a drop in oil production. Current
concerns include human rights abuses, rampant violent
crime, high inflation, and widespread shortages of basic
consumer goods, medicine, and medical supplies.
Background: The conquest of Vietnam by France began in
1858 and was completed by 1884. It became part of French
Indochina in 1887. Vietnam declared independence after
World War II, but France continued to rule until its 1954
defeat by communist forces under Ho Chi MINH. Under the
Geneva Accords of 1954, Vietnam was divided into the
communist North and anti-communist South. US economic
and military aid to South Vietnam grew through the 1960s
in an attempt to bolster the government, but US armed
forces were withdrawn following a cease-fire agreement in
1973. Two years later, North Vietnamese forces overran the
South reuniting the country under communist rule. Despite
the return of peace, for over a decade the country
experienced little economic growth because of conservative
leadership policies, the persecution and mass exodus of
individuals—many of them successful South Vietnamese
merchants—and growing international isolation. However,
since the enactment of Vietnam’s “doi moi” (renovation)
policy in 1986, Vietnamese authorities have committed to
increased economic liberalization and enacted structural
reforms needed to modernize the economy and to produce
more competitive, export-driven industries. The communist
leaders maintain tight control on political expression but
have demonstrated some modest steps toward better
protection of human rights. The country continues to
experience small-scale protests, the vast majority
connected to either land-use issues, calls for increased
political space, or the lack of equitable mechanisms for
resolving disputes. The small-scale protests in the urban
areas are often organized by human rights activists, but
Many occur in rural areas and involve various ethnic
minorities such as the Montagnards of the Central
Highlands, Hmong in the Northwest Highlands, and the
Khmer Krom in the southern delta region.
Background: The Danes secured control over the southern
Virgin Islands of Saint Thomas, Saint John, and Saint Croix
during the 17th and early 18th centuries. Sugarcane,
produced by African slave labor, drove the _ islands’
economy during the 18th and early 19th centuries. In 1917,
the US purchased the Danish holdings, which had been in
economic decline since the abolition of slavery in 1848. On
6 September 2017, Hurricane Irma passed over the
northern Virgin Islands of Saint Thomas and Saint John and
inflicted severe damage to structures, roads, the airport on
Saint Thomas, communications, and electricity. Less than
two weeks later, Hurricane Maria passed over the island of
Saint Croix in the southern Virgin Islands, inflicting
considerable damage with heavy winds and flooding rains.
Background: The US annexed Wake Island in 1899 for a cable
station. An important air and naval base was constructed in
1940-41. In December 1941, the island was captured by the
Japanese and held until the end of World War II. In
subsequent years, Wake became a stopover and refueling
site for military and commercial aircraft transiting the
Pacific. Since 1974, the island’s airstrip has been used by
the US military, as well as for emergency landings.
Operations on the island were temporarily suspended and
all personnel evacuated in 2006 with the approach of super
typhoon IOKE (category 5), but resultant damage was
comparatively minor. A US Air Force repair team restored
full capability to the airfield and facilities, and the island
remains a vital strategic link in the Pacific region.','e046b298f9a34d6626660a824cebb2c8bf9f1b4f9cc15424608925054bb6761c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aff815dafc2367c2c14a4d2e9d57a39ce17be740a67b0b88e6f540fcf9b8a4a5',2020,'ME','Montenegro','introduction',216,'Background: Bosnia and Herzegovina declared sovereignty in
October 1991 and independence from the former
Yugoslavia on 3 March 1992 after a referendum boycotted
by ethnic Serbs. The Bosnian Serbs—supported by
neighboring Serbia and Montenegro—responded with
armed resistance aimed at partitioning the republic along
ethnic lines and joining Serb-held areas to form a “Greater
Serbia.” In March 1994, Bosniaks and Croats reduced the
number of warring factions from three to two by signing an
agreement creating a joint Bosniak-Croat Federation of
Bosnia and Herzegovina. On 21 November 1995, in Dayton,
Ohio, the warring parties initialed a peace agreement that
ended three years of interethnic civil strife (the final
agreement was signed in Paris on 14 December 1995).
The Dayton Peace Accords retained Bosnia and
Herzegovina’s international boundaries and created a
multiethnic and democratic government charged with
conducting foreign, diplomatic, and fiscal policy. Also
recognized was a second tier of government composed of
two entities roughly equal in size: the predominantly
Bosniak-Bosnian Croat Federation of Bosnia and
Herzegovina and the predominantly Bosnian Serb-led
Republika Srpska (RS). The Federation and RS
governments are responsible for overseeing most
government functions. Additionally, the Dayton Accords
established the Office of the High Representative to
oversee the implementation of the civilian aspects of the
agreement. The Peace Implementation Council at its
conference in Bonn in 1997 also gave the High
Representative the authority to impose legislation and
remove Officials, the so-called “Bonn Powers.” An original
NATO-led international peacekeeping force (IFOR) of
60,000 troops assembled in 1995 was succeeded over time
by a smaller, NATO-led Stabilization Force (SFOR). In 2004,
European Union peacekeeping troops (EUFOR) replaced
SFOR. Currently, EUFOR deploys around 600 troops in
theater in a security assistance and training capacity.
Background: The Kingdom of Serbs, Croats, and Slovenes
was formed in 1918; its name was changed to Yugoslavia in
1929. Communist Partisans resisted the Axis occupation
and division of Yugoslavia from 1941 to 1945 and fought
nationalist opponents and collaborators as well. The
military and political movement headed by Josip Broz
“TITO” (Partisans) took full control of Yugoslavia when
their domestic rivals and the occupiers were defeated in
1945. Although communists, TITO and his successors (Tito
died in 1980) managed to steer their own path between the
Warsaw Pact nations and the West for the next four and a
half decades. In 1989, Slobodan MILOSEVIC became
president of the Republic of Serbia and his ultranationalist
calls for Serbian domination led to the violent breakup of
Yugoslavia along ethnic lines. In 1991, Croatia, Slovenia,
and Macedonia declared independence, followed by Bosnia
in 1992. The remaining republics of Serbia and
Montenegro declared a new Federal Republic of Yugoslavia
(FRY) in April 1992 and under MILOSEVIC’s leadership,
Serbia led various military campaigns to unite ethnic Serbs
in neighboring republics into a “Greater Serbia.” These
actions ultimately failed and, after international
intervention, led to the signing of the Dayton Peace
Accords in 1995.
MILOSEVIC retained control over Serbia and eventually
became president of the FRY in 1997. In 1998, an ethnic
Albanian insurgency in the formerly autonomous Serbian
province of Kosovo provoked a Serbian counterinsurgency
campaign that resulted in massacres and massive
expulsions of ethnic Albanians living in Kosovo. The
MILOSEVIC government’s rejection of a _ proposed
international settlement led to NATO’s bombing of Serbia
in the spring of 1999. Serbian military and police forces
withdrew from Kosovo in June 1999, and the UN Security
Council authorized an interim UN administration and a
NATO-led security force in Kosovo. FRY elections in late
2000 led to the ouster of MILOSEVIC and the installation of
democratic government. In 2003, the FRY became the State
Union of Serbia and Montenegro, a loose federation of the
two republics. Widespread violence predominantly
targeting ethnic Serbs in Kosovo in March 2004 led to more
intense calls to address Kosovo’s status, and the UN began
facilitating status talks in 2006. In June 2006, Montenegro
seceded from the federation and declared itself an
independent nation. Serbia subsequently gave notice that it
was the successor state to the union of Serbia and
Montenegro.
In February 2008, after nearly two years of inconclusive
negotiations, Kosovo declared itself independent of Serbia
—an action Serbia refuses to recognize. At Serbia’s
request, the UN General Assembly (UNGA) in October 2008
sought an advisory opinion from the International Court of
Justice (ICJ) on whether Kosovo’s unilateral declaration of
independence was in accordance with international law. In
a ruling considered unfavorable to Serbia, the ICJ issued an
advisory opinion in July 2010 stating that international law
did not prohibit declarations of independence. In late 2010,
Serbia agreed to an EU-drafted UNGA _ Resolution
acknowledging the ICJ’s decision and calling for a new
round of talks between Serbia and Kosovo, this time on
practical issues rather than Kosovo’s status. Serbia and
Kosovo signed the first agreement of principles governing
the normalization of relations between the two countries in
April 2013 and are in the process of implementing its
provisions. In 2015, Serbia and Kosovo reached four
additional agreements within the EU-led Brussels Dialogue
framework. These included agreements on the Community
of Serb-Majority Municipalities; telecommunications;
energy production and distribution; and freedom of
movement. President Aleksandar VUCIC has promoted an
ambitious goal of Serbia joining the EU by 2025. Under his
leadership as prime minister, in 2014 Serbia opened formal
negotiations for accession.','caf12d4036532306d7d008f9c20378eb3f9db5eaddb70b9d01c3710929dc3033','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8ffdcd2b7e7551a65c3962f295967829f3bb72e13a3a9e5a16f75f7cab55545',2020,'PR','Puerto Rico','introduction',244,'Background: The Sultanate of Brunei’s influence peaked
between the 15th and 17th centuries when its control
extended over coastal areas of northwest Borneo and the
southern Philippines. Brunei subsequently entered a period
of decline brought on by internal strife over royal
succession, colonial expansion of European powers, and
piracy. In 1888, Brunei became a British protectorate;
independence was achieved in 1984. The same family has
ruled Brunei for over six centuries. Brunei benefits from
extensive petroleum and natural gas fields, the source of
one of the highest per capita GDPs in the world. In 2017,
Brunei celebrated the 50th anniversary of the Sultan
Hassanal BOLKIAH’s accession to the throne.
Background: Ruled by the Al Thani family since the mid-
1800s, Qatar within the last 60 years transformed itself
from a poor British protectorate noted mainly for pearling
into an independent state with significant oil and natural
gas revenues. Former Amir HAMAD bin Khalifa Al Thani,
who overthrew his father in a bloodless coup in 1995,
ushered in wide-sweeping political and media reforms,
unprecedented economic investment, and a growing Qatari
regional leadership role, in part through the creation of the
pan-Arab satellite news network Al-Jazeera and Qatar’s
mediation of some regional conflicts. In the 2000s, Qatar
resolved its longstanding border disputes with both
Bahrain and Saudi Arabia and by 2007 had attained the
highest per capita income in the world. Qatar did not
experience domestic unrest or violence like that seen in
other Near Eastern and North African countries in 2011,
due in part to its immense wealth and patronage network.
In mid-2013, HAMAD peacefully abdicated, transferring
power to his son, the current Amir TAMIM bin Hamad.
TAMIM is popular with the Qatari public, for his role in
shepherding the country through an economic embargo by
some other regional countries, for his efforts to improve the
country’s healthcare and education systems, and for his
expansion of the country’s infrastructure in anticipation of
Doha’s hosting of the 2022 World Cup.
Recently, Qatar’s relationships with its neighbors have
been tense, although since the fall of 2019 there have been
signs of improved prospects for a thaw. Following the
outbreak of regional unrest in 2011, Doha prided itself on
its support for many popular revolutions, particularly in
Libya and Syria. This stance was to the detriment of
Qatar’s relations with Bahrain, Egypt, Saudi Arabia, and
the United Arab Emirates (UAE), which temporarily
recalled their respective ambassadors from Doha in March
2014. TAMIM later oversaw a warming of Qatar’s relations
with Bahrain, Egypt, Saudi Arabia, and the UAE in
November 2014 following Kuwaiti mediation and signing of
the Riyadh Agreement. This reconciliation, however, was
short-lived. In June 2017, Bahrain, Egypt, Saudi Arabia, and
the UAE (the “Quartet”) cut diplomatic and economic ties
with Qatar in response to alleged violations of the
agreement, among other complaints.','6df3070b916ab72272d9ef2996395dccb10fdd6cf70e82192928b3cbf38cbc75','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98c28cd12c94e8c9e2e436f305b65c6b811589c730135f9ee872682fa892d643',2020,'TH','Thailand','introduction',247,'Background: Various ethnic Burman and ethnic minority city-
states or kingdoms occupied the present borders through
the 19th century, and several minority ethnic groups
continue to maintain independent armies and control
territory within the country today, in opposition to the
central government. Over a period of 62 years (1824-1886),
Britain conquered Burma and incorporated all the groups
within the country into its Indian Empire. Burma was
administered as a province of India until 1937 when it
became aé_ separate, self-governing colony; in 1948,
following major battles on its territory during World War II,
Burma attained independence from the _ British
Commonwealth. Gen. NE WIN dominated the government
from 1962 to 1988, first as military ruler, then as self-
appointed president, and later as political kingpin. In
response to widespread civil unrest, NE WIN resigned in
1988, but within months the military crushed student-led
protests and took power. Since independence, successive
Burmese governments have fought on-and-off conflicts with
armed ethnic groups seeking autonomy in the country’s
mountainous border regions.
Multiparty legislative elections in 1990 resulted in the
main opposition party—the National League for Democracy
(NLD)—winning a landslide victory. Instead of handing over
power, the junta placed NLD leader (and 1991 Nobel Peace
Prize recipient) AUNG SAN SUU KYI under house arrest
from 1989 to 1995, 2000 to 2002, and from May 2003 to
November 2010. In late September 2007, the ruling junta
brutally suppressed protests over increased fuel prices led
by prodemocracy activists and Buddhist monks, killing an
unknown number of people and arresting thousands for
participating in the demonstrations—popularly referred to
as the Saffron Revolution. In early May 2008, Cyclone
Nargis struck Burma, which left over 138,000 dead and
tens of thousands injured and homeless. Despite this
tragedy, the junta proceeded with its May constitutional
referendum, the first vote in Burma since 1990. The 2008
constitution reserves 25% of its seats to the military.
Legislative elections held in November 2010, which the
NLD boycotted and many in the international community
considered flawed, saw the successor ruling junta’s mass
organization, the Union Solidarity and Development Party
garner over 75% of the contested seats.
The national legislature convened in January 2011 and
selected former Prime Minister THEIN SEIN as president.
Although the vast majority of national-level appointees
named by THEIN SEIN were former or current military
officers, the government initiated a series of political and
economic reforms leading to a substantial opening of the
long-isolated country. These reforms included releasing
hundreds of political prisoners, signing a nationwide cease-
fire with several of the country’s ethnic armed groups,
pursuing legal reform, and gradually reducing restrictions
on freedom of the press, association, and civil society. At
least due in part to these reforms, AUNG SAN SUU KyYI
was elected to the national legislature in April 2012 and
became chair of the Committee for Rule of Law and
Tranquility. Burma served as chair of the Association of
Southeast Asian Nations (ASEAN) for 2014. In a flawed but
largely credible national legislative election in November
2015 featuring more than 90 political parties, the NLD
again won a landslide victory. Using its overwhelming
majority in both houses of parliament, the NLD elected
HTIN KYAW, AUNG SAN SUU KYI’s confidant and long-time
NLD supporter, as president. The new legislature created
the position of State Counsellor, according AUNG SAN SUU
KYI a formal role in the government and making her the de
facto head of state. Burma’s first credibly elected civilian
government after more than five decades of military
dictatorship was sworn into office on 30 March 2016. In
March 2018, upon HTIN KYAW’s resignation, parliament
selected WIN MYINT, another long-time ally of AUNG SAN
SUU KYI’s, as president.
Attacks in October 2016 and August 2017 on security
forces in northern Rakhine State by members of the Arakan
Rohingya Salvation Army (ARSA), a Rohingya militant
group, resulted in military crackdowns on the Rohingya
population that reportedly caused thousands of deaths and
human rights abuses. Following the August 2017 violence,
over 740,000 Rohingya fled to neighboring Bangladesh as
refugees. In November 2017, the US Department of State
determined that the August 2017 violence constituted
ethnic cleansing of Rohingyas. The UN has called for
Burma to allow access to a Fact Finding Mission to
investigate reports of human rights violations and abuses
and to work with Bangladesh to facilitate repatriation of
Rohingya refugees, and in September 2018 _ the
International Criminal Court (ICC) determined it had
jurisdiction to investigate reported human rights abuses
against Rohingyas. Burma has rejected charges of ethnic
cleansing and genocide, and has chosen not to work with
the UN Fact Finding Mission or the ICC. In March 2018,
President HTIN KYAW announced his voluntary retirement;
NLD parliamentarian WIN MYINT was named by the
parliament as his successor. In February 2019, the NLD
announced it would establish a parliamentary committee to
examine options for constitutional reform ahead of national
the elections planned for 2020.
Background: Most Cambodians consider themselves to be
Khmers, descendants of the Angkor Empire that extended
over much of Southeast Asia and reached its zenith
between the 10th and 13th centuries. Attacks by the Thai
and Cham (from present-day Vietnam) weakened the
empire, ushering in a long period of decline. The king
placed the country under French protection in 1863, and it
became part of French Indochina in 1887. Following
Japanese occupation in World War II, Cambodia gained full
independence from France in 1953. In April 1975, after a
seven-year struggle, communist Khmer Rouge _ forces
captured Phnom Penh and evacuated all cities and towns.
At least 1.5 million Cambodians died from execution, forced
hardships, or starvation during the Khmer Rouge regime
under POL POT. A December 1978 Vietnamese invasion
drove the Khmer Rouge into the countryside, began a 10-
year Vietnamese occupation, and touched off 20 years of
civil war.
The 1991 Paris Peace Accords mandated democratic
elections and a cease-fire, which was not fully respected by
the Khmer Rouge. UN-sponsored elections in 1993 helped
restore some semblance of normalcy under a coalition
government. Factional fighting in 1997 ended the first
coalition government, but a second round of national
elections in 1998 led to the formation of another coalition
government and renewed political stability. The remaining
elements of the Khmer Rouge surrendered in early 1999.
Some of the surviving Khmer Rouge leaders were tried for
crimes against humanity by a hybrid UN-Cambodian
tribunal supported by international assistance. In 2018, the
tribunal heard its final cases, but it remains in operation to
hear appeals. Elections in July 2003 were relatively
peaceful, but it took one year of negotiations between
contending political parties before a coalition government
was formed. In October 2004, King Norodom SIHANOUK
abdicated the throne and his son, Prince Norodom
SIHAMONI, was selected to succeed him. Local (Commune
Council) elections were held in Cambodia in 2012, with
little of the violence that preceded prior elections. National
elections in July 2013 were disputed, with the opposition—
the Cambodia National Rescue Party (CNRP)—boycotting
the National Assembly. The political impasse was ended
nearly a year later, with the CNRP agreeing to enter
parliament in exchange for commitments by the ruling
Cambodian People’s Party (CPP) to electoral and legislative
reforms. The CNRP made further gains in local commune
elections in June 2017, accelerating sitting Prime Minister
Hun SEN’s efforts to marginalize the CNRP before national
elections in 2018. Hun Sen arrested CNRP President Kem
SOKHA in September 2017. The Supreme Court dissolved
the CNRP in November 2017 and banned its leaders from
participating in politics for at least five years. The CNRP’s
seats in the National Assembly were redistributed to
smaller, less influential opposition parties, while all of the
CNRP’s 5,007 seats in the commune councils throughout
the country were reallocated to the CPP. With the CNRP
banned, the CPP swept the 2018 national elections,
winning all 125 National Assembly seats and effectively
turning the country into a one-party state.','c267957fed45ff2e6c957a650b7aae84328ee3b02236e656e8ceff08056e04f6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec4058861da2a21b0fe9b9356e78fa5647c6b5529621c3ac759e5328b8754bd5',2020,'CV','Cabo Verde','introduction',266,'Background: The uninhabited islands were discovered and
colonized by the Portuguese in the 15th century; Cabo
Verde subsequently became a trading center for African
slaves and later an important coaling and resupply stop for
whaling and transatlantic shipping. The fusing of European
and various African cultural traditions is reflected in Cabo
Verde’s Krioulo language, music, and pano textiles.
Following independence in 1975, and a tentative interest in
unification with Guinea-Bissau, a one-party system was
established and maintained until multi-party elections were
held in 1990. Cabo Verde continues to sustain one of
Africa’s most stable democratic governments and one of its
most stable economies, maintaining a currency formerly
pegged to the Portuguese escudo and then the euro since
1998. Repeated droughts during the second half of the 20th
century caused significant hardship and prompted heavy
emigration. As a result, Cabo Verde’s expatriate population-
concentrated in Boston and Western Europe—is greater
than its domestic one. Most Cabo Verdeans have both
African and Portuguese antecedents. Cabo Verde’s
population descends from its first permanent inhabitants in
the late 15th-century—a preponderance of West African
slaves, a small share of Portuguese colonists, and even
fewer Italians, Spaniards, and Portuguese Jews. Among the
nine inhabited islands, population distribution is variable.
Islands in the east are very dry and are home to the
country’s growing tourism industry. The more western
islands receive more precipitation and support larger
populations, but agriculture and livestock grazing have
damaged their soil fertility and vegetation. For centuries,
the country’s overall population size has _ fluctuated
significantly, as recurring periods of famine and epidemics
have caused high death tolls and emigration.','eede08870a6a56c0c1b878d01b9e45b77dc055e1db35fe4398ebedb0b951699b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83c891ffe6cec6743468d7c7133a1250fc2d892b1931dcfb4551d4c2f9fcadec',2020,'NG','Nigeria','introduction',279,'Background: French Cameroon became independent in 1960
as the Republic of Cameroon. The following year the
southern portion of neighboring British Cameroon voted to
merge with the new country to form the Federal Republic
of Cameroon. In 1972, a new constitution replaced the
federation with a unitary state, the United Republic of
Cameroon. The country has generally enjoyed stability,
which has enabled the development of agriculture, roads,
and railways, as well as a petroleum industry. Despite slow
movement toward democratic reform, political power
remains firmly in the hands of President Paul BIYA.
Background: Equatorial Guinea gained independence in 1968
after 190 years of Spanish rule; it is one of the smallest
countries in Africa consisting of a mainland territory and
five inhabited islands. The capital of Malabo is located on
the island of Bioko, approximately 25 km from the
Cameroonian coastline in the Gulf of Guinea. Between 1968
and 1979, autocratic President Francisco MACIAS
NGUEMA virtually destroyed all of the country’s political,
economic, and social institutions before being deposed by
his nephew Teodoro OBIANG NGUEMA MBASOGO in a
coup. President OBIANG has ruled since October 1979. He
has been elected several times since 1996, and was most
recently reelected in 2016. Although nominally a
constitutional democracy since 1991, presidential and
legislative elections since 1996 have generally been labeled
as flawed. The president exerts almost total control over
the political system and has placed legal and bureaucratic
barriers that hinder political opposition. Equatorial Guinea
has experienced rapid economic growth due to the
discovery of large offshore oil reserves, and in the last
decade had become Sub-Saharan Africa’s third largest oil
exporter, though in 2018 it slipped to 5th place. Despite the
country’s economic windfall from oil production, resulting
in a massive increase in government revenue in recent
years, the drop in global oil prices has placed significant
strain on the state budget. The country has been in
recession since 2014. Oil revenues have mainly been used
for the development of infrastructure and there have been
limited improvements in the population’s living standards.
Equatorial Guinea continues to seek to diversify its
economy and to increase foreign investment. The country
hosts major regional and international conferences and
continues to seek a greater role in international affairs, and
leadership in the sub-region.
Background: Niger became independent from France in 1960
and experienced single-party and military rule until 1991,
when Gen. Ali SAIBOU was forced by public pressure to
allow multiparty elections, which resulted in a democratic
government in 1993. Political infighting brought the
government to a standstill and in 1996 led to a coup by Col.
Ibrahim BARE. In 1999, BARE was killed in a counter coup
by military officers who restored democratic rule and held
elections that brought Mamadou TANDJA to power in
December of that year. TANDJA was reelected in 2004 and
in 2009 spearheaded a constitutional amendment allowing
him to extend his term as president. In February 2010,
military officers led a coup that deposed TANDJA and
suspended the constitution. ISSOUFOU Mahamadou was
elected in April 2011 following the coup and reelected to a
second term in early 2016. Niger is one of the poorest
countries in the world with minimal government services
and insufficient funds to develop its resource base, and is
ranked last in the world on the United Nations
Development Programme’s Human Development Index. The
largely agrarian and _ subsistence-based economy is
frequently disrupted by extended droughts common to the
Sahel region of Africa. The Nigerien Government continues
its attempts to diversify the economy through increased oil
production and mining projects. A Tuareg rebellion
emerged in 2007 and ended in 2009. Niger is facing
increased security concerns on its borders from various
external threats including insecurity in Libya, spillover
from the conflict in Mali, and violent extremism in
northeastern Nigeria.
Background: British influence and control over what would
become Nigeria and Africa’s most populous country grew
through the 19th century. A series of constitutions after
World War II granted Nigeria greater autonomy. After
independence in 1960, politics were marked by coups and
mostly military rule, until the death of a military head of
state in 1998 allowed for a political transition. In 1999, a
new constitution was adopted and a peaceful transition to
civilian government was completed. The government
continues to face the daunting task of institutionalizing
democracy and reforming a petroleum-based economy,
whose revenues have been squandered through corruption
and mismanagement. In addition, Nigeria continues to
experience longstanding ethnic and religious tensions.
Although both the 2003 and 2007 presidential elections
were marred by significant irregularities and violence,
Nigeria is currently experiencing its longest period of
civilian rule since independence. The general elections of
2007 marked the first civilian-to-civilian transfer of power
in the country’s history and the elections of 2011 were
generally regarded as credible. The 2015 election was
heralded for the fact that the then-umbrella opposition
party, the All Progressives Congress, defeated the long-
ruling People’s Democratic Party that had governed since
1999 and assumed the presidency after a peaceful transfer
of power. Successful presidential and legislative elections
were held in early 2019.
Background: Niue’s remoteness, as well as cultural and
linguistic differences between its Polynesian inhabitants
and those of the adjacent Cook Islands, has caused it to be
separately administered by New Zealand. The population of
the island has trended downwards over recent decades
(from a peak of 5,200 in 1966 to 1,618 in 2017) with
substantial emigration to New Zealand 2,400 km to the
southwest.
Background: French Togoland became Togo in 1960. Gen.
Gnassingbe EYADEMA, installed as military ruler in 1967,
ruled Togo with a heavy hand for almost four decades.
Despite the facade of multi-party elections instituted in the
early 1990s, the government was largely dominated by
President EYADEMA, whose Rally of the Togolese People
(RPT) party has been in power almost continually since
1967 and its successor, the Union for the Republic,
maintains a majority of seats in today’s legislature. Upon
EYADEMA’s death in February 2005, the military installed
the president’s son, Faure GNASSINGBE, and _ then
engineered his formal election two months later.
Democratic gains since then allowed Togo to hold its first
relatively free and fair legislative elections in October
2007. Since 2007, President GNASSINGBE has started the
country along a gradual path to democratic reform. Togo
has since held multiple presidential and _ legislative
elections deemed generally free and fair by international
observers. Despite those’ positive moves, political
reconciliation has moved slowly, and the _ country
experiences periodic outbursts of violent protest by
frustrated citizens. Recent constitutional changes to
institute a runoff system in presidential elections and
establish term limits has not reduced the resentment many
Togolese feel after over 50 years of one-family rule.','9e3191fc9b43f87f1007ec810f683f41125ad2866b1217eef39c2a4f12d38148','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c91f498351cb89babdc74798ff1f6b4faea48f968b89ccf75df03085c1198c57',2020,'CA','Canada','introduction',292,'Background: A land of vast distances and rich natural
resources, Canada became a self-governing dominion in
1867, while retaining ties to the British crown. Canada
repatriated its constitution from the UK in 1982, severing a
final colonial tie. Economically and technologically, the
nation has developed in parallel with the US, its neighbor
to the south across the world’s longest international border.
Canada faces the political challenges of meeting public
demands for quality improvements in health care,
education, social services, and economic competitiveness,
as well as responding to the particular concerns of
predominantly francophone Quebec. Canada also aims to
develop its diverse energy resources while maintaining its
commitment to the environment.','2fdd91f02bf59c8934ec1307ea7407162e570e293b3ee36b06377d4f75a1cebd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d7301f93456ace8ee1742c7d51ccce29beaafd5e54109173b17f4be26c392f5',2020,'KY','Cayman Islands','introduction',300,'Background: The Cayman Islands were colonized from
Jamaica by the British during the 18th and 19th centuries
and were administered by Jamaica after 1863. In 1959, the
islands became a territory within the Federation of the
West Indies. When the Federation dissolved in 1962, the
Cayman Islands chose to remain a British dependency. The
territory has transformed itself into a significant offshore
financial center.','870ce6759df6b9a0641abc4a93c5a4d7b3c734046d3262aa52670db9a390342c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96dc8e8c2b80e4d5fad24beb0c0e1672e9823567d9d2b5713f3fccd6678e3ff2',2020,'CG','Congo','introduction',307,'Background: The former French colony of Ubangi-Shari
became the Central African Republic upon independence in
1960. After three tumultuous decades of misrule-mostly by
military governments-civilian rule was established in 1993
but lasted only a decade. In March 2003, President Ange-
Felix PATASSE was deposed in a military coup led by
General Francois BOZIZE, who established a transitional
government. Elections held in 2005 affirmed General
BOZIZE as president; he was reelected in 2011 in voting
widely viewed as flawed. The government still lacks full
control of the countryside, where lawlessness persists.
Several rebel groups joined together in early December
2012 to launch a series of attacks that left them in control
of numerous towns in the northern and central parts of the
country. The rebels—unhappy with BOZIZE’s government—
participated in peace talks in early January 2013 which
resulted in a coalition government including the rebellion’s
leadership. In March 2013, the coalition government
dissolved, rebels seized the capital, and President BOZIZE
fled the country. Rebel leader Michel DJOTODIA assumed
the presidency and the following month established a
National Transitional Council (CNT). In January 2014, the
CNT elected Catherine SAMBA-PANZA as_ interim
president. Elections completed in March 2016 installed
independent candidate Faustin-Archange TOUADERA as
president; he continues to work towards peace between the
government and armed groups, and is developing a
disarmament, demobilization, reintegration, and
repatriation program to reintegrate the armed groups into
society.
Background: In 1959, three years before independence from
Belgium, the majority ethnic group, the Hutus, overthrew
the ruling Tutsi king. Over the next several years,
thousands of Tutsis were killed, and some 150,000 driven
into exile in neighboring countries. The children of these
exiles later formed a rebel group, the Rwandan Patriotic
Front (RPF), and began a civil war in 1990. The war, along
with several political and economic upheavals, exacerbated
ethnic tensions, culminating in April 1994 in a state-
orchestrated genocide, in which Rwandans killed
approximately 800,000 of their fellow citizens, including
approximately three-quarters of the Tutsi population. The
genocide ended later that same year when _ the
predominantly Tutsi RPF, operating out of Uganda and
northern Rwanda, defeated the national army and Hutu
militias, and established an RPF-led government of national
unity. Rwanda held its first local elections in 1999 and its
first post-genocide presidential and legislative elections in
2003. Rwanda joined the Commonwealth in late 2009.
President Paul KAGAME won the presidential election in
August 2017 after changing the constitution in 2016 to
allow him to run for a third term.
Background: Discovered in 1493 by Christopher COLUMBUS
who named it for his brother Bartolomeo, Saint Barthelemy
was first settled by the French in 1648. In 1784, the French
sold the island to Sweden, which renamed the largest town
Gustavia, after the Swedish King GUSTAV III, and made it a
free port; the island prospered as a trade and supply center
during the colonial wars of the 18th century. France
repurchased the island in 1877 and took control the
following year. It was placed under the administration of
Guadeloupe. Saint Barthelemy retained its free port status
along with various Swedish appellations such as Swedish
street and town names, and the three-crown symbol on the
coat of arms. In 2003, the islanders voted to secede from
Guadeloupe, and in 2007, the island became a French
overseas collectivity. In 2012, it became an overseas
territory of the EU, allowing it to exert local control over
the permanent and temporary immigration of foreign
workers including non-French European citizens.
Background: Saint Helena is a British Overseas Territory
consisting of Saint Helena and Ascension Islands, and the
island group of Tristan da Cunha.
Saint Helena: Uninhabited when first discovered by the
Portuguese in 1502, Saint Helena was garrisoned by the
British during the 17th century. It acquired fame as the
place of Napoleon BONAPARTE’s exile from 1815 until his
death in 1821, but its importance as a port of call declined
after the opening of the Suez Canal in 1869. During the
Anglo-Boer War in South Africa, several thousand Boer
prisoners were confined on the island between 1900 and
1903.; Saint Helena is one of the most remote populated
places in the world. The British Government committed to
building an airport on Saint Helena in 2005. After more
than a decade of delays and construction, a commercial air
service to South Africa via Namibia was inaugurated in
October of 2017. The weekly service to Saint Helena from
Johannesburg via Windhoek in Namibia takes just over six
hours (including the refueling stop in Windhoek) and
replaces the mail ship that had made a five-day journey to
the island every three weeks.
Ascension Island: This barren and uninhabited island was
discovered and named by the Portuguese in 1503. The
British garrisoned the island in 1815 to prevent a rescue of
Napoleon from Saint Helena. It served as a provisioning
station for the Royal Navy’s West Africa Squadron on anti-
slavery patrol. The island remained under Admiralty
control until 1922, when it became a dependency of Saint
Helena. During World War II, the UK permitted the US to
construct an airfield on Ascension in support of
transatlantic flights to Africa and _ anti-submarine
operations in the South Atlantic. In the 1960s the island
became an important space tracking station for the US. In
1982, Ascension was an essential staging area for British
forces during the Falklands War. It remains a critical
refueling point in the air-bridge from the UK to the South
Atlantic.; The island hosts one of four dedicated ground
antennas that assist in the operation of the Global
Positioning System (GPS) navigation system (the others are
on Diego Garcia (British Indian Ocean Territory), Kwajalein
(Marshall Islands), and at Cape Canaveral, Florida (US)).
NASA and the US Air Force also operate a Meter-Class
Autonomous Telescope (MCAT) on Ascension as part of the
deep space surveillance system for tracking orbital debris,
which can be a hazard to spacecraft and astronauts.
Tristan da Cunha: The island group consists of Tristan da
Cunha, Nightingale, Inaccessible, and Gough Islands.
Tristan da Cunha, named after its Portuguese discoverer
(1506), was garrisoned by the British in 1816 to prevent
any attempt to rescue Napoleon from Saint Helena. Gough
and Inaccessible Islands have been designated World
Heritage Sites. South Africa leases a_ site for a
meteorological station on Gough Island.','0e3f7af1c333d36979398dd2319200233028f5213f9236956b3a85d31a2a6eae','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0b0f83efb5a10d2de2ef158278eab6c53df6beeeed49aace2720d79ed83e6e5',2020,'TD','Chad','introduction',318,'Background: Chad, part of France’s African holdings until
1960, endured three decades of civil warfare, as well as
invasions by Libya, before peace was restored in 1990. The
government eventually drafted a democratic constitution
and held flawed presidential elections in 1996 and 2001. In
1998, a rebellion broke out in northern Chad, which has
sporadically flared up despite several peace agreements
between the government and insurgents. In June 2005,
President Idriss DEBY held a referendum successfully
removing constitutional term limits and won another
controversial election in 2006. Sporadic rebel campaigns
continued throughout 2006 and 2007. The _ capital
experienced a significant insurrection in early 2008, but
has had no significant rebel threats since then, in part due
to Chad’s 2010 rapprochement with Sudan, which
previously used Chadian rebels as proxies. Nevertheless, a
state of emergency continues to be in place in the Sila and
Ouaddai regions bordering Sudan. In late 2015, the
government imposed a state of emergency in the Lake
Chad region following multiple attacks by the terrorist
group Boko Haram throughout the year; Boko Haram also
launched several bombings in N’Djamena in mid-2015. A
state of emergency is also emplaced in the western Tibesti
region bordering Niger where rival ethnic groups are
fighting. DEBY in 2016 was reelected to his fifth term in an
election that was peaceful but flawed. In December 2015,
Chad completed a two-year rotation on the UN Security
Council. In January 2017, DEBY completed a one-year term
as Chairperson of the African Union Assembly. (2019)','e50d3ab716029941f3020eda7730678f8ff346f1c0a53182bb26c7e65c29b952','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0df6801cd41ed3c11b6bd6d20de12d6493af9e90bf1cdca180160a2d5379bf9',2020,'CL','Chile','introduction',325,'Background: Prior to the arrival of the Spanish in the 16th
century, the Inca ruled northern Chile for nearly a century
while an indigenous people, the Mapuche, inhabited central
and southern Chile. Although Chile’ declared its
independence in 1810, it did not achieve decisive victory
over the Spanish until 1818. In the War of the Pacific (1879-
83), Chile defeated Peru and Bolivia to win its present
northern regions. In the 1880s, the Chilean central
government gained control over the central and southern
regions inhabited by the Mapuche. After a series of elected
governments, the three-year-old Marxist government of
Salvador ALLENDE was overthrown in 1973 by a military
coup led by General Augusto PINOCHET, who ruled until a
democratically-elected president was inaugurated in 1990.
Economic reforms, maintained consistently since the
1980s, contributed to steady growth, reduced poverty rates
by over half, and helped secure the country’s commitment
to democratic and representative government. Chile has
increasingly assumed regional and international leadership
roles befitting its status as a stable, democratic nation.','d8674a3411c64a8f5f83ace298b57e0b049ca0d7427e2d50de1f282ac4bb5bc7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36f249443dbe987ba86cba58b91f1fc9d20e019f2aa9a2b066297ee1dad0e8da',2020,'AQ','Antarctica','introduction',330,'Background: China’s historical civilization dates from at least
1200 B.C.; from the 3rd century B.C. and for the next two
millennia, China alternated between periods of unity and
disunity under a succession of imperial dynasties. In the
19th and early 20th centuries, the country was beset by
civil unrest, major famines, military defeats, and foreign
occupation. After World War II, the Chinese Communist
Party under MAO Zedong established an autocratic
socialist system that, while ensuring China’s sovereignty,
imposed strict controls over everyday life and cost the lives
of tens of millions of people. After 1978, MAO’s successor
DENG Xiaoping and other leaders focused on market-
oriented economic development and by 2000 output had
quadrupled. For much of the population, living standards
have improved dramatically but political controls remain
tight. Since the early 1990s, China has increased its global
outreach and participation in international organizations.','82eed059c6772a912ffd893c3579c50fa165b06337c548bec3145e6f229540f9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5a394e26b8d80dbd9897cfa49df196898f957236e94841dd690ad2e64743702',2020,'CN','China','introduction',342,'Background: Although Europeans had sighted the island at
least as early as 1615, it was only named in 1643 for the
day of its rediscovery. The island was annexed and
settlement began by the UK in 1888 with the discovery of
the island’s phosphate deposits. Following the Second
World War, Christmas Island came under the jurisdiction of
the new British Colony of Singapore. The island existed as
a separate Crown colony from 1 January 1958 to 1 October
1958 when its transfer to Australian jurisdiction was
finalized. That date is still celebrated on the first Monday in
October as Territory Day. Almost two-thirds of the island
has been declared a national park.
Background: This isolated atoll was named for John
CLIPPERTON, an English pirate who was rumored to have
made it his hideout early in the 18th century. Annexed by
France in 1855 and claimed by the US, it was seized by
Mexico in 1897. Arbitration eventually awarded the island
to France in 1931, which took possession in 1935.
Background: Hungary became a Christian kingdom in A.D.
1000 and for many centuries served as a bulwark against
Ottoman Turkish expansion in Europe. The kingdom
eventually became part of the polyglot Austro-Hungarian
Empire, which collapsed during World War I. The country
fell under communist rule following World War II. In 1956,
a revolt and an announced withdrawal from the Warsaw
Pact were met with a massive military intervention by
Moscow. Under the leadership of Janos KADAR in 1968,
Hungary began liberalizing its economy, introducing so-
called “Goulash Communism.” Hungary held its first
multiparty elections in 1990 and initiated a free market
economy. It joined NATO in 1999 and the EU five years
later.
Background: Settled by Norwegian and Celtic (Scottish and
Irish) immigrants during the late 9th and 10th centuries
A.D., Iceland boasts the world’s oldest functioning
legislative assembly, the Althingi, established in 930.
Independent for over 300 years, Iceland was subsequently
ruled by Norway and Denmark. Fallout from the Askja
volcano of 1875 devastated the Icelandic economy and
caused widespread famine. Over the next quarter century,
20% of the island’s population emigrated, mostly to Canada
and the US. Denmark granted limited home rule in 1874
and complete independence in 1944. The second half of the
20th century saw substantial economic growth driven
primarily by the fishing industry. The economy diversified
greatly after the country joined the European Economic
Area in 1994, but Iceland was especially hard hit by the
global financial crisis in the years following 2008. The
economy is now on an upward trajectory, fueled primarily
by a tourism and construction boom. Literacy, longevity,
and social cohesion are first rate by world standards.
Background: The Indus Valley civilization, one of the world’s
oldest, flourished during the 3rd and 2nd millennia B.C.
and extended into northwestern India. Aryan tribes from
the northwest infiltrated the Indian subcontinent about
1500 B.C.; their merger with the earlier Dravidian
inhabitants created the classical Indian culture. The
Maurya Empire of the 4th and 3rd centuries B.C.—which
reached its zenith under ASHOKA—united much of South
Asia. The Golden Age ushered in by the Gupta dynasty (4th
to 6th centuries A.D.) saw a flowering of Indian science,
art, and culture. Islam spread across the subcontinent over
a period of 700 years. In the 10th and 11th centuries, Turks
and Afghans invaded India and established the Delhi
Sultanate. In the early 16th century, the Emperor BABUR
established the Mughal Dynasty, which ruled India for more
than three centuries. European explorers began
establishing footholds in India during the 16th century.
By the 19th century, Great Britain had become the
dominant political power on the subcontinent and India was
seen as the “Jewel in the Crown” of the British Empire. The
British Indian Army played a vital role in both World Wars.
Years of nonviolent resistance to British rule, led by
Mohandas GANDHI and Jawaharlal NEHRU, eventually
resulted in Indian independence in 1947. Large-scale
communal violence took place before and after the
subcontinent partition into two separate states—India and
Pakistan. The neighboring countries have fought three wars
since independence, the last of which was in 1971 and
resulted in East Pakistan becoming the separate nation of
Bangladesh. India’s nuclear weapons tests in 1998
emboldened Pakistan to conduct its own tests that same
year. In November 2008, terrorists originating from
Pakistan conducted a series of coordinated attacks in
Mumbai, India’s financial capital. India’s economic growth
following the launch of economic reforms in 1991, a
massive youthful population, and a strategic geographic
location have contributed to India’s emergence as a
regional and global power. However, India still faces
pressing problems such as environmental degradation,
extensive poverty, and widespread corruption, and _ its
restrictive business climate is dampening economic growth
expectations.
Background: The Indian Ocean is the third largest of the
world’s five oceans (after the Pacific Ocean and Atlantic
Ocean, but larger than the Southern Ocean and Arctic
Ocean). Four critically important access waterways are the
Suez Canal (Egypt), Bab el Mandeb (Djibouti-Yemen), Strait
of Hormuz (Iran-Oman), and Strait of Malacca (Indonesia-
Malaysia).The decision by the International Hydrographic
Organization in the spring of 2000 to delimit a fifth ocean,
the Southern Ocean, removed the portion of the Indian
Ocean south of 60 degrees south latitude.
Background: The Dutch began to colonize Indonesia in the
early 17th century; Japan occupied the islands from 1942 to
1945. Indonesia declared its independence shortly before
Japan’s surrender, but it required four years of sometimes
brutal fighting, intermittent negotiations, and UN
mediation before the Netherlands agreed to transfer
sovereignty in 1949. A period of sometimes’ unruly
parliamentary democracy ended in 1957 when President
SOEKARNO declared martial law and instituted “Guided
Democracy.” After an abortive coup in 1965 by alleged
communist sympathizers, SOEKARNO was gradually eased
from power. From 1967 until 1998, President SUHARTO
ruled Indonesia with his “New Order” government. After
street protests toppled SUHARTO in 1998, free and fair
legislative elections took place in 1999. Indonesia is now
the world’s third most populous democracy, the world’s
largest archipelagic state, and the world’s largest Muslim-
majority nation. Current issues include: alleviating poverty,
improving education, preventing terrorism, consolidating
democracy after four decades of authoritarianism,
implementing economic and financial reforms, stemming
corruption, reforming the criminal justice system,
addressing climate change, and controlling infectious
diseases, particularly those of global and_ regional
importance. In 2005, Indonesia reached a historic peace
agreement with armed separatists in Aceh, which led to
democratic elections in Aceh in December 2006. Indonesia
continues to face low intensity armed resistance in Papua
by the separatist Free Papua Movement.
Background: Known as Persia until 1935, Iran became an
Islamic republic in 1979 after the ruling monarchy was
overthrown and Shah Mohammad Reza PAHLAVI was
forced into exile. Conservative clerical forces led by
Ayatollah Ruhollah KHOMEINI established a theocratic
system of government with ultimate political authority
vested in a learned religious scholar referred to commonly
as the Supreme Leader who, according to the constitution,
is accountable only to the Assembly of Experts (AOE)—a
popularly elected 88-member body of clerics. US-Iranian
relations became strained when a group of Iranian students
seized the US Embassy in Tehran in November 1979 and
held embassy personnel hostages until mid-January 1981.
The US cut off diplomatic relations with Iran in April 1980.
During the period 1980-88, Iran fought a bloody, indecisive
war with Iraq that eventually expanded into the Persian
Gulf and led to clashes between US Navy and Iranian
military forces. Iran has been designated a state sponsor of
terrorism and was subject to US, UN, and EU economic
sanctions and export controls because of its continued
involvement in terrorism and concerns over possible
military dimensions of its nuclear program until Joint
Comprehensive Plan of Action (J/CPOA) Implementation Day
in 2016. The US began gradually re-imposing sanctions on
Iran after the US withdrawal from JCPOA in May 2018.
Following the election of reformer Hojjat ol-Eslam
Mohammad KHATAMI as president in 1997 and a reformist
Majles (legislature) in 2000, a campaign to foster political
reform in response to popular dissatisfaction was initiated.
The movement floundered as conservative politicians,
supported by the Supreme Leader, unelected institutions of
authority like the Council of Guardians, and the security
services reversed and blocked reform measures while
increasing security repression. Starting with nationwide
municipal elections in 2003 and continuing through Majles
elections in 2004, conservatives reestablished control over
Iran’s elected government institutions, which culminated
with the August 2005 inauguration of hardliner Mahmud
AHMADI-NEJAD as president. His controversial reelection
in June 2009 sparked nationwide protests over allegations
of electoral fraud, but the protests were quickly
suppressed. Deteriorating economic conditions due
primarily to government mismanagement and international
sanctions prompted at least two major economically based
protests in July and October 2012, but Iran’s internal
security situation remained stable. President AHMADI-
NEJAD’s independent streak angered regime establishment
figures, including the Supreme Leader, leading to
conservative opposition to his agenda for the last year of
his presidency, and an alienation of his political supporters.
In June 2013 Iranians elected a centrist cleric Dr. Hasan
Fereidun ROHANI to the presidency. He is a longtime
senior member in the regime, but has made promises of
reforming society and Iran’s foreign policy. The UN
Security Council has passed a number of resolutions calling
for Iran to suspend its uranium enrichment and
reprocessing activities and comply with its IAEA obligations
and responsibilities, and in July 2015 Iran and the five
permanent members, plus Germany (P5+1) signed the
JCPOA under which Iran agreed to restrictions on its
nuclear program in exchange for sanctions relief. Iran held
elections in 2016 for the AOE and Majles, resulting in a
conservative-controlled AOE and a Majles that many
Iranians perceive aS more supportive of the ROHANI
administration than the previous, conservative-dominated
body. ROHANI was reelected president in May 2017.
Economic concerns once again led to nationwide protests
in December 2017 and January 2018 but they were
contained by Iran’s’ security’ services. Additional
widespread economic protests broke out in November 2019
in response to the raised price of subsidized gasoline.
Background: Formerly part of the Ottoman Empire, Iraq was
occupied by the United Kingdom during World War I and
was declared a League of Nations mandate under UK
administration in 1920. Iraq attained its independence as a
kingdom in 1932. It was proclaimed a “republic” in 1958
after a coup overthrew the monarchy, but in actuality, a
series of strongmen ruled the country until 2003. The last
was SADDAM Husayn from 1979 to 2003. Territorial
disputes with Iran led to an inconclusive and costly eight-
year war (1980-88). In August 1990, Iraq seized Kuwait but
was expelled by US-led UN coalition forces during the Gulf
War of January-February 1991. After Iraq’s expulsion, the
UN Security Council (UNSC) required Irag to scrap all
weapons of mass destruction and long-range missiles and
to allow UN verification inspections. Continued Iraqi
noncompliance with UNSC resolutions led to the Second
Gulf War in March 2003 and the ouster of the SADDAM
Husayn regime by US-led forces.
In October 2005, Iragis approved a constitution in a
national referendum and, pursuant to this document,
elected a 275-member Council of Representatives (COR) in
December 2005. The COR approved most cabinet ministers
in May 2006, marking the transition to lIraq’s first
constitutional government in nearly a half century. Iraq
held elections for provincial councils in all governorates in
January 2009 and April 2013 and postponed the next
provincial elections, originally planned for April 2017, until
2019. Irag has held three national legislative elections
since 2005, most recently in May 2018 when 329
legislators were elected to the COR. Adil ABD AL-MAHDI
assumed the premiership in October 2018 as a consensus
and independent candidate—the first prime minister who is
not an active member of a major political bloc. However,
widespread protests that began in October 2019
demanding more employment opportunities and an end to
corruption prompted ABD AL-MAHDI to announce his
resignation on 20 November 2019.
Between 2014 and 2017, Iraq was engaged in a military
Campaign against the Islamic State of Iraq and ash-Sham
(ISIS) to recapture territory lost in the western and
northern portion of the country. Iragi and allied forces
recaptured Mosul, the country’s second-largest city, in
2017 and drove ISIS out of its other urban strongholds. In
December 2017, then-Prime Minister Haydar al-ABADI
publicly declared victory against ISIS while continuing
operations against the group’s residual presence in rural
areas. Also in late 2017, ABADI responded to an
independence referendum held by the Kurdistan Regional
Government by ordering Iraqi forces to take control of
disputed territories across central and northern Iraq that
were previously occupied and governed by Kurdish forces.','0e84380b09ddfc1636a9aca262a5b9be5d062350da5c424aa4c8b83b14ca9c9b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('657b24b1da8d4cfab7f1b12af38c2da287ed3880143cc037dc2d535c7698fc65',2020,'CC','Cocos (Keeling) Islands','introduction',348,'Background: There are 27 coral islands in the group. Captain
William KEELING discovered the islands in 1609, but they
remained uninhabited until the 19th century. From the
1820s to 1978, members of the CLUNIES-ROSS family
controlled the islands and the copra produced from local
coconuts. Annexed by the UK in 1857, the Cocos Islands
were transferred to the Australian Government in 1955.
Apart from North Keeling Island, which lies 30 kilometers
north of the main group, the islands form a horseshoe-
shaped atoll surrounding a lagoon. North Keeling Island
was declared a national park in 1995 and is administered
by Parks Australia. The population on the two inhabited
islands generally is split between the ethnic Europeans on
West Island and the ethnic Malays on Home Island.','e888352f183c249175cabf83f546f8544ccd09ce74417c6ebbb8ffc3be819fa4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2bcd2245bd03e7c306e72b9ffa6c1078203498789fa3e8c46bf82999b5c7356',2020,'AO','Angola','introduction',356,'Background: Established as an official Belgian colony in
1908, the then-Republic of the Congo gained _ its
independence in 1960, but its early years were marred by
political and social instability. Col. Joseph MOBUTU seized
power and declared himself president in a November 1965
coup. He subsequently changed his name—to MOBUTU
Sese Seko—as well as that of the country—to Zaire.
MOBUTU retained his position for 32 years through several
sham elections, as well as through brutal force. Ethnic
strife and civil war, touched off by a massive inflow of
refugees in 1994 from conflict in Rwanda and Burundi, led
in May 1997 to the toppling of the MOBUTU regime by a
rebellion backed by Rwanda and Uganda and fronted by
Laurent KABILA. KABILA renamed the country the
Democratic Republic of the Congo (DRC), but in August
1998 his regime was itself challenged by a _ second
insurrection again backed by Rwanda and Uganda. Troops
from Angola, Chad, Namibia, Sudan, and Zimbabwe
intervened to support KABILA’s regime. In January 2001,
KABILA was assassinated and his son, Joseph KABILA, was
named head of state. In October 2002, the new president
was successful in negotiating the withdrawal of Rwandan
forces occupying the eastern DRC; two months later, the
Pretoria Accord was signed by all remaining warring
parties to end the fighting and establish a government of
national unity. Presidential, National Assembly, and
provincial legislatures took place in 2006, with Joseph
KABILA elected to office.
National elections were held in November 2011 and
disputed results allowed Joseph KABILA to be reelected to
the presidency. While the DRC constitution barred
President KABILA from running for a third term, the DRC
Government delayed national elections originally slated for
November 2016, to 30 December 2018. This failure to hold
elections as scheduled fueled significant civil and political
unrest, with sporadic street protests by KABILA’s
opponents and exacerbation of tensions in the tumultuous
eastern DRC_ regions. Presidential, legislative, and
provincial elections were held in late December 2018 and
early 2019 across most of the country. The DRC
Government canceled presidential elections in the cities of
Beni and Butembo (citing concerns over an ongoing Ebola
outbreak in the region) as well as Yumbi (which had
recently experienced heavy violence).
Opposition candidate Felix TSHISEKEDI was announced
the election winner on 10 January 2019 and inaugurated
two weeks later. This was the first transfer of power to an
opposition candidate without significant violence or a coup
since the DRC’s independence.
The DRC, particularly in the East, continues to
experience violence perpetrated by more than 100 armed
groups active in the region, including the Allied Democratic
Forces (ADF), the Democratic Forces for the Liberation of
Rwanda (FDLR), and assorted Mai Mai militias. The UN
Organization Stabilization Mission in the DRC (MONUSCO)
has operated in the region since 1999 and is the largest
and most expensive UN peacekeeping mission in the world.
Background: Namibia gained independence in 1990. Prior to
independence, apartheid South Africa occupied the former
German colony known as South-West Africa during World
War I and administered it as a mandate until after World
War II, when it annexed the territory. In 1966, the Marxist
South-West Africa People’s Organization (SWAPO) guerrilla
group launched a war of independence for the area that
became Namibia, but it was not until 1988 that South
Africa agreed to end its administration in accordance with
a UN peace plan for the entire region. Namibia has been
governed by SWAPO since the country won independence,
though the party has dropped much of its Marxist ideology.
President Hage GEINGOB was elected in 2014 in a
landslide victory, replacing Hifikepunye POHAMBA who
stepped down after serving two terms. SWAPO retained its
parliamentary super majority in the 2014 elections. In 2019
elections, GEINGOB was reelected but by a substantially
reduced majority and SWAPO narrowly lost its super
majority in parliament.','a4bc83a3bb3c205ff6dc9f608cecb2fe0d4cb909a1fd3c9fc8e16ac88a9ef529','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e003490cef0e67e83f3a82a03d4fa0d61395a2eb3fe0bacef6ccab2ece2e6dc6',2020,'CM','Cameroon','introduction',364,'Background: Upon independence in 1960, the former French
region of Middle Congo became the Republic of the Congo.
A quarter century of experimentation with Marxism was
abandoned in 1990 and aé_ democratically elected
government took office in 1992. A two-year civil war that
ended in 1999 restored former Marxist President Denis
SASSOU-Nguesso, who had ruled from 1979 to 1992, and
sparked a short period of ethnic and political unrest that
was resolved by a peace agreement in late 1999. A new
constitution adopted three years later provided for a multi-
party system and a seven-year presidential term, and
elections arranged shortly thereafter installed SASSOU-
Nguesso. Following a year of renewed fighting, President
SASSOU-Nguesso and southern-based rebel groups agreed
to a final peace accord in March 2003. SASSOU-Nguesso
was reeelected in 2009 and, after passing a referendum
allowing him to run for a third term, was reelected again in
2016. The Republic of Congo is one of Africa’s largest
petroleum producers, but with declining production it will
need new offshore oil finds to sustain its oil earnings over
the long term.
Background: The Cook Islands, named after Captain James
Cook who landed in 1773, became a British protectorate in
1888 and was later annexed by proclamation in 1900. The
Cook Islands was first included within the boundaries of
New Zealand in 1901, and in 1965, residents chose self-
government in free association with New Zealand. The
Cook Islands’ economy relies on tourism, fisheries, and
foreign aid. More recently a growing offshore financial
sector exposed the country to vulnerabilities which the
government has addressed with legislation and regulations
for the oversight of all banks and financial institutions, and
with enforcement measures. The Cook Islands continues to
face challenges with the emigration of skilled workers,
government deficits, inadequate infrastructure, and natural
resource depletion. The Cook Islands is expected to
graduate to the high-income threshold set by the World
Bank, which will limit the country’s access to Official
Development Assistance under OECD guidelines.','f33358ca34d2fcf4ed078d5b3304e2e12a249a26550e9256e5820d5ea7f8d34b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1328c9db9b6f45a138ba0cb1915709d57187c0fd516709f87e44bc3b0850624e',2020,'NI','Nicaragua','introduction',369,'Background: Although explored by the Spanish early in the
16th century, initial attempts at colonizing Costa Rica
proved unsuccessful due to a combination of factors,
including disease from mosquito-infested swamps, brutal
heat, resistance by natives, and pirate raids. It was not
until 1563 that a permanent settlement of Cartago was
established in the cooler, fertile central highlands. The area
remained a colony for some two and a half centuries. In
1821, Costa Rica became one of several Central American
provinces that jointly declared their independence from
Spain. Two years later it joined the United Provinces of
Central America, but this federation disintegrated in 1838,
at which time Costa Rica proclaimed its sovereignty and
independence. Since the late 19th century, only two brief
periods of violence have marred the country’s democratic
development. On 1 December 1948, Costa Rica dissolved
its armed forces. Although it still maintains a large
agricultural sector, Costa Rica has expanded its economy to
include strong technology and tourism industries. The
standard of living is relatively high. Land ownership is
widespread.
Background: Once part of Spain’s vast empire in the New
World, Honduras became an independent nation in 1821.
After two and a half decades of mostly military rule, a
freely elected civilian government came to power in 1982.
During the 1980s, Honduras proved a haven for anti-
Sandinista contras fighting the Marxist Nicaraguan
Government and an ally to Salvadoran Government forces
fighting leftist guerrillas. The country was devastated by
Hurricane Mitch in 1998, which killed about 5,600 people
and caused approximately $2 billion in damage. Since then,
the economy has slowly rebounded.
Background: Occupied by the UK in 1841, Hong Kong was
formally ceded by China the following year; various
adjacent lands were added later in the 19th century.
Pursuant to an agreement signed by China and the UK on
19 December 1984, Hong Kong became the Hong Kong
Special Administrative Region of the People’s Republic of
China on 1 July 1997. In this agreement, China promised
that, under its “one country, two systems” formula, China’s
socialist economic system would not be imposed on Hong
Kong and that Hong Kong would enjoy a “high degree of
autonomy” in all matters except foreign and defense affairs
for the subsequent 50 years.','8c30189fc96c48a9620f2a0b29a8f63572a4d0512db282c81827d11bcadfc7aa','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('367a9a5f61053439bc4735f82518ea5e3df2d3f57b74a9dad8029345827a7b50',2020,'HR','Croatia','introduction',391,'Background: The native Amerindian population of Cuba
began to decline after the European discovery of the island
by Christopher COLUMBUS in 1492 and following its
development as a Spanish colony during the next several
centuries. Large numbers of African slaves were imported
to work the coffee and sugar plantations, and Havana
became the launching point for the annual treasure fleets
bound for Spain from Mexico and Peru. Spanish rule
eventually provoked an independence movement and
occasional rebellions were harshly suppressed. US
intervention during the Spanish-American War in 1898
assisted the Cubans in overthrowing Spanish rule. The
Treaty of Paris established Cuban independence from Spain
in 1898 and, following three-and-a-half years of subsequent
US military rule, Cuba became an independent republic in
1902 after which the island experienced a string of
governments mostly dominated by the military and corrupt
politicians. Fidel CASTRO led a rebel army to victory in
1959; his authoritarian rule held the subsequent regime
together for nearly five decades. He stepped down as
president in February 2008 in favor of his younger brother
Raul CASTRO. Cuba’s communist revolution, with Soviet
support, was exported throughout Latin America and Africa
during the 1960s, 1970s, and 1980s. Miguel DIAZ-CANEL
Bermudez, hand-picked by Raul CASTRO to succeed him,
was approved as president by the National Assembly and
took office on 19 April 2018.
The country faced a severe economic downturn in 1990
following the withdrawal of former Soviet subsidies worth
$4-6 billion annually. Cuba traditionally and consistently
portrays the US embargo, in place since 1961, as the
source of its difficulties. As a result of efforts begun in
December 2014 to re-establish diplomatic relations with
the Cuban Government, which were severed in January
1961, the US and Cuba reopened embassies in their
respective countries in July 2015. The embargo remains in
place, and the relationship between the US and Cuba
remains tense.
Illicit migration of Cuban nationals to the US via
maritime and overland routes has been a longstanding
challenge. On 12 January 2017, the US and Cuba signed a
Joint Statement ending the so-called “wet-foot, dry-foot”
policy—by which Cuban nationals who reached US soil
were permitted to stay. Illicit Cuban migration by sea has
since dropped significantly, but land border crossings
continue. In FY 2018, the US Coast Guard interdicted 312
Cuban nationals at sea. Also in FY 2018, 7,249 Cuban
migrants presented themselves at various land border ports
of entry throughout the US.
Background: The original Arawak Indian settlers who arrived
on the island from South America in about 1000, were
largely enslaved by the Spanish early in the 16th century
and forcibly relocated to other colonies where labor was
needed. Curacao was seized by the Dutch from the Spanish
in 1634. Once the center of the Caribbean slave trade,
Curacao was hard hit economically by the abolition of
slavery in 1863. Its prosperity (and that of neighboring
Aruba) was restored in the early 20th century with the
construction of the Isla Refineria to service the newly
discovered Venezuelan oil fields. In 1954, Curacao and
several other Dutch Caribbean possessions were
reorganized as the Netherlands Antilles, part of the
Kingdom of the Netherlands. In referenda in 2005 and
2009, the citizens of Curacao voted to become a self-
governing country within the Kingdom of the Netherlands.
The change in status became effective in October 2010
with the dissolution of the Netherlands Antilles.
Background: The Slovene lands were part of the Austro-
Hungarian Empire until the latter’s dissolution at the end
of World War I. In 1918, the Slovenes joined the Serbs and
Croats in forming a new multinational state, which was
named Yugoslavia in 1929. After World War II, Slovenia was
one of the republics in the restored Yugoslavia, which,
though communist, soon distanced itself from the Soviet
Union and spearheaded the Non-Aligned Movement.
Dissatisfied with the exercise of power by the majority
Serbs, the Slovenes succeeded in establishing their
independence in 1991 after a short 10-day war. Historical
ties to Western Europe, a growing economy, and a stable
democracy have assisted in Slovenia’s postcommunist
transition. Slovenia acceded to both NATO and the EU in
the spring of 2004; it joined the euro zone and the
Schengen zone in 2007.','457da81785bb93a3ec6363d326858256ce9e65f2b96d3dec1671ad5362044a8a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('418c10113622453eb8fd1d9a3e4bfa70961d249bafda13e9424e8a198c086f2c',2020,'HU','Hungary','introduction',396,'Background: At the close of World War I, the Czechs and
Slovaks of the former Austro-Hungarian Empire merged to
form Czechoslovakia. During the interwar years, having
rejected a federal system, the new country’s predominantly
Czech leaders were frequently preoccupied with meeting
the increasingly strident demands of other’ ethnic
minorities within the republic, most notably the Slovaks,
the Sudeten Germans, and the Ruthenians (Ukrainians). On
the eve of World War II, Nazi Germany occupied the
territory that today comprises Czechia, and Slovakia
became an independent state allied with Germany. After
the war, a reunited but truncated Czechoslovakia (less
Ruthenia) fell within the Soviet sphere of influence. In
1968, an invasion by Warsaw Pact troops ended the efforts
of the country’s leaders to liberalize communist rule and
create “socialism with a human face,” ushering in a period
of repression known as “normalization.” The peaceful
“Velvet Revolution” swept the Communist Party from power
at the end of 1989 and inaugurated a return to democratic
rule and a market economy. On 1 January 1993, the country
underwent a nonviolent “velvet divorce” into its two
national components, the Czech Republic and Slovakia. The
Czech Republic joined NATO in 1999 and the European
Union in 2004. The country added the short-form name
Czechia in 2016, while continuing to use the full form
name, Czech Republic.
Background: The island—discovered by Christopher
COLUMBUS in 1494—was settled by the Spanish early in
the 16th century. The native Taino, who had inhabited
Jamaica for centuries, were gradually exterminated and
replaced by African slaves. England seized the island in
1655 and established a plantation economy based on sugar,
cocoa, and coffee. The abolition of slavery in 1834 freed a
quarter million slaves, many of whom became small
farmers. Jamaica gradually increased its independence
from Britain. In 1958 it joined other British Caribbean
colonies in forming the Federation of the West Indies.
Jamaica withdrew from the Federation in 1961 and gained
full independence in 1962. Deteriorating economic
conditions during the 1970s led to recurrent violence as
rival gangs affiliated with the major political parties
evolved into powerful organized crime networks involved in
international drug smuggling and money laundering.
Violent crime, drug trafficking, and poverty pose significant
Challenges to the government today. Nonetheless, many
rural and resort areas remain relatively safe and contribute
substantially to the economy.','6a40a83a966219d15096b4c898a4e39c4b0bd99c990f191d44d9490caab87eb0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb88f60037c192aba2178961940707589726e31e62093ca1a3358e5a6f2cbf20',2020,'SO','Somalia','introduction',414,'Background: The French Territory of the Afars and the Issas
became Djibouti in 1977. Hassan Gouled APTIDON
installed an authoritarian one-party state and proceeded to
serve as president until 1999. Unrest among the Afar
minority during the 1990s led to a civil war that ended in
2001 with a peace accord between Afar rebels and the
Somali Issa-dominated government. In 1999, Djibouti’s first
multiparty presidential election resulted in the election of
Ismail Omar GUELLEH as president; he was reelected to a
second term in 2005 and extended his tenure in office via a
constitutional amendment, which allowed him to serve a
third term in 2011 and begin a fourth term in 2016.
Djibouti occupies a strategic geographic location at the
intersection of the Red Sea and the Gulf of Aden. Its ports
handle 95% of Ethiopia’s trade. Djibouti’s ports also service
transshipments between Europe, the Middle East, and Asia.
The government holds longstanding ties to France, which
maintains a military presence in the country, as does the
US, Japan, Italy, Germany, Spain, and China.
Background: Some of the earliest human remains in the fossil
record are found in South Africa. By about A.D. 500, Bantu
speaking groups began settling into what is now
northeastern South Africa displacing Khoisan speaking
groups to the southwest. Dutch traders landed at the
southern tip of present-day South Africa in 1652 and
established a stopover point on the spice route between the
Netherlands and the Far East, founding the city of Cape
Town. After the British seized the Cape of Good Hope area
in 1806, many of the settlers of Dutch descent (Afrikaners,
also called “Boers” (farmers) at the time) trekked north to
found their own republics, Transvaal and Orange Free
State. In the 1820s, several decades of wars began as the
Zulus expanded their territory, moving out of what is today
southeastern South Africa and clashing with other
indigenous peoples and with expanding European
settlements. The discovery of diamonds (1867) and gold
(1886) spurred wealth and immigration from Europe.
The Anglo-Zulu War (1879) resulted in the incorporation
of the Zulu kingdom’s territory into the British Empire.
Subsequently, the Afrikaner republics were incorporated
into the British Empire after their defeat in the Second
South African War (1899-1902). However, the British and
the Afrikaners ruled together beginning in 1910 under the
Union of South Africa, which became a republic in 1961
after a whites-only referendum. In 1948, the National Party
was voted into power and instituted a policy of apartheid—
billed as “separate development” of the races—which
favored the white minority at the expense of the black
majority and other non-white groups. The African National
Congress (ANC) led the opposition to apartheid and many
top ANC leaders, such as Nelson MANDELA, spent decades
in South Africa’s prisons. Internal protests and insurgency,
as well as boycotts by some Western nations and
institutions, led to the regime’s eventual willingness to
negotiate a peaceful transition to majority rule.
The first multi-racial elections in 1994 following the end
of apartheid ushered in majority rule under an ANC-led
government. South Africa has since struggled to address
apartheid-era imbalances in wealth, housing, education,
and health care. Jacob ZUMA became president in 2009
and was reelected in 2014, but resigned in February 2018
after numerous corruption scandals and _ gains’ by
Opposition parties in municipal elections in 2016. His
successor, Cyril RAMAPHOSA, has made some progress in
reigning in corruption, though many challenges persist. In
May 2019 national elections, the country’s sixth since the
end of apartheid, the ANC won a majority of parliamentary
seats, delivering RAMAPHOSA a five-year term.
Background: The islands, with large bird and_ “seal
populations, lie approximately 1,000 km east of the
Falkland Islands and have been’ under British
administration since 1908—except for a brief period in
1982 when Argentina occupied them. Grytviken, on South
Georgia, was a 19th and early 20th century whaling
station. Famed explorer Ernest SHACKLETON stopped
there in 1914 en route to his ill-fated attempt to cross
Antarctica on foot. He returned some 20 months later with
a few companions in a small boat and arranged a successful
rescue for the rest of his crew, stranded off the Antarctic
Peninsula. He died in 1922 on a subsequent expedition and
is buried in Grytviken. Today, the station houses scientists
from the British Antarctic Survey. Recognizing the
importance of preserving the marine stocks in adjacent
waters, the UK, in 1993, extended the exclusive fishing
zone from 12 nm to 200 nm around each island.','8893ceedc699436f92bd563ab8ccfee0c4d4477560df0f5ddb8e5b9109f3c8f6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3dc035e64062563bf7813494dee8171a7121b58d22c71fc759e3524593bfecc',2020,'DJ','Djibouti','introduction',424,'Background: Dominica was the last of the Caribbean islands
to be colonized by Europeans due chiefly to the fierce
resistance of the native Caribs. France ceded possession to
Great Britain in 1763, which colonized the island in 1805.
Slavery ended in 1833 and in 1835 the first three men of
African descent were elected to the legislative assembly of
Dominica. In 1871, Dominica became part first of the
British Leeward Islands and then the British Windward
Islands until 1958. In 1967 Dominica became an associated
state of the UK, and formally took responsibility for its
internal affairs. In 1980, two years after independence,
Dominica’s fortunes improved when a corrupt and
tyrannical administration was replaced by that of Mary
Eugenia CHARLES, the first female prime minister in the
Caribbean, who remained in office for 15 years. On 18
September 2017, Hurricane Maria passed over the island
causing extensive damage _ to _ structures, roads,
communications, and the power supply, and_ largely
destroying critical agricultural areas.
Background: The Taino—indigenous inhabitants of Hispaniola
prior to the arrival of the Europeans—divided the island
into five chiefdoms and_ territories. Christopher
COLUMBUS explored and claimed the island on his first
voyage in 1492; it became a springboard for Spanish
conquest of the Caribbean and the American mainland. In
1697, Spain recognized French dominion over the western
third of the island, which in 1804 became Haiti. The
remainder of the island, by then known as Santo Domingo,
sought to gain its own independence in 1821 but was
conquered and ruled by the Haitians for 22 years; it finally
attained independence as the Dominican Republic in 1844.
In 1861, the Dominicans voluntarily returned to the
Spanish Empire, but two years later they launched a war
that restored independence in 1865. A legacy of unsettled,
mostly non-representative rule followed, capped by the
dictatorship of Rafael Leonidas TRUJILLO from 1930 to
1961. Juan BOSCH was elected president in 1962 but was
deposed in a military coup in 1963. In 1965, the US led an
intervention in the midst of a civil war sparked by an
uprising to restore BOSCH. In 1966, Joaquin BALAGUER
defeated BOSCH in the presidential election. BALAGUER
maintained a tight grip on power for most of the next 30
years when international reaction to flawed elections
forced him to curtail his term in 1996. Since then, regular
competitive elections have been held in which opposition
candidates have won the presidency. Former President
Leonel FERNANDEZ Reyna (first term 1996-2000) won
election to a new term in 2004 following a constitutional
amendment allowing presidents to serve more than one
term, and was later reelected to a second consecutive term.
In 2012, Danilo MEDINA Sanchez became president; he
was reelected in 2016.','509a3b26178fb34760572011659922e6f9b95c4521aa437b36ed036255258048','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb2ea869e8f5c11d47e2089f47a665c2d4b48cec8e82b18e88b96bef1ebabd55',2020,'CO','Colombia','introduction',436,'Background: What is now Ecuador formed part of the
northern Inca Empire until the Spanish conquest in 1533.
Quito became a seat of Spanish colonial government in
1563 and part of the Viceroyalty of New Granada in 1717.
The territories of the Viceroyalty—New Granada
(Colombia), Venezuela, and Quito—gained their
independence between 1819 and 1822 and formed a
federation known as Gran Colombia. When Quito withdrew
in 1830, the traditional name was changed in favor of the
“Republic of the Equator.” Between 1904 and 1942,
Ecuador lost territories in a series of conflicts with its
neighbors. A border war with Peru that flared in 1995 was
resolved in 1999. Although Ecuador marked 30 years of
civilian governance in 2004, the period was marred by
political instability. Protests in Quito contributed to the
mid-term ouster of three of Ecuador’s last four
democratically elected presidents. In late 2008, voters
approved a new constitution, Ecuador’s 20th since gaining
independence. General elections were held in April 2017,
and voters elected President Lenin MORENO.
Background: The regularity and richness of the annual Nile
River flood, coupled with semi-isolation provided by deserts
to the east and west, allowed for the development of one of
the world’s great civilizations. A unified kingdom arose
circa 3200 B. C., and a series of dynasties ruled in Egypt
for the next three millennia. The last native dynasty fell to
the Persians in 341 B. C., who in turn were replaced by the
Greeks, Romans, and Byzantines. It was the Arabs who
introduced Islam and the Arabic language in the 7th
century and who ruled for the next six centuries. A local
military caste, the Mamluks took control about 1250 and
continued to govern after the conquest of Egypt by the
Ottoman Turks in 1517. Completion of the Suez Canal in
1869 elevated Egypt as an important world transportation
hub. Ostensibly to protect its investments, Britain seized
control of Egypt’s government in 1882, but nominal
allegiance to the Ottoman Empire continued until 1914.
Partially independent from the UK in 1922, Egypt acquired
full sovereignty from Britain in 1952. The completion of the
Aswan High Dam in 1971 and the resultant Lake Nasser
have reaffirmed the time-honored place of the Nile River in
the agriculture and ecology of Egypt. A rapidly growing
population (the largest in the Arab world), limited arable
land, and dependence on the Nile all continue to overtax
resources and stress society. The government has struggled
to meet the demands of Egypt’s fast-growing population as
it implements far-reaching economic reforms, including the
reduction of select subsidies, large-scale infrastructure
projects, energy cooperation, and foreign direct investment
appeals.
Inspired by the 2010 Tunisian revolution, Egyptian
opposition groups led demonstrations and labor strikes
countrywide, culminating in President Hosni MUBARAK’s
ouster in 2011. Egypt’s military assumed national
leadership until a new legislature was in place in early
2012; later that same year, Muhammad MURSI won the
presidential election. Following protests throughout the
spring of 2013 against MURSI’s government and the
Muslim Brotherhood, the Egyptian Armed _ Forces
intervened and removed MURSI from power in July 2013
and replaced him with interim president Adly MANSOUR.
Simultaneously, the government began enacting laws to
limit freedoms of assembly and expression. In January
2014, voters approved a new constitution by referendum
and in May 2014 elected former defense minister
Abdelfattah ELSISI president. Egypt elected a new
legislature in December 2015, its first Hose of
Representatives since 2012. ELSISI was reelected to a
second four-year term in March 2018. In April 2019, Egypt
approved via national referendum a set of constitutional
amendments extending ELSISI’s term in office through
2024 and possibly through 2030 if re-elected for a third
term. The amendments would also allow future presidents
up to two consecutive six-year terms in office, re-establish
an upper legislative house, allow for one or more vice
presidents, establish a 25% quota for female legislators,
reaffirm the military’s role as guardian of Egypt, and
expand presidential authority to appoint the heads of
judicial councils.','5217c624ca2eb0e5fa19a224bbcd6bcb7eb701a0932dbd3e62d1f3ea06393ffb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ac0bc874c93dad545d24cabe4ed14abd45e1ddc174db73be322fb31e8b9afba',2020,'GN','Guinea','introduction',466,'Background: After independence from Italian colonial control
in 1941 and 10 years of British administrative control, the
UN established Eritrea as an autonomous region within the
Ethiopian federation in 1952. Ethiopia’s full annexation of
Eritrea as a province 10 years later sparked a violent 30-
year struggle for independence that ended in 1991 with
Eritrean rebels defeating government forces. Eritreans
overwhelmingly approved independence in a _ 1993
referendum. ISAIAS Afwerki has been Eritrea’s only
president since independence; his rule, particularly since
2001, has been highly autocratic and repressive. His
government has created a highly militarized society by
pursuing an unpopular program of mandatory conscription
into national service—divided between military and civilian
service—of indefinite length. A two-and-a-half-year border
war with Ethiopia that erupted in 1998 ended under UN
auspices in December 2000. A UN peacekeeping operation
was established that monitored a 25 km-wide Temporary
Security Zone. The Eritrea-Ethiopia Boundary Commission
(EEBC) created in April 2003 was tasked “to delimit and
demarcate the colonial treaty border based on pertinent
colonial treaties (1900, 1902, and 1908) and applicable
international law.” The EEBC on 30 November 2007
remotely demarcated the border, assigning the town of
Badme to Eritrea, despite Ethiopia’s maintaining forces
there from the time of the 1998-2000 war. Eritrea insisted
that the UN terminate its peacekeeping mission on 31 July
2008. More than a decade of a tense “no peace, no war”
stalemate ended in 2018 after the newly elected Ethiopian
Prime Minister accepted the EEBC’s 2007 ruling, and the
two countries signed declarations of peace and friendship
in July and September. Following the July 2018 peace
agreement with Ethiopia, Eritrean leaders engaged in
intensive diplomacy around the Horn of Africa, bolstering
regional peace, security, and cooperation, as well as
brokering rapprochements between governments and
opposition groups. In November 2018, the UN Security
Council lifted an arms embargo that had been imposed on
Eritrea since 2009, after the UN _ Somalia-Eritrea
Monitoring Group reported they had not found evidence of
Eritrean support in recent years for Al-Shabaab.
Background: Since independence from Portugal in 1974,
Guinea-Bissau has experienced considerable political and
military upheaval. In 1980, a military coup established
authoritarian General Joao Bernardo ‘Nino’ VIEIRA as
president. Despite eventually setting a path to a market
economy and multiparty system, VIEIRA’s regime was
characterized by the suppression of political opposition and
the purging of political rivals. Several coup attempts
through the 1980s and early 1990s failed to unseat him. In
1994 VIEIRA was elected president in the country’s first
free, multiparty election. A military mutiny and resulting
civil war in 1998 eventually led to VIEIRA’s ouster in May
1999. In February 2000, a transitional government turned
over power to opposition leader Kumba YALA after he was
elected president in transparent polling. In September
2003, after only three years in office, YALA was overthrown
in a bloodless military coup, and businessman Henrique
ROSA was sworn in as interim president. In 2005, former
President VIEIRA was reelected, pledging to pursue
economic development and national reconciliation; he was
assassinated in March 2009. Malam Bacai SANHA was
elected in an emergency election held in June 2009, but he
passed away in January 2012 from a long-term illness. A
military coup in April 2012 prevented Guinea-Bissau’s
second-round presidential election—to determine SANHA’s
successor-from taking place. Following mediation by the
Economic Community of Western African States, a civilian
transitional government assumed power in 2012 and
remained until Jose Mario VAZ won a free and fair election
in 2014. Beginning in 2015, a political dispute between
factions in the ruling PAIGC party brought government
gridlock. It was not until April 2018 that a consensus prime
minister could be appointed, the national legislature
reopened (having been closed for two years), and a new
government formed under Prime Minister Aristides
GOMES. In March 2019, the government held legislative
elections, voting in the PAIGC as the ruling party; however,
President VAZ continues to perpetuate a political stalemate
by refusing to name PAICG President Domingos SIMOES
PEREIRA Prime Minister.
local short form: Papuaniugini
former: Territory of Papua and New Guinea
abbreviation: PNG
etymology: the word “papua” derives from the Malay
“papuah” describing the frizzy hair of the Melanesians;
Spanish explorer Ynigo ORTIZ de RETEZ applied the term
“Nueva Guinea” to the island of New Guinea in 1545 after
noting the resemblance of the locals to the peoples of the
Guinea coast of Africa Government type: parliamentary
democracy under a_ constitutional monarchy; a
Commonwealth realm
Capital: name: Port Moresby
geographic coordinates: 9 27 S,14711E
time difference: UTC+10 (15 hours ahead of Washington,
DC, during Standard Time)
note: Papua New Guinea has two time zones, including
Bougainville (UTC+11)
etymology: named in 1873 by Captain John Moresby (1830-
1922) in honor of his father, British Admiral Sir Fairfax
Moresby (1786-1877) Administrative divisions: 20 provinces, 1
autonomous region*, and 1. district**; Bougainville*,
Central, Chimbu, Eastern Highlands, East New Britain,
East Sepik, Enga, Gulf, Hela, Jiwaka, Madang, Manus,
Milne Bay, Morobe, National Capital**, New _ Ireland,
Northern, Southern Highlands, Western, Western
Highlands, West New Britain, West Sepik Independence: 16
September 1975 (from the Australia-administered UN
trusteeship)
National holiday: Independence Day, 16 September (1975)
Constitution: history: adopted 15 August 1975, effective at
independence 16 September 1975
amendments: proposed by the National Parliament;
passage has_ prescribed majority vote requirements
depending on the constitutional sections being amended—
absolute majority, two-thirds majority, or three-fourths
majority; amended many times, last in 2014 (2018) Legal
system: mixed legal system of English common law and
customary law
International law organization participation: has not submitted an
ICJ jurisdiction declaration; non-party state to the ICCt
Citizenship: citizenship by birth: no
citizenship by descent only: at least one parent must be a
citizen of Papua New Guinea
dual citizenship recognized: no
residency requirement for naturalization: 8 years
Suffrage: 18 years of age; universal
Executive branch: Chief of state: Queen ELIZABETH II (since 6
February 1952); represented by Governor General Grand
Chief Sir Bob DADAE (since 28 February 2017) head of
government: Prime Minister James MARAPE (since 30 May
2019); Deputy Prime Minister Charles ABEL (since 4
August 2017) cabinet: National Executive Council
appointed by the governor general on the recommendation
of the prime minister’ elections/appointments: the
monarchy is hereditary; governor general nominated by the
National Parliament and appointed by the chief of state;
following legislative elections, the leader of the majority
party or majority coalition usually appointed prime minister
by the governor general pending the outcome of a National
Parliament vote election results: Peter Paire O’NEILL
(PNC) reelected prime minister; National Parliament vote—
60 to 46
Legislative branch:description: unicameral National
Parliament (111 seats; members directly elected in single-
seat constituencies—89 local, 20 provinicial, the
autonomous province of Bouganville, and the National
Capital District—by majority preferential vote; members
serve 5-year terms); note—the constitution allows up to 126
seats elections: last held from 24 June 2017 to 8 July 2017
(next to be held in June 2022)
election results: percent of vote by party—PNC 37%; NA
13%; Pangu 14%; URP 11%; PPP 4%; SDP 4%;
Independents 3%; and smaller parties 14%; seats by party
—NA; composition—men 108, women 3, percent of women
3%
Judicial branch: highest courts: Supreme Court (consists of
the chief justice, deputy chief justice, 35 justices, and 5
acting justices); National Courts (consists of 13 courts
located in the provincial capitals, with a total of 19 resident
judges) judge selection and term of office: Supreme Court
chief justice appointed by the governor general upon
advice of the National Executive Council (cabinet) after
consultation with the National Justice Administration
minister; deputy chief justice and other justices appointed
by the Judicial and Legal Services Commission, a 5-member
body that includes the Supreme Court chief and deputy
chief justices, the chief ombudsman, and a member of the
National Parliament; full-time citizen judges appointed for
10-year renewable terms; non-citizen judges initially
appointed for 3-year renewable terms and after first
renewal can serve until age 70; appointment and tenure of
National Court resident judges NA subordinate courts:
district, village, and juvenile courts, military courts,
taxation courts, coronial courts, mining warden courts,
land courts, traffic courts, committal courts, grade five
courts Political parties and leaders:
National Alliance Party or NAP [Patrick PRUAITCH]
Papua and Niugini Union Party or PANGU [Sam BASIL]
Papua New Guinea Party or PNGP [Belden NAMAH]
People’s National Congress Party or PNC [Peter Paire
O’NEILL]
People’s Party or PP [Peter IPATAS]
People’s Progress Party or PPP [Sir Julius CHAN]
Social Democratic Party or SDP [Powes PARKOP]
Triumph Heritage Empowerment Party or THE [Don
POLYE]
United Resources Party or URP [William DUMA]
note: as of 8 July 2017, 45 political parties were registered
International organization participation: ACP ADB, AOSIS, APEC,
ARF, ASEAN (observer), C, CD, CP EITI (candidate
country), FAO, G-77, IAEA, IBRD, ICAO, ICRM, IDA, IFAD,
IFC, IFRCS, IHO, ILO, IMF, IMO, Interpol, IOC, IOM, IPU,
ISO (correspondent), ITSO, ITU, MIGA, NAM, OPCW, PIF,
Sparteca, SPC, UN, UNCTAD, UNESCO, UNIDO, UNMISS,
UNWTO, UPU, WCO, WFTU (NGOs), WHO, WIPO, WMO,
WTO
Diplomatic representation in the’ US: Ambassador (vacant);
Charge D’Affaires Elias Rahuromo WOHENGU (since 30
September 2017) chancery: 1779 Massachusetts Avenue
NW, Suite 805, Washington, DC 20036
telephone: [1] (202) 745-3680
FAX: [1] (202) 745-3679
Diplomatic representation from the US: chief of mission:
Ambassador Erin Elizabeth MCKEE (since 27 November
2019); note—also accredited to the Solomon Islands and
Vanuatu telephone: [675] 321-1455
embassy: P.O. Box 1492, Port Moresby
mailing address: 4240 Port Moresby Place, US Department
of State, Washington DC 20521-4240
FAX: [675] 321-3423
Flag description: divided diagonally from upper hoist-side
corner; the upper triangle is red with a soaring yellow bird
of paradise centered; the lower triangle is black with five,
white, five-pointed stars of the Southern Cross
constellation centered; red, black, and yellow are
traditional colors of Papua New Guinea; the bird of
paradise—endemic to the island of New Guinea—is an
emblem of regional tribal culture and represents the
emergence of Papua New Guinea as a nation; the Southern
Cross, visible in the night sky, symbolizes Papua New
Guinea’s connection with Australia and several other
countries in the South Pacific National symbol(s): bird of
paradise; national colors: red, black
National anthem: Name: O Arise All You Sons
lyrics/music: Thomas SHACKLADY
note: adopted 1975
ele) ‘Tel b 4
Economy—overview: Papua New Guinea (PNG) is richly
endowed with natural resources, but exploitation has been
hampered by rugged terrain, land tenure issues, and the
high cost of developing infrastructure. The economy has a
small formal sector, focused mainly on the export of those
natural resources, and an informal sector, employing the
majority of the population. Agriculture provides a
subsistence livelihood for 85% of the people. The global
financial crisis had little impact because of continued
foreign demand for PNG’s commodities.
Mineral deposits, including copper, gold, and _ oil,
account for nearly two-thirds of export earnings. Natural
gas reserves amount to an estimated 155 billion cubic
meters. Following construction of a $19 billion liquefied
natural gas (LNG) project, PNG LNG, a consortium led by
ExxonMobil, began exporting liquefied natural gas to Asian
markets in May 2014. The project was delivered on time
and only slightly above budget. The success of the project
has encouraged other companies to look at similar LNG
projects. French supermajor Total is hopes to begin
construction on the Papua LNG project by 2020. Due to
lower global commodity prices, resource revenues of all
types have fallen dramatically. PNG’s government has
recently been forced to adjust spending levels downward.
Numerous challenges still face the government of Peter
O’NEILL, including providing physical security for foreign
investors, regaining investor confidence, restoring integrity
to state institutions, promoting economic efficiency by
privatizing moribund state institutions, and maintaining
good relations with Australia, its former colonial ruler.
Other socio-cultural challenges could upend the economy
including chronic law and order and land tenure issues. In
August, 2017, PNG launched its first-ever national trade
policy, PNG Trade Policy 2017-2032. The policy goal is to
maximize trade and investment by increasing exports, to
reduce imports, and to increase foreign direct investment
(FDI).
GDP (purchasing power parity):
$30.19 billion (2017 est.)
$29.44 billion (2016 est.)
$28.98 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 132
GDP (official exchange rate):
$19.82 billion (2017 est.)
GDP—real growth rate: 2.5% (2017 est.)
1.6% (2016 est.)
53.3% (2015 est.)
country comparison to the world: 131
GDP—per capita (PPP): $3,700 (2017 est.)
$3,600 (2016 est.)
$3,700 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 184
Gross national saving:
36.8% of GDP (2017 est.)
38% of GDP (2016 est.)
33.7% of GDP (2015 est.)
country comparison to the world: 14
GDP—composition, by end use:
household consumption: 43.7% (2017 est.)
government consumption: 19.7% (2017 est.)
investment in fixed capital: 10% (2017 est.)
investment in inventories: 0.4% (2017 est.)
exports of goods and services: 49.3% (2017 est.)
imports of goods and services: -22.3% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 22.1% (2017 est.)
industry: 42.9% (2017 est.)
services: 35% (2017 est.)
Agriculture—products: Coffee, cocoa, copra, palm kernels, tea,
sugar, rubber, sweet potatoes, fruit, vegetables, vanilla;
poultry, pork; shellfish Industries: copra crushing, palm oil
processing, plywood production, wood chip production;
mining (gold, silver, copper); crude oil and petroleum
products; construction, tourism, livestock (pork, poultry,
cattle), dairy products, spice products (turmeric, vanilla,
ginger, cardamom, chili, pepper, citronella, and nutmeg),
fisheries products Industrial production growth rate:
3.3% (2017 est.)
country comparison to the world: 97
Labor force: 3.681 million (2017 est.)
country comparison to the world: 97
Labor force—by occupation: agriculture: 85%
industry: NA
services: NA
Unemployment rate: 2.5% (2017 est.)
2.5% (2016 est.)
country comparison to the world: 26
Population below poverty line: 37% (2002 est.)
Household income or consumption by percentage share: Jowest 10%:
1.7%
highest 10%: 40.5% (1996)
Budget: revenues: 3.638 billion (2017 est.)
expenditures: 4.591 billion (2017 est.)
Taxes and other revenues:
18.4% (of GDP) (2017 est.)
country comparison to the world: 160
Budget surplus (+) or deficit (-): -4.8% (of GDP) (2017 est.)
country comparison to the world: 168
Public debt:
36.9% of GDP (2017 est.)
36.9% of GDP (2016 est.)
country comparison to the world: 144
Fiscal year: Calendar year
Inflation rate (consumer prices): 5.4% (2017 est.)
6.7% (2016 est.)
country comparison to the world: 177
Current account balance:
$4.859 billion (2017 est.)
$4.569 billion (2016 est.)
country comparison to the world: 29
Exports: $8.522 billion (2017 est.)
$9,224 billion (2016 est.)
country comparison to the world: 95
Exports—partners: Australia 18.9%, Singapore 17.5%, Japan
13.8%, China 12.7%, Philippines 4.7%, Netherlands 4.2%,
India 4.2% (2017) Exports—commodities: liquefied natural gas,
oil, gold, copper ore, nickel, cobalt logs, palm oil, coffee,
cocoa, copra, spice (turmeric, vanilla, ginger, and
cardamom), crayfish, prawns, tuna, sea cucumber Imports:
$1.876 billion (2017 est.)
$2.077 billion (2016 est.)
country comparison to the world: 170
Imports—commodities: Machinery and transport equipment,
manufactured goods, food, fuels, chemicals
Imports—partners: Australia 30.1%, China 17.3%, Singapore
10.2%, Malaysia 8.2%, Indonesia 4% (2017)
Reserves of foreign exchange and gold:
$1.735 billion (31 December 2017 est.)
$1.656 billion (31 December 2016 est.)
country comparison to the world: 123
Debt—external:
$17.94 billion (31 December 2017 est.)
$18.28 billion (31 December 2016 est.)
country comparison to the world: 95
Exchange rates: kina (PGK) per US dollar—
3.179 (2017 est.)
3.133 (2016 est.)
3.133 (2015 est.)
2.7684 (2014 est.)
2.4614 (2013 est.)
Background: The Paracel Islands are surrounded by
productive fishing grounds and by potential oil and gas
reserves. In 1932, French Indochina annexed the islands
and set up a weather station on Pattle Island; maintenance
was continued by its successor, Vietnam. China has
occupied all the Paracel Islands since 1974, when its troops
seized a South Vietnamese garrison occupying the western
islands. China built a military installation on Woody Island
with an airfield and artificial harbor. The islands also are
claimed by Taiwan and Vietnam.
Background: Paraguay achieved its independence from Spain
in 1811. In the disastrous War of the Triple Alliance (1865-
70)—between Paraguay and Argentina, Brazil, and Uruguay
—Paraguay lost two-thirds of its adult males and much of
its territory. The country stagnated economically for the
next half century. Following the Chaco War of 1932-35 with
Bolivia, Paraguay gained a large part of the Chaco lowland
region. The 35-year military dictatorship of Alfredo
STROESSNER ended in 1989, and Paraguay has held
relatively free and regular presidential elections since the
country’s return to democracy.
Background: The French colonies of Senegal and French
Sudan were merged in 1959 and granted independence in
1960 as the Mali Federation. The union broke up after only
a few months. Senegal joined with The Gambia to form the
nominal confederation of Senegambia in 1982. The
envisaged integration of the two countries was never
implemented, and the union was dissolved in 1989. The
Movement of Democratic Forces in the Casamance has led
a low-level separatist insurgency in southern Senegal since
the 1980s. Several attempts at reaching a comprehensive
peace agreement have failed to resolve the conflict but,
despite sporadic incidents of violence, an unofficial cease-
fire has remained largely in effect since 2012. Senegal
remains one of the most stable democracies in Africa and
has a long history of participating in international
peacekeeping and regional mediation. Senegal was ruled
by the Socialist Party of Senegal, first under President
Léopold Sédar SENGHOR, and then President Abdou
DIOUF, for 40 years until Abdoulaye WADE was elected
president in 2000. He was re-elected in 2007 and during
his two terms amended Senegal’s constitution over a dozen
times to increase executive power and weaken the
opposition. His decision to run for a third presidential term
sparked a large public backlash that led to his defeat in a
March 2012 runoff with Macky SALL. A 2016 constitutional
referendum reduced the term to five years with a maximum
of two consecutive terms for future presidents—the change
did not apply to SALUs first term. SALL won his bid for re-
election in February 2019; his term will end in 2024. A
month after the election, the National Assembly voted to
abolish the office of the prime minister. Opposition
organizations and civil society have criticized the decision
as a further concentration of power in the executive branch
at the expense of the legislative and judicial branches.
Background: The British set up a trading post near present-
day Freetown in the 17th century. Originally, the trade
involved timber and ivory, but later it expanded to slaves.
Following the American Revolution, a colony was
established in 1787 and Sierra Leone became a destination
for resettling black loyalists who had originally been
resettled in Nova Scotia. After the abolition of the slave
trade in 1807, British crews delivered thousands of
Africans liberated from illegal slave ships to Sierra Leone,
particularly Freetown. The colony gradually expanded
inland during the course of the 19th century; independence
was attained in 1961. Democracy is_ slowly being
reestablished after the civil war (1991-2002) that resulted
in tens of thousands of deaths and the displacement of
more than 2 million people (about one-third of the
population). The military, which took over full responsibility
for security following the departure of UN peacekeepers at
the end of 2005, has developed as a guarantor of the
country’s stability; the armed forces remained on the
sideline during the 2007, 2012, and 2018 national
elections. In March 2014, the closure of the UN Integrated
Peacebuilding Office in Sierra Leone marked the end of
more than 15 years of peacekeeping and_ political
operations in Sierra Leone. The government’s stated
priorities include free primary and secondary education,
economic growth, accountable governance, health, and
infrastructure.
Background: A Malay trading port known as Temasek existed
on the island of Singapore by the 14th century. The
settlement changed hands several times in the ensuing
centuries and was eventually burned in the 17th century
and fell into obscurity. The British founded modern
Singapore as a trading colony on the site in 1819. It joined
the Malaysian Federation in 1963 but was ousted two years
later and became independent. Singapore subsequently
became one of the world’s most prosperous countries with
strong international trading links (its port is one of the
world’s busiest in terms of tonnage handled) and with per
capita GDP equal to that of the leading nations of Western
Europe.','98ff8bf5b3532dbe5e8ec3f9357fe6c19111dd8a43a22e023d37f3cfb3902df0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0d871dd9876cfdb0b6f4df75ae7725ac893f4ecbbb220920a519740ec635006',2020,'LV','Latvia','introduction',471,'Background: After centuries of Danish, Swedish, German, and
Russian rule, Estonia attained independence in 1918.
Forcibly incorporated into the USSR in 1940—an action
never recognized by the US and many other countries—it
regained its freedom in 1991 with the collapse of the Soviet
Union. Since the last Russian troops left in 1994, Estonia
has been free to promote economic and political ties with
the West. It joined both NATO and the EU in the spring of
2004, formally joined the OECD in late 2010, and adopted
the euro as its official currency on 1 January 2011.
Background: Lithuanian lands were united under
MINDAUGAS in 1236; over the next century, through
alliances and conquest, Lithuania extended its territory to
include most of present-day Belarus and Ukraine. By the
end of the 14th century Lithuania was the largest state in
Europe. An alliance with Poland in 1386 led the two
countries into a union through the person of a common
ruler. In 1569, Lithuania and Poland formally united into a
single dual state, the Polish-Lithuanian Commonwealth.
This entity survived until 1795 when its remnants were
partitioned by surrounding countries. Lithuania regained
its independence following World War I but was annexed by
the USSR in 1940—an action never recognized by the US
and many other countries. On 11 March 1990, Lithuania
became the first of the Soviet republics to declare its
independence, but Moscow did not recognize this
proclamation until September of 1991 (following the
abortive coup in Moscow). The last Russian troops
withdrew in 1993. Lithuania subsequently restructured its
economy for integration into Western European
institutions; it joined both NATO and the EU in the spring
of 2004. In 2015, Lithuania joined the euro zone, and it
joined the Organization for Economic Cooperation and
Development in 2018.','742f373ffce15143bd669cac6d033b7282e131f7b16c6e9f2ccdd3bf7c72599b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b10c7140345b202cb86591e43cec5b6e91e9af5ba204f4ed75929a25c035be1',2020,'MZ','Mozambique','introduction',480,'Background: Autonomy for Eswatini was guaranteed by the
British in the late 19th century; independence was granted
in 1968. A new constitution came into effect in 2006, which
included provisions for a more independent parliament and
judiciary, but the legal status of political parties remains
unclear. King MSWATI III renamed the country from
Swaziland to Eswatini in April 2018. Despite its
classification as a lower-middle income country, Eswatini
suffers from severe poverty and high unemployment.
Eswatini has the world’s highest HIV/AIDS prevalence rate,
although recent years have shown marked declines in new
infections.
Background: During the late 18th and 19th centuries, Great
Britain established colonies and protectorates in the area
of current Malaysia; these were occupied by Japan from
1942 to 1945. In 1948, the British-ruled territories on the
Malay Peninsula except Singapore formed the Federation of
Malaya, which became independent in 1957. Malaysia was
formed in 1963 when the former British colonies of
Singapore, as well as Sabah and Sarawak on the northern
coast of Borneo, joined the Federation. The first several
years of the country’s independence were marred by a
communist insurgency, Indonesian confrontation with
Malaysia, Philippine claims to Sabah, and Singapore’s
withdrawal in 1965. During the 22-year term of Prime
Minister MAHATHIR Mohamad (1981-2003), Malaysia was
successful in diversifying its economy from dependence on
exports of raw materials to the development of
manufacturing, services, and tourism. Prime Minister
MAHATHIR and a newly-formed coalition of opposition
parties defeated Prime Minister Mohamed NAJIB bin Abdul
Razak’s United Malays National Organization (UMNO) in
May 2018, ending over 60 years of uninterrupted rule by
UMNO.
Background: A Sultanate since the 12th century, the Maldives
became a British protectorate in 1887. The islands became
a republic in 1968, three years after independence.
President Maumoon Abdul GAYOOM dominated Maldives’
political scene for 30 years, elected to six successive terms
by single-party referendums. Following political
demonstrations in the capital Male in August 2003,
GAYOOM and his government pledged to embark upon a
process of liberalization and democratic reforms, including
a more representative political system and expanded
political freedoms. Political parties were legalized in 2005.
In June 2008, a constituent assembly—termed the
“Special Majlis”—finalized a new constitution ratified by
GAYOOM in August 2008. The first-ever presidential
elections under a multi-candidate, multi-party system were
held in October 2008. GAYOOM was defeated in a runoff
poll by Mohamed NASHEED, a political activist who had
been jailed several years earlier by the GAYOOM regime. In
early February 2012, after several weeks of street protests
in response to his ordering the arrest of a top judge,
NASHEED purportedly resigned the presidency and
handed over power to Vice President Mohammed WAHEED
Hassan Maniku. A government-appointed Commission of
National Inguiry concluded there was no evidence of a
coup, but NASHEED contends that police and military
personnel forced him to resign. NASHEED, WAHEED, and
Abdulla YAMEEN Abdul Gayoom ran in the 2013 elections
with YAMEEN ultimately winning the presidency after
three rounds of voting. As president, YAMEEN weakened
democratic institutions, curtailed civil liberties, jailed his
political opponents, restricted the press, and exerted
control over the judiciary to strengthen his hold on power
and limit dissent. In September 2018, YAMEEN lost his
reelection bid to Ibrahim Mohamed SOLIH, a
parliamentarian of the Maldivian Democratic Party (MDP),
who had the support of a coalition of four parties that came
together to defeat YAMEEN and restore democratic norms
to Maldives. In April 2019, SOLIH’s MDP won 65 of 87
seats in parliament.
ej ole) y-V ah
Location: Southern Asia, group of atolls in the Indian Ocean,
south-southwest of India
Geographic coordinates: 3 15 N, 73 OO E
Map references: ASia
Area: total: 298 sq km
land: 298 sq km
water: 0 sq km
country comparison to the world: 210
Area—comparative: about 1.7 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 644 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
contiguous zone: 24 nm
measured from claimed archipelagic straight baselines
Climate: tropical; hot, humid; dry, northeast monsoon
(November to March); rainy, southwest monsoon (June to
August) Terrain: flat, with white sandy beaches
Elevation: mean elevation: 2 m
lowest point: Indian Ocean 0 m
highest point: 8th tee, golf course, Villingi Island 5 m
Natural resources: fish
Land use: agricultural land: 23.3% (2011 est.)
arable land: 10% (2011 est.) / permanent crops: 10% (2011
est.) / permanent pasture: 3.3% (2011 est.) forest: 3%
(2011 est.)
other: 73.7% (2011 est.)
Irrigated land: 0 sq km (2012)
Population distribution: about a third of the population lives in
the centrally located capital city of Male and almost a tenth
in southern Addu City; the remainder of the populace is
spread over the 200 or so populated islands of the
archipelago Natural hazards: tsunamis; low elevation of
islands makes them sensitive to sea level rise Environment—
current issues: Gepletion of freshwater aquifers threatens
water supplies; inadequate sewage treatment; coral reef
bleaching Environment—international agreements: party to:
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution signed, but not
ratified: none of the selected agreements
Geography—note: smallest Asian country; archipelago of
1,190 coral islands grouped into 26 atolls (200 inhabited
islands, plus 80 islands with tourist resorts); strategic
location astride and along major sea lanes in Indian Ocean
Background: Shortly after achieving independence from
Britain in the early 1960s, Tanganyika and Zanzibar
merged to form the United Republic of Tanzania in 1964. In
1995, the country held its first democratic elections since
the 1970s. Zanzibar maintains semi-autonomy and
participates in national elections; popular political
opposition on the isles led to four contentious elections
since 1995, in which the ruling party claimed victory
despite international observers’ claims of voting
irregularities.
Background: The UK annexed Southern Rhodesia from the
former British South Africa Company in 1923. A 1961
constitution was formulated that favored whites in power.
In 1965 the government unilaterally declared its
independence, but the UK did not recognize the act and
demanded more complete voting rights for the black
African majority in the country (then called Rhodesia). UN
sanctions and a guerrilla uprising finally led to free
elections in 1979 and independence (as Zimbabwe) in
1980. Robert MUGABE, the nation’s first prime minister,
was the country’s only ruler (as president since 1987) from
independence until his resignation in November 2017. His
chaotic land redistribution campaign, which began in 1997
and intensified after 2000, caused an exodus of white
farmers, crippled the economy, and ushered in widespread
shortages of basic commodities. Ignoring international
condemnation, MUGABE rigged the 2002 presidential
election to ensure his reelection.
In 2005, the capital city of Harare embarked on
Operation Restore Order,’ ostensibly an urban
rationalization program, which resulted in the destruction
of the homes or businesses of 700,000 mostly poor
supporters of the opposition. MUGABE in 2007 instituted
price controls on all basic commodities causing panic
buying and leaving store shelves empty for months.
General elections held in March 2008 _ contained
irregularities but still amounted to a censure of the ZANU-
PF-led government with the opposition winning a majority
of seats in parliament. Movement for Democratic Change—
Tsvangirai opposition leader Morgan TSVANGIRAI won the
most votes in the presidential poll, but not enough to win
outright. In the lead up to a run-off election in June 2008,
considerable violence against opposition party members
led to the withdrawal of TSVANGIRAI from the ballot.
Extensive evidence of violence and intimidation resulted in
international condemnation of the _ process. Difficult
negotiations over a power-sharing “government of national
unity,” in which MUGABE remained president and
TSVANGIRAI became prime minister, were finally settled in
February 2009, although the leaders failed to agree upon
many key outstanding governmental issues. MUGABE was
reelected president in 2013 in balloting that was severely
flawed and internationally condemned. As a prerequisite to
holding the election, Zimbabwe enacted a new constitution
by referendum, although many provisions in the new
constitution have yet to be codified in law. In November
2017, Vice President Emmerson MNANGAGWA took over
following a military intervention that forced MUGABE to
resign. MNANGAGWA was inaugurated president days
later, promising to hold presidential elections in 2018. In
July 2018, MNANGAGWA won the presidential election
after a close contest with Movement for Democratic
Change Alliance candidate Nelson CHAMISA.
MNANGAGWA has since resorted to the government’s
longstanding practice of violently disrupting protests or
opposition rallies. Official inflation rates soared in 2019,
approaching 500% by the end of the year. MUGABE died in
September 2019.','4f024220123e6d95283235fef05eb61a138edd19a48c8a3266fb34528fee3cf5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c63970cedb00f12ee90fbd97a515cc2bc14d0e788695094c9cc195350be8fb9f',2020,'YE','Yemen','introduction',492,'Background: Unique among African countries, the ancient
Ethiopian monarchy maintained its freedom from colonial
rule with the exception of a short-lived Italian occupation
from 1936-41. In 1974, a military junta, the Derg, deposed
Emperor Haile SELASSIE (who had ruled since 1930) and
established a _ socialist state. Torn by bloody coups,
uprisings, wide-scale drought, and massive refugee
problems, the regime was finally toppled in 1991 by a
coalition of rebel forces, the Ethiopian People’s
Revolutionary Democratic Front (EPRDF). A constitution
was adopted in 1994, and Ethiopia’s first multiparty
elections were held in 1995.
A border war with Eritrea in the late 1990s ended with a
peace treaty in December 2000. In November 2007, the
Eritrea-Ethiopia Border Commission (EEBC) issued specific
coordinates as virtually demarcating the border and
pronounced its work finished. Alleging that the EEBC acted
beyond its mandate in issuing the coordinates, Ethiopia did
not accept them and maintained troops in previously
contested areas pronounced by the EEBC as belonging to
Eritrea. This intransigence resulted in years of heightened
tension between the two countries. In August 2012,
longtime leader Prime Minister MELES Zenawi died in
office and was replaced by his Deputy Prime Minister
HAILEMARIAM Desalegn, marking the first peaceful
transition of power in decades. Following a wave of popular
dissent and anti-government protest that began in 2015,
HAILEMARIAM resigned in February 2018 and ABIY
Ahmed Ali took office in April 2018 as Ethiopia’s first ethnic
Oromo prime minister. In June 2018, ABIY announced
Ethiopia would accept the border ruling of 2000, prompting
rapprochement between Ethiopia and Eritrea that was
marked with a peace agreement in July 2018 and a
reopening of the border in September 2018. In November
2019, Ethiopia’s nearly 30-year ethnic-based ruling
coalition—the EPRDF—merged into a single unity party
called the Prosperity Party, however, one of the four
constituent parties refused to join.
Preliminary statement: The evolution of what is today the
European Union (EU) from a regional economic agreement
among six neighboring states in 1951 to today’s hybrid
intergovernmental and supranational organization of 27
countries across the European continent stands as an
unprecedented phenomenon in the annals of history.
Dynastic unions for territorial consolidation were long the
norm in Europe; on a few occasions even country-level
unions were arranged—the Polish-Lithuanian
Commonwealth and the Austro-Hungarian Empire were
examples. But for such a large number of nation-states to
cede some of their sovereignty to an overarching entity is
unique.
Although the EU is not a federation in the strict sense, it
is far more than a free-trade association such as ASEAN or
Mercosur, and it has certain attributes associated with
independent nations: its own flag, currency (for some
members), and law-making abilities, as well as diplomatic
representation and a common foreign and security policy in
its dealings with external partners.
Thus, inclusion of basic intelligence on the EU has been
deemed appropriate as a separate entity in The World
Factbook. However, because of the EU’s special status, this
description is placed after the regular country entries.
Background: Following the two devastating World Wars in the
first half of the 20th century, a number of far-sighted
European leaders in the late 1940s sought a response to
the overwhelming desire for peace and reconciliation on
the continent. In 1950, the French Foreign Minister Robert
SCHUMAN proposed pooling the production of coal and
steel in Western Europe and setting up an organization for
that purpose that would bring France and the Federal
Republic of Germany together and would be open to other
countries as well. The following year, the European Coal
and Steel Community (ECSC) was set up when six members
—Belgium, France, West Germany, Italy, Luxembourg, and
the Netherlands—signed the Treaty of Paris.
The ECSC was so successful that within a few years the
decision was made to integrate other elements of the
countries’ economies. In 1957, envisioning an “ever closer
union,” the Treaties of Rome created the European
Economic Community (EEC) and the European Atomic
Energy Community (Euratom), and the six member states
undertook to eliminate trade barriers among themselves by
forming a common market. In 1967, the institutions of all
three communities were formally merged into the
European Community (EC), creating a single Commission, a
single Council of Ministers, and the body known today as
the European Parliament. Members of the European
Parliament were initially selected by national parliaments,
but in 1979 the first direct elections were undertaken and
have been held every five years since.
In 1973, the first enlargement of the EC took place with
the addition of Denmark, Ireland, and the UK. The 1980s
saw further membership expansion with Greece joining in
1981 and Spain and Portugal in 1986. The 1992 Treaty of
Maastricht laid the basis for further forms of cooperation in
foreign and defense policy, in judicial and internal affairs,
and in the creation of an economic and monetary union—
including a common currency. This further integration
created the European Union (EU), at the time standing
alongside the EC. In 1995, Austria, Finland, and Sweden
joined the EU/EC, raising the membership total to 15.
A new currency, the euro, was launched in world money
markets on 1 January 1999; it became the unit of exchange
for all EU member states except Denmark, Sweden, and the
UK. In 2002, citizens of those 12 countries began using
euro banknotes and coins. Ten new countries joined the EU
in 2004—Cyprus, the Czech Republic, Estonia, Hungary,
Latvia, Lithuania, Malta, Poland, Slovakia, and Slovenia.
Bulgaria and Romania joined in 2007 and Croatia in 2013,
but the UK withdrew in 2020. Current membership stands
at 27. (Seven of the new countries—Cyprus, Estonia,
Latvia, Lithuania, Malta, Slovakia, and Slovenia—have now
adopted the euro, bringing total euro-zone membership to
19.) In an effort to ensure that the EU could function
efficiently with an expanded membership, the Treaty of
Nice (concluded in 2000; entered into force in 2003) set
forth rules to streamline the size and procedures of EU
institutions. An effort to establish a “Constitution for
Europe,” growing out of a Convention held in 2002-2003,
foundered when it was rejected in referenda in France and
the Netherlands in 2005. A subsequent effort in 2007
incorporated many of the features of the rejected draft
Constitutional Treaty while also making a number of
substantive and symbolic changes. The new treaty, referred
to as the Treaty of Lisbon, sought to amend existing
treaties rather than replace them. The treaty was approved
at the EU intergovernmental conference of the then 27
member states held in Lisbon in December 2007, after
which the process of national ratifications began. In
October 2009, an Irish referendum approved the Lisbon
Treaty (overturning a previous rejection) and cleared the
way for an ultimate unanimous endorsement. Poland and
the Czech Republic ratified soon after. The Lisbon Treaty
came into force on 1 December 2009 and the EU officially
replaced and succeeded the EC. The Treaty’s provisions are
part of the basic consolidated versions of the Treaty on
European Union (TEU) and the Treaty on the Functioning
of the European Union (TFEU) now governing what
remains a very specific integration project.
UK citizens on 23 June 2016 narrowly voted to leave the
EU; the formal exit took place on 31 January 2020. The EU
and UK have negotiated and ratified a Withdrawal
Agreement that includes a status quo transition period
through December 2020, which can be extended if both
sides agree.
Background: Although first sighted by an English navigator in
1592, the first landing (English) did not occur until almost a
century later in 1690, and the first settlement (French) was
not established until 1764. The colony was turned over to
Spain two years later and the islands have since been the
subject of a territorial dispute, first between Britain and
Spain, then between Britain and Argentina. The UK
asserted its claim to the islands by establishing a naval
garrison there in 1833. Argentina invaded the islands on 2
April 1982. The British responded with an expeditionary
force that landed seven weeks later and after fierce
fighting forced an Argentine surrender on 14 June 1982.
With hostilities ended and Argentine forces withdrawn, UK
administration resumed. In response to renewed calls from
Argentina for Britain to relinquish control of the islands, a
referendum was held in March 2013, which resulted in
99.8% of the population voting to remain a part of the UK.
Background: Saudi Arabia is the birthplace of Islam and home
to Islam’s two holiest shrines in Mecca and Medina. The
king’s official title is the Custodian of the Two Holy
Mosques. The modern Saudi state was founded in 1932 by
ABD AL-AZIZ bin Abd al-Rahman Al SAUD (Ibn Saud) after
a 30-year campaign to unify most of the Arabian Peninsula.
One of his male descendants rules the country today, as
required by the country’s 1992 Basic Law. Following Iraq’s
invasion of Kuwait in 1990, Saudi Arabia accepted the
Kuwaiti royal family and 400,000 refugees while allowing
Western and Arab troops to deploy on its soil for the
liberation of Kuwait the following year. The continuing
presence of foreign troops on Saudi soil after the liberation
of Kuwait became a source of tension between the royal
family and the public until all operational US troops left the
country in 2003. Major terrorist attacks in May and
November 2003 spurred a strong ongoing campaign
against domestic terrorism and extremism. US troops
returned to the Kingdom in October 2019 after attacks on
Saudi oil infrastructure.
From 2005 to 2015, King ABDALLAH bin Abd al-Aziz Al
Saud incrementally modernized the Kingdom. Driven by
personal ideology and political pragmatism, he introduced
a series of social and economic initiatives, including
expanding employment and social opportunities for women,
attracting foreign investment, increasing the role of the
private sector in the economy, and discouraging businesses
from hiring foreign workers. These reforms have
accelerated under King SALMAN bin Abd al-Aziz, who
ascended to the throne in 2015, and has since lifted the
Kingdom’s ban on women driving and allowed cinemas to
operate for the first time in decades. Saudi Arabia saw
some protests during the 2011 Arab Spring but not the
level of bloodshed seen in protests elsewhere in the region.
Shia Muslims in the Eastern Province protested primarily
against the detention of political prisoners, endemic
discrimination, and Bahraini and Saudi Government actions
in Bahrain. Riyadh took a cautious but firm approach by
arresting some protesters but releasing most of them
quickly and by using its state-sponsored clerics to counter
political and Islamist activism.
The government held its first-ever elections in 2005 and
2011, when Saudis went to the polls to elect municipal
councilors. In December 2015, women were allowed to vote
and stand as candidates for the first time in municipal
council elections, with 19 women winning seats. After King
SALMAN ascended to the throne in 2015, he placed the
first next-generation prince, MUHAMMAD BIN NAYIF bin
Abd al-Aziz Al Saud, in the line of succession as Crown
Prince. He designated his son, MUHAMMAD BIN SALMAN
bin Abd al-Aziz Al Saud, as the Deputy Crown Prince. In
March 2015, Saudi Arabia led a coalition of 10 countries in
a military campaign to restore the legitimate government
of Yemen, which had been ousted by Huthi forces allied
with former president ALI ABDULLAH al-Salih. The war in
Yemen has drawn international criticism for civilian
casualties and its effect on the country’s dire humanitarian
situation. In December 2015, then Deputy Crown Prince
MUHAMMAD BIN SALMAN announced Saudi Arabia would
lead a 34-nation Islamic Coalition to fight terrorism (it has
since grown to 41 nations). In May 2017, Saudi Arabia
inaugurated the Global Center for Combatting Extremist
Ideology (also known as “Etidal”) as part of its ongoing
efforts to counter violent extremism. In June 2017, King
SALMAN elevated MUHAMMAD BIN SALMAN to Crown
Prince.
The country remains a leading producer of oil and
natural gas and holds about 16% of the world’s proven oil
reserves as of 2015. The government continues to pursue
economic reform and diversification, particularly since
Saudi Arabia’s accession to the WTO in 2005, and promotes
foreign investment in the Kingdom. In April 2016, the Saudi
Government announced a broad set of socio-economic
reforms, known as Vision 2030. Low global oil prices
throughout 2015 and 2016 significantly lowered Saudi
Arabia’s governmental revenue. In _ response, _ the
government cut subsidies on water, electricity, and
gasoline; reduced government employee compensation
packages; and announced limited new land taxes. In
coordination with OPEC and some key non-OPEC countries,
Saudi Arabia agreed cut oil output in early 2017 to regulate
supply and help elevate global prices.','65d5d70f4ba414bee8f582188ae66e550d8f2d1824336016d9d1fba8dccca68d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1689f5fe6d03572ca59df10f7c5ce11c7c5bb783260224f2095c1db394ff36e',2020,'FO','Faroe Islands','introduction',504,'Background: The population of the Faroe Islands is largely
descended from Viking settlers who arrived in the 9th
century. The islands have been connected politically to
Denmark since the 14th century. A high degree of self-
government was granted the Faroese in 1948, who have
autonomy over most internal affairs while Denmark is
responsible for justice, defense, and foreign affairs. The
Faroe Islands are not part of the European Union.','b420d3043cd757a7539815040b6d8d1ab75f89b5d99092b956fa985d24341efe','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d0326b67983d48e376b5e0b3e5ac831c2f4098c7a9d24d9257bfe218cc6bf8c',2020,'EE','Estonia','introduction',512,'Background: Finland was a province and then a grand duchy
under Sweden from the 12th to the 19th centuries, and an
autonomous grand duchy of Russia after 1809. It gained
complete independence in 1917. During World War II,
Finland successfully defended its independence through
cooperation with Germany and resisted subsequent
invasions by the Soviet Union—albeit with some loss of
territory. In the subsequent half century, Finland
transformed from a farm/forest economy to a diversified
modern industrial economy; per capita income is among
the highest in Western Europe. A member of the EU since
1995, Finland was the only Nordic state to join the euro
single currency at its initiation in January 1999. In the 21st
century, the key features of Finland’s modern welfare state
are high quality education, promotion of equality, and a
national social welfare system—currently challenged by an
aging population and the fluctuations of an export-driven','f7b1be4b009d798a60389ef1f1747264e40c1b8061739d3ae93eca4cbfd85d88','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89ed054f36864ff1f1d0358d1818b93e761bfac6ac92d9ce585e5d376d82b615',2020,'IL','Israel','introduction',527,'Background: Inhabited since at least the 15th century B.C.,
the Gaza Strip has been dominated by many different
peoples and empires throughout its history; it was
incorporated into the Ottoman Empire in the early 16th
century. The Gaza Strip fell to British forces during World
War I, becoming a part of the British Mandate of Palestine.
Following the 1948 Arab-Israeli War, Egypt administered
the newly formed Gaza Strip; Israel captured it in the Six-
Day War in 1967. Under a series of agreements known as
the Oslo accords signed between 1993 and 1999, Israel
transferred to the newly-created Palestinian Authority (PA)
security and civilian responsibility for many Palestinian-
populated areas of the Gaza Strip as well as the West Bank.
In 2000, a violent intifada or uprising began, and in 2001
negotiations to determine the permanent status of the West
bank and Gaza Strip stalled. Subsequent attempts to re-
start negotiations have not resulted in progress toward
determining final status of the Israeli-Palestinian conflict.
Israel by late 2005 unilaterally withdrew all of its
settlers and soldiers and dismantled its military facilities in
the Gaza Strip, but it continues to control the Gaza Strip’s
land and maritime borders and airspace. In early 2006, the
Islamic Resistance Movement (HAMAS) won a majority in
the Palestinian Legislative Council election. Attempts to
form a unity government between Fatah, the dominant
Palestinian political faction in the West Bank, and HAMAS
failed, leading to violent clashes between their respective
supporters and HAMAS’s violent seizure of all military and
governmental institutions in the Gaza Strip in June 2007.
Since HAMAS’s takeover, Israel and Egypt have enforced
tight restrictions on movement and access of goods and
individuals into and out of the territory. Fatah and HAMAS
have since reached a series of agreements aimed at
restoring political unity between the Gaza Strip and the
West Bank but have struggled to enact them; a
reconciliation agreement signed in October 2017 remains
unimplemented.
In July 2014, HAMAS and other Gaza-based militant
groups engaged in a 51-day conflict with Israel culminating
in late August with an open-ended truce. Since 2014,
Palestinian militants and the Israel Defense Forces have
exchanged projectiles and air strikes’ respectively,
sometimes lasting multiple days and resulting in multiple
deaths on both sides. Egypt, Qatar, and the UN Special
Coordinator for the Middle East Peace Process have
negotiated multiple ceasefires to avert a broader conflict.
Since March 2018, HAMAS has coordinated weekly
demonstrations along the Gaza security fence, many of
which have turned violent, resulting in one Israeli soldier
death and several Israeli soldier injuries as well as more
than 200 Palestinian deaths and thousands of injuries.
Background: The region of present day Georgia contained the
ancient kingdoms of Colchis and Kartli-Iberia. The area
came under Roman influence in the first centuries A.D., and
Christianity became the state religion in the 330s.
Domination by Persians, Arabs, and Turks was followed by
a Georgian golden age (11th-13th centuries) that was cut
short by the Mongol invasion of 1236. Subsequently, the
Ottoman and Persian empires competed for influence in the
region. Georgia was absorbed into the Russian Empire in
the 19th century. Independent for three years (1918-1921)
following the Russian’ revolution, it was_ forcibly
incorporated into the USSR in 1921 and regained its
independence when the Soviet Union dissolved in 1991.
Mounting public discontent over rampant corruption
and ineffective government services, followed by an
attempt by the incumbent Georgian Government to
manipulate parliamentary elections in November 2003,
touched off widespread protests that led to the resignation
of Eduard SHEVARDNADZE, president since 1995. In the
aftermath of that popular movement, which became known
as the “Rose Revolution,” new elections in early 2004
swept Mikheil SAAKASHVILI into power along with his
United National Movement (UNM) party. Progress on
market reforms and democratization has been made in the
years since independence, but this progress has been
complicated by Russian assistance and support to the
separatist regions of Abkhazia and South Ossetia. Periodic
flare-ups in tension and violence culminated in a five-day
conflict in August 2008 between Russia and Georgia,
including the invasion of large portions of undisputed
Georgian territory. Russian troops pledged to pull back
from most occupied Georgian territory, but in late August
2008 Russia unilaterally recognized the independence of
Abkhazia and South Ossetia, and Russian military forces
remain in those regions.
Billionaire Bidzina IVANISHVILI’s unexpected entry into
politics in October 2011 brought the divided opposition
together under his Georgian Dream coalition, which won a
majority of seats in the October 2012 parliamentary
elections and removed UNM from power. Conceding defeat,
SAAKASHVILI named IVANISHVILI as prime minister and
allowed Georgian Dream to create a new government.
Giorgi MARGVELASHVILI was inaugurated as president on
17 November 2013, ending a tense year of power-sharing
between SAAKASHVILI and IVANISHVILI. At the time,
these changes in leadership represented unique examples
of a former Soviet state that emerged to conduct
democratic and peaceful government transitions of power.
IVANISHVILI voluntarily resigned from office after the
presidential succession, and Georgia’s legislature on 20
November 2013 confirmed Irakli GARIBASHVILI as his
replacement. GARIBASHVILI was replaced by Giorgi
KVIRIKASHVILI in December 2015. KVIRIKASHVILI
remained prime minister following Georgian Dream’s
success in the October 2016 parliamentary elections,
where the party won a_ constitutional majority.
IVANISHVILI reemerged as Georgian Dream _ party
chairman in April 2018. KVIRIKASHVILI resigned in June
2018 and was replaced by Mamuka BAKHTADZE. In
September 2019, BAKHTADZE resigned and _ Giorgi
GAKHARIA was named the country’s new head of
government, Georgia’s fifth prime minister in seven years.
Popular and government support for integration with the
West is high in Georgia. Joining the EU and NATO are
among the country’s top foreign policy goals.','a77decc895b3d325f3faaa1f9dc911a8d1aa34d1b63032505a7dcc96b295df80','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('100844d6596afc23bc64418f8b3ae95ad281243f2761f44d352da30eccdf0582',2020,'AT','Austria','introduction',538,'Background: As Europe’s largest economy and second most
populous nation (after Russia), Germany is a key member of
the continent’s economic, political, and defense
organizations. European power struggles immersed
Germany in two devastating world wars in the first half of
the 20th century and left the country occupied by the
victorious Allied powers of the US, UK, France, and the
Soviet Union in 1945. With the advent of the Cold War, two
German states were formed in 1949: the western Federal
Republic of Germany (FRG) and the eastern German
Democratic Republic (GDR). The democratic FRG
embedded itself in key western economic and security
organizations, the EC (now the EU) and NATO, while the
communist GDR was on the front line of the Soviet-led
Warsaw Pact. The decline of the USSR and the end of the
Cold War allowed for German reunification in 1990. Since
then, Germany has expended considerable funds to bring
eastern productivity and wages up to western standards. In
January 1999, Germany and 10 other EU countries
introduced a common European exchange currency, the
euro.
Background: Formed from the merger of the British colony of
the Gold Coast and the Togoland trust territory, Ghana in
1957 became the first Sub-Saharan country in colonial
Africa to gain its independence. Ghana endured a series of
coups before Lt. Jerry RAWLINGS took power in 1981 and
banned political parties. After approving a new constitution
and restoring multiparty politics in 1992, RAWLINGS won
presidential elections in 1992 and 1996 but was
constitutionally prevented from running for a third term in
2000. John KUFUOR of the opposition New Patriotic Party
(NPP) succeeded him and was reelected in 2004. John Atta
MILLS of the National Democratic Congress won the 2008
presidential election and took over as head of state, but he
died in July 2012 and was constitutionally succeeded by his
vice president, John Dramani MAHAMA, who subsequently
won the December 2012 presidential election. In 2016,
however, Nana Addo Dankwa AKUFO-ADDO of the NPP
defeated MAHAMA, marking the third time that the
Ghana’s presidency has changed parties since the return to
democracy.
Background: Strategically important, Gibraltar was
reluctantly ceded to Great Britain by Spain in the 1713
Treaty of Utrecht; the British garrison was formally
declared a colony in 1830. In a referendum held in 1967,
Gibraltarians voted overwhelmingly to remain a British
dependency. The subsequent granting of autonomy in 1969
by the UK led Spain to close the border and sever all
communication links. Between 1997 and 2002, the UK and
Spain held a series of talks on establishing temporary joint
sovereignty over Gibraltar. In response to these talks, the
Gibraltar Government called a referendum in late 2002 in
which the majority of citizens voted overwhelmingly
against any sharing of sovereignty with Spain. Since late
2004, Spain, the UK, and Gibraltar have held tripartite
talks with the aim of cooperatively resolving problems that
affect the local population, and work continues on
cooperation agreements in areas such as taxation and
financial services; communications and maritime security;
policy, legal and customs services; environmental
protection; and education and visa services. A new
noncolonial constitution came into force in 2007, and the
European Court of First Instance recognized Gibraltar’s
right to regulate its own tax regime in December 2008. The
UK retains responsibility for defense, foreign relations,
internal security, and financial stability.
Spain and the UK continue to spar over the territory.
Throughout 2009, a dispute over Gibraltar’s claim to
territorial waters extending out three miles gave rise to
periodic non-violent maritime confrontations between
Spanish and UK naval patrols and in 2013, the British
reported a record number of entries by Spanish vessels into
waters claimed by Gibraltar following a dispute over
Gibraltar’s creation of an artificial reef in those waters.
Spain renewed its demands for an eventual return of
Gibraltar to Spanish control after the UK’s June 2016 vote
to leave the EU, but London has dismissed any connection
between the vote and its continued sovereignty over
Gibraltar. The EU has said that Gibraltar will be ouside the
territorial scope of any future UK-EU trade deal and that
separate agreements between the EU and UK regarding
Gibraltar would require Spain’s prior approval.','ce8157838fec37805adf6bd3e9e8d373e6d3e2fb1f34ca7f3955f6dd617889ef','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7741479006a98d1064939edc000ef143e2b329ed1b24a329120866537f306ffd',2020,'GI','Gibraltar','introduction',553,'Background: Greece achieved independence from _ the
Ottoman Empire in 1830. During the second half of the
19th century and the first half of the 20th century, it
gradually added neighboring islands and territories, most
with Greek-speaking populations. In World War II, Greece
was first invaded by Italy (1940) and subsequently occupied
by Germany (1941-44); fighting endured in a protracted
civil war between supporters of the king and other anti-
communist and communist rebels. Following the latter’s
defeat in 1949, Greece joined NATO in 1952. In 1967, a
group of military officers seized power, establishing a
military dictatorship that suspended many political liberties
and forced the king to flee the country. In 1974 following
the collapse of the dictatorship, democratic elections and a
referendum created a parliamentary republic and abolished
the monarchy. In 1981, Greece joined the EC (now the EU);
it became the 12th member of the European Economic and
Monetary Union (EMU) in 2001. Greece has suffered a
severe economic crisis since late 2009, due to nearly a
decade of chronic overspending and structural rigidities.
Beginning in 2010, Greece entered three bailout
agreements—with the European Commission, the European
Central Bank (ECB), the IMF, and the third in 2015 with the
European Stability Mechanism (ESM)—worth in total about
$300 billion. The Greek Government formally exited the
third bailout in August 2018.
Background: Greenland, the world’s largest island, is about
80% ice-capped. Vikings reached the island in the 10th
century from Iceland; Danish colonization began in the
18th century, and Greenland became an integral part of the
Danish Realm in 1953. It joined the European Community
(now the EU) with Denmark in 1973 but withdrew in 1985
over a dispute centered on stringent fishing quotas.
Greenland remains a member of the Overseas Countries
and Territories Association of the EU. Greenland was
granted self-government in 1979 by the Danish parliament;
the law went into effect the following year. Greenland voted
in favor of increased selfrule in November 2008 and
acquired greater responsibility for internal affairs when the
Act on Greenland Self-Government was signed into law in
June 2009. Denmark, however, continues to exercise
control over several policy areas on behalf of Greenland,
including foreign affairs, security, and financial policy in
consultation with Greenland’s Self-Rule Government.','94a1755b5fd186bef0c4e6d48d03ae70fd61790542d9a166a341e70f32e592d3','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37e0c75f3d1c84ba67fe60e30dd1c022579351e458200fc7d1710ea7d8d60aa5',2020,'GD','Grenada','introduction',561,'Background: Spain ceded Guam to the US in 1898. Captured
by the Japanese in 1941, it was retaken by the US three
years later. The military installations on the island are some
of the most strategically important US bases in the Pacific;
they also constitute the island’s most important source of
income and economic stability.','0a8dfeaa4739cb5f71a1847769caff579f7d06bdfc575c31ca28da77d04620f2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5c9b685f7a5299953a83016e45da42f2c80c87feb6c53a3d9d368c53aaff904',2020,'SV','El Salvador','introduction',564,'Background: The Maya civilization flourished in Guatemala
and surrounding regions during the first millennium A.D.
After almost three centuries as a Spanish colony,
Guatemala won its independence in 1821. During the
second half of the 20th century, it experienced a variety of
military and civilian governments, as well as a 36-year
guerrilla war. In 1996, the government signed a peace
agreement formally ending the internal conflict.
Background: Guernsey and the other Channel Islands
represent the last remnants of the medieval Duchy of
Normandy, which held sway in both France and England.
The islands were the only British soil occupied by German
troops in World War II. The Bailiwick of Guernsey is a self-
governing British Crown dependency that is not part of the
United Kingdom. However, the UK Government is
constitutionally responsible for its defense and
international representation. The Bailiwick of Guernsey
consists of the main island of Guernsey and a number of
smaller islands including Alderney, Sark, Herm, Jethou,
Brecghou, and Lihou.','b824361a8592bdd34a1e7f138e3ab4bfab1841304a25675b3a1c4089b77ce9fb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4411734b9a5f84e977d33d49e6e5f4e3a417d673fc54e7272599ec287da0303e',2020,'LR','Liberia','introduction',572,'Background: Guinea is at a turning point after decades of
authoritarian rule since gaining its independence from
France in 1958. Sekou TOURE ruled the country as
president from independence to his death in 1984. Lansana
CONTE came to power in 1984 when the military seized
the government after TOURE’s death. Gen. CONTE
organized and won presidential elections in 1993, 1998,
and 2003, though results were questionable due to a lack in
transparency and neutrality in the electoral process. Upon
CONTE’s death in December 2008, Capt. Moussa Dadis
CAMARA led a military coup, seizing power and suspending
the constitution. His unwillingness to yield to domestic and
international pressure to step down led to heightened
political tensions that peaked in September 2009 when
presidential guards opened fire on an opposition rally
killing more than 150 people. In early December 2009,
CAMARA was wounded in an assassination attempt and
exiled to Burkina Faso. A transitional government led by
Gen. Sekouba KONATE paved the way for Guinea’s
transition to a fledgling democracy. The country held its
first free and competitive democratic presidential and
legislative elections in 2010 and 2013 respectively, and in
October 2015 held a second consecutive presidential
election. Alpha CONDE was reelected to a second five-year
term as president in 2015, and the National Assembly was
seated in January 2014. CONDE’s first cabinet is the first
all-civilian government in Guinea. The country held a
successful political dialogue in August and September 2016
that brought together the government and opposition to
address long-standing tensions. Local elections were held
in February 2018, and disputed results in some of the races
resulted in ongoing protests against CONDE’s government.
Background: Settlement of freed slaves from the US in what
is today Liberia began in 1822; by 1847, the Americo-
Liberians were able to establish a republic. William
TUBMAN, president from 1944-71, did much to promote
foreign investment and to bridge the economic, social, and
political gaps between the descendants of the original
settlers and the inhabitants of the interior. In 1980, a
military coup led by Samuel DOE ushered in a decade of
authoritarian rule. In December 1989, Charles TAYLOR
launched a rebellion against DOE’s regime that led to a
prolonged civil war in which DOE was killed. A period of
relative peace in 1997 allowed for an election that brought
TAYLOR to power, but major fighting resumed in 2000. An
August 2003 peace agreement ended the war and
prompted the resignation of former president Charles
TAYLOR, who was convicted by the UN-backed Special
Court for Sierra Leone in The Hague for his involvement in
Sierra Leone’s civil war. After two years of rule by a
transitional government, democratic elections in late 2005
brought President Ellen JOHNSON SIRLEAF to power. She
subsequently won reelection in 2011 but was challenged to
rebuild Liberia’s economy, particularly following the 2014-
15 Ebola epidemic, and to reconcile a nation still
recovering from 14 years of fighting. Constitutional term
limits barred President JOHNSON SIRLEAF from running
for re-election. Legal challenges delayed the 2017
presidential runoff election, which was eventually won by
George WEAH. In March 2018, the UN completed its 15-
year peacekeeping mission in Liberia.
Background: The Italians supplanted the Ottoman Turks in
the area around Tripoli in 1911 and did not relinquish their
hold until 1943 when they were defeated in World War II.
Libya then passed to UN administration and achieved
independence in 1951. Following a 1969 military coup, Col.
Muammar al-QADHAFI assumed leadership and began to
espouse his political system at home, which was a
combination of socialism and Islam. During the 1970s,
QADHAFI used oil revenues to promote his ideology
outside Libya, supporting subversive and terrorist activities
that included the downing of two airliners—one over
Scotland, another in Northern Africa—and a discotheque
bombing in Berlin. UN sanctions in 1992 isolated QADHAFI
politically and economically following the attacks; sanctions
were lifted in 2003 following Libyan acceptance of
responsibility for the bombings and agreement to claimant
compensation. QADHAFI also agreed to end _ Libya’s
program to develop weapons of mass destruction, and he
made significant strides in normalizing relations with
Western nations.
Unrest that began in several Middle Eastern and North
African countries in late 2010 erupted in Libyan cities in
early 2011. QADHAFI’s brutal crackdown on protesters
spawned a civil war that triggered UN authorization of air
and naval intervention by the international community.
After months of seesaw fighting between government and
opposition forces, the QADHAFI regime was toppled in mid-
2011 and replaced by a transitional government known as
the National Transitional Council (NTC). In 2012, the NTC
handed power to an elected parliament, the General
National Congress (GNC). Voters chose a new parliament
to replace the GNC in June 2014—the House of
Representatives (HOR), which relocated to the eastern city
of Tobruk after fighting broke out in Tripoli and Benghazi in
July 2014.
In December 2015, the UN brokered an agreement
among a broad array of Libyan political parties and social
groups—known as the Libyan Political Agreement (LPA).
Members of the Libyan Political Dialogue, including
representatives of the HoR and GNC, signed the LPA in
December 2015. The LPA called for the formation of an
interim Government of National Accord or GNA, with a
nine-member Presidency Council, the HoR, and an advisory
High Council of State that most ex-GNC members joined.
The LPA’s roadmap for a transition to a new constitution
and elected government was subsequently endorsed by UN
Security Council Resolution 2259, which also called upon
member states to cease official contact with parallel
institutions. In January 2016, the HoR voted to approve the
LPA, including the Presidency Council, while voting against
a controversial provision on security leadership positions
and the Presidency Council’s proposed cabinet of ministers.
In March 2016, the GNA Presidency Council seated itself in
Tripoli. In 2016, the GNA twice announced a slate of
ministers who operate in an acting capacity, but the HoR
did not endorse the ministerial list. The HoR and defunct-
GNC-affiliated political hardliners continued to oppose the
GNA and hamper the LPA’s implementation. In September
2017, UN _ Special Representative Ghassan SALAME
announced a new _ roadmap for national political
reconciliation. SALAME’s plan called for amendments to
the LPA, a national conference of Libyan leaders, and a
constitutional referendum and _ general elections. In
November 2018, the international partners supported
SALAME’s recalibrated Action Plan for Libya that aimed to
break the political deadlock by holding a National
Conference in Libya in 2019 on a timeline for political
transition. The National Conference was delayed following
a failure of the parties to implement an agreement
mediated by SALAME in Abu Dhabi on February 27, and
the subsequent military action by Khalifa HAFTAR’s Libyan
National Army against GNA forces in Tripoli that began in
April 2019.
Background: The Principality of Liechtenstein was
established within the Holy Roman Empire in 1719.
Occupied by both French and Russian troops during the
Napoleonic Wars, it became a sovereign state in 1806 and
joined the German Confederation in 1815. Liechtenstein
became fully independent in 1866 when the Confederation
dissolved. Until the end of World War I, it was closely tied
to Austria, but the economic devastation caused by that
conflict forced Liechtenstein to enter into a customs and
monetary union with Switzerland. Since World War II (in
which Liechtenstein remained neutral), the country’s low
taxes have spurred outstanding economic growth. In 2000,
shortcomings in banking regulatory oversight resulted in
concerns about the use of financial institutions for money
laundering. However, Liechtenstein implemented anti-
money laundering legislation and a Mutual Legal
Assistance Treaty with the US that went into effect in 2003.','b939d1436e6a2151b0e4868739bdb2cfcf9f95ae55091e5ea093d46e5108353f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6310b723d2321fc2c421a784f6759e771bc295f57a03ed2baed4b3e4fe190d88',2020,'IT','Italy','introduction',584,'Background: Popes in their secular role ruled portions of the
Italian peninsula for more than a thousand years until the
mid-19th century, when many of the Papal States were
seized by the newly united Kingdom of Italy. In 1870, the
pope’s holdings were further circumscribed when Rome
itself was annexed. Disputes between a series of “prisoner”
popes and Italy were resolved in 1929 by three Lateran
Treaties, which established the independent state of
Vatican City and granted Roman Catholicism special status
in Italy. In 1984, a concordat between the Holy See and
Italy modified certain of the earlier treaty provisions,
including the primacy of Roman Catholicism as the Italian
state religion. Present concerns of the Holy See include
religious freedom, threats against minority Christian
communities in Africa and the Middle East, the plight of
refugees and migrants, sexual misconduct by clergy,
international development, interreligious dialogue and
reconciliation, and the application of church doctrine in an
era of rapid change and globalization. About 1.3 billion
people worldwide profess Catholicism—the world’s largest
Christian faith.','ba34182828269a4b5c0f8bd58c0e0774bbd8d78cd01f75fcb648144fa362537f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b1af0680a0f8224bfc987805850b8ef562c5330a16325a6ccd16d07ab52f0f7',2020,'IE','Ireland','introduction',593,'Background: Celtic tribes arrived on the island between 600
and 150 B.C. Invasions by Norsemen that began in the late
8th century were finally ended when King Brian BORU
defeated the Danes in 1014. Norman invasions began in the
12th century and set off more than seven centuries of
Anglo-Irish struggle marked by fierce rebellions and harsh
repressions. The Irish famine of the mid-19th century was
responsible for a drop in the island’s population by more
than one quarter through starvation, disease, and
emigration. For more than a century afterward, the
population of the island continued to fall only to begin
growing again in the 1960s. Over the last 50 years,
Ireland’s high birthrate has made it demographically one of
the youngest populations in the EU.
The modern Irish state traces its origins to the failed
1916 Easter Monday Uprising that touched off several
years of guerrilla warfare resulting in independence from
the UK in 1921 for 26 southern counties; six northern
(Ulster) counties remained part of the UK. Deep sectarian
divides between the Catholic and Protestant populations
and systemic discrimination in Northern Ireland erupted
into years of violence known as the “Troubles” that began
in the 1960s. The Government of Ireland was part of a
process along with the UK and US Governments that
helped broker the Good Friday Agreement in Northern
Ireland in 1998. This initiated a new phase of cooperation
between the Irish and British Governments. Ireland was
neutral in World War II and continues its policy of military
neutrality. Ireland joined the European Community in 1973
and the euro-zone currency union in 1999. The economic
boom years of the Celtic Tiger (1995-2007) saw rapid
economic growth, which came to an abrupt end in 2008
with the meltdown of the Irish banking system. Today the
economy is recovering, fueled by large and growing foreign
direct investment, especially from US multi-nationals.
Background: Part of the Norwegian Kingdom of the Hebrides
until the 13th century when it was ceded to Scotland, the
isle came under the British crown in 1765. Current
concerns include reviving the almost extinct Manx Gaelic
language. The Isle of Man is a British Crown dependency,
which makes it a self-governing possession of the British
Crown that is not part of the UK. The UK Government,
however, remains constitutionally responsible for its
defense and international representation.','f415aefe4b5836bf0e76ef881df1ed28d43881394a2a77e114608a41320ef7eb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d85a10071dabd28cb87ca71c77b204292e40a67e77fdf670732c0756f083acb',2020,'EG','Egypt','introduction',604,'Background: The State of Israel was declared in 1948, after
Britain withdrew from its mandate of Palestine. The UN
proposed partitioning the area into Arab and Jewish states,
and Arab armies that rejected the UN plan were defeated.
Israel was admitted as a member of the UN in 1949 and
saw rapid population growth, primarily due to migration
from Europe and the Middle East, over the following years.
Israel fought wars against its Arab neighbors in 1967 and
1973, followed by peace treaties with Egypt in 1979 and
Jordan in 1994. Israel took control of the West Bank and
Gaza Strip in the 1967 war, and subsequently administered
those territories through military authorities. Israel and
Palestinian officials signed a number of interim agreements
in the 1990s that created an interim period of Palestinian
selfrule in the West Bank and Gaza. Israel withdrew from
Gaza in 2005. While the most recent formal efforts to
negotiate final status issues occurred in 2013-2014, the US
continues its efforts to advance peace. Immigration to
Israel continues, with 28,600 new immigrants, mostly
Jewish, in 2016. The Israeli economy has undergone a
dramatic transformation in the last 25 years, led by cutting-
edge, high-tech sectors. Offshore gas discoveries in the
Mediterranean, most notably in the Tamar and Leviathan
gas fields, place Israel at the center of a potential regional
natural gas market. However, longer-term structural issues
such as low labor force participation among minority
populations, low workforce productivity, high costs for
housing and consumer staples, and a lack of competition,
remain a concern for many Israelis and an important
consideration for Israeli politicians. Prime Minister
Benjamin NETANYAHU has led the Israeli Government
since 2009; he formed a center-right coalition following the
2015 elections. In December 2018 the Knesset voted to
dissolve itself, leading to an election in April 2019. When
that election failed to result in formation of a government,
Israel held a second election in September 2019, which
also failed to result in the formation of a government. On
11 December 2019, the Knesset voted to hold a third
election on 2 March 2020.
ej] ole) v Nah
Location: Middle East, bordering the Mediterranean Sea,
between Egypt and Lebanon
Geographic coordinates: 31 30 N, 3445 E
Map references: Middle East
Area: total: 21,937 sq km
land: 21,497 sq km
water: 440 sq km
country comparison to the world: 153
Area—comparative: Slightly larger than New Jersey
Land boundaries: total: 1,065 km
border countries (6): Egypt 206 km, Gaza Strip 59 km,
Jordan 336 km (20 km are within the Dead Sea), Lebanon
107 km, Syria 79 km, West Bank 278 km Coastline: 273 km
Maritime claims: territorial sea: 12 nm
continental shelf: to depth of exploitation
Climate: temperate; hot and dry in southern and eastern
desert areas
Terrain: Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley Elevation: mean elevation: 508
m note—does not include elevation data from the Golan
Heights lowest point: Dead Sea -431 m
highest point: Mitspe Shlagim 2,224 m; note—this is the
highest named point, the actual highest point is an
unnamed dome slightly to the west of Mitspe Shlagim at
2,236 m; both points are on the northeastern border of
Israel, along the southern end of the Anti-Lebanon
mountain range Natural resources: timber, potash, copper ore,
natural gas, phosphate rock, magnesium bromide, clays,
sand Land use: agricultural land: 23.8% (2011 est.)
arable land: 13.7% (2011 est.) / permanent crops: 3.8%
(2011 est.) / permanent pasture: 6.3% (2011 est.) forest:
7.1% (2011 est.)
other: 69.1% (2011 est.)
Irrigated land: 2,250 sq km (2012)
Population distribution: population concentrated in and around
Tel-Aviv, as well as around the Sea of Galilee; the south
remains sparsely populated with the exception of the shore
of the Gulf of Aqaba Natural hazards: sandstorms may occur
during spring and summer; droughts; periodic earthquakes
Environment—current issues: limited arable land and restricted
natural freshwater resources; desertification; air pollution
from industrial and vehicle emissions; groundwater
pollution from industrial and domestic waste, chemical
fertilizers, and pesticides Environment—international agreements:
party to: Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling signed, but not ratified: Marine Life
Conservation
Geography—note: note 1: Lake Tiberias (Sea of Galilee) is an
important freshwater source; the Dead Sea is the second
saltiest body of water in the world (after Lake Assal in
Djibouti) note 2: the Malham Cave in Mount Sodom is the
world’s longest salt cave at 10 km (6 mi); its survey is not
complete and its length will undoubtedly increase; Mount
Sodom is actually a hill some 220 m (722 ft) high that is
80% salt (multiple salt layers covered by a veneer of rock)
note 3: in March 2019, there were 380 Israeli settlements,
to include 213 settlements and 132 outposts in the West
Bank, and 35 settlements in East Jerusalem; there are no
Israeli settlements in the Gaza Strip, as all were evacuated
in 2005 (2019) PEOPLE AND SOCIETY
Population: 8,675,475 (includes populations of the Golan
Heights or Golan Sub-District and also East Jerusalem,
which was annexed by Israel after 1967) (July 2020 est.)
note: approximately 22,000 Israeli settlers live in the Golan
Heights (2016); approximately 201,000 Israeli settlers live
in East Jerusalem (2014) country comparison to the world:
98
Nationality: Noun: Israeli(s)
adjective: Israeli
Ethnic groups: Jewish 74.4% (of which Israel-born 76.9%,
Europe/America/Oceania-born 15.9%, Africa-born 4.6%,
Asia-born 2.6%), Arab 20.9%, other 4.7% (2018 est.)
Languages: Hebrew (official), Arabic (special status under
Israeli law), English (most commonly used foreign
language) Religions: Jewish 74.3%, Muslim 17.8%, Christian
1.9%, Druze 1.6%, other 4.4% (2018 est.)
Age structure: 0-14 years: 26.76% (male 1,187,819/female
1,133,365) 15-24 years: 15.67% (male 694,142/female
665,721)
25-54 years: 37.2% (male 1,648,262/female 1,579,399)
95-64 years: 8.4% (male 363,262/female 365,709)
65 years and over: 11.96% (male 467,980/female 569,816)
(2020 est.)
Dependency ratios: total dependency ratio: 64.2 (2015 est.)
youth dependency ratio: 45.7 (2015 est.)
elderly dependency ratio: 18.4 (2015 est.)
potential support ratio: 5.4 (2015 est.)
Median age: total: 30.4 years
male: 29.8 years
female: 31 years (2020 est.)
country comparison to the world: 121
Population growth rate: 1.46% (2020 est.)
country comparison to the world: 74
Birth rate: 17.6 births/1,000 population (2020 est.)
country comparison to the world: 94
Death rate: 5.3 deaths/1,000 population (2020 est.)
country comparison to the world: 190
Net migration rate: 2.1 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 48
Population distribution: population concentrated in and around
Tel-Aviv, as well as around the Sea of Galilee; the south
remains sparsely populated with the exception of the shore
of the Gulf of Aqaba Urbanization: urban population: 92.6% of
total population (2020)
rate of urbanization: 1.64% annual rate of change (2015-20
est.)
Major urban areas—population: 4.181 million Tel Aviv-Yafo,
1.147 million Haifa, 932,000 JERUSALEM (capital) (2020)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.04 male(s)/female (2020 est.)
25-54 years: 1.04 male(s)/female (2020 est.)
55-64 years: 0.99 male(s)/female (2020 est.)
65 years and over: 0.82 male(s)/female (2020 est.)
total population: 101.1 male(s)/female (2020 est.)
Mother’s mean age at first birth: 27.6 years (2015 est.)
Maternal mortality rate: 3 deaths/100,000 live births (2017
est.)
country comparison to the world: 179
Infant mortality rate: total: 3.3 deaths/1,000 live births
male: 3.3 deaths/1,000 live births
female: 3.3 deaths/1,000 live births (2020 est.)
country comparison to the world: 208
Life expectancy at birth: total population: 83 years
male: 81.1 years
female: 85 years (2020 est.)
country comparison to the world: 10
Total fertility rate: 2.59 children born/woman (2020 est.)
country comparison to the world: 68
Drinking water source:
improved:
urban: 100% of population
rural: 100% of population
total: 100% of population
unimproved:
urban: 0% of population
rural: 0% of population
total: 0% of population (2015 est.)
Current Health Expenditure: 7.3% (2016)
Physicians density: 3.22 physicians/1,000 population (2016)
Hospital bed density: 3.1 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 100% of population (2015 est.)
rural: 100% of population (2015 est.)
total: 100% of population (2015 est.)
unimproved:
urban: 0% of population (2015 est.)
rural: 0% of population (2015 est.)
total: 0% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.2% (2018)
country comparison to the world: 101
HIV/AIDS—people living with HIV/AIDS: 9,000 (2018)
country comparison to the world: 104
HIV/AIDS—deaths: <100 (2018)
Obesity—adult prevalence rate: 26.1% (2016)
country comparison to the world: 44
Education expenditures: 5.8% of GDP (2016)
country comparison to the world: 33
Literacy: definition: age 15 and over can read and write
total population: 97.8%
male: 98.7%
female: 96.8% (2011)
School life expectancy (primary to tertiary education): total: 16
years male: 15 years
female: 17 years (2016)
Unemployment, youth ages 15-24: total: 7.3%
male: 6.7%
female: 7.8% (2017 est.)
country comparison to the world: 153','89cf0c7ae5bccdcb2748e3a3bdbf89349af3173fdf508dfc3971fa6bf344d709','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('927a05cf82f50289b981d16075c34d4474f538cf20d2e3311a612ece60b578f8',2020,'JO','Jordan','introduction',617,'Background: Following World War I and the dissolution of the
Ottoman Empire, the League of Nations awarded Britain
the mandate to govern much of the Middle East. Britain
demarcated a semi-autonomous region of Transjordan from
Palestine in the early 1920s. The area gained its
independence in 1946 and thereafter became The
Hashemite Kingdom of Jordan. The country’s long-time
ruler, King HUSSEIN (1953-99), successfully navigated
competing pressures from the major powers (US, USSR,
and Uk), various Arab states, Israel, and a large internal
Palestinian population. Jordan lost the West Bank to Israel
in the 1967 Six-Day War. King HUSSEIN in 1988
permanently relinquished Jordanian claims to the West
Bank; in 1994 he signed a peace treaty with Israel. King
ABDALLAH II, King HUSSEIN’s eldest son, assumed the
throne following his father’s death in 1999. He has
implemented modest political reforms, including the
passage of a new electoral law in early 2016 and an effort
to devolve some authority to governorate- and municipal-
level councils following subnational elections in 2017. In
2016, the Islamic Action Front, which is the political arm of
the Jordanian Muslim Brotherhood, returned to the
National Assembly with 15 seats after boycotting the
previous two elections in 2010 and 2013.
Background: Ethnic Kazakhs, a mix of Turkic and Mongol
nomadic tribes with additional Persian cultural influences,
migrated to the region in the 15th century. The area was
conquered by Russia in the 18th and 19th centuries, and
Kazakhstan became a Soviet Republic in 1925. Repression
and starvation associated with forced agricultural
collectivization led to a massive number of deaths in the
1930s. During the 1950s and 1960s, the agricultural
“Virgin Lands” program led to an influx of settlers (mostly
ethnic Russians, but also other nationalities) and at the
time of Kazakhstan’s independence in 1991, ethnic Kazakhs
were a minority. Non-Muslim ethnic minorities departed
Kazakhstan in large numbers from the mid-1990s through
the mid-2000s and a national program has repatriated
about a million ethnic Kazakhs (from Uzbekistan,
Tajikistan, Mongolia, and the Xinjiang region of China)
back to Kazakhstan. As a result of this shift, the ethnic
Kazakh share of the population now exceeds two-thirds.
Kazakhstan’s economy is the largest in the Central Asian
states, mainly due to the country’s vast natural resources.
Current issues include: diversifying the economy, obtaining
membership in global and regional international economic
institutions, enhancing Kazakhstan’s economic
competitiveness, and_ strengthening’ relations with
neighboring states and foreign powers.','c8f8e47267bc303415b84b6fad0942929ac9daa3a48004e11dc169a23e2109a7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50909557be5fb19d257ff4a4f37f4952adc6f3d14e526b6f11efa0a480ee4db7',2020,'KZ','Kazakhstan','introduction',632,'Background: Founding president and liberation struggle icon
Jomo KENYATTA led Kenya from independence in 1963
until his death in 1978, when Vice President Daniel Arap
MOI took power in a constitutional succession. The country
was a de facto one- party state from 1969 until 1982, after
which time the ruling Kenya African National Union
(KANU) changed the constitution to make itself the sole
legal party in Kenya. MOI acceded to internal and external
pressure for political liberalization in late 1991. The
ethnically fractured opposition failed to dislodge KANU
from power in elections in 1992 and 1997, which were
marred by violence and fraud. President MOI stepped down
in December 2002 following fair and peaceful elections.
Mwai KIBAKI, running as the candidate of the multiethnic,
united opposition group, the National Rainbow Coalition
(NARC), defeated KANU candidate Uhuru KENYATTA, the
son of founding president Jomo KENYATTA, and assumed
the presidency following a campaign centered on an
anticorruption platform.
KIBAKI’s reelection in December 2007 brought charges
of vote rigging from Orange Democratic Movement (ODM)
candidate Raila ODINGA and unleashed two months of
violence in which approximately 1,100 people died. African
Union- sponsored mediation led by former UN Secretary
General Kofi ANNAN in late February 2008 resulted in a
power-sharing accord bringing ODINGA into _ the
government in the restored position of prime minister. The
power sharing accord included a broad reform agenda, the
centerpiece of which was constitutional reform. In August
2010, Kenyans overwhelmingly adopted a new constitution
in a national referendum. The new constitution introduced
additional checks and balances to executive power and
devolved power and resources to 47 newly created
counties. It also eliminated the position of prime minister.
Uhuru KENYATTA won the first presidential election under
the new constitution in March 2013, and was sworn into
office the following month; he began a second term in
November 2017 following a contentious, repeat election.
Background: The Gilbert Islands became a_ British
protectorate in 1892 and a colony in 1915; they were
captured by the Japanese in the Pacific War in 1941. The
islands of Makin and Tarawa were the sites of major US
amphibious victories over entrenched Japanese garrisons in
1943. The Gilbert Islands were granted self-rule by the UK
in 1971 and complete independence in 1979 under the new
name of Kiribati. The US relinquished all claims to the
sparsely inhabited Phoenix and Line Island groups in a
1979 treaty of friendship with Kiribati. Kiribati joined the
UN in 1999 and has been an active participant in
international efforts to combat climate change.
Background: An independent kingdom for much of its long
history, Korea was occupied by Japan beginning in 1905
following the Russo-Japanese War. Five years later, Japan
formally annexed the entire peninsula. Following World
War II, Korea was split with the northern half coming under
Soviet-sponsored communist control. After failing in the
Korean War (1950-53) to conquer the US-backed Republic
of Korea (ROK) in the southern portion by force, North
Korea (DPRK), under its founder President KIM Il Sung,
adopted a policy of ostensible diplomatic and economic
“self-reliance” as a check against outside influence. The
DPRK demonized the US as the ultimate threat to its social
system through state-funded propaganda, and molded
political, economic, and military policies around the core
ideological objective of eventual unification of Korea under
Pyongyang’s control. KIM Il Sung’s son, KIM Jong II, was
officially designated as his father’s successor in 1980,
assuming a growing political and managerial role until the
elder KIM’s death in 1994. Under KIM Jong II’s rein, the
DPRK continued developing nuclear weapons and ballistic
missiles. KIM Jong Un was publicly unveiled as his father’s
successor in 2010. Following KIM Jong II’s death in 2011,
KIM Jong Un quickly assumed power and has since
occupied the regime’s highest political and military posts.
After decades of economic mismanagement and
resource misallocation, the DPRK since the mid-1990s has
faced chronic food shortages. In recent years, the North’s
domestic agricultural production has increased, but still
falls far short of producing sufficient food to provide for its
entire population. The DPRK began to ease restrictions to
allow semi-private markets, starting in 2002, but has made
few other efforts to meet its goal of improving the overall
standard of living. North Korea’s history of regional
military provocations; proliferation of military-related
items; long-range missile development; WMD programs
including tests of nuclear devices in 2006, 2009, 2013,
2016, and 2017; and massive conventional armed forces
are of major concern to the international community and
have limited the DPRK’s international engagement,
particularly economically. In 2013, the DPRK declared a
policy of simultaneous development of its nuclear weapons
program and economy. In late 2017, KIM Jong Un declared
the North’s nuclear weapons development complete. In
2018, KIM announced a pivot towards diplomacy, including
a re-prioritization of economic development, a pause in
missile testing beginning in late 2017, and a refrain from
anti-US rhetoric starting in June 2018. Since 2018, KIM has
participated in four meetings with Chinese President XI
Jinping, three with ROK President MOON Jae-in, and three
with US President TRUMP. Since July 2019, North Korea
has restarted its short-range missile tests and issued
statements condemning the US.
Background: An independent kingdom for much of its long
history, Korea was occupied by Japan beginning in 1905
following the Russo-Japanese War. In 1910, Tokyo formally
annexed the entire Peninsula. Korea regained its
independence following Japan’s surrender to the US in
1945. After World War II, a democratic government
(Republic of Korea, ROK) was set up in the southern half of
the Korean Peninsula while a communist-style government
was installed in the north (Democratic People’s Republic of
Korea, DPRK). During the Korean War (1950-53), US troops
and UN forces fought alongside ROK soldiers to defend
South Korea from a DPRK invasion supported by
communist China and the Soviet Union. A 1953 armistice
split the Peninsula along a demilitarized zone at about the
38th parallel. PARK Chung-hee took over leadership of the
country in a 1961 coup. During his regime, from 1961 to
1979, South Korea achieved rapid economic growth, with
per capita income rising to roughly 17 times the level of
North Korea in 1979.
South Korea held its first free presidential election
under a revised democratic constitution in 1987, with
former ROK Army general ROH Tae-woo winning a close
race. In 1993, KIM Young-sam (1993-98) became the first
civilian president of South Korea’s new democratic era.
President KIM Dae-jung (1998-2003) won the Nobel Peace
Prize in 2000 for his contributions to South Korean
democracy and his “Sunshine” policy of engagement with
North Korea. President PARK Geun-hye, daughter of former
ROK President PARK Chung-hee, took office in February
2013 as South Korea’s first female leader. In December
2016, the National Assembly passed an impeachment
motion against President PARK over her _ alleged
involvement in a corruption and influence-peddling scandal,
immediately suspending her presidential authorities. The
impeachment was upheld in March 2017, triggering an
early presidential election in May 2017 won by MOON Jae-
in. South Korea hosted the Winter Olympic and Paralympic
Games in February 2018, in which North Korea also
participated. Discord with North Korea has permeated
inter-Korean relations for much of the past decade,
highlighted by the North’s attacks on a South Korean ship
and island in 2010, the exchange of artillery fire across the
DMZ in 2015, and multiple nuclear and missile tests in
2016 and 2017. North Korea’s participation in the Winter
Olympics, dispatch of a senior delegation to Seoul, and
three inter-Korean summits in 2018 appear to have ushered
in a temporary period of respite, buoyed by the historic US-
DPRK summits in 2018 and 2019.
Background: Present-day Turkmenistan covers territory that
has been at the crossroads of civilizations for centuries.
The area was ruled in antiquity by various Persian empires,
and was conquered by Alexander the Great, Muslim armies,
the Mongols, Turkic warriors, and eventually the Russians.
In medieval times, Merv (located in present-day Mary
province) was one of the great cities of the Islamic world
and an important stop on the Silk Road. Annexed by Russia
in the late 1800s, Turkmenistan later figured prominently
in the anti-Bolshevik movement in Central Asia. In 1924,
Turkmenistan became a Soviet republic; it achieved
independence upon the dissolution of the USSR in 1991.
President for Life Saparmyrat NYYAZOW died in December
2006, and Gurbanguly BERDIMUHAMEDOW, a deputy
chairman under NYYAZOW, emerged as the country’s new
president. BERDIMUHAMEDOW won Turkmenistan’s first
multi-candidate presidential election in February 2007, and
again in 2012 and in 2017 with over 97% of the vote in both
instances, in elections widely regarded as undemocratic.
Turkmenistan has sought new export markets for its
extensive hydrocarbon/natural gas reserves, which have yet
to be fully exploited. As of late 2019, Turkmenistan
exported the majority of its gas to China and small levels of
gas were also being sent to Russia. Turkmenistan’s reliance
on gas exports has made the economy vulnerable to
fluctuations in the global energy market, and economic
hardships since the drop in energy prices in 2014 have led
many Turkmenistanis to emigrate, mostly to Turkey.
Background: The islands were part of the UK’s Jamaican
colony until 1962, when they assumed the status of a
separate Crown colony upon Jamaica’s independence. The
governor of The Bahamas oversaw affairs from 1965 to
1973. With Bahamian independence, the islands received a
separate governor in 1973. Although independence was
agreed upon for 1982, the policy was reversed and the
islands remain a British overseas territory. Grand Turk
island suffered extensive damage from Hurricane Maria on
22 September 2017 resulting in loss of power and
communications as well as damage to housing and
businesses.
Background: In 1974, ethnic differences within the British
colony of the Gilbert and Ellice Islands caused the
Polynesians of the Ellice Islands to vote for separation from
the Micronesians of the Gilbert Islands. The following year,
the Ellice Islands became the separate British colony of
Tuvalu. Independence was granted in 1978. In 2000,
Tuvalu negotiated a contract leasing its Internet domain
name “.tv” for $50 million in royalties over a 12-year
period. The agreement was subsequently renegotiated but
details were not disclosed. Tuvalu will host the Pacific
Islands Forum Leaders Meeting in August 2019.','b64ee5b69e7e87d16dea5eee142856ea3a8f6d2013588a67807031bb40f3413b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bee7ae6636dd896cb21426e87504805a4c9bfe542fc06fbb6a0e078a8bd324e',2020,'RS','Serbia','introduction',641,'Background: The central Balkans were part of the Roman and
Byzantine Empires before ethnic Serbs migrated to the
territories of modern Kosovo in the 7th century. During the
medieval period, Kosovo became the center of a Serbian
Empire and saw the construction of many important Serb
religious sites, including many architecturally significant
Serbian Orthodox monasteries. The defeat of Serbian
forces at the Battle of Kosovo in 1389 led to five centuries
of Ottoman rule during which large numbers of Turks and
Albanians moved to Kosovo. By the end of the 19th century,
Albanians replaced Serbs as the dominant ethnic group in
Kosovo. Serbia reacquired control over the region from the
Ottoman Empire during the First Balkan War of 1912. After
World War II, Kosovo’s present-day boundaries were
established when Kosovo became an autonomous province
of Serbia in the Socialist Federal Republic of Yugoslavia
(S.F.R.Y.). Despite legislative concessions, Albanian
nationalism increased in the 1980s, which led to riots and
calls for Kosovo’s independence. The Serbs—many of whom
viewed Kosovo as their cultural heartland—instituted a new
constitution in 1989 revoking Kosovo’s autonomous status.
Kosovo’s Albanian leaders responded in 1991 by organizing
a referendum declaring Kosovo independent. Serbia
undertook repressive measures against the Kosovar
Albanians in the 1990s, provoking a Kosovar Albanian
insurgency.
Beginning in 1998, Serbia conducted a_ brutal
counterinsurgency campaign that resulted in massacres
and massive expulsions of ethnic Albanians (some 800,000
ethnic Albanians were forced from their homes in Kosovo).
After international attempts to mediate the conflict failed, a
three-month NATO military operation against Serbia
beginning in March 1999 forced the Serbs to agree to
withdraw their military and police forces from Kosovo. UN
Security Council Resolution 1244 (1999) placed Kosovo
under a transitional administration, the UN Interim
Administration Mission in Kosovo (UNMIK), pending a
determination of Kosovo’s future status. A UN-led process
began in late 2005 to determine Kosovo’s final status. The
2006-07 negotiations ended without agreement between
Belgrade and Pristina, though the UN issued a
comprehensive report on Kosovo’s final status. that
endorsed independence. On 17 February 2008, the Kosovo
Assembly declared Kosovo independent. Since then, over
100 countries have recognized Kosovo, and it has joined
numerous international organizations. In October 2008,
Serbia sought an advisory opinion from the International
Court of Justice (ICJ) on the legality under international law
of Kosovo’s declaration of independence. The ICJ released
the advisory opinion in July 2010 affirming that Kosovo’s
declaration of independence did not violate general
principles of international law, UN Security Council
Resolution 1244, or the Constitutive Framework. The
opinion was closely tailored to Kosovo’s unique history and
circumstances.
Demonstrating Kosovo’s development into a sovereign,
multi-ethnic, democratic country’ the international
community ended the period of Supervised Independence
in 2012. Kosovo held its most recent national and municipal
elections in 2017. Serbia continues to reject Kosovo’s
independence, but the two countries agreed in April 2013
to normalize their relations through EU-facilitated talks,
which produced several subsequent agreements the parties
are engaged in implementing, though they have not yet
reached a comprehensive normalization of relations.
Kosovo seeks full integration into the _ international
community, and has pursued bilateral recognitions and
memberships in international organizations. Kosovo signed
a Stabilization and Association Agreement with the EU in
2015, and was named by a 2018 EU report as one of six
Western Balkan countries that will be able to join the
organization once it meets the criteria to accede. Kosovo
also seeks memberships in the UN and in NATO.
Background: A lengthy struggle between France and Great
Britain for the islands ended in 1814, when they were
ceded to the latter. During colonial rule, a plantation-based
economy developed that relied on imported labor, primarily
from European colonies in Africa. Independence came in
1976. Following a coup d’etat in 1977, the country was a
socialist one-party state until adopting a new constitution
and holding free elections in 1993. President France-Albert
RENE, who had served since 1977, was reelected in 2001,
but stepped down in 2004. Vice President James Alix
MICHEL took over the presidency and in 2006 was elected
to a new five-year term; he was reelected in 2011 and again
in 2015. In 2016, James MICHEL resigned and handed over
the presidency to his vice-president, Danny FAURE.','d6bd92dc30d047e319b4854f4e606c32f930e6ad10dd017cc5be7ab1e3465bbd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fa650652f1cdb928260124146e547ac0786b5ecac9e2e9623192e14afe28385',2020,'KW','Kuwait','introduction',650,'Background: Kuwait has been ruled by the AL-SABAH
dynasty since the 18th century. The threat of Ottoman
invasion in 1899 prompted Amir Mubarak AL-SABAH to
seek protection from Britain, ceding foreign and defense
responsibility to Britain until 1961, when the country
attained its independence. Kuwait was attacked and
overrun by Iraq in August 1990. Following several weeks of
aerial bombardment, a US-led UN coalition began a ground
assault in February 1991 that liberated Kuwait in four days.
In 1992, the Amir reconstituted the parliament that he had
dissolved in 1986. Amid the 2010-11 uprisings and protests
across the Arab world, stateless Arabs, known as Bidoon,
staged small protests in early 2011 demanding citizenship,
jobs, and other benefits available to Kuwaiti nationals.
Other demographic groups, notably Islamists and Kuwaitis
from tribal backgrounds, soon joined the growing protest
movements, which culminated in late 2011 with the
resignation of the prime minister amidst allegations of
corruption. Demonstrations renewed in late 2012 in
response to an amiri decree amending the electoral law
that lessened the voting power of the tribal blocs.
An opposition coalition of Sunni Islamists, tribal
populists, and some liberals, largely boycotted legislative
elections in 2012 and 2013, which ushered in a legislature
more amenable to the government’s agenda. Faced with
the prospect of painful subsidy cuts, oppositionists and
independents actively participated in the November 2016
election, winning nearly half of the seats but a cohesive
opposition alliance largely ceased to exist with the 2016
election and the opposition became increasingly
factionalized. Since coming to power in 2006, the Amir has
dissolved the National Assembly on seven occasions (the
Constitutional Court annulled the Assembly elections in
June 2012 and again in June 2013) and shuffled the cabinet
over a dozen times, usually citing political stagnation and
gridlock between the legislature and the government.
Background: A Central Asian country of incredible natural
beauty and proud nomadic traditions, most of the territory
of the present-day Kyrgyz Republic was formally annexed to
the Russian Empire in 1876. The Kyrgyz staged a major
revolt against the Tsarist Empire in 1916 in which almost
one-sixth of the Kyrgyz population was killed. The Kyrgyz
Republic became a Soviet republic in 1936 and achieved
independence in 1991 when the USSR _ dissolved.
Nationwide demonstrations in 2005 and 2010 resulted in
the ouster of the country’s first two presidents, Askar
AKAEV and Kurmanbek BAKIEV. Interim President Roza
OTUNBAEVA led a transitional government and following a
nation-wide election, President Almazbek ATAMBAEV was
sworn in as president in 2011. In 2017, ATAMBAEV became
the first Kyrgyzstani president to step down after serving
one full six-year term as required in the country’s
constitution. Former prime minister and ruling Social-
Democratic Party of Kyrgyzstan member Sooronbay
JEENBEKOV replaced him after winning an October 2017
presidential election that was the most competitive in the
country’s history, although international and local election
observers noted cases of vote buying and abuse of public
resources. The president holds substantial powers as head
of state even though the prime minister oversees the
Kyrgyzstani Government and_ “selects most’ cabinet
members. The’ president represents the country
internationally and can sign or veto laws, call for new
elections, and nominate Supreme Court judges, cabinet
members for posts related to security or defense, and
numerous other high-level positions. Continuing concerns
for the Kyrgyz Republic include the trajectory of
democratization, endemic corruption, a history of tense,
and at times violent, interethnic relations, border security
vulnerabilities, and potential terrorist threats.
Background: Modern-day Laos has its roots in the ancient Lao
kingdom of Lan Xang, established in the 14th century
under King FA NGUM. For 300 years Lan Xang had
influence reaching into present-day Cambodia and
Thailand, as well as over all of what is now Laos. After
centuries of gradual decline, Laos came under the
domination of Siam (Thailand) from the late 18th century
until the late 19th century, when it became part of French
Indochina. The Franco-Siamese Treaty of 1907 defined the
current Lao border with Thailand. In 1975, the communist
Pathet Lao took control of the government, ending a six-
century-old monarchy and instituting a strict socialist
regime closely aligned to Vietnam. A gradual, limited
return to private enterprise and the liberalization of foreign
investment laws began in 1988. Laos became a member of
ASEAN in 1997 and the WTO in 2013.','8cf76c27c31c81840f42ae356fb3ce8add84882c5ae35c5268c6c84614566cae','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ad2b57d8b6e60cbc52cb3cbb461833750c9617450fcdc5b8956e54d6a5264fb',2020,'BY','Belarus','introduction',661,'Background: Several eastern Baltic tribes merged in medieval
times to form the ethnic core of the Latvian people (ca. 8th-
12th centuries A.D.). The region subsequently came under
the control of Germans, Poles, Swedes, and _ finally,
Russians. A Latvian republic emerged following World War
I, but it was annexed by the USSR in 1940—an action never
recognized by the US and many other countries. Latvia
reestablished its independence in 1991 following the
breakup of the Soviet Union. Although the last Russian
troops left in 1994, the status of the Russian minority
(some 26% of the population) remains of concern to
Moscow. Latvia acceded to both NATO and the EU in the
spring of 2004; it joined the euro zone in 2014 and the
OECD in 2016. A dual citizenship law was adopted in 2013,
easing naturalization for non-citizen children.
Background: Following World War I, France acquired a
mandate over the northern portion of the former Ottoman
Empire province of Syria. The French demarcated the
region of Lebanon in 1920 and granted this area
independence in 1943. Since independence, the country
has been marked by periods of political turmoil
interspersed with prosperity built on its position as a
regional center for finance and trade. The country’s 1975-
90 civil war, which resulted in an estimated 120,000
fatalities, was followed by years of social and _ political
instability. Sectarianism is a key element of Lebanese
political life. Neighboring Syria has historically influenced
Lebanon’s foreign policy and internal policies, and its
military occupied Lebanon from 1976 until 2005. The
Lebanon-based Hizballah militia and Israel continued
attacks and counterattacks against each other after Syria’s
withdrawal, and fought a brief war in 2006. Lebanon’s
borders with Syria and Israel remain unresolved.','33ccdfd07af16e4cfe67ec19de852b1168e7c8549bddcec7964eee34b7f75e80','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f231fceeeec44d3c708d23673eb969dd1d4f19dda9c0028b944166971e6634f1',2020,'MG','Madagascar','introduction',693,'Background: Established in 1891, the British protectorate of
Nyasaland became the independent nation of Malawi in
1964. After three decades of one-party rule under President
Hastings Kamuzu BANDA, the country held multiparty
presidential and parliamentary elections in 1994, under a
provisional constitution that came into full effect the
following year. Bakili MULUZI became the first freely
elected president of Malawi when he won the presidency in
1994; he won re-election in 1999. President Bingu wa
MUTHARIKA, elected in 2004 after a failed attempt by the
previous president to amend the constitution to permit
another term, struggled to assert his authority against his
predecessor and subsequently started his own party, the
Democratic Progressive Party in 2005. MUTHARIKA was
reelected to a second term in 2009. He oversaw some
economic improvement in his first term, but was accused of
economic mismanagement and poor governance in his
second term. He died abruptly in 2012 and was succeeded
by vice president, Joyce BANDA, who had earlier started
her own party, the People’s Party. MUTHARIKA’s brother,
Peter MUTHARIKA, defeated BANDA in the 2014 election;
he was reelected in a disputed 2019 election. Population
growth, increasing pressure on _ agricultural lands,
corruption, and the scourge of HIV/AIDS pose major
problems for Malawi.','a7aabb8b195f2b925ecf42cae99bc41aa7cb882c4de834a6172bf07fe65eaeee','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca0bb9d206d5f90495f2822b4bc8ef293de220d0eb9f057f7ce65849a069f363',2020,'DZ','Algeria','introduction',698,'Background: The Sudanese Republic and Senegal became
independent of France in 1960 as the Mali Federation.
When Senegal withdrew after only a few months, what
formerly made up the Sudanese Republic was renamed
Mali. Rule by dictatorship was brought to a close in 1991
by a military coup that ushered in a period of democratic
rule. President Alpha Oumar KONARE won Mali’s first two
democratic presidential elections in 1992 and 1997. In
keeping with Mali’s two-term constitutional limit, he
stepped down in 2002 and was succeeded by Amadou
Toumani TOURE, who was elected to a second term in a
2007 election that was widely judged to be free and fair.
Malian returnees from Libya in 2011 exacerbated tensions
in northern Mali, and Tuareg ethnic militias rebelled in
January 2012. Low- and mid-level soldiers, frustrated with
the poor handling of the rebellion, overthrew TOURE on 22
March. Intensive mediation efforts led by the Economic
Community of West African States (ECOWAS) returned
power to a civilian administration in April with the
appointment of Interim President Dioncounda TRAORE.
The post-coup chaos led to rebels expelling the Malian
military from the country’s three northern regions and
allowed Islamic militants to set up strongholds. Hundreds
of thousands of northern Malians fled the violence to
southern Mali and neighboring countries, exacerbating
regional food shortages in host communities. A French-led
international military intervention to retake the three
northern regions began in January 2013 and within a
month, most of the north had been retaken. In a democratic
presidential election conducted in July and August of 2013,
Ibrahim Boubacar KEITA was elected president. The Malian
Government and northern armed groups signed an
internationally mediated peace accord in June 2015,
however, the parties to the peace accord have made little
progress in the accord’s implementation, despite a June
2017 target for its completion. Furthermore, extremist
groups outside the peace process made steady inroads into
rural areas of central Mali following the consolidation of
three major terrorist organizations in March 2017. In
central and northern Mali, terrorist groups have exploited
age-old ethnic rivalries between pastoralists and sedentary
communities and inflicted serious losses on the Malian
military. Intercommunal violence incidents such as targeted
killings occur with increasing regularity. KEITA was
reelected president in 2018 in an election that was deemed
credible by international observers, despite some security
and logistic shortfalls.','c9b9adb267e95c62aec6a917ca386d00319847f8f14815db71c9ff813e96cfc6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ff2a4b5b14c547c2e73b033fc140fa65f2faa4d167bfbf2ef5ea169d130915b',2020,'MT','Malta','introduction',703,'Background: With a civilization that dates back thousands of
years, Malta boasts some of the oldest megalithic sites in
the world. Situated in the center of the Mediterranean,
Malta’s islands have long served as a strategic military
asset, with the islands at various times having come under
control of the Phoenicians, Carthaginians, Greeks, Romans,
Byzantines, Moors, Normans, Sicilians, Spanish, Knights of
St. John, and the French. Most recently a British colony
(since 1814), Malta gained its independence in 1964 and
declared itself a republic ten years later. While under
British rule, the island staunchly supported the UK through
both world wars. Since about the mid-1980s, the island has
transformed itself into a freight transshipment point, a
financial center, and a tourist destination while its key
industries moved toward more service-oriented activities.
Malta became an EU member in May 2004 and began using
the euro as currency in 2008.','a546f55661de73b84535a4aebdb4574c2d485be823e714ff1f05a4b97d5fd84b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8bebcdf65187763ab006cac6b0bc036618e1a8fe10ad126595664a44be1a669',2020,'MH','Marshall Islands','introduction',710,'Background: After almost four decades under US
administration as the easternmost part of the UN Trust
Territory of the Pacific Islands, the Marshall Islands
attained independence in 1986 under a Compact of Free
Association. Compensation claims continue as a result of
US nuclear testing conducted on some of the atolls
between 1947 and 1962 (67 tests total). The Marshall
Islands hosts the US Army Kwajalein Atoll Reagan Missile
Test Site, a key installation in the US missile defense
network. Kwajalein also hosts one of four dedicated ground
antennas that assist in the operation of the Global
Positioning System (GPS) navigation system (the others are
at Cape Canaveral, Florida (US), on Ascension (Saint
Helena, Ascension, and Tristan da Cunha), and at Diego
Garcia (British Indian Ocean Territory)).','af461c9358e5a99a8632ffaefcd020c5c977b958013e08c483fb32cc23ba1f9f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17eaaf690ebc2e49a80f19bbf6ec3442cc5e64070708991ce6748cfec256d6fe',2020,'SN','Senegal','introduction',716,'Background: Independent from France in 1960, Mauritania
annexed the southern third of the former Spanish Sahara
(now Western Sahara) in 1976 but relinquished it after
three years of raids by the Polisario guerrilla front seeking
independence for the territory. Maaouya Ould Sid Ahmed
TAYA seized power in a coup in 1984 and ruled Mauritania
with a heavy hand for more than two decades. A series of
presidential elections that he held were widely seen as
flawed. A bloodless coup in August 2005 deposed President
TAYA and ushered in a military council that oversaw a
transition to democratic rule. Independent candidate Sidi
Ould Cheikh ABDALLAHI was inaugurated in April 2007 as
Mauritania’s first freely and fairly elected president. His
term ended prematurely in August 2008 when a military
junta led by General Mohamed Ould Abdel AZIZ deposed
him and installed a military council government. AZIZ was
subsequently elected president in July 2009 and sworn in
the following month. AZIZ sustained injuries from an
accidental shooting by his own troops in October 2012 but
has continued to maintain his authority. He was reelected
in 2014 to a second and final term as president (according
to the present constitution). AZIZ will be replaced through
elections scheduled for June 2019. The country continues
to experience ethnic tensions among three major groups:
Arabic-speaking descendants of slaves (Haratines), Arabic-
speaking “White Moors” (Beydane), and members of Sub-
Saharan ethnic groups mostly originating in the Senegal
River valley (Halpulaar, Soninke, and Wolof).
Al-Qaeda in the Islamic Maghreb (AQIM) launched a
series of attacks in Mauritania between 2005 and 2011,
murdering American and foreign tourists and aid workers,
attacking diplomatic and government facilities, and
ambushing Mauritanian soldiers and gendarmes. A
successful strategy against terrorism that combines
dialogue with the terrorists and military actions has
prevented the country from further terrorist attacks since
2011. However, AQIM and similar groups remain active in
neighboring Mali and elsewhere in the Sahel region and
continue to pose a threat to Mauritanians and foreign
visitors.','d237ffd1e7917e2bf90448e47910176b12ad3bba3ad7b80876b77790f9021717','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6b8fc73d12c3e745c229d68b4d8f64d63b4166e858311f72781aa746f3a1359',2020,'MU','Mauritius','introduction',724,'Background: Although known to Arab and Malay sailors as
early as the 10th century, Mauritius was first explored by
the Portuguese in the 16th century and subsequently
settled by the Dutch—who named it in honor of Prince
Maurits van NASSAU—in the 17th century. The French
assumed control in 1715, developing the island into an
important naval base overseeing Indian Ocean trade, and
establishing a plantation economy of sugar cane. The
British captured the island in 1810, during the Napoleonic
Wars. Mauritius remained a strategically important British
naval base, and later an air station, playing an important
role during World War II for anti-submarine and convoy
operations, as well as the collection of signals intelligence.
Independence from the UK was attained in 1968. A stable
democracy with regular free elections and a positive
human rights record, the country has_ attracted
considerable foreign investment and has one of Africa’s
highest per capita incomes.','7d1d220f84c43133e47ca77ece0af171f7019343df34672adfc3547dc99e4302','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('279a74bee359d23bf73e1f8d34d83cc75dc86e7ce5e70a10bc994021c796ff13',2020,'MX','Mexico','introduction',730,'Background: The site of several advanced Amerindian
civilizations—including the Olmec, Toltec, Teotihuacan,
Zapotec, Maya, and Aztec—Mexico was conquered and
colonized by Spain in the early 16th century. Administered
as the Viceroyalty of New Spain for three centuries, it
achieved independence early in the 19th century. Elections
held in 2000 marked the first time since the 1910 Mexican
Revolution that an opposition candidate—Vicente FOX of
the National Action Party (PAN)—defeated the party in
government, the Institutional Revolutionary Party (PRI). He
was succeeded in 2006 by another PAN candidate Felipe
CALDERON, but Enrique PENA NIETO regained the
presidency for the PRI in 2012. Left-leaning
antiestablishment politician and former mayor of Mexico
City (2000-05) Andres Manuel LOPEZ OBRADOR, from the
National Regeneration Movement (MORENA), became
president in December 2018.
The global financial crisis in late 2008 caused a massive
economic downturn in Mexico the following year, although
growth returned quickly in 2010. Ongoing economic and
social concerns include low’ real wages, high
underemployment, inequitable income distribution, and few
advancement opportunities for the largely indigenous
population in the impoverished southern states. Since
2007, Mexico’s powerful drug-trafficking organizations
have engaged in bloody feuding, resulting in tens of
thousands of drug-related homicides.','263c70dcec08f55d9e01a18099cda2ee439dda9ca4a3ede7a8e6adbb85f23462','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9401933507e4fb2619f55eb1601fe841364b33c1b319f2f8368a13e518a31b6',2020,'UA','Ukraine','introduction',745,'Background: A large portion of present day Moldovan
territory became a province of the Russian Empire in 1812
and then unified with Romania in 1918 in the aftermath of
World War I. This territory was then incorporated into the
Soviet Union at the close of World War II. Although
Moldova has been independent from the Soviet Union since
1991, Russian forces have remained on Moldovan territory
east of the Nistru River in the breakaway region of
Transnistria, whose population is roughly equally composed
of ethnic Ukrainians, Russians, and Moldovans.
Years of Communist Party rule in Moldova from 2001-
2009 ultimately ended with election-related violent protests
and a rerun of parliamentary elections in 2009. Since then,
a series of pro-European ruling coalitions have governed
Moldova. As a result of the country’s most recent
legislative election in February 2019, parliamentary seats
are split among the left-leaning Socialist Party (35 seats),
the former ruling Democratic Party (30 seats), and the
center-right ACUM bloc (26 seats). Parliament voted in
Prime Minister Ion CHICU and his cabinet on 14 November
2019, two days after voting to remove his predecessor,
ACUM co-leader Maia SANDU, who had been in office since
June 2019.','df29d13fa50b5615fe7361e45f912b70086a9a0da0ffb064506673f2f2b4d39a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff6e6bd2b9703f9d4b2db66536b1b0a0212d339215572cd544938ab598ba37ae',2020,'MC','Monaco','introduction',752,'Background: The Genoese built a fortress on the site of
present day Monaco in 1215. The current ruling GRIMALDI
family first seized control in 1297 but was not able to
permanently secure its holding until 1419. Economic
development was spurred in the late 19th century with a
railroad linkup to France and the opening of a casino. Since
then, the principality’s mild climate, splendid scenery, and
gambling facilities have made Monaco world famous as a
tourist and recreation center.','0649a6ca8c28cb9cf7937af5685b5df847b18e18afd31f23062dc723a1f677bc','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31e24117a4a2802d12ed0c0651f67cacc6d84263b2ae4f92494ed918afe1077c',2020,'MN','Mongolia','introduction',758,'Background: The Mongols gained fame in the 13th century
when under Chinggis KHAAN they established a huge
Eurasian empire through conquest. After his death the
empire was divided into several powerful Mongol states,
but these broke apart in the 14th century. The Mongols
eventually retired to their original steppe homelands and in
the late 17th century came under Chinese rule. Mongolia
declared its independence from the Manchu-led Qing
Empire in 1911 and achieved limited autonomy until 1919,
when it again came under Chinese control. The Mongolian
Revolution of 1921 ended Chinese dominance, and a
communist regime, the Mongolian People’s Republic, took
power in 1924.
The modern country of Mongolia, represents only part of
the Mongols’ historical homeland; today, more ethnic
Mongolians live in the Inner Mongolia Autonomous Region
in the People’s Republic of China than in Mongolia. Since
the country’s peaceful democratic revolution in 1990, the
ex-communist Mongolian People’s Revolutionary Party
(MPRP)—which took the name Mongolian People’s Party
(MPP) in 2010—has competed for political power with the
Democratic Party (DP) and several other smaller parties,
including a new party formed by former President
ENKHBAYAR, which confusingly adopted for itself the
MPRP name. In the country’s most recent parliamentary
elections in June 2016, Mongolians handed the MPP
overwhelming control of Parliament, largely pushing out
the DP, which had overseen a sharp decline in Mongolia’s
economy during its control of Parliament in the preceding
years. Mongolians elected a DP member, Khaltmaa
BATTULGA, as president in 2017.','5cfef1ce68f27a4de877d61555332aacd168863171091416f257f53d15e74eab','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cb2c4171fedafaeb3e45608e2c504a5594a87549dbb8a5d20b6552ef33dda3d',2020,'AL','Albania','introduction',766,'Background: The use of the name Crna Gora or Black
Mountain (Montenegro) began in the 13th century in
reference to a highland region in the Serbian province of
Zeta. The later medieval state of Zeta maintained its
existence until 1496 when Montenegro finally fell under
Ottoman rule. Over subsequent centuries, Montenegro
managed to maintain a level of autonomy within the
Ottoman Empire. From the 16th to 19th centuries,
Montenegro was a theocracy ruled by a series of bishop
princes; in 1852, it transformed into a secular principality.
Montenegro was recognized as an independent sovereign
principality at the Congress of Berlin in 1878. After World
War I, during which Montenegro fought on the side of the
Allies, Montenegro was absorbed by the Kingdom of Serbs,
Croats, and Slovenes, which became the Kingdom of
Yugoslavia in 1929. At the conclusion of World War II, it
became a constituent republic of the Socialist Federal
Republic of Yugoslavia. When the latter dissolved in 1992,
Montenegro joined with Serbia, creating the Federal
Republic of Yugoslavia and, after 2003, shifting to a looser
State Union of Serbia and Montenegro. In May 2006,
Montenegro invoked its right under the Constitutional
Charter of Serbia and Montenegro to hold a referendum on
independence from the two-state union. The vote for
severing ties with Serbia barely exceeded 55%—the
threshold set by the EU—allowing Montenegro to formally
restore its independence on 3 June 2006. In 2017,
Montenegro joined NATO and is currently completing its
EU accession process, having officially applied to join the
EU in December 2008.
Background: English and Irish colonists from St. Kitts first
settled on Montserrat in 1632; the first African slaves
arrived three decades later. The British and French fought
for possession of the island for most of the 18th century,
but it finally was confirmed as a British possession in 1783.
The island’s sugar plantation economy was converted to
small farm landholdings in the mid-19th century. Much of
this island was devastated and two-thirds of the population
fled abroad because of the eruption of the Soufriere Hills
Volcano that began on 18 July 1995. Montserrat has
endured volcanic activity since, with the last eruption
occurring in 2013.','83ae04d22089ef68d53f34e8aa0f32c5388079d798351e4c2b544e3d9e6a1622','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6365a7945d970b5f88f45e598b3cc65d00762ba3319f29918f0709c890bc9c7d',2020,'EH','Western Sahara','introduction',774,'Background: In 788, about a century after the Arab conquest
of North Africa, a series of Moroccan Muslim dynasties
began to rule in Morocco. In the 16th century, the Sa’adi
monarchy, particularly under Ahmad al-MANSUR (1578-
1603), repelled foreign invaders and inaugurated a golden
age. The Alaouite Dynasty, to which the current Moroccan
royal family belongs, dates from the 17th century. In 1860,
Spain occupied northern Morocco and ushered in a half-
century of trade rivalry among European powers that saw
Morocco’s sovereignty steadily erode; in 1912, the French
imposed a protectorate over the country. A protracted
independence struggle with France ended successfully in
1956. The internationalized city of Tangier and most
Spanish possessions were turned over to the new country
that same year. Sultan MOHAMMED V, the current
monarch’s grandfather, organized the new state as a
constitutional monarchy and in 1957 assumed the title of
king. Since Spain’s 1976 withdrawal from what is today
called Western Sahara, Morocco has extended its de facto
administrative control to roughly 75% of this territory;
however, the UN does not recognize Morocco as the
administering power for Western Sahara. The UN since
1991 has monitored a cease-fire between Morocco and the
Polisario Front—an organization advocating the territory’s
independence—and restarted negotiations over the status
of the territory in December 2018.
King MOHAMMED VI in early 2011 responded to the
spread of pro-democracy protests in the region by
implementing a reform program that included a new
constitution, passed by popular referendum in July 2011,
under which some new powers were extended to
parliament and the prime minister, but ultimate authority
remains in the hands of the monarch. In November 2011,
the Justice and Development Party (PJD)—a moderate
Islamist party—won the largest number of seats in
parliamentary elections, becoming the first Islamist party
to lead the Moroccan Government. In September 2015,
Morocco held its first direct elections for regional councils,
one of the reforms included in the 2011 constitution. The
PJD again won the largest number of seats in nationwide
parliamentary elections in October 2016.','0654767c6babb3ff0800c0976a2115d86f02bd93f575b61c45a0515997fe5864','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8617ee6ea712edc38cae078212adc16b3ecf6902fa99b1b7c6a97781040c5988',2020,'ZM','Zambia','introduction',781,'Background: Almost five centuries as a Portuguese colony
came to a close with independence in 1975. Large-scale
emigration, economic dependence on South Africa, a
severe drought, and a prolonged civil war hindered the
country’s development until the mid-1990s. The ruling
Front for the Liberation of Mozambique (FRELIMO) party
formally abandoned Marxism in 1989, and a new
constitution the following year provided for multiparty
elections and a free market economy. A UN-negotiated
peace agreement between FRELIMO- and_eé£érebel
Mozambique National Resistance (RENAMO) forces ended
the fighting in 1992. In 2004, Mozambique underwent a
delicate transition as Joaquim CHISSANO stepped down
after 18 years in office. His elected successor, Armando
GUEBUZA, served two terms and then passed executive
power to Filipe NYUSI in 2015. RENAMO’s residual armed
forces intermittently engaged in a low-level insurgency
after 2012, but a late December 2016 ceasefire eventually
led to the two sides signing a comprehensive peace deal in
August 2019. Elections in October 2019, challenged by
Western observers and civil society as being problematic,
resulted in resounding wins for NYUSI and FRELIMO
across the country. Since October 2017, violent extremists
—who an official ISIS media outlet recognized as ISIS’s
network in Mozambique for the first time in June 2019—
have been conducting attacks against civilians and security
services in the northern province of Cabo Delgado.','e8bb8d1d431652340b6964108fdd2fdca176fb20c729ef93d6f0ffc51e1d2f91','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9225b4cc40b6f08c642e471c6e98077c89dbcaab32516abfbfe2689f88a85a1',2020,'NP','Nepal','introduction',790,'Background: During the late 18th-early 19th centuries, the
principality of Gorkha united many of the_ other
principalities and states of the sub-Himalayan region into a
Nepali Kingdom. Nepal retained its independence following
the Anglo-Nepalese War of 1814-16 and the subsequent
peace treaty laid the foundations for two centuries of
amicable relations between Britain and Nepal. (The
Brigade of Gurkhas continues to serve in the British Army
to the present day.) In 1951, the Nepali monarch ended the
century-old system of rule by hereditary premiers and
instituted a cabinet system that brought political parties
into the government. That arrangement lasted until 1960,
when political parties were again banned, but was
reinstated in 1990 with the establishment of a multiparty
democracy within the framework of a_ constitutional
monarchy.
An insurgency led by Maoists broke out in 1996. During
the ensuing 10-year civil war between Maoist and
government forces, the monarchy dissolved the cabinet and
parliament and re-assumed absolute power in 2002, after
the crown prince massacred the royal family in 2001. A
peace accord in 2006 led to the promulgation of an interim
constitution in 2007. Following a nationwide Constituent
Assembly (CA) election in 2008, the newly formed CA
declared Nepal a federal democratic republic, abolished
the monarchy, and elected the country’s first president.
After the CA failed to draft a constitution by a 2012
deadline set by the Supreme Court, then-Prime Minister
Baburam BHATTARAI dissolved the CA. Months of
negotiations ensued until 2013 when the major political
parties agreed to create an interim government headed by
then-Chief Justice Khil Raj REGMI with a mandate to hold
elections for a new CA. Elections were held in 2013, in
which the Nepali Congress (NC) won the largest share of
seats in the CA and in 2014 formed a coalition government
with the second-place Communist Party of Nepal-Unified
Marxist-Leninist (UML) with NC President Sushil KOIRALA
serving as prime minister. Nepal’s new constitution came
into effect in 2015, at which point the CA became the
Parliament. Khagda Prasad Sharma OLI served as the first
post-constitution prime minister from 2015 to 2016. OLI
resigned ahead of a no-confidence motion against him, and
Parliament elected Communist Party of Nepal-Maoist (CPN-
M) leader Pushpa Kamal DAHAL (aka “Prachanda”) prime
minister. The constitution provided for a transitional period
during which three sets of elections—local, provincial, and
national—needed to take place. The first local elections in
20 years occurred in three phases between May and
September 2017, and state and federal elections proceeded
in two phases in November and December 2017. The
parties headed by OLI and DAHAL ran in coalition and
swept the parliamentary elections, and OLI, who led the
larger of the two parties, was sworn in as prime minister in
February 2018. In May 2018, OLI and DAHAL announced
the merger of their parties—the UML and CPN-M—to
establish the Nepal Communist Party (NCP), which is now
the ruling party in Parliament.','683166568519e736abfa1d764dd6df7d87a3cbfd1ad9c93440e14f5f4b92ee11','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e759528f29ba71b070fab9a6ef055b21da45460394b62d6ec73865f20952ee3',2020,'BE','Belgium','introduction',798,'Background: The Dutch United Provinces declared their
independence from Spain in 1579; during the 17th century,
they became a leading seafaring and commercial power,
with settlements and colonies around the world. After a 20-
year French occupation, a Kingdom of the Netherlands was
formed in 1815. In 1830, Belgium seceded and formed a
separate kingdom. The Netherlands remained neutral in
World War I, but suffered German invasion and occupation
in World War II. A modern, industrialized nation, the
Netherlands is also a large exporter of agricultural
products. The country was a founding member of NATO
and the EEC (now the EU) and participated in the
introduction of the euro in 1999. In October 2010, the
former Netherlands Antilles was dissolved and the three
smallest islands—Bonaire, Sint Eustatius, and Saba—
became special municipalities in the Netherlands
administrative structure. The larger islands of Sint Maarten
and Curacao joined the Netherlands and Aruba as
constituent countries forming the Kingdom of the
Netherlands.
In February 2018, the Sint Eustatius island council
(governing body) was dissolved and replaced by a
government commissioner to restore the integrity of public
administration. According to the Dutch Government, the
intervention will be as “short as possible and as long as
needed.”','bd7a1d53eb4676e4c84fa0ed959bd3d20a25f5a3ad38c4b4b93037588ffb2be6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b84a3a6c57f4004d5b5db6b2cca9434abee9eab4daab260d2b30ed6d9d80166',2020,'MP','Northern Mariana Islands','introduction',828,'Background: Under US administration as part of the UN
Trust Territory of the Pacific, the people of the Northern
Mariana Islands decided in the 1970s not to seek
independence but instead to forge closer links with the US.
Negotiations for territorial status began in 1972. A
covenant to establish a commonwealth in political union
with the US was approved in 1975, and came into force on
24 March 1976. A new government and constitution went
into effect in 1978.','9ad84b7f8139c156d4e0d3eab45b629a45b6a728beb8d4fc66c2ec25b0e6d288','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb6c3ff939ca3e583c1d4bc020b1132bef41ad43b9c17d8b7a26eb25b81b7afc',2020,'PA','Panama','introduction',837,'Background: Explored and settled by the Spanish in the 16th
century, Panama broke with Spain in 1821 and joined a
union of Colombia, Ecuador, and Venezuela—named the
Republic of Gran Colombia. When the latter dissolved in
1830, Panama remained part of Colombia. With US
backing, Panama seceded from Colombia in 1903 and
promptly signed a treaty with the US allowing for the
construction of a canal and US sovereignty over a strip of
land on either side of the structure (the Panama Canal
Zone). The Panama Canal was built by the US Army Corps
of Engineers between 1904 and 1914. In 1977, an
agreement was signed for the complete transfer of the
Canal from the US to Panama by the end of the century.
Certain portions of the Zone and increasing responsibility
over the Canal were turned over in the subsequent
decades. With US help, dictator Manuel NORIEGA was
deposed in 1989. The entire Panama Canal, the area
supporting the Canal, and remaining US military bases
were transferred to Panama by the end of 1999. An
ambitious expansion project to more than double the
Canal’s capacity—by allowing for more Canal transits and
larger ships—was carried out between 2007 and 2016.','ce014f67ffc96e5bb4f8f60a65ade371666da061ca84e792e4f469b5aacb13af','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f734fc7469f831f5fc8218f99879a3f8b0d5cacf379379fa736a3820d711e54f',2020,'EC','Ecuador','introduction',847,'Background: Ancient Peru was the seat of several prominent
Andean civilizations, most notably that of the Incas whose
empire was captured by Spanish conquistadors in 1533.
Peru declared its independence in 1821, and remaining
Spanish forces were defeated in 1824. After a dozen years
of military rule, Peru returned to democratic leadership in
1980, but experienced economic problems and the growth
of a violent insurgency. President Alberto FUJIMORI’s
election in 1990 ushered in a decade that saw a dramatic
turnaround in the economy and significant progress in
curtailing guerrilla activity. Nevertheless, the president’s
increasing reliance on authoritarian measures and an
economic slump in the late 1990s generated mounting
dissatisfaction with his regime, which led to his resignation
in 2000. A caretaker government oversaw a new election in
the spring of 2001, which installed Alejandro TOLEDO
Manrigque as the new head of government—Peru’s first
democratically elected president of indigenous ethnicity.
The presidential election of 2006 saw the return of Alan
GARCIA Perez who, after a disappointing presidential term
from 1985 to 1990, oversaw a robust economic rebound.
Former army officer Ollanta HUMALA Tasso was elected
president in June 2011, and carried on the sound, market-
oriented economic policies of the three preceding
administrations. Poverty and unemployment levels have
fallen dramatically in the last decade, and today Peru
boasts one of the best performing economies in Latin
America. Pedro Pablo KUCZYNSKI Godard won a very
narrow presidential runoff election in June 2016. Facing
impeachment after evidence surfaced of his involvement in
a vote-buying scandal, President KUCZYNSKI offered his
resignation on 21 March 2018. Two days later, First Vice
President Martin Alberto VIZCARRA Cornejo was sworn in
as president. On 30 September 2019, President VIZCARRA
invoked his constitutional authority to dissolve Peru’s
Congress after months of battling with the body over
anticorruption reforms. New congressional elections are
scheduled for 26 January 2020.','c14167d93a17463cfdec3647c10169baef7820b2bd625c179326a627695f6d64','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e0a63b2a01a3d9f4a653797e6889409730b8b0cc6ba4fe72f462426d0f351fb',2020,'PL','Poland','introduction',866,'Background: Poland’s history as a state began near the
middle of the 10th century. By the mid-16th century, the
Polish-Lithuanian Commonwealth ruled a vast tract of land
in Central and Eastern Europe. During the 18th century,
internal disorders weakened the nation, and in a series of
agreements between 1772 and 1795, Russia, Prussia, and
Austria partitioned Poland among themselves. Poland
regained its independence in 1918 only to be overrun by
Germany and the Soviet Union in World War II. It became a
Soviet satellite state following the war. Labor turmoil in
1980 led to the formation of the independent trade union
“Solidarity” that over time became a political force with
over 10 million members. Free elections in 1989 and 1990
won Solidarity control of the parliament and _ the
presidency, bringing the communist era to a close. A “shock
therapy” program during the early 1990s enabled the
country to transform its economy into one of the most
robust in Central Europe. Poland joined NATO in 1999 and
the EU in 2004. With its transformation to a democratic,
market-oriented country largely completed and with large
investments in defense, energy, and other infrastructure,
Poland is an increasingly active member of Euro-Atlantic
organizations.
Background: Following its heyday as a global maritime power
during the 15th and 16th centuries, Portugal lost much of
its wealth and status with the destruction of Lisbon in a
1755 earthquake, occupation during the Napoleonic Wars,
and the independence of Brazil, its wealthiest colony, in
1822. A 1910 revolution deposed the monarchy, and for
most of the next six decades, repressive governments ran
the country. In 1974, a left-wing military coup installed
broad democratic reforms. The following year, Portugal
granted independence to all of its African colonies.
Portugal is a founding member of NATO and entered the
EC (now the EU) in 1986.
Background: Populated for centuries by aboriginal peoples,
the island was claimed by the Spanish Crown in 1493
following Christopher COLUMBUS’ second voyage to the
Americas. In 1898, after 400 years of colonial rule that saw
the indigenous population nearly exterminated and African
slave labor introduced, Puerto Rico was ceded to the US as
a result of the Spanish-American War. Puerto Ricans were
granted US citizenship in 1917. Popularly elected
governors have served since 1948. In 1952, a constitution
was enacted providing for internal self-government. In
plebiscites held in 1967, 1993, and 1998, voters chose not
to alter the existing political status with the US, but the
results of a 2012 vote left open the possibility of American
statehood. Economic recession on the island has led to a
net population loss since about 2005, as large numbers of
residents moved to the US mainland. The trend has
accelerated since 2010; in 2014, Puerto Rico experienced a
net population loss to the mainland of 64,000, more than
double the net loss of 26,000 in 2010. Hurricane Maria
struck the island on 20 September 2017 causing
catastrophic damage, including destruction of the electrical
grid that had been cripled by Hurricane Irma just two
weeks before. It was the worst storm to hit the island in
eight decades, and damage is estimated in the tens of
billions of dollars.','f74fb75cf8574be164e285ea38498df30f441e26c8cd518a091176dd8e1bee67','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8ed3ae8aa45d51275fa291209b43775f26fd98a09df096371792e978fb4c2b2',2020,'BG','Bulgaria','introduction',877,'Background: The principalities of Wallachia and Moldavia—
for centuries under the suzerainty of the Turkish Ottoman
Empire—secured their autonomy in 1856; they were de
facto linked in 1859 and formally united in 1862 under the
new name of Romania. The country gained recognition of
its independence in 1878. It joined the Allied Powers in
World War I and acquired new territories—most notably
Transylvania—following the conflict. In 1940, Romania
allied with the Axis powers and participated in the 1941
German invasion of the USSR. Three years later, overrun by
the Soviets, Romania signed an armistice. The post-war
Soviet occupation led to the formation of a communist
“people’s republic” in 1947 and the abdication of the king.
The decades-long rule of dictator Nicolae CEAUSESCU,
who took power in 1965, and his Securitate police state
became increasingly oppressive and draconian through the
1980s. CEAUSESCU was overthrown and executed in late
1989. Former communists dominated the government until
1996 when they were swept from power. Romania joined
NATO in 2004 and the EU in 2007.
Background: Founded in the 12th century, the Principality of
Muscovy was able to emerge from over 200 years of
Mongol domination (13th-15th centuries) and to gradually
conquer and absorb surrounding principalities. In the early
17th century, a new ROMANOV Dynasty continued this
policy of expansion across Siberia to the Pacific. Under
PETER I (ruled 1682-1725), hegemony was extended to the
Baltic Sea and the country was renamed the Russian
Empire. During the 19th century, more territorial
acquisitions were made in Europe and Asia. Defeat in the
Russo-Japanese War of 1904-05 contributed to the
Revolution of 1905, which resulted in the formation of a
parliament and other reforms. Devastating defeats and food
shortages in World War I led to widespread rioting in the
major cities of the Russian Empire and to the overthrow in
1917 of the ROMANOV Dynasty. The communists under
Vladimir LENIN seized power soon after and formed the
USSR. The brutal rule of Iosif STALIN (1928-53)
strengthened communist rule and Russian dominance of
the Soviet Union at a cost of tens of millions of lives. After
defeating Germany in World War II as part of an alliance
with the US (1939-1945), the USSR expanded its territory
and influence in Eastern Europe and emerged as a global
power. The USSR was the principal adversary of the US
during the Cold War (1947-1991). The Soviet economy and
society stagnated in the decades following Stalin’s rule,
until General Secretary Mikhail GORBACHEV (1985-91)
introduced glasnost (openness) and __—i perestroika
(restructuring) in an attempt to modernize communism, but
his initiatives inadvertently released forces that by
December 1991 led to the dissolution of the USSR into
Russia and 14 other independent states.
Following economic and_ political turmoil during
President Boris YELTSIN’s term (1991-99), Russia shifted
toward a centralized authoritarian state under President
Vladimir PUTIN (2000-2008, 2012-present) in which the
regime seeks to legitimize its rule through managed
elections, populist appeals, a foreign policy focused on
enhancing the country’s geopolitical influence, and
commodity-based economic growth. Russia faces a largely
subdued rebel movement in Chechnya and some other
surrounding regions, although violence _ still occurs
throughout the North Caucasus.','0cfa008f97f7293b8c1e791bc7c49cc918e2481f66c269188499077b58120595','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efa5551c7f539291d2989dd9bc315b402b407491929c41158902151ff8004e80',2020,'KN','Saint Kitts and Nevis','introduction',887,'Background: Carib Indians occupied the islands of the West
Indies for hundreds of years before the British and French
began settlement in 1623. During the course of 17th
century, Saint Kitts became the premier base for English
and French expansion into the Caribbean. The French
ceded the territory to the UK in 1713. At the turn of the
18th century, Saint Kitts was the richest British Crown
Colony per capita in the Caribbean, a result of the sugar
trade. Although small in size and separated by only 3 km (2
mi) of water, Saint Kitts and Nevis were viewed and
governed as different states until the late-19th century,
when the British forcibly unified them along with the island
of Anguilla. In 1967, the island territory of Saint
Christopher-Nevis-Anguilla became an associated state of
the UK with full internal autonomy. The island of Anguilla
rebelled and was allowed to secede in 1971. The remaining
islands achieved independence in 1983 as Saint Kitts and
Nevis. In 1998, a referendum on Nevis to separate from
Saint Kitts fell short of the two-thirds majority vote needed.
Background: The island, with its fine natural harbor at
Castries and burgeoning sugar industry, was contested
between England and France throughout the 17th and
early 18th centuries (changing possession 14 times); it was
finally ceded to the UK in 1814 and became part of the
British Windward Islands colony. Even after the abolition of
slavery on its plantations in 1834, Saint Lucia remained an
agricultural island, dedicated to producing tropical
commodity crops. In the mid-20th century, Saint Lucia
joined the West Indies Federation (1958-1962) and in 1967
became one of the six members of the West Indies
Associated States, with internal self-government. In 1979,
Saint Lucia gained full independence.
Background: Although sighted by Christopher COLUMBUS in
1493 and claimed for Spain, it was the Dutch who occupied
the island in 1631 to exploit its salt deposits. The Spanish
retook the island in 1633, but continued to be harassed by
the Dutch. The Spanish finally relinquished Saint Martin to
the French and Dutch, who divided it between themselves
in 1648. Friction between the two sides caused the border
to frequently fluctuate over the next two centuries, with the
French eventually holding the greater portion of the island
(about 61%). The cultivation of sugar cane introduced
African slavery to the island in the late 18th century; the
practice was not abolished until 1848. The island became a
free port in 1939; the tourism industry was dramatically
expanded during the 1970s and 1980s. In 2003, the
populace of Saint Martin voted to secede from Guadeloupe
and in 2007, the northern portion of the island became a
French overseas collectivity. In 2010, the southern Dutch
portion of the island became the independent nation of Sint
Maarten within the Kingdom of the Netherlands. On 6
September 2017, Hurricane Irma passed over the island of
Saint Martin causing extensive damage to_ roads,
communications, electrical power, and housing; the UN
estimated that 90% of the buildings were damaged or
destroyed.
Background: First settled by the French in the early 17th
century, the islands represent the sole remaining vestige of
France’s once vast North American possessions. They
attained the status of an overseas collectivity in 2003.
Background: Resistance by native Caribs prevented
colonization on Saint Vincent until 1719. Disputed between
France and the UK for most of the 18th century, the island
was ceded to the latter in 1783. The British prized Saint
Vincent due to its fertile soil, which allowed for thriving
Sslave-run plantations of sugar, coffee, indigo, tobacco,
cotton, and cocoa. In 1834, the British abolished slavery.
Immigration of indentured servants eased the ensuing
labor shortage, as did subsequent Portuguese immigrants
from Madeira and East Indian laborers. Conditions
remained harsh for both former slaves and immigrant
agricultural workers, however, as depressed world sugar
prices kept the economy stagnant until the early 1900s.
The economy then went into a period of decline with many
landowners abandoning their estates and leaving the land
to be cultivated by liberated slaves. Between 1960 and
1962, Saint Vincent and the Grenadines was a separate
administrative unit of the Federation of the West Indies.
Autonomy was granted in 1969 and independence in 1979.','2227e63449100470db856b0ff35431f80bb8edabaf77969ee34424e655ba78c1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('220f476d81960a6919994593402f1c4d6d7ebc98966a14fb6f6d9792c3284c3c',2020,'WS','Samoa','introduction',897,'Background: New Zealand occupied the German protectorate
of Western Samoa at the outbreak of World War I in 1914.
It continued to administer the islands as a mandate and
then as a trust territory until 1962, when the islands
became the ffirst Polynesian nation to _ reestablish
independence in the 20th century. The country dropped the
“Western” from its name in 1997.
In the late 2000s, Samoa began making efforts to more
closely align with Australia and New Zealand. In 2009,
Samoa changed its driving orientation to the left side of the
road, in line with other Commonwealth countries. In 2011,
Samoa jumped forward one day—skipping December 30—
by moving to the west of the International Date Line so that
it was one hour ahead of New Zealand and three hours
ahead of the east coast of Australia, rather than 23 and 21
hours behind, respectively.','e30b46463681f97171d6e70fa8cb2ed1d54f44277eac38e71e6fb7b8e4451f2c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9465c540780e5c7a54b9b037cb2ba69165fdac8f0b7a4c8066add51de254ebc',2020,'SM','San Marino','introduction',905,'Background: Geographically the third smallest state in
Europe (after the Holy See and Monaco), San Marino also
claims to be the world’s oldest republic. According to
tradition, it was founded by a Christian stonemason named
MARINUS in A.D. 301. San Marino’s foreign policy is
aligned with that of the EU, although it is not a member;
social and political trends in the republic track closely with
those of its larger neighbor, Italy.','a7c870bea023872d16985370536da5876b75441c7b5fde55d81784820a0a359e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e33620ce57f9104784235c61c79c7595911cc778206968e3da0c72b0b8a5dd6',2020,'ST','Sao Tome and Principe','introduction',910,'Background: Discovered and claimed by Portugal in the late
15th century, the islands’ sugar-based economy gave way
to coffee and cocoa in the 19th century—all grown with
African plantation slave labor, a form of which lingered into
the 20th century. While independence was achieved in
1975, democratic reforms were not instituted until the late
1980s. The country held its first free elections in 1991, but
frequent internal wrangling between the various political
parties precipitated repeated changes in leadership and
four failed, non-violent coup attempts in 1995, 1998, 2003,
and 2009. In 2012, three opposition parties combined in a
no confidence vote to bring down the majority government
of former Prime Minister Patrice TROVOADA, but in 2014,
legislative elections returned him to the office. President
Evaristo CARVALHO, of the same political party as Prime
Minister TROVOADA, was elected in September 2016,
marking a rare instance in which the positions of president
and prime minister are held by the same party. Prime
Minister TROVOADA resigned at the end of 2018 and was
replaced by Jorge BOM JESUS. New oil discoveries in the
Gulf of Guinea may attract increased attention to the small
island nation.','1b27699dd9305c4dd9c9aa31b8eaf138db306f2e673f4213f3d5133d8f973b58','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('490739e5ff9b68003c51ab9b878f7fd1d77e99ebe5f580999ca2dc1eb0abda10',2020,'SK','Slovakia','introduction',922,'Background: Slovakia traces its roots to the 9th century state
of Great Moravia. Subsequently, the Slovaks became part of
the Hungarian Kingdom, where they remained for the next
1,000 years. After the formation of the dual Austro-
Hungarian monarchy in 1867, backlash to language and
education policies favoring the use of Hungarian
(Magyarization) encouraged the strengthening of Slovak
nationalism and a cultivation of cultural ties with the
closely related Czechs, who fell administratively under the
Austrian half of the empire. After the dissolution of the
Austro-Hungarian Empire at the close of World War I, the
Slovaks joined the Czechs to form Czechoslovakia. The new
state was envisioned as a nation with Czech and Slovak
branches. During the interwar period, Slovak nationalist
leaders pushed for autonomy within Czechoslovakia, and in
1939 Slovakia became an independent state created by and
allied with Nazi Germany. Following World War II,
Czechoslovakia was_ reconstituted and came under
communist rule within Soviet-dominated Eastern Europe.
In 1968, an invasion by Warsaw Pact troops ended the
efforts of Czechoslovakia’s leaders to liberalize communist
rule and create “socialism with a human face,” ushering in
a period of repression known as “normalization.” The
peaceful “Velvet Revolution” swept the Communist Party
from power at the end of 1989 and inaugurated a return to
democratic rule and a market economy. On 1 January 1993,
Czechoslovakia underwent a nonviolent “velvet divorce”
into its two national components, Slovakia and the Czech
Republic. Slovakia joined both NATO and the EU in the
spring of 2004 and the euro zone on 1 January 2009.','42d6a46c77e510b4a1156f4d352a31061a3c471288125abbe6d75b58dcf70d79','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('676339614d312999794c3b6e745b78bd388e2bb51f635d8cac386d0f19197482',2020,'SI','Slovenia','introduction',935,'Background: The UK established a protectorate over the
Solomon Islands in the 1890s. Some of the _ bitterest
fighting of World War II occurred on this archipelago and
the Guadalcanal Campaign (August 1942-February 1943)
proved a turning point in the Pacific War, since after the
operation the Japanese lost their strategic initiative and
remained on the defensive until thier final defeat in 1945.
Self-government for the Solomon Islands came in 1976 and
independence two years later. Ethnic violence, government
malfeasance, endemic crime, and a narrow economic base
have undermined stability and civil society. In June 2003,
then Prime Minister Sir Allan KEMAKEZA sought the
assistance of Australia in reestablishing law and order; the
following month, an Australian-led multinational force
arrived to restore peace and disarm ethnic militias. The
Regional Assistance Mission to the Solomon Islands
(RAMSI), which ended in June 2017, was generally effective
in restoring law and order and rebuilding government
institutions.','7de0f90fa6959d56d9a95aae5a9859e14f5a17f0e08ae4b5f8fb245d612ea708','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8e5cd83469990f2074c45ae75a0f9536628ccfdf85651caf7249e2e330129c7',2020,'SD','Sudan','introduction',956,'Background: A large body of recent oceanographic research
has shown that the Antarctic Circumpolar Current (ACC),
an ocean current that flows from west to east around
Antarctica, plays a crucial role in global ocean circulation.
The region where the cold waters of the ACC meet and
mingle with the warmer waters of the north defines a
distinct border—the Antarctic Convergence—which
fluctuates with the seasons, but which encompasses a
discrete body of water and a unique ecologic region. The
Convergence concentrates nutrients, which promotes
marine plant life, and which, in turn, allows for a greater
abundance of animal life. In 2000, the International
Hydrographic Organization delimited the waters within the
Convergence as a fifth world ocean—the Southern Ocean—
by combining the southern portions of the Atlantic Ocean,
Indian Ocean, and Pacific Ocean. The Southern Ocean
extends from the coast of Antarctica north to 60 degrees
south latitude, which coincides with the Antarctic Treaty
region and which approximates the extent of the Antarctic
Convergence. As such, the Southern Ocean is now the
fourth largest of the world’s five oceans (after the Pacific
Ocean, Atlantic Ocean, and Indian Ocean, but larger than
the Arctic Ocean). It should be noted that inclusion of the
Southern Ocean does not imply recognition of this feature
as one of the world’s primary oceans by the US','bf65a57017d9206cfeb4107bce7c2f86d0885f0348e00f33f84574ab2b0591a1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e81df616b5227645a8c9aeddb7083fab0e523dd2462cb4261c6d0e6e38573e2a',2020,'LK','Sri Lanka','introduction',961,'Background: The first Sinhalese arrived in Sri Lanka late in
the 6th century B.C., probably from northern India.
Buddhism was introduced circa 250 B.C., and the first
kingdoms developed at the cities of Anuradhapura (from
circa 200 B.C. to circa A.D. 1000) and Polonnaruwa (from
about 1070 to 1200). In the 14th century, a south Indian
dynasty established a Tamil kingdom in northern Sri Lanka.
The Portuguese controlled the coastal areas of the island in
the 16th century followed by the Dutch in the 17th century.
The island was ceded to the British in 1796, became a
crown colony in 1802, and was formally united under
British rule by 1815. As Ceylon, it became independent in
1948; its name was changed to Sri Lanka in 1972.
Prevailing tensions between the Sinhalese majority and
Tamil separatists erupted into war in July 1983. Fighting
between the government and Liberation Tigers of Tamil
Felam (LITE) continued for over a quarter century.
Although Norway brokered peace negotiations that led to a
ceasefire in 2002, the fighting slowly resumed and was
again in full force by 2006. The government defeated the
LITE in May 2009.
During the post-conflict years under President Mahinda
RAJAPAKSA, the government initiated infrastructure
development projects, many of which were financed by
loans from China. His regime faced significant allegations
of human rights violations and a shrinking democratic
space for civil society. In 2015, a new coalition government
headed by President Maithripala SIRISENA of the Sri
Lanka Freedom Party and Prime Minister’ Ranil
WICKREMESINGHE of the United National Party came to
power with pledges to advance economic, governance, anti-
corruption, reconciliation, justice, and accountability
reforms. However, implementation of these reforms has
been uneven. In October 2018, President SIRISENA
attempted to oust Prime Minister WICKREMESINGHE,
swearing in former President RAJAPAKSA as the new prime
minister and issuing an order to dissolve the parliament
and hold elections. This sparked a_ seven-week
constitutional crisis that ended when the Supreme Court
ruled SIRISENA’s actions unconstitutional, RAJAPAKSA
resigned, and WICKREMESINGHE was reinstated. In
November 2019, Gotabaya RAJAPAKSA won_ the
presidential election and appointed his brother, Mahinda,
prime minister.
Background: Military regimes favoring Islamic-oriented
governments have dominated national politics since
independence from Anglo-Egyptian co-rule in 1956. Sudan
was embroiled in two prolonged civil wars during most of
the remainder of the 20th century. These conflicts were
rooted in northern economic, political, and _ social
domination of largely non-Muslim, non-Arab southern
Sudanese. The first civil war ended in 1972 but another
broke out in 1983. Peace talks gained momentum in 2002-
04 with the signing of several accords. The final
North/South Comprehensive Peace Agreement (CPA),
signed in January 2005, granted the southern rebels
autonomy for six years followed by a referendum on
independence for Southern Sudan. The referendum was
held in January 2011 and indicated overwhelming support
for independence. South Sudan became independent on 9
July 2011. Sudan and South Sudan have yet to fully
implement security and economic agreements signed in
September 2012 relating to the normalization of relations
between the two countries. The final disposition of the
contested Abyei region has also to be decided. The 30-year
reign of President Umar Hassan Ahmad al-BASHIR ended
in his ouster in April 2019, and a Sovereignty Council, a
joint civilian-military-executive body, holds power as of
November 2019.
Following South Sudan’s independence, conflict broke
out between the government and the Sudan People’s
Liberation Movement-North in Southern Kordofan and Blue
Nile states (together known as the Two Areas), resulting in
a humanitarian crisis affecting more than a million people.
A earlier conflict that broke out in the western region of
Darfur in 2003, displaced nearly 2 million people and
caused thousands of deaths. While some repatriation has
taken place, about 1.83 million IDPs remain in Sudan as of
May 2019. Fighting in both the Two Areas and Darfur
between government forces and opposition has largely
subsided, however the civilian populations are affected by
low-level violence including inter-tribal conflict and
banditry, largely a result of weak rule of law. The UN and
the African Union have jointly commanded a_ Darfur
peacekeeping operation (UNAMID) since 2007, but are
slowly drawing down as the situation in Darfur becomes
more stable. Sudan also has faced refugee influxes from
neighboring countries, primarily Ethiopia, Eritrea, Chad,
Central African Republic, and South Sudan. Armed conflict,
poor transport infrastructure, and denial of access by both
the government and armed opposition have impeded the
provision of humanitarian assistance to _ affected
populations. However, Sudan’s new _ transitional
government has stated its priority to allow greater
humanitarian access, as the food security and humanitarian
situation in Sudan worsens and as it appeals to the West for
greater engagement.','c43dd9248c28a8fb44e80fcceef63931d5cff24fc1376c06cdf205a29f8cf957','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7419ab017d93abc2846c229c885cd2f81b2a9acce99866e84b02887cb945964',2020,'NO','Norway','introduction',974,'Background: A military power during the 17th century,
Sweden has not participated in any war for two centuries.
An armed neutrality was preserved in both World Wars.
Since then, Sweden has pursued a successful economic
formula consisting of a capitalist system intermixed with
substantial welfare elements. Sweden joined the EU in
1995, but the public rejected the introduction of the euro in
a 2003 referendum. The share of Sweden’s population born
abroad increased from 11.3% in 2000 to 19.1% in 2018.','7eaea19023998764a7d7c17cfb3bd34ae9d3ec88bea8b369d8cc29343201f49c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('004e1992f465bfcf16b3432d5f241c2cfa02312c2ad3db8fc7f3d1a07cd6b016',2020,'JE','Jersey','introduction',977,'Background: Following World War I, France acquired a
mandate over the northern portion of the former Ottoman
Empire province of Syria. The French administered the
area as Syria until granting it independence in 1946. The
new country lacked political stability and experienced a
series of military coups. Syria united with Egypt in
February 1958 to form the United Arab Republic. In
September 1961, the two entities separated, and the Syrian
Arab Republic was reestablished. In the 1967 Arab-Israeli
War, Syria lost the Golan Heights region to Israel. During
the 1990s, Syria and Israel held occasional, albeit
unsuccessful, peace talks over its return. In November
1970, Hafiz al-ASAD, a member of the socialist Ba’ath Party
and the minority Alawi sect, seized power in a bloodless
coup and brought political stability to the country.
Following the death of President Hafiz al-ASAD, his son,
Bashar al-ASAD, was approved as president by popular
referendum in July 2000. Syrian troops—stationed in
Lebanon since 1976 in an ostensible peacekeeping role—
were withdrawn in April 2005. During the July-August 2006
conflict between Israel and Hizballah, Syria placed its
military forces on alert but did not intervene directly on
behalf of its ally Hizballah. In May 2007, Bashar al-ASAD’s
second term as president was approved by popular
referendum.
Influenced by major uprisings that began elsewhere in
the region, and compounded by additional social and
economic factors, antigovernment protests broke out first
in the southern province of Dar’a in March 2011 with
protesters calling for the repeal of the_ restrictive
Emergency Law allowing arrests without charge, the
legalization of political parties, and the removal of corrupt
local officials. Demonstrations and violent unrest spread
across Syria with the size and intensity of protests
fluctuating. The government responded to unrest with a
mix of concessions—including the repeal of the Emergency
Law, new laws permitting new political parties, and
liberalizing local and national elections—and with military
force and detentions. The government’s efforts to quell
unrest and armed opposition activity led to extended
clashes and eventually civil war between government
forces, their allies, and oppositionists.
International pressure on the ASAD regime intensified
after late 2011, as the Arab League, the EU, Turkey, and
the US expanded economic sanctions against the regime
and those entities that support it. In December 2012, the
Syrian National Coalition, was recognized by more than
130 countries as the sole legitimate representative of the
Syrian people. In September 2015, Russia launched a
military intervention on behalf of the ASAD regime, and
domestic and _ foreign government-aligned forces
recaptured swaths of territory from opposition forces, and
eventually the country’s second largest city, Aleppo, in
December 2016, shifting the conflict in the regime’s favor.
The regime, with this foreign support, also recaptured
opposition strongholds in the Damascus suburbs and the
southern province of Dar’a in 2018. The government lacks
territorial control over much of the northeastern part of the
country, which is dominated by the predominantly Kurdish
Syrian Democratic Forces (SDF). The SDF has expanded its
territorial hold over much of the northeast since 2014 as it
has captured territory from the Islamic State of Iraq and
Syria. Since 2016, Turkey has also conducted three large-
scale military operations into Syria, capturing territory
along Syria’s northern border in the provinces of Aleppo,
Ar Raqgah, and Al Hasakah. Political negotiations between
the government and opposition delegations at UN-
sponsored Geneva conferences since 2014 have failed to
produce a resolution of the conflict. Since early 2017, Iran,
Russia, and Turkey have held _ separate political
negotiations outside of UN auspices to attempt to reduce
violence in Syria. According to an April 2016 UN estimate,
the death toll among Syrian Government forces, opposition
forces, and civilians was over 400,000, though other
estimates placed the number well over 500,000. As of
December 2019, approximately 6 million Syrians were
internally displaced. Approximately 11.1 million people
were in need of humanitarian assistance across the country,
and an additional 5.7 million Syrians were registered
refugees in Turkey, Jordan, Irag, Egypt, and North Africa.
The conflict in Syria remains one of the _ largest
humanitarian crises worldwide.
Background: First inhabited by Austronesian people, Taiwan
became home to Han immigrants beginning in the late
Ming Dynasty (17th century). In 1895, military defeat
forced China’s Qing Dynasty to cede Taiwan to Japan,
which then governed Taiwan for 50 years. Taiwan came
under Chinese Nationalist (Kuomintang, KMT) control after
World War II. With the communist victory in the Chinese
civil war in 1949, the Nationalist-controlled Republic of
China government and 2 million Nationalists fled to Taiwan
and continued to claim to be the legitimate government for
mainland China and Taiwan based on a 1947 Constitution
drawn up for all of China. Until 1987, however, the
Nationalist government ruled Taiwan under a civil war
martial law declaration dating to 1948. Beginning in the
1970s, Nationalist authorities gradually began _ to
incorporate the native population into the governing
structure beyond the local level. The democratization
process expanded rapidly in the 1980s, leading to the then
illegal founding of Taiwan’s first opposition party (the
Democratic Progressive Party or DPP) in 1986 and the
lifting of martial law the following year. Taiwan held
legislative elections in 1992, the first in over forty years,
and its first direct presidential election in 1996. In the 2000
presidential elections, Taiwan underwent its first peaceful
transfer of power with the KMT loss to the DPP and
afterwards experienced two- additional democratic
transfers of power in 2008 and 2016. Throughout this
period, the island prospered, became one of East Asia’s
economic “Tigers,” and after 2000 became a major investor
in mainland China as cross-Strait ties matured. The
dominant political issues continue to be economic reform
and growth as well as management of sensitive relations
between Taiwan and China.
Background: The Tajik people came under Russian imperial
rule in the 1860s and 1870s, but Russia’s hold on Central
Asia weakened following the Revolution of 1917. At that
time, bands of indigenous guerrillas (called “basmachi”)
fiercely contested Bolshevik control of the area, which was
not fully reestablished until 1925. Tajikistan was first
created as an autonomous republic within Uzbekistan in
1924, but in 1929 the USSR designated Tajikistan a
separate republic and transferred to it much of present-day
Sughd province. Ethnic Uzbeks form a substantial minority
in Tajikistan, and ethnic Tajiks an even larger minority in
Uzbekistan. Tajikistan became independent in 1991
following the breakup of the Soviet Union, and experienced
a civil war between political, regional, and religious
factions from 1992 to 1997.
Though the country holds general elections for both the
presidency (once every seven years) and parliament (once
every five years), observers note an electoral system rife
with irregularities and abuse, with results that are neither
free nor fair. President Emomali RAHMON, who came to
power in 1994 during the civil war, used an attack planned
by a disaffected deputy defense minister in 2015 to ban the
last major opposition political party in Tajikistan. In
December 2015, RAHMON further strengthened his
position by having himself declared “Founder of Peace and
National Unity, Leader of the Nation,” with limitless terms
and lifelong immunity through constitutional amendments
ratified in a referendum. The referendum also lowered the
minimum age required to run for president from 35 to 30,
which would make RAHMON’s son Rustam EMOMALI, the
current mayor of the capital city of Dushanbe, eligible to
run for president in 2020.
The country remains the poorest in the former Soviet
sphere. Tajikistan became a member of the WTO in March
2013. However, its economy continues to face major
challenges, including dependence on remittances from
Tajikistani migrant laborers working in Russia and
Kazakhstan, pervasive corruption, and the opiate trade and
other destabilizing violence emanating from neighboring
Afghanistan. Tajikistan has endured several domestic
security incidents since 2010, including armed conflict
between government forces and local strongmen in the
Rasht Valley and between government forces and criminal
groups in Gorno-Badakhshan Autonomous _ Oblast.
Tajikistan suffered its first ISIS-claimed attack in 2018,
when assailants attacked a group of Western bicyclists with
vehicles and knives, killing four.','008228920a64a8d67e0e63912bcc8a216ddd68ac2442224eba7d11d65a6b73f2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f02dfa46ee289e19b11d1f1d9026a3300a3061ccbb0d99f22b102c5826dc4c94',2020,'MY','Malaysia','introduction',982,'Background: A unified Thai kingdom was established in the
mid-14th century. Known as Siam until 1939, Thailand is
the only Southeast Asian country never to have been
colonized by a European power. A bloodless revolution in
1932 led to the establishment of a constitutional monarchy.
After the Japanese invaded Thailand in 1941, the
government split into a pro-Japan faction and a pro-Ally
faction backed by the King. Following the war, Thailand
became a US treaty ally in 1954 after sending troops to
Korea and later fighting alongside the US in Vietnam.
Thailand since 2005 has experienced several rounds of
political turmoil including a military coup in 2006 that
ousted then Prime Minister THAKSIN Chinnawat, followed
by large-scale street protests by competing political
factions in 2008, 2009, and 2010. THAKSIN’s youngest
sister, YINGLAK Chinnawat, in 2011 led the Puea Thai
Party to an electoral win and assumed control of the','78afed6522c300bfda4e842ca44787ff72fffeb3fc7747054f3511203151cb64','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d60ce9a3316d282c49a9aa43a6bd97fcf182a23bb3783dbc281c85d08fdcde4',2020,'TT','Trinidad and Tobago','introduction',991,'Background: First colonized by the Spanish, the islands came
under British control in the early 19th century. The islands’
sugar industry was hurt by the emancipation of the slaves
in 1834. Manpower was replaced with the importation of
contract laborers from India between 1845 and 1917,
which boosted sugar production as well as the cocoa
industry. The discovery of oil on Trinidad in 1910 added
another important export. Independence was attained in
1962. The country is one of the most prosperous in the
Caribbean thanks largely to petroleum and natural gas
production and processing. Tourism, mostly in Tobago, is
targeted for expansion and is growing. The government is
struggling to reverse a surge in violent crime.
Background: Rivalry between French and Italian interests in
Tunisia culminated in a French invasion in 1881 and the
creation of a protectorate. Agitation for independence in
the decades following World War I was finally successful in
convincing the French to recognize Tunisia as an
independent state in 1956. The country’s first president,
Habib BOURGUIBA, established a strict one-party state. He
dominated the country for 31 years, repressing Islamic
fundamentalism and_ establishing rights for women
unmatched by any other Arab nation. In November 1987,
BOURGUIBA was removed from office and replaced by Zine
el Abidine BEN ALI in a bloodless coup. Street protests that
began in Tunis in December 2010 over high unemployment,
corruption, widespread poverty, and high food prices
escalated in January 2011, culminating in rioting that led to
hundreds of deaths. On 14 January 2011, the same day
BEN ALI dismissed the government, he fled the country,
and by late January 2011, a “national unity government”
was formed. Elections for the new Constituent Assembly
were held in late October 2011, and in December, it elected
human rights activist Moncef MARZOUKI as _ interim
president. The Assembly began drafting a new constitution
in February 2012 and, after several iterations and a
months-long political crisis that stalled the transition,
ratified the document in January 2014. Parliamentary and
presidential elections for a permanent government were
held at the end of 2014. Beji CAID ESSEBSI was elected as
the first president under the country’s new constitution.
Following ESSEBSI’s death in office in July 2019, Tunisia
moved its scheduled presidential election forward two
months and after two rounds of voting, Kais SAIED was
sworn in as president in October 2019. Tunisia also held
legislative elections on schedule in October 2019. SAIED’s
term, as well as that of Tunisia’s 217- member parliament,
expires in 2024.
Background: Modern Turkey was founded in 1923 from the
remnants of the defeated Ottoman Empire by national hero
Mustafa KEMAL, who was later honored with the title
Ataturk or “Father of the Turks.” Under his leadership, the
country adopted radical social, legal, and political reforms.
After a period of one-party rule, an experiment with multi-
party politics led to the 1950 election victory of the
opposition Democrat Party and the peaceful transfer of
power. Since then, Turkish political parties have multiplied,
but democracy has been fractured by periods of instability
and military coups (1960, 1971, 1980), which in each case
eventually resulted in a return of formal political power to
civilians. In 1997, the military again helped engineer the
ouster—popularly dubbed a “post-modern coup”—of the
then Islamic-oriented government. An unsuccessful coup
attempt was made in July 2016 by a faction of the Turkish
Armed Forces.
Turkey intervened militarily on Cyprus in 1974 to
prevent a Greek takeover of the island and has since acted
as patron state to the “Turkish Republic of Northern
Cyprus,” which only Turkey recognizes. A _ separatist
insurgency begun in 1984 by the Kurdistan Workers’ Party
(PKK), a US-designated terrorist organization, has long
dominated the attention of Turkish security forces and
claimed more than 40,000 lives. In 2013, the Turkish
Government and the PKK conducted negotiations aimed at
ending the violence, however intense fighting resumed in
2015. Turkey joined the UN in 1945 and in 1952 it became
a member of NATO. In 1963, Turkey became an associate
member of the European Community; it began accession
talks with the EU in 2005. Over the past decade, economic
reforms, coupled with some _ political reforms, have
contributed to a growing economy, although economic
growth slowed in recent years.
From 2015 and continuing through 2016, Turkey
witnessed an uptick in terrorist violence, including major
attacks in Ankara, Istanbul, and throughout’ the
predominantly Kurdish southeastern region of Turkey. On
15 July 2016, elements of the Turkish Armed forces
attempted a coup that ultimately failed following
widespread popular resistance. More than 240 people were
killed and over 2,000 injured when Turkish citizens took to
the streets en masse to confront the coup forces. The
government accused followers of the Fethullah Gulen
transnational religious and social movement (“Hizmet”) for
allegedly instigating the failed coup and designates the
movement’s followers as terrorists. Since the attempted
coup, Turkish Government authorities arrested, suspended,
or dismissed more than 130,000 security personnel,
journalists, judges, academics, and civil servants due to
their alleged connection to Gulen’s movement. Following
the failed coup, the Turkish Government instituted a State
of Emergency from July 2016 to July 2018. The Turkish
Government conducted a referendum on 16 April 2017 in
which voters approved _ constitutional amendments
changing Turkey from a parliamentary to a presidential
system. The amendments went into effect fully following
the presidential and parliamentary elections in June 2018.','a48851f8e2149a9e2b20079c199a72138abd50bdcfa7502a716f1f8d74b90152','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b3af2a37bbd7032b8403a4f8f33244b2996716188fffae7c0395deadc09692e',2020,'AE','United Arab Emirates','introduction',1006,'Background: The Trucial States of the Persian Gulf coast
granted the UK control of their defense and foreign affairs
in 19th century treaties. In 1971, six of these states—Abu
Dhabi, ‘Ajman, Al Fujayrah, Ash Sharigah, Dubayy, and
Umm al Qaywayn—merged to form the United Arab
Emirates (UAE). They were joined in 1972 by Ra’s al
Khaymah. The UAE’s per capita GDP is on par with those of
leading West European nations. For more than three
decades, oil and global finance drove the UAE’s economy.
In 2008-09, the confluence of falling oil prices, collapsing
real estate prices, and the international banking crisis hit
the UAE especially hard. The UAE did not experience the
“Arab Spring” unrest seen elsewhere in the Middle East in
2010-11, partly because of the government’s multi-year,
$1.6-billion infrastructure investment plan for the poorer
northern emirates, and its aggressive pursuit of advocates
of political reform. The UAE in recent years has played a
growing role in regional affairs. In addition to donating
billions of dollars in economic aid to help stabilize Egypt,
the UAE was one of the first countries to join the Defeat-
ISIS coalition, and to participate as a key partner in a
Saudi-led military campaign in Yemen.
Background: The United Kingdom has historically played a
leading role in developing parliamentary democracy and in
advancing literature and science. At its zenith in the 19th
century, the British Empire stretched over one-fourth of the
earth’s surface. The first half of the 20th century saw the
UK’s strength seriously depleted in two world wars and the
Irish Republic’s withdrawal from the union. The second half
witnessed the dismantling of the Empire and the UK
rebuilding itself into a modern and prosperous European
nation. As one of five permanent members of the UN
Security Council and a founding member of NATO and the
Commonwealth, the UK pursues a global approach to
foreign policy. The Scottish Parliament, the National
Assembly for Wales, and the Northern Ireland Assembly
were established in 1998.
The UK has been an active member of the EU since its
accession in 1973, although it chose to remain outside the
Economic and Monetary Union. However, motivated in part
by frustration at a remote bureaucracy in Brussels and
massive migration into the country, UK citizens on 23 June
2016 narrowly voted to leave the EU. The UK is scheduled
to depart the EU on 31 January 2020, but negotiations on
the future EU-UK economic and security relationship will
continue throughout 2020 and potentially beyond.','4c1e92bb75be059ee34eb44079a33019c4e3710f98434b8586d805480d051e86','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('521fa5dfb0a151f498599947c3103f62d82fbffa61cff5240653151db595a076',2020,'UZ','Uzbekistan','introduction',1017,'Background: Uzbekistan is the geographic and population
center of Central Asia. The country has a diverse economy
and a relatively young population. Russia conquered and
united the disparate territories of present-day Uzbekistan
in the late 19th century. Stiff resistance to the Red Army
after the Bolshevik Revolution was eventually suppressed
and a socialist republic established in 1924. During the
Soviet era, intensive production of “white gold” (cotton)
and grain led to the overuse of agrochemicals and the
depletion of water supplies, leaving the land degraded and
the Aral Sea and certain rivers half-dry. Independent since
the dissolution of the USSR in 1991, the country has
diversified agricultural production while developing its
mineral and petroleum export capacity and increasing its
manufacturing base, although cotton remains a major part
of its economy. Uzbekistan’s first president, Islam
KARIMOV, led Uzbekistan for 25 years until his death in
September 2016. His successor, former Prime Minister
Shavkat MIRZIYOYEV, has improved relations’ with
Uzbekistan’s neighbors and introduced wide-ranging
economic, judicial, and social reforms.','8cb97d89dde1f69c7b3f0e69f13b9f237866d0e6fa0fe9e75c4bbe029ee23053','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ce2faf5a833e98a7fda2aedb69c5417ff7f49e6d1617e895c401d784bd1581b',2020,'SB','Solomon Islands','introduction',1019,'Background: Multiple waves of colonizers, each speaking a
distinct language, migrated to the New Hebrides in the
millennia preceding European exploration in the 18th
century. This settlkement pattern accounts for the complex
linguistic diversity found on the archipelago to this day. The
British and French, who settled the New Hebrides in the
19th century, agreed in 1906 to an Anglo-French
Condominium, which administered the islands _ until
independence in 1980, when the new name of Vanuatu was
adopted. Politics and society continue to be divided along
linguistic lines, although those divisions are lessening over
time. Coalition governments tend to be weak, and since
2008, prime ministers have been ousted through no-
confidence motions or temporary procedural issues 10
times. Prime Minister Charlot SALAWI has survived four
no-confidence motions since taking office in 2016.','08ffe4bd46b801bb0b963c9713dfaf85f044bc32e1067a222389e6fe4c54f079','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2db419bf3882849ea7f939a3edf778068229f3a47677b36597cd3c5e34360bcc',2020,'MA','Morocco','introduction',1037,'Background: Western Sahara is a non-self-governing territory
on the northwest coast of Africa bordered by Morocco,
Mauritania, and Algeria. After Spain withdrew from its
former colony of Spanish Sahara in 1976, Morocco annexed
the northern two-thirds of Western Sahara and claimed the
rest of the territory in 1979, following Mauritania’s
withdrawal. A guerrilla war with the Polisario Front
contesting Morocco’s sovereignty ended in a 1991 cease-
fire and the establishment of a UN peacekeeping operation.
As part of this effort, the UN sought to offer a choice to the
peoples of Western Sahara between independence (favored
by the Polisario Front) or integration into Morocco. A
proposed referendum on the question of independence
never took place due to lack of agreement on voter
eligibility. The approximately 1,600 km- (almost 1,000 mi-)
long defensive sand berm, built by the Moroccans from
1980 to 1987 and running the length of the territory,
continues to separate the opposing forces, with Morocco
controlling the roughly three-quarters of the territory west
of the berm. There are periodic ethnic tensions between
the native Sahrawi population and Moroccan immigrants.
Morocco maintains a heavy security presence in the
territory. The UN revived direct talks about the territory
between Morocco, the Polisario Front, Algeria, and
Mauritania in December 2018.
Background: Globally, the 20th century was marked by: (a)
two devastating world wars; (b) the Great Depression of
the 1930s; (c) the end of vast colonial empires; (d) rapid
advances in science and technology, from the first airplane
flight at Kitty Hawk, North Carolina (US) to the landing on
the moon; (e) the Cold War between the Western alliance
and the Warsaw Pact nations; (f) a sharp rise in living
standards in North America, Europe, and Japan; (g)
increased concerns about environmental degradation
including deforestation, energy and water shortages,
declining biological diversity, and air pollution; (h) the
onset of the AIDS epidemic; and (i) the ultimate emergence
of the US as the only world superpower. The planet’s
population continues to explode: from 1 billion in 1820 to 2
billion in 1930, 3 billion in 1960, 4 billion in 1974, 5 billion
in 1987, 6 billion in 1999, and 7 billion in 2012. For the
21st century, the continued exponential growth in science
and technology raises both hopes (e.g., advances in
medicine and agriculture) and fears (e.g., development of
even more lethal weapons of war).','010aa37979764dd352cb656f17b915d209f4831754661d08070022d6f2ac1b38','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2769169c32e4747c3d93c4e9cc20da166eceee2ee66c95da46ee27fe523f194a',2020,'SA','Saudi Arabia','introduction',1046,'Background: The Kingdom of Yemen (colloquially known as
North Yemen) became independent from the Ottoman
Empire in 1918 and in 1962 became the Yemen Arab
Republic. The British, who had set up a protectorate area
around the southern port of Aden in the 19th century,
withdrew in 1967 from what became the People’s Republic
of Southern Yemen (colloquially known as South Yemen).
Three years later, the southern government adopted a
Marxist orientation and changed the country’s name to the
People’s Democratic Republic of Yemen. The massive
exodus of hundreds of thousands of Yemenis from the south
to the north contributed to two decades of hostility
between the states. The two countries were formally
unified as the Republic of Yemen in 1990. A southern
secessionist movement and brief civil war in 1994 was
quickly subdued. In 2000, Saudi Arabia and Yemen agreed
to delineate their border.
Fighting in the northwest between the government and
the Huthis, a Zaydi Shia Muslim minority, continued
intermittently from 2004 to 2010, and then again from
2014-present. The southern secessionist movement was
revitalized in 2007.
Public rallies in Sana’a against then President Ali
Abdallah SALIH—inspired by similar demonstrations in
Tunisia and Egypt—slowly built momentum starting in late
January 2011 #£=fueled by complaints’ over high
unemployment, poor economic conditions, and corruption.
By the following month, some protests had resulted in
violence, and the demonstrations had spread to other major
cities. By March the opposition had hardened its demands
and was unifying behind calls for SALIH’s immediate
ouster. In April 2011, the Gulf Cooperation Council (GCC),
in an attempt to mediate the crisis in Yemen, proposed the
GCC Initiative, an agreement in which the president would
step down in exchange for immunity from prosecution.
SALIH’s refusal to sign an agreement led to further
violence. The UN Security Council passed Resolution 2014
in October 2011 calling for an end to the violence and
completing a power transfer deal. In November 2011,
SALIH signed the GCC Initiative to step down and to
transfer some of his powers to Vice President Abd Rabuh
Mansur HADI. Following HADI’s uncontested election
victory in February 2012, SALIH formally transferred all
presidential powers. In accordance with the GCC Initiative,
Yemen launched a National Dialogue Conference (NDC) in
March 2013 to discuss key constitutional, political, and
social issues. HADI concluded the NDC in January 2014
and planned to begin implementing subsequent steps in the
transition process, including constitutional drafting, a
constitutional referendum, and national elections.
The Huthis, perceiving their grievances were not
addressed in the NDC, joined forces with SALIH and
expanded their influence in northwestern Yemen, which
culminated in a major offensive against military units and
rival tribes and enabled their forces to overrun the capital,
Sanaa, in September 2014. In January 2015, the Huthis
surrounded the presidential palace, HADI’s residence, and
key government facilities, prompting HADI and the cabinet
to submit their resignations. HADI fled to Aden in February
2015 and rescinded his resignation. He subsequently
escaped to Oman and then moved to Saudi Arabia and
asked the GCC to intervene militarily in Yemen to protect
the legitimate government from the Huthis. In March,
Saudi Arabia assembled a coalition of Arab militaries and
began airstrikes against the Huthis and Huthi-affiliated
forces. Ground fighting between Huthi-aligned forces and
anti-Huthi groups backed by the Saudi-led coalition
continued through 2016. In 2016, the UN brokered a
months-long cessation of hostilities that reduced airstrikes
and fighting, and initiated peace talks in Kuwait. However,
the talks ended without agreement. The Huthis and
SALIH’s political party announced a Supreme Political
Council in August 2016 and a National Salvation
Government, including a prime minister and several dozen
cabinet members, in November 2016, to govern in Sanaa
and further challenge the _ legitimacy of HADI’s
government. However, amid rising tensions between the
Huthis and SALIH, sporadic clashes erupted in mid-2017,
and escalated into open fighting that ended when Huthi
forces killed SALIH in early December 2017. In 2018, anti-
Huthi forces made the most battlefield progress in Yemen
since early 2016, most notably in Al MHudaydah
Governorate. In December 2018, the Huthis and Yemeni
Government participated in the first UN-brokered peace
talks since 2016, agreeing to a limited ceasefire in Al
Hudaydah Governorate and the establishment of a UN
Mission to monitor the agreement. In April 2019, Yemen’s
parliament convened in Say’un for the first time since the
conflict broke out in 2014. In August 2019, violence
erupted between HADI’s government and the _ pro-
secessionist Southern Transition Council (STC) in southern
Yemen. In November 2019, HADI’s government and the
STC signed a power-sharing agreement to end the fighting
between them.','1c10c79bc54f5fb7279eb5f87ba00d6991173c2c9423b646eaa47c47f4f25518','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

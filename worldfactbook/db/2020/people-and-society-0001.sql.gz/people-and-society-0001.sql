SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20336773ecd0b8423284322144117b16010cf1584c74b1479af438d7b0c58527',2020,'US','United States','people-and-society',43,'Population:
Median age:
Population growth rate:
Birth rate:
Death rate:
Net migration rate:
Maternal mortality rate:
Infant mortality rate:
Life expectancy at birth:
Total fertility rate:
HIV/AIDS—adult prevalence rate: HIV/AIDS—
people living with HIV/AIDS: HIV/AlIDS—deaths:
Obesity—adult prevalence rate: Children under
the age of 5 years underweight: Education
expenditures:
Unemployment, youth ages 15-24:','31f3fc16d574855e4d41f2899cc60f5cc1968af8e167edeed4b002a5199ebf5c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4769c3a7f61729883074e4b75dedd340df7f104ca5bacb790c548b487c8dfeb',2020,'GR','Greece','people-and-society',65,'Population: 3,074,579 (July 2020 est.)
country comparison to the world: 136
Nationality: Noun: Albanian(s)
adjective: Albanian
Ethnic groups: Albanian 82.6%, Greek 0.9%, other 1%
(including Vlach, Romani, Macedonian, Montenegrin, and
Egyptian), unspecified 15.5% (2011 est.) note: data
represent population by ethnic and cultural affiliation
Languages: Albanian 98.8% (official—derived from ‘Tosk
dialect), Greek 0.5%, other 0.6% (including Macedonian,
Romani, Vlach, Turkish, Italian, and Serbo-Croatian),
unspecified 0.1% (2011 est.) Religions: Muslim 56.7%,
Roman Catholic 10%, Orthodox 6.8%, atheist 2.5%,
Bektashi (a Sufi order) 2.1%, other 5.7%, unspecified
16.2% (2011 est.) note: all mosques and churches were
closed in 1967 and religious observances prohibited; in
November 1990, Albania began allowing private religious
practice Age. structure: 0-14 years: 17.6% (male
284,636/female 256,474)
15-24 years: 15.39% (male 246,931/female 226,318)
25-54 years: 42.04% (male 622,100/female 670,307)
95-64 years: 11.94% (male 178,419/female 188,783)
65 years and over: 13.03% (male 186,335/female 214,276)
(2020 est.)
Dependency ratios: total dependency ratio: 46.9
youth dependency ratio: 25.3
elderly dependency ratio: 21.6
potential support ratio: 4.6 (2020 est.)
Median age: total: 34.3 years
male: 32.9 years
female: 35.7 years (2020 est.)
country comparison to the world: 91
Population growth rate: 0.28% (2020 est.)
country comparison to the world: 173
Birth rate: 13 births/1,000 population (2020 est.)
country comparison to the world: 143
Death rate: 7.1 deaths/1,000 population (2020 est.)
country comparison to the world: 121
Net migration rate: -3.3 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 179
Population distribution: a fairly even distribution, with
somewhat higher concentrations of people in the western
and central parts of the country Urbanization: urban
population: 62.1% of total population (2020)
rate of urbanization: 1.69% annual rate of change (2015-20
est.)
Major urban areas—Population: 494,000 TIRANA (capital) (2020)
Sex ratio: at birth: 1.08 male(s)/female (2020 est.)
0-14 years: 1.11 male(s)/female (2020 est.)
15-24 years: 1.09 male(s)/female (2020 est.)
25-54 years: 0.93 male(s)/female (2020 est.)
55-64 years: 0.95 male(s)/female (2020 est.)
65 years and over: 0.87 male(s)/female (2020 est.)
total population: 97.6 male(s)/female (2020 est.)
Mother’s mean age at first birth: 24.8 years (2017/18 est.)
Maternal mortality rate: 15 deaths/100,000 live births (2017
est.)
country comparison to the world: 136
Infant mortality rate: total: 10.8 deaths/1,000 live births
male: 12.1 deaths/1,000 live births
female: 9.5 deaths/1,000 live births (2020 est.)
country comparison to the world: 125
Life expectancy at birth: total population: 79 years
male: 76.3 years
female: 81.9 years (2020 est.)
country comparison to the world: 61
Total fertility rate: 1.53 children born/woman (2020 est.)
country comparison to the world: 197
Contraceptive prevalence rate: 46% (2017/18)
Drinking water source:
improved:
urban: 84.3% of population
rural: 81.8% of population
total: 83.6% of population
unimproved:
urban: 15.7% of population
rural: 18.2% of population
total: 16.4% of population (2015 est.)
Current Health Expenditure: 6.7% (2016)
Physicians density: 1.2 physicians/1,000 population (2016)
Hospital bed density: 2.9 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 95.5% of population (2015 est.)
rural: 90.2% of population (2015 est.)
total: 93.2% of population (2015 est.)
unimproved:
urban: 4.5% of population (2015 est.)
rural: 9.8% of population (2015 est.)
total: 6.8% of population (2015 est.)
HIV/AIDS—adult prevalence rate: <.1 (2017 est.)
HIV/AIDS—people living with HIV/AIDS: 1,400 (2017 est.)
country comparison to the world: 137
HIV/AIDS—deaths: <100 (2017 est.)
Obesity—adult prevalence rate: 21.7% (2016)
country comparison to the world: 85
Children under the age of 5 years underweight: 1.5% (2017)
country comparison to the world: 116
Education expenditures: 4% of GDP (2016)
country comparison to the world: 101
Literacy: definition: age 15 and over can read and write
total population: 98.1%
male: 98.5%
female: 97.8% (2018)
School life expectancy (primary to tertiary education):
total: 15 years
male: 15 years
female: 16 years (2017)
Unemployment, youth ages 15-24:
total: 31.9%
male: 34.2%
female: 27.7% (2017 est.)
country comparison to the world: 26
Population: 42,972,878 (July 2020 est.)
country comparison to the world: 35
Nationality: noun: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less than 1%
note: although almost all Algerians are Berber in origin
(not Arab), only a minority identify themselves as primarily
Berber, about 15% of the total population; these people live
mostly in the mountainous region of Kabylie east of Algiers
and several other communities; the Berbers are also
Muslim but identify with their Berber rather than Arab
cultural heritage; Berbers have long agitated, sometimes
violently, for autonomy; the government is unlikely to grant
autonomy but has officially recognized Berber languages
and introduced them into public schools Languages: Arabic
(official), French (lingua franca), Berber or Tamazight
(official); dialects include Kabyle Berber (Taqbaylit),
Shawiya Berber (Tacawit), Mzab Berber, Tuareg Berber
(Tamahaq) Religions: Muslim (official; predominantly Sunni)
99%, other (includes Christian and Jewish) <1% (2012 est.)
Demographic profile: For the first two thirds of the 20th
century, Algeria’s high fertility rate caused its population to
grow rapidly. However, about a decade after independence
from France in 1962, the total fertility rate fell dramatically
from 7 children per woman in the 1970s to about 2.4 in
2000, slowing Algeria’s population growth rate by the late
1980s. The lower fertility rate was mainly the result of
women’s rising age at first marriage (virtually all Algerian
children being born in wedlock) and to a lesser extent the
wider use of contraceptives. Later marriages and a
preference for smaller families are attributed to increases
in women’s education and participation in the labor
market; higher unemployment; and a shortage of housing
forcing multiple generations to live together. The average
woman’s age at first marriage increased from about 19 in
the mid-1950s to 24 in the mid-1970s to 30.5 in the late
1990s.
Algeria’s fertility rate experienced an unexpected upturn
in the early 2000s, as the average woman’s age at first
marriage dropped slightly. The reversal in fertility could
represent a temporary fluctuation in marriage age or, less
likely, a decrease in the steady rate of contraceptive use.
Thousands of Algerian peasants—mainly Berber men
from the Kabylia region—faced with land dispossession and
economic hardship under French rule migrated temporarily
to France to work in manufacturing and mining during the
first half of the 20th century. This movement accelerated
during World War I, when Algerians filled in for French
factory workers or served as soldiers. In the years following
independence, low-skilled Algerian workers and Algerians
who had supported the French (known as_ Harkis)
emigrated en masse to France. Tighter French immigration
rules and Algiers’ decision to cease managing labor
migration to France in the 1970s limited legal emigration
largely to family reunification.
Not until Algeria’s civil war in the 1990s did the country
again experience substantial outmigration. Many Algerians
legally entered Tunisia without visas claiming to be tourists
and then stayed as workers. Other Algerians headed to
Europe seeking asylum, although France imposed
restrictions. Sub-Saharan African migrants came to Algeria
after its civil war to work in agriculture and mining. In the
2000s, a wave of educated Algerians went abroad seeking
skilled jobs in a wider range of destinations, increasing
their presence in North America and Spain. At the same
time, legal foreign workers principally from China and
Egypt came to work in Algeria’s construction and oil
sectors. Illegal migrants from Sub-Saharan Africa,
particularly Malians, Nigeriens, and Gambians, continue to
come to Algeria in search of work or to use it as a stepping
stone to Libya and Europe.
Since 1975, Algeria also has been the main recipient of
Sahrawi refugees from the ongoing conflict in Western
Sahara. More than 1000,000 Sahrawis are estimated to be
living in five refugee camps in southwestern Algeria near
Tindouf.
Age structure: 0-14 years: 29.58% (male 6,509,490/female
6,201,450)
15-24 years: 13.93% (male 3,063,972/female 2,922,368)
25-54 years: 42.91% (male 9,345,997/female 9,091,558)
55-64 years: 7.41% (male 1,599,369/female 1,585,233)
65 years and over: 6.17% (male 1,252,084/female
1,401,357) (2020 est.)
Dependency ratios: total dependency ratio: 60.1
youth dependency ratio: 49.3
elderly dependency ratio: 10.8
potential support ratio: 9.3 (2020 est.)
Median age: total: 28.9 years
male: 28.6 years
female: 29.3 years (2020 est.)
country comparison to the world: 139
Population growth rate: 1.52% (2020 est.)
country comparison to the world: 67
Birth rate: 20 births/1,000 population (2020 est.)
country comparison to the world: 76
Death rate: 4.4 deaths/1,000 population (2020 est.)
country comparison to the world: 208
Net migration rate: -0.9 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 137
Population distribution: the vast majority of the populace is
found in the extreme northern part of the country along the
Mediterranean Coast Urbanization: urban population: 73.7%
of total population (2020)
rate of urbanization: 2.46% annual rate of change (2015-20
est.)
Major urban areas—Population: 2.768 million ALGIERS (capital),
899,000 Oran (2020)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.05 male(s)/female (2020 est.)
25-54 years: 1.03 male(s)/female (2020 est.)
55-64 years: 1.01 male(s)/female (2020 est.)
65 years and over: 0.89 male(s)/female (2020 est.)
total population: 102.7 male(s)/female (2020 est.)
Maternal mortality rate: 112 deaths/100,000 live births (2017
est.)
country comparison to the world: 68
Infant mortality rate: total: 17.6 deaths/1,000 live births
male: 19.1 deaths/1,000 live births
female: 16 deaths/1,000 live births (2020 est.)
country comparison to the world: 85
Life expectancy at birth: total population: 77.5 years
male: 76.1 years
female: 79.1 years (2020 est.)
country comparison to the world: 77
Total fertility rate: 2.59 children born/woman (2020 est.)
country comparison to the world: 67
Contraceptive prevalence rate: 57.1% (2012/13)
Drinking water source:
improved:
urban: 84.3% of population
rural: 81.8% of population
total: 83.6% of population
unimproved:
urban: 15.7% of population
rural: 18.2% of population
total: 16.4% of population (2015 est.)
Current Health Expenditure: 6.6% (2016)
Physicians density: 1.83 physicians/1,000 population (2016)
Hospital bed density: 1.9 beds/1,000 population (2015)
Sanitation facility access:
improved:
urban: 89.8% of population (2015 est.)
rural: 82.2% of population (2015 est.)
total: 87.6% of population (2015 est.)
unimproved:
urban: 10.2% of population (2015 est.)
rural: 17.8% of population (2015 est.)
total: 12.4% of population (2015 est.)
HIV/AIDS—adult prevalence rate: <.1% (2018 est.)
HIV/AIDS—people living with HIV/AIDS: 16,000 (2018 est.)
country comparison to the world: 89
HIV/AIDS—deaths: <200 (2018 est.)
Obesity—adult prevalence rate: 27.4% (2016)
country comparison to the world: 38
Children under the age of 5 years underweight: 3% (2012)
country comparison to the world: 99
Education expenditures: NA
Literacy: definition: age 15 and over can read and write
total population: 81.4%
male: 87.4%
female: 75.3% (2018)
School life expectancy (primary to tertiary education):
total: 14 years
male: 14 years
female: 15 years (2011)
Unemployment, youth ages 15-24:
total: 25.7%
male: 22.1%
female: 44.9% (2016 est.)
country comparison to the world: 46
Population: 20,835,401 (July 2020 est.)
note: estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can result
in lower life expectancy, higher infant mortality, higher
death rates, lower population growth rates, and changes in
the distribution of population by age and sex than would
otherwise be expected country comparison to the world: 61
Nationality: Noun: Burkinabe (singular and plural)
adjective: Burkinabe
Ethnic groups: Mossi 52%, Fulani 8.4%, Gurma 7%, Bobo
4.9%, Gurunsi 4.6%, Senufo 4.5%, Bissa 3.7%, Lobi 2.4%,
Dagara 2.4%, Tuareg/Bella 1.9%, Dioula 0.8%,
unspecified/no answer 0.3%, other 7.2% (2010 est.)
Languages: French (official), native African languages
belonging to Sudanic family spoken by 90% of the
population Religions: Muslim 61.5%, Roman Catholic 23.3%,
traditional/animist 7.8%, Protestant 6.5%, other/no answer
0.2%, none 0.7% (2010 est.) Demographic profile: Burkina Faso
has a young age structure—the result of declining mortality
combined with steady high fertility—and continues to
experience rapid population growth, which is putting
increasing pressure on the country’s limited arable land.
More than 65% of the population is under the age of 25,
and the population is growing at 3% annually. Mortality
rates, especially those of infants and children, have
decreased because of improved health care, hygiene, and
sanitation, but women continue to have an average of
almost 6 children. Even if fertility were substantially
reduced, today’s large cohort entering their reproductive
years would sustain high population growth for the
foreseeable future. Only about a third of the population is
literate and unemployment is widespread, dampening the
economic prospects of Burkina Faso’s large working-age
population.
Migration has traditionally been a way of life for
Burkinabe, with seasonal migration being replaced by
stints of up to two years abroad. Cote d’Ivoire remains the
top destination, although it has experienced periods of
internal conflict. Under French colonization, Burkina Faso
became a main labor source for agricultural and factory
work in Cote d’Ivoire. Burkinabe also migrated to Ghana,
Mali, and Senegal for work between the world wars.
Burkina Faso attracts migrants from Cote d''Ivoire, Ghana,
and Mali, who often share common ethnic backgrounds
with the Burkinabe. Despite its food shortages and high
poverty rate, Burkina Faso has become a destination for
refugees in recent years and hosts about 33,500 Malians as
of May 2017.
(2018)
Age structure: 0-14 years: 43.58% (male 4,606,350/female
4,473,951) 15-24 years: 20.33% (male 2,121,012/female
2,114,213)
25-54 years: 29.36% (male 2,850,621/female 3,265,926)
55-64 years: 3.57% (male 321,417/female 423,016)
65 years and over: 3.16% (male 284,838/female 374,057)
(2020 est.)
Dependency ratios: total dependency ratio: 87.9
youth dependency ratio: 83.4
elderly dependency ratio: 4.5
potential support ratio: 22.1 (2020 est.)
Median age: total: 17.9 years
male: 17 years
female: 18.7 years (2020 est.)
country comparison to the world: 217
Population growth rate: 2.66% (2020 est.)
country comparison to the world: 18
Birth rate: 35.1 births/1,000 population (2020 est.)
country comparison to the world: 20
Death rate: 8.2 deaths/1,000 population (2020 est.)
country comparison to the world: 84
Net migration rate: -0.6 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 128
Population distribution: Most of the population is located in the
center and south. Nearly 31 percent of the population lives
in cities. The capital and largest city is Ouagadougou
(Ouaga), with a population of 1.8 million.
(2019)
Urbanization: urban population: 30.6% of total population
(2020)
rate of urbanization: 4.99% annual rate of change (2015-20
est.)
Major urban areas—population: 2.780 million OUAGADOUGOU
(capital), 972,000 Bobo-Dioulasso (2020) Sex ratio: at birth:
1.03 male(s)/female (2020 est.)
0-14 years: 1.03 male(s)/female (2020 est.)
15-24 years: 1 male(s)/female (2020 est.)
25-54 years: 0.87 male(s)/female (2020 est.)
55-64 years: 0.76 male(s)/female (2020 est.)
65 years and over: 0.76 male(s)/female (2020 est.)
total population: 95.6 male(s)/female (2020 est.)
Mother’s mean age at first birth: 19.4 years (2010 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 320 deaths/100,000 live births (2017
est.)
country comparison to the world: 34
Infant mortality rate: total: 52 deaths/1,000 live births
male: 56.4 deaths/1,000 live births
female: 47.5 deaths/1,000 live births (2020 est.)
country comparison to the world: 21
Life expectancy at birth: total population: 62.7 years
male: 60.9 years
female: 64.5 years (2020 est.)
country comparison to the world: 208
Total fertility rate: 4.51 children born/woman (2020 est.)
country comparison to the world: 23
Contraceptive prevalence rate: 31.7% (2017/18)
Drinking water source:
improved:
urban: 97.5% of population (2015 est.)
rural: 75.8% of population
total: 82.3% of population
unimproved:
urban: 2.5% of population
rural: 24.2% of population
total: 17.7% of population (2015 est.)
Current Health Expenditure: 6.8% (2016)
Physicians density: 0.06 physicians/1,000 population (2016)
Hospital bed density: 0.4 beds/1,000 population (2010)
Sanitation facility access:
improved:
urban: 50.4% of population (2015 est.)
rural: 6.7% of population (2015 est.)
total: 19.7% of population (2015 est.)
unimproved:
urban: 49.6% of population (2015 est.)
rural: 93.3% of population (2015 est.)
total: 80.3% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.7% (2018 est.)
country comparison to the world: 56
HIV/AIDS—people living with HIV/AIDS: 96,000 (2018 est.)
country comparison to the world: 44
HIV/AIDS—deaths: 3,300 (2018 est.)
country comparison to the world: 34
Major infectious diseases: degree of risk: very high (2019)
food or waterborne diseases: bacterial and _ protozoal
diarrhea, hepatitis A, and typhoid fever (2019) vectorborne
diseases: dengue fever and malaria (2019)
water contact diseases: schistosomiasis (2019)
animal contact diseases: rabies (2019)
respiratory diseases: meningococcal meningitis (2019)
Obesity—adult prevalence rate: 5.6% (2016)
country comparison to the world: 175
Children under the age of 5 years underweight:
16.2% (2017)
country comparison to the world: 38
Education expenditures: 4.2% of GDP (2015)
country comparison to the world: 92
Literacy: definition: age 15 and over can read and write
total population: 41.2%
male: 50.1%
female: 32.7% (2018)
School life expectancy (primary to tertiary education): total: 9 years
male: 9 years
female: 9 years (2017)
Unemployment, youth ages 15-24: total: 8.7%
male: 5.3%
female: 12.6%
country comparison to the world: 136','6c726dc22dc11eecbda032ecd6fe3e0b17be70152850165f242de5d853b168ab','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fba5d94bee9d3b135117bac76577d09619c43244f5741ca398ee08b5f7ca749',2020,'NA','Namibia','people-and-society',102,'Population: 18,090 July 2020 est.)
country comparison to the world: 220
Nationality: Noun: Anguillan(s)
adjective: Anguillan
Ethnic groups: African/black 85.3%, hispanic 4.9%, mixed
3.8%, white 3.2%, East Indian/Indian 1%, other 1.6%,
unspecified 0.3% (2011 est.) note: data represent
population by ethnic origin
Languages: English (official)
Religions: Protestant 73.2% (includes Anglican 22.7%,
Methodist 19.4%, Pentecostal 10.5%, Seventh Day
Adventist 8.3%, Baptist 7.1%, Church of God 4.9%,
Presbytarian 0.2%, Brethren 0.1%), Roman Catholic 6.8%,
Jehovah’s Witness 1.1%, other Christian 10.9%, other 3.2%,
unspecified 0.3%, none 4.5% (2011 est.) Age structure: 0-14
years: 21.63% (male 1,991/female 1,922)
15-24 years: 13.9% (male 1,269/female 1,246)
25-54 years: 42.27% (male 3,428/female 4,218)
95-64 years: 12.42% (male 993/female 1,254)
65 years and over: 9.78% (male 874/female 895) (2020 est.)
Median age: total: 35.7 years
male: 33.7 years
female: 37.6 years (2020 est.)
country comparison to the world: 81
Population growth rate: 1.86% (2020 est.)
country comparison to the world: 54
Birth rate: 12.2 births/1,000 population (2020 est.)
country comparison to the world: 158
Death rate: 4.8 deaths/1,000 population (2020 est.)
country comparison to the world: 204
Net migration rate: 11.1 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 6
Population distribution: most of the population is concentrated
in The Valley in the center of the island; settlmement is
fairly uniform in the southwest, but rather sparce in the
northeast Urbanization: urban population: 100% of total
population (2020)
rate of urbanization: 0.9% annual rate of change (2015-20
est.)
Major urban areas—Population: 1,000 THE VALLEY (capital)
(2018)
Sex ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1.04 male(s)/female (2020 est.)
15-24 years: 1.02 male(s)/female (2020 est.)
25-54 years: 0.81 male(s)/female (2020 est.)
595-64 years: 0.79 male(s)/female (2020 est.)
65 years and over: 0.98 male(s)/female (2020 est.)
total population: 89.7 male(s)/female (2020 est.)
Infant mortality rate: total: 3.3 deaths/1,000 live births
male: 3.6 deaths/1,000 live births
female: 2.9 deaths/1,000 live births (2020 est.)
country comparison to the world: 203
Life expectancy at birth: total population: 81.8 years
male: 79.2 years
female: 84.5 years (2020 est.)
country comparison to the world: 26
Total fertility rate: 1.74 children born/woman (2020 est.)
country comparison to the world: 161
Drinking water source:
improved:
urban: 94.6% of population
total: 94.6% of population
unimproved:
urban: 5.4% of population
total: 5.4% of population (2015 est.)
Sanitation facility access:
improved:
urban: 97.9% of population (2015 est.)
total: 97.9% of population (2015 est.)
unimproved:
urban: 2.1% of population (2015 est.)
total: 2.1% of population (2015 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Major infectious diseases: note: active local transmission of
Zika virus by Aedes species mosquitoes has been identified
in this country (as of August 2016); it poses an important
risk (a large number of cases possible) among US citizens if
bitten by an infective mosquito; other less common ways to
get Zika are through sex, via blood transfusion, or during
pregnancy, in which the pregnant woman passes Zika virus
to her fetus Education expenditures: NA','b5887fbf49ef2a27eacbc6d8a06ffae00d620170d1c5758ee69f70d3c45b2558','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf9a31181f80ef85606622f3eafcb40c8b6d8f8d3155dd847109411b365d003c',2020,'AU','Australia','people-and-society',129,'Population: no indigenous inhabitants
note: Indonesian fishermen are allowed access to the
lagoon and fresh water at Ashmore Reef’s West Island;
access to East and Middle Islands is by permit only
Population: no indigenous inhabitants (2017 est.)
note: there is a staff of four at the meteorological station on
Willis Island
Population: 290,009 (July 2020 est.)
country comparison to the world: 183
Nationality: noun: New Caledonian(s)
adjective: New Caledonian
Ethnic groups: Kanak 39.1%, European 27.1%, Wallisian,
Futunian 8.2%, Tahitian 2.1%, Indonesian 1.4%, Ni-Vanuatu
1%, Vietnamese 0.9%, other 17.7%, unspecified 2.5% (2014
est.) Languages: French (official), 33 Melanesian-Polynesian
dialects
Religions: Roman Catholic 60%, Protestant 30%, other 10%
Age structure: 0-14 years: 21.74% (male 32,227/female
30,819)
15-24 years: 15.63% (male 23,164/female 22,163)
25-54 years: 43.73% (male 63,968/female 62,856)
55-64 years: 9.06% (male 12,700/female 13,568)
65 years and over: 9.84% (male 12,552/female 15,992)
(2020 est.)
Dependency ratios: total dependency ratio: 48.3 (2015 est.)
youth dependency ratio: 33.9 (2015 est.)
elderly dependency ratio: 14.4 (2015 est.)
potential support ratio: 6.9 (2015 est.)
Median age: total: 32.9 years
male: 32.1 years
female: 33.7 years (2020 est.)
country comparison to the world: 103
Population growth rate: 1.25% (2020 est.)
country comparison to the world: 88
Birth rate: 14.5 births/1,000 population (2020 est.)
country comparison to the world: 129
Death rate: 5.9 deaths/1,000 population (2020 est.)
country comparison to the world: 173
Net migration rate: 3.8 migrant(s)/1,000 population (2020 est.)
note: there has been steady emigration from Wallis and
Futuna to New Caledonia
country comparison to the world: 32
Population distribution: most of the populace lives in the
southern part of the main island, in and around the capital
of Noumea Urbanization: urban population: 71.5% of total
population (2020)
rate of urbanization: 1.89% annual rate of change (2015-20
est.)
Major urban areas—population: 198,000 NOUMEA (capital)
(2018)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.05 male(s)/female (2020 est.)
25-54 years: 1.02 male(s)/female (2020 est.)
55-64 years: 0.94 male(s)/female (2020 est.)
65 years and over: 0.78 male(s)/female (2020 est.)
total population: 99.5 male(s)/female (2020 est.)
Infant mortality rate: total: 5 deaths/1,000 live births
male: 5.9 deaths/1,000 live births
female: 4.1 deaths/1,000 live births (2020 est.)
country comparison to the world: 178
Life expectancy at birth: total population: 78.4 years
male: 74.4 years
female: 82.5 years (2020 est.)
country comparison to the world: 67
Total fertility rate: 1.88 children born/woman (2020 est.)
country comparison to the world: 134
Drinking water source:
improved:
urban: 98.5% of population
rural: 98.5% of population
total: 98.5% of population
unimproved:
urban: 1.5% of population
rural: 1.5% of population
total: 1.5% of population (2015 est.)
Physicians density: 2.22 physicians/1,000 population (2009)
Sanitation facility access:
improved:
urban: 100% of population (2015 est.)
rural: 100% of population (2015 est.)
total: 100% of population (2015 est.)
unimproved:
urban: 0% of population (2015 est.)
rural: 0% of population (2015 est.)
total: 0% of population (2015 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Major infectious diseases: note: active local transmission of
Zika virus by Aedes species mosquitoes has been identified
in this country (as of August 2016); it poses an important
risk (a large number of cases possible) among US citizens if
bitten by an infective mosquito; other less common ways to
get Zika are through sex, via blood transfusion, or during
pregnancy, in which the pregnant woman passes Zika virus
to her fetus Education expenditures: NA
Literacy: definition: age 15 and over can read and write
total population: 96.9%
male: 97.3%
female: 96.5% (2015)
Unemployment, youth ages 15-24: total: 38.4%
male: 37.1%
female: 40% (2014 est.)
country comparison to the world: 16','7a4c6460b24708df3746016c36261e99585860ac58938a1403d6a4085d08a804','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fd96f1ffa2c6864007ad1440c3d5ab72cf5d23702db7c850d2c3e58fe93408c',2020,'BB','Barbados','people-and-society',160,'Population: 294,560 (July 2020 est.)
country comparison to the world: 182
Nationality: Noun: Barbadian(s) or Bajan (colloquial)
adjective: Barbadian or Bajan (colloquial)
Ethnic groups: African descent 92.4%, mixed 3.1%, white
2.7%, East Indian 1.3%, other 0.2%, unspecified 0.3%
(2010 est.) Languages: English (official), Bajan (English-
based creole language, widely spoken in informal settings)
Religions: Protestant 66.4% (includes Anglican 23.9%, other
Pentecostal 19.5%, Adventist 5.9%, Methodist 4.2%,
Wesleyan 3.4%, Nazarene 3.2%, Church of God 2.4%,
Baptist 1.8%, Moravian 1.2%, other Protestant 0.9%),
Roman Catholic 3.8%, other Christian 5.4% (includes
Jehovah’s Witness 2.0%, other 3.4%), Rastafarian 1%, other
1.5%, none 20.6%, unspecified 1.2% (2010 est.) Age
structure: 0-14 years: 17.49% (male 25,762/female 25,764)
15-24 years: 12.34% (male 18,024/female 18,330)
25-54 years: 42.69% (male 62,655/female 63,093)
595-64 years: 13.91% (male 19,533/female 21,430)
65 years and over: 13.57% (male 16,398/female 23,571)
(2020 est.)
Dependency ratios: total dependency ratio: 50.3
youth dependency ratio: 25.2
elderly dependency ratio: 25.1
potential support ratio: 4 (2020 est.)
Median age: total: 39.5 years
male: 38.4 years
female: 40.7 years (2020 est.)
country comparison to the world: 55
Population growth rate: 0.23% (2020 est.)
country comparison to the world: 179
Birth rate: 11.3 births/1,000 population (2020 est.)
country comparison to the world: 173
Death rate: 8.8 deaths/1,000 population (2020 est.)
country comparison to the world: 65
Net migration rate: -0.3 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 112
Population distribution: most densely populated country in the
eastern Caribbean; approximately one-third live in urban
areaS Urbanization: urban population: 31.2% of total
population (2020) rate of urbanization: 0.2% annual rate of
change (2015-20 est.)
Major urban areas—population: 89,000 BRIDGETOWN (capital)
(2018)
Sex ratio: at birth: 1.01 male(s)/female (2020 est.)
0-14 years: 1 male(s)/female (2020 est.)
15-24 years: 0.98 male(s)/female (2020 est.)
25-54 years: 0.99 male(s)/female (2020 est.)
55-64 years: 0.91 male(s)/female (2020 est.)
65 years and over: 0.7 male(s)/female (2020 est.)
total population: 93.6 male(s)/female (2020 est.)
Maternal mortality rate: 27 deaths/100,000 live births (2017
est.)
country comparison to the world: 115
Infant mortality rate: total: 9.6 deaths/1,000 live births
male: 10.7 deaths/1,000 live births
female: 8.4 deaths/1,000 live births (2020 est.)
country comparison to the world: 135
Life expectancy at birth: total population: 76 years
male: 73.6 years
female: 78.4 years (2020 est.)
country comparison to the world: 106
Total fertility rate: 1.68 children born/woman (2020 est.)
country comparison to the world: 178
Contraceptive prevalence rate: 59.2% (2012)
Drinking water source:
improved:
urban: 99.7% of population
rural: 99.7% of population
total: 99.7% of population
unimproved:
urban: 0.3% of population
rural: 0.3% of population
total: 0.3% of population (2015 est.)
Current Health Expenditure: 7% (2016)
Physicians density: 2.49 physicians/1,000 population (2017)
Hospital bed density: 5.8 beds/1,000 population (2014)
Sanitation facility access:
improved:
urban: 96.2% of population (2015 est.)
rural: 96.2% of population (2015 est.)
total: 96.2% of population (2015 est.)
unimproved:
urban: 3.8% of population (2015 est.)
rural: 3.8% of population (2015 est.)
total: 3.8% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 1.5% (2018 est.)
country comparison to the world: 30
HIV/AIDS—people living with HIV/AIDS: 3,000 (2018 est.)
country comparison to the world: 130
HIV/AIDS—deaths: <100 (2018 est.)
Major infectious diseases: note: active local transmission of
Zika virus by Aedes species mosquitoes has been identified
in this country (as of August 2016); it poses an important
risk (a large number of cases possible) among US citizens if
bitten by an infective mosquito; other less common ways to
get Zika are through sex, via blood transfusion, or during
pregnancy, in which the pregnant woman passes Zika virus
to her fetus Obesity—adult prevalence rate: 23.1% (2016)
country comparison to the world: 67
Children under the age of 5 years underweight:
3.5% (2012)
country comparison to the world: 92
Education expenditures: 4.7% of GDP (2017)
country comparison to the world: 76
Literacy: definition: age 15 and over can read and write
total population: 99.6%
male: 99.6%
female: 99.6% (2014)
School life expectancy (primary to tertiary education): total: 15
years male: 14 years
female: 17 years (2011)
Unemployment, youth ages 15-24: total: 29.6%
male: 27.9%
female: 31.5% (2016 est.)
country comparison to the world: 32
Population: 9,477,918 (July 2020 est.)
country comparison to the world: 94
Nationality: Noun: Belarusian(s)
adjective: Belarusian
Ethnic groups: Belarusian 83.7%, Russian 8.3%, Polish 3.1%,
Ukrainian 1.7%, other 2.4%, unspecified 0.9% (2009 est.)
Languages: Russian (official) 70.2%, Belarusian (official)
23.4%, other 3.1% (includes small Polish- and Ukrainian-
speaking minorities), unspecified 3.3% (2009 est.) Religions:
Orthodox 48.3%, Catholic 7.1%, other 3.5%, non-believers
41.1% (2011 est.) Age structure: 0-14 years: 16.09% (male
784,231/female 740,373) 15-24 years: 9.59% (male
467,393/female 441,795)
25-54 years: 43.94% (male 2,058,648/female 2,105,910)
595-64 years: 14.45% (male 605,330/female 763,972)
65 years and over: 15.93% (male 493,055/female
1,017,211) (2020 est.)
Dependency ratios: total dependency ratio: 48.9
youth dependency ratio: 25.7
elderly dependency ratio: 23.2
potential support ratio: 4.3 (2020 est.)
Median age: total: 40.9 years
male: 38 years
female: 43.9 years (2020 est.)
country comparison to the world: 48
Population growth rate: -0.27% (2020 est.)
country comparison to the world: 215
Birth rate: 9.5 births/1,000 population (2020 est.)
country comparison to the world: 196
Death rate: 13.1 deaths/1,000 population (2020 est.)
country comparison to the world: 8
Net migration rate: 0.7 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 65
Population distribution: a fairly even distribution throughout
most of the country, with urban areas attracting larger and
denser populations Urbanization: urban population: 79.5% of
total population (2020) rate of urbanization: 0.44% annual
rate of change (2015-20 est.)
Major urban areas—population: 2.028 million MINSK (capital)
(2020)
Sex ratio: at birth: 1.06 male(s)/female (2020 est.)
0-14 years: 1.06 male(s)/female (2020 est.)
15-24 years: 1.06 male(s)/female (2020 est.)
25-54 years: 0.98 male(s)/female (2020 est.)
55-64 years: 0.79 male(s)/female (2020 est.)
65 years and over: 0.48 male(s)/female (2020 est.)
total population: 87 male(s)/female (2020 est.)
Mother’s mean age at first birth: 207 years (2014 est.)
Maternal mortality rate: 2 deaths/100,000 live births (2017
est.)
country comparison to the world: 181
Infant mortality rate: total: 3.5 deaths/1,000 live births
male: 3.9 deaths/1,000 live births
female: 3.1 deaths/1,000 live births (2020 est.)
country comparison to the world: 198
Life expectancy at birth: total population: 73.8 years
male: 68.3 years
female: 79.5 years (2020 est.)
country comparison to the world: 139
Total fertility rate: 1.5 children born/woman (2020 est.)
country comparison to the world: 201
Contraceptive prevalence rate: 72.1% (2017)
note: percent of women 18-49
Drinking water source:
improved:
urban: 99.9% of population
rural: 99.1% of population
total: 99.7% of population
unimproved:
urban: 0.1% of population
rural: 0.9% of population
total: 0.3% of population (2015 est.)
Current Health Expenditure: 6.3% (2016)
Physicians density: 4.08 physicians/1,000 population (2014)
Hospital bed density: 11 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 94.1% of population (2015 est.)
rural: 95.2% of population (2015 est.)
total: 94.3% of population (2015 est.)
unimproved:
urban: 5.9% of population (2015 est.)
rural: 4.8% of population (2015 est.)
total: 5.7% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.5% (2018 est.)
country comparison to the world: 66
HIV/AIDS—people living with HIV/AIDS: 27,000 (2018 est.)
country comparison to the world: 75
HIV/AIDS—deaths: <500 (2018 est.)
Obesity—adult prevalence rate: 24.5% (2016)
country comparison to the world: 58
Education expenditures: 4.8% of GDP (2017)
country comparison to the world: 70
Literacy: definition: age 15 and over can read and write
total population: 99.8%
male: 99.8%
female: 99.7% (2018)
School life expectancy (primary to tertiary education): total: 15
years male: 15 years
female: 16 years (2017)
Unemployment, youth ages 15-24: total: 9.3%
male: 11.2%
female: 7.2% (2017 est.)
country comparison to the world: 133','00323cfac69c9a3ab62af4afae6332eb88d8afec0f309b69541a6cab784b88e0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15688e8271334f727e0052abdccd73ccbe68ab564a4ff0ae7cd2415eed307dee',2020,'FR','France','people-and-society',171,'Population: 11,720,716 (July 2020 est.)
country comparison to the world: 80
Nationality: Noun: Belgian(s)
adjective: Belgian
Ethnic groups: Belgian 75.2%, Italian 4.1%, Moroccan 3.7%,
French 2.4%, Turkish 2%, Dutch 2%, other 10.6% (2012
est.) Languages: Dutch (official) 60%, French (official) 40%,
German (official) less than 1%
Religions: Roman Catholic 50%, Protestant and other
Christian 2.5%, Muslim 5%, Jewish 0.4%, Buddhist 0.3%,
atheist 9.2%, none 32.6% (2009 est.) Age structure: 0-14
years: 17.22% (male 1,033,383/female 984,624) 15-24
years: 11.2% (male 670,724/female 642,145)
25-54 years: 39.23% (male 2,319,777/female 2,278,450)
95-64 years: 13.14% (male 764,902/female 775,454)
65 years and over: 19.21% (male 988,148/female
1,263,109) (2020 est.)
Dependency ratios: total dependency ratio: 57
youth dependency ratio: 26.7
elderly dependency ratio: 30.2
potential support ratio: 3.3 (2020 est.)
Median age: total: 41.6 years
male: 40.4 years
female: 42.8 years (2020 est.)
country comparison to the world: 44
Population growth rate: 0.63% (2020 est.)
country comparison to the world: 148
Birth rate: 11.1 births/1,000 population (2020 est.)
country comparison to the world: 176
Death rate: 9.8 deaths/1,000 population (2020 est.)
country comparison to the world: 40
Net migration rate: 4.8 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 26
Population distribution: most of the population concentrated in
the northern two-thirds of the country; the southeast is
more thinly populated; considered to have one of the
highest population densities in the world; approximately
97% live in urban areas Urbanization: urban population:
98.1% of total population (2020) rate of urbanization:
0.62% annual rate of change (2015-20 est.)
Major urban areas—population: 2.081 million BRUSSELS
(capital), 1.042 million Antwerp (2020) Sex ratio: at birth:
1.05 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.04 male(s)/female (2020 est.)
25-54 years: 1.02 male(s)/female (2020 est.)
55-64 years: 0.99 male(s)/female (2020 est.)
65 years and over: 0.78 male(s)/female (2020 est.)
total population: 97.2 male(s)/female (2020 est.)
Mother’s mean age at first birth: 28.6 years (2013 est.)
Maternal mortality rate: 5 deaths/100,000 live births (2017
est.)
country comparison to the world: 164
Infant mortality rate: total: 3.3 deaths/1,000 live births male:
3.7 deaths/1,000 live births
female: 2.9 deaths/1,000 live births (2020 est.)
country comparison to the world: 205
Life expectancy at birth: total population: 81.4 years
male: 78.8 years
female: 84.2 years (2020 est.)
country comparison to the world: 31
Total fertility rate: 1.77 children born/woman (2020 est.)
country comparison to the world: 152
Contraceptive prevalence rate: 66.8% (2013)
note: percent of women aged 15-54
Drinking water source:
improved:
urban: 100% of population
rural: 100% of population
total: 100% of population
unimproved:
urban: 0% of population
rural: 0% of population
total: 0% of population (2015 est.)
Current Health Expenditure: 10% (2016)
Physicians density: 3.32 physicians/1,000 population (2016)
Hospital bed density: 6.2 beds/1,000 population (2014)
Sanitation facility access:
improved:
urban: 99.5% of population (2015 est.)
rural: 99.4% of population (2015 est.)
total: 99.5% of population (2015 est.)
unimproved:
urban: 0.5% of population (2015 est.)
rural: 0.6% of population (2015 est.)
total: 0.5% of population (2015 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Obesity—adult prevalence rate: 22.1% (2016)
country comparison to the world: 81
Education expenditures: 6.5% of GDP (2016)
country comparison to the world: 20
School life expectancy (primary to tertiary education): total: 20
years male: 19 years
female: 21 years (2016)
Unemployment, youth ages 15-24: total: 19.3%
male: 20.2%
female: 18% (2017 est.)
country comparison to the world: 70','62625c4de83c88f88db90dbbf6259f20cba7272185c57e761085a5ec5ef311bd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('659033126f32b184378dc53c1bfd70879af0df4e68c671d3a33d2e7d0f2f4128',2020,'ET','Ethiopia','people-and-society',193,'Population: 71,750 (July 2020 est.)
country comparison to the world: 203
Nationality: N0un: Bermudian(s)
adjective: Bermudian
Ethnic groups: African descent 53.8%, white 31%, mixed
7.5%, other 7.1%, unspecified 0.6% (2010 est.) Languages:
English (official), Portuguese
Religions: Protestant 46.2% (includes Anglican 15.8%,
African Methodist Episcopal 8.6%, Seventh Day Adventist
6.7, Pentecostal 3.5%, Methodist 2.7%, Presbyterian 2.0%,
Church of God 1.6%, Baptist 1.2%, Salvation Army 1.1%,
Brethren 1.0%, other Protestant 2.0%), Roman Catholic
14.5%, Jehovah’s Witness 1.3%, other Christian 9.1%,
Muslim 1%, other 3.9%, none 17.8%, unspecified 6.2%
(2010 est.) Age structure: 0-14 years: 16.7% (male
6,053/female 5,928) 15-24 years: 11.88% (male
4,290/female 4,235)
25-54 years: 35.31% (male 12,758/female 12,575)
95-64 years: 16.37% (male 5,560/female 6,185)
65 years and over: 19.74% (male 6,032/female 8,134) (2020
est.)
Median age: total: 43.6 years
male: 41.6 years
female: 45.7 years (2020 est.)
country comparison to the world: 23
Population growth rate: 0.39% (2020 est.)
country comparison to the world: 161
Birth rate: 11.2 births/1,000 population (2020 est.)
country comparison to the world: 175
Death rate: 9.1 deaths/1,000 population (2020 est.)
country comparison to the world: 57
Net migration rate: 1.6 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 53
Population distribution: relatively even population distribution
throughout
Urbanization: urban population: 100% of total population
(2020) rate of urbanization: -0.44% annual rate of change
(2015-20 est.)
Major urban areas—population: 10,000 HAMILTON (capital)
(2018)
Sex ratio: at birth: 1.02 male(s)/female (2020 est.)
0-14 years: 1.02 male(s)/female (2020 est.)
15-24 years: 1.01 male(s)/female (2020 est.)
25-54 years: 1.01 male(s)/female (2020 est.)
55-64 years: 0.9 male(s)/female (2020 est.)
65 years and over: 0.74 male(s)/female (2020 est.)
total population: 93.6 male(s)/female (2020 est.)
Infant mortality rate: total: 2.5 deaths/1,000 live births male:
2.6 deaths/1,000 live births
female: 2.4 deaths/1,000 live births (2020 est.)
country comparison to the world: 221
Life expectancy at birth: total population: 81.7 years
male: 78.5 years
female: 84.9 years (2020 est.)
country comparison to the world: 27
Total fertility rate: 1.91 children born/woman (2020 est.)
country comparison to the world: 128
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Education expenditures: 1.5% of GDP (2017)
country comparison to the world: 171
School life expectancy (primary to tertiary education): total: 12
years male: 11 years
female: 12 years (2015)
Unemployment, youth ages 15-24: total: 29.3%
male: 29.7%
female: 29% (2014 est.)
country comparison to the world: 35
Population: 1,285 (2016 est.)
country comparison to the world: 235
Nationality: N0un: Tokelauan(s)
adjective: Tokelauan
Ethnic groups: Tokelauan 64.5%, part Tokelauan/Samoan
9.7%, part Tokelauan/Tuvaluan 2.8%, Tuvaluan 7.5%,
Samoan 5.8%, other Pacific Islander 3.4%, other 5.6%,
unspecified 0.8% (2016 est.) Languages: Tokelauan 88.1% (a
Polynesian language), English 48.6%, Samoan 26.7%,
Tuvaluan 11.2%, Kiribati 1.5%, other 2.8%, none 2.8%,
unspecified 0.8% (2016 ests.) note: shares sum to more
than 100% because some respondents gave more than one
answer on the census Religions: Congregational Christian
Church 50.4%, Roman Catholic 38.7%, Presbyterian 5.9%,
other Christian 4.2%, unspecified 0.8% (2016 est.)
Population growth rate: -0.01% (2014 est.)
country comparison to the world: 196
Population distribution: the country’s small population is fairly
evenly distributed amongst the three atolls Urbanization:
urban population: 0% of total population (2020)
rate of urbanization: 0% annual rate of change (2015-20
est.)
Sex ratio: NA
Infant mortality rate: total: NA (2018)
male: NA
female: NA
Life expectancy at birth: total population: NA (2017 est.)
male: NA
female: NA
Total fertility rate: NA
Drinking water source:
improved:
rural: 100% of population
total: 100% of population
unimproved:
rural: 0% of population
total: 0% of population (2015 est.)
Physicians density: 2.72 physicians/1,000 population (2010)
Sanitation facility access:
improved:
rural: 90.5% of population (2015 est.)
total: 90.5% of population (2015 est.)
unimproved:
rural: 9.5% of population (2015 est.)
total: 9.5% of population (2015 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Education expenditures: NA','572cb3547d6a349e0d8713ebda29f3bb1ce337cda63c3444920e99ce9e1741d7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f68d7b2457a9fa3842643e8618f3669bfc01b277891fa73ff37514aff401de5',2020,'PR','Puerto Rico','people-and-society',236,'Population: 37,381 (July 2020 est.)
country comparison to the world: 215
Nationality: Noun: British Virgin Islander(s)
adjective: British Virgin Islander
Ethnic groups: African/black 76.3%, Latino 5.5%, white 5.4%,
mixed 5.3%, Indian 2.1%, East Indian 1.6%, other 3%,
unspecified 0.8% (2010 est.) Languages: English (official)
Religions: Protestant 70.2% (Methodist 17.6%, Church of
God 10.4%, Anglican 9.5%, Seventh Day Adventist 9.0%,
Pentecostal 8.2%, Baptist 7.4%, New Testament Church of
God 6.9%, other Protestant 1.2%), Roman Catholic 8.9%,
Jehovah’s Witness 2.5%, Hindu 1.9%, other 6.2%, none
7.9%, unspecified 2.4% (2010 est.) Age structure: 0-14 years:
16.59% (male 3,060/female 3,142)
15-24 years: 12.53% (male 2,240/female 2,445)
25-54 years: 48.27% (male 8,424/female 9,620)
95-64 years: 12.51% (male 2,261/female 2,416)
65 years and over: 10.09% (male 1,808/female 1,965) (2020
est.)
Median age: total: 37.2 years
male: 37 years
female: 37.5 years (2020 est.)
country comparison to the world: 71
Population growth rate: 2.14% (2020 est.)
country comparison to the world: 39
Birth rate: 11.1 births/1,000 population (2020 est.)
country comparison to the world: 177
Death rate: 5.4 deaths/1,000 population (2020 est.)
country comparison to the world: 184
Net migration rate: 15.5 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 2
Population distribution: a fairly even distribution throughout
the inhabited islands, with the largest islands of Tortola,
Anegada, Virgin Gorda, and Jost Van Dyke having the
largest populations Urbanization: urban population: 48.5% of
total population (2020)
rate of urbanization: 2.42% annual rate of change (2015-20
est.)
Major urban areas—population: 15,000 ROAD TOWN (capital)
(2018)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 0.97 male(s)/female (2020 est.)
15-24 years: 0.92 male(s)/female (2020 est.)
25-54 years: 0.88 male(s)/female (2020 est.)
55-64 years: 0.94 male(s)/female (2020 est.)
65 years and over: 0.92 male(s)/female (2020 est.)
total population: 90.8 male(s)/female (2020 est.)
Infant mortality rate: total: 11 deaths/1,000 live births
male: 12.5 deaths/1,000 live births
female: 9.4 deaths/1,000 live births (2020 est.)
country comparison to the world: 122
Life expectancy at birth: total population: 79.2 years
male: 77.7 years
female: 80.8 years (2020 est.)
country comparison to the world: 57
Total fertility rate: 1.33 children born/woman (2020 est.)
country comparison to the world: 222
Drinking water source:
improved:
urban: 98% of population
rural: 98% of population
total: 98% of population
unimproved:
urban: 2% of population
rural: 2% of population
total: 2% of population (2010 est.)
Sanitation facility access:
improved:
urban: 97.5% of population (2015 est.)
rural: 97.5% of population (2015 est.)
total: 97.5% of population (2015 est.)
unimproved:
urban: 2.5% of population (2015 est.)
rural: 2.5% of population (2015 est.)
total: 2.5% of population (2015 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Education expenditures: 3.2% of GDP (2017)
country comparison to the world: 130
School life expectancy (primary to tertiary education): total: 14
years male: NA
female: NA (2015)','118e6dca0ba02552d0766d69c9fada23be1885cd37df188f722361408773a554','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4aa7731055bfbd9227a7a151805cb43f532fe0eed406a1d1f7d8bbde0b2f80a',2020,'RW','Rwanda','people-and-society',257,'Population: 11,865,821 (July 2020 est.)
note: estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can result
in lower life expectancy, higher infant mortality, higher
death rates, lower population growth rates, and changes in
the distribution of population by age and sex than would
otherwise be expected country comparison to the world: 77
Nationality: N0un: Burundian(s)
adjective: Burundian
Ethnic groups: Hutu, Tutsi, Twa (Pygmy)
Languages: Kirundi only 29.7% (official); French only .3%
(official); Swahili only .2%; English only .1% (official);
Kirundi and French 8.4%; Kirundi, French, and English
2.4%, other language combinations 2%, unspecified 56.9%
(2008 est.) note: data represent languages read and written
by people 10 years of age or older; spoken Kirundi is nearly
universal Religions: Roman Catholic 62.1%, Protestant 23.9%
(includes Adventist 2.3% and other Protestant 21.6%),
Muslim 2.5%, other 3.6%, unspecified 7.9% (2008 est.)
Demographic profile: Burundi is a densely populated country
with a high population growth rate, factors that combined
with land scarcity and poverty place a large share of its
population at risk of food insecurity. About 90% of the
population relies on subsistence agriculture. Subdivision of
land to sons, and redistribution to returning refugees,
results in smaller, overworked, and less productive plots.
Food shortages, poverty, and a lack of clean water
contribute to a 60% chronic malnutrition rate among
children. A lack of reproductive health services has
prevented a significant reduction in Burundi’s maternal
mortality and fertility rates, which are both among the
world’s highest. With two-thirds of its population under the
age of 25 and a birth rate of about 6 children per woman,
Burundi’s population will continue to expand rapidly for
decades to come, putting additional strain on a poor
country.
Historically, migration flows into and out of Burundi
have consisted overwhelmingly of refugees from violent
conflicts. In the last decade, more than a half million
Burundian refugees returned home from _ neighboring
countries, mainly Tanzania. Reintegrating the returnees
has been problematic due to their prolonged time in exile,
land scarcity, poor infrastructure, poverty, and
unemployment. Repatriates and_ existing § residents
(including internally displaced persons) compete for limited
land and other resources. To further complicate matters,
international aid organizations reduced their assistance
because they no longer classified Burundi as a post-conflict
country. Conditions have deteriorated since renewed
violence erupted in April 2015, causing another outpouring
of refugees. In addition to refugee out-migration, Burundi
has hosted thousands of refugees from neighboring
countries, mostly from the Democratic Republic of the
Congo and lesser numbers from Rwanda.
Age structure: 0-14 years: 43.83% (male 2,618,868/female
2,981,597) 15-24 years: 19.76% (male 1,172,858/female
1,171,966)
25-54 years: 29.18% (male 1,713,985/female 1,748,167)
55-64 years: 4.17% (male 231,088/female 264,131)
65 years and over: 3.06% (male 155,262/female 207,899)
(2020 est.)
Dependency ratios: total dependency ratio: 91
youth dependency ratio: 86.4
elderly dependency ratio: 4.5
potential support ratio: 22 (2020 est.)
Median age: total: 17.7 years
male: 17.4 years
female: 18 years (2020 est.)
country comparison to the world: 218
Population growth rate: 2.85% (2020 est.)
country comparison to the world: 11
Birth rate: 36.5 births/1,000 population (2020 est.)
country comparison to the world: 16
Death rate: 6.2 deaths/1,000 population (2020 est.)
country comparison to the world: 154
Net migration rate: -0.8 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 134
Population distribution: one of Africa’s most densely populated
countries; concentrations tend to be in the north and along
the northern shore of Lake Tanganyika in the west; most
people live on farms near areas of fertile volcanic soil
Urbanization: urban population: 13.7% of total population
(2020)
rate of urbanization: 5.68% annual rate of change (2015-20
est.)
Major urban areas—population: 1,013,000 BUJUMBURA (capital)
(2020)
Sex ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1.01 male(s)/female (2020 est.)
15-24 years: 1 male(s)/female (2020 est.)
25-54 years: 0.98 male(s)/female (2020 est.)
55-64 years: 0.87 male(s)/female (2020 est.)
65 years and over: 0.75 male(s)/female (2020 est.)
total population: 98.6 male(s)/female (2020 est.)
Mother’s mean age at first birth: 21.3 years (2010 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 548 deaths/100,000 live births (2017
est.)
country comparison to the world: 16
Infant mortality rate: total: 40.1 deaths/1,000 live births
male: 44.4 deaths/1,000 live births
female: 35.7 deaths/1,000 live births (2020 est.)
country comparison to the world: 39
Life expectancy at birth: total population: 66.7 years
male: 64.6 years
female: 68.8 years (2020 est.)
country comparison to the world: 184
Total fertility rate: 5.28 children born/woman (2020 est.)
country comparison to the world: 12
Contraceptive prevalence rate: 28.5% (2016/17)
Drinking water source:
improved:
urban: 91.1% of population
rural: 73.8% of population
total: 75.9% of population
unimproved:
urban: 8.9% of population
rural: 26.2% of population
total: 24.1% of population (2015 est.)
Current Health Expenditure: 6.2% (2016)
Physicians density: 0.05 physicians/1,000 population (2016)
Hospital bed density: 0.8 beds/1,000 population (2014)
Sanitation facility access:
improved:
urban: 43.8% of population (2015 est.)
rural: 48.6% of population (2015 est.)
total: 48% of population (2015 est.)
unimproved:
urban: 56.2% of population (2015 est.)
rural: 51.4% of population (2015 est.)
total: 52% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 1% (2018 est.)
country comparison to the world: 47
HIV/AIDS—people living with HIV/AIDS: 82,000 (2018 est.)
country comparison to the world: 48
HIV/AIDS—deaths: 1,900 (2018 est.)
country comparison to the world: 46
Major infectious diseases: degree of risk: very high (2019)
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever (2019) vectorborne
diseases: malaria and dengue fever (2019)
water contact diseases: schistosomiasis (2019)
animal contact diseases: rabies (2019)
Obesity—adult prevalence rate: 5.4% (2016)
country comparison to the world: 178
Children under the age of 5 years underweight:
29.3% (2016)
country comparison to the world: 12
Education expenditures: 4.8% of GDP (2017)
country comparison to the world: 71
Literacy: definition: age 15 and over can read and write
total population: 68.4%
male: 76.3%
female: 61.2% (2017)
School life expectancy (primary to tertiary education): total: 11
years male: 11 years
female: 11 years (2017)
Unemployment, youth ages 15-24: total: 2.9%
male: 4.4%
female: 2% (2014 est.)
country comparison to the world: 173','648410f959c6af4e50afd2ef637ac300342b36a6003c4e8494d657a241e8a03c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d4c1ef6c353ee6887f7f66809b39333d6f2a21962657460d3321585759fd55a',2020,'AQ','Antarctica','people-and-society',331,'Population: 1,394,015,977 (July 2020 est.)
country comparison to the world: 1
Nationality: Noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Han Chinese 91.6%, Zhuang 1.3%, other
(includes Hui, Manchu, Uighur, Miao, Yi, Tujia, Tibetan,
Mongol, Dong, Buyei, Yao, Bai, Korean, Hani, Li, Kazakh,
Dai, and other nationalities) 7.1% (2010 est.) note: the
Chinese Government officially recognizes 56 ethnic groups
Languages: Standard Chinese or Mandarin (official;
Putonghua, based on the Beijing dialect), Yue (Cantonese),
Wu (Shanghainese), Minbei (Fuzhou), Minnan (Hokkien-
Taiwanese), Xiang, Gan, Hakka dialects, minority languages
(see Ethnic groups entry) note: Zhuang is official in
Guangxi Zhuang, Yue is official in Guangdong, Mongolian is
official in Nei Mongol, Uighur is official in Xinjiang Uygur,
Kyrgyz is official in Xinjiang Uygur, and Tibetan is official in
Xizang (Tibet) Religions: Buddhist 18.2%, Christian 5.1%,
Muslim 1.8%, folk religion 21.9%, Hindu < 0.1%, Jewish <
0.1%, other 0.7% (includes Daoist (Taoist)), unaffiliated
592.2% (2010 est.) note: officially atheist
Age structure: 0-14 years: 17.29% (male 129,296,339/female
111,782,427) 15-24 years: 11.48% (male 86,129,841/female
73,876,148)
25-54 years: 46.81% (male 333,789,731/female
318,711,557)
95-64 years: 12.08% (male 84,827,645/female 83,557,507)
65 years and over: 12.34% (male 81,586,490/female
90,458,292) (2020 est.)
Dependency ratios: total dependency ratio: 42.2
youth dependency ratio: 25.2
elderly dependency ratio: 17
potential support ratio: 5.9 (2020 est.)
data do not include Hong Kong, Macau, and Taiwan
Median age: total: 38.4 years
male: 37.5 years
female: 39.4 years (2020 est.)
country comparison to the world: 62
Population growth rate: 0.32% (2020 est.)
country comparison to the world: 170
Birth rate: 11.6 births/1,000 population (2020 est.)
country comparison to the world: 168
Death rate: 8.2 deaths/1,000 population (2020 est.)
country comparison to the world: 85
Net migration rate: -0.4 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 123
Population distribution: Overwhelming majority of the
population is found in the eastern half of the country; the
west, with its vast mountainous and desert areas, remains
sparsely populated; though ranked first in the world in total
population, overall density is less than that of many other
countries in Asia and Europe; high population density is
found along the Yangtze and Yellow River valleys, the Xi
Jiang River delta, the Sichuan Basin (around Chengdu), in
and around Beijing, and the industrial area around
Shenyang Urbanization: urban population: 61.4% of total
population (2020)
rate of urbanization: 2.42% annual rate of change (2015-20
est.)
note: data do not include Hong Kong and Macau
Major urban areas—population: 27.058 million Shanghai, 20.463
million BEIJING (capital), 15.872 million Chongqing,
13.589 million Tianjin, 13.302 million Guangzhou, 12.357
million Shenzhen (2020) Sex ratio: at birth: 1.11
male(s)/female (2020 est.)
0-14 years: 1.16 male(s)/female (2020 est.)
15-24 years: 1.17 male(s)/female (2020 est.)
25-54 years: 1.05 male(s)/female (2020 est.)
55-64 years: 1.02 male(s)/female (2020 est.)
65 years and over: 0.9 male(s)/female (2020 est.)
total population: 105.5 male(s)/female (2020 est.)
Maternal mortality rate: 29 deaths/100,000 live births (2017
est.)
country comparison to the world: 111
Infant mortality rate: total: 11.4 deaths/1,000 live births
male: 11.9 deaths/1,000 live births
female: 10.9 deaths/1,000 live births (2020 est.)
country comparison to the world: 115
Life expectancy at birth: total population: 76.1 years
male: 74 years
female: 78.4 years (2020 est.)
country comparison to the world: 104
Total fertility rate: 1.6 children born/woman (2020 est.)
country comparison to the world: 184
Contraceptive prevalence rate: 84.5% (2017)
Drinking water source:
improved:
urban: 97.5% of population
rural: 93% of population
total: 95.5% of population
unimproved:
urban: 2.5% of population
rural: 7% of population
total: 4.5% of population (2015 est.)
Current Health Expenditure: 5% (2016)
Physicians density: 1.79 physicians/1,000 population (2015)
Hospital bed density: 4.2 beds/1,000 population (2012)
Sanitation facility access:
improved:
urban: 86.6% of population (2015 est.)
rural: 63.7% of population (2015 est.)
total: 76.5% of population (2015 est.)
unimproved:
urban: 13.4% of population (2015 est.)
rural: 36.3% of population (2015 est.)
total: 23.5% of population (2015 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Major infectious diseases: degree of risk: intermediate (2016)
food or waterborne diseases: bacterial diarrhea, hepatitis
A, and typhoid fever (2016)
vectorborne diseases: Japanese encephalitis (2016)
soil contact diseases: hantaviral hemorrhagic fever with
renal syndrome (HFRS) (2016)
Obesity—adult prevalence rate: 6.2% (2016)
country comparison to the world: 169
Children under the age of 5 years underweight:
2.4% (2013)
country comparison to the world: 108
Education expenditures: NA
Literacy: definition: age 15 and over can read and write
total population: 96.8%
male: 98.5%
female: 95.2% (2018)
School life expectancy (primary to tertiary education): total: 14
years male: 14 years
female: 14 years (2015)
People—note: in October 2015, the Chinese Government
announced that it would change its rules to allow all
couples to have two children, loosening a 1979 mandate
that restricted many couples to one child; the new policy
was implemented on 1 January 2016 to address China’s
rapidly aging population and economic needs','3e83a62dc2adc014534b7c7bd144152b974906f45772a6d9baf3447269d2acba','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ed41e7e092163cf5a87360e73c065fe0960091cfdb03a85288df297620c2c16',2020,'BR','Brazil','people-and-society',355,'Population: 846,281 (July 2020 est.)
country comparison to the world: 163
Nationality: 20uUn: Comoran(s)
adjective: Comoran
Ethnic groups: Antalote, Cafre, Makoa, Oimatsaha, Sakalava
Languages: Arabic (official), French (official), Shikomoro
(official; a blend of Swahili and Arabic) (Comorian) Religions:
Sunni Muslim 98%, other (including Shia Muslim, Roman
Catholic, Jehovah’s Witness, Protestant) 2%
note: Sunni Islam is the state religion
Demographic profile: Comoros’ population is a melange of
Arabs, Persians, Indonesians, Africans, and Indians, and the
much smaller number of Europeans that settled on the
islands between the 8th and 19th centuries, when they
served as a regional trade hub. The Arab and Persian
influence is most evident in the islands’ overwhelmingly
Muslim majority—about 98% of Comorans are Sunni
Muslims. The country is densely populated, averaging
nearly 350 people per square mile, although this varies
widely among the islands, with Anjouan being the most
densely populated.
Given the large share of land dedicated to agriculture
and Comoros’ growing population, habitable land is
becoming increasingly crowded. The combination of
increasing population pressure on limited land and
resources, widespread poverty, and poor job prospects
motivates thousands of Comorans each year to attempt to
illegally migrate using small fishing boats to the
neighboring island of Mayotte, which is a French territory.
The majority of legal Comoran migration to France came
after Comoros’ independence from France in 1975, with
the flow peaking in the mid-1980s.
At least 150,000 to 200,000 people of Comoran
citizenship or descent live abroad, mainly in France, where
they have gone seeking a better quality of life, job
opportunities, higher education (Comoros has_ no
universities), advanced health care, and to finance
elaborate traditional wedding ceremonies (aada).
Remittances from the diaspora are an economic mainstay,
in 2013 representing approximately 25% of Comoros’ GDP
and significantly more than the value of its exports of goods
and services (only 15% of GDP). Grand Comore, Comoros’
most populous island, is both the primary source of
emigrants and the main recipient of remittances. Most
remittances are spent on private consumption, but this
often goes toward luxury goods and the aada and does not
contribute to economic development or poverty reduction.
Although the majority of the diaspora is now French-born
with more distant ties to Comoros, it is unclear whether
they will sustain the current level of remittances.
Age structure: 0-14 years: 36.68% (male 154,853/female
155,602) 15-24 years: 20.75% (male 85,208/female 90,422)
25-54 years: 33.99% (male 136,484/female 151,178)
595-64 years: 4.49% (male 17,237/female 20,781)
65 years and over: 4.08% (male 15,437/female 19,079)
(2020 est.)
Dependency ratios: total dependency ratio: 75.5 (2015 est.)
youth dependency ratio: 70.5 (2015 est.)
elderly dependency ratio: 5.1 (2015 est.)
potential support ratio: 19.7 (2015 est.)
Median age: total: 20.9 years
male: 20.2 years
female: 21.5 years (2020 est.)
country comparison to the world: 189
Population growth rate: 1.47% (2020 est.)
country comparison to the world: 73
Birth rate: 23.6 births/1,000 population (2020 est.)
country comparison to the world: 52
Death rate: 6.9 deaths/1,000 population (2020 est.)
country comparison to the world: 130
Net migration rate: -2.3 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 169
Population distribution: the capital city of Maroni, located on
the western side of the island of Grande Comore, is the
country’s largest city; however, of the three islands that
comprise Comoros, it is Anjouan that is the most densely
populated Urbanization: urban population: 29.4% of total
population (2020) rate of urbanization: 2.87% annual rate
of change (2015-20 est.)
Major urban areas—population: 62,000 MORONI (capital) (2018)
Sex ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1 male(s)/female (2020 est.)
15-24 years: 0.94 male(s)/female (2020 est.)
25-54 years: 0.9 male(s)/female (2020 est.)
55-64 years: 0.83 male(s)/female (2020 est.)
65 years and over: 0.81 male(s)/female (2020 est.)
total population: 93.6 male(s)/female (2020 est.)
Mother’s mean age at first birth: 24.6 years (2012 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 273 deaths/100,000 live births (2017
est.)
country comparison to the world: 40
Infant mortality rate: total: 55 deaths/1,000 live births male:
64.8 deaths/1,000 live births
female: 45.1 deaths/1,000 live births (2020 est.)
country comparison to the world: 17
Life expectancy at birth: total population: 65.7 years male: 63.3
years
female: 68.1 years (2020 est.)
country comparison to the world: 191
Total fertility rate: 2.95 children born/woman (2020 est.)
country comparison to the world: 53
Contraceptive prevalence rate: 19.4% (2012)
Drinking water source:
improved:
urban: 92.6% of population
rural: 89.1% of population
total: 90.1% of population
unimproved:
urban: 7.4% of population
rural: 10.9% of population
total: 9.9% of population (2015 est.)
Current Health Expenditure: 7.6% (2016)
Physicians density: 0.17 physicians/1,000 population (2012)
Hospital bed density: 2.2 beds/1,000 population (2010)
Sanitation facility access:
improved:
urban: 48.3% of population (2015 est.)
rural: 30.9% of population (2015 est.)
total: 35.8% of population (2015 est.)
unimproved:
urban: 51.7% of population (2015 est.)
rural: 69.1% of population (2015 est.)
total: 64.2% of population (2015 est.)
HIV/AIDS—adult prevalence rate: <.1% (2018 est.)
HIV/AIDS—people living with HIV/AIDS: <200 (2018 est.)
HIV/AIDS—deaths: <100 (2018 est.)
Obesity—adult prevalence rate: 7.8% (2016)
country comparison to the world: 157
Children under the age of 5 years underweight:
16.9% (2012)
country comparison to the world: 35
Education expenditures: 2.5% of GDP (2015)
country comparison to the world: 160
Literacy: definition: age 15 and over can read and write total
population: 58.8%
male: 64.6%
female: 53% (2018)
School life expectancy (primary to tertiary education): total: 11
years male: 11 years
female: 11 years (2014)
Population: uninhabited','438e9df80c7a082d0e1bc2e5e123c1be8b8f38c3af09163891b720bb3f7a9da8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c086d570ad6ee427836765c02d2017c69ccc5e43bf22991b01676979e3c2fe4',2020,'AO','Angola','people-and-society',358,'Population: 101,780,263 (July 2020 est.)
note: estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can result
in lower life expectancy, higher infant mortality, higher
death rates, lower population growth rates, and changes in
the distribution of population by age and sex than would
otherwise be expected country comparison to the world: 15
Nationality: Noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: more than 200 African ethnic groups of which
the majority are Bantu; the four largest tribes—Mongo,
Luba, Kongo (all Bantu), and the Mangbetu-Azande
(Hamitic)—make up about 45% of the population Languages:
French (official), Lingala (a lingua franca trade language),
Kingwana (a dialect of Kiswahili or Swahili), Kikongo,
Tshiluba Religions: Roman Catholic 29.9%, Protestant 26.7%,
Kimbanguist 2.8%, other Christian 36.5%, Muslim 1.3%,
other (includes syncretic sects and indigenous beliefs)
1.2%, none 1.3%, unspecified.2% (2014 est.) Demographic
profile: Despite a wealth of fertile soil, hydroelectric power
potential, and mineral resources, the Democratic Republic
of the Congo (DRC) struggles with many socioeconomic
problems, including high infant and maternal mortality
rates, malnutrition, poor vaccination coverage, lack of
access to improved water sources and sanitation, and
frequent and_- early _ fertility. Ongoing _ conflict,
mismanagement of resources, and a lack of investment
have resulted in food insecurity; almost 30 percent of
children under the age of 5 are malnourished. The overall
coverage of basic public services—education, health,
sanitation, and potable water—is very limited and
piecemeal, with substantial regional and _ rural/urban
disparities. Fertility remains high at almost 5 children per
woman and is likely to remain high because of the low use
of contraception and the cultural preference for larger
families.
The DRC is a source and host country for refugees.
Between 2012 and 2014, more than 119,000 Congolese
refugees returned from the Republic of Congo to the
relative stability of northwest DRC, but more than 540,000
Congolese refugees remained abroad as of year-end 2015.
In addition, an estimated 3.9 million Congolese were
internally displaced as of October 2017, the vast majority
fleeing violence between rebel group and Congolese armed
forces. Thousands of refugees have come to the DRC from
neighboring countries, including Rwanda, the Central
African Republic, and Burundi.
Age structure: 0-14 years: 46.38% (male 23,757,297/female
23,449,057) 15-24 years: 19.42% (male 9,908,686/female
9,856,841)
25-54 years: 28.38% (male 14,459,453/female 14,422,912)
595-64 years: 3.36% (male 1,647,267/female 1,769,429)
65 years and over: 2.47% (male 1,085,539/female
1,423,782) (2020 est.)
Dependency ratios: total dependency ratio: 97.5 (2015 est.)
youth dependency ratio: 91.5 (2015 est.)
elderly dependency ratio: 6 (2015 est.)
potential support ratio: 16.8 (2015 est.)
Median age: total: 16.7 years
male: 16.5 years
female: 16.8 years (2020 est.)
country comparison to the world: 223
Population growth rate: 3.18% (2020 est.)
country comparison to the world: 8
Birth rate: 41 births/1,000 population (2020 est.)
country comparison to the world: 7
Death rate: 8.4 deaths/1,000 population (2020 est.)
country comparison to the world: 76
Net migration rate: -0.9 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 138
Population distribution: urban clusters are spread throughout
the country, particularly in the northeast along the boarder
with Uganda, Rwanda, and Burundi; the largest city is the
capital, Kinshasha, located in the west along the Congo
River; the south is least densely populated Urbanization:
urban population: 45.6% of total population (2020) rate of
urbanization: 4.53% annual rate of change (2015-20 est.)
Major urban areas-population:
14.342 million KINSHASA (capital), 2.525 million Mbuji-
Mayi, 2.478 million Lubumbashi, 1.458 million Kananga,
1.261 million Kisangani, 1.078 million Bukavu (2020) Sex
ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1.01 male(s)/female (2020 est.)
15-24 years: 1.01 male(s)/female (2020 est.)
25-54 years: 1 male(s)/female (2020 est.)
55-64 years: 0.93 male(s)/female (2020 est.)
65 years and over: 0.76 male(s)/female (2020 est.)
total population: 99.9 male(s)/female (2020 est.)
Mother’s mean age at first birth: 19.9 years (2013/14 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 473 deaths/100,000 live births (2017
est.)
country comparison to the world: 23
Infant mortality rate: total: 64.5 deaths/1,000 live births male:
70.3 deaths/1,000 live births
female: 58.4 deaths/1,000 live births (2020 est.)
country comparison to the world: 8
Life expectancy at birth: total population: 61 years
male: 59.3 years
female: 62.8 years (2020 est.)
country comparison to the world: 216
Total fertility rate: 5.77 children born/woman (2020 est.)
country comparison to the world: 3
Contraceptive prevalence rate: 20.4% (2013/14)
Drinking water source:
improved:
urban: 81.1% of population
rural: 31.2% of population
total: 52.4% of population
unimproved:
urban: 18.9% of population
rural: 68.8% of population
total: 47.6% of population (2015 est.)
Current Health Expenditure: 3.9% (2016)
Physicians density: 0.09 physicians/1,000 population (2013)
Sanitation facility access:
improved:
urban: 28.5% of population (2015 est.)
rural: 28.7% of population (2015 est.)
total: 28.7% of population (2015 est.)
unimproved:
urban: 71.5% of population (2015 est.)
rural: 71.3% of population (2015 est.)
total: 71.3% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.8% (2018 est.)
country comparison to the world: 54
HIV/AIDS—people living with HIV/AIDS: 450,000 (2018 est.)
country comparison to the world: 18
HIV/AIDS—deaths: 13,000 (2018 est.)
country comparison to the world: 17
Major infectious diseases: degree of risk: very high (2016) food
or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever (2016) vectorborne diseases:
malaria, dengue fever, and trypanosomiasis-gambiense
(African sleeping sickness) (2016) water contact diseases:
schistosomiasis (2016)
animal contact diseases: rabies (2016)
note: On 18 October 2019, the Centers for Disease Control
and Prevention issued a Travel Health Notice for an Ebola
outbreak in the South Kivu (Kivu Sud), North Kivu (Kivu
Nord), and Ituri provinces in the northeastern part of the
Democratic Republic of the Congo; travelers to this area
could be infected with Ebola if they come into contact with
an infected person’s blood or other body fluids; travelers
should seek medical care immediately if they develop fever,
muscle pain, sore throat, diarrhea, weakness, vomiting,
stomach pain, or unexplained bleeding or bruising during
or after travel Obesity—adult prevalence rate: 6.7% (2016)
country comparison to the world: 164
Children under the age of 5 years underweight:
23.4% (2013)
country comparison to the world: 23
Education expenditures: 1.5% of GDP (2017)
country comparison to the world: 172
Literacy: definition: age 15 and over can read and write
French, Lingala, Kingwana, or Tshiluba total population:
77%
male: 88.5%
female: 66.5% (2016)
School life expectancy (primary to tertiary education): total: 10
years male: 11 years
female: 9 years (2013)
Unemployment, youth ages 15-24: total: 8.7%
male: 11.3%
female: 6.8% (2012 est.)
country comparison to the world: 137','0dfeaf387c449f63f93a2f2aa8617773efdaa6150005feffb592b78b8b0620f6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d218008817e36cab95dad1b179a63fcff78d0397f5fe9c903931a49c87be211f',2020,'NI','Nicaragua','people-and-society',372,'Population: 5,097,988 (July 2020 est.)
country comparison to the world: 123
Nationality: 20un: Costa Rican(s)
adjective: Costa Rican
Ethnic groups: white or mestizo 83.6%, mulatto 6.7%,
indigenous 2.4%, black of African descent 1.1%, other
1.1%, none 2.9%, unspecified 2.2% (2011 est.) Languages:
Spanish (official), English
Religions: Roman Catholic 71.8%, Evangelical and
Pentecostal 12.3%, other Protestant 2.6%, Jehovah’s
Witness 0.5%, other 2.4%, none 10.4% (2016 est.)
Demographic profile: Costa Rica’s political stability, high
standard of living, and well-developed social benefits
system set it apart from its Central American neighbors.
Through the government’s sustained social spending—
almost 20% of GDP annually—Costa Rica has made
tremendous progress toward achieving its goal of providing
universal access to education, healthcare, clean water,
sanitation, and electricity. Since the 1970s, expansion of
these services has led to a rapid decline in infant mortality,
an increase in life expectancy at birth, and a sharp
decrease in the birth rate. The average number of children
born per women has fallen from about 7 in the 1960s to 3.5
in the early 1980s to below replacement level today. Costa
Rica’s poverty rate is lower than in most Latin American
countries, but it has stalled at around 20% for almost two
decades.
Costa Rica is a popular regional immigration destination
because of its job opportunities and social programs.
Almost 9% of the population is foreign-born, with
Nicaraguans comprising nearly three-quarters of the
foreign population. Many Nicaraguans who perform
unskilled seasonal labor enter Costa Rica illegally or
overstay their visas, which continues to be a source of
tension. Less than 3% of Costa Rica’s population lives
abroad. The overwhelming majority of expatriates have
settled in the United States after completing a university
degree or in order to work in a highly skilled field.
Age structure: 0-14 years: 22.08% (male 575,731/female
549,802) 15-24 years: 15.19% (male 395,202/female
3/9277)
25-54 years: 43.98% (male 1,130,387/female 1,111,791)
55-64 years: 9.99% (male 247,267/female 261,847)
65 years and over: 8.76% (male 205,463/female 241,221)
(2020 est.)
Dependency ratios: total dependency ratio: 45.4 (2015 est.)
youth dependency ratio: 32.4 (2015 est.)
elderly dependency ratio: 12.9 (2015 est.)
potential support ratio: 7.7 (2015 est.)
Median age: total: 32.6 years
male: 32.1 years
female: 33.1 years (2020 est.)
country comparison to the world: 109
Population growth rate: 1.08% (2020 est.)
country comparison to the world: 99
Birth rate: 14.8 births/1,000 population (2020 est.)
country comparison to the world: 122
Death rate: 4.9 deaths/1,000 population (2020 est.)
country comparison to the world: 198
Net migration rate: 0.8 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 63
Population distribution: roughly half of the nation’s population
resides in urban areas; the capital of San Jose is the largest
city and home to approximately one-fifth of the population
Urbanization: urban population: 80.8% of total population
(2020) rate of urbanization: 1.5% annual rate of change
(2015-20 est.)
Major urban areas—population: 1.400 million SAN JOSE (capital)
(2020)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.04 male(s)/female (2020 est.)
25-54 years: 1.02 male(s)/female (2020 est.)
55-64 years: 0.94 male(s)/female (2020 est.)
65 years and over: 0.85 male(s)/female (2020 est.)
total population: 100.4 male(s)/female (2020 est.)
Maternal mortality rate: 27 deaths/100,000 live births (2017
est.)
country comparison to the world: 116
Infant mortality rate: total: 7.5 deaths/1,000 live births
male: 8.2 deaths/1,000 live births
female: 6.7 deaths/1,000 live births (2020 est.)
country comparison to the world: 153
Life expectancy at birth: total population: 79.2 years
male: 76.5 years
female: 82 years (2020 est.)
country comparison to the world: 58
Total fertility rate: 1.87 children born/woman (2020 est.)
country comparison to the world: 136
Contraceptive prevalence rate: 77.8% (2015)
Drinking water source:
improved:
urban: 99.6% of population
rural: 91.9% of population
total: 97.8% of population
unimproved:
urban: 0.4% of population
rural: 8.1% of population
total: 2.2% of population (2015 est.)
Current Health Expenditure: 7.6% (2016)
Physicians density: 1.15 physicians/1,000 population (2013)
Hospital bed density: 1.1 beds/1,000 population (2014)
Sanitation facility access:
improved:
urban: 95.2% of population (2015 est.)
rural: 92.3% of population (2015 est.)
total: 94.5% of population (2015 est.)
unimproved:
urban: 4.8% of population (2015 est.)
rural: 7.7% of population (2015 est.)
total: 5.5% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.4% (2018 est.)
country comparison to the world: 76
HIV/AIDS—people living with HIV/AIDS: 15,000 (2018 est.)
country comparison to the world: 90
HIV/AIDS—deaths: <500 (2018 est.)
Major infectious diseases: degree of risk: intermediate (2016)
food or waterborne diseases: bacterial diarrhea (2016)
vectorborne diseases: dengue fever (2016)
note: active local transmission of Zika virus by Aedes
species mosquitoes has been identified in this country (as
of August 2016); it poses an important risk (a large number
of cases possible) among US citizens if bitten by an
infective mosquito; other less common ways to get Zika are
through sex, via blood transfusion, or during pregnancy, in
which the pregnant woman passes Zika virus to her fetus
Obesity—adult prevalence rate: 25.7% (2016)
country comparison to the world: 48
Children under the age of 5 years underweight:
Education expenditures: 7.4% of GDP (2017)
country comparison to the world: 10
Literacy: definition: age 15 and over can read and write
total population: 97.9%
male: 97.8%
female: 97.9% (2018)
School life expectancy (primary to tertiary education): total: 15
years male: 15 years
female: 16 years (2016)
Unemployment, youth ages 15-24: total: 20.6%
male: 17.6%
female: 25.9% (2017 est.)
country comparison to the world: 65','2429ed2f4f041b69c0960d1cc206a12d2d6bb5336094b384903843ce71216bbc','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6c0874c44b5b8d48be76096786277519198d390c6377b88440c340a8eefe8a1',2020,'CO','Colombia','people-and-society',438,'Population: 16,904,867 (July 2020 est.)
country comparison to the world: 70
Nationality: N0un: Ecuadorian(s)
adjective: Ecuadorian
Ethnic groups: Mestizo (mixed Amerindian and white) 71.9%,
Montubio 7A%, Amerindian 7%, white 6.1%,
Afroecuadorian 4.3%, mulatto 1.9%, black 1%, other 0.4%
(2010 est.) Languages: Spanish (Castilian) 93% (official),
Quechua 4.1%, other indigenous 0.7%, foreign 2.2% (2010
est.) note: (Quechua and Shuar are official languages of
intercultural relations; other indigenous languages are in
official use by indigenous peoples in the areas they inhabit)
Religions: Roman Catholic 74%, Evangelical 10.4%,
Jehovah’s Witness 1.2%, other 6.4% (includes Mormon,
Buddhist, Jewish, Spiritualist, Muslim, Hindu, indigenous,
African American, Pentecostal), atheist 7.9%, agnostic 0.1%
(2012 est.) note: data represent persons at least 16 years of
age from five Ecuadoran cities
Demographic profile: Ecuador’s high poverty and income
inequality most affect indigenous, mixed race, and rural
populations. ,The government has increased its social
spending to ameliorate these problems, but critics question
the efficiency and implementation of its _ national
development plan. Nevertheless, the conditional cash
transfer program, which requires participants’ children to
attend school and have medical check-ups, has helped
improve educational attainment and healthcare among
poor children. Ecuador is stalled at above replacement
level fertility and the population most likely will keep
growing rather than stabilize.
An estimated 2 to 3 million Ecuadorians live abroad, but
increased unemployment in key receiving countries—Spain,
the United States, and Italy—is slowing emigration and
increasing the likelihood of returnees to Ecuador. The first
large-scale emigration of Ecuadorians occurred between
1980 and 2000, when an economic crisis drove
Ecuadorians from southern provinces to New York City,
where they had trade contacts. A second, nationwide wave
of emigration in the late 1990s was caused by another
economic downturn, political instability, and a currency
crisis. Spain was the logical destination because of its
shared language and the wide availability of low-skilled,
informal jobs at a time when increased border surveillance
made illegal migration to the US difficult. Ecuador has a
small but growing immigrant population and is Latin
America’s top recipient of refugees; 98% are neighboring
Colombians fleeing violence in their country.
Age structure: 0-14 years: 25.82% (male 2,226,240/female
2,138,219)
15-24 years: 17.8% (male 1,531,545/female 1,478,222)
25-54 years: 40.31% (male 3,333,650/female 3,480,262)
55-64 years: 7.92% (male 647,718/female 691,759)
65 years and over: 8.15% (male 648,761/female 728,491)
(2020 est.)
Dependency ratios: total dependency ratio: 55.6 (2015 est.)
youth dependency ratio: 45.1 (2015 est.)
elderly dependency ratio: 10.4 (2015 est.)
potential support ratio: 9.6 (2015 est.)
Median age: total: 28.8 years
male: 28 years
female: 29.6 years (2020 est.)
country comparison to the world: 140
Population growth rate: 1.2% (2020 est.)
country comparison to the world: 89
Birth rate: 17 births/1,000 population (2020 est.)
country comparison to the world: 100
Death rate: 5.2 deaths/1,000 population (2020 est.)
country comparison to the world: 194
Net migration rate: 0 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 80
Population distribution: nearly half of the population is
concentrated in the interior in the Andean intermontane
basins and valleys, with large concentrations also found
along the western coastal strip; the rainforests of the east
remain sparsely populated Urbanization: urban population:
64.2% of total population (2020)
rate of urbanization: 1.66% annual rate of change (2015-20
est.)
Major urban areas—population: 2.994 million Guayaquil, 1.874
million QUITO (capital) (2020)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.04 male(s)/female (2020 est.)
15-24 years: 1.04 male(s)/female (2020 est.)
25-54 years: 0.96 male(s)/female (2020 est.)
55-64 years: 0.94 male(s)/female (2020 est.)
65 years and over: 0.89 male(s)/female (2020 est.)
total population: 98.5 male(s)/female (2020 est.)
Maternal mortality rate: 59 deaths/100,000 live births (2017
est.)
country comparison to the world: 90
Infant mortality rate: total: 15 deaths/1,000 live births
male: 17.8 deaths/1,000 live births
female: 12 deaths/1,000 live births (2020 est.)
country comparison to the world: 97
Life expectancy at birth: total population: 77.5 years
male: 74.5 years
female: 80.6 years (2020 est.)
country comparison to the world: 80
Total fertility rate: 2.09 children born/woman (2020 est.)
country comparison to the world: 99
Contraceptive prevalence rate: 80.1% (2007/12)
Drinking water source:
improved:
urban: 93.4% of population
rural: 75.5% of population
total: 86.9% of population
unimproved:
urban: 6.6% of population
rural: 24.5% of population
total: 13.1% of population (2015 est.)
Current Health Expenditure: 8.4% (2016)
Physicians density: 2.05 physicians/1,000 population (2016)
Hospital bed density: 1.5 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 87% of population (2015 est.)
rural: 80.7% of population (2015 est.)
total: 84.7% of population (2015 est.)
unimproved:
urban: 13% of population (2015 est.)
rural: 19.3% of population (2015 est.)
total: 15.3% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.4% (2018 est.)
country comparison to the world: 78
HIV/AIDS—people living with HIV/AIDS: 44,000 (2018 est.)
country comparison to the world: 63
HIV/AIDS—deaths: <1000 (2018 est.)
Major infectious diseases: degree of risk: high (2016)
food or waterborne diseases: bacterial diarrhea, hepatitis
A, and typhoid fever (2016)
vectorborne diseases: dengue fever and malaria (2016)
note: active local transmission of Zika virus by Aedes
species mosquitoes has been identified in this country (as
of August 2016); it poses an important risk (a large number
of cases possible) among US citizens if bitten by an
infective mosquito; other less common ways to get Zika are
through sex, via blood transfusion, or during pregnancy, in
which the pregnant woman passes Zika virus to her fetus
Obesity—adult prevalence rate: 19.9% (2016)
country comparison to the world: 107
Children under the age of 5 years underweight:
5.1% (2014)
country comparison to the world: 81
Education expenditures: 5% of GDP (2015)
country comparison to the world: 62
Literacy: definition: age 15 and over can read and write
total population: 92.8%
male: 93.8%
female: 92.1% (2017)
School life expectancy (primary to tertiary education): total: 16
years male: 15 years
female: 16 years (2015)
Unemployment, youth ages 15-24: total: 7.9%
male: 6.4%
female: 10.6% (2018 est.)
country comparison to the world: 145
Population: 104,124,440 (July 2020 est.)
country comparison to the world: 14
Nationality: noun: Egyptian(s)
adjective: Egyptian
Ethnic groups: Egyptian 99.7%, other 0.3% (2006 est.)
note: data represent respondents by nationality
Languages: Arabic (official), Arabic, English, and French
widely understood by educated classes Religions: Muslim
(predominantly Sunni) 90%, Christian (majority Coptic
Orthodox, other Christians include Armenian Apostolic,
Catholic, Maronite, Orthodox, and Anglican) 10% (2015
est.) Demographic profile: Egypt is the most populous country
in the Arab world and the third most populous country in
Africa, behind Nigeria and Ethiopia. Most of the country is
desert, so about 95% of the population is concentrated in a
narrow strip of fertile land along the Nile River, which
represents only about 5% of Egypt’s land area. Egypt’s
rapid population growth—46% between 1994 and 2014—
stresses limited natural resources, jobs, housing,
sanitation, education, and health care.
Although the country’s total fertility rate (TFR) fell from
roughly 5.5 children per woman in 1980 to just over 3 in
the late 1990s, largely as a result of state-sponsored family
planning programs, the population growth rate dropped
more modestly because of decreased mortality rates and
longer life expectancies. During the last decade, Egypt’s
TFR decline stalled for several years and then reversed,
reaching 3.6 in 2011, and has plateaued the last few years.
Contraceptive use has held steady at about 60%, while
preferences for larger families and early marriage may
have strengthened in the wake of the recent 2011
revolution. The large cohort of women of or nearing
childbearing age will sustain high population growth for
the foreseeable future (an effect called population
momentum).
Nevertheless, post-MUBARAK governments have not
made curbing population growth a priority. To increase
contraceptive use and to prevent further overpopulation
will require greater government commitment and
substantial social change, including encouraging smaller
families and better educating and empowering women.
Currently, literacy, educational attainment, and labor force
participation rates are much lower for women than men. In
addition, the prevalence of violence against women, the
lack of female political representation, and _ the
perpetuation of the nearly universal practice of female
genital cutting continue to keep women from playing a
more significant role in Egypt’s public sphere.
Population pressure, poverty, high unemployment, and
the fragmentation of inherited land holdings have
historically motivated Egyptians, primarily young men, to
migrate internally from rural and smaller urban areas in
the Nile Delta region and the poorer rural south to Cairo,
Alexandria, and other urban centers in the north, while a
much smaller number migrated to the Red Sea and Sinai
areas. Waves of forced internal migration also resulted
from the 1967 Arab-Israeli War and the floods caused by
the completion of the Aswan High Dam in 1970. Limited
numbers of students and_ professionals emigrated
temporarily prior to the early 1970s, when economic
problems and high unemployment pushed the Egyptian
Government to lift restrictions on labor migration. At the
same time, high oil revenues enabled Saudi Arabia, Iraq,
and other Gulf states, as well as Libya and Jordan, to fund
development projects, creating a demand for unskilled
labor (mainly in construction), which attracted tens of
thousands of young Egyptian men.
Between 1970 and 1974 alone, Egyptian migrants in the
Gulf countries increased from approximately 70,000 to
370,000. Egyptian officials encouraged legal labor
migration both to alleviate unemployment and to generate
remittance income (remittances continue to be one of
Egypt’s largest sources of foreign currency and GDP).
During the mid-1980s, however, depressed oil prices
resulting from the Iran-Iraq War, decreased demand for
low-skilled labor, competition from less costly South Asian
workers, and efforts to replace foreign workers with locals
significantly reduced Egyptian migration to the Gulf States.
The number of Egyptian migrants dropped from a peak of
almost 3.3 million in 1983 to about 2.2 million at the start
of the 1990s, but numbers gradually recovered.
In the 2000s, Egypt began facilitating more labor
migration through bilateral agreements, notably with Arab
countries and Italy, but illegal migration to Europe through
overstayed visas or maritime human smuggling via Libya
also rose. The Egyptian Government estimated there were
6.5 million Egyptian migrants in 2009, with roughly 75%
being temporary migrants in other Arab countries (Libya,
Saudi Arabia, Jordan, Kuwait, and the United Arab
Emirates) and 25% being predominantly permanent
migrants in the West (US, UK, Italy, France, and Canada).
During the 2000s, Egypt became an _ increasingly
important transit and destination country for economic
migrants and asylum seekers, including Palestinians, East
Africans, and South Asians and, more recently, Iragis and
Syrians. Egypt draws many refugees because of its
resettlement programs with the West; Cairo has one of the
largest urban refugee populations in the world. Many East
African migrants are interned or live in temporary
encampments along the Egypt- Israel border, and some
have been shot and killed by Egyptian border guards.
Age structure: 0-14 years: 33.62% (male 18,112,550/female
16,889,155) 15-24 years: 18.01% (male 9,684,437/female
9,071,163)
25-54 years: 37.85% (male 20,032,310/female 19,376,847)
595-64 years: 6.08% (male 3,160,438/female 3,172,544)
65 years and over: 4.44% (male 2,213,539/female
2,411,457) (2020 est.)
Dependency ratios: total dependency ratio: 61.8 (2015 est.)
youth dependency ratio: 53.6 (2015 est.)
elderly dependency ratio: 8.2 (2015 est.)
potential support ratio: 12.2 (2015 est.)
Median age: total: 24.1 years
male: 23.8 years
female: 24.5 years (2020 est.)
country comparison to the world: 166
Population growth rate: 2.28% (2020 est.)
country comparison to the world: 31
Birth rate: 27.2 births/1,000 population (2020 est.)
country comparison to the world: 42
Death rate: 4.4 deaths/1,000 population (2020 est.)
country comparison to the world: 209
Net migration rate: -0.3 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 117
Population distribution: approximately 95% of the population
lives within 20 km of the Nile River and its delta; vast areas
of the country remain sparsely populated or uninhabited
Urbanization: urban population: 42.8% of total population
(2020)
rate of urbanization: 1.86% annual rate of change (2015-20
est.)
Major urban areas—population: 20.901 million CAIRO (capital),
5.281 million Alexandria (2020) Sex ratio: at birth: 1.06
male(s)/female (2020 est.)
0-14 years: 1.07 male(s)/female (2020 est.)
15-24 years: 1.07 male(s)/female (2020 est.)
25-54 years: 1.03 male(s)/female (2020 est.)
595-64 years: 1 male(s)/female (2020 est.)
65 years and over: 0.92 male(s)/female (2020 est.)
total population: 104.5 male(s)/female (2020 est.)
Mother’s mean age at first birth: 22.7 years (2014 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 37 deaths/100,000 live births (2017
est.)
country comparison to the world: 102
Infant mortality rate: total: 17.1 deaths/1,000 live births
male: 18.2 deaths/1,000 live births
female: 15.8 deaths/1,000 live births (2020 est.)
country comparison to the world: 87
Life expectancy at birth: total population: 73.7 years
male: 72.3 years
female: 75.3 years (2020 est.)
country comparison to the world: 140
Total fertility rate: 3.29 children born/woman (2020 est.)
country comparison to the world: 45
Contraceptive prevalence rate: 58.5% (2014)
Drinking water source:
improved:
urban: 100% of population
rural: 99% of population
total: 99.4% of population
unimproved:
urban: 0% of population
rural: 1% of population
total: 0.6% of population (2015 est.)
Current Health Expenditure: 4.6% (2016)
Physicians density: 0.79 physicians/1,000 population (2017)
Hospital bed density: 1.6 beds/1,000 population (2014)
Sanitation facility access:
improved:
urban: 96.8% of population (2015 est.)
rural: 93.1% of population (2015 est.)
total: 94.7% of population (2015 est.)
unimproved:
urban: 3.2% of population (2015 est.)
rural: 6.9% of population (2015 est.)
total: 5.3% of population (2015 est.)
HIV/AIDS—adult prevalence rate: <.1% (2018 est.)
HIV/AIDS—people living with HIV/AIDS: 22,000 (2018 est.)
country comparison to the world: 83
HIV/AIDS—deaths: <500 (2018 est.)
Major infectious diseases: degree of risk: intermediate (2016)
food or waterborne diseases: bacterial diarrhea, hepatitis
A, and typhoid fever (2016)
water contact diseases: schistosomiasis (2016)
Obesity—adult prevalence rate: 32% (2016)
country comparison to the world: 18
Children under the age of 5 years underweight:
7% (2014)
country comparison to the world: 74
Education expenditures: NA
Literacy: definition: age 15 and over can read and write
total population: 71.2%
male: 76.5%
female: 65.5% (2017)
School life expectancy (primary to tertiary education): total: 13
years male: 13 years
female: 13 years (2016)
Unemployment, youth ages 15-24: total: 29.6%
male: 25.7%
female: 38.3% (2017 est.)
country comparison to the world: 33','fc2ad1189c979ce711218639f4ad19327088bfbc50532fccc6d02d6ac454ead0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8947adb759bfee9e91addace3df6ccd9402fcec67e15caa9f762c98d272fcc2e',2020,'GN','Guinea','people-and-society',469,'Population: 6,081,196 (July 2020 est.)
country comparison to the world: 112
Nationality: N0un: Eritrean(s)
adjective: Eritrean
Ethnic groups: Tigrinya 55%, Tigre 30%, Saho 4%, Kunama
2%, Rashaida 2%, Bilen 2%, other (Afar, Beni Amir, Nera)
5% (2010 est.) note: data represent Eritrea’s nine
recognized ethnic groups
Languages: Tigrinya (official), Arabic (official), English
(official), Tigre, Kunama, Afar, other Cushitic languages
Religions: Sunni Muslim, Coptic Christian, Roman Catholic,
Protestant
Demographic profile: Eritrea is a persistently poor country that
has made progress in some socioeconomic categories but
not in others. Education and human capital formation are
national priorities for facilitating economic development
and eradicating poverty. To this end, Eritrea has made
great strides in improving adult literacy—doubling the
literacy rate over the last 20 years—in large part because
of its successful adult education programs. The overall
literacy rate was estimated to be almost 74% in 2015; more
work needs to be done to raise female literacy and school
attendance among nomadic and rural communities.
Subsistence farming fails to meet the needs of Eritrea’s
growing population because of repeated droughts,
dwindling arable land, overgrazing, soil erosion, and a
shortage of farmers due to conscription and displacement.
The government’s emphasis on spending on defense over
agriculture and its lack of foreign exchange to import food
also contribute to food insecurity.
Eritrea has been a leading refugee source country since
at least the 1960s, when its 30-year war for independence
from Ethiopia began. Since gaining independence in 1993,
Eritreans have continued migrating to Sudan, Ethiopia,
Yemen, Egypt, or Israel because of a lack of basic human
rights or _ political freedom, educational and _ job
opportunities, or to seek asylum because of militarization.
Eritrea’s large diaspora has been a source of vital
remittances, funding its war for independence and
providing 30% of the country’s GDP annually since it
became independent.
In the last few years, Eritreans have increasingly been
trafficked and held hostage by Bedouins in the Sinai
Desert, where they are victims of organ harvesting, rape,
extortion, and torture. Some Eritrean trafficking victims
are kidnapped after being smuggled to Sudan or Ethiopia,
while others are kidnapped from within or around refugee
camps or crossing Eritrea’s borders. Eritreans composed
approximately 90% of the conservatively estimated 25,000-
30,000 victims of Sinai trafficking from 2009-2013,
according to a 2013 consultancy firm report.
Age structure: 0-14 years: 38.23% (male 1,169,456/female
1,155,460)
15-24 years: 20.56% (male 622,172/female 627,858)
25-54 years: 33.42% (male 997,693/female 1,034,550)
55-64 years: 3.8% (male 105,092/female 125,735)
65 years and over: 4% (male 99,231/female 143,949) (2020
est.)
Dependency ratios: total dependency ratio: 85 (2015 est.)
youth dependency ratio: 78.3 (2015 est.)
elderly dependency ratio: 6.8 (2015 est.)
potential support ratio: 14.8 (2015 est.)
Median age: total: 20.3 years
male: 19.7 years
female: 20.8 years (2020 est.)
country comparison to the world: 193
Population growth rate: 0.93% (2020 est.)
country comparison to the world: 115
Birth rate: 27.9 births/1,000 population (2020 est.)
country comparison to the world: 39
Death rate: 6.9 deaths/1,000 population (2020 est.)
country comparison to the world: 131
Net migration rate: -11.6 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 220
Population distribution: density is highest in the center of the
country in and around the cities of Asmara (capital) and
Keren; smaller settlements exist in the north and south
Urbanization: urban population: 41.3% of total population
(2020)
rate of urbanization: 3.86% annual rate of change (2015-20
est.)
Major urban areas—population: 963,000 ASMARA (capital)
(2020)
Sex ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1.01 male(s)/female (2020 est.)
15-24 years: 0.99 male(s)/female (2020 est.)
25-54 years: 0.96 male(s)/female (2020 est.)
55-64 years: 0.84 male(s)/female (2020 est.)
65 years and over: 0.69 male(s)/female (2020 est.)
total population: 97 male(s)/female (2020 est.)
Mother’s mean age at first birth: 21.3 years (2010 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 480 deaths/100,000 live births (2017
est.)
country comparison to the world: 21
Infant mortality rate: total: 43.3 deaths/1,000 live births
male: 50.3 deaths/1,000 live births
female: 36.1 deaths/1,000 live births (2020 est.)
country comparison to the world: 31
Life expectancy at birth: total population: 66.2 years
male: 63.6 years
female: 68.8 years (2020 est.)
country comparison to the world: 188
Total fertility rate: 3.73 children born/woman (2020 est.)
country comparison to the world: 35
Contraceptive prevalence rate: 8.4% (2010)
Drinking water source: improved:
urban: 73.2% of population
rural: 53.3% of population
total: 57.8% of population
unimproved:
urban: 26.8% of population
rural: 46.7% of population
total: 42.2% of population (2015 est.)
Current Health Expenditure: 3% (2016)
Hospital bed density: 0.7 beds/1,000 population (2011)
Sanitation facility access:
improved:
urban: 44.5% of population (2015 est.)
rural: 7.3% of population (2015 est.)
total: 15.7% of population (2015 est.)
unimproved:
urban: 55.5% of population (2015 est.)
rural: 92.7% of population (2015 est.)
total: 84.3% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.7% (2018 est.)
country comparison to the world: 57
HIV/AIDS—people living with HIV/AIDS: 18,000 (2018 est.)
country comparison to the world: 86
HIV/AIDS—deaths: <500 (2018 est.)
Major infectious diseases: degree of risk: high (2016)
food or waterborne diseases: bacterial diarrhea, hepatitis
A, and typhoid fever (2016)
vectorborne diseases: malaria and dengue fever (2016)
Obesity—adult prevalence rate: 5% (2016)
country comparison to the world: 183
Children under the age of 5 years underweight:
39.4% (2010)
country comparison to the world: 2
Education expenditures: NA
Literacy: definition: age 15 and over can read and write
total population: 76.6%
male: 84.4%
female: 68.9% (2018)
School life expectancy (primary to tertiary education): total: 5 years
male: 6 years
female: 5 years (2015)
Population: 15,736,368 (July 2020 est.)
country comparison to the world: 72
Nationality: Noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic groups: Wolof 37.1%, Pular 26.2%, Serer 17%,
Mandinka 5.6%, Jola 4.5%, Soninke 1.4%, other 8.3%
(includes Europeans and persons of Lebanese descent)
(2017 est.) Languages: French (official), Wolof, Pular, Jola,
Mandinka, Serer, Soninke
Religions: Muslim 95.9% (most adhere to one of the four
main Sufi brotherhoods), Christian 4.1% (mostly Roman
Catholic) (2016 est.) Demographic profile: Senegal has a large
and growing youth population but has not been successful
in developing its potential human capital. Senegal’s high
total fertility rate of almost 4.5 children per woman
continues to bolster the country’s large youth cohort—more
than 60% of the population is under the age of 25. Fertility
remains high because of the continued desire for large
families, the low use of family planning, and early
childbearing. Because of the country’s high illiteracy rate
(more than 40%), high unemployment (even among
university graduates), and widespread poverty, Senegalese
youths face dim prospects; women are. especially
disadvantaged.
Senegal historically was a destination country for
economic migrants, but in recent years West African
migrants more often use Senegal as a transit point to North
Africa—and sometimes illegally onward to Europe. The
country also has been host to several thousand black
Mauritanian refugees since they were expelled from their
homeland during its 1989 border conflict with Senegal. The
country’s economic crisis in the 1970s_ stimulated
emigration; departures accelerated in the 1990s.
Destinations shifted from neighboring countries, which
were experiencing economic decline, civil wars, and
increasing xenophobia, to Libya and Mauritania because of
their booming oil industries and to developed countries
(most notably former colonial ruler France, as well as Italy
and Spain). The latter became attractive in the 1990s
because of job opportunities and _ their periodic
regularization programs (legalizing the status of illegal
migrants).
Additionally, about 16,000 Senegalese refugees still
remain in The Gambia and Guinea-Bissau as a result of
more than 30 years of fighting between government forces
and rebel separatists in southern Senegal’s Casamance
region.
Age structure: 0-14 years: 40.38% (male 3,194,454/female
3,160,111)
15-24 years: 20.35% (male 1,596,896/female 1,606,084)
25-54 years: 31.95% (male 2,327,424/female 2,700,698)
55-64 years: 4.21% (male 283,480/female 378,932)
65 years and over: 3.1% (male 212,332/female 275,957)
(2020 est.)
Dependency ratios: total dependency ratio: 85.4 (2015 est.)
youth dependency ratio: 79.8 (2015 est.)
elderly dependency ratio: 5.6 (2015 est.)
potential support ratio: 18 (2015 est.)
Median age: total: 19.4 years
male: 18.5 years
female: 20.3 years (2020 est.)
country comparison to the world: 204
Population growth rate: 2.31% (2020 est.)
country comparison to the world: 30
Birth rate: 31.8 births/1,000 population (2020 est.)
country comparison to the world: 29
Death rate: 7.6 deaths/1,000 population (2020 est.)
country comparison to the world: 102
Net migration rate: -1.3 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 149
Population distribution: the population is concentrated in the
west, with Dakar anchoring a well-defined core area;
approximately 70% of the population is rural Urbanization:
urban population: 48.1% of total population (2020) rate of
urbanization: 3.73% annual rate of change (2015-20 est.)
Major urban areas—population: 3.140 million DAKAR (capital)
(2020)
Sex ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1.01 male(s)/female (2020 est.)
15-24 years: 0.99 male(s)/female (2020 est.)
25-54 years: 0.86 male(s)/female (2020 est.)
55-64 years: 0.75 male(s)/female (2020 est.)
65 years and over: 0.77 male(s)/female (2020 est.)
total population: 93.8 male(s)/female (2020 est.)
Mother’s mean age at first birth: 21.9 years (2017 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 315 deaths/100,000 live births (2017
est.)
country comparison to the world: 35
Infant mortality rate: total: 45.7 deaths/1,000 live births
male: 51.3 deaths/1,000 live births
female: 40 deaths/1,000 live births (2020 est.)
country comparison to the world: 28
Life expectancy at birth: total population: 63.2 years
male: 61.1 years
female: 65.4 years (2020 est.)
country comparison to the world: 206
Total fertility rate: 4.04 children born/woman (2020 est.)
country comparison to the world: 30
Contraceptive prevalence rate: 27.8% (2017)
Drinking water source:
improved:
urban: 92.9% of population
rural: 67.3% of population
total: 78.5% of population
unimproved:
urban: 7.1% of population
rural; 32.7% of population
total: 21.5% of population (2015 est.)
Current Health Expenditure: 5.5% (2016)
Physicians density: 0.07 physicians/1,000 population (2016)
Hospital bed density: 0.3 beds/1,000 population
Sanitation facility access:
improved:
urban: 65.4% of population (2015 est.)
rural: 33.8% of population (2015 est.)
total: 47.6% of population (2015 est.)
unimproved:
urban: 34.6% of population (2015 est.)
rural: 66.2% of population (2015 est.)
total: 52.4% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.4% (2018 est.)
country comparison to the world: 84
HIV/AIDS—people living with HIV/AIDS: 42,000 (2018 est.)
country comparison to the world: 65
HIV/AIDS—deaths: 1,300 (2018 est.)
country comparison to the world: 54
Major infectious diseases: degree of risk: very high (2016)
food or waterborne diseases: bacterial and _ protozoal
diarrhea, hepatitis A, and typhoid fever (2016) vectorborne
diseases: malaria and dengue fever (2016)
water contact diseases: schistosomiasis (2016)
animal contact diseases: rabies (2016)
respiratory diseases: meningococcal meningitis (2016)
Obesity—adult prevalence rate: 8.8% (2016)
country comparison to the world: 146
Children under the age of 5 years underweight:
14.4% (2017)
country comparison to the world: 46
Education expenditures: 4.8% of GDP (2017)
country comparison to the world: 74
Literacy: definition: age 15 and over can read and write
total population: 51.9%
male: 64.8%
female: 39.8% (2017)
School life expectancy (primary to tertiary education): total: 9 years
male: 9 years
female: 9 years (2017)
Unemployment, youth ages 15-24: total: 8.1%
male: 7.4%
female: 8.9% (2015 est.)
country comparison to the world: 142','f6734ce00f1343483f948a98fd9b4aee1ec35f5f1dde99ab19503510210ce120','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13b7860a02fe067788b73ab5b72e09554492079b8f17bb8e06ac09d250c738ac',2020,'LV','Latvia','people-and-society',473,'Population: 1,228,624 (July 2020 est.)
country comparison to the world: 158
Nationality: N0un: Estonian(s)
adjective: Estonian
Ethnic groups: Estonian 68.7%, Russian 24.8%, Ukrainian
1.7%, Belarusian 1%, Finn 0.6%, other 1.6%, unspecified
1.6% (2011 est.) Languages: Estonian (official) 68.5%,
Russian 29.6%, Ukrainian 0.6%, other 1.2%, unspecified
0.1% (2011 est.) Religions: Orthodox 16.2%, Lutheran 9.9%,
other Christian (including Methodist, Seventh-Day
Adventist, Roman Catholic, Pentecostal) 2.2%, other 0.9%,
none 54.1%, unspecified 16.7% (2011 est.) Age structure: O-
14 years: 16.22% (male 102,191/female 97,116) 15-24
years: 8.86% (male 56,484/female 52,378)
25-54 years: 40.34% (male 252,273/female 243,382)
595-64 years: 13.58% (male 76,251/female 90,576)
65 years and over: 21% (male 89,211/female 168,762)
(2020 est.)
Dependency ratios: total dependency ratio: 53.7 (2015 est.)
youth dependency ratio: 24.8 (2015 est.)
elderly dependency ratio: 28.9 (2015 est.)
potential support ratio: 3.5 (2015 est.)
Median age: total: 43.7 years
male: 40.4 years
female: 47 years (2020 est.)
country comparison to the world: 21
Population growth rate: -0.65% (2020 est.)
country comparison to the world: 229
Birth rate: 9.3 births/1,000 population (2020 est.)
country comparison to the world: 200
Death rate: 12.9 deaths/1,000 population (2020 est.)
country comparison to the world: 9
Net migration rate: -3.1 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 177
Population distribution: a fairly even distribution throughout
most of the country, with urban areas attracting larger and
denser populations Urbanization: urban population: 69.2% of
total population (2020) rate of urbanization: 0.01% annual
rate of change (2015-20 est.)
Major urban areas—population: 445,000 TALLINN (capital)
(2020)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.08 male(s)/female (2020 est.)
25-54 years: 1.04 male(s)/female (2020 est.)
55-64 years: 0.84 male(s)/female (2020 est.)
65 years and over: 0.53 male(s)/female (2020 est.)
total population: 88.4 male(s)/female (2020 est.)
Mother’s mean age at first birth: 26.6 years (2014 est.)
Maternal mortality rate: 9 deaths/100,000 live births (2017
est.)
country comparison to the world: 147
Infant mortality rate: total: 3.7 deaths/1,000 live births male:
3.6 deaths/1,000 live births
female: 3.8 deaths/1,000 live births (2020 est.)
country comparison to the world: 193
Life expectancy at birth: total population: 77.4 years male: 72.7
years
female: 82.3 years (2020 est.)
country comparison to the world: 82
Total fertility rate: 1.61 children born/woman (2020 est.)
country comparison to the world: 183
Drinking water source:
improved:
urban: 100% of population
rural: 99% of population
total: 99.6% of population
unimproved:
urban: 0% of population
rural: 1% of population
total: 0.4% of population (2015 est.)
Current Health Expenditure: 6.7% (2016)
Physicians density: 3.47 physicians/1,000 population (2016)
Hospital bed density: 5 beds/1,000 population (2015)
Sanitation facility access:
improved:
urban: 97.5% of population (2015 est.)
rural: 96.6% of population (2015 est.)
total: 97.2% of population (2015 est.)
unimproved:
urban: 2.5% of population (2015 est.)
rural: 3.4% of population (2015 est.)
total: 2.8% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.9% (2018 est.)
country comparison to the world: 51
HIV/AIDS—people living with HIV/AIDS: 7,400 (2018 est.)
country comparison to the world: 112
HIV/AIDS—deaths: <100 (2018 est.)
Major infectious diseases: degree of risk: intermediate (2016)
vectorborne diseases: tickborne encephalitis (2016)
Obesity—adult prevalence rate: 21.2% (2016)
country comparison to the world: 92
Education expenditures: 5.2% of GDP (2016)
country comparison to the world: 54
Literacy: definition: age 15 and over can read and write total
population: 99.8%
male: 99.8%
female: 99.8% (2015)
School life expectancy (primary to tertiary education): total: 16
years male: 15 years
female: 17 years (2016)
Unemployment, youth ages 15-24: total: 12.1%
male: 13.9%
female: 10% (2017 est.)
country comparison to the world: 113','ac759f8332518fbfa3a8124846482568cf6cdea4e7c671f0273a74453aef6ca2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4d7564b1f8fa7146469c9c90fded8f56f200bea312c89dc12b4cfb1e6f68ebc',2020,'MZ','Mozambique','people-and-society',483,'Population: 1,104,479 July 2020 est.)
note: estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can result
in lower life expectancy, higher infant mortality, higher
death rates, lower population growth rates, and changes in
the distribution of population by age and sex than would
otherwise be expected country comparison to the world:
160
Nationality: Noun: liSwati (singular), emaSwati (plural); note
—former term, Swazi(s), still used among English speakers
adjective: Swati; note—former term, Swazi, still used
among English speakers Ethnic groups: predominantly Swazi;
smaller populations of other African ethnic groups,
including the Zulu, as well as people of European ancestry
Languages: English (official, used for government business),
siSwati (official) Religions: Christian 90% (Zionist—a blend of
Christianity and indigenous ancestral worship—40%,
Roman Catholic 20%, other 30%—includes Anglican,
Methodist, Mormon, Jehovah’s Witness), Muslim 2%, other
8% (includes Baha’i, Buddhist, Hindu, indigenous, Jewish)
(2015 est.) Demographic profile: ESwatini, a small,
predominantly rural, landlocked country surrounded by
South Africa and Mozambique, suffers from severe poverty
and the world’s highest HIV/AIDS prevalence rate. A weak
and deteriorating economy, high unemployment, rapid
population growth, and an uneven distribution of resources
all combine to worsen already persistent poverty and food
insecurity, especially in rural areas. Erratic weather
(frequent droughts and intermittent heavy rains and
flooding), overuse of small plots, the overgrazing of cattle,
and outdated agricultural practices reduce crop yields and
further degrade the environment, exacerbating Eswatini’s
poverty and subsistence problems. Eswatini’s extremely
high HIV/AIDS prevalence rate—more than 28% of adults
have the disease—compounds these issues. Agricultural
production has declined due to HIV/AIDS, as the illness
causes households to lose manpower and to sell livestock
and other assets to pay for medicine and funerals.
Swazis, mainly men from the country’s rural south, have
been migrating to South Africa to work in coal, and later
gold, mines since the late 19th century. Although the
number of miners abroad has never been high in absolute
terms because of Eswatini’s small population, the outflow
has had important social and economic repercussions. The
peak of mining employment in South Africa occurred
during the 1980s. Cross-border movement has accelerated
since the 1990s, as increasing unemployment has pushed
more Swazis to look for work in South Africa (creating a
“brain drain” in the health and educational sectors);
southern Swazi men have continued to pursue mining,
although the industry has downsized. Women now make up
an increasing share of migrants and dominate cross-border
trading in handicrafts, using the proceeds to purchase
goods back in Eswatini. Much of today’s migration,
however, is not work-related but focuses on visits to family
and friends, tourism, and shopping.
Age structure: 0-14 years: 33.63% (male 185,640/female
185,808) 15-24 years: 18.71% (male 98,029/female
108,654)
25-54 years: 39.46% (male 202,536/female 233,275)
595-64 years: 4.36% (male 20,529/female 27,672)
65 years and over: 3.83% (male 15,833/female 26,503)
(2020 est.)
Dependency ratios: total dependency ratio: 68.8 (2015 est.)
youth dependency ratio: 63.5 (2015 est.)
elderly dependency ratio: 5.2 (2015 est.)
potential support ratio: 19.1 (2015 est.)
Median age: total: 23.7 years
male: 22.5 years
female: 24.7 years (2020 est.)
country comparison to the world: 174
Population growth rate: 0.77% (2020 est.)
country comparison to the world: 132
Birth rate: 24.5 births/1,000 population (2020 est.)
country comparison to the world: 50
Death rate: 10.1 deaths/1,000 population (2020 est.)
country comparison to the world: 36
Net migration rate: -6.8 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 209
Population distribution: because of its mountainous terrain, the
population distribution is uneven throughout the country,
concentrating primarily in valleys and plains Urbanization:
urban population: 24.2% of total population (2020) rate of
urbanization: 2.46% annual rate of change (2015-20 est.)
Major urban areas—population: 68,000 MBABANE (capital)
(2018)
Sex ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1 male(s)/female (2020 est.)
15-24 years: 0.9 male(s)/female (2020 est.)
25-54 years: 0.87 male(s)/female (2020 est.)
55-64 years: 0.74 male(s)/female (2020 est.)
65 years and over: 0.6 male(s)/female (2020 est.)
total population: 89.8 male(s)/female (2020 est.)
Maternal mortality rate: 4377 deaths/100,000 live births (2017
est.)
country comparison to the world: 25
Infant mortality rate: total: 42.8 deaths/1,000 live births male:
47.3 deaths/1,000 live births
female: 38.2 deaths/1,000 live births (2020 est.)
country comparison to the world: 32
Life expectancy at birth: total population: 58.6 years male: 56.5
years
female: 60.7 years (2020 est.)
country comparison to the world: 220
Total fertility rate: 2.52 children born/woman (2020 est.)
country comparison to the world: 71
Contraceptive prevalence rate: 66.1% (2014)
Drinking water source:
improved:
urban: 93.6% of population
rural: 68.9% of population
total: 74.1% of population
unimproved:
urban: 6.4% of population
rural: 31.1% of population
total: 25.9% of population (2015 est.)
Current Health Expenditure: 7.7% (2016)
Physicians density: 0.08 physicians/1,000 population (2016)
Hospital bed density: 2.1 beds/1,000 population (2011)
Sanitation facility access:
improved:
urban: 63.1% of population (2015 est.)
rural: 56% of population (2015 est.)
total: 57.5% of population (2015 est.)
unimproved:
urban: 36.9% of population (2015 est.)
rural: 44% of population (2015 est.)
total: 42.5% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 27.3% (201 est.)
country comparison to the world: 1
HIV/AIDS—people living with HIV/AIDS: 210,000 (2018 est.)
country comparison to the world: 28
HIV/AIDS—deaths: 2,400 (2018 est.)
country comparison to the world: 42
Major infectious diseases: degree of risk: intermediate (2016)
food or waterborne diseases: bacterial diarrhea, hepatitis
A, and typhoid fever (2016) vectorborne diseases: malaria
(2016)
water contact diseases: schistosomiasis (2016)
Obesity—adult prevalence rate: 16.5% (2016)
country comparison to the world: 124
Children under the age of 5 years underweight:
5.8% (2014)
country comparison to the world: 79
Education expenditures: 7.1% of GDP (2014)
country comparison to the world: 13
Literacy: definition: age 15 and over can read and write total
population: 88.4%
male: 88.3%
female: 88.5% (2015)
School life expectancy (primary to tertiary education): total: 11
years male: 12 years
female: 11 years (2013)
Unemployment, youth ages 15-24: total: 47.1%
male: 44.2%
female: 50.1% (2016)
country comparison to the world: 5
Population: 21,196,629 (July 2020 est.)
note: estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can result
in lower life expectancy, higher infant mortality, higher
death rates, lower population growth rates, and changes in
the distribution of population by age and sex than would
otherwise be expected country comparison to the world: 60
Nationality: Noun: Malawian(s)
adjective: Malawian
Ethnic groups: Chewa 34.3%, Lomwe 18.8%, Yao 13.2%,
Ngoni 10.4%, Tumbuka 9.2%, Sena 3.8%, Mang’anja 3.2%,
Tonga 1.8%, Nyanja 1.8%, Nkhonde 1%, other 2.2%,
foreign .3% (2018 est.) Languages: English (official),
Chichewa (common), Chinyanja, Chiyao, Chitumbuka,
Chilomwe, Chinkhonde, Chingoni, Chisena, Chitonga,
Chinyakyusa, Chilambya_ Religions: Protestant 33.5%
(includes Church of Central Africa Presbyterian 14.2%,
Seventh Day Adventist/Baptist 9.4%, Pentecostal 7.6%,
Anglican 2.3%), Roman Catholic 17.2%, other Christian
26.6%, Muslim 13.8%, traditionalist 1.1%, other 5.6%, none
2.1% (2018 est.) Demographic profile: Malawi has made great
improvements in maternal and child health, but has made
less progress in reducing its high fertility rate. In both rural
and urban areas, very high proportions of mothers are
receiving prenatal care and skilled birth assistance, and
most children are being vaccinated. Malawi’s fertility rate,
however, has only declined slowly, decreasing from more
than 7 children per woman in the 1980s to about 5.5 today.
Nonetheless, Malawians prefer smaller families than in the
past, and women are increasingly using contraceptives to
prevent or space pregnancies. Rapid population growth
and high population density is putting pressure on Malawi''s
land, water, and forest resources. Reduced plot sizes and
increasing vulnerability to climate change, further threaten
the sustainability of Malawi’s agriculturally based economy
and will worsen food shortages. About 80% of the
population is employed in agriculture.
Historically, Malawians migrated abroad in search of
work, primarily to South Africa and present-day Zimbabwe,
but international migration became uncommon after the
1970s, and most migration in recent years has been
internal. During the colonial period, Malawians regularly
migrated to southern Africa as contract farm laborers,
miners, and domestic servants. In the decade and a half
after independence in 1964, the Malawian Government
sought to transform its economy from one dependent on
small-scale farms to one based on estate agriculture. The
resulting demand for wage labor induced more than
300,000 Malawians to return home between the mid-1960s
and the mid-1970s. In recent times, internal migration has
generally been local, motivated more by marriage than
economic reasons.
Age structure: 0-14 years: 45.87% (male 4,843,107/female
4,878,983) 15-24 years: 20.51% (male 2,151,417/female
2,195,939)
25-54 years: 27.96% (male 2,944,936/female 2,982,195)
595-64 years: 2.98% (male 303,803/female 328,092)
65 years and over: 2.68% (male 249,219/female 318,938)
(2020 est.)
Dependency ratios: total dependency ratio: 91 (2015 est.)
youth dependency ratio: 85.3 (2015 est.)
elderly dependency ratio: 5.7 (2015 est.)
potential support ratio: 17.4 (2015 est.)
Median age: total: 16.8 years
male: 16.7 years
female: 16.9 years (2020 est.)
country comparison to the world: 222
Population growth rate: 3.3% (2020 est.)
country comparison to the world: 6
Birth rate: 40.1 births/1,000 population (2020 est.)
country comparison to the world: 9
Death rate: 7.2 deaths/1,000 population (2020 est.)
country comparison to the world: 120
Net migration rate: 0 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 89
Population distribution: population density is highest south of
Lake Nyasa
Urbanization: urban population: 17.4% of total population
(2020)
rate of urbanization: 4.19% annual rate of change (2015-20
est.)
Major urban areas—population: 1.122 million LILONGWE
(capital), 932,000 Blantyre-Limbe (2020) Sex ratio: at birth:
1.02 male(s)/female (2020 est.)
0-14 years: 0.99 male(s)/female (2020 est.)
15-24 years: 0.98 male(s)/female (2020 est.)
25-54 years: 0.99 male(s)/female (2020 est.)
55-64 years: 0.93 male(s)/female (2020 est.)
65 years and over: 0.78 male(s)/female (2020 est.)
total population: 98 male(s)/female (2020 est.)
Mother’s mean age at first birth: 18.9 years (2015/16 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 349 deaths/100,000 live births (2017
est.)
country comparison to the world: 31
Infant mortality rate: total: 39.5 deaths/1,000 live births
male: 45.8 deaths/1,000 live births
female: 33.2 deaths/1,000 live births (2020 est.)
country comparison to the world: 40
Life expectancy at birth: total population: 63.2 years
male: 61.2 years
female: 65.3 years (2020 est.)
country comparison to the world: 205
Total fertility rate: 5.31 children born/woman (2020 est.)
country comparison to the world: 11
Contraceptive prevalence rate: 59.2% (2015/16)
Drinking water source:
improved:
urban: 95.7% of population
rural: 89.1% of population
total: 90.2% of population
unimproved:
urban: 4.3% of population
rural: 10.9% of population
total: 9.8% of population (2015 est.)
Current Health Expenditure: 9.8% (2016)
Physicians density: 0.02 physicians/1,000 population (2016)
Hospital bed density: 1.3 beds/1,000 population (2011)
Sanitation facility access:
improved:
urban: 47.3% of population (2015 est.)
rural: 39.8% of population (2015 est.)
total: 41% of population (2015 est.)
unimproved:
urban: 52.7% of population (2015 est.)
rural: 60.2% of population (2015 est.)
total: 59% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 9.2% (2018 est.)
country comparison to the world: 9
HIV/AIDS—people living with HIV/AIDS: 1 million (2018 est.)
country comparison to the world: 10
HIV/AIDS—deaths: 13,000 (2018 est.)
country comparison to the world: 18
Major infectious diseases: degree of risk: very high (2016)
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever (2016) vectorborne
diseases: malaria and dengue fever (2016)
water contact diseases: schistosomiasis (2016)
animal contact diseases: rabies (2016)
Obesity—adult prevalence rate: 5.8% (2016)
country comparison to the world: 173
Children under the age of 5 years underweight:
11.8% (2015)
country comparison to the world: 56
Education expenditures: 4% of GDP (2017)
country comparison to the world: 104
Literacy: definition: age 15 and over can read and write
total population: 62.1%
male: 69.8%
female: 55.2% (2015)
School life expectancy (primary to tertiary education): total: 11
years male: 11 years
female: 11 years (2011)
Unemployment, youth ages 15-24: total: 8.5%
male: 6.7%
female: 10.6% (2017 est.)
country comparison to the world: 140
COUNTRY NAME: GOVERNMENT
conventional long form: Republic of Malawi
conventional short form: Malawi
local long form: Dziko la Malawi
local short form: Malawi
former: British Central African Protectorate, Nyasaland
Protectorate, Nyasaland
etymology: named for the East African Maravi Kingdom of
the 16th century; the word “maravi” means “fire flames”
Government type: presidential republic
Capital: name: Lilongwe
geographic coordinates: 13 58 S, 33 47 E
time difference: UTC+2 (7 hours ahead of Washington, DC,
during Standard Time)
etymology: named after the Lilongwe River that flows
through the city
Administrative divisions: 28 districts; Balaka, Blantyre,
Chikwawa, Chiradzulu, Chitipa, Dedza, Dowa, Karonga,
Kasungu, Likoma, Lilongwe, Machinga, Mangochi, Mchinji,
Mulanje, Mwanza, Mzimba, Neno, Ntcheu, Nkhata Bay,
Nkhotakota, Nsanje, Ntchisi, Phalombe, Rumphi, Salima,
Thyolo, Zomba Independence: 6 July 1964 (from the UK)
National holiday: Independence Day, 6 July (1964); note—also
called Republic Day since 6 July 1966
Constitution: /istory: previous 1953 (preindependence),
1966; latest drafted January to May 1994, approved 16 May
1994, entered into force 18 May 1995
amendments: proposed by the National Assembly; passage
of amendments affecting constitutional articles, including
the sovereignty and territory of the state, fundamental
constitutional principles, human rights, voting rights, and
the judiciary, requires majority approval in a referendum
and majority approval by the Assembly; passage of other
amendments requires at least two-thirds majority vote of
the Assembly; amended several times, last in 2017 (2018)
Legal system: mixed legal system of English common law and
customary law; judicial review of legislative acts in the
Supreme Court of Appeal International law _ organization
participation: accepts compulsory ICJ jurisdiction with
reservations; accepts ICCt jurisdiction Citizenship:
citizenship by birth: no
citizenship by descent only: at least one parent must be a
citizen of Malawi
dual citizenship recognized: no
residency requirement for naturalization: 7 years
Suffrage: 18 years of age; universal
Executive branch: Chief of state: President Arthur Peter
MUTHARIKA (since 31 May 2014); Vice President Everton
CHIMULIRENJI (since 28 May 2019; note—the president is
both chief of state and head of government head of
government: President Arthur Peter MUTHARIKA (since 31
May 2014); Vice President Everton CHIMULIRENJI (since
28 May 2019) cabinet: Cabinet named by the president
elections/appointments: president directly elected by
simple majority popular vote for a 5-year term (eligible for
a second term); election last held on 21 May 2019 (next to
be held in May 2024) election results: Peter MUTHARIKA
elected president; percent of vote—Peter MUTHARIKA
(DPP) 38.6%, Lazarus CHAKWERA (MCP) 35.4%, Saulos
CHILIMA (UTM) 20.2%, Atupele MULUZI (UDF) 4.7%,
other 3.1%
Legislative branch:description: unicameral National Assembly
(193 seats; members directly elected in _ single-seat
constituencies by simple majority vote to serve 5-year
terms) elections: last held on 21 May 2019 (next to be held
in May 2024)
election results: percent of vote by party—n/a; seats by
party—DPP 62, MCP 55, UDF 10, PP 5, other 5,
independent 55, vacant 1; composition—men 161, women
32, percent of women 16.6%
Judicial branch: highest courts: Supreme Court of Appeal
(consists of the chief justice and at least 3 judges) judge
selection and term of office: Supreme Court chief justice
appointed by the president and confirmed by the National
Assembly; other judges appointed by the president upon
the recommendation of the Judicial Service Commission,
which regulates judicial officers; judges serve until age 65
subordinate courts: High Court; magistrate courts;
Industrial Relations Court; district and city traditional or
local courts Political parties and leaders:
Democratic Progressive Party or DPP [Peter MUTHARIKA]
Malawi Congress Party or MCP [Lazarus CHAKWERA]
Peoples Party or PP [Joyce BANDA]
United Democratic Front or UDF [Atupele MULUZI]
United Transformation Movement or UTM _ [Saulos
CHILIMA]
International organization participation: ACP AfDB, AU, C, CD,
COMESA, FAO, G-77, IAEA, IBRD, ICAO, ICCt, ICRM, IDA,
IFAD, IFC, IFRCS, ILO, IMF, IMO, Interpol, IOC, IOM, IPU,
ISO (correspondent), ITSO, ITU, ITUC (NGOs), MIGA,
MINURSO, MONUSCO, NAM, OPCW, SADC, UN, UNCTAD,
UNESCO, UNIDO, UNISFA, UNOCI, UNWTO, UPU, WCO,
WFTU (NGOs), WHO, WIPO, WMO, WTO
Diplomatic representation in the US: Ambassador Edward Yakobe
SAWERENGERA (since 16 September 2016) chancery:
2408 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 721-0270
FAX: [1] (202) 721-0288
Diplomatic representation from the US: chief of mission:
Ambassador Robert SCOTT (since 6 August 2019)
telephone: 265 (0) 1773166
embassy: 16 Jomo Kenyatta Road, Lilongwe 3
mailing address: P.O. Box 30016, Lilongwe 3, Malawi
FAX: 265 (0) 1770471
Flag description: three equal horizontal bands of black (top),
red, and green with a radiant, rising, red sun centered on
the black band; black represents the native peoples, red
the blood shed in their struggle for freedom, and green the
color of nature; the rising sun represents the hope of
freedom for the continent of Africa National symbol(s): lion;
national colors: black, red, green
National anthem: Name: “Mulungu dalitsa Malawi” (Oh God
Bless Our Land of Malawi) lyrics/music: Michael-Fredrick
Paul SAUKA
note: adopted 1964
ele} Tel b 4
Economy—overview: Landlocked Malawi ranks among the
world’s least developed countries. The country’s economic
performance has historically been constrained by policy
inconsistency, macroeconomic instability, poor
infrastructure, rampant corruption, high population
growth, and poor health and education outcomes that limit
labor productivity. The economy is_ predominately
agricultural with about 80% of the population living in rural
areas. Agriculture accounts for about one-third of GDP and
80% of export revenues. The performance of the tobacco
sector is key to short-term growth as tobacco accounts for
more than half of exports, although Malawi is looking to
diversify away from tobacco to other cash crops.
The economy depends on_ substantial inflows of
economic assistance from the IMF, the World Bank, and
individual donor nations. Donors halted direct budget
support from 2013 to 2016 because of concerns about
corruption and fiscal carelessness, but the World Bank
resumed budget support in May 2017. In 2006, Malawi was
approved for relief under the Heavily Indebted Poor
Countries (HIPC) program but recent increases in domestic
borrowing mean that debt servicing in 2016 exceeded the
levels prior to HIPC debt relief.
Heavily dependent on rain-fed agriculture, with corn
being the staple crop, Malawi’s economy was hit hard by
the El Nino-driven drought in 2015 and 2016, and now
faces threat from the fall armyworm. The drought also
slowed economic activity, led to two consecutive years of
declining economic growth, and contributed to high
inflation rates. Depressed food prices over 2017 led to a
significant drop in inflation (from an average of 21.7% in
2016 to 12.3% in 2017), with a similar drop in interest
rates.
GDP (purchasing power parity):
$22.42 billion (2017 est.)
$21.56 billion (2016 est.)
$21.08 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 145
GDP (official exchange rate):
$6.24 billion (2017 est.)
GDP—real growth rate: 4% (2017 est.)
2.3% (2016 est.)
3% (2015 est.)
country comparison to the world: 79
GDP—per capita (PPP): $1,200 (2017 est.)
$1,200 (2016 est.)
$1,200 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 223
Gross national saving:
3.9% of GDP (2017 est.)
-2.8% of GDP (2016 est.)
2.8% of GDP (2015 est.)
country comparison to the world: 178
GDP—composition, by end use:
household consumption: 84.3% (2017 est.)
government consumption: 16.3% (2017 est.)
investment in fixed capital: 15.3% (2017 est.)
investment in inventories: 0% (2017 est.)
exports of goods and services: 27.9% (2017 est.)
imports of goods and services: -43.8% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 28.6% (2017 est.)
industry: 15.4% (2017 est.)
services: 56% (2017 est.)
Agriculture—products: tobacco, sugarcane, tea, corn, potatoes,
sweet potatoes, cassava (manioc, tapioca), sorghum,
pulses, cotton, groundnuts, macadamia nuts, coffee; cattle,
goats Industries: tobacco, tea, sugar, sawmill products,
cement, consumer goods
Industrial production growth rate:
1.2% (2017 est.)
country comparison to the world: 150
Labor force: 7 million (2013 est.)
country comparison to the world: 66
Labor force—by occupation: agriculture: 76.9%
industry: 4.1%
services: 19% (2013 est.)
Unemployment rate: 20.4% (2013 est.)
country comparison to the world: 187
Population below poverty line: 50.7% (2010 est.)
Household income or consumption by percentage share: Jowest 10%:
2.2%
highest 10%: 37.5% (2010 est.)
Budget: revenues: 1.356 billion (2017 est.)
expenditures: 1.567 billion (2017 est.)
Taxes and other revenues:
21.7% (of GDP) (2017 est.)
country comparison to the world: 135
Budget surplus (+) or deficit (-): -3.4% (of GDP) (2017 est.)
country comparison to the world: 144
Public debt:
59.2% of GDP (2017 est.)
60.3% of GDP (2016 est.)
country comparison to the world: 75
Fiscal year: 1 July—30 June
Inflation rate (consumer prices): 12.2% (2017 est.)
21.7% (2016 est.)
country comparison to the world: 205
Current account balance:
-§591 million (2017 est.)
-$744 million (2016 est.)
country comparison to the world: 122
Exports: $1.42 billion (2017 est.)
$1.361 billion (2016 est.)
country comparison to the world: 150
Exports—partners: Zimbabwe 13.1%, Mozambique 11.8%,
Belgium 10.7%, South Africa 6.3%, Netherlands 5%, UK
4.7%, Germany 4.3%, US 4.2% (2017) Exports—commodities:
tobacco (55%), dried legumes (8.8%), sugar (6.7%), tea
(5.7%), cotton (2%), peanuts, coffee, soy (2015 est.) Imports:
$2.312 billion (2017 est.)
$2.277 billion (2016 est.)
country comparison to the world: 161
Imports—commodities: food, petroleum products, semi-
manufactures, consumer goods, transportati','1cc5a93fb206848ac7628c2204c3cb50c6fa1dba3fc00ae6e64a752d81bbf79e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e6f7b805a9ed0b8a52265e1c6655e1a5f1573a0d20dd5e44e83bd19863ec427',2020,'MZ','Mozambique','people-and-society',484,'on equipment
Imports—partners: South Africa 20.7%, China 14.2%, India
11.6%, UAE 7%, Netherlands 4.4% (2017) Reserves of foreign
exchange and gold:
$780.2 million (31 December 2017 est.)
$585.7 million (31 December 2016 est.)
country comparison to the world: 140
Debt—external:
$2.102 billion (31 December 2017 est.)
$1.5 billion (31 December 2016 est.)
country comparison to the world: 152
Exchange rates: Malawian kwachas (MWK) per US dollar—
731.69 (2017 est.)
720.1 (2016 est.)
713.85 (2015 est.)
499.6 (2014 est.)
424.9 (2013 est.)
Population: 32,652,083 (July 2020 est.)
country comparison to the world: f
Nationality: Noun: Malaysian(s)
adjective: Malaysian
Ethnic groups: Bumiputera 62% (Malays and indigenous
peoples, including Orang Asli, Dayak, Anak Negeri),
Chinese 20.6%, Indian 6.2%, other 0.9%, non-citizens
10.3% (2017 est.) Languages: Bahasa Malaysia (official),
English, Chinese (Cantonese, Mandarin, Hokkien, Hakka,
Hainan, Foochow), Tamil, Telugu, Malayalam, Panjabi, Thai
note: Malaysia has 134 living languages—112 indigenous
languages and 22 non-indigenous languages; in East
Malaysia, there are several indigenous languages; the most
widely spoken are Iban and Kadazan Religions: Muslim
(official) 61.3%, Buddhist 19.8%, Christian 9.2%, Hindu
6.3%, Confucianism, Taoism, other traditional Chinese
religions 1.3%, other 0.4%, none 0.8%, unspecified 1%
(2010 est.) Age structure: 0-14 years: 26.8% (male
4,504,562/female 4,246,681) 15-24 years: 16.63% (male
2,760,244/female 2,670,186)
25-54 years: 40.86% (male 6,737,826/female 6,604,776)
55-64 years: 8.81% (male 1,458,038/female 1,418,280)
65 years and over: 6.9% (male 1,066,627/female 1,184,863)
(2020 est.)
Dependency ratios: total dependency ratio: 44.6 (2015 est.)
youth dependency ratio: 36.1 (2015 est.)
elderly dependency ratio: 8.5 (2015 est.)
potential support ratio: 11.8 (2015 est.)
Median age: total: 29.2 years
male: 28.9 years
female: 29.6 years (2020 est.)
country comparison to the world: 134
Population growth rate: 1.29% (2020 est.)
country comparison to the world: 83
Birth rate: 18.3 births/1,000 population (2020 est.)
country comparison to the world: 85
Death rate: 5.3 deaths/1,000 population (2020 est.)
country comparison to the world: 191
Net migration rate: -0.3 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 119
Population distribution: a highly uneven distribution with over
80% of the population residing on the Malay Peninsula
Urbanization: urban population: 77.2% of total population
(2020)
rate of urbanization: 2.13% annual rate of change (2015-20
est.)
Major urban areas—population: 7.997 million KUALA LUMPUR
(capital), 1.024 million Johor Bahru, 814,000 Ipoh (2020)
Sex ratio: at birth: 1.07 male(s)/female (2020 est.)
0-14 years: 1.06 male(s)/female (2020 est.)
15-24 years: 1.03 male(s)/female (2020 est.)
25-54 years: 1.02 male(s)/female (2020 est.)
55-64 years: 1.03 male(s)/female (2020 est.)
65 years and over: 0.9 male(s)/female (2020 est.)
total population: 102.5 male(s)/female (2020 est.)
Maternal mortality rate: 29 deaths/100,000 live births (2017
est.)
country comparison to the world: 113
Infant mortality rate: total: 11.4 deaths/1,000 live births
male: 13.2 deaths/1,000 live births
female: 9.6 deaths/1,000 live births (2020 est.)
country comparison to the world: 116
Life expectancy at birth: total population: 75.9 years
male: 73 years
female: 78.9 years (2020 est.)
country comparison to the world: 108
Total fertility rate: 2.43 children born/woman (2020 est.)
country comparison to the world: 78
Contraceptive prevalence rate: 52.2% (2014)
Drinking water source:
improved:
urban: 100% of population
rural: 93% of population
total: 98.2% of population
unimproved:
urban: 0% of population
rural: 7% of population
total: 1.8% of population (2015 est.)
Current Health Expenditure: 3.8% (2016)
Physicians density: 1.51 physicians/1,000 population (2015)
Hospital bed density: 1.9 beds/1,000 population (2015)
Sanitation facility access:
improved:
urban: 96.1% of population (2015 est.)
rural: 95.9% of population (2015 est.)
total: 96% of population (2015 est.)
unimproved:
urban: 3.9% of population (2015 est.)
rural: 4.1% of population (2015 est.)
total: 4% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.4% (2018 est.)
country comparison to the world: 83
HIV/AIDS—people living with HIV/AIDS: 87,000 (2018 est.)
country comparison to the world: 47
HIV/AIDS—deaths: 2,600 (2018 est.)
country comparison to the world: 41
Major infectious diseases: degree of risk: intermediate (2016)
food or waterborne diseases: bacterial diarrhea (2016)
vectorborne diseases: dengue fever (2016)
water contact diseases: leptospirosis (2016)
Obesity—adult prevalence rate: 15.6% (2016)
country comparison to the world: 125
Children under the age of 5 years underweight:
13.7% (2016)
country comparison to the world: 48
Education expenditures: 4.7% of GDP (2017)
country comparison to the world: 80
Literacy: definition: age 15 and over can read and write
total population: 93.7%
male: 96.3%
female: 91.1% (2016)
School life expectancy (primary to tertiary education): total: 13
years male: 13 years
female: 14 years (2017)
Unemployment, youth ages 15-24: total: 10.5%
male: 9.8%
female: 11.4% (2016 est.)
country comparison to the world: 125
Population: 391,904 (July 2020 est.)
country comparison to the world: 177
Nationality: N0un: Maldivian(s)
adjective: Maldivian
Ethnic groups: homogeneous mixture of Sinhalese, Dravidian,
Arab, Australasian, and African resulting from historical
changes in regional hegemony over marine trade routes
Languages: Dhivehi (official, dialect of Sinhala, script derived
from Arabic), English (spoken by most government
officials) Religions: Sunni Muslim (official)
Age structure: 0-14 years: 22.13% (male 44,260/female
42,477)
15-24 years: 17.24% (male 37,826/female 29,745)
25-54 years: 48.91% (male 104,217/female 87,465)
595-64 years: 6.91% (male 12,942/female 14,123)
65 years and over: 4.81% (male 8,417/female 10,432) (2020
est.)
Dependency ratios: total dependency ratio: 38 (2015 est.)
youth dependency ratio: 32.3 (2015 est.)
elderly dependency ratio: 5.7 (2015 est.)
potential support ratio: 17.7 (2015 est.)
Median age: total: 29.5 years
male: 29.2 years
female: 30 years (2020 est.)
country comparison to the world: 129
Population growth rate: -0.08% (2020 est.)
country comparison to the world: 203
Birth rate: 16 births/1,000 population (2020 est.)
country comparison to the world: 111
Death rate: 4.1 deaths/1,000 population (2020 est.)
country comparison to the world: 213
Net migration rate: -12.7 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 221
Population distribution: about a third of the population lives in
the centrally located capital city of Male and almost a tenth
in southern Addu City; the remainder of the populace is
spread over the 200 or so populated islands of the
archipelago Urbanization: urban population: 40.7% of total
population (2020)
rate of urbanization: 2.93% annual rate of change (2015-20
est.)
Major urban areas—population: 177,000 MALE (capital) (2018)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.04 male(s)/female (2020 est.)
15-24 years: 1.27 male(s)/female (2020 est.)
25-54 years: 1.19 male(s)/female (2020 est.)
55-64 years: 0.92 male(s)/female (2020 est.)
65 years and over: 0.81 male(s)/female (2020 est.)
total population: 112.7 male(s)/female (2020 est.)
Mother’s mean age at first birth: 24.5 years (2009 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 53 deaths/100,000 live births (2017
est.)
country comparison to the world: 92
Infant mortality rate: total: 19.8 deaths/1,000 live births
male: 22 deaths/1,000 live births
female: 17.5 deaths/1,000 live births (2020 est.)
country comparison to the world: 78
Life expectancy at birth: total population: 76.4 years
male: 74 years
female: 78.9 years (2020 est.)
country comparison to the world: 96
Total fertility rate: 1.71 children born/woman (2020 est.)
country comparison to the world: 171
Contraceptive prevalence rate: 34.7% (2009)
Drinking water source:
improved:
urban: 99.5% of population
rural: 97.9% of population
total: 98.6% of population
unimproved:
urban: 0.5% of population
rural: 2.1% of population
total: 1.4% of population (2015 est.)
Current Health Expenditure: 10.6% (2016)
Physicians density: 1.04 physicians/1,000 population (2016)
Hospital bed density: 4.3 beds/1,000 population (2009)
Sanitation facility access:
improved:
urban: 97.5% of population (2015 est.)
rural: 98.3% of population (2015 est.)
total: 97.9% of population (2015 est.)
unimproved:
urban: 2.5% of population (2015 est.)
rural: 1.7% of population (2015 est.)
total: 2.1% of population (2015 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Obesity—adult prevalence rate: 8.6% (2016)
country comparison to the world: 148
Children under the age of 5 years underweight:
17.7% (2009)
country comparison to the world: 33
Education expenditures: 4.1% of GDP (2016)
country comparison to the world: 97
Literacy: definition: age 15 and over can read and write
total population: 97.7%
male: 97.3%
female: 98.1% (2016)
Unemployment, youth ages 15-24: total: 15.9%
male: 19.1%
female: 12.1% (2016 est.)
country comparison to the world: 85','ad8cc0daee63d34e87293fbb99a9644addfdbe226ac11d9abffa5b6ca4731cbd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63d5a41f9dc6748168a96977cacf7be0e4939cb2277b4c62ccbe57fea1344330',2020,'DK','Denmark','people-and-society',511,'Population: 935,974 (July 2020 est.)
country comparison to the world: 161
Nationality: Noun: Fijian(s)
adjective: Fijian
Ethnic groups: ilaukei 56.8% (predominantly Melanesian with
a Polynesian admixture), Indo-Fijian 37.5%, Rotuman 1.2%,
other 4.5% (European, part European, other Pacific
Islanders, Chinese) (2007 est.) note: a 2010 law replaces
‘Fijian’ with ‘iTaukei’ when referring to the original and
native settlers of Fiji Languages: English (official), Fijian
(official), Hindustani
Religions: Protestant 45% (Methodist 34.6%, Assembly of
God 5.7%, Seventh Day Adventist 3.9%, and Anglican
0.8%), Hindu 27.9%, other Christian 10.4%, Roman
Catholic 9.1%, Muslim 6.3%, Sikh 0.3%, other 0.3%, none
0.8% (2007 est.) Age structure: 0-14 years: 26.86% (male
128,499/female 122,873)
15-24 years: 15.51% (male 73,993/female 71,139)
25-54 years: 41.05% (male 196,932/female 187,270)
595-64 years: 9.25% (male 43,813/female 42,763)
65 years and over: 7.34% (male 31,556/female 37,136)
(2020 est.)
Dependency ratios: total dependency ratio: 52.8 (2015 est.)
youth dependency ratio: 43.9 (2015 est.)
elderly dependency ratio: 8.9 (2015 est.)
potential support ratio: 11.2 (2015 est.)
Median age: total: 29.9 years
male: 29.7 years
female: 30.1 years (2020 est.)
country comparison to the world: 125
Population growth rate: 0.5% (2020 est.)
country comparison to the world: 155
Birth rate: 17.4 births/1,000 population (2020 est.)
country comparison to the world: 96
Death rate: 6.3 deaths/1,000 population (2020 est.)
country comparison to the world: 150
Net migration rate: -6.2 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 207
Population distribution: approximately 70% of the population
lives on the island of Viti Levu; roughly half of the
population lives in urban areas’ Urbanization: urban
population: 57.2% of total population (2020)
rate of urbanization: 1.62% annual rate of change (2015-20
est.)
Major urban areas—population: 178,000 SUVA (capital) (2018)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.04 male(s)/female (2020 est.)
25-54 years: 1.05 male(s)/female (2020 est.)
55-64 years: 1.02 male(s)/female (2020 est.)
65 years and over: 0.85 male(s)/female (2020 est.)
total population: 103 male(s)/female (2020 est.)
Maternal mortality rate: 34 deaths/100,000 live births (2017
est.)
country comparison to the world: 107
Infant mortality rate: total: 8.8 deaths/1,000 live births
male: 9.7 deaths/1,000 live births
female: 7.9 deaths/1,000 live births (2020 est.)
country comparison to the world: 143
Life expectancy at birth: total population: 73.7 years
male: 71 years
female: 76.6 years (2020 est.)
country comparison to the world: 141
Total fertility rate: 2.31 children born/woman (2020 est.)
country comparison to the world: 83
Drinking water source:
improved:
urban: 99.5% of population
rural: 91.2% of population
total: 95.7% of population
unimproved:
urban: 0.5% of population
rural: 8.8% of population
total: 4.3% of population (2015 est.)
Current Health Expenditure: 3.5% (2016)
Physicians density: 0.84 physicians/1,000 population (2015)
Hospital bed density: 2.3 beds/1,000 population (2011)
Sanitation facility access:
improved:
urban: 93.4% of population (2015 est.)
rural: 88.4% of population (2015 est.)
total: 91.1% of population (2015 est.)
unimproved:
urban: 6.6% of population (2015 est.)
rural: 11.6% of population (2015 est.)
total: 8.9% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.1% (2016 est.)
country comparison to the world: 121
HIV/AIDS—people living with HIV/AIDS: <1000 (2016 est.)
HIV/AIDS—deaths: <100 (2016 est.)
Major infectious diseases: note: active local transmission of
Zika virus by Aedes species mosquitoes has been identified
in this country (as of August 2016); it poses an important
risk (a large number of cases possible) among US citizens if
bitten by an infective mosquito; other less common ways to
get Zika are through sex, via blood transfusion, or during
pregnancy, in which the pregnant woman passes Zika virus
to her fetus Obesity—adult prevalence rate: 30.2% (2016)
country comparison to the world: 24
Education expenditures: 3.9% of GDP (2013)
country comparison to the world: 106
Literacy: total population: 99.1%
male: 99.1%
female: 99.1% (2018)
Unemployment, youth ages 15-24: total: 15.4%
male: 11.9%
female: 22.4% (2016 est.)
country comparison to the world: 87','e0209938dc783c310491debf3a92da68c82a909e5eb612c53eb96c43eeb1eb9a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f2b9e6824450478ddbc5c7977462e2ad31ccb6333f1bafe511d277144db6028',2020,'IL','Israel','people-and-society',536,'Population: 3.997 million (2019 est. est.)
country comparison to the world: 129
Nationality: Noun: Georgian(s)
adjective: Georgian
Ethnic groups: Georgian 86.8%, Azeri 6.3%, Armenian 4.5%,
other 2.3% (includes Russian, Ossetian, Yazidi, Ukrainian,
Kist, Greek) (2014 est.) Languages: Georgian (official) 87.6%,
Azeri 6.2%, Armenian 3.9%, Russian 1.2%, other 1% (2014
est.) note: Abkhaz is the official language in Abkhazia
Religions: Orthodox (official) 83.4%, Muslim 10.7%,
Armenian Apostolic 2.9%, other 1.2% (includes Catholic,
Jehovah’s Witness, Yazidi, Protestant, Jewish), none 0.5%,
unspecified/no answer 1.2% (2014 est.) Age structure: 0-14
years: 18.42% (male 472,731/female 435,174) 15-24 years:
10.9% (male 286,518/female 250,882)
25-54 years: 40.59% (male 984,942/female 1,016,353)
95-64 years: 13.24% (male 288,650/female 364,117)
65 years and over: 16.85% (male 326,219/female 504,444)
(2020 est.)
Dependency ratios: total dependency ratio: 50 (2015 est.)
youth dependency ratio: 28.1 (2015 est.)
elderly dependency ratio: 21.9 (2015 est.)
potential support ratio: 4.6 (2015 est.)
Median age: total: 38.6 years
male: 35.9 years
female: 41.4 years (2020 est.)
country comparison to the world: 60
Population growth rate: 0.05% (2020 est.)
country comparison to the world: 189
Birth rate: 11.6 births/1,000 population (2020 est.)
country comparison to the world: 169
Death rate: 11 deaths/1,000 population (2020 est.)
country comparison to the world: 21
Net migration rate: 0.1 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 74
Population distribution: Settlement concentrated in the central
valley, particularly in the capital city of Tbilisi in the east;
smaller urban agglomerations dot the Black Sea coast, with
Bat’umi being the largest Urbanization: urban population:
59.5% of total population (2020) rate of urbanization:
0.42% annual rate of change (2015-20 est.)
note: data include Abkhazia and South Ossetia
Major urban areas—population: 1.078 million TBILISI (capital)
(2020)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.09 male(s)/female (2020 est.)
15-24 years: 1.14 male(s)/female (2020 est.)
25-54 years: 0.97 male(s)/female (2020 est.)
55-64 years: 0.79 male(s)/female (2020 est.)
65 years and over: 0.65 male(s)/female (2020 est.)
total population: 91.8 male(s)/female (2020 est.)
Mother’s mean age at first birth: 24.5 years (2014 est.)
note: data do not cover Abkhazia and South Ossetia
Maternal mortality rate: 25 deaths/100,000 live births (2017
est.)
country comparison to the world: 121
Infant mortality rate: total: 13.8 deaths/1,000 live births
male: 15.8 deaths/1,000 live births
female: 11.7 deaths/1,000 live births (2020 est.)
country comparison to the world: 101
Life expectancy at birth: total population: 77 years
male: 72.9 years
female: 81.3 years (2020 est.)
country comparison to the world: 85
Total fertility rate: 1.75 children born/woman (2020 est.)
country comparison to the world: 160
Contraceptive prevalence rate: 53.4% (2010)
note: percent of women aged 15-44
Drinking water source:
improved:
urban: 100% of population
rural: 100% of population
total: 100% of population
unimproved:
urban: 0% of population
rural: 0% of population
total: 0% of population (2015 est.)
Current Health Expenditure: 8.4% (2016)
Physicians density: 5.1 physicians/1,000 population (2015)
Hospital bed density: 2.6 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 95.2% of population (2015 est.)
rural: 75.9% of population (2015 est.)
total: 86.3% of population (2015 est.)
unimproved:
urban: 4.8% of population (2015 est.)
rural: 24.1% of population (2015 est.)
total: 13.7% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.4% (2018 est.)
country comparison to the world: 79
HIV/AIDS—people living with HIV/AIDS: 9,400 (2018 est.)
country comparison to the world: 101
HIV/AIDS—deaths: <500 (2018 est.)
Obesity—adult prevalence rate: 21.7% (2016)
country comparison to the world: 86
Children under the age of 5 years underweight:
1.1% (2009)
country comparison to the world: 121
Education expenditures: 3.8% of GDP (2017)
country comparison to the world: 111
Literacy: definition: age 15 and over can read and write
total population: 99.4%
male: 99.4%
female: 99.3% (2017)
School life expectancy (primary to tertiary education): total: 15
years male: 15 years
female: 16 years (2017)
Unemployment, youth ages 15-24: total: 30.5%
male: 26.3%
female: 32.7% (2017 est.)
country comparison to the world: 29','c1444b3c97dc4e28af0f6bd9b4c73a925576286ff5faad3633d5a09b31fe000e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('632cfb479c7b3f0cea7e0a816be57a75e015bb5cbfbbd9fa0bf365384b1c3e34',2020,'SV','El Salvador','people-and-society',571,'Population: 67,052 (July 2020 est.)
country comparison to the world: 204
Nationality: N0un: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: Guernsey 52%, UK and Ireland 23.7%,
Portugal 2.1%, Latvia 1.5%, other 6.7%, unspecified 14.1%
note: data represent population by country of birth; the
native population is of British and Norman-French descent
Languages: English, French, Norman-French dialect spoken
in country districts
Religions: Protestant (Anglican, Presbyterian, Baptist,
Congregational, Methodist), Roman Catholic Age structure: 0-
14 years: 14.5% (male 5,008/female 4,712)
15-24 years: 10.58% (male 3,616/female 3,476)
25-54 years: 40.73% (male 13,821/female 13,492)
95-64 years: 13.96% (male 4,635/female 4,728)
65 years and over: 20.23% (male 6,229/female 7,335) (2020
est.)
Dependency ratios: total dependency ratio: 49
youth dependency ratio: 22.3
elderly dependency ratio: 26.7
potential support ratio: 3.7 (2020 est.)
note: data represent the Guernsey and Jersey
Median age: total: 44.3 years
male: 43 years
female: 45.6 years (2020 est.)
country comparison to the world: 17
Population growth rate: 0.26% (2020 est.)
country comparison to the world: 176
Birth rate: 9.8 births/1,000 population (2020 est.)
country comparison to the world: 193
Death rate: 9.2 deaths/1,000 population (2020 est.)
country comparison to the world: 55
Net migration rate: 1.9 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 49
Urbanization: urban population: 31% of total population
(2020) rate of urbanization: 0.46% annual rate of change
(2015-20 est.)
note: data represent Guernsey and Jersey
Major urban areas—population: 16,000 SAINT PETER PORT
(capital) (2018)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.06 male(s)/female (2020 est.)
15-24 years: 1.04 male(s)/female (2020 est.)
25-54 years: 1.02 male(s)/female (2020 est.)
55-64 years: 0.98 male(s)/female (2020 est.)
65 years and over: 0.85 male(s)/female (2020 est.)
total population: 98.7 male(s)/female (2020 est.)
Infant mortality rate: total: 3.3 deaths/1,000 live births
male: 3.6 deaths/1,000 live births
female: 3 deaths/1,000 live births (2020 est.)
country comparison to the world: 207
Life expectancy at birth: total population: 82.8 years
male: 80.1 years
female: 85.7 years (2020 est.)
country comparison to the world: 11
Total fertility rate: 1.57 children born/woman (2020 est.)
country comparison to the world: 192
Current Health Expenditure: HIV/AIDS—adult prevalence rate:
NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Education expenditures: NA','d93ed177cf727fcbeaaa3bd2200cd3e13cdf0503e63cba02789afdc2bc36d110','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04f5bb3a61244e08a08e2f789134dd373b57198c56b3a6557a84b4b1956b64d8',2020,'LR','Liberia','people-and-society',575,'Population: 12,527,440 (July 2020 est.)
country comparison to the world: 76
Nationality: N0un: Guinean(s)
adjective: Guinean
Ethnic groups: Fulani (Peuhl) 33.4%, Malinke 29.4%, Susu
21.2%, Guerze 7.8%, Kissi 6.2%, Toma 1.6%, other/foreign
4% (2018 est.) Languages: French (official), Pular, Maninka,
Susu, other native languages
note: about 40 languages are spoken; each ethnic group
has its own language
Religions: Muslim 89.1%, Christian 6.8%, animist 1.6%,
other .1%, none 2.4% (2014 est.) Demographic profile:
Guinea’s strong population growth is a result of declining
mortality rates and sustained elevated fertility. The
population growth rate was somewhat tempered in the
2000s because of a period of net outmigration. Although
life expectancy and mortality rates have improved over the
last two decades, the nearly universal practice of female
genital cutting continues to contribute to high infant and
maternal mortality rates. Guinea’s total fertility remains
high at about 5 children per woman because of the ongoing
preference for larger families, low contraceptive usage and
availability, a lack of educational attainment and
empowerment among women, and poverty. A lack of
literacy and vocational training programs limit job
prospects for youths, but even those with university
degrees often have no option but to work in the informal
sector. About 60% of the country’s large youth population is
unemployed.
Tensions and refugees have spilled over Guinea’s
borders with Sierra Leone, Liberia, and Cote d’Ivoire.
During the 1990s Guinea harbored as many as half a
million refugees from Sierra Leone and Liberia, more
refugees than any other African country for much of that
decade. About half sought refuge in the volatile “Parrot’s
Beak” region of southwest Guinea, a wedge of land jutting
into Sierra Leone near the Liberian border. Many were
relocated within Guinea in the early 2000s because the
area suffered repeated cross-border attacks from various
government and rebel forces, as well as anti-refugee
violence.
Age structure: 0-14 years: 41.2% (male 2,601,221/female
2,959,918) 15-24 years: 19.32% (male 1,215,654/female
1,204,366)
25-54 years: 30.85% (male 1,933,141/female 1,930,977)
595-64 years: 4.73% (male 287,448/female 305,420)
65 years and over: 3.91% (male 218,803/female 270,492)
(2020 est.)
Dependency ratios: total dependency ratio: 84.2 (2015 est.)
youth dependency ratio: 78.6 (2015 est.)
elderly dependency ratio: 5.6 (2015 est.)
potential support ratio: 17.8 (2015 est.)
Median age: total: 19.1 years
male: 18.9 years
female: 19.4 years (2020 est.)
country comparison to the world: 206
Population growth rate: 2.76% (2020 est.)
country comparison to the world: 13
Birth rate: 36.1 births/1,000 population (2020 est.)
country comparison to the world: 18
Death rate: 8.4 deaths/1,000 population (2020 est.)
country comparison to the world: 77
Net migration rate: 0 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 83
Population distribution: areas of highest density are in the west
and south; interior is sparsely populated Urbanization: urban
population: 36.5% of total population (2020) rate of
urbanization: 3.54% annual rate of change (2015-20 est.)
Major urban areas—population: 1.938 million CONAKRY (capital)
(2020)
Sex ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1.02 male(s)/female (2020 est.)
15-24 years: 1.01 male(s)/female (2020 est.)
25-54 years: 1 male(s)/female (2020 est.)
55-64 years: 0.94 male(s)/female (2020 est.)
65 years and over: 0.81 male(s)/female (2020 est.)
total population: 99.8 male(s)/female (2020 est.)
Mother’s mean age at first birth: 19.5 years (2018 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 576 deaths/100,000 live births (2017
est.)
country comparison to the world: 14
Infant mortality rate: total: 52.4 deaths/1,000 live births
male: 57.3 deaths/1,000 live births
female: 47.3 deaths/1,000 live births (2020 est.)
country comparison to the world: 19
Life expectancy at birth: total population: 63.2 years
male: 61.3 years
female: 65 years (2020 est.)
country comparison to the world: 204
Total fertility rate: 4.92 children born/woman (2020 est.)
country comparison to the world: 14
Contraceptive prevalence rate: 8.7% (2016)
Drinking water source:
improved:
urban: 92.7% of population
rural: 67.4% of population
total: 76.8% of population
unimproved:
urban: 7.3% of population
rural: 32.6% of population
total: 23.2% of population (2015 est.)
Current Health Expenditure: 5.5% (2016)
Physicians density: 0.08 physicians/1,000 population (2016)
Hospital bed density: 0.3 beds/1,000 population (2011)
Sanitation facility access:
improved:
urban: 34.1% of population (2015 est.)
rural: 11.8% of population (2015 est.)
total: 20.1% of population (2015 est.)
unimproved:
urban: 65.9% of population (2015 est.)
rural: 88.2% of population (2015 est.)
total: 79.9% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 1.4% (2018 est.)
country comparison to the world: 34
HIV/AIDS—people living with HIV/AIDS: 120,000 (2018 est.)
country comparison to the world: 40
HIV/AIDS—deaths: 4,300 (2018 est.)
country comparison to the world: 30
Major infectious diseases: degree of risk: very high (2016)
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever (2016) vectorborne
diseases: malaria, dengue fever, and yellow fever (2016)
water contact diseases: schistosomiasis (2016)
animal contact diseases: rabies (2016)
aerosolized dust or soil contact diseases: Lassa fever
(2016)
Obesity—adult prevalence rate: 7.7% (2016)
country comparison to the world: 158
Children under the age of 5 years underweight:
18.3% (2016)
country comparison to the world: 31
Education expenditures: 2.2% of GDP (2017)
country comparison to the world: 165
Literacy: definition: age 15 and over can read and write
total population: 30.4%
male: 38.1%
female: 22.8% (2015)
School life expectancy (primary to tertiary education): total: 9 years
male: 10 years
female: 8 years (2014)
Unemployment, youth ages 15-24: total: 1%
male: 1.5%
female: 0.6% (2012 est.)
country comparison to the world: 178
COUNTRY NAME: GOVERNMENT
conventional long form: Republic of Guinea
conventional short form: Guinea
local long form: Republique de Guinee
local short form: Guinee
former: French Guinea
etymology: the country is named after the Guinea region of
West Africa that lies along the Gulf of Guinea and stretches
north to the Sahel Government type: presidential republic
Capital: name: Conakry
geographic coordinates: 9 30 N, 13 42 W
time difference: UTC O (5 hours ahead of Washington, DC,
during Standard Time)
Administrative divisions: 7 regions administrative and 1
gouvenorat*; Boke, Conakry*, Faranah, Kankan, Kindia,
Labe, Mamou, N’Zerekore Independence: 2 October 1958
(from France)
National holiday: Independence Day, 2 October (1958)
Constitution: history: previous 1958, 1990; latest
promulgated 19 April 2010, approved 7 May 2010; note—in
late December 2019, President CONDE announced a new
draft constitution amendments: proposed by the National
Assembly or by the president of the republic; consideration
of proposals requires approval by simple majority vote by
the Assembly; passage requires approval in referendum;
the president can opt to submit amendments directly to the
Assembly, in which case approval requires at least two-
thirds majority vote (2017) Legal system: civil law system
based on the French model
International law organization participation: accepts compulsory
ICJ jurisdiction with reservations; accepts ICCt jurisdiction
Citizenship: citizenship by birth: no
citizenship by descent only: at least one parent must be a
citizen of Guinea
dual citizenship recognized: no
residency requirement for naturalization: na
Suffrage: 18 years of age; universal
Executive branch: Chief of state: President Alpha CONDE
(since 21 December 2010) head of government: Prime Minister
Ibrahima FOFANA (since 22 May 2018)
cabinet: Council of Ministers appointed by the president
elections/appointments: president directly elected by
absolute majority popular vote in 2 rounds if needed for a
9-year term (eligible for a second term); election last held
on 11 October 2015 (next to be held in 2020); prime
minister appointed by the president election results: Alpha
CONDE reelected president in the first round; percent of
vote—Alpha CONDE (RPG) 57.8%, Cellou Dalein DIALLO
(UFDG) 31.4%, other 10.8%
Legislative branch: description: unicameral People’s National
Assembly or Assemblee Nationale Populaire (114 seats; 76
members directly elected in a_ single nationwide
constituency by proportional representation vote and 38
directly elected in single-seat constituencies by simple
majority vote; members serve 5-year terms) elections: last
held on 28 September 2013 (next was schelduled for
January 2019, but postponed indefinitely) election results:
percent of vote by party—NA; seats by party—RPG 53,
UFDG 37, UFR 10, PEDN 2, UPG 2, other 10; composition
—men 89, women 25, percent of women 21.9%
Judicial branch: highest courts: Supreme Court or Cour
Supreme (organized into Administrative Chamber and Civil,
Penal, and Social Chamber; court consists of the first
president, 2 chamber presidents, 10 councilors, the
solicitor general, and NA deputies); Constitutional Court
(consists of 9 members) judge selection and term of Office:
Supreme Court first president appointed by the national
president after consultation with the National Assembly;
other members appointed by presidential decree; members
serve until age 65; Constitutional Court member
appointments—2 by the National Assembly and _ the
president of the republic, 3 experienced judges designated
by their peers, 1 experienced lawyer, 1 university professor
with expertise in public law designated by peers, and 2
experienced representatives of the Independent National
Institution of Human Rights; members serve single 9-year
terms subordinate courts: Court of Appeal or Cour d’Appel;
High Court of Justice or Cour d’Assises; Court of Account
(Court of Auditors); Courts of First Instance (Tribunal de
Premiere Instance); labor court; military tribunal; justices
of the peace; specialized courts Political parties and leaders:
Bloc Liberal or BL [Faya MILLIMONO]
National Party for Hope and Development or PEDN
[Lansana KOUYATE]
Rally for the Guinean People or RPG [Alpha CONDE]
Union for the Progress of Guinea or UPG
Union of Democratic Forces of Guinea or UFDG [Cellou
Dalein DIALLO]
Union of Republican Forces or UFR [Sidya TOURE]
International organization participation: ACP AfDB, AU, ECOWAS,
EITI (compliant country), FAO, G-77, IBRD, ICAO, ICCt,
ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO, Interpol,
IOC, IOM, IPU, ISO (correspondent), ITSO, ITU, ITUC
(NGOs), MIGA, MINURSO, MINUSMA, MONUSCO, NAM,
OIC, OIF OPCW, UN, UNCTAD, UNESCO, UNHCR, UNIDO,
UNISFA, UNMISS, UNOCI, UNWTO, UPU, WCO, WFTU
(NGOs), WHO, WIPO, WMO, WTO
Diplomatic representation in the _ US: Ambassador Kerfalla
YANSANE (since 24 January 2018) chancery: 2112 Leroy
Place NW, Washington, DC 20008
telephone: [1] (202) 986-4300
FAX: [1] (202) 986-3800
Diplomatic representation from the US: chief of mission:
Ambassador Simon HENSHAW (since 4 March 2019)
telephone: [224] 655-10-40-00
embassy: Transversale #2, Center Administratif de Koloma,
Commune de Ratoma, Conakry mailing address: P.O. Box
603, Transversale No. 2, Centre Administratif de Koloma,
Commune de Ratoma, Conakry FAX: [224] 655-10-42-97
Flag description: three equal vertical bands of red (hoist side),
yellow, and green; red represents the people’s sacrifice for
liberation and work; yellow stands for the sun, for the
riches of the earth, and for justice; green symbolizes the
country’s vegetation and unity note: uses the popular Pan-
African colors of Ethiopia; the colors from left to right are
the reverse of those on the flags of neighboring Mali and
Senegal National symbol(s): elephant; national colors: red,
yellow, green
National anthem: Name: “Liberte” (Liberty)
lyrics/music: unknown/Fodeba KEITA
note: adopted 1958
ele} ‘Tel h 4
Economy—overview: Guinea is a poor country of approximately
12.9 million people in 2016 that possesses the world’s
largest reserves of bauxite and largest untapped high-
grade iron ore reserves, as well as gold and diamonds. In
addition, Guinea has fertile soil, ample rainfall, and is the
source of several West African rivers, including the
Senegal, Niger, and Gambia. Guinea’s hydro potential is
enormous and the country could be a major exporter of
electricity. The country also has tremendous agriculture
potential. Gold, bauxite, and diamonds are Guinea’s main
exports. International investors have shown interest in
Guinea’s unexplored mineral reserves, which have the
potential to propel Guinea’s future growth.
Following the death of long-term President Lansana
CONTE in 2008 and the coup that followed, international
donors, including the G-8, the IMF, and the World Bank,
significantly curtailed their development programs in
Guinea. However, the IMF approved a 3-year Extended
Credit Facility arrangement in 2012, following the
December 2010 presidential elections. In September 2012,
Guinea achieved Heavily Indebted Poor Countries
completion point status. Future access to international
assistance and investment will depend on the government’s
ability to be transparent, combat corruption, reform its
banking system, improve its business environment, and
build infrastructure. In April 2013, the government
amended its mining code to reduce taxes and royalties. In
2014, Guinea complied with requirements of the Extractive
Industries Transparency Initiative by publishing its mining
contracts. Guinea completed its program with the IMF in
October 2016 even though some targeted reforms have
been delayed. Currently Guinea is negotiating a new IMF
program which will be based on Guinea’s new five-year
economic plan, focusing on the development of higher
value-added products, including from the agro-business
sector and development of the rural economy.
Political instability, a reintroduction of the Ebola virus
epidemic, low international commodity prices, and an
enduring legacy of corruption, inefficiency, and lack of
government transparency are factors that could impact
Guinea’s future growth. Economic recovery will be a long
process while the government adjusts to lower inflows of
international donor aid following the surge of Ebola-related
emergency support. Ebola stalled promising economic
growth in the 2014-15 period and impeded several projects,
such as offshore oil exploration and the Simandou iron ore
project. The economy, however, grew by 6.6% in 2016 and
6.7% in 2017, mainly due to growth from bauxite mining
and thermal energy generation as well as the resiliency of
the agricultural sector. The 240-megawatt Kaleta Dam,
inaugurated in September 2015, has expanded access to
electricity for residents of Conakry. An combined with fears
of Ebola virus, continue to undermine Guinea’s economic
viability.
Guinea’s iron ore industry took a hit in 2016 when
investors in the Simandou iron ore project announced plans
to divest from the project. In 2017, agriculture output and
public investment boosted economic growth, while the
mining sector continued to play a prominent role in
economic performance.
Successive governments have failed to address the
country’s crumbling infrastructure. Guinea suffers from
chronic electricity shortages; poor roads, rail lines and
bridges; and a lack of access to clean water—all of which
continue to plague economic development. The present
government, led by President Alpha CONDE, is working to
create an environment to attract foreign investment and
hopes to have greater participation from western countries
and firms in Guinea’s economic development.
GDP (purchasing power parity):
$27.97 billion (2017 est.)
$25.84 billion (2016 est.)
$23.39 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 138
GDP (official exchange rate):
$10.25 billion (2017 est.)
GDP—real growth rate: 8.2% (2017 est.)
10.5% (2016 est.)
3.8% (2015 est.)
country comparison to the world: 8
GDP—per capita (PPP): $2,200 (2017 est.)
$2,000 (2016 est.)
$1,900 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 205
Gross national saving:
9.1% of GDP (2017 est.)
-6.3% of GDP (2016 est.)
-5.3% of GDP (2015 est.)
country comparison to the world: 176
GDP—composition, by end use:
household consumption: 80.8% (2017 est.)
government consumption: 6.6% (2017 est.)
investment in fixed capital: 9.1% (2017 est.)
investment in inventories: 18.5% (2017 est.)
exports of goods and services: 21.9% (2017 est.)
imports of goods and services: -36.9% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 19.8% (2017 est.)
industry: 32.1% (2017 est.)
services: 48.1% (2017 est.)
Agriculture—products: rice, coffee, pineapples, mangoes, palm
kernels, cocoa, cassava (manioc, tapioca), bananas,
potatoes, sweet potatoes; cattle, sheep, goats; timber
Industries: bauxite, gold, diamonds, iron ore; _ light
manufacturing, agricultural processing Industrial production
growth rate:
11% (2017 est.)
country comparison to the world: 9
Labor force: 5.558 million (2017 est.)
country comparison to the world: 75
Labor force—by occupation: agriculture: 76%
industry: 24% (2006 est.)
Unemployment rate: 2.7% (2017 est.)
2.8% (2016 est.)
country comparison to the world: 28
Population below poverty line: 47% (2006 est.)
Household income or consumption by percentage share: Jowest 10%:
2.7%
highest 10%: 30.3% (2007)
Budget: revenues: 1.7 billion (2017 est.)
expenditures: 1.748 billion (2017 est.)
Taxes and other revenues:
16.6% (of GDP) (2017 est.)
country comparison to the world: 178
Budget surplus (+) or deficit (-): -0.5% (of GDP) (2017 est.)
country comparison to the world: 61
Public debt:
37.9% of GDP (2017 est.)
41.8% of GDP (2016 est.)
country comparison to the world: 137
Fiscal year: Calendar year
Inflation rate (consumer prices): 8.9% (2017 est.)
8.2% (2016 est.)
country comparison to the world: 200
Current account balance:
-§705 million (2017 est.)
-$2.705 billion (2016 est.)
country comparison to the world: 128
Exports: $3.514 billion (2017 est.)
$1.954 billion (2016 est.)
country comparison to the world: 123
Exports—partners: China 35.8%, Ghana 20.1%, UAE 11.6%,
India 4.3% (2017)
Exports—commodities: bauxite, gold, diamonds, coffee, fish,
agricultural products
Imports: $4.799 billion (2017 est.)
$4.43 billion (2016 est.)
country comparison to the world: 133
Imports—commodities: petroleum products, metals, machinery,
transport equipment, textiles, grain and other foodstuffs
Imports—partners: Netherlands 17.2%, China 13.2%, India
11.8%, Belgium 10%, France 6.9%, UAE 4.5% (2017)
Reserves of foreign exchange and gold:
$331.8 million (31 December 2017 est.)
$383.4 million (31 December 2016 est.)
country comparison to the world: 165
Debt—external:
$1.458 billion (31 December 2017 est.)
$1.462 billion (31 December 2016 est.)
country comparison to the world: 160
Exchange rates: Guinean francs (GNF) per US dollar—
9,230 (2017 est.)
9,085 (2016 est.)
9,085 (2015 est.)
7,485.5 (2014 est.)
7,014.1 (2013 est.)','cabf6c5391e849ca16d16845318044b85f04e0428dea1082771eaad03cd67904','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5496ab08a9704c93b0bbcfc1230309f6edb14d2350e5183b5e8a7e56d0181f28',2020,'CN','China','people-and-society',589,'Population: 350,734 (July 2020 est.)
Country comparison to the world: 178
country comparison to the world: 178
(../fields/335rank.html#IC)
Nationality: Noun: Icelander(s)
adjective: Icelandic
Ethnic groups: homogeneous mixture of descendants of Norse
and Celts 81%, population with foreign background 19%
(2018 est.) note: population with foreign background
includes immigrants and persons having at least one parent
who was born abroad Languages: Icelandic, English, Nordic
languages, German
Religions: Evangelical Lutheran Church of Iceland (official)
67.2%, Roman Catholic 3.9%, Reykjavik Free Church 2.8%,
Hafnarfjordur Free Church 2%, Asatru Association 1.2%,
The Independent Congregation .9%, other religions 4%
(includes Zuist and Pentecostal), none 6.7%, other or
unspecified 11.3% (2018 est.) Age structure: 0-14 years:
20.31% (male 36,394/female 34,837)
15-24 years: 12.85% (male 22,748/female 22,317)
25-54 years: 39.44% (male 70,227/female 68,095)
55-64 years: 11.94% (male 20,762/female 21,111)
65 years and over: 15.47% (male 25,546/female 28,697)
(2020 est.)
Dependency rations:
total dependency ratio: 51.6 (2015 est.)
youth dependency ratio: 30.8 (2015 est.)
elderly dependency ratio: 20.8 (2015 est.)
potential support ratio: 4.8 (2015 est.)
Median age: total: 37.1 years
male: 36.6 years
female: 37.7 years (2020 est.)
country comparison to the world: 74
Population growth rate: 1.02% (2020 est.)
country comparison to the world: 104
Birth rate: 13.3 births/1,000 population (2020 est.)
country comparison to the world: 141
Death rate: 6.6 deaths/1,000 population (2020 est.)
country comparison to the world: 139
Net migration rate: 3.3 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 34
Population distribution: Iceland is almost entirely urban with
half of the population located in and around the capital of
Reykjavik; smaller clusters are primarily found along the
coast in the north and west Urbanization: urban population:
93.9% of total population (2020)
rate of urbanization: 0.81% annual rate of change (2015-20
est.)
Major urban areas—population: 216,000 REYKJAVIK (capital)
(2018)
Sex ration:
at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.04 male(s)/female (2020 est.)
15-24 years: 1.02 male(s)/female (2020 est.)
25-54 years: 1.03 male(s)/female (2020 est.)
55-64 years: 0.98 male(s)/female (2020 est.)
65 years and over: 0.89 male(s)/female (2020 est.)
total population: 100.4 male(s)/female (2020 est.)
Mother’s mean age at first birth: 27.4 years (2015 est.)
Maternal mortality rate: 4 deaths/100,000 live births (2017
est.)
country comparison to the world: 173
Infant mortality rate: total: 2.1 deaths/1,000 live births
male: 2.3 deaths/1,000 live births
female: 2 deaths/1,000 live births (2020 est.)
country comparison to the world: 225
Life expectancy at birth: total population: 83.3 years
male: 81 years
female: 85.6 years (2020 est.)
country comparison to the world: 7
Total fertility rate: 1.97 children born/woman (2020 est.)
country comparison to the world: 115
Drinking water source:
improved:
urban: 100% of population
rural: 100% of population
total: 100% of population
unimproved:
urban: 0% of population
rural: 0% of population
total: 0% of population (2015 est.)
Current Health Expenditure: 8.3% (2016)
Physicians density: 3.97 physicians/1,000 population (2017)
Hospital bed density: 3.4 beds/1,000 population (2015)
Sanitation facility access:
improved:
urban: 98.7% of population (2015 est.)
rural: 100% of population (2015 est.)
total: 98.8% of population (2015 est.)
unimproved:
urban: 1.3% of population (2015 est.)
rural: 0% of population (2015 est.)
total: 1.2% of population (2015 est.)
HIV/AIDS—adult prevalence rate
0.1% (2018)
country comparison to the world: 124
HIV/AIDS—people living with HIV/AIDS: <500 (2018)
HIV/AIDS—deaths: <100 (2018)
Obesity—adult prevalence rate: 21.9% (2016)
country comparison to the world: 83
Education expenditures: 7.5% of GDP (2016)
country comparison to the world: 8
School life expectancy (primary to tertiary education): total: 19
years male: 18 years
female: 20 years (2016)
Unemployment, youth ages 15-24: total: 7.9%
male: 8.6%
female: 7.1% (2017 est.)
country comparison to the world: 147
Population: 1,326,093,247 (July 2020 est.)
country comparison to the world: 2
Nationality: Noun: Indian(s)
adjective: Indian
Ethnic groups: Indo-Aryan 72%, Dravidian 25%, Mongoloid
and other 3% (2000)
Languages: Hindi 43.6%, Bengali 8%, Marathi 6.9%, Telugu
6.7%, Tamil 5.7%, Gujarati 4.6%, Urdu 4.2%, Kannada
3.6%, Odia 3.1%, Malayalam 2.9%, Punjabi 2.7%, Assamese
1.3%, Maithili 1.1%, other 5.6% (2011 est.) note: English
enjoys the status of subsidiary official language but is the
most important language for national, political, and
commercial communication; there are 22 other officially
recognized languages: Assamese, Bengali, Bodo, Dogri,
Gujarati, Hindi, Kannada, Kashmiri, Konkani, Maithili,
Malayalam, Manipuri, Nepali, Odia, Punjabi, Sanskrit,
Santali, Sindhi, Tamil, Telugu, Urdu; Hindustani is a
popular variant of Hindi/Urdu spoken widely throughout
northern India but is not an official language Religions:
Hindu 79.8%, Muslim 14.2%, Christian 2.3%, Sikh 1.7%,
other and unspecified 2% (2011 est.) Age structure: 0-14
years: 26.31% (male 185,017,089/female 163,844,572) 15-
24 years: 17.51% (male 123,423,531/female 108,739,780)
25-54 years: 41.56% (male 285,275,667/female
265,842,319)
55-64 years: 7.91% (male 52,444,817/female 52,447,038)
65 years and over: 6.72% (male 42,054,459/female
47,003,975) (2020 est.)
Dependency ratios: total dependency ratio: 52.2 (2015 est.)
youth dependency ratio: 43.6 (2015 est.)
elderly dependency ratio: 8.6 (2015 est.)
potential support ratio: 11.7 (2015 est.)
Median age: total: 28.7 years
male: 28 years
female: 29.5 years (2020 est.)
country comparison to the world: 141
Population growth rate: 1.1% (2020 est.)
country comparison to the world: 96
Birth rate: 18.2 births/1,000 population (2020 est.)
country comparison to the world: 87
Death rate: 7.3 deaths/1,000 population (2020 est.)
country comparison to the world: 113
Net migration rate: 0 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 85
Population distribution: with the notable exception of the
deserts in the northwest, including the Thar Desert, and
the mountain fringe in the north, a very high population
density exists throughout most of the country; the core of
the population is in the north along the banks of the
Ganges, with other river valleys and southern coastal areas
also having large population concentrations Urbanization:
urban population: 34.9% of total population (2020)
rate of urbanization: 2.37% annual rate of change (2015-20
est.)
Major urban areas—population: 30.291 million NEW DELHI
(capital), 20.411 million Mumbai, 14.850 million Kolkata,
1.237 million Bangalore, 10.971 million Chennai, 10.004
million Hyderabad (2020) Sex ratio: at birth: 1.11
male(s)/female (2020 est.)
0-14 years: 1.13 male(s)/female (2020 est.)
15-24 years: 1.14 male(s)/female (2020 est.)
25-54 years: 1.07 male(s)/female (2020 est.)
55-64 years: 1 male(s)/female (2020 est.)
65 years and over: 0.89 male(s)/female (2020 est.)
total population: 107.9 male(s)/female (2020 est.)
Maternal mortality rate: 145 deaths/100,000 live births (2017
est.)
country comparison to the world: 57
Infant mortality rate: total: 35.4 deaths/1,000 live births
male: 34.4 deaths/1,000 live births
female: 36.5 deaths/1,000 live births (2020 est.)
country comparison to the world: 45
Life expectancy at birth: total population: 69.7 years
male: 68.4 years
female: 71.2 years (2020 est.)
country comparison to the world: 167
Total fertility rate: 2.35 children born/woman (2020 est.)
country comparison to the world: 81
Contraceptive prevalence rate: 53.5% (2015/16)
Drinking water source:
improved:
urban: 97.1% of population
rural: 92.6% of population
total: 94.1% of population
unimproved:
urban: 2.9% of population
rural: 7.4% of population
total: 5.9% of population (2015 est.)
Current Health Expenditure: 3.7% (2016)
Physicians density: 0.78 physicians/1,000 population (2017)
Hospital bed density: 0.7 beds/1,000 population (2011)
Sanitation facility access:
improved:
urban: 62.6% of population (2015 est.)
rural: 28.5% of population (2015 est.)
total: 39.6% of population (2015 est.)
unimproved:
urban: 37.4% of population (2015 est.)
rural: 71.5% of population (2015 est.)
total: 60.4% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.2% (2017 est.)
country comparison to the world: 99
HIV/AIDS—people living with HIV/AIDS: 2.1 million (2017 est.)
country comparison to the world: 3
HIV/AIDS—deaths: 69,000 (2017 est.)
country comparison to the world: 2
Major infectious diseases: degree of risk: very high (2016)
food or waterborne diseases: bacterial diarrhea, hepatitis A
and E, and typhoid fever (2016) vectorborne diseases:
dengue fever, Japanese encephalitis, and malaria (2016)
water contact diseases: leptospirosis (2016)
animal contact diseases: rabies (2016)
Obesity—adult prevalence rate: 3.9% (2016)
country comparison to the world: 189
Children under the age of 5 years underweight:
36.3% (2015)
country comparison to the world: 4
Education expenditures: 3.8% of GDP (2013)
country comparison to the world: 112
Literacy: definition: age 15 and over can read and write
total population: 74.4%
male: 82.4%
female: 65.8% (2018)
School life expectancy (primary to tertiary education): total: 12
years male: 12 years
female: 13 years (2016)
Unemployment, youth ages 15-24: total: 10.1%
male: 9.5%
female: 12% (2012 est.)
country comparison to the world: 129','5b7777d0b9ea76aa8657ac3a7ab33f4196881f2a4f14ce86b8c7d26b070abaab','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44c0c638810b41bda5741e87912ac6ff9d524d715efbc8f6327a774dd52ebf76',2020,'IE','Ireland','people-and-society',595,'Population: 5,176,569 (July 2020 est.)
country comparison to the world: 122
Nationality: Noun: Irishman(men), Irishwoman(women), Irish
(collective plural) adjective: Irish
Ethnic groups: Irish 82.2%, Irish travelers 0.7%, other white
9.5%, Asian 2.1%, black 1.4%, other 1.5%, unspecified
2.6% (2016 est.) Languages: English (official, the language
generally used), Irish (Gaelic or Gaeilge) (official, spoken
by approximately 39.8% of the population as of 2016;
mainly spoken in areas along Ireland’s western coast
known as gaeltachtai, which are officially recognized
regions where Irish is the predominant language) Religions:
Roman Catholic 78.3%, Church of Ireland 2.7%, other
Christian 1.6%, Orthodox 1.3%, Muslim 1.3%, other 2.4%,
none 9.8%, unspecified 2.6% (2016 est.) Age structure: 0-14
years: 21.15% (male 560,338/female 534,570)
15-24 years: 12.08% (male 316,239/female 308,872)
25-54 years: 42.19% (male 1,098,058/female 1,085,794)
95-64 years: 10.77% (male 278,836/female 278,498)
65 years and over: 13.82% (male 331,772/female 383,592)
(2020 est.)
Dependency ratios: total dependency ratio: 53.8 (2015 est.)
youth dependency ratio: 33.4 (2015 est.)
elderly dependency ratio: 20.3 (2015 est.)
potential support ratio: 4.9 (2015 est.)
Median age: total: 37.8 years
male: 37.4 years
female: 38.2 years (2020 est.)
country comparison to the world: 66
Population growth rate: 1.04% (2020 est.)
country comparison to the world: 101
Birth rate: 13 births/1,000 population (2020 est.)
country comparison to the world: 144
Death rate: 6.8 deaths/1,000 population (2020 est.)
country comparison to the world: 134
Net migration rate: 3.9 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 31
Population distribution: population distribution is weighted to
the eastern side of the island, with the _ largest
concentration being in and around Dublin; populations in
the west are small due to mountainous land, poorer soil,
lack of good transport routes, and fewer job opportunities
Urbanization: urban population: 63.7% of total population
(2020)
rate of urbanization: 1.14% annual rate of change (2015-20
est.)
Major urban areas—population: 1.228 million DUBLIN (capital)
(2020)
Sex ratio: at birth: 1.06 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.02 male(s)/female (2020 est.)
25-54 years: 1.01 male(s)/female (2020 est.)
595-64 years: 1 male(s)/female (2020 est.)
65 years and over: 0.86 male(s)/female (2020 est.)
total population: 99.8 male(s)/female (2020 est.)
Mother’s mean age at first birth: 30.7 years (2015 est.)
Maternal mortality rate: 5 deaths/100,000 live births (2017
est.)
country comparison to the world: 165
Infant mortality rate: total: 3.6 deaths/1,000 live births
male: 3.9 deaths/1,000 live births
female: 3.2 deaths/1,000 live births (2020 est.)
country comparison to the world: 195
Life expectancy at birth: total population: 81.2 years
male: 78.9 years
female: 83.7 years (2020 est.)
country comparison to the world: 36
Total fertility rate: 1.94 children born/woman (2020 est.)
country comparison to the world: 125
Contraceptive prevalence rate: 73.3% (2010)
note: percent of women aged 18-45
Drinking water source:
improved:
urban: 97.9% of population
rural: 97.8% of population
total: 97.9% of population
unimproved:
urban: 2.1% of population
rural: 2.2% of population
total: 2.1% of population (2015 est.)
Current Health Expenditure: 7.4% (2016)
Physicians density: 3.09 physicians/1,000 population (2017)
Hospital bed density: 2.8 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 89.1% of population (2015 est.)
rural: 92.9% of population (2015 est.)
total: 90.5% of population (2015 est.)
unimproved:
urban: 10.9% of population (2015 est.)
rural: 7.1% of population (2015 est.)
total: 9.5% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.2% (2018 est.)
country comparison to the world: 100
HIV/AIDS—people living with HIV/AIDS: 7,200 (2018 est.)
country comparison to the world: 114
HIV/AIDS—deaths: <100 (2018 est.)
Obesity—adult prevalence rate: 25.3% (2016)
country comparison to the world: 51
Education expenditures: 3.7% of GDP (2016)
country comparison to the world: 117
School life expectancy (primary to tertiary education): total: 19
years male: 19 years
female: 19 years (2016)
Unemployment, youth ages 15-24: total: 14.4%
male: 16%
female: 12.6% (2017 est.)
country comparison to the world: 99','50d56afdf6b2a497700fb9e825d848b0c265a011c2a4e4cbb3d7cd4d523de0e1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a53b0375af39af683d51c3e9f0ac47bdce791127c08ed0985b1bb8097035e3b',2020,'JO','Jordan','people-and-society',624,'Population: 19,091,949 (July 2020 est.)
country comparison to the world: 64
Nationality: N0un: Kazakhstani(s)
adjective: Kazakhstani
Ethnic groups: Kazakh (Qazaqg) 68%, Russian 19.3%, Uzbek
3.2%, Ukrainian 1.5%, Uighur 1.5%, Tatar 1.1%, German
1%, other 4.4% (2019 est.) Languages: Kazakh (official,
Qazaq) 83.1% (understand spoken language) and trilingual
(Kazakh, Russian, English) 22.3% (2017 est.); Russian
(official, used in everyday business, designated the
“language of interethnic communication”) 94.4%
(understand spoken language) (2009 est.) Religions: Muslim
70.2%, Christian 26.2% (mainly Russian Orthodox), other
0.2%, atheist 2.8%, unspecified 0.5% (2009 est.) Age
structure: 0-14 years: 26.13% (male 2,438,148/female
2,950,535) 15-24 years: 12.97% (male 1,262,766/female
1,212,645)
25-54 years: 42.23% (male 3,960,188/female 4,102,845)
595-64 years: 10.25% (male 856,180/female 1,099,923)
65 years and over: 8.43% (male 567,269/female 1,041,450)
(2020 est.)
Dependency ratios: total dependency ratio: 50.4 (2015 est.)
youth dependency ratio: 40.3 (2015 est.)
elderly dependency ratio: 10.2 (2015 est.)
potential support ratio: 9.8 (2015 est.)
Median age: total: 31.6 years
male: 30.3 years
female: 32.8 years (2020 est.)
country comparison to the world: 114
Population growth rate: 0.89% (2020 est.)
country comparison to the world: 117
Birth rate: 16.4 births/1,000 population (2020 est.)
country comparison to the world: 105
Death rate: 8.2 deaths/1,000 population (2020 est.)
country comparison to the world: 86
Net migration rate: 0.4 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 67
Population distribution: Most of the country displays a low
population density, particularly the interior; population
clusters appear in urban agglomerations in the far northern
and southern portions of the country Urbanization: urban
population: 57.7% of total population (2020) rate of
urbanization: 1.29% annual rate of change (2015-20 est.)
Major urban areas—population: 1.896 million Almaty, 1.896
million NUR-SULTAN (capital), 1.058 million Shimkent
(2020) Sex ratio: at birth: 0.94 male(s)/female (2020 est.)
0-14 years: 0.96 male(s)/female (2020 est.)
15-24 years: 1.04 male(s)/female (2020 est.)
25-54 years: 0.97 male(s)/female (2020 est.)
55-64 years: 0.78 male(s)/female (2020 est.)
65 years and over: 0.54 male(s)/female (2020 est.)
total population: 90.8 male(s)/female (2020 est.)
Mother’s mean age at first birth: 25 years (2014 est.)
Maternal mortality rate: 10 deaths/100,000 live births (2017
est.)
country comparison to the world: 146
Infant mortality rate: total: 17.9 deaths/1,000 live births
male: 20.4 deaths/1,000 live births
female: 15.5 deaths/1,000 live births (2020 est.)
country comparison to the world: 83
Life expectancy at birth: total population: 72 years
male: 66.8 years
female: 76.8 years (2020 est.)
country comparison to the world: 156
Total fertility rate: 2.16 children born/woman (2020 est.)
country comparison to the world: 96
Contraceptive prevalence rate: 54.8% (2018)
note: percent of women aged 18-49
Drinking water source:
improved:
urban: 99.4% of population
rural: 85.6% of population
total: 92.9% of population
unimproved:
urban: 0.6% of population
rural: 14.4% of population
total: 7.1% of population (2015 est.)
Current Health Expenditure: 3.5% (2016)
Physicians density: 3.25 physicians/1,000 population (2014)
Hospital bed density: 6.7 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 97% of population (2015 est.)
rural: 98.1% of population (2015 est.)
total: 97.5% of population (2015 est.)
unimproved:
urban: 3% of population (2015 est.)
rural: 1.9% of population (2015 est.)
total: 2.5% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.2% (2018 est.)
country comparison to the world: 102
HIV/AIDS—people living with HIV/AIDS: 26,000 (2018 est.)
country comparison to the world: 77
HIV/AIDS—deaths: <500 (2018 est.)
Obesity—adult prevalence rate: 21% (2016)
country comparison to the world: 94
Children under the age of 5 years underweight:
2% (2015)
country comparison to the world: 112
Education expenditures: 2.8% of GDP (2017)
country comparison to the world: 146
Literacy: definition: age 15 and over can read and write
total population: 99.8%
male: 99.8%
female: 99.8% (2015)
School life expectancy (primary to tertiary education): total: 15
years male: 15 years
female: 16 years (2017)
Unemployment, youth ages 15-24: total: 3.9%
male: 3.6%
female: 4.3% (2013 est.)
country comparison to the world: 167','edf63c336b914990faaaa70406634b5a60bc1edf31f4180316d918ca30e3e35a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6139eac408991f18c77da0419c9667a6e6885ea2c6a3279c06dd3458bcb8aa8',2020,'KW','Kuwait','people-and-society',652,'Population: 2,993,706 July 2020 est.)
note: Kuwait’s Public Authority for Civil Information
estimates the country’s total population to be 4,420,110 for
2019, with non-Kuwaitis accounting for nearly 70% of the
population country comparison to the world: 138
Nationality: N0un: Kuwaiti(s)
adjective: Kuwaiti
Ethnic groups: Kuwaiti 30.4%, other Arab 27.4%, Asian
40.3%, African 1%, other .9% (includes European, North
American, South American, and Australian) (2018 est.)
Languages: Arabic (official), English widely spoken
Religions: Muslim (official) 74.6%, Christian 18.2%, other
and unspecified 7.2% (2013 est.) note: data represent the
total population; about 69% of the population consists of
immigrants Age structure: 0-14 years: 24.29% (male
378,778/female 348,512) 15-24 years: 14.96% (male
245,354/female 202,642)
25-54 years: 52.39% (male 984,813/female 583,632)
55-64 years: 5.43% (male 90,583/female 72,026)
65 years and over: 2.92% (male 38,614/female 48,752)
(2020 est.)
Dependency ratios: total dependency ratio: 29.8 (2015 est.)
youth dependency ratio: 27.1 (2015 est.)
elderly dependency ratio: 2.7 (2015 est.)
potential support ratio: 37.3 (2015 est.)
Median age: total: 29.7 years
male: 30.7 years
female: 27.9 years (2020 est.)
country comparison to the world: 127
Population growth rate: 1.27% (2020 est.)
country comparison to the world: 86
Birth rate: 18 births/1,000 population (2020 est.)
country comparison to the world: 90
Death rate: 2.3 deaths/1,000 population (2020 est.)
country comparison to the world: 227
Net migration rate: -3.3 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 181
Population distribution: densest settlement is along the Persian
Gulf, particularly in Kuwait City and on Bubiyan Island;
significant population threads extend south and west along
highways that radiate from the capital, particularly in the
southern half of the country Urbanization: urban population:
100% of total population (2020) rate of urbanization: 1.78%
annual rate of change (2015-20 est.)
Major urban areas—population: 3.115 million KUWAIT (capital)
(2020)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.09 male(s)/female (2020 est.)
15-24 years: 1.21 male(s)/female (2020 est.)
25-54 years: 1.69 male(s)/female (2020 est.)
55-64 years: 1.26 male(s)/female (2020 est.)
65 years and over: 0.79 male(s)/female (2020 est.)
total population: 138.4 male(s)/female (2020 est.)
Maternal mortality rate: 12 deaths/100,000 live births (2017
est.)
country comparison to the world: 140
Infant mortality rate: total: 6.5 deaths/1,000 live births male:
6.4 deaths/1,000 live births
female: 6.7 deaths/1,000 live births (2020 est.)
country comparison to the world: 162
Life expectancy at birth: total population: 78.6 years male: 77.2
years
female: 80.2 years (2020 est.)
country comparison to the world: 65
Total fertility rate: 2.26 children born/woman (2020 est.)
country comparison to the world: 86
Drinking water source:
improved:
urban: 99% of population
rural: 99% of population
total: 99% of population
unimproved:
urban: 1% of population
rural: 1% of population
total: 1% of population (2015 est.)
Current Health Expenditure: 3.9% (2016)
Physicians density: 2.58 physicians/1,000 population (2015)
Hospital bed density: 2 beds/1,000 population (2014)
Sanitation facility access:
improved:
urban: 100% of population (2015 est.)
rural: 100% of population (2015 est.)
total: 100% of population (2015 est.)
unimproved:
urban: 0% of population (2015 est.)
rural: 0% of population (2015 est.)
total: 0% of population (2015 est.)
HIV/AIDS—adult prevalence rate: <.1% (2018 est.)
HIV/AIDS—people living with HIV/AIDS: <1000 (2018 est.)
HIV/AIDS—deaths: <100 (2018 est.)
Obesity—adult prevalence rate: 37.9% (2016)
country comparison to the world: 11
Children under the age of 5 years underweight:
3% (2014)
country comparison to the world: 101
Education expenditures: NA
Literacy: definition: age 15 and over can read and write total
population: 96.1%
male: 96.7%
female: 94.9% (2018)
School life expectancy (primary to tertiary education): total: 14
years male: 13 years
female: 14 years (2013)
Unemployment, youth ages 15-24: total: 15.4%
male: 9.4% N/A
female: 30% N/A (2016 est.)
country comparison to the world: 88
Population: 5,964,897 (July 2020 est.)
country comparison to the world: 114
Nationality: Noun: Kyrgyzstani(s)
adjective: Kyrgyzstani
Ethnic groups: Kyrgyz 73.5%, Uzbek 14.7%, Russian 5.5%,
Dungan 1.1%, other 5.2% (includes Uyghur, Tajik, Turk,
Kazakh, Tatar, Ukrainian, Korean, German) (2019 est.)
Languages: Kyrgyz (official) 71.4%, Uzbek 14.4%, Russian
(official) 9%, other 5.2% (2009 est.) Religions: Muslim 90%
(majority Sunni), Christian 7% (Russian Orthodox 3%),
other 3% (includes Jewish, Buddhist, Baha’i) (2017 est.) Age
structure: 0-14 years: 30.39% (male 930,455/female 882,137)
15-24 years: 15.7% (male 475,915/female 460,604)
25-54 years: 40.02% (male 1,172,719/female 1,214,624)
55-64 years: 8.09% (male 210,994/female 271,480)
65 years and over: 5.8% (male 132,134/female 213,835)
(2020 est.)
Dependency ratios: total dependency ratio: 54.7 (2015 est.)
youth dependency ratio: 48.1 (2015 est.)
elderly dependency ratio: 6.6 (2015 est.)
potential support ratio: 15.1 (2015 est.)
Median age: total: 27.3 years
male: 26.1 years
female: 28.5 years (2020 est.)
country comparison to the world: 147
Population growth rate: 0.96% (2020 est.)
country comparison to the world: 109
Birth rate: 20.6 births/1,000 population (2020 est.)
country comparison to the world: 74
Death rate: 6.3 deaths/1,000 population (2020 est.)
country comparison to the world: 151
Net migration rate: -5 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 197
Population distribution: the vast majority of Kyrgyzstanis live in
rural areas; densest population settlement is to the north in
and around the capital, Bishkek, followed by Osh in the
west; the least densely populated area is the east,
southeast in the Tien Shan mountains Urbanization: urban
population: 36.9% of total population (2020) rate of
urbanization: 2.03% annual rate of change (2015-20 est.)
Major urban areas—population: 1.038 million BISHKEK (capital)
(2020)
Sex ratio: at birth: 1.07 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.03 male(s)/female (2020 est.)
25-54 years: 0.97 male(s)/female (2020 est.)
55-64 years: 0.78 male(s)/female (2020 est.)
65 years and over: 0.62 male(s)/female (2020 est.)
total population: 96 male(s)/female (2020 est.)
Mother’s mean age at first birth: 23.2 years (2014 est.)
Maternal mortality rate: 60 deaths/100,000 live births (2017
est.)
country comparison to the world: 89
Infant mortality rate: total: 23.3 deaths/1,000 live births male:
27.2 deaths/1,000 live births
female: 19.2 deaths/1,000 live births (2020 est.)
country comparison to the world: 69
Life expectancy at birth: total population: 71.8 years male: 67.7
years
female: 76.2 years (2020 est.)
country comparison to the world: 159
Total fertility rate: 2.54 children born/woman (2020 est.)
country comparison to the world: 69
Contraceptive prevalence rate: 42% (2014)
Drinking water source:
improved:
urban: 96.7% of population
rural: 86.2% of population
total: 90% of population
unimproved:
urban: 3.3% of population
rural: 13.8% of population
total: 10% of population (2015 est.)
Current Health Expenditure: 6.6% (2016)
Physicians density: 1.88 physicians/1,000 population (2014)
Hospital bed density: 4.5 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 89.1% of population (2015 est.)
rural: 95.6% of population (2015 est.)
total: 93.3% of population (2015 est.)
unimproved:
urban: 10.9% of population (2015 est.)
rural: 4.4% of population (2015 est.)
total: 6.7% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.2% (2018 est.)
country comparison to the world: 103
HIV/AIDS—people living with HIV/AIDS: 8,500 (2018 est.)
country comparison to the world: 106
HIV/AIDS—deaths: <200 (2018 est.)
Obesity—adult prevalence rate: 16.6% (2016)
country comparison to the world: 121
Children under the age of 5 years underweight:
2.8% (2014)
country comparison to the world: 104
Education expenditures: 7.2% of GDP (2017)
country comparison to the world: 12
Literacy: definition: age 15 and over can read and write total
population: 99.6%
male: 99.7%
female: 99.5% (2018)
School life expectancy (primary to tertiary education): total: 13
years male: 13 years
female: 14 years (2017)
Unemployment, youth ages 15-24: total: 14.8%
male: 11.7%
female: 21% (2017 est.)
country comparison to the world: 93
Population: 7,447,396 (July 2020 est.)
country comparison to the world: 101
Nationality: N0un: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic groups: Lao 53.2%, Khmou 11%, Hmong 9.2%,
Phouthay 3.4%, Tai 3.1%, Makong 2.5%, Katong 2.2%, Lue
2%, Akha 1.8%, other 11.6% (2015 est.) note: the Laos
Government officially recognizes 49 ethnic groups, but the
total number of ethnic groups is estimated to be well over
200
Languages: Lao (official), French, English, various ethnic
languages
Religions: Buddhist 64.7%, Christian 1.7%, none 31.4%,
other/not stated 2.1% (2015 est.)
Age structure: 0-14 years: 31.25% (male 1,177,297/female
1,149,727)
15-24 years: 20.6% (male 763,757/female 770,497)
25-54 years: 38.29% (male 1,407,823/female 1,443,774)
55-64 years: 5.73% (male 206,977/female 219,833)
65 years and over: 4.13% (male 139,665/female 168,046)
(2020 est.)
Dependency ratios: total dependency ratio: 60.2 (2015 est.)
youth dependency ratio: 54 (2015 est.)
elderly dependency ratio: 6.2 (2015 est.)
potential support ratio: 16.1 (2015 est.)
Median age: total: 24 years
male: 23.7 years
female: 24.4 years (2020 est.)
country comparison to the world: 170
Population growth rate: 1.44% (2020 est.)
country comparison to the world: 76
Birth rate: 22.4 births/1,000 population (2020 est.)
country comparison to the world: 64
Death rate: 7.2 deaths/1,000 population (2020 est.)
country comparison to the world: 119
Net migration rate: -1 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 144
Population distribution: most densely populated area is in and
around the capital city of Vientiane; large communities are
primarily found along the Mekong River along the
southwestern border; overall density is considered one of
the lowest in Southeast Asia Urbanization: urban population:
36.3% of total population (2020)
rate of urbanization: 3.28% annual rate of change (2015-20
est.)
Major urban areas—population: 683,000 VIENTIANE (capital)
(2020)
Sex ratio: at birth: 1.04 male(s)/female (2020 est.)
0-14 years: 1.02 male(s)/female (2020 est.)
15-24 years: 0.99 male(s)/female (2020 est.)
25-54 years: 0.98 male(s)/female (2020 est.)
55-64 years: 0.94 male(s)/female (2020 est.)
65 years and over: 0.83 male(s)/female (2020 est.)
total population: 98.5 male(s)/female (2020 est.)
Maternal mortality rate: 185 deaths/100,000 live births (2017
est.)
country comparison to the world: 50
Infant mortality rate: total: 45.6 deaths/1,000 live births
male: 50.5 deaths/1,000 live births
female: 40.4 deaths/1,000 live births (2020 est.)
country comparison to the world: 29
Life expectancy at birth: total population: 65.7 years
male: 63.6 years
female: 67.9 years (2020 est.)
country comparison to the world: 193
Total fertility rate: 2.53 children born/woman (2020 est.)
country comparison to the world: 70
Contraceptive prevalence rate: 54.1% (2017)
Drinking water source:
improved:
urban: 85.6% of population
rural: 69.4% of population
total: 75.7% of population
unimproved:
urban: 14.4% of population
rural: 30.6% of population
total: 24.3% of population (2015 est.)
Current Health Expenditure: 2.4% (2016)
Physicians density: 0.5 physicians/1,000 population (2014)
Hospital bed density: 1.5 beds/1,000 population (2012)
Sanitation facility access:
improved:
urban: 94.5% of population (2015 est.)
rural: 56% of population (2015 est.)
total: 70.9% of population (2015 est.)
unimproved:
urban: 5.5% of population (2015 est.)
rural: 44% of population (2015 est.)
total: 29.1% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.3% (2018 est.)
country comparison to the world: 90
HIV/AIDS—people living with HIV/AIDS: 12,000 (2018 est.)
country comparison to the world: 96
HIV/AIDS—deaths: <500 (2018 est.)
Major infectious diseases: degree of risk: very high (2016)
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever (2016) vectorborne
diseases: dengue fever and malaria (2016)
Obesity—adult prevalence rate: 5.3% (2016)
country comparison to the world: 179
Children under the age of 5 years underweight:
26.9% (2011)
country comparison to the world: 16
Education expenditures: 2.9% of GDP (2014)
country comparison to the world: 141
Literacy: definition: age 15 and over can read and write
total population: 84.7%
male: 90%
female: 79.4% (2015)
School life expectancy (primary to tertiary education): total: 11
years male: 11 years
female: 11 years (2017)
Unemployment, youth ages 15-24: total: 18.2%
male: 20.8%
female: 15.5% (2017 est.)
country comparison to the world: 75
lyrics/music: SISANA Sisane/THONGDY Sounthonevichit
note: music adopted 1945, lyrics adopted 1975; the
anthem’s lyrics were changed following the 1975
Communist revolution that overthrew the monarchy','22ca487706235c76292a7fb270ba4fc80595180bd786a9227fb6567e3b6c3638','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad0e62fb097d3e9cf708c6d6d8c059df16c89bea12595b673b13580ee9b17e30',2020,'LU','Luxembourg','people-and-society',680,'Population: 628,381 (July 2020 est.)
country comparison to the world: 169
Nationality: noun: Luxembourger(s)
adjective: Luxembourg
Ethnic groups: Luxembourger 51.1%, Portuguese 15.7%,
French 7.5%, Italian 3.6%, Belgian 3.3%, German 2.1%,
Spanish 1.1%, British 1%, other 14.6% (2019 est.) note:
data represent population by nationality
Languages: Luxembourgish (official administrative and
judicial language and _ national language (spoken
vernacular)) 55.8%, Portuguese 15.7%, French (official
administrative, judicial, and legislative language) 12.1%,
German (official administrative and judicial language)
3.1%, Italian 2.9%, English 2.1%, other 8.4% (2011 est.)
Religions: Christian (predominantly Roman Catholic) 70.4%,
Muslim 2.3%, other (includes Buddhist, folk religions,
Hindu, Jewish) 0.5%, none 26.8% (2010 est.) Age structure: 0-
14 years: 16.73% (male 54,099/female 51,004) 15-24 years:
11.78% (male 37,946/female 36,061)
25-54 years: 43.93% (male 141,535/female 134,531)
595-64 years: 12.19% (male 39,289/female 37,337)
65 years and over: 15.37% (male 43,595/female 52,984)
(2020 est.)
Dependency ratios: total dependency ratio: 43.6 (2015 est.)
youth dependency ratio: 23.5 (2015 est.)
elderly dependency ratio: 20.1 (2015 est.)
potential support ratio: 5 (2015 est.)
Median age: total: 39.5 years
male: 38.9 years
female: 40 years (2020 est.)
country comparison to the world: 56
Population growth rate: 1.8% (2020 est.)
country comparison to the world: 57
Birth rate: 11.6 births/1,000 population (2020 est.)
country comparison to the world: 170
Death rate: 7.3 deaths/1,000 population (2020 est.)
country comparison to the world: 114
Net migration rate: 13.3 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 3
Population distribution: Most people live in the south, on or
near the border with France Urbanization: urban population:
91.5% of total population (2020) rate of urbanization:
1.55% annual rate of change (2015-20 est.)
Major urban areas—population: 120,000 LUXEMBOURG (capital)
(2018)
Sex ratio: at birth: 1.06 male(s)/female (2020 est.) 0-14
years: 1.06 male(s)/female (2020 est.)
15-24 years: 1.05 male(s)/female (2020 est.)
25-54 years: 1.05 male(s)/female (2020 est.)
55-64 years: 1.05 male(s)/female (2020 est.)
65 years and over: 0.82 male(s)/female (2020 est.)
total population: 101.5 male(s)/female (2020 est.)
Mother’s mean age at first birth: 30.1 years (2015 est.)
Maternal mortality rate: 5 deaths/100,000 live births (2017
est.)
country comparison to the world: 168
Infant mortality rate: total: 3.3 deaths/1,000 live births male:
3.7 deaths/1,000 live births
female: 3 deaths/1,000 live births (2020 est.)
country comparison to the world: 209
Life expectancy at birth: total population: 82.6 years male: 80.1
years
female: 85.2 years (2020 est.)
country comparison to the world: 16
Total fertility rate: 1.62 children born/woman (2020 est.)
country comparison to the world: 182
Drinking water source:
improved:
urban: 100% of population
rural: 100% of population
total: 100% of population
unimproved:
urban: 0% of population
rural: 0% of population
total: 0% of population (2015 est.)
Current Health Expenditure: 6.2% (2016)
Physicians density: 3.03 physicians/1,000 population (2017)
Hospital bed density: 4.9 beds/1,000 population (2014)
Sanitation facility access:
improved:
urban: 97.5% of population (2015 est.)
rural: 98.5% of population (2015 est.)
total: 97.6% of population (2015 est.)
unimproved:
urban: 2.5% of population (2015 est.)
rural: 1.5% of population (2015 est.)
total: 2.4% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.3% (2018 est.)
country comparison to the world: 91
HIV/AIDS—people living with HIV/AIDS: 1,200 (2018 est.)
country comparison to the world: 139
HIV/AIDS—deaths: <100 (2018 est.)
Obesity—adult prevalence rate: 22.6% (2016)
country comparison to the world: 74
Education expenditures: 3.9% of GDP (2015)
country comparison to the world: 107
Literacy: School life expectancy (primary to _ tertiary
education): total: 14 years male: 14 years
female: 14 years (2016)
Unemployment, youth ages 15-24: total: 15.4%
male: 17.2%
female: 13.2% (2017 est.)
country comparison to the world: 89','635a0252c66a26d6972471e5a3d7d8fbeded9b88bfe904bcadc0ff2b27fcc87f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e498969c9a9b488ac040c7a26bc650dee8439061414e4b0caf87c146d69590b4',2020,'MT','Malta','people-and-society',705,'Population: 457,267 (July 2020 est.)
country comparison to the world: 175
Nationality: noun: Maltese (singular and plural)
adjective: Maltese
Ethnic groups: Maltese (descendants of ancient Carthaginians
and Phoenicians with strong elements of Italian and other
Mediterranean stock) Languages: Maltese (official) 90.1%,
English (official) 6%, multilingual 3%, other 0.9% (2005
est.) Religions: Roman Catholic (official) more than 90%
(2006 est.)
Age structure: 0-14 years: 14.38% (male 33,934/female
31,823)
15-24 years: 10.33% (male 24,445/female 22,811)
25-54 years: 41.1% (male 97,685/female 90,264)
95-64 years: 12.88% (male 29,533/female 29,353)
65 years and over: 21.3% (male 44,644/female 52,775)
(2020 est.)
Dependency ratios: total dependency ratio: 48.8 (2015 est.)
youth dependency ratio: 21.4 (2015 est.)
elderly dependency ratio: 27.3 (2015 est.)
potential support ratio: 3.7 (2015 est.)
Median age: total: 42.3 years
male: 41.2 years
female: 43.5 years (2020 est.)
country comparison to the world: 35
Population growth rate: 0.87% (2020 est.)
country comparison to the world: 119
Birth rate: 9.9 births/1,000 population (2020 est.)
country comparison to the world: 192
Death rate: 8.3 deaths/1,000 population (2020 est.)
country comparison to the world: 79
Net migration rate: 6.6 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 16
Population distribution: most of the population lives on the
eastern half of Malta, the largest of the three inhabited
islands Urbanization: urban population: 94.7% of total
population (2020)
rate of urbanization: 0.38% annual rate of change (2015-20
est.)
Major urban areas—population: 213,000 VALLETTA (capital)
(2018)
Sex ratio: at birth: 1.04 male(s)/female (2020 est.)
0-14 years: 1.07 male(s)/female (2020 est.)
15-24 years: 1.07 male(s)/female (2020 est.)
25-54 years: 1.08 male(s)/female (2020 est.)
95-64 years: 1.01 male(s)/female (2020 est.)
65 years and over: 0.85 male(s)/female (2020 est.)
total population: 101.4 male(s)/female (2020 est.)
Mother’s mean age at first birth: 26.9 years (2010 est.)
note: data refer to the average of the different childbearing
ages of first-order births
Maternal mortality rate: 6 deaths/100,000 live births (2017
est.)
country comparison to the world: 161
Infant mortality rate: total: 4.6 deaths/1,000 live births
male: 4.5 deaths/1,000 live births
female: 4.7 deaths/1,000 live births (2020 est.)
country comparison to the world: 181
Life expectancy at birth: total population: 82.8 years
male: 80.7 years
female: 85 years (2020 est.)
country comparison to the world: 12
Total fertility rate: 1.49 children born/woman (2020 est.)
country comparison to the world: 205
Drinking water source:
improved:
urban: 100% of population
rural: 100% of population
total: 100% of population
unimproved:
urban: 0% of population
rural: 0% of population
total: 0% of population (2015 est.)
Current Health Expenditure: 9.3% (2016)
Physicians density: 3.83 physicians/1,000 population (2015)
Hospital bed density: 4.7 beds/1,000 population (2014)
Sanitation facility access:
improved:
urban: 100% of population (2015 est.)
rural: 100% of population (2015 est.)
total: 100% of population (2015 est.)
unimproved:
urban: 0% of population (2015 est.)
rural: 0% of population (2015 est.)
total: 0% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.1% (2016 est.)
country comparison to the world: 126
HIV/AIDS—people living with HIV/AIDS: <500 (2016 est.)
HIV/AIDS—deaths: <100 (2016 est.)
Obesity—adult prevalence rate: 28.9% (2016)
country comparison to the world: 28
Education expenditures: 5.3% of GDP (2015)
country comparison to the world: 50
Literacy: definition: age 15 and over can read and write
total population: 94.5%
male: 93%
female: 96% (2018)
School life expectancy (primary to tertiary education): total: 16
years male: 15 years
female: 16 years (2016)
Unemployment, youth ages 15-24: total: 11.3%
male: 12.2%
female: 10.2% (2017 est.)
country comparison to the world: 115','0a57a9dfd208b81b73615fe2ad6128ec6ad31ae33b59e84a809b83aa66f890c4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc4e6a1f53ec95044ec97d5337273eb467ef76b3a8f102f43d67b30477c21e5a',2020,'FM','Micronesia, Federated States of','people-and-society',738,'Population: 102,436 (July 2020 est.)
country comparison to the world: 194
Nationality: N0un: Micronesian(s)
adjective: Micronesian; Chuukese, Kosraen(s),
Pohnpeian(s), Yapese
Ethnic groups: Chuukese/Mortlockese 49.3%, Pohnpeian
29.8%, Kosraean 6.3%, Yapese 5.7%, Yap outer islanders
5.1%, Polynesian 1.6%, Asian 1.4%, other 0.8% (2010 est.)
Languages: English (official and common language),
Chuukese, Kosrean, Pohnpeian, Yapese, Ulithian, Woleaian,
Nukuoro, Kapingamarangi Religions: Roman Catholic 54.7%,
Protestant 41.1% (includes Congregational 38.5%, Baptist
1.1%, Seventh Day Adventist 0.8%, Assembly of God 0.7%),
Mormon 1.5%, other 1.9%, none 0.7%, unspecified 0.1%
(2010 est.) Age structure: 0-14 years: 28.88% (male
15,046/female 14,542) 15-24 years: 18.94% (male
9,710/female 9,696)
25-54 years: 40.32% (male 19,903/female 21,395)
95-64 years: 7.24% (male 3,572/female 3,842)
65 years and over: 4.62% (male 2,130/female 2,600) (2020
est.)
Dependency ratios: total dependency ratio: 62.4 (2015 est.)
youth dependency ratio: 55.3 (2015 est.)
elderly dependency ratio: 7.1 (2015 est.)
potential support ratio: 14.1 (2015 est.)
Median age: total: 26.3 years
male: 25.5 years
female: 27.1 years (2020 est.)
country comparison to the world: 154
Population growth rate: -0.6% (2020 est.)
country comparison to the world: 227
Birth rate: 18.9 births/1,000 population (2020 est.)
country comparison to the world: 81
Death rate: 4.3 deaths/1,000 population (2020 est.)
country comparison to the world: 211
Net migration rate: -20.9 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 225
Population distribution: the majority of the populaton lives in
the coastal areas of the high islands; the mountainous
interior is largely uninhabited; less than half of the
population lives in urban areas’ Urbanization: urban
population: 22.9% of total population (2020) rate of
urbanization: 1.05% annual rate of change (2015-20 est.)
Major urban areas—population: 7,000 PALIKIR (capital) (2018)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.03 male(s)/female (2020 est.)
15-24 years: 1 male(s)/female (2020 est.)
25-54 years: 0.93 male(s)/female (2020 est.)
55-64 years: 0.93 male(s)/female (2020 est.)
65 years and over: 0.82 male(s)/female (2020 est.)
total population: 96.7 male(s)/female (2020 est.)
Maternal mortality rate: 88 deaths/100,000 live births (2017
est.)
country comparison to the world: 75
Infant mortality rate: total: 17.8 deaths/1,000 live births male:
19.8 deaths/1,000 live births
female: 15.8 deaths/1,000 live births (2020 est.)
country comparison to the world: 84
Life expectancy at birth: total population: 73.9 years
male: 71.8 years
female: 76.1 years (2020 est.)
country comparison to the world: 137
Total fertility rate: 2.29 children born/woman (2020 est.)
country comparison to the world: 85
Drinking water source:
improved:
urban: 94.8% of population
rural: 87.4% of population
total: 89% of population
unimproved:
urban: 5.2% of population
rural: 12.6% of population
total: 11% of population (2015 est.)
Current Health Expenditure: 12.6% (2016)
Physicians density: 0.19 physicians/1,000 population (2009)
Hospital bed density: 3.2 beds/1,000 population (2009)
Sanitation facility access:
improved:
urban: 85.1% of population (2015 est.)
rural: 49% of population (2015 est.)
total: 57.1% of population (2015 est.)
unimproved:
urban: 14.9% of population (2015 est.)
rural: 51% of population (2015 est.)
total: 42.9% of population (2015 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Major infectious diseases: note: active local transmission of
Zika virus by Aedes species mosquitoes has been identified
in this country (as of August 2016); it poses an important
risk (a large number of cases possible) among US citizens if
bitten by an infective mosquito; other less common ways to
get Zika are through sex, via blood transfusion, or during
pregnancy, in which the pregnant woman passes Zika virus
to her fetus Obesity—adult prevalence rate: 45.8% (2016)
country comparison to the world: 10
Education expenditures: 12.5% of GDP (2015)
country comparison to the world: 2
Unemployment, youth ages 15-24: total: 18.9%
male: 10.4%
female: 29.9% (2014)
country comparison to the world: 71','40f14ed9bc4e4ee1e6d4ab79c2b419f96632ac8d467b788a716502a3f2001382','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be9d9248cddcb84a70dd01259021534eb37833f578087ddb882812b06f73bcc3',2020,'NG','Nigeria','people-and-society',815,'Population: 22,772,361 (July 2020 est.)
country comparison to the world: 58
Nationality: Noun: Nigerien(s)
adjective: Nigerien
Ethnic groups: Hausa 53.1%, Zarma/Songhai 21.2%, Tuareg
11%, Fulani (Peuhl) 6.5%, Kanuri 5.9%, Gurma 0.8%, Arab
0.4%, Tubu 0.4%, other/unavailable 0.9% (2006 est.)
Languages: French (official), Hausa, Djerma
Religions: Muslim 99.3%, Christian 0.3%, animist 0.2%, none
0.1% (2012 est.)
Demographic profile: Niger has the highest total fertility rate
(TFR) of any country in the world, averaging close to 7
children per woman in 2016. A slight decline in fertility
over the last few decades has stalled. This leveling off of
the high fertility rate is in large part a product of the
continued desire for large families. In Niger, the TFR is
lower than the desired fertility rate, which makes it
unlikely that contraceptive use will increase. The high TFR
sustains rapid population growth and a large youth
population—almost 70% of the populace is under the age of
25. Gender inequality, including a lack of educational
opportunities for women and early marriage and childbirth,
also contributes to high population growth.
Because of large family sizes, children are inheriting
smaller and smaller parcels of land. The dependence of
most Nigeriens on subsistence farming on increasingly
small landholdings, coupled with declining rainfall and the
resultant shrinkage of arable land, are all preventing food
production from keeping up with population growth.
For more than half a century, Niger’s lack of economic
development has led to steady net outmigration. In the
1960s, Nigeriens mainly migrated to coastal West African
countries to work on a seasonal basis. Some headed to
Libya and Algeria in the 1970s to work in the booming oil
industry until its decline in the 1980s. Since the 1990s, the
principal destinations for Nigerien labor migrants have
been West African countries, especially Burkina Faso and
Cote d''Ivoire, while emigration to Europe and North
America has remained modest. During the same period,
Niger’s desert trade route town Agadez became a hub for
West African and other Sub-Saharan migrants crossing the
Sahara to North Africa and sometimes onward to Europe.
More than 60,000 Malian refugees have fled to Niger
since violence between Malian government troops and
armed rebels began in early 2012. Ongoing attacks by the
Boko Haram Islamist insurgency, dating to 2013 in
northern Nigeria and February 2015 in southeastern Niger,
have pushed tens of thousands of Nigerian refugees and
Nigerien returnees across the border to Niger and to
displace thousands of locals in Niger’s’ already
impoverished Diffa region.
Age structure: 0-14 years: 50.58% (male 5,805,102/female
9,713,815) 15-24 years: 19.99% (male 2,246,670/female
2,306,285)
25-54 years: 23.57% (male 2,582,123/female 2,784,464)
595-64 years: 3.17% (male 357,832/female 364,774)
65 years and over: 2.68% (male 293,430/female 317,866)
(2020 est.)
Dependency ratios: total dependency ratio: 111.6 (2015 est.)
youth dependency ratio: 106.2 (2015 est.)
elderly dependency ratio: 5.4 (2015 est.)
potential support ratio: 18.6 (2015 est.)
Median age: total: 14.8 years
male: 14.5 years
female: 15.1 years (2020 est.)
country comparison to the world: 228
Population growth rate: 3.66% (2020 est.)
country comparison to the world: 2
Birth rate: 47.5 births/1,000 population (2020 est.)
country comparison to the world: 1
Death rate: 10.2 deaths/1,000 population (2020 est.)
country comparison to the world: 35
Net migration rate: -0.7 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 133
Population distribution: Majority of the populace is located in
the southernmost extreme of the country along the border
with Nigeria and Benin Urbanization: urban population:
16.6% of total population (2020) rate of urbanization:
4.27% annual rate of change (2015-20 est.)
Major urban areas—population: 1.292 million NIAMEY (capital)
(2020)
Sex ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1.02 male(s)/female (2020 est.)
15-24 years: 0.97 male(s)/female (2020 est.)
25-54 years: 0.93 male(s)/female (2020 est.)
55-64 years: 0.98 male(s)/female (2020 est.)
65 years and over: 0.92 male(s)/female (2020 est.)
total population: 98.2 male(s)/female (2020 est.)
Mother’s mean age at first birth: 18.1 years (2012 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 509 deaths/100,000 live births (2017
est.)
country comparison to the world: 20
Infant mortality rate: total: 67.7 deaths/1,000 live births
male: 72 deaths/1,000 live births
female: 63.3 deaths/1,000 live births (2020 est.)
country comparison to the world: 6
Life expectancy at birth: total population: 59.3 years
male: 57.8 years
female: 60.8 years (2020 est.)
country comparison to the world: 219
Total fertility rate: 7 children born/woman (2020 est.)
country comparison to the world: 1
Contraceptive prevalence rate: 11% (2018)
Drinking water source:
improved:
urban: 100% of population
rural: 48.6% of population
total: 58.2% of population
unimproved:
urban: 0% of population
rural: 51.4% of population
total: 41.8% of population (2015 est.)
Current Health Expenditure: 6.2% (2016)
Physicians density: 0.05 physicians/1,000 population (2014)
Sanitation facility access:
improved:
urban: 37.9% of population (2015 est.)
rural: 4.6% of population (2015 est.)
total: 10.9% of population (2015 est.)
unimproved:
urban: 62.1% of population (2015 est.)
rural: 95.4% of population (2015 est.)
total: 89.1% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.3% (2018 est.)
country comparison to the world: 93
HIV/AIDS—people living with HIV/AIDS: 36,000 (2018 est.)
country comparison to the world: 70
HIV/AIDS—deaths: 1,200 (2018 est.)
country comparison to the world: 58
Major infectious diseases: degree of risk: very high (2016)
food or waterborne diseases: bacterial and _ protozoal
diarrhea, hepatitis A, and typhoid fever (2016) vectorborne
diseases: malaria and dengue fever (2016)
water contact diseases: schistosomiasis (2016)
animal contact diseases: rabies (2016)
respiratory diseases: meningococcal meningitis (2016)
Obesity—adult prevalence rate: 5.5% (2016)
country comparison to the world: 177
Children under the age of 5 years underweight:
31.4% (2016)
country comparison to the world: 9
Education expenditures: 3.5% of GDP (2017)
country comparison to the world: 123
Literacy: definition: age 15 and over can read and write
total population: 19.1%
male: 27.3%
female: 11% (2015)
School life expectancy (primary to tertiary education): total: 6 years
male: 7 years
female: 6 years (2017)
Unemployment, youth ages 15-24: total: 0.7%
male: 0.9%
female: 0.4% (2014 est.)
country comparison to the world: 180
Population: 214,028,302 (July 2020 est.)
note: estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can result
in lower life expectancy, higher infant mortality, higher
death rates, lower population growth rates, and changes in
the distribution of population by age and sex than would
otherwise be expected country comparison to the world: 6
Nationality: Noun: Nigerian(s)
adjective: Nigerian
Ethnic groups: Hausa 30%, Yoruba 15.5%, Igbo (Ibo) 15.2%,
Fulani 6%, Tiv 2.4%, Kanuri/Beriberi 2.4%, Ibibio 1.8%,
jaw/Izon 1.8%, other 24.7% (2018 est.) note: Nigeria,
Africa’s most populous country, is composed of more than
250 ethnic groups
Languages: English (official), Hausa, Yoruba, Igbo (Ibo),
Fulani, over 500 additional indigenous languages Religions:
Muslim 53.5%, Roman Catholic 10.6%, other Christian
35.3%, other .6% (2018 est.)
Demographic profile: Nigeria’s population is projected to grow
from more than 186 million people in 2016 to 392 million in
2050, becoming the world’s fourth most populous country.
Nigeria’s sustained high population growth rate will
continue for the foreseeable future because of population
momentum and its high birth rate. Abuja has not
successfully implemented family planning programs to
reduce and space births because of a lack of political will,
government financing, and the availability and affordability
of services and products, as well as a cultural preference
for large families. Increased educational attainment,
especially among women, and improvements in health care
are needed to encourage and to better enable parents to
opt for smaller families.
Nigeria needs to harness the potential of its burgeoning
youth population in order to boost economic development,
reduce widespread poverty, and channel large numbers of
unemployed youth into productive activities and away from
ongoing religious and ethnic violence. While most
movement of Nigerians is internal, significant emigration
regionally and to the West provides an outlet for Nigerians
looking for economic opportunities, seeking asylum, and
increasingly pursuing higher education. Immigration
largely of West Africans continues to be insufficient to
offset emigration and the loss of highly skilled workers.
Nigeria also is a major source, transit, and destination
country for forced labor and sex trafficking.
Age structure: 0-14 years: 41.7% (male 45,571,738/female
43,674,769) 15-24 years: 20.27% (male 22,022,660/female
21,358,753)
25-54 years: 30.6% (male 32,808,913/female 32,686,474)
95-64 years: 4.13% (male 4,327,847/female 4,514,264)
65 years and over: 3.3% (male 3,329,083/female 3,733,801)
(2020 est.)
Dependency ratios: total dependency ratio: 88.2 (2015 est.)
youth dependency ratio: 83 (2015 est.)
elderly dependency ratio: 5.1 (2015 est.)
potential support ratio: 19.4 (2015 est.)
Median age: total: 18.6 years
male: 18.4 years
female: 18.9 years (2020 est.)
country comparison to the world: 208
Population growth rate: 2.53% (2020 est.)
country comparison to the world: 23
Birth rate: 34.6 births/1,000 population (2020 est.)
country comparison to the world: 21
Death rate: 9.1 deaths/1,000 population (2020 est.)
country comparison to the world: 59
Net migration rate: -0.2 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 108
Population distribution: largest population of any African
nation; significant population clusters are _ scattered
throughout the country, with the highest density areas
being in the south and southwest Urbanization: urban
population: 52% of total population (2020)
rate of urbanization: 4.23% annual rate of change (2015-20
est.)
Major urban areas—population: 14.368 million Lagos, 3.999
million Kano, 3.552 million Ibadan, 3.278 million ABUJA
(capital), 3.020 million Port Harcourt, 1.727 million Benin
City (2020) Sex ratio: at birth: 1.06 male(s)/female (2020
est.)
0-14 years: 1.04 male(s)/female (2020 est.)
15-24 years: 1.03 male(s)/female (2020 est.)
25-54 years: 1 male(s)/female (2020 est.)
55-64 years: 0.96 male(s)/female (2020 est.)
65 years and over: 0.89 male(s)/female (2020 est.)
total population: 102 male(s)/female (2020 est.)
Mother’s mean age at first birth: 20.3 years (2013 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 9177 deaths/100,000 live births (2017
est.)
country comparison to the world: 4
Infant mortality rate: total: 59.8 deaths/1,000 live births
male: 65.4 deaths/1,000 live births
female: 54 deaths/1,000 live births (2020 est.)
country comparison to the world: 12
Life expectancy at birth: total population: 60.4 years
male: 58.6 years
female: 62.3 years (2020 est.)
country comparison to the world: 217
Total fertility rate: 4.72 children born/woman (2020 est.)
country comparison to the world: 18
Contraceptive prevalence rate: 27.6% (2018)
Drinking water source:
improved:
urban: 80.8% of population
rural: 57.3% of population
total: 68.5% of population
unimproved:
urban: 19.2% of population
rural: 42.7% of population
total: 31.5% of population (2015 est.)
Current Health Expenditure: 3.6% (2016)
Physicians density: 0.38 physicians/1,000 population (2013)
Sanitation facility access:
improved:
urban: 32.8% of population (2015 est.)
rural: 25.4% of population (2015 est.)
total: 29% of population (2015 est.)
unimproved:
urban: 67.2% of population (2015 est.)
rural: 74.6% of population (2015 est.)
total: 71% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 1.5% (2018 est.)
country comparison to the world: 31
HIV/AIDS—people living with HIV/AIDS: 1.9 million (2018 est.)
country comparison to the world: 4
HIV/AIDS—deaths: 53,200 (2017 est.)
country comparison to the world: 4
Major infectious diseases: degree of risk: very high (2016)
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A and E, and typhoid fever (2016)
vectorborne diseases: malaria, dengue fever, and yellow
fever (2016)
water contact diseases: leptospirosis and schistosomiasis
(2016)
animal contact diseases: rabies (2016)
respiratory diseases: meningococcal meningitis (2016)
aerosolized dust or soil contact diseases: Lassa fever
(2016)
note—on 7 October 2019, the Centers for Disease
Control and Prevention issued a Travel Health Notice for a
Yellow Fever outbreak in Nigeria; a large, ongoing
outbreak of yellow fever in Nigeria began in September
2017; the outbreak is now spread throughout the country
with the Nigerian Ministry of Health reporting cases of the
disease in all 36 states and the Federal Capital Territory;
the CDC recommends travelers going to Nigeria should
receive vaccination against yellow fever at least 10 days
before travel and should take steps to prevent mosquito
bites while there; those never vaccinated against yellow
fever should avoid travel to Nigeria during the outbreak
Obesity—adult prevalence rate: 8.9% (2016)
country comparison to the world: 145
Children under the age of 5 years underweight:
31.5% (2016)
country comparison to the world: 8
Education expenditures: NA
Literacy: definition: age 15 and over can read and write
total population: 62%
male: 71.3%
female: 52.7% (2018)
School life expectancy (primary to tertiary education): total: 9 years
male: 9 years
female: 8 years (2011)
Unemployment, youth ages 15-24: total: 12.4%
male: NA
female: NA (2016 est.)
country comparison to the world: 112','c4e9d0f884d74ee05717483f4b79614261f2e87030852bb2b5e6d5ef8f151029','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1c02d0feabb81e0475b484c64fddd88fa7fdfeb23ad5cdd03d9e7d6c88ce7dd',2020,'HU','Hungary','people-and-society',917,'Population: 7,012,165 (July 2020 est.)
note: does not include the population of Kosovo
country comparison to the world: 105
Nationality: NOUN: Serb(s)
adjective: Serbian
Ethnic groups: Serb 83.3%, Hungarian 3.5%, Romani 2.1%,
Bosniak 2%, other 5.7%, undeclared or unknown 3.4%
(2011 est.) note: most ethnic Albanians boycotted the 2011
census; Romani populations are usually underestimated in
official statistics and may represent 5-11% of Serbia’s
population Languages: Serbian (official) 88.1%, Hungarian
3.4%, Bosnian 1.9%, Romani 1.4%, other 3.4%, undeclared
or unknown 1.8% (2011 est.) note: Serbian, Hungarian,
Slovak, Romanian, Croatian, and Ruthenian (Rusyn) are
official in the Autonomous Province of Vojvodina; most
ethnic Albanians boycotted the 2011 census Religions:
Orthodox 84.6%, Catholic 5%, Muslim 3.1%, Protestant 1%,
atheist 1.1%, other 0.8% (includes agnostics, other
Christians, Eastern, Jewish), undeclared or unknown 4.5%
(2011 est.) note: most ethnic Albanians boycotted the 2011
census
Age structure: 0-14 years: 14.07% (male 508,242/female
478,247)
15-24 years: 11.04% (male 399,435/female 374,718)
25-54 years: 41.19% (male 1,459,413/female 1,429,176)
55-64 years: 13.7% (male 464,881/female 495,663)
65 years and over: 20% (male 585,705/female 816,685)
(2020 est.)
Dependency ratios: total dependency ratio: 49.2 (2015 est.)
youth dependency ratio: 24.9 (2015 est.)
elderly dependency ratio: 24.3 (2015 est.)
potential support ratio: 4.1 (2015 est.)
note: data include Kosovo
Median age: total: 43.4 years
male: 41.7 years
female: 45 years (2020 est.)
country comparison to the world: 26
Population growth rate: -0.47% (2020 est.)
country comparison to the world: 224
Birth rate: 8.8 births/1,000 population (2020 est.)
country comparison to the world: 210
Death rate: 13.5 deaths/1,000 population (2020 est.)
country comparison to the world: 6
Net migration rate: 0 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 95
Population distribution: a fairly even distribution throughout
most of the country, with urban areas attracting larger and
denser populations Urbanization: urban population: 56.4% of
total population (2020)
rate of urbanization: -0.07% annual rate of change (2015-
20 est.)
note: data include Kosovo
Major urban areas—population: 1.398 million BELGRADE
(capital) (2020)
Sex ratio: at birth: 1.07 male(s)/female (2020 est.)
0-14 years: 1.06 male(s)/female (2020 est.)
15-24 years: 1.07 male(s)/female (2020 est.)
25-54 years: 1.02 male(s)/female (2020 est.)
55-64 years: 0.94 male(s)/female (2020 est.)
65 years and over: 0.72 male(s)/female (2020 est.)
total population: 95.1 male(s)/female (2020 est.)
Mother’s mean age at first birth: 27.9 years (2014 est.)
note: data do not cover Kosovo or Metohija
Maternal mortality rate: 12 deaths/100,000 live births (2017
est.)
country comparison to the world: 141
Infant mortality rate: total: 5.6 deaths/1,000 live births
male: 6.4 deaths/1,000 live births
female: 4.7 deaths/1,000 live births (2020 est.)
country comparison to the world: 171
Life expectancy at birth: total population: 76.3 years
male: 73.4 years
female: 79.4 years (2020 est.)
country comparison to the world: 99
Total fertility rate: 1.46 children born/woman (2020 est.)
country comparison to the world: 211
Contraceptive prevalence rate: 58.4% (2014)
Drinking water source:
improved:
urban: 99.4% of population
rural: 98.9% of population
total: 99.2% of population
unimproved:
urban: 0.6% of population
rural: 1.1% of population
total: 0.8% of population (2015 est.)
Current Health Expenditure: 9.1% (2016)
Physicians density: 3.13 physicians/1,000 population (2016)
Hospital bed density: 5.7 beds/1,000 population (2012)
Sanitation facility access:
improved:
urban: 98.2% of population (2015 est.)
rural: 94.2% of population (2015 est.)
total: 96.4% of population (2015 est.)
unimproved:
urban: 1.8% of population (2015 est.)
rural: 5.8% of population (2015 est.)
total: 3.6% of population (2015 est.)
HIV/AIDS—adult prevalence rate: <.1% (2018 est.)
HIV/AIDS—people living with HIV/AIDS: 3,000 (2018 est.)
country comparison to the world: 131
HIV/AIDS—deaths: <100 (2018 est.)
Major infectious diseases: degree of risk: intermediate (2016)
food or waterborne diseases: bacterial diarrhea (2016)
Obesity—adult prevalence rate: 21.5% (2016)
country comparison to the world: 88
Children under the age of 5 years underweight:
1.8% (2014)
country comparison to the world: 114
Education expenditures: 4% of GDP (2017)
country comparison to the world: 105
Literacy: definition: age 15 and over can read and write
total population: 98.3%
male: 99.1%
female: 97.5% (2016)
School life expectancy (primary to tertiary education): total: 15
years male: 14 years
female: 15 years (2017)
Unemployment, youth ages 15-24: total: 29.7%
male: 28.3%
female: 32% (2018 est.)
country comparison to the world: 31','f9e56ab527f34d73ed11274edd45e50bde7688e44f752049725d9d79bfb9559b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40d339b6930e102ff245191879c70551251b8b93e5a1056204409dae4b509287',2020,'HR','Croatia','people-and-society',928,'Population: 2,102,678 (July 2020 est.)
country comparison to the world: 148
Nationality: Noun: Slovene(s)
adjective: Slovenian
Ethnic groups: Slovene 83.1%, Serb 2%, Croat 1.8%, Bosniak
1.1%, other or unspecified 12% (2002 est.) Languages:
Slovene (official) 91.1%, Serbo-Croatian 4.5%, other or
unspecified 4.4%, Italian (official, only in municipalities
where Italian national communities reside), Hungarian
(official, only in municipalities where Hungarian national
communities reside) (2002 census) Religions: Catholic
57.8%, Muslim 2.4%, Orthodox 2.3%, other Christian 0.9%,
unaffiliated 3.5%, other or unspecified 23%, none 10.1%
(2002 est.) Age structure: 0-14 years: 14.84% (male
160,134/female 151,960) 15-24 years: 9.01% (male
98,205/female 91,318)
25-54 years: 40.73% (male 449,930/female 406,395)
595-64 years: 14.19% (male 148,785/female 149,635)
65 years and over: 21.23% (male 192,420/female 253,896)
(2020 est.)
Dependency ratios: total dependency ratio: 48.7 (2015 est.)
youth dependency ratio: 21.9 (2015 est.)
elderly dependency ratio: 26.8 (2015 est.)
potential support ratio: 3.7 (2015 est.)
Median age: total: 44.9 years
male: 43.4 years
female: 46.6 years (2020 est.)
country comparison to the world: 11
Population growth rate: 0.01% (2020 est.)
country comparison to the world: 191
Birth rate: 8.7 births/1,000 population (2020 est.)
country comparison to the world: 212
Death rate: 10.3 deaths/1,000 population (2020 est.)
country comparison to the world: 32
Net migration rate: 1.5 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 55
Population distribution: a fairly even distribution throughout
most of the country, with urban areas attracting larger and
denser populations; pockets in the mountainous northwest
exhibit less density than elsewhere Urbanization: urban
population: 55.1% of total population (2020) rate of
urbanization: 0.56% annual rate of change (2015-20 est.)
Major urban areas—population: 286,000 LJUBLJANA (capital)
(2018)
Sex ratio: at birth: 1.04 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.08 male(s)/female (2020 est.)
25-54 years: 1.11 male(s)/female (2020 est.)
55-64 years: 0.99 male(s)/female (2020 est.)
65 years and over: 0.76 male(s)/female (2020 est.)
total population: 99.6 male(s)/female (2020 est.)
Mother’s mean age at first birth: 29.1 years (2014 est.)
Maternal mortality rate: 7 deaths/100,000 live births (2017
est.)
country comparison to the world: 156
Infant mortality rate: total: 1.7 deaths/1,000 live births
male: 1.8 deaths/1,000 live births
female: 1.6 deaths/1,000 live births (2020 est.)
country comparison to the world: 228
Life expectancy at birth: total population: 81.4 years male: 78.5
years
female: 84.4 years (2020 est.)
country comparison to the world: 32
Total fertility rate: 1.59 children born/woman (2020 est.)
country comparison to the world: 188
Drinking water source:
improved:
urban: 99.7% of population
rural: 99.4% of population
total: 99.5% of population
unimproved:
urban: 0.3% of population
rural: 0.6% of population
total: 0.5% of population (2015 est.)
Current Health Expenditure: 8.5% (2016)
Physicians density: 2.81 physicians/1,000 population (2015)
Hospital bed density: 4.6 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 99.1% of population (2015 est.)
rural: 99.1% of population (2015 est.)
total: 99.1% of population (2015 est.)
unimproved:
urban: 0.9% of population (2015 est.)
rural: 0.9% of population (2015 est.)
total: 0.9% of population (2015 est.)
HIV/AIDS—adult prevalence rate: <.1% (2018 est.)
HIV/AIDS—people living with HIV/AIDS: <1000 (2017 est.)
HIV/AIDS—deaths: <100 (2018 est.)
Obesity—adult prevalence rate: 20.2% (2016)
country comparison to the world: 104
Education expenditures: 4.8% of GDP (2016)
country comparison to the world: 75
Literacy: definition: NA
total population: 99.7%
male: 99.7%
female: 99.7% (2015)
School life expectancy (primary to tertiary education): total: 17
years male: 17 years
female: 18 years (2016)
Unemployment, youth ages 15-24: total: 11.2%
male: 9.9%
female: 13% (2017 est.)
country comparison to the world: 116','7d7964c97b38cf1b7971025d3c914fb450595c3587e09143eff149eeeccbd2dd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6f24db8dabe9063ed278b341e232a55b766d3f857289721325c19d09ce88bfe',2020,'SI','Slovenia','people-and-society',937,'Population: 685,097 (July 2020 est.)
country comparison to the world: 167
Nationality: N0un: Solomon Islander(s)
adjective: Solomon Islander
Ethnic groups: Melanesian 95.3%, Polynesian 3.1%,
Micronesian 1.2%, other 0.3% (2009 est.)
Languages: Melanesian pidgin (in much of the country is
lingua franca), English (official but spoken by only 1%-2%
of the population), 120 indigenous languages Religions:
Protestant 73.4% (Church of Melanesia 31.9%, South Sea
Evangelical 17.1%, Seventh Day Adventist 11.7%, United
Church 10.1%, Christian Fellowship Church 2.5%), Roman
Catholic 19.6%, other Christian 2.9%, other 4%,
unspecified 0.1% (2009 est.) Age structure: 0-14 years:
32.99% (male 116,397/female 109,604)
15-24 years: 19.82% (male 69,914/female 65,874)
25-54 years: 37.64% (male 131,201/female 126,681)
595-64 years: 5.04% (male 17,844/female 16,704)
65 years and over: 4.51% (male 14,461/female 16,417)
(2020 est.)
Dependency ratios: total dependency ratio: 75.4 (2015 est.)
youth dependency ratio: 69.4 (2015 est.)
elderly dependency ratio: 6 (2015 est.)
potential support ratio: 16.6 (2015 est.)
Median age: total: 23.5 years
male: 23.2 years
female: 23.7 years (2020 est.)
country comparison to the world: 176
Population growth rate: 1.84% (2020 est.)
country comparison to the world: 56
Birth rate: 23.6 births/1,000 population (2020 est.)
country comparison to the world: 53
Death rate: 3.8 deaths/1,000 population (2020 est.)
country comparison to the world: 217
Net migration rate: -1.6 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 157
Population distribution: most of the population lives along the
coastal regions; about one in five live in urban areas, and of
these some two-thirds reside in Honiara, the largest town
and chief port Urbanization: urban population: 24.7% of total
population (2020) rate of urbanization: 3.91% annual rate
of change (2015-20 est.)
Major urban areas—population: 82,000 HONIARA (capital)
(2018)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.06 male(s)/female (2020 est.)
15-24 years: 1.06 male(s)/female (2020 est.)
25-54 years: 1.04 male(s)/female (2020 est.)
55-64 years: 1.07 male(s)/female (2020 est.)
65 years and over: 0.88 male(s)/female (2020 est.)
total population: 104.3 male(s)/female (2020 est.)
Mother’s mean age at first birth: 22.6 years (2015 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 104 deaths/100,000 live births (2017
est.)
country comparison to the world: 69
Infant mortality rate: total: 13.4 deaths/1,000 live births
male: 15.3 deaths/1,000 live births
female: 11.4 deaths/1,000 live births (2020 est.)
country comparison to the world: 102
Life expectancy at birth: total population: 76.2 years
male: 73.5 years
female: 79 years (2020 est.)
country comparison to the world: 103
Total fertility rate: 2.97 children born/woman (2020 est.)
country comparison to the world: 52
Contraceptive prevalence rate: 29.3% (2015)
Drinking water source:
improved:
urban: 93.2% of population
rural: 77.2% of population
total: 80.8% of population
unimproved:
urban: 6.8% of population
rural: 22.8% of population
total: 19.2% of population (2015 est.)
Current Health Expenditure: 5.2% (2016)
Physicians density: 0.2 physicians/1,000 population (2016)
Hospital bed density: 1.4 beds/1,000 population (2012)
Sanitation facility access:
improved:
urban: 81.4% of population (2015 est.)
rural: 15% of population (2015 est.)
total: 29.8% of population (2015 est.)
unimproved:
urban: 18.6% of population (2015 est.)
rural: 85% of population (2015 est.)
total: 70.2% of population (2015 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Obesity—adult prevalence rate: 22.5% (2016)
country comparison to the world: 76
Children under the age of 5 years underweight:
16.2% (2015)
country comparison to the world: 39
Education expenditures: 9.9% of GDP (2010)
country comparison to the world: 3
Literacy:
Unemployment, youth ages 15-24: total: 1.3%
male: 1%
female: 1.6% (2013)
country comparison to the world: 176','7b61869c3c5094741a4b8d104206dab691ad2161f702d111bca98a782211bde0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e73474e3ba5078c81fa9e39de4d594bd2ccbd8a0e1d4abee77a98450acdce49d',2020,'SO','Somalia','people-and-society',942,'Population: 56,463,617 (July 2020 est.)
note: estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can result
in lower life expectancy, higher infant mortality, higher
death rates, lower population growth rates, and changes in
the distribution of population by age and sex than would
otherwise be expected country comparison to the world: 26
Nationality: N0un: South African(s)
adjective: South African
Ethnic groups: black African 80.9%, colored 8.8%, white
7.8%, Indian/Asian 2.5% (2018 est.)
note: colored is a term used in South Africa, including on
the national census, for persons of mixed race ancestry
who developed a distinct cultural identity over several
hundred years Languages: isiZulu (official) 24.7%, isixhosa
(official) 15.6%, Afrikaans (official) 12.1%, Sepedi (official)
9.8%, Setswana (official) 8.9%, English (official) 8.4%,
Sesotho (official) 8%, Xitsonga (official) 4%, siSwati
(official) 2.6%, Tshivenda (official) 2.5%, isiNdebele
(official) 1.6%, other (includes Khoi, Nama, and San
languages) 1.9% (2017 est.) note: data represent language
spoken most often at home
Religions: Christian 86%, ancestral, tribal, animist, or other
traditional African religions 5.4%, Muslim 1.9%, other
1.5%, nothing in particular 5.2% (2015 est.) Demographic
profile: South Africa’s youthful population is gradually aging,
as the country’s total fertility rate (TFR) has declined
dramatically from about 6 children per woman in the 1960s
to roughly 2.2 in 2014. This pattern is similar to fertility
trends in South Asia, the Middle East, and North Africa,
and sets South Africa apart from the rest of Sub-Saharan
Africa, where the average TFR remains higher than other
regions of the world. Today, South Africa’s decreasing
number of reproductive age women is having fewer
children, as women increase their educational attainment,
workforce participation, and use of family planning
methods; delay marriage; and opt for smaller families.
As the proportion of working-age South Africans has
grown relative to children and the elderly, South Africa has
been unable to achieve a demographic dividend because
persistent high unemployment and the prevalence of
HIV/AIDs have created a larger-than-normal dependent
population. HIV/AIDS was also responsible for South
Africa’s average life expectancy plunging to less than 43
years in 2008; it has rebounded to 63 years as of 2017.
HIV/AIDS continues to be a serious public health threat,
although awareness-raising campaigns and the wider
availability of anti-retroviral drugs is stabilizing the number
of new cases, enabling infected individuals to live longer,
healthier lives, and reducing mother-child transmissions.
Migration to South Africa began in the second half of the
17th century when traders from the Dutch East India
Company settled in the Cape and started using slaves from
South and southeast Asia (mainly from India but also from
present-day Indonesia, Bangladesh, Sri Lanka, and
Malaysia) and southeast Africa (Madagascar and
Mozambique) as farm laborers and, to a lesser extent, as
domestic servants. The Indian subcontinent remained the
Cape Colony’s main source of slaves in the early 18th
century, while slaves were increasingly obtained from
southeast Africa in the latter part of the 18th century and
into the 19th century under British rule.
After slavery was completely abolished in the British
Empire in 1838, South Africa’s colonists turned to
temporary African migrants and indentured labor through
agreements with India and later China, countries that were
anxious to export workers to alleviate domestic poverty and
overpopulation. Of the more than 150,000 indentured
Indian laborers hired to work in Natal’s sugar plantations
between 1860 and 1911, most exercised the right as British
subjects to remain permanently (a small number of Indian
immigrants came freely as merchants). Because of growing
resentment toward Indian workers, the 63,000 indentured
Chinese workers who mined gold in Transvaal between
1904 and 1911 were under more restrictive contracts and
generally were forced to return to their homeland.
In the late 19th century and nearly the entire 20th
century, South Africa’s then British colonies’ and Dutch
states’ enforced selective immigration policies that
welcomed “assimilable” white Europeans as permanent
residents but excluded or restricted other immigrants.
Following the Union of South Africa’s passage of a law in
1913 prohibiting Asian and other non-white immigrants
and its elimination of the indenture system in 1917,
temporary African contract laborers from neighboring
countries became the dominant source of labor in the
burgeoning mining industries. Others worked in agriculture
and smaller numbers in manufacturing, domestic service,
transportation, and construction. Throughout the 20th
century, at least 40% of South Africa’s miners were
foreigners; the numbers peaked at over 80% in the late
1960s. Mozambique, Lesotho, Botswana, and Eswatini were
the primary sources of miners, and Malawi and Zimbabwe
were periodic suppliers.
Under apartheid, a “two gates” migration policy focused
on policing and deporting illegal migrants rather than on
Managing migration to meet South Africa’s development
needs. The exclusionary 1991 Aliens Control Act limited
labor recruitment to the highly skilled as defined by the
ruling white minority, while bilateral labor agreements
provided exemptions that enabled the influential mining
industry and, to a lesser extent, commercial farms, to hire
temporary, low-paid workers from neighboring states.
Illegal African migrants were often tacitly allowed to work
for low pay in other sectors but were always under threat
of deportation.
The abolishment of apartheid in 1994 led to the
development of a new inclusive national identity and the
strengthening of the country’s restrictive immigration
policy. Despite South Africa’s protectionist approach to
immigration, the downsizing and closing of mines, and
rising unemployment, migrants from across the continent
believed that the country held work opportunities. Fewer
African labor migrants were issued temporary work
permits and, instead, increasingly entered South Africa
with visitors’ permits or came illegally, which drove growth
in cross-border trade and the informal job market. A new
wave of Asian immigrants has also arrived over the last two
decades, many operating small retail businesses.
In the post-apartheid period, increasing numbers of highly
skilled white workers emigrated, citing dissatisfaction with
the political situation, crime, poor services, and a reduced
quality of life. The 2002 Immigration Act and later
amendments were intended to facilitate the temporary
migration of skilled foreign labor to fill labor shortages, but
instead the legislation continues to create regulatory
obstacles. Although the education system has improved and
brain drain has slowed in the wake of the 2008 global
financial crisis, South Africa continues to face skills
shortages in several key sectors, such as health care and
technology.
South Africa’s stability and economic growth has acted
as a magnet for refugees and asylum seekers from nearby
countries, despite the prevalence of discrimination and
xenophobic violence. Refugees have included an estimated
350,000 Mozambicans during its 1980s civil war and, more
recently, several thousand Somalis, Congolese, and
Ethiopians. Nearly all of the tens of thousands of
Zimbabweans who have applied for asylum in South Africa
have been categorized as economic migrants and denied
refuge.
Age structure: 0-14 years: 27.94% (male 7,894,742/female
7,883,266)
15-24 years: 16.8% (male 4,680,587/female 4,804,337)
25-54 years: 42.37% (male 12,099,441/female 11,825,193)
95-64 years: 6.8% (male 1,782,902/female 2,056,988)
65 years and over: 6.09% (male 1,443,956/female
1,992,205) (2020 est.)
Dependency ratios: total dependency ratio: 52.5 (2015 est.)
youth dependency ratio: 44.8 (2015 est.)
elderly dependency ratio: 7.7 (2015 est.)
potential support ratio: 12.9 (2015 est.)
Median age: total: 28 years
male: 27.9 years
female: 28.1 years (2020 est.)
country comparison to the world: 142
Population growth rate: 0.97% (2020 est.)
country comparison to the world: 108
Birth rate: 19.2 births/1,000 population (2020 est.)
country comparison to the world: 78
Death rate: 9.3 deaths/1,000 population (2020 est.)
country comparison to the world: 50
Net migration rate: -0.2 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 110
Population distribution: the population concentrated along the
southern and southeastern coast, and inland around
Pretoria; the eastern half of the country is more densly
populated than the west Urbanization: urban population:
67.4% of total population (2020) rate of urbanization:
1.97% annual rate of change (2015-20 est.)
Major urban areas—population: 9.677 million Johannesburg
(includes Ekurhuleni), 4.618 million Cape Town (legislative
capital), 3.158 million Durban, 2.566 million PRETORIA
(administrative capital), 1.254 million Port Elizabeth,
898,000 West Rand (2020) Sex ratio: at birth: 1.02
male(s)/female (2020 est.)
0-14 years: 1 male(s)/female (2020 est.)
15-24 years: 0.97 male(s)/female (2020 est.)
25-54 years: 1.02 male(s)/female (2020 est.)
55-64 years: 0.87 male(s)/female (2020 est.)
65 years and over: 0.72 male(s)/female (2020 est.)
total population: 97.7 male(s)/female (2020 est.)
Maternal mortality rate: 119 deaths/100,000 live births (2017
est.)
country comparison to the world: 66
Infant mortality rate: total: 27.8 deaths/1,000 live births
male: 31 deaths/1,000 live births
female: 24.6 deaths/1,000 live births (2020 est.)
country comparison to the world: 63
Life expectancy at birth: total population: 64.8 years
male: 63.4 years
female: 66.2 years (2020 est.)
country comparison to the world: 198
Total fertility rate: 2.22 children born/woman (2020 est.)
country comparison to the world: 91
Contraceptive prevalence rate: 54.6% (2016)
Drinking water source:
improved:
urban: 99.6% of population
rural: 81.4% of population
total: 93.2% of population
unimproved:
urban: 0.4% of population
rural: 18.6% of population
total: 6.8% of population (2015 est.)
Current Health Expenditure: 8.1% (2016)
Physicians density: 0.91 physicians/1,000 population (2017)
Sanitation facility access:
improved:
urban: 69.6% of population (2015 est.)
rural: 60.5% of population (2015 est.)
total: 66.4% of population (2015 est.)
unimproved:
urban: 30.4% of population (2015 est.)
rural: 39.5% of population (2015 est.)
total: 33.6% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 20.4% (2018 est.)
country comparison to the world: 3
HIV/AIDS—people living with HIV/AIDS: 7.7 million (2018 est.)
Country comparison to the world: 1
HIV/AIDS—deaths: 71,000 (2018 est.)
country comparison to the world: 1
Major infectious diseases: degree of risk: intermediate (2016)
food or waterborne diseases: bacterial diarrhea, hepatitis
A, and typhoid fever (2016)
water contact diseases: schistosomiasis (2016)
Obesity—adult prevalence rate: 28.3% (2016)
country comparison to the world: 31
Children under the age of 5 years underweight:
5.9% (2016)
country comparison to the world: 78
Education expenditures: 6.2% of GDP (2018)
country comparison to the world: 29
Literacy: definition: age 15 and over can read and write
total population: 87%
male: 87.7%
female: 86.5% (2017)
School life expectancy (primary to tertiary education): total: 14
years
male: 13 years
female: 14 years (2016)
Unemployment, youth ages 15-24: total: 53.4%
male: 49.2%
female: 58.8% (2018 est.)
country comparison to the world: 2','167aba3fc0f75bd97855f54c4254dff166285d08a69e9e784359f6ec91aff77c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e883618d409319f4cc39c31ef6b61d83ac3de600ff182b0a5abe024bdc6d253',2020,'LK','Sri Lanka','people-and-society',968,'Population: 45,561,556 (July 2020 est.)
country comparison to the world: 31
Nationality: NOUN: Sudanese (singular and plural) adjective:
Sudanese
Ethnic groups: unspecified Sudanese Arab (approximately
70%), Fur, Beja, Nuba, Fallata Languages: Arabic (official),
English (official), Nubian, Ta Bedawie, Fur Religions: Sunni
Muslim, small Christian minority
Age structure: 0-14 years: 42.01% (male 9,726,937/female
9,414,988) 15-24 years: 20.94% (male 4,852,903/female
4,687,664)
25-54 years: 29.89% (male 6,633,567/female 6,986,241)
55-64 years: 4.13% (male 956,633/female 923,688)
65 years and over: 3.03% (male 729,214/female 649,721)
(2020 est.)
Dependency ratios: total dependency ratio: 81.6 (2015 est.)
youth dependency ratio: 75.4 (2015 est.)
elderly dependency ratio: 6.3 (2015 est.)
potential support ratio: 15.9 (2015 est.)
Median age: total: 18.3 years
male: 18.1 years
female: 18.5 years (2020 est.)
country comparison to the world: 212
Population growth rate: 2.69% (2020 est.)
country comparison to the world: 17
Birth rate: 33.8 births/1,000 population (2020 est.)
country comparison to the world: 23
Death rate: 6.5 deaths/1,000 population (2020 est.)
country comparison to the world: 144
Net migration rate: -0.4 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 125
Population distribution: with the exception of a ribbon of
settlement that corresponds to the banks of the Nile,
northern Sudan, which extends into the dry Sahara, is
sparsely populated; more abundant vegetation and broader
access to water increases population distribution in the
south extending habitable range along nearly the entire
border with South Sudan; sizeable areas of population are
found around Khartoum, southeast between the Blue and
White Nile Rivers, and througout South Darfur urbanization:
urban population: 35.3% of total population (2020) rate of
urbanization: 3.17% annual rate of change (2015-20 est.)
Major urban areas—population: 5.829 million KHARTOUM
(capital), 923,000 Nyala (2020) Sex ratio: at birth: 1.05
male(s)/female (2020 est.) 0-14 years: 1.03 male(s)/female
(2020 est.)
15-24 years: 1.04 male(s)/female (2020 est.)
25-54 years: 0.95 male(s)/female (2020 est.)
55-64 years: 1.04 male(s)/female (2020 est.)
65 years and over: 1.12 male(s)/female (2020 est.)
total population: 101 male(s)/female (2020 est.)
Maternal mortality rate: 295 deaths/100,000 live births (2017
est.) country comparison to the world: 38
Infant mortality rate: total: 41.8 deaths/1,000 live births male:
46.7 deaths/1,000 live births
female: 36.6 deaths/1,000 live births (2020 est.)
country comparison to the world: 35
Life expectancy at birth: total population: 66.5 years male: 64.3
years
female: 68.8 years (2020 est.)
country comparison to the world: 186
Total fertility rate: 4.72 children born/woman (2020 est.)
country comparison to the world: 19
Contraceptive prevalence rate: 12.2% (2014)
Drinking water source:
improved:
urban: 66% of population
rural: 50.2% of population
total: 55.5% of population
unimproved:
urban: 34% of population
rural: 49.8% of population
total: 44.5% of population (2012 est.)
Current Health Expenditure: 5.7% (2016)
Physicians density: 0.41 physicians/1,000 population (2015)
Hospital bed density: 0.8 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 43.9% of population (2012 est.)
rural: 13.4% of population (2012 est.)
total: 23.6% of population (2012 est.)
unimproved:
urban: 56.1% of population (2012 est.)
rural: 86.6% of population (2012 est.)
total: 76.4% of population (2012 est.)
HIV/AIDS—adult prevalence rate: 0.2% (2018 est.)
country comparison to the world: 112
HIV/AIDS—people living with HIV/AIDS: 59,000 (2018 est.)
country comparison to the world: 58
HIV/AIDS—deaths: 2,900 (2018 est.)
country comparison to the world: 37
Major infectious diseases: degree of risk: very high (2016) food
or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A and E, and typhoid fever (2016) vectorborne
diseases: malaria, dengue fever, and Rift Valley fever
(2016) water contact diseases: schistosomiasis (2016)
animal contact diseases: rabies (2016)
respiratory diseases: meningococcal meningitis (2016)
Obesity—adult prevalence rate: 6.6% (2014)
country comparison to the world: 166
Children under the age of 5 years underweight:
33.5% (2014)
country comparison to the world: 5
Education expenditures: 2.2% of GDP (2009)
country comparison to the world: 166
Literacy: definition: age 15 and over can read and write total
population: 60.7%
male: 65.4%
female: 56.1% (2018)
School life expectancy (primary to tertiary education): total: 8 years
male: 8 years
female: 7 years (2015)
Unemployment, youth ages 15-24: total: 20%
male: 16%
female: 32% (2009 est.)
country comparison to the world: 69','596639fbaf91880d46759d26d12e9a173df00438058599d902006ba9ac69d327','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2906b62f832007ca6e1498130bd8930eedc9e74b1c4a02c3bdacf0dcaaf1a41a',2020,'JE','Jersey','people-and-society',981,'Population: 23,603,049 (July 2020 est.)
country comparison to the world: 56
Nationality: Noun: Taiwan (singular and plural)
adjective: Taiwan (or Taiwanese)
note: example—he or she is from Taiwan; they are from
Taiwan
Ethnic groups: Han Chinese (including Hoklo, who compose
approximately 70% of Taiwan’s population, Hakka, and
other groups originating in mainland China) more than
95%, indigenous Malayo-Polynesian peoples 2.3%
note 1: there are 16 officially recognized indigenous
groups: Amis, Atayal, Bunun, Hla’alua, Kanakaravu,
Kavalan, Paiwan, Puyuma, Rukai, Saisiyat, Sakizaya,
Seediq, Thao, Truku, Tsou, and Yami; Amis, Paiwan, and
Atayal are the largest and account for roughly 70% of the
indigenous population note 2: although not definitive, the
majority of current genetic, archeological, and linguistic
data support the theory that Taiwan is the ultimate source
for the spread of humans across the Pacific to Polynesia;
the expansion (ca. 3000 B.C. to A.D. 1200) took place via
the Philippines and eastern Indonesia and reached Fiji and
Tonga by about 900 B.C.; from there voyagers spread
across all of the rest of the Pacific islands over the next two
millennia Languages: Mandarin Chinese (official), Taiwanese
(Min Nan), Hakka dialects, approximately 16 indigenous
languages Religions: Buddhist 35.3%, Taoist 33.2%, Christian
3.9%, folk (includes Confucian) approximately 10%, none or
unspecified 18.2% (2005 est.) Age structure: 0-14 years:
12.42% (male 1,504,704/female 1,426,494)
15-24 years: 11.62% (male 1,403,117/female 1,339,535)
25-54 years: 45.51% (male 5,351,951/female 5,389,112)
595-64 years: 14.73% (male 1,698,555/female 1,778,529)
65 years and over: 15.72% (male 1,681,476/female
2,029,576) (2020 est.)
Dependency ratios: total dependency ratio: 40
youth dependency ratio: 17.8
elderly dependency ratio: 22.2
potential support ratio: 4.5 (2020 est.)
Median age: total: 42.3 years
male: 41.5 years
female: 43.1 years (2020 est.)
country comparison to the world: 36
Population growth rate: 0.11% (2020 est.)
country comparison to the world: 187
Birth rate: 8 births/1,000 population (2020 est.)
country comparison to the world: 223
Death rate: 7.9 deaths/1,000 population (2020 est.)
country comparison to the world: 97
Net migration rate: 0.8 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 64
Population distribution: distribution exhibits a _ peripheral
coastal settlement pattern, with the largest populations on
the north and west coasts Urbanization: urban population:
78.9% of total population (2020)
rate of urbanization: 0.8% annual rate of change (2015-20
est.)
Major urban areas—population: 4.398 million New Taipei City,
2.721 million TAIPEI (capital), 2.245 million Taoyuan, 1.538
million Kaohsiung, 1.321 million Taichung, 850,000 Tainan
(2020) Sex ratio: at birth: 1.06 male(s)/female (2020 est.)
0-14 years: 1.05 male(s)/female (2020 est.)
15-24 years: 1.05 male(s)/female (2020 est.)
25-54 years: 0.99 male(s)/female (2020 est.)
55-64 years: 0.96 male(s)/female (2020 est.)
65 years and over: 0.83 male(s)/female (2020 est.)
total population: 97.3 male(s)/female (2020 est.)
Infant mortality rate: total: 4.2 deaths/1,000 live births
male: 4.6 deaths/1,000 live births
female: 3.8 deaths/1,000 live births (2020 est.)
country comparison to the world: 188
Life expectancy at birth: total population: 80.6 years
male: 77.5 years
female: 83.9 years (2020 est.)
country comparison to the world: 43
Total fertility rate: 1.14 children born/woman (2020 est.)
country comparison to the world: 226
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Education expenditures: NA
Literacy: definition: age 15 and over can read and write
total population: 98.5%
male: 99.7%
female: 97.3% (2014)
Population: 8,873,669 (July 2020 est.)
country comparison to the world: 96
Nationality: Noun: Tajikistani(s)
adjective: Tajikistani
Ethnic groups: Tajik 84.3% (includes Pamiri and Yagnobi),
Uzbek 13.8%, other 2% (includes Kyrgyz, Russian,
Turkmen, Tatar, Arab) (2014 est.) Languages: Tajik (official)
84.4%, Uzbek 11.9%, Kyrgyz .8%, Russian .5%, other 2.4%
(2010 est.)
note: Russian widely used in government and business
Religions: Muslim 98% (Sunni 95%, Shia 3%) other 2% (2014
est.)
Age structure: 0-14 years: 31.43% (male 1,420,271/female
1,368,445)
15-24 years: 18.13% (male 816,658/female 792,231)
25-54 years: 40.58% (male 1,789,271/female 1,811,566)
55-64 years: 6.23% (male 253,862/female 299,378)
65 years and over: 3.63% (male 132,831/female 189,156)
(2020 est.)
Dependency ratios: total dependency ratio: 62.5 (2015 est.)
youth dependency ratio: 57.1 (2015 est.)
elderly dependency ratio: 5.4 (2015 est.)
potential support ratio: 18.5 (2015 est.)
Median age: total: 25.3 years
male: 24.6 years
female: 26 years (2020 est.)
country comparison to the world: 162
Population growth rate: 1.52% (2020 est.)
country comparison to the world: 69
Birth rate: 21.8 births/1,000 population (2020 est.)
country comparison to the world: 68
Death rate: 5.8 deaths/1,000 population (2020 est.)
country comparison to the world: 176
Net migration rate: -1.1 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 146
Population distribution: the country’s population is
concentrated at lower elevations, with perhaps as much as
90% of the people living in valleys; overall density
increases from east to west Urbanization: urban population:
27.5% of total population (2020)
rate of urbanization: 2.62% annual rate of change (2015-20
est.)
Major urban areas—population: 916,000 DUSHANBE (capital)
(2020)
Sex ratio: at birth: 1.05 male(s)/female (2020 est.)
0-14 years: 1.04 male(s)/female (2020 est.)
15-24 years: 1.03 male(s)/female (2020 est.)
25-54 years: 0.99 male(s)/female (2020 est.)
55-64 years: 0.85 male(s)/female (2020 est.)
65 years and over: 0.7 male(s)/female (2020 est.)
total population: 98.9 male(s)/female (2020 est.)
Mother’s mean age at first birth: 22 years (2017 est.)
note: median age at first birth among women 25-29
Maternal mortality rate: 177 deaths/100,000 live births (2017
est.)
country comparison to the world: 132
Infant mortality rate: total: 28.8 deaths/1,000 live births
male: 32.7 deaths/1,000 live births
female: 24.8 deaths/1,000 live births (2020 est.)
country comparison to the world: 59
Life expectancy at birth: total population: 69 years male: 65.9
years
female: 72.3 years (2020 est.)
country comparison to the world: 174
Total fertility rate: 2.51 children born/woman (2020 est.)
country comparison to the world: 73
Contraceptive prevalence rate: 29.3% (2017)
Drinking water source:
improved:
urban: 93.1% of population
rural: 66.7% of population
total: 73.8% of population
unimproved:
urban: 6.9% of population
rural: 33.3% of population
total: 26.2% of population (2015 est.)
Current Health Expenditure: 7% (2016)
Physicians density: 1.7 physicians/1,000 population (2014)
Hospital bed density: 4.8 beds/1,000 population (2013)
Sanitation facility access:
improved:
urban: 93.8% of population (2015 est.)
rural: 95.5% of population (2015 est.)
total: 95% of population (2015 est.)
unimproved:
urban: 6.2% of population (2015 est.)
rural: 4.5% of population (2015 est.)
total: 5% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 0.2% (2018 est.)
country comparison to the world: 114
HIV/AIDS—people living with HIV/AIDS: 13,000 (2018 est.)
country comparison to the world: 95
HIV/AIDS—deaths: <500 (2018 est.)
Major infectious diseases: degree of risk: high (2016)
food or waterborne diseases: bacterial diarrhea, hepatitis
A, and typhoid fever (2016)
vectorborne diseases: malaria (2016)
Obesity—adult prevalence rate: 14.2% (2016)
country comparison to the world: 128
Children under the age of 5 years underweight:
7.6% (2017)
country comparison to the world: 71
Education expenditures: 5.2% of GDP (2015)
country comparison to the world: 57
Literacy: definition: age 15 and over can read and write
total population: 99.8%
male: 99.8%
female: 99.7% (2015)
School life expectancy (primary to tertiary education): total: 11
years
male: 12 years
female: 11 years (2013)
Unemployment, youth ages 15-24: total: 16.7%
male: 19.2%
female: 13.7% (2009 est.)
country comparison to the world: 82','511b8ae1306c8194df6860bac92765e68335d7b55c219076d49c33b4974f9b7d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe996d279c9aa3725b3b94136075f93cda13889f3ed53d64e5821544667d8fc3',2020,'TT','Trinidad and Tobago','people-and-society',993,'Population: 1,208,789 (July 2020 est.)
country comparison to the world: 159
Nationality: Noun: Trinidadian(s), Tobagonian(s)
adjective: Trinidadian, Tobagonian
note: Trinbagonian is used on occasion to describe a citizen
of the country without specifying the island of origin Ethnic
groups: East Indian 35.4%, African descent 34.2%, mixed—
other 15.3%, mixed—African/East Indian 7.7%, other 1.3%,
unspecified 6.2% (2011 est.) Languages: English (official),
Trinidadian Creole English, Tobagonian Creole English,
Caribbean Hindustani (a dialect of Hindi), Trinidadian
Creole French, Spanish, Chinese Religions: Protestant 32.1%
(Pentecostal/Evangelical/Full Gospel 12%, Baptist 6.9%,
Anglican ay iy Seventh-Day Adventist 4.1%,
Presbyterian/Congregational 2.5%, other Protestant 0.9%),
Roman Catholic 21.6%, Hindu 18.2%, Muslim 5%,
Jehovah’s Witness 1.5%, other 8.4%, none 2.2%,
unspecified 11.1% (2011 est.) Age structure: 0-14 years:
19.01% (male 116,953/female 112,805)
15-24 years: 11.28% (male 70,986/female 65,389)
25-54 years: 43.77% (male 276,970/female 252,108)
95-64 years: 13.83% (male 83,650/female 83,585)
65 years and over: 12.11% (male 64,092/female 82,251)
(2020 est.)
Dependency ratios: total dependency ratio: 43.2 (2015 est.)
youth dependency ratio: 29.8 (2015 est.)
elderly dependency ratio: 13.5 (2015 est.)
potential support ratio: 7.4 (2015 est.)
Median age: total: 37.8 years
male: 37.3 years
female: 38.3 years (2020 est.)
country comparison to the world: 67
Population growth rate: -0.3% (2020 est.)
country comparison to the world: 219
Birth rate: 11.4 births/1,000 population (2020 est.)
country comparison to the world: 172
Death rate: 9.1 deaths/1,000 population (2020 est.)
country comparison to the world: 60
Net migration rate: -5.4 migrant(s)/1,000 population (2020
est.)
country comparison to the world: 200
Population distribution: population on Trinidad is concentrated
in the western half of the island, on Tobago in the southern
half Urbanization: urban population: 53.2% of total population
(2020)
rate of urbanization: 0.22% annual rate of change (2015-20
est.)
Major urban’ areas—population: 544,000 PORI-OF-SPAIN
(capital) (2020)
Sex ratio: at birth: 1.03 male(s)/female (2020 est.)
0-14 years: 1.04 male(s)/female (2020 est.)
15-24 years: 1.09 male(s)/female (2020 est.)
25-54 years: 1.1 male(s)/female (2020 est.)
95-64 years: 1 male(s)/female (2020 est.)
65 years and over: 0.78 male(s)/female (2020 est.)
total population: 102.8 male(s)/female (2020 est.)
Maternal mortality rate: 67 deaths/100,000 live births (2017
est.)
country comparison to the world: 85
Infant mortality rate: total: 20.1 deaths/1,000 live births
male: 21.3 deaths/1,000 live births
female: 18.8 deaths/1,000 live births (2020 est.)
country comparison to the world: 75
Life expectancy at birth: total population: 73.9 years
male: 70.9 years
female: 76.9 years (2020 est.)
country comparison to the world: 138
Total fertility rate: 1.7 children born/woman (2020 est.)
country comparison to the world: 174
Contraceptive prevalence rate: 40.3% (2011)
Drinking water source:
improved:
urban: 95.1% of population
rural: 95.1% of population
total: 95.1% of population
unimproved:
urban: 4.9% of population
rural: 4.9% of population
total: 4.9% of population (2015 est.)
Current Health Expenditure: 6.5% (2016)
Physicians density: 2.67 physicians/1,000 population (2015)
Hospital bed density: 3 beds/1,000 population (2014)
Sanitation facility access:
improved:
urban: 91.5% of population (2015 est.)
rural: 91.5% of population (2015 est.)
total: 91.5% of population (2015 est.)
unimproved:
urban: 8.5% of population (2015 est.)
rural: 8.5% of population (2015 est.)
total: 8.5% of population (2015 est.)
HIV/AIDS—adult prevalence rate: 1.1% (2017 est.)
country comparison to the world: 45
HIV/AIDS—people living with HIV/AIDS: 11,000 (2017 est.)
country comparison to the world: 99
HIV/AIDS—deaths: <500 (2017 est.)
Major infectious diseases: note: active local transmission of
Zika virus by Aedes species mosquitoes has been identified
in this country (as of August 2016); it poses an important
risk (a large number of cases possible) among US citizens if
bitten by an infective mosquito; other less common ways to
get Zika are through sex, via blood transfusion, or during
pregnancy, in which the pregnant woman passes Zika virus
to her fetus Obesity—adult prevalence rate: 18.6% (2016)
country comparison to the world: 116
Children under the age of 5 years underweight:
4.9% (2011)
country comparison to the world: 84
Education expenditures: NA
Literacy: definition: age 15 and over can read and write
total population: 99%
male: 99.2%
female: 98.7% (2015)
Unemployment, youth ages 15-24: total: 7.1%
male: 7.2%
female: 6.9% (2016 est.)
country comparison to the world: 155','b93ea78c4039000015a653927b361105b0b322eb7f574d4c30c53c4a319f7410','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22cd8304120045d99554d880a48a11b21c88f367aebc3b998ec5fa511f3379f9',2020,'KZ','Kazakhstan','people-and-society',1001,'Government type: presidential republic; authoritarian
Capital: name: Ashgabat (Ashkhabad) geographic coordinates:
3757 N, 58 23 E
time difference: UTC+5 (10 hours ahead of Washington,
DC, during Standard Time) etymology: derived from the
Persian words “eshq” meaning “love” and “abad” meaning
“inhabited place” or “city,” and so loosely translates as “the
city of love”
Administrative divisions: 5 provinces (welayatlar, singular—
welayat) and 1 independent city*: Ahal Welayaty (Anew),
Ashgabat*, Balkan Welayaty (Balkanabat), Dasoguz
Welayaty, Lebap Welayaty (Turkmenabat), Mary Welayaty
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative
center name following in parentheses) Independence: 27
October 1991 (from the Soviet Union)
National holiday: Independence Day, 27 October (1991)
Constitution: history: several previous; latest adopted 14
September 2016
amendments: proposed by the National Assembly; passage
requires two-thirds majority vote of the total Assembly
membership or absolute majority approval in a referendum;
amended 2017 (2019) Legal system: civil law system with
Islamic (sharia) law influences International law organization
participation: has not submitted an ICj jurisdiction
declaration; non-party state to the ICCt Citizenship:
citizenship by birth: no citizenship by descent only: at least
one parent must be a citizen of Turkmenistan dual
citizenship recognized: yes
residency requirement for naturalization: 7 years
Suffrage: 18 years of age; universal
Executive branch: Chief of state: President Gurbanguly
BERDIMUHAMEDOW (since 14 February 2007); note—the
president is both chief of state and head of government
head of government: President Gurbanguly
BERDIMUHAMEDOW (since 14 February 2007) cabinet:
Cabinet of Ministers appointed by the _ president
elections/appointments: president directly elected by
absolute majority popular vote in 2 rounds if needed for a
7-year term (no term limits); election last held on 12
February 2017 (next to be held in February 2024) election
results: Gurbanguly BERDIMUHAMEDOW reelected
president in the first round; percent of vote—Gurbanguly
BERDIMUHAMEDOW (DPT) 97.7%, other 2.3%
Legislative branch: description: unicameral National Assembly
or Mejlis (125 seats; members directly elected from single-
seat constituencies by absolute majority vote; members
serve 5-year terms) elections: last held on 25 March 2018,
although interim elections are held on an ad hoc basis to fill
vacant sets election results: percent of vote by party—NA;
seats by party—DPT 55, APT 11, PIE 11, independent 48
(individuals nominated by citizen groups); composition—
men 94, women 31, percent of women 24.8%
Judicial branch: highest courts: Supreme Court of
Turkmenistan (consists of the court president and 21
associate judges and organized into civil, criminal, and
military chambers) judge selection and term of Office:
judges appointed by the president for 5-year terms
subordinate courts: High Commercial Court; appellate
courts; provincial, district, and city courts; military courts
Political parties and leaders:
Agrarian Party of Turkmenistan or APT [Basim
ANNAGURBANOW]
Democratic Party of Turkmenistan or DPT _ [Ata
SERDAROW]
Party of Industrialists and Entrepreneurs or PIE
[Saparmyrat OWGANOW]
note: all of these parties support President
BERDIMUHAMEDOW; a law authorizing the registration of
political parties went into effect in January 2012; unofficial,
small opposition movements exist abroad International
organization participation: ADB, CIS (associate member, has
not ratified the 1993 CIS charter although it participates in
meetings and held the chairmanship of the CIS in 2012),
EAPC, EBRD, ECO, FAO, G-77, IBRD, ICAO, ICRM, IDA,
IDB, IFC, IFRCS, ILO, IMF, IMO, Interpol, IOC, IOM
(observer), ISO (correspondent), ITU, MIGA, NAM, OIC,
OPCW, OSCE, PFP UN, UNCTAD, UNESCO, UNHCR,
UNIDO, UNWTO, UPU, WCO, WFTU (NGOs), WHO, WIPO,
WMO
Diplomatic representation in the _ US: Ambassador Meret
ORAZOW (since 14 February 2001) chancery: 2207
Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 588-1500
FAX: [1] (202) 588-0697
Diplomatic representation from the US: chief of mission:
Ambassador Matthew S. KLIMOW (since 26 June 2019)
telephone: [993] (12) 94-00-45
embassy: No. 9 1984 Street (formerly Pushkin Street),
Ashgabat, Turkmenistan 744000
mailing address: 7070 Ashgabat Place, Washington, DC
20521-7070
FAX: [993] (12) 94-26-14
Flag description: green field with a vertical red stripe near the
hoist side, containing five tribal guls (designs used in
producing carpets) stacked above two crossed olive
branches; five white, five-pointed stars and a _ white
crescent moon appear in the upper corner of the field just
to the fly side of the red stripe; the green color and
crescent moon represent Islam; the five stars symbolize the
regions or welayats of Turkmenistan; the guls reflect the
national identity of Turkmenistan where carpet-making has
long been a part of traditional nomadic life note: the flag of
Turkmenistan is the most intricate of all national flags
National symbol(s): Akhal-Teke horse; national colors: green,
white National anthem: name: “Garassyz, Bitarap
Turkmenistanyn” (Independent, Neutral, Turkmenistan
State Anthem) /yrics/music: collective/Veli MUKHATOV
note: adopted 1997, lyrics revised in 2008, to eliminate
references to deceased President Saparmurat NYYAZOW
ele] ‘Tel b 4
Economy—overview: Turkmenistan is largely a desert country
with intensive agriculture in irrigated oases and significant
natural gas and oil resources. The two largest crops are
cotton, most of which is produced for export, and wheat,
which is domestically consumed. Although agriculture
accounts for almost 8% of GDP it continues to employ
nearly half of the country’s workforce. Hydrocarbon
exports, the bulk of which is natural gas going to China,
make up 25% of Turkmenistan’s GDP. Ashgabat has
explored two initiatives to bring gas to new markets: a
trans-Caspian pipeline that would carry gas to Europe and
the Turkmenistan-Afghanistan-Pakistan-India gas pipeline.
Both face major financing, political, and security hurdles
and are unlikely to be completed soon.
Turkmenistan’s autocratic governments under
presidents NIYAZOW (1991-2006) and
BERDIMUHAMEDOW (since 2007) have made little
progress improving the business climate, privatizing state-
owned industries, combatting corruption, and limiting
economic development outside the energy sector. High
energy prices in the mid-2000s allowed the government to
undertake extensive development and social spending,
including providing heavy utility subsidies.
Low energy prices since mid-2014 are hampering
Turkmenistan’s economic growth and reducing government
revenues. The government has cut subsidies in several
areas, and wage arrears have increased. In January 2014,
the Central Bank of Turkmenistan devalued the manat by
19%, and downward pressure on the currency continues.
There is a widening spread between the official exchange
rate (3.5 TMM per US dollar) and the black market
exchange rate (approximately 14 TMM per US dollar).
Currency depreciation and conversion — restrictions,
corruption, isolationist policies, and declining spending on
public services have resulted in a stagnate economy that is
nearing crisis. Turkmenistan claims substantial foreign
currency reserves, but non-transparent data _ limit
international institutions’ ability to verify this information.
GDP (purchasing power parity):
$103.7 billion (2017 est.)
$97.41 billion (2016 est.)
$91.72 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 84
GDP (official exchange rate):
$37.93 billion (2017 est.)
GDP—real growth rate: 6.5% (2017 est.)
6.2% (2016 est.)
6.5% (2015 est.)
country comparison to the world: 30
GDP—per capita (PPP): $18,200 (2017 est.)
$17,300 (2016 est.)
$16,500 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 97
Gross national saving:
23.9% of GDP (2017 est.)
24.3% of GDP (2016 est.)
18.9% of GDP (2015 est.)
country comparison to the world: 70
GDP—composition, by end use:
household consumption: 50% (2017 est.)
government consumption: 10% (2017 est.)
investment in fixed capital: 28.2% (2017 est.)
investment in inventories: 0% (2017 est.)
exports of goods and services: 26.2% (2017 est.)
imports of goods and services: -14.3% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 7.5% (2017 est.)
industry: 44.9% (2017 est.)
services: 47.7% (2017 est.)
Agriculture—products: cotton, grain, melons; livestock
Industries: natural gas, oil, petroleum products, textiles, food
processing Industrial production growth rate:
1% (2017 est.)
country comparison to the world: 160
Labor force: 2.305 million (2013 est.)
country comparison to the world: 116
Labor force—by occupation: agriculture: 48.2%
industry: 14%
services: 37.8% (2004 est.)
Unemployment rate: 11% (2014 est.)
10.6% (2013)
country comparison to the world: 149
Population below poverty line: 0.2% (2012 est.)
Household income or consumption by percentage share: Jowest 10%:
2.6%
highest 10%: 31.7% (1998)
Budget: revenues: 5.657 billion (2017 est.) expenditures:
6.714 billion (2017 est.)
Taxes and other revenues:
14.9% (of GDP) (2017 est.)
country comparison to the world: 197
Budget surplus (+) or deficit (-): -2.8% (of GDP) (2017 est.)
country comparison to the world: 126
Public debt:
28.8% of GDP (2017 est.)
24.1% of GDP (2016 est.)
country comparison to the world: 167
Fiscal year: Calendar year
Inflation rate (consumer prices): 8% (2017 est.)
3.6% (2016 est.)
country comparison to the world: 198
Current account balance:
-$4.359 billion (2017 est.)
-$7.207 billion (2016 est.)
country comparison to the world: 181
Exports: $7.458 billion (2017 est.)
$6.987 billion (2016 est.)
country comparison to the world: 99
Exports—partners: China 83.7%, Turkey 5.1% (2017)
Exports—commodities: gas, crude oil, petrochemicals, textiles,
cotton fiber Imports: $4.571 billion (2017 est.)
$5.215 billion (2016 est.)
country comparison to the world: 135
Imports—commodities: Machinery and equipment, chemicals,
foodstuffs imports—partners: Turkey 24.2%, Algeria 14.4%,
Germany 9.8%, China 8.9%, Russia 8%, US 6.6% (2017)
Reserves of foreign exchange and gold:
$24.91 billion (31 December 2017 est.)
$25.05 billion (31 December 2016 est.)
country comparison to the world: 56
Debt—external:
$539.4 million (31 December 2017 est.)
$425.3 million (31 December 2016 est.)
country comparison to the world: 177
Exchange rates: Turkmenistani manat (TMM) per US dollar—
4.125 (2017 est.)
3.5 (2016 est.)
(2015 est.)
3.5 (2014 est.)
2.85 (2013 est.)','28854b90befa2badbc462406876a97445f326f4e715fd3bc5133db5811b161bc','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a03ec6fce73f1337526e38db8c378ae2149ea192b341165aeea678b33689a92',2020,'MA','Morocco','people-and-society',1040,'Population: 652,271 (July 2020 est.)
note: estimate is based on projections by age, sex, fertility,
mortality, and migration; fertility and mortality are based
on data from neighboring countries country comparison to
the world: 168
Nationality: Noun: Sahrawi(s), Sahraoui(s)
adjective: Sahrawi, Sahrawian, Sahraouian
Ethnic groups: Arab, Berber
Languages: Standard Arabic, Hassaniya Arabic, Moroccan
Arabic, Berber, Spanish, French Religions: Muslim
Demographic profile: Western Sahara is a non-self governing
territory; approximately 75% is under Moroccan control. It
was inhabited almost entirely by Sahrawi pastoral nomads
until the mid-20th century. Their traditional vast migratory
ranges, based on following unpredictable rainfall, did not
coincide with colonial and later international borders.
Since the 1930s, most Sahrawis have been compelled to
adopt a sedentary lifestyle and to live in urban settings as a
result of fighting, the presence of minefields, job
opportunities in the phosphate industry, prolonged drought,
the closure of Western Sahara’s border with Mauritania
from 1979-2002, and the construction of the defensive
berm separating Moroccan-and Polisario-controlled
(Sahrawi liberalization movement) areas. Morocco
supported rapid urbanization to facilitate surveillance and
security.
Today more than 80% of Western Sahara’s population
lives in urban areas; more than 40% live in the
administrative center Laayoune. Moroccan immigration has
altered the composition and dramatically increased the size
of Western Sahara’s population. Morocco maintains a large
military presence in Western Sahara and has encouraged
its citizens to settle there, offering bonuses, pay raises, and
food subsidies to civil servants and a tax exemption, in
order to integrate Western Sahara into the Moroccan
Kingdom and, Sahrawis contend, to marginalize the native
population.
Western Saharan Sahrawis have been migrating to
Europe, principally to former colonial ruler Spain, since the
1950s. Many who moved to refugee camps in Tindouf,
Algeria, also have migrated to Spain and Italy, usually
alternating between living in cities abroad with periods
back at the camps. The Polisario claims that the population
of the Tindouf camps is about 155,000, but this figure may
include thousands of Arabs and Tuaregs from neighboring
countries. Because international organizations have been
unable to conduct an independent census in Tindouf, the
UNHCR bases its aid on a figure of 90,000 refugees.
Western Saharan coastal towns emerged as key migration
transit points (for reaching Spain’s Canary Islands) in the
mid-1990s, when Spain’s and Italy’s tightening of visa
restrictions and EU pressure on Morocco and other North
African countries to control illegal migration pushed Sub-
Saharan African migrants to shift their routes to the south.
Age structure: 0-14 years: 36.29% (male 119,719/female
116,997) 15-24 years: 19.44% (male 63,852/female 62,954)
25-54 years: 34.9% (male 112,301/female 115,313)
595-64 years: 5.27% (male 16,095/female 18,292)
65 years and over: 4.1% (male 11,802/female 14,946) (2020
est.)
Dependency ratios: total dependency ratio: 45 (2015 est.)
youth dependency ratio: 41.4 (2015 est.)
elderly dependency ratio: 3.7 (2015 est.)
potential support ratio: 27.1 (2015 est.)
Median age: total: 21.8 years
male: 21.4 years
female: 22.3 years (2020 est.)
country comparison to the world: 184
Population growth rate: 2.54% (2020 est.)
country comparison to the world: 22
Birth rate: 28 births/1,000 population (2020 est.)
country comparison to the world: 38
Death rate: 7.7 deaths/1,000 population (2020 est.)
country comparison to the world: 100
Net migration rate: 4.9 migrant(s)/1,000 population (2020 est.)
country comparison to the world: 25
Population distribution: most of the population lives in the two-
thirds of the area west of the berm (Moroccan-occupied)
that divides the territory; about 40% of that populace
resides in Laayoune Urbanization: urban population: 86.8% of
total population (2020) rate of urbanization: 2.61% annual
rate of change (2015-20 est.)
Major urban areas—population: 232,000 Laayoune (2018)
Sex ratio: at birth: 1.04 male(s)/female (2020 est.)
0-14 years: 1.02 male(s)/female (2020 est.)
15-24 years: 1.01 male(s)/female (2020 est.)
25-54 years: 0.97 male(s)/female (2020 est.)
55-64 years: 0.88 male(s)/female (2020 est.)
65 years and over: 0.79 male(s)/female (2020 est.)
total population: 98.6 male(s)/female (2020 est.)
Infant mortality rate: total: 47.9 deaths/1,000 live births male:
52.5 deaths/1,000 live births
female: 43.1 deaths/1,000 live births (2020 est.)
country comparison to the world: 26
Life expectancy at birth: total population: 64.5 years male: 62.1
years
female: 67 years (2020 est.)
country comparison to the world: 202
Total fertility rate: 3.65 children born/woman (2020 est.)
country comparison to the world: 38
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Education expenditures: NA','b05245aab9f4f7930d17bb3d4663286478f37e990aa949270a58bcdfb007c99b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b08ba63a16672a2719b93ac9adf6db3774f8bf47ceca7e0480dec58a3c51df6b',2020,'US','United States','transportation',42,'National air transport system: number of registered
air carriers inventory of registered aircraft operated by
air carriers annual passenger traffic on registered air
carriers annual freight traffic on registered air carriers
Civil aircraft registration country code prefix:
Airports: total
Airports—with paved runways: total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Airports—with unpaved runways: total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Heliports: Pipelines: Railways: total
standard gauge
narrow gauge
broad gauge
dual gauge
Roadways: total
paved
unpaved
urban
non-urban
Waterways: Merchant marine: total
by type
Ports and terminals: major seaport(s)
oil terminal(s)
container port(s) (TEUs)
lake port(s)
LNG terminal(s) (export)
LNG terminal(s) (import)
river port(s)
dry bulk cargo port(s)
bulk cargo port(s)
Transportation—note: TERRORISM
Terrorist groups—home based: Terrorist groups
—foreign based: TRANSNATIONAL ISSUES
Disputes—international: Refugees and
internally displaced persons: refugees (country of
origin)
IDPs
stateless persons
Trafficking in persons: current situation
tier rating
Hlicit drugs:
GUIDE TO COUNTRY COMPARISONS
Country Comparison pages are presorted lists of data from
selected Factbook data fields. Country Comparison pages
are generally given in descending order—highest to lowest
—such as Population and Area. The two exceptions are
Unemployment Rate and Inflation Rate, which are in
ascending—lowest to highest—order. Country Comparison
pages are available for the following fields in seven of the
ten Factbook categories.
Airports:
Railways:
Roadways:
Waterways:
Merchant marine:
Airports: Baker Island: one abandoned World War II runway
of 1,665 m covered with vegetation and unusable (2013)
Howland Island: airstrip constructed in 1937 for scheduled
refueling stop on the round-the-world flight of Amelia
EARHART and Fred NOONAN; the aviators left Lae, New
Guinea, for Howland Island but were never seen again; the
airstrip is no longer serviceable (2013) Johnston Atoll: one
closed and not maintained (2013)
Kingman Reef: lagoon was used as a halfway station
between Hawaii and American Samoa by Pan American
Airways for flying boats in 1937 and 1938 (2013) Midway
Islands: 3—one operational (2,377 m paved); no fuel for
sale except emergencies (2013) Palmyra Atoll: 1—1,846 m
unpaved runway; privately owned (2013)
Airports—with paved runways:
2,438 to 3,047 m: 1—Johnston Atoll; (2016)
note—abandoned but usable
Airports—with unpaved runways:
1—Palmyra Atoll (2016)
Roadways: Ports and terminals: major seaport(s): Baker,
Howland, and Jarvis Islands, and Kingman Reef Baker
Howland, and Jarvis Islands, and Kingman Reef: none;
offshore anchorage only Johnston Atoll: Johnston Island
Midway Islands: Sand Island
Palmyra Atoll: West Lagoon','1c46d82aec956f7115bf1ec1205e6a7968cda4dc3b25c1e50d5a2836d017437c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5435fd1839f9d0d60fdf53f566bc122a83654d93d5e07edaad3c3255528af14',2020,'GR','Greece','transportation',71,'National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 1 (2015)
annual passenger traffic on registered air carriers: 151,632
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: ZA (2016)
Airports: 4 (2016)
country comparison to the world: 184
Airports—with paved runways: total: 4 (2017)
2,438 to 3,047 m: 3 (2017)
1,524 to 2,437 m: 1 (2017)
Airports—with unpaved runways: total: 1 (2012)
914 to 1,523 m: 1 (2012)
Heliports: 1 (2013)
Pipelines: 498 km gas (a majority of the network is in
disrepair and parts of it are missing), 249 km oil (2015)
Railways: total: 677 km (447 km of major railway lines and
230 km of secondary lines) (2015) standard gauge: 677 km
1.435-m gauge (2015)
country comparison to the world: 103
Roadways: total: 3,945 km (2018)
country comparison to the world: 152
Waterways: 41 km (on the Bojana River) (2011)
country comparison to the world: 103
Merchant marine:
total: 60
by type: bulk carrier 1, general cargo 50, oil tanker 1, other
8 (2018)
country comparison to the world: 107
Ports and terminals: major seaport(s): Durres, Sarande,
Shengjin, Vlore
Civil aircraft registration country code prefix: Z3 (2016)
Airports: 10 (2013)
country comparison to the world: 156
Airports—with paved runways:
total: 8 (2017)
2,438 to 3,047 m: 2 (2017)
under 914 m: 6 (2017)
Airports—with unpaved runways:
total: 2 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 1 (2013)
Pipelines: 262 km gas, 120 km oil (2017)
Railways: total: 925 km (2017)
standard gauge: 925 km 1.435-m gauge (313 km
electrified) (2017)
country comparison to the world: 93
Roadways: total: 14,182 km _ (includes 290 km of
expressways) (2017) paved: 9,633 km (2017)
unpaved: 4,549 km (2017)
country comparison to the world: 125','70696775a81a35ca3fe8844f73d3b4b266c71af9c955b2a55afb4e11cf4e021e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2176e130dba1ab2a558dbba29dc366cf8785b292434bb94deb92833b4ab6d2f8',2020,'AS','American Samoa','transportation',84,'Airports: 3 (2016)
country comparison to the world: 192
Airports—with paved runways: total: 3 (2019)
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 1
Roadways: total: 241 km (2008)
country comparison to the world: 199
Ports and terminals: Major seaport(s): Pago Pago','8f7fabb2e5e2cc7f62bd3b087a445357171ea01ff9e220bf96835a99bb143401','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd2239b6ae163a4b71dd66760a206078f0a31aff84f92a1c8fb5655db2be4e77',2020,'ES','Spain','transportation',90,'eS ag “2 ZEEBEESEEEEZZXEEY)
Civil aircraft registration country code prefix: C3 (2016)
Roadways: total: 320 km (2019)
country comparison to the world: 195','5f5720eac4f70c0b6f64c1a742bf25642f78f2f85ad0a41d7678083a67c0ad70','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0805728807e7cb5205f00fc90f68d42c1cf726cfb7524a6729c7a32ef725d64',2020,'NA','Namibia','transportation',103,'National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 3 (2015)
Civil aircraft registration country code prefix: VP-A (2016)
Airports: 2 (2013)
country comparison to the world: 197
Airports—with paved runways: total: 1 (2019)
1,524 to 2,437 m: 1
Airports—with unpaved runways: total: 1 (2013)
under 914 m: 1 (2013)
Railways:
Roadways: total: 175 km (2004)
paved: 82 km (2004)
unpaved: 93 km (2004)
country comparison to the world: 203
Merchant marine:
total: 1
by type: other 1 (2018)
country comparison to the world: 170
Ports and terminals: Major seaport(s): Blowing Point, Road Bay
Airports: 23 (2013)
country comparison to the world: 133
Airports—with unpaved runways: total: 23 (2013)
over 3,047 m: 3 (2013)
2,438 to 3,047 m: 5 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 8 (2013)
under 914 m: 6 (2013)
Heliports: 53 (2012)
note: all year-round and seasonal stations operated by
National Antarctic Programs stations have some kind of
helicopter landing facilities, prepared (helipads) or
unprepared Roadways: Ports and terminals: most coastal
stations have sparse and intermittent offshore anchorages;
a few stations have basic wharf facilities Transportation—note:
US coastal stations include McMurdo (77 51 S, 166 40 E)
and Palmer (64 43 S, 64 03 W); government use only; all
ships at port are subject to inspection in accordance with
Article 7, Antarctic Treaty; relevant legal instruments and
authorization procedures adopted by the states parties to
the Antarctic Treaty regulating the Antarctic Treaty area
have to be complied with (see “Legal System”); The
Hydrographic Commission on Antarctica (HCA), a
commission of the International Hydrographic Organization
(IHO), is responsible for hydrographic surveying and
nautical charting matters in Antarctic Treaty area; it
coordinates and facilitates provision of accurate and
appropriate charts and other aids to navigation in support
of safety of navigation in region; membership of HCA is
open to any IHO Member State whose government has
acceded to the Antarctic Treaty and which contributes
resources or data to IHO Chart coverage of the area
Roadways: Ports and terminals: major seaport(s): Churchill
(Canada), Murmansk (Russia), Prudhoe Bay (US)
Transportation—note: Sparse network of air, ocean, river, and
land routes; the Northwest Passage (North America) and
Northern Sea Route (Eurasia) are important seasonal
waterways TRANSNATIONAL ISSUES
Disputes—international: Canada and the US dispute how to
divide the Beaufort Sea and the status of the Northwest
Passage but continue to work cooperatively to survey the
Arctic continental shelf; Denmark (Greenland) and Norway
have made submissions to the Commission on the Limits of
the Continental shelf (CLCS) and Russia is collecting
additional data to augment its 2001 CLCS submission;
record summer melting of sea ice in the Arctic has renewed
interest in maritime shipping lanes and _ sea _ floor
exploration; Norway and Russia signed a comprehensive
maritime boundary agreement in 2010','dc2c5a29f14fed47a815d53c29436a15169377bc44358632c4f0c4bbfd2c1774','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6566efa166fe4901cfc267248cbb60e369a8a14cdf16d97d7ebc4e234be937a',2020,'PY','Paraguay','transportation',105,'qoalta
San Miguel
ae Tucuman
San
Juan Cordoba
Stan San Lorenzo} del
Aconcagua San Marting
‘osarioS
Mendoza 6 BUENOS
ruguay','3e1def6e25094b9c83d06a4f3956a3207f4504b32cc3b463c84bb7d000b262eb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0320fe4532e6e66cfbcae1a94cbe817cffbb7b911c68af4fb696b18c90011db',2020,'UY','Uruguay','transportation',106,'AIRES x,
La Plata
x : Mar del
a Bahia Plata
Blanca, §
San Carlos Viedma «
Ge Bariloche (——*
Punta
Colorada
#Comodoro
Rivadavia
Falkland Islands
Soy % (Islas Malvinas)
© (administered by UK.
claimed by ARGENTINA)','dd6499ab2b8c92266e68e9d67d96d31967c4da0136cb5eab5f119dfba48aad62','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('900b242c6b0ef5a405e0376272abb73b115aafc5e8c1ab732cc07877c989463c',2020,'AM','Armenia','transportation',122,'National air transport system: number of registered air Carriers:
3 (2015) inventory of registered aircraft operated by air
carriers: 5 (2015)
Civil aircraft registration country code prefix: EK (2016)
Airports: 11 (2013)
country comparison to the world: 153
Airports—with paved runways: total: 10 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 4 (2017)
914 to 1,523 m: 2 (2017)
Airports—with unpaved runways: total: 1 (2013)
914 to 1,523 m: 1 (2013)
Pipelines: 3838 km gas (high and medium pressure) (2017)
Railways: total: 780 km (2014)
broad gauge: 780 km 1.520-m gauge (780 km electrified)
(2014)
note: 726 km operational
country comparison to the world: 98
Roadways: total: 7,700 km (2014)
country comparison to the world: 135','1de07b2048896980f664e41201d9139e0b354677b525ed0eb8a138e8fb044997','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffeb261cbd7050c9f422144cc24f34d34252c71090e387a20c2c82d17cf61bc7',2020,'AU','Australia','transportation',133,'Roadways: Ports and terminals: major seaport(s): Alexandria
(Egypt), Algiers (Algeria), Antwerp (Belgium), Barcelona
(Spain), Buenos Aires (Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Denmark), Dakar (Senegal),
Gdansk (Poland), Hamburg (Germany), Helsinki (Finland),
Las Palmas (Canary Islands, Spain), Le Havre (France),
Lisbon (Portugal), London (UK), Marseille (France),
Montevideo (Uruguay), Montreal (Canada), Naples (Italy),
New Orleans (US), New York (US), Oran (Algeria), Oslo
(Norway), Peiraiefs or Piraeus (Greece), Rio de Janeiro
(Brazil), Rotterdam (Netherlands), Saint Petersburg
(Russia), Stockholm (Sweden) Transportation—note: Kiel Canal
and Saint Lawrence Seaway are two important waterways;
significant domestic commercial and recreational use of
Intracoastal Waterway on central and south Atlantic
seaboard and Gulf of Mexico coast of US; the International
Maritime Bureau reports the territorial waters of littoral
states and offshore Atlantic waters as high risk for piracy
and armed robbery against ships, particularly in the Gulf of
Guinea off West Africa; in 2014, 41 commercial vessels
were attacked in the Gulf of Guinea with 5 hijacked and
144 crew members taken hostage; hijacked vessels are
often disguised and cargoes stolen; crews have been
robbed and stores or cargoes stolen TRANSNATIONAL
ISSUES
Disputes—international: Some maritime disputes (see littoral
states)
PAPUL
NEW GUINEA
Cairns,
Townsville
e~*Port Hedland 4
Dampier - Mackay
Alice Springs
Gladstone”
Brisbane,
yrerth Newcastle
Fremantle Adelaide Sydney, >
ANBERRA*
Melbourne, “Mount
2 _Kostiuszk
Lau inceston,
Tasmania eHobart
Lord Howe Island and
pouarie Island not shown
Roadways: Ports and terminals: none; offshore anchorage
only
National air transport system:
number of registered air carriers: 2 (registered in France)
(2015)
inventory of registered aircraft operated by air carriers: 10
(registered in France) (2015)
Airports: 25 (2013)
country comparison to the world: 129
Airports—with paved runways:
total: 12 (2019)
over 3,047 m: 1
914 to 1,523 m: 10
under 914 m: 1
Airports—with unpaved runways:
total: 13 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 8 (2013)
Heliports: 8 (2013)
Roadways: total: 5,622 km (2006)
country comparison to the world: 142
Merchant marine: total: 10
by type: general cargo 2, other 8 (2018)
country comparison to the world: 151
Ports and terminals: Major seaport(s): Noumea
Airports: 1 (2013)
country comparison to the world: 232
Airports—with paved runways:
total: 1 (2019)
1,524 to 2,437 m: 1
Roadways: total: 80 km (2008)
paved: 53 km (2008)
unpaved: 27 km (2008)
country comparison to the world: 209
Ports and terminals: Major seaport(s): Kingston','51c8ea69d40772066d3ebd31228f8c6e8a946872cfc06453cb5aea80e3215fcf','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6950b5f1aec52e0e1d115c079914f5f45935cca998af16aa765d938bc963780',2020,'NF','Norfolk Island','transportation',143,'National air transport system:
number of registered air carriers: 4 (2015)
inventory of registered aircraft operated by air carriers: 16
(2015)
annual passenger traffic on registered air carriers: 587,516
(2015)
annual freight traffic on registered air carriers: 172,730
mt-km (2015)
Civil aircraft registration country code prefix: C6 (2016)
Airports: 61 (2013)
country comparison to the world: 79
Airports—with paved runways:
total: 24 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 13 (2017)
914 to 1,523 m: 7 (2017)
Airports—with unpaved runways:
total: 37 (2013)
1,524 to 2,437 m: 4 (2013)
914 to 1,523 m: 16 (2013)
under 914 m: 17 (2013)
Heliports: 1 (2013)
Roadways: total: 2,700 km (2011)
paved: 1,620 km (2011)
unpaved: 1,080 km (2011)
country comparison to the world: 162
Merchant marine: total: 1,418
by type: bulk carrier 328, container ship 49, general cargo
96, oil tanker 271, other 674 (2018) country comparison to
the world: 19
Ports and terminals: Major seaport(s): Freeport, Nassau, South
Riding Point cruise port(s): Nassau
container port(s) (TEUs): Freeport (1,116,272)(2011)','00d69a6cc1bad0a556e835f59bee93f51f9c559b9f2b06d2b906f63a4db20679','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00ef773d2e37a6237f8d19f5a7219772ac6c7ccabff11f3b2b4b63c1ee5329bb',2020,'IN','India','transportation',155,'National air transport system:
number of registered air carriers: 6 (2015)
inventory of registered aircraft operated by air carriers: 30
(2015)
annual passenger traffic on registered air Carriers:
2,906,799 (2015)
annual freight traffic on _ registered air carriers:
182,692,553 mt-km (2015)
Civil aircraft registration country code prefix: S2 (2016)
Airports: 18 (2013)
country comparison to the world: 138
Airports—with paved runways:
total: 16 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 6 (2017)
914 to 1,523 m: 1 (2017)
under 914 m: 5 (2017)
Airports—with unpaved runways:
total: 2 (2013)
1,524 to 2,437 m: 1 (2013)
under 914 m: 1 (2013)
Heliports: 3 (2013)
Pipelines: 2950 km gas (2013)
Railways: total: 2,460 km (2014)
narrow gauge: 1,801 km 1.000-m gauge (2014)
broad gauge: 659 km 1.676-m gauge (2014)
country comparison to the world: 68
Roadways: total: 369,105 km (2018)
paved: 110,311 km (2018)
unpaved: 258,794 km (2018)
country comparison to the world: 20
Waterways: 8,370 km (includes up to 3,060 km of main cargo
routes; network reduced to 5,200 km in the dry season)
(2011) country comparison to the world: 16
Merchant marine: total: 329
by type: bulk carrier 33, container ship 4, general cargo 77,
oil tanker 122, other 93 (2018) country comparison to the
world: 48
Ports and terminals: Major seaport(s): Chittagong
container port(s) (TEUs): Chittagong (2,566,597) (2017)
river port(s): Mongla Port (Sela River)','ba922f301c549274e42e296a6854654d50320fccb79bf24ea5a15332ced47c83','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('884347824a774e7a24277b7ad2ba328ab1bd4979861eb03ab7f737980c3f92a3',2020,'HN','Honduras','transportation',184,'National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 28
(2015)
annual passenger traffic on registered air carriers: 935,603
(2015)
annual freight traffic on registered air carriers: 2,463,420
mt-km (2015)
Civil aircraft registration country code prefix: V3 (2016)
Airports: 47 (2013)
country comparison to the world: 91
Airports—with paved runways:
total: 6 (2017)
2,438 to 3,047 m: 1 (2017)
914 to 1,523 m: 2 (2017)
under 914 m: 3 (2017)
Airports—with unpaved runways:
total: 41 (2013)
2,438 to 3,047 m: 1 (2013)
914 to 1,523 m: 11 (2013)
under 914 m: 29 (2013)
Roadways: total: 3,281 km (2017)
paved: 601 km (2017)
unpaved: 2,680 km (2017)
country comparison to the world: 156
Waterways: 825 km (navigable only by small craft) (2011)
country comparison to the world: 70
Merchant marine: total: 764
by type: bulk carrier 54, container ship 4, general cargo
383, oil tanker 57, other 266 (2018) country comparison to
the world: 29
Ports and terminals: Major seaport(s): Belize City, Big Creek
Santa Rosa Pedro
sierts uerto
eiba-—*
de Copan Sula
° jluticalpa d
ree fomayagua
as Minas TEGUCIGALPA
* ae
Danii
ELS ADOR
»* ,Choluteca','acd29007b50cfda082e7d982f311998269f66bf157a5bfc3e3599b644011a043','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f4bbbda2d989cf78ffebd5113de30f95f9156ee30817c2e0f808cc69f034075',2020,'ET','Ethiopia','transportation',194,'Civil aircraft registration country code prefix: VP-B (2016)
Airports: 1 (2013)
country comparison to the world: 214
Airports—with paved runways:
total: 1 (2019)
2,438 to 3,047 m: 1
Roadways: total: 447 km (2010)
paved: 447 km (2010)
note: 225 km public roads; 222 km private roads
country comparison to the world: 191
Merchant marine: total: 160
by type: bulk carrier 6, container ship 11, general cargo 1,
oil tanker 19, other 123 (2018) country comparison to the
world: 68
Ports and terminals: Major seaport(s): Hamilton, Ireland
Island, Saint George TRANSNATIONAL ISSUES
Disputes—International: NONe
Ports and terminals: none; offshore anchorage only
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 1 (2015)
annual passenger traffic on registered air carriers: 75,416
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: A3 (2016)
Airports: 6 (2013)
country comparison to the world: 178
Airports—with paved runways:
total: 1 (2019)
2,438 to 3,047 m: 1
Airports—with unpaved runways:
total: 5 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 3 (2013)
under 914 m: 1 (2013)
Roadways: total: 680 km (2011)
paved: 184 km (2011)
unpaved: 496 km (2011)
country comparison to the world: 183
Merchant marine: total: 33
by type: bulk carrier 1, container ship 1, general cargo 15,
oil tanker 1, other 15 (2018)
country comparison to the world: 123
Ports and terminals: Major seaport(s): Nuku’alofa, Neiafu,
Pangai','84409c9504cdaf1ae69821b7f748f1737e691a9ae00f758e4490bbf363d6c9b3','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b806a395236fe2b24d5da7466579cd847ca3f4085496d40b53b48bdd66899cfc',2020,'BT','Bhutan','transportation',195,'“leks Bees Trashi
y, Yangtse
THIMPHU Srongsa 9 *
*Wangdue
Phodrang Mongar’
isimasham
up
Samdr
Phuentsholing Gelephu__/ Jongkha','389826676e81bd1c6d238c215fbdcfb807d627cf50eea147d3f74d49bcea4323','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ec09ccb34f29e1675cccf71588178d4ba0c904661865d4a218447317e3c736b',2020,'BR','Brazil','transportation',232,'National air transport system:
number of registered air carriers: 9 (2015)
inventory of registered aircraft operated by air carriers:
443 (2015)
annual passenger traffic on registered air Carriers:
102,039,359 (2015)
annual freight traffic on registered air carriers: 149.393
million mt-km (2015)
Civil aircraft registration country code prefix: PP (2016)
Airports: 4,093 (2013)
country comparison to the world: 2
Airports—with paved runways:
total: 698 (2017)
over 3,047 m: 7 (2017)
2,438 to 3,047 m: 27 (2017)
1,524 to 2,437 m: 179 (2017)
914 to 1,523 m: 436 (2017)
under 914 m: 49 (2017)
Airports—with unpaved runways:
total: 3,395 (2013)
1,524 to 2,437 m: 92 (2013)
914 to 1,523 m: 1,619 (2013)
under 914 m: 1,684 (2013)
Heliports: 13 (2013)
Pipelines: 5959 km refined petroleum product (1,165 km
distribution, 4,794 km transport), 11696 km natural gas
(2,274 km distribution, 9,422 km transport), 1985 km crude
oil (distribution), 77 km ethanol/petrochemical (37 km
distribution, 40 km transport) (2016) Railways: total: 29,850
km (2014)
standard gauge: 194 km 1.435-m gauge (2014)
narrow gauge: 23,341.6 km 1.000-m gauge (24 km
electrified) (2014)
broad gauge: 5,822.3 km 1.600-m gauge (498.3 km
electrified) (2014)
dual gauge: 492 km 1.600-1.000-m gauge (2014)
country comparison to the world: 9
Roadways: total: 2 million km (2018)
paved: 246,000 km (2018)
unpaved: 1.754 million km (2018)
country comparison to the world: 4
Waterways: 50,000 km (most in areas remote from industry
and population) (2012)
country comparison to the world: 3
Merchant marine: total: 791
by type: bulk carrier 13, container ship 15, general cargo
47, oil tanker 38, other 678 (2018) country comparison to
the world: 28
Ports and terminals: Major seaport(s): Belem, Paranagua, Rio
Grande, Rio de Janeiro, Santos, Sao Sebastiao, Tubarao oil
terminal(s): DTSE/Gegua oil terminal, Ilha Grande (Gebig),
Guaiba Island terminal, Guamare oil terminal container
port(s) (TEUs): Santos (3,853,719) (2017)
LNG terminal(s) (import): Pecem, Rio de Janiero
river port(s): Manaus (Amazon)
dry bulk cargo port(s): Sepetiba ore terminal, Tubarao
National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 5 (2015) annual passenger traffic on registered air
carriers: 259,682 (2015) annual freight traffic on registered
air carriers: 29,324,319 mt-km (2015) Civil aircraft registration
country code prefix: PZ (2016)
Airports: 55 (2013)
country comparison to the world: 85
Airports—with paved runways:
total: 6 (2019)
over 3,047 m: 1
under 914 m:5
Airports—with unpaved runways:
total: 49 (2013)
914 to 1,523 m: 4 (2013)
under 914 m: 45 (2013)
Pipelines: 50 km oil (2013)
Roadways: total: 4,304 km (2003)
paved: 1,119 km (2003)
unpaved: 3,185 km (2003)
country comparison to the world: 147
Waterways: 1,200 km (most navigable by ships with drafts up
to 7 m) (2011) country comparison to the world: 59
Merchant marine: total: 10
by type: general cargo 5, oil tanker 3, other 2 (2018)
country comparison to the world: 152
Ports and terminals: major seaport(s): Paramaribo,
Wageningen TRANSNATIONAL ISSUES
Disputes—International: area claimed by French Guiana
between Riviere Litani and Riviere Marouini (both
headwaters of the Lawa); Suriname claims a triangle of
land between the New and Kutari/Koetari rivers in a
historic dispute over the headwaters of the Courantyne;
Guyana seeks UN Convention on the Law of the Sea
arbitration to resolve the longstanding dispute with
Suriname over the axis of the territorial sea boundary in
potentially oil-rich waters Trafficking in persons: current
situation: Suriname is a source, transit, and destination
country for women and children subjected to sex trafficking
and men, women, and children subjected to forced labor;
women and girls from Suriname, Guyana, Brazil, and the
Dominican Republic are subjected to sex trafficking in the
country, sometimes in interior mining camps; migrant
workers in agriculture and on fishing boats and children
working in informal urban sectors and gold mines are
vulnerable to forced labor; traffickers from Suriname
exploit victims in the Netherlands tier rating: Tier 2 Watch
List—Suriname does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; in 2014, Suriname was
granted a waiver from an otherwise required downgrade to
Tier 3 because its government has a written plan that, if
implemented, would constitute making significant efforts to
bring itself into compliance with the minimum standards
for the elimination of trafficking; authorities increased the
number of trafficking investigations, prosecutions, and
convictions as compared to 2013, but resources were
insufficient to conduct investigations in the country’s
interior; more trafficking victims were identified in 2014
than in 2013, but protective services for adults and
children were inadequate, with a proposed government
shelter for women and child trafficking victims remaining
unopened (2015) Illicit drugs: growing transshipment point
for South American drugs destined for Europe via the
Netherlands and Brazil; transshipment point for arms-for-
drugs dealing
SVALBARD
Kvitoya
Nordaustiandet
Ny-
Alesund NawtontOpnen
Prins Karis p
ponies Spitsbergen KONG KARLS
LAND
LONGYEARBYEN
Barentsburg, * Barentsoya
Sveagruya,
Edgeoya
*
Hornsund
100 200 mi
National air transport system: number of registered air Carriers:
17 (2015) inventory of registered aircraft operated by air
carriers: 122 (2015)
annual passenger traffic on registered air Carriers:
6,456,853 (2015)
annual freight traffic on registered air carriers: 6,204,085
mt-km (2015) Civil aircraft registration country code prefix: YV
(2016)
Airports: 444 (2013)
country comparison to the world: 18
Airports—with paved runways:
total: 127 (2013)
over 3,047 m: 6 (2013)
2,438 to 3,047 m: 9 (2013)
1,524 to 2,437 m: 33 (2013)
914 to 1,523 m: 62 (2013)
under 914 m: 17 (2013)
Airports—with unpaved runways:
total: 317 (2013)
2,438 to 3,047 m: 3 (2013)
1,524 to 2,437 m: 57 (2013)
914 to 1,523 m: 127 (2013)
under 914 m: 130 (2013)
Heliports: 3 (2013)
Pipelines: 981 km extra heavy crude, 5941 km gas, 7588 km
oil, 1778 km refined products (2013) Railways: total: 447 km
(2014)
standard gauge: 447 km 1.435-m gauge (41.4 km
electrified) (2014)
country comparison to the world: 115
Roadways: total: 96,189 km (2014)
country comparison to the world: 50
Waterways: 7,100 km (Orinoco River (400 km) and Lake de
Maracaibo navigable by oceangoing vessels) (2011) country
comparison to the world: 20
Merchant marine: total: 269
by type: bulk carrier 4, container ship 1, general cargo 30,
oil tanker 26, other 208 (2018) country comparison to the
world: 53
Ports and terminals: Major seaport(s): La Guaira, Maracaibo,
Puerto Cabello, Punta Cardon oil terminal(s): Jose terminal
National air transport system: number of registered air Carriers:
4 (2015) inventory of registered aircraft operated by air
carriers: 140 (2015)
annual passenger traffic on registered air Carriers:
29,944,771 (2015)
annual freight traffic on _ registered air Carriers:
384,470,240 mt-km (2015) Civil aircraft registration country code
prefix: VN (2016)
Airports: 45 (2013)
country comparison to the world: 95
Airports—with paved runways:
total: 38 (2013)
over 3,047 m: 10 (2013)
2,438 to 3,047 m: 6 (2013)
1,524 to 2,437 m: 13 (2013)
914 to 1,523 m: 9 (2013)
Airports—with unpaved runways:
total: 7 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 3 (2013)
under 914 m: 3 (2013)
Heliports: 1 (2013)
Pipelines: 72 km condensate, 398 km condensate/gas, 955
km gas, 128 km oil, 33 km oil/gas/water, 206 km refined
products, 13 km water (2013) Railways: total: 2,600 km
(2014)
standard gauge: 178 km 1.435-m gauge; 253 km mixed
gauge (2014)
narrow gauge: 2,169 km 1.000-m gauge (2014)
country comparison to the world: 66
Roadways: total: 195,468 km (2013)
paved:148,338 km (2013)
unpaved: 47,130 km (2013)
country comparison to the world: 28
Waterways: 47,130 km (30,831 km weight under 50 tons)
(2011)
country comparison to the world: 4
Merchant marine: total: 1,863
by type: bulk carrier 83, container ship 38, general cargo
1266, oil tanker 114, other 362 (2018) country comparison
to the world: 13
Ports and terminals: Major seaport(s): Cam Pha Port, Da Nang,
Haiphong, Phu My, Quy Nhon container port(s) (TEUs):
Saigon (6,155,535), Cai Mep (3,065,014) (2017) river
port(s): Ho Chi Minh (Mekong)
Airports: 2 (2013)
country comparison to the world: 208
Airports—with paved runways:
total: 2 (2019)
over 3,047 m: 1
1,524 to 2,437 m: 1
Roadways: total: 1,260 km (2008)
country comparison to the world: 173
Ports and terminals: Major seaport(s): Charlotte Amalie,
Christiansted, Cruz Bay, Frederiksted, Limetree Bay
Airports: 1 (2018)
country comparison to the world: 238
Airports—with paved runways:
total: 1 (2019)
2,438 to 3,047 m: 1
Ports and terminals: none; two offshore anchorages for large
ships
Transportation—note: there are no commercial or civilian
flights to and from Wake Island, except in direct support of
island missions; emergency landing is_ available','9ead26e700a9d3a468f4b3a1902a19f340c9aaafd67cc5f9662793bff1556c81','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f2adfdca319e948950ec7b44601ce0607b3684a0660a86c1a9e3b966f6bac34',2020,'PR','Puerto Rico','transportation',242,'National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 3 (2015)
Civil aircraft registration country code prefix: VP-L (2016)
Airports: 4 (2013)
country comparison to the world: 186
Airports—with paved runways:
total: 2 (2019)
914 to 1,523 m: 1
under 914 m: 1
Airports—with unpaved runways:
total: 2 (2013)
914 to 1,523 m: 2 (2013)
Roadways: total: 200 km (2007)
paved: 200 km (2007)
country comparison to the world: 201
Merchant marine: total: 25
by type: general cargo 4, other 21 (2018)
country comparison to the world: 133
Ports and terminals: Major seaport(s): Road Harbor
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 10
(2015)
annual passenger traffic on registered air Carriers:
1,150,003 (2015)
annual freight traffic on registered air carriers: 115.147
million mt-km (2015)
Civil aircraft registration country code prefix: V8 (2016)
Airports: 1 (2013)
country comparison to the world: 216
Airports—with paved runways:
total: 1 (2019)
over 3,047 m:1
Heliports: 3 (2013)
Pipelines: 33 km condensate, 86 km condensate/gas, 628 km
gas, 492 km oil (2013)
Roadways: total: 2,976 km (2014)
paved: 2,559 km (2014)
unpaved: 417 km (2014)
country comparison to the world: 158
Waterways: 209 km (navigable by craft drawing less than 1.2
m; the Belait, Brunei, and Tutong Rivers are major
transport links) (2012) country comparison to the world: 96
Merchant marine: total: 100
by type: general cargo 20, LNG tanker 2, other 78 (2018)
country comparison to the world: 85
Ports and terminals: Major seaport(s): Muara
oil terminal(s): Lumut, Seria
LNG terminal(s) (export): Lumut
Airports: 29 (2013)
country comparison to the world: 119
Airports—with paved runways: total: 17 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 1 (2017)
1,524 to 2,437 m: 2 (2017)
914 to 1,523 m: 7 (2017)
under 914 m: 5 (2017)
Airports—with unpaved runways:
total: 12 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 10 (2013)
Roadways: total: 26,862 km _ (includes 454 km _ of
expressways) (2012)
country comparison to the world: 100
Ports and terminals: Major seaport(s): Ensenada Honda,
Mayaguez, Playa de Guayanilla, Playa de Ponce, San Juan
container port(s) (TEUs): San Juan (1,210,503) (2015)
LNG terminal(s) (import): Guayanilla Bay
National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 199 (2015) annual passenger traffic on registered
air carriers: 25,263,224 (2015) annual freight traffic on
registered air carriers: 7,563,307,390 mt-km (2015) Civil
aircraft registration country code prefix: A7 (2016) Airports: 6
(2013)
country comparison to the world: 175
Airports—with paved runways:
total: 4 (2017)
over 3,047 m: 3 (2017)
1,524 to 2,437 m: 1 (2017)
Airports—with unpaved runways:
total: 2 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 1 (2013)
Heliports: 1 (2013)
Pipelines: 288 km condensate, 221 km condensate/gas, 2383
km gas, 90 km liquid petroleum gas, 745 km oil, 103 km
refined products (2013) Roadways: total: 7,039 km (2016)
country comparison to the world: 137
Merchant marine: total: 140
by type: bulk carrier 10, container ship 5, general cargo 6,
oil tanker 7, other 112 (2018) country comparison to the
world: 73
Ports and terminals: Major seaport(s): Doha, Musay’id, Ra’s
Laffan LNG terminal(s) (export): Ras Laffan','8fa711e98cba6ab3e66626968655722520839f76b0d8d2dcfd40b52cd86ef328','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb4c2ababd44e9134cc0f95420320fb81f7b930dbd570191ad783eab573b54ce',2020,'MM','Myanmar','transportation',254,'National air transport system:
number of registered air carriers: 11 (2015)
inventory of registered aircraft operated by air carriers: 45
(2015)
annual passenger traffic on registered air Carriers:
2,029,139 (2015)
annual freight traffic on registered air carriers: 3,365,967
mt-km (2015)
Civil aircraft registration country code prefix: XY (2016)
Airports: 64 (2013)
country comparison to the world: 76
Airports—with paved runways:
total: 36 (2017)
over 3,047 m: 12 (2017)
2,438 to 3,047 m: 11 (2017)
1,524 to 2,437 m: 12 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 28 (2013)
over 3,047 m: 1 (2013)
1,524 to 2,437 m: 4 (2013)
914 to 1,523 m: 10 (2013)
under 914 m: 13 (2013)
Heliports: 11 (2013)
Pipelines: 3739 km gas, 1321 km oil (2017)
Railways: total: 5,031 km (2008)
narrow gauge: 5,031 km 1.000-m gauge (2008)
country comparison to the world: 40
Roadways: total: 157,000 km (2013)
paved: 34,700 km (2013)
unpaved: 122,300 km (2013)
country comparison to the world: 33
Waterways: 12,800 km (2011)
country comparison to the world: 10
Merchant marine: total: 95
by type: bulk carrier 1, general cargo 41, oil tanker 5, other
48 (2018)
country comparison to the world: 89
Ports and terminals: major seaport(s): Mawlamyine
(Moulmein), Sittwe river port(s): Rangoon (Yangon)
(Rangoon River)','32c2022db276cd4382ef490be3d6101af57d12723128b40a8e62ca90cdaee020','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c02a2aeb7b9a0441bccbe7af957832605dd48d1e24d0393c6f0a6fcbd8b3f9ea',2020,'BI','Burundi','transportation',263,'Civil aircraft registration country code prefix: 9U (2016)
Airports: 7 (2013)
country comparison to the world: 166
Airports—with paved runways:
total: 1 (2019)
over 3,047 m: 1
Airports—with unpaved runways:
total: 6 (2013)
914 to 1,523 m: 4 (2013)
under 914 m: 2 (2013)
Heliports: 1 (2012)
Roadways: total: 12,322 km (2016)
paved: 1,500 km (2016)
unpaved: 10,822 km (2016)
country comparison to the world: 127
Waterways: (mainly on Lake Tanganyika between Bujumbura,
Burundi’s principal port, and lake ports in Tanzania,
Zambia, and the Democratic Republic of the Congo) (2011)
Ports and terminals: Jake port(s): Bujumbura (Lake
Tanganyika)','8f6b0eba7a224565c54d0c664b6d274541d52ccd83a2e29ba96a89c0c07cbbb9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f0ebfdfa2ad4bd23a0efddf5b1090c7f15086cbb0f88cba76a0965e4c6b8962',2020,'CV','Cabo Verde','transportation',272,'National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 5
(2015)
annual passenger traffic on registered air Carriers: 567,182
(2015)
annual freight traffic on registered air carriers: 1,728,152
mt-km (2015)
Civil aircraft registration country code prefix: D4 (2016)
Airports: 9 (2013)
country comparison to the world: 157
Airports—with paved runways:
total: 9 (2017)
over 3,047 m: 1 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 3 (2017)
under 914 m: 2 (2017)
Roadways: total: 1,350 km (2013)
paved: 932 km (2013)
unpaved: 418 km (2013)
country comparison to the world: 172
Merchant marine: total: 43
by type: general cargo 20, oil tanker 3, other 20 (2018)
country comparison to the world: 117
Ports and terminals: Major seaport(s): Porto Grande','ef2ae4f11ba42cad2cb04af0118779368509671c4fccf8d067a31ef7e1441091','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ad8f73841b2277181a89dd4ad66987fc23a187fe9517a9444d6f7a27ea2cd6d',2020,'TH','Thailand','transportation',277,'National air transport system:
number of registered air carriers: 4 (2015)
inventory of registered aircraft operated by air carriers: 10
(2015)
annual passenger traffic on registered air Carriers:
1,103,880 (2015)
annual freight traffic on registered air carriers: 2,301,260
mt-km (2015)
Civil aircraft registration country code prefix: XU (2016)
Airports: 16 (2013)
country comparison to the world: 142
Airports—with paved runways:
total: 6 (2019)
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 1
Airports—with unpaved runways:
total: 10 (2013)
1,524 to 2,437 m: 2 (2013)
914 to 1,523 m: 7 (2013)
under 914 m: 1 (2013)
Heliports: 1 (2013)
Railways: total: 642 km (2014)
narrow gauge: 642 km 1.000-m gauge (2014)
note: under restoration
country comparison to the world: 107
Roadways: total: 47,263 km (2013)
paved: 12,239 km (2013)
unpaved: 35,024 km (2013)
country comparison to the world: 83
Waterways: 3,700 km (mainly on Mekong River) (2012)
country comparison to the world: 28
Merchant marine: total: 364
by type: container ship 2, general cargo 260, oil tanker 25,
other 77 (2018)
country comparison to the world: 46
Ports and terminals: Major seaport(s): Sihanoukville (Kampong
Saom) river port(s): Phnom Penh (Mekong)','7a93af56b7dd1a2ff4d01ee2cfceeee941c2e59bb82e5127a75f7d0a165fa190','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be17c0e98fba43f34cf45c7888bb8fbe13cfe0fcbec61f23557e21c4e3313a4f',2020,'KY','Cayman Islands','transportation',306,'National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 6
(2015)
Civil aircraft registration country code prefix: VP-C (2016)
Airports: 3 (2013)
country comparison to the world: 194
Airports—with paved runways:
total: 3 (2017)
1,524 to 2,437 m: 2 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 1 (2012)
914 to 1,523 m: 1 (2012)
Roadways: total: 785 km (2007)
paved: 785 km (2007)
country comparison to the world: 182
Merchant marine: total: 165
by type: bulk carrier 31, general cargo 4, oil tanker 19,
other 111 (2018)
country comparison to the world: 67
Ports and terminals: Major seaport(s): Cayman Brac, George
Town TRANSNATIONAL ISSUES
Disputes—International: NONe
Illicit drugs: Major offshore financial center; vulnerable to
drug transshipment to the US and Europe','152d949b77db507e7b71f5df1d3a1bb4493108c489bcb2386543c7dba5b25f63','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d89d74b3e7de8e6fd06dc7d398bbd96eaa1105a3abc2bd6ea922ba02fe34cdad',2020,'CG','Congo','transportation',315,'National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 2
(2015)
annual passenger traffic on registered air carriers: 46,364
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: [TL (2016)
Airports: 39 (2013)
country comparison to the world: 106
Airports—with paved runways:
total: 1 (2019)
2,438 to 3,047 m: 1
Airports—with unpaved runways:
total: 37 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 11 (2013)
914 to 1,523 m: 19 (2013)
under 914 m: 6 (2013)
Roadways: total: 24,000 km (2018)
paved: 700 km (2018)
unpaved: 23,300 km (2018)
country comparison to the world: 104
Waterways: km (the primary navigable river is the Ubangi,
which joins the River Congo; it was the traditional route for
the export of products because it connected with the
Congo-Ocean railway at Brazzaville; because of the warfare
on both sides of the River Congo from 1997, importers and
exporters preferred routes through Cameroon) (2011)
country comparison to the world: 34
Ports and terminals: river port(s): Bangui (Oubangui), Nola
(Sangha)
Airports: 1 (2013)
country comparison to the world: 234
Airports—with paved runways:
total: 1 (2019)
under 914 m: 1
Ports and terminals: Major seaport(s): Gustavia
Transportation—note: nearest airport for international flights is
Princess Juliana International Airport (SXM) located on Sint
Maarten SAINT HELENA, ASCENSION, AND TRISTAN DA
CUNHA
Saint Helena
JAMESTOWN
TRISTAN DA CUNHA
Island Queen Mary''s Peak
-# Tristan da Cunha
NIGHTINGALE
ISLANDS
Civil aircraft registration country code prefix: VQ-H (2016)
Airports: 2 (2015)
country comparison to the world: 203
Airports—with paved runways:
total: 2 (2019)
over 3,047 m: 1 Ascension Island—Wideawake Field (ASI)
1,524 to 2,437 m: 1 Saint Helena (HLE);
note—weekly commercial air service to South Africa via
Namibia commenced on 14 October 2017
Roadways: total: 198 km (Saint Helena 138 km, Ascension 40
km, Tristan da Cunha 20 km) (2002) paved: 168 km (Saint
Helena 118 km, Ascension 40 km, Tristan da Cunha 10 km)
(2002)
unpaved: 30 km (Saint Helena 20 km, Tristan da Cunha 10
km) (2002)
country comparison to the world: 202
Ports and terminals: Najor seaport(s): Saint Helena
Saint Helena: Jamestown
Ascension Island: Georgetown
Tristan da Cunha: Calshot Harbor (Edinburgh)
Transportation—note: the new airport on Saint Helena opened
for limited operations in July 2016, and the first commercial
flight took place on 14 October 2017, marking the start of
weekly air service between Saint Helena and South Africa
via Namibia; the military airport on Ascension Island is
closed to civilian traffic; there is no air connection to
Tristan da Cunha and very limited sea connections making
it one of the most isolated communities on the planet
\\ =
{ asama, Mafinga
> 4
Kapiri Mposhi,
*Kabwe
~Mongu LUSAKA,
(~
men Living anf
ae','2daf2c548747d9c7666b7b7eb07b275637b2019aea283b3ea933bdc0174e1cb6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c51b91bd2c4a035104fc2b65c0b58bb7ff94539a4b60a7ea6e165e9540bfb1d3',2020,'AQ','Antarctica','transportation',328,'National air transport system:
number of registered air carriers: 9 (2015)
inventory of registered aircraft operated by air carriers:
173 (2015)
annual passenger traffic on registered air Carriers:
15,006,762 (2015)
annual freight traffic on _ registered air carriers:
1,392,236,000 mt-km (2015)
Civil aircraft registration country code prefix: CC (2016)
Airports: 481 (2013)
country comparison to the world: 14
Airports—with paved runways:
total: 90 (2017)
over 3,047 m: 5 (2017)
2,438 to 3,047 m: 7 (2017)
1,524 to 2,437 m: 23 (2017)
914 to 1,523 m: 31 (2017)
under 914 m: 24 (2017)
Airports—with unpaved runways:
total: 391 (2013)
2,438 to 3,047 m: 5 (2013)
1,524 to 2,437 m: 11 (2013)
914 to 1,523 m: 56 (2013)
under 914 m: 319 (2013)
Heliports: 1 (2013)
Pipelines: 3160 km gas, 781 km liquid petroleum gas, 985
km oil, 722 km refined products (2013) Railways: total: 7,282
km (2014)
narrow gauge: 3,853.5 km 1.000-m gauge (2014)
broad gauge: 3,428 km 1.676-m gauge (1,691 km
electrified) (2014)
country comparison to the world: 30
Roadways: total: 77,801 km (2016)
country comparison to the world: 62
Merchant marine: total: 222
by type: bulk carrier 9, container ship 5, general cargo 58,
oil tanker 15, other 135 (2018) country comparison to the
world: 61
Ports and terminals: Major seaport(s): Coronel, Huasco,
Lirquen, Puerto Ventanas, San Antonio, San Vicente,
Valparaiso container’ port(s) (TEUs): San Antonio
(1,296,890), Valparaiso (1,073,734) (2017)
LNG terminal(s) (import): Mejillones, Quintero','e67bfc2077bd825f12e1b99cb1faf38496fdc3693a03095f559cd0e2e9427541','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb0b01ed2f24d17de5586ab6e96776dfac2e7accd053c4bbc50ea79c67b4417a',2020,'CN','China','transportation',346,'Airports: 1 (2013)
country comparison to the world: 217
Airports—with paved runways:
total: 1 (2019)
1,524 to 2,437 m: 1
Railways: total: 18 km (2017)
standard gauge: 18 km 1.435-m (not in operation) (2017)
note: the 18-km Christmas Island Phosphate Company
Railway between Flying Fish Cove and South Point was
decommissioned in 1987; some tracks and scrap remain in
place country comparison to the world: 134
Roadways: total: 140 km (2011)
paved: 30 km (2011)
unpaved: 110 km (2011)
country comparison to the world: 204
Ports and terminals: Major seaport(s): Flying Fish Cove
Roadways: Ports and terminals: none; offshore anchorage
only TRANSNATIONAL ISSUES
Disputes—International: NONe
National air transport system:
number of registered air carriers: 7 (registered in China)
(2015)
inventory of registered aircraft operated by air carriers:
253 (registered in China) (2015) annual passenger traffic
on registered air carriers: 41,867,157 (2015)
annual freight traffic on registered air carriers: 11.294
billion mt-km (2015)
Civil aircraft registration country code prefix: B-H (2016)
Airports: 2 (2013)
country comparison to the world: 201
Airports—with paved runways:
total: 2 (2019)
over 3,047 m: 1
1,524 to 2,437 m: 1
Heliports: 9 (2013)
Roadways: total: 2,107 km (2017)
paved: 2,107 km (2017)
country comparison to the world: 166
Merchant marine: total: 2,615
by type: bulk carrier 1143, container ship 499, general
cargo 217, oil tanker 355, other 401 (2018) country
comparison to the world: 10
Ports and terminals: Major seaport(s): Hong Kong
container port(s) (TEUs): Hong Kong (20,770,000) (2017)','4910301b00c607fa133177a4daf3a51b490d803f09cd8a00a058c4572638592d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7a407fa4b986077577d0edff241cd7ecbe02b50e14ca223c2f102525ef34ae5',2020,'CC','Cocos (Keeling) Islands','transportation',347,'North Keeling
Island
Horsburgh
Island
Direction Island
Home Isiand
South
Keeling
Islands
South Island','e22bc7c3d391290d54d0f09b52510d949084b222e8a9e27b0d82cb0a10c425f9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe0b0e7d57c5cb2b6bd8068614877d27af2585fcb0d8616cbecc459c88465f91',2020,'CM','Cameroon','transportation',366,'National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 12
(2015)
annual passenger traffic on registered air Carriers: 657,926
(2015)
annual freight traffic on registered air carriers: 2,987,493
mt-km (2015)
Civil aircraft registration country code prefix: TN (2016)
Airports: 27 (2013)
country comparison to the world: 124
Airports—with paved runways:
total: 8 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 1 (2017)
1,524 to 2,437 m: 5 (2017)
Airports—with unpaved runways:
total: 19 (2013)
1,524 to 2,437 m: 8 (2013)
914 to 1,523 m: 9 (2013)
under 914 m: 2 (2013)
Pipelines: 232 km gas, 4 km liquid petroleum gas, 982 km oil
(2013)
Railways: total: 510 km (2014)
narrow gauge: 510 km 1.067-m gauge (2014)
country comparison to the world: 112
Roadways: total: 23,324 km (2017)
paved: 3,111 km (2017)
unpaved: 20,213 km (2017)
note: road network in Congo is composed of 23,324 km of
which 17,000 km are classified as national, departmental,
and routes of local interest: 6,324 km are non-classified
routes country comparison to the world: 106
Waterways: 1,120 km (commercially navigable on Congo and
Oubanqui Rivers above Brazzaville; there are many ferries
across the river to Kinshasa; the Congo south of
Brazzaville-Kinshasa to the coast is not navigable because
of rapids, necessitating a rail connection to Pointe Noire;
other rivers are used for local traffic only) (2011) country
comparison to the world: 61
Merchant marine: total: 16
by type: general cargo 3, oil tanker 2, other 11 (2018)
country comparison to the world: 142
Ports and terminals: Major seaport(s): Pointe-Noire
oil terminal(s): Djeno
river port(s): Brazzaville (Congo)
Impfondo (Oubangi) Ouesso (Sangha) Oyo (Alima)','7fbc5405ad540dafc9476ece3f1bbc3ae99aa5f56c1c8d34299da06617a636e1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37dd0e4545b1887431e84196bbd0c5541f243e6fc77ec00799ff8902d56bda3b',2020,'NI','Nicaragua','transportation',377,'National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 39
(2015)
annual passenger traffic on registered air Carriers:
1,617,075 (2015)
annual freight traffic on registered air carriers: 9,284,160
mt-km (2015)
Civil aircraft registration country code prefix: II (2016)
Airports: 161 (2013)
country comparison to the world: 35
Airports—with paved runways:
total: 47 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 2 (2017)
914 to 1,523 m: 27 (2017)
under 914 m: 16 (2017)
Airports—with unpaved runways:
total: 114 (2013)
914 to 1,523 m: 18 (2013)
under 914 m: 96 (2013)
Pipelines: 662 km refined products (2013)
Railways: total: 278 km (2014)
narrow gauge: 278 km 1.067-m gauge (2014)
note: the entire rail network fell into disrepair and out of
use at the end of the 20th century; since 2005, certain
sections of rail have been rehabilitated country comparison
to the world: 123
Roadways: total: 5,035 km (2017)
country comparison to the world: 143
Waterways: 730 km (seasonally navigable by small craft)
(2011)
country comparison to the world: 74
Merchant marine: total: 11
by type: general cargo 2, other 9 (2018)
country comparison to the world: 148
Ports and terminals: major seaport(s): Atlantic Ocean
(Caribbean)—Puerto Limon, Pacific Ocean—Caldera','2b1813af5416d4dac289c90a13c1bc8fef742537498341cdc472e8be4c6a3db1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3e58f7f73c3a5d4e59ab94b7292ad1a5bb8ff1bac6347ddc27b5a22e1fa8847',2020,'HR','Croatia','transportation',389,'National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 46
(2015)
annual passenger traffic on registered air Carriers:
1,782,666 (2015)
annual freight traffic on registered air carriers: 775,320
mt-km (2015)
Civil aircraft registration country code prefix: 9A (2016)
Airports: 69 (2013)
country comparison to the world: 71
Airports—with paved runways:
total: 24 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 6 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 3 (2017)
under 914 m: 10 (2017)
Airports—with unpaved runways:
total: 45 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 6 (2013)
under 914 m: 38 (2013)
Heliports: 1 (2013)
Pipelines: 2410 km gas, 610 km oil (2011)
Railways: total: 2,722 km (2014)
standard gauge: 2,722 km 1.435-m gauge (980 km
electrified) (2014)
country comparison to the world: 64
Roadways: total: 26,958 km (includes 1,416 km of
expressways) (2015) country comparison to the world: 99
Waterways: 785 km (2009)
country comparison to the world: 73
Merchant marine: total: 131
by type: bulk carrier 28, oil tanker 14, other 89 (2018)
country comparison to the world: 75
Ports and terminals: Major seaport(s): Ploce, Rijeka, Sibenik,
Split oil terminal(s): Omisalj
river port(s): Vukovar (Danube)','7b0787946931bf55f2bcd8ed0a504aaddb722a9a6fff9b55ad766748be2c754e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f46bba348238ec70ef9657a70d9484de75aabbb8a97a010ba5dd024a80c52e44',2020,'HU','Hungary','transportation',403,'National air transport system:
number of registered air carriers: 4 (2015)
inventory of registered aircraft operated by air carriers: 48
(2015)
annual passenger traffic on registered air Carriers:
4,971,616 (2015)
annual freight traffic on registered air carriers: 26,619,650
mt-km (2015)
Civil aircraft registration country code prefix: OK (2016)
Airports: 128 (2013)
country comparison to the world: 46
Airports—with paved runways:
total: 41 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 9 (2017)
1,524 to 2,437 m: 12 (2017)
914 to 1,523 m: 2 (2017)
under 914 m: 16 (2017)
Airports—with unpaved runways:
total: 87 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 25 (2013)
under 914 m: 61 (2013)
Heliports: 1 (2013)
Pipelines: 7,160 km gas, 675 km oil, 94 km refined products
(2016)
Railways: total: 9,408 km (2017)
standard gauge: 9,385 km 1.435-m gauge (3,218 km
electrified) (2017)
narrow gauge: 23 km 0.760-m gauge (2017)
country comparison to the world: 24
Roadways: total: 55,744 km (includes urban and category I,
II, III] roads) (2019) paved: 55,744 km (includes 1,252 km of
expressways) (2019)
country comparison to the world: 81
Waterways: 664 km (principally on Elbe, Vitava, Oder, and
other navigable rivers, lakes, and canals) (2010) country
comparison to the world: 76
Ports and terminals: river port(s): Prague (Vltava), Decin, Usti
nad Labem (Elbe) TRANSNATIONAL ISSUES
Disputes—International: NOnNe
Refugees and internally displaced persons: stateless
persons: 1,502 (2018)
Illicit drugs: transshipment point for Southwest Asian heroin
and minor transit point for Latin American cocaine to
Western Europe; producer of synthetic drugs for local and
regional markets; susceptible to money laundering related
to drug trafficking, organized crime; significant consumer
of ecstasy
National air transport system:
number of registered air carriers: 9 (2015)
inventory of registered aircraft operated by air carriers:
382 (2015)
annual passenger traffic on registered air Carriers:
26,036,010 (2015)
annual freight traffic on _ registered air _ carriers:
945,433,732 mt-km (2015)
Civil aircraft registration country code prefix: | (2016)
Airports: 129 (2013)
country comparison to the world: 45
Airports—with paved runways:
total: 98 (2017)
over 3,047 m: 9 (2017)
2,438 to 3,047 m: 31 (2017)
1,524 to 2,437 m: 18 (2017)
914 to 1,523 m: 29 (2017)
under 914 m: 11 (2017)
Airports—with unpaved runways:
total: 31 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 10 (2013)
under 914 m: 20 (2013)
Heliports: 5 (2013)
Pipelines: 20223 km gas, 1393 km oil, 1574 km refined
products (2013)
Railways: total: 20,182 km (2014)
standard gauge: 18,770.1 km 1.435-m gauge (12,893.6 km
electrified) (2014)
narrow gauge: 122.3 km 1.000-m gauge (122.3 km
electrified) (2014)
1289.3 0.950-m gauge (151.3 km electrified)
country comparison to the world: 15
Roadways: total: 487,700 km (2007)
paved: 487,700 km (includes 6,700 km of expressways)
(2007)
country comparison to the world: 15
Waterways: 2,400 km (used for commercial traffic; of limited
overall value compared to road and rail) (2012) country
comparison to the world: 36
Merchant marine: total: 1,405
by type: bulk carrier 59, container ship 10, general cargo
142, oil tanker 128, other 1066 (2018) country comparison
to the world: 20
Ports and terminals: major seaport(s): Augusta, Cagliari,
Genoa, Livorno, Taranto, Trieste, Venice oil terminal(s):
Melilli (Santa Panagia) oil terminal, Sarroch oil terminal
container port(s) (TEUs): Genoa (2,622,200), Gioia Tauro
(2,448,600) (2017)
LNG terminal(s) (import): La Spezia, Panigaglia, Porto
Levante','1bfb609fe6b413b7d8a8190abcdac0673d3dacf08044c76f13ed89065aa1e0f9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d710a36b0d9920233d141458243f0d19f513cdd151016106967628c68cd6750d',2020,'DK','Denmark','transportation',404,'eokagen,
Alborg, SWEDEN
Randers,
i}
Jutland Anshus
Helsingor,
f Lammetjord
Kolding Fredericia u ° AP OPENHAGEN
4 le dense “Roskilde
Esbjerg ° Sjaeiiand
Ronne,
Bornholm
National air transport system:
number of registered air carriers: 1 (registered in
Denmark) (2015)
inventory of registered aircraft operated by air carriers: 3
(registered in Denmark) (2015) Civil aircraft registration country
code prefix: OY-H (2016)
Airports: 1 (2013)
country comparison to the world: 220
Airports—with paved runways: total: 1 (2019)
1,524 to 2,437 m: 1
Railways: Roadways: total: 960 km (2017)
paved: 500 km (2017)
unpaved: 460 km (2017)
note: those islands not connected by roads (bridges or
tunnels) are connected by seven different ferry links
operated by the nationally owned company SSL; 28 km of
tunnels country comparison to the world: 180
Merchant marine: total: 100
by type: container ship 3, general cargo 42, oil tanker 1,
other 54 (2018)
country comparison to the world: 87
Ports and terminals: Major seaport(s): Fuglafjordur, Torshavn,
Vagur TRANSNATIONAL ISSUES
Disputes—International: because anticipated offshore
hydrocarbon resources have not been realized, earlier
Faroese proposals for full independence have been
deferred; Iceland, the UK, and Ireland dispute Denmark’s
claim to UNCLOS that the Faroe Islands’ continental shelf
extends beyond 200 nm FIJI
Vanua Levu RINGGOLD
. Taveuni
Savusavu NORTHERN
Koro
Lautoka Na
* aA lu
Tomanivi ‘por
Viti Levu *
SUVA sa
Kandavu
island
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 12
(2015)
annual passenger traffic on registered air Carriers:
1,336,976 (2015)
annual freight traffic on registered air carriers: 83,686,504
mt-km (2015)
Civil aircraft registration country code prefix: DQ (2016)
Airports: 28 (2013)
country comparison to the world: 121
Airports—with paved runways:
total: 4 (2017)
over 3,047 m: 1 (2017)
1,524 to 2,437 m: 1 (2017)
914 to 1,523 m: 2 (2017)
Airports—with unpaved runways:
total: 24 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 19 (2013)
Railways: total: 597 km (2008)
narrow gauge: 597 km 0.600-m gauge (2008)
note: belongs to the government-owned Fiji Sugar
Corporation; used to haul sugarcane during the harvest
season, which runs from May to December country
comparison to the world: 109
Roadways: total: 3,440 km (2011)
paved: 1,686 km (2011)
unpaved: 1,754 km (2011)
country comparison to the world: 155
Waterways: 203 km (122 km are navigable by motorized craft
and 200-metric-ton barges) (2012) country comparison to
the world: 97
Merchant marine: total: 60
by type: general cargo 21, oil tanker 1, other 38 (2018)
country comparison to the world: 108
Ports and terminals: ajor seaport(s): Lautoka, Levuka, Suva
National air transport system: number of registered air Carriers:
3 (2015) inventory of registered aircraft operated by air
carriers: 106 (2015) annual passenger traffic on registered
air carriers: 12,277,220 (2015) annual freight traffic on
registered air carriers: 0 mt-km (2015) Civil aircraft
registration country code prefix: LN (2016) Airports: 95 (2013)
country comparison to the world: 61
Airports—with paved runways:
total: 67 (2017)
2,438 to 3,047 m: 14 (2017)
1,524 to 2,437 m: 10 (2017)
914 to 1,523 m: 22 (2017)
under 914 m: 21 (2017)
Airports—with unpaved runways:
total: 28 (2013)
914 to 1,523 m: 6 (2013)
under 914 m: 22 (2013)
Heliports: 1 (2013)
Pipelines: 8520 km gas, 1304 km oil/condensate (2017)
Railways: total: 4,200 km (2019) standard gauge: 4,200 km
1.435-m gauge (2,480 km electrified) (2019) country
comparison to the world: 45
Roadways: total: 94,902 km (includes 455 km _ of
expressways) (2018) country comparison to the world: 52
Waterways: 1,577 km (2010)
country comparison to the world: 51
Merchant marine: total: 1,581
by type: bulk carrier 102, general cargo 249, oil tanker 81,
other 1149 (2018) country comparison to the world: 17
Ports and terminals: Major seaport(s): Bergen, Haugesund,
Maaloy, Mongstad, Narvik, Sture LNG terminal(s) (export):
Kamoy, Kollsnes, Melkoya Island LNG terminal(s) (import):
Fredrikstad, Mosjoen
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 45 (2015) annual passenger traffic on registered
air carriers: 6,365,784 (2015) annual freight traffic on
registered air carriers: 412,234,008 mt-km (2015) Civil
aircraft registration country code prefix: A4O (2016) Airports: 132
(2013)
country comparison to the world: 44
Airports—with paved runways:
total: 13 (2017)
over 3,047 m: 7 (2017)
2,438 to 3,047 m: 5 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 119 (2013)
over 3,047 m: 2 (2013)
2,438 to 3,047 m: 7 (2013)
1,524 to 2,437 m: 51 (2013)
914 to 1,523 m: 33 (2013)
under 914 m: 26 (2013)
Heliports: 3 (2013)
Pipelines: 106 km condensate, 4224 km gas, 3558 km oil, 33
km oil/gas/water, 264 km refined products (2013) Railways:
Roadways: total: 60,230 km (2012) paved: 29,685 km
(includes 1,943 km of expressways) (2012) unpaved: 30,545
km (2012)
country comparison to the world: 74
Merchant marine: total: 51
by type: general cargo 9, other 42 (2018) country
comparison to the world: 114
Ports and terminals: Major seaport(s): Mina’ Qabus, Salalah,
Suhar container port(s) (TEUs): Salalah (3,946,421) (2017)
LNG terminal(s) (export): Qalhat','13b05bcc2068f2faa828c3c3562e46d051eeff0a7138610bc85b2118052f5482','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf14ca11c4e73970153f7a23018ed0ae36e47509283818aaac01dd6a26c1e569',2020,'DJ','Djibouti','transportation',422,'National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 4
(2015)
Civil aircraft registration country code prefix: J2 (2016)
Airports: 13 (2013)
country comparison to the world: 151
Airports—with paved runways:
total: 3 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 1 (2017)
1,524 to 2,437 m: 1 (2017)
Airports—with unpaved runways:
total: 10 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 7 (2013)
under 914 m: 2 (2013)
Railways: total: 97 km (Djibouti segment of the 756 km Addis
Ababa-Djibouti railway) (2017) standard gauge: 97 km
1.435-m gauge (2017)
country comparison to the world: 127
Roadways: total: 2,893 km (2013)
country comparison to the world: 159
Merchant marine: total: 15
by type: other 15 (2018)
country comparison to the world: 144
Ports and terminals: Major seaport(s): Djibouti','b6b344c59596d5e919c66bb0531a6b4933d050f5a63ba5aa1ef909e2c374708c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbc4c611302f00753a5924b3c2c9f6b5b5128573171aa1425c2e4308a3031143',2020,'CO','Colombia','transportation',444,'National air transport system:
number of registered air carriers: 7 (2015)
inventory of registered aircraft operated by air carriers: 35
(2015)
annual passenger traffic on registered air Carriers:
9,762,485 (2015)
annual freight traffic on registered air carriers: 86,128,720
mt-km (2015)
Civil aircraft registration country code prefix: HC (2016)
Airports: 432 (2013)
country comparison to the world: 19
Airports—with paved runways:
total: 104 (2017)
over 3,047 m: 4 (2017)
2,438 to 3,047 m: 5 (2017)
1,524 to 2,437 m: 18 (2017)
914 to 1,523 m: 26 (2017)
under 914 m: 51 (2017)
Airports—with unpaved runways:
total: 328 (2013)
914 to 1,523 m: 37 (2013)
under 914 m: 291 (2013)
Heliports: 2 (2013)
Pipelines: 485 km extra heavy crude, 123 km gas, 2131 km
oil, 1526 km refined products (2017) Railways: total: 965 km
(2017)
narrow gauge: 965 km 1.067-m gauge (2017)
note: passenger service limited to certain sections of track,
mostly for tourist trains
country comparison to the world: 91
Roadways: total: 43,216 km (2015)
paved: 8,161 km (2015)
unpaved: 35,055 km (2015)
country comparison to the world: 86
Waterways: 1,500 km (most inaccessible) (2012)
country comparison to the world: 52
Merchant marine: total: 137
by type: container ship 1, general cargo 6, oil tanker 34,
other 96 (2018)
country comparison to the world: 74
Ports and terminals: Major seaport(s): Esmeraldas, Manta,
Puerto Bolivar container port(s) (TEUs): Guayaquil
(1,871,591) (2017)
river port(s): Guayaquil (Guayas)','75f39a5c3c06e0d90ea93a3fe93eec39c442783c21791a66df23d4f2e4d9a8ba','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc98f65fcf8bf7f5e55e3bedbe2516e2285a452c43780db4b80e00a9960b8878',2020,'GT','Guatemala','transportation',456,'National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 32
(2015)
annual passenger traffic on registered air Carriers:
2,997,649 (2015)
annual freight traffic on registered air carriers: 13,873,884
mt-km (2015)
Civil aircraft registration country code prefix: YS (2016)
Airports: 68 (2013)
country comparison to the world: 73
Airports—with paved runways:
total: 5 (2017)
over 3,047 m: 1 (2017)
1,524 to 2,437 m: 1 (2017)
914 to 1,523 m: 2 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 63 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 11 (2013)
under 914 m: 51 (2013)
Heliports: 2 (2013)
Railways: total: 13 km (2014)
narrow gauge: 12.5 km 0.914-m gauge (2014)
country comparison to the world: 135
Roadways: total: 9,012 km (2017)
paved: 5,341 km (2017)
unpaved: 3,671 km (2017)
country comparison to the world: 133
Waterways: (Rio Lempa River is partially navigable by small
craft) (2011)
Merchant marine: total: 2
by type: other 2 (2018)
country comparison to the world: 169
Ports and terminals: Major seaport(s): Puerto Cutuco
oil terminal(s): Acajutla offshore terminal','a1cf5553c8a12d624d0264e03eee3a0a00c833901a40f6b9da0d4087e8fa5ff1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a266b6e4ce08de2976aaca9835be2eeff1994e819e2afa97a7adb23666b52ba',2020,'YE','Yemen','transportation',501,'Airports: 3 (2013)
Airports—with paved runways:
total: 1,882 (2017)
over 3,047 m: 120 (2017)
2,438 to 3,047 m: 341 (2017)
1,524 to 2,437 m: 507 (2017)
914 to 1,523 m: 425 (2017)
under 914 m: 489 (2017)
Airports—with unpaved runways:
total: 1,244 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 15 (2013)
914 to 1,523 m: 245 (2013)
under 914 m: 982 (2013)
Heliports: 90 (2013)
Railways: total: 230,548 km (2013)
Roadways: total: 10,582,653 km (2013)
Waterways: 53,384 km (2013)
Ports and terminals: Major port(s): Antwerp (Belgium),
Barcelona (Spain), Braila (Romania), Bremen (Germany),
Burgas (Bulgaria), Constanta (Romania), Copenhagen
(Denmark), Galati (Romania), Gdansk (Poland), Hamburg
(Germany), Helsinki (Finland), Las Palmas (Canary Islands,
Spain), Le Havre (France), Lisbon (Portugal), Marseille
(France), Naples (Italy), Peiraiefs or Piraeus (Greece), Riga
(Latvia), Rotterdam (Netherlands), Split (Croatia),
Stockholm (Sweden), Talinn (Estonia), Tulcea (Romania),
Varna (Bulgaria) TRANSNATIONAL ISSUES
Disputes—International: aS a political union, the EU has no
border disputes with neighboring countries, but Estonia
has no land boundary agreements with Russia, Slovenia
disputes its land and maritime boundaries with Croatia,
and Spain has territorial and maritime disputes with
Morocco and with the UK over Gibraltar; the EU has set up
a Schengen area—consisting of 22 EU member states that
have signed the convention implementing the Schengen
agreements or “acquis” (1985 and 1990) on the free
movement of persons and the harmonization of border
controls in Europe; these agreements became incorporated
into EU law with the implementation of the 1997 Treaty of
Amsterdam on 1 May 1999; in addition, non-EU states
Iceland and Norway (as part of the Nordic Union) have
been included in the Schengen area since 1996 (full
members in 2001), Switzerland since 2008, and
Liechtenstein since 2011 bringing the total current
membership to 26; the UK (since 2000) and Ireland (since
2002) take part in only some aspects of the Schengen area,
especially with respect to police and criminal matters; nine
of the 13 new member states that joined the EU since 2004
joined Schengen on 21 December 2007; of the four
remaining EU states, Romania, Bulgaria, and Croatia are
obligated to eventually join, while Cyprus’ entry is held up
by the ongoing Cyprus dispute
FALKLAND ISLANDS (ISLAS
MALVINAS)
West
Falkland Port Howard Mount
- Usbome
4 *
Weddelt \\ STANLEY
eettlement Goose Green
Settlement
East
Falkland
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 5
(2015)
Civil aircraft registration country code prefix: VP-F (2016)
Airports: 7 (2013)
country comparison to the world: 168
Airports—with paved runways:
total: 2 (2019)
2,438 to 3,047 m: 1
914 to 1,523 m: 1
Airports—with unpaved runways:
total: 5 (2013)
under 914 m: 5 (2013)
Roadways: total: 440 km (2008)
paved: 50 km (2008)
unpaved: 390 km (2008)
country comparison to the world: 192
Merchant marine: total: 3
by type: general cargo 1, other 2 (2018)
country comparison to the world: 167
Ports and terminals: Major seaport(s): Stanley','d3ec97df362ed08923a761bd7ab47cba2eca839ed35135979ff1a3156b0edf0c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02dc7ceba6566237c7bd60f0bba25f82efa74bf6421129eb537fd94e96d58fcc',2020,'EE','Estonia','transportation',518,'National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 73
(2015)
annual passenger traffic on registered air Carriers:
9,972,333 (2015)
annual freight traffic on registered air carriers: 713.484
million mt-km (2015)
Civil aircraft registration country code prefix: OH (2016)
Airports: 148 (2013)
country comparison to the world: 38
Airports—with paved runways:
total: 74 (2017)
over 3,047 m: 3 (2017)
2,438 to 3,047 m: 26 (2017)
1,524 to 2,437 m: 10 (2017)
914 to 1,523 m: 21 (2017)
under 914 m: 14 (2017)
Airports—with unpaved runways:
total: 74 (2013)
914 to 1,523 m: 3 (2013)
under 914 m: 71 (2013)
Pipelines: 1288 km gas transmission pipes, 1976 km
distribution pipes (2016)
Railways: total: 5,926 km (2016)
broad gauge: 5,926 km 1.524-m gauge (3,270 km
electrified) (2016)
country comparison to the world: 32
Roadways: total: 454,000 km (2012)
highways: 78,000 km (50,000 paved, including 700 km of
expressways; 28,000 unpaved) (2012) private and forest roads:
350,000 km (2012)
urban: 26,000 km (2012)
country comparison to the world: 16
Waterways: 8,000 km (includes Saimaa Canal system of
3,577 km; southern part leased from Russia; water
transport used frequently in the summer and widely
replaced with sledges on the ice in winter; there are
187,888 lakes in Finland that cover 31,500 km); Finland
also maintains 8,200 km of coastal fairways (2013) country
comparison to the world: 17
Merchant marine: total: 259
by type: bulk carrier 7, container ship 1, general cargo 88,
oil tanker 4, other 159 (2018) country comparison to the
world: 57
Ports and terminals: Major seaport(s): Helsinki, Kotka,
Naantali, Porvoo, Raahe, Rauma TRANSNATIONAL ISSUES
Disputes—International: various groups in Finland advocate
restoration of Karelia and other areas ceded to the former
Soviet Union, but the Finnish Government asserts no
territorial demands Refugees and internally displaced persons:
refugees (country of origin): 8,523 (Iraq) (2018) stateless
persons: 2,759 (2018)','d67211d800439ef99dc3736b089c63c4e441501a96059d4fa058a86c285820aa','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff03d5306a907cdb3fa0526a117915a013c4c77cdda84a28e74746db7b383aff',2020,'FR','France','transportation',519,'UNITED
KINGDOM -<
Cherbourge te Havre
$=eRouen
@Biest PARIS*
<Orléans
Jours
*
Nantes
._ Lyon,
Saint-Etienne, ;
“Bordeaux
Toulouse, Montpellier
Ice, MONACO
-Marseilie
Toulon
Corsica
(FR)
National air transport system:
number of registered air carriers: 30 (2015)
inventory of registered aircraft operated by air carriers:
485 (2015)
annual passenger traffic on registered air Carriers:
65,039,503 (2015)
annual freight traffic on _ registered air _ carriers:
4,098,310,000 mt-km (2015)
Civil aircraft registration country code prefix: F (2016)
Airports: 464 (2013)
country comparison to the world: 16
Airports—with paved runways:
total: 294 (2017)
over 3,047 m: 14 (2017)
2,438 to 3,047 m: 25 (2017)
1,524 to 2,437 m: 97 (2017)
914 to 1,523 m: 83 (2017)
under 914 m: 75 (2017)
Airports—with unpaved runways:
total: 170 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 64 (2013)
under 914 m: 105 (2013)
Heliports: 1 (2013)
Pipelines: 15322 km gas, 2939 km oil, 5084 km refined
products (2013)
Railways: total: 29,640 km (2014)
standard gauge: 29,473 km 1.435-m gauge (15,561 km
electrified) (2014)
narrow gauge: 167 km 1.000-m gauge (63 km electrified)
(2014)
country comparison to the world: 10
Roadways: total: 1,053,215 km (2011)
urban: 654,201 km (2011)
non-urban: 399,014 km (2011)
country comparison to the world: 7
Waterways: metropolitan France: 8,501 km (1,621 km
navigable by craft up to 3,000 metric tons) (2010) Merchant
marine: total: 555
by type: container ship 24, general cargo 73, oil tanker 29,
other 429 (2018)
note: includes Monaco
country comparison to the world: 39
Ports and terminals: major seaport(s): Brest, Calais,
Dunkerque, Le Havre, Marseille, Nantes, container port(s)
(TEUs): Le Havre (2,870,000) (2017)
LNG terminal(s) (import): Fos Cavaou, Fos Tonkin, Montoir
de Bretagne
river port(s): Paris, Rouen (Seine)
cruise/ferry port(s): Calais, Cherbourg, Le Havre,
Strasbourg (Rhine) Bordeaux (Garronne)
Transportation—note: begun in 1988 and completed in 1994,
the Channel Tunnel (nicknamed the Chunnel) is a 50.5-km
(31.4-mi) rail tunnel beneath the English Channel at the
Strait of Dover that runs from Folkestone, Kent, England to
Coquelles, Pas-de-Calais in northern France; it is the only
fixed link between the island of Great Britain and mainland
Europe TRANSNATIONAL ISSUES
Disputes—International: Madagascar claims the French
territories of Bassas da India, Europa Island, Glorioso
Islands, and Juan de Nova Island; Comoros claims Mayotte;
Mauritius claims Tromelin Island; territorial dispute
between Suriname and the French overseas department of
French Guiana; France asserts a territorial claim in
Antarctica (Adelie Land); France and Vanuatu claim
Matthew and Hunter Islands, east of New Caledonia
Refugees and internally displaced persons: refugees (country of
origin): 23,918 (Sri Lanka), 18,534 (Afghanistan), 16,484
(Democratic Republic of the Congo), 15,898 (Russia),
15,822 (Syria), 14,700 (Sudan), 13,778 (Serbia and
Kosovo), 11,196 (Turkey), 11,193 (Cambodia), 9,264
(Guinea), 8,131 (Iraq), 7,821 (Vietnam), 6,617 (Laos), 5,419
(Mauritania) (2018) stateless persons: 1,493 (2018)
Illicit drugs: Metropolitan France: transshipment point for
South American cocaine, Southwest Asian heroin, and
European synthetics; French Guiana: small amount of
marijuana grown for local consumption; minor
transshipment point to Europe; Martinique: transshipment
point for cocaine and marijuana bound for the US and
Europe','88610b70d6c9e00e7d4acc3bd09da415da5d492e6b4898944f0a9582982eed4e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a99d44a4df0b210f7a30e9c526a3d930547159db2d3c515383d99bbc2e221f28',2020,'PF','French Polynesia','transportation',520,'iLes
KIRIBATI Taiohae® MARQUISES
A,
Chip,
<
Makatea_
Uturoa’ GPAPEETE
a wa
ahiti Mont Orohena
r
‘SLANDS
a“
,Mataura Mururoa~* Rikitoa a
LES
GAMBIER
National air transport system:
number of registered air carriers: 2 (registered in France)
(2015)
inventory of registered aircraft operated by air carriers: 21
(registered in France) (2015) Civil aircraft registration country
code prefix: F-OH (2016)
Airports: 54 (2013)
country comparison to the world: 86
Airports—with paved runways:
total: 45 (2017)
over 3,047 m: 2 (2017)
1,524 to 2,437 m: 5 (2017)
914 to 1,523 m: 33 (2017)
under 914 m: 5 (2017)
Airports—with unpaved runways:
total: 9 (2013)
914 to 1,523 m: 4 (2013)
under 914 m: 5 (2013)
Heliports: 1 (2013)
Roadways: total: 2,590 km (1999)
paved: 1,735 km (1999)
unpaved: 855 km (1999)
country comparison to the world: 163
Merchant marine: total: 17
by type: general cargo 8, other 9 (2018)
country comparison to the world: 141
Ports and terminals: Major seaport(s): Papeete
Airports: 4 (2013)
country comparison to the world: 188
Roadways: Ports and terminals: none; offshore anchorage
only
National air transport system:
number of registered air carriers: 5 (2015)
inventory of registered aircraft operated by air carriers: 7
(2015)
annual passenger traffic on registered air carriers: 137,331
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: [TR (2016)
Airports: 44 (2013)
country comparison to the world: 96
Airports—with paved runways:
total: 14 (2019)
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 9
914 to 1,523 m: 1
under 914 m: 1
Airports—with unpaved runways:
total: 30 (2013)
1,524 to 2,437 m: 7 (2013)
914 to 1,523 m: 9 (2013)
under 914 m: 14 (2013)
Pipelines: 807 km gas,1639 km oil,3 km water (2013)
Railways: total: 649 km (2014)
standard gauge: 649 km 1.435-m gauge (2014)
country comparison to the world: 106
Roadways: total: 14,300 km (2001)
paved: 900 km (2001)
unpaved: 13,400 km (2001)
country comparison to the world: 124
Waterways: 1,600 km (310 km on Ogooue River) (2010)
country comparison to the world: 48
Merchant marine: total: 29
by type: general cargo 11, oil tanker 1, other 17 (2018)
country comparison to the world: 127
Ports and terminals: Major seaport(s): Libreville, Owendo,
Port-Gentil oil terminal(s): Gamba, Lucina','85b279f6dec68726d20ba3bb921c900782baca9b83f21335a79c5bf7fb405f24','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be0df328e6425d04508d6e9400aa4c24a8e4ff208c0d2496d56ca7c4eaa585d8',2020,'IL','Israel','transportation',533,'Airports: 1 (2013)
country comparison to the world: 222
Airports—with paved runways:
total: 1 (2019)
under 914 m: 1
note: non-operational
Heliports: 1 (2013)
Roadways: note: see entry for the West Bank
Ports and terminals: Major seaport(s): Gaza
National air transport system:
number of registered air carriers: 5 (2015)
inventory of registered aircraft operated by air carriers: 13
(2015)
annual passenger traffic on registered air carriers: 232,263
(2015)
annual freight traffic on registered air carriers: 185,040
mt-km (2015)
Civil aircraft registration country code prefix: 4L (2016)
Airports: 22 (2013)
country comparison to the world: 135
Airports—with paved runways:
total: 18 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 7 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 5 (2017)
under 914 m: 2 (2017)
Airports—with unpaved runways:
total: 4 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 1 (2013)
Heliports: 2 (2013)
Pipelines: 1596 km gas, 1175 km oil (2013)
Railways: total: 1,363 km (2014)
narrow gauge: 37 km 0.912-m gauge (37 km electrified)
(2014)
broad gauge: 1,326 km 1.520-m gauge (1,251 km
electrified) (2014)
country comparison to the world: 84
Roadways: total: 20,295 km (2018)
country comparison to the world: 111
Merchant marine: total: 82
by type: bulk carrier 1, general cargo 24, oil tanker 2, other
55 (2018)
country comparison to the world: 96
Ports and terminals: Major seaport(s): Black Sea—Bat’umi,
P’ot’i TRANSNATIONAL ISSUES
Disputes—International: Russia’s military support and
subsequent recognition of Abkhazia and South Ossetia
independence in 2008 continue to sour relations with
Georgia Refugees and internally displaced persons: [DPs: 293,000
(displaced in the 1990s as a result of armed conflict in the
breakaway republics of Abkhazia and South Ossetia;
displaced in 2008 by fighting between Georgia and Russia
over South Ossetia) (2018) stateless persons: 566 (2018)
Illicit drugs: limited cultivation of cannabis and opium poppy,
mostly for domestic consumption; used as transshipment
point for opiates via Central Asia to Western Europe and
Russia GERMANY
fostock,
*LUbeck
*Hamburg
*,
Bremen BERLIN
Hannover, *
*Magdeburg
Duisburg
yFssen Leipzig
.
*Disseldorf *
{> 4Cologne — Dresden®
jonn
Munich,','8456b7f678872f6d147e40a938a23100b0473b6e0a6aa8e51e15190a23770449','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d91dcbbbe40e01c4c5ad91843bb2e79c2e380e7bf13fb17da5f84793e7b01ef',2020,'AT','Austria','transportation',537,'9 80 100km
ty
° 50 100 mi
Zugspitze
National air transport system:
number of registered air carriers: 20 (2015)
inventory of registered aircraft operated by air carriers:
1,113 (2015)
annual passenger traffic on registered air Carriers:
115,540,886 (2015)
annual freight traffic on _ registered air _ carriers:
6,985,007,915 mt-km (2015)
Civil aircraft registration country code prefix: D (2016)
Airports: 539 (2013)
country comparison to the world: 12
Airports—with paved runways:
total: 318 (2017)
over 3,047 m: 14 (2017)
2,438 to 3,047 m: 49 (2017)
1,524 to 2,437 m: 60 (2017)
914 to 1,523 m: 70 (2017)
under 914 m: 125 (2017)
Airports—with unpaved runways:
total: 221 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 35 (2013)
under 914 m: 185 (2013)
Heliports: 23 (2013)
Pipelines: 37 km condensate, 26985 km gas, 2400 km oil,
4479 km refined products, 8 km water (2013) Railways: total:
33,590 km (2017)
standard gauge: 33,331 km 1.435-m gauge (19,973 km
electrified) (2015)
narrow gauge: 220 km 1.000-m gauge (79 km electrified)
15 km 0.900-m gauge, 24 km 0.750-m gauge (2015)
country comparison to the world: 7
Roadways: total: 625,000 km (2017)
paved: 625,000 km (includes 12,996 km of expressways)
(2017)
note: includes local roads
country comparison to the world: 12
Waterways: 7,467 km (Rhine River carries most goods; Main-
Danube Canal links North Sea and Black Sea) (2012)
country comparison to the world: 18
Merchant marine: total: 629
by type: bulk carrier 1, container ship 107, general cargo
92, oil tanker 36, other 393 (2018) country comparison to
the world: 33
Ports and terminals: Major seaport(s): Baltic Sea—Rostock
oil terminal(s): Brunsbuttel Canal terminals
container port(s) (TEUs): Bremen/Bremerhaven
(5,510,000), Hamburg (8,860,000) (2017) LNG terminal(s)
(import): Hamburg
river port(s): Bremen (Weser)
North Sea—Wilhelmshaven Bremerhaven (Geeste)
Duisburg, Karlsruhe, Neuss-Dusseldorf (Rhine)
Brunsbuttel, Hamburg (Elbe) Lubeck (Wakenitz)','a50f858f14263499f52f52299520583dd844421709d60e8f7f5d14dcce76c910','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9361f414cb060f6ed100a5972b80554375d54e889a817e47aa1bd19da0878152',2020,'GD','Grenada','transportation',559,'National air transport system:
number of registered air carriers: 0 (2015)
inventory of registered aircraft operated by air carriers: 0
(2015)
annual passenger traffic on registered air carriers: 0 (2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: J3 (2016)
Airports: 3 (2013)
country comparison to the world: 195
Airports—with paved runways: total: 3 (2017)
2,438 to 3,047 m: 1 (2017)
1,524 to 2,437 m: 1 (2017)
under 914 m: 1 (2017)
Roadways: total: 1,127 km (2017)
paved: 902 km (2017)
unpaved: 225 km (2017)
country comparison to the world: 176
Merchant marine: total: 6
by type: general cargo 3, other 3 (2018)
country comparison to the world: 161
Ports and terminals: Major seaport(s): Saint George’s
Airports: 5 (2013)
country comparison to the world: 180
Airports—with paved runways:
total: 4 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 1 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 1 (2013)
under 914 m: 1 (2013)
Roadways: total: 1,045 km (2008)
country comparison to the world: 178
Merchant marine: total: 3
by type: other 3 (2018)
country comparison to the world: 168
Ports and terminals: Major seaport(s): Apra Harbor','ad67931c9ab1663aa65ade319571e6bebf2383ea2df46a2e0703268ccb3e0320','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f92cc15b46c8a167ab7dc7ec72dccebb8436c50f61b4324e0531166b72fd3028',2020,'SV','El Salvador','transportation',570,'National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 8
(2015)
annual passenger traffic on registered air carriers: 93,129
(2015)
annual freight traffic on registered air carriers: 455,520
mt-km (2015)
Civil aircraft registration country code prefix: [G (2016)
Airports: 291 (2013)
country comparison to the world: 23
Airports—with paved runways:
total: 16 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 4 (2017)
914 to 1,523 m: 6 (2017)
under 914 m: 4 (2017)
Airports—with unpaved runways:
total: 275 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 2 (2013)
914 to 1,523 m: 77 (2013)
under 914 m: 195 (2013)
Heliports: 1 (2013)
Pipelines: 480 km oil (2013)
Railways: total: 800 km (2018)
narrow gauge: 800 km 0.914-m gauge (2018)
note: despite the existence of a railway network, all rail
service was suspended in 2007 and no passenger or freight
train currently runs in the country (2018) country
comparison to the world: 97
Roadways: total: 17,621 km (2016)
paved: 7,489 km (2016)
unpaved: 10,132 km (includes 4,960 km of rural roads)
(2016)
country comparison to the world: 117
Waterways: 990 km (260 km navigable year round; additional
730 km navigable during high-water season) (2012)
country comparison to the world: 65
Merchant marine: total: 9
by type: oil tanker 1, other 8 (2018)
country comparison to the world: 155
Ports and terminals: Major seaport(s): Puerto Quetzal, Santo
Tomas de Castilla TRANSNATIONAL ISSUES
Disputes—International: annual ministerial meetings under the
Organization of American States-initiated Agreement on
the Framework for Negotiations and Confidence Building
Measures continue to address Guatemalan land and
maritime claims in Belize and the Caribbean Sea;
Guatemala persists in its territorial claim to half of Belize,
but agrees to Line of Adjacency to keep Guatemalan
squatters out of Belize’s forested interior; both countries
agreed in April 2012 to hold simultaneous referenda,
scheduled for 6 October 2013, to decide whether to refer
the dispute to the ICJ for binding resolution, but this vote
was suspended indefinitely; Mexico must deal with
thousands of impoverished Guatemalans and other Central
Americans who cross the porous border looking for work in
Mexico and the US
Refugees and internally displaced persons: IDPs: 242,000 (more
than three decades of internal conflict that ended in 1996
displaced mainly the indigenous Maya population and rural
peasants; ongoing drug cartel and gang violence) (2018)
Illicit drugs: Major transit country for cocaine and heroin; it is
estimated that 1,000 mt of cocaine are smuggled through
the country each year, primarily destined for the US
market; in 2016, the Guatamalan government estimated
that an average of 4,500 hectares of opium poppy were
being cultivated; marijuana cultivation for mostly domestic
consumption; proximity to Mexico makes Guatemala a
major staging area for drugs (particularly for cocaine);
money laundering is a serious problem; corruption is a
major problem GUERNSEY
Burhou
St. Anine®
Alderney
Guernsey aaa
National air transport system: number of registered air Carriers:
2 (registered in UK) (2015) inventory of registered aircraft
operated by air carriers: 11 (registered in UK) (2015)
Airports: 2 (2013)
country comparison to the world: 200
Airports—with paved runways:
total: 2 (2019)
1,524 to 2,437 m: 1
under 914 m: 1
Roadways: total: 260 km (2017)
country comparison to the world: 198
Ports and terminals: Major seaport(s): Braye Bay, Saint Peter
Port TRANSNATIONAL ISSUES
Disputes—International: NONe
THE GAMBIA
*Kankan
Kissidougou
SIERRA
LEONE','21c43102cde961511680669d38514c2316ccb216e605fabf7d31d0a79b5e2c7b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de067e62d09435880d7ad08f7d1df342d784399939f4544377dace4c4046d85d',2020,'LR','Liberia','transportation',579,'Civil aircraft registration country code prefix: 3.X (2016)
Airports: 16 (2013)
country comparison to the world: 143
Airports—with paved runways:
total: 4 (2019)
over 3,047 m: 1
1,524 to 2,437 m: 3
Airports—with unpaved runways:
total: 12 (2013)
1,524 to 2,437 m: 7 (2013)
914 to 1,523 m: 3 (2013)
under 914 m: 2 (2013)
Railways: total: 1,086 km (2017)
standard gauge: 279 km 1.435-m gauge (2017)
narrow gauge: 807 km 1.000-m gauge (2017)
country comparison to the world: 88
Roadways: total: 44,301 km (2018)
paved: 3,346 km (2018)
unpaved: 40,955 km (2018)
country comparison to the world: 84
Waterways: 1,300 km (navigable by shallow-draft native craft
in the northern part of the Niger River system) (2011)
country comparison to the world: 54
Merchant marine: total: 1
by type: other 1 (2018)
country comparison to the world: 171
Ports and terminals: Major seaport(s): Conakry, Kamsar','1d30eb3e2466ec2bb0879d35dbb5c2df7b1579eaeaf2c338f60d2ac7b94db564','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8b705e788f29e16769b2fb4e5f28e7d0b9d6671c9646eae2dd10892058ae2a2',2020,'IE','Ireland','transportation',602,'Civil aircraft registration country code prefix: M (2016)
Airports: 1 (2013)
country comparison to the world: 224
Airports—with paved runways:
total: 1 (2019)
1,524 to 2,437 m: 1
Railways: total: 63 km (2008)
narrow gauge: 6 km 1.076-m gauge (6 km electrified)
(2008)
597 0.914-m gauge (29 km electrified)
note: primarily summer tourist attractions
country comparison to the world: 130
Roadways: total: 500 km (2008)
country comparison to the world: 190
Ports and terminals: Major seaport(s): Douglas, Ramsey','1cb89ae42712a8d4082fb42ea30e96656752ee54a4f103f5b718379730e2de57','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('881a84111a1bf6c6e4ce247b5b4a333d0eb9d0d839ca5beed4f9bcd4795778a0',2020,'CU','Cuba','transportation',614,'National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 5
(2015)
annual passenger traffic on registered air carriers: 92,836
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: GY (2016)
Airports: 28 (2013)
country comparison to the world: 122
Airports—with paved runways: total: 11 (2017)
2,438 to 3,047 m: 2 (2017)
914 to 1,523 m: 4 (2017)
under 914 m: 5 (2017)
Airports—with unpaved runways:
total: 17 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 16 (2013)
Roadways: total: 22,121 km (includes 44 km of expressways)
(2011) paved: 16,148 km (2011)
unpaved: 5,973 km (2011)
country comparison to the world: 108
Merchant marine: total: 43
by type: bulk carrier 1, container ship 8, general cargo 10,
oil tanker 1, other 23 (2018) country comparison to the
world: 118
Ports and terminals: major seaport(s): Discovery Bay (Port
Rhoades), Kingston, Montego Bay, Port Antonio, Port
Esquivel, Port Kaiser, Rocky Point container port(s) (TEUs):
Kingston (1,681,706) (2017)
Airports: 1 (2013)
country comparison to the world: 225
Airports—with unpaved runways:
total: 1 (2013)
1,524 to 2,437 m: 1 (2013)
Roadways: Ports and terminals: none; offshore anchorage
only
National air transport system:
number of registered air carriers: 2 (registered in UK)
(2015)
inventory of registered aircraft operated by air carriers: 11
(registered in UK) (2015) Airports: 1 (2013)
country comparison to the world: 226
Airports—with paved runways:
total: 1 (2019)
1,524 to 2,437 m: 1
Roadways
total: 576 km (2010)
country comparison to the world: 186
Ports and terminals: Major seaport(s): Gorey, Saint Aubin,
Saint Helier TRANSNATIONAL ISSUES
Disputes—International: NONe','02421fc6bcdd2acafa9c6716784d6efae11313789a4e8b496038af6b1e43d9e0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7b580ce3f584f433dab99faa9001b1f9965c31be6336ec09c902498161edd9e',2020,'KZ','Kazakhstan','transportation',636,'National air transport system:
number of registered air carriers: 16 (2015)
inventory of registered aircraft operated by air carriers:
106 (2015)
annual passenger traffic on registered air Carriers:
4,874,590 (2015)
annual freight traffic on _ registered air carriers:
286,414,683 mt-km (2015)
Civil aircraft registration country code prefix: 5Y (2016)
Airports: 197 (2013)
country comparison to the world: 28
Airports—with paved runways:
total: 16 (2017)
over 3,047 m: 5 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 2 (2017)
914 to 1,523 m: 6 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 181 (2013)
1,524 to 2,437 m: 14 (2013)
914 to 1,523 m: 107 (2013)
under 914 m: 60 (2013)
Pipelines: 4 km oil, 1,432 km refined products (2018)
Railways: total: 3,819 km (2018)
standard gauge: 485 km 1.435-m gauge (2018)
narrow gauge: 3,334 km 1.000-m gauge (2018)
country comparison to the world: 52
Roadways: total: 177,800 km (2018)
paved: 14,420 km (8,500 km highways, 1,872 urban roads,
and 4,048 rural roads) (2017) unpaved: 147,032 km (2017)
country comparison to the world: 31
Waterways: none specifically; the only significant inland
waterway is the part of Lake Victoria within the boundaries
of Kenya; Kisumu is the main port and has ferry
connections to Uganda and Tanzania (2011) Merchant marine:
total: 22
by type: general cargo 1, oil tanker 2, other 19 (2018)
country comparison to the world: 137
Ports and terminals: Major seaport(s): Kisumu, Mombasa
LNG terminal(s) (import): Mombasa
Civil aircraft registration country code prefix: [3 (2016)
Airports: 19 (2013)
country comparison to the world: 137
Airports—with paved runways:
total: 4 (2017)
1,524 to 2,437 m: 4 (2017)
Airports—with unpaved runways:
total: 15 (2013)
914 to 1,523 m: 10 (2013)
under 914 m: 5 (2013)
Roadways: total: 670 km (2017)
country comparison to the world: 184
Waterways: 5 km (small network of canals in Line Islands)
(2012)
country comparison to the world: 107
Merchant marine: total: 111
by type: bulk carrier 3, general cargo 46, oil tanker 16,
other 46 (2018)
country comparison to the world: 80
Ports and terminals: Major seaport(s): Betio (Tarawa Atoll),
Canton Island, English Harbor TRANSNATIONAL ISSUES
Disputes—International: NONe
KOREA, NORTH
-Kanggye
Kimch''aek,
Sindiju Hamhang,
a
Hungnam
unch’on 9
=
PYONGYANG
Nampo .Songnim —_,, Kudm-ni
eSariwon / ?
Wonsan”
Kaesong ,~ aaa
ine?
Baeic ‘ »°3P''anmunjom-ni
SOUTH KOREA
National air transport system:
number of registered air carriers: 12 (2015)
inventory of registered aircraft operated by air carriers:
348 (2015)
annual passenger traffic on registered air Carriers:
65,482,307 (2015)
annual freight traffic on registered air carriers: 11.297
billion mt-km (2015) Civil aircraft registration country code prefix:
HL (2016)
Airports: 111 (2013)
country comparison to the world: 53
Airports—with paved runways:
total: 71 (2017)
over 3,047 m: 4 (2017)
2,438 to 3,047 m: 19 (2017)
1,524 to 2,437 m: 12 (2017)
914 to 1,523 m: 13 (2017)
under 914 m: 23 (2017)
Airports—with unpaved runways:
total: 40 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 38 (2013)
Heliports: 466 (2013)
Pipelines: 3790 km gas, 16 km oil, 889 km refined products
(2017)
Railways: total: 3,979 km (2016)
standard gauge: 3,979 km 1.435-m gauge (2,727 km
electrified) (2016)
country comparison to the world: 49
Roadways: total: 100,428 km (2016)
paved: 92,795 km (includes 4,193 km of expressways)
(2016)
unpaved: 7,633 km (2016)
country comparison to the world: 47
Waterways: 1,600 km (most navigable only by small craft)
(2011)
country comparison to the world: 49
Merchant marine: total: 1,897
by type: bulk carrier 95, container ship 86, general cargo
379, oil tanker 196, other 1141 (2018) country comparison
to the world: 12
Ports and terminals: major seaport(s): Busan, Incheon,
Gunsan, Kwangyang, Mokpo, Pohang, Ulsan, Yeosu
container port(s) (TEUs): Busan (20,493,000), Incheon
(3,050,000), Kwangyang (2,230,000) (2017) LNG
terminal(s) (import): Incheon, Kwangyang, Pyeongtaek,
Samcheok, Tongyeong, Yeosu TRANSNATIONAL ISSUES
Disputes—International: Military Demarcation Line within the
4-km-wide Demilitarized Zone has separated North from
South Korea since 1953; periodic incidents with North
Korea in the Yellow Sea over the Northern Limit Line,
which South Korea claims as a maritime boundary; South
Korea and Japan claim Liancourt Rocks (Tok-do/Take-
shima), occupied by South Korea since 1954
Refugees and internally displaced persons: Stateless persons: 197
(2018) KOSOVO
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 16 (2015) Civil aircraft registration country code prefix:
VQ-T (2016) Airports: 8 (2013)
country comparison to the world: 165
Airports—with paved runways:
total: 6 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 1 (2013)
Airports—with unpaved runways:
total: 2 (2013)
under 914 m: 2 (2013)
Roadways: total: 121 km (2003) paved: 24 km (2003)
unpaved: 97 km (2003)
country comparison to the world: 206
Merchant marine: total: 4
by type: general cargo 1, other 3 (2018)
country comparison to the world: 166
Ports and terminals: Major seaport(s): Cockburn Harbour,
Grand Turk, Providenciales TRANSNATIONAL ISSUES
Disputes—International: have received Haitians fleeing
economic and civil disorder tlicit drugs: transshipment point
for South American narcotics destined for the US and
Europe TUVALU
« Nanumea
Lolua
ince Kulia, wiutao
.
Nanumanga
ui
Tanrake*
Asau -
Vaitupu
6 ¢° Nukufetau
avave
FUNAFUT}I ="
Funatuti
Fangaua,
Nukulaelae
Niulakita','ae258bd5ca3a643b0a4204667d8258baadff6fef2d26e0d2f3c4944bba862354','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa39e4cf5497475304ba18f440a5e24c393b504883e03c3981e408b15caf8477',2020,'RS','Serbia','transportation',640,'Podujeve)
Podujevo,
MONTENEGRO mene,
Mitrovic6/ ¢V) setatrri/
Vuéitrn
oPejé/ *
Pee PRISTINA
Gjeravica/ Gjilan/
Deravica Gnijilane,
*Gjakové/ *Ferizaj/
UroSevac
ePrizren/
Prizren
ALBANIA MACEDONIA
9 20 40 km
pt
0 20','e5bfa487e4ac19b2ae648e8678bf0257fd7da73f870b1489b3ec0b12eb954f84','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a76173adaf2c247a401fe796e96c96ff7237e0dde238f4cae5bc6876954e5e1',2020,'KW','Kuwait','transportation',658,'National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 31
(2015)
annual passenger traffic on registered air Carriers:
3,655,366 (2015)
annual freight traffic on _ registered air carriers:
275,777,666 mt-km (2015)
Civil aircraft registration country code prefix: 9K (2016)
Airports: 7 (2013)
country comparison to the world: 169
Airports—with paved runways: total: 4 (2019)
over 3,047 m: 1
2,438 to 3,047 m: 2
914 to 1,523 m: 1
Airports—with unpaved runways:
total: 3 (2013)
1,524 to 2,437 m: 1 (2013)
under 914 m: 2 (2013)
Heliports: 4 (2013)
Pipelines: 261 km gas, 540 km oil, 57 km refined products
(2013)
Roadways: total: 5,749 km (2018)
paved: 4,887 km (2018)
unpaved: 862 km (2018)
country comparison to the world: 141
Merchant marine: total: 158
by type: general cargo 18, oil tanker 26, other 114 (2018)
country comparison to the world: 69
Ports and terminals: Major seaport(s): Ash Shu’aybah, Ash
Shuwaykh, Az Zawr (Mina’ Sa’ud), Mina’ ‘Abd Allah, Mina’
al Ahmadi TRANSNATIONAL ISSUES
Disputes—International: Kuwait and Saudi Arabia continue
negotiating a joint maritime boundary with Iran; no
maritime boundary exists with Iraq in the Persian Gulf
Refugees and internally displaced persons: stateless
persons: 92,000 (2018); note—Kuwait’s 1959 Nationality
Law defined citizens as persons who settled in the country
before 1920 and who had maintained normal residence
since then; one-third of the population, descendants of
Bedouin tribes, missed the window of opportunity to
register for nationality rights after Kuwait became
independent in 1961 and were classified as bidun (meaning
“without”); since the 1980s Kuwait’s bidun have
progressively lost their rights, including opportunities for
employment and education, amid official claims that they
are nationals of other countries who have destroyed their
identification documents in hopes of gaining Kuwaiti
citizenship; Kuwaiti authorities have delayed processing
citizenship applications and labeled biduns as “illegal
residents,” denying them access to civil documentation,
such as birth and marriage certificates Trafficking in persons:
current situation: Kuwait is a destination country for men
and women subjected to forced labor and, to a lesser
degree, forced prostitution; men and women migrate from
South and Southeast Asia, Egypt, the Middle East, and
increasingly Africa to work in Kuwait, most of them in the
domestic service, construction, and sanitation sectors;
although most of these migrants enter Kuwait voluntarily,
upon arrival some are subjected to conditions of forced
labor by their sponsors and labor agents, including debt
bondage; Kuwait’s sponsorship law restricts workers’
movements and penalizes them for running away from
abusive workplaces, making domestic workers particularly
vulnerable to forced labor in private homes tier rating: Tier 3
—Kuwait does not fully comply with the minimum
standards for the elimination of trafficking and is not
making sufficient efforts to do so; although investigations
into visa fraud rings lead to the referral of hundreds of
people for prosecution, including complicit officials, the
government has not prosecuted or convicted any suspected
traffickers; authorities made no effort to enforce the
prohibition against withholding workers’ passports, as
mandated under Kuwaiti law; punishment of forced labor
cases was limited to shutting down labor recruitment firms,
assessing fines, and ordering the return of withheld
passports and the paying of back-wages; the government
made progress in victims’ protection by opening a high-
capacity shelter for runaway domestic workers but still
lacks formal procedures to identify and refer victims to
care services (2015) KYRGYZSTAN
National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 10
(2015)
annual passenger traffic on registered air carriers: 625,294
(2015)
annual freight traffic on registered air carriers: 69,290 mt-
km (2015)
Civil aircraft registration country code prefix: EX (2016)
Airports: 28 (2013)
country comparison to the world: 123
Airports—with paved runways:
total: 18 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 3 (2017)
1,524 to 2,437 m: 11 (2017)
under 914 m: 3 (2017)
Airports—with unpaved runways:
total: 10 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 8 (2013)
Pipelines: 3566 km gas (2018), 16 km oil (2013)
Railways: total: 424 km (2018)
broad gauge: 424 km 1.520-m gauge (2018)
country comparison to the world: 118
Roadways: total: 34,000 km (2018)
country comparison to the world: 93
Waterways: 600 km (2010)
country comparison to the world: 78
Ports and terminals: lake port(s): Balykchy (Ysyk-Kol or
Rybach’ye)(Lake Ysyk-Kol) TRANSNATIONAL ISSUES
Disputes—International: disputes in Isfara Valley delay
completion of delimitation with Tajikistan; delimitation of
approximately 15% or 200 km of border with Uzbekistan is
hampered by serious disputes over enclaves and other
areas Illicit drugs: limited illicit cultivation of cannabis and
opium poppy for CIS markets; limited government
eradication of illicit crops; transit point for Southwest Asian
narcotics bound for Russia and the rest of Europe; major
consumer of opiates
VIETNAM
Couangphrabang
Xiangkhoang*
4 Phu Bia
Ban
VIENTIANES™. Nape +
rt ad .
THAILAND “%_Salavan
> Pakxe
CAMBODIA™','fa0736ca515c3544f496f7cbe2cbe2f5bb84b19f2186ff668483a39c90e74abb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ffa723bf6482bbf6274f300d26eb487f2e953440c23464a5131d9e7ea0537ce',2020,'BY','Belarus','transportation',667,'National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 47
(2015)
annual passenger traffic on registered air Carriers:
2,527,368 (2015)
annual freight traffic on registered air carriers: 2,277,996
mt-km (2015)
Civil aircraft registration country code prefix: YL (2016)
Airports: 42 (2013)
country comparison to the world: 101
Airports—with paved runways:
total: 18 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 3 (2017)
1,524 to 2,437 m: 4 (2017)
914 to 1,523 m: 3 (2017)
under 914 m: 7 (2017)
Airports—with unpaved runways:
total: 24 (2013)
under 914 m: 24 (2013)
Heliports: 1 (2013)
Pipelines: 1,213 km gas, 417 km refined products (2018)
Railways: total: 1,860 km (2018)
narrow gauge: 34 km 0.750-m gauge (2018)
broad gauge: 1,826 km 1.520-m gauge (2018)
country comparison to the world: 75
Roadways: total: 70,244 km (2018)
paved: 15,158 km (2018)
unpaved: 55,086 km (2018)
country comparison to the world: 69
Waterways: 300 km (navigable year-round) (2010)
country comparison to the world: 92
Merchant marine: total: 68
by type: general cargo 18, oil tanker 8, other 42 (2018)
country comparison to the world: 102
Ports and terminals: Najor seaport(s): Riga, Ventspils','941c42c83cb32f8597d26f36ce1c9d21b7900b9fd96ab6e0fef23204529f8891','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a6de96d4b0994ca254e26c6732ceeedb45a6bf1efffb23bfa35cd00cc77264d',2020,'LU','Luxembourg','transportation',685,'National air transport system: number of registered air Carriers:
3 (2015) inventory of registered aircraft operated by air
carriers: 119 (2015)
annual passenger traffic on registered air Carriers:
1,830,972 (2015)
annual freight traffic on _ registered air carriers:
6,309,473,324 mt-km (2015) Civil aircraft registration country
code prefix: LX (2016)
Airports: 2 (2013)
country comparison to the world: 202
Airports—with paved runways:
total: 1 (2019)
over 3,047 m: 1
Airports—with unpaved runways:
total: 1 (2013)
under 914 m: 1 (2013)
Heliports: 1 (2013)
Pipelines: 142 km gas, 27 km refined products (2013)
Railways: total: 275 km (2014)
standard gauge: 275 km 1.435-m gauge (275 km
electrified) (2014)
country comparison to the world: 124
Roadways: total: 2,875 km (2019)
country comparison to the world: 161
Waterways: 37 km (on Moselle River) (2010)
country comparison to the world: 104
Merchant marine: total: 152
by type: bulk carrier 4, container ship 9, general cargo 6,
oil tanker 2, other 131 (2018) country comparison to the
world: 70
Ports and terminals: river port(s): Mertert (Moselle)','8507c432478315498c7a71fccbeb7f6ffe9eb978a9cc2571ec3741776c50a874','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b22fbbec84632c9289427cf914d0033c3dc4fb3887cfe9261c8f00b30f4d300d',2020,'MZ','Mozambique','transportation',695,'National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 2
(2015)
annual passenger traffic on registered air carriers: 6,010
(2015)
annual freight traffic on registered air carriers: 5,467 mt-
km (2015)
Civil aircraft registration country code prefix: 7Q (2016)
Airports: 32 (2013)
country comparison to the world: 113
Airports—with paved runways:
total: 7 (2019)
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 4
Airports—with unpaved runways:
total: 25 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 11 (2013)
under 914 m: 13 (2013)
Railways: total: 767 km (2014)
narrow gauge: 767 km 1.067-m gauge (2014)
country comparison to the world: 99
Roadways: total: 15,452 km (2015)
paved: 4,074 km (2015)
unpaved: 11,378 km (2015)
country comparison to the world: 121
Waterways: 700 km (on Lake Nyasa [Lake Malawi] and Shire
River) (2010)
country comparison to the world: 75
Ports and terminals: Jake port(s): Chipoka, Monkey Bay,
Nkhata Bay, Nkhotakota, Chilumba (Lake Nyasa)
National air transport system:
number of registered air carriers: 12 (2015)
inventory of registered aircraft operated by air carriers:
263 (2015)
annual passenger traffic on registered air Carriers:
590,347,149 (2015)
annual freight traffic on _ registered air carriers:
2,005,979,379 mt-km (2015)
Civil aircraft: 9M (2016)
Airports: 114 (2013)
country comparison to the world: 51
Airports—with paved runways:
total: 39 (2017)
over 3,047 m: 8 (2017)
2,438 to 3,047 m: 8 (2017)
1,524 to 2,437 m: 7 (2017)
914 to 1,523 m: 8 (2017)
under 914 m: 8 (2017)
Airports—with unpaved runways:
total: 75 (2013)
914 to 1,523 m: 6 (2013)
under 914 m: 69 (2013)
Heliports: 4 (2013)
Pipelines: 354 km condensate, 6439 km gas, 155 km liquid
petroleum gas, 1937 km oil, 43 km oil/gas/water, 114 km
refined products, 26 km water (2013)
Railways: total: 1,851 km (2014)
standard gauge: 59 km 1.435-m gauge (59 km electrified)
(2014)
narrow gauge: 1,792 km 1.000-m gauge (339 km
electrified) (2014)
country comparison to the world: 77
Roadways: total: 144,403 km (excludes local roads) (2010)
paved: 116,169 km (includes 1,821 km of expressways)
(2010)
unpaved: 28,234 km (2010)
country comparison to the world: 35
Waterways: 7,200 km (Peninsular Malaysia 3,200 km; Sabah
1,500 km; Sarawak 2,500 km) (2011) country comparison
to the world: 19
Merchant marine: total: 1,704
by type: bulk carrier 15, container ship 22, general cargo
182, oil tanker 137, other 1348 (2018) country comparison
to the world: 15
Ports and terminals: Major seaport(s): Bintulu, Johor Bahru,
George Town (Penang), Port Kelang (Port Klang), Tanjung
Pelepas container port(s) (TEUs): Port Kelang (Port Klang)
(11,978,000), Tanjung Pelepas (8,260,000) (2017) LNG
terminal(s) (export): Bintulu (Sarawak)
LNG terminal(s) (import): Sungei Udang
National air transport system: number of registered air Carriers:
3 (2015) inventory of registered aircraft operated by air
carriers: 16 (2015)
annual passenger traffic on registered air Carriers: 686,892
(2015)
annual freight traffic on registered air carriers: 5,138,916
mt-km (2015) Civil aircraft registration country code prefix: C9
(2016)
Airports: 98 (2013)
country comparison to the world: 57
Airports—with paved runways:
total: 21 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 9 (2017)
914 to 1,523 m: 5 (2017)
under 914 m: 4 (2017)
Airports—with unpaved runways:
total: 77 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 9 (2013)
914 to 1,523 m: 29 (2013)
under 914 m: 38 (2013)
Pipelines: 972 km gas, 278 km refined products (2013)
Railways: total: 4,787 km (2014)
narrow gauge: 4,787 km 1.067-m gauge (2014)
country comparison to the world: 41
Roadways: total: 31,083 km (2015)
paved: 7,365 km (2015)
unpaved: 23,718 km (2015)
country comparison to the world: 96
Waterways: 460 km (Zambezi River navigable to Tete and
along Cahora Bassa Lake) (2010) country comparison to
the world: 85
Merchant marine: total: 27
by type: general cargo 10, other 17 (2018)
country comparison to the world: 132
Ports and terminals: Major seaport(s): Beira, Maputo, Nacala
National air transport system: number of registered air Carriers:
5 (2015) inventory of registered aircraft operated by air
carriers: 17 (2015)
annual passenger traffic on registered air Carriers:
1,239,707 (2015)
annual freight traffic on registered air carriers: 2,337,440
mt-km (2015)
Civil aircraft registration country code prefix: ]H (2016)
Airports: 166 (2013)
country comparison to the world: 34
Airports—with paved runways:
total: 10 (2019)
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 2
Airports—with unpaved runways:
total: 156 (2013)
over 3,047 m: 1 (2013)
1,524 to 2,437 m: 24 (2013)
914 to 1,523 m: 98 (2013)
under 914 m: 33 (2013)
Pipelines: 311 km gas, 891 km oil, 8 km refined products
(2013)
Railways: total: 4,567 km (2014)
narrow gauge: 1,860 km 1.067-m gauge (2014)
2707 km 1.000-m gauge
country comparison to the world: 43
Roadways: total: 87,581 km (2015)
paved: 10,025 km (2015)
unpaved: 77,556 km (2015)
country comparison to the world: 55
Waterways: (Lake Tanganyika, Lake Victoria, and Lake Nyasa
(Lake Malawi) are the principal avenues of commerce with
neighboring countries; the rivers are not navigable) (2011)
Merchant marine: total: 329
by type: bulk carrier 6, container ship 9, general cargo 184,
oil tanker 41, other 89 (2018)
country comparison to the world: 49
Ports and terminals: Major seaport(s): Dar es Salaam, Zanzibar','566963a53df0398c9b641363588855fb0121bdf65b6c45aa464063fe1694cf46','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22fb416ce8dafd9c71e177ec703b0df876d1512686956825dee3cc91f9756e08',2020,'DZ','Algeria','transportation',700,'National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 2
(2015)
Civil aircraft registration country code prefix: [''Z, IT (2016)
Airports: 25 (2013)
country comparison to the world: 128
Airports—with paved runways:
total: 8 (2019)
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
914 to 1,523 m: 1
Airports—with unpaved runways:
total: 17 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 9 (2013)
under 914 m: 5 (2013)
Heliports: 2 (2013)
Railways: total: 593 km (2014)
narrow gauge: 593 km 1.000-m gauge (2014)
country comparison to the world: 110
Roadways: total: 139,107 km (2018)
country comparison to the world: 38
Waterways: 1,800 km (downstream of Koulikoro; low water
levels on the River Niger cause problems in dry years; in
the months before the rainy season the river is not
navigable by commercial vessels) (2011) country
comparison to the world: 43
Ports and terminals: river port(s): Koulikoro (Niger)','93456db4c1f0900c21ef2e5afb2f720d688be802a2161df5705e3d354a178e73','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ca5238b695cb393b1ecc984d6f990981d4b03fe8f87680e1817618afd62374e',2020,'MH','Marshall Islands','transportation',715,'National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 1
(2015)
annual passenger traffic on registered air carriers: 86,868
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: V7 (2016)
Airports: 15 (2013)
country comparison to the world: 147
Airports—with paved runways:
total: 4 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 11 (2013)
914 to 1,523 m: 10 (2013)
under 914 m: 1 (2013)
Roadways: total: 2,028 km (2007)
paved: 75 km (2007)
unpaved: 1,953 km
country comparison to the world: 167
Merchant marine: total: 3,419
by type: bulk carrier 1437, container ship 256, general
cargo 68, oil tanker 837, other 821 (2018) country
comparison to the world: 7
Ports and terminals: Major seaport(s): Enitwetak Island,
Kwajalein, Majuro TRANSNATIONAL ISSUES
Disputes—International: Claims US territory of Wake Island
Trafficking in persons: Current situation: The Marshall Islands
is a source and destination country for Marshallese women
and girls and women from East Asia subjected to sex
trafficking; Marshallese and foreign women are forced into
prostitution in businesses frequented by crew members of
fishing and transshipping vessels that dock in Majuro; some
Chinese women are recruited to the Marshall Islands with
promises of legitimate work and are subsequently forced
into prostitution tier rating: Tier 3—The Marshall Islands do
not fully comply with the minimum standards for the
elimination of trafficking and is not making significant
efforts to do so; the government made no anti-trafficking
law enforcement efforts, including developing a written
plan to combat trafficking; no new trafficking investigations
were opened in 2014, and no prosecutions or convictions
were made for the fourth consecutive year; no efforts were
made to identify trafficking victims, especially among
women in prostitution or men working on foreign fishing
vessels in Marshallese waters, and no attempt was made to
ensure their access to protective services; limited
awareness-raising events were conducted by an
international organization (2015) MAURITANIA
Bir Moghrein a
Western
Sahara
Tidjikdja
Rosso Bogue —Kiffa
Kaédi','361110b8adc609afe31af9b19869c26da0f69591a92e729359be02231358690f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b17911cead5fe1552564a562a616ecbcab4f2c94a0ae363c71670cde291190a',2020,'MX','Mexico','transportation',736,'National air transport system:
number of registered air carriers: 21 (2015)
inventory of registered aircraft operated by air carriers:
357 (2015)
annual passenger traffic on registered air Carriers:
45,560,063 (2015)
annual freight traffic on _ registered air _ carriers:
713,985,467 mt-km (2015)
Civil aircraft registration country code prefix: XA (2016)
Airports: 1,714 (2013)
country comparison to the world: 3
Airports—with paved runways:
total: 243 (2017)
over 3,047 m: 12 (2017)
2,438 to 3,047 m: 32 (2017)
1,524 to 2,437 m: 80 (2017)
914 to 1,523 m: 86 (2017)
under 914 m: 33 (2017)
Airports—with unpaved runways:
total: 1,471 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 42 (2013)
914 to 1,523 m: 281 (2013)
under 914 m: 1,146 (2013)
Heliports: 1 (2013)
Pipelines: 15,986 km natural gas (2019), 10,365 km oil
(2017), 8,946 km refined products (2016) Railways: total:
20,825 km (2017)
standard gauge: 20,825 km 1.435-m gauge (27 km
electrified) (2017)
country comparison to the world: 14
Roadways: total: 398,148 km (2017)
paved: 174,911 km (includes 10,362 km of expressways)
(2017)
unpaved: 223,237 km (2017)
country comparison to the world: 18
Waterways: 2,900 km (navigable rivers and coastal canals
mostly connected with ports on the country’s east coast)
(2012) country comparison to the world: 33
Merchant marine: total: 617
by type: bulk carrier 6, general cargo 11, oil tanker 35,
other 565 (2018)
country comparison to the world: 34
Ports and __ terminals: major seaport(s): Altamira,
Coatzacoalcos, Lazaro Cardenas, Manzanillo, Veracruz oil
terminal(s): Cayo Arcas terminal, Dos Bocas terminal
cruise port(s): Cancun, Cozumel, Ensenada
container port(s) (TEUs): Manzanillo (2,830,370), Lazaro
Cardenas (1,149,079) (2017) LNG terminal(s) (import):
Altamira, Ensenada','c8447b6756ccb779aca1f168cf50083e7c7cccbe2c54c91ea73d5b3135687e2e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('423cf769ee6227de1a89ef72cda0e6087a2e665e7c851552ba1c09687b5e478a',2020,'FM','Micronesia, Federated States of','transportation',740,'Under the terms of the original Compact, the US
provided $1.3 billion in grants and aid from 1986 to 2001.
The US and the Federated States of Micronesia (FSM)
negotiated a second (amended) Compact agreement in
2002-03 that took effect in 2004. The amended Compact
runs for a 20-year period to 2023; during which the US will
provide roughly $2.1 billion to the FSM. The amended
Compact also develops a trust fund for the FSM that will
provide a comparable income stream beyond 2024 when
Compact grants end.
The country’s medium-term economic outlook appears
fragile because of dependence on US assistance and
lackluster performance of its small and stagnant private
sector.
GDP (purchasing power parity): $348 million (2017 est.)
$341.1 million (2016 est.)
$331.4 million (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 215
GDP (official exchange rate):
$328 million (2017 est.)
GDP—real growth rate: 2% (2017 est.)
2.9% (2016 est.)
3.9% (2015 est.)
country comparison to the world: 153
GDP—per capita (PPP): $3,400 (2017 est.)
$3,300 (2016 est.)
$3,200 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 189
GDP—composition, by end use:
household consumption: 83.5% (2013 est.)
government consumption: 48.4% (2016 est.)
investment in fixed capital: 29.5% (2016 est.)
investment in inventories: 1.9% (2016 est.)
exports of goods and services: 27.5% (2016 est.)
imports of goods and services: -77% (2016 est.)
GDP—composition, by sector of origin:
agriculture: 26.3% (2013 est.)
industry: 18.9% (2013 est.)
services: 54.8% (2013 est.)
Agriculture—products: taro, yams, coconuts, bananas, cassava
(manioc, tapioca), sakau (kava), Kosraen citrus, betel nuts,
black pepper, fish, pigs, chickens Industries: tourism,
construction; specialized aquaculture, craft items (shell and
WOOd) Industrial production growth rate: NA
Labor force: 37,920 (2010 est.)
country comparison to the world: 200
Labor force—by occupation: agriculture: 0.9%
industry: 5.2%
services: 93.9% (2013 est.)
note: two-thirds of the labor force are government
employees
Unemployment rate: 16.2% (2010 est.)
country comparison to the world: 177
Population below poverty line: 26.7% (2000 est.)
Household income or consumption by percentage share: Jowest 10%:
NA highest 10%: NA
Budget: revenues: 213.8 million (FY12/13 est.)
expenditures: 192.1 million (FY12/13 est.)
Taxes and other revenues:
65.2% (of GDP) (FY12/13 est.)
country comparison to the world: 7
Budget surplus (+) or deficit (-): 6.6% (of GDP) (FY12/13 est.)
country comparison to the world: 4
Public debt:
24.5% of GDP (2017 est.)
25.3% of GDP (2016 est.)
country comparison to the world: 176
Fiscal year: 1 October—30 September
Inflation rate (consumer prices): 0.5% (2017 est.)
0.5% (2016 est.)
country comparison to the world: 28
Current account balance:
$12 million (2017 est.)
$11 million (2016 est.)
country comparison to the world: 63
Exports: $88.3 million (2013 est.)
country comparison to the world: 197
Exports—commodities: fish, sakau (kava), betel nuts, black
pepper
Imports: $167.8 million (2015 est.)
$258.5 million (2013 est.)
country comparison to the world: 212
Imports—commodities: food, beverages, clothing, computers,
household electronics, appliances, manufactured goods,
automobiles, machinery and equipment, furniture, tools
Reserves of foreign exchange and gold:
$203.7 million (31 December 2017 est.)
$135.1 million (31 December 2015 est.)
country comparison to the world: 174
Debt—external:
$93.6 million (2013 est.)
$93.5 million (2012 est.)
country comparison to the world: 194
Exchange rates: the US dollar is used
Civil aircraft registration country code prefix: V6 (2016)
Airports: 6 (2013)
country comparison to the world: 174
Airports—with paved runways:
total: 6 (2017)
1,524 to 2,437 m: 4 (2017)
914 to 1,523 m: 2 (2017)
Roadways: note—paved and unpaved circumferential roads,
most interior roads are unpaved Merchant marine: total: 63
by type: general cargo 40, oil tanker 6, other 17 (2018)
country comparison to the world: 105
Ports and terminals: Major seaport(s): Colonia (Tamil Harbor),
Molsron Lele Harbor, Pohnepi Harbor TRANSNATIONAL
ISSUES
Disputes—International: NONe
Illicit drugs: Major consumer of cannabis
MOLDOVA','fee5488046c52846803bf57722013e221aaa8d0e5e6fa2ebf17a720f98029b3b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e944abc20bbfab87f78bfa176a0757df086471d742824807a0a93637998dfa61',2020,'UA','Ukraine','transportation',744,'Balti Ribnita,
%
L
4
Dealul fi
eal! Dubasari,
CHISINAU,
National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 12
(2015)
annual passenger traffic on registered air Carriers:
1,005,942 (2015)
annual freight traffic on registered air carriers: 489,630
mt-km (2015)
Civil aircraft registration country code prefix: ER (2016)
Airports: 7 (2013)
country comparison to the world: 170
Airports—with paved runways:
total: 5 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 2 (2017)
Airports—with unpaved runways:
total: 2 (2013)
1,524 to 2,437 m: 1 (2013)
under 914 m: 1 (2013)
Pipelines: 1916 km gas (2014)
Railways: total: 1,171 km (2014)
standard gauge: 14 km 1.435-m gauge (2014)
broad gauge: 1,157 km 1.520-m gauge (2014)
country comparison to the world: 87
Roadways: total: 9,352 km (2012)
paved: 8,835 km (2012)
unpaved: 517 km (2012)
country comparison to the world: 131
Waterways: 508 km (in public use on Danube, Dniester and
Prut Rivers) (2011)
country comparison to the world: 82
Merchant marine: total: 151
by type: bulk carrier 3, container ship 3, general cargo 113,
oil tanker 8, other 24 (2018) country comparison to the
world: 71','eba953b7f472d69e5848aa0b8da279138f3068fa67eb3ddaba029a16e651c8fa','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c062745eddbc6c0d216ad4053727035eb9b4ec1546c1f1ba9fed5b83fbfde1bf',2020,'MC','Monaco','transportation',757,'Civil aircraft registration country code prefix: 3A (2016)
Heliports: 1 (2012)
Railways: note: Monaco has a single railway station but
does not operate its own train service; the French operator
SNCF operates rail services in Monaco Roadways: Ports and
terminals: major seaport(s): Hercules Port','10feca0d642dabe0a8606db80be9b993d848de80fdda58e15ab5147ec4efa8b1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2324294761885c8d2ca7ce70d7317287291c7e2aef22f2e6b9a93955b0953767',2020,'AL','Albania','transportation',773,'National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 3
(2015)
Civil aircraft registration country code prefix: VP-M (2016)
Airports: 1 (2013)
country comparison to the world: 229
Airports—with paved runways:
total: 1 (2019)
under 914 m: 1
Roadways: note: volcanic eruptions that began in 1995
destroyed most of the 227 km road system; a new road
infrastructure has been built on the north end of the island
Ports and terminals: Major seaport(s): Little Bay, Plymouth','d65f74f2899636b46e8f1d8ed6c0d9c157b12713ba4da1aac66afc46df354b04','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f02180e512f6c529ca70a8f2972f692a83e819559009c4d302c5d36773fb3e9',2020,'NL','Netherlands','transportation',805,'National air transport system: number of registered air Carriers:
8 (2015) inventory of registered aircraft operated by air
carriers: 244 (2015)
annual passenger traffic on registered air Carriers:
34,870,204 (2015)
annual freight traffic on _ registered air _ carriers:
5,292,794,685 mt-km (2015)
Civil aircraft registration country code prefix: PH (2016)
Airports: 29 (2013)
country comparison to the world: 118
Airports—with paved runways:
total: 23 (2017)
over 3,047 m: 3 (2017)
2,438 to 3,047 m: 11 (2017)
1,524 to 2,437 m: 1 (2017)
914 to 1,523 m: 6 (2017)
under 914 m: 2 (2017)
Airports—with unpaved runways:
total: 6 (2013)
914 to 1,523 m: 4 (2013)
under 914 m: 2 (2013)
Heliports: 1 (2013)
Pipelines: 14000 km gas, 2500 km oil and refined products,
3000 km chemicals (2016)
Railways: total: 3,058 km (2016)
standard gauge: 3,058 km 1.435-m gauge (2,314 km
electrified) (2016)
country comparison to the world: 61
Roadways: total: 139,124 km (includes 3,654 km of
expressways) (2016) country comparison to the world: 37
Waterways: 6,237 km (navigable by ships up to 50 tons)
(2012)
country comparison to the world: 21
Merchant marine: total: 1,233
by type: bulk carrier 13, container ship 41, general cargo
986, oil tanker 21, other 572 (2018) country comparison to
the world: 23
Ports and terminals: Major seaport(s): IJmuiden, Vlissingen
container port(s) (TEUs): Rotterdam (13,734,000) (2017)
LNG terminal(s) (import): Rotterdam
river port(s): Amsterdam (Nordsee Kanaal); Moerdijk
(Hollands Diep River); Rotterdam (Rhine River); Terneuzen
(Western Scheldt River) TRANSNATIONAL ISSUES
Disputes—International: NONe
Refugees and internally displaced persons: refugees (country of
origin): 32,092 (Syria), 15,478 (Somalia), 14,931 (Eritrea),
9,259 (Iraq), 6,267 (Afghanistan) (2017) stateless persons:
1,951 (2018)
Illicit drugs: Major European producer of synthetic drugs,
including ecstasy, and cannabis cultivator; important
gateway for cocaine, heroin, and hashish entering Europe;
major source of US-bound ecstasy and a _ significant
consumer of ecstasy; a large financial sector vulnerable to
money laundering NEW CALEDONIA
Efaté
Airports: 1 (2013)
country comparison to the world: 236
Airports—with paved runways:
total: 1 (2019)
1,524 to 2,437 m: 1
note: Princess Juliana International Airport (SXM) was
severely damaged on 6 September 2017 by hurricane Irma,
but resumed commercial operations on 10 October 2017
Roadways: total: 53 km
country comparison to the world: 210
Ports and terminals: Major seaport(s): Philipsburg
oil terminal(s): Coles Bay oil terminal','48f1424ce7b90ba396408f4c631c46f8bd1141173ba8706eb3ffceb95d4f4f10','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3958984220b9b0d9c6646b06cdebbfa720d946b45fed49a56a0cff25b08f489',2020,'VU','Vanuatu','transportation',806,'Erromango
iles
*Poindimié yer, Loyauté
Mueo*®
Thioe
New
Caledonia
*
NOUMEA lle des Pins
ile Huon and lles Chesterfield
are not shown,','ace3991b84dfbf262eadd5ea22979c278d0124bb2825c4c5b13f748304163fe3','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('582b81996504f729fcfbf288839e372c29ceff33d2190103d66ba9d758522f0c',2020,'NG','Nigeria','transportation',820,'National air transport system: number of registered air Carriers:
16 (2015) inventory of registered aircraft operated by air
carriers: 73 (2015)
annual passenger traffic on registered air Carriers:
3,223,459 (2015)
annual freight traffic on registered air carriers: 22,400,657
mt-km (2015)
Civil aircraft registration country code prefix: ]N (2016)
Airports: 54 (2013)
country comparison to the world: 87
Airports—with paved runways:
total: 40 (2017)
over 3,047 m: 10 (2017)
2,438 to 3,047 m: 12 (2017)
1,524 to 2,437 m: 9 (2017)
914 to 1,523 m: 6 (2017)
under 914 m: 3 (2017)
Airports—with unpaved runways:
total: 14 (2013)
1,524 to 2,437 m: 2 (2013)
914 to 1,523 m: 9 (2013)
under 914 m: 3 (2013)
Heliports: 5 (2013)
Pipelines: 124 km condensate, 4045 km gas, 164 km liquid
petroleum gas, 4441 km oil, 3940 km refined products
(2013) Railways: total: 3,798 km (2014)
standard gauge: 293 km 1.435-m gauge (2014)
narrow gauge: 3,505 km 1.067-m gauge (2014)
note: as of the end of 2018, there were only six operational
locomotives in Nigeria primarily used for passenger
service; the majority of the rail lines are in a severe state of
disrepair and need to be replaced country comparison to
the world: 54
Roadways: total: 195,000 km (2017)
paved: 60,000 km (2017)
unpaved: 135,000 km (2017)
country comparison to the world: 29
Waterways: 8,600 km (Niger and Benue Rivers and smaller
rivers and creeks) (2011)
country comparison to the world: 15
Merchant marine: total: 576
by type: general cargo 14, oil tanker 90, other 472 (2018)
country comparison to the world: 36
Ports and terminals: Major seaport(s): Bonny Inshore Terminal,
Calabar, Lagos LNG terminal(s) (export): Bonny Island','3d294e04d1b32a585c4469b0f3794da8256d8f4cd1ebb2aa2db11748d8ebbd20','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cefe87a6441159f04232eba55df7588fde0c054b336cdb81738fd467241608b1',2020,'TO','Tonga','transportation',826,'Airports: 1 (2013)
country comparison to the world: 231
Airports—with paved runways:
total: 1 (2017)
1,524 to 2,437 m: 1 (2017)
Airports—with unpaved runways:
total: 1 (2013)
1,524 to 2,437 m: 1 (2013)
Roadways: total: 234 km (2017)
paved: 210 km (2017)
unpaved: 24 km
country comparison to the world: 200
Ports and terminals: ajor seaport(s): Alofi','3d5adf1b9db57037bd27565574c0bde5f7c147f897aa05fa3fcd9095a1def71e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('691e96ecd8e465fc11e009fb70cb5d710c6598fb95d8e09679832f08e8ea3054',2020,'MP','Northern Mariana Islands','transportation',833,'Airports: 5 (2013)
country comparison to the world: 183
Airports—with paved runways:
total: 3 (2019)
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
Airports—with unpaved runways:
total: 2 (2013)
2,438 to 3,047 m: 1 (2013)
under 914 m: 1 (2013)
Heliports: 1 (2013)
Roadways: total: 536 km (2008) country comparison to the
world: 188
Merchant marine: total: 1
by type: other 1 (2018)
country comparison to the world: 175
Ports and terminals: Major seaport(s): Saipan, Tinian, Rota','80b8405a11618707926e987ada413d41beff2cf5f9fc2ab49adcf8cdcc8369d5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc92ac17c14e6abdb68f7456bb91795ea5d8b08f5787ad7e83b1798b4fe635f2',2020,'PA','Panama','transportation',843,'National air transport system: number of registered air Carriers:
4 (2015) inventory of registered aircraft operated by air
carriers: 103 (2015)
annual passenger traffic on registered air Carriers:
12,018,103 (2015)
annual freight traffic on _ registered air _ Carriers:
121,567,075 mt-km (2015)
Civil aircraft registration country code prefix: HP (2016)
Airports: 117 (2013)
country comparison to the world: 50
Airports—with paved runways:
total: 57 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 3 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 20 (2017)
under 914 m: 30 (2017)
Airports—with unpaved runways:
total: 60 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 8 (2013)
under 914 m: 51 (2013)
Heliports: 3 (2013)
Pipelines: 128 km oil (2013)
Railways: total: 77 km (2014)
standard gauge: 77 km 1.435-m gauge (2014)
country comparison to the world: 128
Roadways: Waterways: 800 km (includes the 82-km Panama
Canal that is being widened) (2011)
country comparison to the world: 71
Merchant marine: total: 7,914
by type: bulk carrier 2585, container ship 590, general
cargo 1327, oil tanker 808, other 2604 (2018) country
comparison to the world: 2
Ports and terminals: Major seaport(s): Balboa, Colon, Cristobal
container port(s) (TEUs): Balboa (2,905,049), Colon
(3,891,209) (2017)','ace44b7dd7c91b83456279bcc92b36c9518305fa49e6fc67addd56025ee583fe','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c902b1f3230ce2090eeb6c891c145b8f672f43b78b3ba6783930cf54afeeadb2',2020,'GN','Guinea','transportation',845,'National air transport system: number of registered air Carriers:
6 (2015) inventory of registered aircraft operated by air
carriers: 47 (2015)
annual passenger traffic on registered air Carriers:
2,062,584 (2015)
annual freight traffic on registered air carriers: 34,827,034
mt-km (2015)
Civil aircraft registration country code prefix: P2 (2016)
Airports: 561 (2013)
country comparison to the world: 11
Airports—with paved runways:
total: 21 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 12 (2017)
914 to 1,523 m: 5 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 540 (2013)
1,524 to 2,437 m: 11 (2013)
914 to 1,523 m: 53 (2013)
under 914 m: 476 (2013)
Heliports: 2 (2013)
Pipelines: 264 km oil (2013)
Roadways: total: 9,349 km (2011)
paved: 3,000 km (2011)
unpaved: 6,349 km (2011)
country comparison to the world: 132
Waterways: 11,000 km (2011)
country comparison to the world: 12
Merchant marine: total: 173
by type: container ship 7, general cargo 79, oil tanker 3,
other 84 (2018)
country comparison to the world: 65
Ports and terminals: Major seaport(s): Kimbe, Lae, Madang,
Rabaul, Wewak LNG terminal(s) (export): Port Moresby
Airports: 1 (2013)
country comparison to the world: 233
Airports—with paved runways:
total: 1 (2019)
1,524 to 2,437 m: 1
Roadways: Ports and terminals: small Chinese port facilities
on Woody Island and Duncan Island
National air transport system: annual passenger traffic on
registered air carriers: 115,355 (2015) annual freight
traffic on registered air carriers: 3,095,523 mt-km (2015)
Civil aircraft registration country code prefix: 6V (2016)
Airports: 20 (2013)
country comparison to the world: 136
Airports—with paved runways:
total: 9 (2017)
over 3,047 m: 2 (2017)
1,524 to 2,437 m: 6 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 11 (2013)
1,524 to 2,437 m: 7 (2013)
914 to 1,523 m: 3 (2013)
under 914 m: 1 (2013)
Pipelines: 43 km gas, 8 km refined products (2017)
Railways: total: 906 km (713 km operational in 2017) (2017)
narrow gauge: 906 km 1.000-m gauge (2017)
country comparison to the world: 94
Roadways: total: 16,665 km (2017)
paved: 6,126 km (includes 241 km of expressways) (2017)
unpaved: 10,539 km (2017)
country comparison to the world: 118
Waterways: 1,000 km (primarily on the Senegal, Saloum, and
Casamance Rivers) (2012)
country comparison to the world: 63
Merchant marine: total: 28
by type: general cargo 4, oil tanker 1, other 23 (2018)
country comparison to the world: 130
Ports and terminals: Major seaport(s): Dakar','caf00128df2a0bf5da1a62883ebd994b85505f5be622f745329728be0322d865','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd621105cfbd2298069e0512bf92e238703e190fe8f552d78e6753cb9a731e12',2020,'PH','Philippines','transportation',865,'Roadways: total: 0 km
country comparison to the world: 215
Ports and terminals: Major seaport(s): Adamstown (on Bounty
Bay)','a579ec7ee432dfb57730458b77fa1bc88d665ec2d17bb1d613a75584681a6ce6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09fe7df84e9625bcec7463d2e2f9ecf6198f5a0b65a5bae792aaf92aea6c5f20',2020,'BG','Bulgaria','transportation',884,'National air transport system: number of registered air Carriers:
5 (2015) inventory of registered aircraft operated by air
carriers: 51 (2015)
annual passenger traffic on registered air Carriers:
3,636,642 (2015)
annual freight traffic on registered air carriers: 4,691,280
mt-km (2015)
Civil aircraft registration country code prefix: YR (2016)
Airports: 45 (2013)
country comparison to the world: 94
Airports—with paved runways:
total: 26 (2017)
over 3,047 m: 4 (2017)
2,438 to 3,047 m: 10 (2017)
1,524 to 2,437 m: 11 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 19 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 14 (2013)
Heliports: 2 (2013)
Pipelines: 3726 km gas, 2451 km oil (2013)
Railways: total: 11,268 km (2014)
standard gauge: 10,781 km 1.435-m gauge (3,292 km
electrified) (2014)
narrow gauge: 427 km 0.760-m gauge (2014)
broad gauge: 60 km 1.524-m gauge (2014)
country comparison to the world: 23
Roadways: total: 84,185 km (2012)
paved: 49,873 km (includes 337 km of expressways) (2012)
unpaved: 34,312 km (2012)
country comparison to the world: 58
Waterways: 1,731 km (includes 1,075 km on the Danube
River, 524 km on secondary branches, and 132 km on
canals) (2010) country comparison to the world: 45
Merchant marine: total: 112
by type: general cargo 13, oil tanker 8, other 91 (2018)
country comparison to the world: 79
Ports and terminals: Major seaport(s): Constanta, Midia river
port(s): Braila, Galati (Galatz), Mancanului (Giurgiu),
Tulcea (Danube River) TRANSNATIONAL ISSUES
Disputes—International: the ICJ ruled largely in favor of
Romania in its dispute submitted in 2004 over Ukrainian-
administered Zmiyinyy/Serpilor (Snake) Island and Black
Sea maritime boundary delimitation; Romania opposes
Ukraine’s reopening of a navigation canal from the Danube
border through Ukraine to the Black Sea Refugees and
internally displaced persons: stateless persons: 227 (2018)
Illicit drugs: Major transshipment point for Southwest Asian
heroin transiting the Balkan route and small amounts of
Latin American cocaine bound for Western Europe;
although not a significant financial center, role as a
narcotics conduit leaves it vulnerable to laundering, which
occurs via the banking system, currency exchange houses,
and casinos RUSSIA','d559693bceebe713c24d55ba27b3c5190e144bee648980be5e86e5f78e314250','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd73e8fe5e951f39a4551e23f893ad3466abb15f7688055e838a461acef2be7e',2020,'KN','Saint Kitts and Nevis','transportation',895,'Civil aircraft registration country code prefix: V4 (2016)
Airports: 2 (2013)
country comparison to the world: 204
Airports—with paved runways:
total: 2 (2019)
1,524 to 2,437 m: 1
914 to 1,523 m: 1
Railways: total: 50 km (2008)
narrow gauge: 50 km 0.762-m gauge on Saint Kitts for
tourists (2008)
country comparison to the world: 132
Roadways: total: 383 km (2002)
paved: 163 km (2002)
unpaved: 220 km (2002)
country comparison to the world: 194
Merchant marine: total: 240
by type: bulk carrier 6, container ship 5, general cargo 44,
oil tanker 55, other 130 (2018) country comparison to the
world: 60
Ports and_ terminals: major seaport(s): Basseterre,
Charlestown TRANSNATIONAL ISSUES
Disputes—International: joins other Caribbean states to counter
Venezuela’s claim that Aves Island sustains human
habitation, a criterion under UN Convention on the Law of
the Sea, which permits Venezuela to extend its
EEZ/continental shelf over a large portion of the eastern
Caribbean Sea Illicit drugs: transshipment point for South
American drugs destined for the US and Europe; some
money-laundering activity SAINT LUCIA
"Gros
Islet
*
-» CASTRIES
Cul de Sac
Dennery,
Vieux Fort®
Civil aircraft registration country code prefix: JO (2016)
Airports: 2 (2013)
country comparison to the world: 205
Airports—with paved runways:
total: 2 (2019)
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
Roadways: total: 1,210 km (2011)
paved: 847 km (2011)
unpaved: 363 km (2011)
country comparison to the world: 174
Ports and terminals: Major seaport(s): Castries, Cul-de-Sac,
Vieux-Fort TRANSNATIONAL ISSUES
Disputes—International: joins other Caribbean states to counter
Venezuela’s claim that Aves Island sustains human
habitation, a criterion under UN Convention on the Law of
the Sea, which permits Venezuela to extend its
EEZ/continental shelf over a large portion of the eastern
Caribbean Sea Illicit drugs: transit point for South American
drugs destined for the US and Europe
SAINT MARTIN
lle Tintamarre
Grand-Case
eae
Saint Martin
Pie du
ap bradis
%MARIGOT
Orléans
Sint Maarten
(NETHERLANDS
Airports: 1 (2013)
country comparison to the world: 235
Airports—with paved runways:
total: 1 (2019)
914 to 1,523 m: 1
Transportation—note: nearest airport for international flights is
Princess Juliana International Airport (SXM) located on Sint
Maarten SAINT PIERRE AND MIQUELON
Miquelon*
Miquelon
(Grande
Miquelon)
lle Saint-Pierre
Langlade
(Petite Miquelon)
*.
SAINT-PIERRE
Airports: 2 (2013)
country comparison to the world: 206
Airports—with paved runways:
total: 2 (2019)
1,524 to 2,437 m: 1
914 to 1,523 m: 1
Roadways: total: 117 km (2009)
paved: 80 km (2009)
unpaved: 37 km (2009)
country comparison to the world: 207
Ports and terminals: Major seaport(s): Saint-Pierre','be6bd6bf0216865da87bb5951a80e83cc9e15c4d537be0fa62f712c7e8b3ee50','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a9030ac2cbe8d53f2f3d24fe17a3b7cf8c83665d9ea06672a4669d2fed0b5d7',2020,'WS','Samoa','transportation',903,'National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 1 (2015)
annual passenger traffic on registered air carriers: 270,908
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: 5W (2016)
Airports: 4 (2013)
country comparison to the world: 189
Airports—with paved runways:
total: 1 (2019)
2,438 to 3,047 m: 1
Airports—with unpaved runways:
total: 3 (2013)
under 914 m: 3 (2013)
Roadways: Merchant marine: total: 13
by type: general cargo 4, oil tanker 2, other 7 (2018)
country comparison to the world: 146
Ports and terminals: Major seaport(s): Apia','cd3f0c0f1ae3e405bbcfa3719044df5d4a158a1e8d66bb6d58c0fe3d35ebeea5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49584679ee3fd20a7fc82dd8725427537f803cc3a0d1edcc21caf2fc305b5dbf',2020,'SM','San Marino','transportation',909,'Civil aircraft registration country code prefix: I''7 (2016)
Roadways: total: 292 km (2006)
paved: 292 km (2006)
country comparison to the world: 197','9a9319e89477439257bb37744634149d534a3afe42cbeaca04db1c0955b613f6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fef12146ef83d9f816acf483522c9f44a69dd5d48b80d4c3f24f1fb001f7c4e',2020,'SO','Somalia','transportation',943,'National air transport system: number of registered air Carriers:
23 (2015) inventory of registered aircraft operated by air
carriers: 216 (2015)
annual passenger traffic on registered air Carriers:
17,188,887 (2015)
annual freight traffic on registered air _ carriers:
885,277,991 mt-km (2015)
Civil aircraft registration country code prefix: ZS (2016)
Airports: 407 (2020)
country comparison to the world: 20
Airports—with paved runways:
total: 130 (2020)
over 3,047 m: 11
2,438 to 3,047 m: 6
1,524 to 2,437 m: 46
914 to 1,523 m: 60
under 914 m:7
Airports—with unpaved runways:
total: 277 (2020)
2,438 to 3,047 m: 1
1,524 to 2,437 m: 19
914 to 1,523 m: 178
under 914 m:79
Heliports: Pipelines: 94 km condensate, 1293 km gas, 992
km oil, 1460 km refined products (2013)
Railways: total: 20,986 km (2014)
standard gauge: 80 km 1.435-m gauge (80 km electrified)
(2014)
narrow gauge: 19,756 km 1.065-m gauge (8,271 km
electrified) (2014)
other: 1,150 km (passenger rail, gauge unspecified, 1,115.5
km electrified) (2014)
country comparison to the world: 13
Roadways: total: 750,000 km (2016)
paved: 158,124 km (2016)
unpaved: 591,876 km (2016)
country comparison to the world: 10
Merchant marine: total: 88
by type: bulk carrier 2, general cargo 1, oil tanker 6, other
79 (2018)
country comparison to the world: 92
Ports and terminals: Major seaport(s): Cape Town, Durban,
Port Elizabeth, Richards Bay, Saldanha Bay container
port(s) (TEUs): Durban (2,699,978) (2017)
LNG terminal(s) (import): Mossel Bay
Roadways: Ports and terminals: major seaport(s): Grytviken','5dd599a27259d995b22caa3591add2406041817dc6f3e476626f6ee0163d406b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a24c2502add11b051914b65e9012186276f807f87b858ffdafe55ec2f8d446b',2020,'NO','Norway','transportation',973,'Airports: 4 (2013)
country comparison to the world: 190
Airports—with paved runways:
total: 1 (2019)
2,438 to 3,047 m: 1
Airports—with unpaved runways:
total: 3 (2013)
under 914 m: 3 (2013)
Heliports: 1 (2013)
Ports and terminals: major seaport(s): Barentsburg,
Longyearbyen, Ny-Alesund, Pyramiden TRANSNATIONAL
ISSUES
Disputes—International: despite recent discussions, Russia and
Norway dispute their maritime limits in the Barents Sea
and Russia’s fishing rights beyond Svalbard’s territorial
limits within the Svalbard Treaty zone SWEDEN
Lulea Det
sib
¢
Skelleftea
Umea, /
wi
Sundsvall. s¢
Bus 5 a.
‘2 ye STOCKHOLM
Orebro? Eskilstufia -,
| Ts
Norrképing Pi.
uy Linképing, °"S Oxelésund
<4Stenungsund *
EGSteborg Jénkdping J ;
Boras ¥ Gotiand
, >
Hailmstad
4 Kalmar’) / Gand
_Sarisharnn','bb6655319b1085ec51b03b8db6c4cfb122bb2b66934d26b99596976d23888060','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88748711248519668647cfcf2ca8affc9144f7f9f5e0b57a3e73e2c26e320183',2020,'JE','Jersey','transportation',979,'National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 11 (2015)
annual passenger traffic on registered air carriers: 475,932
(2015)
annual freight traffic on registered air carriers: 1,517,388
mt-km (2015)
Civil aircraft registration country code prefix: YK (2016)
Airports: 90 (2013)
country comparison to the world: 62
Airports—with paved runways:
total: 29 (2013)
over 3,047 m: 5 (2013)
2,438 to 3,047 m: 16 (2013)
914 to 1,523 m: 3 (2013)
under 914 m: 5 (2013)
Airports—with unpaved runways:
total: 61 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 12 (2013)
under 914 m: 48 (2013)
Heliports: 6 (2013)
Pipelines: 3170 km gas, 2029 km oil (2013)
Railways: total: 2,052 km (2014)
standard gauge: 1,801 km 1.435-m gauge (2014)
narrow gauge: 251 km 1.050-m gauge (2014)
country comparison to the world: 74
Roadways: total: 69,873 km (2010)
paved: 63,060 km (2010)
unpaved: 6,813 km (2010)
country comparison to the world: 70
Waterways: 900 km (navigable but not economically
significant) (2011)
country comparison to the world: 68
Merchant marine: total: 21
by type: bulk carrier 1, general cargo 7, other 13 (2018)
country comparison to the world: 138
Ports and terminals: Major seaport(s): Baniyas, Latakia, Tartus
National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 10 (2015)
annual passenger traffic on registered air carriers: 802,470
(2015)
annual freight traffic on registered air carriers: 105,376
mt-km (2015)
Civil aircraft registration country code prefix: EY (2016)
Airports: 24 (2013)
country comparison to the world: 132
Airports—with paved runways:
total: 17 (2013)
over 3,047 m: 2 (2013)
2,438 to 3,047 m: 4 (2013)
1,524 to 2,437 m: 5 (2013)
914 to 1,523 m: 3 (2013)
under 914 m: 3 (2013)
Airports—with unpaved runways:
total: 7 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 5 (2013)
Pipelines: 549 km gas, 38 km oil (2013)
Railways: total: 680 km (2014)
broad gauge: 680 km 1.520-m gauge (2014)
country comparison to the world: 102
Roadways: total: 30,000 km (2018)
country comparison to the world: 97
Waterways: 200 km (along Vakhsh River) (2011)
country comparison to the world: 98','6d2dbdb638f53f2814bf5d5f5b8cf25103b3067be194806112bac7a34529550d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('510621ffcf6dbbce1ece1f9e5156e676a35d10a1c2f51298b4beb482f4a5bf87',2020,'MY','Malaysia','transportation',988,'National air transport system: number of registered air Carriers:
19 (2015) inventory of registered aircraft operated by air
carriers: 276 (2015)
annual passenger traffic on registered air Carriers:
94,259,629 (2015)
annual freight traffic on _ registered air carriers:
2,134,149,001 mt-km (2015)
Civil aircraft registration country code prefix: HS (2016)
Airports: 101 (2013)
country comparison to the world: 56
Airports—with paved runways:
total: 63 (2013)
over 3,047 m: 8 (2013)
2,438 to 3,047 m: 12 (2013)
1,524 to 2,437 m: 23 (2013)
914 to 1,523 m: 14 (2013)
under 914 m: 6 (2013)
Airports—with unpaved runways:
total: 38 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 10 (2013)
under 914 m: 26 (2013)
Heliports: 7 (2013)
Pipelines: 2 km condensate, 5900 km gas, 85 km liquid
petroleum gas, 1 km oil, 1097 km refined products (2013)
Railways: total: 4,127 km (2017)
standard gauge: 84 km 1.435-m gauge (84 km electrified)
(2017)
narrow gauge: 4,043 km 1.000-m gauge (2017)
country comparison to the world: 47
Roadways: total: 180,053 km (includes 450 km of
expressways) (2006)
country comparison to the world: 30
Waterways: 4,000 km (3,701 km navigable by boats with
drafts up to 0.9 m) (2011)
country comparison to the world: 26
Merchant marine: total: 807
by type: bulk carrier 27, container ship 25, general cargo
91, oil tanker 241, other 423 (2018)
country comparison to the world: 27
Ports and terminals: Major seaport(s): Bangkok, Laem
Chabang, Map Ta Phut, Prachuap Port, Si Racha container
port(s) (TEUs): Laem Chabang (7,227,431) (2017)
LNG terminal(s) (import): Map Ta Phut','5b67d5ccdefe7df6a6149973a6fbef14c5b9997b69a315364fe5cf2a2b62d2e5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cec6d82ccdf0f52942bd0a1657949e76cef8a27423d5abf7e9b29c5806b7309a',2020,'TT','Trinidad and Tobago','transportation',999,'National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 17 (2015)
annual passenger traffic on registered air Carriers:
2,617,842 (2015)
annual freight traffic on registered air carriers: 43,198,176
mt-km (2015)
Civil aircraft registration country code prefix: 9Y (2016)
Airports: 4 (2013)
country comparison to the world: 191
Airports—with paved runways:
total: 2 (2019)
over 3,047 m: 1
2,438 to 3,047 m: 1
Airports—with unpaved runways:
total: 2 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 1 (2013)
Pipelines: 257 km condensate, 11 km condensate/gas, 1567
km gas, 587 km oil (2013)
Roadways: Merchant marine: total: 102
by type: general cargo 1, other 101 (2018)
country comparison to the world: 84
Ports and terminals: Major seaport(s): Point Fortin, Point Lisas,
Port of Spain, Scarborough oil terminal(s): Galeota Point
terminal
LNG terminal(s) (export): Port Fortin
National air transport system: number of registered air Carriers:
15 (2015) inventory of registered aircraft operated by air
carriers: 531 (2015)
annual passenger traffic on registered air Carriers:
96,604,665 (2015)
annual freight traffic on _ registered air _ carriers:
2,882,162,000 mt-km (2015)
Civil aircraft registration country code prefix: [''C (2016)
Airports: 98 (2013)
country comparison to the world: 58
Airports—with paved runways:
total: 91 (2013)
over 3,047 m: 16 (2013)
2,438 to 3,047 m: 38 (2013)
1,524 to 2,437 m: 17 (2013)
914 to 1,523 m: 16 (2013)
under 914 m: 4 (2013)
Airports—with unpaved runways:
total: 7 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 4 (2013)
under 914 m: 2 (2013)
Heliports: 20 (2013)
Pipelines: 14,666 km gas, 3,293 km oil (2017)
Railways: total: 12,710 km (2018)
standard gauge: 11,497 km 1.435-m gauge (1.435 km high
speed train) (2018)
country comparison to the world: 21
Roadways: total: 67,333 km (2018)
paved: 24,082 km (includes 2,159 km of expressways)
(2018)
unpaved: 43,251 km (2018)
country comparison to the world: 72
Waterways: 1,200 km (2010)
country comparison to the world: 60
Merchant marine: total: 1,277
by type: bulk carrier 61, container ship 70, general cargo
305, oil tanker 139, other 702 (2018) country comparison
to the world: 22
Ports and terminals: Major seaport(s): Aliaga, Ambarili,
Diliskelesi, Eregli, Izmir, Kocaeli (Izmit), Mersin (Icel),
Limani, Yarimca container port(s) (TEUs): Ambarli
(3,131,621), Mersin (Icel) (1,592,000) (2017)
LNG terminal(s) (import): Izmir Aliaga, Marmara Ereglisi','62f35bc68bbf3ac1008ccf2750d9c86d12c9457547678f8047e3edfc713fae2d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('010412a6e94ddaad4174d39f9e4162ae8e1ad94906380a3a7dfd2b1c9b23edd5',2020,'SB','Solomon Islands','transportation',1026,'National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 6 (2015)
annual passenger traffic on registered air Carriers: 287,526
(2015)
annual freight traffic on registered air carriers: 1,510,732
mt-km (2015) Civil aircraft registration country code prefix: YJ
(2016)
Airports: 31 (2013)
country comparison to the world: 114
Airports—with paved runways:
total: 3 (2019)
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1
Airports—with unpaved runways:
total: 28 (2013)
914 to 1,523 m: 7 (2013)
under 914 m: 21 (2013)
Roadways: total: 1,070 km (2000)
paved: 256 km (2000)
unpaved: 814 km (2000)
country comparison to the world: 177
Merchant marine: total: 405
by type: bulk carrier 27, container ship 1, general cargo 35,
other 342 (2018) country comparison to the world: 43
Ports and terminals: Major seaport(s): Forari Bay, Luganville
(Santo, Espiritu Santo), Port-Vila TRANSNATIONAL
ISSUES
Disputes—International: Matthew and Hunter Islands east of
New Caledonia claimed by Vanuatu) and _ France
VENEZUELA
Puerto : ifaw
Maracaibo Cabello ,-4 Guaira Tos
A aloncies », RCARACAS ‘
Barquisimeto® Maracay ~ "Barcelona!
h
San Ciudad p ay
Pico Bolivar Fernando Bolivat,—# Ciudad
Guayan
€7—
$
ane
> san Cristobal
Lv','b2e543c5f6624b929513117942786f351d87464d171862ea0cc112c59e23e6b4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baf309b0c9b41a5ba8b997fbab0cfe68cddb895bd82a8491f99f7b63e18ded99',2020,'WF','Wallis and Futuna','transportation',1033,'Airports: 2 (2013)
country comparison to the world: 209
Airports—with paved runways:
total: 2 (2019)
1,524 to 2,437 m: 1
914 to 1,523 m: 1
Ports and terminals: Major seaport(s): Leava, Mata-Utu','a78aebda0006238e759cbf0076ce950ae4e1e66abc8158afaede5387ddc0c722','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f746cf497985b96ccfeb5dd26ef817a4ba9a083206a8cc2141ea3fb30db4a49',2020,'MA','Morocco','transportation',1045,'Airports: 41,820 (2016) top ten by passengers: Atlanta (ATL)
—103,902,992; Beijing (PEK)—95,786,442; Dubai (DXB)—
88,242,099; Tokyo (HND)—85,408,975; Los Angeles (LAX)
—84,557,968; Chicago (ORD)—79,828,183; London (LHR)
—78,014,598; Hong Kong (HKG) 72,664,075; Shanghai
(PVG) 70,001,237; Paris (CDG)—69,471,442 (2017) top ten
by cargo (metric tons): Hong Kong (HKG)—5,049,898;
Memphis, TN (MEM)—4,336,752; Shanghai (PVG)—
3,824,280; Incheon (ICN)—2,921,691; Anchorage, AK
(ANC)—2,713,230; Dubai (DXB)—2,654,494; Louisville, KY
(SDF)—2,602,695; Tokyo (NRT)—2,336,427; Taipei (TPE)—
2,269,585; Paris (CDG)—2,195,229 (2017) Heliports: 6,524
(2013)
Railways: total: 1,148,186 km (2013)
Roadways: total: 64,285,009 km (2013)
Waterways: 2,293,412 km (2017)
top ten longest rivers: Nile (Africa) 6,693 km; Amazon
(South America) 6,436 km; Mississippi-Missouri (North
America) 6,238 km; Yenisey-Angara (Asia) 5,981 km; Ob-
Irtysh (Asia) 5,569 km; Yangtze (Asia) 5,525 km; Yellow
(Asia) 4,671 km; Amur (Asia) 4,352 km; Lena (Asia) 4,345
km; Congo (Africa) 4,344 km note: rivers are not
necessarily navigable along the entire length; if measured
by volume, the Amazon is the largest river in the world,
responsible for about 20% of the Earth’s freshwater
entering the ocean top ten largest natural lakes (by surface
area): Caspian Sea (Azerbaijan, Iran, Kazakhstan, Russia,
Turkmenistan) 372,960 sq km; Lake Superior (Canada,
United States) 82,414 sq km; Lake Victoria (Kenya,
Tanzania, Uganda) 69,490 sq km; Lake Huron (Canada,
United States) 59,596 sq km; Lake Michigan (United
States) 57,441 sq km; Lake Tanganyika (Burundi,
Democratic Republic of the Congo, Tanzania, Zambia)
32,890 sq km; Great Bear Lake (Canada) 31,800 sq km;
Lake Baikal (Russia) 31,494 sq km; Lake Nyasa (Malawi,
Mozambique, Tanzania) 30,044 sq km; Great Slave Lake
(Canada) 28,400 sq km note 1: the areas of the lakes are
subject to seasonal variation; only the Caspian Sea is
saline, the rest are fresh water note 2: Lakes Huron and
Michigan are technically a single lake because the flow of
water between the Straits of Mackinac that connects the
two lakes keeps their water levels at near-equilibrium;
combined, Lake Huron-Michigan is the largest freshwater
lake by surface area in the world Merchant marine: total:
92,647
by type: bulk carrier 11,115, container ship 5,145, general
cargo 19,128, oil tanker 10,252, other 47,007 (2018) Ports
and terminals: top twenty container ports as measured by
Twenty-Foot Equivalent Units (TEUs) throughput: Shanghai
(China)—40,233,000; Singapore (Singapore)—33,666,000;
Shenzhen (China)—25,208,000; Ningbo (China)—
24,607,000; Hong Kong (China)—20,770,000; Busan (South
Korea)—20,493,000; Guangzhou (China)—18,858,000;
Qingdao (China)—18,262,000; Dubai (UAE)—15,368,000;—
Tianjin (China)—15,040,000; Rotterdam (Netherlands)—
13,734,000; Port Kelang (Malaysia)—11,978,000; Antwerp
(Belgium)—10,450,000; Xiamen (China)—10,380,000;
Kaohsiung (Taiwan)—10,271,000; Dalian (China)—
9,707,000; Los Angeles (US)—9,343,000; Hamburg
(Germany)—8,860,000; Tanjung Pelepas (Malaysia)—
8,260,000; Laem Chabang (Thailand)—7,227,000 (2017)
note—it was estimated that in 2017 60% of global sea-
borne’ trade by value moved ~oby container','b2f742bcf6b7d31b9741bcefdf8669019a2e0a2929d253ec07c8588f2daefff6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f138d1082d04a5928d62875f7ab9814252bf3057edb73f79c178528ca714bb0',2020,'SA','Saudi Arabia','transportation',1052,'National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 10 (2015) annual passenger traffic on registered
air carriers: 1,387,999 (2015) annual freight traffic on
registered air carriers: 0 mt-km (2015) Civil aircraft
registration country code prefix: 7O (2016) Airports: 57 (2013)
country comparison to the world: 83
Airports—with paved runways:
total: 17 (2013)
over 3,047 m: 4 (2013)
2,438 to 3,047 m: 9 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 1 (2013)
Airports—with unpaved runways:
total: 40 (2013)
over 3,047 m: 3 (2013)
2,438 to 3,047 m: 5 (2013)
1,524 to 2,437 m: 7 (2013)
914 to 1,523 m: 16 (2013)
under 914 m: 9 (2013)
Pipelines: 641 km gas, 22 km liquid petroleum gas, 1370 km
oil (2013) Roadways: total: 71,300 km (2005) paved: 6,200
km (2005)
unpaved: 65,100 km (2005)
country comparison to the world: 68
Merchant marine: total: 31
by type: general cargo 3, oil tanker 4, other 24 (2018)
country comparison to the world: 125
Ports and terminals: Major seaport(s): Aden, Al Hudaydah, Al
Mukalla TERRORISM
Terrorist groups—home based:
al-Qa’ida in the Arabian Peninsula (AQAP): aim(s): overthrow the
Yemen Government and Huthi forces and, ultimately,
establish an Islamic caliphate; eradicate US and Western
influence and presence from Yemen and the rest of the
Arabian Peninsula area(s) of operation: a core al-Qa’ida
affiliate; most active in southern, eastern, and central
Yemen (2018) Islamic State of Iraq and ash-Sham-Yemen (ISIS-
Yemen): aim/(s): replace the Yemen Government and Huthi
forces with an Islamic state and implement ISIS’s strict
interpretation of sharia area(s) of operation: operational
primarily in south and central Yemen, where operatives
conduct attacks against Huthi forces, Shia Muslims, and
government facilities and personnel (2018) Terrorist groups—
foreign based:
Islamic Revolutionary Guard Corps—Qods Force (IRGC-QF): aiim(s):
spread Iran’s influence and counter Saudi and UAE by
supporting Yemen’s Houthi government through funding,
training, logistical support, and weapons, to include
ballistic missile and unmanned aerial vehicle (UAV)
technology area(s) of operations: Yemen, including the Red
Sea (2019) TRANSNATIONAL ISSUES
Disputes—International: Saudi Arabia has _ reinforced its
concrete-filled security barrier along sections of the fully
demarcated border with Yemen to stem illegal cross-border
activities Refugees and internally displaced persons: refugees
(country of origin): 250,860 (Somalia), 14,638 (Ethiopia)
(2019) IDPs: 3,647,250 (conflict in Sa’ada Governorate;
clashes between al-Qa’ida in the Arabian Peninsula and
government forces) (2019) Trafficking in persons: current
situation: Yemen is a source and, to a lesser extent, transit
and destination country for men, women, and children
subjected to forced labor and women and _ children
subjected to sex trafficking; trafficking activities grew in
Yemen in 2014, as the country’s security situation
deteriorated and poverty worsened; armed _ groups
increased their recruitment of Yemeni children as
combatants or checkpoint guards, and the Yemeni military
and security forces continue to use child soldiers; some
other Yemeni children, mostly boys, migrate to Yemeni
cities or Saudi Arabia and, less frequently Oman, where
they end up as beggars, drug smugglers, prostitutes, or
forced laborers in domestic service or small shops; Yemeni
children increasingly are also subjected to sex trafficking in
country and in Saudi Arabia; tens of thousands of Yemeni
migrant workers deported from Saudi Arabia and
thousands of Syrian refugees are vulnerable to trafficking;
additionally, Yemen is a destination and transit country for
women and children from the Horn of Africa who are
looking for work or receive fraudulent job offers in the Gulf
states but are subjected to sexual exploitation or forced
labor upon arrival; reports indicate that adults and children
are still sold or inherited as slaves in Yemen tier rating: Tier
3—Yemen does not fully comply with the minimum
standards for the elimination of trafficking and is not
making significant efforts to do so; weak government
institutions, corruption, economic problems, security
threats, and poor law enforcement capabilities impeded the
government’s ability to combat human trafficking; not all
forms of trafficking are criminalized, and officials continue
to conflate trafficking and smuggling; the status of an anti-
trafficking law drafted with assistance from an
international organization remains unknown following the
dissolution of the government in January 2015; the
government did not report efforts to investigate, prosecute,
or convict anyone of trafficking or slavery offenses,
including complicit officials, despite reports of officials
willfully ignoring trafficking crimes and using child soldiers
in the government’s armed forces; the government
acknowledged the use of child soldiers and signed a UN
action plan to end the practice in 2014 but made no efforts
to release child soldiers from the military and provide them
with rehabilitative services; authorities failed to identify
victims and refer them to protective services; the status of
a draft national anti-trafficking strategy remains unknown
(2015)','42bdf556f1b7e0c6ac4e6267b3c6a665bd1a539658a5709d5a110b15e145ee84','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

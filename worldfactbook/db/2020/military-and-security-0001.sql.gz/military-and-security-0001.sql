SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7128ac2a5a7287ffe5d3269bff9e2bf24ae672022999c178ec53a88cb975daa2',2020,'PK','Pakistan','military-and-security',52,'Military expenditures: 0.99% of GDP (2018)
0.94% of GDP (2017)
0.89% of GDP (2016)
0.99% of GDP (2015)
1.33% of GDP (2014)
country comparison to the world: 116
Military and security forces: Afghan National Defense and
Security Forces (ANDSF) comprised of military, police, and
other security elements: Afghan National Army ((ANA),
Afghan Air Force, Afghan Special Security Forces,
Afghanistan National Army Territorial Forces (ANA-TF)),
Afghan National Police (Ministry of Interior), Afghan Local
Police (Ministry of Interior), and the National Directorate of
Security (2020) Military service age and obligation: 18 is the
legal minimum age for voluntary military service; no
conscription (2017) Military—note: Since early 2015, the
NATO-led mission in Afghanistan known as _ Resolute
Support Mission (RSM) has focused on training, advising,
and assisting Afghan government forces; RSM includes
17,000 troops, including 8,500 US and 8,700 other troops
from 38 countries (September 2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
4 (2015) inventory of registered aircraft operated by air
carriers: 20 (2015)
annual passenger traffic on registered air Carriers:
1,929,907 (2015)
annual freight traffic on registered air carriers: 33,102,038
mt-km (2015)
Civil aircraft registration country code prefix: YA (2016)
Airports: 43 (2016)
country comparison to the world: 98
Airports—with paved runways: total: 25 (2017)
over 3,047 m: 4
2,438 to 3,047 m: 4
1,524 to 2,437 m: 14
914 to 1,523 m: 2
under 914 m: 1
Airports—with unpaved runways: total: 18 (2016)
2,438 to 3,047 m: 1 (2016)
1,524 to 2,437 m: 8 (2016)
914 to 1,523 m: 4 (2016)
under 914 m: 5 (2016)
Heliports: 9 (2013)
Pipelines: 466 km gas (2013)
Roadways: total: 34,903 km (2017)
paved: 17,903 km (2017)
unpaved: 17,000 km (2017)
country comparison to the world: 92
Waterways: 1,200 km (chiefly Amu Darya, which handles
vessels up to 500 DWT) (2011)
country comparison to the world: 58
Ports and terminals: river port(s): Kheyrabad, Shir Khan
Military expenditures:
4.03% of GDP (2018)
3.77% of GDP (2017)
3.59% of GDP (2016)
3.55% of GDP (2015)
3.48% of GDP (2014)
country comparison to the world: 10
Military and security forces: Pakistan Army (includes National
Guard), Pakistan Navy (includes marines, Maritime
Security Agency), Pakistan Air Force (Pakistan Fizaia);
Ministry of Interior paramilitary forces: Frontier Corps,
Pakistan Rangers (2019) Military service age and obligation: 16-
23 years of age for voluntary military service; soldiers
cannot be deployed for combat until age 18; women serve
in all three armed forces; reserve obligation to age 45 for
enlisted men, age 50 for officers (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
4 (2015) inventory of registered aircraft operated by air
carriers: 67 (2015)
annual passenger traffic on registered air Carriers:
8,467,827 (2015)
annual freight traffic on _ registered air _ carriers:
183,177,313 mt-km (2015)
Civil aircraft registration country code prefix: AP (2016)
Airports: 151 (2013)
country comparison to the world: 37
Airports—with paved runways:
total: 108 (2017)
over 3,047 m: 15 (2017)
2,438 to 3,047 m: 20 (2017)
1,524 to 2,437 m: 43 (2017)
914 to 1,523 m: 20 (2017)
under 914 m: 10 (2017)
Airports—with unpaved runways:
total: 43 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 9 (2013)
914 to 1,523 m: 9 (2013)
under 914 m: 24 (2013)
Heliports: 23 (2013)
Pipelines: 12,984 km gas, 3,470 km oil, 1,170 km refined
products (2019)
Railways: total: 11,881 km (2019)
narrow gauge: 389 km 1.000-m gauge (2019)
broad gauge: 11,492 km 1.676-m gauge (293 km
electrified) (2019)
country comparison to the world: 22
Roadways: total: 263,775 km (2019)
paved: 185,063 km (includes 708 km of expressways)
(2019)
unpaved: 78,712 km (2019)
country comparison to the world: 22
Merchant marine: total: 53
by type: bulk carrier 5, oil tanker 7, other 41 (2018)
country comparison to the world: 113
Ports and terminals: major seaport(s): Karachi, Port
Muhammad Bin Qasim
container port(s) (TEUs): Karachi (2,224,000) (2017)
LNG terminal(s) (import): Port Qasim
Military and security forces: no regular military forces; the
Ministry of Justice includes divisions/bureaus for public
security, police functions, and maritime law enforcement.
(2019) Military—note: Under a 1994 Compact of Free
Association between Palau and the US, the US until 2044 is
responsible for the defense of Palaus and the US military is
granted access to the islands, but it has not stationed any
military forces there. (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 1 (2015)
Airports: 3 (2013)
country comparison to the world: 196
Airports—with paved runways:
total: 1 (2019)
1,524 to 2,437 m: 1
Airports—with unpaved runways:
total: 2 (2013)
1,524 to 2,437 m: 2 (2013)
Roadways: total: 125 km (2018)
paved: 89 km (2018)
unpaved: 36 km (2018)
country comparison to the world: 205
Ports and terminals: Major seaport(s): Koror','b2a2cad62ffbfef8a143ba4c3ef7632e0a8cc56bc103db53d0f2083de461df83','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c787e058222cdcd136ef01bbb9efdb53db086cb052524bdb97f3f8d534e91ac6',2020,'CY','Cyprus','military-and-security',60,'Military—note: defense is the responsibility of the UK; Akrotiri
has a full RAF base, headquarters for British Forces
Cyprus, and Episkopi Support Unit TRANSPORTATION
Airports: 1 (2017)
country comparison to the world: 211
Airports—with paved runways: 2,438 to 3,047 m: 1 (2017)
Military expenditures:
1.57% of GDP (2018)
1.63% of GDP (2017)
1.78% of GDP (2016)
1.68% of GDP (2015)
1.54% of GDP (2014)
country comparison to the world: 72
Military and security forces: Republic of Cyprus: Cypriot
National Guard (Ethniki Froura, EF, includes ground, naval,
and air elements); “Turkish Republic of Northern Cyprus”:
Turkish Cypriot Security Force (GKK) (2019) Military service
age and obligation: Cypriot National Guard (CNG): 18-50
years of age for compulsory military service for all Greek
Cypriot males; 17 years of age for voluntary service; 14-
month service obligation (2016) Military—note: the United
Nations Peacekeeping Force in Cyprus (UNICYP) was set
up in 1964 to prevent further fighting between the Greek
Cypriot and Turkish Cypriot communities on the island and
bring about a return to normal conditions; as of October
2019, the UNICYP mission consisted of about 1,000
personnel TRANSPORTATION
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 6
(2015)
annual passenger traffic on registered air carriers: 23,404
(2015)
annual freight traffic on registered air carriers: 230,600
mt-km (2015)
Civil aircraft registration country code prefix: 5B (2016)
Airports: 15 (2013)
country comparison to the world: 145
Airports—with paved runways:
total: 13 (2017)
2,438 to 3,047 m: 7 (2017)
1,524 to 2,437 m: 2 (2017)
914 to 1,523 m: 3 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 2 (2013)
under 914 m: 2 (2013)
Heliports: 9 (2013)
Pipelines: 0 km oil
Roadways: total: 19,901 km (2016)
government control: 12,901 km (includes 272 km _ of
expressways) (2016)
paved: 8,631 km (2016)
unpaved: 4,270 km (2016)
Turkish Cypriot control: 7,000 km (2011)
country comparison to the world: 112
Merchant marine: total: 1,020
by type: bulk carrier 311, container ship 184, general cargo
177, oil tanker 51, other 297 (2018) country comparison to
the world: 24
Ports and terminals: Major seaport(s): area under government
control: Larnaca, Limassol, Vasilikos area administered by
Turkish Cypriots: Famagusta, Kyrenia','63795cd1fe38e24484f6bb99b55fd98b605a995b7b1460e9b937dded4113a776','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fe0aae89168f3eb96ad0e6c120049804661b32667cc9ec7b86923cdc1f83edc',2020,'AL','Albania','military-and-security',61,'Shkodér
TIRANA MACEDONIA
Elbasan
.
Military expenditures:
1.66% of GDP (2019 est.)
1.39% of GDP (2018)
1.35% of GDP (2017)
1.42% of GDP (2016)
1.4% of GDP (2015)
country comparison to the world: 70
Military and security forces: Armed Forces of the Republic of
Montenegro: Army of Montenegro (includes Ground Troops
(Kopnena Vojska), Montenegrin Navy (Mornarica Crne
Gore, MCG)), Air Force (2019) Military service age and
obligation: 18 is the legal minimum age for voluntary military
service; no conscription (2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 6
(2015)
annual passenger traffic on registered air Carriers: 526,980
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: 40 (2016)
Airports: 5 (2013)
country comparison to the world: 182
Airports—with paved runways:
total: 5 (2019)
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1
Heliports: 1 (2012)
Railways: total: 250 km (2017)
standard gauge: 250 km 1.435-m gauge (224 km
electrified) (2017)
country comparison to the world: 125
Roadways: total: 7,762 km (2010)
paved: 7,141 km (2010)
unpaved: 621 km (2010)
country comparison to the world: 134
Merchant marine: total: 12
by type: bulk carrier 4, other 8 (2018)
country comparison to the world: 147
Ports and terminals: Major seaport(s): Bar
Military and security forces: nO regular military forces; Royal
Montserrat Defence Force (ceremonial, civil defense
duties), Montserrat Police Force (2019) Military—note:
defense is the responsibility of the UK','738d82ff630b96ea4d81e300a3a16e26c9891525339328cc2f5dfd8981bee564','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70306efe6fb3731dadca53f4d1cd6a4ab7ab9011fcec61643260295c43a3eb92',2020,'GR','Greece','military-and-security',62,'0 20 40km
—_
0 20 40 mi
Military expenditures: 1.26% of GDP (2019 est.)
1.17% of GDP (2018)
1.11% of GDP (2017)
1.1% of GDP (2016)
1.16% of GDP (2015)
country comparison to the world: 97
Military and security forces: Land Forces Command, Navy Force
Command, Air Forces Command (2019) Military service age
and obligation: 19 is the legal minimum age for voluntary
military service; 18 is the legal minimum age in case of
general/partial compulsory mobilization (2012)
Military expenditures:
3.25% of GDP (2019 est.)
1.48% of GDP (2018)
1.24% of GDP (2017)
1.26% of GDP (2016)
1.26% of GDP (2015)
country comparison to the world: 22
Military and security forces: Bulgarian Armed Forces: Land
Forces (aka Army), Naval Forces, Bulgarian Air Forces
(Voennovazdushni Sili, VVS) (2019) Military service age and
obligation: 18-27 years of age for voluntary military service;
conscription ended in January 2008; service obligation 6-9
months (2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 8 (2015)
inventory of registered aircraft operated by air carriers: 44
(2015)
annual passenger traffic on registered air Carriers:
1,118,689 (2015)
annual freight traffic on registered air carriers: 1,583,340
mt-km (2015)
Civil aircraft registration country code prefix: LZ (2016)
Airports: 68 (2013)
country comparison to the world: 72
Airports—with paved runways:
total: 57 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 17 (2017)
1,524 to 2,437 m: 12 (2017)
under 914 m: 26 (2017)
Airports—with unpaved runways:
total: 11 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 9 (2013)
Heliports: 1 (2013)
Pipelines: 2765 km gas, 346 km oil, 378 km refined products
(2017)
Railways: total: 5,114 km (2014)
standard gauge: 4,989 km 1.435-m gauge (2,880 km
electrified) (2014)
narrow gauge: 125 km 0.760-m gauge (2014)
country comparison to the world: 37
Roadways: total: 19,512 km (2011)
paved: 19,235 km (includes 458 km of expressways) (2011)
unpaved: 277 km (2011)
note: does not include Category IV local roads
country comparison to the world: 115
Waterways: 470 km (2009)
country comparison to the world: 83
Merchant marine: total: 80
by type: bulk carrier 2, general cargo 18, oil tanker 8, other
52 (2018)
country comparison to the world: 97
Ports and terminals: Major seaport(s): Burgas, Varna (Black
Sea)
Military expenditures:
2.06% of GDP (2018)
1.43% of GDP (2017)
1.23% of GDP (2016)
1.33% of GDP (2015)
1.43% of GDP (2014)
country comparison to the world: 47
Military and security forces: Armed Forces of Burkina Faso
(FABF): Army, Central Army Group (joint logistics
command), Air Force of Burkina Faso (Force Aerienne de
Burkina Faso, FABF), National Gendarmerie, National Fire
Brigade (Brigade Nationale des Sapeurs-Pompiers, BNSP)
(2019) Military service age and obligation: 18 years of age for
voluntary military service; no conscription; women may
serve in supporting roles (2013) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 3
(2015)
annual passenger traffic on registered air Carriers: 122,589
(2015)
annual freight traffic on registered air carriers: 55,868 mt-
km (2015)
Civil aircraft registration country code prefix: XT (2016)
Airports: 23 (2013)
country comparison to the world: 134
Airports—with paved runways:
total: 2 (2019)
over 3,047 m: 1
2,438 to 3,047 m: 1
Airports—with unpaved runways:
total: 21 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 13 (2013)
under 914 m: 5 (2013)
Railways: total: 622 km (2014)
narrow gauge: 622 km 1.000-m gauge (2014)
note: another 660 km of this railway extends into Cote
d’Ivoire
country comparison to the world: 108
Roadways: total: 15,304 km (2014)
paved: 3,642 km (2014)
unpaved: 11,662 km (2014)
country comparison to the world: 122
Military expenditures:
1.19% of GDP (2018)
0.99% of GDP (2017)
0.96% of GDP (2016)
1% of GDP (2015)
1.09% of GDP (2014)
country comparison to the world: 108
Military and security forces: Army of the Republic of North
Macedonia (ARSM; includes General Staff and subordinate
Joint Operational Command, Logistic Support Command,
Training and Doctrine Command, Special Operations
Regiment, Electronic Surveillance Center, and Air
Surveillance Center) (2019) note: the Joint Operations
Command includes air, ground, support, and reserve forces
Military service age and obligation: 18 years of age for voluntary
military service; conscription abolished in 2008 (2013)','7f5c0ae6aee3903c980c6389a96d577864e75a6f443ecdcc9cb768066cde2f49','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12a696e6b1e3506b9efa71ad60bc285a8d6f4b14976c8b76d4027b76fc17a034',2020,'DZ','Algeria','military-and-security',77,'Military expenditures: 5.27% of GDP (2018)
5.81% of GDP (2017)
6.55% of GDP (2016)
6.32% of GDP (2015)
5.94% of GDP (2014)
country comparison to the world: 4
Military and security forces: Algerian People’s National Army
(ANP): Land Forces, Naval Forces (includes coast guard),
Air Forces, Territorial Air Defense Forces, National
Gendarmerie, Republican Guard; Ministry of Interior:
General Directorate of National Security (2019) Military
service age and obligation: 18 is the legal minimum age for
voluntary military service; 19-30 years of age for
compulsory service; conscript service obligation is 18
months (6 months basic training, 12 months civil projects)
(2018) TRANSPORTATION
National air transport system: number of registered air Carriers:
4 (2015) inventory of registered aircraft operated by air
carriers: 74 (2015)
annual passenger traffic on registered air Carriers:
5,910,835 (2015)
annual freight traffic on registered air carriers: 24,723,377
mt-km (2015)
Civil aircraft registration country code prefix: 7T (2016)
Airports: 157 (2016)
country comparison to the world: 36
Airports—with paved runways: total: 64 (2017)
over 3,047 m: 12 (2017)
2,438 to 3,047 m: 29 (2017)
1,524 to 2,437 m: 17 (2017)
914 to 1,523 m: 5 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways: total: 93 (2013)
2,438 to 3,047 m: 2 (2013)
1,524 to 2,437 m: 18 (2013)
914 to 1,523 m: 39 (2013)
under 914 m: 34 (2013)
Heliports: 3 (2013)
Pipelines: 2600 km condensate, 16415 km gas, 3447 km
liquid petroleum gas, 7036 km oil, 144 km refined products
(2013) Railways: total: 3,973 km (2014)
standard gauge: 2,888 km 1.432-m gauge (283 km
electrified) (2014)
narrow gauge: 1,085 km 1.055-m gauge (2014)
country comparison to the world: 50
Roadways: total: 104,000 km (2015)
paved: 71,656 km (2015)
unpaved: 32,344 km (2015)
country comparison to the world: 46
Merchant marine: total: 106
by type: container ship 1, general cargo 11, oil tanker 10,
other 84 (2018)
country comparison to the world: 82
Ports and terminals: Major Seaport(s): Algiers, Annaba, Arzew,
Bejaia, Djendjene, Jijel, Mostaganem, Oran, Skikda LNG
terminal(s) (export): Arzew, Bethioua, Skikda
Military expenditures:
2.87% of GDP (2018)
3.01% of GDP (2017)
2.58% of GDP (2016)
2.36% of GDP (2015)
1.52% of GDP (2014)
country comparison to the world: 28
Military and security forces: Malian Armed Forces (FAMa):
Army (Armee de Terre), Republic of Mali Air Force (Force
Aerienne de la Republique du Mali, FARM), National Guard
(Garde National du Mali), Gendarmerie (2019) note: Mali
planned to establish a border guard force in 2019
Military service age and obligation: 18 years of age for selective
compulsory and voluntary military service (men and
women); 2-year conscript service obligation (2014) Military—
note: the United Nations Multi-dimensional Integrated
Stabilization Mission in Mali (MINUSMA) has operated in
the country since 2013; the Mission’s responsibilities
include providing security, rebuilding Malian security
forces, supporting national political dialogue, and assisting
in the reestablishment of Malian government authority; as
of October 2019, MINUSMA had more than 16,000 military,
police, and_ civilian personnel deployed (2019)','ba554eec30c478fb1da7f9e1f5d480506b4131ac0d72c44d787e37bc5652c7eb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('685830209ab5588c66b8c068e3f3e75de55f7cbc896c9f68bcfbcd3f18d8db16',2020,'AD','Andorra','military-and-security',89,'Military and security forces: NO regular military forces; Police
Corps of Andorra
Military—note: defense is the responsibility of France and','6c664136ec202c700a8155d5684319d82a10b24a600d910b9fd8216ba9efb37e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2484fc24e7bdef80a55dbd28c1e26c1d9b7b9de1368f9dc344278c34df6dda34',2020,'NA','Namibia','military-and-security',100,'Military expenditures: 1.78% of GDP (2018)
2.42% of GDP (2017)
2.95% of GDP (2016)
3.52% of GDP (2015)
5.4% of GDP (2014)
country comparison to the world: 64
Military and security forces: Angolan Armed Forces (Forcas
Armadas Angolanas, FAA): Army, Navy (Marinha de Guerra
Angola, MGA), Angolan National Air Force (Forca Aerea
Nacional Angolana, FANA; under operational control of the
Army); Rapid Reaction Police (paramilitary) (2019) Military
service age and obligation: 20-45 years of age for compulsory
male and 18-45 years for voluntary male military service
(registration at age 18 is mandatory); 20-45 years of age
for voluntary female service; 2-year conscript service
obligation; Angolan citizenship required; the Navy (MGA) is
entirely staffed with volunteers (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
10 (2015) inventory of registered aircraft operated by air
carriers: 55 (2015)
annual passenger traffic on registered air Carriers:
1,244,491 (2015)
annual freight traffic on registered air carriers: 46.043
million mt-km (2015)
Civil aircraft registration country code prefix: D2 (2016)
Airports: 176 (2013)
country comparison to the world: 32
Airports—with paved runways: total: 31 (2017)
over 3,047 m: 7 (2017)
2,438 to 3,047 m: 8 (2017)
1,524 to 2,437 m: 12 (2017)
914 to 1,523 m: 4 (2017)
Airports—with unpaved runways: total: 145 (2013)
over 3,047 m: 2 (2013)
2,438 to 3,047 m: 3 (2013)
1,524 to 2,437 m: 31 (2013)
914 to 1,523 m: 66 (2013)
under 914 m: 43 (2013)
Heliports: 1 (2013)
Pipelines: 352 km gas, 85 km liquid petroleum gas, 1065 km
oil, 5 km oil/gas/water (2013)
Railways: total: 2,852 km (2014)
narrow gauge: 2,729 km 1.067-m gauge (2014)
123 km 0.600-m gauge
country comparison to the world: 63
Roadways: total: 26,000 km (2018)
paved: 13,600 km (2018)
unpaved: 12,400 km (2018)
country comparison to the world: 101
Waterways: 1,300 km (2011)
country comparison to the world: 53
Merchant marine: total: 55
by type: general cargo 14, oil tanker 8, other 33 (2018)
country comparison to the world: 110
Ports and terminals: Major seaport(s): Cabinda, Lobito,
Luanda, Namibe
LNG terminal(s) (export): Angola Soyo
Military—note: defense is the responsibility of the UK
Military—note: the Antarctic Treaty prohibits any measures of
a military nature, such as the establishment of military
bases and fortifications, the carrying out of military
maneuvers, or the testing of any type of weapon; it permits
the use of military personnel or equipment for scientific
research or for any other’ peaceful purposes
Military and security forces: Ministry of National Security, Royal
Antigua and Barbuda Defense Force (includes Antigua and
Barbuda Coast Guard) (2012) Military service age and obligation:
18 years of age for voluntary military service; no
conscription; Governor-General has powers to call up men
for national service and set the age at which they could be
called up (2012) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 9 (2015)
annual passenger traffic on registered air Carriers:
1,039,809 (2015)
annual freight traffic on registered air carriers: 526,545
mt-km (2015)
Civil aircraft registration country code prefix: V2 (2016)
Airports: 3 (2013)
country comparison to the world: 193
Airports—with paved runways: total: 2 (2019)
2,438 to 3,047 m: 1
under 914 m: 1
Airports—with unpaved runways: total: 1 (2013)
under 914 m: 1 (2013)
Roadways: total: 1,170 km (2011)
paved: 386 km (2011)
unpaved: 784 km (2011)
country comparison to the world: 175
Merchant marine: total: 853
by type: bulk carrier 33, container ship 189, general cargo
5962, oil tanker 2, other 67 (2018) country comparison to
the world: 26
Ports and terminals: Major seaport(s): Saint John’s','e2e1fe69d7df10705705e022a12d06e1f9a4fb192de969e1f0925f8fa22ef3fd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45773ab5ff6975233522daa43c43f430f2c90064ff0ee5c54822d3483011a5c0',2020,'AQ','Antarctica','military-and-security',113,'Military expenditures: 0.86% of GDP (2018)
0.86% of GDP (2017)
0.95% of GDP (2016)
0.86% of GDP (2015)
0.88% of GDP (2014)
country comparison to the world: 127
Military and security forces: Argentine Army (Ejercito
Argentino), Navy of the Argentine Republic (Armada
Republica; includes naval aviation and naval infantry),
Argentine Air Force (Fuerza Aerea Argentina, FAA);
Ministry of Security: Gendarmerie, Prefectura Naval (coast
guard) (2019) Military service age and obligation: 18-24 years of
age for voluntary military service (18-21 requires parental
consent); no conscription; if the number of volunteers fails
to meet the quota of recruits for a particular year, Congress
can authorize the conscription of citizens turning 18 that
year for a period not exceeding one year (2012) Military—
note: The Argentine military is a well-organized force
constrained by the country’s prolonged economic hardship;
the military is implementing a modernization plan aimed at
making the ground forces lighter and more responsive.
President Mauricio Macri in July of 2019 said he would
remove a 2006 decree that limited the armed forces to
defending against external attacks and banned military
involvement in internal security issues. Macri said he
wanted the military to be able to collaborate in internal
security, primarily by providing logistic support in the
border areas. (2018) TRANSPORTATION
National air transport system: number of registered air Carriers:
6 (2015) inventory of registered aircraft operated by air
carriers: 107 (2015)
annual passenger traffic on registered air Carriers:
14,245,183 (2015)
annual freight traffic on _ registered air _ carriers:
243,772,567 mt-km (2015)
Civil aircraft registration country code prefix: LV (2016)
Airports: 1,138 (2013)
country comparison to the world: 6
Airports—with paved runways: total: 161 (2017)
over 3,047 m: 4 (2017)
2,438 to 3,047 m: 29 (2017)
1,524 to 2,437 m: 65 (2017)
914 to 1,523 m: 53 (2017)
under 914 m: 10 (2017)
Airports—with unpaved runways: total: 977 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 43 (2013)
914 to 1,523 m: 484 (2013)
under 914 m: 448 (2013)
Heliports: 2 (2013)
Pipelines: 29930 km gas, 41 km liquid petroleum gas, 6248
km oil, 3631 km refined products (2013) Railways: total:
36,917 km (2014)
standard gauge: 2,745.1 km 1.435-m gauge (41.1 km
electrified) (2014)
narrow gauge: 7,523.3 km 1.000-m gauge (2014)
broad gauge: 26,391 km 1.676-m gauge (149 km
electrified) (2014)
258 km 0.750-m gauge
country comparison to the world: 6
Roadways: total: 281,290 km (2017)
paved: 117,616 km (2017)
unpaved: 163,674 km (2017)
country comparison to the world: 21
Waterways: 11,000 km (2012)
country comparison to the world: 11
Merchant marine:
total: 167
by type: container ship 1, general cargo 9, oil tanker 27,
other 130 (2018)
country comparison to the world: 66
Ports and terminals: Major seaport(s): Bahia Blanca, Buenos
Aires, La Plata, Punta Colorada, Ushuaia container port(s)
(TEUs): Buenos Aires (1,851,701)
LNG terminal(s) (import): Bahia Blanca
river port(s): Arroyo Seco, Rosario, San Lorenzo-San
Martin (Parana)
Military expenditures:
1.89% of GDP (2018)
1.94% of GDP (2017)
1.87% of GDP (2016)
1.91% of GDP (2015)
1.96% of GDP (2014)
country comparison to the world: 56
Military and security forces: Armed Forces of Chile (Fuerzas
Armadas de Chile): Chilean Army, Chilean Navy (Armada de
Chile, includes Naval Aviation, Marine Corps, and Maritime
Territory and Merchant Marine Directorate (Directemar)),
Chilean Air Force (Fuerza Aerea de Chile, FACh);
Carabineros de Chile (National Police Force) (2019) note:
Carabineros de Chile are responsible to both the Ministry
of Defense and the Ministry of Interior Military service age and
obligation: 18-45 years of age for voluntary male and female
military service, although the right to compulsory
recruitment of males 18-45 is retained; service obligation is
12 months for Army and 22 months for Navy and Air Force
(2015)','48ed35a7a599696a40073b0f884b8d8eba0c1734621209e54794acecd4ee5d45','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f46b9409239a29027a54db9f53b3b7acfb968246ceb3a0baaa49b3c9d040c542',2020,'AM','Armenia','military-and-security',121,'Military expenditures: 4.25% of GDP (2018)
3.84% of GDP (2017)
4.09% of GDP (2016)
4.25% of GDP (2015)
3.94% of GDP (2014)
country comparison to the world: 9
Military and security forces: Armenian Armed Forces: Ground
Forces (Armenian Army), Air Force, Air Defense; “Nagorno-
Karabakh Republic”: Nagorno-Karabakh Defense Army
(2019) Military service age and obligation: 18-27 years of age for
voluntary or compulsory military service; 2-year conscript
service obligation, which can be served as an officer upon
deferment for university studies if enrolled in officer-
producing program; 17 year olds are eligible to become
cadets at military higher education institutes, where they
are classified as military personnel (2019)
Military and security forces: NO regular military forces (2011)
Military—note: defense is the _ responsibility of the
Netherlands; the Aruba _ security services focus on
organized crime and terrorism TRANSPORTATION
National air transport system: number of registered air Carriers:
3 (2015) inventory of registered aircraft operated by air
carriers: 19 (2015)
annual passenger traffic on registered air Carriers:
2,120,578 (2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: P4 (2016)
Airports: 1 (2013)
country comparison to the world: 212
Airports—with paved runways: total: 1 (2019)
2,438 to 3,047 m: 1
Roadways: total: 1,000 km (2010)
country comparison to the world: 179
Ports and terminals: Major Sseaport(s): Barcadera, Oranjestad
oil terminal(s): Sint Nicolaas
cruise port(s): Oranjestad','aa9c22649932899c5e6ba57ae7a10eb08d40c0980973c4d631ffb12a0434dd5d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('018711bbe0d5d4e9a9e04984ea162b371e8d1ad3cb66d78638448eb47c3ef78d',2020,'AU','Australia','military-and-security',132,'Military—note: defense is the responsibility of Australia;
periodic visits by the Royal Australian Navy and Royal
Australian Air Force TRANSPORTATION
Roadways: Ports and terminals: none; offshore anchorage
only
Military and security forces: NO regular military forces; France
bases land, air, and naval forces on New Caledonia (Forces
Armées de la Nouvelle-Calédonie, FANC) (2019) military—
note: defense is the responsibility of France
Military expenditures:
1.16% of GDP (2018)
1.21% of GDP (2017)
1.18% of GDP (2016)
1.15% of GDP (2015)
1.18% of GDP (2014)
country comparison to the world: 110
Military and security forces: New Zealand Defence Force
(NZDF): New Zealand Army, Royal New Zealand Navy,
Royal New Zealand Air Force (2019) Military service age and
obligation: 17 years of age for voluntary military service;
soldiers cannot be deployed until the age of 18; no
conscription (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
6 (2015) inventory of registered aircraft operated by air
carriers: 123 (2015)
annual passenger traffic on registered air Carriers:
15,304,409 (2015)
annual freight traffic on _ registered air _ carriers:
999,384,961 mt-km (2015)
Civil aircraft registration country code prefix: ZK (2016)
Airports: 123 (2013)
country comparison to the world: 48
Airports—with paved runways:
total: 39 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 1 (2017)
1,524 to 2,437 m: 12 (2017)
914 to 1,523 m: 23 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 84 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 33 (2013)
under 914 m: 48 (2013)
Pipelines: 331 km condensate, 2500 km gas, 172 km liquid
petroleum gas, 288 km oil, 198 km refined products (2018)
Railways: total: 4,128 km (2018)
narrow gauge: 4,128 km 1.067-m gauge (506 km
electrified) (2018)
country comparison to the world: 46
Roadways: total: 94,000 km (2017)
paved: 61,600 km (includes 199 km of expressways) (2017)
unpaved: 32,400 km (2017)
country comparison to the world: 53
Merchant marine: total: 111
by type: general cargo 15, oil tanker 6, other 90 (2018)
country comparison to the world: 81
Ports and terminals: Major seaport(s): Auckland, Lyttelton,
Manukau Harbor, Marsden Point, Tauranga, Wellington
Military—note: defense is the responsibility of Australia','1058db2ceff4b60a21c3365b865e2acfce51e507a8d9fb3b60f49eaa3a7bfc05','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('383b40e96ea9dc887f0308a0a1e7a9dbaaf03db15878c6d2701dd400caf1a5c9',2020,'NF','Norfolk Island','military-and-security',140,'Military expenditures: 1.89% of GDP (2018)
2.09% of GDP (2017)
2% of GDP (2016)
1.98% of GDP (2015)
1.8% of GDP (2014)
country comparison to the world: 55
Military and security forces: Australian Defense Force (ADF):
Australian Army (includes Special Operations Command),
Royal Australian Navy (includes Naval Aviation Force),
Royal Australian Air Force, Joint Operations Command
(JOC) (2019) Military service age and obligation: 177 years of age
for voluntary military service (with parental consent); no
conscription; women allowed to serve in most combat roles
(2018) TRANSPORTATION
National air transport system: number of registered air Carriers:
25 (2018) inventory of registered aircraft operated by air
carriers: 583 (2018)
annual passenger traffic on registered air Carriers:
69,294,187 (2018) annual freight traffic on registered air
carriers: 1,887,295,820 mt-km (2018)
Civil aircraft registration country code prefix: VH (2016)
Airports: 480 (2013)
country comparison to the world: 15
Airports—with paved runways: total: 349 (2017)
over 3,047 m: 11 (2017)
2,438 to 3,047 m: 14 (2017)
1,524 to 2,437 m: 155 (2017)
914 to 1,523 m: 155 (2017)
under 914 m: 14 (2017)
Airports—with unpaved runways: total: 131 (2013)
1,524 to 2,437 m: 16 (2013)
914 to 1,523 m: 101 (2013)
under 914 m: 14 (2013)
Heliports: 1 (2013)
Pipelines: 637 km condensate/gas, 30054 km gas, 240 km
liquid petroleum gas, 3609 km oil, 110 km oil/gas/water, 72
km refined products (2013) Railways: total: 33,343 km
(2015)
standard gauge: 17,446 km 1.435-m gauge (650 km
electrified) (2015)
narrow gauge: 12,318 km 1.067-m gauge (2,075.5 km
electrified) (2015)
broad gauge: 3,247 km 1.600-m gauge (372 km electrified)
(2015)
country comparison to the world: 8
Roadways: total: 873,573 km (2015)
urban: 145,928 km (2015)
non-urban: 727,645 km (2015)
country comparison to the world: 9
Waterways: 2,000 km (mainly used for recreation on Murray
and Murray-Darling River systems) (2011) country
comparison to the world: 42
Merchant marine: total: 563
by type: bulk carrier 4, general cargo 84, oil tanker 7, other
468 (2018)
country comparison to the world: 38
Ports and terminals: Major seaport(s): Brisbane, Cairns,
Darwin, Fremantle, Geelong, Gladstone, Hobart,
Melbourne, Newcastle, Port Adelaide, Port Kembla, Sydney
container port(s) (TEUs): Melbourne (2,806,436), Sydney
(2,530,122) (2017)
LNG terminal(s) (export): Australia Pacific, Barrow Island,
Burrup (Pluto), Curtis Island, Darwin, Karratha, Bladin
Point (Ichthys), Gladstone, Prelude (offshore FLNG),
Wheatstone dry bulk cargo port(s): Dampier (iron ore),
Dalrymple Bay (coal), Hay Point (coal), Port Hedland (iron
ore), Port Walcott (iron ore) TRANSNATIONAL ISSUES
Disputes—international: In 2007, Australia and Timor-Leste
agreed to a 50-year development zone and revenue sharing
arrangement and deferred a maritime boundary; Australia
asserts land and maritime claims to Antarctica; Australia’s
2004 submission to the Commission on the Limits of the
Continental Shelf extends its continental margins over 3.37
million square kilometers, expanding its seabed roughly 30
percent beyond its claimed EEZ; all borders between
Indonesia and Australia have been agreed upon bilaterally,
but a 1997 treaty that would settle the last of their
maritime and EEZ boundary has yet to be ratified by
Indonesia’s legislature; Indonesian groups_ challenge
Australia’s claim to Ashmore Reef; Australia closed parts of
the Ashmore and Cartier reserve to Indonesian traditional
fishing Refugees and internally displaced persons: refugees
(country of origin): 11,932 (Afghanistan), 10,702 (Iran),
5,061 (Pakistan) (2018) stateless persons: 132 (2018)
Illicit drugs: Tasmania is one of the world’s major suppliers of
licit opiate products; government maintains strict controls
over areas of opium poppy cultivation and output of poppy
straw concentrate; major consumer of cocaine and
amphetamines AUSTRIA
Military expenditures: 3.77% of GDP (2018)
3.72% of GDP (2017)
3.64% of GDP (2016)
5.61% of GDP (2015)
4.56% of GDP (2014)
country comparison to the world: 16
Military and security forces: Land Forces, Air Forces, Navy
Forces; Ministry of Internal Affairs: State Border Service
(includes Coast Guard) (2019) Military service age and
obligation: 18-35 years of age for compulsory military
service; service obligation 18 months or 12 months for
university graduates; 17 years of age for voluntary service;
17 year olds are considered to be on active service at cadet
military schools (2012) TRANSPORTATION
National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 35 (2015)
annual passenger traffic on registered air Carriers:
1,803,112 (2015)
annual freight traffic on registered air carriers: 41,954,600
mt-km (2015)
Civil aircraft registration country code prefix: 4K (2016)
Airports: 37 (2013)
country comparison to the world: 107
Airports—with paved runways: total: 30 (2017)
over 3,047 m: 5 (2017)
2,438 to 3,047 m: 5 (2017)
1,524 to 2,437 m: 13 (2017)
914 to 1,523 m: 4 (2017)
under 914 m: 3 (2017)
Airports—with unpaved runways: total: 7 (2013)
under 914 m: 7 (2013)
Heliports: 1 (2012)
Pipelines: 89 km condensate, 3890 km gas, 2446 km oil
(2013)
Railways: total: 2,944 km (2017)
broad gauge: 2,944.3 km 1.520-m gauge (approx. 1,767 km
electrified) (2017)
country comparison to the world: 62
Roadways: total: 24,981 km (2013)
country comparison to the world: 103
Merchant marine: total: 313
by type: general cargo 48, oil tanker 48, other 217 (2018)
country comparison to the world: 51
Ports and terminals: Major seaport(s): Baku (Baki) located on
the Caspian Sea TRANSNATIONAL ISSUES
Disputes—international: Azerbaijan, Kazakhstan, and Russia
ratified the Caspian seabed delimitation treaties based on
equidistance, while Iran continues to insist on a one-fifth
Slice of the sea; the dispute over the break-away Nagorno-
Karabakh region and the Armenian military occupation of
surrounding lands in Azerbaijan remains the primary focus
of regional instability; residents have evacuated the former
Soviet-era small ethnic enclaves in Armenia and
Azerbaijan; local border forces struggle to control the
illegal transit of goods and people across the porous,
undemarcated Armenian, Azerbaijani, and Georgian
borders; bilateral talks continue with Turkmenistan on
dividing the seabed and contested oilfields in the middle of
the Caspian Refugees and internally displaced persons: [DPs:
344,000 (conflict with Armenia over Nagorno-Karabakh;
IDPs are mainly ethnic Azerbaijanis but also include ethnic
Kurds, Russians, and Turks predominantly from occupied
territories around Nagorno-Karabakh; includes’ IDPs’
descendants, returned IDPs, and people living in insecure
areas and excludes people displaced by natural disasters;
around half the IDPs live in the capital Baku) (2018)
stateless persons: 3,585 (2018)
Illicit drugs: limited illicit cultivation of cannabis and opium
poppy, mostly for CIS consumption; small government
eradication program; transit point for Southwest Asian
opiates bound for Russia and to a lesser extent the rest of
Europe
BAHAMAS, THE
Grand
Bahama
U.S .
Freeport’ South
Riding Abaco
Biv nt
ISLANDS
Eleuthera
Cat Island
‘@ Mount Aivernia
Military and security forces: Royal Bahamas Defense Force:
Patrol Squadron, Commando Squadron, and Air Wing
(2019) Military service age and obligation: 18 years of age for
voluntary male and female service; no conscription (2012)','2b33384f8a461b2a06063ec8066acf94905fcb437bba0573b7de65e235e77b97','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b79adbf51db974520a55f43fc8f7d1585d145e85eae18fc02c54a814df8a593',2020,'BH','Bahrain','military-and-security',147,'Military expenditures:
3.6% of GDP (2018)
4.39% of GDP (2017)
4.73% of GDP (2016)
4.59% of GDP (2015)
4.42% of GDP (2014)
country comparison to the world: 17
Military and security forces: Bahrain Defense Force (BDF):
Royal Bahraini Army, Royal Bahraini Navy, Royal Bahraini
Air Force, Royal Bahraini Air Defense Force; National
Guard (charged with internal security and assisting the
BDF in defending against external threats) (2016) note: the
BDF also includes the Royal Guard, a battalion-plus sized
combined arms special forces unit Military service age and
obligation: 18 years of age for voluntary military service; 15
years of age for NCOs, technicians, and cadets; no
conscription (2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 6 (2015)
inventory of registered aircraft operated by air carriers: 42
(2015)
annual passenger traffic on registered air Carriers:
9,313,756 (2015)
annual freight traffic on _ registered air _ carriers:
240,107,004 mt-km (2015)
Civil aircraft registration country code prefix: AOC (2016)
Airports: 4 (2013)
country comparison to the world: 185
Airports—with paved runways:
total: 4 (2017)
over 3,047 m: 3 (2017)
914 to 1,523 m: 1 (2017)
Heliports: 1 (2013)
Pipelines: 20 km gas, 54 km oil (2013)
Roadways: total: 4,122 km (2010)
paved: 3,392 km (2010)
unpaved: 730 km (2010)
country comparison to the world: 149
Merchant marine: total: 259
by type: bulk carrier 1, container ship 1, general cargo 12,
oil tanker 4, other 241 (2018) country comparison to the
world: 56
Ports and terminals: Major seaport(s): Mina’ Salman, Sitrah','260cd7553132a4f774cfc2ade9d44ddd2f55dde00b5fa482156c982d9fcae155','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d57084e2e81d71ceeeec8a164b87afb30969105032253309ad6005f23bf46409',2020,'IN','India','military-and-security',154,'Military expenditures:
1.37% of GDP (2018)
1.38% of GDP (2017)
1.44% of GDP (2016)
1.46% of GDP (2015)
1.36% of GDP (2014)
country comparison to the world: 86
Military and security forces: Bangladesh Defense Force:
Bangladesh Army, Bangladesh Navy, Bangladesh Air Force;
Ministry of Home Affairs: Border Guard Bangladesh (BGB)
(2019) Military service age and obligation: 16-21 years of age for
voluntary military service; Bangladeshi nationality and 10th
grade education required; officers: 17-21 years of age,
Bangladeshi nationality, and 12th grade education required
(2018) Maritime threats: the International Maritime Bureau
reports the territorial waters of Bangladesh remain a risk
for armed robbery against ships; in 2018, the number of
attacks against commercial vessels increased to 12 over
the 11 such incidents in 2017','dc213d99866c8ce3cfd47fa6f7a6e0ed2fcc45059743053bb1afdbb991591429','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16b0520823b359e5f43158d085e3fb9185581d540f4b9ad199f3fe9a52d4a491',2020,'BB','Barbados','military-and-security',165,'Military and security forces: Royal Barbados Defense Force: The
Barbados Regiment, The Barbados Coast Guard (2019)
Military service age and obligation: 18 years of age for voluntary
military service, or earlier with parental consent; no
conscription (2013) TRANSPORTATION
Civil aircraft registration country code prefix: 8P (2016)
Airports: 1 (2013)
country comparison to the world: 213
Airports—with paved runways:
total: 1 (2019)
over 3,047 m: 1
Pipelines: 33 km gas, 64 km oil, 6 km refined products
(2013)
Roadways: total: 1,700 km (2015)
paved: 1,700 km (2015)
country comparison to the world: 169
Merchant marine: total: 121
by type: bulk carrier 21, general cargo 82, other 18 (2018)
country comparison to the world: 76
Ports and terminals: Major seaport(s): Bridgetown
Military expenditures:
1.27% of GDP (2018)
0.93% of GDP (2017)
1.2% of GDP (2016)
1.33% of GDP (2015)
1.33% of GDP (2014)
country comparison to the world: 96
Military and security forces: Belarus Armed Forces: Army, Air
and Air Defense Force, Special Operations Force; Ministry
of Interior: State Border Troops, Militia, Internal Troops
(2019) Military service age and obligation: 18-27 years of age for
compulsory military or alternative service; conscript
service obligation is 12-18 months, depending on academic
qualifications, and 24-36 months for alternative service,
depending on academic qualifications; 17 year olds are
eligible to become cadets at military higher education
institutes, where they are classified as military personnel
(2017) TRANSPORTATION
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 30
(2015)
annual passenger traffic on registered air Carriers:
1,489,035 (2015)
annual freight traffic on registered air carriers: 1.807
million mt-km (2015)
Civil aircraft registration country code prefix: EW (2016)
Airports: 65 (2013)
country comparison to the world: 75
Airports—with paved runways:
total: 33 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 20 (2017)
1,524 to 2,437 m: 4 (2017)
914 to 1,523 m: 1 (2017)
under 914 m: 7 (2017)
Airports—with unpaved runways:
total: 32 (2013)
over 3,047 m: 1 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 28 (2013)
Heliports: 1 (2013)
Pipelines: 5386 km gas, 1589 km oil, 1730 km refined
products (2013)
Railways: total: 5,528 km (2014)
standard gauge: 25 km 1.435-m gauge (2014)
broad gauge: 5,503 km 1.520-m gauge (874 km electrified)
(2014)
country comparison to the world: 35
Roadways: total: 86,600 km (2017)
country comparison to the world: 56
Waterways: 2,000 km (major rivers are the west-flowing
Western Dvina and Neman Rivers and the south-flowing
Dnepr River and its tributaries, the Berezina, Sozh, and
Pripyat Rivers) (2011) country comparison to the world: 35
Merchant marine: total: 5
by type: oil tanker 1, other 4 (2018)
country comparison to the world: 162
Ports and terminals: river port(s): Mazyr (Prypyats’)','9a99a760e8cdb613b608285fd6b4a2f98de0897e5bdd3115591c2bb2315d8986','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6700673ed2e6c460e7cb115553eff5d12e6a68e4f1eb86406db58955a5ace556',2020,'FR','France','military-and-security',177,'Military expenditures:
0.93% of GDP (2019)
0.93% of GDP (2018)
0.9% of GDP (2017)
0.91% of GDP (2016)
0.92% of GDP (2015)
country comparison to the world: 122
Military and _ security forces: Belgian Armed Forces: Land
Component, Naval Component, Air Component (2019)
Military service age and obligation: 18 years of age for male and
female voluntary military service; conscription abolished in
1994 (2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 7 (2015)
inventory of registered aircraft operated by air carriers:
117 (2015)
annual passenger traffic on registered air Carriers:
11,193,023 (2015)
annual freight traffic on _ registered air _ carriers:
1,464,316,900 mt-km (2015)
Civil aircraft registration country code prefix: OO (2016)
Airports: 41 (2013)
country comparison to the world: 102
Airports—with paved runways:
total: 26 (2019)
over 3,047 m: 6
2,438 to 3,047 m: 9
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m:8
Airports—with unpaved runways:
total: 15 (2013)
under 914 m: 15 (2013)
Heliports: 1 (2013)
Pipelines: 3139 km gas, 154 km oil, 535 km refined products
(2013)
Railways: total: 3,592 km (2014)
standard gauge: 3,592 km 1.435-m gauge (2,960 km
electrified) (2014)
country comparison to the world: 55
Roadways: total: 118,414 km (2015)
paved: 118,414 km (includes 1,747 km of expressways)
(2015)
country comparison to the world: 41
Waterways: 2,043 km (1,528 km in regular commercial use)
(2012)
country comparison to the world: 41
Merchant marine: total: 192
by type: bulk carrier 18, general cargo 18, oil tanker 20,
other 136 (2018)
country comparison to the world: 64
Ports and terminals: Major seaport(s): Oostende, Zeebrugge
container port(s) (TEUs): Antwerp (10,450,000) (2017)
LNG terminal(s) (import): Zeebrugge
river port(s): Antwerp, Gent (Schelde River)
Brussels (Senne River) Liege (Meuse River)
Military expenditures:
1.84% of GDP (2019 est.)
1.82% of GDP (2018)
1.78% of GDP (2017)
1.79% of GDP (2016)
1.78% of GDP (2015)
country comparison to the world: 61
Military and security forces: Army (Armee de Terre; includes
Foreign Legion), Navy (Marine Nationale), Air Force
(Armee de l’Air (AdlA); includes Air Defense), National
Guard (Reserves), National Gendarmerie (paramilitary
police force that is a branch of the Armed Forces but under
the jurisdiction of the Ministry of the Interior; also has
additional duties to the Ministry of Defense) (2019) Military
service age and obligation: 18-25 years of age for male and
female voluntary military service; no conscription; 1-year
service obligation; women serve in noncombat posts (2013)
Military expenditures:
0.92% of GDP (2019 est.)
0.92% of GDP (2018)
0.9% of GDP (2017)
0.81% of GDP (2016)
0.92% of GDP (2015)
country comparison to the world: 126
Military and security forces: Spanish Armed Forces: Army
(Ejercito de Tierra), Spanish Navy (Armada Espanola, AE,
includes Marine Corps), Spanish Air Force (Ejercito del
Aire Espanola, EdA); Civil Guard (Guardia Civil) (2019)
note: the Civil Guard is a military force with police duties
(including coast guard) under both the Ministry of Defence
and the Ministry of the Interior; it also responds to the
needs of the Ministry of Finance Military service age and
obligation: 18-26 years of age for voluntary military service
by a Spanish citizen or legal immigrant, 2-3 year obligation;
women allowed to serve in all SAF branches, including
combat units; no conscription, but Spanish Government
retains right to mobilize citizens 19-25 years of age in a
national emergency; mandatory retirement of non-NCO
enlisted personnel at age 45 or 58, depending on service
length (2013) TRANSPORTATION
National air transport system: number of registered air Carriers:
20 (2015) inventory of registered aircraft operated by air
carriers: 414 (2015)
annual passenger traffic on registered air Carriers:
60,809,228 (2015)
annual freight traffic on _ registered air _ Carriers:
1,040,913,279 mt-km (2015)
Civil aircraft registration country code prefix: EC (2016)
Airports: 135 (2020)
country comparison to the world: 41
Airports—with paved runways:
total: 102 (2020)
over 3,047 m: 18
2,438 to 3,047 m: 16
1,524 to 2,437 m: 19
914 to 1,523 m: 26
under 914 m: 23
Airports—with unpaved runways:
total: 33 (2020)
914 to 1,523 m: 14
under 914 m: 19
Heliports: 13 (2020)
Pipelines: 10481 km gas, 358 km oil, 4378 km refined
products (2017)
Railways: total: 15,333 km (9,699 km electrified) (2017)
standard gauge: 2,571 km 1.435-m gauge (2,571 km
electrified) (2017)
narrow gauge: 1,207 km 1.000-m gauge (400 km
electrified) (2017)
broad gauge: 11,333 km 1.668-m gauge (6,538 km
electrified) (2017)
mixed gauge: 190 km 1.668-m and 1.435m gage (190.1 km
electrified); 28 km 0.914-m gauge (28 km electrified); 4 km
0.600-m gauge country comparison to the world: 19
Roadways: total: 683,175 km (2011)
paved: 683,175 km (includes 16,205 km of expressways)
(2011)
country comparison to the world: 11
Waterways: 1,000 km (2012)
country comparison to the world: 64
Merchant marine: total: 119
by type: container ship 2, general cargo 17, oil tanker 12,
other 88 (2019)
country comparison to the world: 78
Ports and terminals: Major seaport(s): Algeciras, Barcelona,
Bilbao, Cartagena, Huelva, Tarragona, Valencia (all in
Spain); Las Palmas, Santa Cruz de Tenerife (in the Canary
Islands) container port(s) (TEUs): Algeciras (4,389,836),
Barcelona (2,968,757), Valencia (4,832,156) (2017) LNG
terminal(s) (import): Barcelona, Bilbao, Cartagena, Huelva,
Mugardos, Sagunto
Military—note: Spratly Islands consist of more than 100 small
islands or reefs of which about 45 are claimed and
occupied by China, Malaysia, the Philippines, Taiwan, and
Vietnam TRANSPORTATION
Airports: 8 (2020)
country comparison to the world: 163
Airports—with paved runways:
total: 6 (2020)
2,438 to 3,047 m: 3
914 to 1,523 m: 2
under 914 m:1
Airports—with unpaved runways:
total: 2 (2020)
914 to 1,523 m: 2
Heliports: 5 (2020)
Roadways: Ports and terminals: none; offshore anchorage
only','ef68e053ddd9a0b058b20abc82ba10e24e4645a2f70eddc4c9488a1c9cbf3a31','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2e7976c49847d68c5e0fdc44af472ab8d73af94fee370dd9b22a27ed5b3bc6',2020,'HN','Honduras','military-and-security',183,'Military expenditures:
1.26% of GDP (2018)
1.58% of GDP (2017)
1.17% of GDP (2016)
1.09% of GDP (2015)
1.06% of GDP (2014)
country comparison to the world: 98
Military and security forces: Belize Defense Force (BDF): Army,
Air Wing; Belize Coast Guard (2019) Military service age and
obligation: 18 years of age for voluntary military service;
laws allow for conscription only if volunteers are
insufficient; conscription has never been implemented;
volunteers typically outnumber available positions by 3:1;
initial service obligation 12 years (2012)','2307c61110644bbbe3d65cdb43c46e663000dfc9f323f8afba7bd147f7d5dd4c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fafc0e77fe89a9a5cf91d59dae2f6715a63d8b8525018a407ec9265d2390072c',2020,'ET','Ethiopia','military-and-security',190,'Military expenditures:
0.86% of GDP (2018)
1.26% of GDP (2017)
1.14% of GDP (2016)
1.1% of GDP (2015)
0.96% of GDP (2014)
country comparison to the world: 128
Military and security forces: Benin Armed Forces (Forces
Armees Beninoises, FAB): Army, Navy, Air Force; Ministry
of Public Security: Republican Police (2019) Military service
age and obligation: 18-35 years of age for selective
compulsory and voluntary military service; a _ higher
education diploma is required; both sexes are eligible for
military service; conscript tour of duty—18 months (2013)
Maritime threats: West African piracy more than doubled in
2018 to become the most dangerous area in the World; the
waters off of Benin saw a dramatic increase in 2018 with
five attacks reported compared with none in 2017; three
ships were boarded, two were hijacked, and 48 crew taken
hostage or kidnapped TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 1
(2015)
annual passenger traffic on registered air carriers: 112,392
(2015)
annual freight traffic on registered air carriers: 805,347
mt-km (2015)
Civil aircraft registration country code prefix: TY (2016)
Airports: 6 (2013)
country comparison to the world: 172
Airports—with paved runways:
total: 1 (2017)
1,524 to 2,437 m: 1 (2017)
Airports—with unpaved runways:
total: 5 (2013)
2,438 to 3,047 m: 2 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 2 (2013)
Pipelines: 134 km gas
Railways: total: 438 km (2014)
narrow gauge: 438 km 1.000-m gauge (2014)
country comparison to the world: 116
Roadways: total: 16,000 km (2006)
paved: 1,400 km (2006)
unpaved: 14,600 km (2006)
country comparison to the world: 119
Waterways: 150 km (seasonal navigation on River Niger
along northern border) (2011) country comparison to the
world: 101
Merchant marine: total: 6
by type: other 6 (2018)
country comparison to the world: 160
Ports and terminals: Major seaport(s): Cotonou
LNG terminal(s) (import): Cotonou
Military and security forces: Royal Bermuda Regiment (2019)
Military service age and obligation: 18-45 years of age for
voluntary male or female enlistment in the Bermuda
Regiment; males must register at age 18 and may be
subject to conscription; term of service is 38 months for
volunteers or conscripts (2012) Military—note: defense is the
responsibility of the UK
N afr eataore
a SOMALIA
; ““Beledweyne
~Baydhabo
MOGADISHU i
«
Marka
*Ki
HsMAaayO = 9 100 200km
| eens ean!
0 100 200mi
Military expenditures:
1.97% of GDP (2018)
1.89% of GDP (2017)
1.85% of GDP (2016)
1.68% of GDP (2015)
1.8% of GDP (2014)
country comparison to the world: 53
Military and security forces: Togolese Armed Forces (Forces
Armees Togolaise, FAT): Togolese Army (l’Armee de Terre),
Togolese Navy (Forces Naval Togolaises), Togolese Air
Force (Armee de |’Air), National Gendarmerie (2018) Military
service age and obligation: 18 years of age for military service;
2-year service obligation; currently the military is only an
all-volunteer force (2017) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 8 (2015)
annual passenger traffic on registered air carriers: 769,904
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: )V (2016)
Airports: 8 (2013)
country comparison to the world: 164
Airports—with paved runways:
total: 2 (2019)
2,438 to 3,047 m: 2
Airports—with unpaved runways:
total: 6 (2013)
914 to 1,523 m: 4 (2013)
under 914 m: 2 (2013)
Pipelines: 62 km gas
Railways: total: 568 km (2014)
narrow gauge: 568 km 1.000-m gauge (2014)
country comparison to the world: 111
Roadways: Waterways: 50 km (seasonally navigable by small
craft on the Mono River depending on rainfall) (2011)
country comparison to the world: 102
Merchant marine: total: 327
by type: bulk carrier 7, container ship 4, general cargo 215,
oil tanker 42, other 59 (2018)
country comparison to the world: 50
Ports and terminals: Major seaport(s): Kpeme, Lome
Military—note: defense is the responsibility of New Zealand
Military and security forces: His Majesty’s Armed Forces
(HMAF): Territorial Forces, Land Force (includes Tonga
Royal Guards, Royal Tonga Marines, and a Combined Log
and Tech Support Unit), Tonga Navy, Training Wing, Air
Wing and Support Unit (2019) Military service age and
obligation: Volunteers, 18-25; no conscription (2014)','561b0a2723418fe48b468f1e2d50292dc571e3306efc40ebcbde43251d91400b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feb46ced37ac0139a079035bc9e790d2c6d51031526680676011cd50c2416019',2020,'BT','Bhutan','military-and-security',199,'Military and security forces: Royal Bhutan Army (includes Royal
Bodyguard and Royal Bhutan Police, plus militia) (2019)
note: Bhutan does not have an air force; India is
responsible for military training, arms supplies, and the air
defense of Bhutan Military service age and obligation: 18 years of
age for voluntary military service; no conscription; militia
training is compulsory for males aged 20-25, over a 3-year
period (2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 6
(2015)
annual passenger traffic on registered air carriers: 162,864
(2015)
annual freight traffic on registered air carriers: 538,041
mt-km (2015)
Civil aircraft registration country code prefix: AD (2016)
Airports: 2 (2013)
country comparison to the world: 198
Airports—with paved runways:
total: 2 (2017)
1,524 to 2,437 m: 1 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 1 (2012)
914 to 1,523 m: 1 (2012)
Roadways: total: 12,205 km (2017)
urban: 437 km (2017)
country comparison to the world: 129','497947a3b5b6a843ed38cac543633f61610b127a9d2f906af946fa37e4eea2b5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2df63f160a37d037c9d5caa9c16f2e14af0dc726a1177012de5c85641e017f8b',2020,'BR','Brazil','military-and-security',215,'Military expenditures:
1.5% of GDP (2018)
1.54% of GDP (2017)
1.68% of GDP (2016)
1.74% of GDP (2015)
1.9% of GDP (2014)
country comparison to the world: 76
Military and security forces: Bolivian Armed Forces: Bolivian
Army (Ejercito Boliviano, EB), Bolivian Naval Force (Fuerza
Naval Boliviana, FNB, includes Marines), Bolivian Air Force
(Fuerza Aerea Boliviana, FAB); Ministry of Interior:
National Police (Policia Nacional de Bolivia, PNB; includes
Anti-Narcotics Special Forces (Fuerza Especial de Lucha
Contra el Narcotrafico, FELCN) and other paramilitary
units (2019) Military service age and obligation: 16-49 years of
age for 12-month voluntary male and female military
service; Bolivian citizenship required; minimum age for
combat duty is 18; when annual number of volunteers falls
short of goal, compulsory recruitment is effected, including
conscription of boys as young as 14; 15-19 years of age for
voluntary premilitary service, provides exemption from
further military service (2017) TRANSPORTATION
National air transport system:
number of registered air carriers: 7 (2015)
inventory of registered aircraft operated by air carriers: 39
(2015)
annual passenger traffic on registered air Carriers:
2,978,959 (2015)
annual freight traffic on registered air carriers: 9,456,548
mt-km (2015)
Civil aircraft registration country code prefix: CP (2016)
Airports: 855 (2013)
country comparison to the world: 7
Airports—with paved runways:
total: 21 (2017)
over 3,047 m: 5 (2017)
2,438 to 3,047 m: 4 (2017)
1,524 to 2,437 m: 6 (2017)
914 to 1,523 m: 6 (2017)
Airports—with unpaved runways:
total: 834 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 4 (2013)
1,524 to 2,437 m: 47 (2013)
914 to 1,523 m: 151 (2013)
under 914 m: 631 (2013)
Pipelines: 5457 km gas, 51 km liquid petroleum gas, 2511
km oil, 1627 km refined products (2013) Railways: total:
3,960 km (2019)
narrow gauge: 3,960 km 1.000-m gauge (2014)
country comparison to the world: 51
Roadways: total: 90,568 km (2017)
paved: 9,792 km (2017)
unpaved: 80,776 km (2017)
country comparison to the world: 54
Waterways: 10,000 km (commercially navigable almost
exclusively in the northern and eastern parts of the
country) (2012) country comparison to the world: 13
Merchant marine: total: 49
by type: general cargo 36, oil tanker 2, other 11 (2018)
country comparison to the world: 115
Ports and terminals: river port(s): Puerto Aguirre
(Paraguay/Parana)
note: Bolivia has free port privileges in maritime ports in
Argentina, Brazil, Chile, and Paraguay TRANSNATIONAL
ISSUES
Disputes—International: Chile and Peru rebuff Bolivia’s
reactivated claim to restore the Atacama corridor, ceded to
Chile in 1884, but Chile offers instead unrestricted but not
sovereign maritime access through Chile for Bolivian
products; contraband smuggling, human trafficking, and
illegal narcotic trafficking are problems in the porous areas
of its border regions with all of its neighbors (Argentina,
Brazil, Chile, Paraguay, and Peru) Trafficking in persons:
current situation: Bolivia is a source country for men,
women, and children subjected to forced labor and sex
trafficking domestically and abroad; rural and poor
Bolivians, most of whom are indigenous, and LGBT youth
are particularly vulnerable; Bolivians perform forced labor
domestically in mining, ranching, agriculture, and domestic
service, and a significant number are in forced labor
abroad in sweatshops, agriculture, domestic service, and
the informal sector; women and girls are sex trafficked
within Bolivia and in neighboring countries, such as
Argentina, Peru, and Chile; a limited number of women
from nearby countries are sex trafficked in Bolivia tier rating:
Tier 2 Watch List—Bolivia does not comply fully with the
minimum standards for the elimination of human
trafficking; however, it is making significant efforts to do
so; the government did not demonstrate overall increasing
anti-trafficking efforts, and poor data collection made it
difficult to assess the number of _ investigations,
prosecutions, and victim identifications and referrals to
care services; authorities did not adequately differentiate
between human trafficking and other crimes, such as
domestic violence and child abuse; law enforcement failed
to implement an early detection protocol for identifying
trafficking cases and lacked a formal process for identifying
trafficking victims among’ vulnerable populations;
specialized victim services were inadequately funded and
virtually non-existent for adult women and male victims
(2015) Illicit drugs: world’s third-largest cultivator of coca
(after Colombia and Peru) with an estimated 37,500
hectares under cultivation in 2016, a 3 percent increase
over 2015; third largest producer of cocaine, estimated at
275 metric tons potential pure cocaine in 2016; transit
country for Peruvian and Colombian cocaine destined for
Brazil, Argentina, Chile, Paraguay, and Europe; weak
border controls; some money-laundering activity related to
narcotics trade; major cocaine consumption BOSNIA AND
HERZEGOVINA
2 40 mi
DNS rea PP
“By Rex
Bosanski Brod \\
"Banja
Luka
@eenica
CROATIA SARAJEVO, Re ubsika
Federation of Bosnia Srpska
Military expenditures:
1.48% of GDP (2018)
1.42% of GDP (2017)
1.32% of GDP (2016)
1.36% of GDP (2015)
1.33% of GDP (2014)
country comparison to the world: 78
Military and security forces: Brazilian Armed Forces: Brazilian
Army (Exercito Brasileiro, EB), Brazilian Navy (Marinha do
Brasil, MB, includes Naval Aviation and Marine Corps
(Corpo de Fuzileiros Navais)), Brazilian Air Force (Forca
Aerea Brasileira, FAB); Public Security Forces (2019)
Military service age and obligation: 18-45 years of age for
compulsory military service; conscript service obligation is
10-12 months; 17-45 years of age for voluntary service; an
increasing percentage of the ranks are “long-service”
volunteer professionals; women were allowed to serve in
the armed forces beginning in early 1980s, when the
Brazilian Army became the first army in South America to
accept women into career ranks; women serve in Navy and
Air Force only in Women’s Reserve Corps (2012)
Military expenditures:
3.5% of GDP (2018 est.)
3.1% of GDP (2017)
3.06% of GDP (2016)
3.12% of GDP (2015)
3.13% of GDP (2014)
country comparison to the world: 18
Military and_ security forces: Military Forces of Colombia
(Fuerzas Militares de Colombia): National Army (Ejercito
Nacional), Republic of Colombia Navy (Armada Republica
de Colombia, ARC, includes Naval Aviation, Naval Infantry
(Infanteria de Marina, IM), and Coast Guard), Colombian
Air Force (Fuerza Aerea de Colombia, FAC); Colombian
National Police (civilian force that is part of the Ministry of
Defense) (2019) Military service age and obligation: 18-24
years of age for compulsory and voluntary military service;
service obligation is 18 months (2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 12 (2015)
inventory of registered aircraft operated by air carriers:
157 (2015)
annual passenger traffic on registered air Carriers:
30,742,928 (2015)
annual freight traffic on _ registered air _ carriers:
1,317,562,271 mt-km (2015) Civil aircraft registration country
code prefix: HJ, HK (2016)
Airports: 836 (2013)
country comparison to the world: 8
Airports—with paved runways:
total: 121 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 9 (2017)
1,524 to 2,437 m: 39 (2017)
914 to 1,523 m: 53 (2017)
under 914 m: 18 (2017)
Airports—with unpaved runways:
total: 715 (2013)
over 3,047 m: 1 (2013)
1,524 to 2,437 m: 25 (2013)
914 to 1,523 m: 201 (2013)
under 914 m: 488 (2013)
Heliports: 3 (2013)
Pipelines: 4991 km gas, 6796 km oil, 3429 km refined
products (2013)
Railways: total: 2,141 km (2015)
standard gauge: 150 km 1.435-m gauge (2015)
narrow gauge: 1,991 km 0.914-m gauge (2015)
country comparison to the world: 72
Roadways: total: 206,500 km (2016)
country comparison to the world: 26
Waterways: 24,725 km (18,300 km navigable; the most
important waterway, the River Magdalena, of which 1,488
km is navigable, is dredged regularly to ensure safe
passage of cargo vessels and container barges) (2012)
country comparison to the world: 6
Merchant marine: total: 102
by type: general cargo 18, oil tanker 8, other 76 (2018)
country comparison to the world: 83
Ports and terminals: major seaport(s): Atlantic Ocean
(Caribbean)—Cartagena, Santa Marta, Turbo © oil
terminal(s): Covenas offshore terminal
container port(s) (TEUs): Cartagena (2,663,415) (2017)
river port(s): Barranquilla (Rio Magdalena)
dry bulk cargo port(s): Puerto Bolivar (coal)
Pacific Ocean—Buenaventura
Military and security forces: National Army for Development
(l’Armee Nationale de Developpement, AND): Comoran
Security Force (also called Comoran Defense Force (Force
Comorienne de Defense, FCD), includes Gendarmerie),
Comoran Coast Guard, Comoran Federal Police (2017)
Military service age and obligation: 18 years of age for 2-
year voluntary male and female military service; no
conscription (2015) TRANSPORTATION
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 9
(2015)
Civil aircraft registration country code prefix: D6 (2016)
Airports: 4 (2013)
country comparison to the world: 187
Airports—with paved runways:
total: 4 (2017)
2,438 to 3,047 m: 1 (2017)
914 to 1,523 m: 3 (2017)
Roadways: total: 880 km (2002)
paved: 673 km (2002)
unpaved: 207 km (2002)
country comparison to the world: 181
Merchant marine: total: 218
by type: bulk carrier 7, container ship 2, general cargo 102,
oil tanker 29, other 78 (2018) country comparison to the
world: 62
Ports and terminals: Major seaport(s): Moroni, Moutsamoudou
Military expenditures:
1.69% of GDP (2018)
1.68% of GDP (2017)
1.51% of GDP (2016)
1.46% of GDP (2015)
1.28% of GDP (2014)
country comparison to the world: 68
Military and security forces: Guyana Defense Force: Army, Air
Corps, Coast Guard (2019) Military service age and obligation:
18 years of age or older for voluntary military service; no
conscription (2014) TRANSPORTATION
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 12
(2015)
annual passenger traffic on registered air carriers: 43,835
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: 8R (2016)
Airports: 117 (2013)
country comparison to the world: 49
Airports—with paved runways:
total: 11 (2017)
1,524 to 2,437 m: 2 (2017)
914 to 1,523 m: 1 (2017)
under 914 m: 8 (2017)
Airports—with unpaved runways: total: 106 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 16 (2013)
under 914 m: 89 (2013)
Roadways: total: 3,995 km (2019)
paved: 799 km (2019)
unpaved: 3,196 km (2019)
country comparison to the world: 151
Waterways: 330 km (the Berbice, Demerara, and Essequibo
Rivers are navigable by oceangoing vessels for 150 km, 100
km, and 80 km respectively) (2012) country comparison to
the world: 91
Merchant marine: total: 55
by type: general cargo 26, oil tanker 7, other 22 (2018)
country comparison to the world: 111
Ports and terminals: Major seaport(s): Georgetown
OO —SSCSC‘C;CSCiézC
Military and security forces: the Haitian Armed Forces (FAdH),
disbanded in 1995, began to be reconstituted in 2017 to
assist with natural disaster relief, border security, and
combating transnational crime; the small Coast Guard is
not part of the military, but rather the Haitian National
Police. (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 1
(2015)
Civil aircraft registration country code prefix: HH (2016)
Airports: 14 (2013)
country comparison to the world: 149
Airports—with paved runways:
total: 4 (2019)
2,438 to 3,047 m: 2
914 to 1,523 m: 2
Airports—with unpaved runways:
total: 10 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 8 (2013)
Roadways: total: 4,266 km (2009)
paved: 768 km (2009)
unpaved: 3,498 km (2009)
country comparison to the world: 148
Merchant marine: total: 4
by type: general cargo 3, other 1 (2018)
country comparison to the world: 165
Ports and terminals: Major seaport(s): Cap-Haitien, Gonaives,
Jacmel, Port-au-Prince TRANSNATIONAL ISSUES
Disputes—International: Since 2004, peacekeepers from the UN
Stabilization Mission in Haiti have assisted in maintaining
civil order in Haiti; the mission currently includes 6,685
military, 2,607 police, and 443 civilian personnel; despite
efforts to control illegal migration, Haitians cross into the
Dominican Republic and sail to neighboring countries; Haiti
claims US-administered Navassa Island Refugees and
internally displaced persons: IDPs: 34,508 (includes only IDPs
from the 2010 earthquake living in camps or camp-like
situations; information is lacking about IDPs living outside
of camps or who have left camps) (2019) stateless persons:
2,992 (2018); note—individuals without a nationality who
were born in the Dominican Republic prior to January 2010
Trafficking in persons: Current situation: Haiti is a source,
transit, and destination country for men, women, and
children subjected to forced labor and sex trafficking; most
of Haiti’s trafficking cases involve children in domestic
servitude vulnerable to physical and sexual abuse;
dismissed and runaway child domestic servants often end
up in prostitution, begging, or street crime; other exploited
populations included low-income Haitians, child laborers,
and women and children living in IDP camps dating to the
2010 earthquake; Haitian adults are vulnerable to
fraudulent labor recruitment abroad and, along with
children, may be subjected to forced labor in the Dominican
Republic, elsewhere in the Caribbean, South America, and
the US; Dominicans are exploited in sex trafficking and
forced labor in Haiti tier rating: Tier 2 Watch List—Haiti does
not fully comply with the minimum standards for the
elimination of trafficking; however, it is making significant
efforts to do so; in 2014, Haiti was granted a waiver from
an otherwise required downgrade to Tier 3 because its
government has a written plan that, if implemented would
constitute making significant efforts to bring itself into
compliance with the minimum standards for the elimination
of trafficking; in 2014, Haiti developed a national anti-
trafficking action plan and enacted a law prohibiting all
forms of human trafficking, although judicial corruption
hampered its implementation; progress was made in
investigating and prosecuting suspected traffickers, but no
convictions were made; the government sustained limited
efforts to identify and refer victims to protective services,
which were provided mostly by NGOs without government
support; campaigns to raise awareness about child labor
and child trafficking continued (2015) illicit drugs: Caribbean
transshipment point for cocaine en route to the US and
Europe; substantial bulk cash smuggling activity;
Colombian narcotics traffickers favor Haiti for illicit
financial transactions; pervasive corruption; significant
consumer of cannabis HEARD ISLAND AND MCDONALD
ISLANDS
McDonald Shag
Islands Island
Flat Island
McDonald Island
Heard Island
Military and security forces: Suriname Army (National Leger,
NL): Army, Navy, Air Force, Military Police (2019) Military
service age and obligation: 18 is the legal minimum age for
voluntary military service; no _ conscription (2019)
Military expenditures:
1.95% of GDP (2018)
1.98% of GDP (2017)
1.88% of GDP (2016)
1.82% of GDP (2015)
1.81% of GDP (2014)
country comparison to the world: 54
Military and security forces: Armed Forces of Uruguay (Fuerzas
Armadas del Uruguay): National Army (Ejercito Nacional),
National Navy (Armada Nacional, includes Maritime
National Prefecture (Coast Guard)), Uruguayan Air Force
(Fuerza Aerea) (2019) Military service age and obligation: 18-30
years of age (18-22 years of age for Navy) for male or
female voluntary military service; up to 40 years of age for
specialists; enlistment is voluntary in peacetime, but the
government has the authority to conscript in emergencies
(2013) TRANSPORTATION
National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 3 (2015)
Civil aircraft registration country code prefix: CX (2016)
Airports: 133 (2013)
country comparison to the world: 43
Airports—with paved runways:
total: 11 (2013)
over 3,047 m: 1 (2013)
1,524 to 2,437 m: 4 (2013)
914 to 1,523 m: 4 (2013)
under 914 m: 2 (2013)
Airports—with unpaved runways:
total: 122 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 40 (2013)
under 914 m: 79 (2013)
Pipelines: 257 km gas, 160 km oil (2013)
Railways: total: 1,673 km (operational; government claims
overall length is 2,961 km) (2016) standard gauge: 1,673
km 1.435-m gauge (2016)
country comparison to the world: 80
Roadways: total: 77,732 km (2010)
paved: 7,743 km (2010)
unpaved: 69,989 km (2010)
country comparison to the world: 63
Waterways: 1,600 km (2011)
country comparison to the world: 50
Merchant marine: total: 57
by type: container ship 1, general cargo 6, oil tanker 3,
other 47 (2018)
country comparison to the world: 109
Ports and terminals: Major seaport(s): Montevideo
Military expenditures:
0.49% of GDP (2017)
0.45% of GDP (2016)
0.94% of GDP (2015)
1.16% of GDP (2014)
1.67% of GDP (2013)
country comparison to the world: 149
Military and security forces: Bolivarian National Armed Forces
(Fuerza Armada Nacional Bolivariana, FANB): Bolivarian
Army (Ejercito Bolivariano, EB), Bolivarian Navy (Armada
Bolivariana, AB; includes Marines, Coast Guard), Bolivarian
Military Aviation (Aviacion Militar Bolivariana, AMB),
Integral Aerospace Defense Command (Comando de
Defensa Aeroespacial Integral, CODAI), Bolivarian National
Guard (Guardia Nacional Bolivaria, GNB), Bolivarian Militia
(Milicia Bolivariana, NMB) (2019) Military service age and
obligation: all citizens of military service age (18-60 years
old) are obligated to register for military service and
subject to military training, though mandatory recruitment
is forbidden; the minimum service obligation is 24-30
months (2016) Maritime threats: The International Maritime
Bureau continues to report the territorial and offshore
waters in the Caribbean Sea as at risk for piracy and armed
robbery against ships; numerous vessels, including
commercial shipping and pleasure craft, have been
attacked and hijacked both at anchor and while underway;
crews have been robbed and stores or cargoes stolen; in
2018, 11 attacks were reported which was a slight
decrease from the 12 attacks in 2017. Nevertheless, the
waters off Venezuela continue to be the fourth most
dangerous area for mariners in the world. (2018)
Military expenditures:
2.3% of GDP (2018)
2.27% of GDP (2017)
2.44% of GDP (2016)
2.36% of GDP (2015)
2.29% of GDP (2014)
country comparison to the world: 38
Military and security forces: People’s Army of Vietnam (PAVN):
PAVN Ground Forces, PAVN Navy (includes naval infantry),
PAVN Air Force and Air Defense, Border Defense Force,
and Vietnam Coast Guard; Vietnam People’s Public
Security; Vietnam Civil Defense Force (2019) Military service
age and obligation: 18-27 years of age for compulsory and
voluntary military service (females eligible for conscription,
but in practice only males are drafted); conscription
typically takes place twice annually and service obligation
is 2 years (Army, Air Defense) and 3 years (Navy and Air
Force) (2019) Maritime threats: the International Maritime
Bureau reports the territorial and offshore waters in the
South China Sea as high risk for piracy and armed robbery
against ships; numerous commercial vessels have been
attacked and hijacked both at anchor and while underway;
hijacked vessels are often disguised and cargo diverted to
ports in East Asia; crews have been murdered or cast
adrift; the number of reported incidents increased from two
in 2017 to four in 2018, primarily near the port of Vung Tau
Military—note: defense is the responsibility of the US','55a31e32ae1fbe3d76d35248ab4272e3c710ca216dd082bb7ad96a8f7e920012','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6490aed67ce9ade299158168f6006035da1d7f268524428170aa2f2bad98a0af',2020,'ME','Montenegro','military-and-security',221,'Military expenditures:
1.11% of GDP (2018)
0.91% of GDP (2017)
0.99% of GDP (2016)
1% of GDP (2015)
1.03% of GDP (2014)
country comparison to the world: 112
Military and security forces: Armed Forces of Bosnia and
Herzegovina (Oruzanih Snaga Bosne i Hercegovine,
OSBiH): Operations Command (includes Army, Air, and Air
Defense units), Support Command (2019) Military service age
and obligation: 18 years of age for voluntary military service;
mandatory retirement at age 35 or after 15 years of service
for E-1 through E-4, mandatory retirement at age 50 and
30 years of service for E-5 through E-9, mandatory
retirement at age 55 and 30 years of service for all officers
(2014) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 1
(2015)
annual passenger traffic on registered air carriers: 7,070
(2015)
annual freight traffic on registered air carriers: 87 mt-km
(2015)
Civil aircraft registration country code prefix: [9 (2016)
Airports: 24 (2013)
country comparison to the world: 130
Airports—with paved runways:
total: 7 (2017)
2,438 to 3,047 m: 4 (2017)
1,524 to 2,437 m: 1 (2017)
under 914 m: 2 (2017)
Airports—with unpaved runways:
total: 17 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 11 (2013)
Heliports: 6 (2013)
Pipelines: 147 km gas, 9 km oil (2013)
Railways: total: 965 km (2014)
standard gauge: 965 km 1.435-m gauge (565 km
electrified) (2014)
country comparison to the world: 90
Roadways: total: 22,926 km (2010)
paved: 19,426 km (4,652 km of interurban roads) (2010)
unpaved: 3,500 km (2010)
country comparison to the world: 107
Waterways: (Sava River on northern border; open to shipping
but use limited) (2011)
Ports and terminals: river port(s): Bosanska Gradiska,
Bosanski Brod, Bosanski Samac, Brcko, Orasje (Sava River)','6c59ad05638ea61b04010b8a699f979101b71ead7713fd71abf4ff22f4cea5ef','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40fbedb89e4a6559a96a8c9aa3e67ca2d9bb2baab68eb49df95493070c80bb07',2020,'ZA','South Africa','military-and-security',231,'Military expenditures:
2.78% of GDP (2018)
3.02% of GDP (2017)
3.37% of GDP (2016)
2.66% of GDP (2015)
2.13% of GDP (2014)
country comparison to the world: 29
Military and security forces: Botswana Defence Force (BDF):
Ground Forces Command, Air Arm Command, Defense
Logistics Command (2019) Military service age and obligation:
18 is the legal minimum age for voluntary military service;
no conscription (2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 6
(2015)
annual passenger traffic on registered air carriers: 194,005
(2015)
annual freight traffic on registered air carriers: 94,729 mt-
km (2015)
Civil aircraft registration country code prefix: AZ (2016)
Airports: 74 (2013)
country comparison to the world: 70
Airports—with paved runways:
total: 10 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 1 (2017)
1,524 to 2,437 m: 6 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 64 (2013)
1,524 to 2,437 m: 5 (2013)
914 to 1,523 m: 46 (2013)
under 914 m: 13 (2013)
Railways: total: 888 km (2014)
narrow gauge: 888 km 1.067-m gauge (2014)
country comparison to the world: 95
Roadways: total: 31,747 km (2017)
paved: 9,810 km (2017)
unpaved: 21,937 km (2017)
country comparison to the world: 94
Military—note: defense is the responsibility of Norway
Military expenditures:
1.81% of GDP (2018)
2.01% of GDP (2017)
1.83% of GDP (2016)
1.85% of GDP (2015)
1.84% of GDP (2014)
country comparison to the world: 62
Military and security forces: Lesotho Defense Force (LDF): Army
(includes Air Wing) (2019)
Military service age and obligation: 18-24 years of age for
voluntary military service; no conscription; women serve as
commissioned officers (2017) Military—note: Lesotho’s
declared policy for its military is the maintenance of the
country’s sovereignty and the preservation of internal
security; in practice, external security is guaranteed by
South Africa TRANSPORTATION
Civil aircraft registration country code prefix: 7P (2016)
Airports: 24 (2013)
country comparison to the world: 131
Airports—with paved runways:
total: 3 (2019)
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 1
Airports—with unpaved runways:
total: 21 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 16 (2013)
Roadways: total: 5,940 km (2011)
paved: 1,069 km (2011)
unpaved: 4,871 km (2011)
country comparison to the world: 140','25548c3f8ed22a41efb9d9da49c650a1a5af30b0210ab19902dec91c3d9056ce','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('293e4d4044488c8654c8a6a8e193c1334814919bfb31c64e642d3bbe06dbf928',2020,'PR','Puerto Rico','military-and-security',241,'Military—note: defense is the responsibility of the UK
Military expenditures:
2.37% of GDP (2018)
2.87% of GDP (2017)
3.54% of GDP (2016)
3.28% of GDP (2015)
3.08% of GDP (2014)
country comparison to the world: 36
Military and security forces: Royal Brunei Armed Forces: Royal
Brunei Land Force, Royal Brunei Navy, Royal Brunei Air
Force (2019) Military service age and obligation: 17 years of age
for voluntary military service; non-Malays are ineligible to
serve; recruits from the army, navy, and air force all
undergo 43-week initial training (2013) Military—note: Brunei
has a long-standing defense relationship with the United
Kingdom and hosts a British Army garrison, which includes
a Gurkha battalion and a jungle warfare school; there is
also a long-term Singaporean military presence (2019)
Military and security forces: NO regular indigenous military
forces; National Guard, State Guard, Police Force Military—
note: defense is the responsibility of the US
Military and security forces: Qatari Amiri Land Force (QALF,
includes Emiri Guard), Qatari Amiri Navy (QAN, includes
Coast Guard), Qatari Amiri Air Force (QAAF); Internal
Security Forces: Mobile Gendarmerie (2019) Military service
age and obligation: conscription for males aged 18-35;
compulsory service times range from 4 months to up to a
year, depending on the cadets educational and professional
circumstances; women are permitted to serve in the armed
forces, including as uniformed officers and pilots (2019)','7363fbc4372d5fd9b7c86b30c4b5629c16c322f6553a1dd6c663ef490fb71cb7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22a25572114b92bf57b26424c65a67179a575fddd96411e00c30f2ae92de16c5',2020,'MM','Myanmar','military-and-security',253,'Military expenditures:
2.93% of GDP (2018)
3.24% of GDP (2017)
3.74% of GDP (2016)
4.08% of GDP (2015)
3.58% of GDP (2014)
country comparison to the world: 26
Military and security forces: Burmese Defense Service
(Tatmadaw): Army (Tatmadaw Kyi), Navy (Tatmadaw Yay),
Air Force (Tatmadaw Lay), Directorate of People’s Militia
and Border Guard Forces (2019) Military service age and
obligation: 18-35 years of age (men) and 18-27 years of age
(women) for voluntary military service; no conscription (a
2010 law reintroducing conscription has not yet entered
into force); 2-year service obligation; male (ages 18-45) and
female (ages 18-35) professionals (including doctors,
engineers, mechanics) serve up to 3 years; service terms
may be stretched to 5 years in an officially declared
emergency; Burma signed the Convention on the Rights of
the Child on 15 August 1991; on 27 June 2012, the regime
signed a Joint Action Plan on prevention of child
recruitment; in February 2013, the military formed a new
task force to address forced child conscription (2013)','c632fc1202c01f2208b7db40a8d3554ed28ebd19a21c13883a677d9930739fda','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3a9895fd714991ae420a153371feb54bef80e36c38df1be23aaf7561b633fc8',2020,'BI','Burundi','military-and-security',262,'Military expenditures:
1.88% of GDP (2018)
1.87% of GDP (2017)
2.2% of GDP (2016)
2.14% of GDP (2015)
2.01% of GDP (2014)
country comparison to the world: 59
Military and security forces: National Defense Forces (Forces de
Defense Nationale, FDN): Army (includes maritime wing,
air wing), National Police (Police Nationale du Burundi)
(2019) Military service age and obligation: 18 years of age for
voluntary military service; the armed forces law of 31
December 2004 did not specify a minimum age for
enlistment, but the government claimed that no one
younger than 18 was being recruited; mandatory
retirement ages: 45 (enlisted), 50 (NCOs), 55 (officers), and
60 (officers with the rank of general) (2017)','6a0075d9cffbf913e0fcf7b715cdd4f5c95a4acf59c1eaaaa5c5a8c360cd0cfb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d19999726a98fdf3c191f8910c1dc0846025253f0aafe7d80c53c3e1e707e246',2020,'CV','Cabo Verde','military-and-security',271,'Military expenditures:
0.55% of GDP (2018)
0.54% of GDP (2017)
0.63% of GDP (2016)
0.57% of GDP (2015)
0.54% of GDP (2014)
country comparison to the world: 145
Military and security forces: Armed Forces: Army (also called
the National Guard, GN), Cabo Verde Coast Guard (Guardia
Costeira de Cabo Verde, GCCV, includes naval infantry)
(2013) Military service age and obligation: 18-35 years of age for
male and female selective compulsory military service; 2-
years conscript service obligation; 17 years of age for
voluntary service (with parental consent) (2013)','06e98fa6b0d91fa11fe4691f9270f40355c4ed389e8f8bd0bbcd9a32582d38a2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6678472c4880edaec8b2d5319547dfc3cb977e991bd3c5080be57747776de35a',2020,'TH','Thailand','military-and-security',276,'Military expenditures:
2.21% of GDP (2018)
2.09% of GDP (2017)
1.85% of GDP (2016)
2.11% of GDP (2015)
1.66% of GDP (2014)
country comparison to the world: 41
Military and security forces: Royal Cambodian Armed Forces:
High Command Headquarters, Royal Cambodian Army,
Royal Khmer Navy, Royal Cambodian Air Force; the Royal
Cambodian Gendarmerie (military police force responsible
for internal security); the National Counter Terrorism
Committee; the National Committee for Maritime Security
(performs Coast Guard functions and has representation
from military and civilian agencies) (2019) Military service
age and obligation: 18 is the legal minimum age for
compulsory and _ voluntary military’ service (2012)','ddaf62130d7eafce36a527881f2379cb0d362c25b52fa230d1d5d8df7adf97a8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db2ad67d6df9b08f2099b1c0feab829ffede4020cf26ff11f0a58425694a8130',2020,'CM','Cameroon','military-and-security',289,'Military expenditures:
1.25% of GDP (2018)
1.31% of GDP (2017)
1.32% of GDP (2016)
1.25% of GDP (2015)
1.25% of GDP (2014)
country comparison to the world: 99
Military and security forces: Cameroon Armed Forces (Forces
Armees Camerounaises, FAC): Army (LArmee de Terre),
Navy (Marine Nationale Republique, MNR, includes naval
infantry), Air Force (Armee de |’Air du Cameroun, AAC),
Gendarmerie, Presidential Guard (2019) Military service
age and obligation: 18-23 years of age for male and female
voluntary military service; no conscription; high school
graduation required; service obligation 4 years; periodic
government calls for volunteers (2012) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 3 (2015)
annual passenger traffic on registered air carriers: 267,208
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: TJ (2016)
Airports: 33 (2013)
country comparison to the world: 112
Airports—with paved runways:
total: 11 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 5 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 22 (2013)
1,524 to 2,437 m: 4 (2013)
914 to 1,523 m: 10 (2013)
under 914 m: 8 (2013)
Pipelines: 53 km gas, 5 km liquid petroleum gas, 1107 km
oil, 35 km water (2013)
Railways: total: 987 km (2014)
narrow gauge: 987 km 1.000-m gauge (2014)
note: railway connections generally efficient but limited;
rail lines connect major cities of Douala, Yaounde,
Ngaoundere, and Garoua; passenger and freight service
provided by CAMRAIL
country comparison to the world: 89
Roadways: total: 77,589 km (2016)
paved: 5,133 km (2016)
unpaved: 72,456 km (2016)
country comparison to the world: 64
Waterways: (major rivers in the south, such as the Wouri and
the Sanaga, are largely non-navigable; in the north, the
Benue, which connects through Nigeria to the Niger River,
is navigable in the rainy season only to the port of Garoua)
(2010) Merchant marine: total: 19
by type: general cargo 4, other 15 (2018)
country comparison to the world: 139
Ports and terminals: Oil terminal(s): Limboh Terminal
river port(s): Douala (Wouri)
Garoua (Benoue)
Military expenditures:
2.55% of GDP (2018)
4.27% of GDP (2017)
6.38% of GDP (2016)
5% of GDP (2014)
4.61% of GDP (2013)
country comparison to the world: 32
Military and security forces: Congolese Armed Forces (Forces
Armees Congolaises, FAC): Army (Armee de Terre), Navy,
Congolese Air Force (Armee de _ 1l’Air Congolaise);
Gendarmerie; Presidential Guard (2019) Military service
age and obligation: 18 years of age for voluntary military
service; women may serve in the Armed Forces (2013)','27386ed86eac5a4066a8c2a79fa898e5d8093a6e4ef4f976241dbd8bce795a1f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce1750734609685684a908a51ebc2686597c65875e18a5b29ecfd0bd6e0430ea',2020,'CA','Canada','military-and-security',298,'Military expenditures:
1.31% of GDP (2019 est.)
1.31% of GDP (2018)
1.44% of GDP (2017)
1.16% of GDP (2016)
1.2% of GDP (2015)
country comparison to the world: 93
Military and security forces: Canadian Forces: Canadian Army,
Royal Canadian Navy, Royal Canadian Air Force, Canadian
Joint Operations Command, Canadian Special Operations
Forces Command (2019) Military service age and
obligation: 17 years of age for voluntary male and female
military service (with parental consent); 16 years of age for
Reserve and Military College applicants; Canadian
citizenship or permanent residence status required;
maximum 34 years of age; service obligation 3-9 years
(2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 51 (2015)
inventory of registered aircraft operated by air carriers:
879 (2015)
annual passenger traffic on registered air Carriers:
80,228,301 (2015)
annual freight traffic on _ registered air _ carriers:
2,074,830,881 mt-km (2015)
Civil aircraft registration country code prefix: C (2016)
Airports: 1,467 (2013)
country comparison to the world: 4
Airports—with paved runways:
total: 523 (2017)
over 3,047 m: 21 (2017)
2,438 to 3,047 m: 19 (2017)
1,524 to 2,437 m: 147 (2017)
914 to 1,523 m: 257 (2017)
under 914 m: 79 (2017)
Airports—with unpaved runways:
total: 944 (2013)
1,524 to 2,437 m: 75 (2013)
914 to 1,523 m: 385 (2013)
under 914 m: 484 (2013)
Heliports: 26 (2013)
Pipelines: 110000 km gas and liquid petroleum (2017)
Railways: total: 77,932 km (2014)
standard gauge: 77,932 km 1.435-m gauge (2014)
country comparison to the world: 4
Roadways: total: 1,042,300 km (2011)
paved: 415,600 km (includes 17,000 km of expressways)
(2011)
unpaved: 626,700 km (2011)
country comparison to the world: 8
Waterways: 636 km (Saint Lawrence Seaway of 3,769 km,
including the Saint Lawrence River of 3,058 km, shared
with United States) (2011)
country comparison to the world: 77
Merchant marine: total: 657
by type: bulk carrier 17, container ship 1, general cargo 91,
oil tanker 17, other 531 (2018) country comparison to the
world: 32
Ports and terminals: Major seaport(s): Halifax, Saint John
(New Brunswick), Vancouver oil terminal(s): Lower Lakes
terminal
container port(s) (TEUs): Montreal (1,537,669), Vancouver
(3,252,225) (2017)
LNG terminal(s) (import): Saint John
river and lake port(s): Montreal, Quebec City, Sept-Isles
(St. Lawrence)
dry bulk cargo port(s): Port-Cartier (iron ore and grain),
Fraser River Port (Fraser) Hamilton (Lake Ontario)','ee297bfb60adf71c4ce0fbe417a806a41d9abed9d893bd4386f912c8596a95be','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71ca6e01274ba18ed8f290cbdabfd62820538dd9b0f3cbb78a7ff6f350c6c3ad',2020,'KY','Cayman Islands','military-and-security',305,'Military and security forces: NO regular military forces; Royal
Cayman Islands Police Service (2019) Military—note: defense
is the responsibility of the UK','e428b99d77e36212ce27329c19252e7cb2b7b157264f1b04e83fc4d10bcc2895','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdc18b4f4124e03d4fa38f1f99d1ce389dc22672b27fc24d9338d47daf17c153',2020,'CG','Congo','military-and-security',314,'Military expenditures:
1.41% of GDP (2018)
1.44% of GDP (2017)
1.53% of GDP (2016)
1.69% of GDP (2015)
2.56% of GDP (2014)
country comparison to the world: 82
Military and security forces: Central African Armed Forces
(Forces Armees Centrafricaines, FACA): Ground Forces
(includes Military Air Service), General Directorate of
Gendarmerie Inspection (DGIG), National Police (2019)
Military service age and obligation: 18 years of age for
military service; no conscription (2019)
Military—note: the United Nations Multidimensional
Integrated Stabilization Mission in the Central African
Republic (MINUSCA) has operated in the country since
2014; its peacekeeping mission includes providing security,
protecting civilians, facilitating humanitarian assistance,
disarming and demobilizing armed groups, and supporting
the country’s fragile transitional government; as _ of
September 2019, MINUSCA had nearly 14,000 total
personnel, including about 10,800 troops; in November
2019, the UN Security Council extended the mandate of the
MINUSCA peacekeeping mission another year (2019)
Military expenditures:
1.23% of GDP (2018)
1.28% of GDP (2017)
1.28% of GDP (2016)
1.25% of GDP (2015)
1.13% of GDP (2014)
country comparison to the world: 102
Military and security forces: Rwanda Defense Force (RDF):
Rwanda Army (Rwanda Land Force), Rwanda Air Force
(Force Aerienne Rwandaise, FAR), Rwanda Reserve Force
(2019) Military service age and obligation: 18 years of age for
voluntary military service; no conscription; Rwandan
citizenship is required, as is a Q9th-grade education for
enlisted recruits and an A-level certificate for officer
candidates; enlistment is either as contract (5-years,
renewable twice) or career; retirement (for officers and
senior NCOs) after 20 years of service or at 40-60 years of
age (2013) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 9 (2015)
annual passenger traffic on registered air carriers: 645,815
(2015)
annual freight traffic on registered air carriers: 21,382,897
mt-km (2015)
Civil aircraft registration country code prefix: 9XR (2016)
Airports: 7 (2013)
country comparison to the world: 171
Airports—with paved runways:
total: 4 (2019)
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m:1
Airports—with unpaved runways:
total: 3 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 1 (2013)
Roadways: total: 4,700 km (2012)
paved: 1,207 km (2012)
unpaved: 3,493 km (2012)
country comparison to the world: 144
Waterways: (Lac Kivu navigable by shallow-draft barges and
native craft) (2011) Ports and terminals: Jake port(s):
Cyangugu, Gisenyi, Kibuye (Lake Kivu) TRANSNATIONAL
ISSUES
Disputes—International: Burundi and Rwanda dispute two sq
km (0.8 sq mi) of Sabanerwa, a farmed area in the Rukurazi
Valley where the Akanyaru/Kanyaru River shifted its course
southward after heavy rains in 1965; fighting among ethnic
groups—loosely associated political rebels, armed gangs,
and various government forces in Great Lakes region
transcending the boundaries of Burundi, Democratic
Republic of the Congo (DROC), Rwanda, and Uganda—
abated substantially from a decade ago due largely to UN
peacekeeping, international mediation, and efforts by local
governments to create civil societies; nonetheless, 57,000
Rwandan refugees still reside in 21 African states,
including Zambia, Gabon, and 20,000 who fled to Burundi
in 2005 and 2006 to escape drought and recriminations
from traditional courts investigating the 1994 massacres;
the 2005 DROC and Rwanda border verification mechanism
to stem rebel actions on both sides of the border remains in
place Refugees and _ internally displaced persons: refugees
(country of origin): 76,266 (Democratic Republic of the
Congo), 73,327 (Burundi) (2019)
SAINT BARTHELEMY
Vitet &
G See Morne
USTAVIA, "St
Le Pain
de Sucre
lle Saint-
Barthélemy le Coco','9a50566095481ade5f88be5d57506b4477ba0c1e7e3a8006d43d6b4204ef1108','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4484c0c081c1a6da94127eedfdcdb95f410741f62f7c159dd8a701804ae0f581',2020,'TD','Chad','military-and-security',323,'Military expenditures:
2.13% of GDP (2018)
2.24% of GDP (2017)
1.79% of GDP (2016)
2.03% of GDP (2015)
2.82% of GDP (2014)
country comparison to the world: 45
Military and security forces: Chadian National Army (Armee
Nationale du Tchad, ANT): Ground Forces (l’Armee de
Terre, AdT), Chadian Air Force (l’Armee de _ |’Air
Tchadienne, AAT), National Gendarmerie, National
Nomadic Guard of Chad (GNNT); General Direction of the
Security Services of State Institutions (Direction Generale
des Services de Securite des Institutions de l’Etat, GDSSIE)
(2019) note: the GDSSIE, formerly known as _ the
Republican Guard, is the presidential guard force and
considered an elite military unit Military service age and
obligation: 20 is the legal minimum age for compulsory
military service, with a 3-year service obligation; 18 is the
legal minimum age for voluntary service; no minimum age
restriction for volunteers with consent from a parent or
guardian; women are subject to 1 year of compulsory
military or civic service at age 21; while provisions for
military service have not been repealed, they have never
been fully implemented (2015) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 1
(2015)
annual passenger traffic on registered air carriers: 28,332
(2015)
annual freight traffic on registered air carriers: mt-km
(2015)
Airports: 59 (2013)
country comparison to the world: 81
Airports—with paved runways:
total: 9 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 4 (2017)
1,524 to 2,437 m: 2 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 50 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 2 (2013)
1,524 to 2,437 m: 14 (2013)
914 to 1,523 m: 22 (2013)
under 914 m: 11 (2013)
Pipelines: 582 km oil (2013)
Roadways: total: 40,000 km (2018)
note: consists of 25,000 km of national and regional roads
and 15,000 km of local roads; 206 km of urban roads are
paved country comparison to the world: 88
Waterways: (Chari and Legone Rivers are navigable only in
wet season) (2012)','79285700d1c51588054afb257f24ca4705c9c6bbfaa7bb1d12ff9c3404a4671b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20ab5ebeb7ac7815702565417d434ba25dfe6715c7ad3a63a88c66c67e1640f4',2020,'CN','China','military-and-security',340,'Military expenditures:
1.87% of GDP (2018)
1.9% of GDP (2017)
1.93% of GDP (2016)
1.95% of GDP (2015)
1.9% of GDP (2014)
country comparison to the world: 60
Military and security forces: People’s Liberation Army (PLA):
Ground Forces, Navy (PLAN, includes marines and naval
aviation), Air Force (PLAAF, includes airborne forces),
Rocket Force (strategic missile force), and Strategic
Support Force (space and cyber forces); People’s Armed
Police (PAP, includes Coast Guard, Border Defense Force,
Internal Security Forces); PLA Reserve Force (2019)
Military service age and obligation: 18-22 years of age for
selective compulsory military service, with a 2-year service
obligation; no minimum age for voluntary service (all
officers are volunteers); 18-19 years of age for women high
school graduates who meet requirements for specific
military jobs (2018) TRANSPORTATION
National air transport system:
number of registered air carriers: 56 (2015)
inventory of registered aircraft operated by air carriers:
2,890 (2015)
annual passenger traffic on registered air Carriers:
436,183,969 (2015)
annual freight traffic on registered air carriers: 19.806
billion mt-km (2015)
Civil aircraft registration country code prefix: B (2016)
Airports: 507 (2013)
country comparison to the world: 13
Airports—with paved runways:
total: 510 (2019)
over 3,047 m: 87
2,438 to 3,047 m: 187
1,524 to 2,437 m: 109
914 to 1,523 m: 43
under 914 m: 84
Airports—with unpaved runways:
total: 23 (2019)
over 3,047 m: 2
2,438 to 3,047 m: 0
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 13
Heliports: 39 (2019)
Pipelines: 76000 km gas, 30400 km crude oil, 27700 km
refined petroleum products, 797000 km water (2018)
Railways: total: 131,000 km 1.435-m gauge (80,000 km
electrified); 102,000 traditional, 29,000 high-speed (2018)
country comparison to the world: 2
Roadways: total: 4,960,600 km (2017)
paved: 4,338,600 km (includes 136,500 km of expressways)
(2017)
unpaved: 622,000 km (2017)
country comparison to the world: 2
Waterways: 110,000 km (navigable waterways) (2011)
country comparison to the world: 1
Merchant marine: total: 4,610
by type: bulk carrier 1114, container ship 242, general
cargo 741, oil tanker 503, other 2010 (2018) country
comparison to the world: 4
Ports and terminals: Major seaport(s): Dalian, Ningbo,
Qingdao, Qinhuangdao, Shanghai, Shenzhen, Tianjin
container port(s) (TEUs): Dalian (9,707,000), Guangzhou
(18,858,000), Ningbo (24,607,000), Qingdao (18,262,000),
Shanghai (40,233,000), Shenzhen (25,208,000), Tianjin
(15,040,000) (2017) LNG terminal(s) (import): Fujian,
Guangdong, Jiangsu, Shandong, Shanghai, Tangshan,
Zhejiang river port(s): Guangzhou (Pearl)
Transportation—note: seven of the world’s ten _ largest
container ports are in China
Military—note: defense is the responsibility of Australia
Military—note: defense is the responsibility of France
Military and security forces: NO regular indigenous military
forces; Hong Kong Police Force; Hong Kong garrison of
China’s People’s Liberation Army (PLA) includes elements
of the PLA Army, PLA Navy, and PLA Air Force; these forces
are under the direct leadership of the Central Military
Commission in Beijing and under administrative control of
the adjacent Southern Theater Command (2019) Military—
note: defense is the responsibility of China
Military expenditures:
1.21% of GDP (2019 est.)
1.15% of GDP (2018)
1.05% of GDP (2017)
1.02% of GDP (2016)
0.92% of GDP (2015)
country comparison to the world: 105
Military and security forces: Hungarian Defense Forces: Ground
Forces and Hungarian Air Force (2019) note: the
Hungarian Defense Forces are organized into a joint force
structure with ground, air, and logistic components Military
service age and obligation: 18-25 years of age for voluntary
military service; no _ conscription; 6-month — service
obligation (2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 5 (2015)
inventory of registered aircraft operated by air carriers: 75
(2015)
annual passenger traffic on registered air Carriers:
20,042,185 (2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: HA (2016)
Airports: 41 (2013)
country comparison to the world: 103
Airports—with paved runways:
total: 20 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 6 (2017)
1,524 to 2,437 m: 6 (2017)
914 to 1,523 m: 5 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 21 (2013)
1,524 to 2,437 m: 2 (2013)
914 to 1,523 m: 8 (2013)
under 914 m: 11 (2013)
Heliports: 3 (2013)
Pipelines: 5874 km gas (high-pressure transmission system),
83732 km gas (low-pressure distribution network), 850 km
oil, 1200 km refined products (2016) Railways: total: 8,049
km (2014)
standard gauge: 7,794 km 1.435-m gauge (2,889 km
electrified) (2014)
narrow gauge: 219 km 0.760-m gauge (2014)
broad gauge: 36 km 1.524-m gauge (2014)
country comparison to the world: 28
Roadways: total: 203,601 km (2014)
paved: 77,087 km (includes 1,582 km of expressways)
(2014)
unpaved: 126,514 km (2014)
country comparison to the world: 27
Waterways: 1,622 km (most on Danube River) (2011)
country comparison to the world: 47
Ports and terminals: river port(s): Baja, Csepel (Budapest),
Dunaujvaros, Gyor-Gonyu, Mohacs (Danube)
Military expenditures:
0.3% of GDP (2018)
0.3% of GDP (2017)
0.3% of GDP (2016)
0.3% of GDP (2015)
0.5% of GDP (2014)
country comparison to the world: 154
Military and security forces: NO regular military forces; Icelandic
Coast Guard; Icelandic National Police (2019) Military—note:
Iceland is the only NATO member that has no standing
military force; defense of Iceland remains a NATO
commitment and NATO maintains an air policing presence
in Icelandic airspace; Iceland participates in international
peacekeeping missions with the civilian-manned Icelandic
Crisis Response Unit (ICRU) (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 5 (2015)
inventory of registered aircraft operated by air carriers: 43
(2015)
annual passenger traffic on registered air Carriers:
3,413,950 (2015)
annual freight traffic on _ registered air _ Carriers:
102,356,809 mt-km (2015)
Civil aircraft registration country code prefix: [TF (2016)
Airports: 96 (2013)
country comparison to the world: 59
Airports—with paved runways:
total: 7 (2017)
over 3,047 m: 1 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 3 (2017)
Airports—with unpaved runways:
total: 89 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 26 (2013)
under 914 m: 60 (2013)
Roadways: total: 12,898 km (2012)
paved/oiled gravel: 5,647 km (excludes urban roads) (2012)
unpaved: 7,251 km (2012)
country comparison to the world: 126
Merchant marine: total: 33
by type: general cargo 5, oil tanker 1, other 27 (2018)
country comparison to the world: 122
Ports and terminals: major seaport(s): Grundartangi,
Hafnarfjordur, Reykjavik TRANSNATIONAL ISSUES
Disputes—International: Iceland, the UK, and Ireland dispute
Denmark’s claim that the Faroe Islands’ continental shelf
extends beyond 200 nm; the European Free ‘Trade
Association Surveillance Authority filed a suit against
Iceland, claiming the country violated the Agreement on
the European Economic Area in failing to pay minimum
compensation to Icesave depositors Refugees and internally
displaced persons: Stateless persons: 69 (2018) INDIA
‘*< Kandla Bhopal
°
Ahmadabad
Nagpur Mae My BURMA
*Vishakhapatnam
; yPanaji Bay of
Marmagao
Bangalore | i ANDAMAN
Galore Chennai Narain
Kozhikode — ¢ Puducherry Port Blair?
. Madurai
Kochi¢ ¢«
A. gy SAI
Tuticorin’ LANKA FSLANDS *¢
Military expenditures:
2.04% of GDP (2019)
2.42% of GDP (2018)
2.51% of GDP (2017)
2.51% of GDP (2016)
2.41% of GDP (2015)
country comparison to the world: 48
Military and security forces: Indian Armed Forces: Army, Navy
(includes marines), Air Force, Coast Guard; Defense
Security Corps (paramilitary forces); Ministry of Home
Affairs paramilitary forces: Central Armed Police Force
(includes Assam Rifles, Border Security Force, Central
Industrial Security Force, Central Reserve Police Force,
Indo-Tibetan Border Police, National Security Guards,
Sashastra Seema Bal) (2019) Military service age and obligation:
16-18 years of age for voluntary military service (Army 17
1/2, Air Force 17, Navy 16 1/2); no conscription; women
may join as officers, currently serve in combat roles as
pilots, and under consideration for Army combat roles
(2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
20 (2015) inventory of registered aircraft operated by air
carriers: 485 (2015)
annual passenger traffic on registered air Carriers:
98,927,860 (2015)
annual freight traffic on _ registered air _ carriers:
1,833,847,614 mt-km (2015)
Civil aircraft registration country code prefix: VI (2016)
Airports: 346 (2013)
country comparison to the world: 21
Airports—with paved runways:
total: 253 (2017)
over 3,047 m: 22 (2017)
2,438 to 3,047 m: 59 (2017)
1,524 to 2,437 m: 76 (2017)
914 to 1,523 m: 82 (2017)
under 914 m: 14 (2017)
Airports—with unpaved runways:
total: 93 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 3 (2013)
1,524 to 2,437 m: 6 (2013)
914 to 1,523 m: 38 (2013)
under 914 m: 45 (2013)
Heliports: 45 (2013)
Pipelines: 9 km condensate/gas, 13581 km gas, 2054 km
liquid petroleum gas, 8943 km oil, 20 km oil/gas/water,
11069 km refined products (2013) Railways: total: 68,525 km
(2014)
narrow gauge: 9,499 km 1.000-m gauge (2014)
broad gauge: 58,404 km 1.676-m gauge (23,654 electrified)
(2014)
622 0.762-m gauge
country comparison to the world: 5
Roadways: total: 4,699,024 km (2015)
note: includes 96,214 km of national highways and
expressways, 147,800 km of state highways, and 4,455,010
km of other roads country comparison to the world: 3
Waterways: 14,500 km (5,200 km on major rivers and 485 km
on canals suitable for mechanized vessels) (2012) country
comparison to the world: 9
Merchant marine: total: 1,719
by type: bulk carrier 75, container ship 22, general cargo
982, oil tanker 133, other 907 (2018) country comparison
to the world: 14
Ports and terminals: Major seaport(s): Chennai, Jawaharal
Nehru Port, Kandla, Kolkata (Calcutta), Mumbai (Bombay),
Sikka, Vishakhapatnam container port(s) (TEUs): Chennai
(1,549,457), Jawaharal Nehru Port (4,833,397), Mundra
(4,240,260) (2017) LNG terminal(s) (import): Dabhol,
Dahej, Hazira
Military expenditures:
0.72% of GDP (2018)
0.84% of GDP (2017)
0.88% of GDP (2016)
0.89% of GDP (2015)
0.78% of GDP (2014)
country comparison to the world: 136
Military and security forces: Indonesian National Armed Forces
(Tentara Nasional Indonesia, TNI): Army (TNI-Angkatan
Darat (TNI-AD)), Navy (TNI-Angkatan Laut (TNI-AL),
includes marines (Korps Marinir, KorMar), naval air arm),
Air Force (TNI-Angkatan Udara (TNI-AU)), National Air
Defense Command (Komando Pertahanan Udara Nasional
(Kohanudnas)), Armed Forces’ Special Operations
Command (Koopssus), Strategic Reserve Command
(Kostrad) (2019) note: the Indonesian National Police
includes a paramilitary Mobile Brigade Corps (BRIMOB)
Military service age and obligation: 18-45 years of age for
voluntary military service, with selective conscription
authorized; 2-year service obligation, with reserve
obligation to age 45 (officers); Indonesian citizens only
(2013) Maritime threats: The International Maritime Bureau
continues to report the territorial and offshore waters in
the Strait of Malacca and South China Sea as high risk for
piracy and armed robbery against ships; attacks declined
for the third year in a row from 43 incidents in 2016 to 36
in 2018 due to aggressive maritime patrolling by regional
authorities; in 2018, 29 commercial vessels were boarded
and three crew members were taken hostage; hijacked
vessels are often disguised and cargo diverted to ports in
East Asia (2018) TRANSPORTATION
National air transport system:
number of registered air carriers: 29 (2015)
inventory of registered aircraft operated by air carriers:
950 (2015)
annual passenger traffic on registered air Carriers:
88,685,767 (2015)
annual freight traffic on _ registered air _ carriers:
747,473,207 mt-km (2015)
Civil aircraft registration country code prefix: PK (2016)
Airports: 673 (2013)
country comparison to the world: 10
Airports—with paved runways:
total: 186 (2017)
over 3,047 m: 5 (2017)
2,438 to 3,047 m: 21 (2017)
1,524 to 2,437 m: 51 (2017)
914 to 1,523 m: 72 (2017)
under 914 m: 37 (2017)
Airports—with unpaved runways:
total: 487 (2013)
1,524 to 2,437 m: 4 (2013)
914 to 1,523 m: 23 (2013)
under 914 m: 460 (2013)
Heliports: 76 (2013)
Pipelines: 1064 km condensate, 150 km condensate/gas,
11702 km gas, 119 km liquid petroleum gas, 7767 km oil,
77 km oil/gas/water, 728 km refined products, 53 km
unknown, 44 km water (2013) Railways: total: 8,159 km
(2014)
narrow gauge: 8,159 km 1.067-m gauge (565 km
electrified) (2014)
note: 4,816 km operational
country comparison to the world: 27
Roadways: total: 496,607 km (2011)
paved: 283,102 km (2011)
unpaved: 213,505 km (2011)
country comparison to the world: 14
Waterways: 21,579 km (2011)
country comparison to the world: 7
Merchant marine: total: 9,053
by type: bulk carrier 97, container ship 205, general cargo
2203, oil tanker 567, other 5981 (2018) country
comparison to the world: 1
Ports and terminals: Major seaport(s): Banjarmasin, Belawan,
Kotabaru, Krueg Geukueh, Palembang, Panjang, Sungai
Pakning, Tanjung Perak, Tanjung Priok container port(s)
(TEUs): Tanjung Perak (3,553,370), Tanjung Priok
(6,090,000) (2017)
LNG terminal(s) (export): Bontang, Tangguh
LNG terminal(s) (import): Arun, Lampung, West Java
Military expenditures:
2.67% of GDP (2018 est.)
3.11% of GDP (2017 est.)
2.97% of GDP (2016 est.)
2.76% of GDP (2015 est.)
2.28% of GDP (2014 est.)
(Estimates)
country comparison to the world: 30
Military and security forces: Islamic Republic of Iran Regular
Forces (Artesh): Ground Forces, Navy (includes marines),
Air Force, Air Defense Forces; Islamic Revolutionary Guard
Corps (Sepah, IRGC): Ground Forces, Navy (includes
marines), Aerospace Force (controls strategic missile
force), Qods Force (special operations), Cyber Command,
Basij Paramilitary Forces (Popular Mobilization Army); Law
Enforcement Forces (border and security troops, assigned
to the armed forces in wartime) (2019) Military service age and
obligation: 18 years of age for compulsory military service;
16 years of age for volunteers; 17 years of age for Law
Enforcement Forces; 15 years of age for Basij Forces
(Popular Mobilization Army); conscript military service
obligation is 18-24 months; women exempt from military
service (2019) Maritime threats: the Maritime Administration
of the US Department of Transportation has issued a
Maritime Advisory (2019-012-Persian Gulf, Strait of
Hormuz, Gulf of Oman, Arabian Sea, Red Sea-Threats to US
and International Shipping from Iran) effective 7 August
2019, which states in part that “heightened military
activities and increased political tensions in this region
continue to present risk to commercial shipping...there is a
continued possibility that Iran and/or its regional proxies
could take actions against US and partner interests in the
region;” at present, Iran has seized two foreign-flagged
tankers in the Persian Gulf; the US and UK navies have
established Operation Sentinel to provide escorts for
commercial shipping transiting the Persian Gulf, Strait of
Hormuz, and Gulf of Oman TRANSPORTATION
National air transport system:
number of registered air carriers: 15 (2015)
inventory of registered aircraft operated by air carriers:
228 (2015)
annual passenger traffic on registered air Carriers:
15,003,958 (2015)
annual freight traffic on registered air carriers:
107,184,869 mt-km (2015)
Civil aircraft registration country code prefix: EP (2016)
Airports: 319 (2013)
country comparison to the world: 22
Airports—with paved runways:
total: 140 (2019)
over 3,047 m: 42
2,438 to 3,047 m: 29
1,524 to 2,437 m: 26
914 to 1,523 m: 36
under 914 m:7
Airports—with unpaved runways:
total: 179 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 2 (2013)
1,524 to 2,437 m: 9 (2013)
914 to 1,523 m: 135 (2013)
under 914 m: 32 (2013)
Heliports: 26 (2013)
Pipelines: 7 km condensate, 973 km condensate/gas, 20794
km gas, 570 km liquid petroleum gas, 8625 km oil, 7937 km
refined products (2013) Railways: total: 8,484 km (2014)
standard gauge: 8,389.5 km 1.435-m gauge (189.5 km
electrified) (2014)
broad gauge: 94 km 1.676-m gauge (2014)
country comparison to the world: 25
Roadways: total: 223,485 km (2018)
paved: 195,485 km (2018)
unpaved: 28,000 km (2018)
country comparison to the world: 23
Waterways: 850 km (on Karun River; some navigation on
Lake Urmia) (2012)
country comparison to the world: 69
Merchant marine: total: 720
by type: bulk carrier 31, container ship 25, general cargo
336, oil tanker 17, other 311 (2018) country comparison to
the world: 30
Ports and terminals: Major seaport(s): Bandar-e Asaluyeh,
Bandar Abbas, Bandar Emam container port(s) (TEUs):
Bandar Abbas (2,607,000) (2017)
Military expenditures:
3.85% of GDP (2019)
2.73% of GDP (2018)
3.84% of GDP (2017)
3.63% of GDP (2016)
9.35% of GDP (2015)
country comparison to the world: 14
Military and security forces: Ministry of Defense: Iraqi Army,
Army Aviation Command, Iraqi Navy, Iraqi Air Force, Iraqi
Air Defense Command, Special Forces Command; National-
Level Security Forces: Iraqi Counterterrorism Service,
Prime Minister’s Special Forces Division, Presidential
Brigades; Ministry of Interior: Federal Police Forces
Command, Border Guard Forces Command, Federal
Intelligence and _ MInvestigations Agency, Emergency
Response Division, Facilities Protection Directorate, and
Energy Police Directorate; Popular Mobilization
Commission and Affiliated Forces; Peshmerga Ministry
(Kurdistan Regional Government) (2019) Military service age
and obligation: 18-40 years of age for voluntary military
service; no conscription (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 4 (2015)
inventory of registered aircraft operated by air carriers: 39
(2015)
annual passenger traffic on registered air carriers: 484,803
(2015)
annual freight traffic on registered air carriers: 10,758,230
mt-km (2015)
Civil aircraft registration country code prefix: YI (2016)
Airports: 102 (2013)
country comparison to the world: 55
Airports—with paved runways:
total: 72 (2017)
over 3,047 m: 20 (2017)
2,438 to 3,047 m: 34 (2017)
1,524 to 2,437 m: 4 (2017)
914 to 1,523 m: 7 (2017)
under 914 m: 7 (2017)
Airports—with unpaved runways:
total: 30 (2013)
over 3,047 m: 3 (2013)
2,438 to 3,047 m: 5 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 13 (2013)
under 914 m: 6 (2013)
Heliports: 16 (2013)
Pipelines: 2455 km gas, 913 km liquid petroleum gas, 5432
km oil, 1637 km refined products (2013) Railways: total:
2,272 km (2014)
standard gauge: 2,272 km 1.435-m gauge (2014)
country comparison to the world: 69
Roadways: total: 59,623 km (2012)
paved: 59,623 km (includes Kurdistan region) (2012)
country comparison to the world: 76
Waterways: 5,279 km (the Euphrates River (2,815 km), Tigris
River (1,899 km), and Third River (565 km) are the
principal waterways) (2012)
country comparison to the world: 22
Merchant marine: total: 80
by type: general cargo 1, oil tanker 6, other 73 (2018)
country comparison to the world: 98
Ports and terminals: river port(s): Al Basrah (Shatt al Arab);
Khawr az Zubayr, Umm Qasr (Khawr az Zubayr waterway)
Military and security forces: NO regular indigenous military
forces
Military—note: defense is the responsibility of China and the
Chinese People’s Liberation Army (PLA) maintains a
garrison in Macau TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (registered in China)
(2015)
inventory of registered aircraft operated by air carriers: 17
(registered in China) (2015) annual passenger traffic on
registered air Carriers: 2,276,436 (2015)
annual freight traffic on registered air carriers: 25.435
million mt-km (2015)
Civil aircraft registration country code prefix: B-M (2016)
Airports: 1 (2013)
country comparison to the world: 227
Airports—with paved runways: total: 1 (2019)
over 3,047 m: 1
Heliports: 2 (2013)
Roadways: total: 428 km (2017)
paved: 428 km (2017)
country comparison to the world: 193
Merchant marine: total: 1
by type: other 1 (2018)
country comparison to the world: 173
Ports and terminals: Major seaport(s): Macau','8f251e7da7c9a745b9df94a24a547f85993185f0985c051d43e012aaffb571ee','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc30681f8ed5024724eeaa20a39b333fd2e019a255f70072d29a97927d7b29fd',2020,'CC','Cocos (Keeling) Islands','military-and-security',352,'Military—note: defense is the responsibility of Australia; the
territory has a five-person police force TRANSPORTATION
Airports: 1 (2013)
country comparison to the world: 218
Airports—with paved runways:
total: 1 (2019)
2,438 to 3,047 m: 1
Roadways: total: 22 km (2007)
paved: 10 km (2007)
unpaved: 12 km (2007)
country comparison to the world: 213
Ports and terminals: Major seaport(s): Port Refuge','9ceceaaf3374fb63950c2412a320ff710e8105d3840c8333ca4ac8b639cb96aa','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acabcf530c7762c8bdbbbbd746c1bbfd56e28e07da767fda59777a16a732665f',2020,'AO','Angola','military-and-security',363,'Military expenditures:
0.67% of GDP (2018)
0.74% of GDP (2017)
1.34% of GDP (2016)
1.36% of GDP (2015)
1% of GDP (2014)
country comparison to the world: 139
Military and security forces: Armed Forces of the Democratic
Republic of the Congo (Forces d’Armees de la Republique
Democratique du Congo, FARDC): Land Forces, National
Navy (La Marine Nationale), Congolese Air Force (Force
Aerienne Congolaise, FAC); Republican Guard (responsible
for presidential security) (2019) Military service age and
obligation: 18-45 years of age for voluntary and compulsory
military service (2012) Military—note: MONUSCO, the United
Nations peacekeeping and _ stabilization force in the
Democratic Republic of Congo, has operated in the central
and eastern parts of the country since 1999; as of
November 2019, MONUSCO comprised around 20,000
personnel, including more than 15,000 military troops; in
December 2019, the UN extended MONUSCO’s s mandate
until 20 December 2020 (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
8 (2015)
inventory of registered aircraft operated by air carriers: 13
(2015)
annual passenger traffic on registered air carriers: 476,352
(2015)
annual freight traffic on registered air carriers: 85,839 mt-
km (2015)
Civil aircraft registration country code prefix: 9Q (2016)
Airports: 198 (2013)
country comparison to the world: 27
Airports-with paved runways:
total: 26 (2017)
over 3,047 m: 3 (2017)
2,438 to 3,047 m: 3 (2017)
1,524 to 2,437 m: 17 (2017)
914 to 1,523 m: 2 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 172 (2013)
1,524 to 2,437 m: 20 (2013)
914 to 1,523 m: 87 (2013)
under 914 m: 65 (2013)
Heliports: 1 (2013)
Pipelines: 62 km gas, 77 km oil, 756 km refined products
(2013)
Railways: total: 4,007 km (2014)
narrow gauge: 3,882 km 1.067-m gauge (858 km
electrified) (2014)
125 1.000-m gauge
country comparison to the world: 48
Roadways: total: 152,373 km (2015)
paved: 3,047 km (2015)
unpaved: 149,326 km (2015)
urban: 7,400 km (2015)
non-urban: 144,973 km
country comparison to the world: 34
Waterways: 15,000 km (including the Congo River, its
tributaries, and unconnected lakes) (2011) country
comparison to the world: 8
Merchant marine: total: 27
by type: general cargo 12, oil tanker 1, other 14 (2018)
country comparison to the world: 131
Ports and terminals: Major seaport(s): Banana
river or lake port(s): Boma, Bumba, Kinshasa, Kisangani,
Matadi, Mbandaka (Congo) Kindu (Lualaba) Bukavu, Goma
(Lake Kivu) Kalemie (Lake Tanganyika)
Military expenditures:
3.35% of GDP (2018)
3.56% of GDP (2017)
3.89% of GDP (2016)
4.48% of GDP (2015)
4.2% of GDP (2014)
country comparison to the world: 20
Military and security forces: Namibian Defense Force (NDF):
Army, Navy, Air Force; Namibian Police Force: Special Field
Force (paramilitary unit responsible for protecting borders
and government installations) (2019) Military service age and
obligation: 18-25 years of age for voluntary military service;
no conscription (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 12
(2015)
annual passenger traffic on registered air Carriers: 553,322
(2015)
annual freight traffic on registered air carriers: 30,302,405
mt-km (2015)
Civil aircraft registration country code prefix: V5 (2016)
Airports: 112 (2013)
country comparison to the world: 52
Airports—with paved runways:
total: 19 (2017)
over 3,047 m: 4 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 12 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 93 (2013)
1,524 to 2,437 m: 25 (2013)
914 to 1,523 m: 52 (2013)
under 914 m: 16 (2013)
Railways: total: 2,628 km (2014)
narrow gauge: 2,628 km 1.067-m gauge (2014)
country comparison to the world: 65
Roadways: total: 48,875 km (2018)
paved: 7,893 km (2018)
unpaved: 40,982 km (2018)
country comparison to the world: 82
Merchant marine: total: 10
by type: general cargo 1, other 9 (2018)
country comparison to the world: 150
Ports and terminals: Major seaport(s): Luderitz, Walvis Bay','132c4c817822d9658db090398375bbff77e41148be86e9bc8ce7bf9b373045a6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5e2b9b00115b445c24520628951e3009e3f43247ef699a4ed7824557bb133a9',2020,'NI','Nicaragua','military-and-security',376,'Military and security forces: no regular military forces; Ministry
of Public Security commands the Public Forces of Costa
Rica, which includes the Public Force (National Police),
Anti-Drug Police, and National Coast Guard Service (2019)
note: Costa Rica’s armed forces were constitutionally
abolished in 1949
Military expenditures:
1.71% of GDP (2018)
1.74% of GDP (2017)
1.68% of GDP (2016)
1.68% of GDP (2015)
4.62% of GDP (2014)
country comparison to the world: 67
Military and security forces: Honduran Armed Forces (Fuerzas
Armadas de Honduras, FFAA): Army, Honduran Naval
Force (FNH; includes marines), Honduran Air Force
(Fuerza Aerea Hondurena, FAH), Honduran Public Order
Military Police (PMOP); Ministry of Public Security and
Defense: Public Security Forces (includes paramilitary
units) (2019) Military service age and obligation: 18 years of age
for voluntary 2- to 3-year military service; no conscription
(2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 5 (2015)
inventory of registered aircraft operated by air carriers: 10
(2015)
annual passenger traffic on registered air Carriers: 251,149
(2015)
annual freight traffic on registered air carriers: 502,372
mt-km (2015)
Civil aircraft registration country code prefix: HR (2016)
Airports: 103 (2013)
country comparison to the world: 54
Airports—with paved runways:
total: 13 (2017)
2,438 to 3,047 m: 3 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 4 (2017)
under 914 m: 3 (2017)
Airports—with unpaved runways:
total: 90 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 16 (2013)
under 914 m: 73 (2013)
Railways: total: 699 km (2014)
narrow gauge: 164 km 1.067-m gauge (2014)
115 km 1.057-m gauge
420 km 0.914-m gauge
country comparison to the world: 101
Roadways: total: 14,742 km (2012)
paved: 3,367 km (2012)
unpaved: 11,375 km (1,543 km summer only) (2012)
note: an additional 8,951 km of non-official roads used by
the coffee industry
country comparison to the world: 123
Waterways: 465 km (most navigable only by small craft)
(2012)
country comparison to the world: 84
Merchant marine: total: 550
by type: container ship 1, general cargo 249, oil tanker 89,
other 211 (2018)
country comparison to the world: 40
Ports and terminals: INajor seaport(s): La Ceiba, Puerto Cortes,
San Lorenzo, Tela TRANSNATIONAL ISSUES
Disputes—International: International Court of Justice (ICJ)
ruled on the delimitation of “bolsones” (disputed areas)
along the El Salvador- Honduras border in 1992 with final
settlement by the parties in 2006 after an Organization of
American States survey and a further ICJ ruling in 2003;
the 1992 ICJ ruling advised a tripartite resolution to a
maritime boundary in the Gulf of Fonseca with
consideration of Honduran access to the Pacific; El
Salvador continues to claim tiny Conejo Island, not
mentioned in the ICJ ruling, off Honduras in the Gulf of
Fonseca; Honduras claims the _ Belizean-administered
Sapodilla Cays off the coast of Belize in its constitution, but
agreed to a joint ecological park around the cays should
Guatemala consent to a maritime corridor in the Caribbean
under the OAS-sponsored 2002 Belize-Guatemala
Differendum Refugees and internally displaced persons: IDPs:
190,000 (violence, extortion, threats, forced recruitment by
urban gangs) (2016) Illicit drugs: transshipment point for
drugs and narcotics; illicit producer of cannabis, cultivated
on small plots and used principally for local consumption;
corruption is a major problem; some money-laundering
activity HONG KONG
nd Sheung
Shui
>
Tai Po
New Territories
Tai N ,','bbebc6f188e9596fab106e5ca2aab6a79cce4958136d3a6bc3d38b1a2cf82bdb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ba008aa84cec8e667ca893b8e66f14b59ae37a9e2f5f5a2296d6528bc736908',2020,'BF','Burkina Faso','military-and-security',383,'Military expenditures:
1.36% of GDP (2018)
1.28% of GDP (2017)
1.69% of GDP (2016)
1.74% of GDP (2015)
1.48% of GDP (2014)
country comparison to the world: 87
Military and security forces: Armed Forces of Cote d’Ivoire
(Forces Armees de Cote d''Ivoire, FACI): Army (Armee de
Terre), Navy (Marine Nationale), Cote Air Force (Force
Aerienne Cote), Special Forces (Forces Speciale) (2019)
Military service age and obligation: 18-25 years of age for
compulsory and voluntary male and female military service;
conscription is not enforced; voluntary recruitment of
former rebels into the new national army is restricted to
ages 22-29 (2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 10
(2015)
annual passenger traffic on registered air carriers: 359,260
(2015)
annual freight traffic on registered air carriers: 4,719,120
mt-km (2015)
Civil aircraft registration country code prefix: [TU (2016)
Airports: 27 (2013)
country comparison to the world: 125
Airports—with paved runways:
total: 7 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 4 (2017)
Airports—with unpaved runways:
total: 20 (2013)
1,524 to 2,437 m: 6 (2013)
914 to 1,523 m: 11 (2013)
under 914 m: 3 (2013)
Heliports: 1 (2013)
Pipelines: 101 km condensate, 256 km gas, 118 km oil, 5 km
oil/gas/water, 7 km water (2013) Railways: total: 660 km
(2008)
narrow gauge: 660 km 1.000-m gauge (2008)
note: an additional 622 km of this railroad extends into
country comparison to the world: 104
Roadways: total: 81,996 km (2007)
paved: 6,502 km (2007)
unpaved: 75,494 km (2007)
note: includes intercity and urban roads; another 20,000
km of dirt roads are in poor condition and 150,000 km of
dirt roads are impassable country comparison to the world:
61
Waterways: 980 km (navigable rivers, canals, and numerous
coastal lagoons) (2011)
country comparison to the world: 66
Merchant marine: total: 15
by type: oil tanker 2, other 13 (2018)
country comparison to the world: 143
Ports and terminals: ajor seaport(s): Abidjan, San-Pedro
oil terminal(s): Espoir Offshore Terminal','bbf3f4cdbef12b8e0250a704af55a97f7d0f1483309744f4c9ced5591ad88e46','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6385738954aa0fc90f1366448b22c8e0ba8a011314cb772cda53f61a67ae6c74',2020,'HR','Croatia','military-and-security',388,'Military expenditures: 1.68% of GDP (2019 est.)
1.59% of GDP (2018)
1.67% of GDP (2017)
1.62% of GDP (2016)
1.78% of GDP (2015)
country comparison to the world: 69
Military and security forces: Armed Forces of the Republic of
Croatia (Oruzane Snage Republike Hrvatske, OSRH)
consists of five major commands directly subordinate to a
General Staff: Ground Forces (Hrvatska Kopnena Vojska,
HKoV), Naval Forces (Hrvatska Ratna Mornarica, HRM,
includes Coast Guard), Air Force and Air Defense
Command (Hrvatsko Ratno Zrakoplovstvo I Protuzracna
Obrana), Joint Education and Training Command, Logistics
Command; Military Police Force supports each of the three
Croatian military forces (2019) Military service age and
obligation: 18-27 years of age for voluntary military
service; conscription abolished in 2008 (2017)
Military expenditures:
2.87% of GDP (2017)
3.07% of GDP (2016)
3.08% of GDP (2015)
3.54% of GDP (2014)
3.51% of GDP (2013)
country comparison to the world: 27
Military and_ security forces: Revolutionary Armed Forces
(Fuerzas Armadas Revolucionarias, FAR): Revolutionary
Army (Ejercito Revolucionario, ER, includes and Production
and Defense Brigades), Revolutionary Navy (Marina de
Guerra Revolucionaria, MGR, includes Marine Corps),
Revolutionary Air and Air Defense Forces (Defensas Anti-
Aereas y Fuerza Aerea Revolucionaria, DAAFAR);
Paramilitary forces: Youth Labor Army (Ejercito Juvenil del
Trabajo, EJT), Territorial Militia Troops (Milicia de Tropas
de Territoriales, MTT), Civil Defense Force; Ministry of
Interior: Border Guards, State Security (2019) Military
service age and obligation: 17-28 years of age for
compulsory military service; 2-year service obligation for
males, optional for females (2017) Military—note: the collapse
of the Soviet Union deprived the Cuban military of its major
economic and logistic support and had a significant impact
on the state of Cuban equipment; the army remains well
trained and professional in nature; the lack of replacement
parts for its existing equipment has increasingly affected
operational capabilities (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 4 (2015)
inventory of registered aircraft operated by air carriers: 18
(2015)
annual passenger traffic on registered air Carriers:
1,294,458 (2015)
annual freight traffic on registered air carriers: 20,919,645
mt-km (2015)
Civil aircraft registration country code prefix: CU (2016)
Airports: 133 (2017)
country comparison to the world: 42
Airports—with paved runways:
total: 64 (2017)
over 3,047 m: 7 (2017)
2,438 to 3,047 m: 10 (2017)
1,524 to 2,437 m: 16 (2017)
914 to 1,523 m: 4 (2017)
under 914 m: 27 (2017)
Airports—with unpaved runways:
total: 69 (2013)
914 to 1,523 m: 11 (2013)
under 914 m: 58 (2013)
Pipelines: 41 km gas, 230 km oil (2013)
Railways: total: 8,367 km (2017)
standard gauge: 8,195 km 1.435-m gauge (124 km
electrified) (2017)
narrow gauge: 172 km 1.000-m gauge (2017)
note: 82 km of standard gauge track is not for public use
country comparison to the world: 26
Roadways: total: 60,000 km (2015)
paved: 20,000 km (2001)
unpaved: 40,000 km (2001)
country comparison to the world: 75
Waterways: 240 km (almost all navigable inland waterways
are near the mouths of rivers) (2011) country comparison
to the world: 94
Merchant marine: total: 41
by type: general cargo 11, oil tanker 3, other 27 (2018)
country comparison to the world: 120
Ports and terminals: Major seaport(s): Antilla, Cienfuegos,
Guantanamo, Havana, Matanzas, Mariel, Nuevitas Bay,
Santiago de Cuba TRANSNATIONAL ISSUES
Disputes—International: US Naval Base at Guantanamo Bay is
leased to US and only mutual agreement or US
abandonment of the facility can terminate the lease
Trafficking in persons: Current situation: Cuba is a source
country for adults and children subjected to sex trafficking
and forced labor; child sex trafficking and child sex tourism
occur in Cuba, while some Cubans are forced into
prostitution in South America and the Caribbean;
allegations have been made that some Cubans have been
forced or coerced to work at Cuban medical missions
abroad; assessing the scope of trafficking within Cuba is
difficult because of the lack of information tier rating: Tier 2
Watch List—Cuba does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; Cuba’s penal code does
not criminalize all forms of human trafficking, but the
government reported that it is in the process of amending
its criminal code to comply with the 2000 UN TIP Protocol,
to which it acceded in 2013; the government in 2014
prosecuted and convicted 13 sex traffickers and provided
services to the victims in those cases but does not have
shelters specifically for trafficking victims; the government
did not recognize forced labor as a problem and took no
action to address it; state media produced newspaper
articles and TV and radio programs to raise public
awareness about sex trafficking (2015) Inicit drugs: territorial
waters and air space serve as transshipment zone for US-
and European-bound drugs; established the death penalty
for certain drug-related crimes in 1999
CURACAO
Sabana
Westpunt
aChiistotigiberg
Barber
*Dorp''Soto + Curagao
Tera Coras pgropuerto
Hato
Dorp
Sint Michiel
WILLEMSTAD
Newport’
Military and security forces: no regular military forces; the
Dutch Government controls foreign and defense policy; the
Dutch Caribbean Coast Guard (DCCG) provides maritime
security (2019) Military service age and_ obligation: no
conscription (2010)
Military—note: defense is the responsibility of the Kingdom of
the Netherlands (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 11
(2015)
Civil aircraft registration country code prefix: PJ (2016)
Airports: 1 (2017)
country comparison to the world: 219
Airports—with paved runways:
total: 1 (2019)
over 3,047 m: 1
Roadways: total: 550 km
country comparison to the world: 187
Merchant marine: total: 82
by type: general cargo 11, oil tanker 1, other 70 (2018)
country comparison to the world: 95
Ports and terminals: Major seaport(s): Willemstad
oil terminal(s): Bullen Baai (Curacao Terminal)
bulk cargo port(s): Fuik Bay (phosphate rock)','a87ffd2e6516e0b7bf381f878db50e3caf9aed07e31ea061fd2ac36b01ded691','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a449ccb30d2d88c1d39b2d2c8da83dbd75486b1b31273ee777a5640a243975aa',2020,'HU','Hungary','military-and-security',402,'Military expenditures:
1.19% of GDP (2019 est.)
1.13% of GDP (2018)
1.04% of GDP (2017)
0.96% of GDP (2016)
1.03% of GDP (2015)
country comparison to the world: 107
Military and security forces: Ministry of Defense and Armed
Forces: Czech Land Forces, Czech Air Force (2019) Military
service age and obligation: 18-28 years of age for male and
female voluntary military service; no conscription (2012)
Military expenditures:
1.22% of GDP (2019 est.)
1.21% of GDP (2018)
1.21% of GDP (2017)
1.18% of GDP (2016)
1.07% of GDP (2015)
country comparison to the world: 103
Military and security forces: Italian Armed Forces: Army
(Esercito Italiano, EI), Navy (Marina Militare Italiana, MMI;
includes aviation, marines), Italian Air Force (Aeronautica
Militare Italiana, AMI), Carabinieri Corps (Arma dei
Carabinieri, CC) (2019) note(s): the Financial Guard
(Guardia di Finanza) under the Ministry of Economy and
Finance is a force with military status and nationwide remit
for financial crime investigations, including narcotics
trafficking, smuggling, and illegal immigration Italy has
established a Joint Special Operations Command and a
Joint Headquarters Cyber Operations (Comando Interforze
per le Operazioni Cibernetiche, CIOC) Military service age and
obligation: 18-25 years of age for voluntary military service;
women may serve in any military branch; Italian citizenship
required; 1-year service obligation (2013)','a5a69ad78303c887f6d8f039d238a66e355dbef7015e19df6cbbe357442d0498','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04cbd48255d2210d33802ca8f248958738b145a3cd710de590c00b0e80a6c17a',2020,'DK','Denmark','military-and-security',412,'Military expenditures:
1.32% of GDP (2019)
1.3% of GDP (2018)
1.15% of GDP (2017)
1.15% of GDP (2016)
1.11% of GDP (2015)
country comparison to the world: 92
Military and security forces: Royal Danish Army, Royal Danish
Navy, Royal Danish Air Force, Danish Home Guard
(Reserves) (2019) Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscripts serve an initial training period that varies from 4
to 12 months depending on_ specialization; former
conscripts are assigned to mobilization units; women
eligible to volunteer for military service; in addition to full
time employment, the Danish Military offers reserve
contracts in all three branches (2016) TRANSPORTATION
National air transport system:
number of registered air carriers: 10 (2015)
inventory of registered aircraft operated by air carriers: 76
(2015)
annual passenger traffic on registered air carriers: 582,011
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: OY (2016)
Airports: 80 (2013)
country comparison to the world: 68
Airports—with paved runways:
total: 28 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 7 (2017)
1,524 to 2,437 m: 5 (2017)
914 to 1,523 m: 12 (2017)
under 914 m: 2 (2017)
Airports—with unpaved runways:
total: 52 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 47 (2013)
Pipelines: 1536 km gas, 330 km oil (2015)
Railways: total: 3,476 km (2017)
standard gauge: 3,476 km 1.435-m gauge (1,756 km
electrified) (2017)
country comparison to the world: 57
Roadways: total: 74,558 km (2017)
paved: 74,558 km (includes 1,205 km of expressways)
(2017)
country comparison to the world: 66
Waterways: 400 km (2010)
country comparison to the world: 87
Merchant marine: total: 668
by type: bulk carrier 7, container ship 123, general cargo
77, oil tanker 75, other 386 (2018) country comparison to
the world: 31
Ports and terminals: Major seaport(s): Baltic Sea—Aarhus,
Copenhagen, Fredericia, Kalundborg’ cruise port(s):
Copenhagen
river port(s): Aalborg (Langerak)
dry bulk cargo port(s): Ensted (coal), North Sea—Esbjerg
Military expenditures:
0.92% of GDP (2018)
0.92% of GDP (2017)
0.98% of GDP (2016)
1.07% of GDP (2015)
1.03% of GDP (2014)
country comparison to the world: 125
Military and security forces: Republic of Fiji Military Forces
(RFMF): Land Force Command, Maritime Command (2019)
Military service age and obligation: 18 years of age for voluntary
military service; mandatory retirement at age 55 (2013)
Military and security forces: No regular military forces or
conscription. (2019)
Military—note: The Danish military’s Joint Arctic Command in
Nuuk is responsible for territorial defense of Greenland
(2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (registered in
Denmark) (2015)
inventory of registered aircraft operated by air carriers: 8
(registered in Denmark) (2015) Civil aircraft registration country
code prefix: OY-H (2016)
Airports: 15 (2013)
country comparison to the world: 146
Airports—with paved runways:
total: 10 (2019)
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 6
Airports—with unpaved runways:
total: 5 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 2 (2013)
Roadways: note: although there are short roads in towns,
there are no roads between towns; inter-urban transport is
either by sea or by air Merchant marine: total: 8
by type: general cargo 1, other 7 (2018)
country comparison to the world: 157
Ports and terminals: Major seaport(s): Sisimiut
Military expenditures:
1.8% of GDP (2019 est.)
1.73% of GDP (2018)
1.71% of GDP (2017)
1.73% of GDP (2016)
1.59% of GDP (2015)
country comparison to the world: 63
Military and_ security’ forces: Norwegian Armed Forces:
Norwegian Army (Haeren), Royal Norwegian Navy
(Kongelige Norske Sjoeforsvaret; includes Coastal Rangers
and Coast Guard (Kystvakt)), Royal Norwegian Air Force
(Kongelige Norske Luftforsvaret), Home Guard
(Heimevernet, HV) (2019) Military service age and obligation: 19-
35 years of age for male and female selective compulsory
military service; 17 years of age for male volunteers (16 in
wartime); 18 years of age for women; 19-month service
obligation; conscripts first serve 12 months from 19-28, and
then up to 4-5 refresher training periods until age 35, 44,
595, or 60 depending on rank and function. (2019)
Military expenditures:
8.17% of GDP (2018)
9.56% of GDP (2017)
11.97% of GDP (2016)
10.79% of GDP (2015)
10.14% of GDP (2014)
country comparison to the world: 2
Military and security forces: Sultan’s Armed Forces (SAF): Royal
Army of Oman (RAO), Royal Navy of Oman (RNO), Royal
Air Force of Oman (RAFO), Royal Guard of Oman (RGO)
(2019) note: the Royal Oman Police Coast Guard is
separate from the SAF
Military service age and obligation: 18-30 years of age for
voluntary military service; no conscription (2012) Maritime
threats: the Maritime Administration of the US Department
of Transportation has issued a Maritime Advisory (2019-
012-Persian Gulf, Strait of Hormuz, Gulf of Oman, Arabian
Sea, Red Sea-Threats to US and International Shipping
from Iran) effective 7 August 2019, which states in part
that “heightened military activities and increased political
tensions in this region continue to present risk to
commercial shipping...there is a continued possibility that
Iran and/or its regional proxies could take actions against
US and partner interests in the region;” at present, Iran
has seized two foreign-flagged tankers in the Persian Gulf;
the US and UK navies have established Operation Sentinel
to provide escorts for commercial shipping transiting the
Persian Gulf, Strait of Hormuz, and Gulf of Oman','b1788d08a4884baa95827f843597214f20269a7d516b190788b05482f185e14b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf84070a86709836044652982fd844500be702bba5931bb0d7bee8270bca964f',2020,'DJ','Djibouti','military-and-security',421,'Military and security forces: Djibouti Armed Forces (FAD):
Djibouti National Army (includes Navy, Djiboutian Air
Force, National Gendarmerie); Djibouti Coast Guard (2019)
Military service age and obligation: 18 years of age for voluntary
military service; 16-25 years of age for voluntary military
training; no conscription (2012) Maritime threats: the
International Maritime Bureau reports offshore waters in
the Red Sea and Gulf of Aden remain a high risk for piracy;
the presence of several naval task forces in the Gulf of
Aden and additional anti-piracy measures on the part of
ship operators, including the use of on-board armed
security teams, contributed to the drop in incidents; there
was one incident in the Gulf of Aden and none in the Red
Sea in 2018; Operation Ocean Shield, the
NATO/EUNAVFOR naval task force established in 2009 to
combat Somali piracy, concluded its operations in
December 2016 as a result of the drop in reported
incidents over the last few years; the EU naval mission,
Operation ATALANTA, continues its operations in the Gulf
of Aden and Indian Ocean through 2020; naval units from
Japan, India, and China also operate in conjunction with EU
forces; China has established a logistical base in Djibouti to
support its deployed naval units in the Horn of Africa
Military and_ security forces: NO regular military forces;
Commonwealth of Dominica Police Force (includes Coast
Guard) (2019) Military—note: Dominica participates in the
Regional Security System (RSS) an international agreement
for the defense and security of the eastern Caribbean
region (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 0 (2015)
inventory of registered aircraft operated by air carriers: 0
(2015)
annual passenger traffic on registered air carriers: 0 (2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: J7 (2016)
Airports: 2 (2013)
country comparison to the world: 199
Airports—with paved runways:
total: 2 (2019)
1,524 to 2,437 m: 1
914 to 1,523 m: 1
Roadways: total: 1,512 km (2018)
paved: 762 km (2018)
unpaved: 750 km (2018)
country comparison to the world: 170
Merchant marine: total: 100
by type: general cargo 26, oil tanker 25, other 49 (2018)
country comparison to the world: 86
Ports and terminals: Major seaport(s): Portsmouth, Roseau','e55b4be68a74e8b515f0d208659cefbe12b43672e9ab25dcf957ba3d0cb2a730','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31b70e277f10471db56d198e36b31cd61942df6fcc120363bc7502534fc171a9',2020,'JE','Jersey','military-and-security',434,'Military expenditures:
0.74% of GDP (2018)
0.66% of GDP (2017)
0.67% of GDP (2016)
0.67% of GDP (2015)
0.67% of GDP (2014)
country comparison to the world: 135
Military and security forces: Armed Forces of the Dominican
Republic: Army (Ejercito Nacional, EN), Navy (Marina de
Guerra, MdG, includes naval infantry), Dominican Air Force
(Fuerza Aerea Dominicana, FAD) (2019) Military service age
and obligation: 17-21 years of age for voluntary military
service; recruits must have completed primary school and
be Dominican Republic citizens; women may volunteer
(2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 6
(2015)
annual passenger traffic on registered air carriers: 14,463
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: HI (2016)
Airports: 36 (2013)
country comparison to the world: 109
Airports—with paved runways:
total: 16 (2017)
over 3,047 m: 3 (2017)
2,438 to 3,047 m: 4 (2017)
1,524 to 2,437 m: 4 (2017)
914 to 1,523 m: 4 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 20 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 18 (2013)
Heliports: 1 (2013)
Pipelines: 27 km gas, 103 km oil (2013)
Railways: total: 496 km (2014)
standard gauge: 354 km 1.435-m gauge (2014)
narrow gauge: 142 km 0.762-m gauge (2014)
country comparison to the world: 114
Roadways: total: 19,705 km (2002)
paved: 9,872 km (2002)
unpaved: 9,833 km (2002)
country comparison to the world: 113
Merchant marine: total: 23
by type: general cargo 2, oil tanker 1, other 20 (2018)
country comparison to the world: 135
Ports and terminals: Major seaport(s): Puerto Haina, Puerto
Plata, Santo Domingo oil terminal(s): Punta Nizao oil
terminal
LNG terminal(s) (import): Andres LNG terminal (Boca
Chica)
Military expenditures:
0.68% of GDP (2018)
0.68% of GDP (2017)
0.68% of GDP (2016)
0.66% of GDP (2015)
0.66% of GDP (2014)
country comparison to the world: 138
Military and security forces: Swiss Armed Forces: Land Forces,
Swiss Air Force (Schweizer Luftwaffe) (2019) Military service
age and obligation: 18-30 years of age generally for male
compulsory military service; 18 years of age for voluntary
male and female military service; every Swiss male has to
serve at least 245 days in the armed forces; conscripts
receive 18 weeks of mandatory training, followed by six 19-
day intermittent recalls for training during the next 10
years (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
12 (2015) inventory of registered aircraft operated by air
carriers: 163 (2015)
annual passenger traffic on registered air Carriers:
26,843,991 (2015)
annual freight traffic on _ registered air _ carriers:
1,322,379,468 mt-km (2015)
Civil aircraft registration country code prefix: HB (2016)
Airports: 63 (2013)
country comparison to the world: 78
Airports—with paved runways:
total: 40 (2013)
over 3,047 m: 3 (2013)
2,438 to 3,047 m: 2 (2013)
1,524 to 2,437 m: 12 (2013)
914 to 1,523 m: 6 (2013)
under 914 m: 17 (2013)
Airports—with unpaved runways:
total: 23 (2013)
under 914 m: 23 (2013)
Heliports: 2 (2013)
Pipelines: 1,800 km gas, 94 km oil (of which 60 are inactive),
17 km refined products (2017) Railways: total: 5,690 km
(includes 19 km in neighboring countries) (2015) standard
gauge: 3,836 km 1.435-m gauge (3,634 km electrified)
(2015)
narrow gauge: 1,630 km 1.200-m gauge (2 km electrified)
(includes 19 km in neighboring countries) (2015) 1188 km
1.000-m gauge (1,167.3 km electrified)
36 km 0.800-m gauge (36.4 km electrified)
country comparison to the world: 34
Roadways: total: 71,557 km (2017)
paved: 71,557 km (includes 1,458 of expressways) (2017)
country comparison to the world: 67
Waterways: 1,292 km (there are 1,227 km of waterways on
lakes and rivers for public transport and 65 km on the
Rhine River between Basel-Rheinfelden and Schaffhausen-
Bodensee for commercial goods transport) (2010) country
comparison to the world: 57
Merchant marine: total: 30 includes Liechtenstein
by type: bulk carrier 24, general cargo 4, oil tanker 2
(2019)
country comparison to the world: 126
Ports and terminals: river port(s): Basel (Rhine)
Military and security forces: Syrian Armed Forces: Syrian Arab
Army, Syrian Naval Forces, Syrian Air Forces, Syrian Air
Defense Forces, National Defense Forces (pro-government
militia and auxiliary forces) (2019) note: the Syrian
government is working to demobilize militias or integrate
them into its regular forces Military service age and obligation:
18-42 years of age for compulsory and voluntary military
service; conscript service obligation is 18 months; women
are not conscripted but may volunteer to serve (2019)
Military—note: the United Nations Disengagement Observer
Force (UNDOF) has operated in the Golan between Israel
and Syria since 1974 to monitor the ceasefire following the
1973 Arab-Israeli War and supervise the areas of
separation between the two countries; as of October 2019,
UNDOF consisted of about 1,140 personnel
Military expenditures:
2.16 % (est) (2019)
1.78% of GDP (2018)
1.82% of GDP (2017)
1.82% of GDP (2016)
1.87% of GDP (2015)
country comparison to the world: 65
Military and security forces: Republic of China Armed Forces:
Republic of China Army, Republic of China Navy (includes
Marine Corps), Republic of China Air Force, Military Police
Command, Armed Forces Reserve Command; Taiwan Coast
Guard Administration (a law enforcement organization with
homeland security functions during peacetime and national
defense missions during wartime) (2019) Military service age
and obligation: Starting with those born in 1994, males 18-36
years of age may volunteer for military service or must
complete 4 months of compulsory military training (or
substitute civil service in some cases); men born before
December 1993 are required to complete compulsory
service for 1 year (military or civil); men are subject to
training recalls up to four times for periods not to exceed
20 days for 8 years after discharge; women may enlist, but
are restricted to noncombat roles in most cases; as part of
its transition to an all-volunteer military in December 2018,
the last cohort of one-year military conscripts completed
their service obligations (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
8 (2015) inventory of registered aircraft operated by air
carriers: 221 (2015)
Civil aircraft registration country code prefix: B (2016)
Airports: 37 (2013)
country comparison to the world: 108
Airports—with paved runways:
total: 35 (2013)
over 3,047 m: 8 (2013)
2,438 to 3,047 m: 7 (2013)
1,524 to 2,437 m: 10 (2013)
914 to 1,523 m: 8 (2013)
under 914 m: 2 (2013)
Airports—with unpaved runways:
total: 2 (2013)
1,524 to 2,437 m: 1 (2013)
under 914 m: 1 (2013)
Heliports: 31 (2013)
Pipelines: 25 km condensate, 2,200 km gas, 13,500 km oil
(2018)
Railways: total: 1,613 km (2018)
standard gauge: 345 km 1.435-m gauge (345 km
electrified) (2018)
narrow gauge: 1,118.1 km 1.067-m gauge (793.9 km
electrified) (2018)
150 0.762-m gauge
note: the 0.762-gauge track belongs to three entities: the
Forestry Bureau, Taiwan Cement, and TaiPower country
comparison to the world: 81
Roadways: total: 43,206 km (2017)
paved: 42,793 km (includes 1,348 km of highways and 737
km of expressways) (2017)
unpaved: 413 km (2017)
country comparison to the world: 87
Merchant marine: total: 267
by type: bulk carrier 18, container ship 59, general cargo
60, oil tanker 19, other 111 (2018)
country comparison to the world: 54
Ports and terminals: Major seaport(s): Keelung (Chi-lung),
Kaohsiung, Hualian, Taichung container port(s) (TEUs):
Kaohsiung (10,271,018), Taichung (1,660,663), Taipei
(1,561,743) (2017)
LNG terminal(s) (import): Yung An (Kaohsiung), Taichung
Military expenditures:
1.22% of GDP (2015)
1.13% of GDP (2014)
1% of GDP (2012)
1.09% of GDP (2011)
note: no public data available for 2013, 2016-2018
country comparison to the world: 104
Military and security forces: Armed Forces of the Republic of
Tajikistan: Land Forces, Mobile Forces, Air and Air Defense
Forces; National Guard; Ministry of Internal Affairs:
Internal Troops (reserves for Armed Forces in wartime);
State Committee on National Security: Border Guard
Forces (2019) Military service age and obligation: 18-27 years of
age for compulsory or voluntary military service; 12-18
month conscript service obligation (2019)','6d8f610e9b76f6dbeefb69ddeb8333d65a0aced7c4097dc7b387d8576d2b6627','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('031d6883c08bf2be9bcd72b94f4a4dc50ec16686bd4b2872df351aba07b58f65',2020,'CO','Colombia','military-and-security',443,'Military expenditures:
2.38% of GDP (2018)
2.36% of GDP (2017)
2.21% of GDP (2016)
2.44% of GDP (2015)
2.72% of GDP (2014)
country comparison to the world: 35
Military and security forces: Ecuadorian Armed _ Forces:
Ecuadorian Land Force (Fuerza Terrestre Ecuatoriana,
FTE), Ecuadorian Navy (Fuerza Naval del Ecuador, FNE,
includes naval infantry, naval aviation, coast guard),
Ecuadorian Air Force (Fuerza Aerea Ecuatoriana, FAE)
(2019) Military service age and obligation: 18 years of age for
selective conscript military service; conscription has been
suspended; 18 years of age for voluntary military service;
Air Force 18-22 years of age, Ecuadorian birth
requirement; 1-year service obligation (2013) Maritime
threats: the International Maritime Bureau continues to
report the territorial and offshore waters as at risk for
piracy and armed robbery against ships; vessels, including
commercial shipping and pleasure craft, have been
attacked and hijacked both at anchor and while underway;
crews have been robbed and stores or cargoes stolen; after
several years with no incidents, there has been an increase
over the last two years with four attacks reported in 2018','4f27b43b1591d7a06c80b7857e0238bf6d1639e5720539c3724ed036920bc440','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbab686fd6500dd7fae89562d39a579dc3700fad34c9ff5b1414080a192c6463',2020,'GT','Guatemala','military-and-security',455,'Military expenditures:
1.03% of GDP (2018)
0.9% of GDP (2017)
0.92% of GDP (2016)
0.95% of GDP (2015)
0.93% of GDP (2014)
country comparison to the world: 115
Military and security forces: Armed Force of El Salvador (Fuerza
Armada de El Salvador, FAES): Army of El Salvador
(Ejercito de El Salvador, ES), Navy of El Salvador (Fuerza
Naval de El Salvador, FNES), Salvadoran Air Force (Fuerza
Aerea Salvadorena, FAS) (2019) note: supporting the
National Police in countering gang violence and drug
trafficking is a primary mission for the Armed Forces of El
Salvador Military service age and obligation: 18 years of age for
selective compulsory military service; 16-22 years of age
for voluntary male or female service; service obligation is
12 months, with 11 months for officers and NCOs (2012)','d10aff044b9c7bbde4f19cf564eb4f8826e91b29f9bf701b675141abc8bf5897','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3befa38ad2cff47e015fd9a53710a0b5ccd9f0879af8e8967ab1e5f72cfd7423',2020,'GN','Guinea','military-and-security',464,'Military expenditures:
0.18% of GDP (2016)
0.78% of GDP (2014)
country comparison to the world: 157
Military and security forces: Equatorial Guinea Armed Forces
(FAGE): Equatorial Guinea National Guard (Guardia
Nacional de Guinea Ecuatorial, GNGE (Army), Navy, Air
Force (2019) Military service age and obligation: 18 years of age
for selective compulsory military service, although
conscription is rare in practice; 2-year service obligation;
women hold only administrative positions in the Navy
(2013) TRANSPORTATION
National air transport system: number of registered air Carriers:
6 (2015) inventory of registered aircraft operated by air
carriers: 15 (2015)
annual passenger traffic on registered air carriers: 400,759
(2015)
annual freight traffic on registered air carriers: 461,650
mt-km (2015)
Civil aircraft registration country code prefix: 3C (2016)
Airports: 7 (2013)
country comparison to the world: 167
Airports—with paved runways:
total: 6 (2019)
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
under 914 m: 2
Airports—with unpaved runways:
total: 1 (2013)
2,438 to 3,047 m: 1 (2013)
Pipelines: 42 km condensate, 5 km condensate/gas, 79 km
gas, 71 km oil (2013)
Roadways: total: 2,880 km (2017)
country comparison to the world: 160
Merchant marine: total: 38
by type: container ship 1, general cargo 7, oil tanker 6,
other 24 (2018)
country comparison to the world: 121
Ports and terminals: Major seaport(s): Bata, Luba, Malabo
LNG terminal(s) (export): Bioko Island
Military and security forces: Eritrean Defense Forces: Eritrean
Ground Forces, Eritrean Navy, Eritrean Air Force (includes
Air Defense Force) (2019) Military service age and obligation: 18-
40 years of age for male and female voluntary and
compulsory military service; 18-month conscript service
obligation (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 1
(2015)
Civil aircraft registration country code prefix: E3 (2016)
Airports: 13 (2013)
country comparison to the world: 152
Airports—with paved runways:
total: 4 (2019)
over 3,047 m: 2
2,438 to 3,047 m: 2
Airports—with unpaved runways:
total: 9 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 5 (2013)
914 to 1,523 m: 2 (2013)
Heliports: 1 (2013)
Railways: total: 306 km (2018)
narrow gauge: 306 km 0.950-m gauge (2018)
country comparison to the world: 121
Roadways: total: 16,000 km (2018)
paved: 1,600 km (2000)
unpaved: 14,400 km (2000)
country comparison to the world: 120
Merchant marine: total: 9
by type: general cargo 4, oil tanker 1, other 4 (2018)
country comparison to the world: 153
Ports and terminals: Major seaport(s): Assab, Massawa
Military expenditures:
1.64% of GDP (2015)
2.04% of GDP (2014)
2.08% of GDP (2013)
1.46% of GDP (2012)
1.6% of GDP (2011)
country comparison to the world: 71
Military and security forces: People’s Revolutionary Armed
Force (FARP): Army, Navy, National Air Force (Forca Aerea
Nacional); Guard Nacional (2019) Military service age and
obligation: 18-25 years of age for selective compulsory
military service (Air Force service is voluntary); 16 years of
age or younger, with parental consent, for voluntary service
(2013) TRANSPORTATION
Civil aircraft registration country code prefix: JS (2016)
Airports: 8 (2013)
country comparison to the world: 160
Airports—with paved runways:
total: 2 (2019)
over 3,047 m: 1
1,524 to 2,437 m: 1
Airports—with unpaved runways:
total: 6 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 3 (2013)
Roadways: total: 4,400 km (2018)
paved: 453 km (2018)
unpaved: 3,947 km (2018)
country comparison to the world: 146
Waterways: (rivers are partially navigable; many inlets and
creeks provide shallow-water access to much of interior)
(2012) Merchant marine: total: 9
by type: general cargo 5, other 4 (2018)
country comparison to the world: 156
Ports and terminals: Major seaport(s): Bissau, Buba, Cacheu,
Farim TRANSNATIONAL ISSUES
Disputes—International: a longstanding low-grade conflict
continues in parts of Casamance, in Senegal across the
border; some rebels use Guinea-Bissau as a safe haven
Refugees and internally displaced persons: refugees (country of
origin): 10,000 (Senegal) (2018) Trafficking in persons: Current
situation: Guinea-Bissau is a source country for children
subjected to forced labor and sex trafficking; the extent to
which adults are trafficked for forced labor or forced
prostitution is unclear; boys are forced into street vending
in Guinea-Bissau and manual labor, agriculture, and mining
in Senegal, while girls may be forced into street vending,
domestic service, and, to a lesser extent, prostitution in
Guinea and Senegal; some Bissau-Guinean boys at Koranic
schools are forced into begging by religious teachers tier
rating: Tier 3—Guinea-Bissau does not fully comply with the
minimum standards for the elimination of trafficking and is
not making significant efforts to do so; despite enacting an
anti-trafficking law and adopting a national action plan in
2011, the country failed to demonstrate any notable anti-
trafficking efforts for the third consecutive year; existing
laws prohibiting all forms of trafficking were not used to
prosecute any trafficking offenders in 2014, and only one
case of potential child labor trafficking was under
investigation; authorities continued to rely entirely on
NGOs and international organizations to provide victims
with protective services; no trafficking prevention activities
were conducted (2015) Illicit drugs: increasingly important
transit country for South American cocaine en route to
Europe; enabling environment for trafficker operations due
to pervasive corruption; archipelago-like geography near
the capital facilitates drug smuggling GUYANA
.
* GEORGETOWN
New Amsterdam
Corriverton
Military expenditures:
0.27% of GDP (2018)
0.34% of GDP (2017)
0.39% of GDP (2016)
0.47% of GDP (2015)
0.49% of GDP (2014)
country comparison to the world: 155
Military and security forces: Papua New Guinea Defense Force
(PNGDF, includes land, maritime, and air elements) (2019)
Military service age and obligation: 16 years of age for voluntary
military service (with parental consent); no conscription;
graduation from grade 12 required (2013)
Military—note: occupied by China
Military expenditures:
0.93% of GDP (2018)
0.89% of GDP (2017)
0.95% of GDP (2016)
1.07% of GDP (2015)
0.99% of GDP (2014)
country comparison to the world: 124
Military and_ security forces: Armed Forces Command
(Commando de las Fuerzas Militares): Army, National Navy
(Armada Nacional, includes marines), Paraguayan Air Force
(Fuerza Aerea Paraguay, FAP) (2019) Military service age and
obligation: 18 years of age for compulsory and voluntary
military service; conscript service obligation is 12 months
for Army, 24 months for Navy; volunteers for the Air Force
must be younger than 22 years of age with a secondary
school diploma (2016) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 5 (2015)
annual passenger traffic on registered air carriers: 452,004
(2015)
annual freight traffic on registered air carriers: 1,641,624
mt-km (2015)
Civil aircraft registration country code prefix: ZP (2016)
Airports: 799 (2013)
country comparison to the world: 9
Airports—with paved runways:
total: 15 (2017)
over 3,047 m: 3 (2017)
1,524 to 2,437 m: 7 (2017)
914 to 1,523 m: 5 (2017)
Airports—with unpaved runways:
total: 784 (2013)
1,524 to 2,437 m: 23 (2013)
914 to 1,523 m: 290 (2013)
under 914 m: 471 (2013)
Railways: total: 30 km (2014)
standard gauge: 30 km 1.435-m gauge (2014)
country comparison to the world: 133
Roadways: total: 74,676 km (2017)
paved: 6,167 km (2017)
unpaved: 68,509 km (2017)
country comparison to the world: 65
Waterways: 3,100 km (primarily on the Paraguay and Parana
River systems) (2012)
country comparison to the world: 32
Merchant marine: total: 106
by type: bulk carrier 3, general cargo 24, oil tanker 5, other
74 (2019)
note: as of 2017, Paraguay registered 2,012 fluvial vessels
of which 1,741 were commercial barges
country comparison to the world: 87
Ports and terminals: river port(s): Asuncion, Villeta, San
Antonio, Encarnacion (Parana) TRANSNATIONAL ISSUES
Disputes—International: unruly region at convergence of
Argentina-Brazil-Paraguay borders is locus of money
laundering, smuggling, arms and _ illegal narcotics
trafficking, and fundraising for violent extremist
organizations Mlicit drugs: Major illicit producer of cannabis,
most or all of which is consumed in Brazil, Argentina, and
Chile; transshipment country for Andean cocaine headed
for Brazil, other Southern Cone markets, and Europe; weak
border controls, extensive corruption and money-
laundering activity, especially in the Tri-Border Area; weak
anti-money-laundering laws and enforcement
Military expenditures:
1.38% of GDP (2019 est.)
1.44% of GDP (2018)
1.46% of GDP (2017)
1.73% of GDP (2016)
1.58% of GDP (2015)
country comparison to the world: 85
Military and security forces: Senegalese Armed Forces: Army,
Senegalese National Navy (Marine Senegalaise, MNS),
Senegalese Air Force (Armee de |’Air du Senegal), National
Gendarmerie (includes Territorial and Mobile components)
(2019) Military service age and obligation: 18 years of age for
voluntary military service; 20 years of age for selective
conscript service; 2-year service obligation; women have
been accepted into military service since 2008 (2016)
Military expenditures:
0.8% of GDP (2018)
1.11% of GDP (2017)
1.14% of GDP (2016)
0.92% of GDP (2015)
0.97% of GDP (2014)
country comparison to the world: 131
Military and security forces: Republic of Sierra Leone Armed
Forces (RSLAF): Army (includes Maritime Wing and Air
Wing) (2019) Military service age and obligation: 18-29 for
voluntary military service; women are eligible to serve; no
conscription (2019) TRANSPORTATION
National air transport system: annual passenger traffic on
registered air carriers: 50,193 (2015) annual freight traffic
on registered air carriers: 0 mt-km (2015)
Civil aircraft registration country code prefix: OL (2016)
Airports: 8 (2013)
country comparison to the world: 162
Airports—with paved runways:
total: 1 (2019)
over 3,047 m: 1
Airports—with unpaved runways:
total: 7 (2013)
914 to 1,523 m: 7 (2013)
Heliports: 2 (2013)
Roadways: Waterways: 800 km (600 km navigable year-
round) (2011)
country comparison to the world: 72
Merchant marine: total: 469
by type: bulk carrier 21, container ship 10, general cargo
255, oil tanker 68, other 115 (2018) country comparison to
the world: 41
Ports and terminals: Major seaport(s): Freetown, Pepel,
Sherbro Islands TRANSNATIONAL ISSUES
Disputes—International: Sierra Leone opposes Guinean troops’
continued occupation of Yenga, a small village on the
Makona River that serves as a border with Guinea;
Guinea’s forces came to Yenga in the mid-1990s to help the
Sierra Leonean military to suppress rebels and to secure
their common border but have remained there even after
both countries signed a 2005 agreement acknowledging
that Yenga belonged to Sierra Leone; in 2012, the two sides
signed a declaration to demilitarize the area SINGAPORE
Yishurt
New Town
Ang Mo Kio
Tied New Town
Queens- »
wong town ~~" SINGAPORE
‘stam
Sentosa
LNDONESIA
‘ul
Pulau Batam','b35634a88891e2be943eb898f63174ccbd9f8b986a327ccdabb8c798f9962c6f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('603e379290409af9c42c10b7051ddb4fa9bb9adc1e0ceaec273fb6e61d5eb04f',2020,'LV','Latvia','military-and-security',478,'Military expenditures:
2.14% of GDP (2019 est.)
2% of GDP (2018)
2.03% of GDP (2017)
2.07% of GDP (2016)
2.02% of GDP (2015)
country comparison to the world: 43
Military and security forces: Estonian Defense Forces: Land
Forces, Navy, Air Force, Estonian Defence League
(Reserves); Ministry of Interior: Border Guards (2019)
Military service age and obligation: 18-27 for compulsory military
or governmental service, conscript service requirement 8-
11 months depending on education; NCOs, reserve officers,
and specialists serve 11 months (2016) TRANSPORTATION
National air transport system: number of registered air Carriers:
3 (2015) inventory of registered aircraft operated by air
carriers: 14 (2015)
annual passenger traffic on registered air Carriers: 512,388
(2015)
annual freight traffic on registered air carriers: 870,362
mt-km (2015)
Civil aircraft registration country code prefix: ES (2016)
Airports: 18 (2013)
country comparison to the world: 139
Airports—with paved runways:
total: 13 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 8 (2017)
1,524 to 2,437 m: 2 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 5 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 3 (2013)
Heliports: 1 (2012)
Pipelines: 2360 km gas (2016)
Railways: total: 2,146 km (2016)
broad gauge: 2,146 km 1.520-m and 1.524-m gauge (132
km electrified) (2016)
note: includes 1,510 km public and 636 km non-public
railway
country comparison to the world: 71
Roadways: total: 58,412 km (includes urban roads) (2011)
paved: 10,427 km (includes 115 km of expressways) (2011)
unpaved: 47,985 km (2011)
country comparison to the world: 78
Waterways: 335 km (320 km are navigable year-round)
(2011)
country comparison to the world: 90
Merchant marine: total: 74
by type: general cargo 8, oil tanker 6, other 60 (2018)
country comparison to the world: 100
Ports and terminals: Major seaport(s): Kuivastu, Kunda,
Muuga, Parnu Reid, Sillamae, Tallinn TRANSNATIONAL
ISSUES
Disputes—International: Russia and Estonia in May 2005
signed a technical border agreement, but Russia in June
2005 recalled its signature after the Estonian parliament
added to its domestic ratification act a historical preamble
referencing the Soviet occupation and Estonia’s pre-war
borders under the 1920 Treaty of Tartu; Russia contends
that the preamble allows Estonia to make territorial claims
on Russia in the future, while Estonian officials deny that
the preamble has any legal impact on the treaty text;
Russia demands better treatment of the Russian-speaking
population in Estonia; as a member state that forms part of
the EU’s external border, Estonia implements strict
Schengen border rules with Russia Refugees and internally
displaced persons: Stateless persons: 77,877 (2018); note—
following independence in 1991, automatic citizenship was
restricted to those who were Estonian citizens prior to the
1940 Soviet occupation and their descendants; thousands
of ethnic Russians remained stateless when forced to
choose between passing Estonian language and citizenship
tests or applying for Russian citizenship; one reason for
demurring on Estonian citizenship was to retain the right of
visa-free travel to Russia; stateless residents can vote in
local elections but not general elections; stateless parents
who have been lawful residents of Estonia for at least five
years can apply for citizenship for their children before
they turn 15 years old Illicit drugs: growing producer of
synthetic drugs; increasingly important transshipment zone
for cannabis, cocaine, opiates, and synthetic drugs since
joining the European Union and the Schengen Accord;
potential money laundering related to organized crime and
drug trafficking is a concern, as is possible use of the
gambling sector to launder funds; major use of opiates and
ecstasy ESWATINI
Military expenditures:
2.03% of GDP (2019 est.)
1.98% of GDP (2018)
1.72% of GDP (2017)
1.48% of GDP (2016)
1.14% of GDP (2015)
country comparison to the world: 50
Military and security forces: Lithuanian Armed Forces (Lietuvos
Ginkluotosios Pajegos): Land Forces (Sausumos Pajegos),
Naval Forces (Karines Juru Pajegos), Air Forces (Karines
Oro Pajegos), Special Operations Forces (Specialiuju
Operaciju Pajegos); National Defense Volunteer Forces
(Savanoriu Pajegos) (2019) Military service age and obligation:
19-26 years of age for conscripted military service (males);
9-month service obligation; in 2015, Lithuania reinstated
conscription after having converted to a_ professional
military in 2008; 18-38 for voluntary service (male and
female) (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 52
(2015)
annual passenger traffic on registered air Carriers:
1,363,950 (2015)
annual freight traffic on registered air carriers: 565,642
mt-km (2015)
Civil aircraft registration country code prefix: LY (2016)
Airports: 61 (2013)
country comparison to the world: 80
Airports—with paved runways:
total: 22 (2017)
over 3,047 m: 3 (2017)
2,438 to 3,047 m: 1 (2017)
1,524 to 2,437 m: 7 (2017)
914 to 1,523 m: 2 (2017)
under 914 m: 9 (2017)
Airports—with unpaved runways:
total: 39 (2013)
over 3,047 m: 1 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 36 (2013)
Pipelines: 1921 km gas, 121 km refined products (2013)
Railways: total: 1,768 km (2014)
standard gauge: 22 km 1.435-m gauge (2014)
broad gauge: 1,746 km 1.520-m gauge (122 km electrified)
(2014)
country comparison to the world: 79
Roadways: total: 84,166 km (2012)
paved: 72,297 km (includes 312 km of expressways) (2012)
unpaved: 11,869 km (2012)
country comparison to the world: 59
Waterways: 441 km (navigable year-round) (2007)
country comparison to the world: 86
Merchant marine: total: 61
by type: container ship 3, general cargo 28, oil tanker 2,
other 28 (2018) country comparison to the world: 106
Ports and terminals: Major seaport(s): Klaipeda
oil terminal(s): Butinge oil terminal
LNG terminal(s) (import): Klaipeda','a6608dd1db06d6fc9cd8e7aca864e5fafa7f07f1d4080b6c72e66a9b64006215','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f59260607099319d92fe98580875c31d6054e4e41ceed22997863552aeefd4e',2020,'MZ','Mozambique','military-and-security',479,'miembe
*Piggs
Peak Mhlume”
MBABANE
*
Lobamba, _Manzini_—Steki,
{royal and J
V—~fegisiative
capital}
*
Mankayane Big
Bend
.
Hiatikulu
Nhlangano
be 2 SOUTH
AFRICA
Military expenditures:
1.5% of GDP (2018)
1.8% of GDP (2017)
1.81% of GDP (2016)
1.78% of GDP (2015)
1.81% of GDP (2014)
country comparison to the world: 77
Military and security forces: Umbutfo Eswatini Defense Force
(UEDF): Ground Force (includes Air Wing (no operational
aircraft)) (2019) Military service age and obligation: 18-30 years
of age for male and female voluntary military service; no
conscription; compulsory HIV testing required, only HIV-
negative applicants accepted (2013) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 1
(2015)
annual passenger traffic on registered air carriers: 89,791
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: 3 (2016)
Airports: 14 (2013)
country comparison to the world: 148
Airports—with paved runways:
total: 2 (2019)
over 3,047 m:1
2,438 to 3,047 m: 1
Airports—with unpaved runways:
total: 12 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 7 (2013)
Railways: total: 301 km (2014)
narrow gauge: 301 km 1.067-m gauge (2014)
country comparison to the world: 122
Roadways: total: 3,769 km (2019)
country comparison to the world: 153
Military expenditures:
0.85% of GDP (2018)
0.76% of GDP (2017)
0.64% of GDP (2016)
0.63% of GDP (2015)
0.82% of GDP (2014)
country comparison to the world: 129
Military and security forces: Malawi Defense Force (MDF):
Army (includes Air Wing, Marine Unit); note—a 2017
amendment to Malawi’s Defense Force Act established a
separate Army, Air Force, and Maritime Force within the
MDF, but these services have yet to develop independent
budgets, chains of command, and training institutions
(2019) Military service age and obligation: 18 years of age for
voluntary military service; high school equivalent required
for enlisted recruits and college equivalent for officer
recruits; initial engagement is 7 years for enlisted
personnel and 10 years for officers (2014)
Military expenditures:
0.98% of GDP (2018)
1.12% of GDP (2017)
1.41% of GDP (2016)
1.53% of GDP (2015)
1.46% of GDP (2014)
country comparison to the world: 119
Military and security forces: Malaysian Armed Forces (Angkatan
Tentera Malaysia, ATM): Malaysian Army (Tentera Darat
Malaysia), Royal Malaysian Navy (Tentera Laut Diraja
Malaysia, TLDM), Royal Malaysian Air Force (Tentera
Udara Diraja Malaysia, TUDM); Ministry of Home Affairs:
the Royal Malaysian Police (PRMD, includes the General
Operations Force, a paramilitary force with a variety of
roles, including patrolling borders, counter-terrorism,
maritime security, and counterinsurgency) (2019) note:
Malaysia created a National Special Operations Force in
2016 for combating terrorism threats; the force is
comprised of personnel from the Armed Forces, the Royal
Malaysian Police, and the Malaysian Maritime Enforcement
Agency (Malaysian Coast Guard, MMEA) Military service age
and obligation: 17 years 6 months of age for voluntary
military service (younger with parental consent and proof
of age); mandatory retirement age 60; women serve in the
Malaysian Armed Forces; no conscription (2017) Maritime
threats: the International Maritime Bureau reports that the
territorial and offshore waters in the Strait of Malacca and
South China Sea remain high risk for piracy and armed
robbery against ships; in the past, commercial vessels have
been attacked and hijacked both at anchor and while
underway; hijacked vessels are often disguised and cargo
diverted to ports in East Asia; crews have been murdered
or cast adrift; 11 attacks were reported in 2018 including
eight ships boarded and seven crew taken hostage
Military and security forces: Maldives National Defense Force
(MNDF): Marine Corps, Special Protection Group, Coast
Guard (2019) note: the MNDF is primarily tasked to
reinforce the Maldives Police Service (MPS) and ensure
security in the country’s exclusive economic zone Military
service age and obligation: 18-28 years of age for voluntary
service; no conscription; 10th grade or _ equivalent
education required; must not be a member of a political
party TRANSPORTATION
National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 15
(2015)
Civil aircraft registration country code prefix: 8Q (2016)
Airports: 9 (2013)
country comparison to the world: 158
Airports—with paved runways:
total: 7 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 1 (2017)
1,524 to 2,437 m: 1 (2017)
914 to 1,523 m: 4 (2017)
Airports—with unpaved runways:
total: 2 (2013)
914 to 1,523 m: 2 (2013)
Roadways: total: 93 km (2018)
paved: 93 km—60 km in Male; 16 km on Addu Atolis; 17 km
on Laamu (2018)
note: island roads are mainly compacted coral
country comparison to the world: 208
Merchant marine: total: 67
by type: bulk carrier 1, general cargo 27, oil tanker 15,
other 24 (2018)
country comparison to the world: 103
Ports and terminals: Major seaport(s): Male
Military expenditures:
0.99% of GDP (2018)
1.02% of GDP (2017)
1.03% of GDP (2016)
0.81% of GDP (2015)
1.02% of GDP (2014)
country comparison to the world: 118
Military and_ security’ forces: Armed Defense Forces of
Mozambique (Forcas Armadas de Defesa de Mocambique,
FADM): Mozambique Army, Mozambique Navy (Marinha de
Guerra de Mocambique, MGM), Mozambique Air Force
(Forca Aerea de Mocambigque, FAM) (2019) Military service
age and obligation: registration for military service is
mandatory for all males and females at 18 years of age; 18-
35 years of age for selective compulsory military service;
18 years of age for voluntary service; 2-year service
obligation; women may serve as officers or enlisted (2019)
Military expenditures:
1.21% of GDP (2018)
1.18% of GDP (2017)
1.14% of GDP (2016)
1.13% of GDP (2015)
1.05% of GDP (2014)
country comparison to the world: 106
Military and security forces: Tanzania People’s Defense Forces
(TPDF or Jeshi la Wananchi la Tanzania, JWTZ): Land
Forces Command, Naval Forces Command, Air Force
Command, National Building Army (JJeshi la Kujenga Taifa,
JKT), People’s Militia (Reserves) (2019) note: the National
Building Army is a paramilitary organization under the
Defense Forces that provides six months of military and
vocational training to individuals as part of their two years
of public service; after completion of training, some
graduates join the regular Defense Forces while the
remainder become part of the People’s Militia Military service
age and obligation: 18-25 years of age for voluntary military
service; 6-year commitment (2019) Maritime threats: The
International Maritime Bureau reports that shipping in
territorial and offshore waters in the Indian Ocean remain
at risk for piracy and armed robbery against ships,
especially as Somali-based pirates extend their activities
south; numerous commercial vessels have been attacked
and hijacked both at anchor and while underway; crews
have been robbed and stores or cargoes stolen.
Military expenditures:
2.17% of GDP (2018)
1.93% of GDP (2017)
2.22% of GDP (2016)
2.34% of GDP (2015)
2.33% of GDP (2014)
country comparison to the world: 42
Military and security forces: Zimbabwe Defense Forces (ZDF):
Zimbabwe National Army (ZNA), Air Force of Zimbabwe
(AFZ) (2019) Military service age and obligation: 18-22 years of
age for voluntary military service (18-24 for officer cadets;
18-30 for technical/specialist personnel); no conscription;
women are eligible to serve (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 4 (2015) annual passenger traffic on registered air
carriers: 370,164 (2015) annual freight traffic on registered
air carriers: 962,642 mt-km (2015) Civil aircraft registration
country code prefix: Z (2016) Airports: 196 (2013)
country comparison to the world: 29
Airports—with paved runways:
total: 17 (2013)
over 3,047 m: 3 (2013)
2,438 to 3,047 m: 2 (2013)
1,524 to 2,437 m: 5 (2013)
914 to 1,523 m: 7 (2013)
Airports—with unpaved runways:
total: 179 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 104 (2013)
under 914 m: 72 (2013)
Pipelines: 270 km refined products (2013)
Railways: total: 3,427 km (2014) narrow gauge: 3,427 km
1.067-m gauge (313 km electrified) (2014) country
comparison to the world: 58
Roadways: total: 97,267 km (2019) paved: 18,481 km (2019)
unpaved: 78,786 km (2019)
country comparison to the world: 49
Waterways: (Some navigation possible on Lake Kariba) (2011)
Ports and terminals: river port(s): Binga, Kariba (Zambezi)','a576346c9edcd1869394a6c57937bc80432ce9e691c5ada7dab9b035f8311ed4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ce6c9dc2706ff631eb0e0decc0c1c64464ebcbf1004a1be2388dda2ae4ca80e',2020,'YE','Yemen','military-and-security',500,'Military expenditures:
0.64% of GDP (2018)
0.68% of GDP (2017)
0.67% of GDP (2016)
0.71% of GDP (2015)
0.77% of GDP (2014)
country comparison to the world: 140
Military and security forces: Ethiopian National Defense Force
(ENDF): Ground Forces, Ethiopian Air Force (Ye Ityopya
Ayer Hayl, ETAF) (2019) note: as of December 2018, a
committee was tasked to reestablish a naval force and a
special operations command Military service age and obligation:
18 years of age for voluntary military service; no
compulsory military service, but the military can conduct
callups when necessary and compliance is compulsory
(2013) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 75
(2015)
annual passenger traffic on registered air Carriers:
7,074,779 (2015)
annual freight traffic on _ registered air _ Carriers:
1,228,738,320 mt-km (2015) Civil aircraft registration country
code prefix: ET (2016)
Airports: 57 (2013)
country comparison to the world: 82
Airports—with paved runways:
total: 17 (2017)
over 3,047 m: 3 (2017)
2,438 to 3,047 m: 8 (2017)
1,524 to 2,437 m: 4 (2017)
under 914 m: 2 (2017)
Airports—with unpaved runways:
total: 40 (2013)
2,438 to 3,047 m: 3 (2013)
1,524 to 2,437 m: 9 (2013)
914 to 1,523 m: 20 (2013)
under 914 m: 8 (2013)
Railways: total: 659 km (Ethiopian segment of the 756 km
Addis Ababa-Djibouti railroad) (2017) standard gauge: 659
km 1.435-m gauge (2017)
note: electric railway with redundant power supplies;
under joint control of Djibouti and Ethiopia and managed
by a Chinese contractor country comparison to the world:
105
Roadways: total: 120,171 km (2018)
country comparison to the world: 40
Merchant marine: total: 11
by type: general cargo 9, oil tanker 2 (2018)
country comparison to the world: 149
Ports and terminals: Ethiopia is landlocked and uses the ports
of Djibouti in Djibouti and Berbera in Somalia TERRORISM
Terrorist groups—home based:
al-Shabaab: aim(s): punish Ethiopia for participating in the
African Union Mission in Somalia; compel Ethiopia to
withdraw troops from Somalia area(s) of operation: aspires
to conduct attacks in Addis Ababa; no permanent presence
(2018) Terrorist groups—foreign based:
al-Shabaab: aim(s): punish Ethiopia for participating in the
African Union Mission in Somalia; compel Ethiopia to
withdraw troops from Somalia area(s) of operation: aspires
to conduct attacks in Addis Ababa; no permanent presence
(April 2018) TRANSNATIONAL ISSUES
Disputes—International: Eritrea and Ethiopia agreed to abide
by the 2002 Eritrea-Ethiopia Boundary Commission’s
(EEBC) delimitation decision, but neither party responded
to the revised line detailed in the November 2006 EEBC
Demarcation Statement; the undemarcated former British
administrative line has littke meaning as a_ political
separation to rival clans within Ethiopia’s Ogaden and
southern Somalia’s Oromo region; Ethiopian forces invaded
southern Somalia and routed Islamist courts from
Mogadishu in January 2007; “Somaliland” secessionists
provide port facilities in Berbera and trade ties to
landlocked Ethiopia; civil unrest in eastern Sudan has
hampered efforts to demarcate the porous boundary with
Ethiopia Refugees and internally displaced persons: refugees
(country of origin): 334,014 (South Sudan),192,082
(Somalia),160,405 (Eritrea),41,899 (Sudan) (2019) IDPs:
2,164,201 (includes conflict-and climate-induced IDPs,
excluding unverified estimates from the Amhara region;
border war with Eritrea from 1998-2000; ethnic clashes;
and ongoing fighting between the Ethiopian military and
separatist rebel groups in the Somali and Oromia regions;
natural disasters; intercommunal violence; most IDPs live
in Sumale state) (2019) Illicit drugs: transit hub for heroin
originating in Southwest and Southeast Asia and destined
for Europe, as well as cocaine destined for markets in
southern Africa; cultivates gat (khat) for local use and
regional export, principally to Djibouti and Somalia (legal
in all three countries); the lack of a well-developed financial
system limits the country’s utility as a money laundering
center EUROPEAN UNION
Military expenditures:
1.5% of GDP (2018)
1.49% of GDP (2017)
1.48% of GDP (2016)
1.48% of GDP (2015)
1.5% of GDP (2014)
Military—note: the current five-nation Eurocorps, formally
established in 1992 and activated the following year, began
in 1987 as a French-German Brigade; Belgium (1993),
Spain (1994), and Luxembourg (1996) joined over the next
few years; five additional countries participate in
Eurocorps as associated nations: Greece, Poland, and
Turkey (since 2002), Italy and Romania (joined in 2009 and
2016 respectively); Eurocorps consists of approximately
1,000 troops at its headquarters in Strasbourg, France and
the 5,000-man Franco-German Brigade; Eurocorps has
deployed troops and police on NATO _ peacekeeping
missions to Bosnia-Herzegovina (1998-2000), Kosovo
(2000), and Afghanistan (2004-05 and 2012); Eurocorps has
been involved in EU operations to Mali (2015) and the
Central African Republic (2016-17) (2019)
Military and security forces: NO regular military forces
Military—note: defense is the responsibility of the UK','72ceb05befc5f709bf4f70852fd401c4f7039a3945ee66bbf48069103f6e7eda','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1be58890ed80418598d25b62e00a3d98e41181ba8cd6f6105dd2e13cd44f453',2020,'FO','Faroe Islands','military-and-security',510,'Military and security forces: No regular military forces or
conscription; the Government of Denmark has
responsibility for defense; as such, the Danish military’s
Joint Arctic Command in Nuuk, Greenland is responsible
for territorial defense of the Faroe Islands; the Joint Arctic
Command has a contact element in the capital of Torshavn
(2019) Military—note: defense is the responsibility of','89b784f9d8ad0c9e67340a6c5a613e0501efa0c74c2dbb7934022c0155e52963','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1667d99cbc2a3748946e72a1d1f9b655efd133c8c4c3193fbdf77ffdef25423e',2020,'EE','Estonia','military-and-security',517,'Military expenditures:
1.29% of GDP (2019)
1.23% of GDP (2018)
1.26% of GDP (2017)
1.31% of GDP (2016)
1.29% of GDP (2015)
country comparison to the world: 95
Military and security forces: Finnish Defense Forces (FDF):
Army (Maavoimat), Navy (Merivoimat), Air Force
(IImavoimat), Border Guard (Rajavartiolaitos) (2019) Military
service age and obligation: at age 18, all Finnish men are
obligated to serve 6-12 months of service within a branch
of the military or the Border Guard, and women may
volunteer for service; after completing their initial
conscript obligation, individuals enter the reserves and
remain eligible for mobilization until the age of 60 (2019)','0f2c805e8fc52be1b52ca408be8b2373d1de5f3f68eced8abf8e906810dd6bba','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3149f962c4530108e2920a3aa0f4cc617f664af9fffd5798a2c0ff723fb2dbc2',2020,'PF','French Polynesia','military-and-security',525,'Military and security forces: NO regular military forces (2019)
Military—note: defense is the responsibility of France and
France maintains forces in French Polynesia (2019)
Military—note: defense is the responsibility of France
Military expenditures:
1.53% of GDP (2018)
1.81% of GDP (2017)
1.43% of GDP (2016)
1.19% of GDP (2015)
1.14% of GDP (2014)
country comparison to the world: 74
Military and security forces: Gabonese Defense Forces (Forces
de Defense Gabonaise): Land Force (Force Terrestre),
Gabonese Navy (Marine Gabonaise), Gabonese Air Forces
(Forces Aerienne Gabonaises, FAG), Gabonese National
Gendarmerie (2019) Military service age and obligation: 20 years
of age for voluntary military service; no conscription (2013)
Military expenditures:
3% of GDP (2018)
1.48% of GDP (2015)
1.72% of GDP (2014)
1.15% of GDP (2013)
1.22% of GDP (2012)
country comparison to the world: 25
Military and security forces: Office of the Chief of Defense Staff:
Gambian National Army (GNA), Gambian Navy (GN),
Republican National Guard (RNG) (2018) Military service age
and obligation: 18 years of age for male and female voluntary
military service; no conscription; service obligation 6
months (2012) TRANSPORTATION
Civil aircraft registration country code prefix: C5 (2016)
Airports: 1 (2013)
country comparison to the world: 221
Airports—with paved runways:
total: 1 (2019)
over 3,047 m: 1
Roadways: total: 2,977 km (2011)
paved: 518 km (2011)
unpaved: 2,459 km (2011)
country comparison to the world: 157
Waterways: 390 km (on River Gambia; small oceangoing
vessels can reach 190 km) (2010) country comparison to
the world: 88
Merchant marine: total: 9
by type: other 9 (2018)
country comparison to the world: 154
Ports and terminals: Major seaport(s): Banjul','1001f7328c8bc622fb1ed876df4bf1d6f1440753a3f90e71be1d3c63c21ea562','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('736d499f8a4c74c1ed5e1f301fd3f4d234b948b94ddfdfd5a7e5bdf904fc0006',2020,'IL','Israel','military-and-security',532,'Military and _ security forces: HAMAS does not have a
conventional military in the Gaza Strip but maintains
security forces in addition to its military wing, the ‘Izz al-
Din al-Qassam Brigades; the military wing reports to the
HAMAS Political Bureau leadership; there are several other
militant groups operating in Gaza, most notably the AI-
Quds Brigades of Palestine Islamic Jihad, which are usually
but not always beholden to HAMAS’s authority (2019)
Military expenditures:
2.3% of GDP (2019)
2.1% of GDP (2018)
2% of GDP (2017)
2.23% of GDP (2016)
2.34% of GDP (2015)
country comparison to the world: 37
Military and security forces: Georgian Defense Forces: Land
Forces (include Air and Air Defense Forces); separatist
Abkhazia Armed Forces: Ground Forces, Air Forces;
separatist South Ossetia Armed Forces (2019) note:
Georgian naval forces have been incorporated into the
Coast Guard, which is part of the Ministry of Internal
Affairs rather than the Ministry of Defense Military service age
and obligation: 18 to 27 years of age for compulsory and
voluntary active duty military service; conscript service
obligation is 12 months (2017) Military—note: Georgia does
not have any military stationed in the separatist territories
of Abkhazia and South Ossetia, but large numbers of
Russian servicemen have been stationed in these regions
since the 2008 Russia-Georgia War (2019)','da7e590b3f8f4f6a48d0af1d86312e024671380a3ca40addf19c646a228ee43c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3acf9fd4243a7150f3ab8e867620077056158782b807210ef04be546b200f2c3',2020,'AT','Austria','military-and-security',544,'Military expenditures:
1.38% of GDP (2019 est.)
1.24% of GDP (2018)
1.23% of GDP (2017)
1.19% of GDP (2016)
1.18% of GDP (2015)
country comparison to the world: 84
Military and security forces: Federal Armed Forces
(Bundeswehr): Army (Heer), Navy (Deutsche Marine,
includes naval air arm), Air Force (Luftwaffe, includes air
defense), Joint Support Service (Streitkraeftebasis, SKB),
Central Medical Service (Zentraler Sanitaetsdienst,
ZSanDstBw), Cyber and Information Space Command
(Kommando Cyber- und Informationsraum, Kdo CIR) (2019)
Military service age and obligation: 17-23 years of age for male
and female voluntary military service; conscription ended 1
July 2011; service obligation 8-23 months or 12 years;
women have been eligible for voluntary service in all
military branches and _ positions since 2001 (2013)
Military expenditures:
0.41% of GDP (2018)
0.4% of GDP (2017)
0.38% of GDP (2016)
0.52% of GDP (2015)
0.68% of GDP (2014)
country comparison to the world: 150
Military and security forces: Ghana Armed Forces: Army, Navy,
Air Force (2019)
Military service age and obligation: 18-26 years of age for
voluntary military service, with basic education certificate;
no conscription; must be HIV/AIDS negative (2012) Maritime
threats: West African piracy more than doubled in 2018 to
become the most dangerous area in the World; the waters
off of Ghana saw a dramatic increase with 10 attacks
reported in 2018 compared with only one in 2017; eight
ships were boarded, one hijacked, and 47 crew taken
hostage or kidnapped TRANSPORTATION
National air transport system:
number of registered air carriers: 4 (2015)
inventory of registered aircraft operated by air carriers: 8
(2015)
annual passenger traffic on registered air carriers: 390,457
(2015)
annual freight traffic on registered air carriers: 844,630
mt-km (2015)
Civil aircraft registration country code prefix: 9G (2016)
Airports: 10 (2013)
country comparison to the world: 155
Airports—with paved runways:
total: 7 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 1 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 2 (2017)
Airports—with unpaved runways:
total: 3 (2013)
914 to 1,523 m: 3 (2013)
Pipelines: 394 km gas, 20 km oil, 361 km refined products
(2013)
Railways: total: 947 km (2014)
narrow gauge: 947 km 1.067-m gauge (2014)
country comparison to the world: 92
Roadways: total: 109,515 km (2009)
paved: 13,787 km (2009)
unpaved: 95,728 km (2009)
country comparison to the world: 45
Waterways: 1,293 km (168 km for launches and lighters on
Volta, Ankobra, and Tano Rivers; 1,125 km of arterial and
feeder waterways on Lake Volta) (2011) country
comparison to the world: 56
Merchant marine: total: 44
by type: general cargo 6, oil tanker 2, other 36 (2018)
country comparison to the world: 116
Ports and terminals: Major seaport(s): Takoradi, Tema','c52c008cb5f6725b8c780f53400f1d29d4f6f6388aecb7a84dc4bd2d4940ef8e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37be6db5469046216a08188717fc0e2dccc48d0ed389ef0d14e5216f59b2cafd',2020,'GI','Gibraltar','military-and-security',551,'Military and security forces: Royal Gibraltar Regiment (2019)
Military—note: defense is the responsibility of the UK; the
Royal Gibraltar Regiment replaced the last British regular
infantry forces in 1991 (2019) TRANSPORTATION
Civil aircraft registration country code prefix: VP-G (2016)
Airports: 1 (2013)
country comparison to the world: 223
Airports—with paved runways:
total: 1 (2017)
1,524 to 2,437 m: 1 (2017)
Roadways: total: 29 km (2007)
paved: 29 km (2007)
country comparison to the world: 212
Merchant marine: total: 250
by type: bulk carrier 11, container ship 26, general cargo
81, oil tanker 27, other 105 (2018) country comparison to
the world: 59
Ports and terminals: Major seaport(s): Gibraltar
Military expenditures:
2.28% of GDP (2019 est.)
2.48% of GDP (2018)
2.34% of GDP (2017)
2.38% of GDP (2016)
2.3% of GDP (2015)
country comparison to the world: 39
Military and security forces: Hellenic Armed Forces: Hellenic
Army (Ellinikos Stratos, ES; includes National Guard
reserves), Hellenic Navy (Elliniko Polemiko Navtiko, EPN),
Hellenic Air Force (Elliniki Polemiki Aeroporia, EPA;
includes air defense) (2019) Military service age and obligation:
19-45 years of age for compulsory military service; during
wartime the law allows for recruitment beginning January
of the year of inductee’s 18th birthday, thus including 17
year olds; 18 years of age for volunteers; conscript service
obligation is 1 year for the Army and 9 months for the Air
Force and Navy; women are eligible for voluntary military
service (2014) TRANSPORTATION
National air transport system:
number of registered air carriers: 9 (2015)
inventory of registered aircraft operated by air carriers: 93
(2015)
annual passenger traffic on registered air Carriers:
12,583,541 (2015)
annual freight traffic on registered air carriers: 27,452,961
mt-km (2015)
Civil aircraft registration country code prefix: SX (2016)
Airports: 77 (2013)
country comparison to the world: 69
Airports—with paved runways:
total: 68 (2017)
over 3,047 m: 6 (2017)
2,438 to 3,047 m: 15 (2017)
1,524 to 2,437 m: 19 (2017)
914 to 1,523 m: 18 (2017)
under 914 m: 10 (2017)
Airports—with unpaved runways:
total: 9 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 7 (2013)
Heliports: 9 (2013)
Pipelines: 1329 km gas, 94 km oil (2013)
Railways: total: 2,548 km (2014)
standard gauge: 1,565 km 1.435-m gauge (764 km
electrified) (2014)
narrow gauge: 961 km 1.000-m gauge (2014)
22 0.750-m gauge
country comparison to the world: 67
Roadways: total: 117,000 km (2018)
country comparison to the world: 42
Waterways: 6 km (the 6-km-long Corinth Canal crosses the
Isthmus of Corinth; it shortens a sea voyage by 325 km)
(2012) country comparison to the world: 106
Merchant marine: total: 1,343
by type: bulk carrier 191, container ship 6, general cargo
136, oil tanker 405, other 605 (2018) country comparison
to the world: 21
Ports and terminals: Major seaport(s): Aspropyrgos, Pachi,
Piraeus, Thessaloniki oil terminal(s): Agioi Theodoroi
container port(s) (TEUs): Piraeus (4,145,079) (2017)
LNG terminal(s) (import): Revithoussa','b142f49b8e2023af8097aca343090a232b33de33bb5ee8e42440088adf4ff13e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39f44c0fb8bd42003cf92815829c615644920f218891673b226364687c68a131',2020,'GD','Grenada','military-and-security',558,'Military and security forces: NO regular military forces; Royal
Grenada Police Force (includes Coast Guard) (2019)
Military—note: defense is the responsibility of the US','9994d89d51cb687d4eace9f9e80348d747d729429c084e41498327e2dff4fd7f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e2dc25271f713e5797b06c3ed18a9b5ef58fe3f839db5eaa621a0bebc19bd8f',2020,'SV','El Salvador','military-and-security',569,'Military expenditures:
0.35% of GDP (2018)
0.36% of GDP (2017)
0.39% of GDP (2016)
0.43% of GDP (2015)
0.45% of GDP (2014)
country comparison to the world: 151
Military and security forces: Army of Guatemala (Ejercito de
Guatemala): Land Forces (Fuerzas de Tierra), Naval Forces
(Fuerza de Mar), and Air Force (Fuerza de Aire); Ministry
of Interior: National Civil Police (Policia Nacional Civil;
includes paramilitary units) (2019) Military service age and
obligation: all male citizens between the ages of 18 and 50
are eligible for military service; in practice, most of the
force is volunteer, however, a selective draft system is
employed, resulting in a small portion of 17-21 year-olds
conscripted; conscript service obligation varies from 1 to 2
years; women can _ serve’ as_ officers (2013)
Military—note: defense is the responsibility of the UK','829c2ec7c975707c0679d6ff836200ee2d35ae2ece4c7ce8afa6847ffe201d4f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac82d97e322b434e0c1384b7c56a2805acee1b09d3d0034bcdd4c3e4a87e3d1f',2020,'LR','Liberia','military-and-security',578,'Military expenditures:
2.47% of GDP (2018)
2.71% of GDP (2017)
2.49% of GDP (2016)
3.31% of GDP (2015)
2.97% of GDP (2014)
country comparison to the world: 33
Military and security forces: National Armed Forces: Army,
Guinean Navy (Armee de Mer or Marine Guineenne,
includes Marines), Guinean Air Force (Force Aerienne de
Guinee), Republican Guard, Gendarmerie, People’s Militia
(Reserves) (2019) Military service age and obligation: no
compulsory military service (2017)
Military expenditures:
0.77% of GDP (2018)
0.73% of GDP (2017)
0.7% of GDP (2016)
0.73% of GDP (2015)
0.72% of GDP (2014)
country comparison to the world: 133
Military and security forces: Armed Forces of Liberia (AFL):
Army, Liberia Air Wing, Liberian Coast Guard (2019) Military
service age and obligation: 18 years of age for voluntary
military service; no conscription (2012) TRANSPORTATION
Civil aircraft registration country code prefix: AS (2016)
Airports: 29 (2013)
country comparison to the world: 117
Airports—with paved runways:
total: 2 (2019)
over 3,047 m: 1
1,524 to 2,437 m: 1
Airports—with unpaved runways:
total: 27 (2013)
1,524 to 2,437 m: 5 (2013)
914 to 1,523 m: 8 (2013)
under 914 m: 14 (2013)
Pipelines: 4 km oil (2013)
Railways: total: 429 km (2008)
standard gauge: 345 km 1.435-m gauge (2008)
narrow gauge: 84 km 1.067-m gauge (2008)
note: most sections of the railways inoperable due to
damage sustained during the civil wars from 1980 to 2003,
but many are being rebuilt country comparison to the
world: 117
Roadways: total: 10,600 km (2018)
paved: 657 km (2018)
unpaved: 9,943 km (2018)
country comparison to the world: 130
Merchant marine: total: 3,321
by type: bulk carrier 1086, container ship 834, general
cargo 130, oil tanker 723, other 548 (2018) country
comparison to the world: 8
Ports and terminals: Major seaport(s): Buchanan, Monrovia
Military and security forces: note—in transition; Government of
National Accord (GNA) has various ground, air, naval, and
coast guard forces under its command; the ground forces
are comprised of a mix of semi-regular military units, tribal
militias, and civilian volunteers (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
8 (2015) inventory of registered aircraft operated by air
carriers: 23 (2015)
annual passenger traffic on registered air Carriers:
2,966,465 (2015)
annual freight traffic on registered air carriers: 3,833,542
mt-km (2015) Civil aircraft registration country code prefix: 5A
(2016)
Airports: 146 (2013)
country comparison to the world: 40
Airports—with paved runways:
total: 68 (2017)
over 3,047 m: 23 (2017)
2,438 to 3,047 m: 7 (2017)
1,524 to 2,437 m: 30 (2017)
914 to 1,523 m: 7 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 78 (2013)
over 3,047 m: 2 (2013)
2,438 to 3,047 m: 5 (2013)
1,524 to 2,437 m: 14 (2013)
914 to 1,523 m: 37 (2013)
under 914 m: 20 (2013)
Heliports: 2 (2013)
Pipelines: 882 km condensate, 3743 km gas, 7005 km oil
(2013)
Roadways: total: 37,000 km (2010)
paved: 34,000 km (2010)
unpaved: 3,000 km (2010)
country comparison to the world: 91
Merchant marine: total: 98
by type: general cargo 2, oil tanker 16, other 80 (2018)
country comparison to the world: 88
Ports and terminals: Major seaport(s): Marsa al Burayqah
(Marsa el Brega), Tripoli oil terminal(s): Az Zawiyah, Ra’s
Lanuf
LNG terminal(s) (export): Marsa el Brega
Military and security forces: nO regular military forces; National
Police maintain close relations with neighboring forces
(2019) TRANSPORTATION
Civil aircraft registration country code prefix: HB (2016)
Pipelines: 434.5 km gas (2018)
Railways: total: 9 km (2018)
standard gauge: 9 km 1.435-m gauge (electrified) (2018)
note: belongs to the Austrian Railway System connecting
Austria and Switzerland country comparison to the world:
136
Roadways: total: 630 km (2019)
country comparison to the world: 185
Waterways: 28 km (2010)
country comparison to the world: 105','187a1ce54961dc5605883f4e814c66058df0febd44c73fd246e4d215e2e53c10','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50fe4519dd2567f58c9a87eae1a1c68bd6dd89b84a417c100c80035d8068cc88',2020,'HM','Heard Island and McDonald Islands','military-and-security',583,'Military—note: defense is the responsibility of Australia;
Australia conducts fisheries patrols TRANSPORTATION
Railways: Roadways: Ports and terminals: none; offshore
anchorage only','6110e891de77686c6d7742d2bbb552c9bcb7b291cfe0d75387e7bb38ba0a5946','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a785246f61b1838b1265b24f72a079f138fef0a96e737bf36a43c556d578b58a',2020,'IT','Italy','military-and-security',588,'Military and security forces: Pontifical Swiss Guard Corps
(Corpo della Guardia Svizzera Pontificia); the Gendarmerie
Corps of Vatican City is a police force that helps augment
the Pontifical Swiss Guard during the Pope’s appearances,
as well as providing general security, traffic direction, and
investigative duties for the Vatican City State (2019) Military
service age and obligation: Pontifical Swiss Guard Corps (Corpo
della Guardia Svizzera Pontificia): 19-30 years of age for
voluntary military service; no conscription; must be Roman
Catholic, a single male, and a Swiss citizen, with a
secondary education (2019) Military—note: defense is the
responsibility of Italy','a4f2d62fe75a26e8cefdcc78816fc403120a2f94f0642b9c253e67cdecc381d7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3df58ff4a660d6b775fdd7bfb8d9dc71afa3cba6c90439617c6710dabfd9674',2020,'IE','Ireland','military-and-security',600,'Military expenditures:
0.33% of GDP (2018)
0.4% of GDP (2017)
0.34% of GDP (2016)
0.35% of GDP (2015)
0.47% of GDP (2014)
country comparison to the world: 153
Military and security forces: Irish Defence Forces (Oglaigh na h-
Eireannn): Army (includes Army Reserve), Naval Service
(includes Naval Service Reserves), Air Corps (2019) Military
service age and obligation: 18-25 years of age for male and
female voluntary military service recruits to the Defence
Forces (18-27 years of age for the Naval Service); 18-26 for
cadetship (officer) applicants; 12-year service (5 active, 7
reserves); Irish citizen, European Economic’ Area
citizenship, or refugee status (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 6 (2015)
inventory of registered aircraft operated by air carriers:
431 (2015)
annual passenger traffic on registered air Carriers:
113,144,501 (2015)
annual freight traffic on registered air carriers: 138.58
million mt-km (2015)
Civil aircraft registration country code prefix: EI (2016)
Airports: 40 (2013)
country comparison to the world: 105
Airports—with paved runways:
total: 16 (2019)
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 5
under 914 m:5
Airports—with unpaved runways:
total: 24 (2013)
2,438 to 3,047 m: 1 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 21 (2013)
Pipelines: 2,427 km gas (2017)
Railways: total: 4,301 km (2018)
narrow gauge: 1,930 km 0.914-m gauge (operated by the
Irish Peat Board to transport peat to power stations and
briquetting plants) (2018) broad gauge: 2,371 km 1.600-m
gauge (53 km electrified) (2018)
country comparison to the world: 44
Roadways: total: 99,830 km (2018)
paved: 99,830 km (includes 2,717 km of expressways)
(2018)
country comparison to the world: 48
Waterways: 956 km (pleasure craft only) (2010)
country comparison to the world: 67
Merchant marine: total: 88
by type: bulk carrier 8, general cargo 34, oil tanker 1, other
45 (2018)
country comparison to the world: 91
Ports and terminals: Major seaport(s): Dublin, Shannon Foynes
cruise port(s): Cork, Dublin
container port(s) (TEUs): Dublin (529,563) (2016)
river port(s): Cork (Lee), Waterford (Suir)
Military—note: defense is the responsibility of the UK','3960a76b7eeb1b432897ab622222bb4e0634b887cf6d3d17879f84858f1002bc','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2bfc6928092663ae78451eab2593bc1a030a5767b880abb07a8446dbf34c7fc',2020,'EG','Egypt','military-and-security',606,'Military expenditures:
4.35% of GDP (2018)
4.43% of GDP (2017)
4.63% of GDP (2016)
5.65% of GDP (2015)
5.96% of GDP (2014)
country comparison to the world: 8
Military and _ security forces: Israel Defense Forces (IDF):
Ground Forces, Israel Naval Force (IN, _ includes
commandos), Israel Air Force (IAF, includes air defense);
Ministry of Public Security: Border Police (2019) note: the
Border Police is a unit within the Israel Police with its own
organizational and command structure; it works both
independently as well as in cooperation with or in support
of the Israel Police and Israel Defense Force Military service
age and obligation: 18 years of age for compulsory (Jews,
Druze) military service; 17 years of age for voluntary
(Christians, Muslims, Circassians) military service; both
sexes are obligated to military service; conscript service
obligation—32 months for enlisted men and about 24
months for enlisted women (varies based on military
occupation), 48 months for officers; pilots commit to 9-year
service; reserve obligation to age 41-51 (men), age 24
(women) (2015) Military—note: the United Nations
Disengagement Observer Force (UNDOF) has operated in
the Golan between Israel and Syria since 1974 to monitor
the ceasefire following the 1973 Arab-Israeli War and
supervise the areas of separation between the two
countries; as of October 2019, UNDOF consisted of about
1,140 personnel TRANSPORTATION
National air transport system:
number of registered air carriers: 6 (2015)
inventory of registered aircraft operated by air carriers: 60
(2015)
annual passenger traffic on registered air Carriers:
6,064,478 (2015)
annual freight traffic on _ registered air carriers:
758,633,996 mt-km (2015)
Civil aircraft registration country code prefix: 4X (2016)
Airports: 42 (2020)
country comparison to the world: 100
Airports—with paved runways:
total: 33 (2019)
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 5
914 to 1,523 m: 12
under 914 m: 8
Airports—with unpaved runways:
total: 9 (2020)
914 to 1,523 m: 3
under 914 m: 6
Heliports: 3 (2013)
Pipelines: 763 km gas, 442 km oil, 261 km refined products
(2013)
Railways: total: 1,384 km (2014)
standard gauge: 1,384 km 1.435-m gauge (2014)
country comparison to the world: 83
Roadways: total: 19,555 km (2017)
paved: 19,555 km (includes 449 km of expressways) (2017)
country comparison to the world: 114
Merchant marine: total: 42
by type: container ship 5, general cargo 5, oil tanker 3,
other 29 (2018)
country comparison to the world: 119
Ports and terminals: Major seaport(s): Ashdod, Elat (Eilat),
Hadera, Haifa container port(s) (TEUs): Ashdod (1,443,000)
(2016)','3c0900c83f2ef33ec0fdaa762f96a5cac95d181bf0f800cd6d51873c5b7e759f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83a0accdbc0b751bc71678bf67c2591b9dfaacae1ed738b7f526a82b9a9a72fb',2020,'CU','Cuba','military-and-security',613,'Military expenditures:
1.35% of GDP (2018)
0.98% of GDP (2017)
0.96% of GDP (2016)
0.87% of GDP (2015)
0.87% of GDP (2014)
country comparison to the world: 89
Military and security forces: Jamaica Defense Force (JDF):
Ground Forces, Coast Guard, Air Wing (2019) Military service
age and obligation: 17 1/2 is the legal minimum age for
voluntary military service; no _ conscription (2012)
Military—note: defense is the responsibility of Norway
Military expenditures:
0.93% of GDP (2018)
0.93% of GDP (2017)
0.94% of GDP (2016)
0.94% of GDP (2015)
0.97% of GDP (2014)
country comparison to the world: 123
Military and security forces: Japanese Ministry of Defense
(MOD): Ground Self-Defense Force (Rikujou Jieitai, GSDF;
includes aviation), Maritime Self-Defense Force (Kaijou
Jieitai, MSDF; includes naval aviation), Air Self-Defense
Force (Koukuu Jieitai, ASDF); Japan Coast Guard (Ministry
of Land, Transport, Infrastructure and Tourism) (2019)
Military service age and obligation: 18 years of age for voluntary
military service; no conscription; mandatory retirement at
age 53 for senior enlisted personnel and at 62 years for
senior service officers (2012) TRANSPORTATION
National air transport system:
number of registered air carriers: 23 (2015)
inventory of registered aircraft operated by air carriers:
627 (2015) annual passenger traffic on registered air
carriers: 113.762 million (2015) annual freight traffic on
registered air carriers: 8,868,745,000 mt-km (2015) Civil
aircraft registration country code prefix: JA (2016)
Airports: 175 (2013)
country comparison to the world: 33
Airports—with paved runways:
total: 142 (2017)
over 3,047 m: 6 (2017)
2,438 to 3,047 m: 45 (2017)
1,524 to 2,437 m: 38 (2017)
914 to 1,523 m: 28 (2017)
under 914 m: 25 (2017)
Airports—with unpaved runways:
total: 33 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 28 (2013)
Heliports: 16 (2013)
Pipelines: 4456 km gas, 174 km oil, 104 km oil/gas/water
(2013)
Railways: total: 27,311 km (2015)
standard gauge: 4,800 km 1.435-m gauge (4,800 km
electrified) (2015)
narrow gauge: 124 km 1.372-m gauge (124 km electrified)
(2015)
dual gauge: 132 km 1.435-1.067-m gauge (132 km
electrified) (2015)
22,207 km 1.067-m gauge (15,430 km electrified)
48 km 0.762-m gauge (48 km electrified)
country comparison to the world: 11
Roadways: total: 1,218,772 km (2015)
paved: 992,835 km (includes 8,428 km of expressways)
(2015)
unpaved: 225,937 km (2015)
country comparison to the world: 6
Waterways: 1,770 km (seagoing vessels use inland seas)
(2010)
country comparison to the world: 44
Merchant marine: total: 5,299
by type: bulk carrier 158, container ship 29, general cargo
1942, oil tanker 703, other 2467 (2018) country
comparison to the world: 3
Ports and terminals: Major seaport(s): Chiba, Kawasaki, Kobe,
Mizushima, Moji, Nagoya, Osaka, Tokyo, Tomakomai,
Yokohama container port(s) (TEUs): Kobe (2,924,179),
Nagoya (2,784,109), Osaka (2,326,852), Tokyo (4,500,156),
Yokohama (2,926,698) (2017) LNG terminal(s) (import):
Chita, Fukwoke, Futtsu, Hachinone, Hakodate,
Hatsukaichi, Higashi Ohgishima, Higashi Niigata, Himeiji,
Joetsu, Kagoshima, Kawagoe, Kita Kyushu, Mizushima,
Nagasaki, Naoetsu, Negishi, Ohgishima, Oita, Sakai,
Sakaide, Senboku, Shimizu, Shin Minato, Sodegaura,
Tobata, Yanai, Yokkaichi Okinawa—Nakagusuku
Military—note: defense is the responsibility of the UK','2cb70f1ab2c27feddbe5a876c5d3a167845c4f738fcad281b08e6ddb7989d47b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('113d4399b1b2a06a8114c8cab42d72b83adaa119c2f65f2b0119674def40b806',2020,'JO','Jordan','military-and-security',622,'Military expenditures:
4.68% of GDP (2018)
4.8% of GDP (2017)
4.58% of GDP (2016)
4.31% of GDP (2015)
4.32% of GDP (2014)
country comparison to the world: 7
Military and security forces: Jordanian Armed Forces (/AF):
Royal Jordanian Army (includes Special Operations Forces,
Border Guards, Royal Guard), Royal Jordanian Navy, Royal
Jordanian Air Force; Ministry of Interior: General
Directorate of Gendarmerie Forces, Public Security
Directorate (2019) Military service age and obligation: 17 years
of age for voluntary male military service; initial service
term 2 years, with option to reenlist for 18 years;
conscription at age 18 suspended in 1999; women are not
conscripted, but can volunteer to serve in noncombat
military positions in the Royal Jordanian Arab Army
Women’s Corps and RJAF (2013) TRANSPORTATION
National air transport system:
number of registered air carriers: 7 (2015)
inventory of registered aircraft operated by air carriers: 40
(2015)
annual passenger traffic on registered air Carriers:
3,065,145 (2015) annual freight traffic on registered air
carriers: 169.105 million mt-km (2015) Civil aircraft
registration country code prefix: JY (2016)
Airports: 18 (2013)
country comparison to the world: 140
Airports—with paved runways:
total: 16 (2017)
over 3,047 m: 8 (2017)
2,438 to 3,047 m: 5 (2017)
1,524 to 2,437 m: 2 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 2 (2013)
under 914 m: 2 (2013)
Heliports: 1 (2012)
Pipelines: 473 km gas, 49 km oil (2013)
Railways: total: 509 km (2014)
narrow gauge: 509 km 1.050-m gauge (2014)
country comparison to the world: 113
Roadways: total: 7,203 km (2011)
paved: 7,203 km (2011)
country comparison to the world: 136
Merchant marine: total: 32
by type: general cargo 8, oil tanker 1, other 23 (2018)
country comparison to the world: 124
Ports and terminals: major seaport(s): Al ‘Agabah','5d7d9015539e2e632d9090293f493c41e1740a9fa9b8ed33e9170a7b04ca898e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e18f9d96b2d508b78c777f85d20afd8cab3868501c4de08bf32ed49a8647528',2020,'KZ','Kazakhstan','military-and-security',631,'Military expenditures:
0.95% of GDP (2018)
0.84% of GDP (2017)
0.96% of GDP (2016)
1.1% of GDP (2015)
1.04% of GDP (2014)
country comparison to the world: 121
Military and security forces: Armed Forces of Kazakhstan: Land
Forces, Navy, Air Defense Force, Republican Guard;
Ministry of Internal Affairs: National Guard, Border Service
(2019) Military service age and obligation: All men 18-27 are
required to serve in the military for at least one year.
(2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 10 (2015)
inventory of registered aircraft operated by air carriers: 71
(2015)
annual passenger traffic on registered air Carriers:
9,081,631 (2015)
annual freight traffic on registered air carriers: 37,669,008
mt-km (2015)
Civil aircraft registration country code prefix: UP (2016)
Airports: 96 (2013)
country comparison to the world: 60
Airports—with paved runways:
total: 63 (2017)
over 3,047 m: 10 (2017)
2,438 to 3,047 m: 25 (2017)
1,524 to 2,437 m: 15 (2017)
914 to 1,523 m: 5 (2017)
under 914 m: 8 (2017)
Airports—with unpaved runways:
total: 33 (2013)
over 3,047 m: 5 (2013)
2,438 to 3,047 m: 7 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 13 (2013)
Heliports: 3 (2013)
Pipelines: 658 km condensate, 15,256 km gas (2017), 8,013
km oil (2017), 1,095 km refined products, 1,975 km water
(2016) (2017) Railways: total: 16,614 km (2017)
broad gauge: 16,614 km 1.520-m gauge (4,200 km
electrified) (2017)
country comparison to the world: 18
Roadways: total: 95,409 km (2017)
paved: 81,814 km (2017)
unpaved: 13,595 km (2017)
country comparison to the world: 51
Waterways: 4,000 km (on the Ertis (Irtysh) River (80%) and
Syr Darya (Syrdariya) River) (2010) country comparison to
the world: 25
Merchant marine: total: 121
by type: general cargo 3, oil tanker 10, other 108 (2018)
country comparison to the world: 77
Ports and terminals: Major seaport(s): Caspian Sea—Aqtau
(Shevchenko), Atyrau (Gur’yev) river port(s): Oskemen
(Ust-Kamenogorsk), Pavlodar, Semey (Semipalatinsk)
(Irtysh River) TRANSNATIONAL ISSUES
Disputes—International: in January 2019, the Kyrgyz Republic
ratified the demarcation agreement of the Kazakh-Kyrgyz
border; the demarcation of the Kazakh-Uzbek borders is
ongoing; the ongoing demarcation with Russia began in
2007; demarcation with China completed in 2002
Refugees and internally displaced persons: stateless
persons: 7,690 (2018)
Ilicit drugs: Significant illicit cultivation of cannabis for CIS
markets, as well as limited cultivation of opium poppy and
ephedra (for the drug ephedrine); limited government
eradication of illicit crops; transit point for Southwest Asian
narcotics bound for Russia and the rest of Europe;
significant consumer of opiates KENYA
< SOMALIA
&
© KENYA
Idoret pounr Meru
eKisumu_— Kenya, *
*
Nakuru” HiGHLANDS
NAIROBI
iS *
*Machakos
&
£
TANZANIA
0 100 =200km
at,
0 100 200 mi
Military expenditures:
1.3% of GDP (2019)
1.22% of GDP (2018)
1.32% of GDP (2017)
1.32% of GDP (2016)
1.32% of GDP (2015)
country comparison to the world: 94
Military and security forces: Kenya Defence Forces: Kenya Army,
Kenya Navy, Kenya Air Force (2019) note: the National
Police Service includes a paramilitary General Service Unit
Military service age and obligation: 18-26 years of age for male
and female voluntary service (under 18 with parental
consent), with a 9-year obligation (7 years for Kenyan
Navy) and subsequent 3-year reenlistments; applicants
must be Kenyan citizens and provide a national identity
card (obtained at age 18) and a school-leaving certificate,
and undergo a series of mental and physical examinations;
women serve under the same terms and conditions as men;
mandatory retirement at age 55 but personnel leaving
before this age remain in a reserve status until they reach
age 55 unless they were removed for disciplinary reasons;
there is no active military reserve, although the Ministry of
Defence has stated its desire to create one as recently as
2017 (2019) Maritime threats: The International Maritime
Bureau reports that shipping in territorial and offshore
waters in the Indian Ocean remain at risk for piracy and
armed robbery against ships, especially as Somali-based
pirates extend their activities south; numerous commercial
vessels have been attacked and hijacked both at anchor
and while underway; crews have been robbed and stores or
cargoes stolen.
Military—note: The Kenya Coast Guard Service (established
2018) is separate from the Defence Forces, but led by a
military officer and comprised of personnel from the
military, as well as the National Police Service, intelligence
services, and other government agencies. (2019)
Military and security forces: No regular military forces
(establishment prevented by the constitution); Police Force
(2011) Military—note: Kiribati does not have military forces;
defense assistance is provided by Australia and NZ
Military and security forces: Korean People’s Army (KPA): KPA
Ground Forces, KPA Navy, KPA Air Force (includes air
defense), KPA Strategic Force (missile forces); Guard
Command (protects the Kim family, other senior North
Korean leadership figures, and government facilities in
Pyongyang); Ministry of Public Security: Border Guards,
civil security forces (2019) Military service age and obligation: 17
years of age for compulsory male and female military
service; service obligation 10 years for men, to age 23 for
women (2015) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 17
(2015)
annual passenger traffic on registered air Carriers: 223,418
(2015)
annual freight traffic on registered air carriers: 1,574,719
mt-km (2015)
Civil aircraft registration country code prefix: P (2016)
Airports: 82 (2013)
country comparison to the world: 67
Airports—with paved runways:
total: 39 (2017)
over 3,047 m: 3 (2017)
2,438 to 3,047 m: 22 (2017)
1,524 to 2,437 m: 8 (2017)
914 to 1,523 m: 2 (2017)
under 914 m: 4 (2017)
Airports—with unpaved runways:
total: 43 (2013)
2,438 to 3,047 m: 3 (2013)
1,524 to 2,437 m: 17 (2013)
914 to 1,523 m: 15 (2013)
under 914 m: 8 (2013)
Heliports: 23 (2013)
Pipelines: 6 km oil (2013)
Railways: total: 7,435 km (2014)
standard gauge: 7,435 km 1.435-m gauge (5,400 km
electrified) (2014)
note: figures are approximate; some narrow-gauge railway
also exists
country comparison to the world: 29
Roadways: total: 25,554 km (2006)
paved: 724 km (2006)
unpaved: 24,830 km (2006)
country comparison to the world: 102
Waterways: 2,250 km (most navigable only by small craft)
(2011)
country comparison to the world: 37
Merchant marine: total: 274
by type: bulk carrier 8, container ship 5, general cargo 198,
oil tanker 31, other 32 (2018) country comparison to the
world: 52
Ports and terminals: Major seaport(s): Ch’ongjin, Haeju,
Hungnam, Namp’o, Songnim, Sonbong (formerly Unggi),
Wonsan TRANSNATIONAL ISSUES
Disputes—International: risking arrest, imprisonment, and
deportation, tens of thousands of North Koreans cross into
China to escape famine, economic privation, and political
oppression; North Korea and China dispute the sovereignty
of certain islands in Yalu and Tumen Rivers; Military
Demarcation Line within the 4-km-wide Demilitarized Zone
has separated North from South Korea since 1953; periodic
incidents in the Yellow Sea with South Korea which claims
the Northern Limiting Line as a maritime boundary; North
Korea supports South Korea in rejecting Japan’s claim to
Liancourt Rocks (Tok-do/Take-shima) Refugees and internally
displaced persons: JDPs: undetermined (periodic flooding and
famine during mid-1990s) (2017) Trafficking in persons:
current situation: North Korea is a source country for men,
women, and children who are subjected to forced labor and
sex trafficking; many North Korean workers recruited to
work abroad under bilateral contracts with foreign
governments, most often Russia and China, are subjected
to forced labor and do not have a choice in the work the
government assigns them, are not free to change jobs, and
face government reprisals if they try to escape or complain
to outsiders; tens of thousands of North Koreans, including
children, held in prison camps are subjected to forced
labor, including logging, mining, and farming; many North
Korean women and girls, lured by promises of food, jobs,
and freedom, have migrated to China illegally to escape
poor social and economic conditions only to be forced into
prostitution, domestic service, or agricultural work through
forced marriages tier rating: Tier 3—North Korea does not
fully comply with minimum standards for the elimination of
trafficking and is not making significant efforts to do so; the
government continued to participate in human trafficking
through its use of domestic forced labor camps and the
provision of forced labor to foreign governments through
bilateral contracts; officials did not demonstrate any efforts
to address human _ trafficking through prosecution,
protection, or prevention measures; no known
investigations, prosecutions, or convictions of trafficking
offenders or officials complicit in _ trafficking-related
offenses were conducted; the government also made no
efforts to identify or protect trafficking victims and did not
permit NGOs to assist victims (2015) Illicit drugs: at present
there is insufficient information to determine the current
level of involvement of government officials in the
production or trafficking of illicit drugs, but for years, from
the 1970s into the 2000s, citizens of the Democratic
People’s Republic of (North) Korea (DPRK), many of them
diplomatic employees of the government, were
apprehended abroad while trafficking in narcotics; police
investigations in Taiwan and Japan in recent years have
linked North Ksorea to large illicit shipments of heroin and
methamphetamine
KOREA, SOUTH
NORTH KOREA _
100 mi
“oO ff Gangneung
(Kangning)
SEOUL * men
Incheon, *
(Inchrdn)®.
wDonghae 9"?
hae)
Wo nj lu {Tong )
Suwon
Daejeon
(Taejon)
(Kwang WM),
(Mokpo j
Military expenditures:
2.62% of GDP (2018)
2.7% of GDP (2017)
2.3% of GDP (2016)
2.3% of GDP (2015)
2.64% of GDP (2014)
country comparison to the world: 31
Military and security forces: Republic of Korea Army (ROKA),
Navy (ROKN, includes Marine Corps, ROKMC), Air Force
(ROKAF); Military reserves include Mobilization Reserve
Forces (First Combat Forces) and Homeland Defense
Forces (Regional Combat Forces); Ministry of Maritime
Affairs and Fisheries: Korea Coast Guard (2019) Military
service age and obligation: 18-28 years of age for compulsory
military service; minimum conscript service obligation
varies by service- 21 months (Army, Marines), 23 months
(Navy), 24 months (Air Force); 18-26 years of age for
voluntary military service; women, in service since 1950,
are able to serve in all branches (2019) note: South Korea
intends to reduce the length of military service to 18-22
months by 2022
Military and security forces: Armed Forces of Turkmenistan:
National Army, Navy, Air and Air Defense Forces; Federal
Border Guard Service (2019) Military service age and obligation:
18-27 years of age for compulsory male military service; 2-
year conscript service obligation; 20 years of age for
voluntary service; males may enroll in military schools from
age 15 (2013) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 23 (2015) annual passenger traffic on registered
air carriers: 2,138,389 (2015) annual freight traffic on
registered air carriers: 0 mt-km (2015) Civil aircraft
registration country code prefix: EZ (2016) Airports: 26 (2013)
country comparison to the world: 127
Airports—with paved runways:
total: 21 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 9 (2013)
1,524 to 2,437 m: 9 (2013)
914 to 1,523 m: 2 (2013)
Airports—with unpaved runways:
total: 5 (2013)
1,524 to 2,437 m: 1 (2013)
under 914 m: 4 (2013)
Heliports: 1 (2013)
Pipelines: 7500 km gas, 1501 km oil (2013)
Railways: total: 5,113 km (2017) broad gauge: 5,113 km
1.520-m gauge (2017)
country comparison to the world: 38
Roadways: total: 58,592 km (2002) paved: 47,577 km (2002)
unpaved: 11,015 km (2002)
country comparison to the world: 77
Waterways: 1,300 km (Amu Darya River and Kara Kum Canal
are important inland waterways) (2011) country
comparison to the world: 55
Merchant marine: total: 72
by type: general cargo 9, oil tanker 8, other 55 (2018)
country comparison to the world: 101
Ports and terminals: major seaport(s): Caspian Sea—
Turkmenbasy TRANSNATIONAL ISSUES
Disputes—international: Cotton monoculture in Uzbekistan and
Turkmenistan creates water-sharing difficulties for Amu
Darya river states; field demarcation of the boundaries with
Kazakhstan commenced in 2005; bilateral talks continue
with Azerbaijan on dividing the seabed and contested
oilfields in the middle of the Caspian Refugees and
internally displaced persons: stateless persons: 4,714
(2018) Trafficking in persons: Current situation: Turkmenistan
is a source country for men, women, and children subjected
to forced labor and sex trafficking; Turkmenistanis who
migrate abroad are forced to work in the textile,
agriculture, construction, and domestic service industries,
while women and girls may also be sex trafficked; in 2014,
men surpassed women as victims; Turkey and Russia are
primary trafficking destinations, followed by the Middle
East, South and Central Asia, and other parts of Europe;
Turkmenistanis also experience forced labor domestically
in the informal construction industry; participation in the
cotton harvest is still mandatory for some public sector
employees tier rating: Tier 2 Watch List - Turkmenistan does
not fully comply with the minimum standards for the
elimination of trafficking; however, it is making significant
efforts to do so; in 2014, Turkmenistan was granted a
waiver from an otherwise required downgrade to Tier 3
because its government has a written plan that, if
implemented, would constitute making significant efforts to
bring itself into compliance with the minimum standards
for the elimination of trafficking; the government made
some progress in its law enforcement efforts in 2014,
convicting more offenders than in 2013; authorities did not
make adequate efforts to identify and protect victims and
did not fund international organizations or NGOs that
offered protective services; some victims were punished for
crimes as a result of being trafficked (2015) mlicit drugs:
transit country for Afghan narcotics bound for Russian and
Western European markets; transit point for heroin
precursor chemicals bound for Afghanistan TURKS AND
CAICOS ISLANDS
Kew, Bottle Creek
. Middle Caic
Providenciales
Providenciales
West
Caicos
Military—note: defense is the responsibility of the UK
Military and security forces: NO regular military forces; Tuvalu
Police Force (2012) TRANSPORTATION
Civil aircraft registration country code prefix: [2 (2016) Airports: 1
(2013)
country comparison to the world: 237
Airports—with unpaved runways:
total: 1 (2013)
1,524 to 2,437 m: 1 (2013)
Roadways: total: 8 km (2011)
paved: 8 km (2011)
country comparison to the world: 214
Merchant marine: total: 254
by type: bulk carrier 24, container ship 1, general cargo 41,
oil tanker 25, other 163 (2018) country comparison to the
world: 58
Ports and terminals: major seaport(s): Funafuti
Military expenditures:
4% of GDP (2018)
3.5% of GDP (2010)
country comparison to the world: 11
Military and security forces: Armed Forces of Uzbekistan: Army,
Air and Air Defense Forces; National Guard; Ministry of
Internal Affairs: Internal Security Troops (2019) Military
service age and obligation: 18-27 years of age for compulsory
military service; 1-year conscript service obligation for
males (conscripts have the option of paying for a shorter
service of one month while remaining in the reserves until
the age of 27); Uzbek citizens who have completed their
service terms in the armed forces have privileges in
employment and admission to higher educational
institutions (2016) TRANSPORTATION
National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 29 (2015)
annual passenger traffic on registered air Carriers:
2,486,673 (2015)
annual freight traffic on _ registered air _ carriers:
114,334,520 mt-km (2015)
Civil aircraft registration country code prefix: UK (2016)
Airports: 53 (2013)
country comparison to the world: 88
Airports—with paved runways:
total: 33 (2013)
over 3,047 m: 6 (2013)
2,438 to 3,047 m: 13 (2013)
1,524 to 2,437 m: 6 (2013)
914 to 1,523 m: 4 (2013)
under 914 m: 4 (2013)
Airports—with unpaved runways:
total: 20 (2013)
2,438 to 3,047 m: 2 (2013)
under 914 m: 18 (2013)
Pipelines: 13,700 km gas, 944 km oil (2016)
Railways: total: 4,642 km (2018)
broad gauge: 4,642 km 1.520-m gauge (1,684 km
electrified) (2018)
country comparison to the world: 42
Roadways: total: 86,496 km (2000)
paved: 75,511 km (2000)
unpaved: 10,985 km (2000)
country comparison to the world: 57
Waterways: 1,100 km (2012)
country comparison to the world: 62
Ports and terminals: river port(s): Termiz (Amu Darya)','e4730c5d04dbbffb1738de8d26973eff2bfe799effa3887fe3504d997a01c68d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17725d6f9f6801061019351e520b42206a8b4b1ba46e975b48263ac257b9b244',2020,'RS','Serbia','military-and-security',647,'Military expenditures:
0.8% of GDP (2018)
0.8% of GDP (2017)
0.77% of GDP (2016)
0.78% of GDP (2015)
0.73% of GDP (2014)
country comparison to the world: 130
Military and security forces: in December 2018, Kosovo adopted
a legislative package to initiate a ten-year transition of the
Kosovo Security Force (KSF) into a professional multi-
ethnic force with a limited territorial defense mandate
(2019) TRANSPORTATION
Civil aircraft registration country code prefix: Z6 (2016)
Airports: 6 (2013)
country comparison to the world: 173
Airports—with paved runways:
total: 3 (2019)
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1
Airports—with unpaved runways:
total: 3 (2013)
under 914 m: 3 (2013)
Heliports: 2 (2013)
Railways: total: 333 km (2015)
standard gauge: 333 km 1.435-m gauge (2015)
country comparison to the world: 120
Roadways: total: 2,012 km (2015)
paved: 1,921 km (includes 78 km of expressways) (2015)
unpaved: 91 km (2015)
country comparison to the world: 168
Military expenditures:
1.39% of GDP (2018 est.)
1.34% of GDP (2017 est.)
1.25% of GDP (2016)
1.41% of GDP (2015)
1.49% of GDP (2014)
country comparison to the world: 83
Military and security forces: Serbian Armed Forces (Vojska
Srbije, VS): Land Forces (includes Riverine Component,
consisting of a river flotilla on the Danube), Air and Air
Defense Forces; Ministry of Interior: Gendarmerie (2019)
Military service age and obligation: 18 years of age for voluntary
military service; conscription abolished December 2010
(2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 21 (2015)
annual passenger traffic on registered air Carriers:
2,424,886 (2015)
annual freight traffic on registered air carriers: 2.748
million mt-km (2015)
Civil aircraft registration country code prefix: YU (2016)
Airports: 26 (2013)
country comparison to the world: 126
Airports—with paved runways:
total: 10 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 3 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 2 (2017)
Airports—with unpaved runways:
total: 16 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 10 (2013)
under 914 m: 5 (2013)
Heliports: 2 (2012)
Pipelines: 1936 km gas, 413 km oil
Railways: total: 3,809 km (2015)
standard gauge: 3,809 km 1.435-m gauge (3,526 km one-
track lines and 283 km double-track lines) out of which
1,279 km electrified (1,000 km one-track lines and 279 km
double-track lines) (2015) country comparison to the world:
53
Roadways: total: 44,248 km (2016)
paved: 28,000 km (16,162 km state roads, out of which 741
km highways) (2016)
unpaved: 16,248 km (2016)
country comparison to the world: 85
Waterways: 587 km (primarily on the Danube and Sava
Rivers) (2009)
country comparison to the world: 80
Ports and terminals: river port(s): Belgrade (Danube)','e5d537b5a861bb9fff5969fa66bea31454d2e82ec0ca02fa92cd572517eba27b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f1f0a1db0e85d5a06c789064f2af0dcb884f9b19b5c062724444bdbc6e89572',2020,'KW','Kuwait','military-and-security',657,'Military expenditures:
5.06% of GDP (2018)
5.64% of GDP (2017)
5.81% of GDP (2016)
5.01% of GDP (2015)
3.59% of GDP (2014)
country comparison to the world: 5
Military and security forces: Kuwaiti Armed Forces: Kuwaiti
Land Forces (KLF), Kuwaiti Navy (includes Coast Guard),
Kuwaiti Air Force (Al-Quwwat al-Jawwiya al-Kuwaitiya;
includes Kuwaiti Air Defense Force, KADF), Kuwaiti
National Guard (KNG) (2019) Military service age and obligation:
17-21 years of age for voluntary military service; Kuwait
reintroduced one-year mandatory service for men aged 18-
35 in May 2017 after having suspended conscription in
2001; service is divided in two phases—four months for
training and eight months for military service (2018)
Military expenditures:
1.57% of GDP (2018)
1.67% of GDP (2017)
1.77% of GDP (2016)
1.75% of GDP (2015)
1.71% of GDP (2014)
country comparison to the world: 73
Military and security forces: Kyrgyz Armed Forces: Land Forces,
Air Defense Forces, National Guard, and State Border
Service (2019) Military service age and obligation: 18-27 years of
age for compulsory or voluntary male military service in the
Armed Forces or Interior Ministry; 1-year service obligation
(9 months for university graduates), with optional fee-based
3-year service in the call-up mobilization reserve; women
may volunteer at age 19; 16-17 years of age for military
cadets, who cannot take part in military operations (2016)
Military expenditures:
0.19% of GDP (2013)
0.2% of GDP (2012)
0.21% of GDP (2011)
note: no public figures available for 2014-2019
country comparison to the world: 156
Military and security forces: Lao People’s Armed Forces (LPAF):
Lao People’s Army (LPA, includes Riverine Force), Air
Force, Self-Defense Militia Forces (2019) Military service age
and obligation: 18 years of age for compulsory or voluntary
military service; conscript service obligation—minimum 18
months (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 11
(2015)
annual passenger traffic on registered air Carriers:
1,181,187 (2015)
annual freight traffic on registered air carriers: 1,356,497
mt-km (2015)
Civil aircraft registration country code prefix: RDPL (2016)
Airports: 41 (2013)
country comparison to the world: 104
Airports—with paved runways:
total: 8 (2017)
2,438 to 3,047 m: 3 (2017)
1,524 to 2,437 m: 4 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 33 (2013)
1,524 to 2,437 m: 2 (2013)
914 to 1,523 m: 9 (2013)
under 914 m: 22 (2013)
Pipelines: 540 km refined products (2013)
Roadways: total: 39,586 km (2009)
paved: 5,415 km (2009)
unpaved: 34,171 km (2009)
country comparison to the world: 89
Waterways: 4,600 km (primarily on the Mekong River and its
tributaries; 2,900 additional km are _ intermittently
navigable by craft drawing less than 0.5 m) (2012) country
comparison to the world: 23
Merchant marine: tota/: 1
by type: general cargo 1 (2017)
country comparison to the world: 172','cc87332de301eb61a10539661322b12086ef4a8cd38f8391666fd9000e51855c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08a73ea8154654458fd573a49d71fac2bfe03d50207a87078ba44d4aa17fed29',2020,'BY','Belarus','military-and-security',666,'Military expenditures:
2.01% of GDP (2019 est.)
2.08% of GDP (2018)
1.59% of GDP (2017)
1.45% of GDP (2016)
1.04% of GDP (2015)
country comparison to the world: 51
Military and security forces: National Armed Forces (Nacionalie
Brunotie Speki): Land Forces (Latvijas Sauszemes Speki),
Naval Force (Latvijas Juras Speki, includes Coast Guard
(Latvijas Kara Flote)), Air Force (Latvijas Gaisa Speki),
National Guard (2019) Military service age and obligation: 18
years of age for voluntary male and female military service;
no conscription; under current law, every citizen is entitled
to serve in the armed _ forces for life (2017)','b8dfe8088b90ac04733507cc5f22d79627577361a99a54192381ceff26d46f7b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2826fbd5acaaf367b84a307c6373d95ad5f81817ed8d4917d91fb2dc816b07c',2020,'LB','Lebanon','military-and-security',671,'Military expenditures:
4.99% of GDP (2018)
4.6% of GDP (2017)
5.17% of GDP (2016)
4.53% of GDP (2015)
4.75% of GDP (2014)
country comparison to the world: 6
Military and security forces: Lebanese Armed Forces (LAF):
Army Command (includes Presidential Guard Brigade, Land
Border Regiments), Naval Forces, Air Forces; Lebanese
Internal Security Forces Directorate (includes Mobile
Gendarmerie); Directorate for General Security (DGS);
Directorate General for State Security (2019) Military service
age and obligation: 17-25 years of age for voluntary military
service (including women); no conscription (2019) Military—
note: the United Nations Interim Force In Lebanon (UNIFIL)
has operated in the country since 1978, originally under
UNSCRs 425 and 426 to confirm Israeli withdrawal from
Lebanon, restore international peace and security and
assist the Lebanese Government in restoring its effective
authority in the area; following the July-August 2006 war,
the UN _ Security Council adopted resolution 1701
enhancing UNIFIL and deciding that in addition to the
original mandate, it would, among other things, monitor
the cessation of hostilities; accompany and support the
Lebanese Armed Forces (LAF) as they deploy throughout
the south of Lebanon; and extend its assistance to help
ensure humanitarian access to civilian populations and the
voluntary and safe return of displaced persons; UNIFIL had
about 11,000 personnel deployed in the country as of
October 2019 (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 21
(2015)
annual passenger traffic on registered air Carriers:
2,983,274 (2015)
annual freight traffic on registered air carriers: 53,902,026
mt-km (2015)
Civil aircraft registration country code prefix: OD (2016)
Airports: 8 (2013)
country comparison to the world: 161
Airports—with paved runways:
total: 5 (2019)
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
under 914 m: 1
Airports—with unpaved runways:
total: 3 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 1 (2013)
Heliports: 1 (2013)
Pipelines: 88 km gas (2013)
Railways: total: 401 km (2017)
standard gauge: 319 km 1.435-m gauge (2017)
narrow gauge: 82 km 1.050-m gauge (2017)
note: rail system is still unusable due to damage sustained
from fighting in the 1980s and in 2006
country comparison to the world: 119
Roadways: total: 21,705 km (2017)
country comparison to the world: 109
Merchant marine: total: 55
by type: bulk carrier 1, container ship 1, general cargo 40,
oil tanker 1, other 12 (2018)
country comparison to the world: 112
Ports and terminals: INajor seaport(s): Beirut, Tripoli
container port(s) (TEUs): Beirut (1,305,038) (2017)','523cb54b4b26207f8e0da1aa672392db1a7e78855d2fb27572479d39ca65fc6f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dd2fcc59532b90f36c8e75f914f8ae2f048443d2fea8959572cb3533dc2d6b9',2020,'LU','Luxembourg','military-and-security',684,'Military expenditures:
0.56% of GDP (2019 est.)
0.51% of GDP (2018)
0.52% of GDP (2017)
0.4% of GDP (2016)
0.44% of GDP (2015)
country comparison to the world: 144
Military and security forces: Luxembourg Army (l’Armée
Luxembourgeoise) (2019) Military service age and obligation: 18-
26 years of age for male and female voluntary military
service; no conscription; Luxembourg citizen or EU citizen
with 3-year residence in Luxembourg = (2019)','820cbc914d355f4eee13df9d734fd26d78d63b193d0d0be52a9d5bc5e272d70b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('758c822662ee9911737b196d6dc239361304bc96f924ab5e4acd80d170d2d410',2020,'MG','Madagascar','military-and-security',692,'Military expenditures:
0.6% of GDP (2018)
0.58% of GDP (2017)
0.59% of GDP (2016)
0.6% of GDP (2015)
0.65% of GDP (2014)
country comparison to the world: 143
Military and security forces: People’s Armed _ Forces:
Intervention Force, Development Force, Navy, Air Force;
National Gendarmerie (operates under the Ministry of
Defense) (2019) Military service age and obligation: Madagascar
has an all-volunteer military; 18-25 years of age for males;
service obligation 18 months; women are permitted to
serve in all branches (2018) TRANSPORTATION
National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 11
(2015)
annual passenger traffic on registered air Carriers: 546,946
(2015)
annual freight traffic on registered air carriers: 30,512,607
mt-km (2015)
Civil aircraft registration country code prefix: 5R (2016)
Airports: 83 (2013)
country comparison to the world: 66
Airports—with paved runways:
total: 26 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 6 (2017)
914 to 1,523 m: 16 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 57 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 38 (2013)
under 914 m: 18 (2013)
Railways: total: 836 km (2018)
narrow gauge: 836 km 1.000-m gauge (2018)
country comparison to the world: 96
Roadways: total: 31,640 km (2018)
country comparison to the world: 95
Waterways: 600 km (432 km navigable) (2011)
country comparison to the world: 79
Merchant marine: total: 28
by type: general cargo 15, oil tanker 3, other 10 (2018)
country comparison to the world: 128
Ports and terminals: Major seaport(s): Antsiranana (Diego
Suarez), Mahajanga, Toamasina, Toliara (Tulear)
Military expenditures:
1.44% of GDP (2018)
1.57% of GDP (2017)
1.29% of GDP (2016)
1.21% of GDP (2015)
2.17% of GDP (2014)
country comparison to the world: 80
Military and security forces: Seychelles People’s Defence Forces
(SPDF): Army (includes infantry, Special Forces (Tazar),
and Presidential Security Unit), Coast Guard, and Air Force
(2019) Military service age and obligation: 18-28 years of age for
voluntary military service (18-25 for officers); 6-year initial
commitment; no conscription (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 3 (2015)
annual passenger traffic on registered air carriers: 497,496
(2015)
annual freight traffic on registered air carriers: 19,234,992
mt-km (2015)
Civil aircraft registration country code prefix: S7 (2016)
Airports: 14 (2013)
country comparison to the world: 150
Airports—with paved runways:
total: 7 (2019)
2,438 to 3,047 m: 1
914 to 1,523 m: 5
under 914 m:1
Airports—with unpaved runways:
total: 7 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 5 (2013)
Heliports: 1 (2013)
Roadways: total: 526 km (2015)
paved:514 km (2015)
unpaved: 12 km (2015)
country comparison to the world: 189
Merchant marine: total: 24
by type: general cargo 4, oil tanker 6, other 14 (2018)
country comparison to the world: 134
Ports and terminals: Major seaport(s): Victoria','4c99f997d5871ccf7f4126f4802f3b9b1655f24aac183c2e95b36a87cf8a66fc','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc057cdd4ea3242f46b9f9c471f9de72275f9340c6deee83ad4e4fb7db17453a',2020,'MT','Malta','military-and-security',709,'Military expenditures:
0.49% of GDP (2018)
0.51% of GDP (2017)
0.54% of GDP (2016)
0.5% of GDP (2015)
0.5% of GDP (2014)
country comparison to the world: 148
Military and security forces: Armed Forces of Malta (AFM,
includes land, maritime, and air elements, plus a Volunteer
Reserve Force) (2019) Military service age and obligation: 18-30
years of age for voluntary military service; no conscription
(2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
9 (2015) inventory of registered aircraft operated by air
carriers: 28 (2015)
annual passenger traffic on registered air Carriers:
1,583,046 (2015)
annual freight traffic on registered air carriers: 3.352
million mt-km (2015)
Civil aircraft registration country code prefix: 9H (2016)
Airports: 1 (2013)
country comparison to the world: 228
Airports—with paved runways:
total: 1 (2019)
over 3,047 m: 1
Heliports: 2 (2013)
Roadways: total: 2,254 km (2001)
paved: 1,973 km (2001)
unpaved: 281 km (2001)
urban: 1,422 km (2001)
non-urban: 832 km (2001)
country comparison to the world: 165
Merchant marine: total: 2,205
by type: bulk carrier 645, container ship 283, general cargo
288, oil tanker 391, other 598 (2018) country comparison
to the world: 11
Ports and terminals: Major seaport(s): Marsaxlokk (Malta
Freeport), Valletta container port(s) (TEUs): Marsaxlokk
(3,150,000) (2017)','eef6043a1a9956f37dee6ca70b36e917b4c0b807859208792417dffd61956ab7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6feb6a43b9bcfabd283ea45f48d40cfc8b4432ac8de0cc96bb54007a320858e',2020,'SN','Senegal','military-and-security',722,'Military expenditures:
3.02% of GDP (2018)
2.91% of GDP (2017)
2.91% of GDP (2016)
2.75% of GDP (2015)
2.7% of GDP (2014)
country comparison to the world: 24
Military and security forces: Mauritanian Armed Forces: Army,
Mauritanian Navy (Marine Mauritanienne), Islamic
Republic of Mauritania Air Group (Groupement Aerienne
Islamique de Mauritanie, GAIM); Ministry of Interior:
Gendarmerie, National Guard (2019) military service age and
obligation: 18 is the legal minimum age for voluntary military
service; no conscription (2012) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 4 (2015)
annual passenger traffic on registered air carriers: 248,158
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: DT (2016)
Airports: 30 (2013)
country comparison to the world: 115
Airports—with paved runways: total: 9 (2017)
2,438 to 3,047 m: 5 (2017)
1,524 to 2,437 m: 4 (2017)
Airports—with unpaved runways:
total: 21 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 10 (2013)
914 to 1,523 m: 8 (2013)
under 914 m: 2 (2013)
Railways: total: 728 km (2014)
standard gauge: 728 km 1.435-m gauge (2014)
country comparison to the world: 100
Roadways: total: 12,253 km (2018)
paved: 3,988 km (2018)
unpaved: 8,265 km (2018)
country comparison to the world: 128
Waterways: (Some navigation possible on the Senegal River)
(2011)
Merchant marine: total: 7
by type: bulk carrier 1, general cargo 2, oil tanker 1, other
3 (2018)
country comparison to the world: 159
Ports and terminals: Major seaport(s): Nouadhibou,
Nouakchott','1104d7d2bb4d097156ed75b12f38b3fea18c30782b00c529fb864f600e3f76c2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff02878d783b16b07528e0a4977ca7f295415c934cc5d83623a05dc228c401b9',2020,'MU','Mauritius','military-and-security',729,'Military expenditures:
0.16% of GDP (2018)
0.18% of GDP (2017)
0.19% of GDP (2016)
0.18% of GDP (2015)
0.15% of GDP (2014)
country comparison to the world: 158
Military and_ security forces: NO regular military forces;
Mauritius Police Force includes a Special Mobile Force (a
paramilitary force formed as a mobile infantry battalion)
and the National Coast Guard (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 13 (2015)
annual passenger traffic on registered air Carriers:
1,466,527 (2015)
annual freight traffic on registered air carriers: 168.773
million mt-km (2015)
Civil aircraft registration country code prefix: 3B (2016)
Airports: 5 (2013)
country comparison to the world: 181
Airports—with paved runways:
total: 2 (2019)
over 3,047 m: 1
914 to 1,523 m: 1
Airports—with unpaved runways:
total: 3 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 1 (2013)
Roadways: total: 2,428 km (2015)
paved: 2,379 km (includes 99 km of expressways) (2015)
unpaved: 49 km (2015)
country comparison to the world: 164
Merchant marine: total: 28
by type: general cargo 1, oil tanker 4, other 23 (2018)
country comparison to the world: 129
Ports and terminals: Major seaport(s): Port Louis','4e896fcb310eaa70dca07d67c3722565ea2ce3a6b79af9bf200319b169fbf8f6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4d6056bfc4ab58d908ac8ca7f6267476cc0de3b0c77560de943bb7e509d087f',2020,'MX','Mexico','military-and-security',735,'Military expenditures:
0.54% of GDP (2018)
0.47% of GDP (2017)
0.56% of GDP (2016)
0.66% of GDP (2015)
0.66% of GDP (2014)
country comparison to the world: 146
Military and security forces: Secretariat of National Defense
(Secretaria de Defensa Nacional, Sedena): Army (Ejercito),
Mexican Air Force (Fuerza Aerea Mexicana, FAM);
Secretariat of the Navy (Secretaria de Marina, Semar):
Mexican Navy (Armada de Mexico (ARM), includes Naval
Air Force (FAN), Mexican Naval Infantry Corps (Cuerpo de
Infanteria de Marina, Mexmar or CIM)); Ministry of
Security and Citizen Protection: Federal Police (includes
Gendarmerie), National Guard (2019) note: the National
Guard was formed in 2019 and consists of personnel from
the Federal Police and military police units of the Army and
Navy Military service age and obligation: 18 years of age for
compulsory military service (selection for service
determined by lottery), conscript service obligation is 12
months; 16 years of age with consent for voluntary
enlistment; cadets enrolled in military schools from the age
of 15 are considered members of the armed forces; women
are eligible for voluntary military service (2012)','3ecf235232dad1370520ef02d56599116cdd00631fbfd211bf1943d1eaca6fb8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5624bd167ce817e038f183cd0ba282e942dca35a9238d3a79f1fd0aa66d60b60',2020,'FM','Micronesia, Federated States of','military-and-security',743,'Military and security forces: no military forces; Federated States
of Micronesia National Police (2019) military—note: defense
is the responsibility of the US','e35f3a1ac16070254e7fdb64a4d10e5c0210db38d9f7f73f9951b9a9bf626d68','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4157b3bde26596da8fcfd4ada4175d307949a2bbeab5e87703fdb1b7d28caea5',2020,'UA','Ukraine','military-and-security',750,'Military expenditures:
0.35% of GDP (2018)
0.37% of GDP (2017)
0.44% of GDP (2016)
0.35% of GDP (2015)
0.35% of GDP (2014)
country comparison to the world: 152
Military and _ security forces: National Army: Land Forces
Command, Air Forces Command (includes air defense unit);
Carabinieri Troops (a component of the Ministry of Internal
Affairs that also has official status as a service of the Armed
Forces during wartime) (2019) Military service age and
obligation: 18-27 years of age for compulsory or voluntary
military service; male registration required at age 16; 1-
year service obligation (2019) note: Moldova intends to
abolish military conscription by 2021','c5b98411d3c7f9e0f4793c178109536184fbc0ed69608ceb91ebd4b0af8be21d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4bbd1d3d20ea2f06a6f6acdf98dcbe57c9cbf813f22fe60e7df1bb6a4b0addd',2020,'MC','Monaco','military-and-security',756,'Military and security forces: no regular military forces; Ministry
of Interior: Compagnie des Carabiniers du Prince (Prince’s
Company of Carabiniers (Palace Guard)), Corps des
Sapeurs-pompiers de Monaco (Fire and Emergency), Police
Department (2019) Military—note: defense is the
responsibility of France','fbd2aab8462a485b3a77bc367eb805a6ce7462292292eb4669988349af73df3a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef8638aae0da240ea9f90673621c3355781bd0f493b2db859253ac3081a3a361',2020,'MN','Mongolia','military-and-security',763,'Military expenditures:
0.68% of GDP (2018)
0.72% of GDP (2017)
0.92% of GDP (2016)
0.87% of GDP (2015)
0.86% of GDP (2014)
country comparison to the world: 137
Military and security forces: Mongolian Armed Forces (Mongol
ulsyn zevsegt huchin): Mongolian Army, Mongolian Air
Force, National Center for Emergency and Disaster Relief
(coordinates the military’s efforts as first-responders for
earthquakes, wildfires, and forest fires; contagious
diseases; and snow and dust storms as well as severe
winters (known as zud); paramilitary forces: Border
Guards, Internal Security Troops (2019) Military service age
and obligation: 18-27 years of age for compulsory and
voluntary military service; 1-year conscript service
obligation in army or air forces or police for males only;
after conscription, soldiers can contract into military
service for 2 or 4 years; citizens can also voluntarily join
the armed forces (2017) TRANSPORTATION
National air transport system:
number of registered air carriers: 3 (2015)
inventory of registered aircraft operated by air carriers: 12
(2015)
annual passenger traffic on registered air Carriers: 541,129
(2015)
annual freight traffic on registered air carriers: 7,130,148
mt-km (2015)
Civil aircraft registration country code prefix: JU (2016)
Airports: 44 (2013)
country comparison to the world: 97
Airports—with paved runways:
total: 15 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 10 (2017)
1,524 to 2,437 m: 3 (2017)
Airports—with unpaved runways:
total: 29 (2013)
over 3,047 m: 2 (2013)
2,438 to 3,047 m: 2 (2013)
1,524 to 2,437 m: 24 (2013)
under 914 m: 1 (2013)
Heliports: 1 (2013)
Railways: total: 1,815 km (2017)
broad gauge: 1,815 km 1.520-m gauge (2017)
note: national operator Ulaanbaatar Railway is jointly
owned by the Mongolian Government and by the Russian
State Railway country comparison to the world: 78
Roadways: total: 113,200 km (2017)
paved: 10,600 km (2017)
unpaved: 102,600 km (2017)
country comparison to the world: 44
Waterways: 580 km (the only waterway in operation is Lake
Hovsgol) (135 km); Selenge River (270 km) and Orhon
River (175 km) are navigable but carry little traffic; lakes
and rivers ice free from May to September) (2010) country
comparison to the world: 81
Merchant marine: total: 265
by type: bulk carrier 4, container ship 3, general cargo 107,
oil tanker 68, other 83 (2018) country comparison to the
world: 55','144e3c1d096cb810e74b9a03763b3635d129a6da641ff1460f43c19841fedbd5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fce1de09a671d4e844d112498e1704cd7943d502587cdbb8122ea8b060f052c',2020,'NR','Nauru','military-and-security',789,'Military and security forces: NO regular military forces (2019)
Military—note: Nauru maintains no defense forces; under an
informal agreement, defense is the responsibility of
Australia TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 5
(2015)
annual passenger traffic on registered air carriers: 38,858
(2015)
annual freight traffic on registered air carriers: 7,793,474
mt-km (2015)
Civil aircraft registration country code prefix: C2 (2016)
Airports: 1 (2013)
country comparison to the world: 230
Airports—with paved runways:
total: 1 (2019)
1,524 to 2,437 m: 1
Roadways: total: 30 km (2002)
paved: 24 km (2002)
unpaved: 6 km (2002)
country comparison to the world: 211
Ports and terminals: Major seaport(s): Nauru
Military—note: defense is the responsibility of the US','952ca5410795a7e4331401a7b25b13a28ff4f651d5f6da2844bc14797ebff446','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f565514697392b5bbe3fff415e8f5f8ddc64f368a379831574fa2cffccf00ef',2020,'NP','Nepal','military-and-security',795,'Military expenditures:
1.44% of GDP (2018)
1.55% of GDP (2017)
1.7% of GDP (2016)
1.56% of GDP (2015)
1.63% of GDP (2014)
country comparison to the world: 79
Military and security forces: Nepal Army (includes Air Wing);
Nepal Armed Police Force (under the Ministry of Home
Affairs; paramilitary force responsible for border and
internal security, including counter-insurgency, and
assisting the Army in the event of an external invasion)
(2019) Military service age and obligation: 18 years of age for
voluntary military service (including women); no
conscription (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
4 (2015) inventory of registered aircraft operated by air
carriers: 15 (2015)
annual passenger traffic on registered air carriers: 510,341
(2015)
annual freight traffic on registered air carriers: 4,536,371
mt-km (2015)
Civil aircraft registration country code prefix: 9N (2016)
Airports: 47 (2013)
country comparison to the world: 92
Airports—with paved runways:
total: 11 (2017)
over 3,047 m: 1 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 6 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 36 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 6 (2013)
under 914 m: 29 (2013)
Railways: total: 59 km (2018)
narrow gauge: 59 km 0.762-m gauge (2018)
country comparison to the world: 131
Roadways: total: 27,990 km (2016)
paved: 11,890 km (2016)
unpaved: 16,100 km (2016)
country comparison to the world: 98','ccf19545aa36effec1a9a5271df07750c0e76faebf9aabebbcbc39ec95dae25e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b86a1fbafd6401630083f795dd8e18b657cf48a8a63911f69ff1d1c0b3942152',2020,'NL','Netherlands','military-and-security',804,'Military expenditures:
1.36% of GDP (2019 est.)
1.21% of GDP (2018)
1.15% of GDP (2017)
1.16% of GDP (2016)
1.13% of GDP (2015)
country comparison to the world: 88
Military and security forces: Royal Netherlands Army, Royal
Netherlands Navy (includes Naval Air Service and Marine
Corps), Royal Netherlands Air Force (Koninklijke
Luchtmacht, KLu), Royal Netherlands Marechaussee
(Gendarmerie) (2019) Military service age and obligation: 17
years of age for an all-volunteer force (2016)','156b9a606b0b649c08b61339db444e28a25dc94bd66e34914ae07b8a12f0f14b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7749197712f9e28c005ebeaad704c47770732f48c18158ba3abf715c0d89fc4f',2020,'CR','Costa Rica','military-and-security',813,'Military expenditures:
0.61% of GDP (2018)
0.62% of GDP (2017)
0.64% of GDP (2016)
0.78% of GDP (2015)
0.69% of GDP (2014)
country comparison to the world: 141
Military and security forces: Army of Nicaragua (Ejercito de
Nicaragua, EN; includes Navy, Air Force) (2019) Military
service age and obligation: 18-30 years of age for voluntary
military service; no conscription; tour of duty 18-36
months; requires Nicaraguan nationality and 6th-grade
education (2017) TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 2
(2015)
annual passenger traffic on registered air carriers: 61,031
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: YN (2016)
Airports: 147 (2013)
country comparison to the world: 39
Airports—with paved runways:
total: 12 (2017)
2,438 to 3,047 m: 3 (2017)
1,524 to 2,437 m: 2 (2017)
914 to 1,523 m: 3 (2017)
under 914 m: 4 (2017)
Airports—with unpaved runways:
total: 135 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 15 (2013)
under 914 m: 119 (2013)
Pipelines: 54 km oil (2013)
Roadways: total: 23,897 km (2014)
paved: 3,346 km (2014)
unpaved: 20,551 km (2014)
country comparison to the world: 105
Waterways: 2,220 km (navigable waterways as well as the
use of the large Lake Managua and Lake Nicaragua; rivers
serve only the sparsely populated eastern part of the
country) (2011) country comparison to the world: 39
Merchant marine: total: 5
by type: general cargo 1, oil tanker 1, other 3 (2018)
country comparison to the world: 163
Ports and terminals: Najor seaport(s): Bluefields, Corinto','ef392d3c83c5bd2fa1afe8846eaa225ae4c1aa2a0a559233b478f9d830a18d5d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d29c7665236bc64704efdf3388047564ea3c0e38190005bf723ce36c28599cc9',2020,'NG','Nigeria','military-and-security',818,'Military expenditures:
2.45% of GDP (2018)
2.47% of GDP (2017)
2.22% of GDP (2016)
1.78% of GDP (2014)
1.38% of GDP (2013)
country comparison to the world: 34
Military and security forces: Nigerien Armed Forces (Forces
Armees Nigeriennes, FAN): Army, Nigerien Air Force
(Force Aerienne du Niger), Niger Gendarmerie (GN);
Ministry of Interior: Niger National Guard (GNN) (2019)
Military service age and obligation: 18 is the legal minimum age
for compulsory or voluntary military service; enlistees must
be Nigerien citizens and unmarried; 2-year service term;
women may serve in health care (2017) TRANSPORTATION
National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 2 (2015)
annual passenger traffic on registered air carriers: 15,242
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: 5U (2016)
Airports: 30 (2013)
country comparison to the world: 116
Airports—with paved runways:
total: 10 (2017)
2,438 to 3,047 m: 3 (2017)
1,524 to 2,437 m: 6 (2017)
914 to 1,523 m: 1 (2017)
Airports—with unpaved runways:
total: 20 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 15 (2013)
under 914 m: 2 (2013)
Heliports: 1 (2013)
Pipelines: 464 km oil
Roadways: total: 18,949 km (2010)
paved: 3,912 km (2010)
unpaved: 15,037 km (2010)
country comparison to the world: 116
Waterways: 300 km (the Niger, the only major river, is
navigable to Gaya between September and March) (2012)
country comparison to the world: 93
Merchant marine: total: 1
by type: other 1 (2018)
country comparison to the world: 174
Military expenditures:
0.51% of GDP (2018)
0.43% of GDP (2017)
0.43% of GDP (2016)
0.42% of GDP (2015)
0.42% of GDP (2014)
country comparison to the world: 147
Military and security forces: Nigerian Armed Forces: Army,
Navy (includes Coast Guard), Air Force; Ministry of
Interior: Nigeria Security and Civil Defence Corps (NSCDC,
a paramilitary agency commissioned to assist the military
in the management of threats to internal security, including
attacks and natural disasters) (2019) Military service age and
obligation: 18 years of age for voluntary military service; no
conscription (2012) Maritime threats: the International
Maritime Bureau reports the territorial and offshore waters
in the Niger Delta and Gulf of Guinea as very high risk for
piracy and armed robbery of ships; in 2018, 48 commercial
vessels were boarded or attacked compared with 33
attacks in 2017; in 2018, 29 ships were boarded eight of
which were underway, 12 were fired upon, and 78 crew
members were abducted; Nigerian pirates have extended
the range of their attacks to as far away as Cote d''Ivoire
and as far as 170 nm offshore; the Maritime Administration
of the US Department of Transportation has issued a
Maritime Advisory (2019-010-Gulf of Guinea-Piracy/Armed
Robbery/Kidnapping for Ransom) effective 19 July 2019,
which states in part “Piracy, armed robbery, and
kidnapping for ransom (KFR) continue to serve as
significant threats to U.S. flagged vessels transiting or
operating in the Gulf of Guinea (GoG). ...According to the
Office of Naval Intelligence’s “Weekly Piracy Reports” 72
reported incidents of piracy and armed robbery at sea
occurred in the GoG region this year as of July 9, 2019.
Attacks, kidnappings for ransom (KFR), and boardings to
steal valuables from the ships and crews are the most
common types of incidents with approximately 75 percent
of all incidents taking place off Nigeria. During the first six
months of 2019, there were 15 kidnapping and 3 hijackings
in the GoG.”','4298985c64640647a3bcbed80c7e56098e12926b8f27bae9fbcc5f5a797bbd84','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f5e193d3215c7da7347d9ead11a9ef8a3132fd6b50d3a0aa8a251fab59220d2',2020,'TO','Tonga','military-and-security',825,'Military and security forces: NO regular indigenous military
forces; Police Force (2019)
Military—note: defense is the responsibility of New Zealand','e0b80c0dd83cf5162260e699125070ffc83604a60a635d26f8bf5d85cac055cf','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6adf410d518a644e0df8774e591bec075d3d1afdf0d936fe8c5392d11a0d573e',2020,'PA','Panama','military-and-security',842,'Military and_ security forces: NO regular military forces;
Panamanian Public Security Forces (subordinate to the
Ministry of Public Security), comprising the National Police
(PNP), National Air-Naval Service (SENAN), National
Border Service (SENAFRONT) (2019) note: on 10 February
1990, the government of then President Guillermo
ENDARA abolished Panama’s military and reformed the
security apparatus by creating the Panamanian Public
Forces; in October 1994, Panama’s National Assembly
approved a constitutional amendment prohibiting the
creation of a standing military force but allowing the
temporary establishment of special police units to counter
acts of “external aggression”','3975502b56fa15926397b8441365a64136093021ac4528e16bcce68602e40527','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e52ed2a2d0a2cddd0d609004a1eee3387178db8b94a3cb669642ffd076e68d7',2020,'EC','Ecuador','military-and-security',846,'Iquitosy
Talara,
“Piura Yugimaguas
Chiclayo®, ¥
Trujillo. {Pucallpa
Chimbote® “An
Hudnuéo
LIMA
Callao®™ —“Huancayo
S
Cc “Puerto
ica eee Maldonado
fsouivi A
Arequipa *\\)
.
Matarani*
Tacnae
CHIL
Military expenditures:
1.19% of GDP (2018)
1.24% of GDP (2017)
1.3% of GDP (2016)
1.72% of GDP (2015)
1.59% of GDP (2014)
country comparison to the world: 109
Military and security forces: Peruvian Army (Ejercito del Peru),
Peruvian Navy (Marina de Guerra del Peru, MGP, includes
naval air, naval infantry, and Coast Guard), Air Force of
Peru (Fuerza Aerea del Peru, FAP); Ministry of the Interior
(Ministerio del Interior): Peruvian National Police (Policia
Nacional del Peru, PNP) (2019) Military service age and
obligation: 18-50 years of age for male and 18-45 years of
age for female voluntary military service; no conscription
(2013) Maritime threats: the International Maritime Bureau
reports the territorial waters of Peru are a risk for armed
robbery against ships; in 2018, four attacks against
commercial vessels were reported, a slight increase from
the two reported in 2017; most of these occured in the
main port of Callao TRANSPORTATION
National air transport system: number of registered air Carriers:
7 (2015) inventory of registered aircraft operated by air
carriers: 35 (2015)
annual passenger traffic on registered air Carriers:
13,907,948 (2015)
annual freight traffic on _ registered air _ carriers:
223,643,434 mt-km (2015)
Civil aircraft registration country code prefix: OB (2016)
Airports: 191 (2013)
country comparison to the world: 30
Airports—with paved runways:
total: 59 (2017)
over 3,047 m: 5 (2017)
2,438 to 3,047 m: 21 (2017)
1,524 to 2,437 m: 16 (2017)
914 to 1,523 m: 12 (2017)
under 914 m: 5 (2017)
Airports—with unpaved runways:
total: 132 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 19 (2013)
914 to 1,523 m: 30 (2013)
under 914 m: 82 (2013)
Heliports: 5 (2013)
Pipelines: 786 km extra heavy crude, 1526 km gas, 679 km
liquid petroleum gas, 1033 km oil, 15 km refined products
(2013) Railways: total: 1,854 km (2014)
standard gauge: 1,730.4 km 1.435-m gauge (34 km
electrified) (2014)
narrow gauge: 124 km 0.914-m gauge (2014)
country comparison to the world: 76
Roadways: total: 140,672 km (18,699 km paved) (2012)
note: includes 24,593 km of national roads (14,748 km
paved), 24,235 km of departmental roads (2,340 km
paved), and 91,844 km of local roads (1,611 km paved)
country comparison to the world: 36
Waterways: 8,808 km (8,600 km of navigable tributaries on
the Amazon River system and 208 km on Lago Titicaca)
(2011) country comparison to the world: 14
Merchant marine: total: 95
by type: container ship 2, oil tanker 13, other 80 (2018)
country comparison to the world: 90
Ports and terminals: Major seaport(s): Callao, Matarani, Paita
oil terminal(s): Conchan oil terminal, La Pampilla oil terminal
container port(s) (TEUs): Callao (2,250,200) (2017)
river port(s): Iquitos, Pucallpa, Yurimaguas (Amazon)','01ce63658633768f50e33328a7ef44d42f33365ab88e640de782667834924bd1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c1b1b1a185607b84162ce474be18aa25a056f4c0175ffbc6f54ebf0fe9597fb',2020,'PH','Philippines','military-and-security',860,'Military expenditures:
1.13% of GDP (2018)
1.2% of GDP (2017)
1.43% of GDP (2016)
1.14% of GDP (2015)
1.09% of GDP (2014)
country comparison to the world: 111
Military and security forces: Armed Forces of the Philippines
(AFP): Army, Navy (includes Marine Corps), Air Force
(2019) note: the Philippine Coast Guard is an armed and
uniformed service under the Department of Transportation;
it would be attached to the AFP in wartime; the Philippine
National Police Force (PNP) falls under the Ministry of
Interior and Local Government Military service age and
obligation: 18-23 years of age (officers 21-29) for voluntary
military service; no conscription (2019) Maritime threats: the
International Maritime Bureau reports the territorial and
offshore waters in the South China Sea as high risk for
piracy and armed robbery against ships; during 2018, 10
attacks were reported in and around the Philippines
including six ships that were boarded, one fired upon, and
three crewman kidnapped for ransom; an emerging threat
area lies in the Celebes and Sulu Seas between the
Philippines and Malaysia where it is believed the pirates
involved are associated with the Abu Sayyaf Group (ASG)
terrorist organization; numerous commercial vessels have
been attacked and hijacked both at anchor and while
underway; hijacked vessels are often disguised and cargo
diverted to ports in East Asia; crews have been murdered
or cast adrift; the Maritime Administration (MARAD) of the
US Department of Transportation has issued a Maritime
Advisory (2019-011-Sulu and Celebes Seas-Piracy/Armed
Robbery/Terrorism) which states in part “In 2018, there
were at least 12 reported boardings, attempted boardings,
attacks, hijackings, and kidnappings in the Sulu and
Celebes Seas. Recent kidnapping incidents in this area
were reportedly linked to the Abu Sayyaf Group (ASG), a
violent Islamic separatist group operating in the southern
Philippines...” and advises ships to adhere to counter-piracy
practices to minimize risk TRANSPORTATION
National air transport system: number of registered air Carriers:
11 (2015)
inventory of registered aircraft operated by air carriers:
158 (2015)
annual passenger traffic on registered air Carriers:
32,230,986 (2015)
annual freight traffic on _ registered air
484,190,968 mt-km (2015)
Civil aircraft registration country code prefix: RP (2016)
Airports: 247 (2013)
country comparison to the world: 24
Airports—with paved runways:
total: 89 (2019)
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m: 33
914 to 1,523 m: 34
under 914 m:10
Airports—with unpaved runways:
total: 158 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 56 (2013)
under 914 m: 99 (2013)
Heliports: 2 (2013)
carriers:
Pipelines: 530 km gas, 138 km oil (non-operational), 185 km
refined products (2017)
Railways: total: 77 km (2017)
standard gauge: 49 km 1.435-m gauge (2017)
narrow gauge: 28 km 1.067-m gauge (2017)
country comparison to the world: 129
Roadways: total: 216,387 km (2014)
paved: 61,093 km (2014)
unpaved: 155,294 km (2014)
country comparison to the world: 25
Waterways: 3,219 km (limited to vessels with draft less than
1.5 m) (2011)
country comparison to the world: 30
Merchant marine: total: 1,615
by type: bulk carrier 58, container ship 43, general cargo
654, oil tanker 191, other 669 (2018)
country comparison to the world: 16
Ports and terminals: Major seaport(s): Batangas, Cagayan de
Oro, Cebu, Davao, Liman, Manila container port(s) (TEUs):
Manila (4,782,240) (2017)
Military—note: defense is the responsibility of the UK','c38a8ff8706a2f27cddda1a5088219f617ac147af01836e47d5063dff864ebbb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5de18832be877a22d3cf0eb5e411e63b7e719dbf82eb87f4c6742f9e0f01d1f',2020,'PL','Poland','military-and-security',872,'Military expenditures:
2% of GDP (2019 est.)
2.02% of GDP (2018)
1.89% of GDP (2017)
1.99% of GDP (2016)
2.22% of GDP (2015)
country comparison to the world: 52
Military and security forces: Polish Armed Forces: Land Forces
(Wojska Ladowe), Navy (Marynarka Wojenna), Air Force
(Sily Powietrzne), Special Forces (Wojska Specjalne),
Territorial Defense Force (Wojska Obrony Terytorialnej)
(2019) note: Territorial Defense Force only began
recruitment in winter 2016
Military service age and obligation: 18-28 years of age for male
and female voluntary military service; conscription phased
out in 2009-12; professional soldiers serve on a permanent
basis (for an unspecified period of time) or on a contract
basis (for a specified period of time); initial contract period
is 24 months; women serve in the military on the same
terms as men (2019) Military—note: Coast guard duties fall
under the Border Guard, which is controlled by the
Ministry of the Interior (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
6 (2015)
inventory of registered aircraft operated by air carriers: 92
(2015)
annual passenger traffic on registered air Carriers:
4,841,128 (2015)
annual freight traffic on _ registered air _ carriers:
120,016,466 mt-km (2015)
Civil aircraft registration country code prefix: SP (2016)
Airports: 126 (2013)
country comparison to the world: 47
Airports—with paved runways:
total: 87 (2017)
over 3,047 m: 5 (2017)
2,438 to 3,047 m: 30 (2017)
1,524 to 2,437 m: 36 (2017)
914 to 1,523 m: 10 (2017)
under 914 m: 6 (2017)
Airports—with unpaved runways:
total: 39 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 17 (2013)
under 914 m: 21 (2013)
Heliports: 6 (2013)
Pipelines: 14198 km gas, 1374 km oil, 2483 km refined
products (2016)
Railways: total: 19,231 km (2016)
standard gauge: 18,836 km 1.435-m gauge (11,874 km
electrified) (2016)
broad gauge: 395 km 1.524-m gauge (2016)
country comparison to the world: 16
Roadways: total: 420,000 km (2016)
paved: 291,000 km (includes 1,492 km of expressways,
1,559 of motorways) (2016)
unpaved: 129,000 km (2016)
country comparison to the world: 17
Waterways: 3,997 km (navigable rivers and canals) (2009)
country comparison to the world: 27
Merchant marine: total: 148
by type: bulk carrier 1, container ship 1, general cargo 13,
oil tanker 7, other 126 (2018)
country comparison to the world: 72
Ports and terminals: Major seaport(s): Gdansk, Gdynia,
Swinoujscie
container port(s) (TEUs): Gdansk (1,593,761) (2017)
LNG terminal(s) (import): Swinoujscie
river port(s): Szczecin (River Oder)
Military expenditures:
1.52% of GDP (2019 est.)
1.43% of GDP (2018)
1.25% of GDP (2017)
1.27% of GDP (2016)
1.33% of GDP (2015)
country comparison to the world: 75
Military and security forces: Portuguese Armed Forces:
Portuguese Army (Exercito Portuguesa), Portuguese Navy
(Marinha Portuguesa; includes Marine Corps), Portuguese
Air Force (Forca Aerea Portuguesa, FAP); Portuguese
National Republican Guard (Guarda Nacional Republicana,
GNR) (2019) note: the GNR is a national gendarmerie force
comprised of military personnel with law enforcement,
internal security, civil defense, disaster response, and coast
guard duties; it is responsible to the Minister of Internal
Administration and to the Minister of National Defense; in
the event of war or crisis, it may be placed under the Chief
of the General Staff of the Armed Forces Military service age
and obligation: 18-30 years of age for voluntary or contract
military service; no compulsory military service, but
conscription possible if insufficient volunteers available;
women serve in the armed forces, on naval ships since
1992, but are prohibited from serving in some combatant
specialties; contract service lasts for an initial period from
two to six years, and can be extended to a maximum of 20
years of service. Voluntary military service lasts 12 months;
reserve obligation to age 35 (2017) TRANSPORTATION
National air transport system: number of registered air Carriers:
12 (2015)
inventory of registered aircraft operated by air carriers:
122 (2015)
annual passenger traffic on registered air Carriers:
12,635,233 (2015)
annual freight traffic on _ registered air _ carriers:
343,971,094 mt-km (2015)
Civil aircraft registration country code prefix: CR, CS (2016)
Airports: 64 (2013)
country comparison to the world: 77
Airports—with paved runways:
total: 43 (2017)
over 3,047 m: 5 (2017)
2,438 to 3,047 m: 7 (2017)
1,524 to 2,437 m: 8 (2017)
914 to 1,523 m: 15 (2017)
under 914 m: 8 (2017)
Airports—with unpaved runways:
total: 21 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 20 (2013)
Pipelines: 1344 km gas, 11 km oil, 188 km refined products
(2013)
Railways: total: 3,075 km (2014)
narrow gauge: 108.1 km 1.000-m gauge (2014)
broad gauge: 2,439 km 1.668-m gauge (1,633.4 km
electrified) (2014)
other: 528 km (gauge unspecified) (2014)
country comparison to the world: 60
Roadways: total: 82,900 km (2008)
paved: 71,294 km (includes 2,613 km of expressways)
(2008)
unpaved: 11,606 km (2008)
country comparison to the world: 60
Waterways: 210 km (on Douro River from Porto) (2011)
country comparison to the world: 95
Merchant marine: total: 576
by type: bulk carrier 68, container ship 236, general cargo
84, oil tanker 11, other 177 (2018)
country comparison to the world: 37
Ports and terminals: Major seaport(s): Leixoes, Lisbon,
Setubal, Sines container port(s) (TEUs): Sines (1,669,057)
(2017)
LNG terminal(s) (import): Sines','7eaa53d3c5b9fb8e0b3dc336645edd68e0f9f6e0cf8617df06c36890cecc0570','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b6ed798ac5ab58ca5f2c3093bbc9f71f1608a4df66ac9af10821f20777e35d2',2020,'BG','Bulgaria','military-and-security',883,'Military expenditures: 2.04% of GDP (2019 est.)
1.82% of GDP (2018)
1.72% of GDP (2017)
1.4% of GDP (2016)
1.45% of GDP (2015)
country comparison to the world: 49
Military and security forces: Romanian Armed Forces: Land
Forces, Naval Forces, Air Force; Ministry of Internal
Affairs: Romanian Gendarmerie (2019) Military service age and
obligation: conscription ended 2006; 18 years of age for male
and female voluntary service; all military inductees
(including women) contract for an initial 5-year term of
service, with subsequent successive 3-year terms until age
36 (2015) Military—note: Ministry of Internal Affairs:
Gendarmerie
Military expenditures: 3.93% of GDP (2018)
4.23% of GDP (2017)
9.45% of GDP (2016)
4.86% of GDP (2015)
4.1% of GDP (2014)
country comparison to the world: 13
Military and security forces: Armed Forces of the Russian
Federation: Ground Troops (Sukhoputnyye Voyskia, SV),
Navy (Voyenno-Morskoy Flot, VMF), Aerospace Forces
(Vozdushno-Kosmicheskiye Sily, VKS); Airborne Troops
(Vozdushno-Desantnyye Voyska, VDV), and Missile Troops
of Strategic Purpose (Raketnyye Voyska Strategicheskogo
Naznacheniya, RVSN) referred to commonly as Strategic
Rocket Forces, are independent “combat arms,” not
subordinate to any of the three branches Federal National
Guard Troops Service of the Russian Federation (National
Guard, Russian Guard, or Rosgvardiya): created in 2016 as
an independent agency for internal/regime security,
combating terrorism and narcotics trafficking, protecting
important state facilities and government personnel, and
supporting border security; forces include Interior Troops
that formerly belong to the Interior Ministry, special police
units, rapid response units, and other air, ground,
maritime, and police forces Federal Security Service (FSB)
Border Guard Service: Coast Guard (2019)
Military service age and obligation: 18-27 years of age for
compulsory or voluntary military service; males are
registered for the draft at 17 years of age; one-year service
obligation (Russia offers the option of serving on a two-year
contract instead of completing a one-year conscription
period); reserve obligation for non-officers to age 50;
enrollment in military schools from the age of 16, cadets
classified as members of the armed forces (2019) note: in
April of 2019, the Russian government pledged its intent to
end conscription TRANSPORTATION
National air transport system:
number of registered air carriers: 32 (2015)
inventory of registered aircraft operated by air carriers:
661 (2015)
annual passenger traffic on registered air Carriers:
76,846,126 (2015)
annual freight traffic on _ registered air carriers:
4,761,047,070 mt-km (2015) Civil aircraft registration country
code prefix: RA (2016)
Airports: 1,218 (2013)
country comparison to the world: 5
Airports—with paved runways:
total: 594 (2017)
over 3,047 m: 54 (2017)
2,438 to 3,047 m: 197 (2017)
1,524 to 2,437 m: 123 (2017)
914 to 1,523 m: 95 (2017)
under 914 m: 125 (2017)
Airports—with unpaved runways:
total: 624 (2013)
over 3,047 m: 4 (2013)
2,438 to 3,047 m: 13 (2013)
1,524 to 2,437 m: 69 (2013)
914 to 1,523 m: 81 (2013)
under 914 m: 457 (2013)
Heliports: 49 (2013)
Pipelines: 177700 km gas, 54800 km oil, 19300 km refined
products (2016)
Railways: total: 87,157 km (2014)
narrow gauge: 957 km 1.067-m gauge (on Sakhalin Island)
(2014)
broad gauge: 86,200 km 1.520-m gauge (40,300 km
electrified) (2014)
note: an additional 30,000 km of non-common carrier lines
serve industries
country comparison to the world: 3
Roadways: total: 1,283,387 km (2012)
paved: 927,721 km (includes 39,143 km of expressways)
(2012)
unpaved: 355,666 km (2012)
country comparison to the world: 5
Waterways: 102,000 km (including 48,000 km _ with
guaranteed depth; the 72,000-km system in European
Russia links Baltic Sea, White Sea, Caspian Sea, Sea of
Azov, and Black Sea) (2009) country comparison to the
world: 2
Merchant marine: total: 2,625
by type: bulk carrier 15, container ship 13, general cargo
879, oil tanker 411, other 1307 (2018) country comparison
to the world: 9
Ports and terminals: Major seaport(s): Kaliningrad, Nakhodka,
Novorossiysk, Primorsk, Vostochnyy oil terminal(s): Kavkaz
oil terminal
container port(s) (TEUs): Saint Petersburg (1,848,700)
(2017)
LNG terminal(s) (export): Sakhalin Island
river port(s): Saint Petersburg (Neva River)','6e833d5b9f292f48bfba44a5e3b4938011a949792ca993e9908a9c878e9d44bd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9a33b6448f027a6f97250ede99bba7461ecb792de0608018e378fbd5433b0d1',2020,'KN','Saint Kitts and Nevis','military-and-security',894,'Military and security forces: Ministry of Foreign Affairs,
National Security, Labour, Immigration, and _ Social
Security: Royal Saint Kitts and Nevis Defense Force
(includes Coast Guard), Royal Saint Kitts and Nevis Police
Force (2013) Military service age and obligation: 18 years of age
for voluntary military service; no conscription (2012)
Military and security forces: NO regular military forces; Royal
Saint Lucia Police Force (includes Special Service Unit,
Marine Unit) (2018) military—note: St. Lucia is a member of
the Regional Security System (RSS), an international
agreement for the defense and security of the eastern
Caribbean region.
Military—note: defense is the responsibility of France
Military—note: defense is the responsibility of France
Military and security forces: no regular military forces; the
Special Services Unit (SSU) is the paramilitary arm of the
Royal Saint Vincent and the Grenadines Police Force
(RSVPF) (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 2 (2015)
inventory of registered aircraft operated by air carriers: 11
(2015)
Civil aircraft registration country code prefix: J8 (2016)
Airports: 6 (2013)
country comparison to the world: 176
Airports—with paved runways: total: 5 (2017)
1,524 to 2,437 m: 1 (2017)
914 to 1,523 m: 3 (2017)
under 914 m: 1 (2017)
Airports—with unpaved runways:
total: 1 (2013)
under 914 m: 1 (2013)
Roadways: Merchant marine: total: 889
by type: bulk carrier 22, container ship 14, general cargo
184, oil tanker 17, other 652 (2018) country comparison to
the world: 25
Ports and terminals: major seaport(s): Kingstown','8d1339d92c1eedf9cceb0eddd4e9e912cad86c8934f722de09ea22fc0c506314','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ef1a36c7ad347c193c550fbc381b392b53e5063d827480d35ecf0f4e3ca46a7',2020,'WS','Samoa','military-and-security',902,'Military and security forces: no regular military forces; Samoa
Police Force (2019)
Military—note: Samoa has no formal defense structure or
regular armed forces; informal defense ties exist with NZ,
which is required to consider any Samoan request for
assistance under the 1962 Treaty of Friendship','391b3dd5283c1fa782d294c5d394348610a953bb979c9be13aa6d8fb7b9a6e65','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e0b1378fde8c61ad289c1424ace98c10ded8e44c4955cd8669fc23b31dfa3f3',2020,'SM','San Marino','military-and-security',908,'Military and security forces: No regular military forces;
Voluntary Military Corps (Corpi Militari), which includes a
Uniformed Militia (performs ceremonial duties and limited
police support functions) and Guard of the Great and
General Council (defends the Captains Regent and the
Great and General Council, participates in _ official
ceremonies, cooperates with the maintenance of public
order on special occasions, and performs guard duties
during parliamentary sittings); the Police Corps includes
the Gendarmerie, which is responsible for maintaining
public order, protecting citizens and their property, and
providing assistance during disasters (2019) Military service
age and obligation: 18 is the legal minimum age for voluntary
military service; no conscription; government has the
authority to call up all San Marino citizens from 16-60
years of age to service in the military (2012) Military—note:
defense is the responsibility of Italy','a7016052a207c9d673d40e389345baa2fde96ae71c5b1a1846e8b452956034fb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1a6fc246eafc7de408c1a507f4ad3a114bbddf2b5844c3029fdd1ecbf6ec586',2020,'ST','Sao Tome and Principe','military-and-security',915,'Military and security forces: Armed Forces of Sao Tome and
Principe (Forcas Armadas de Sao Tome e Principe, FASTP):
Army, Coast Guard of Sao Tome e Principe (Guarda
Costeira de Sao Tome e Principe, GCSTP; also called
“Navy”), Presidential Guard, National Guard (2019) Military
service age and obligation: 18 is the legal minimum age for
compulsory military service; 17 is the legal minimum age
for voluntary service (2012) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 1 (2015)
annual passenger traffic on registered air carriers: 50,716
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: S9 (2016)
Airports: 2 (2013)
country comparison to the world: 207
Airports—with paved runways:
total: 2 (2019)
1,524 to 2,437 m: 1
914 to 1,523 m: 1
Roadways: Merchant marine: total: 15
by type: general cargo 12, other 3 (2018)
country comparison to the world: 145
Ports and terminals: Major seaport(s): Sao Tome','87bd17b26736d37e3a0392cf39141d0016b7fe0e70706371d818417b1c9d59d5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29006cddef6d383225cb9c9d47272bccccc7e01717b04a10c5a01573c6206828',2020,'ID','Indonesia','military-and-security',920,'3.3% of GDP (2019)
3.14% of GDP (2018)
3.16% of GDP (2017)
3.19% of GDP (2016)
3.09% of GDP (2015)
country comparison to the world: 21
Military and security forces: Singapore Armed _. Forces:
Singapore Army, Republic of Singapore Navy, Republic of
Singapore Air Force (includes air defense); Police Coast
Guard (subordinate to the Singapore Police Force) (2019)
Military service age and obligation: 18-21 years of age for male
compulsory military service; 16 1/2 years of age for
voluntary enlistment (with parental consent); 2-year
conscript service obligation, with a reserve obligation to
age 40 (enlisted) or age 50 (officers) (2019) Maritime
threats: the International Maritime Bureau reports the
territorial and offshore waters in the South China Sea as
high risk for piracy and armed robbery against ships;
numerous commercial vessels have been attacked and
hijacked both at anchor and while underway; hijacked
vessels are often disguised and cargo diverted to ports in
East Asia; crews have been murdered or cast adrift; the
Singapore Straits saw three attacks against commercial
vessels in 2018, a slight decrease from the four attacks in
2017 (2018) TRANSPORTATION
National air transport system: number of registered air Carriers:
5 (2015) inventory of registered aircraft operated by air
carriers: 197 (2015)
annual passenger traffic on registered air Carriers:
33,290,544 (2015)
annual freight traffic on _ registered air _ carriers:
6,154,365,275 mt-km (2015)
Civil aircraft registration country code prefix: 9V (2016)
Airports: 9 (2013)
country comparison to the world: 159
Airports—with paved runways:
total: 9 (2017)
over 3,047 m: 2 (2017)
2,438 to 3,047 m: 2 (2017)
1,524 to 2,437 m: 3 (2017)
914 to 1,523 m: 1 (2017)
under 914 m: 1 (2017)
Pipelines: 3220 km domestic gas (2014), 1122 km cross-
border pipelines (2017), 8 km refined products (2013)
Roadways: total: 3,500 km (2017)
paved: 3,500 km (includes 164 km of expressways) (2017)
country comparison to the world: 154
Merchant marine: total: 3,526
by type: bulk carrier 603, container ship 490, general cargo
132, oil tanker 732, other 1,569 (2018) country comparison
to the world: 6
Ports and terminals: Major seaport(s): Singapore
container port(s) (TEUs): Singapore (33,666,000) (2017)
LNG terminal(s) (import): Singapore
Military expenditures:
0.61% of GDP (2018)
0.86% of GDP (2017)
0.97% of GDP (2016)
1.19% of GDP (2015)
0.73% of GDP (2014)
country comparison to the world: 142
Military and security forces: Timor-Leste Defense Force
(Falintil-Forcas de Defesa de Timor-Leste, Falintil (F-
FDTL)): Headquarters with Land and Naval components
(2019) Military service age and obligation: 18 years of age for
voluntary military service; 18-month service obligation
(2019) TRANSPORTATION
Civil aircraft registration country code prefix: 4W (2016)
Airports: 6 (2013)
country comparison to the world: 177
Airports—with paved runways:
total: 2 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 1 (2013)
Airports—with unpaved runways:
total: 4 (2013)
914 to 1,523 m: 2 (2013)
under 914 m: 2 (2013)
Heliports: 8 (2013)
Roadways: total: 6,040 km (2008)
paved: 2,600 km (2008)
unpaved: 3,440 km (2008)
country comparison to the world: 139
Ports and terminals: Major seaport(s): Dili','d18db582ceafac37d5f966d2dba4f6449cee1d311b46283bd175b4ba82dc2ffa','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90233f7e4d6ded9948ab76c647cf0ad1a891bf0d05dac27d8384021fcb2398e5',2020,'SK','Slovakia','military-and-security',927,'Military expenditures:
1.74% of GDP (2019 est.)
1.22% of GDP (2018)
1.1% of GDP (2017)
1.12% of GDP (2016)
1.12% of GDP (2015)
country comparison to the world: 66
Military and _ security forces: Armed Forces of the Slovak
Republic (Ozbrojene Sily Slovenskej Republiky): Land
Forces, Air and Air Defense Forces, and a Joint Training
and Support Command (2019) Military service age and
obligation: 18-30 years of age for voluntary military service;
conscription in peacetime suspended in 2006; women are
eligible to serve (2012) TRANSPORTATION
National air transport system: number of registered air Carriers:
4 (2015) inventory of registered aircraft operated by air
carriers: 23 (2015)
annual passenger traffic on registered air carriers: 11,100
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: OM (2016)
Airports: 35 (2013)
country comparison to the world: 111
Airports—with paved runways:
total: 19 (2019)
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 9
Airports—with unpaved runways:
total: 15 (2019)
914 to 1,523 m: 10
under 914 m:5
Heliports: 1 (2019)
Pipelines: 2270 km gas transmission pipelines, 6278 km
high-pressure gas distribution pipelines, 27023 km mid-
and low-pressure gas distribution pipelines (2016), 510 km
oil (2015) Railways: total: 3,580 km (2016)
standard gauge: 3,435 km 1.435-m gauge (1,587 km
electrified) (2016)
narrow gauge: 46 km 1.000-m or 0.750-m gauge (2016)
broad gauge: 99 km 1.520-m gauge (2016)
country comparison to the world: 56
Roadways: total: 56,926 km (includes local roads, national
roads, and 464 km of highways) (2016) country comparison
to the world: 80
Waterways: 172 km (on Danube River) (2012)
country comparison to the world: 99
Ports and terminals: river port(s): Bratislava, Komarno
(Danube) TRANSNATIONAL ISSUES
Disputes—International: bilateral government, legal, technical
and economic working group negotiations continued
between Slovakia and Hungary over Hungary’s completion
of its portion of the Gabcikovo-Nagymaros hydroelectric
dam project along the Danube; as a member state that
forms part of the EU’s external border, Slovakia has
implemented strict Schengen border rules Refugees and
internally displaced persons: stateless persons: 1,523
(2018)
Illicit drugs: transshipment point for Southwest Asian heroin
bound for Western Europe; producer of synthetic drugs for
regional market; consumer of ecstasy SLOVENIA
Maribor
eat
ice Velenje
e ,Kamnik Lelje
elrbovije
*
Nova Gorica LJUBLJANA
Novo®
Mesto','75c16800c0b8f4a24706152f5dddc967362d3d671fca5a5ff8f9959a92bbe56d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b330897cb58821ba3881e038747bc5d543e5f1f031614d88404091bc372ae9fa',2020,'SI','Slovenia','military-and-security',933,'Military expenditures:
1.04% of GDP (2019 est.)
1.01% of GDP (2018)
0.98% of GDP (2017)
1.01% of GDP (2016)
0.93% of GDP (2015)
country comparison to the world: 113
Military and security forces: Slovenian Armed Forces (Slovenska
Vojska, SV): structured as a combined Force Command with
air, land, logistical, maritime, support, and_ training
components (2019) Military service age and obligation: 18-25
years of age for voluntary military service; conscription
abolished in 2003 (2013) TRANSPORTATION
National air transport system: number of registered air Carriers:
2 (2015) inventory of registered aircraft operated by air
carriers: 35 (2015)
annual passenger traffic on registered air Carriers:
1,130,637 (2015)
annual freight traffic on registered air carriers: 1,349,442
mt-km (2015)
Civil aircraft registration country code prefix: S5 (2016)
Airports: 16 (2020)
country comparison to the world: 144
Airports—with paved runways:
total: 9 (2020)
over 3,047 m: 1
2,438 to 3,047 m: 2
914 to 1,523 m: 3
under 914 m:3
Airports—with unpaved runways:
total: 7 (2020)
914 to 1,523 m: 4
under 914 m: 3
Pipelines: 1155 km gas, 5 km oil (2017)
Railways: total: 1,229 km (2014)
standard gauge: 1,229 km 1.435-m gauge (503 km
electrified) (2014)
country comparison to the world: 86
Roadways: total: 38,985 km (2012)
paved: 38,985 km (includes 769 km of expressways) (2012)
country comparison to the world: 90
Waterways: (Some transport on the Drava River) (2012)
Merchant marine: total: 8
by type: other 8 (2018)
country comparison to the world: 158
Ports and terminals: major seaport(s): Koper
Military and security forces: NO regular military forces; Royal
Solomon Islands Police Force (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 3 (2015)
annual passenger traffic on registered air carriers: 373,738
(2015)
annual freight traffic on registered air carriers: 3,691,584
mt-km (2015)
Civil aircraft registration country code prefix: H4 (2016)
Airports: 36 (2013)
country comparison to the world: 110
Airports—with paved runways:
total: 1 (2019)
1,524 to 2,437 m: 1
Airports—with unpaved runways:
total: 35 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 10 (2013)
under 914 m: 24 (2013)
Heliports: 3 (2013)
Roadways: total: 1,390 km (2011)
paved: 34 km (2011)
unpaved: 1,356 km (2011)
note: includes 920 km of private plantation roads
country comparison to the world: 171
Merchant marine: total: 23
by type: general cargo 6, other 17 (2018)
country comparison to the world: 136
Ports and terminals: Major seaport(s): Honiara, Malloco Bay,
Viru Harbor, Tulaghi TRANSNATIONAL ISSUES
Disputes—International: since 2003, the Regional Assistance
Mission to Solomon Islands, consisting of police, military,
and civilian advisors drawn from 15 countries, has assisted
in reestablishing and maintaining civil and political order
while reinforcing regional stability and security Trafficking in
persons: Current situation: the Solomon Islands is a source
and destination country for local adults and children and
Southeast Asian men and women subjected to forced labor
and forced prostitution; women from China, Indonesia,
Malaysia, and the Philippines are recruited for legitimate
work and upon arrival are forced into prostitution; men
from Indonesia and Malaysia recruited to work in the
Solomon Islands’ mining and logging industries may be
subjected to forced labor; local children are forced into
prostitution near foreign logging camps, on fishing vessels,
at hotels, and entertainment venues; some local children
are also sold by their parents for marriage to foreign
workers or put up for “informal adoption” to pay off debts
and then find themselves forced into domestic servitude or
forced prostitution tier rating: Tier 2 Watch List—the
Solomon Islands does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; in 2014, the Solomon
Islands was granted a waiver from an otherwise required
downgrade to Tier 3 because its government has a written
plan that, if implemented, would constitute making
significant efforts to bring itself into compliance with the
minimum standards for the elimination of trafficking; the
government gazetted implementing regulations for the
2012 immigration act prohibiting transnational trafficking,
but the penalties are not sufficiently stringent because they
allow the option of paying a fine; a new draft law to address
these weaknesses awaits parliamentary review; no new
trafficking investigations were conducted, even after labor
inspections at logging and fishing companies, no existing
cases led to prosecutions or convictions, and no funding
was’ allocated for national anti-trafficking efforts;
authorities did not identify or protect any victims and lack
any procedures or shelters to do so; civil society and
religious organizations provide most of the limited services
available; a lack of understanding of the crime of
trafficking remains a serious challenge (2015)','b4eb7d233ac764e631c584c18aeec5bc558ec3d9c8ba003cb049d14dbf937473','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('367bcab933d73aaa73fa5c2eb0986be9c104154a682cf576651736be192288c4',2020,'SO','Somalia','military-and-security',938,'=
A Boosaaso
“Berbera moins
SOMALILAND
PUNTLAND
Hargeysa
Military and security forces: Somali National Security Forces:
Somali National Army (SNA), Somali National Police (SNP,
includes a maritime unit), National Intelligence and
Security Agency (NISA) (2019) Military service age and
obligation: 18 is the legal minimum age for compulsory and
voluntary military service (2012) Maritime threats: the
International Maritime Bureau continues to report the
territorial and offshore waters in the Gulf of Aden and
Indian Ocean as a region of significant risk for piracy and
armed robbery against ships; during 2018, two vessels
were attacked compared with five in 2017; Operation
Ocean Shield, the NATO naval task force established in
2009 to combat Somali piracy, concluded its operations in
December 2016 as a result of the drop in reported
incidents over the last few years; additional anti-piracy
measures on the part of ship operators, including the use of
on-board armed security teams, have reduced piracy
incidents in that body of water; Somali pirates tend to be
heavily armed with automatic weapons and_ rocket
propelled grenades; the use of “mother ships” from which
skiffs can be launched to attack vessels allows these pirates
to extend the range of their operations hundreds of nautical
miles offshore Military—note: the African Union Mission in
Somalia (AMISOM) has operated in the country with the
approval of the United Nations (UN) since 2007; AMISOM’s
peacekeeping mission includes assisting Somali forces in
providing security for a stable political process, enabling
the gradual handing over of security responsibilities from
AMISOM to the Somali security forces, and reducing the
threat posed by Al-Shabaab and other armed opposition
groups; as of 2019, AMISOM had more than 22,000
military and police personnel from six African countries
deployed in Somalia UN Assistance Mission in Somalia
(UNSOM) is mandated by the Security Council to work with
the Federal Government of Somalia to support national
reconciliation, provide advice on peace-building and state-
building, monitor the human rights situation, and help
coordinate the efforts of the international community the
UN Support Office in Somalia (UNSOS) is responsible for
providing logistical field support to AMISOM, UNSOM, the
Somali National Army, and the Somali Police Force on joint
operations with AMISOM (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 1 (2015)
annual passenger traffic on registered air Carriers: 251,652
(2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: 60 (2016)
Airports: 52 (2020)
country comparison to the world: 90
Airports—with paved runways:
total: 8 (2020)
over 3,047 m:5
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
Airports—with unpaved runways:
total: 44 (2020)
2,438 to 3,047 m: 5
1,524 to 2,437 m: 16
914 to 1,523 m: 22
under 914 m:1
Roadways: Merchant marine: total: 5
by type: general cargo 1, other 4 (2018)
country comparison to the world: 164
Ports and terminals: Major seaport(s): Berbera, Kismaayo
Military expenditures:
0.98% of GDP (2018)
1.04% of GDP (2017)
1.08% of GDP (2016)
1.1% of GDP (2015)
1.11% of GDP (2014)
country comparison to the world: 120
Military and security forces: South African National Defence
Force (SANDF): South African Army (includes Reserve
Force), South African Navy (SAN), South African Air Force
(SAAF), South African Military Health Services (2019)
Military service age and obligation: 18-26 years of age for
voluntary military service; women are eligible to serve in
noncombat roles; 2-year service obligation (2019)
Military—note: defense is the responsibility of the UK','59c8def9ef7ec453dd9d1b56cdd81f3cc8620982cacd7f18c9ed1862573fee36','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e03473487bae3b10ee7ab7ee19a8d1d59ab4047fec60070a1ccc0495c3131e8',2020,'SD','Sudan','military-and-security',954,'Military expenditures:
1.33% of GDP (2018)
2.35% of GDP (2017)
4.6% of GDP (2016)
10.56% of GDP (2015)
8.62% of GDP (2014)
country comparison to the world: 90
Military and security forces: South Sudan People’s Defence
Force (SSPDF): Ground Force, Air Force, Air Defense
Forces, Presidential Guard (2019) Military service age and
obligation: 18 is the legal minimum age for compulsory and
voluntary military service; the Government of South Sudan
signed agreements in March 2012 and August 2015 that
included the demobilization of all child soldiers within the
armed forces and opposition, but the recruitment of child
soldiers by the warring parties continues; as of the end of
2018, UNICEF estimated that more than 19,000 child
soldiers had been used in the country’s civil war since it
began in December 2013 (2018) Military—note: under the
September 2018 peace agreement, all armed groups in
South Sudan were to assemble at designated sites where
fighters could be either disarmed and demobilized, or
integrated into unified military and police forces; the
unified forces were then to be retrained and deployed prior
to the formation of a national unity government; all fighters
were ordered to these sites in July 2019, but as of
December 2019 this process had not been completed the
United Nations Mission in South Sudan (UNMISS) has
operated in the country since 2011 with the objectives of
consolidating peace and security and helping establish
conditions for the successful economic and_ political
development of South Sudan; UNMISS had more than
19,000 personnel deployed in the country as of September
2019
United Nations Interim Security Force for Abyei
(UNISFA) has operated in the disputed Abyei region along
the border between Sudan and South Sudan since 2011;
UNISFA4’s mission includes ensuring security, protecting
civilians, strengthening the capacity of the Abyei Police
Service, de-mining, monitoring/verifying the redeployment
of armed forces from the area, and facilitating the flow of
humanitarian aid; UNISFA had about 4,400 personnel
deployed as of October 2019 (2019) TRANSPORTATION
National air transport system: annual freight traffic on
registered air carriers: 0 mt-km Civil aircraft registration country
code prefix: Z8 (2016)
Airports: 89 (2020)
country comparison to the world: 63
Airports—with paved runways:
total: 4 (2020)
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
Airports—with unpaved runways:
total: 84 (2020)
2,438 to 3,047 m: 1
1,524 to 2,437 m: 12
914 to 1,523 m: 38
under 914 m: 33
Heliports: 3 (2020)
Railways: total: 248 km (2018)
note: a narrow gauge, single-track railroad between
Babonosa (Sudan) and Wau, the only existing rail system,
was repaired in 2010 with $250 million in UN funds, but is
not currently operational country comparison to the world:
126
Roadways: total: 7,000 km (2012)
note: most of the road network is unpaved and much of it is
in disrepair; a 192-km paved road between the capital,
Juba, and Nimule on the Ugandan border was constructed
with USAID funds in 2012
country comparison to the world: 138
Waterways: See entry for Sudan
Military expenditures:
2.28% of GDP (2018)
3.91% of GDP (2017)
2.96% of GDP (2016)
2.8% of GDP (2015)
country comparison to the world: 40
Military and security forces: Sudanese Armed Forces (SAF):
Ground Force, Navy, Sudanese Air Force; Rapid Support
Forces (paramilitary); Popular Defense Forces
(paramilitary) (2019) Military service age and obligation: 18-33
years of age for male and female compulsory or voluntary
military service; 1-2 year service obligation (2013) Military—
note: United Nations Interim Security Force for Abyei
(UNISFA) has operated in the disputed Abyei region along
the border between Sudan and South Sudan since 2011;
UNISF4’s mission includes ensuring security, protecting
civilians, strengthening the capacity of the Abyei Police
Service, de-mining, monitoring/verifying the redeployment
of armed forces from the area, and facilitating the flow of
humanitarian aid; UNISFA had about 4,400 personnel
deployed as of July 2019
In addition, the United Nations African Union Hybrid
Operation in Darfur (UNAMID) has operated in the war-
torn Darfur region since 2007; UNAMID is a joint African
Union-UN peacekeeping force with the mission of bringing
stability to Darfur, including protecting civilians,
facilitating humanitarian assistance, and promoting
mediation efforts, while peace talks on a final settlement
continue; as of October 2019, UNAMID had about 7,800
personnel deployed (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
6 (2015) inventory of registered aircraft operated by air
carriers: 25 (2015) annual passenger traffic on registered
air carriers: 496,178 (2015) annual freight traffic on
registered air carriers: 13,161,592 mt-km (2015) Civil aircraft
registration country code prefix: ST (2016)
Airports: 67 (2020)
country comparison to the world: 74
Airports—with paved runways:
total: 17 (2020)
over 3,047 m: 2
2,438 to 3,047 m: 11
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1
Airports—with unpaved runways:
total: 50 (2020)
1,524 to 2,437 m: 17
914 to 1,523 m: 24
under 914 m: 9
Heliports: 7 (2020)
Pipelines: 156 km gas, 4070 km oil, 1613 km refined
products (2013) Railways: total: 7,251 km (2014)
narrow gauge: 5,851 km 1.067-m gauge (2014)
1,400 km 0.600-m gauge for cotton plantations
country comparison to the world: 31
Roadways: Waterways: 4,068 km (1,723 km open year-round
on White and Blue Nile Rivers) (2011) country comparison
to the world: 24
Merchant marine: total: 18
by type: general cargo 1, other 17 (2018)
country comparison to the world: 140
Ports and terminals: major seaport(s): Port Sudan','23022c48f84ff66435bb8225746b6245543a56d48e74542697b1b27b70bd4c44','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59a66633724bfd120eded9c21b47c76f9eb8d7f222d906702132f7089ac8c380',2020,'LK','Sri Lanka','military-and-security',966,'Military expenditures:
1.89% of GDP (2018)
2.14% of GDP (2017)
2.14% of GDP (2016)
2.55% of GDP (2015)
2.41% of GDP (2014)
country comparison to the world: 57
Military and security forces: Sri Lanka Army (includes National
Guard and the Volunteer Force), Sri Lanka Navy (includes
Marine Corps), Sri Lanka Air Force, Sri Lanka Coast Guard;
Civil Security Department; Sri Lanka National Police:
Special Task Force (counter-terrorism and _ counter-
insurgency) (2019) Military service age and obligation: 18-22
years of age for voluntary military service; no conscription
(2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
3 (2015) inventory of registered aircraft operated by air
carriers: 25 (2015) annual passenger traffic on registered
air carriers: 4,911,730 (2015) annual freight traffic on
registered air carriers: 381,381,300 mt-km (2015) Civil
aircraft registration country code prefix: 4R (2016)
Airports: 18 (2020)
country comparison to the world: 141
Airports—with paved runways:
total: 11 (2020)
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 4
Airports—with unpaved runways:
total: 7 (2020)
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m:2
Heliports: 1 (2020)
Pipelines: 7 km refined products
Railways: total: 1,562 km (2016)
broad gauge: 1,562 km 1.676-m gauge (2016)
country comparison to the world: 82
Roadways: total: 114,093 km (2010)
paved: 16,977 km (2010)
unpaved: 97,116 km (2010)
country comparison to the world: 43
Waterways: 160 km (primarily on rivers in southwest) (2012)
country comparison to the world: 100
Merchant marine: total: 87
by type: bulk carrier 9, container ship 1, general cargo 11,
oil tanker 11, other 55 (2018) country comparison to the
world: 94
Ports and terminals: Major seaport(s): Colombo container
port(s) (TEUs): Colombo (6,209,000) (2017)','5fa2dd0751fa219def13bbc71af409c140294445d3a40e0f1f9c6e07b9cf2e0a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a296d4583e93f0008f9a58c77a3f170d48d93f328d121e3d98b90ec4aae64e3',2020,'NO','Norway','military-and-security',972,'eee
Military and security forces: nO regular military forces; military
installations prohibited by treaty military—note: Svalbard is a
territory of Norway, demilitarized by treaty on 9 February
1920; Norwegian military activity is limited to fisheries
surveillance by the Norwegian Coast Guard
Military expenditures:
1.04% of GDP (2018)
1.03% of GDP (2017)
1.06% of GDP (2016)
1.08% of GDP (2015)
1.14% of GDP (2014)
country comparison to the world: 114
Military and_ security forces: Swedish Armed Forces
(Forsvarsmakten): Army, Navy, Air Force, Home Guard
(2019) Military service age and obligation: 18-47 years of age for
male and female voluntary military service; service
obligation: 7.5 months (Army), 7-15 months (Navy), 8-12
months (Air Force); after completing initial service, soldiers
have a reserve commitment until age 47; compulsory
military service, abolished in 2010, was reinstated in
January 2018; conscription is selective, includes both
female and male (age 18), and requires 9-12 months of
service (2018) TRANSPORTATION
National air transport system: number of registered air Carriers:
8 (2015) inventory of registered aircraft operated by air
carriers: 219 (2015)
annual passenger traffic on registered air Carriers:
11,623,930 (2015)
annual freight traffic on registered air carriers: 0 mt-km
(2015)
Civil aircraft registration country code prefix: SE (2016)
Airports: 231 (2013)
country comparison to the world: 25
Airports—with paved runways:
total: 149 (2013)
over 3,047 m: 3 (2013)
2,438 to 3,047 m: 12 (2013)
1,524 to 2,437 m: 75 (2013)
914 to 1,523 m: 22 (2013)
under 914 m: 37 (2013)
Airports—with unpaved runways:
total: 82 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 77 (2013)
Heliports: 2 (2013)
Pipelines: 1626 km gas (2013)
Railways: total: 14,127 km (2016)
standard gauge: 14,062 km 1.435-m gauge (12,322 km
electrified) (2016)
narrow gauge: 65 km 0.891-m gauge (65 km electrified)
(2016)
country comparison to the world: 20
Roadways: total: 573,134 km (includes 2,050 km of
expressways) (2016) paved: 140,100 km (2016)
unpaved: 433,034 km (2016)
note: includes 98,500 km of state roads, 433,034 km of
private roads, and 41,600 km of municipal roads country
comparison to the world: 13
Waterways: 2,052 km (2010)
country comparison to the world: 40
Merchant marine: total: 359
by type: general cargo 66, oil tanker 22, other 271 (2018)
country comparison to the world: 47
Ports and terminals: Major seaport(s): Brofjorden, Goteborg,
Helsingborg, Karlshamn, Lulea, Malmo, Stockholm,
Trelleborg, Visby LNG terminal(s) (import):
Brunnsviksholme, Lysekil','de20717398b15ce04d607add0ae4b9f4b3e8876673c8838e3ef03b00cef20cbe','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b8577983c182a48836bbf4039831476d2148ac78f385b6afd9f412ff5e2114e',2020,'MY','Malaysia','military-and-security',987,'Military expenditures:
1.33% of GDP (2018)
1.37% of GDP (2017)
1.44% of GDP (2016)
1.43% of GDP (2015)
1.41% of GDP (2014)
country comparison to the world: 91
Military and_ security forces: Royal Thai Armed Forces
(Kongthap Thai, RTARF): Royal Thai Army (Kongthap Bok
Thai, RTA, includes paramilitary Thai Rangers (Thahan
Phrahan)), Royal Thai Navy (Kongthap Ruea Thai, RIN,
includes Royal Thai Marine Corps), Royal Thai Air Force
(Kongthap Akaat Thai, RIAF); Interior Ministry
paramilitary forces: Volunteer Defense Corps (2018) Military
service age and obligation: 21 years of age for compulsory
military service; 18 years of age for voluntary military
service; males register at 18 years of age; 2-year conscript
service obligation based on lottery (2018)','2f8fd9e7e43a671c4c96a7a7827a82883256d38c2bf30cdee060990eb629b87c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ce3ff697545f65657f6efcda368cd5b9ff9360ac473f53dff43d2622cdf8544',2020,'TT','Trinidad and Tobago','military-and-security',998,'Military expenditures:
0.78% of GDP (2018)
0.95% of GDP (2017)
1.02% of GDP (2016)
0.86% of GDP (2015)
0.72% of GDP (2014)
country comparison to the world: 132
Military and security forces: Trinidad and Tobago Defense Force
(TTDF): Trinidad and Tobago Regiment (Land Forces),
Coast Guard, Air Guard, Defense Force Reserves (2019)
Military service age and obligation: 18-25 years of age for
voluntary military service (some age variations between
services, reserves); no conscription (2019)
Military expenditures:
2.09% of GDP (2018)
2.13% of GDP (2017)
2.35% of GDP (2016)
2.27% of GDP (2015)
1.91% of GDP (2014)
country comparison to the world: 46
Military and security forces: Tunisian Armed Forces (Forces
Armees Tunisiens, FAT): Tunisian Army (includes Tunisian
Air Defense Force), Tunisian Navy, Republic of Tunisia Air
Force; Ministry of Interior: Tunisian National Guard (2019)
Military service age and obligation: 20-23 years of age for
compulsory service, 1-year service obligation; 18-23 years
of age for voluntary service (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
3 (2015) inventory of registered aircraft operated by air
carriers: 41 (2015)
annual passenger traffic on registered air Carriers:
3,496,190 (2015)
annual freight traffic on registered air carriers: 10,354,241
mt-km (2015)
Civil aircraft registration country code prefix: [TS (2016)
Airports: 29 (2013)
country comparison to the world: 120
Airports—with paved runways:
total: 15 (2013)
over 3,047 m: 4 (2013)
2,438 to 3,047 m: 6 (2013)
1,524 to 2,437 m: 2 (2013)
914 to 1,523 m: 3 (2013)
Airports—with unpaved runways:
total: 14 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 8 (2013)
Pipelines: 68 km condensate, 3111 km gas, 1381 km oil, 453
km refined products (2013)
Railways: total: 2,173 km (1,991 in use) (2014)
standard gauge: 471 km 1.435-m gauge (2014)
narrow gauge: 1,694 km 1.000-m gauge (65 km electrified)
(2014)
dual gauge: 8 km 1.435-1.000-m gauge (2014)
country comparison to the world: 70
Roadways: paved: 20,000 km (2015)
Merchant marine: total: 66
by type: general cargo 14, oil tanker 1, other 51 (2018)
country comparison to the world: 104
Ports and terminals: Major seaport(s): Bizerte, Gabes, Rades,
Sfax, Skhira TERRORISM
Terrorist groups—home based:
al-Qa’ida in the Islamic Maghreb (AQIM): aim(s): overthrow
various African regimes and replace them with one ruled by
Sharia; establish a regional Islamic caliphate across all of
North and West Africa area(s) of operation: leadership
headquartered in Algeria; operates in Tunisia and Libya
note: al-Qa’ida’s affiliate in North Africa; Tunisia-based
branch known as the Ugbah bin Nafi Battalion; Mali-based
cadre merged with allies to form JNIM in March 2017,
which pledged allegiance to AQIM and al-Qa’ida (2018)
Ansar al-Sharia in Tunisia (AAS-T): aim(s): expand its influence in
Tunisia and, ultimately, replace the Tunisian Government
with Sharia area(s) of operation: headquartered in Tunisia;
members instigate riots and violent demonstrations and
engage in attacks, targeting Tunisian military and security
personnel, Tunisian politicians, religious sites, and Western
interests (2018) Islamic State of Iraq and ash-Sham (ISIS)
network in Tunisia (to include pro-ISIS cells and designated
Jund al-Khilafah (JAK-T)): aim(s): replace the Tunisian
Government with an Islamic state and implement ISIS’s
strict interpretation of Sharia area(s) of operation: Tunisian
ISIS fighters stage attacks just across the border in Libya
against government facilities and personnel and foreign
tourists in Tunisia (2018) TRANSNATIONAL ISSUES
Disputes—International: NONe
Trafficking in persons: Current situation: Tunisia is a source,
destination, and possible transit country for men, women,
and children subjected to forced labor and sex trafficking;
Tunisia’s increased number of street children, rural
children working to support their families, and migrants
who have fled unrest in neighboring countries are
vulnerable to human trafficking; organized gangs force
street children to serve as thieves, beggars, and drug
transporters; Tunisian women have been forced into
prostitution domestically and elsewhere in the region under
false promises of legitimate work; East and West African
women may be subjected to forced labor as domestic
workers tier rating: Tier 2 Watch List - Tunisia does not fully
comply with the minimum standards for the elimination of
trafficking; however, it is making significant efforts to do
so; in 2014, Tunisia was granted a waiver from an
otherwise required downgrade to Tier 3 because _ its
government has a written plan that, if implemented would
constitute making significant efforts to bring itself into
compliance with the minimum standards for the elimination
of trafficking; in early 2015, the government drafted a
national anti-trafficking action plan outlining proposals to
raise awareness and enact draft anti-trafficking legislation;
authorities did not provide data on the prosecution and
conviction of offenders but reportedly identified 24 victims,
as opposed to none in 2013, and operated facilities
specifically dedicated to trafficking victims, regardless of
nationality and gender; the government did not fully
implement its national victim referral mechanism; some
unidentified victims were not protected from punishment
for unlawful acts directly resulting from being trafficked
(2015) TURKEY
Military expenditures:
1.89% of GDP (2019 est.)
1.85% of GDP (2018)
1.52% of GDP (2017)
1.46% of GDP (2016)
1.39% of GDP (2015)
country comparison to the world: 58
Military and security forces: Turkish Armed Forces (TSK):
Turkish Land Forces (Turk Kara Kuvvetleri), Turkish Naval
Forces (Turk Deniz Kuvvetleri; includes naval air and naval
infantry), Turkish Air Forces (Turk Hava Kuvvetleri);
Ministry of Interior: Gendarmerie of the Turkish Republic,
Turkish Coast Guard Command (2019) Military service age and
obligation: President Erdogan on 25 June 2019 signed a new
law cutting the men’s mandatory military service period in
half, as well as making paid military service permanent;
with the new system, the period of conscription was
reduced from 12 months to six months for private and non-
commissioned soldiers (the service term for reserve officers
chosen among university or college graduates will remain
12 months); after completing six months of service, if a
conscripted soldier wants to and is suitable for extending
his military service, he may do so for an additional six
months in return for a monthly salary; under the new law,
all male Turkish citizens over the age of 20 will be required
to undergo a one month military training period, but they
can obtain an exemption from the remaining five months of
their mandatory service by paying 31,000 Turkish Liras
(2019) Military—note: The ruling Justice and Development
Party (AKP) has actively pursued the goal of asserting
civilian control over the military since first taking power in
2002; the Turkish Armed Forces (TSK) role in internal
security has been significantly reduced; the TSK leadership
continues to be an influential institution within Turkey, but
plays a much smaller role in politics; the Turkish military
remains focused on the threats emanating from the Syrian
civil war, Russia’s actions in Ukraine, and the PKK
insurgency; primary domestic threats are listed as
fundamentalism (with the definition in some dispute with
the civilian government), separatism (Kurdish discontent),
and the extreme left wing; Ankara strongly opposed
establishment of an autonomous Kurdish region in Iraq; an
overhaul of the Turkish Land Forces Command (TLFC)
taking place under the “Force 2014” program is to produce
20-30% smaller, more highly trained forces characterized
by greater mobility and firepower and capable of joint and
combined operations; the TLFC has taken on increasing
international peacekeeping responsibilities including in
Afghanistan; the Turkish Navy is a regional naval power
that wants to develop the capability to project power
beyond Turkey’s coastal waters; the Navy is _ heavily
involved in NATO, multinational, and UN operations; its
roles include control of territorial waters and security for
sea lines of communications; the Turkish Air Force adopted
an “Aerospace and Missile Defense Concept” in 2002 and
has initiated project work on an integrated missile defense
system; in a controversial move, it recently July 2019)
purchased the Russian S-400 air defense system for an
estimated $2.5 billion; Air Force priorities include attaining
a modern deployable, survivable, and sustainable force
structure, and establishing a sustainable command and
control system; Turkey is a NATO ally and hosts NATO’s
Land Forces Command in Izmir, as well as the AN/TPY-2
radar as part of NATO Missile Defense (2019)','bfd7136c03982f150a8d122432168e4db8d4af9904cf804e0ec264d385568855','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('789fa15d642d06e696fa529033ed7625a349f4a55d44d754840b6b22577b432b',2020,'SS','South Sudan','military-and-security',1004,'Military expenditures:
1.43% of GDP (2018)
1.29% of GDP (2017)
1.26% of GDP (2016)
1.21% of GDP (2015)
1.17% of GDP (2014)
country comparison to the world: 81
Military and security forces: Uganda People’s Defense Force
(UPDF): Land Forces, Air Forces, Marine Forces, Special
Operations Command, Reserve Force (2019) Military service
age and obligation: 18-25 years of age for voluntary military
duty (must be single, no children); 9-year service obligation
(2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 1 (2015)
annual passenger traffic on registered air carriers: 41,812
(2015)
annual freight traffic on registered air carriers: 23,472 mt-
km (2015)
Civil aircraft registration country code prefix: 5X (2016)
Airports: 47 (2013)
country comparison to the world: 93
Airports—with paved runways:
total: 5 (2019)
over 3,047 m: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 1
Airports—with unpaved runways:
total: 42 (2013)
over 3,047 m: 1 (2013)
1,524 to 2,437 m: 8 (2013)
914 to 1,523 m: 26 (2013)
under 914 m: 7 (2013)
Railways: total: 1,244 km (2014)
narrow gauge: 1,244 km 1.000-m gauge (2014)
country comparison to the world: 85
Roadways: total: 20,544 km (excludes local roads) (2017)
paved: 4,257 km (2017)
unpaved: 16,287 km (2017)
country comparison to the world: 110
Waterways: (there are no long navigable stretches of river in
Uganda; parts of the Albert Nile that flow out of Lake
Albert in the northwestern part of the country are
navigable; several lakes including Lake Victoria and Lake
Kyoga have substantial traffic; Lake Albert is navigable
along a 200-km stretch from its northern tip to its southern
shores) (2011) Merchant marine: total: 1
by type: bulk carrier 1 (2017)
country comparison to the world: 176
Ports and terminals: lake port(s): Entebbe, Jinja, Port Bell
(Lake Victoria)','1c061aee51ab7e4c89080cfff138c5ab0cb074f5fea33dc9e70ee6e579a13915','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b91ef9d28385ea92be6b8ea916946b92928804dbdcf5c7a319f887258bb2bff',2020,'AE','United Arab Emirates','military-and-security',1012,'Military expenditures:
5.7% of GDP (2016)
5.64% of GDP (2014)
6.02% of GDP (2013)
5.08% of GDP (2012)
5.45% of GDP (2011)
no public data available for 2015 or after 2016
country comparison to the world: 3
Military and security forces: United Arab Emirates Armed
Forces: Land Forces, Navy, Air Force, Presidential Guard,
Joint Aviation Command; Ministry of Interior: Critical
Infrastructure Coastal Patrol Agency (CICPA) (2019) Military
service age and obligation: 18-30 years of age for compulsory
military service for men; 17 years of age for male
volunteers with parental approval; 24-month general
service obligation, 16 months for secondary school
graduates; women can volunteer to serve for 9 months
regardless of education (2018) TRANSPORTATION
National air transport system: number of registered air Carriers:
12 (2015) inventory of registered aircraft operated by air
carriers: 498 (2015)
annual passenger traffic on registered air Carriers:
84,738,479 (2015)
annual freight traffic on registered air carriers: 16.647
billion mt-km (2015)
Civil aircraft registration country code prefix: A6 (2016)
Airports: 43 (2013)
country comparison to the world: 99
Airports—with paved runways:
total: 25 (2013)
over 3,047 m: 12 (2013)
2,438 to 3,047 m: 3 (2013)
1,524 to 2,437 m: 5 (2013)
914 to 1,523 m: 3 (2013)
under 914 m: 2 (2013)
Airports—with unpaved runways:
total: 18 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 4 (2013)
914 to 1,523 m: 6 (2013)
under 914 m: 6 (2013)
Heliports: 5 (2013)
Pipelines: 533 km condensate, 3277 km gas, 300 km liquid
petroleum gas, 3287 km oil, 24 km oil/gas/water, 218 km
refined products, 99 km water (2013) Roadways: total: 4,080
km (2008)
paved: 4,080 km (includes 253 km of expressways) (2008)
country comparison to the world: 150
Merchant marine: total: 616
by type: container ship 2, general cargo 103, oil tanker 22,
other 489 (2018)
country comparison to the world: 35
Ports and terminals: Major seaport(s): Al Fujayrah, Mina’ Jabal
‘Ali (Dubai), Khor Fakkan (Khawr Fakkan) (Sharjah),
Mubarraz Island (Abu Dhabi), Mina’ Rashid (Dubai), Mina’
Sagr (Ra’s al Khaymah) container port(s) (TEUs): Dubai
Port (15,368,000), Khor Fakkan (Khawr Fakkan) (Sharjah)
(2,321,000) (2017) LNG terminal(s) (export): Das Island
Military expenditures:
2.14% of GDP (est) (2019 est.)
2.13% of GDP (2018)
2.11% of GDP (2017)
2.11% of GDP (2016)
2.05% of GDP (2015)
country comparison to the world: 44
Military and security forces: British Army, Royal Navy (includes
Royal Marines), Royal Air Force (2019) Military service age and
obligation: Slight variations by service, but generally 16-36
years of age for enlisted (with parental consent under 18)
and 18-29 for officers; minimum length of service 4 years;
women serve in military services including ground combat
roles (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
28 (2015) inventory of registered aircraft operated by air
carriers: 1,242 (2015)
annual passenger traffic on registered air Carriers:
131,449,680 (2015)
annual freight traffic on _ registered air carriers:
59,466,504,676 mt-km (2015)
Civil aircraft registration country code prefix: G (2016)
Airports: 460 (2013)
country comparison to the world: 17
Airports—with paved runways:
total: 271 (2013)
over 3,047 m: 7 (2013)
2,438 to 3,047 m: 29 (2013)
1,524 to 2,437 m: 89 (2013)
914 to 1,523 m: 80 (2013)
under 914 m: 66 (2013)
Airports—with unpaved runways:
total: 189 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 26 (2013)
under 914 m: 160 (2013)
Heliports: 9 (2013)
Pipelines: 502 km condensate, 9 km condensate/gas, 28603
km gas, 59 km liquid petroleum gas, 5256 km oil, 175 km
oil/gas/water, 4919 km refined products, 255 km water
(2013) Railways: total: 16,837 km (2015)
standard gauge: 16,534 km 1.435-m gauge (5,357 km
electrified) (2015)
broad gauge: 303 km 1.600-m gauge (in Northern Ireland)
(2015)
country comparison to the world: 17
Roadways: total: 394,428 km (2009)
paved: 394,428 km (includes 3,519 km of expressways)
(2009)
country comparison to the world: 19
Waterways: 3,200 km (620 km used for commerce) (2009)
country comparison to the world: 31
Merchant marine: total: 1,570
by type: bulk carrier 129, container ship 109, general cargo
162, oil tanker 177, other 993 (2018) country comparison
to the world: 18
Ports and terminals: Major seaport(s): Dover, Felixstowe,
Immingham, Liverpool, London, Southampton, Teesport
(England); Forth Ports (Scotland); Milford Haven (Wales) oil
terminal(s): Fawley Marine terminal, Liverpool Bay terminal
(England); Braefoot Bay terminal, Finnart oil terminal,
Hound Point terminal (Scotland) container port(s) (TEUs):
Felixstowe (3,849,700), London (2,431,000), Southampton
(2,040,000) (2017) LNG terminal(s) (import): Isle of Grain,
Milford Haven, Teesside
Transportation—note: begun in 1988 and completed in 1994,
the Channel Tunnel (nicknamed the Chunnel) is a 50.5-km
(31.4-mi) rail tunnel beneath the English Channel at the
Strait of Dover that runs from Folkestone, Kent, England to
Coquelles, Pas-de-Calais in northern France; it is the only
fixed link between the island of Great Britain and mainland
Europe TERRORISM
Terrorist groups—home based:
Continuity Irish Republican Army (CIRA): aim(s): disrupt the
Northern Ireland peace process; remove British rule in
Northern Ireland and, ultimately, unify Ireland area(s) of
operation: based and operationally active primarily in
Belfast and along the Northern Ireland-Ireland border,
where operatives continue to carry out bombings,
assassinations, kidnappings, hijackings, extortion, and
robberies (2018) New Irish Republican Army (NIRA): aim(s): use
violence to remove British rule in Northern Ireland, disrupt
the Northern Ireland peace process, and unify Ireland
area(s) of operation: based and operationally active in
Northern Ireland, where operatives continue to conduct
occasional shootings and small-scale bombings; maintains a
presence in Great Britain note: formerly known as the Real
Irish Republican Army (RIRA) (2018)','9b69bf72190d4e03c9c1eb4589fd185e8b554acfd25efa95aa784f586b79c2a1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efbe581e8ae08bdecea881d4a6efb7235305db51d1d4d4b8a7c8adf6ed9ad765',2020,'SB','Solomon Islands','military-and-security',1025,'Military and security forces: nO regular military forces; Vanuatu
Police Force (VPF; includes Vanuatu Mobile Force (VMF)
and Police Maritime Wing (VPMW)) (2019)','1110790274e0ec4276889651e826d2e596312ccb1ac81510e97438e70df74b35','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80bea5f98d6b0b3a3b021c5951f9c42f77b0d234a664acbb7d6e5369ee975c14',2020,'WF','Wallis and Futuna','military-and-security',1032,'Military—note: defense is the responsibility of France
Military and security forces: in accordance with the Oslo
Accords, the PA is not permitted a conventional military but
maintains security and police forces; PA security personnel
have operated almost exclusively in the West Bank since
HAMAS seized power in the Gaza Strip in 2007; PA forces
include National Security Forces, Presidential Guard, Civil
Police, Preventative Security Service, and the General
Intelligence Service (2019) TRANSPORTATION
Airports: 2 (2013)
country comparison to the world: 210
Airports—with paved runways:
total: 2 (2013)
1,524 to 2,437 m: 1 (2013)
under 914 m: 1 (2013)
Heliports: 1 (2013)
Roadways: total: 4,686 km (2010)
paved: 4,686 km (2010)
note: includes Gaza Strip
country comparison to the world: 145','d51e4832d49d30e9817ffe5247864c1cdff8a7f724901e9bad33924e0698eec9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ab91debac5b7706dece131429448998d9ba6674ec1369af84a8e0928a63e3b5',2020,'MA','Morocco','military-and-security',1044,'Military—note: the United Nations Mission for the
Referendum in Western Sahara (MINURSO) has operated
in the Western Sahara since 1991 in accordance with
settlement proposals accepted in 1988 by Morocco and the
Frente Popular para la Liberacién de Saguia el-Hamra y de
Rio de Oro (Frente POLISARIO); the Mission’s
responsibilities include monitoring the ceasefire, reducing
the threat of mines and unexploded ordnance, and
providing logistic support to the UNHCR-led Confidence
Building Measures pending an agreement to resume those
activities, which were suspended in June 2014; as of
November 2019, MINURSO had about 460 personnel
deployed TRANSPORTATION
Airports: 6 (2013)
country comparison to the world: 179
Airports—with paved runways:
total: 3 (2019)
2,438 to 3,047 m: 3
Airports—with unpaved runways:
total: 3 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 1 (2013)
under 914 m: 1 (2013)
Ports and terminals: Major seaport(s): Ad Dakhla, Laayoune
(El Aaiun) TRANSNATIONAL ISSUES
Disputes—International: many neighboring states reject
Moroccan administration of Western Sahara; several states
have extended diplomatic relations to the “Sahrawi Arab
Democratic Republic” represented by the Polisario Front in
exile in Algeria, while others support Morocco’s proposal to
grant the territory autonomy as part of Morocco, although
no state recognizes Moroccan sovereignty over Western
Sahara; an estimated 100,000 Sahrawi refugees continue
to be sheltered in camps in Tindouf, Algeria, which has
hosted Sahrawi refugees since the 1980s WORLD','0fdc6bff6e46a268cd4ba2c363ede320771f2435070bf2304830c8ef9fbb7b43','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b7d5f7d8b44b8b9c7b7dd6108bfa1b3bf7eb3498634459f34eaf9a87ccdd988',2020,'SA','Saudi Arabia','military-and-security',1051,'Military expenditures:
3.98% of GDP (2014)
4.08% of GDP (2013)
4.57% of GDP (2012)
4.19% of GDP (2011)
note—no reliable information exists following the start of
renewed conflict in 2015
country comparison to the world: 12
Military and security forces: Land Forces (includes seven
Military Regional Commands, supported by Strategic
Reserve Units), Naval and Coastal Defense Forces (includes
Navy Infantry or Marine units and Coast Guard), Air and
Air Defense Force (although it still exists in name, in
practice many of the officers and soldiers in this branch
have been distributed to other military branches and jobs),
Border Guards, Strategic Reserve Forces (supports the
Land Forces at the discretion of the Armed Forces
Commander-in-Chief and also includes a Missile Group,
Presidential Protection Brigades, and Special Operations
Forces), Minister of Defense Intelligence Authority
(consists of the Department of Military Intelligence
[active], Department of Reconnaissance [active],
Department of Military Security [inactive], and the
Electronic Warfare Department [inactive]) (2018) Military
service age and obligation: 18 is the legal minimum age for
voluntary military service; no conscription; 2-year service
obligation (2018) Maritime threats: the International Maritime
Bureau reports offshore waters in the Gulf of Aden are high
risk for piracy; numerous vessels, including commercial
shipping and pleasure craft, have been attacked and
hijacked both at anchor and while underway; crew,
passengers, and cargo have been held for ransom; the
presence of several naval task forces in the Gulf of Aden
and additional anti-piracy measures on the part of ship
operators reduced the incidence of piracy in that body of
water; one attack was reported in 2016 while three ships
reported being fired upon in 2017','121306a16b86bc3aaa748cbe2b14ef783fa0fbe0eb03beaeae9c54c2f57627d5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1500353b3d79fabc08781241c2ff776f71986424db1315ec80bc97a4d85124de',2020,'ZW','Zimbabwe','military-and-security',1059,'Military expenditures:
1.25% of GDP (2018)
1.31% of GDP (2017)
1.43% of GDP (2016)
1.75% of GDP (2015)
1.63% of GDP (2014)
country comparison to the world: 101
Military and security forces: Zambia Defense Force (ZDF):
Zambia Army, Zambia Air Force, Zambia National Service
(support organization); the Zambia Police includes a
paramilitary battalion (2019) Military service age and obligation:
18-25 years of age for male and female voluntary military
service; no conscription; 12-year enlistment period (7 years
active, 5 in the Reserves) (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
1 (2015) inventory of registered aircraft operated by air
carriers: 1 (2015) annual passenger traffic on registered air
carriers: 11,796 (2015) annual freight traffic on registered
air carriers: 79,092,826 mt-km (2015) Civil aircraft registration
country code prefix: 9J (2016) Airports: 88 (2013)
country comparison to the world: 64
Airports—with paved runways:
total: 8 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 3 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 1 (2013)
Airports—with unpaved runways:
total: 80 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 5 (2013)
914 to 1,523 m: 53 (2013)
under 914 m: 21 (2013)
Pipelines: 771 km oil (2013)
Railways: total: 3,126 km (2014) narrow gauge: 3,126 km
1.067-m gauge (2014)
note: includes 1,860 km of the Tanzania-Zambia Railway
Authority (TAZARA) country comparison to the world: 59
Roadways: total: 67,671 km (2018) paved: 14,888 km (2018)
unpaved: 52,783 km (2018)
country comparison to the world: 71
Waterways: 2,250 km (includes Lake Tanganyika and the
Zambezi and Luapula Rivers) (2010) country comparison to
the world: 38
Merchant marine: total: 1
by type: other 1 (2017)
country comparison to the world: 177
Ports and terminals: river port(s): Mpulungu (Zambezi)','8cdf34a25c255c99e51c05dc36eda61276ed093469d3a005a92c7fc4f53f5ec3','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cfcda246b74d21e2f93f15e7b7f3e2d2216141a32d095f3ea9cf84edeb00754',1981,'AF','Afghanistan','geography',3,'Total area: 647,500 km2; land area:
647,500 km2
Comparative area: about the size of Texas
Land boundaries: 5,510 km total
Boundary disputes: none; Pushtunistan
and Baluchistan questions with Pakistan;
periodic disputes with Iran over Helmand
water rights
Climate: arid to semiarid; cold winters
and hot summers
Terrain: mostly rugged mountains; plains
in north and southwest
Land use: 12% arable land; NEGL%
permanent crops; 46% meadows and
pastures; 3% forest and woodland; 39%
other; includes NEGL% irrigated
Environment: damaging earthquakes
occur in Hindu Kush mountains; soil
degradation, desertification, overgrazing,
deforestation, pollution
Special notes: landlocked; narrow and
strategic Vakhan (Wakhan Corridor) pro-
vides direct access to China and separates
Pakistan from USSR
Population: 14,183,671 (July 1987), aver-
age annual growth rate 1.44%; these esti-
mates include an adjustment for emigra-
tion to Pakistan and Iran during recent
years, but do not take into account other
demographic consequences of the Soviet
intervention in Afghanistan
Nationality: noun — Afghan(s); adjective —
Afghan
Ethnic divisions: 50% Pushtun, 25% Tajik,
9% Uzbek, 9% Hazara; minor ethnic
groups include Chahar Aimaks, Turkmen,
Baluch, and others
Religion: 74% Sunni Muslim, 25% Shi''a
Muslim, 1% other
Language: 50% Pashtu, 35% Afghan
Persian (Dari), 11% Turkic languages
(primarily Uzbek and Turkmen), 4% thirty
minor languages (primarily Baluchi and
Pashai); much bilingualism
Life expectancy: men 42.53, women 40.87
(1986)
Literacy: 12%
Labor force: 4.98 million (1980 est);
67.8% agriculture and animal husbandry,
10.2% industry, 6.3% construction, 5.0%
commerce, 7.7% services and other; cur-
rent figures unavailable because of fighting
(1986)
Organized labor: government-controlled
unions are being established','33439fc2a2db7777109f92b986188b3ff2183b167710059be6d753ff9e7bb0d3','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41d834e830456147ddfbb78197ce0b1c2e1135fd3caea3d09f895b0a20cf674a',1981,'AL','Albania','geography',8,'Total area: 28,750 km2; land area: 27,400
km2
Comparative area: slightly larger than
Maryland
Land boundaries: 716 km total
Coastline: 362 km
Maritime claim:
Territorial sea: 15 nm
Boundary disputes: none; Kosovo question
with Yugoslavia; Northern Epirus question
with Greece
Climate: mild temperate; cool, cloudy,
wet winters ; hot, clear, dry summers;
interior is cooler and wetter
Terrain: mostly mountains and hills; small
plains along coast
Land use: 21% arable land; 4% permanent
crops; 15% meadows and pastures; 38%
forest and woodland; 22% other; includes
1% irrigated
Environment: subject to destructive earth-
quakes; tsunami occur along southwestern
coast; deforestation
Special notes: strategic location on Strait
of Otranto linking Adriatic Sea to Mediter-
ranean Sea
Population: 3,085,985 (July 1987), average
annual growth rate 2.03%
Nationality: noun— Albanian(s); adjec-
tive— Albanian
Ethnic divisions: 96% Albanian; remain-
ing 4% are Greeks, Vlachs, Gypsies, Serbs,
and Bulgarians
Religion: Albania claims to be the world''s
first atheist state; all churches and mosques
were closed in 1967 and religious obser-
vances prohibited; pre-1967 estimates of
religious affiliation— 70% Muslim, 20%
Albanian Orthodox, 10% Roman Catholic
Language: Albanian (Tosk is official dia-
lect), Greek
Infant mortality rate: 86.8/1,000 (1971)
Life expectancy: 69
Literacy: 75%
Labor force: 584,000 (1978); about 22%
agriculture, 40% industry and commerce,
38% other (1978)','30fe94f7b9f20a6b3a1962a695eb5d38d27ad41598220abf93b8bdc0741f26a1','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb1a8684d9fe756ac610c54fb0b21d37187db9d5aebbdad41dc9b71b61b41654',1981,'DZ','Algeria','geography',13,'Total area: 2,381,740 km2; land area:
2,381,740 km2
Comparative area: more than three times
the size of Texas
Land boundaries: 6,260 km total
Coastline: 998 km
Maritime claim:
Territorial sea: 12 nm
Climate: arid to semiarid; mild, wet
winters with hot, dry summers along coast;
drier with cold winters and hot summers
on high plateau; sirocco is a hot,
dust/sand-laden wind especially common
in summer
Terrain: mostly high plateau and desert;
some mountains; narrow, discontinuous
coastal plain
Land use: 3% arable land; NEGL% per-
manent crops; 13% meadows and pastures;
2% forest and woodland; 82% other; in-
cludes NEGL% irrigated
Environment: mountainous areas subject
to severe earthquakes; desertification
Special notes: second largest country in
Africa (after Sudan)
Population: 23,460,614 (July 1987), aver-
age annual growth rate 3.10%
Nationality: noun — Algerian(s); adjec-
tive— Algerian
Algeria (continued)
Ethnic divisions: 99% Arab-Berber, less
than 1% European
Religion: 99% Sunni Muslim (state reli-
gion); 1% Christian and Jewish
Language: Arabic (official), French, Berber
dialects
Infant mortality rate: 106/1,000 (1984)
Life expectancy: 60
Literacy: 52%
Labor force: 3.7 million (1984); 40%
industry and commerce, 30% agriculture,
17% government, 10% services; at least
11% of urban labor unemployed
Organized labor: 16-19% of labor force
claimed; General Union of Algerian Work-
ers (UGTA) is the only labor organization
and is subordinate to the National Libera-
tion Front','e17c3d7f6b205f431ca31ab6b2ecb09688117d28958e2d49b1742f5745ac5d54','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ed96418b49a9338f6d6e9891d645dae90ad46c662412d207d6228a23e8c0e43',1981,'AD','Andorra','geography',14,'Total area: 450 km2; land area: 450 km2
Comparative area: about two and one-
half times the size of Washington, D.C.
Land boundaries: 105 km total
Climate: temperate; snowy, cold winters
with cool, dry summers
Terrain: rugged mountains dissected by
narrow valleys
Land use: 2% arable land; 0% permanent
crops; 56% meadows and pastures; 22%
forest and woodland; 20% other
Environment: deforestation, overgrazing
Special notes: landlocked','56d1ea4fb85371186554fcdacac140f026a9e9275e09f08edaa6a30194a0438b','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e51f70076fde7f2cdd96b68de34d35141a6b3bccffde16869f561d9c841c7bd8',1981,'AO','Angola','geography',21,'Total area: 1,246,700 km2; land area:
1,246,700 km2
Comparative area: almost twice the size
of Texas
Land boundaries: 5,070 km total
Coastline: 1,600 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 20 nm
Climate: semiarid in south and along coast
to Luanda; north has cool, dry season (May
to October) and hot, rainy season (Novem-
ber to April)
Terrain: narrow coastal plain rises
abruptly to vast interior plateau
Land use: 2% arable land; NEGL% per-
manent crops; 23% meadows and pastures;
43% forest and woodland; 31% other
Environment: locally heavy rainfall causes
periodic flooding on plateau; desertification
Special notes: Cabinda is separated from
rest of country by Zaire
Population: 7,950,244 (July 1987), average
annual growth rate 2.86%; includes Cabi-
nda 109,802, average annual growth rate
6.64%
Nationality: noun — Angolan(s); adjective —
Angolan
Ethnic divisions: 37% Ovimbundu, 25%
Kimbundu, 13% Bakongo, 2% Mestico, 1%
European
Religion: 68% Roman Catholic, 20%
Protestant, about 12% indigenous beliefs
Language: Portuguese (official); various
Bantu dialects
Infant mortality rate: 148/1,000 (1983)
Life expectancy: men 40.6, women 42.9
Literacy: 20%
Labor force: 2,783,000 economically
active (mid-1985 est); 85% agriculture,
15% industry
Organized labor: about 450,695 (1980)','e6a902e6650ed9110c68aa0e2e9c77f4ad94babec1b50c03a3c605983e5f1a1e','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41b01c620e51a6aa22507f2a292b0b9987349827e3db12d9dd07c1d50935a992',1981,'AI','Anguilla','geography',25,'Total area: 91 km2; land area: 91 km2
Comparative area: about one-half the size
of Washington, D.C.
Coastline: about 61 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; moderated by northeast
trade winds
Terrain: flat and low-lying island of coral
and limestone
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
mostly rock with sparse scrub oak, few
trees, some commercial salt ponds
Environment: frequent hurricanes, other
tropical storms (July to October)
Special notes: northernmost of Leeward
Islands
Population: 6,828 (1987), average annual
growth rate 0.69%
Nationality: noun — Anguillan(s); adjec-
tive— Anguillan
Ethnic divisions: mainly of black African
descent
Beligion: Anglican, Methodist, and Catho-
lic
Language: English (official)
Literacy: 80%
Labor force: 2,000 Anguillans living
overseas send remittances home; 26.4%
unemployed (1984)','24be22944d9c895025890600b2b111ee77e51a934a28ec974c11a4e54dadea1e','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23bb6b5ce1ab3a695cc79f54bc5199bbe6d1c2e38c9e771ff0c456cd0d55b50f',1981,'AG','Antigua and Barbuda','geography',29,'Total area: 440 km2; land area: 440 km2
Comparative area: about two and one-
half times the size of Washington, D.C.
Coastline: 153 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical marine; little seasonal
temperature variation
Terrain: mostly low-lying with some
higher volcanic areas
Land use: 18% arable land; 0% permanent
crops; 7% meadows and pastures; 16%
forest and woodland; 59% other
Environment: subject to hurricanes and
tropical storms (June to October); insuffi-
cient freshwater resources; deeply in-
dented coastline provides many natural
harbors
Special notes: about 650 km from Puerto
Rico','adcd35aaa2215bf6ee4c61bf444faf3bceb1f9cca1512f72f6baa7948446b935','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1217acc3698beadc082a89cf515187aa97a05c6577f2244580c481022b4a91b5',1981,'AR','Argentina','geography',34,'Total area: 2,766,890 km2; land area:
2,736,690 km2
Comparative area: about four times the
size of Texas
Land boundaries: 9,414 km total
Coastline: 4,989 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm (overflight and
navigation permitted beyond 12 nm)
Boundary disputes: Uruguay; short section
with Chile is indefinite; claims Falkland
Islands (Islas Malvinas) which are adminis-
tered by UK; territorial claim in Antarc-
tica
Climate: mostly temperate; arid in south-
east; subantarctic in southwest
Terrain: rich plains of the Pampas in
northern half, flat to rolling plateau of
Patagonia in south, rugged Andes along
western border
Land use: 9% arable land; 4% permanent
crops; 52% meadows and pastures; 22%
forest and woodland; 13% other; includes
1% irrigated
Environment: Tucuman and Mendoza
areas in Andes subject to earthquakes;
pamperos are violent windstorms that can
strike Pampas and northeast; irrigated soil
degradation; desertification
Special notes: second largest country in
South America (after Brazil); strategic
location relative to sea lanes between
Atlantic and Pacific Oceans (Strait of
Magellan, Beagle Channel, Drake Passage)
Population: 31,144,775 (July 1987), aver-
age annual growth rate 1.27%
Nationality: noun — Argentine(s); adjec-
tive— Argentine
Ethnic divisions: 85% white, 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic
(less than 20% practicing), 2% Protestant,
2% Jewish, 6% other
Language: Spanish (official), English,
Italian, German, French
Infant mortality rate: 36/1,000 (1983)
Life expectancy: 68
Literacy: 94%
Labor force: 16.8 million (1984 est);
15.9% agriculture, 24.3% manufacturing,
13.2% commerce, 11.5% transport and
communications, 7.7% finance and bank-
ing, 4.4% utilities, 3.6% construction, 2.7%
mining, 16.7% services and other; 6.3%
unemployment (April 1985)
Organized labor: 3 million; about 33% of
labor force','0d3e31f6ef61df3a77381fd1c86add879a78d286d630d637134743c97d99b3b1','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8f36b47156a3f768efa2e4fe4b33f593c26af31b7a8e57723c5afa13b5ac254',1981,'AW','Aruba','geography',37,'Total area: 193 km2; land area: 193 km2
Comparative area: slightly larger than
Washington, D.C.
Coastline: about 72 km
Maritime claims:
Territorial sea: 12 nm
Climate: tropical marine; little seasonal
temperature variation
Terrain: flat with a few hills; scant vegeta-
tion
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: lies outside the Caribbean
hurricane belt
Special notes: 28 km from Venezuela
Population: 62,125 (1987 est), average
annual growth rate 0.34%
Nationality: noun — Aruban(s); adjective —
Aruban
Ethnic divisions: 85% mixed African;
remainder Carib Indian, European, Latin,
and Oriental
Religion: 82% Roman Catholic, 8% Protes-
tant; also small Hindu, Muslim, Confucian,
and Jewish minority
Language: Dutch (official), Papiamento (a
Spanish, Portuguese, Dutch, English dia-
lect), English (widely spoken), Spanish
Literacy: 95%
Labor force: 30% oil refining; 10% unem-
ployment','835f6e84bf3eccf82e827fb510e2cda34c7649145b29483b9345992eef456ba8','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('583f8f826e35fc76a59c6d2a4da3d02ec49869dd9deb63cc9da064209e934267',1981,'AU','Australia','geography',40,'Total area: 7,686,850 km2; land area:
7,617,930 km2
Comparative area: almost as large as
conterminous US
Coastline: 25,760 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: none; maritime dis-
pute with Indonesia; territorial claim in
Antarctica (Australian Antarctic Territory)
Climate: generally arid to semiarid; tem-
perate in south and east; tropical in north
Terrain: mostly low plateau with deserts;
fertile plain in southeast
Land use: 6% arable land; NEGL% per-
manent crops; 58% meadows and pastures;
14% forest and woodland; 22% other;
includes NEGL% irrigated
Environment: subject to severe droughts
and floods; cyclones along coast; limited
freshwater availability; irrigated soil degra-
dation; regular, tropical, invigorating, sea
breeze known as the doctor occurs along
west coast in summer; desertification
Special notes: world''s smallest continent
but sixth largest country
Population: 16,072,986 (July 1987), aver-
age annual growth rate 1.21%
Nationality: noun — Australian(s); adjec-
tive— Australian
Ethnic divisions: 96% Caucasian, 4%
Asian, Aboriginal, and other
Religion: 26.1% Anglican, 26.0% Roman
Catholic, 24.3% other Christian
Language: English, native languages
Infant mortality rate: 10/1,000 (1983)
Life expectancy: men 72.1, women 78.7
(1983)
Literacy: 98.5%
Labor force: 7.6 million (November 1986);
26.9 manufacturing and industry; 22.4
public and community services; 20.0
wholesale and retail trade; 18.1 finance
and services; 6.0% agriculture; 8.2% unem-
ployment (January 1987)
Organized labor: 62% of total employees
(1986)','981a19696019ac3f5765e7811ef071dacefd62fd034a4e0dab94863570863e23','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d382c8feb1f0fa7392f57d84c3f509b46ddcb93330f7e4305a929d65ddc23f10',1981,'AT','Austria','geography',45,'Total area: 83,850 km2; land area: 82,730
km2
Comparative area: slightly smaller than
Maine
Land boundaries: 2,582 km total
Boundary disputes: none; South Tyrol
question with Italy
Climate: temperate; continental, cloudy;
cold winters with frequent rain in low-
lands and snow in mountains; cool sum-
mers with occasional showers
Terrain: mostly mountains with Alps in
west and south; low local relief and gentle
slopes along eastern and northern margins
Land use: 17% arable land; 1% permanent
crops; 24% meadows and pastures; 39%
forest and woodland; 19% other; includes
NEGL% irrigated
Environment: due to steep slopes, poor
soils, and cold temperatures, population is
concentrated on eastern lowlands
Special notes: landlocked; strategic loca-
tion at the crossroads of central Europe
with many easily traversable Alpine passes
and valleys
Total area: 13,940 km2; land area: 10,070
km2
Comparative area: about the size of
Connecticut
Coastline: 3,542 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical marine; moderated by
warm waters of Gulf Stream
Terrain: long, flat, coral formations with
some low, rounded hills
Land use: 1% arable land; NEGL% per-
manent crops; NEGL% meadows and
pastures; 32% forest and woodland; 67%
other
Environment: subject to hurricanes and
other tropical storms; archipelago of about
700 islands and keys
Special notes: strategic location adjacent
to US and Cuba','755226dc40c4baaebd0621dfe68347751e63a05c9f741537c5b878906b68e985','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a20129a0d4b804cb10afc99c2e3011148af865d9b21e55aac2e5dc82f523525b',1981,'BH','Bahrain','geography',51,'Total area: 620 km2; land area: 620 km2
Comparative area: about three times the
size of Washington, D. C.
Coastline: 161 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 3 nm
Boundary disputes: none; territorial dis-
pute with Qatar over the island of Hawar
and its ring of islets
Climate: arid; mild, pleasant winters; very
hot, humid summers
Terrain: mostly low desert plain rising
gently to low central escarpment
Land use: 2% arable land; 2% permanent
crops; 6% meadows and pastures; 0% forest
and woodland; 90% other; includes
NEGL% irrigated
Environment: subsurface water sources
being rapidly depleted (requires develop-
ment of desalination facilities); dust storms;
desertification
Special notes: close proximity to primary
Middle East crude oil sources and strategic
location in Persian Gulf through which
much of western world''s crude oil must
transit to reach open ocean
Population: 464,102 (July 1987), average
annual growth rate 3.54%
16','8f3a713f996783754b79e5e967cf15974a40d8ff73201a351abd78477f00ad1d','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a4a29368a2e977aa9bad381485286754f4691da7f014655a1955a2d1632578b',1981,'BD','Bangladesh','geography',52,'Nationality: noun — Bahraini(s); adjec-
tive— Bahraini
Ethnic divisions: 63% Bahraini, 13%
Asian, 10% other Arab, 8% Iranian, 6%
other
Religion: Muslim (70% Shi''a, 30% Sunni)
Language: Arabic (official); English also
widely spoken; Farsi, Urdu
Literacy: 40%
Labor force: 140,000 (1982); 42% of labor
force is Bahraini; 85% industry and com-
merce, 5% agriculture, 5% services, 3%','a9be7283f4cf14e325eb39fbdc829e33d63cd539ffaf1134ec1ac142d8f3086d','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d607bbb9e6c3c1e6884c9e8f784425deac7f439febfa95219dda45584bf03ca2',1981,'SA','Saudi Arabia','geography',57,'Total area: 144,000 km2; land area:
133,910 km2
Comparative area: slightly smaller than
Wisconsin
Land boundaries: 2,535 km total
Coastline: 580 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: up to outer limits of
continental margin
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: India
Climate: tropical; cool, dry winter (Octo-
ber to March); hot, humid summer (March
to June); cool, rainy monsoon (June to
October)
Terrain: mostly flat alluvial plain; hilly in
southeast
Land use: 67% arable land; 2% permanent
crops; 4% meadows and pastures; 16%
forest and woodland; 11% other; includes
14% irrigated
Environment: vulnerable to droughts;
much of country routinely flooded during
summer monsoon season; overpopulation;
deforestation
Special notes: almost completely sur-
rounded by India; Joint River Commission
on water sharing with upstream riparian
Total area: 2,149,690 km2; land area:
2,149,690km2
Comparative area: about one-third the
size of US
Land boundaries: 4,537 km total
Coastline: 2,510 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: not specific
Territorial sea: 12 nm
Boundary disputes: none; no defined
boundaries with Oman, PDRY, UAE,
YAR; shares Neutral Zone with Iraq
Climate: harsh, dry desert with great
extremes of temperature
Terrain: mostly uninhabited, sandy desert
Land use: 1% arable land; NEGL% per-
manent crops; 39% meadows and pastures;
1% forest and woodland; 59% other; in-
cludes NEGL% irrigated
Environment: no perennial rivers or
permanent water bodies; developing exten-
sive coastal seawater desalination facilities;
desertification
Special notes: extensive coastlines on
Persian Gulf and Red Sea provide great
leverage on shipping (especially crude oil)
through Persian Gulf and Suez Canal
Population: 14,904,794 (July 1987), aver-
age annual growth rate 4.95%
Nationality: noun — Saudi(s); adjective —
Saudi or Saudi Arabian
Ethnic divisions: 90% Arab, 10% Afro-
Asian
Religion: 100% Muslim
Language: Arabic
Infant mortality rate: 118/1,000 (1983)
Life expectancy: 54
Literacy: 52%
Labor force: about one-third (one-half
foreign) of population; 45% commerce,
services, government, and other; 30%
agriculture; 15% construction; 5% industry;
5% oil and mining
Total area: 28,450 km2; land area: 27,540
km2
Comparative area: slightly larger than
Maryland
Coastline: 5,313 km
Maritime claims: (measured from claimed
archipelagic baselines)
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical monsoon; few extremes
of temperature and weather
Terrain: mostly ruggedly mountainous
with some low coral atolls
Land use: 1% arable land; 1% permanent
crops; 1% meadows and pastures; 93%
forest and woodland; 4% other
Environment: subject to typhoons, but
rarely destructive; geologically active
region with frequent earth tremors
Special notes: none
Population: 301,180 (July 1987), average
annual growth rate 3.62%
Nationality: noun — Solomon Islanders);
adjective — Solomon Islander
Ethnic divisions: 93.0% Melanesian, 4.0%
Polynesian, 1.5% Micronesian, 0.8% Euro-
pean, 0.3% Chinese, 0.4% other
Religion: almost all at least nominally
Christian; Anglican, Seventh-Day Advent-
ist, and Roman Catholic churches domi-
nant
220
Climate: desert; extraordinarily hot and
dry
Terrain: mostly upland desert plains;
narrow, flat, sandy coastal plain backed by
flat-topped hills and rugged mountains
Land use: 1% arable land; NEGL% per-
manent crops; 27% meadows and pastures;
7% forest and woodland; 65% other; in-
cludes NEGL% irrigated
Environment: scarcity of natural fresh
water resources; overgrazing; soil erosion;
desertification
Special notes: controls southern
approaches to Bab el Mandeb linking Red
Sea to Gulf of Aden, one of world''s most
active shipping lanes
267
Yemen, People''s Democratic
Republic of
(South Yemen) (continued)','aeeea9994b3cec656484cfd77fc21f9b33ba6cf71be328a1b48d8f561fa2fbe3','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('014f089bab678fa24a070bcb6f68e659d0b89c723053e4f8cc24fb67e94a4ff7',1981,'IN','India','geography',58,'17
Bangladesh (continued)
Population: 107,087,586 (July 1987),
average annual growth rate 2.70%
Nationality: noun — Bangladeshi(s); adjec-
tive— Bangladesh
Ethnic divisions: 98% Bengali; 250,000
Biharis and fewer than one million tribals
Religion: 83% Muslim, about 16% Hindu,
less than 1% Buddhist, Christian, and other
Language: Bangla (official), English widely
used
Infant mortality rate: 119.4/1,000 (1984)
Life expectancy: 53.9
Literacy: 23% (31% men, 16% women)
Labor force: 35. 1 million (FY86); extensive
export of labor to Saudi Arabia, UAE,
Oman, and Kuwait; 74% of labor force is
in agriculture, 15% services, 11% industry
and commerce; unemployment and under-
employment 40% (est.)
Total area: 3,287,590 km2; land area:
2,973,190 km2
Comparative area: about one-third the
size of US
Land boundaries: 12,700 km total
Coastline: 7,000 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12
Boundary disputes: Bangladesh, China,
Cease-Fire Line with Pakistan
Climate: varies from tropical monsoon in
south to temperate in north
Terrain: upland plain (Deccan Plateau) in
south, flat to rolling plain along the Ganges
River, deserts in west, Himalayas in north
Land use: 55% arable land; 1% permanent
crops; 4% meadows and pastures; 23%
forest and woodland; 17% other; includes
13% irrigated
Environment: droughts, flash floods, severe
thunderstorms common; deforestation; soil
erosion; overgrazing; air and water pollu-
tion; desertification
Special notes: dominates South Asian
subcontinent; near important Indian
Ocean trade routes; Joint River Commis-
sion on water sharing with downstream
riparian Bangladesh
112
Population: 800,325,817 (July 1987),
average annual growth rate 2.07%
Nationality: noun — Indian(s); adjective —
Indian
Ethnic divisions: 72% Indo-Aryan, 25%
Dravidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 11.0% Muslim,
2.6% Christian, 2.0-2.5% Sikh, 0.7% Bud-
dhist, 0.2% other
Language: Hindi, English, and 14 other
official languages; 24 languages spoken by
a million or more persons each; numerous
other languages and dialects, for the most
part mutually unintelligible; Hindi is the
national language and primary tongue of
30 percent of the people; English enjoys
associate status but is the most important
language for national, political, and com-
mercial communication; Hindustani, a
popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Infant mortality rate: 116/1,000 (1984
est.)
Life expectancy: 54.9
Literacy: 36%
Labor force: (1984/85) about 284.4 mil-
lion; 67% agriculture; more than 10%
unemployed and underemployed
Organized labor: less than 5% of total
labor force','2beea0b120173f2ca9d8a7d4879dedb4715a587dd2d5427ab0a9e9b8895233d2','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e74f98d6915e59abd0c331962aba80e523049aed1c7c2a00816847e583fd3202',1981,'BB','Barbados','geography',63,'Total area: 430 km2; land area: 430 km2
Comparative area: about twice the size of
Washington, D. C.
Coastline: 97 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; rainy season (June to
November)
Terrain: relatively flat; rises gently to
central highland region
Land use: 77% arable land; 0% permanent
crops; 9% meadows and pastures; 0% forest
and woodland; 14% other
Environment: subject to hurricanes (espe-
cially June to November)
Special notes: easternmost Caribbean
island
Population: 323,839 (July 1987), average
annual growth rate 3.04%
Nationality: noun — Barbadian(s); adjec-
tive — Barbadian
Ethnic divisions: 80% African, 16%
mixed, 4% European
Religion: 70% Anglican, 9% Methodist, 4%
Roman Catholic, 17% other, including
Moravian
Language: English
Infant mortality rate: 26.3/1,000 (1984)
Life expectancy: 70.8
Literacy: 99%
Labor force: 112,300 (1985 est); 37%
services and government; 22% commerce;
22% manufacturing and construction; 9%
transportation, storage, communications,
and financial institutions; 8% agriculture;
and 2% utilities
Organized labor: 32%','3893188511e1bb20c1f18be6a833a344aad991c3fc82c1e75e03bdc56711befc','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('987902261da7c99bf00e4e9fc7b9acf477c9f3addc6567dd37faf777eee9c30f',1981,'BE','Belgium','geography',68,'Total area: 30,510 km2; land area: 30,230
km2
Comparative area: slightly larger than
Maryland
Land boundaries: 1,377 km total
Coastline: 64 km
Maritime claims:
Continental shelf: not specific
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: temperate; mild winters, cool
summers; rainy, humid, cloudy
Terrain: flat coastal plains in northwest,
central rolling hills, rugged mountains of
Ardennes Forest in southeast
Land use: 24% arable land; 1% permanent
crops; 20% meadows and pastures; 21%
forest and woodland; 34% other; includes
NEGL% irrigated
Environment: air and water pollution
Special notes: majority of West European
capitals within 1,000 km of Brussels;
crossroads of Western Europe
Population: 9,873,066 (July 1987), average
annual growth rate 0.07%
Nationality: noun — Belgian(s); adjective —
Belgian
Ethnic divisions: 55% Fleming, 33%
Walloon, 12% mixed or other
20
Religion: 75% Roman Catholic; remainder
Protestant, none, or other
Language: 56% Flemish (Dutch), 32%
French, 1% German; 11% legally bilingual;
divided along ethnic lines
Infant mortality rate: 11.15/1,000(1979)
Life expectancy: men 68.6, women 75.1
Literacy: 98%
Labor force: 4 million; 58% services, 37%
industry, 5% agriculture; 13.6% unem-
ployed (1985)
Organized labor: 70% of labor force','18396ca1d6ba5ceabcc7b63ec12e306452f5a671e0f4963a5a865b7bd7b3e469','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0bc52a741b6044607c77fafebf4c67116580e597318bf62fefa20825c85259b',1981,'BZ','Belize','geography',70,'Total area: 22,960 km2; land area: 22,800
km2
Comparative area: slightly larger than
Massachusetts
Land boundaries: 515 km total
Coastline: 386 km
Maritime claim:
Territorial sea: 3 nm
Boundary disputes: none; claimed by','3e0d36ff52956933c36ef5207e5d97f5aa0e32ce37f2200634dfa4b0238b9c08','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47513615c0706ef2d7e5b7174dcbcd28ed2542359dbbb3835b2ca30c21c5127d',1981,'GT','Guatemala','geography',71,'Climate: tropical; very hot and humid;
rainy season (May to February)
Terrain: flat, swampy coastal plain; low
mountains in south
Land use: 2% arable land; NEGL% per-
manent crops; 2% meadows and pastures;
44% forest and woodland; 52% other;
includes NEGL% irrigated
Environment: frequent devastating hurri-
canes (September to December) and
coastal flooding (especially in south); defor-
estation
Special notes: national capital moved 80
km inland from Belize City to Belmopan
because of hurricanes; only country in
Central America without a coastline on the
Pacific Ocean
Population: 168,204 (July 1987), average
annual growth rate 1.95%
Nationality: noun — Belizean(s); adjec-
tive— Belizean
Ethnic divisions: 51% black, 22% mestizo,
19% Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican,
Seventh-Day Adventist, Methodist, Baptist,
Jehovah''s Witnesses, Mennonite
Language: English (official), Spanish Maya,
Carib
Infant mortality rate: 56/1,000 (1984)
Life expectancy: 66
Literacy: about 90%
Labor force: 51,500 (1985); 30.0% agricul-
ture, 16.0% services, 15.4% government,
11.2% commerce, 10.3% manufacturing;
shortage of skilled labor and all types of
technical personnel; over 14% are unem-
ployed
Organized labor: 15% of labor force; 7 of
16 registered unions currently active
Total area: 108,890 km2; land area:
108,430 km2
Comparative area: about the size of
Tennessee
Land boundaries: 1,625 km total
Coastline: 400 km
Maritime claims:
Continental shelf: not specific
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claims Belize
Climate: tropical; hot, humid in lowlands;
cooler in highlands
Terrain: mostly mountains with narrow
coastal plains and rolling limestone plateau
(Peten)
Land use: 12% arable land; 4% permanent
crops; 12% meadows and pastures; 40%
forest and woodland; 32% other; includes
1% irrigated
Environment: numerous volcanoes in
mountains with frequent violent earth-
quakes; Caribbean coast subject to hurri-
canes and other tropical storms; deforesta-
tion; soil erosion; water pollution
Special notes: no natural harbors on west
coast
Population: 8,622,387 (July 1987), average
annual growth rate 2.45%
Nationality: noun — Guatemalan(s); adjec-
tive— Guatemalan
Ethnic divisions: 56% Ladino (mestizo
and westernized Indian), 44% Indian
Religion: predominantly Roman Catholic;
also Protestant, traditional Mayan
Language: Spanish, but over 40% of the
population speaks an Indian language as a
primary tongue (18 Indian dialects, includ-
ing Quiche, Cakchiquel, Kekchi)
Infant mortality rate: 66/1,000 (1982)
Life expectancy: 60
Literacy: 50%
Labor force (1985): 2.5 million; 57.0%
agriculture, 14.0% manufacturing, 13.0%
services, 7.0% commerce, 4.0% construc-
tion, 3.0% transport, 0.8% utilities, 0.4%
mining; unemployment and underem-
ployment 40%
Organized labor: 10% of labor force
(1986)','ca56e410982a0053e5bb5ea034d525aae399a7fd85b8863b2ea9c0551eb899e0','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da39806e97b66da89b1c4cd4c038df5f469f64d9ea8a2053ec187f455afb12fe',1981,'BJ','Benin','geography',76,'Total area: 112,620 km2; land area:
110,620 km2
Comparative area: slightly smaller than
Pennsylvania
Land boundaries: 1,963 km total
Coastline: 121 km
Maritime claim:
Territorial sea: 200 nm
Climate: tropical; hot, humid in south;
arid in north
Terrain: mostly flat to undulating plain;
some hills and low mountains
Land use: 12% arable land; 4% permanent
crops; 4% meadows and pastures; 35%
forest and woodland; 45% other; includes
NEGL% irrigated
Environment: hot, dry, dusty harmattan
wind may affect north in winter; defores-
tation; desertification
Special notes: recent droughts have se-
verely affected marginal agriculture in
north; no natural harbors
Population: 4,339,096 (July 1987), average
annual growth rate 3.52%
Nationality: noun — Beninese (sing., pi.);
adjective — Beninese
Ethnic divisions: 99% African (42 ethnic
groups, most important being Fon, Adja,
Yoruba, Bariba); 5,500 Europeans
Benin (continued)
Religion: 70% indigenous beliefs, 15%
Muslim, 15% Christian
Language: French (official); Fon and
Yoruba most common vernaculars in
south; at least six major tribal languages in
north
Infant mortality rate: 45/1,000 (1984)
Life expectancy: 46.9
Literacy: 11%
Labor force: 1.5 million (1982); 60% of
labor force employed in agriculture; less
than 2% of the labor force work in the
industrial sector, and the remainder are
employed in transport, commerce, and
public services
Organized labor: about 75% of wage
earners (two major and several minor
unions)','4567a992892b7d2db30b19ed5710397cb931d76d8edf255b6a4a4d78c9be90d6','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ee2bd2110abe677dc0d2b9bc345a00df25b5a6b52b3807ab191d91a434edf7c',1981,'BM','Bermuda','geography',78,'Total area: 50 km2; land area: 50 km2
Comparative area: about one-third the
size of Washington, D.C.
Coastline: 103 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: subtropical; mild, humid; gales,
strong winds common in winter
Terrain: low hills separated by fertile
depressions
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 20%
forest and woodland; 80% other; includes
11% leased for military bases
Environment: ample rainfall, but no rivers
or freshwater lakes; consists of about 360
small coral islands
Special notes: 1,050 km east of North
Carolina; some reclaimed land leased by
US Government
Population: 58,033 (July 1987), average
annual growth rate 0.18%
Nationality: noun — Bermudian(s); adjec-
tive— Bermudian
Ethnic divisions: 61% black, 39% white
and other
Religion: 37% Anglican, 14% Roman
Catholic, 10% African Methodist Episcopal
(Zion), 6% Methodist, 5% Seventh-Day
Adventist, 28% other
Language: English
Infant mortality rate: 7.1/1,000 (1985)
Life expectancy: men 69, women 76
Literacy: 98%
Labor force: 32,000 employed (1984); 25%
clerical, 22% services, 21% laborers, 13%
professional and technical, 10% adminis-
trative and managerial, 7% sales, 2%
agriculture and fishing
Organized labor: 8,573 members (1985);
largest union is Bermuda Industrial Union','77be92e10354c5342e97ce34703ab8325d7ef821ae580d60d85d72156c8f9578','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4d72d28759bcce132183e45c4085f4911a4b0944191cc76dbe3c66470d987c5',1981,'BT','Bhutan','geography',82,'Total area: 47,000 km2; land area: 47,000
km2
Comparative area: the size of Vermont
and New Hampshire combined
Land boundaries: 870 km total
Climate: varies; tropical in southern
plains; cool winters and hot summers in
central valleys; severe winters and cool
summers in Himalayas
Terrain: mostly mountainous with some
fertile valleys and savanna
Land use: 2% arable land; NEGL% per-
manent crops; 5% meadows and pastures;
70% forest and woodland; 23% other
Environment: violent storms coming down
from the Himalayas were the source of the
country name which translates as Land of
the Thunder Dragon
Special notes: landlocked; strategic loca-
tion between China and India; controls
several key Himalayan mountain passes
Total area: 1,098,580 km2; land area:
1,084,390 km2
Comparative area: about the size of
California and Texas combined
Land boundaries: 6,083 km total
Boundary disputes: none; has wanted a
sovereign corridor to the Pacific Ocean
since Atacama area was lost to Chile in
1884; dispute with Chile over Rio Lauca
water rights
Climate: varies with altitude; humid and
tropical to cold and semiarid
Terrain: high plateau, hills, lowland plains
Land use: 3% arable land; NEGL% per-
manent crops; 25% meadows and pastures;
52% forest and woodland; 20% other;
includes NEGL% irrigated
Environment: cold, thin air of high pla-
teau makes physical activity very difficult;
overgrazing; soil erosion; desertification
Special notes: landlocked; shares control
of Lago Titicaca, world''s highest navigable
lake, with Peru','59226b1ec92b3c3ee3b477aed2e34bf8f48ec419cc365d8f77fc449dfb4a59e3','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2649e9589e9278e4ac8d952839f1acb0c8a593a9e48974961afbf1b67e3b7c3',1981,'BW','Botswana','geography',88,'Total area: 600,370 km2; land area:
585,370 km2
Comparative area: slightly smaller than
Texas
Land boundaries: 3,774 km total
Boundary disputes: short section with
Namibia is indefinite
Climate: tropical; warm winters and hot
summers
Terrain: predominately flat to gently
rolling tableland
Land use: 2% arable land; 0% permanent
crops; 75% meadows and pastures; 2%
forest and woodland; 21% other; includes
NEGL% irrigated
Environment: continuing drought severely
affecting important cattle industry; over-
grazing; desertification
Special notes: landlocked; very long
boundary with South Africa
Population: 1,149,141 (July 1987), average
annual growth rate 3.48%
Nationality: noun — Motswana (sing.),
Botswana (pi.); adjective — Botswana
Ethnic divisions: 95% Batswana; about 4%
Kalanga, Basarwa, and Kgalagadi; about
1% white
Religion: 50% indigenous beliefs, 50%
Christian
Language: English (official), Setswana
28
Infant mortality rate: about 63/1,000
(1985)
Life expectancy: 63.5 (1985)
Literacy: about 24% in English; about 35%
in Tswana; less than 1% secondary school
graduates
Labor force: about 400,000 total; 110,000
formal sector employees (1984); most
others are engaged in cattle raising and
subsistence agriculture; 40,000 formal
sector employees spend at least six to nine
months per year as wage earners in South
Africa (1980); 17% unemployment (1983)
Organized labor: 16 trade unions orga-
nized','b2aa39fa7d1e46ac3216c8b79931943071b28f66b9db69f365e136c39f5a8e88','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6536dab6e9747465e8be90fd5e1297fa8d1877996f39389f21c58e13f5b9e18',1981,'BR','Brazil','geography',91,'Total area: 8,511,970 km2; land area:
8,456,510 km2
Comparative area: larger than contermi-
nous US
Land boundaries: 13,076 km total
Coastline: 7,491 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm
Boundary disputes: Paraguay (Rio Parana
area), Uruguay; claims a Zone of Interest
in Antarctica
Climate: mostly tropical, but temperate in
south
Terrain: mostly flat to rolling lowlands in
north; some plains, hills, mountains, and
narrow coastal belt
Land use: 7% arable land; 1% permanent
crops; 19% meadows and pastures; 67%
forest and woodland; 6% other; includes
NEGL% irrigated
Environment: recurrent droughts in north-
east; floods and frost in south; deforestation
in Amazon basin
Special notes: largest country in South
America; shares common boundaries with
every South American country except
Chile and Ecuador
Total area: 80 km2; land area: 80 km2
Comparative area: less than one-half the
size of Washington, D.C.
Coastline: about 120 km
Maritime claim:
Territorial sea: 3 nm
Boundary disputes: none; Diego Garcia
claimed by Mauritius
Climate: tropical marine; hot, humid,
moderated by trade winds
Terrain: flat and low (up to 4 meters in
elevation)
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: consists of 2,300 islands
Special notes: Diego Garcia, largest and
southernmost island, occupies strategic
location in central Indian Ocean
Population: no permanent civilian popula-
tion; formerly about 3,000 islanders
Ethnic divisions: civilian inhabitants,
known as the Hois, evacuated to Mauritius
before construction of UK and US defense
facilities
Total area: 150 km2; land area: 150 km2
Comparative area: about the size of
Washington, D. C.
Coastline: 80 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: subtropical; humid; temperatures
moderated by trade winds
Terrain: coral islands relatively flat; volca-
nic islands steep, hilly
Land use: 20% arable land; 1% permanent
crops; 33% meadows and pastures; 1%
forest and woodland; 33% other
Environment: subject to hurricanes and
tropical storms
Special notes: strong ties to nearby US
Virgin Islands and Puerto Rico
Population: 12,374 (July 1987), average
annual growth rate 2.12%
Nationality: noun — Virgin Islanders);
adjective — Virgin Islander
Ethnic divisions: over 90% black, remain-
der of white and Asian origin
Religion: majority Methodist; others in-
clude Anglican, Church of God, Seventh-
Day Adventist, Baptist, and Roman
Catholic
Language: English (official)
Literacy: 98.3%
Work force: 4,911 (1980)
Total area: 5,770 km2; land area: 5,270
km2
Comparative area: slightly larger than
Delaware
Land boundary: 381 km with Malaysia
Coastline: 161 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; possible territo-
rial claim in complex dispute over Spratly
Islands involving China, Malaysia, Philip-
pines, Taiwan, and Vietnam
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to moun-
tains in east; hilly lowland in west
Land use: 1% arable land; 1% permanent
crops; 1% meadows and pastures; 79%
forest and woodland; 18% other; includes
NEGL% irrigated
Environment: typhoons, earthquakes, and
severe flooding are rare
Special notes: close to vital sea lanes
through South China Sea linking Indian
and Pacific Oceans; two parts physically
separated by Malaysia; almost an enclave
of Malaysia
Population: 249,961 (July 1987), average
annual growth rate 3.67%
Nationality: noun — Bruneian(s); adjec-
tive— Bruneian
Ethnic divisions: 64% Malay, 20% Chi-
nese, 16% other
Religion: 60% Muslim (official); 8% Chris-
tian; 32% Buddhist and indigenous beliefs
Language: Malay (official), English, and
Chinese
Life expectancy: 73.7
Literacy: 45%
Labor force: 68,128 (includes members of
the Army); 50.4% production of oil, natu-
ral gas, and construction; 47.6% trade,
services, and other; 2.0% agriculture,
forestry, and fishing (1984)
Organized labor: 2% of labor force','cc13fffba61761e8fabf8775328423a29264daafec616851c871f0e06b3eba13','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a40fc48724ea6a104e7d4ebe430cb6bf0d9b94c9e76e76699d1238e259b35cc',1981,'BG','Bulgaria','geography',98,'Total area: 110,910 km2; land area:
110,550 km2
Comparative area: slightly larger than
Ohio
Land boundaries: 1,883 km total
Coastline: 354 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Macedonia
question with Greece and Yugoslavia
Climate: temperate; cold, damp winters;
hot, dry summers
Terrain: mostly mountains with lowlands
in north and south
Land use: 34% arable land; 3% permanent
crops; 18% meadows and pastures; 35%
forest and woodland; 10% other; includes
11% irrigated
Environment: subject to earthquakes,
landslides; deforestation
Special notes: strategic location near
Turkish Straits; controls key land routes
from Europe to Middle East and Asia
Population: 8,960,749 (July 1987), average
annual growth rate 0.08%
Nationality: noun — Bulgarian(s); adjec-
tive— Bulgarian
34
Ethnic divisions: 85.3% Bulgarian, 8.5%
Turk, 2.6% Gypsy, 2.5% Macedonian, 0.3%
Armenian, 0.2% Russian, 0.6% other
Religion: regime promotes atheism; relig-
ious background of population is 85%
Bulgarian Orthodox, 13% Muslim, 0.8%
Jewish, 0.7% Roman Catholic, 0.5% Protes-
tant, Gregorian-Armenian, and other
Language: Bulgarian; secondary languages
closely correspond to ethnic breakdown
Infant mortality rate: 20.2/1,000 (1983)
Life expectancy: men 69, women 74
Literacy: 95% (est.)
Labor force: 4,113,546 (1983); 34% indus-
try, 22% agriculture, 44% other
Total area: 274,200 km2; land area:
273,800 km2
Comparative area: about the size of
Colorado
Land boundaries: 3,307 km total
Climate: tropical; warm, dry winters; hot,
wet summers
Terrain: mostly flat to dissected, undulat-
ing plains; hills in south
Land use: 10% arable land; NEGL%
permanent crops; 37% meadows and
pastures; 26% forest and woodland; 27%
other; includes NEGL% irrigated
Environment: recent droughts and deserti-
fication severely affecting marginal agri-
cultural activities, population distribution,
economy; overgrazing; deforestation
Special notes: landlocked
Population: 8,276,272 (July 1987), average
annual growth rate 2.42%
Nationality: noun — Burkinabe; adjective —
Burkinabe
Ethnic divisions: more than 50 tribes;
principal tribe is Mossi (about 2.5 million);
other important groups are Gurunsi, Se-
nufo, Lobi, Bobo, Mande, and Fulani
Religion: 65% indigenous beliefs, about
25% Muslim, 10% Christian (mainly Cath-
olic)
Language: French (official); tribal lan-
guages belong to Sudanic family, spoken
by 50% of the population
Infant mortality rate: 182/1,000 (1984)
Life expectancy: 42
Literacy: 7%
Labor force: 90% agriculture; 10% indus-
try, commerce, services, and government;
about 30,000 are wage earners; about 20%
of male labor force migrates annually to
neighboring countries for seasonal employ-
ment
Organized labor: four principal trade
union groups represent less than 1% of
population
Total area: 676,550 km2; land area:
657,740 km2
Comparative area: nearly as large as
Texas
Land boundaries: 5,850 km total
Coastline: 3,060 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical monsoon; cloudy, rainy,
hot, humid summers (southwest monsoon,
June to September); less cloudy, scant
rainfall, mild temperatures, lower humid-
ity during winter (northeast monsoon,
December to April)
Terrain: central lowlands ringed by steep,
rugged highlands
Land use: 15% arable land; 1% permanent
crops; 1% meadows and pastures; 49%
forest and woodland; 34% other; includes
2% irrigated
Environment: subject to destructive earth-
quakes and cyclones; flooding and land-
slides common during rainy season (June
to September); deforestation
Special notes: strategic location near
major Indian Ocean shipping lanes
Population: 38,822,484 (July 1987), aver-
age annual growth rate 2.08%
Nationality: noun — Burmese; adjective —
Burmese
Ethnic divisions: 68% Burman, 9% Shan,
7% Karen, 4% Raljome, 3% Chinese, 2%
Indian, 7% other
Religion: 85% Buddhist, 15% indigenous
beliefs, Muslim, Christian, or other
Language: Burmese; minority ethnic
groups have their own languages
Infant mortality rate: 96/1,000 (1986)
Life expectancy: 57
Literacy: 78%
Labor force: 14.8 million (est. 1985/86);
66.1% agriculture, 12.0% industry, 10.6%
government, 9.7% trade, 1.6% other
Organized labor: Workers'' Asiayone or
association (1.8 million members) and
Peasants'' Asiayone (7.6 million members)
integrated into the country''s sole political
party','b4f3984d5c8c2ca18519cf059a55c18860443753e5e4c5442d5e72fc74995b74','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b62926da988f49b4e403bd5f53967e6648444045dab71b7c864765001f3aee58',1981,'BI','Burundi','geography',102,'Total area: 27,830 km2; land area: 25,650
km2
Comparative area: about the size of
Maryland
Land boundaries: 974 km total
Climate: temperate; warm; occasional frost
in uplands
Terrain: mostly rolling to hilly highland;
some plains
Land use: 43% arable land; 8% permanent
crops; 35% meadows and pastures; 2%
forest and woodland; 12% other; includes
NEGL% irrigated
Environment: soil exhaustion; soil erosion;
deforestation
Special notes: landlocked; straddles crest
of the Nile-Congo watershed
Population: 5,005,504 (July 1987), average
annual growth rate 2.92%
Nationality: noun — Burundian(s); adjec-
tive— Burundi
Ethnic divisions: Africans — 85% Hutu
(Bantu), 14% Tutsi (Hamitic), 1% Twa
(Pygmy); other Africans include around
70,000 refugees, mostly Rwandans and
Zairians; non-Africans include about 3,000
Europeans and 2,000 South Asians
Religion: about 67% Christian (62% Ro-
man Catholic, 5% Protestant), 32% indige-
nous beliefs, 1% Muslim
38
Language: Kirundi and French (official);
Swahili (along Lake Tanganyika and in the
Bujumbura area)
Infant mortality rate: 121/1,000 (1983)
Life expectancy: 42.3
Literacy: 25%
Labor force: about 1.9 million (1983);
93.0% agriculture, 4.0% government, 1.5%
industry and commerce, 1.5% services
Organized labor: sole group is the Union
of Burundi Workers (UTB); by charter,
membership is extended to all Burundi
workers (informally); figures denoting
active membership unobtainable','ac54ea94cc543e8e3c5ed72142de427cfc4763400e919448dc0550e17a5018b7','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d8b1fbd38169323666960e473e5ce00e6cf5e6e6def782f0a7a3838bd251e95',1981,'TH','Thailand','geography',104,'Total area: 181,040 km2; land area:
176,520 km2
Comparative area: the size of Missouri
Land boundaries: 2,438 km total
Coastline: 443 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Vietnam (three areas);
occupied by Vietnam
Climate: tropical; rainy, monsoon season
(May to October); dry season (December to
March); little seasonal temperature varia-
tion
Terrain: mostly low, flat plains; mountains
in southwest and north
Land use: 16% arable land; 1% permanent
crops; 3% meadows and pastures; 76%
forest and woodland; 4% other; includes
1% irrigated
Environment: a land of paddies and
forests dominated by Mekong River and
Tonle Sap
Special notes: buffer between Thailand
and Vietnam
Population: 6,536,079 (July 1987), average
annual growth rate 2.26%
Nationality: noun — Cambodian(s); adjec-
tive— Cambodian
Ethnic divisions: 90% Khmer (Cambo-
dian), 5% Chinese, 5% other minorities
Religion: 95% Theravada Buddhism, 5%
other
Language: Khmer (official), French
Life expectancy: men 42, women 44.9
Literacy: 48%
Total area: 1,240,000 km2; land area:
1,220,000 km2
Comparative area: larger than California
and Texas combined
Land boundaries: 7,459 km total
Climate: subtropical to arid; hot and dry
February to June; rainy, humid, and mild
June to November; cool and dry Novem-
ber to February
Terrain: mostly flat to rolling northern
plains covered by sand; savanna in south,
rugged hills in northeast
Land use: 2% arable land; NEGL% per-
manent crops; 25% meadows and pastures;
7% forest and woodland; 66% other; in-
cludes NEGL% irrigated
Environment: hot, dust-laden harmattan
haze common during dry seasons; deserti-
fication; recent droughts affecting marginal
agriculture
Special notes: landlocked
Total area: 514,000 km2; land area:
511,770km2
Comparative area: about the size of Texas
Land boundaries: 4,868 km total
Coastline: 3,219 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; rainy, warm, cloudy
southwest monsoon (mid-May to October);
dry, cool northeast monsoon (November to
mid-March); southern isthmus always hot
and humid
Terrain: central plain; eastern plateau
(Khorat); mountains elsewhere
Land use: 34% arable land; 4% permanent
crops; 1% meadows and pastures; 30%
forest and woodland; 31% other; includes
7% irrigated
Environment: air and water pollution;
land subsidence in Bangkok area
Special notes: controls only land route
from Asia to Malaysia and Singapore
Population: 53,645,823 (July 1987), aver-
age annual growth rate 1.78%
Nationality: noun — Thai (sing, and pi.);
adjective — Thai
Ethnic divisions: 75% Thai, 14% Chinese,
11% other
Religion: 95.5% Buddhist, 4% Muslim,
0.5% other
Language: Thai; English is the secondary
language of the elite; ethnic and regional
dialects
Infant mortality rate: 51.4/1,000 (1985)
Life expectancy: men 59.5, women 65.1
Literacy: 82%
Labor force: 26 million (1984); 73% agri-
culture, 11% industry and commerce, 10%
services, 6% government; 8% unemploy-
ment rate','14802a8ffb4a0cd39de3a60b65d96eb67cb54b039c912af3e9ca6985b242ad05','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e1fb58170ad6d6669b98d2d700d1d1585ee01a3221fc3bf3162ed89b06ea55a',1981,'CM','Cameroon','geography',108,'Total area: 475,440 km2; land area:
469,440 km2
Comparative area: slightly larger than
California
Land boundaries: 4,554 km total
Coastline: 402 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 50 nm
Boundary disputes: none; sporadic border
dispute with Nigeria
Climate: varies with terrain from tropical
along coast to semiarid and hot in north
Terrain: diverse with coastal plain in
southwest, dissected plateau in center,
mountains in west, plains in north
Land use: 13% arable land; 2% permanent
crops; 18% meadows and pastures; 54%
forest and woodland; 13% other; includes
NEGL% irrigated
Environment: recent volcanic activity
with release of poisonous gases; deforesta-
tion; overgrazing; desertification
Special notes: sometimes referred to as
the hinge of Africa
Population: 10,255,332 (July 1987), aver-
age annual growth rate 2.66%
Nationality: noun — Cameroonian(s); adjec-
tive— Cameroonian
Ethnic divisions: over 200 tribes of widely
differing background; 31% Cameroon
Highlanders, 19% Equatorial Bantu, 11%
Kirdi, 10% Fulani, 8% Northwestern
Bantu, 7% Eastern Nigritic, 13% other
African, less than 1% non- African
Religion: 51% indigenous beliefs, 33%
Christian, 16% Muslim
Language: English and French (official),
24 major African language groups
Infant mortality rate: 113/1,000 (1985)
Life expectancy: 44
Literacy: 65%
Labor force: (1983) 74.4% agriculture,
11.4% industry and transport, 14.2% other
services
Organized labor: under 45% of wage
labor force','d6b78a045cbaa1e66e960ba9e3b38ee7df156aac1beea15e7ec66ad23a505d87','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2990276a6b89991f9260b71118b309499a329ac40242a4099418f891a22da8f6',1981,'CA','Canada','geography',113,'Total area: 9,976,140 km2; land area:
9,220,970 km2
Comparative area: slightly larger than US
Land boundaries: 9,010 km total
Coastline: 243,791 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
putes with France, US
Climate: varies from temperate in south to
subarctic and arctic in north
Terrain: mostly plains with mountains in
west and lowlands in southeast
Land use: 5% arable land; NEGL% per-
manent crops; 3% meadows and pastures;
35% forest and woodland; 57% other;
includes NEGL% irrigated
Environment: 80% of population concen-
trated within 160 km of US border; con-
tinuous permafrost in north a serious
obstacle to development
Special notes: second largest country in
world; strategic location between USSR
and US via polar route
Population: 25,857,943 (July 1987), aver-
age annual growth rate 0.91%
Nationality: noun — Canadian(s); adjec-
tive— Canadian
42
Ethnic divisions: 45% British Isles origin,
29% French origin, 23% other European,
1.5% indigenous Indian and Eskimo
Religion: 46% Roman Catholic, 16%
United Church, 10% Anglican
Language: English and French (official)
Infant mortality rate: 9.1/1,000 (1982)
Life expectancy: men 71.9, women 79
Literacy: 99%
Labor force: 12.88 million (1986 average);
68% services (37% government, 23% trade
and finance, 8% transportation), 18%
manufacturing, 6% construction, 3.8%
agriculture, 4.2% other; 9.6% unemploy-
ment (1986 average)
Organized labor: 30.6% of labor force;
39.6% of nonagricultural paid workers
Total area: 4,030 km2; land area: 4,030
km2
Comparative area: slightly larger than
Rhode Island
Coastline: 965 km
Maritime claim: (measured from claimed
archipelagic baselines)
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: temperate; warm, dry, summer
precipitation very erratic
Terrain: steep, rugged, rocky, volcanic
Land use: 9% arable land; NEGL% per-
manent crops; 6% meadows and pastures;
NEGL% forest and woodland; 85% other;
includes 1% irrigated
Environment: subject to prolonged
droughts; harmattan wind can obscure
visibility; volcanically and seismically
active; deforestation; overgrazing
Special notes: strategic location 500 km
from African coast near major north-south
sea routes; important communications
station; important sea and air refueling site','c5796868a6a9177a3820fb296706c4243f8b181954748f5809beb05d2091815c','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd74972d3fbc6243d8f0db05f5749e85a8c92d06b64defd0ab41bc030bebc519',1981,'KY','Cayman Islands','geography',117,'Total area: 260 km2; land area: 260 km2
Comparative area: less than twice the size
of Washington, D. C.
Coastline: 160 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical marine with warm
summers and cool winters
Terrain: low lying limestone base sur-
rounded by coral reefs
Land use: 0% arable land; 0% permanent
crops; 8% meadows and pastures; 23%
forest and woodland; 69% other
Environment: within the Caribbean hurri-
cane belt, but rarely affected
Special notes: important location between
Cuba and Central America','6a8b07af15a3d26abe271f64eaef9fd92e052fc4f63443a4063b0d6fc39fa49e','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9579d39fea9b4102e4d28711e82dcacc7741249d5adc712f9ca75a573d04de6d',1981,'CF','Central African Republic','geography',122,'Total area: 622,980 km2; land area:
622,980 km2
Comparative area: slightly smaller than
Texas
Land boundaries: 4,981 km total
Climate: tropical; hot, dry winters; mild to
hot, humid, wet summers
Terrain: vast, flat to rolling, monotonous
plateau; scattered hills in northeast and
southwest
Land use: 3% arable land; NEGL% per-
manent crops; 5% meadows and pastures;
64% forest and woodland; 28% other
Environment: hot, dry, dusty harmattan
winds affect northern areas; poaching has
diminished reputation as one of last great
wildlife refuges; desertification
Special notes: landlocked; almost the
precise center of Africa
Population: 2,669,293 (July 1987), average
annual growth rate 2.44%
Nationality: noun — Central African(s);
adjective — Central African
Ethnic divisions: about 80 ethnic groups,
the majority of which have related ethnic
and linguistic characteristics; 34% Baya,
27% Banda, 10% Sara, 21% Mandjia, 4%
Mboum, 4% M''Baka; 6,500 Europeans, of
whom 3,600 are French
Religion: 24% indigenous beliefs, 25%
Protestant, 25% Roman Catholic, 15%
Muslim; animistic beliefs and practices
strongly influence the Christian majority
Language: French (official); Sangho (lingua
franca and national language); Arabic,
Hunsa, Swahili
Infant mortality rate: 134/1,000 (1986)
Life expectancy: 44
Literacy: 20%
Labor force: 775,413 (1986 est); 85%
agriculture, 8.9% commerce and services,
2.9% industry, 3% government; about
64,000 salaried workers
Organized labor: 1% of labor force','7f8cfa96219d1811227cbd6fc945151ed3e3c53d1269d0c58827c4109ab8ae0f','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f9ad5ccaff6e51fc29ba667142ba87f2a6ac521ae81ce091b8e15b2376d7ab0',1981,'TD','Chad','geography',127,'Total area: 1,284,000 km2; land area:
1,259,200 km2
Comparative area: slightly larger than
Texas and California combined
Land boundaries: 5,987 km total
Boundary disputes: none; Libya claims
Aozou Strip in far north; Libyan troops
occupy northern Chad
Climate: tropical in south gradually be-
coming dry desert in north
Terrain: broad, arid plains in center,
desert in north, mountains in northwest,
lowlands in south
Land use: 2% arable land; NEGL% per-
manent crops; 36% meadows and pastures;
11% forest and woodland; 51% other;
includes NEGL% irrigated
Environment: hot, dry, dusty harmattan
winds occur in north; recent drought and
desertification adversely affecting south
Special notes: landlocked; Lake Chad
most significant water body in Sahel
Population: 4,646,054 (July 1987), average
annual growth rate 2.44%
Nationality: noun — Chadian(s); adjec-
tive— Chadian
Ethnic divisions: some 200 distinct ethnic
groups, most of whom are Muslims (Arabs,
Toubou, Fulbe, Kotoko, Hausa, Kanem-
bou, Baguirmi, Boulala, and Maba) in the
47
Chad (continued)
north and center and non-Muslims (Sara,
Ngambaye, Mbaye, Goulaye, Moudang,
Moussei, Massa) in the south; some 150,000
nonindigenous, of whom 1,000 are French
Religion: 44% Muslim, 23% indigenous
beliefs, 33% Christian
Language: French and Arabic (official);
Sara and Sango in south; more than 100
different languages and dialects are spoken
Infant mortality rate: 142/1,000 (1983)
Life expectancy: men 42.0, women 45.0
Literacy: about 17%
Labor force: 85% agriculture (engaged in
unpaid subsistence farming, herding, and
fishing)
Organized labor: about 20% of wage labor
force
Total area: 1,267,000 km2; land area:
1,266,700 km2
Comparative area: almost three times the
size of California
Land boundaries: 5,745 km total
Climate: desert; mostly hot, dry, dusty;
tropical in south
Terrain: predominately desert plains and
sand dunes; flat to rolling plains in south
Land use: 3% arable land; 0% permanent
crops; 7% meadows and pastures; 2% forest
and woodland; 88% other; includes
NEGL% irrigated
Environment: recent drought and deserti-
fication severely affecting marginal agri-
cultural activities; overgrazing; soil erosion
Special notes: landlocked
Population: 6,988,540 (July 1987), average
annual growth rate 3.16%
Nationality: noun — Nigerien(s) adjective —
Nigerien
Ethnic divisions: 56% Hausa; 22%
Djerma; 8.5% Fula; 8% Tuareg; 4.3% Beri
Beri (Kanouri); 1.2% Arab, Toubou, and
Gourmantche; about 4,000 French expatri-
ates
Religion: 80% Muslim, remainder indige-
nous beliefs and Christians
Language: French (official); Hausa,
Djerma
Infant mortality rate: 136/1,000 (1984)
Life expectancy: 45
Literacy: 10%
Labor force: 2.5 million (1982) wage
earners; 90% agriculture, 6% industry and
commerce, 4% government
Organized labor: negligible','3fc22cd5f3ca77dda4f941bb1bccc951cf4d2ba7dd0557d7eaa3942b5f8e94f7','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ab104bc0943b21d73a0b6fed6f8aebea2f2c1238bfcf9000e9383729b3f40e7',1981,'CL','Chile','geography',129,'Total area: 756,950 km2; land area:
748,800 km2
Comparative area: larger than Texas
Land boundaries: 6,325 km total
Coastline: 6,435 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 nm
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: short section with
Argentina is indefinite; Bolivia has wanted
a sovereign corridor to Pacific Ocean since
Atacama area was lost to Chile in 1884;
dispute with Bolivia over Rio Lauca water
rights; territorial claim in Antarctica
(Chilean Antarctic Territory)
Climate: temperate; desert in north; cool
and damp in south
Terrain: low coastal mountains; fertile
central valley; rugged Andes in west
Land use: 7% arable land; NEGL% per-
'' manent crops; 16% meadows and pastures;
21% forest and woodland; 56% other;
includes 2% irrigated
Environment: subject to severe earth-
quakes, active volcanism, tsunami; At-
acama Desert one of world''s driest regions;
desertification
Special notes: strategic location relative to
sea lanes between Atlantic and Pacific
Oceans (Strait of Magellan, Beagle Chan-
nel, Drake Passage)
Population: 12,448,008 (July 1987), aver-
age annual growth rate 1.54%
Nationality: noun — Chilean(s); adjective —
Chilean
Ethnic divisions: 95% European and
European-Indian, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11%
Protestant, and small Jewish population
Language: Spanish
Infant mortality rate: 20/1,000 (1984)
Life expectancy: men 63.8, women 70.4
Literacy: 94%
Labor force: 3.84 million; 38.6% services
(including government— 12%), 31.3%
industry and commerce; 15.9% agriculture,
forestry, and fishing; 8.7% mining; 4.4%
construction (1985); unemployed 13.9%
(1984)
Organized labor: 12% of labor force
organized into labor unions (1982)','721a30237d431ed17bcca1945e71eb7677c5f8b748cbb1e5cee0125047504dfc','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('598bc01cd4fdfb8c0d579bc8e3daf2dfeb7465cdc362d1a00c59211bfae9cae3',1981,'CN','China','geography',134,'Total area: 9,596,960 km2; land area:
9,326,410 km2
Comparative area: slightly larger than
conterminous US
Land boundaries: 24,000 km total
Coastline: 14,500 km
Maritime claim:
Territorial sea: 12 nm
Boundary disputes: India, USSR (Pamir,
Argun, Amur, and Khabarovsk areas); short
section with North Korea is indefinite;
British colony of Hong Kong will become
a Special Administrative Region in 1997;
Portuguese territory of Macau will become
a Special Administrative Region in 1999;
sporadic border clashes with Vietnam;
involved in complex dispute over Spratly
Islands with Malaysia, Philippines, Taiwan,
Vietnam, and possibly Brunei; maritime
dispute with Vietnam; dispute with Viet-
nam over Paracel Islands
Climate: extremely diverse; tropical in
south to subarctic in north
Terrain: mostly mountains, high plateaus,
deserts in west; plains, deltas, and hills in
east
Land use: 10% arable land; NEGL%
permanent crops; 31% meadows and
pastures; 14% forest and woodland; 45%
other; includes 5% irrigated
Environment: frequent typhoons (about
five times per year along southern and
50
eastern coasts), damaging floods, earth-
quakes; deforestation; soil erosion; indus-
trial pollution; water pollution; desertifica-
tion
Special notes: world''s third largest coun-
try (after USSR and Canada)
Population: 1,064,147,038 (July 1987),
average annual growth rate 0.99%
Nationality: noun — Chinese (sing., pi.);
adjective — Chinese
Ethnic divisions: 93.3% Han Chinese;
6.7% Zhuang, Uygur, Hui, Yi, Tibetan,
Miao, Manchu, Mongol, Buyi, Korean, and
numerous lesser nationalities
Religion: officially atheist, but traditionally
pragmatic and eclectic; most important
elements of religion are Confucianism,
Taoism, and Buddhism; about 2-3% Mus-
lim, 1% Christian
Language: Standard Chinese (Putonghua)
or Mandarin (based on the Beijing dialect);
also Yue (Cantonese), Wu (Shanghainese),
Minbei (Fuzhou), Minnan (Hokkien-
Taiwanese), Xiang, Gan, Hakka dialects,
and minority languages (see ethnic divi-
sions)
Life expectancy: 68
Literacy: over 75%
Labor force: 476 million (1984 est); 68.2%
agriculture and forestry, 18.2% industry
and commerce, 3.9% construction and
mining, 3.7% social services, 6% other
Organized labor: All-China Federation of
Trade Unions (ACFTU) follows the leader-
ship of the Chinese Communist Party;
membership over 80 million (about 65% of
the urban work force) (1985)
Total area: 300,000 km2; land area:
298,170 km2
Comparative area: slightly larger than
Nevada
Coastline: 36,289 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: to depth of exploita-
tion
Extended economic zone: 200 nm
Territorial sea: irregular polygon up to
285 nm in breadth
Boundary disputes: none; involved in
complex dispute over Spratley Islands with
China, Malaysia, Taiwan, Vietnam, and
possibly Brunei
Climate: tropical marine; northeast mon-
soon (December to May); southwest mon-
soon (July to October)
Terrain: mostly mountains with narrow to
extensive coastal lowlands
Land use: 26% arable land; 11% perma-
nent crops; 4% meadows and pastures;
40% forest and woodland; 19% other;
includes 5% irrigated
Environment: astride typhoon belt, af-
fected by 15 and struck by five to six
cyclonic storms per year; subject to land-
slides, active volcanoes, destructive earth-
quakes; deforestation; soil erosion; water
pollution
Special notes: none
Population: 61,524,761 (July 1987), aver-
age annual growth rate 2.70%
Nationality: noun — Filipino(s); adjective —
Philippine
Ethnic divisions: 91.5% Christian Malay,
4% Muslim Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 9% Protes-
tant, 5% Muslim, 3% Buddhist and other
Language: Filipino (based on Tagalog) and
English (both official)
Infant mortality rate: 59/1,000 (1982)
Life expectancy: 64
Literacy: about 88%
Labor force: 21,643 million (1985); 47.0%
agriculture, 20% industry and commerce,
13.5% services, 10.0% government, 9.5%
other; 6.1% official unemployment rate
(1985); much underemployment
Organized labor: 2,064 registered unions;
total membership 4.8 million (includes 2.7
million members of the National Congress
of Farmers Organizations)
Total area: 329,560 km2; land area:
325,360
Comparative area: about the size of New','b5fbcf52d5134673952074656c8bb70a95590c58350ec69f52da3b11dfd98138','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b67835f5e63adc6567e46e57026f9e69f0890fc2dede00dcdf99dcd2b6b69c8',1981,'CX','Christmas Island','geography',136,'Total area: 130 km2; land area: 130 km2
Comparative area: slightly smaller than
Washington, B.C.
Coastline: about 54 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; heat and humidity
moderated by trade winds
Terrain: steep cliffs along coast rise
abruptly to central plateau
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: almost completely sur-
rounded by a reef
Special notes: located along major sea
lanes of Indian Ocean','9559b2e4eb6506a0b9bf5504feb488830716d4de418a294b45e8e946dada66b7','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5033ffe021545c79d94f1149877e0e50aacacd288ca2f9e70deb9375f918522',1981,'CO','Colombia','geography',141,'Total area: 1,138,910 km2; land area:
1,038,700 km2
Comparative area: about the size of New
Mexico and Texas combined
Land boundaries: 6,342 km total
Coastline: 3,208 km total (1,448 km Pa-
cific Ocean; 1,760 Caribbean Sea)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with Venezuela; territorial dispute
with Nicaragua over San Andres and
Providencia Archipelago
Climate: tropical along coast and eastern
plains; cooler in highlands
Terrain: mixture of flat coastal lowlands,
plains in east, central highlands, some high
mountains
Land use: 4% arable land; 2% permanent
crops; 29% meadows and pastures; 49%
forest and woodland; 16% other; includes
NEGL% irrigated
Environment: highlands subject to volca-
nic eruptions; deforestation
Special notes: only South American coun-
try with coastlines on both Pacific Ocean
and Caribbean Sea
Population: 30,660,504 (July 1987), aver-
age annual growth rate 2.07%
Nationality: noun — Colombian(s); adjec-
tive— Colombian
Ethnic divisions: 58% mestizo, 20% white,
14% mulatto, 4% black, 3% mixed black-
Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Infant mortality rate: 56/1,000 (1985);
Indians about 233/1,000
Life expectancy: 65 (1985); Indians about
34
Literacy: 87.8% (1985 est.); Indians about
40%
Labor force: 11 million (1986); 53% ser-
vices, 26% agriculture, 21% industry
(1981); 14% official unemployment (1985)
Organized labor: 900,000 members (1986),
about 8 percent of labor force','c72c4e0d77c94eb6087ff19936fcab8ba7c0bb4f9ffa843ef37936a6e003163a','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06e58d41cf2ff5af64558d3b66489430c07b590d2592d4eaea0c5c5abd41d4f5',1981,'KM','Comoros','geography',146,'Total area: 2,170 km2; land area: 2,170
km2
Comparative area: about half the size of
Delaware
Coastline: 340 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claims French-
administered Mayotte
Climate: tropical marine; rainy season
(November to May)
Terrain: interiors vary from steep moun-
tains to low hills
Land use: 35% arable land; 8% permanent
crops; 7% meadows and pastures; 16%
forest and woodland; 34% other
Environment: soil degradation and ero-
sion; deforestation; cyclones possible dur-
ing rainy season
Special notes: important location at north-
ern end of Mozambique Channel
Population: 415,220 (July 1987), average
annual growth rate 3.32%
Nationality: noun — Comoran(s); adjec-
tive— Comoran
Ethnic divisions: Antalote, Cafre, Makoa,
Oimatsaha, Sakalava
Religion: 86% Sunni Muslim, 14% Roman
Catholic
54
Climate: tropical; marine; hot, humid,
rainy season during northeastern monsoon
(November to May); dry season is cooler
(May to November)
Terrain: generally undulating with ancient
volcanic peaks, deep ravines
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other
Environment: subject to cyclones during
rainy season
Special notes: none
Population: 64,481 (July 1987), average
annual growth rate 3.71%
Nationality: noun — Mahorais (sing., pi.);
adjective — Mahoran
Religion: 99% Muslim; remainder Chris-
tian, mostly Roman Catholic
Language: Mahorian (a Swahili dialect),
French
Literacy: probably high','533f8ca92a82231ea8e95c3824fc280a41af77234ebbe38996ff13481101c725','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8b429f5c6994747d18496660893299621417a1c414a4ae14895b9a85a656105',1981,'CG','Congo','geography',147,'Language: Shaafi Islam (a Swahili dialect),
Malagasy, French
Infant mortality rate: 92.3/1,000 (1983)
Life expectancy: 48.8
Literacy: 15%
Labor force: 140,000 (1982); 80% agricul-
ture, 3% government; significant unem-
ployment
Total area: 342,000 km2; land area:
341,500 km2
Comparative area: slightly smaller than
Montana
Land boundaries: 4,514 km total
Coastline: 169 km
Maritime claim:
Territorial sea: 200 nm
Boundary disputes: section with Zaire is
indefinite
Climate: tropical; rainy season (March to
June); dry season (June to October); con-
stantly high temperatures and humidity;
particularly enervating climate astride the
Equator
Terrain: coastal plain, southern basin,
central plateau, northern basin
Land use: 2% arable land; NEGL% per-
manent crops; 29% meadows and pastures;
62% forest and woodland; 7% other
Environment: deforestation
Special notes: none
Population: 2,082,154 (July 1987), average
annual growth rate 3.38%
Nationality: noun — Congolese (sing., pi.);
adjective — Congolese or Congo
Ethnic divisions: about 15 ethnic groups
divided into some 75 tribes, almost all
Bantu; most important ethnic groups are
Kongo (48%) in the south, Sangha (20%)
55
Congo (continued)
and M''Bochi (12%) in the north, Teke
(17%) in the center; about 8,500 Europe-
ans, mostly French
Religion: 42% animist, 50% Christian, 2%
Muslim
Language: French (official); many African
languages with Lingala and Kikongo most
widely used
Infant mortality rate: 200/1,000 (1985)
Life expectancy: 46.5
Literacy: over 80%
Labor force: about 40% of population
economically active (1985); 75% agricul-
ture, 25% commerce, industry, govern-
ment; 79,100 wage earners; 40,000-60,000
unemployed
Organized labor: 20% of total labor force
(1979 est.)','3635c4ec343f282a3cb45fadd1ac3a794dbaeb2fe36f79e4b78a13eccdf6a4cb','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('375e1b7558c68f1c15786d85bf171ffc9a9272fe098a9e55aa3b1c2a3b5971fd',1981,'CK','Cook Islands','geography',152,'Total area: 230 km2; land area: 230 km2
Comparative area: slightly larger than
Washington, D. C.
Coastline: 120 km
Maritime claims:
Continental shelf: 200 meters or edge
of continental margin
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by trade
winds
Terrain: low coral atolls in north; volcanic,
hilly islands in south
Land use: 4% arable land; 22% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 74% other
Environment: subject to typhoons from
November to March
Special notes: none
Population: 17,898 (July 1987), average
annual growth rate 0.55%
Nationality: noun — Cook Islanders);
adjective — Cook Islander
Ethnic divisions: 81.3% Polynesian (full
blood), 7.7% Polynesian and European,
7.7% Polynesian and other, 2.4% Euro-
pean, 0.9% other
Religion: Christian, majority of populace
members of Cook Islands Christian Church
Language: English','eac435b11962394fbe2d543d4e33011ddad13285884d27d483b845cc0c58361f','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd11dbc7d0046d2b98124c6a19d926543bdf9e8cbe24fe44d40f08e375a29cae',1981,'CR','Costa Rica','geography',155,'Total area: 50,700 km2; land area: 50,660
km2
Comparative area: slightly smaller than
West Virginia
Land boundaries: 670 km total
Coastline: 1,290 km
Maritime claims:
Continental shelf: 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Nicaraguan
interruption of transit in the Rio San Juan
(the international boundary) is an occa-
sional source of friction
Climate: tropical; dry season (December to
April); rainy season (May to November)
Terrain: coastal plains separated by rugged
mountains
Land use: 6% arable land; 1% permanent
crops; 43% meadows and pastures; 32%
forest and woodland; 12% other; includes
1% irrigated
Environment: subject to occasional earth-
quakes, hurricanes along Atlantic coast;
frequent flooding of lowlands at onset of
rainy season; active volcanoes; deforesta-
tion; soil erosion
Special notes: none
Population: 2,811,652 (July 1987), average
annual growth rate 2.78%
Nationality: noun — Costa Rican(s); adjec-
tive— Costa Rican
Ethnic divisions: 96% white (including
mestizo), 3% black, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish (official), with Jamai-
can dialect of English spoken around
Puerto Union
Infant mortality rate: 18.8/1,000 (1983)
Life expectancy: men 67.5, women 71.9
Literacy: 93%
Labor force: 868,300 (1985 est.); 34%
industry and commerce, 27% agriculture,
21% government and services, 8% other;
10% unemployment (1985 est.)
Organized labor: about 15.1% of labor
force','d63d6ea9d17fba9606fc1a35ab49d4d62fc7fd45ba6fb4555e21fd7419566d57','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef11146be86e34e322fbbf9ea295ff8748a1c02a8a46066e12ddee688a865b55',1981,'CU','Cuba','geography',160,'Total area: 110,860 km2; land area:
110,860 km2
Comparative area: slightly smaller than
Pennsylvania
Land boundary: 29. 1 km with Guantan-
amo (US Naval Base)
Coastline: 3,735 km
Maritime claims:
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Guantanamo
(US Naval Base) leased to US
Climate: tropical; moderated by trade
winds; dry season (November to April);
rainy season (May to November)
Terrain: mostly flat to rolling plains with
some hills and mountains
Land use: 23% arable land; 6% permanent
crops; 23% meadows and pastures; 17%
forest and woodland; 31% other; includes
10% irrigated
Environment: averages one hurricane
every other year
Special notes: largest country in Carib-
bean; 145 km south of Florida
Population: 10,259,473 (July 1987), aver-
age annual growth rate 0.90%
Nationality: noun— Cuban(s); adjective-
Cuban
Cuba (continued)
Ethnic divisions: 51% mulatto, 37% white,
11% black, 1% Chinese
Religion: at least 85% nominally Roman
Catholic before Castro assumed power
Language: Spanish
Infant mortality rate: 15/1,000 (1985)
Life expectancy: 74
Literacy: 96%
Labor force: 3.0 million; 47% industry and
commerce, 28% services and government,
25% agriculture (1982)','d59a25ffda75cef782322eb84380764b08714e035fb5d71e72e2e0af1b85d86a','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85cf4be25e2d422b0bb3592fff6f1e173c2cc3e1b245a088ae4bf94a183f1f92',1981,'CY','Cyprus','geography',163,'Total area: 9,250 km2; land area: 9,240
km2
Comparative area: slightly smaller than
Connecticut
Coastline: 648 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 12 nm
Boundary disputes: none; has been di-
vided de facto into two autonomous areas
since 1974 hostilities — one controlled by
the Cyprus Government or Greek area
(60%) and the other administered by
Turkish Cypriots (35%); those areas are
separated by a UN buffer zone and two
UK sovereign base areas (5%)
Climate: temperate; hot, dry summers;
cool, rainy winters
Terrain: central plain with mountains to
north and south
Land use: 40% arable land; 7% permanent
crops; 10% meadows and pastures; 18%
forest and woodland; 25% other; includes
10% irrigated
Environment: moderate earthquake activ-
ity; water resource problems (no natural
reservoir catchments and seasonal disparity
in rainfall)
Special notes: occupies important location
in eastern Mediterranean, gateway to the
Middle East
Total area: 127,870 km2; land area:
125,460 km2
Comparative area: about the size of New
York State
Land boundaries: 3,540 km total
Climate: temperate; cool summers; cold,
cloudy, humid winters
Terrain: mixture of hills and mountains
separated by plains and basins
Land use: 40% arable land; 1% permanent
crops; 13% meadows and pastures; 37%
forest and woodland; 9% other; includes
1% irrigated
Environment: infrequent earthquakes;
acid rain; water pollution
Special notes: landlocked; strategically
located astride some of oldest and most
significant land routes in Europe; Morav-
ian Gate is a traditional military corridor
between northern Europe and Danube','c733779a824ccedeeaea160755203cc10c2b4326b485280c33a98b3644a32274','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('059db9c1aed512c9adb25a189c55e5504ae5d1e3762a805abad0570413768693',1981,'DK','Denmark','geography',168,'Total area: 43,070 km2; land area: 42,370
km2 (excluding Greenland and Faroe
Islands)
Comparative area: about twice the size of
Massachusetts
Land boundaries: 68 km total
Coastline: 3,379 km
Maritime claims:
Contiguous zone: 4 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: none; Rockall conti-
nental shelf dispute involving Iceland,
Ireland, and UK
Climate: temperate; humid and overcast;
mild winters and cool summers
Terrain: low and flat to gently rolling
plains
Land use: 61% arable land; NEGL%
permanent crops; 6% meadows and pas-
tures; 12% forest and woodland; 21%
other; includes 9% irrigated
Environment: air and water pollution
Special notes: controls Danish Straits
linking Baltic and North Seas
Population: 5,121,766 (July 1987), average
annual growth rate 0.07%
Nationality: noun — Dane(s); adjective —
Danish
Ethnic divisions: Scandinavian, Eskimo,
Faroese, German
Religion: 97% Evangelical Lutheran, 2%
other Protestant and Roman Catholic, 1%
other
Language: Danish, Faroese, Greenlandic
(an Eskimo dialect); small German-
speaking minority
Infant mortality rate: 7.7/1,000 (1983)
Life expectancy: men 71.5, women 77.5
Literacy: 99%
Labor force: 2,779,000 (1985); 33.2%
government; 20.7% manufacturing; 13.2%
commerce; 2.0% agriculture, forestry, and
fishing; 5.9% construction; 7.5% banking
and business services; 7.2% transportation;
10.3% unemployment rate
Organized labor: 65% of labor force','8f95a7b1424ceece69d625f0c086ec2413f54420dbbe0ef341c3e90486d5fc44','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dd5279f4e7d58bc6cc200b0d79c1d749c06285405b1aa10e096b3646ef5de7d',1981,'DJ','Djibouti','geography',173,'Total area: 22,000 km2; land area: 21,980
km2
Comparative area: about the size of New
Hampshire
Land boundaries: 517 km total
Coastline: 314 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; possible claim
by Somalia based on unification of ethnic
Somalis
Climate: desert; torrid, dry
Terrain: coastal plain and plateau sepa-
rated by central mountains
Land use: 0% arable land; 0% permanent
crops; 9% meadows and pastures; NEGL%
forest and woodland; 91% other
Environment: vast wasteland with impor-
tant geothermal resources
Special notes: strategic location near
world''s busiest shipping lanes and close to
Arabian oilfields
Population: 312,405 (July 1987), average
annual growth rate 2.53%
Nationality: noun — Djiboutian(s); adjec-
tive— Djiboutian
65
Djibouti (continued)
Total area: 196,190 km2; land area:
192,000 km2
Comparative area: about the size of South
Dakota
Land boundaries: 2,680 km total
Coastline: 531 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: short section with The
Gambia is indefinite
Climate: tropical; hot, humid; rainy season
(December to April) has strong southeast
winds; dry season (May to November)
dominated by hot, dry harmattan wind
Terrain: generally low, rolling, plains
rising to foothills in southeast
Land use: 27% arable land; 0% permanent
crops; 30% meadows and pastures; 31%
forest and woodland; 12% other; includes
1% irrigated
Environment: lowlands seasonally flooded;
deforestation; overgrazing; soil erosion;
desertification
Special notes: The Gambia is almost an
enclave
Population: 7,064,025 (July 1987), average
annual growth rate 3.01%
Nationality: noun — Senegalese (sing, and
pi.); adjective — Senegalese
Ethnic divisions: 36% Wolof, 17% Fulani,
17% Serer, 9% Toucouleur, 9% Diola, 9%
Mandingo, 1% European and Lebanese
Religion: 92% Muslim, 6% indigenous
beliefs, 2% Christian (mostly Roman Cath-
olic)
Language: French (official); Wolof, Pulaar,
Diola, Mandingo
Infant mortality: 112/1,000
Life expectancy: 43
Literacy: 10%
Labor force: 2,509,000; 77% subsistence
agricultural workers; 175,000 wage earn-
ers— 40% private sector, 60% government
and parapublic
Organized labor: majority of wage-labor
force represented by unions; however,
dues-paying membership very limited;
major confederation is National Confeder-
ation of Senegalese Labor (CNTS), an
affiliate of governing party','c53f1a284ee983fbc9f1691e95fb75e554c1aebbd3f9c2cc15f121e38b653132','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcdbeaf255a10c6778eb47e39a30a6e5c7b74b07583fadb138df4a354f9e76fd',1981,'DM','Dominica','geography',174,'Ethnic divisions: 60% Somali (Issa); 35%
Afar, 5% French, Arab, Ethiopian, and
Italian
Religion: 94% Muslim, 6% Christian
Language: French (official); Arabic, So-
mali, and Afar widely used
Infant mortality rate: 140/1,000(1985)
Life expectancy: 50
Literacy: 20%
Labor force: a small number of semi-
skilled laborers at port; 3,000 railway
workers
Organized labor: 3,000 railway workers
Total area: 750 km2; land area: 750 km2
Comparative area: about one-fourth the
size of Rhode Island
Coastline: 148 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by northeast
trade winds; heavy rainfall
Terrain: rugged mountains of volcanic
origin
Land use: 9% arable land; 13% permanent
crops; 3% meadows and pastures; 41%
forest and woodland; 34% other
. . •
Environment: flash floods a constant
hazard; occasional hurricanes
Special notes: northernmost and largest of
Windward Islands
Population: 94,191 (July 1987), average
annual growth rate 3.80%
Nationality: noun — Dominican(s); adjec-
tive— Dominican
Ethnic divisions: mostly black; some
Carib-Indians
Religion: 80% Roman Catholic; Anglican,
Methodist
Language: English (official); French patois
widely spoken
Infant mortality rate: 24.1/1,000 (1981)
Life expectancy: men 57, women 59.','e645372f997e077213a740af054a785c73e402cfc9bdac6bc79ca914329278b6','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9102a76e5ae6b4a4268b00261eec5b59c1ef1f36e247e9feab2372ef3c4c560b',1981,'DO','Dominican Republic','geography',178,'Literacy: about 80%
Labor force: 25,000; 40% agriculture, 32%
industry and commerce, 28% services;
15-20% unemployment (1984)
Organized labor: 25% of labor force
Total area: 48,730 km2; land area: 48,380
km2
Comparative area: about the size of New
Hampshire and Vermont combined
Land boundary 361 km with Haiti
Coastline: 1,288 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: outer edge of conti-
nental margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 6 nm
Climate: tropical maritime; little seasonal
temperature variation
Terrain: rugged highlands and mountains
Land use: 23% arable land; 7% permanent
crops; 43% meadows and pastures; 13%
forest and woodland; 14% other; includes
4% irrigated
Environment: subject to occasional hurri-
canes; deforestation
Special notes: shares island of Hispaniola
with Haiti
Population: 6,960,743 (July 1987), average
annual growth rate 2.49%
Nationality: noun — Dominican(s); adjec-
tive— Dominican
Ethnic divisions: 73% mixed, 16% white,
11% black
Religion: 95% Roman Catholic
67
Dominican Republic (continued)
Language: Spanish
Infant mortality rate: 63/1,000 (1983)
Life expectancy: 60
Literacy: 68%
Labor force: over 2 million (1986); 45%
agriculture, 34% industry, 16% services
Organized labor: between 200,000 and
250,000 (1986); 10-15% of labor force','ec2908535bcf966345235ef8c1a836a42547df07d50143a6a0a4829cb3b5cc27','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('297d22c5e8f4bebdd7e02eaae488b3005108ce2345878008543901dbe544b79d',1981,'EC','Ecuador','geography',183,'Total area: 283,560 km2; land area:
276,840 km2
Comparative area: about the size of
Colorado
Land boundaries: 1,931 km total
Coastline: 2,237 km
Maritime claims:
Continental shelf: 200 m
Territorial sea: 200 nm
Boundary disputes: Peru (two areas)
Climate: tropical along coast becoming
cooler inland
Terrain: coastal plain (Costa), Andes
Mountains and central highlands (Sierra),
flat to rolling eastern jungle (Oriente)
Land use: 6% arable land; 3% permanent
crops; 17% meadows and pastures; 51%
forest and woodland; 23% other; includes
2% irrigated
Environment: subject to frequent earth-
quakes, landslides, volcanic activity, tsuna-
mis; deforestation; desertification; soil
erosion
Special notes: Cotopaxi in Andes is high-
est active volcano in world
Population: 9,954,609 (July 1987), average
annual growth rate 2.80%
Nationality: noun — Ecuadorean(s); adjec-
tive— Ecuadorean
Ethnic divisions: 55% mestizo (mixed
Indian and Spanish), 25% Indian, 10%
Spanish, 10% black
Religion: 95% Roman Catholic (majority
nonpracticing)
Language: Spanish (official); Indian lan-
guages, especially Quechua
Infant mortality rate: 68.4/1,000 (1984)
Life expectancy: 64 (1984)
Literacy: 85% (1981)
Labor force: (1983) 2.8 million; 52%
agriculture, 13% manufacturing, 7% com-
merce, 4% construction, 4% public admin-
istration, 16% other services and activities
Organized labor: less than 15% of labor
force','01df0d8d416f5a74b1cea0132c5bcd2ac6812af13f003e7bcecc4f9b474c633b','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24d17f2cae0a519878f4fe1a9a86094a7273ae3702c2876cf2f5c496cf8f2921',1981,'EG','Egypt','geography',188,'Total area: 1,001,450 km2; land area:
995,450 km2
Comparative area: about the size of
Oregon and Texas combined
Land boundaries: 2,580 km total
Coastline: 2,450 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; disputes with
Israel over Taba area and precise location
of some individual boundary markers;
Administrative Boundary and international
boundary with Sudan; West Bank and
Gaza Strip are Israeli occupied with status
to be determined
Climate: desert; hot, dry summers with
moderate winters
Terrain: vast desert plateau interrupted by
Nile valley and delta
Land use: 2% arable land; NEGL% per-
manent crops; 0% meadows and pastures;
NEGL% forest and woodland; 98% other;
includes 2% irrigated
Environment: Nile is only perennial water
source; increasing soil salinization below
Aswan High Dam; hot, driving windstorm
called khamsins occurs in spring; water
pollution; desertification
Special notes: controls Sinai Peninsula,
only land bridge between Africa and
remainder of Eastern Hemisphere; controls
Suez Canal, shortest sea link between
Indian Ocean and Mediterranean; size and
juxtaposition to Israel establishes its major
role in Middle East geopolitics
Population: 51,929,962 (July 1987), aver-
age annual growth rate 2.74%
Nationality: noun — Egyptian(s); adjec-
tive— Egyptian
Ethnic divisions: 90% Eastern Hamitic
stock; 10% Greek, Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim
(mostly Sunni), 6% Coptic Christian and
other
Language: Arabic (official); English and
French widely understood by educated
classes
Infant mortality rate: 94/1,000 (1984)
Life expectancy: 60
Literacy: 40%
Labor force: about 13.0 million (1985);
40-45% agriculture, 36% government (local
and national), public sector enterprises,
and armed forces; 20% privately owned
service and manufacturing enterprises
(1984); shortage of skilled labor; unemploy-
ment about 7% (official estimate); esti-
mated 2.0 million Egyptians work abroad,
mostly in Iraq and the Gulf Arab states
(1986)
Organized labor: about 2.5 million','7f05bf67ecc4a47bce4d91da655f7ef8d1536fa097ee53f60a06e2c2b97e4927','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e94257e92274fb56e294dbe434390f089255c0859edc7350d0297679f493c6e',1981,'SV','El Salvador','geography',191,'Total area: 21,040 km2; land area: 20,720
km2
Comparative area: about the size of
Massachusetts
Land boundaries: 515 km total
Coastline: 307 km
Maritime claim:
Territorial sea: 200 nm (overflight and
navigation permitted beyond 12 nm)
Boundary disputes: Honduras
Climate: tropical; rainy season (May to
October); dry season (November to April)
Terrain: mostly mountains with narrow
coastal belt and central plateau
Land use: 27% arable land; 8% permanent
crops; 29% meadows and pastures; 6%
forest and woodland; 30% other; includes
5% irrigated
Environment: The Land of Volcanoes;
subject to frequent and sometimes very
destructive earthquakes; deforestation; soil
erosion; water pollution
Special notes: smallest Central American
country and only one without a coastline
on Caribbean Sea
Population: 5,260,478 (July 1987), average
annual growth rate 2.37%
Nationality: noun — Salvadoran(s); adjec-
tive— Salvadoran
Ethnic divisions: 89% mestizo, 10% In-
dian, 1% white
Religion: about 97% Roman Catholic, with
activity by Protestant groups throughout
the country
Language: Spanish, Nahua (among some
Indians)
Infant mortality rate: 41/1,000 (1984)
Life expectancy: men 62.6, women 66.3
Literacy: 65%
Labor force: 1.7 million (est. 1982); 40%
agriculture, 16% manufacturing, 16%
commerce, 13% government, 9% financial
services, 6% transportation (1984 est.);
shortage of skilled labor and large pool of
unskilled labor, but manpower training
programs improving situation; significant
unemployment and underemployment
Organized labor: 8% total labor force;
10% agricultural labor force; 7% urban
labor force (1982)','00f7280a318927f83d6873908cc1d2950628bda4a733affaee39b98083ac1386','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c021e276f90492ac9551efa1a56e46f60b159420acbfc5daf2503bf2d98605a4',1981,'GQ','Equatorial Guinea','geography',195,'Total area: 28,050 km2; land area: 28,050
km2
Comparative area: about the size of
Maryland
Land boundaries: 539 km total
Coastline: 296 km
Maritime claim:
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with Gabon
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills
Land use: 5% arable land; 4% permanent
crops; 4% meadows and pastures; 61%
forest and woodland; 26% other
Environment: subject to violent wind-
storms
Special notes: none
Population: 340,434 (July 1987), average
annual growth rate 1.83%; includes Rio
Muni 265,281, average annual growth rate
1.83%, and Bioko 75,153, average annual
growth rate 1.83%
Nationality: noun — Equatorial Guinean(s);
adjective — Equatorial Guinean
Ethnic divisions: indigenous population of
Bioko, primarily Bubi, some Fernandinos;
Rio Muni, primarily Fang; less than 1,000
Europeans, mostly Spanish
Religion: natives all nominally Christian
and predominantly Roman Catholic; some
pagan practices retained
Language: Spanish (official), pidgin En-
glish, Fang
Infant mortality rate: 142.9/1,000(1984)
Life expectancy: men 44, women 48
Literacy: 55%
Labor force: most involved in subsistence
agriculture; labor shortages on plantations','ad0ffb69ef25ad773a491ace21afdb75b1d52d206da3c4469d04972cad950519','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5ecbe1c469ec3d8c8e9fca795d1e8f90952a65a2230fbe14874bda009b60a4b',1981,'ET','Ethiopia','geography',200,'Total area: 1,221,900 km2; land area:
1,101,000km2
Comparative area: four-fifths the size of
Alaska
Land boundaries: 5,198 km total
Coastline: 1,094 km
Maritime claim:
Territorial sea: 12 nm
Boundary disputes: southern half of
boundary with Somalia is a Provisional
Administrative Line; possible claim by
Somalia based on unification of ethnic
Somalis; territorial dispute with Somalia
over the Ogaden
Climate: tropical monsoon with wide
topographic-induced variation
Terrain: high plateau with central moun-
tain range divided by Great Rift Valley
Land use: 12% arable land; 1% permanent
crops; 41% meadows and pastures; 24%
forest and woodland; 22% other; includes
NEGL% irrigated
Environment: geologically active Great
Rift Valley susceptible to earthquakes,
volcanic eruptions; deforestation; overgraz-
ing; soil erosion; desertification
Special notes: strategic geopolitical posi-
tion along world''s busiest shipping lanes
and close to Arabian oilfields
Total area: 12,170 km2; land area: 12,170
km2
Comparative area: about the size of
Connecticut
Coastline: 1,288 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm (enforc-
ing only to 150 nm, 1 February 1987)
Territorial sea: 3 nm
Boundary disputes: none; territorial dis-
pute— islands administered by UK,
claimed by Argentina
Climate: cold marine; strong westerly
winds, cloudy, humid; rain occurs on more
than half of days in year; occasional snow
all year, does not accumulate
Terrain: rocky, hilly, mountainous with
some boggy, undulating plains
Land use: 0% arable land; 0% permanent
crops; 99% meadows and pastures; 0%
forest and woodland; 1% other
Environment: some smaller islands in
dependencies are volcanically active
Special notes: deeply indented coastline
provides good natural harbors
Population: 1,821 (July 1987), average
annual growth rate 0.00%; population may
be declining slightly each year
Nationality: noun — Falkland Islanders);
adjective — Falkland Island
Ethnic divisions: almost totally British
Religion: predominantly Anglican
Language: English
Literacy: compulsory education up to age
14
Labor force: 1,100 (est); about 95% in
agriculture, mostly sheepherding','251ca9f2c28a6bf12590ffb8da87f9dddb503471ebb220459b2b6d7a1fbaebfa','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10b6b659ff237c6fd246e325c4c2c4a48ae234831b1815f096d3019210dd89c8',1981,'FO','Faroe Islands','geography',206,'Total area: 1,400 km2; land area: 1,400
km2
Comparative area: slightly larger than
Rhode Island
Coastline: 764 km
Maritime claims:
Contiguous zone: 4 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: mild winters, cool summers;
usually overcast; foggy, windy
Terrain: rugged, rocky, some low peaks;
cliffs along most of coast
Land use: 2% arable land; 0% permanent
crops; 0% meadcws and pastures; 0% forest
and woodland; 98% other
Environment: precipitous terrain limits
habitation to small coastal lowlands; archi-
pelago consists of 18 inhabited islands and
a few uninhabited islets
Special notes: strategically located along
important sea lanes in northeastern Atlan-
tic about midway between Iceland and
Shetland Islands
Population: 46,429 (July 1987), average
annual growth rate 0.91%
Nationality: noun— Faroese (sing., pi.);
adjective — Faroese
Ethnic divisions: homogeneous white
population
Religion: Evangelical Lutheran
Language: Faroese (derived from Old
Norse), Danish
Literacy: 99%
Labor force: 17,585; largely engaged in
fishing, manufacturing, transportation, and
commerce','4e22106b427a94df8d51bdf19480d7be1e34a8283b25e0464f20fee96f2968bb','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2adc028f0d0f19824bf47806b4e95666f0c5a87752642e279920ecfd50e9e991',1981,'FJ','Fiji','geography',210,'Total area: 18,270 km2; land area: 18,270
km2
Comparative area: about the size of
Massachusetts
Coastline: 1,129 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical marine; only slight
seasonal temperature variation
Terrain: mostly mountains of volcanic
origin
Land use: 8% arable land; 5% permanent
crops; 3% meadows and pastures; 65%
forest and woodland; 19% other; includes
NEGL% irrigated
Environment: subject to hurricanes from
November to January
Special notes: none
Population: 727,902 (July 1987), average
annual growth rate 2.25%
Nationality: noun — Fijian(s); adjective —
Fijian
Ethnic divisions: 50% Indian, 45% Fijian;
5% European, other Pacific Islanders,
overseas Chinese, and others
Religion: Fijians are mainly Christian,
Indians are Hindu with a Muslim minority
Language: English (official); Fijian;
Hindustani
Infant mortality rate: 29/1,000 (1983)
Life expectancy: 72
Literacy: 80%
Labor force: 176,000 (1979); 40% of total
work force paid employees; remainder
involved in subsistence agriculture; 43.4%
agriculture, 15.6% industry
Organized labor: about 45,000 employees
belong to some 46 trade unions, which are
organized along lines of work and ethnic
origin (1983)','0e79c5c85ee0223b5ae47fab02f86d0de8c772a09c2effea0020dafb2f7b8e2f','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcced0fe63ac381de185b3b22ced0aa3f11ddedcd8a4d3548611df88d5064835',1981,'FI','Finland','geography',214,'Total area: 337,030 km2; land area:
305,470 km2
Comparative area: slightly smaller than
Montana
Land boundaries: 2,534 km total
Coastline: 1,126 km excluding islands and
coastal indentations
Maritime claims:
Contiguous zone: 6 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 12 nm
Territorial sea: 4 nm
Climate: cold temperate; potentially
subarctic, but comparatively mild because
of moderating influence of Gulf Stream,
Baltic Sea, more than 60,000 lakes
Terrain: mostly low, flat to rolling plains
interspersed with low hills
Land use: 8% arable land; 0% permanent
crops; NEGL% meadows and pastures;
76% forest and woodland; 16% other;
includes NEGL% irrigated
Environment: permanently wet ground
covers about 30% of land; population
concentrated on small southwestern coastal
plain
Special notes: long boundary with USSR;
Helsinki is northernmost national capital
on European continent
79
Finland (continued)','d7116e427bb401058ee2f0778d8e27d6fe424051f068c18c7b0dbc9b298b01a8','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('899df7aa09376a03a0793ef57100fe4dc877ac967b77bf0bbd743bb8b41072e3',1981,'FR','France','geography',218,'Total area: 547,030 km2; land area:
545,630 km2
Comparative area: four-fifths the size of
Texas
Land boundaries: 2,888 km total
Coastline: 3,427 km (includes Corsica, 644
km)
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with Canada; Madagascar claims
Bassas da India, Europa Island, Glorioso
Islands, Juan de Nova Island, and Trome-
lin Island; Comoros claims Mayotte;
Mauritius claims Tromelin Island; Seychel-
les claims Tromelin Island; Suriname
claims part of French Guiana; territorial
claim in Antarctica (Adelie Land)
Climate: generally cool winters and mild
summers, but mild winters and hot sum-
mers along the Mediterranean
Terrain: mostly flat plains or gently rolling
hills; rest is mountainous
Land use: 32% arable land; 2% permanent
crops; 23% meadows and pastures; 27%
forest and woodland; 16% other; includes
2% irrigated
Environment: most of large urban areas
and industrial centers in Rhone, Garonne,
Seine, or Loire river basins; occasional
warm tropical wind known as mistral
Special notes: largest West European
nation
Population: 55,596,030 (July 1987), aver-
age annual growth rate 0.38%
Nationality: noun — Frenchman(men);
adjective — French
Ethnic divisions: Celtic and Latin with
Teutonic, Slavic, North African, Indo-
chinese, and Basque minorities
Religion: 90% Roman Catholic, 2% Protes-
tant, 1% Jewish, 1% Muslim (North Afri-
can workers), 6% unaffiliated
Language: French (100% of population);
rapidly declining regional dialects (Proven-
cal, Breton, Germanic, Corsican, Catalan,
Basque, Flemish)
Infant mortality rate: 9/1,000 (1984)
Life expectancy: 75
Literacy: 99%
Labor force: 23.98 million; 60.8% services,
24.0% industry, 7.6% agriculture, 7.6%
other; 10.6% unemployed (1986)
Organized labor: about 20% of labor force
Total area: 1,565,000 km2; land area:
1,565,000 km2
Comparative area: more than twice the
size of Texas
Land boundaries: 8,000 km total
Climate: desert; cold, dry, continental;
sharp seasonal variation
Terrain: vast semidesert and desert plains;
mountains in west and southwest; Gobi
Desert in southeast
Land use: 1% arable land; 0% permanent
crops; 79% meadows and pastures; 10%
forest and woodland; 10% other; includes
NEGL% irrigated
Environment: harsh and rugged
Special notes: landlocked; strategic loca-
tion between China and Soviet Union
Population: 2,011,066 (July 1987), average
annual growth rate 2.79%
Nationality: noun — Mongolian(s); adjec-
tive— Mongolian
Ethnic divisions: 90% Mongol, 4%
Kazakh, 2% Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Bud-
dhist, about 4% Muslim, limited religious
activity because of Communist regime
Language: Khalkha Mongol used by over
90% of population; minor languages in-
clude Turkic, Russian, and Chinese
Life expectancy: 63
Mongolia (continued)
Literacy: about 80%; 100% claimed in
1985
Labor force: primarily agricultural; over
half the adult population is in the labor
force, including a large percentage of
women; shortage of skilled labor','edf51bbe790e2ad506167fcdc0ba3639aba0ce1cc391ba6cc1ab8974fdb01a8d','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3fb5540bd59428e076025785fdb0457c8a09e3d21b3f875abbe1f40aa127064',1981,'GF','French Guiana','geography',222,'Total area: 91,000 km2; land area: 89,150
km2
Comparative area: slightly smaller than
Maine
Land boundaries: 1,183 km total
Coastline: 378 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Suriname claims area
between Litani Rivier and Riviere
Marouini (both headwaters of the Lawa)
Climate: tropical; hot, humid; little sea-
sonal temperature variation
Terrain: low lying coastal plains rising to
hills and small mountains
Land use: NEGL% arable land; NEGL%
permanent crops; NEGL% meadows and
pastures; 82% forest and woodland; 18%
other
Environment: mostly an unsettled wilder-
ness
Special notes: none','71fa4b6d2a7d178d0f0d0bbbbc0857dbe104c790fdd95bc2c116c72ad1c73178','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('014d5efde205b57558ab12816ca9c86d53704fe01cb5ef8b6ef0d31e13d1fa73',1981,'PF','French Polynesia','geography',227,'Total area: 4,000 km2; land area: 3,660
km2
Comparative area: larger than Rhode
Island
Coastline: 2,525 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical, but moderate
Terrain: mixture of rugged high islands
and low islands with reefs
Land use: 1% arable land; 19% permanent
crops; 5% meadows and pastures; 31%
forest and woodland; 44% other
Environment: occasional cyclonic storm in
January
Special notes: Makatea is one of three
great phosphate rock islands in the Pacific
(others are Banaba or Ocean Island in
Kiribati and Nauru)
Population: 185,683 (July 1987), average
annual growth rate 2.84%
Nationality: noun — French Polynesian(s);
adjective — French Polynesian
Ethnic divisions: 78% Polynesian, 12%
Chinese, 6% local French, 4% metropolitan
French
84','bf995825b6c5dd72e4e57ee3a55e0de49446aa440762d9c5b34850c78a27425e','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a583609a159e09846447c3ae91146f3f37088ad5507b2743fa927ac143edcbf2',1981,'GA','Gabon','geography',228,'Religion: mainly Christian; 55% Protes-
• tant, 32% Catholic
Total area: 267,670 km2; land area:
257,670 km2
Comparative area: about the size of
Colorado
Land boundaries: 2,422 km total
Coastline: 885 km
Maritime claims:
Exclusive fishing zone: 150 nm
Territorial sea: 100 nm
Boundary disputes: none; maritime dis-
pute with Equatorial Guinea
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly inter-
ior; savanna in east and south
Land use: 1% arable land; 1% permanent
crops; 18% meadows and pastures; 78%
forest and woodland; 2% other
Environment: deforestation
Special notes: none
Population: 1,039,006 (July 1987), average
annual growth rate 1.31%
Nationality: noun — Gabonese (sing., pi.);
adjective — Gabonese
Ethnic divisions: about 40 Bantu tribes,
including 4 major tribal groupings (Fang,
Eshira, Bapounou, Bateke); about 100,000
expatriate Africans and Europeans, includ-
ing 35,000 French
85
Gabon (continued)
Religion: 55-75%''Christian, less than 1%
Muslim, remainder animist
Language: French (official), Fang, Myene,
Bateke, Bapounou/Eschira, Bandjabi
Infant mortality rate: 117/1,000 (1983)
Life expectancy: 50
Literacy: 65%
Labor force: 120,000 salaried (1983);
65.0% agriculture, 30.0% industry and
commerce, 2.5% services, 2.5% govern-
ment
Organized labor: there are 38,000 mem-
bers of the national trade union, the Ga-
bonese Trade Union Confederation
(COSYGA)
Total area: 11,300 km2; land area: 10,000
km2
Comparative area: about twice the size of
Delaware
Land boundary: 740 km with Senegal
Coastline: 80 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 200 nm
Boundary disputes: short section with
Senegal is indefinite
Climate: tropical; hot, rainy season (June
to November); cooler, dry season (Novem-
ber to May)
Terrain: flood plain of Gambia River
flanked by some low hills
Land use: 16% arable land; 0% permanent
crops; 9% meadows and pastures; 20%
forest and woodland; 55% other; includes
3% irrigated
Environment: deforestation
Special notes: almost an enclave of','8f1618bcf2deeb0c739d562a4b7dc443b7f90bf778a7edabe4bf24d02e3fa343','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cd6c5cc22ac97a84d83193dcd2ca9f33ca2dc6ad294f75f517c9f7d9b50bc2e',1981,'SN','Senegal','geography',232,'Population: 760,362 (July 1987), average
annual growth rate 2.44%
Nationality: noun — Gambian(s); adjec-
tive— Gambian
Ethnic divisions: 99% African (42% Man-
dinka, 18% Fula, 16% Wolof, 10% Jola, 9%
Serahuli, 4% other); 1% non-Gambian
Religion: 90% Muslim, 9% Christian, 1%
indigenous beliefs
Language: English (official); Mandinka,
Wolof, Fula, other indigenous vernaculars
Infant mortality rate: 174/1,000
Life expectancy: 42
Literacy: 12%
Labor force: 165,000 (1983 est); 75.0%
agriculture; 18.9% industry, commerce,
and services; 6.1% government
Organized labor: 25-30% of wage labor
force
Total area: 108,330 km2; land area:
105,980 km2
Comparative area: about the size of
Virginia
Land boundaries: 2,309 km total
Coastline: 901 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: it is US policy that
the final borders of Germany have not
been established
Climate: temperate; cloudy, cold winters
with frequent rain and snow; cool, wet
summers
Terrain: mostly flat plain with hills and
mountains in south
Land use: 45% arable land; 3% permanent
crops; 12% meadows and pastures; 28%
forest and woodland; 12% other; includes
2% irrigated
Environment: significant deforestation due
to air pollution, acid rain
Special notes: strategic location on North-
ern European Plain and near entrance to
Baltic Sea; West Berlin is an enclave
(about 100 km from FRG)
Total area: 248,580 km2; land area:
244,280 km2 (including West Berlin)
Comparative area: about the size of
Wyoming
Land boundaries: 4,232 km total
Coastline: 1,488 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm (extends, at one
point, to 16 nm in the Helgolander
Bucht)
Boundary disputes: it is US policy that
the final borders of Germany have not
been established
Climate: temperate and marine; cool,
cloudy, wet winters and summers; occa-
sional warm, tropical foehn wind
Terrain: lowlands in north, uplands in
center, Bavarian Alps in south
Land use: 30% arable land; 1% permanent
crops; 19% meadows and pastures; 30%
forest and woodland; 20% other; includes
1% irrigated
Environment: air and water pollution
Special notes: separated from GDR by a
highly secured strip that extends entire
length of frontier; West Berlin is an ex-
clave (about 100 km from FRG)
Population: 60,989,419, including West
Berlin (July 1987), average annual growth
rate -0.03%
Nationality: noun — German(s); adjective —
German
Ethnic divisions: primarily German;
Danish minority
Religion: 45% Roman Catholic, 44%
Protestant, 11% other
Language: German
Infant mortality rate: 11/1,000 (1983)
Life expectancy: men 67.2, women 73.4
Literacy: 99%
Labor force: 27.8 million, including
armed forces (est. avg. 1985); 41.6% indus-
try, 34.7% services and other, 18.2% trade
and transport, 5.4% agriculture; 9.0%
unemployment (1986)
Organized labor: 9.3 million total, 7.76
million in German Trade Union Federa-
tion (DGB); union membership constitutes
about 40% of union-eligible labor force,
34% of total labor force, and 35% of wage
and salary earners (1986)','d52b37107e4ee40213e722a2f0756772fff88c8c7c52d30f098b8de8006b693d','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cba9e3ff310e2a94bc20bcaa254afe174f5bd9c0ebb872485458c8a833d42a3',1981,'GH','Ghana','geography',239,'Total area: 238,540 km2; land area:
230,020 km2
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,285 km total
Coastline: 539 km
Maritime claims:
Continental shelf: 100 fathoms or to
depth of exploitation
Territorial sea: 200 nm
Climate: tropical; warm and compar-
atively dry along southeast coast; hot and
humid in southwest, hot and dry in north
Terrain: mostly low plains with dissected
plateau in south-central area
Land use: 5% arable land; 7% permanent
crops; 15% meadows and pastures; 37%
forest and woodland; 36% other; includes
NEGL% irrigated
Environment: recent drought in north
severely affecting marginal agricultural
activities; deforestation; overgrazing; soil
erosion; dry, northeasterly harmattan wind
(January to March)
Special notes: Lake Volta is world''s largest
artificial lake
Population: 13,948,925 (July 1987), aver-
age annual growth rate 2.89%
Nationality: noun — Ghanaian(s); adjec-
tive — Ghanaian
91
Ghana (continued)
Ethnic divisions: 99.8% black African
(major tribes Akan, Ewe, Ga), 0.2% Euro-
pean and other
Religion: 38% indigenous beliefs, 30%
Muslim, 24% Christian, 8% other
Language: English (official); African lan-
guages include 44% Akan, 16% Mole-
Dagbani, 13% Ewe, and 8% Ga-Adangbe
Infant mortality rate: 97/1,000 (1983)
Life expectancy: 49
Literacy: 30%
Labor force: 3.7 million; 54.7% agriculture
and fishing; 18.7% industry; 15.2% sales
and clerical; 7.7% services, transportation,
and communications; 3.7% professional;
400,000 unemployed
Organized labor: 467,000 (about 13% of
labor force)','767fdcffa81b2555e126aa756243d21ddd856d0f638ce69b903c582f9fbba8a9','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16940ea3c867af6f31ada8ea1023329c419dacc06cccea9b71bd094f2df04083',1981,'GI','Gibraltar','geography',242,'Total area: 6.5 km2; land area: 6.5 km2
Comparative area: about one-twenty-
seventh the size of Washington, D.C.
Land boundaries: 1.6 km total
Coastline: 12 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 3 nm
Boundary disputes: none; occasional
source of friction between Spain and UK
Climate: Mediterranean with mild winters
and warm summers
Terrain: a narrow coastal lowland borders
The Rock
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: natural fresh water sources
are very meager so large water catchments
(concrete or natural rock) collect rain
water
Special notes: strategic location on Strait
of Gibraltar that links Atlantic Ocean and
Mediterranean Sea
Population: 29,048 (July 1987), average
annual growth rate 0.36%
Nationality: noun — Gibraltarian; adjec-
tive— Gibraltar
Ethnic divisions: mostly Italian, English,
Maltese, Portuguese, and Spanish descent
Religion: 75% Roman Catholic, 8%
Church of England, 2.25% Jewish
Language: English and Spanish are pri-
mary languages; Italian, Portuguese, and
Russian also spoken; English used in the
schools and for official purposes
Literacy: about 99%
Labor force: about 14,800 (including
non-Gibraltar laborers)
Organized labor: over 6,000
Total area: 504,750 km2; land area:
499,400 km2
Comparative area: about the size of
Arizona and Utah combined
Land boundaries: 1,899 km total
Coastline: 4,964 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Gibraltar ques-
tion with UK; controls two presidios or
places of sovereignty (Ceuta, Melilla) on
the coast of Morocco
Climate: temperate; clear, hot summers in
interior, more moderate and cloudy along
coast; cloudy, cold winters in interior,
partly cloudy and cool along coast
Terrain: large, flat to dissected plateau
surrounded by rugged hills
Land use: 31% arable land; 10% perma-
nent crops; 21% meadows and pastures;
31% forest and woodland; 7% other; in-
cludes 6% irrigated
Environment: deforestation; desertification
Special notes: strategic location along
approaches to Strait of Gibraltar','cf38047eb5b49d0f96e1eb592bb7993f38ae446e5006bb6e8ed427427bff2162','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cecef3a65681c4940afaeed1c944f4c9cbc03b2c4124075441ad120f4f0994b4',1981,'GR','Greece','geography',246,'Total area: 131,940 km2; land area:
130,800 km2
Comparative area: about the size of New
York State
Land boundaries: 1,191 km total
Coastline: 13,676 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 6 nm
Boundary disputes: none; complex mari-
time and air (but not territorial) disputes
with Turkey in Aegean Sea; Cyprus ques-
tion with Turkey; Macedonia question
with Bulgaria and Yugoslavia; Northern
Epirus question with Albania
Climate: temperate; mild, wet winters;
hot, dry summers
Terrain: mostly mountains with ranges
extending into sea as peninsulas or chains
of islands
Land use: 23% arable land; 8% permanent
crops; 40% meadows and pastures; 20%
forest and woodland; 9% other; includes
7% irrigated
Environment: subject to severe earth-
quakes; archipelago of 2,000 islands; air
pollution
Special notes: strategic location dominat-
ing the Aegean Sea and southern approach
to Turkish Straits
Population: 9,987,785 (July 1987), average
annual growth rate 0.28%
Nationality: noun — Greek(s); adjective —
Greek
Ethnic divisions: 97.7% Greek, 1.3%
Turkish; 1.0% Vlach, Slav, Albanian,
Pomach (note — the Greek Government
states there are no ethnic divisions in
Greece)
Religion: 98% Greek Orthodox, 1.3%
Muslim, 0.7% other
Language: Greek (official); English and
French widely understood
Infant mortality rate: 13.8/1,000 (1984)
Life expectancy: men 72, women 75
Literacy: 95%
Labor force: 3.86 million (1985); 43%
services, 27% agriculture, 20% manufactur-
ing and mining, 7% construction; 8.3%
unemployment
Organized labor: 10-15% of total labor
force, 20-25% of urban labor force','43cfaee8d612be126f2af74f3bef2cbd4dcebcea308dc680ed45da2b056e7bf8','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a8cce9c02ebf6f95c70675435089a66ccd9efe40ecd7e0c53c10215cd776bc2',1981,'GL','Greenland','geography',251,'Total area: 2,175,600 km2; land area:
341,700 km2 (ice free)
Comparative area: about three times the
size of Texas
Coastline: 44,087 km
Maritime claims:
Contiguous zone: 4 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: arctic to subarctic; cool summers,
cold winters
Terrain: flat to gradually sloping icecap
covers all but narrow, barren, steep, rocky
coast
Land use: 0% arable land; 0% permanent
crops; 1% meadows and pastures; NEGL%
forest and woodland; 99% other
Environment: sparse population confined
to small settlements along coast
Special notes: dominates North Atlantic
Ocean between North America and
Europe','d6dd875cf9a3e44d06910cab14063d06e93274e9138c90ed1a479dba1f56a7a3','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48d1440640f57c6aa99fff614d5f3f9ecb92414c4be808d224d7dcedc49aa353',1981,'GD','Grenada','geography',257,'Total area: 340 km2; land area: 340 km2
Comparative area: about twice the size of
Washington, D.C.
Coastline: 121 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; tempered by northeast
trade winds
Terrain: volcanic in origin with central
mountains
Land use: 15% arable land; 26% perma-
nent crops; 3% meadows and pastures; 9%
forest and woodland; 47% other
Environment: lies on edge of hurricane
belt; hurricane season lasts from June to
November
Special notes: islands of the Grenadines
group are divided politically with St.
Vincent and the Grenadines','03b1819d64645bb881582b0af19a24b8262fc21c810c453f7ad5c078f01a39ad','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c014fd62928e19a7788c229a72a01f0fb8f939bb9e9f10abc2e501f80d45463',1981,'GP','Guadeloupe','geography',259,'Total area: 1,780 km2; land area: 1,760
km2
Comparative area: about half the size of
Rhode Island
Coastline: 306 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: subtropical tempered by trade
winds; relatively high humidity
Terrain: Basse- Terre is volcanic in origin
with interior mountains; Grand-Terre is
low limestone formation
Land use: 18% arable land; 5% permanent
Drops; 13% meadows and pastures; 40%
Forest and woodland; 24% other; includes
1% irrigated
Environment: subject to hurricanes (June
:o December)
special notes: none
Population: 336,354 (July 1987), average
innual growth rate 0.61%
Vationality: noun — Guadeloupian(s);
idjective — Guadeloupe
Ethnic divisions: 90% black or mulatto;
3% white; less than 5% East Indian, Leba-
nese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, Creole patois
Infant mortality rate: 18.6/1,000 (1983)
Life expectancy: 67
Literacy: over 70%
Labor force: 120,000; services, govern-
ment, and commerce 53.0%; industry
25.8%; agriculture 21.2%; significant un-
employment
Organized labor: 11% of labor force','f8c9e7266ba91c9ceb5c8c9d9ce40ac15390710953f32ef2db2d718e4e500ce5','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e84fda82f827b1e8e85bdf1bc625d3e4d49503ee10edddbe5478076a93ee4b92',1981,'GG','Guernsey','geography',265,'Total area: 194 km2; land area: 194 km2
Comparative area: slightly larger than
Washington, D.C.
Coastline: 50 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: temperate with mild winters and
cool summers; about 50% of days are
overcast
Terrain: mostly level with low hills in
southwest
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
about 50% cultivated
Environment: large, deepwater harbor at
St. Peter Port
Special notes: 52km west of France
Population: 52,947 (July 1987), average
annual growth rate -0.12%
Nationality: noun — Channel Islander(s);
adjective — Channel Islander
Ethnic divisions: UK and Norman-French
descent
Religion: Anglican, Roman Catholic,
Presbyterian, Raptist, Congregational,
Methodist
Language: English, French; Norman-
French dialect spoken in country districts
Literacy: universal education','d20db1eedf1ce897da9d60f74cc2d9a97d99d17b9c6732fc9215e88821ff59e6','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5ba1d00a982b37eac20e69245a1b1b2d4c81e9650309ef78afac51c45831060',1981,'GN','Guinea','geography',268,'Total area: 245,860 km2; land area:
245,860 km2
Comparative area: slightly smaller than
Oregon
Land boundaries: 3,476 km total
Coastline: 320 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: generally hot and humid;
monsoonal-type rainy season (June to
November) with southwesterly winds; dry
season (December to May) with northeast-
erly harmattan winds
Terrain: generally flat coastal plain, hilly
to mountainous interior
Land use: 6% arable land; NEGL% per-
manent crops; 12% meadows and pastures;
42% forest and woodland; 40% other;
includes NEGL% irrigated
Environment: hot, dry, dusty harmattan
haze may reduce visibility during dry
season; deforestation
Special notes: none
Population: 6,737,760 (July 1987), average
annual growth rate 2.50%
Nationality: noun — Guinean(s); adjec-
tive— Guinean
Ethnic divisions: Fulani, Malinke, Sousou,
15 smaller tribes
Religion: 85% Muslim, 5% indigenous
beliefs, 10% Christian
Language: French (official); each tribe has
its own language
Infant mortality rate: 159/1,000
Life expectancy: 40
Literacy: 20% in French; 48% in local
languages
Labor force: 2.4 million (1983); 82.0%
agriculture, 11.0% industry and commerce,
5.4% services, 1.6% government
Organized labor: virtually 100% of wage
labor force loosely affiliated with the
National Confederation of Guinean
Workers
Total area: 960 km2; land area: 960 km2
Comparative area: about one-third the
size of Rhode Island
Coastline: 209 km
Maritime claims: (measured from claimed
archipelagic baselines)
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; hot, humid; one rainy
season (October to May)
Terrain: volcanic, mountainous
Land use: 1% arable land; 36% permanent
crops; 1% meadows and pastures; 0% forest
and woodland; 62% other
Environment: deforestation; soil erosion
Special notes: smallest country in Africa
Population: 114,025 (July 1987), average
annual growth rate 2.89%
Nationality: noun — Sao Tomean(s); adjec-
tive— Sao Tomean
Ethnic divisions: mestico, angolares (de-
scendents of Angolan slaves), forros (de-
scendents of freed slaves), servicais (con-
tract laborers from Angola, Mozambique,
and Cape Verde), tongas (children of
servicais born on the islands), and Europe-
ans (primarily Portuguese)
Religion: Roman Catholic, Evangelical
Protestant, Seventh-Day Adventist
Language: Portuguese (official)
Infant mortality rate: 63/1,000 (1983)
Literacy: est. 50%
Labor force: (1981) 21,096; most of popu-
lation engaged in subsistence agriculture
and fishing; some unemployment; labor
shortages on plantations and for skilled
workers','d87dc4c173ba6b765adb7dd4a129b23fa08dc52ff05c731fda108519994fe68c','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a4abcac823bb1769131972bc57f0ba63401dabe39449f9216bdd836318d8473',1981,'GW','Guinea-Bissau','geography',270,'Total area: 36,120 km2; land area: 28,000
km2
Comparative area: about the size of
Connecticut and New Hampshire com-
bined
Land boundaries: 740 km total
Coastline: 350 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; generally hot and hu-
mid; monsoonal-type rainy season (June to
November) with southwesterly winds; dry
season (December to May) with northeast-
erly harmattan winds
Terrain: mostly low coastal plain rising to
savanna in east
Land use: 9% arable land; 1% permanent
crops; 46% meadows and pastures; 38%
forest and woodland; 6% other
Environment: hot, dry, dusty harmattan
haze may reduce visibility during dry
season
Special notes: none
Population: 928,425 (July 1987), average
annual growth rate 2.36%
Nationality: noun — Guinea-Bissauan(s);
adjective — Guinea- Bissauan
Ethnic divisions: about 99% African (30%
Balanta, 20% Fula, 14% Manjaca, 13%
Mandinga, 7% Papel); less than 1% Euro-
pean and mulatto
Religion: 65% indigenous beliefs, 30%
Muslim, 5% Christian
Language: Portuguese (official); Criolo and
numerous African languages
Infant mortality rate: 250/1,000 (1982)
Life expectancy: 42
Literacy: 9%
Labor force: 90% agriculture; 5% industry,
services, and commerce; 5% government','c5920f360b0a287779628702504784bcf210323e7c60016a08cd1f9231ee80af','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41d7baaf61f314070890e1dcfbf6dcba18914c07cb5e0ea649ab469c5b35cdc8',1981,'GY','Guyana','geography',274,'Land area: 214,970 km2; land area:
196,850 km2
Comparative area about the size of Idaho
Land boundaries: 2,575 km total
Coastline: 459 km
Maritime claims:
Continental shelf: outer edge of conti-
nental margin or 200 nm
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Essequibo area
claimed by Venezuela; Suriname claims
area between New (Upper Courantyne)
and Courantyne/Kutari rivers (all head-
waters of the Courantyne)
Climate: tropical; hot, humid, moderated
by northeast trade winds; two rainy sea-
sons (May to mid-August, mid-November
to mid-January)
Terrain: mostly rolling highlands; low
coastal plain; savanna in south
Land use: 3% arable land; NEGL% per-
manent crops; 6% meadows and pastures;
83% forest and woodland; 8% other; in-
cludes 1% irrigated
Environment: flash floods a constant threat
during rainy seasons; water pollution
Special notes: none
Population: 765,844 (July 1987), average
annual growth rate 0.03%
Nationality: noun — Guyanese (sing., pi.);
adjective — Guyanese
Ethnic divisions: 51% East Indian, 43%
black and mixed, 4% Amerindian, 2%
European and Chinese
Religion: 57% Christian, 33% Hindu, 9%
Muslim, 1% other
Language: English, Amerindian dialects
Infant mortality rate: 41/1,000 (1985)
Life expectancy: 70
Literacy: 85%
Labor force: 268,000 (1985); 44.5% indus-
try and commerce, 33.8% agriculture,
21.7% services; public sector employment
amounts to 60-80% of the total labor force;
unemployment and underemployment
30% (1985 est.)
Organized labor: 34% of labor force','1874f4f0e9f1e8f3d7ab4f202823299c8cb534489c3505fc32770623e60d34aa','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d14e9fc93891b489c9e4d4f976ab564c39783330e8e1e6c207eb98275033c990',1981,'HT','Haiti','geography',279,'Total area: 27,750 km2; land area: 27,560
km2
Comparative area: about the size of
Maryland
Land boundary: 361 km with Dominican
Republic
Coastline: 1,771 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: to depth of exploita-
tion
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claims Navassa
Island (US possession)
Climate: tropical; semiarid where moun-
tains in east cut off trade winds
Terrain: mostly rough and mountainous
Land use: 20% arable land; 13% perma-
nent crops; 18% meadows and pastures;
4% forest and woodland; 45% other; in-
cludes 3% irrigated
Environment: lies in middle of hurricane
belt; hurricanes have caused extensive
damage; occasional flooding and earth-
quakes; deforestation
Special notes: shares island of Hispaniola
with Dominican Republic
Population: 6,187,115 (July 1987), average
annual growth rate 1.78%
105
Haiti (continued)
Nationality: noun — Haitian(s); adjective —
Haitian
Ethnic divisions: 95% black, 5% mulatto
and European
Religion: 75-80% Roman Catholic (of
which an overwhelming majority also
practice Voodoo), 10% Protestant, 10%
other
Language: French (official) spoken by only
10% of population; all speak Creole
Infant mortality rate: 107/1,000 (1983)
Life expectancy: 45
Literacy: 23%
Labor force: 2.3 million (1982); 66%
agriculture, 25% services, 9% industry;
significant unemployment; shortage of
skilled labor, unskilled labor abundant
Organized labor: less than 1% of labor
force','ddfe31392759ff40a0ed2a6c6568a2d88ac16590735f8a9ef11e8a9a48f5c2ef','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca275a36fe8d63412d3064a0104e939d949c817fd76fccf1471cb18729cb345f',1981,'HN','Honduras','geography',281,'Total area: 112,090 km2; land area:
111,890km2
Comparative area: slightly larger than
Tennessee
Land boundaries: 1,530 km total
Coastline: 820 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: El Salvador
Climate: subtropical in lowlands, temper-
ate in mountains
Terrain: mostly mountains in interior,
narrow coastal plains
Land use: 14% arable land; 2% permanent
crops; 30% meadows and pastures; 34%
forest and woodland; 20% other; includes
1% irrigated
Environment: subject to frequent, but
generally mild, earthquakes; damaging
hurricanes along Caribbean coast; defores-
tation; soil erosion
Special notes: none
Population: 4,823,818 (July 1987), average
annual growth rate 3.33%
Nationality: noun — Honduran(s); adjec-
tive— Honduran
Ethnic divisions: 90% mestizo (mixed
Indian and European), 7% Indian, 2%
black, 1% white
Religion: about 97% Roman Catholic;
small Protestant minority
Language: Spanish, Indian dialects
Infant mortality rate: 78/1,000 (1984)
Life expectancy: 58.7
Literacy: 56%
Labor force: 1.3 million (1985); 62%
agriculture, 20% services, 9% manufactur-
ing, 3% construction, 6% other; 25% unem-
ployed, 25% underemployed
Organized labor: 40% of urban labor
force, 20% of rural work force (1985)','7950b6d5ab8ffb128297fc0a1fc9b8b9314efec2d03e2ab67d7fbb5e496aebe4','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d36d359f85c945a1bf4ab2ef81b6a10526cd54e245eb10e999ee54ab9eb3f47',1981,'HK','Hong Kong','geography',285,'Total area: 1,040 km2; land area: 990 km2
Comparative area: about one-third the
size of Rhode Island
Land boundary: 24 km with China
Coastline: 733 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 3 nm
Boundary disputes: none; will become a
Special Administrative Region of China in
1997
Climate: tropical monsoon; cool and
humid in winter, hot and rainy from
spring through summer, warm and sunny
in fall
Terrain: hilly to mountainous with steep
slopes; lowlands in north
Land use: 7% arable land; 1% permanent
crops; 1% meadows and pastures; 12%
forest and woodland; 79% other; includes
3% irrigated
Environment: more than 200 islands;
occasional typhoons
Special notes: outstanding natural harbor
Population: 5,608,610 (July 1987), average
annual growth rate 1.32%
Nationality: adjective — Hong Kong
Ethnic divisions: 98% Chinese, 2% other
108
Religion: 90% eclectic mixture of local
religions, 10% Christian
Language: Chinese (Cantonese), English
Infant mortality rate: 9.2/1,000 (1986)
Life expectancy: 75 (1986)
Literacy: 75%
Labor force: (June 1985) 2.64 million;
36.3% manufacturing; 22.1% commerce;
18.4% services; 7.6% construction; 7.6%
transport and communications; 6.8%
financing, insurance, and real estate; 1.2%
agriculture, fishing, mining, and quarrying;
unemployment (seasonally adjusted) 3.0%
Organized labor: 15.2% of 1984 labor
force','b6495de445d6a0fba8eb3e65cb6e2a9f1ae7c06bc3b64d6ebe7db9240145e7ee','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c019cdb83e230c969e3943693ebecf382386be95bac8b6654f9c28f700729384',1981,'HU','Hungary','geography',287,'Total area: 93,030 km2; land area: 92,340
km2
Comparative area: slightly smaller than
Indiana
Land boundaries: 2,242 km total
Boundary disputes: none; Transylvania
question with Romania
Climate: temperate; cold, cloudy, humid
winters; warm summers
Terrain: mostly flat to rolling plains
Land use: 54% arable land; 3% permanent
crops; 14% meadows and pastures; 18%
forest and woodland; 11% other; includes
2% irrigated
Environment: levies are common along
many streams, but flooding occurs almost
every year
Special notes: landlocked; strategic loca-
tion astride main land routes between
Western Europe and Balkan Peninsula as
well as between USSR and Mediterranean
basin
Population: 10,609,447 (July 1987), aver-
age annual growth rate —0.19%
Nationality: noun — Hungarian(s); adjec-
tive— Hungarian
Ethnic divisions: 96.6% Hungarian, 1.6%
German, 1.1% Slovak, 0.3% Southern Slav,
0.2% Romanian
Religion: 67.5% Roman Catholic, 20.0%
Calvinist, 5.0% Lutheran, 7.5% atheist and
other
Language: 98.2% Hungarian, 1.8% other
Infant mortality rate: 19/1,000 (1983)
Life expectancy: men 65.6, women 73.7
(1984)
Literacy: 98.9%
Labor force: 4,913,000 (1985); 31.3%
industry; 21.1% agriculture; 7.2% construc-
tion; 40.4% services, trade, government,
other','3dd05fcb37e35534eb1a634ddb8e42a4b06e2ce671dcbcef8b7b760cb8326406','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d04bac11f236b6928695d31e27c32bacba192cd65cb12b2bbc65b7f3007bffc',1981,'IS','Iceland','geography',291,'Total area: 103,000 km2; land area:
100,250 km2
Comparative area: about the size of
Virginia
Coastline: 4,988 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Rockall conti-
nental shelf dispute involving Denmark,
Ireland, and UK
Climate: temperate; Gulf Stream influ-
ence; mild, windy winters; damp, cool
summers
Terrain: mostly plateau interspersed with
mountain peaks, icefields
Land use: NEGL% arable land; 0% per-
manent crops; 23% meadows and pastures;
1% forest and woodland; 76% other
Environment: subject to earthquakes and
volcanic activity
Special notes: strategic location between
Greenland and Europe; westernmost
European country
Population: 244,676 (July 1987), average
annual growth rate 0.69%
Nationality: noun— Icelander(s); adjec-
tive— Icelandic
Ethnic divisions: homogeneous mixture of
descendants of Norwegians and Celts
Religion: 95% Evangelical Lutheran, 3%
other Protestant and Roman Catholic, 2%
no affiliation
Language: Icelandic
Infant mortality rate: 6.1/1,000 (1983)
Life expectancy: men 73.9, women 79.4
Literacy: 99.9%
Labor force: 122,800; 55.4% commerce,
finance, and services; 11.3% agriculture;
8.0% fish processing; 5.0% fishing; 20.3%
other manufacturing (1985); 0.9% unem-
ployment (1985 average)
Organized labor: 60% of labor force','a7d41b10a76aa04d6e10252f63c2f4fffcfc8816938d402e4e7ccdbaaf2338e4','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e5a957eea547fa53f9a6b2c47a58e943ff5b88469b5e90e4e3df5461dae2493',1981,'ID','Indonesia','geography',295,'Total area: 1,904,570 km2; land area:
1,811,570km2
Comparative area: about the size of
Alaska and California combined
Land boundaries: 2,736 km total
Coastline: 54,716 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: to depth of exploita-
tion
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with Australia; East Timor question
with Portugal
Climate: tropical; hot, humid; more mod-
erate in highlands
Terrain: mostly coastal lowlands; larger
islands have interior mountains
Land use: 8% arable land; 3% permanent
crops; 7% meadows and pastures; 67%
forest and woodland; 15% other; includes
3% irrigated
Environment: more than 13,500 islands;
occasional floods; deforestation
Special notes: straddles Equator; strategic
location astride or along major sea lanes
from Indian Ocean to Pacific Ocean
Population: 180,425,534; average annual
growth rate 2.05%
Nationality: noun — Indonesian(s); adjec-
tive— Indonesian
Ethnic divisions: majority of Malay stock
comprising 45.0% Javanese, 14.0% Sundan-
ese, 7.5% Madurese, 7.5% coastal Malays,
26.0% other
Religion: 88% Muslim, 6% Protestant, 3%
Roman Catholic, 2% Hindu, 1% other
Language: Indonesian (modified form of
Malay; official); English and Dutch leading
foreign languages; local dialects, the most
widely spoken of which is Javanese
Infant mortality rate: 95/1,000 (1983)
Life expectancy: 54
Literacy: 62%
Labor force: 67 million (1985 est.); 55%
agriculture, 10% manufacturing, 4% con-
struction, 3% transport and communica-
tions
Organized labor: 3 million members
(claimed); about 5% of labor force','8901a6d18a8efb615004d3735f2d6d0065721595375855c84d1fd60f502809bc','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dde76896e34fcbbe032794e6081e47ff0d02b3557c24c77aa913646518bd5c6d',1981,'OM','Oman','geography',298,'Total area: 1,648,000 km2; land area:
1,636,000km2
Comparative area: about the size of
Alaska and Pennsylvania combined
Land boundaries: 5,318 km total
Coastline: 3,180 km
Maritime claims:
Continental shelf: not specific
Exclusive fishing zone: 50 nm in the
Sea of Oman; median-line boundaries in
the Persian Gulf
Territorial sea: 12 nm
Boundary disputes: none; on 17 Septem-
ber 1980 Iraq abrogated 1975 treaty with
Iraq which shifted the boundary in Shaft
al Arab waterway from the low water
mark on Iranian side of river to midpoint
of deepest navigable channel (thalweg) —
heavy fighting with Iraq began on 22
September 1980; Kurdistan question with
Iraq; occupies three islands claimed by
UAE in Strait of Hormuz; periodic dis-
putes with Afghanistan over Helmand
water rights
Climate: mostly arid or semiarid, sub-
tropical along Caspian coast
Terrain: rugged, mountainous rim; high,
central basin with deserts, mountains;
small, discontinuous plains along both
coasts
Land use: 8% arable land; NEGL% per-
manent crops; 27% meadows and pastures;
11% forest and woodland; 54% other;
includes 2% irrigated
Environment: deforestation; overgrazing;
desertification
Special notes: none
Population: 50,407,763 (July 1987), aver-
age annual growth rate 3.32%; figures do
not take into account the impact of the
Iran- Iraq war
Nationality: noun — Iranian(s); adjective —
Iranian
Ethnic divisions: 63% ethnic Persian, 18%
Turkic, 13% other Iranian, 3% Kurdish,
3% Arab and other Semitic
Religion: 93% Shi''a Muslim; 5% Sunni
Muslim; 2% Zoroastrian, Jewish, Christian,
and Baha''i
Language: Farsi, Turki, Kurdish, Arabic,
English, French
Infant mortality rate: 110/1,000 (1986
est.)
Life expectancy: 54
Literacy: 48%
Labor force: 12.0 million, (1979 est.); 33%
agriculture, 21% manufacturing; shortage
of skilled labor; unemployment may be as
high as 35%
Total area: 212,460 km2; land area:
212,460 km2
Comparative area: about the size of New','15b17435bedb8dd36f2e71f4336f2a4e4d516248a3df3e05df18d869044e7c38','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05434a1be29fee11583726c9a5e00191e2bae13dfcb0fdbea50770336a3574e8',1981,'IQ','Iraq','geography',302,'Total area: 434,920 km2; land area:
433,970 km2
Comparative area: larger than California
Land boundaries: 3,668 km total
Coastline: 58 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 12 nm
Boundary disputes: none; on 17 Septem-
ber 1980 Iraq abrogated 1975 treaty with
Iraq which shifted the boundary in Shatt
al Arab waterway from the low water
mark on Iranian side of river to midpoint
of deepest navigable channel (thalweg) —
heavy fighting with Iran began on 22
September 1980; Kurdistan question with
Iran; ownership of Warbah and Bubiy5n
islands disputed with Kuwait; shares Neu-
tral Zone with Saudi Arabia; periodic
disputes with Syria over Euphrates water
rights; potential dispute over water devel-
opment plans by Turkey for the Tigris and
Euphrates rivers
Climate: desert; mild to cool winters with
dry, hot, cloudless summers
Terrain: mostly broad plains; reedy
marshes in southeast; mountains along
borders with Iran and Turkey
Land use: 12% arable land; 1% permanent
crops; 9% meadows and pastures; 3% forest
and woodland; 75% other; includes 4%
irrigated
117
Iraq (continued)
Environment: development of Tigris-
Euphrates river systems contingent upon
agreements with upstream riparians (Syria,
Turkey); air and water pollution; soil
degradation and erosion; desertification
Special notes: none
Climate: dry desert; intensely hot sum-
mers; short, cool winters
Terrain: flat to slightly undulating desert
plain
Land use: NEGL% arable land; 0% per-
manent crops; 8% meadows and pastures;
NEGL% forest and woodland; 92% other;
includes NEGL% irrigated
Environment: some of world''s largest and
most sophisticated desalination facilities
provide most of water; air and water
pollution; desertification
Special notes: strategic location at head of
Persian Gulf and close to Iran-Iraq war
zone
Population: 1,863,615 (July 1987), average
annual growth rate 4.13%
Nationality: noun — Kuwaiti(s); adjective —
Kuwaiti
Ethnic divisions: 39% Kuwaiti, 39% other
Arab, 9% South Asian, 4% Iranian, 9%
other
Religion: 85% Muslim (30% Shi''a, 45%
Sunni), 15% Christian, Hindu, Parsi, and
other
Language: Arabic (official); English widely
spoken
Infant mortality rate: 26.1/1,000 (1985)
Life expectancy: men 69, women 74
Literacy: about 71%
Labor force: 566,000 (1985); 45.0% ser-
vices, 20.0% construction, 12.0% trade,
8.6% manufacturing, 2.6% finance and real
estate, 1.9% agriculture, 1.7% power and
water, 1.4% mining and quarrying; 70% of
labor force is non-Kuwaiti
Organized labor: labor unions, first autho-
rized in 1964, formed in oil industry and
among government personnel
Total area: 236,800 km2; land area:
230,800 km2
Comparative area: slightly larger than
Utah
Land boundaries: 5,053 km total
Climate: tropical monsoon; rainy season
(May to October); dry season (February to
May)
Terrain: mostly rugged mountains; some
plains and plateaus
Land use: 4% arable land; NEGL% per-
manent crops; 3% meadows and pastures;
58% forest and woodland; 35% other;
includes 1% irrigated
Environment: deforestation; soil erosion;
subject to floods
Special notes: landlocked','0ec0fbc3e0f3f5c66953d1d377d15e9e6a4bed0f6f1113212e7f7b92d1574656','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b5c954b041f90d2c45541b22cff8c1c94a1c0d2dac689d458f50fd44a530601',1981,'IE','Ireland','geography',305,'Total area: 70,280 km2; land area: 68,890
km2
Comparative area: slightly larger than
West Virginia
Land boundary: 360 km with United
Kingdom
Coastline: 1,448 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: none; maritime dis-
pute with UK; Northern Ireland question
with UK; Rockall continental shelf dispute
involving Denmark, Iceland, and UK
Climate: temperate marine; modified by
Gulf Stream; mild winters, cool summers;
consistently humid; overcast about half the
time
Terrain: mostly level to rolling interior
plain surrounded by rugged hills and low
mountains
Land use: 14% arable land; NEGL%
permanent crops; 71% meadows and
pastures; 5% forest and woodland; 10%
other
Environment: deforestation
Special notes: none
Population: 3,534,553 (July 1987), average
annual growth rate —0.08%
Nationality: noun — Irishman(men), Irish
(collective pi.); adjective — Irish
Ethnic divisions: Celtic, with English
minority
Religion: 94% Roman Catholic, 4% Angli-
can, 2% other
Language: Irish (Gaelic) and English
(official); English is widely spoken
Infant mortality rate: 11/1,000(1983)
Life expectancy: 73
Literacy: 99%
Labor force: about 1,299,400 (1985);
27.5% manufacturing and construction;
16.4% agriculture, forestry, fishing; 20.4%
services; 6.6% government; 6.2% transpor-
tation; other 22.9%; 17.4% unemployment
(1985 average)
Organized labor: 36% of labor force','4d7bafb894ad5731a70277ee4d4fe75c18b3c09822cc1b3769dfd1d8fa78df24','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edfdbada55213ac493c8132849b59f625a2ae8adde1aef52f88d903df08e612b',1981,'IL','Israel','geography',310,'Total area: 20,770 km2; land area: 20,330
km2
Comparative area: about the size of
Massachusetts
Land boundaries: 1,036 km total (before
1967 war)
Coastline: 273 km (before 1967 war)
Maritime claims:
Continental shelf: to depth of exploita-
tion
Territorial sea: 6 nm
Boundary disputes: separated from Jor-
dan, Lebanon, and Syria by 1949 Armi-
stice Line; disputes with Egypt over Taba
area and precise location of some individ-
ual boundary markers; West Bank and
Gaza Strip are Israeli occupied with status
to be determined; Golan Heights is Israeli
occupied; Israeli troops in southern Leba-
non since June 1982
Climate: temperate; hot and dry in desert
areas
Terrain: mostly desert (Negev) in south;
low coastal plain; central mountains;
Jordan Rift Valley
Land use: 17% arable land; 5% permanent
crops; 40% meadows and pastures; 6%
forest and woodland; 32% other; includes
11% irrigated
Environment: sandstorms may occur
during spring and summer; limited arable
land and natural water resources pose
serious constraints; deforestation
Special notes: none','5aef60f2727bec526cd7648231155ded58978c10956e051c917ffc5ed8674969','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2796921e85dcb54fd82515f1dc5da8ab9e087fe2ec8556d36da280fd1ed3e3c',1981,'IT','Italy','geography',314,'Total area: 301,230 km2; land area:
294,020 km2
Comparative area: slightly larger than
Arizona
Land boundaries: 1,702 km total
Coastline: 4,996 km
Maritime claims:
Continental shelf: 200 m or to depth of
exploitation
Territorial sea: 12 nm
Boundary disputes: none; South Tyrol
question with Austria; Trieste question
with Yugoslavia
Climate: temperate; Alpine in far north
Terrain: mostly rugged and mountainous;
some plains, coastal lowlands
Land use: 32% arable land; 10% perma-
nent crops; 17% meadows and pastures;
22% forest and woodland; 19% other;
includes 10% irrigated
Environment: regional risks include land-
slides, mudflows, snowslides, earthquakes,
volcanic eruptions, flooding, pollution; land
sinkage in Venice
Special notes: strategic location dominat-
ing central Mediterranean as well as south-
ern sea and air approaches to Western
Europe
Population: 57,350,850 (July 1987), aver-
age annual growth rate 0.19%
Nationality: noun — Italian(s); adjective —
Italian
Ethnic divisions: primarily Italian but
population includes small clusters of
German-, French-, and Slovene-Italians in
the north and of Albanian-Italians in the
south
Religion: almost 100% nominally Roman
Catholic
Language: Italian; parts of Trentino-Alto
Adige region (for example, Bolzano) are
predominantly German speaking; signifi-
cant French-speaking minority in Valle
d''Aosta region; Slovene-speaking minority
in the Trieste-Gorizia area
Infant mortality rate: 11.3/1,000 (1984)
Life expectancy: 73
Literacy: 93%
Labor force: 22.20 million (1985); 30.5%
industry, 10.5% agriculture, 48.6% services
(1984); 10.8% unemployment
Organized labor: 40-45% (est.) of labor
force
Total area: 322,460 km2; land area:
318,000 km2
Comparative area: slightly larger than
New Mexico
Land boundaries: 3,227 km total
Coastline: 515 km
Maritime claims:
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical along coast, semiarid in
far north; three seasons — warm and dry
(November to March), hot and dry (March
to May), hot and wet (June to October)
Terrain: mostly flat to undulating plains;
mountains in northwest
Land use: 9% arable land; 4% permanent
crops; 9% meadows and pastures; 26%
forest and woodland; 52% other; includes
NEGL% irrigated
Environment: coast has heavy surf and no
natural harbors; deforestation
Special notes: none
Population: 10,766,632 (July 1987), aver-
age annual growth rate 3.82%
Nationality: noun — Ivorian(s); adjective —
Ivorian
Ethnic divisions: over 60 ethnic groups;
most important are the Baoule 23%, Bete
18%, Senoufou 15%, Malinke 11%, and
Agni; about 2 million foreign Africans,
mostly Burkinabe; about 130,000 to
330,000 non-Africans (30,000 French and
100,000 to 300,000 Lebanese)
Religion: 63% indigenous, 25% Muslim,
12% Christian
Language: French (official), over 60 native
dialects; Dioula most widely spoken
Infant mortality rate: 127/1,000 (1980)
Literacy: 24%
Labor force: over 85% of population
engaged in agriculture, forestry, livestock
raising; about 11% of labor force are wage
earners, nearly half in agriculture and the
remainder in government, industry, com-
merce, and professions
Organized labor: 20% of wage labor force
Climate: temperate; hot, relatively dry
summers with mild, rainy winters along
coast; warm summer with cold winters
inland
Terrain: mostly mountains with large areas
of karst topography; plain in north
Land use: 28% arable land; 3% permanent
crops; 25% meadows and pastures; 36%
forest and woodland; 8% other; includes
1% irrigated
Environment: subject to frequent and
very destructive earthquakes
Special notes: controls the most important
land routes from central and western
Europe to Aegean Sea and Turkish Straits
Population: 23,430,830 (July 1987), aver-
age annual growth rate 0.66%
Nationality: noun — Yugoslav(s); adjec-
tive— Yugoslav
Ethnic divisions: 36.3% Serb, 19.7%
Croat, 8.9% Muslim, 7.8% Slovene, 7.7%
Albanian, 5.9% Macedonian, 5.4%
Yugoslav, 2.5% Montenegrin, 1.9% Hun-
garian, 3.9% other (1981 census)
Religion: 50% Eastern Orthodox, 30%
Roman Catholic, 10% Muslim, 1% Protes-
tant, 9% other
Language: Serbo-Croatian, Slovene, Mace-
donian (all official); Albanian, Hungarian
Infant mortality rate: 30/1,000 (1982)
Life expectancy: men 68, women 73
Literacy: 90.5%
Labor force: 10.1 million (1983); 25%
agriculture, 29% mining and manufactur-
ing; about 5% of labor force are guest
workers in Western Europe; unemploy-
ment about 10.0% of domestic labor force,
including private agriculture (August 1986)
Total area: 2,345,410 km2; land area:
2,267,600 km2
Comparative area: about one-fourth the
size of US
Land boundaries: 9,902 km total
Coastline: 37 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: sections with Congo
and Zambia are indefinite
Climate: tropical; hot, humid in river
basin; cooler, drier in southern highlands
Terrain: vast central basin is a low-lying
plateau; mountains in east
Land use: 3% arable land; NEGL% per-
manent crops; 4% meadows and pastures;
78% forest and woodland; 15% other;
includes NEGL% irrigated
Environment: straddles Equator; periodic
droughts in south
Special notes: very narrow strip of land is
only outlet to Atlantic Ocean','ee909ca89419211a1439cad7101967e0612a9588d560b0f9e14db8071a45bbd4','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('064b71e20613ea492d82ad3cda4ec89e1c5512b2ae75d5925d90b468fe937917',1981,'JM','Jamaica','geography',318,'Total area: 10,990 km2; land area: 10,830
km2
Comparative area: slightly smaller than
Connecticut
Coastline: 1,022 km
Maritime claim:
Territorial sea: 12 nm
Climate: tropical; hot, humid; temperate
interior
Terrain: mostly mountains with narrow,
discontinuous coastal plain
Land use: 19% arable land; 6% permanent
crops; 18% meadows and pastures; 28%
forest and woodland; 29% other; includes
3% irrigated
Environment: subject to hurricanes, espe-
cially (May to December); deforestation;
water pollution
Special notes: strategic location between
Cayman Trench and Jamaica Channel, the
main sea lanes for Panama Canal
Population: 2,455,536 (July 1987), average
annual growth rate 1.17%
Nationality: noun — Jamaican(s); adjec-
tive— Jamaican
Ethnic divisions: 76.3% African, 15.1%
Afro-European, 3.4% East Indian and
Afro- East Indian, 3.2% white, 1.2% Chi-
nese and Afro-Chinese, 0.8% other
Religion: predominantly Protestant (in-
cluding Anglican and Baptist), some Ro-
man Catholic, some spiritualist cults
Language: English, Creole
Infant mortality rate: 16.8/1,000 (1984)
Life expectancy: 65
Literacy: 76%
Labor force: 728,700 (1984); 32% agricul-
ture, 28% industry and commerce, 27%
services, 13% government; shortage of
technical and managerial personnel; 30%
unemployment
Organized labor: about 33% of labor force
(1980)','725ca6adb2ac4ab39993609da0ae2bc7dffc7d0b3e890de8d5affa6ca7f03fea','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc988e2535b83fb18e0f630de8ec997b488ec338486c5d22d6485b1043bd54c4',1981,'JP','Japan','geography',322,'Total area: 372,310 km2; land area:
371,030 km2
Comparative area: slightly smaller than
California
Coastline: 13,685 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm (3 nm in interna-
tional straits — La Perouse or Soya,
Tsugaru, Osumi, and Eastern and West-
ern channels of Tsushima or Korea
Strait)
Boundary disputes: none; Habomai Is-
lands, Etorofu, Kunashiri, and Shikotan
islands occupied by Soviet Union since
1945, claimed by Japan; Kuril Islands
administered by Soviet Union; Liancourt
Rocks disputed with South Korea
Climate: varies from tropical in south to
cool temperate in north
Terrain: mostly rugged and mountainous
Land use: 11% arable land; 2% permanent
crops; 2% meadows and pastures; 68%
forest and woodland; 17% other; includes
9% irrigated
Environment: many dormant and some
active volcanoes; about 1,500 seismic
occurrences (mostly tremors) every year
Special notes: strategic location in north-
east Asia
126
Population: 122,124,293 (July 1987),
average annual growth rate 0.55%
Nationality: noun — Japanese (sing., pi.);
adjective — Japanese
Ethnic divisions: 99.4% Japanese, 0.6%
other (mostly Korean)
Religion: most Japanese observe both
Shinto and Buddhist rites; about 16%
belong to other faiths, including 0.8%
Christian
Language: Japanese
Infant mortality rate: 6/1,000 (1984)
Life expectancy: men 74.54, women 80.18
Literacy: 99%
Labor force: (1985) 59.3 million; 53%
trade and services; 33% manufacturing,
mining, and construction; 9% agriculture,
forestry, and fishing; 3% government;
2.68% unemployed (1985 average)
Organized labor: about 30% of labor force
Total area: 406,750 km2; land area:
397,300 km2
Comparative area: about the size of
California
Land boundaries: 3,444 km total
Boundary disputes: Brazil (Rio Parana
area)
Climate: varies from temperate in east to
semiarid in far west
Terrain: grassy plains and wooded hills
east of Paraguay River; Gran Chaco region
west of Paraguay River mostly low,
marshy plain
Land use: 4% arable land; 1% permanent
crops; 39% meadows and pastures; 51%
forest and woodland; 5% other; includes
NEGL% irrigated
Environment: local flooding in southeast
(early September to June); poorly drained
plains may become boggish (early October
to June)
Special notes: landlocked; buffer between
Argentina and Brazil
Population: 4,251,924 (July 1987), average
annual growth rate 3.15%
Nationality: noun — Paraguayan(s); adjec-
tive— Paraguayan
Ethnic divisions: 95% mestizo (Spanish
and Indian), 5% white and Indian
Religion: 97% Roman Catholic; Mennonite
and other Protestant denominations
Language: Spanish (official) and Guarani
Infant mortality rate: 64/1,000 (1981)
Life expectancy: 68
Literacy: 81%
Labor force: 1.1 million (1983 est); 44%
agriculture; 34% industry and commerce,
18% services, 4% government; unemploy-
ment rate 25% (1986 est.)
Organized labor: about 5% of labor force
Total area: 430 km2; land area: 430 km2
Comparative area: about two and one-
half times the size of Washington, D. C.
Coastline: about 300 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; marine; moderated by
trade winds; sunny and relatively dry
Terrain: low, flat limestone; extensive
marshes and mangrove swamps
Land use: 2% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 98% other
Environment: 30 islands (8 inhabited);
subject to frequent hurricanes
Special notes: none
Population: 9,052 (1987), average annual
growth rate 2.66
Ethnic division: majority of African
descent
Religion: Anglican, Roman Catholic,
Raptist, Methodist, Church of God,
Seventh-Day Adventist
Language: English (official)
Infant mortality rate: 24.4/1,000
(1981/82)
Literacy: about 99%
Labor force: some subsistence agriculture;
majority engaged in fishing and tourist
industries
Organized labor: St. George''s Industrial
Trade Union (Cockburn Harbour), 250
members','57acec66375b29a2b1b677c81cb9aab10e7044c4745bd1db75a88ae5b12a25c3','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6ff673e60031b3e8fcfd4912cec2d6c027f36986cedce6079fb01a28b1d153a',1981,'JE','Jersey','geography',324,'Total area: 117 km2; land area: 117 km2
Comparative area: slightly more than half
the size of Washington, D.C.
Coastline: 70 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: temperate; mild winters and cool
summers
Terrain: gently rolling plain with low
rugged hills along north coast
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
about 58% of land under cultivation
Environment: about 30% of population
concentrated in Saint Helier
Special notes: largest and southernmost of
Channel Islands; 27 km from France
Population: 80,511 (July 1987), average
annual growth rate 0.91%
Nationality: noun — Channel Islanders);
adjective — Channel Islander
Ethnic divisions: UK and Norman-French
descent
Religion: Anglican, Roman Catholic,
Baptist, Congregational New Church,
Methodist, Presbyterian
Language: English and French (official),
with the Norman-French dialect spoken in
country districts
Literacy: probably high
Land boundaries: 435 km total
Climate: varies from tropical to near
temperate
Terrain: mostly mountains and hills; some
moderately sloping plains
Land use: 8% arable land; NEGL% per-
manent crops; 67% meadows and pastures;
6% forest and woodland; 19% other; in-
cludes 2% irrigated
Environment: overgrazing; soil degrada-
tion; soil erosion
Special notes: landlocked; almost an
enclave of South Africa
Population: 715,160 (July 1987), average
annual growth rate 2.75%
Nationality: noun — Swazi(s); adjective —
Swazi
Ethnic divisions: 96% African, 3% Euro-
pean, 1% mulatto
Religion: 57% Christian, 43% indigenous
beliefs
Language: English and siSwati (official);
government business conducted in English
Infant mortality rate: 156/1,000(1982)
Life expectancy: men 46.8, women 50.0
232
Literacy: 65%
Labor force: 195,000; over 60,000 engaged
in subsistence agriculture; 55,000-60,000
wage earners, many only intermittently,
with 36% agriculture and forestry, 20%
community and social services, 14% manu-
facturing, 9% construction, 21% other;
12,000 employed in South Africa (1982)
Organized labor: about 15% of wage
earners are unionized','d2b5776cbd132b2264a7a8f07894e34e340d03d7da635df30b856e9172d40c02','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feb06567d805b6989c4a9ad14c181523923aee24aaa5d50c9ceebc5cea9838e6',1981,'JO','Jordan','geography',329,'Total area: 97,740 km2; land area: 97,180
km2
Comparative area: about the size of
Minnesota
Land boundaries: 1,770 km total (before
1967 war)
Coastline: 26 km
Maritime claim:
Territorial sea: 3 nm
Boundary disputes: separated from Israel
by 1949 Armistice Line; West Bank and
Gaza Strip are Israeli occupied with status
to be determined
Climate: mostly arid desert; rainy season
in west (November to March)
Terrain: mostly high desert plateau in east;
Great Rift Valley separates East and West
Banks of Jordan River
Land use: 4% arable land; .5% permanent
crops; 1% meadows and pastures; .5%
forest and woodland; 94% other; includes
.5% irrigated
Environment: lack of natural water re-
sources; deforestation; overgrazing; soil
erosion; desertification
Special notes: none','a7f063fed366ec29538100dfc96c887eb3ebc1c63e2070603a44b63e44a04c3b','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16c4233c48ad44db3a911de274b13e7af6bcf6e2793629cab7c8af443c0034f1',1981,'KE','Kenya','geography',335,'Total area: 582,650 km2; land area:
569,250 km2
Comparative area: slightly smaller than
Texas
Land boundaries: 3,368 km total
Coastline: 536 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; international
boundary and Administrative Boundary
with Sudan; possible claim by Somalia
based on unification of ethnic Somalis
Climate: varies from tropical along coast
to arid in interior
Terrain: low plains rise to central high-
lands bisected by Great Rift Valley; fertile
plateau in west
Land use: 3% arable land; 1% permanent
crops; 7% meadows and pastures; 4% forest
and woodland; 85% other; includes
NEGL% irrigated
Environment: unique physiography sup-
ports abundant and varied wildlife of
immense scientific and economic value;
deforestation; soil erosion; desertification
Special notes: none
Population: 22,377,802 (July 1987), aver-
age annual growth rate 4.22%
130
Nationality: noun— Kenyan(s); adjective-
Kenyan
Ethnic divisions: 21% Kikuyu, 14%
Luhya, 13% Luo, 11% Kalenjin, 11%
Kamba, 6% Kisii, 6% Meru, 1% Asian,
European, and Arab
Religion: 38% Protestant, 28% Catholic,
26% indigenous beliefs, 6% Muslim
Language: English and Swahili (official);
numerous indigenous languages
Infant mortality rate: 59/1,000 (1985)
Life expectancy: men 53, women 58. 1
Literacy: 47%
Labor force: 7.4 million; about 1.1 million
wage earners; 50% public sector, 18%
industry and commerce, 17% agriculture,
13% services
Organized labor: about 390,000
Total area: 360 km2; land area: 360 km2
Comparative area: about twice the size of
Washington, D. C.
Coastline: 135 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: subtropical tempered by constant
sea breezes; little seasonal temperature
variation; one rainy season (May to No-
vember)
Terrain: volcanic with mountainous
interiors
Land use: 22% arable land; 17% perma-
nent crops; 3% meadows and pastures;
17% forest and woodland; 41% other
Environment: lies within Caribbean hurri-
cane belt
Special notes: none
Population: 54,775 (July 1987), average
annual growth rate 2.96%
Ethnic divisions: mainly of black African
descent
Nationality: noun — Kittsian(s), Nevisian(s);
adjective — Kittsian, Nevisian
Religion: Anglican, other Protestant sects,
Roman Catholic
Language: English
Literacy:
207
St. Christopher
and Nevis (continued)
St. Helena
Labor force: 20,000 (1981)
Organized labor: 6,700
Total area: 310 km2; land area: 310 km2
Comparative area: almost twice the size
of Washington, D. C.
Coastline: 60 km
_
Maritime claims:
Territorial sea: 3 nm
Climate: tropical; marine; mild, tempered
by trade winds
Terrain: rugged, volcanic; small scattered
plateaus and plains
Land use: 7% arable land; 0% permanent
crops; 7% meadows and pastures; 3% forest
and woodland; 83% other
Environment: very few perennial streams
Special notes: Ascension is major relay
station for cables running between Europe
and South Africa
Total area: 620 km2; land area: 610 km2
Comparative area: about one-fifth the size
of Rhode Island
Coastline: 158 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 3 nm
Climate: tropical marine, moderated by
northeast trade winds; dry season from
January to April, rainy season from May to
August
Terrain: mostly mountainous with some
broad, fertile valleys
Land use: 8% arable land; 20% permanent
crops; 5% meadows and pastures; 13%
forest and woodland; 54% other; includes
2% irrigated
Environment: subject to hurricanes and
mild volcanic activity; deforestation; soil
erosion
Special notes: none
Population: 152,305 (July 1987), average
annual growth rate 3.65%
Nationality: noun — St. Lucian(s); adjec-
tive— St. Lucian
Ethnic divisions: 90.3% African descent,
5.5% mixed, 3.2% East Indian, 0.8% Cau-
casian
Religion: 90% Roman Catholic, 7% Protes-
tant, 3% Church of England
209
St. Lucia (continued)
St. Vincent and
the Grenadines
Language: English (official), French patois
Infant mortality rate: 27.4/1,000 (1984)
Life expectancy: men 68.3, women 72.4
Literacy: 78%
Labor force: 43,800 (1983 est); 43.4%
agriculture, 38.9% services, 17.7% industry
and commerce; 30% unemployment (1984)
Organized labor: 20% of labor force
Total area: 340 km2; land area: 340 km2
Comparative area: about twice the size of
Washington, D. C.
Coastline: 84 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 3 nm
Climate: tropical; little seasonal tempera-
ture variation; one rainy season (May to
November)
Terrain: volcanic, mountainous
Land use: 38% arable land; 12% perma-
nent crops; 6% meadows and pastures;
41% forest and woodland; 3% other; in-
cludes 3% irrigated
Environment: subject to hurricanes;
Soufriere volcano a constant threat
Special notes: islands of the Grenadines
group are divided politically with Grenada','3c1e01b4c6a797d524cc12ae98e575d82ce42d0e7e39fe319e5e64a546a30412','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30c7b829648545343a287bc56e54fef53f2c48880f2444cc107925067118bdce',1981,'KI','Kiribati','geography',337,'Total area: 710 km2; land area: 710 km2
Comparative area: about four times the
size of Washington, D. C.
Coastline: 1,143 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; marine, hot and humid,
moderated by trade winds
Terrain: mostly low lying coral atolls
surrounded by extensive reefs
Land use: 0% arable land; 51% permanent
crops; 0% meadows and pastures; 3% forest
and woodland; 46% other
Environment: typhoons can occur any
time, but usually November to March
Special notes: Banaba or Ocean Island is
one of three great phosphate rock islands
in the Pacific (others are Makatea in
French Polynesia and Nauru)
Total area: 120,540 km2; land area:
120,410 km2
Comparative area: slightly smaller than
Mississippi
Land boundaries: 1,675 km total
Coastline: 2,495 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Military boundary line: 50 nm (all
foreign vessels and aircraft are banned
without permission)
Boundary disputes: short section with
China is indefinite; Demarcation Line with
South Korea
Climate: temperate with rainfall concen-
trated in summer
Terrain: mostly hills and mountains sepa-
rated by deep, narrow valleys; coastal
plains wide in west, discontinuous in east
Land use: 18% arable land; 1% permanent
crops; NEGL% meadows and pastures;
74% forest and woodland; 7% other; in-
cludes 9% irrigated
Environment: mountainous interior is
isolated, nearly inaccessible, and sparsely
populated; late spring droughts often
followed by severe flooding
Special notes: occupies northern half of
Korean peninsula; strategic location bor-
dering China, South Korea, and USSR
Total area: 98,480 km2; land area: 98,190
km2
Comparative area: slightly larger than
Indiana
Land boundary: 241 km with North
Korea
Coastline: 2,413 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 12 nm (3 nm in the
Korea Strait)
Boundary disputes: Demarcation Line
with North Korea; Liancourt Rocks dis-
puted with Japan
Climate: temperate; cold, dry, clear win-
ters with hot and humid summers
Terrain: mostly rugged and mountainous
Land use: 21% arable land; 1% permanent
crops; 1% meadows and pastures; 67%
forest and woodland; 10% other; includes
12% irrigated
Environment: occasional typhoons bring
high winds, floods, landslides; water pollu-
tion; air pollution
Special notes: strategic location along
Korea Strait and between Chinese, Japa-
nese, and Soviet spheres of influence
Population: 41,986,669 (July 1987), aver-
age annual growth rate 1.53%
Nationality: noun — Korean(s); adjective —
Korean
Ethnic divisions: homogeneous; small
Chinese minority (about 20,000)
Religion: strong Confucian tradition;
vigorous Christian minority (28% of the
total population); Buddhism; pervasive folk
religion (Shamanism); Chondokyo (religion
of the heavenly way), eclectic religion with
nationalist overtones founded in 19th
century, claims about 1.5 million adher-
ents
Language: Korean; English widely taught
in high school
Infant mortality rate: 29/1,000 (1983)
Life expectancy: men 64, women 71
Literacy: over 90%
Labor force: 15.9 million; 47% services
and other; 30% agriculture, fishing, for-
estry; 21% mining and manufacturing;
average unemployment 4.0% (1986 est.)
Organized labor: about 10% of nonagri-
cultural labor force in government-
sanctioned unions','983ed1f22bc388f1456e7874059a40119807a2b26ca166dedb51642fb823985d','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03b20966d8a8f7a2ef46aa72d059fec5a86c90db9ab3396e4cf327fe89d975ab',1981,'KW','Kuwait','geography',341,'Total area: 17,820 km2; land area: 17,820
km2
Comparative area: slightly smaller than
New Jersey
Land boundaries: 490 km total
Coastline: 499 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 12 nm
Boundary disputes: none; ownership of
Warbah and Bubiydn islands disputed by','8462fc37f45186ce243107248c40b7253ebde0d93754ff9b595d6f2ce05453c8','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f19e85e8c532ae918462e7411a6949222dc5c4448b9830819f0e66696a275068',1981,'LB','Lebanon','geography',344,'Total area: 10,400 km2; land area: 10,230
km2
Comparative area: smaller than Connecti-
cut
Land boundaries: 531 km total
Coastline: 225 km
Maritime claim:
Territorial sea: 12 nm
Boundary disputes: separated from Israel
by 1949 Armistice Line; Israeli troops in
southern Lebanon since June 1982
Climate: Mediterranean; mild to cool, wet
winters with hot, dry summers
Terrain: narrow coastal plain; Al Biqa''
(Bekaa Valley) separates Lebanon and
Anti-Lebanon Mountains
Land use: 21% arable land; 9% permanent
crops; 1% meadows and pastures; 8% forest
and woodland; 61% other; includes 8%
irrigated
Environment: rugged terrain has histori-
cally helped isolate, protect, and develop
numerous factional groups based on reli-
gion, clan, ethnicity; deforestation; soil
erosion; air and water pollution; desertifi-
cation
Special notes: Nahr al Litani only river in
Near East not crossing an international
boundary
138','1a29d0c3235d35e9693a0215369810e67929a92b3f04517dca2b1422e0eadb54','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26a7c551a6e99da2efe2b94cb53731b5e18ce22d709ad642a5a9b45fe2977162',1981,'LS','Lesotho','geography',350,'Total area: 30,350 km2; land area: 30,350
km2
Comparative area: slightly larger than
Maryland
Land boundary: 805 km with South
Africa
Climate: temperate; cool to cold, dry
winters; hot, wet summers
Terrain: mostly highland with some pla-
teaus, hills, and mountains
Land use: 10% arable land; 0% permanent
crops; 66% meadows and pastures; 0%
forest and woodland; 24% other
Environment: population pressure forcing
settlement in marginal areas resulting in
overgrazing, severe soil erosion, soil ex-
haustion; desertification
Special notes: landlocked; enclave of','05d8614c527b104c5f81a3eb6c5d88f64a921200bed6447c5a9e5af98dfbf23d','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dca3c7cd8a976c6568c43a9974e795b947d2c4bc14cc0d2f5eedddaf4b0f166',1981,'LR','Liberia','geography',355,'Total area: 111,370 km2; land area: 96,320
km2
Comparative area: slightly smaller than
Pennsylvania
Land boundaries: 1,336 km total
Coastline: 579 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters
with hot days and cool to cold nights; wet,
cloudy summers with frequent heavy
showers
Terrain: mostly flat to rolling coastal plains
rising to rolling plateau and low mountains
in northeast
Land use: 1% arable land; 3% permanent
crops; 2% meadows and pastures; 39%
forest and woodland; 55% other; includes
NEGL% irrigated
Environment: West Africa''s largest tropi-
cal rainforest subject to deforestation
Special notes: none
Population: 2,384,189 (July 1987), average
annual growth rate 3.27%
Nationality: noun — Liberian(s); adjec-
tive— Liberian
Ethnic divisions: 95% indigenous African
tribes, including Kpelle, Bassa, Gio, Km,
Grebo, Mano, Krahn, Gola, Gbandi, Loma,
Kissi, Vai, and Bella; 5% descendants of
repatriated slaves known as Americo-
Liberians
Religion: 70% traditional, 20% Muslim,
10% Christian
Language: English (official); more than 20
local languages of the Niger-Congo lan-
guage group; English used by about 20%
Infant mortality rate: 153/1,000 (1984)
Life expectancy: 54
Literacy: 24%
Labor force: 510,000, of which 220,000
are in monetary economy; non-African
foreigners hold about 95% of the top-level
management and engineering jobs; 70.5%
agriculture, 10.8% services, 4.5% industry
and commerce, 14.2% other
Organized labor: 2% of labor force','b7413de4da9294da0bf6069256d112a36cda1a29079d58c11b5e80211f6ffccd','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09375070990193bb00ee8be8e235078e2e8782d1ec1af0f34adb9e4d1c88240c',1981,'LY','Libya','geography',359,'Total area: 1,759,540 km2; land area:
1,759,540 km2
Comparative area: larger than Alaska
Land boundaries: 4,345 km total
Coastline: 1,770 km
Maritime claims:
Territorial sea: 12 nm
Gulf of Sidra closing line: 32° 30'' N
Boundary disputes: none; claims Aozou
Strip in northern Chad; occupies northern
Chad; maritime dispute with Tunisia
Climate: Mediterranean along coast; dry,
extreme desert interior
Terrain: mostly barren, flat to undulating
plains, plateaus, depressions
Land use: 1% arable land; 0% permanent
crops; 8% meadows and pastures; 0% forest
and woodland; 91% other; includes
NEGL% irrigated
Environment: hot, dry, dust-laden ghibli is
a southern wind lasting 1-4 days in spring
and fall; desertification; sparse natural
water resources
Special notes: largest water development
scheme in world being built to bring water
from deep wells under Sahara Desert to
coast
Population: 3,306,825 (July 1987), average
annual growth rate 3.39%
Nationality: noun — Libyan(s); adjective —
Libyan
Ethnic divisions: 97% Berber and Arab;
some Greeks, Maltese, Italians, Egyptians,
Pakistanis, Turks, Indians, and Tunisians
Religion: 97% Sunni Muslim
Language: Arabic; Italian and English
widely understood in major cities
Infant mortality rate: 84/1,000 (1985)
Life expectancy: men 56, women 59
Literacy: 50-60%
Labor force: 1 million, of which about
280,000 are resident foreigners; 31% indus-
try, 27% services, 24% government, 18%
agriculture','fa23255fab9c5bb3e992a59f72d1248aad24aee17f683c8f30befee947553820','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60ddcd14771828ccbc38c28cc5def6215f10b122f61c9078e47275ddb3f07705',1981,'LI','Liechtenstein','geography',364,'Total area: 160 km2; land area: 160 km2
Comparative area: slightly smaller than
Washington, D.C.
Land boundaries: 76 km total
Climate: continental; cold, cloudy winters
with frequent snow or rain; cool to moder-
ately warm, cloudy, humid summers
Terrain: mostly mountainous (Alps) with
Rhine Valley in western third
Land use: 25% arable land; 0% permanent
crops; 38% meadows and pastures; 19%
forest and woodland; 18% other
Environment: variety of microclimatic
variations based on elevation
Special notes: landlocked','4cfcee777a440f39a7fb30c5347d7fa252563a264e06e8baf602c21f0d2b0087','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97d1ad7a9125b95120abb03f33e70e4e4010cfb7f51522b668f1547ab90292ac',1981,'LU','Luxembourg','geography',367,'Total area: 2,586 km2; land area: 2,586
km2
Comparative area: smaller than Rhode
Island
Land boundaries: 356 km total
Climate: modified continental with mild
winters, cool summers
Terrain: mostly gently rolling uplands
with broad shallow valleys; uplands to
slightly mountainous in north
Land use: 24% arable land; 1% permanent
crops; 20% meadows and pastures; 21%
forest and woodland; 34% other
Environment: deforestation
Special notes: landlocked
Population: 366,127 (July 1987), average
annual growth rate 0.03%
Nationality: noun — Luxembourger(s);
adjective — Luxembourg
Ethnic divisions: Celtic base, with French
and German blend; also guest and worker
residents from Portugal, Italy, and Euro-
pean countries
Religion: 97% Roman Catholic, 3% Protes-
tant and Jewish
Language: Luxembourgish, German,
French; many also speak English
Infant mortality rate: 12/1,000 (1984)
Life expectancy: men 70, women 76.7
Literacy: 100%
Labor force: (1984) 161,000; one-third of
labor force is foreign, comprising mostly
workers from Portugal, Italy, France,
Belgium, and FRG; 48.9% services, 24.7%
industry, 13.2% government, 8.8% con-
struction, 4.4% agriculture; unemployment
1.5% (1985 average)
Total area: 20 km2; land area: 20 km2
Comparative area: about one-ninth the
size of Washington, B.C.
Land boundary: 201 meters with China
Coastline: 40 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 6 nm
Boundary disputes: none; will become a
Special Administrative Region of China in
1999
Climate: tropical; marine with cool win-
ters, warm summers
Terrain: generally flat
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: essentially urban; one
causeway and one bridge connect the two
islands to the peninsula on mainland
Special notes: none
Population: 437,822 (July 1987), average
annual growth rate 5.53%
Nationality: noun — Macanese (sing, and
pi.); adjective — Macau
Ethnic divisions: 98% Chinese, 2% Portu-
guese
Religion: mainly Buddhist; 17,000 Catho-
lics, of whom about half are Chinese
Language: 98% Chinese, 2% Portuguese
Infant mortality: 12/1,000 (1985)
Literacy: almost 100% among Portuguese
and Macanese; no data on Chinese popula-
tion','658770083377fd783938f7be64411ae09c4d6ab913378d52dfe26e6f3406878f','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac0d60758b788e261e31c59f99cf0f2ba239033f11766c30c5f7876e82eb1e36',1981,'MG','Madagascar','geography',372,'Total area: 587,040 km2; land area:
581,540 km2
Comparative area: slightly smaller than
Texas
Coastline: 4,828 km
Maritime claims:
Continental shelf: 150 nm
Exclusive fishing zone: 150 nm
Extended economic zone: 150 nm
Territorial sea: 50 nm
Boundary disputes: none; claims French-
administered Bassas da India, Europa
Island, Juan de Nova Island, Glorioso
Islands, Tromelin Island
Climate: tropical along coast, temperate
inland, arid in south
Terrain: narrow coastal plain, high plateau
and mountains in center
Land use: 4% arable land; 1% permanent
crops; 58% meadows and pastures; 26%
forest and woodland; 11% other; includes
1% irrigated
Environment: subject to periodic cyclones;
deforestation; overgrazing; soil erosion;
desertification
Special notes: world''s fourth largest
island; important location along Mozam-
bique Channel
Population: 10,730,754 (July 1987), aver-
age annual growth rate 3.11%
Nationality: noun — Malagasy (sing, and
pi.); adjective — Malagasy
Ethnic divisions: basic split between
highlanders of predominantly Malayo-
Indonesian origin (Merina 1,643,000 and
related Betsileo 760,000) on the one hand
and coastal tribes — collectively termed the
Cotiers, with mixed black,
Malayo-Indonesian, and Arab ancestry
(Betsimisaraka 941,000, Tsimihety 442,000,
Antaisaka 415,000, Sakalava 375,000) on
the other; there are also 11,000 European
French, 5,000 Indians of French national-
ity, and 5,000 Creoles
Religion: 52% indigenous beliefs; about
41% Christian, 7% Muslim
Language: French and Malagasy (official)
Infant mortality rate: 177/1,000 (1984)
Life expectancy: 46
Literacy: 53%
Labor force: about 4.9 million (1985), of
which 90% are nonsalaried family workers
engaged in subsistence agriculture; of
175,000 wage and salary earners, 26%
agriculture, 17% domestic service, 15%
industry, 14% commerce, 11% construc-
tion, 9% services, 6% transportation, 2%
miscellaneous
Organized labor: 4% of labor force','629d49ff5d9dc85640ce7da484d357cc8971177fce844ca07967701e9a08ee87','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99e938f8c3f302b5ab503c3f395527d7524f139427348aad6930d86393210163',1981,'MW','Malawi','geography',375,'Total area: 118,480 km2; land area: 94,080
km2
Comparative area: about the size of
Pennsylvania
Land boundaries: 2,881 km total
Boundary disputes: none; maritime dis-
pute with Tanzania
Climate: tropical; rainy season (November
to May); dry season (May to November)
Terrain: narrow elongated plateau with
rolling plains, rounded hills, some moun-
tains
Land use: 25% arable land; NEGL%
permanent crops; 20% meadows and
pastures; 50% forest and woodland; 5%
other; includes NEGL% irrigated
Environment: deforestation
Special notes: landlocked
Population: 7,437,911 (July 1987), average
annual growth rate 3. 15%
Nationality: noun — Malawian(s); adjec-
tive— Malawian
Ethnic divisions: Chewa, Nyanja, Tum-
buko, Yao, Lomwe, Sena, Tonga, Ngoni,
Asian, European
Religion: 55% Protestant, 20% Roman
Catholic, 20% Muslim; traditional indige-
nous beliefs are also practiced by some
members of these groups
Language: English and Chichewa (official);
Tombuka is second African language
Infant mortality rate: 14/1,000 (1983)
Life expectancy: 47
Literacy: 25%
Labor force: 344,052 wage earners em-
ployed in Malawi (1982); 52% agriculture,
16% personal services, 9% manufacturing,
7% construction, 6% commerce, 4% miscel-
laneous services, 6% other permanently
employed
Organized labor: small minority of wage
earners are unionized','a2f321e7874612142e38c57e38b30159e14efc7e78b1068d816d889a0d8aeb37','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca871f8fd073b5ab971487bfcf29e4c2890736e74f6e7d2e4233d4c7830829b2',1981,'MY','Malaysia','geography',379,'Total area: 329,750 km2; land area:
328,550 km2
Comparative area: slightly larger than
New Mexico
Land boundaries: 2,295 km total
Coastline: 4,675 km total (2,068 km Pen-
insular Malaysia, 2,607 km East Malaysia)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; involved in
complex dispute over Spratly Islands with
China, Philippines, Taiwan, Vietnam, and
possibly Brunei
Climate: tropical; annual southwest (April
to October) and northest (October to
February) monsoons
Terrain: coastal plains rising to hills and
mountains
Land use: 3% arable land; 10% permanent
crops; NEGL% meadows and pastures;
63% forest and woodland; 24% other;
includes 1% irrigated
Environment: subject to flooding; air and
water pollution
Special notes: strategic location along
Strait of Malacca; occupies southern half
of Malay Peninsula and northern quarter
of island of Borneo
Population: 16,068,516 (July 1987), aver-
age annual growth rate 2.08%, includes
Peninsular Malaysia— 13,280,754, average
annual growth rate 1.98%; Sabah—
1,281,994, average annual growth rate
3.28%; and Sarawak— 1,505,768, average
annual growth rate 1.88%
Nationality: noun — Malaysian(s); adjec-
tive— Malaysian
Ethnic divisions: 59% Malay and other
indigenous, 32% Chinese, 9% Indian
Religion: Peninsular Malaysia — Malays
nearly all Muslim, Chinese predominantly
Buddhists, Indians predominantly Hindu;
Sabah— 38% Muslim, 17% Christian, 45%
other; Sarawak — 35% tribal religion, 24%
Buddhist and Confucianist, 20% Muslim,
16% Christian, 5% other
Language: Peninsular Malaysia — Malay
(official); English, Chinese dialects, Tamil;
Sabah— English, Malay, numerous tribal
dialects, Mandarin and Hakka dialects
predominate among Chinese; Sarawak —
English, Malay, Mandarin, numerous tribal
languages
Infant mortality rate: 25/1,000 (1985)
Life expectancy: 67.7 male, 72.7 female
Literacy: 65.0% overall, age 20 and up;
Peninsular Malaysia— 80%; Sabah— 60%;
Sarawak— 60%
Labor force: 5.95 million (1985); 34.5%
agriculture; trade, hotels, and restaurants;
15.6% manufacturing, 14.9% government;
6.6% construction, 5% finance; 4.9% trans-
port and communications; 1.6% mining;
1.2% utilities
Organized labor: 620,000, about 10% of
total labor force; unemployment about
7.6% of total labor force, but higher in
urban areas (1985)','8184ba8cd2ae7823cf3ab51ea0a86d619631ac8098d08089b78b8cf6fafabba8','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed3f1433739211cfdfb32b4117ebeccbd4029634d858ed966c54a11f0dc99b59',1981,'MV','Maldives','geography',383,'Total area: 300 km2; land area: 300 km2
Comparative area: about twice the size of
Washington D.C.
Coastline: 644 km
Maritime claims:
Exclusive fishing zone: about 100 nm
(defined by geographic coordinates)
Extended economic zone: irregular
polygon varying in breadth from about
35 nm to more than 300 nm
Territorial sea: irregular polygon vary-
ing in breadth from less than 3 nm to
about 55 nm
Climate: tropical; hot, humid; dry, north-
west monsoon (November to March); rainy,
southwest monsoon (June to August)
Terrain: flat with elevations only as high
as 2.5 meters
Land use: 10% arable land; 0% permanent
crops; 3% meadows and pastures; 3% forest
and woodland; 84% other
Environment: 1,200 coral islands grouped
into 19 atolls
Special notes: strategic location astride
and along major sea lanes in Indian Ocean
Population: 195,837 (July 1987), average
annual growth rate 3.65%
Nationality: noun — Maldivian(s); adjec-
tive— Maldivian
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab, and black
Religion: Sunni Muslim
Language: Divehi (dialect of Sinhala;
script derived from Arabic); English spo-
ken by most government officials
Infant mortality rate: 88/1,000 (1984)
Life expectancy: 46.5
Literacy: 36%
Labor force: about 66,000; fishing industry
employs 80% of labor force','44a83ae1b24079b6f69cf3ab670758bfbad8db59fc72cd7ddbb70a5e434bf259','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f0470b633f710a44bc17b9ae445eb6c053cf48c12ecc4bef38c97f40d493ede',1981,'MT','Malta','geography',390,'Total area: 320 km2; land area: 320 km2
Comparative area: about twice the size of
Washington, D.C.
Coastline: 140 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 25 nm
Territorial sea: 12 nm
Climate: Mediterranean with mild, rainy
winters and hot, dry summers
Terrain: mostly low, rocky, flat to dis-
sected plains; many coastal cliffs
Land use: 38% arable land; 3% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 59% other; includes 3%
irrigated
Environment: numerous bays provide
good harbors
Special notes: strategic location in central
Mediterranean, 93 km south of Sicily, 290
km north of Libya
Total area: 588 km2; land area: 588 km2
Comparative area: about three times the
size of Washington, D. C.
Coastline: 113 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: cool summers and mild winters;
humid; overcast about half the time
Terrain: coastal plains in north and south
connected by valley bisecting hilly interior
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
extensive arable land and forests
Environment: strong westerly winds
prevail
Special notes: located in Irish Sea equidis-
tant from England, Scotland, and Ireland
Population: 64,934 (July 1987), average
annual growth rate 0.01%
Nationality: noun — Manxman, adjective —
Manx
Ethnic divisions: native Manx of Norse-
Celtic descent; British
Religion: Anglican, Roman Catholic,
Methodist, Baptist, Presbyterian, Society of
Friends
Language: English, Manx Gaelic
Literacy: compulsory education between
ages of 5 and 15
Labor force: 25,864; manufacturing 3,467,
construction 2,921, transport and commu-
nications 2,300, retail 2,687, professional
and scientific services 3,737 (1981); unem-
ployment 8% (1984)
Organized labor: 22 labor unions pat-
terned along British lines','17052388731e926e2ebbd83880491c0b854171a4484ac93871d099ca44566bc6','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43044faa27f87a2503a860f73fe06d0cbd061d0f11e4011d50bf68d9d1757453',1981,'MQ','Martinique','geography',392,'Total area: 1,100 km2; land area: 1,060
km2
Comparative area: slightly smaller than
Rhode Island
Coastline: 290 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by trade
winds; rainy season (June to October)
Terrain: mountainous with indented
coastline
Land use: 10% arable land; 8% permanent
crops; 30% meadows and pastures; 26%
forest and woodland; 26% other; includes
5% irrigated
Environment: subject to hurricanes,
flooding, and volcanic activity that results
in an average of one major natural disaster
every five years
Special notes: northernmost of Windward
Islands
Population: 344,922 (July 1987), average
annual growth rate 1.84%
Nationality: noun — Martiniquais (sing, and
pi.); adjective — Martiniquais
Ethnic divisions: 90% African and
African-Caucasian-Indian mixture, 5%
Caucasian, less than 5% East Indian,
Lebanese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, Creole patois
Infant mortality rate: 12.6/1,000 (1981)
Life expectancy: 68
Literacy: over 70%
Labor force: 100,000; 31.7% service indus-
try, 29.4% construction and public works,
13.1% agriculture, 7.3% industry, 2.2%
fisheries, 16.3% other; 14% unemployed
Organized labor: 11% of labor force','f4e4594c92d071e6cc8fb0df3113619654bae503f9af07c801bff79869fc4389','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05073f4ce7ac9da08c1dd0f19e15f58d4b75d44bacf78e4a3b5c8fd61e382568',1981,'MR','Mauritania','geography',396,'Total area: 1,030,700 km2; land area:
1,030,400 km2
Comparative area: about the size of
California and Texas combined
Land boundaries: 5,118 km total
Coastline: 754 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 70 nm
Boundary disputes: none; Western Sahara
question with Morocco
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of
Sahara Desert; some central hills
Land use: NEGL% arable land; NEGL%
permanent crops; 38% meadows and
pastures; 15% forest and woodland; 47%
other; includes NEGL% irrigated
Environment: hot, dry, dust/sand-laden
sirocco wind blows primarily in March
and April; desertification; only perennial
river is the Senegal
Special notes: none
Population: 1,863,208 (July 1987), average
annual growth rate 2.91%
Nationality: noun — Mauritanian(s); adjec-
tive— Mauritanian
Ethnic divisions: 40% mixed Moor /black;
30% Moor, 30% black
Religion: nearly 100% Muslim
Language: Hasaniya Arabic (national);
French (official); Toucouleur, Fula,
Sarakole, Wolof
Infant mortality rate: 136/1,000 (1983)
Life expectancy: men 44, women 47
Literacy: 17%
Labor force: total labor force 465,000
(1981 est); about 45,000 wage earners
(1980 IMF); 47% agriculture, 29% services,
14% industry and commerce, 10% govern-
ment; considerable unemployment
Organized labor: 30,000 members claimed
by single union, Mauritanian Workers''
Union
Govern rnent
Official name: Islamic Republic of Mauri-
tania
Type: republic; military first seized power
in bloodless coup 10 July 1978; a palace
coup that took place on 12 December
1984 brought the President to power
Capital: Nouakchott
Administrative divisions: 12 regions and a
capital district
Legal system: based on Islamic law; mili-
tary constitution April 1979
National holiday: Independence Day, 28
November
Branches: executive, Military Committee
for National Salvation rules by decree;
National Assembly and judiciary sus-
pended pending restoration of civilian rule
Government leader: Col. Maaouiya Ould
Sid Ahmed Ould TAYA, President and
Prime Minister (since December 1984)
Suffrage: universal for adults
Elections: municipal elections conducted
December 1986; last presidential election
August 1976
Political parties and leaders: suspended
Communists: no Communist Party, but
there is a scattering of Maoist sympathizers
159
Mauritania (continued)','c132a9080e4877abfd9295f6cbabd73d64c25adab6942dd07f05fa8b4cf8e737','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c720d6acab5de23acc8a5c0ba58c8806e181c127cbbf472cb9a13ddddffe0f79',1981,'MU','Mauritius','geography',397,'Member of: AfDB, AIOEC, Arab League,
CEAO, CIPEC (associate), EAMA, EIB
(associate), FAO, G-77, GATT, IBRD,
ICAO, IDA, IDE— Islamic Development
Bank, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, ITU,
NAM, OAU, QIC, OMVS (Organization
for the Development of the Senegal River
Valley), UN, UNESCO, UPU, WHO,
WIPO, WMO
Total area: 1,860 km2; land area: 1,850
km2
Comparative area: smaller than Rhode
Island
Coastline: 177 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claims island of
Diego Garcia in UK-administered British
Indian Ocean Territory; claims French-
administered Tromelin Island
Climate: tropical modified by southeast
trade winds; warm, dry winter (May to
November); hot, wet, humid summer
(November to May)
Terrain: small coastal plain rising to dis-
continuous mountains encircling central
plateau
Land use: 54% arable land; 4% permanent
crops; 4% meadows and pastures; 31%
forest and woodland; 7% other; includes
9% irrigated
Environment: subject to cyclones (Novem-
ber to April); almost completely sur-
rounded by reefs
Special notes: none
Population: 1,079,627 (July 1987), average
annual growth rate 1.87%
160
Nationality: noun — Mauritian(s); adjec-
tive— Mauritian
Ethnic divisions: 68% Indo-Mauritian,
27% Creole, 3% Sino-Mauritian, 2%
Franco-Mauritian
Religion: 51% Hindu, 30% Christian
(mostly Roman Catholic with a few Angli-
cans), 17% Muslim
Language: English (official), Creole,
French, Hindi, Urdu, Hakka, Bojpoori
Infant mortality rate: 28/1,000 (1985)
Life expectancy: 67
Literacy: 79%
Labor force: 335,000; 29% government
services, 27% agriculture and fishing, 22%
manufacturing, 22% other; about 15-20%
unemployed
Organized labor: about 35% of labor
force, forming over 270 unions','78ff89876b6e6aec91a07ab14c05f4f03e92a66d7866739a1280e428531d4b54','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40a923b902298c188747a362dd3fc0e168af783467ca572f529e83549d524915',1981,'YT','Mayotte','geography',402,'Total area: 375 km2; land area: 375 km2
Comparative area: about twice the size of
Washington, D.C.
Coastline: 165 km (excluding islets)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claimed by','7605fa73cd98257077bb8696d4bde221ba0cc926d1753df01035f740d6e9fad5','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('739dc6a7a850dfe4f03c5772c7207e8186020ae56f5d03d4d09c663ea2b39f81',1981,'MX','Mexico','geography',405,'Total area: 1,972,550 km2; land area:
1,923,040 km2
Comparative area: about three times the
size of Texas
Land boundaries: 4,220 km total
Coastline: 9,330 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 2 nm
Climate: varies from tropical to desert
Terrain: mostly high, rugged mountains
with low coastal plains and high plateaus
Land use: 12% arable land; 1% permanent
crops; 39% meadows and pastures; 24%
forest and woodland; 24% other; includes
3% irrigated
Environment: subject to destructive earth-
quakes in center and south; natural water
resources scarce in north, inaccessible and
poor quality in center and extreme south-
east; deforestation; soil erosion widespread;
desertification
Special notes: strategic location on south-
ern border of US
Population: 81,860,566 (July 1987), aver-
age annual growth rate 2.09%
Nationality: noun — Mexican(s); adjective-
Mexican
Ethnic divisions: 60% mestizo (Indian-
Spanish), 30% Amerindian or predomi-
nantly Amerindian, 9% white or predomi-
nantly white, 1% other
Religion: 97% nominally Roman Catholic,
3% Protestant
Language: Spanish
Infant mortality rate: 51.0/1,000 (1984)
Life expectancy: 65.4
Literacy: 88.1%
Labor force: 26,320,000 (1985); 31.4%
services; 26% agriculture, forestry, hunting,
fishing; 13.9% commerce; 12.8% manufac-
turing; 9.5% construction; 4.8% transporta-
tion; 1.3% mining and quarrying; 0.3%
electricity; 10% unemployed, 40% under-
employed
Organized labor: 35% of total labor force
Land boundaries: 2,579 km total
Coastline: 21,925 km (3,419 km mainland;
2,413 km large islands; 16,093 km long
fjords, numerous small islands, and minor
indentations)
Maritime claims:
Contiguous zone: 10 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 4 nm
Boundary disputes: none; maritime dis-
pute with USSR; territorial claim in Ant-
arctica (Queen Maud Land)
Climate: temperate along coast, modified
by Gulf Stream; colder interior
Terrain: glaciated; mostly high plateaus
and rugged mountains broken by fertile
valleys; small, scattered plains; coastline
deeply indented by fjords; arctic tundra in
north
Land use: 3% arable land; 0% permanent
crops; NEGL% meadows and pastures;
27% forest and woodland; 70% other;
includes NEGL% irrigated
Environment: air and water pollution;
acid rain
186
Special notes: strategic location adjacent
to sea lanes and air routes in North Atlan-
tic; one of most rugged and longest coast-
lines in world; Norway and Turkey only
NATO members having a boundary with
the USSR
Population: 4,178,545 (July 1987), average
annual growth rate 0.30%
Nationality: noun — Norwegian(s); adjec-
tive— Norwegian
Ethnic divisions: Germanic (Nordic,
Alpine, Baltic) and racial-cultural minority
of 20,000 Lapps
Religion: 94% Evangelical Lutheran (state
church), 4% other Protestant and Roman
Catholic, 2% other
Language: Norwegian (official); small
Lapp- and Finnish-speaking minorities
Infant mortality rate: 7.9/1,000 (1983)
Life expectancy: men 72.7, women 79.5
Literacy: 100%
Labor force: 2.064 million (1985); 30.9%
services; 19.6% mining and manufacturing;
16.7% commerce; 8.8% transportation;
7.6% construction; 7.2% agriculture, for-
estry, fishing; 5.7% banking and financial
services (1983); 2.3% unemployed (1985)
Organized labor: 66% of labor force
(1985)
Land boundaries: 1,384 km total
Coastline: 2,092 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Administrative Line
with PDRY; no defined boundary with
most of UAE, Administrative Line in far
north; no defined boundary with Saudi
Arabia
Climate: dry desert; hot, humid along
coast; hot, dry interior; strong southwest
summer monsoon (May to September) in
far south
Terrain: vast central desert plain, rugged
mountains in north and south
Land use: NEGL% arable land; NEGL%
permanent crops; 5% meadows and pas-
tures; 0% forest and woodland; 95% other;
includes NEGL% irrigated
Environment: summer winds often raise
large sandstorms and duststorms in inte-
rior; sparse natural fresh water resources
Special notes: strategic location with small
foothold on Musandam Peninsula control-
ling Strait of Hormuz (17% of world''s
daily oil production transits this point
going from Persian Gulf to Arabian Sea)
Population: 1,226,923 (July 1987), average
annual growth rate 3.10%
Nationality: noun — Omani(s); adjective —
Omani
Ethnic divisions: almost entirely Arab,
with small Baluchi, Zanzibar!, and Indian
groups
Religion: 75% Ibadhi Muslim; remainder
Sunni Muslim, Shi''a Muslim, some Hindu
Language: Arabic (official); English,
Baluchi, Urdu, Indian dialects
Infant mortality rate: 121/1,000 (1983)
Life expectancy: men 51, women 54
Literacy: 20%
Labor force: 430,000; 58% are
non-Omani; est. 60% agriculture
Land boundaries: 3,090 km total
Coastline: 491 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Climate: temperate with cold, cloudy,
moderately severe winters with frequent
precipitation; mild summers with frequent
showers and thundershowers
Terrain: mostly flat plain, mountains along
southern border
Land use: 48% arable land; 1% permanent
crops; 13% meadows and pastures; 29%
forest and woodland; 9% other; includes
NEGL% irrigated
Environment: plain crossed by a few
north-flowing, meandering streams
Special notes: historic area on North
European Plain for conflict because of flat
terrain and lack of natural barriers
Population: 37,726,699 (July 1987), aver-
age annual growth rate 0.67%
Nationality: noun — Pole(s); adjective —
Polish
Ethnic divisions: 98.7% Polish, 0.6%
Ukrainian, 0.5% Byelorussian, less than
0.05% Jewish
Religion: 95% Roman Catholic (about 75%
practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Infant mortality rate: 19.3/1,000 (1984)
Life expectancy: 71.6
Literacy: 98%
Labor force: 17.54 million; 44% industry
and commerce, 30% agriculture, 11%
services, 8% government (1985)
Organized labor: new government trade
unions formed following dissolution of
Solidarity and all government unions in
October 1982
Land boundaries: 4,562 km total
Coastline: 3,444 km (excluding islands)
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Cambodia (three
areas); occupies Cambodia; sporadic border
clashes with China; involved in complex
dispute over Spratly Islands with China,
Malaysia, Philippines, Taiwan, and possi-
bly Brunei; maritime dispute with China;
dispute with China over Paracel Islands
Climate: tropical in south; monsoonal in
north with hot, rainy season (mid-May to
mid-September) and warm, dry season
(mid-October to mid-March)
Terrain: low, flat delta in south and north;
central highlands; hilly, mountainous in far
north and northwest
Land use: 22% arable land; 2% permanent
crops; 1% meadows and pastures; 40%
forest and woodland; 35% other; includes
5% irrigated
Environment: occasional typhoons (May to
January) with extensive flooding
Special notes: none
Population: 63,585,121 (July 1987), aver-
age annual growth rate 2.49%
Nationality: noun — Vietnamese (sing, and
pi.); adjective — Vietnamese
Ethnic divisions: 85-90% predominantly
Vietnamese; 3% Chinese; ethnic minorities
include Muong, Thai, Meo, Khmer, Man,
Cham; other mountain tribes
Religion: Buddhist, Confucian, Taoist,
Roman Catholic, indigenous beliefs, Is-
lamic, Protestant
Language: Vietnamese (official), French,
Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian)
Infant mortality rate: 53/1,000 (1983)
Life expectancy: men 62, women 66
Literacy: 78%
Labor force: 31.20 million, not including','242eaff90d9dddad20695636e34642a98e0c392149972439e966ea32ee29a652','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b14ae09730aa9060619bd4466432e2abd99226c5f8a6d59a472b293f6cfdac9',1981,'MC','Monaco','geography',410,'Total area: 1.9 km2; land area: 1.9 km2
Comparative area: about one-hundredth
the size of Washington, D.C.
Land boundary: 3.7 km with France
Coastline: 4.1 km
Maritime claim:
Territorial sea: 12 nm
Climate: Mediterranean with mild, wet
winters and hot, dry summers
Terrain: hilly, rugged, rocky
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: almost entirely urban
Special notes: second smallest indepen-
dent state in world (after Vatican City)
.','57578ed7c7c8ced168026fce2b32bacf46152ca9a5d1242c67c1d189562544b9','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea172d93aad9c55fe5ff682d74421f3b30b82619c38c75e590fd9befd00c35a3',1981,'MS','Montserrat','geography',415,'Total area: 100 km2; land area: 100 km2
Comparative area: about one-half the size
of Washington, B.C.
Coastline: 40 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; little daily or seasonal
temperature variation
Terrain: volcanic islands, mostly moun-
tainous, with small coastal lowland
Land use: 20% arable land; 0% permanent
crops; 10% meadows and pastures; 40%
forest and woodland; 30% other
Environment: subject to severe hurricanes
(especially June to December)
Special notes: none','14a2c3e9c3f170c8f2c72ad442fc098b938113c17ba1d940adbccc2c43095dbc','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b789509abe0f28ee8a8407c222890f1d0f1746adcd7226e70587e7e9baba0c3',1981,'MA','Morocco','geography',420,'Total area: 446,550 km2; land area:
446,300 km2
Comparative area: about the same size as
California
Land boundaries: 1,996 km total
Coastline: 1,835 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claims and
administers Western Sahara, but sover-
eignty is unresolved; Western Sahara
question with Mauritania; Spain controls
two coastal presidios or places of sover-
eignty (Ceuta, Melilla)
Climate: Mediterranean, becoming more
extreme in the interior
Terrain: mostly mountains with rich
coastal plains
Land use: 18% arable land; 1% permanent
crops; 28% meadows and pastures; 12%
forest and woodland; 41% other; includes
1% irrigated
Environment: northern mountains geologi-
cally unstable and subject to earthquakes;
desertification
Special notes: strategic location along
Strait of Gibraltar
Population: 23,361,495 (July 1987), aver-
age annual growth rate 2.49%
Nationality: noun — Moroccan(s); adjec-
tive— Moroccan
Ethnic divisions: 99.1% Arab- Berber,
0.7% non-Moroccan, 0.2% Jewish
Religion: 98.7% Muslim, 1.1% Christian,
0.2% Jewish
Language: Arabic (official); several Berber
dialects; French is language of business,
government, diplomacy, and postprimary
education
Infant mortality rate: 117/1,000 (1978)
Life expectancy: 54
Literacy:
Labor force: 7.5 million (1985); 50%
agriculture, 26% services, 15% industry,
9% other; at least 20% of urban labor
unemployed
Organized labor: about 5% of the labor
force, mainly in the Union of Moroccan
Workers (UMT) and the Democratic
Confederation of Labor (CDT)','021b0ff8200e81412aff4c9e18ffef1ef10c50a8d8257f9414ff20e6896830b3','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7a34d5ab36700172b5df9e183be96562aba0baa6bd11fe12897b592eb2a7638',1981,'MZ','Mozambique','geography',425,'Total area: 801,590 km2; land area:
784,090 km2
Comparative area: about the size of Texas
Land boundaries: 4,627 km total
Coastline: 2,470 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands
in center, high plateaus in northwest,
mountains in west
Land use: 4% arable land; NEGL% per-
manent crops; 56% meadows and pastures;
20% forest and woodland; 20% other;
includes NEGL% irrigated
Environment: severe drought and floods
occur in south; desertification
Special notes: none
Population: 14,535,805 (July 1987), aver-
age annual growth rate 2.64%
Nationality: noun — Mozambican(s); adjec-
tive— Mozambican
Ethnic divisions: majority from indige-
nous tribal groups; about 10,000 Europe-
ans, 35,000 Euro-Africans, 15,000 Indians
Religion: 60% indigenous beliefs, 30%
Christian, 10% Muslim
Language: Portuguese (official); many
indigenous dialects
169
Mozambique (continued)
Infant mortality rate: 109/1,000 (1983)
Life expectancy: men 44, women 47
Literacy: 14%
Labor force: 95% engaged in agriculture','c665787331239eed1f537d6ae357f6b77036a7828b3bbe4baaf52a25ebbd2286','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6334cfeee632c8da39f4a342710460f1e144b08b77d8b2fe2e525de0be73ccc1',1981,'NA','Namibia','geography',428,'Total area: 824,290 km2; land area:
823,290 km2
Comparative area: about twice the size of
California
Land boundaries: 3,798 km total
Coastline: 1,489 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 6 nm
Boundary disputes: short section with
Botswana is indefinite; occupied by South
Africa
Climate: desert; hot, dry; rainfall sparse
and erratic
Terrain: mostly high plateau; Namib
Desert along coast; Kalahari Desert in east
Land use: 1% arable land; NEGL% per-
manent crops; 64% meadows and pastures;
22% forest and woodland; 13% other;
includes NEGL% irrigated
Environment: inhospitable with very
limited natural water resources; desertifi-
cation
Special notes: Walvis Bay area of South
Africa is almost an enclave
Population: 1,273,263 (July 1987), average
annual growth rate 3.39%
Nationality: noun — Namibian(s); adjec-
tive— Namibian
Ethnic divisions: 85.6% black, 7.5% white,
6.9% mixed; about half the blacks belong
to Ovambo tribe
Religion: whites predominantly Christian,
nonwhites either Christian or indigenous
beliefs
Language: Afrikaans principal language of
about 60% of white population, German of
33%, and English of 7% (all official); sev-
eral indigenous languages
Literacy: 100% whites, 16% nonwhites
Labor force: about 500,000 (1981); 60%
agriculture, 19% industry and commerce,
8% services, 7% government, 6% mining;
15-17% unemployment
Organized labor: 7 trade unions, whose
membership is almost exclusively white
and mulatto, except new mineworkers
union which has sizable black membership
Climate: mostly dry desert, subtropical
along coast; sunny days, cool nights
Terrain: vast interior plateau rimmed by
rugged hills and narrow coastal plain
Land use: 10% arable land; 1% permanent
crops; 65% meadows and pastures; 3%
forest and woodland; 21% other; includes
1% irrigated
Environment: lack of important arterial
rivers or lakes requires extensive water
conservation and control measures
Special notes: Walvis Bay is almost an
enclave of Namibia; Lesotho is an enclave
Population: 34,313,356 (July 1987), aver-
age annual growth rate 2.27%, includes the
four nominally independent homelands
that are not recognized by the US (Bophu-
thatswana 1,750,165, average annual
growth rate 3.85%; Ciskei 982,982, average
annual growth rate 2.62%; Transkei
2,832,345, average annual growth rate
2.70%; Venda 434,395, average annual
growth rate 2.72%)
Nationality: noun — South African(s);
adjective — South African
Ethnic divisions: 69.9% black, 17.8%
white, 9.4% colored, 2.9% Indian
Religion: most whites and coloreds and
roughly 60% of blacks are Christian;
roughly 60% of Indians are Hindu, 20%
Muslim
Language: Afrikaans, English (official);
many vernacular languages, including
Zulu, Xhosa, North and South Sotho,
Tswana
Infant mortality rate: whites 14.9/1,000
(1982), coloreds 80.6/1,000 (1982), blacks
80.6/1,000 (1982), Asians 25.3/1,000 (1982)
Life expectancy: whites 70 years, Asians
66 years, coloreds 59 years, blacks 55 years
Literacy: almost all white population
literate; government estimates 50% of
blacks literate
Labor force: 11 million economically
active (1985); 34% services, 30% agricul-
ture, 29% industry and commerce, 7%
mining
Organized labor: about 17% of total labor
force is unionized (mostly white workers);
African unions represent less than 15% of
black labor force
Total area: 22,402,200 km2; land area:
22,272,000 km2
Comparative area: almost two and one-
half times the size of US
Land boundaries: 20,217 km total
Coastline: 108,346 km (60,085 km main-
land; 48,261 islands)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: China (Pamir, Argun,
Amur, and Khabarovsk areas); US Govern-
ment has not recognized incorporation of
Estonia, Latvia, and Lithuania into Soviet
Union; Habomai Islands, Etorofu, Kunash-
iri, and Shikotan islands occupied by
Soviet Union since 1945, claimed by
Japan; Kuril Islands administered by
Soviet Union; maritime disputes with
Sweden, Norway; has made no territorial
claim in Antarctica (but has reserved the
right to do so) and does not recognize the
claims of any other nation; Bessarabia
question with Romania
Climate: mostly temperate to arctic conti-
nental; winters vary from cool along Black
Sea to frigid in Siberia; summers vary
from hot in southern deserts to cool along
Arctic coast
Terrain: broad plain with low hills west of
Urals; vast coniferous forest and tundra in
Siberia, deserts in Central Asia, mountains
in south
224
Land use: 10% arable land; NEGL%
permanent crops; 17% meadows and
pastures; 41% forest and woodland; 32%
other; includes 1% irrigated
Environment: despite size and diversity,
small percentage of land is arable and
much is too far north; some of most fertile
land is water deficient or has insufficient
growing season; many better climates have
poor soils; hot, dry, desiccating sukhovey
wind affects south; desertification
Special notes: largest country in world,
but unfavorably located in relation to
major sea lanes of world
Population: 284,008,160 (July 1987),
average annual growth rate 0.90%
Nationality: noun — Soviet(s); adjective —
Soviet
Ethnic divisions: 52% Russian, 16% Ukrai-
nian, 32% among over 100 other ethnic
groups, according to 1979 census
Religion: 18% Russian Orthodox; 9%
Muslim; 3% Jewish, Protestant, Georgian
Orthodox, or Roman Catholic; population
is 70% atheist
Language: Russian (official); more than
200 languages and dialects (at least 18 with
more than 1 million speakers); 75% Slavic
group, 8% other Indo-European, 12%
Altaic, 3% Uralian, 2% Caucasian
Infant mortality rate: 27.9/1,000 (1982)
Life expectancy: men 64, women 74
Literacy: 99%
Labor force: civilian 148 million (midyear
1984), 20% agriculture, 80% industry and
other nonagricultural fields; unemployed
not reported; shortage of skilled labor
reported','2ddfe5439198f2798e4f893acd071bd2036d03a09b26debd42a9080dced12387','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46f1024308fc9b7f5804ca89dfd73a82b3b91812e88728ddb73f6116b68a33a0',1981,'NR','Nauru','geography',432,'Total area: 20 km2; land area: 20 km2
Comparative area: about one-ninth the
size of Washington, D.C.
Coastline: 24 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; monsoonal; rainy season
(November to February)
Terrain: sandy beach rises to fertile ring
around raised coral reefs with phosphate
plateau in center
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: only 53 km south of
Equator
Special notes: one of three great phos-
phate rock islands in the Pacific (others are
Banaba or Ocean Island in Kiribati and
Makatea in French Polynesia)','9c2138ae7fe0f8243e91d2ec8ab422e9fe9b223ae6d049a621b57a45ba2bbc18','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83f32f9a751456dc5ebfebca08f556b2a80737a60699b5b1f1dd70abae8e4f78',1981,'NP','Nepal','geography',437,'Total area: 140,800 km2; land area:
136,800 km2
Comparative area: about the size of North
Carolina
Land boundaries: 2,800 km total
Climate: varies from cool summers and
severe winters in north to subtropical
summers and mild winter in south
Terrain: Tarai or flat river plain of the
Ganges in south, central hill region, rugged
Himalayas in north
Land use: 17% arable land; NEGL%
permanent crops; 13% meadows and
pastures; 33% forest and woodland; 37%
other; includes 2% irrigated
Environment: contains eight of world''s ten
highest peaks; deforestation; soil erosion;
water pollution
Special notes: landlocked; strategic loca-
tion between China and India
Population: 17,814,294 (July 1987), aver-
age annual growth rate 2.43%
Nationality: noun — Nepalese (sing, and
pi.); adjective — Nepalese
Ethnic divisions: Newars, Indians, Tibet-
ans, Gurungs, Magars, Tamangs, Bhotias,
Rais, Limbus, Sherpas, as well as many
smaller groups
Religion: only official Hindu kingdom in
world, although no sharp distinction be-
tween many Hindu (about 88%) and Bud-
dhist groups; small groups of Muslims and
Christians
Language: Nepali (official); 20 mutually
unintelligible languages divided into nu-
merous dialects
Infant mortality rate: 143/1,000 (1983)
Life expectancy: men 47, women 45
Literacy: 20%
Labor force: 4.1 million; 93% agriculture,
5% services, 2% industry; great lack of
skilled labor','9041d6ada76ebe11250032f2d144ea0f0848781c6555c2613088d9cae5f493ac','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('daf760fefe8b76f7be09bdcdc8470d4614c0532e2f64a8a36c8e1b060b81b915',1981,'NL','Netherlands','geography',442,'Total area: 37,310 km2; land area: 33,940
km2
Comparative area: about the size of
Massachusetts, Connecticut, and Rhode
Island combined
Land boundaries: 1,022 km total
Coastline: 451 km
Maritime claims:
Contiguous zone: 12 nm
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Climate: temperate; marine; cool summers
and mild winters
Terrain: mostly coastal lowland and re-
claimed land (polders); some hills in south-
east
Land use: 25% arable land; 1% permanent
crops; 34% meadows and pastures; 9%
forest and woodland; 31% other; includes
15% irrigated
Environment: dikes protect 30% of land
area that is below sea level from North Sea
Special notes: located at mouths of three
major European rivers (Rhine, Maas or
Meuse, Schelde)
Population: 14,641,554 (July 1987), aver-
age annual growth rate 0.51%
Nationality: noun — Netherlander(s); adjec-
tive— Netherlands
174
Ethnic divisions: 99% Dutch, 1% Indo-
nesian and other
Religion: 40% Roman Catholic, 31%
Protestant, 24% unaffiliated, 5% none
Language: Dutch
Infant mortality rate: 8/1,000 (1984)
Life expectancy: 76
Literacy: 99%
Labor force: 5.3 million (1984); 50.1%
services, 27.8% manufacturing and con-
struction, 16.1% government, 6.0% agricul-
ture; unemployment rate 14.4% (1985
average)
Organized labor: 29% of labor force
Total area: 960 km2; land area: 960 km2
Comparative area: about one third the
size of Rhode Island
Coastline: 364 km
Maritime claims:
Territorial sea: 12 nm
Climate: tropical; modified by northeast
trade winds
Terrain: generally hilly, volcanic interiors
Land use: 8% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 92% other
Environment: south of Carribean hurri-
cane belt, so rarely threatened
Special notes: none
Population: 182,218 (July 1987), average
annual growth rate 0.28%
Nationality: noun — Netherlands Antil-
lean(s); adjective — Netherlands Antillean
Ethnic divisions: 85% mixed African;
remainder Carib Indian, European, Latin,
and Oriental
Religion: predominantly Roman Catholic;
Protestant, Jewish, Seventh-Day Adventist
Language: Dutch (official); Papiamento, a
Spanish-Portuguese-Dutch-English dialect
predominates; English widely spoken;
Spanish
Literacy: 95%
176
Labor force: 89,000 (1983); 65% govern-
ment, 28% industry and commerce, 1.5%
agriculture; unemployment about 16%
(1984 est.)
Organized labor: 60-70% of labor force','1238252e2ac98a2e06007a910b1ead1b99f9944e4a379c286f6845b708c92061','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b1d45a891d47cd8541fc651bb406893bf80f2a605d736cbf4bf7abf43149b30',1981,'NC','New Caledonia','geography',446,'Total area: 19,060 km2; land area: 18,760
km2
Comparative area: about the size of
Massachusetts
Coastline: 2,254 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; modified by southeast
trade winds; hot, humid
Terrain: coastal plains with interior moun-
tains
Land use: NEGL% arable land; NEGL%
permanent crops; 14% meadows and
pastures; 51% forest and woodland; 35%
other
Environment: typhoons most frequent
from November to March
Special notes: none','da14afcd7ca912f198c7eb501cfcd926cdcb0b5b6f5c46cbf2426be882f9ab01','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9caee3361cf7efc9d7a19bd29657abd012c0baf5d9a9e29d0f67d714d63b5019',1981,'NZ','New Zealand','geography',452,'Total area: 268,680 km2; land area:
268,670 km2
Comparative area: about the size of
Colorado
Coastline: 15,134 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; territorial claim
in Antarctica (Ross Dependency)
Climate: temperate with sharp regional
contrasts
Terrain: predominately mountainous with
some large coastal plains.
Land use: 2% arable land; 0% permanent
crops; 53% meadows and pastures; 38%
forest and woodland; 7% other; includes
1% irrigated
Environment: earthquakes are common,
though usually not severe
Special notes: none','2442a348ed46e5b56b2806307d49201f6d07c004f21e02e6bd05d945dbdc488f','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('916b84802e50a936d7fde564aa345ebdd85b597225a82af49785d44af12a576e',1981,'NI','Nicaragua','geography',457,'Total area: 130,000 km2; land area:
118,750 km2
Comparative area: about the size of Iowa
Land boundaries: 1,220 km total
Coastline: 910 km
Maritime claims:
Continental shelf: 200 meters depth
Territorial sea: 200 nm
Boundary disputes: none; Nicaraguan
interruption of transit in the Rio San Juan
(the international boundary) is an occa-
sional source of friction with Costa Rica;
territorial dispute with Columbia over San
Andres and Providencia Archipelago
Climate: tropical in lowlands, cooler in
highlands
Terrain: extensive coastal plains rising to
interior mountains
Land use: 9% arable land; 1% permanent
crops; 43% meadows and pastures; 35%
forest and woodland; 12% other; including
1% irrigated
Environment: subject to destructive earth-
quakes, volcanoes, and landslides; defores-
tation; soil erosion; water pollution
Special notes: none
Population: 3,319,059 (July 1987), average
annual growth rate 2.50%
Nationality: noun — Nicaraguan(s); adjec-
tive— Nicaraguan
Ethnic divisions: 69% mestizo, 17% white,
9% black, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English- and
Indian-speaking minorities on Atlantic
coast
Infant mortality rate: 84/1,000 (1983)
Life expectancy: men 56, women 60
Literacy: 66%
Labor force: 1,086,000 (1986); 45% ser-
vice, 42% agriculture, 13% industry; 25%
unemployment
Organized labor: 35% of Nicaragua''s labor
force is organized; of the seven confedera-
tions, five are Sandinista or Marxist ori-
ented— the government-sponsored Sandin-
ista Workers'' Central (CST), 115,000
members, including state and municipal
employees; the Association of Campesino
Workers (ATC), 130,000 members; the
General Confederation of Independent
Workers (CGI-I), about 15,000 members;
the Workers Front, about 100 members;
and the Central for Labor Action and
Unity (CAUS), about 3,000 members; the
other two unions are the Nicaraguan
Workers'' Central (CTN), 25,000 members,
and the Confederation of Labor Unifica-
tion (CUS), 50,000 members','e509b43bb4a4466cbf69175c4fa81a4739b2cc8709b250cf29bae5f1cb266d4d','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('394098997bb62a8a46d22e810cd41b45e50b870d72a4f7896358ee8db66dd1e5',1981,'NG','Nigeria','geography',461,'Total area: 923,770 km2; land area:
910,770 km2
Comparative area: more than twice the
size of California
Land boundaries: 4,034 km total
Coastline: 853 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 30 nm
Boundary disputes: none; sporadic border
dispute with Cameroon
Climate: varies — equatorial in south,
tropical in center, arid in north
Terrain: southern lowlands merge into
central hills and plateaus; mountains in
southeast, plains in north
Land use: 31% arable land; 3% permanent
crops; 23% meadows and pastures; 15%
forest and woodland; 28% other; includes
NEGL% irrigated
Environment: recent droughts in north
severely affecting marginal agricultural
activities; desertification; soil degradation
Special notes: none
Population: 108,579,764 (July 1987),
average annual growth rate 2.93%
Nationality: noun- — Nigerian(s); adjec-
tive— Nigerian
Ethnic divisions: more than 250 tribal
groups; Hausa and Fulani of the north,
Yoruba of the southwest, and Ibos of the
southeast comprise 65% of the population;
about 27,000 non-Africans
Religion: 50% Muslim, 40% Christian, 10%
indigenous beliefs
Language: English (official); Hausa,
Yoruba, Ibo, Fulani, and several other
languages also widely used
Infant mortality rate: 113/1,000 (1983)
Life expectancy: men 47, women 50
(1983)
Literacy: 25-30%
Labor force: est. 45-50 million (1984); 54%
agriculture; 19% industry, commerce, and
services; 15% government
Organized labor: 3.52 million wage earn-
ers belong to one of 42 recognized trade
unions, which are under a single national
labor federation, the Nigerian Labor
Congress (NLC)','d9f3852b426d0f7cf64f0ce55dc4cad961d0e15df25fb523a6f846fada8eef08','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e55b377c1d0e167b47310465b1ee71fdccfc7b6b725f6b9a2c5fa4fe5346685',1981,'NU','Niue','geography',466,'Total area: 260 km2; land area: 260 km2
Comparative area: one and one-half times
the size of Washington, D.C.
Coastline: 64 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; modified by southeast
trade winds
Terrain: steep limestone cliffs along coast,
central plateau
Land use: 61% arable land; 4% permanent
crops; 4% meadows and pastures; 19%
forest and woodland; 12% other
Environment: subject to typhoons
Special notes: one of world''s largest coral
islands
Population: 2,602 (July 1987), average
annual growth rate -3.21%
Nationality: noun — Niuean(s); adjective —
Niuean
Ethnic divisions: Polynesian, with some
200 Europeans, Samoans, and Tongans
Religion: 75% Ekalesia Nieue (Niuean
Church) — a Christian Protestant church
closely related to the London Missionary
Society, 10% Morman, 5% Roman Catho-
lic, Jehovah''s Witnesses, Seventh-Day
Adventist
184','108ec6eb91df7cd3f4463f7e9793c0f2531f3ce355ea0bebcd0d06e7e8c8b7f7','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8123be5111b5691ceaa0de1f7feb7d5bb8370a02beeda518d2de0f30ffd056e',1981,'NF','Norfolk Island','geography',467,'Language: Polynesian tongue closely
related to Tongan and Samoan; English
Literacy: education compulsory between 5
and 14 years of age
Labor force: about 1,000 (1981); most
Niueans work on family plantations; paid
work exists only in government service,
small industry, and the Niue Development
Board
Total area: 40 km2; land area: 40 km2
Comparative area: less than one-fourth
the size of Washington, D.C.
Coastline: 32 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: subtropical, mild, little seasonal
temperature variation
Terrain: volcanic formation with mostly
rolling plains
Land use: 0% arable land; 0% permanent
crops; 25% meadows and pastures; 0%
forest and woodland; 75% other
Environment: subject to typhoons (espe-
cially May to July)
Special notes: none','41e46f94d3f6518de98cd36be4f5bbf415642c3a22aea545da3d8abf63980ed4','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc0f7d7b32caa43e797736e452db5408d306d5b8e1b3740381790cfdefce8762',1981,'NO','Norway','geography',476,'Total area: 324,220 km2; land area:
307,860 km2
Comparative area: about the size of New','abbf85491fb1e0874c9aaec362307dc254aa4bb25414a59685a3ab7fb51ce82a','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e25759705cddb6461594ebed99907610d13d4553ab1cdc71f5387b46b6600082',1981,'PK','Pakistan','geography',480,'Total area: 803,940 km2; land area:
778,720 km2
Comparative area: about the size of Texas
Land boundaries: 5,900 km total
Coastline: 1,046 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Cease-Fire Line with
India; Pushtunistan and Baluchistan ques-
tions with Afghanistan
Climate: mostly hot, dry desert; temperate
in northwest; arctic in north
Terrain: flat Indus plain in east; mountains
in north and northwest; Baluchistan Pla-
teau in west
Land use: 26% arable land; NEGL%
permanent crops; 6% meadows and pas-
tures; 4% forest and woodland; 64% other;
includes 19% irrigated
Environment: frequent earthquakes,
occasionally severe especially in north and
west; flooding along the Indus after heavy
rains (July and August); deforestation; soil
erosion; desertification
Special notes: controls Khyber Pass, tradi-
tional invasion route between Afghanistan
and Pakistan
189
Pakistan (continued)
Population: 104,600,799 (July 1987),
average annual growth rate 2.74%
Nationality: noun — Pakistani(s); adjec-
tive— Pakistani
Ethnic divisions: Punjabi, Sindhi, Pushtun
(Pathan), Baluch
Religion: 97% Muslim, 3% Christian,
Hindu, and other
Language: Urdu and English (official);
total spoken languages— 64% Punjabi, 12%
Sindhi, 8% Pushtu, 7% Urdu, 9% Baluchi
and other; English is lingua franca
Infant mortality rate: 119/1,000 (1983)
Life expectancy: men 51, women 49
Literacy: 24%
Labor force: 28.6 million (1985 est);
extensive export of labor; 53% agriculture,
19% industry, 28% services
Organized labor: about 10% of industrial
work force','051dee997b562bf9ccd1e72d0b19b4b7dc7adc4d80c63334b6a01b88156621d5','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd3453417742189fccc0e12eafe7895d6fc34f42d790855fe5ac0466081fbe14',1981,'PA','Panama','geography',483,'Total area: 77,080 km2; land area: 75,990
km2
Comparative area: slightly larger than
West Virginia
Land boundaries: 630 km total
Coastline: 2,490 km
Maritime claim:
Territorial sea: 200 nm
Climate: tropical; hot, humid, cloudy;
prolonged rainy season (May to January),
short dry season (January to May)
Terrain: interior mostly steep, rugged
mountains and dissected, upland plains;
coastal areas largely plains and rolling hills
Land use: 6% arable land; 2% permanent
crops; 15% meadows and pastures; 54%
forest and woodland; 23% other; includes
NEGL% irrigated
Environment: dense tropical forest in east
and northwest
Special notes: strategic location on eastern
end of isthmus forming land bridge con-
necting North and South America; controls
Panama Canal that links Atlantic Ocean
via Caribbean Sea with Pacific Ocean
Population: 2,274,833 (July 1987), average
annual growth rate 2.14%
Nationality: noun — Panamanian(s); adjec-
tive— Panamanian
Ethnic divisions: 70% mestizo, 14% West
Indian, 10% white, 6% Indian
Religion: over 93% Roman Catholic, 6%
Protestant
Language: Spanish (official); 14% speak
English as native tongue; many Pana-
manians bilingual
Infant mortality rate: 20.1/1,000 (1984)
Life expectancy: 71
Literacy: 90%
Labor force: 680,471 (1984 est); 45%
commerce, finance, and services; 29%
agriculture, hunting, and fishing; 10%
manufacturing and mining; 5% construc-
tion; 5% transportation and communica-
tions; 4% Canal Zone; 1.2% utilities; 20%
unemployed (January 1985 est.); shortage
of skilled labor, but an oversupply of
unskilled labor
Organized labor: 17% of labor force
(1986)','96fefb5290bc6efbccd7d9dc0415c20c28d52b98325c40963c83a8b825c6e3b4','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d332a3a12b5ad859c10c897a67ffe7752bb5ae69f986246f69dac2e1078046b',1981,'PG','Papua New Guinea','geography',486,'Total area: 461,690 km2; land area:
451,710 km2
Comparative area: slightly larger than
California
Land boundary: 966 km with Indonesia
Coastline: 5,152 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; northwest monsoon
(December to March), southeast monsoon
(May to October); slight seasonal tempera-
ture variation
Terrain: mostly mountains with coastal
lowlands and rolling foothills
Land use: NEGL% arable land; 1% per-
manent crops; NEGL% meadows and
pastures; 71% forest and woodland; 28%
other
Environment: one of world''s largest
swamps along southwest coast; some active
volcanos; frequent earthquakes
Special notes: none
Population: 3,563,743 (July 1987), average
annual growth rate 2.41%
Nationality: noun — Papua New Guin-
ean(s); adjective — Papua New Guinean
Ethnic divisions: predominantly Mela-
nesian and Papuan; some Negrito, Micro-
nesian, and Polynesian
Religion: over half of population nomi-
nally Christian (490,000 Catholic, 320,000
Lutheran, other Protestant sects); remain-
der indigenous beliefs
Language: 715 indigenous languages;
English spoken by 1-2%, pidgin English
widespread, Motu spoken in Papua region
Infant mortality rate: 102/1,000 (1985)
Life expectancy: 50
Literacy: 32%
Labor force: 1.66 million (1980); 732,806
(1980) in salaried employment; 54% agri-
culture, 25% government, 9% industry and
commerce, 8% services','96f9403ebac3e7b402f5565a53c654f85c43a7bdddf07621a546387b0f0ef7d2','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b3d0295a690b3970cc9470014816b58969cfbfbf811b63525b6156c8e8a4be8',1981,'PE','Peru','geography',492,'Total area: 1,285,220 km2; land area:
1,280,000 km2
Comparative area: about five-sixths the
size of Alaska
Land boundaries: 6,131 km total
Coastline: 2,414 km
Maritime claims:
Continental shelf: 200 nm
Territorial sea: 200 nm
Boundary disputes: Ecuador (two areas)
Climate: varies from tropical in east to
dry desert in west
Terrain: western coastal plain (costa), high
and rugged Andes in center (sierra), east-
ern lowland jungle of Amazon Basin (selva)
Land use: 3% arable land; NEGL% per-
manent crops; 21% meadows and pastures;
55% forest and woodland; 21% other;
includes 1% irrigated
Environment: subject to earthquakes,
tsunamis, landslides, mild volcanic activity;
deforestation; overgrazing; soil erosion;
desertification
Special notes: shares control of Lago
Titicaca, world''s highest navigable lake,
with Bolivia','5af8a9a7db4f25d20f59b472571370caa062ee0eb572e5f0830cad0241e09d59','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e666854151b32c8aed3b3561b76fdffb7ca8f1b0be5ab60effb427c3bc5673f3',1981,'PN','Pitcairn','geography',494,'Total area: 47 km2; land area: 47 km2
Comparative area: about one-fourth the
size of Washington, D.C.
Coastline: 51 km
Maritime claims:
Exclusive fishing zone: 200 nm
Climate: tropical, hot, humid, modified by
southeast trade winds; rainy season (No-
vember to March)
Terrain: rugged volcanic formation; rocky
coastline with cliffs
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other
Environment: subject to typhoons (espe-
cially November to March)
Special notes: none','82868d1ae1dd3f91ee641908ab1974c9f57c1e1a8a885a2177189ce0b1b5c17c','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9e51e32e2a7a53c7218da99a7bdf703112f84487a41bfbfdab6bc1a0d2a259d',1981,'PL','Poland','geography',499,'Total area: 312,680 km2; land area:
304,510 km2
Comparative area: smaller than New','077005d17d4464f57c29985411310f24bfe0ba1402a6259a60fb09b3de689892','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2101f19696198655b1815cabb49db512e0f0650ef261d10506fa98cae58e5c0',1981,'PT','Portugal','geography',503,'Total area: 92,080 km2; land area: 91,640
km2
Comparative area: slightly smaller than
Indiana
Land boundary: 1,207 km with Spain
Coastline: 1,793 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; territory of
Macau will become a Special Administra-
tive Region of China in 1999; East Timor
question with Indonesia
Climate: maritime temperate; cool and
rainy in north, warmer and drier in south
Terrain: mountainous north of Tagus
River, rolling plains in south
Land use: 32% arable land; 6% permanent
crops; 6% meadows and pastures; 40%
forest and woodland; 16% other; includes
7% irrigated
Environment: Azores subject to severe
earthquakes
Special notes: Azores and Madeira Islands
occupy strategic locations along western
sea approaches to Strait of Gibraltar
Population: 10,314,727 (July 1987), aver-
age annual growth rate 0.74%
Nationality: noun — Portuguese (sing, and
pi.); adjective — Portuguese
Ethnic divisions: homogeneous Mediterra-
nean stock in mainland, Azores, Madeira
Islands; citizens of black African descent
who immigrated to mainland during
decolonization number less than 100,000
Religion: 97% Roman Catholic, 1% Protes-
tant sects, 2% other
Language: Portuguese
Infant mortality rate: 19/1,000 (1983)
Life expectancy: 73
Literacy: 83%
Labor force: 4.59 million; 45% services,
34% industry, 21% agriculture; unemploy-
ment, 11.1% (1986 est.)
Organized labor: about 55% of Portuguese
labor is organized; the Communist-
dominated General Confederation of
Portuguese Workers — Intersindical
(CGTP-IN) represents more than half of
theunionized labor force; its main compe-
tition, the General Workers Union (UGT),
is organized by the Socialists and Social
Democrats and represents less than half of
unionized labor','3dbb70db83ef573974693607a09f427de078f50e5af3d70bd86644d511fdf29a','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c8d2beb75278708e566d2d4b4285c8711515ad8d1025cc5452986776fefa01a',1981,'QA','Qatar','geography',505,'Total area: 11,000 km2; land area: 11,000
km2
Comparative area: about the size of
Connecticut
Land boundaries: 56 km total
Coastline: 563 km
Maritime claims:
Continental shelf: not specific
Exclusive fishing zone: as delimited
with neighboring states, or to limit of
shelf, or to median line
Extended economic zone: to median
line
Territorial sea: 3 nm
Boundary disputes: UAE; territorial
dispute with Bahrain over Hawar island
and its ring of islets
Climate: desert; hot, dry; humid and
sultry in summer
Terrain: mostly flat and barren desert
covered with loose sand and gravel
Land use: NEGL% arable land; 0% per-
manent crops; 5% meadows and pastures;
0% forest and woodland; 95% other
Environment: haze, duststorms, sand-
storms common; limited fresh water re-
sources mean increasing dependence on
large-scale desalination facilities
Special notes: strategic location in central
Persian Gulf and close proximity to
region''s important crude oil sources
Total area: 2,510 km2; land area: 2,500
km2
Comparative area: about the size of
Rhode Island
Coastline: 201 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical, but moderates with
elevation; cool and dry from May to
November, hot and rainy from November
to April
Terrain: mostly rugged and mountainous;
fertile lowlands along coast
Land use: 20% arable land; 2% permanent
crops; 4% meadows and pastures; 35%
forest and woodland; 39% other; includes
2% irrigated
Environment: periodic devastating
cyclones
Special notes: none','729a70866031a0c34928eb082e34a164345abb039b2d60776caa6f1333c632b7','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a142070849d9fc3d274003f56960867a81cf99841cd9b40eef5a4daaf0d25cff',1981,'RO','Romania','geography',509,'Total area: 237,500 km2; land area:
230,340 km2
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,969 km total
Coastline: 225 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Transylvania
question with Hungary; Bessarabia ques-
tion with USSR
Climate: temperate; cold, cloudy winters
with frequent snow and fog; sunny sum-
mers with frequent showers and thunder-
storms
Terrain: mostly flat to undulating plains;
some hills and mountains
Land use: 43% arable land; 3% permanent
crops; 19% meadows and pastures; 28%
forest and woodland; 7% other; includes
11% irrigated
Environment: frequent earthquakes most
severe in south and southwest; geologic
structure and climate promote landslides
Special notes: controls most easily travers-
able land route between Balkans and
western USSR
Population: 22,936,503 (July 1987), aver-
age annual growth rate 0.44%
Nationality: noun — Romanian(s); adjec-
tive— Romanian
Ethnic divisions: 89.1% Romanian; 7.8%
Hungarian; 1.5% German; 1.6% Ukrainian,
Serb, Croat, Russian, Turk, and Gypsy
Religion: 80% Romanian Orthodox; 6%
Roman Catholic; 4% Calvinist, Lutheran,
Jewish, Baptist
Language: Romanian, Hungarian, German
Infant mortality rate: 25.6/1,000 (1985)
Life expectancy: men 67.0, women 72.6
Literacy: 98%
Labor force: 10.6 million; 37.1% industry,
28.9% agriculture, 34.0% other nonagri-
cultural (1985)','7fa13d88df70a7bfb94017f811928286ce102a52e0f5099a553849609c487418','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6ec73d6246e545b3ee1b6bf4aa630de2d9b3440e088e70c6de5b033fc8e2482',1981,'RW','Rwanda','geography',514,'Total area: 26,340 km2; land area: 24,950
km2
Comparative area: about the size of
Maryland
Land boundaries: 877 km total
Climate: temperate; two rainy seasons
(February to April, November to January);
mild in mountains with frost and snow
possible
Terrain: mostly grassy uplands and hills;
mountains in west
Land use: 29% arable land; 11% perma-
nent crops; 18% meadows and pastures;
10% forest and woodland; 32% other;
includes NEGL% irrigated
Environment: deforestation; overgrazing;
soil exhaustion; soil erosion; periodic
droughts
Special notes: landlocked
Population: 6,811,336 (July 1987), average
annual growth rate 3.53%
Nationality: noun — Rwandan(s); adjec-
tive— Rwandan
Ethnic divisions: 85% Hutu, 14% Tutsi,
1% Twa (Pygmoid)
Religion: 65% Catholic, 9% Protestant, 1%
Muslim; indigenous beliefs
Language: Kinyarwanda, French (official);
Kiswahili used in commercial centers
Infant mortality rate: 102/1,000(1985)
Life expectancy: 48
Literacy: 37%
Labor force: 3.6 million (1985); 91%
agriculture, 2% industry and commerce,
7% government and services','6e9ac29d0720d1753799ca8210b27cfd8328c3da8d750d6e36aa3e7c014bc046','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8aa3423a5d3cf72c3a72483010f133d9cc42a350b5a09957c413f15d62ba3c45',1981,'SM','San Marino','geography',521,'Total area: 60 km2; land area: 60 km2
Comparative area: about one-third the
size of Washington, D. C.
Land boundary: 34 km with Italy
Climate: Mediterranean; mild to cool
winters; warm, sunny summers
Terrain: rugged mountains
Land use: 17% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 83% other
Environment: dominated by the Appeni-
nes
Special notes: landlocked; world''s smallest
republic; enclave of Italy','362920b7c4646032e9a03b70ed1208192dcb05840c59a442f3da3a138095b034','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e6bdb5282b5c85fc06ff17b8fc46424cf0062b2dfeb6b5212d793a8e66d37d9',1981,'SC','Seychelles','geography',530,'Total area: 280 km2; land area: 270 km2
Comparative area: about one and one-half
times the size of Washington, D. C.
Coastline: 491 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical marine; humid; cooler
season during southeast monsoon (late May
to September); warmer season during
northwest monsoon (March to May)
Terrain: Marie Group is granitic, narrow
coastal strip, rocky, hilly; others are coral,
flat, elevated reefs, no fresh water, mostly
uninhabited
Land use: 4% arable land; 18% permanent
crops; 0% meadows and pastures; 18%
forest and woodland; 60% other
Environment: lies outside the cyclone belt,
so severe storms are rare; short droughts
possible; 40 granitic and about 50 coralline
islands
Special notes: none
Population: 67,552 (July 1987), average
annual growth rate 1.52%
Nationality: noun — Seychellois (sing, and
pi.); adjective — Seychelles
216
Ethnic divisions: Seychellois (mixture of
Asians, Africans, Europeans)
Religion: 90% Roman Catholic, 8% Angli-
can, 2% other
Language: English and French (official);
Creole
Infant mortality rate: 26/1,000 (1983)
Life expectancy: 66
Literacy: 60%
Labor force: 1984 (est.) formal employ-
ment (all sectors) — 38.4 government, 30.7%
parastatal, 30.8% private; formal employ-
ment (by sector) — 49.0% industry and
commerce, 39.0% services, 11.5% agricul-
ture, forestry, and fishing
Organized labor: 3 major trade unions','1638833cdef0f70e8ead8466d7244c159f88fa5e03e7dba1040383b0709a57f6','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('410a5b1adf0fba263b4ed2ed799e8154a237826961cba8dd49351532a262695f',1981,'SL','Sierra Leone','geography',531,'Total area: 71,740 km2; land area: 71,620
km2
Comparative area: slightly smaller than
South Carolina
Land boundaries: 933 km total
Coastline: 402 km
Maritime claim:
Territorial sea: 200 nm
Climate: tropical; hot, humid; summer
rainy season (May to December); winter
dry season (December to April)
Terrain: coastal belt of mangrove swamps,
wooded hill country, upland plateau,
mountains in east
Land use: 23% arable land; 2% permanent
crops; 31% meadows and pastures; 29%
forest and woodland; 15% other; includes
NEGL% irrigated
Environment: extensive mangrove swamps
hinder access to sea; deforestation; soil
degradation
Special notes: none
Population: 3,754,088 (July 1987), average
annual growth rate 2.16%
Nationality: noun — Sierra Leonean(s);
adjective — Sierra Leonean
Ethnic divisions: over 99% native African
(30% Temne, 30% Mende, 2% Creole), rest
European and Asian; 13 tribes
Religion: 30% Muslim, 30% indigenous
beliefs, 10% Christian, 30% other or none
Language: English (official); regular use
limited to literate minority; principal
vernaculars are Mende in south and
Temne in north; Krio is the language of
the resettled exslave population of the
Freetown area and is lingua franca
Life expectancy: 46
Literacy: about 15%
Labor force: about 1.5 million; most of
population engages in subsistence agricul-
ture; only small minority, some 65,000,
earn wages
Organized labor: 35% of wage earners','442c98671c775baee41213e939857fc481c5f51a2def94901308a3333acafb3d','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ea9faa29dc829347224b9cbc57e06acefead78d4139a788c30235570fb22766',1981,'SG','Singapore','geography',535,'Total area: 580 km2; land area: 570 km2
Comparative area: about three times the
size of Washington, D. C.
Coastline: 193 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 3 nm
Climate: tropical; hot, humid, rainy; no
pronounced rainy or dry seasons; thunder-
storms occur on 40% of all days (67% of
days in April)
Terrain: lowland; gently undulating cen-
tral plateau contains water catchment area
and nature preserve
Land use: 4% arable land; 7% permanent
crops; 0% meadows and pastures; 5% forest
and woodland; 84% other
Environment: mostly urban and industri-
alized
Special notes: focal point for Southeast
Asian sea routes
Population: 2,616,236 (July 1987), average
annual growth rate 1.13%
Nationality: noun — Singaporean(s), adjec-
tive— Singapore
Ethnic divisions: 76.4% Chinese, 14.9%
Malay, 6.4% Indian, 2.3% other
Religion: majority of Chinese are Bud-
dhists or atheists; Malays nearly all Mus-
lim; minorities include Christians, Hindus,
Sikhs, Taoists, Confucianists
Language: Chinese, Malay, Tamil, and
English (official); Malay (national)
Infant mortality rate: 8.3/1,000 (1985)
Life expectancy: men 69, women 74
Literacy: 84.2%
Labor force: 1,154,260 (June 1985); 30.2%
services, 25.5% manufacturing, 23.5%
trade, 10.1% transport and communica-
tion, 8.9% construction, 0.7% agriculture
and fishing; 6.5% unemployment (June
1986)
Organized labor: 202,302, 17.5% of labor
force (1985)','5ada909b828fba6461b694b55f4243e7c8d14b680b16a241152ecc8e7956a60c','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1100dbcbae8482d27f9d1c94c00a98a964d39a59adde9f50787988ae0f26ad20',1981,'SO','Somalia','geography',539,'Language: 120 indigenous languages;
Melanesian pidgin in much of the country
is lingua franca; English spoken by 1-2%
of population
Infant mortality rate: 46/1,000 (1980)
Life expectancy: 54
Literacy: 60%
Labor force: 23,448 economically active
(1984); 32.4% agriculture, forestry, and
fishing; 7.0% construction, manufacturing,
and mining; 4.7% commerce, transport,
and finance
Organized labor: most of the cash econ-
omy workers have trade union representa-
tion
Total area: 637,660 km2; land area:
627,340 km2
Comparative area: slightly smaller than
Texas
Land boundaries: 2,263 km total
Coastline: 3,025 km
Maritime claim:
Territorial sea: 200 nm
Boundary disputes: southern half of
boundary with Ethiopia is a Provisional
Administrative Line; territorial dispute
with Ethiopia over the Ogaden; possible
claims to Djibouti, Ethiopia, and Kenya
based on unification of ethnic Somalis
Climate: hot, dry desert; northeast mon-
soon (December to February), cooler
southwest monsoon (May to October);
irregular rainfall; hot, humid periods
(Tangambili) between monsoons
Terrain: mostly flat to undulating plateau
rising to hills in north
Land use: 2% arable land; NEGL% per-
manent crops; 46% meadows and pastures;
14% forest and woodland; 38% other;
includes 3% irrigated
Environment: recurring droughts; fre-
quent dust storms over eastern plains in
summer; deforestation; overgrazing; soil
erosion; desertification
Special notes: strategic location on Horn
of Africa along southern approaches to
Bab el Mandeb and route through Red Sea
and Suez Canal
221
Somalia (continued)
Population: 7,741,859 (July 1987), average
annual growth rate 3.01%
Nationality: noun — Somali(s); adjective —
Somali
Ethnic divisions: 85% Somali, rest mainly
Bantu; 30,000 Arabs, 3,000 Europeans, 800
Asians
Religion: almost entirely Sunni Muslim
Language: Somali (official); Arabic, Italian,
English
Infant mortality rate: 150/1,000 (1984)
Life expectancy: 43.9
Literacy: 60%
Labor force: about 2.2 million; very few
are skilled laborers; 70% pastoral nomad,
30% agriculturists, government employees,
traders, fishermen, handicraftsmen, other
Organized labor: General Federation of
Somali Trade Unions, a government-
controlled organization, established in 1977','74f4e77938b0353a79118d217752dc44c2f31c6073bf755bb88243fb0e063c1a','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fc6a477db97e3cfbd9aa2d9a469abf59073e71fb8e178b127f59a18d530b164',1981,'ZA','South Africa','geography',543,'Total area: 1,221,040 km2; land area:
1,221,040 km2
Comparative area: about four-fifths the
size of Alaska
Land boundaries: 2,044 km total
Coastline: 2,881 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; occupies','b69ba843e3f0c2b775693df5b5c24889232b0cfc6546de4d3ed91b2f9ada55f2','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ba8b2cde9445cf3e5de03cd6710f372c54a467252b7ea659b01e020af796f78',1981,'LK','Sri Lanka','geography',547,'Total area: 65,610 km2; land area: 64,740
km2
Comparative area: about one-half the size
of North Carolina
Coastline: 1,340 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; monsoonal; northeast
monsoon (December to March); southwest
monsoon (June to October)
Terrain: mostly low, flat to rolling plain;
mountains in south-central interior
Land use: 16% arable land; 17% perma-
nent crops; 7% meadows and pastures;
37% forest and woodland; 23% other;
includes 8% irrigated
Environment: occasional cyclones, torna-
dos; deforestation; soil erosion
Special notes: only 29 km from India;
near major Indian Ocean sea lanes
Population: 16,406,576 (July 1987), aver-
age annual growth rate 1.37%
Nationality: noun — Sri Lankan(s); adjec-
tive— Sri Lankan
Ethnic divisions: 74% Sinhalese; 18%
Tamil; 7% Moor; 1% Burgher, Malay, and
Veddha
Religion: 69% Buddhist, 15% Hindu, 8%
Christian, 8% Muslim
Language: Sinhala (official); Sinhala and
Tamil listed as national languages; Sinhala
spoken by about 74% of population, Tamil
spoken by about 18%; English commonly
used in government and spoken by about
10% of the population
Infant mortality rate: 37/1,000 (1983)
Life expectancy: 68
Literacy: 87%
Labor force: 6.6 million (1985 est.); 45.9%
agriculture, 13.3% mining and manufac-
turing, 12.4% trade and transport, 26.3%
services and other; extensive underemploy-
ment; 19% unemployment (1985 est.)
Organized labor: about 33% of labor
force, over 50% of which employed on tea,
rubber, and coconut estates','bb9adac450a260d022a3c9b7ca0015a9c9c6994a797d43e9c08ac3410af3c4f1','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89072f477ae3e7ca41a2cc9b79f0423c791ab159b053c1fe39346b852ef9c3a0',1981,'SD','Sudan','geography',550,'Total area: 2,505,810 km2; land area:
2,376,000 km2
Comparative area: about one-fourth the
size of US
Land boundaries: 7,805 km total
Coastline: 853 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 12 nm
Boundary disputes: none; international
boundary and Administrative Boundary
with Kenya; international boundary and
Administrative Boundary with Egypt
Climate: tropical in south; arid desert in
north; rainy season (April to October)
Terrain: generally flat, featureless plain;
mountains in east and west
Land use: 5% arable land; NEGL% per-
manent crops; 24% meadows and pastures;
20% forest and woodland; 51% other;
includes 1% irrigated
Environment: dominated by Nile River
and tributaries; dust storms; desertification
Special notes: largest country in Africa
Population: 23,524,622 (July 1987), aver-
age annual growth rate 1.90%
Nationality: noun — Sudanese (sing, and
pi.); adjective — Sudanese
Ethnic divisions: 52% black, 39% Arab,
6% Beja, 2% foreigners, 1% other
Religion: 70% Sunni Muslim in north, 20%
indigenous beliefs, 5% Christian (mostly in
south)
Language: Arabic (official), Nubian, Ta
Bedawie, diverse dialects of Nilotic, Nilo-
Hamitic, and Sudanic languages, English;
program of Arabization in process
Infant mortality rate: 118.9/1,000 (1985)
Life expectancy: 47
Literacy: 20%
Labor force: 6.086 million (1982); roughly
78.4% agriculture, 9.8% industry and
commerce, 6.0% government; labor short-
ages for almost all categories of employ-
ment coexist with urban unemployment','9f70d3d047231b26ac2401fca90d39ca12d8a073e164cfa6393554d2b65ed4d0','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c78541ce8351bc14718cbb3a2939902cad39e9d222a9f1c78374064c0fde3cd',1981,'SR','Suriname','geography',554,'Total area: 163,270 km2; land area:
161,470 km2
Comparative area: about the size of','e0a1b69439467400c577a27e18dfc743926dc53a609435e7c5def921e1d26569','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('391b740e37ee6c93d01da7d1fee2b5ea6eccd7bf25dd90f4524e535602368e87',1981,'GE','Georgia','geography',555,'Land boundaries: 1,561 km total
Coastline: 386 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: claims area in French
Guiana between Litani Rivier and Riviere
Marouini (both headwaters of the Lawa);
claims area in Guyana between New
(Upper Courantyne) and Courantyne/Ku-
tari rivers (all headwaters of the Couran-
tyne)
Climate: tropical; moderated by trade
winds
Terrain: mostly rolling hills; narrow
coastal plain with swamps
Land use: NEGL% arable land; NEGL%
permanent crops; NEGL% meadows and
pastures; 97% forest and woodland; 3%
other; includes NEGL% irrigated
Environment: mostly tropical rain forest
Special notes: none
Population: 388,636 (July 1987), average
annual growth rate 1.61%
Nationality: noun — Surinamer(s); adjec-
tive— Surinamese
Ethnic divisions: 37.0% Hindustani (East
Indian), 31.0% Creole (black and mixed),
15.3% Javanese, 10.3% Bush black, 2.6%
Amerindian, 1.7% Chinese, 1.0% Europe-
ans, 1.1% other
Religion: 27.4% Hindu, 19.6% Muslim,
22.8% Roman Catholic, 25.2% Protestant
(predominantly Moravian), about 5%
indigenous beliefs
Language: Dutch (official); English widely
spoken; Sranan Tongo (Surinamese, some-
times called Taki-Taki) is native language
of Creoles and much of the younger popu-
lation and is lingua franca among others;
also Hindi Suriname Hindustani (a variant
of Bhoqpuri), and Javanese
Infant mortality rate: 23/1,000 (1984)
Life expectancy: men 64.8, women 69.8
Literacy: 65%
Labor force: 104,000 (1984); unemploy-
ment 25% (1985); about 10.6% of work
force engaged in agriculture, animal hus-
bandry, and fishing
Organized labor: 49,000 members of labor
force organized
Total area: 17,360 km2; land area: 17,200
km2
Comparative area: about the size of New','d2a2eba76cb30958bc8844d2d11554575be1b7ff10c56d226180d2c729f0b3d1','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cee8e4075568ed32793dc533660cb6de0d760194a8743bf264a3e805d6f7e871',1981,'SE','Sweden','geography',560,'Total area: 449,960 km2; land area:
411,620km2
Comparative area: about the size of
California
Land boundaries: 2,196 km total
Coastline: 3,218 km
Maritime claims:
Continental shelf: 200 meters or to
deptb of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with USSR
Climate: temperate in south with cold,
cloudy winters and cool partly cloudy
summers; subarctic in north
Terrain: mostly flat or gently rolling low-
lands; mountains in west
Land use: 7% arable land; 0% permanent
crops; 2% meadows and pastures; 64%
forest and woodland; 27% other; includes
NEGL% irrigated
Environment: water pollution; acid rain
Special notes: strategic location along
Danish Straits linking Baltic and North
Seas','16d7fd4dfb7dddc1caf12cf1bee4e5c470a9d294ccb5d4f14e4684873a135de2','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d107a715404b145b3ce02567fca51dc5f81efb7cf21a29e981c52fc611b5bb60',1981,'CH','Switzerland','geography',566,'Total area: 41,290 km2; land area: 39,770
km2
Comparative area: about twice the size of
New Jersey
Land boundaries: 1,884 km total
Climate: temperate, but varies with alti-
tude; cold, cloudy, rainy /snowy winters;
cool to warm, cloudy, humid summers
with occasional showers
Terrain: mostly mountains (Alps in south,
Jura in northwest) with central plateau of
rolling hills and plains
Land use: 10% arable land; 1% permanent
crops; 40% meadows and pastures; 26%
forest and woodland; 23% other; includes
1% irrigated
Environment: dominated by Alps
Special notes: landlocked; crossroads of
northern and southern Europe
Population: 6,572,739 (July 1987), average
annual growth rate 0.32%
Nationality: noun — Swiss (sing. & pi.);
adjective — Swiss
Ethnic divisions: total population — 65%
German, 18% French, 10% Italian, 1%
Romansch, 5% other; Swiss nationals — 74%
German, 20% French, 4% Italian, 1%
Romansch, 1% other
Religion: 49% Catholic, 48% Protestant,
0.3% Jewish
Switzerland (continued)
Language: total population — 65% German,
18% French, 12% Italian, 1% Romansch,
4% other; Swiss nationals — 74% German,
20% French, 4% Italian, 1% Romansch, 1%
other
Infant mortality rate: 9/1,000 (1985)
Life expectancy: men 70.3, women 76.2
Literacy: 99%
Labor force: 3.05 million, about 706,000
foreign workers, mostly Italian; 42% ser-
vices, 39% industry and crafts, 11% gov-
ernment, 7% agriculture and forestry, 1%
other; 0.9% unemployed (1985)
Organized labor: 20% of labor force
Total area: 185,180 km2; land area:
184,050 km2 (including 1,295 km2 of
Israeli-occupied territory)
Comparative area: about the size of North
Dakota
Land boundaries: 2,196 km total (excludes
2,156 km occupied area)
Coastline: 193 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 35 nm
Boundary disputes: separated from Israel
by 1949 Armistice Line; Golan Heights is
Israeli occupied; Hatay question with
Turkey; periodic disputes with Iraq over
Euphrates water rights; potential dispute
over water development plans by Turkey
for the Tigris and Euphrates rivers
Climate: mostly dry desert with hot, dry,
sunny summers (June to August) and mild,
rainy winters (December to February)
along coast
Terrain: primarily semiarid and desert
plain; narrow coastal plain; mountains in
west
Land use: 28% arable land; 3% permanent
crops; 46 meadows and pastures; 3% forest
and woodland; 20% other; includes 3%
irrigated
Environment: deforestation; overgrazing;
soil erosion; desertification
Special notes: none
Population: 11,147,763 (July 1987), aver-
age annual growth rate 3.69%
Nationality: noun — Syrian(s); adjective —
Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds,
Armenians, and other
Religion: 74% Sunni Muslim; 16% Alawite,
Druze, and other Muslim sects; 10% Chris-
tian (various sects)
Language: Arabic (official), Kurdish,
Armenian, Aramaic, Circassian; French
and English widely understood
Infant mortality rate: 57/1,000 (1984)
Life expectancy: men 64.9, women 67.6
Literacy: 47%
Labor force: 2.4 million; 36% miscella-
neous services, 32% agriculture, 32%
industry (including construction); majority
unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Total area: 945,090 km2; land area:
886,040 km2
Comparative area: about twice the size of
California
Land boundaries: 3,883 km total
Coastline: 1,424 km
Maritime claim:
Territorial sea: 50 nm
Boundary disputes: none; maritime dis-
pute with Malawi
Climate: varies from tropical along coast
to temperate in highlands
Terrain: plains along coast; central pla-
teau; highlands in north, south
Land use: 5% arable land; 1% permanent
crops; 40% meadows and pastures; 47%
forest and woodland; 7% other; includes
NEGL% irrigated
Environment: lack of water and tsetse fly
limit agriculture; recent droughts affecting
marginal agriculture; Kilimanjaro is high-
est point in Africa
Special notes: none
Population: 23,502,472 (July 1987), aver-
age annual growth rate 3.28%
Nationality: noun — Tanzanian(s); adjec-
tive— Tanzanian
Ethnic divisions: mainland — 99% native
African consisting of well over 100 tribes;
1% Asian, European, and Arab; Zanzibar —
almost all Arab
238
Religion: mainland— 33% Christian, 33%
Muslim, 33% indigenous beliefs; Zanzi-
bar— almost all Muslim
Language: Swahili and English (official);
English primary language of commerce,
administration, and higher education;
Swahili widely understood and generally
used for communication between ethnic
groups; first language of most people is one
of the local languages; primary education
is generally in Swahili
Infant mortality rate: 103/1,000 (1984)
Life expectancy: 52
Literacy: 79%
Labor force: 208,680 in paid employment
(1983); 90% agriculture, 10% industry and
commerce
Organized labor: 15% of labor force','cf2e38786cef5862a35b5c1ad3ac05e84ff924c05ca15e63e368c12a33cf1a4a','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bbb778a8f1f0485b180044bb77d3b64b2e8b6243bee50956bb8998ac3c8e704',1981,'TG','Togo','geography',570,'Total area: 56,790 km2; land area: 54,390
km2
Comparative area: about the size of West
Virginia
Land boundaries: 1,646 km total
Coastline: 56 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 30 nm
Climate: tropical; hot, humid in south;
semiarid in north
Terrain: gently rolling savanna in north;
central hills; southern plateau; low coastal
plain with extensive lagoons and marshes
Land use: 25% arable land; 1% permanent
crops; 4% meadows and pastures; 28%
forest and woodland; 42% other; includes
NEGL% irrigated
Environment: hot, dry harmattan wind
can reduce visibility in north during win-
ter; recent droughts affecting agriculture;
deforestation
Special notes: none
Population: 3,228,635 (July 1987), average
annual growth rate 3.25%
Nationality: noun — Togolese (sing, and
pi.); adjective — Togolese
Ethnic divisions: 37 tribes; largest and
most important are Ewe, Mina, and Ka-
bye; under 1% European and Syrian-
Lebanese
Religion: about 70% indigenous beliefs,
20% Christian, 10% Muslim
Language: French, both official and lan-
guage of commerce; major African lan-
guages are Ewe and Mina in the south and
Dagomba and Kabye in the north
Infant mortality rate: 114/1,000 (1983)
Life expectancy: 47
Literacy: 18%
Labor force: 78% agriculture, 22% indus-
try; about 88,600 wage earners, evenly
divided between public and private sectors
Organized labor: one national union, the
National Federation of Togolese Workers','752473c160b5f5b10426ab9edf1a91106e2f68f4b4da2b0ddfe9e362ca329278','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76cd48b12ef50c46145569f1130e9ddac2ca1c6e3bf9b0120a46bd04f744db89',1981,'TK','Tokelau','geography',572,'Total area: 10 km2; land area: 10 km2
Comparative area: about one-eighteenth
the size of Washington, D. C.
Coastline: 101 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by trade
winds (April to November)
Terrain: coral atolls enclosing large lagoons
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: lies in Pacific typhoon belt
Special notes: none
Population: 1,713 (July 1987), average
annual growth rate 1.95%
Nationality: noun — Tokelauan(s); adjec-
tive— Tokelauan
Ethnic divisions: all Polynesian, with
cultural ties to Western Samoa
Religion: 70% Congregational Christian
Church, 30% Roman Catholic — on Atafu,
all Congregational Christian Church of
Samoa; on Nukunonu, all Roman Catholic;
on Fakaofo, both denominations
Language: Tokelauan (a Polynesian lan-
guage) and English
Literacy: probably high
242','3f029bc24807bee7353759f129bdfc874386e9caa28d5143ee58f36e675b6358','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9218d82dee99f1b283948f5928425fb3d910fae8e6e6ce97fc04d05b940b938',1981,'TO','Tonga','geography',576,'Total area: 700 km2; land area: 670 km2
Comparative area: about four times the
size of Washington, D. C.
Coastline: 419 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; modified by trade
winds; warm season (December to May),
cool season (May to December)
Terrain: most have limestone base formed
from uplifted coral formation; others have
limestone overlaying volcanic base
Land use: 25% arable land; 55% perma-
nent crops; 6% meadows and pastures;
12% forest and woodland; 2% other
Environment: archipelago of 170 islands
(36 inhabited); subject to cyclones (October
to April); deforestation
Special notes: none','d51b75a9112d2caf2e6acbe8439d6198ad0b24d6f269dd866e3fd80c65ea75f3','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d58f1cb17ab81201929f06681df71bd86312b753ee7a7b6ded77c1ddf9250642',1981,'TT','Trinidad and Tobago','geography',582,'Total area: 5,130 km2; land area: 5,130
km2
Comparative area: about the size of
Delaware
Coastline: 362 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; rainy season (June to
December)
Terrain: mostly plains with some hills and
low mountains
Land use: 14% arable land; 17% perma-
nent crops; 2% meadows and pastures;
44% forest and woodland; 23% other;
includes 4% irrigated
Environment: outside usual path of hurri-
canes and other tropical storms
Special notes: southernmost of Southern
Antilles; only 11 km from Venezuela
Population: 1,250,839 (July 1987), average
annual growth rate 2.36%
Nationality: noun — Trinidadian(s),
Tobagan(s); adjective — Trinidadian,
Tobagan
244
Ethnic divisions: 43% black, 40% East
Indian, 14% mixed, 1% white, 1% Chinese,
1% other
Religion: 36.2% Roman Catholic, 23.0%
Hindu, 13.1% Protestant, 6.0% Muslim,
21.7% unknown
Language: English (official), Hindi,
French, Spanish
Infant mortality rate: 20/1,000 (1984)
Life expectancy: men 67, women 72
Literacy: 89%
Labor force: about 463,900 (est. 1985);
18.1% construction and utilities; 14.8%
manufacturing, mining, and quarrying;
10.9% agriculture; 47.9% other services
(1985); 15.4% unemployment (June 1985)
Organized labor: 40% of labor force
(1984)','b32b9dd225b3436b941f38f5a2c3494c76b41690757bcf66c46f28d1eda68ac5','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9c3ee169a72a5368af1bce57fe377a4c96928d7d10da8ff89c8aeb3d14e8a8e',1981,'TN','Tunisia','geography',584,'Total area: 163,610 km2; land area:
155,360 km2
Comparative area: about the size of
Missouri
Land boundaries: 1,408 km total
Coastline: 1,148 km
Maritime claim:
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with Libya
Climate: temperate in north with mild,
rainy winters and hot, dry summers; hot,
dry desert in south year round
Terrain: mountains in north; hot, dry
central plain; semiarid south merges into
Sahara Desert
Land use: 20% arable land; 10% perma-
nent crops; 19% meadows and pastures;
4% forest and woodland; 47% other; in-
cludes 1% irrigated
Environment: deforestation; overgrazing;
soil erosion; desertification
Special notes: strategic location in central
Mediterranean; only 144 km from Italy
across the Strait of Sicily; borders Libya on
east
Population: 7,561,641 (July 1987), average
annual growth rate 2.33%
Nationality: noun — Tunisian(s); adjec-
tive— Tunisian
Ethnic divisions: 98% Arab, 1% European,
less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less
than 1% Jewish
Language: Arabic (official); Arabic and
French (commerce)
Infant mortality rate: 83/1,000 (1983)
Life expectancy: men 60, women 63
Literacy: about 62%
Labor force: 1.9 million, 32% agriculture;
15%-25% unemployed; shortage of skilled
labor
Organized labor: about 360,000 members
claimed, roughly 20% of labor force;
General Union of Tunisian Workers
(UGTT), quasi-independent of Destourian
Socialist Party
Total area: 780,580 km2; land area:
770,760 km2
Comparative area: about twice the size of
California
Land boundaries: 2,574 km total
Coastline: 7,200 km
Maritime claims:
Extended economic zone: 200 nm in
Black Sea only
Territorial sea: 6 nm (12 nm in Black
Sea and Mediterranean Sea)
Boundary disputes: none; complex mari-
time and air (but not territorial) disputes
with Greece in Aegean Sea; Cyprus ques-
tion with Greece; Hatay question with
Syria; potential dispute with downstream
riparians (Syria and Iraq) over water
development plans for the Tigris and
Euphrates rivers
Climate: temperate; hot, dry summers
with mild, wet winters; harsher in interior
Terrain: mostly mountains; narrow coastal
plain; central plateau (Anatolia)
Land use: 30% arable land; 4% permanent
crops; 12% meadows and pastures; 26%
forest and woodland; 28% other; includes
3% irrigated
Environment: subject to severe earth-
quakes, especially along major river valleys
in west; air pollution; desertification
Special notes: strategic location controlling
Turkish Straits (Bosporus, Sea of Marmara,
Dardanelles) that link Black and Aegean
Seas; Turkey and Norway only NATO
members having a boundary with USSR
Population: 52,987,778 (July 1987), aver-
age annual growth rate 2.23%
Nationality: noun — Turk(s); adjective —
Turkish
Ethnic divisions: 85% Turkish, 12% Kurd,
3% other
Religion: 98% Muslim (mostly Sunni), 2%
other (mostly Christian and Jewish)
Language: Turkish (official), Kurdish,
Arabic
Infant mortality rate: 15.3/1,000 (1984)
Life expectancy: 57
Literacy: 70%
Labor force: 18.5 million (1986); 58.3%
agriculture, 28.7% service, 13.0% industry
and energy; about 1 million Turks work
abroad (1986); effective unemployment
rate estimated to be over 20% (1986)
Organized labor: 10-15% of labor force','64c7d5a2f9bcbf67339304f7ca9d4da29b409fb15418730b513cf5d1db7db4f7','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deb3055c5109d558d7c312604cbf5d04aa8f929f44f0a1d1887364cf70024371',1981,'TV','Tuvalu','geography',588,'Total area: 26 km2; land area: 26 km2
Comparative area: about one-seventh the
size of Washington, D. C.
Coastline: 24 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by easterly
trade winds (March to November); west-
erly gales and heavy rain (November to
March)
Terrain: very low lying and narrow coral
atolls
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: severe tropical storms are
rare
Special notes: none','8679c0c0dbc8b6d373dbbdfe776490195ea7ac2fb9a86d43ea115c01c8e0ec7b','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ea1d3e11d6760f0332dfbf83027e073dfef373096196338e9973dbcfbc6b7c5',1981,'UG','Uganda','geography',593,'Total area: 236,040 km2; land area:
199,710 km2
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,680 km total
Climate: tropical; generally rainy with two
dry seasons (December to February, June
to August); semiarid in northeast
Terrain: mostly plateau with rim of moun-
tains
Land use: 23% arable land; 9% permanent
crops; 25% meadows and pastures; 30%
forest and woodland; 13% other; includes
NEGL% irrigated
Environment: straddles Equator; defores-
tation; overgrazing; soil erosion
Special notes: landlocked
Population: 15,908,896 (July 1987), aver-
age annual growth rate 3.70%
Nationality: noun — Ugandan(s); adjec-
tive— Ugandan
Ethnic divisions: 99% African, 1% Euro-
pean, Asian, Arab
Religion: 33% Roman Catholic, 33%
Protestant, 16% Muslim, rest indigenous
beliefs
Language: English (official); Luganda and
Swahili widely used; other Bantu and
Nilotic languages
Infant mortality rate: 92/1,000 (1985)
Life expectancy: men 48, women 50
Literacy: 52%
Labor force: estimated 4.5 million; about
250,000 in paid labor; remainder in subsis-
tence activities
Organized labor: 125,000 union members','35d488cf2feae3b9e59457252840ddbd385997633f9635330b47ad4bf05d5404','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26a33ef1239f01aead68156389331c8599e0599ff47aa6456ab0c90efac407ad',1981,'AE','United Arab Emirates','geography',597,'Total area: 83,600 km2; land area: 83,600
km2
Comparative area: about the size of
Maine
Land boundaries: 1,094 km total
Coastline: 1,448 km
Maritime claims:
Continental shelf: defined by bilateral
boundaries or equidistant line
Extended economic zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: Qatar; no defined
boundary with Saudi Arabia; no defined
boundary with most of Oman, Administra-
tive Line in far north; claims three islands
occupied by Iran in Strait of Hormuz
Climate: hot, dry desert; cooler in eastern
mountains
Terrain: flat, barren coastal plain merging
into rolling sand dunes of vast desert
wasteland; mountains in east
Land use: NEGL% arable land; NEGL%
permanent crops; 2% meadows and pas-
tures; NEGL% forest and woodland; 98%
other; includes NEGL% irrigated
Environment: frequent dust and sand
storms; lack of natural fresh water re-
sources being overcome by desalination
plants; desertification
Special notes: strategic location along
southern approaches to Strait of Hormuz, a
vital transit point for world crude oil
Population: 1,846,373 (July 1987), average
annual growth rate 7.47%
Nationality: noun — Emirian(s), adjective —
Emirian
Ethnic divisions: 19% Emirian, 23% other
Arab, 50% South Asian (fluctuating), 8%
other expatriates (includes Westerners and
East Asians); fewer than 20% of the popu-
lation are UAE citizens (1982)
Religion: 96% Muslim (16% Shi''a); 4%
Christian, Hindu, and other
Language: Arabic (official); Farsi and
English widely spoken in major cities;
Hindi, Urdu
Infant mortality rate: 44/1,000 (1983)
Life expectancy: men 68, women 73
Literacy: 68%
Labor force: 580,000 (1985 est); 85%
industry and commerce, 5% agriculture,
5% services, 5% government; 80% of labor
force is foreign','b46af35bf72ebc2b14df23f1e2594a67b66e01443591e70c53644dd420d557c2','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed8fb177ab840c761571b5712f4dd2d1965ddd847c12780988e6e88ea328f2d3',1981,'GB','United Kingdom','geography',601,'Total area: 244,820 km2; land area:
241,590 km2
Comparative area: about the size of
Oregon
Land boundary: 360 km with Ireland
Coastline: 12,429 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: none; maritime dis-
pute with Ireland; Northern Ireland ques-
tion with Ireland; Gibraltar question with
Spain; Argentina claims Falkland Islands
(Islas Malvinas); Mauritius claims island of
Diego Garcia in British Indian Ocean
Territory; colony of Hong Kong will be-
come a Special Administrative Region of
China in 1997; Rockall continental shelf
dispute involving Denmark, Iceland,
Ireland; territorial claim in Antarctica
(British Antarctic Territory)
Climate: temperate; moderated by pre-
vailing southwest winds over Gulf Stream;
more than one-half of days are overcast
Terrain: mostly rugged hills and low
mountains; level to rolling plains in east
and southeast
Land use: 29% arable land; NEGL%
permanent crops; 48% meadows and
pastures; 9% forest and woodland; 14%
other; includes 1% irrigated
United Kingdom (continued)
Environment: pollution control measures
improving air, water quality; because of
heavily indented coastline, no location is
more than 125 km from tidal waters
Special notes: lies near vital North Atlan-
tic sea lanes; only 35 km from France
Population: 56,845,195 (July 1987), aver-
age annual growth rate 0. 15%
Nationality: noun — Briton(s), British
(collective pi.); adjective — British
Ethnic divisions: 81.5% English, 9.6%
Scottish, 2.4% Irish, 1.9% Welsh, 1.8%
Ulster, 2.8% West Indian, Indian, Paki-
stani, and other
Religion: 27.0 million Anglican, 5.3 mil-
lion Roman Catholic, 2.0 million Presbyte-
rian, 760,000 Methodist, 450,000 Jewish
(registered)
Language: English, Welsh (about 26% of
population of Wales), Scottish form of
Gaelic (about 60,000 in Scotland)
Infant mortality rate: 10.1/1,000 (1983)
Life expectancy: 71
Literacy: 99%
Labor force: (1986) 27.94 million; 24.5%
manufacturing and construction, 49.8%
services, 9.8% self-employed, 13.0% gov-
ernment, 1.1% agriculture; 11.4% unem-
ployed (November 1986)
Organized labor: 42% of labor force','ae65449b69d0edd84946a4c163343f7eab25b0b271623ea5c475aa6beffb20aa','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b8878d015d7fb434bf2333b0b1e9d06e52ed831bff9e9a902e8bd16c36e4c46',1981,'US','United States','geography',604,'Total area: 9,372,610 km2; land area:
9,166,600km2
Comparative area: about four-tenths the
size of USSR; about one-third the size of
Africa; about one-half the size of South
America (or slightly larger than Brazil);
slightly smaller than China; about two and
one-half times the size of Western Europe
Land boundaries: 12,000 km total
Coastline: 19,924 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters
Extended economic zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: none; maritime dis-
pute with Canada; Guantanamo (US Naval
Base) leased from Cuba; Haiti claims
Navassa Island (US possession); has made
no territorial claim in Antarctica (but has
reserved the right to do so) and does not
recognize the claims of any other nation
Climate: mostly temperate, but varies
from tropical (Hawaii) to arctic (Alaska);
arid to semiarid with occasional warm, dry
chinook wind in west
Terrain: vast central plain, mountains in
west, hills and low mountains in east;
rugged mountains and broad river valleys
255
United States (continued)
in Alaska; rugged, volcanic topography in
Hawaii
Land use: 20% arable land; NEGL%
permanent crops; 26% meadows and
pastures; 29% forest and woodland; 25%
other; includes 2% irrigated
Environment: pollution control measures
improving air and water quality; acid rain;
agricultural fertilizer and pesticide pollu-
tion; management of sparse natural water
resources in west; desertification; tsunamis,
volcanoes, and earthquake activity around
Pacific Basin
Special notes: world''s fourth largest coun-
try (after USSR, Canada, and China)
Population: 243,084,000 (July 1987),
average annual growth rate 0.92%
Ethnic divisions: 83.1% white; 11.6%
black; 6.448% Spanish origin; 0.622%
American Indian, Eskimo, and Aleut;
0.357% Chinese; 0.343% Filipino; 0.31%
Japanese, 0.1595% other Asian; 0.156%
Korean; 0.115% Vietnamese (1980)
Religion: total membership in religious
bodies 140.170 million; Protestant 76.8
million, Roman Catholic 52.7 million,
Jewish 5.7 million, other religions 5.0
million; 60% of the population have a
religious affiliation (1982)
Language: predominantly English; sizable
Spanish-speaking minority
Infant mortality rate: 10.6/1,000 (1984)
Life expectancy: men 71.6, women 76.3
Literacy: 99%
Labor force: 117.17 million (includes the
armed forces and the unemployed) —
annual averages of monthly data; unem-
ployment rate 7.2% (1985); 7.1% unem-
ployed as a share of total civilian labor
force (1985)
Organized labor: 17.3 million members;
18% of civilian labor force (1985)','539948c5aeee374a37dbc99fade444b6641978bc8da4eeebf66448be84f24b6e','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('929a16823046c65bfaf388e7c4956c0e808724bd0955cb470580479f86c7245e',1981,'UY','Uruguay','geography',608,'Total area: 176,220 km2; land area:
173,620 km2
Comparative area: about the size of the
State of Washington
Land boundaries: 1,352 km total
Coastline: 660 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm (overflight and
navigation permitted beyond 12 nm)
Boundary disputes: Argentina, Brazil
Climate: warm temperate; freezing tem-
peratures almost unknown
Terrain: mostly rolling plains and low
hills; fertile coastal lowland
Land use: 8% arable land; NEGL% per-
manent crops; 78% meadows and pastures;
4% forest and woodland; 10% other; in-
cludes 1% irrigated
Environment: subject to seasonally high
winds, droughts, floods
Special notes: none
Population: 2,964,052 (July 1987), average
annual growth rate 0.39%
Nationality: noun — Uruguayan(s); adjec-
tive— Uruguayan
Ethnic divisions: 88% white, 8% mestizo,
4% black
257
Uruguay (continued)
Religion: 66% Roman Catholic (less than
half adult population attends church
regularly), 2% Protestant, 2% Jewish, 30%
nonprofessing or other
Language: Spanish
Infant mortality rate: 32/1,000 (1983)
Life expectancy: men 67.1, women 73.7
Literacy: 94.3%
Labor force: about 1.28 million (1981);
25% government; 19% manufacturing; 11%
agriculture; 12% commerce; 12% utilities,
construction, transport, and communica-
tions; 21% other services; unemployment
11% (1986 est.)
Organized labor: Interunion Workers''
Assembly/National Workers'' Confedera-
tion (PIT/CNT) Labor Federation','73defc33fe00aef8ba72489d25733de265c61be08529fa3a0a8a9962853e86f2','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('353c7e9853e039c59addb1948d8d602542a7538e9d3f0935844acfaf5f8abf91',1981,'VU','Vanuatu','geography',611,'Total area: 14,760 km2; land area: 14,760
km2
Comparative area: about the size of
Connecticut
Coastline: 2,528 km
Maritime claims: (measured from claimed
archipelagic baselines)
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by southeast
trade winds
Terrain: mostly mountains of volcanic
origin; narrow coastal plains
Land use: 1% arable land; 5% permanent
crops; 2% meadows and pastures; 1% forest
and woodland; 91% other
Environment: subject to cyclones (January
to April); volcanism causes minor earth-
quakes; over 80 islands
Special notes: none
Total area: 0.438 km2; land area: 0.438
km2
Comparative area: about one-four hun-
dredth the size of Washington, D. C.
Land boundary: 3 km with Italy
Climate: temperate; mild, rainy winters
(September to mid-May) with hot, dry
summers (May to September)
Terrain: low hill
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: urban
Special notes: landlocked; enclave of
Rome, Italy; world''s smallest state
Population: 738 (July 1987), average
annual growth rate 0.14%
Ethnic divisions: primarily Italians but
also many other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various
other languages
Literacy: 100%
Labor force: about 1,500; Vatican City
employees divided into three categories-
executives, office workers, and salaried
employees
Total area: 912,050 km2; land area:
882,050 km2
Comparative area: about twice the size of
California
Land boundaries: 4,181 km total
Coastline: 2,800 km
Maritime claims:
Contiguous zone: 15 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: claims Essequibo area
of Guyana; maritime dispute with Colom-
bia
Climate: tropical; hot, humid; more mod-
erate in highlands
Terrain: Andes mountains and Maracaibo
lowlands in northwest; central plains
(llanos); Guyana highlands in southeast
Land use: 3% arable land; 1% permanent
crops; 20% meadows and pastures; 39%
forest and woodland; 37% other; includes
NEGL% irrigated
Environment: Angel Falls is world''s high-
est waterfall
Special notes: on major sea and air routes
linking North and South America
Population: 18,291,134 (July 1987), aver-
age annual growth rate 2.66%
Nationality: noun — Venezuelan(s); adjec-
tive— Venezuelan
Ethnic divisions: 67% mestizo, 21% white,
10% black, 2% Indian
Religion: 96% nominally Roman Catholic,
2% Protestant
Language: Spanish (official); Indian dia-
lects spoken by about 200,000 Amerind-
ians in the remote interior
Infant mortality rate: 36.2/1,000 (1984)
Life expectancy: men 64.0, women 69.0
Literacy: 85.6%
Labor force: 5.8 million (1985); 56%
services, 28% industry, 16% agriculture
(1980); 10.5% unemployment (December
1986)
Organized labor: 32% of labor force','b01a551686e75a09230332584f61a3b72cafb9ff026dcb7f538e8c2f33493ff9','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78b5568572198022f1c533cb21d8f15b0cc3dc380a98e1dbb51cf729f786389a',1981,'WF','Wallis and Futuna','geography',618,'Total area: 200 km2; land area: 200 km2
Comparative area: slightly larger than
Washington, D.C.
Coastline: 129 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; hot, rainy season (No-
vember to April); cool, dry season (May to
October)
Terrain: volcanic origin; low hills
Land use: 5% arable land; 20% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 75% other
Environment: both island groups have
fringing reefs
Special notes: none
Population: 14,593 (July 1987) average
annual growth rate 2.35%
Nationality: noun — Wallisian(s), Futun-
an(s), or Wallis and Futuna Islanders;
adjective — Wallisian, Futunan, or Wallis
and Futuna Islander
Ethnic divisions: almost entirely Polynes-
ian
Religion: largely Roman Catholic
Wallis and Futuna (continued) Western Sahara
Total area: 266,000 km2; land area:
266,000 km2
Comparative area: about the size of Utah
Land boundaries: 2,086 km total
Coastline: 1,110 km
Maritime claims: contingent upon resolu-
tion of sovereignty issue
Boundary disputes: none; claimed and
administered by Morocco, but sovereignty
is unresolved
Climate: hot, dry desert; rain is rare; cold
offshore currents produce fog and heavy
dew
Terrain: mostly low, flat desert with large
areas of rocky or sandy surfaces rising to
small mountains in south and northeast
Land use: NEGL% arable land; 0% per-
manent crops; 19% meadows and pastures;
0% forest and woodland; 81% other
Environment: hot, dry, dust/sand-laden
sirocco wind can occur during winter and
spring; widespread harmattan haze exists
60% of time, often severely restricting
visibility; sparse water and arable land
Special notes: none
Population: 93,859 (July 1987), average
annual growth rate 1.78%
Nationality: noun— Saharan(s), Moroc-
can(s); adjective — Saharan, Moroccan
Ethnic divisions: Arab and Berber
Religion: Muslim
Language: Hassaniya Arabic, Moroccan
Arabic
Literacy: about 20% among Moroccans,
5% among Saharans
Labor force: 12,000; 50% animal hus-
bandry and subsistence farming
Total area: 2,860 km2; land area: 2,850
km2
Comparative area: about the size of
Rhode Island
Coastline: 403 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; rainy season (October to
March), dry season May to October)
Terrain: narrow coastal plain with volca-
nic, rocky, rugged mountains in interior
Land use: 19% arable land; 24% perma-
nent crops; NEGL% meadows and pas-
tures; 47% forest and woodland; 10% other
Environment: subject to occasional ty-
phoons; active volcanism
Special notes: none
Population: 175,084 (July 1987), average
annual growth rate 2.20%
Nationality: noun — Western Samoan(s);
adjective — Western Samoa
Ethnic divisions: Samoan; about 12,000
Euronesians (persons of European and
Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of
population associated with the London
Missionary Society; includes Congrega-
tional, Roman Catholic, Methodist, Latter
Day Saints, Seventh-Day Adventist)
Language: Samoan (Polynesian), English
Infant mortality rate: 36/1,000 (1983)
Life expectancy: 63
Literacy: 90%
Labor force: about 37,000 (1983); about
22,000 employed in agriculture
Total area: 195,000 km2; land area:
195,000 km2
Comparative area: slightly smaller than
South Dakota
Land boundaries: 1,528 km total
Coastline: 523 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: 200 meters
Territorial sea: 12 nm
Boundary disputes: international boun-
dary/indefinite boundary/no defined
boundary with PDRY; international boun-
dary/no defined boundary with Saudi
Arabia
Climate: desert; hot and humid along
coast; temperate in central mountains;
harsh desert in east
Terrain: narrow coastal plain (Tihama);
western mountains; flat dissected plain in
center sloping into desert interior of Ara-
bian Peninsula
Land use: 14% arable land; NEGL%
permanent crops; 36% meadows and
pastures; 8% forest and woodland; 42%
other; includes 1% irrigated
Environment: subject to sand and dust
storms in summer; overgrazing; soil ero-
sion; desertification
Special notes: controls northern
approaches to Bab el Mandeb linking Red
Sea and Gulf of Aden, one of world''s most
active shipping lanes
Population: 6,533,265 (July 1987), average
annual growth rate 2.93%
Nationality: noun — Yemeni(s); adjective —
Yemeni
Ethnic divisions: 90% Arab, 10% Afro-
Arab (mixed)
Religion: 100% Muslim (Sunni and Shi''a)
Language: Arabic
Infant mortality rate: 152/1,000 (1983)
Life expectancy: men 37.3, women 38.7
Literacy: 15% (est.)
Labor force: about 30% expatriate labor-
ers; remainder almost entirely agriculture
and herding
Total area: 332,970 km2; land area:
332,970 km2
Comparative area: about the size of
Nevada
Land boundaries: 1,802 km total
Coastline: 1,383 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: international boun-
dary/indefinite boundary/no defined
boundary with YAR; Administrative Line
with Oman; no defined boundary with','57a271671d51796a63930c6bcbf913a2e54ce1ccfaf923d57cd4c7f277dddef5','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('801d6ccc8883ef51fe4c4111e7f58ff478acd50cc0e4d2243b174ffce61fe0f6',1981,'YE','Yemen','geography',621,'Total area: 255,800 km2; land area:
255,400 km2
Comparative area: about the size of
Wyoming
Land boundaries: 3,001 km total
Coastline: 3,935 km (including 2,414 km
offshore islands)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 12 nm
Boundary disputes: none; Kosovo question
with Albania; Macedonia question with
Bulgaria and Greece; Trieste question with','88691bdbabb9e826725f7251833f7cee7d71c373beeca1564b825a645b70e0ae','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5811c3b65007526fe744bc599aa9b8f00db64f3a6afa4b0bef7a9cd97f66fc36',1981,'ZM','Zambia','geography',624,'Total area: 752,610 km2; land area:
740,720 km2
Comparative area: about the size of Texas
Land boundaries: 6,003 km total
Boundary disputes: short section with
Zaire is indefinite
Climate: tropical; modified by altitude;
rainy season (October to April)
Terrain: mostly high plateau with some
hills and mountains
Land use: 7% arable land; NEGL% per-
manent crops; 47% meadows and pastures;
27% forest and woodland; 19% other;
includes NEGL% irrigated
Environment: deforestation; soil erosion;
desertification
Special notes: landlocked
Population: 7,281,738 (July 1987), average
annual growth rate 3.73%
Nationality: noun — Zambian(s); adjec-
tive— Zambian
Ethnic divisions: 98.7% African, 1.1%
European, 0.2% other
Religion: 50-75% Christian, 1% Muslim
and Hindu, remainder indigenous beliefs
Language: English (official); about 70
indigenous languages
Infant mortality rate: 140/1,000 (1984)
Life expectancy: 47
Literacy: 54%
Labor force: 2,455,000; 85% agriculture;
6% mining, manufacturing, and construc-
tion; 9% transport and services
Organized labor: about 238,000 wage
earners are unionized','8daf0ce92463465f79d61d10899db6f7ef09ed4911cf6e71641d7f587b8ff591','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1578803feb0002a317422b6d6cf5e912872985598159695eaa2e94069c6b263',1981,'ZW','Zimbabwe','geography',628,'Total area: 390,580 km2; land area:
386,670 km2
Comparative area: slightly smaller than
California
Land boundaries: 3,017 km total
Climate: tropical; moderated by altitude;
rainy season (November to March)
Terrain: mostly high plateau with higher
central plateau (high veld); mountains in
east
Land use: 7% arable land; NEGL% per-
manent crops; 12% meadows and pastures;
62% forest and woodland; 19% other;
includes NEGL% irrigated
Environment: recurring droughts; floods
and severe storms are rare; deforestation;
soil erosion; air and water pollution; deser-
tification
Special notes: landlocked
Population: 9,371,972 (July 1987), average
annual growth rate 3.60%
Nationality: noun — Zimbabwean(s); adjec-
tive— Zimbabwean
Ethnic divisions: about 96% African (over
73% members of Shona-speaking subtribes,
19% speak Ndebele); about 3% white, 1%
mixed and Asian
Religion: 50% syncretic (part Christian,
part indigenous beliefs), 25% Christian,
24% indigenous beliefs, a few Muslim
Language: English (official); ChiShona and
Si Ndebele
Infant mortality rate: 66/1,000 (1985)
Life expectancy: men 53.3, women 56.8
Literacy: 45-55%
Labor force: 1,985,000 (1985); 78% agri-
culture; 18% mining, manufacturing,
construction; 4% transport and services
Organized labor: about one-third of
European wage earners are unionized, but
only a small minority of Africans
Total area: 35,980 km2; land area: 35,980
km2
Comparative area: about the size of
Connecticut and New Hampshire com-
bined
Coastline: 1,448 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; involved in
complex dispute over Spratly Islands with
China, Malaysia, Philippines, Vietnam,
and possibly Brunei
Climate: tropical; marine; rainy season
during southwest monsoon (June to Sep-
tember); cloudiness is persistent and exten-
sive all year
Terrain: mostly mountains; flat to gently
rolling plains in west
Land use: 24% arable land; 1% permanent
crops; 5% meadows and pastures; 55%
forest and woodland; 15% other; 14%
irrigated
Environment: subject to earthquakes and
typhoons
Special notes: none
Population: 19,768,035, excluding the
population of Chin-men Tao (Quemoy),
Ma-tsu Tao (Matsu), and foreigners (July
1987), average annual growth rate 1.24%
Nationality: noun — Chinese (sing., pi.);
adjective — Chinese
Ethnic divisions: 85% Taiwanese, 14%
mainland Chinese, 2% aborigine
Religion: 93% mixture of Buddhist, Con-
fucian, and Taoist; 4.5% Christian; 2.5%
other
Language: Mandarin Chinese (official);
Taiwanese and Hakka dialects also used
Infant mortality rate: 11.01/1,000 (1983)
Life expectancy: men 69.9, women 74.9
Literacy: 94%
Labor force: 7,491,000 (1984); 41% indus-
try and commerce, 32% services, 20%
agriculture, 7% civil administration; 2.4%
unemployment (1984)
Organized labor: (1983) 1.3 million or
about 18.4% (government controlled)
Administration
Type: one-party presidential regime; the
new political organizations bill (due to be
passed in early 1987) will permit legal
formation of new political parties
Capital: Taipei
Administrative divisions: 16 counties, 5
cities, 2 special municipalities (Taipei and
Kao-hsiung)
Legal system: based on civil law system;
constitution adopted 1946, though 1948
amendments set most of the constitution
aside; martial law (declared in 1949) was
lifted in early 1987; accepts compulsory
ICJ jurisdiction, with reservations
National holiday: 10 October
Branches: five independent branches
(executive, legislative, judicial, plus tradi-
tional Chinese functions of examination
and control), dominated by executive
branch; President and Vice President
elected by National Assembly
Government leaders: CHIANG Ching-
kuo, President (since March 1978); Yt)
Kuo-hua, Premier (since June 1984)
Suffrage: universal over age 20
Elections: national level — Legislative Yuan
every three years; National Assembly and
Control Yuan every six years; no general
election held since 1948 election on main-
land (partial elections for Taiwan province
representatives in December 1969, 1972,
1975, 1980, 1983, 1984, 1985, and 1986);
local level — provincial assembly, county
and municipal executives every four years;
county and municipal assemblies every
four years
Political parties and leaders: Kuomint-
ang, or National Party, led by Chairman
Chiang Ching-kuo; Democratic Socialist
Party and Young China Party controlled
by Kuomintang; The Democratic Progres-
sive Party (new opposition party) not
formally recognized by Kuomintang
Voting strength: (1983 Legislative Yuan
elections) 62 seats Kuomintang, 19 seats
independents; 1981 local elections, with
63% turnout of eligible voters, Kuomintang
received 71% of the popular vote, non-
Kuomintang 29%
Member of: expelled from UN General
Assembly and Security Council on 25
October 1971 and withdrew on same date
from other charter-designated subsidiary
organs; expelled from IMF/World Bank
group April/May 1980; member of ADB
and PECC, seeking to join GATT and/or
MFA; attempting to retain membership in
ICAC, ISO, INTELSAT, INTERPOL,
IWC— International Wheat Council, PCA;
suspended from IAEA in 1972, but still
allows IAEA controls over extensive atomic
development
Total area: West Bank— 5,860 km2 (in-
cludes West Bank, East Jerusalem, Latrun
Salient, Jerusalem No Man''s Land, and
northwest quarter of the Dead Sea, but
excludes Mt. Scopus) and Gaza Strip —
380km2; land area: West Bank— 5,640 km2
and Gaza Strip— 380 km2
Comparative area: West Bank — slightly
larger than Delaware; Gaza Strip — about
twice the size of Washington, D. C.
Land boundaries: West Bank — 480 km
total; Gaza Strip — 72 km total
Coastline: West Bank — none (landlocked);
Gaza Strip — 40 km
Maritime claims: West Bank — none
(landlocked); Gaza Strip — to be deter-
mined
Boundary disputes: West Bank — Israeli
occupied with status to be determined;
Gaza Strip — Israeli occupied with status to
be determined
Climate: West Bank — temperate, tempera-
ture and precipitation vary with altitude,
warm to hot summers, cool to mild win-
ters; Gaza Strip — temperate, mild winters,
dry and warm to hot summers
Terrain: West Bank — mostly rugged
dissected upland, some vegetation in west,
but barren in east; Gaza Strip — flat to
rolling, sand and dune covered coastal
plain
Land use: West Bank — 27% arable land,
0% permanent crops, 32% meadows and
pastures, 1% forest and woodland, 40%
other; Gaza Strip— 13% arable land, 32%
permanent crops, 0% meadows and pas-
tures, 0% forest and woodland, 55% other
Environment: West Bank — highlands are
main recharge area for Israel''s coastal
aquifers; Gaza Strip — desertification
Special notes: West Bank — landlocked,
Israeli settlements; Gaza Strip — Israeli
settlements
Population: total, 1,529,235 (July 1987);
average annual growth rate 2.57%; West
Bank (including East Jerusalem)— 969,386
(July 1987), average annual growth rate
2.27%; Gaza Strip— 559,849 (July 1987),
average annual growth rate 3.09%
276
Nationality: West Bank — to be deter-
mined; Gaza Strip — to be determined
Ethnic divisions: West Bank— 88% Pales-
tinian Arab and other, 12% Jewish (includ-
ing expanded East Jerusalem), 4% Be-
douin; Gaza Strip — 99.8% Palestinian Arab
and other, 0.2% Jewish
Religion: West Bank — 80% Muslim (pre-
dominantly Sunni), 12% Jewish, 8% Chris-
tian and other; Gaza Strip — 99% Muslim
(predominantly Sunni), 0.8% Christian,
0.2% Jewish
Language: West Bank — Arabic, Israeli
settlers speak Hebrew, English widely
understood; Gaza Strip — Arabic, Israeli
settlers speak Hebrew, English widely
understood
Labor force: West Bank — (excluding
Israeli Jewish settlers) 29.8% small indus-
try, commerce, and business, 24.2% con-
struction, 22.4% agriculture, and 23.6%
service and other (1984); Gaza Strip —
(excluding Israeli Jewish settlers) 32.0%
small industry, commerce and business,
24.4% construction, 25.5% service and
other, and 18.1% agriculture (1984)','b8ddc19ab5749bfc550e14a7cacee53a8f5dc7ab5ca1cb6203c1c7a2f9c31aa9','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c62ca5490ad43b96fccdc97bdcd53fb815b67fb6a84fc14f350d0604da9f8517',1981,'AF','Afghanistan','geography',8,'Total area: 647,500 km2; land area:
647,500 km2
Comparative area: slightly smaller than
Texas
Land boundaries: 5,826 km total; China
76 km, Iran 936 km, Pakistan 2,430 km,
USSR 2,384 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: Pashtun question with Pakistan;
Baloch question with Iran and Pakistan;
periodic disputes with Iran over Helmand
water rights; insurgency with Iranian and
Pakistani involvement; traditional tribal
rivalries
Climate: arid to semiarid; cold winters and
hot summers
Terrain: mostly rugged mountains; plains
in north and southwest
Natural resources: natural gas, crude oil,
coal, copper, talc, barites, sulphur, lead,
zinc, iron ore, salt, precious and semipre-
cious stones
Land use: 12% arable land; NEGL% per-
manent crops; 46% meadows and pastures;
3% forest and woodland; 39% other; in-
cludes NEGL% irrigated
Environment: damaging earthquakes occur
in Hindu Kush mountains; soil degrada-
tion, desertification, overgrazing, defores-
tation, pollution
Note: landlocked','c3b4290924d26eb7b6488278da06951ba599c0b6de85f3b7edbef8c8bf5f5227','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('296b309354dab085cb1ae888ef38dccbcfddcbb9f877b5897ba83434a5230066',1981,'AL','Albania','geography',14,'Total area: 28,750 km2; land area: 27,400
km2
Comparative area: slightly larger than
Maryland
Land boundaries: 768 km total; Greece
282 km, Yugoslavia 486 km
Coastline: 362 km
Maritime claims:
Continental shelf: not specified
Territorial sea: 1 5 nm
Disputes: Kosovo question with Yugosla-
via; Northern Epirus question with Greece
Climate: mild temperate; cool, cloudy, wet
winters; hot, clear, dry summers; interior
is cooler and wetter
Terrain: mostly mountains and hills; small
plains along coast
Natural resources: crude oil, natural gas,
coal, chromium, copper, timber, nickel
Land use: 21% arable land; 4% permanent
crops; 15% meadows and pastures; 38%
forest and woodland; 22% other; includes
1% irrigated
Environment: subject to destructive earth-
quakes; tsunami occur along southwestern
coast; deforestation seems to be slowing
Note: strategic location along Strait of
Otranto (links Adriatic Sea to Ionian Sea
and Mediterranean Sea)','79e67956679101f132c411118e9c65d46347789aca4c4fef6efa4fd53e92e212','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3080acfc2d6d5fdd282c29a5a113e39b6fdf2fa3d96badb724fb99a7fbc562c',1981,'DZ','Algeria','geography',18,'Total area: 2,381,740 km2; land area:
2,381,740 km2
Comparative area: slightly less than 3.5
times the size of Texas
Land boundaries: 6,343 km total; Libya
982 km, Mali 1,376 km, Mauritania 463
km, Morocco 1,559 km, Niger 956 km,
Tunisia 965 km. Western Sahara 42 km
Coastline: 998 km
Maritime claims:
Territorial sea: 1 2 nm
Disputes: Libya claims about 19,400 km2
in southeastern Algeria
Climate: arid to semiarid; mild, wet win-
ters with hot, dry summers along coast;
drier with cold winters and hot summers
on high plateau; sirocco is a hot, dust/
sand-laden wind especially common in
summer
Terrain: mostly high plateau and desert;
some mountains; narrow, discontinuous
coastal plain
Natural resources: crude oil, natural gas,
iron ore, phosphates, uranium, lead, zinc
Land use: 3% arable land; NEGL% per-
manent crops; 13% meadows and pastures;
2% forest and woodland; 82% other; in-
cludes NEGL% irrigated
Environment: mountainous areas subject to
severe earthquakes; desertification
Note: second largest country in Africa
(after Sudan)','d9030c69a409fb9962eca37cdb957c83d8a60c80c45c787976ddc92d62be99a6','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bac312bd5646807c2d90b38fe06b45bddf2a50b917d5cbe5e7da5e17599de13',1981,'AS','American Samoa','geography',23,'Total area: 199 km2; land area: 199 km2
Comparative area: slightly larger than
Washington, DC
Land boundaries: none
Coastline: 116 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical marine, moderated by
southeast trade winds; annual rainfall av-
erages 1 24 inches; rainy season from No-
vember to April, dry season from May to
October; little seasonal temperature varia-
tion
Terrain: five volcanic islands with rugged
peaks and limited coastal plains, two coral
atolls
Natural resources: pumice and pumicite
Land use: 10% arable land; 5% permanent
crops; 0% meadows and pastures; 75%
forest and woodland; 10% other
Environment: typhoons common from De-
cember to March
Note: Pago Pago has one of the best natu-
ral deepwater harbors in the South Pacific
Ocean, sheltered by shape from rough
seas and protected by peripheral moun-
tains from high winds; strategic location
about 3,700 km south-southwest of Hono-
lulu in the South Pacific Ocean about
halfway between Hawaii and New Zea-
land','102a3b9463ae9f1a07956b20f5df0c1be4c38c20303ac1bfe52bbf94227680f9','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b137bc84291a87d4f2b0fd63f997eeed85773193a6f293c64a39d4db05cb6f7',1981,'AD','Andorra','geography',29,'Total area: 450 km2; land area: 450 km2
Comparative area: slightly more than 2.5
times the size of Washington, DC
Land boundaries: 125 km total; France 60
km, Spain 65 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: temperate; snowy, cold winters
and cool, dry summers
Terrain: rugged mountains dissected by
narrow valleys
Natural resources: hydropower, mineral
water, timber, iron ore, lead
Land use: 2% arable land; 0% permanent
crops; 56% meadows and pastures; 22%
forest and woodland; 20% other
Environment: deforestation, overgrazing
Note: landlocked','35b27c58a94a76c766ba90490286a18d285998dee06a2c5d88327109f8edd0b2','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba546da2b25f39e11d974a7b15ca044c0f85e78233139629ca3f86e15c8f3e47',1981,'AO','Angola','geography',35,'Total area: 1,246,700 km2; land area:
1,246,700km2
Comparative area: slightly less than twice
the size of Texas
Land boundaries: 5,198 km total; Congo
201 km, Namibia 1,376 km, Zaire 2,51 1
km, Zambia 1,110 km
Coastline: 1,600 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 20 nm
Disputes: civil war since independence on
11 November 1975
Climate: semiarid in south and along coast
to Luanda; north has cool, dry season
(May to October) and hot, rainy season
(November to April)
Terrain: narrow coastal plain rises
abruptly to vast interior plateau
Natural resources: petroleum, diamonds,
iron ore, phosphates, copper, feldspar,
gold, bauxite, uranium
Land use: 2% arable land; NEGL% per-
manent crops; 23% meadows and pastures;
43% forest and woodland; 32% other
Environment: locally heavy rainfall causes
periodic flooding on plateau; desertifica-
tion
Note: Cabinda is separated from rest of
country by Zaire','21fb0db5e45779093bf357957ec112e2776cc321638edc8121bae68cb5e90f13','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c27c635161fdf371923b0e687f0fbf044931a00685cb3d8d0eb2403bd87a47a9',1981,'AI','Anguilla','geography',40,'Total area: 91 km2; land area: 91 km2
Comparative area: about half the size of
Washington, DC
Land boundaries: none
Coastline: 61 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; moderated by northeast
trade winds
Terrain: flat and low-lying island of coral
and limestone
Natural resources: negligible; salt, fish,
lobsters
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
mostly rock with sparse scrub oak, few
trees, some commercial salt ponds
Environment: frequent hurricanes, other
tropical storms (July to October)
Note: located 270 km east of Puerto Rico','b1984e56d5b303921e08ad51d72e144ffa93179296723812c79320ba78cddfc9','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e71ff67e56fa0c0721b83e4b0119d2665cacf0b5dd405032c3f6d7cc31548c8',1981,'AQ','Antarctica','geography',45,'Total area: about 14,000,000 km2; land
area: about 14,000,000 km2
Comparative area: slightly less than 1 .5
times the size of the US; second-smallest
continent (after Australia)
Land boundaries: see entry on Disputes
Coastline: 1 7,968 km
Maritime claims: see entry on Disputes
Disputes: Antarctic Treaty suspends all
claims; sections (some overlapping)
claimed by Argentina, Australia, Chile,
France (Adelie Land), New Zealand (Ross
Dependency), Norway (Queen Maud
Land), and UK; Brazil claims a Zone of
Interest; the US and USSR do not recog-
nize the territorial claims of other nations
and have made no claims themselves (but
reserve the right to do so); no formal
claims have been made in the sector be-
tween 90° west and 150° west
Climate: severe low temperatures vary
with latitude, elevation, and distance from
the ocean; East Antarctica colder than
Antarctic Peninsula in the west; warmest
temperatures occur in January along the
coast and average slightly below freezing
Terrain: about 98% thick continental ice
sheet, with average elevations between
2,000 and 4,000 meters; mountain ranges
up to 5,000 meters high; ice-free coastal
areas include parts of southern Victoria
Land, Wilkes Land, and the scientific re-
search areas of Graham Land and Ross
Island on McMurdo Sound; glaciers form
ice shelves along about half of coastline
Natural resources: coal and iron ore; chro-
mium, copper, gold, nickel, platinum, and
hydrocarbons have been found in small
quantities along the coast; offshore depos-
its of oil and gas
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other (98% ice,
2% barren rock)
Environment: mostly uninhabitable; kata-
batic (gravity) winds blow coastward from
the high interior; frequent blizzards form
near the foot of the plateau; cyclonic
storms form over the ocean and move
clockwise around the coast; during sum-
mer more solar radiation reaches the sur-
face at the South Pole than is received at
the Equator in an equivalent period; in
October 1987 it was reported that the
ozone shield, which protects the Earth''s
surface from harmful ultraviolet radiation,
has dwindled to its lowest level ever over
Antarctica; subject to active volcanism
(Deception Island)
Note: the coldest continent','8521fefe2382cc2d315cc46180a2eccb0191ca4e156a0676ca824f4d27f18e4b','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4afdcf0b2c108d3c08c94b78bfcdd193889e4ba60fb2db9167d88bb947680496',1981,'AG','Antigua and Barbuda','geography',50,'Total area: 440 km2; land area: 440 km2;
includes Redonda
Comparative area: slightly less than 2.5
times the size of Washington, DC
Land boundaries: none
Coastline: 1 53 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical marine; little seasonal
temperature variation
Terrain: mostly low-lying limestone and
coral islands with some higher volcanic
areas
Natural resources: negligible; pleasant cli-
mate fosters tourism
Land use: 18% arable land; 0% permanent
crops; 7% meadows and pastures; 16%
forest and woodland; 59% other
Environment: subject to hurricanes and
tropical storms (July to October); insuffi-
cient freshwater resources; deeply
indented coastline provides many natural
harbors
Note: 420 km east-southeast of Puerto
Rico
Total area: 14,056,000 km2; includes
Baffin Bay, Barents Sea, Beaufort Sea,
Chukchi Sea, East Siberian Sea, Green-
land Sea, Hudson Bay, Hudson Strait,
Kara Sea, Laptev Sea, and other tributary
water bodies
Comparative area: slightly more than 1 .5
times the size of the US; smallest of the
world''s four oceans (after Pacific Ocean,
Atlantic Ocean, and Indian Ocean)
Coastline: 45,389 km
f''limate: persistent cold and relatively nar-
row annual temperature ranges; winters
characterized by continuous darkness, cold
and stable weather conditions, and clear
skies; summers characterized by continu-
ous daylight, damp and foggy weather,
and weak cyclones with rain or snow
Terrain: central surface covered by a pe-
rennial drifting polar icepack which aver-
ages about 3 meters in thickness, although
pressure ridges may be three times that
size; clockwise drift pattern in the Beau-
fort Gyral Stream, but nearly straight line
movement from the New Siberian Islands
(USSR) to Denmark Strait (between
Greenland and Iceland); the ice pack is
surrounded by open seas during the sum-
mer, but more than doubles in size during
the winter and extends to the encircling
land masses; the ocean floor is about 50%
continental shelf (highest percentage of
any ocean) with the remainder a central
basin interrupted by three submarine
ridges (Alpha Cordillera, Nansen Cordil-
lera, and Lomonsov Ridge); maximum
depth is 4,665 meters in the Fram Basin
Natural resources: sand and gravel aggre-
gates, placer deposits, polymetallic nod-
ules, oil and gas fields, fish, marine mam-
mals (seals, whales)
Environment: endangered marine species
include walruses and whales; ice islands
occasionally break away from northern
Ellesmere Island; icebergs calved from
13
Arctic Ocean (continued)','10ff255d14837ef2087e95b1dab3dc2b4674d8652eb195db1dc3f65ab6f0a2cb','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94fc75ed80ebad896175d8bc8ecf3bafb945aadc4f18fb66f2c7365acf295e4c',1981,'AR','Argentina','geography',53,'western Greenland and extreme northeast-
ern Canada; maximum snow cover in
March or April about 20 to 50 centime-
ters over the frozen ocean and lasts about
10 months; permafrost in islands; virtually
icelocked from October to June; fragile
ecosystem slow to change and slow to re-
cover from disruptions or damage
Note: major chokepoint is the southern
Chukchi Sea (northern access to the Pa-
cific Ocean via the Bering Strait); ships
subject to superstructure icing from Octo-
ber to May; strategic location between
North America and the USSR; shortest
marine link between the extremes of east-
ern and western USSR; floating research
stations operated by the US and USSR
Total area: 2,766,890 km2; land area:
2,736,690 km2
Comparative area: slightly more than four
times the size of Texas
Land boundaries: 9,665 km total; Bolivia
832 km, Brazil 1,224 km, Chile 5,150 km,
Paraguay 1,880 km, Uruguay 579 km
Coastline: 4,989 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm (overflight and
navigation permitted beyond 1 2 nm)
Disputes: short section of the boundary
with Uruguay is in dispute; short section
of the boundary with Chile is indefinite;
claims British-administered Falkland Is-
lands (Islas Malvinas); claims
British-administered South Georgia and
the South Sandwich Islands; territorial
claim in Antarctica
Climate: mostly temperate; arid in south-
east; subantarctic in southwest
Terrain: rich plains of the Pampas in
northern half, flat to rolling plateau of
Patagonia in south, rugged Andes along
western border
Natural resources: fertile plains of the
pampas, lead, zinc, tin, copper, iron ore,
manganese, crude oil, uranium
Land use: 9% arable land; 4% permanent
crops; 52% meadows and pastures; 22%
forest and woodland; 1 3% other; includes
1% irrigated
Environment: Tucuman and Mendoza ar-
eas in Andes subject to earthquakes; pam-
peros are violent windstorms that can
strike Pampas and northeast; irrigated soil
degradation; desertification; air and water
pollution in Buenos Aires
Note: second-largest country in South
America (after Brazil); strategic location
relative to sea lanes between South Atlan-
tic and South Pacific Oceans (Strait of
Magellan, Beagle Channel, Drake Pas-
sage)','9ade910632dab74223f5cf462b7a363e862a2e5cc40c7d43cbfe17d539aa1796','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65228cc121ab2358f1d8afef1c33c004c4e3cfb29397bc53fbea1715c8ca856f',1981,'AW','Aruba','geography',59,'Total area: 193 km2; land area: 193 km2
Comparative area: slightly larger than
Washington, DC
Land boundaries: none
Coastline: 68.5 km
Maritime claims:
Exclusive fishing zone: \\ 2 nm
Territorial sea: 1 2 nm
Climate: tropical marine; little seasonal
temperature variation
Terrain: flat with a few hills; scant vegeta-
tion
Natural resources: negligible; white sandy
beaches
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: lies outside the Caribbean
hurricane belt
Note: 28 km north of Venezuela
Total area: 5 km2; land area: 5 km2; in-
cludes Ashmore Reef (West, Middle, and
East Islets) and Cartier Island
Comparative area: about 8.5 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 74.1 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploration
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical
Terrain: low with sand and coral
Natural resources: fish
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other — grass and
sand
Environment: surrounded by shoals and
reefs; Ashmore Reef National Nature Re-
serve established in August 1983
Note: located in extreme eastern Indian
Ocean between Australia and Indonesia
320 km off the northwest coast of Austra-
lia
Total area: 82,217,000 km2; includes Bal-
tic Sea, Black Sea, Caribbean Sea, Davis
Strait, Denmark Strait, Drake Passage,
Gulf of Mexico, Mediterranean Sea,
North Sea, Norwegian Sea, Weddell Sea,
and other tributary water bodies
Comparative area: slightly less than nine
times the size of the US; second-largest of
the world''s four oceans (after the Pacific
Ocean, but larger than Indian Ocean or
Arctic Ocean)
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes) de-
velop off the coast of Africa near Cape
Verde and move westward into the Carib-
bean Sea; hurricanes can occur from May
to December, but are most frequent from
August to November
Terrain: surface usually covered with sea
ice in Labrador Sea, Denmark Strait, and
Baltic Sea from October to June; clock-
wise warm water gyre (broad, circular sys-
tem of currents) in the north Atlantic,
counterclockwise warm water gyre in the
south Atlantic; the ocean floor is domi-
nated by the Mid-Atlantic Ridge, a rug-
ged north-south centerline for the entire
Atlantic basin; maximum depth is 8,605
meters in the Puerto Rico Trench
Natural resources: oil and gas fields, fish,
marine mammals (seals and whales), sand
and gravel aggregates, placer deposits,
polymetallic nodules, precious stones
Environment: endangered marine species
include the manatee, seals, sea lions, tur-
tles, and whales; municipal sludge pollu-
tion off eastern US, southern Brazil, and
eastern Argentina; oil pollution in Carib-
bean Sea, Gulf of Mexico, Lake Mara-
caibo, Mediterranean Sea, and North Sea;
industrial waste and municipal sewage
pollution in Baltic Sea, North Sea, and
Mediterranean Sea; icebergs common in
Davis Strait, Denmark Strait, and the
northwestern Atlantic from February to
17
Atlantic Ocean (continued)','4e8d4f7d9173969c31aa96fb5717b864be0fb84c6acd914a774f657f582fb03d','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e31ad8e9dc6b6f8387729df65ac5dc81c342d89c78690c36e76df15b827a351b',1981,'AU','Australia','geography',63,'August and have been spotted as far south
as Bermuda and the Madeira Islands; ice-
bergs from Antarctica occur in the ex-
treme southern Atlantic
Note: ships subject to superstructure icing
in extreme north Atlantic from October to
May and extreme south Atlantic from
May to October; persistent fog can be a
hazard to shipping from May to Septem-
ber; major choke points include the Dar-
danelles, Strait of Gibraltar, access to the
Panama and Suez Canals; strategic straits
include the Dover Strait, Straits of Flor-
ida, Mona Passage, The Sound (Oresund),
and Windward Passage; north Atlantic
shipping lanes subject to icebergs from
February to August; the Equator divides
the Atlantic Ocean into the North Atlan-
tic Ocean and South Atlantic Ocean
Total area: 7,686,850 km2; land area:
7,617,930 km2; includes Macquarie Island
Comparative area: slightly smaller than
the US
Land boundaries: none
Coastline: 25,760 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Disputes: territorial claim in Antarctica
(Australian Antarctic Territory)
Climate: generally arid to semiarid; tem-
perate in south and east; tropical in north
Terrain: mostly low plateau with deserts;
fertile plain in southeast
Natural resources: bauxite, coal, iron ore,
copper, tin, silver, uranium, nickel, tung-
sten, mineral sands, lead, zinc, diamonds,
natural gas, crude oil
Land use: 6% arable land; NEGL% per-
manent crops; 58% meadows and pastures;
14% forest and woodland; 22% other; in-
cludes NEGL% irrigated
Environment: subject to severe droughts
and floods; cyclones along coast; limited
freshwater availability; irrigated soil deg-
radation; regular, tropical, invigorating,
sea breeze known as the doctor occurs
along west coast in summer; desertifica-
tion
Note: world''s smallest continent but sixth-
largest country','b346e9445e10cac67c5b7f23e4e1024d6430fe03711c2e00dda589cae5a04368','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c65e918740517b42f1586a7878c87ce80c5f6ba4833c9606016c3168d634a059',1981,'AT','Austria','geography',69,'Total area: 83,850 km2; land area: 82,730
km2
Comparative area: slightly smaller than
Maine
Land boundaries: 2,640 km total; Czecho-
slovakia 548 km, Hungary 366 km, Italy
430 km, Liechtenstein 37 km, Switzerland
164 km, FRG 784 km, Yugoslavia 311
km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: South Tyrol question with Italy
Climate: temperate; continental, cloudy;
cold winters with frequent rain in low-
lands and snow in mountains; cool sum-
mers with occasional showers
Terrain: mostly mountains with Alps in
west and south; mostly flat, with gentle
slopes along eastern and northern margins
Natural resources: iron ore, crude oil, tim-
ber, magnesite, aluminum, lead, coal, lig-
nite, copper, hydropower
Land use: 17% arable land; 1% permanent
crops; 24% meadows and pastures; 39%
forest and woodland; 19% other; includes
NEGL% irrigated
Environment: because of steep slopes, poor
soils, and cold temperatures, population is
concentrated on eastern lowlands
Note: landlocked; strategic location at the
crossroads of central Europe with many
easily traversable Alpine passes and val-
leys; major river is the Danube
Total area: 13,940 km2; land area: 10,070
km2
Comparative area: slightly larger than
Connecticut
Land boundaries: none
Coastline: 3,542 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical marine; moderated by
warm waters of Gulf Stream
Terrain: long, flat coral formations with
some low rounded hills
Natural resources: salt, aragonite, timber
Land use: 1% arable land; NEGL% per-
manent crops; NEGL% meadows and pas-
tures; 32% forest and woodland; 67%
other
Environment: subject to hurricanes and
other tropical storms that cause extensive
flood damage
Note: strategic location adjacent to US
and Cuba; extensive island chain','d39fa0094e6ecd3fd6fd43219fd3a73eff159984f519e5f54dd29ce67a84887c','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eb17b3cd9fab9c0d2204af750cf3c1d8e7e45b2c90284639774b8ed9ec1fa29',1981,'BH','Bahrain','geography',74,'Total area: 620 km2; land area: 620 km2
Comparative area: slightly less than 3.5
times the size of Washington, DC
Land boundaries: none
Coastline: 161 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 3 nm
Disputes: territorial dispute with Qatar
over the Hawar Islands
Climate: arid; mild, pleasant winters; very
hot, humid summers
Terrain: mostly low desert plain rising
gently to low central escarpment
Natural resources: oil, associated and no-
nassociated natural gas, fish
Land use: 2% arable land; 2% permanent
crops; 6% meadows and pastures; 0% for-
est and woodland; 90% other; includes
NEGL% irrigated
Environment: subsurface water sources
being rapidly depleted (requires develop-
ment of desalination facilities); dust
storms; desertification
Note: proximity to primary Middle East-
ern crude oil sources and strategic loca-
tion in Persian Gulf through which much
of Western world''s crude oil must transit
to reach open ocean
Total area: 1 .4 km2; land area: 1 .4 km2
Comparative area: about 2.3 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 4.8 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: equatorial; scant rainfall, con-
stant wind, burning sun
Terrain: low, nearly level coral island sur-
rounded by a narrow fringing reef
Natural resources: guano (deposits worked
until 1891)
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: treeless, sparse and scattered
vegetation consisting of grasses, prostrate
vines, and low growing shrubs; lacks fresh
water; primarily a nesting, roosting, and
foraging habitat for seabirds, shorebirds,
and marine wildlife
Note: remote location 2,575 km southwest
of Honolulu in the North Pacific Ocean,
just north of the Equator, about halfway
between Hawaii and Australia','ac14833798975cfd046427b9ebe1cd3eb8dc68b9660bcff5fb13c2eefd507e0e','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dd968ed9f2bac5039338be037ef47f6dd2ebbb57f6b2ce4a4ef33ab6701d700',1981,'BD','Bangladesh','geography',78,'Total area: 144,000 km2; land area:
133,910 km2
Comparative area: slightly smaller than
Wisconsin
Land boundaries: 4,246 km total; Burma
193 km, India 4,053 km
Coastline: 580 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: up to outer limits of
continental margin
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: a portion of the boundary with
India is in dispute; water sharing problems
with upstream riparian India over the
Ganges
Climate: tropical; cool, dry winter (Oc-
tober to March); hot, humid summer
(March to June); cool, rainy monsoon
(June to October)
Terrain: mostly flat alluvial plain; hilly in
southeast
Natural resources: natural gas, uranium,
arable land, timber
Land use: 67% arable land; 2% permanent
crops; 4% meadows and pastures; 16%
forest and woodland; 1 1 % other; includes
14% irrigated
Environment: vulnerable to droughts;
much of country routinely flooded during
summer monsoon season; overpopulation;
deforestation
Note: almost completely surrounded by','226b4b91ecc9bad2ec01003b3888e89ce52f70d8149212af22d8650ebe004461','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69701a997cdcce479c8dbed24113ffeda3f9409219b8eac080bab013660d5104',1981,'BB','Barbados','geography',85,'Total area: 430 km2; land area: 430 km2
Comparative area: slightly less than 2.5
times the size of Washington, DC
Land boundaries: none
Coastline: 97 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; rainy season (June to
October)
Terrain: relatively flat; rises gently to cen-
tral highland region
Natural resources: crude oil, fishing, natu-
ral gas
Land use: 77% arable land; 0% permanent
crops; 9% meadows and pastures; 0% for-
est and woodland; 14% other
Environment: subject to hurricanes (espe-
cially June to October)
Note: easternmost Caribbean island','41bb4044daa3d01b59929daff5aaf3655e4c49b70adf560f7b41854275b5bd82','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02c6d369752774707dbdf0db6a84261d0e5d3a7a86c09dd266b75b43a38f7288',1981,'BE','Belgium','geography',89,'Total area: undetermined
Comparative area: undetermined
Land boundaries: none
Coastline: 35.2 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claimed by Madagascar
Climate: tropical
Terrain: a volcanic rock 2.4 m high
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other (rock)
Environment: surrounded by reefs; subject
to periodic cyclones
Note: navigational hazard since it is usu-
ally under water during high tide; located
in southern Mozambique Channel about
halfway between Africa and Madagascar','ed19b2daeb16a9c69a82af6ca7f5ec9a55dd138ab431ff4415c4e346a3d79a79','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f803b053a9e53faae48c5d4e28929a77aaa42f540157c9b6f3a25124bdb379b9',1981,'FR','France','geography',92,'Total area: 30,510 km2; land area: 30,230
km2
Comparative area: slightly larger than
Maryland
Land boundaries: 1,385 km total; France
620 km, Luxembourg 148 km, Nether-
lands 450 km, FRG 167 km
Coastline: 64 km
Maritime claims:
Continental shelf: not specific
Exclusive fishing zone: equidistant line
with neighbors (extends about 68 km
from coast)
Territorial sea: 12 nm
Climate: temperate; mild winters, cool
summers; rainy, humid, cloudy
Terrain: flat coastal plains in northwest,
central rolling hills, rugged mountains of
Ardennes Forest in southeast
Natural resources: coal, natural gas
Land use: 24% arable land; 1% permanent
crops; 20% meadows and pastures; 21%
forest and woodland; 34% other; includes
NEGL% irrigated
Environment: air and water pollution
Note: majority of West European capitals
within 1 ,000 km of Brussels; crossroads of
Western Europe; Brussels is the seat of
the EC
Total area: 12,170 km2; land area: 12,170
km2; includes the two main islands of East
and West Falkland and about 200 small
islands
Comparative area: slightly smaller than
Connecticut
Land boundaries: none
Coastline: 1,288 km
Maritime claims:
Continental shelf: 100 meter depth
Exclusive fishing zone: 1 50 nm
Territorial sea: 1 2 nm
Disputes: administered by the UK,
claimed by Argentina
Climate: cold marine; strong westerly
winds, cloudy, humid; rain occurs on more
than half of days in year; occasional snow
all year, except in January and February,
but does not accumulate
Terrain: rocky, hilly, mountainous with
some boggy, undulating plains
Natural resources: fish and wildlife
Land use: 0% arable land; 0% permanent
crops; 99% meadows and pastures; 0%
forest and woodland; 1% other
Environment: poor soil fertility and a short
growing season
Note: deeply indented coast provides good
natural harbors
Total area: 547,030 km2; land area:
545,630 km2; includes Corsica and the
rest of metropolitan France, but excludes
the overseas administrative divisions
Comparative area: slightly more than
twice the size of Colorado
Land boundaries: 2,892.4 km total; An-
dorra 60 km, Belgium 620 km, FRG 451
km, Italy 488 km, Luxembourg 73 km,
Monaco 4.4 km, Spain 623 km, Switzer-
land 573 km
Coastline: 3,427 km (includes Corsica, 644
km)
Maritime claims:
Contiguous zone: 1 2-24 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: maritime boundary dispute with
Canada (St. Pierre and Miquelon); Mada-
gascar claims Bassas da India, Europa
Island, Glorioso Islands, Juan de Nova
Island, and Tromelin Island; Comoros
claims Mayotte; Mauritius claims Trome-
lin Island; Seychelles claims Tromelin Is-
land; Suriname claims part of French Gu-
iana; territorial claim in Antarctica
(Adelie Land)
Climate: generally cool winters and mild
summers, but mild winters and hot sum-
mers along the Mediterranean
Terrain: mostly flat plains or gently rolling
hills in north and west; remainder is
mountainous, especially Pyrenees in south,
Alps in east
Natural resources: coal, iron ore, bauxite,
fish, timber, zinc, potash
Land use: 32% arable land; 2% permanent
crops; 23% meadows and pastures; 27%
forest and woodland; 16% other; includes
2% irrigated
Environment: most of large urban areas
and industrial centers in Rhone, Garonne,
Seine, or Loire River basins; occasional
warm tropical wind known as mistral
Note: largest West European nation
Total area: 3,941 km2; land area: 3,660
km2
Comparative area: slightly less than one-
third the size of Connecticut
Land boundaries: none
Coastline: 2,525 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical, but moderate
Terrain: mixture of rugged high islands
and low islands with reefs
Natural resources: timber, fish, cobalt
Land use: 1% arable land; 19% permanent
crops; 5% meadows and pastures; 31%
forest and woodland; 44% other
Environment: occasional cyclonic storm in
January; includes five archipelagoes
Note: Makatea is one of three great phos-
phate rock islands in the Pacific (others
are Banaba or Ocean Island in Kiribati
and Nauru)
Total area: 131,940 km2; land area:
130,800km2
Comparative area: slightly smaller than
Alabama
Land boundaries: 1,228 km total; Albania
282 km, Bulgaria 494 km, Turkey 206
km, Yugoslavia 246 km
Coastline: 13,676 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 6 nm
Disputes: complex maritime and air (but
not territorial) disputes with Turkey in
Aegean Sea; Cyprus question; Macedonia
question with Bulgaria and Yugoslavia;
Northern Epirus question with Albania
Climate: temperate; mild, wet winters; hot,
dry summers
Terrain: mostly mountains with ranges
extending into sea as peninsulas or chains
of islands
Natural resources: bauxite, lignite, magne-
site, crude oil, marble
Land use: 23% arable land; 8% permanent
crops; 40% meadows and pastures; 20%
forest and woodland; 9% other; includes
7% irrigated
Environment: subject to severe
earthquakes; air pollution; archipelago of
2,000 islands
Note: strategic location dominating the
Aegean Sea and southern approach to
Turkish Straits
Total area: 582,650 km2; land area:
569,250 km2
Comparative area: slightly more than
twice the size of Nevada
Land boundaries: 3,477 km total; Ethiopia
861 km, Somalia 682 km, Sudan 232 km,
Tanzania 769 km, Uganda 933 km
Coastline: 536 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: international boundary and Ad-
ministrative Boundary with Sudan; possi-
ble claim by Somalia based on unification
of ethnic Somalis
Climate: varies from tropical along coast
to arid in interior
Terrain: low plains rise to central high-
lands bisected by Great Rift Valley; fer-
tile plateau in west
Natural resources: gold, limestone, dioto-
mite, salt barytes, magnesite, feldspar,
sapphires, fluorspar, garnets, wildlife
Land use: 3% arable land; 1% permanent
crops; 7% meadows and pastures; 4% for-
est and woodland; 85% other; includes
NEGL% irrigated
Environment: unique physiography sup-
ports abundant and varied wildlife of sci-
entific and economic value; deforestation;
soil erosion; desertification; glaciers on
Mt. Kenya
Note: Kenyan Highlands one of the most
successful agricultural production regions
in Africa
Total area: 1,565,000 km2; land area:
1,565,000 km2
Comparative area: slightly larger than
Alaska
Land boundaries: 8,1 14 km total; China
4,673 km, USSR 3,441 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: desert; continental (large daily
and seasonal temperature ranges)
Terrain: vast semidesert and desert plains;
mountains in west and southwest; Gobi
Desert in southeast
Natural resources: coal, copper, molybde-
num, tungsten, phosphates, tin, nickel,
zinc, wolfram, fluorspar, gold
Land use: 1% arable land; 0% permanent
crops; 79% meadows and pastures; 10%
forest and woodland; 10% other; includes
NEGL% irrigated
Environment: harsh and rugged
Note: landlocked; strategic location be-
tween China and Soviet Union
Total area: 268,680 km2; land area:
268,670 km2; includes Antipodes Islands,
Auckland Islands, Bounty Islands, Camp-
bell Island, Chatham Islands, and Kerma-
dec Islands
Comparative area: about the size of Colo-
rado
Land boundaries: none
Coastline: 15,134 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: territorial claim in Antarctica
(Ross Dependency)
Climate: temperate with sharp regional
contrasts
Terrain: predominately mountainous with
some large coastal plains
Natural resources: natural gas, iron ore,
sand, coal, timber, hydropower, gold,
limestone
Land use: 2% arable land; 0% permanent
crops; 53% meadows and pastures; 38%
forest and woodland; 7% other; includes
1% irrigated
Environment: earthquakes are common,
though usually not severe
Total area: 237,500 km2; land area:
230,340 km2
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,904 km total; Bulgaria
608 km, Hungary 443 km, USSR 1,307
km, Yugoslavia 546 km
Coastline: 225 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: Transylvania question with Hun-
gary; Bessarabia question with USSR
Climate: temperate; cold, cloudy winters
with frequent snow and fog; sunny sum-
mers with frequent showers and thunder-
storms
Terrain: central Transylvanian Basin is
separated from the plain of Moldavia on
the east by the Carpathian Mountains and
separated from the Walachian Plain on
the south by the Transylvanian Alps
Natural resources: crude oil (reserves be-
ing exhausted), timber, natural gas, coal,
iron ore, salt
Land use: 43% arable land; 3% permanent
crops; 19% meadows and pastures; 28%
forest and woodland; 7% other; includes
11% irrigated
Environment: frequent earthquakes most
severe in south and southwest; geologic
structure and climate promote landslides,
air pollution in south
Note: controls most easily traversable land
route between the Balkans and western
USSR
Total area: 340 km2; land area: 340 km2
Comparative area: slightly less than twice
the size of Washington, DC
Land boundaries: none
Coastline: 84 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; little seasonal tempera-
ture variation; rainy season (May to No-
vember)
Terrain: volcanic, mountainous; Soufriere
volcano on the island of St. Vincent
Natural resources: negligible
Land use: 38% arable land; 12% perma-
nent crops; 6% meadows and pastures;
41% forest and woodland; 3% other; in-
cludes 3% irrigated
Environment: subject to hurricanes; Souf-
riere volcano is a constant threat
Note: some islands of the Grenadines
group are administered by Grenada
Total area: 1 km2; land area: I km2
Comparative area: about 1 .7 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 3.7 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claimed by Madagascar, Mauri-
tius, and Seychelles
Climate: tropical
Terrain: sandy
Natural resources: fish
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other — scattered
bushes
Environment: wildlife sanctuary
Note: located 350 km east of Madagascar
and 600 km north of Reunion in the In-
dian Ocean; climatologically important
location for forecasting cyclones
Total area: 163,610 km2; land area:
155,360km2
Comparative area: slightly larger than
Total area: 5,860 km2; land area: 5,640
km2; includes West Bank, East Jerusalem,
Latrun Salient, Jerusalem No Man''s
Land, and the northwest quarter of the
Dead Sea, but excludes Mt. Scopus
Comparative area: slightly larger than
Delaware
Land boundaries: 404 km total; Israel 307
km, Jordan 97 km;
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: Israeli occupied with status to
be determined
Climate: temperate, temperature and pre-
cipitation vary with altitude, warm to hot
summers, cool to mild winters
Terrain: mostly rugged dissected upland,
some vegetation in west, but barren in
east
Natural resources: negligible
Land use: 27% arable land, 0% permanent
crops, 32% meadows and pastures, 1%
forest and woodland, 40% other
Environment: highlands are main recharge
area for Israel''s coastal aquifers
Note: landlocked; there are 173 Jewish
settlements in the West Bank and 14
Israeli-built Jewish neighborhoods in East
Jerusalem','04dbc6c9ce4d912b1299a9b258ce878c0e10976d7caee540af3a2e42b3bd679f','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e59df957a1db7b6ba809d377aef222e12fe11f27e4da740c0ae2ffb4e2399c9',1981,'BZ','Belize','geography',98,'Total area: 22,960 km2; land area: 22,800
km2
Comparative area: slightly larger than
Massachusetts
Land boundaries: 516 km total; Guate-
mala 266 km, Mexico 250 km
Coastline: 386 km
Maritime claims:
Territorial sea: 3 nm
Disputes: claimed by Guatemala, but
boundary negotiations are under way
Climate: tropical; very hot and humid;
rainy season (May to February)
Terrain: flat, swampy coastal plain; low
mountains in south
Natural resources: arable land potential,
timber, fish
Land use: 2% arable land; NEGL% per-
manent crops; 2% meadows and pastures;
44% forest and woodland; 52% other; in-
cludes NEGL% irrigated
Environment: frequent devastating hurri-
canes (September to December) and
coastal flooding (especially in south); de-
forestation
Note: national capital moved 80 km in-
land from Belize City to Belmopan be-
cause of hurricanes; only country in Cen-
tral America without a coastline on the
North Pacific Ocean','629994005f7352b5a4135a39dc836f87a29a6f78223bce71e1e80e8cabb6c630','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('531eff6731be9d793564425e92f6e1cbb96971e1428c00f29ea58729cdfe270c',1981,'BJ','Benin','geography',104,'Total area: 112,620 km2; land area:
110,620km2
Comparative area: slightly smaller than
Pennsylvania
Land boundaries: 1,989 km total; Burkina
306 km, Niger 266 km, Nigeria 773 km,
Togo 644 km
Coastline: 121 km
Maritime claims:
Territorial sea: 200 nm
Climate: tropical; hot, humid in south; se-
miarid in north
Terrain: mostly flat to undulating plain;
some hills and low mountains
Natural resources: small offshore oil de-
posits, limestone, marble, timber
Land use: 1 2% arable land; 4% permanent
crops; 4% meadows and pastures; 35%
forest and woodland; 45% other; includes
NEGL% irrigated
Environment: hot, dry, dusty harmattan
wind may affect north in winter; defores-
tation; desertification
Note: recent droughts have severely af-
fected marginal agriculture in north; no
natural harbors
Total area: 923,770 km2; land area:
910,770 km2
Comparative area: slightly more than
twice the size of California
Land boundaries: 4,047 km total; Benin
773 km, Cameroon 1,690 km, Chad 87
km, Niger 1,497 km
Coastline: 853 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 30 nm
Disputes: exact locations of the
Chad-Niger-Nigeria and Cameroon-Chad-
Nigeria tripoints in Lake Chad have not
been determined, so the boundary has not
been demarcated and border incidents
have resulted; Nigerian proposals to re-
open maritime boundary negotiations and
redemarcate the entire land boundary
have been rejected by Cameroon
Climate: varies — equatorial in south, tropi-
cal in center, arid in north
Terrain: southern lowlands merge into
central hills and plateaus; mountains in
southeast, plains in north
Natural resources: crude oil, tin, colum-
bite, iron ore, coal, limestone, lead, zinc,
natural gas
Land use: 31% arable land; 3% permanent
crops; 23% meadows and pastures; 1 5%
forest and woodland; 28% other; includes
NEGL% irrigated
Environment: recent droughts in north se-
verely affecting marginal agricultural ac-
tivities; desertification; soil degradation,
rapid deforestation','f2f9764db5f162dee07c10561f575d1a4a0ba09257af705b7890516ce449727b','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('293aaebcc171228fa2acb05d3e3b90b0a0b639fc5405af503be707eb788c863b',1981,'BM','Bermuda','geography',109,'Total area: 50 km2; land area: 50 km2
Comparative area: about 0.3 times the size
of Washington, DC
Land boundaries: none
Coastline: 103 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Climate: subtropical; mild, humid; gales,
strong winds common in winter
Terrain: low hills separated by fertile de-
pressions
Natural resources: limestone, pleasant cli-
mate fostering tourism
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 20%
forest and woodland; 80% other
Environment: ample rainfall, but no rivers
or freshwater lakes; consists of about 360
small coral islands
Note: 1 ,050 km east of North Carolina;
some reclaimed land leased by US Gov-
ernment','710b2c510b68e977cf2726221d78176deb41a89b539c0c92a88de2fbbb9f2ff8','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48ed584f5f2e3efd7b748a7b12c9fca7798dc1f0146b39a22ae15c954aeb48fd',1981,'BT','Bhutan','geography',113,'Total area: 47,000 km2; land area: 47,000
km2
Comparative area: slightly more than half
the size of Indiana
Land boundaries: 1,075 km total; China
470 km, India 60S km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: varies; tropical in southern
plains; cool winters and hot summers in
central valleys; severe winters and cool
summers in Himalayas
Terrain: mostly mountainous with some
fertile valleys and savanna
Natural resources: timber, hydropower,
gypsum, calcium carbide
Land use: 2% arable land; NEGL% per-
manent crops; 5% meadows and pastures;
70% forest and woodland; 23% other
Environment: violent storms coming down
from the Himalayas were the source of
the country name which translates as
Land of the Thunder Dragon
Note: landlocked; strategic location be-
tween China and India; controls several
key Himalayan mountain passes
Total area: 1,098,580 km2; land area:
1,084,390km2
Comparative area: slightly less than three
times the size of Montana
Land boundaries: 6,743 km total; Argen-
tina 832 km, Brazil 3,400 km, Chile 861
km, Paraguay 750 km, Peru 900 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: has wanted a sovereign corridor
to the South Pacific Ocean since the Ata-
cama area was lost to Chile in 1884; dis-
pute with Chile over Rio Lauca water
rights
Climate: varies with altitude; humid and
tropical to cold and semiarid
Terrain: high plateau, hills, lowland plains
Natural resources: tin, natural gas, crude
oil, zinc, tungsten, antimony, silver, iron
ore, lead, gold, timber
Land use: 3% arable land; NEGL% per-
manent crops; 25% meadows and pastures;
52% forest and woodland; 20% other; in-
cludes NEGL% irrigated
Environment: cold, thin air of high plateau
is obstacle to efficient fuel combustion;
overgrazing; soil erosion; desertification
Note: landlocked; shares control of Lago
Titicaca, world''s highest navigable lake,
with Peru','7c526fc29e25c4890a24c5b4e81ffca81807aec2cc7a4c685a22e9f1be3f0690','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1dc684ce7eed8b73ba8daff8380f05347edd63b0d5beed6e877f0591af9d9a6',1981,'BW','Botswana','geography',118,'Total area: 600,370 km2; land area:
585,370 km2
Comparative area: slightly smaller than
Texas
Land boundaries: 4,013 km total; Namibia
1,360 km, South Africa 1,840 km, Zimba-
bwe 813 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: short section of the boundary
with Namibia is indefinite; quadripoint
with Namibia, Zambia, and Zimbabwe is
in disagreement
Climate: semiarid; warm winters and hot
summers
Terrain: predominately flat to gently roll-
ing tableland; Kalahari Desert in south-
west
Natural resources: diamonds, copper,
nickel, salt, soda ash, potash, coal, iron
ore, silver, natural gas
Land use: 2% arable land; 0% permanent
crops; 75% meadows and pastures; 2%
forest and woodland; 21% other; includes
NEGL% irrigated
Environment: rains in early 1988 broke six
years of drought that had severely
affected the important cattle industry;
overgrazing; desertification
Note: landlocked; very long boundary with','4e0938b6b0ac85439c2a6ceef377dd7fb7333d57f2393969df488f9647386c49','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e669c8287937385318afe739fb83dd9b5707cb527dba38dd177589102ec3db1',1981,'BR','Brazil','geography',123,'Total area: 58 km2; land area: 58 km2
Comparative area: about 0.3 times the size
of Washington, DC
Land boundaries: none
Coastline: 29.6 km
Maritime claims:
Contiguous zone: 10 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 4 nm
Climate: antarctic
Terrain: volcanic; maximum elevation about
800 meters; coast is mostly inacessible
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: covered by glacial ice
Note: located in the South Atlantic Ocean
2,575 km south-southwest of the Cape of
Good Hope, South Africa
Total area: 8,51 1,965 km2; land area:
8,456,510 km2; includes Arquipelago de
Fernando de Noronha, Atol das Rocas,
Ilha da Trindade, Ilhas Martin Vaz, and
Penedos de S3o Pedro e Sao Paulo
Comparative area: slightly smaller than
the US
Land boundaries: 14,691 km total; Argen-
tina 1,224 km, Bolivia 3,400 km, Colom-
bia 1,643 km, French Guiana 673 km,
Guyana 1,1 19 km, Paraguay 1,290 km,
Peru 1,560 km, Suriname 597 km, Uru-
guay 985 km, Venezuela 2,200 km
Coastline: 7,491 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 200 nm
Disputes: short section of the boundary with
Paraguay (just west of Guaira Falls on the
Rio Parana) is in dispute; two short sections
of boundary with Uruguay are in dispute
(Arroyo de la Invernada area of the Rio
Quarai and the islands at the confluence of
the Rio Quarai and the Uruguay); claims a
Zone of Interest in Antarctica
Climate: mostly tropical, but temperate in
south
Terrain: mostly flat to rolling lowlands in
north; some plains, hills, mountains, and
narrow coastal belt
Natural resources: iron ore, manganese,
bauxite, nickel, uranium, phosphates, tin,
hydropower, gold, platinum, crude oil,
timber
Land use: 7% arable land; 1 % permanent
crops; 19% meadows and pastures; 67%
forest and woodland; 6% other; includes
NEGL% irrigated
Environment: recurrent droughts in north-
east; floods and frost in south; deforesta-
tion in Amazon basin; air and water pollu-
tion in Rio de Janeiro and Sao Paulo
38
Note: largest country in South America;
shares common boundaries with every
South American country except Chile and','a2cd4867f550c47c9f210413e3afc5de3e3a648fc7be92dd14eab70ba4cef82d','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f345b0b8efe615f80eb51588301d47ba2146c07bd29b56fa8579d2f7cd47c82d',1981,'IO','British Indian Ocean Territory','geography',128,'Total area: 60 km2; land area: 60 km2
Comparative area: about 0.3 times the size
of Washington, DC
Land boundaries: none
Coastline: 698 km
Maritime claims:
Territorial sea: 3 nm
Disputes: Diego Garcia is claimed by','2347e225424ebaf9029cba88e017ec9b58eaf78fb77e5e4a320441e61de3cda1','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c83753debeb59344c1c801dfa63dc2faed44c90dd5f46035e4793f9d7aa43ff',1981,'MU','Mauritius','geography',129,'Climate: tropical marine; hot, humid,
moderated by trade winds
Terrain: flat and low (up to 4 meters in
elevation)
Natural resources: coconuts, fish
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: archipelago of 2,300 islands
Note: Diego Garcia, largest and southern-
most island, occupies strategic location in
central Indian Ocean
Total area: 150 km2; land area: 150 km2
Comparative area: about 0.8 times the size
of Washington, DC
Coastline: 80 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: subtropical; humid; temperatures
moderated by trade winds
Terrain: coral islands relatively flat; volca-
nic islands steep, hilly
Natural resources: negligible
Land use: 20% arable land; 7% permanent
crops; 33% meadows and pastures; 7%
forest and woodland; 33% other
Environment: subject to hurricanes and
tropical storms from July to October
Note: strong ties to nearby US Virgin Is-
lands and Puerto Rico
Total area: 5,770 km2; land area: 5,270
km2
Comparative area: slightly larger than
Delaware
Land boundary: 381 km with Malaysia
Coastline: 161 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Disputes: may wish to purchase the Ma-
laysian salient that divides the country
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to moun-
tains in east; hilly lowland in west
Natural resources: crude oil, natural gas,
timber
Land use: 1% arable land; 1% permanent
crops; 1% meadows and pastures; 79%
forest and woodland; 18% other; includes
NEGL% irrigated
Environment: typhoons, earthquakes, and
severe flooding are rare
Note: close to vital sea lanes through
South China Sea linking Indian and Pa-
cific Oceans; two parts physically sepa-
rated by Malaysia; almost an enclave of
Total area: 1,860 km2; land area: 1,850
km2; includes Agalega Islands, Cargados
Carajos Shoals (St. Brandon) and Rodri-
gues
Comparative area: slightly less than 10.5
times the size of Washington, DC
Land boundaries: none
Coastline: 177 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claims Chagos Archipelago,
which includes the island of Diego Garcia
in UK-administered British Indian Ocean
Territory; claims French-administered
Tromelin Island
Climate: tropical modified by southeast
trade winds; warm, dry winter (May to
November); hot, wet, humid summer (No-
vember to May)
Terrain: small coastal plain rising to dis-
continuous mountains encircling central
plateau
Natural resources: arable land, fish
Land use: 54% arable land; 4% permanent
crops; 4% meadows and pastures; 31%
forest and woodland; 7% other; includes
9% irrigated
Environment: subject to cyclones
(November to April); almost completely
surrounded by reefs
Note: located 900 km east of Madagascar
in the Indian Ocean','225c11c9765d85793b4e02c2c0c817755ec24e330e7b28118bb68026023197bf','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a5b4be4226d7b7ba1203e4939d1ad7d9aeb9b1b5ab805a06d318abe27d1475f',1981,'BG','Bulgaria','geography',139,'Total area: 1 10,910 km2; land area:
110,550km2
Comparative area: slightly larger than
Tennessee
Land boundaries: 1,881 km total; Greece
494 km, Romania 608 km, Turkey 240
km, Yugoslavia 539 km
Coastline: 354 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: Macedonia question with Greece
and Yugoslavia
Climate: temperate; cold, damp winters;
hot, dry summers
Terrain: mostly mountains with lowlands
in north and south
Natural resources: bauxite, copper, lead,
zinc, coal, timber, arable land
Land use: 34% arable land; 3% permanent
crops; 18% meadows and pastures; 35%
forest and woodland; 10% other; includes
11% irrigated
Environment: subject to earthquakes, land-
slides; deforestation; air pollution
Note: strategic location near Turkish
Straits; controls key land routes from Eu-
rope to Middle East and Asia
Total area: 274,200 km2; land area:
273,800 km2
Comparative area: slightly larger than
Colorado
Land boundaries: 3,192 km total; Benin
306 km, Ghana 548 km, Ivory Coast 584
km, Mali 1,000 km, Niger 628 km, Togo
126km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: the disputed international
boundary between Burkina and Mali was
submitted to the International Court of
Justice (ICJ) in October 1983 and the ICJ
issued its final ruling in December 1986,
which both sides agreed to accept; Burk-
ina and Mali are proceeding with bound-
ary demarcation, including the tripoint
with Niger
Climate: tropical; warm, dry winters; hot,
wet summers
Terrain: mostly flat to dissected, undulat-
ing plains; hills in west and southeast
Natural resources: manganese, limestone,
marble; small deposits of gold, antimony,
copper, nickel, bauxite, lead, phosphates,
zinc, silver
Land use: 10% arable land; NEGL% per-
manent crops; 37% meadows and pastures;
26% forest and woodland; 27% other; in-
cludes NEGL% irrigated
Environment: recent droughts and deserti-
fication severely affecting marginal agri-
cultural activities, population distribution,
economy; overgrazing; deforestation
Note: landlocked
Total area: 678,500 km2; land area:
657,740 km2
Comparative area: slightly smaller than
Texas
Land boundaries: 5,876 km total; Bangla-
desh 193 km, China 2,185 km, India
1,463 km, Laos 235 km, Thailand 1,800
km
Coastline: 1,930 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical monsoon; cloudy, rainy,
hot, humid summers (southwest monsoon,
June to September); less cloudy, scant
rainfall, mild temperatures, lower humid-
ity during winter (northeast monsoon, De-
cember to April)
Terrain: central lowlands ringed by steep,
rugged highlands
Natural resources: crude oil, timber, tin,
antimony, zinc, copper, tungsten, lead,
coal, some marble, limestone, precious
stones, natural gas
Land use: 15% arable land; 1% permanent
crops; 1% meadows and pastures; 49%
forest and woodland; 34% other; includes
2% irrigated
Environment: subject to destructive earth-
quakes and cyclones; flooding and land-
slides common during rainy season (June
to September); deforestation
Note: strategic location near major Indian
Ocean shipping lanes','cd2ac55af97fb506ac9e268a6a5dbd6e93a461975d7a4b2b47d21d71a8d76711','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2dcc86fe135f571cf81607bce5d1468dcc318e1466a21ff6419092ca699a679',1981,'BI','Burundi','geography',143,'Total area: 27,830 km2; land area: 25,650
km2
Comparative area: slightly larger than
Maryland
Land boundaries: 974 km total; Rwanda
290 km, Tanzania 451 km, Zaire 233 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: temperate; warm; occasional frost
in uplands
Terrain: mostly rolling to hilly highland;
some plains
Natural resources: nickel, uranium, rare
earth oxide, peat, cobalt, copper, platinum
(not yet exploited), vanadium
Land use: 43% arable land; 8% permanent
crops; 35% meadows and pastures; 2%
forest and woodland; 1 2% other; includes
NEGL% irrigated
Environment: soil exhaustion; soil erosion;
deforestation
Note: landlocked; straddles crest of the
Nile-Congo watershed','599b7738c08b191938062a5708f3e16908cae858a16d684208dda0b48d61ca16','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47c1c769b1ab7e00e3f08087e4f52effb0810a64409b2d21a915c1482ea3a514',1981,'TH','Thailand','geography',147,'Total area: 181,040 km2; land area:
176,520km2
Comparative area: slightly smaller than
Oklahoma
Land boundaries: 2,572 km total; Laos
541 km, Thailand 803 km, Vietnam 1,228
km
Coastline: 443 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: offshore islands and three sec-
tions of the boundary with Vietnam are in
dispute; maritime boundary with Vietnam
not defined; occupied by Vietnam on 25
December 1978
Climate: tropical; rainy, monsoon season
(May to October); dry season (December
to March); little seasonal temperature
variation
Terrain: mostly low, flat plains; mountains
in southwest and north
Natural resources: timber, gemstones,
some iron ore, manganese, phosphates,
hydropower potential
Land use: 16% arable land; 1% permanent
crops; 3% meadows and pastures; 76%
forest and woodland; 4% other; includes
1% irrigated
Environment: a land of paddies and forests
dominated by Mekong River and Tonle
Sap
Note: buffer between Thailand and Viet-
nam
Total area: 514,000 km2; land area:
511,770km2
Comparative area: slightly more than
twice the size of Wyoming
Land boundaries: 4,863 km total; Burma
1,800 km, Cambodia 803 km, Laos 1,754
km, Malaysia 506 km
Coastline: 3,219 km
Maritime claims:
Continental shelf: not specific
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: boundary dispute with Laos
Climate: tropical; rainy, warm, cloudy
southwest monsoon (mid-May to Septem-
ber); dry, cool northeast monsoon (No-
vember to mid-March); southern isthmus
always hot and humid
Terrain: central plain; eastern plateau
(Khorat); mountains elsewhere
Natural resources: tin, rubber, natural gas,
tungsten, tantalum, timber, lead, fish, gyp-
sum, lignite, fluorite
Land use: 34% arable land; 4% permanent
crops; 1% meadows and pastures; 30%
forest and woodland; 31% other; includes
7% irrigated
Environment: air and water pollution; land
subsidence in Bangkok area
Note: controls only land route from Asia
to Malaysia and Singapore
Total area: 329,560 km2; land area:
325,360
Comparative area: slightly larger than
New Mexico
Land boundaries: 3,818 km total; Cambo-
dia 982 km, China 1,281 km, Laos 1,555
km
Coastline: 3,444 km (excluding islands)
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: offshore islands and three sec-
tions of the boundary with Cambodia are
in dispute; occupied Cambodia on 25 De-
cember 1978; sporadic border clashes with
China; involved in a complex dispute over
the Spratly Islands with China, Malaysia,
Philippines, and Taiwan; maritime bound-
ary dispute with China in the Gulf of
Tonkin; Paracel Islands occupied by
China but claimed by Vietnam and Tai-
wan
Climate: tropical in south; monsoonal in
north with hot, rainy season (mid- May to
mid-September) and warm, dry season
(mid-October to mid- March)
Terrain: low, flat delta in south and north;
central highlands; hilly, mountainous in
far north and northwest
Natural resources: phosphates, coal, man-
ganese, bauxite, chromate, offshore oil
deposits, forests
Land use: 22% arable land; 2% permanent
crops; 1% meadows and pastures; 40%
forest and woodland; 35% other; includes
5% irrigated
Environment: occasional typhoons (May to
January) with extensive flooding
331
Vietnam (continued)
Total area: 352 km2; land area: 349 km2
Comparative area: slightly less than twice
the size of Washington, DC
Land boundaries: none
Coastline: 188 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: subtropical, tempered by easterly
tradewinds, relatively low humidity, little
seasonal temperature variation; rainy sea-
son May to November
Terrain: mostly hilly to rugged and moun-
tainous with little level land
Natural resources: sun, sand, sea, surf
Land use: 15% arable land; 6% permanent
crops; 26% meadows and pastures; 6%
forest and woodland; 47% other
Environment: rarely affected by
hurricanes; subject to frequent severe
droughts, floods, earthquakes; lack of nat-
ural freshwater resources
Note: important location 1,770 km south-
east of Miami and 65 km east of Puerto
Rico, along the Anegada Passage — a key
shipping lane for the Panama Canal; St.
Thomas has one of the best natural, deep-
water harbors in the Caribbean','b2f56f63cf0ebe129b831d785832bbe85bf3691b70a53e6780901287bc29d6cd','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee0518ee41409c98fc2e2e0c898e5e38809922ebd109a7bd6746dd144f5bf759',1981,'CM','Cameroon','geography',153,'Total area: 475,440 km2; land area:
469,440 km2
Comparative area: slightly larger than
California
Land boundaries: 4,591 km total; Central
African Republic 797 km, Chad 1,094
km, Congo 523 km, Equatorial Guinea
189 km, Gabon 298 km, Nigeria 1,690
km
Coastline: 402 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 50 nm
Disputes: exact locations of the
Chad-Niger-Nigeria and Cameroon-Chad-
Nigeria tripoints in Lake Chad have not
been determined, so the boundary has not
been demarcated and border incidents
have resulted; Nigerian proposals to re-
open maritime boundary negotiations and
redemarcate the entire land boundary
have been rejected by Cameroon
Climate: varies with terrain from tropical
along coast to semiarid and hot in north
Terrain: diverse with coastal plain in
southwest, dissected plateau in center,
mountains in west, plains in north
Natural resources: crude oil, bauxite, iron
ore, timber, hydropower potential
Land use: 13% arable land; 2% permanent
crops; 18% meadows and pastures; 54%
forest and woodland; 1 3% other; includes
NEGL% irrigated
Environment: recent volcanic activity with
release of poisonous gases; deforestation;
overgrazing; desertification
Note: sometimes referred to as the hinge
of Africa','acefd6c990cfaec8ad0a6fa3e0971571b6f409994953db38696b269de24d3280','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('188a9bf0083ede06ed4b76d0b94567d1be8bc90f8f0983c1cf8b4ce510151d83',1981,'CA','Canada','geography',159,'Total area: 9,976,140 km2; land area:
9,220,970 km2
Comparative area: slightly larger than US
Land boundaries: 8,893 km with US (in-
cludes 2,477 km with Alaska)
Coastline: 243,791 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: \\ 2 nm
Disputes: maritime boundary disputes
with France (St. Pierre and Miquelon) and
US
Climate: varies from temperate in south to
subarctic and arctic in north
Terrain: mostly plains with mountains in
west and lowlands in southeast
Natural resources: nickel, zinc, copper,
gold, lead, molybdenum, potash, silver,
fish, timber, wildlife, coal, crude oil, natu-
ral gas
Land use: 5% arable land; NEGL% per-
manent crops; 3% meadows and pastures;
35% forest and woodland; 57% other; in-
cludes NEGL% irrigated
Environment: 80% of population concen-
trated within 160 km of US border; con-
tinuous permafrost in north a serious ob-
stacle to development
Note: second-largest country in world
(after USSR); strategic location between
USSR and US via north polar route
Total area: 4,030 km2; land area: 4,030
km2
Comparative area: slightly larger than
Rhode Island
Land boundaries: none
Coastline: 965 km
Maritime claims: (measured from claimed
archipelagic baselines)
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: temperate; warm, dry, summer
precipitation very erratic
Terrain: steep, rugged, rocky, volcanic
Natural resources: salt, basalt rock, pozzo-
lana, limestone, kaolin, fish
Land use: 9% arable land; NEGL% per-
manent crops; 6% meadows and pastures;
NEGL% forest and woodland; 85% other;
includes 1% irrigated
Environment: subject to prolonged
droughts; harmattan wind can obscure
visibility; volcanically and seismically ac-
tive; deforestation; overgrazing
Note: strategic location 500 km from Af-
rican coast near major north-south sea
routes; important communications station;
important sea and air refueling site','d450163d6845f619d876ce33545801b1f8d45110181895c1302a41b750d6c8d1','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ad064c6a765b68e39d6ec829bd4098fa5cfa9bfb62b5125613fdadd3a56f16d',1981,'KY','Cayman Islands','geography',164,'Total area: 260 km2; land area: 260 km2
Comparative area: slightly less than 1.5
times the size of Washington, DC
Land boundaries: none
Coastline: 160 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical marine; warm, rainy
summers (May to October) and cool, rela-
tively dry winters (November to April)
Terrain: low-lying limestone base
surrounded by coral reefs
Natural resources: fish, climate and
beaches that foster tourism
Land use: 0% arable land; 0% permanent
crops; 8% meadows and pastures; 23%
forest and woodland; 69% other
Environment: within the Caribbean hurri-
cane belt
Note: important location between Cuba
and Central America','51aa31fb8056ac1bee2f7de87e3432801c129ac1802cb1a4f7d7356e9c2e1ba8','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d4c151ad3dce041a7841917047d9915c58d7e8291fa40574d80bf359d54e9c5',1981,'CF','Central African Republic','geography',169,'Total area: 622,980 km2; land area:
622,980 km2
Comparative area: slightly smaller than
Texas
Land boundaries: 5,203 km total; Came-
roon 797 km, Chad 1,197 km, Congo 467
km, Sudan 1,165 km, Zaire 1,577 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: tropical; hot, dry winters; mild to
hot, wet summers
Terrain: vast, flat to rolling, monotonous
plateau; scattered hills in northeast and
southwest
Natural resources: diamonds, uranium,
timber, gold, oil
Land use: 3% arable land; NEGL% per-
manent crops; 5% meadows and pastures;
64% forest and woodland; 28% other
Environment: hot, dry, dusty harmattan
winds affect northern areas; poaching has
diminished reputation as one of last great
wildlife refuges; desertification
Note: landlocked; almost the precise cen-
ter of Africa','d9787a079e7a8fcd80610692395911b109b7ab1caf44fb2ba4dde4594a835167','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d18e2b8e4df58c569f1f9adc0c018a5cfe06bba029775f5de0236266805347e',1981,'TD','Chad','geography',173,'Total area: 1,284,000 km2; land area:
1,259,200 km2
Comparative area: slightly more than
three times the size of California
Land boundaries: 5,968 km total; Came-
roon 1,094 km, Central African Republic
1,197 km, Libya 1,055 km, Niger 1,175
km, Nigeria 87 km, Sudan 1,360 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: Libya claims and occupies a
small portion of the Aozou Strip in far
north; exact locations of the Chad-Niger-
Nigeria and Cameroon-Chad-Nigeria tri-
points in Lake Chad have not been deter-
mined— since the boundary has not been
demarcated, border incidents have
resulted
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center,
desert in north, mountains in northwest,
lowlands in south
Natural resources: small quantities of
crude oil (unexploited but exploration be-
ginning), uranium, natron, kaolin, fish
(Lake Chad)
Land use: 2% arable land; NEGL% per-
manent crops; 36% meadows and pastures;
11% forest and woodland; 51% other; in-
cludes NEGL% irrigated
Environment: hot, dry, dusty harmattan
winds occur in north; drought and deserti-
fication adversely affecting south; subject
to plagues of locusts
Note: landlocked; Lake Chad is the most
significant water body in the Sahel','53d377489aa6556f9627ca70459d17e7593b3045e1e8b420dd45a366d3e4b9bf','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a7852eb261ea804768eb6c8e86f6b8ba5623b4e54a747d1f746ebb0a97e7b4d',1981,'CL','Chile','geography',178,'Total area: 756,950 km2; land area:
748,800 km2; includes Isla de Pascua
(Easter Island) and Isla Sala y G6mez
Comparative area: slightly smaller than
twice the size of Montana
Land boundaries: 6,171 km total; Argen-
tina 5,150 km, Bolivia 861 km, Peru 160
km
Coastline: 6,435 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 nm
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Disputes: short section of the southern
boundary with Argentina is indefinite; Bo-
livia has wanted a sovereign corridor to
the South Pacific Ocean since the Ata-
cama area was lost to Chile in 1 884; dis-
pute with Bolivia over Rio Lauca water
rights; territorial claim in Antarctica
(Chilean Antarctic Territory) partially
overlaps Argentine claim
Climate: temperate; desert in north; cool
and damp in south
Terrain: low coastal mountains; fertile
central valley; rugged Andes in east
Natural resources: copper, timber, iron
ore, nitrates, precious metals, molybde-
num
Land use: 7% arable land; NEGL% per-
manent crops; 16% meadows and pastures;
21% forest and woodland; 56% other; in-
cludes 2% irrigated
Environment: subject to severe
earthquakes, active volcanism, tsunami;
Atacama Desert one of world''s driest re-
gions; desertification
Note: strategic location relative to sea
lanes between Atlantic and Pacific Oceans
(Strait of Magellan, Beagle Channel,
Drake Passage)','9d0eb2b26f06b13dd0b06ee756b4f4c07626c2412e9c345094d7280b8f93b7e6','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d70b7ecac08fb4a28d6b9533ec5cca34b7f48d15ef2846b7a549b445145a14c5',1981,'CN','China','geography',184,'Total area: 9,596,960 km2; land area:
9,326,410 km2
Comparative area: slightly larger than the
US
Land boundaries: 23,213.34 km total; Af-
ghanistan 76 km, Bhutan 470 km, Burma
2,185 km, Hong Kong 30 km, India 3,380
km, North Korea 1,416 km, Laos 423 km,
Macau 0.34 km, Mongolia 4,673 km,
Nepal 1,236 km, Pakistan 523 km, USSR
7,520 km, Vietnam 1,281 km
Coastline: 14,500 km
Maritime claims:
Territorial sea: 1 2 nm
Disputes: boundary with India; bilateral
negotiations are under way to resolve four
disputed sections of the boundary with the
USSR (Pamir, Argun, Amur, and Khaba-
rovsk areas); a short section of the bound-
ary with North Korea is indefinite; Hong
Kong is scheduled to become a Special
Administrative Region in 1997; Portu-
guese territory of Macau is scheduled to
become a Special Administrative Region
in 1999; sporadic border clashes with
Vietnam; involved in a complex dispute
over the Spratly Islands with Malaysia,
Philippines, Taiwan, and Vietnam; mari-
time boundary dispute with Vietnam in
the Gulf of Tonkin; Paracel Islands occu-
pied by China, but claimed by Vietnam
and Taiwan; claims Japanese-administered
Senkaku-shotO (Senkaku Islands)
Climate: extremely diverse; tropical in
south to subarctic in north
Terrain: mostly mountains, high plateaus,
deserts in west; plains, deltas, and hills in
east
Natural resources: coal, iron ore, crude oil,
mercury, tin, tungsten, antimony, manga-
nese, molybdenum, vanadium, magnetite,
aluminum, lead, zinc, uranium, world''s
largest hydropower potential
62
Land use: 10% arable land; NEGL% per-
manent crops; 31% meadows and pastures;
14% forest and woodland; 45% other; in-
cludes 5% irrigated
Environment: frequent typhoons (about five
times per year along southern and eastern
coasts), damaging floods, tsunamis, earth-
quakes; deforestation; soil erosion; indus-
trial pollution; water pollution; desertifica-
tion
Note: world''s third-largest country (after
USSR and Canada)
Total area: 329,750 km2; land area:
328,550 km2
Comparative area: slightly larger than
New Mexico
Land boundaries: 2,669 km total; Brunei
381 km, Indonesia 1,782, Thailand 506
km
Coastline: 4,675 km total (2,068 km Pen-
insular Malaysia, 2,607 km East Malay-
sia)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation; specified bound-
ary in the South China Sea
Exclusive fishing zone: 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: involved in a complex dispute
over the Spratly Islands with China, Phil-
ippines, Taiwan, and Vietnam; state of
Sabah claimed by the Philippines; Brunei
may wish to purchase the Malaysian sa-
lient that divides Brunei into two parts
Climate: tropical; annual southwest (April
to October) and northeast (October to
February) monsoons
Terrain: coastal plains rising to hills and
mountains
Natural resources: tin, crude oil, timber,
copper, iron ore, natural gas, bauxite
Land use: 3% arable land; 10% permanent
crops; NEGL% meadows and pastures;
63% forest and woodland; 24% other; in-
cludes 1% irrigated
Environment: subject to flooding; air and
water pollution
Note: strategic location along Strait of
Malacca and southern South China Sea
Total area: 300,000 km2; land area:
298,170km2
Comparative area: slightly larger than Ar-
izona
Land boundaries: none
Coastline: 36,289 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: to depth of exploita-
tion
Extended economic zone: 200 nm
Territorial sea: irregular polygon ex-
tending up to 100 nm from coastline as
defined by 1898 treaty; since late 1970s
has also claimed polygonal-shaped area
in South China Sea up to 285 nm in
breadth
Disputes: involved in a complex dispute
over the Spratly Islands with China, Ma-
laysia, Taiwan, and Vietnam; claims Ma-
laysian state of Sabah
Climate: tropical marine; northeast mon-
soon (November to April); southwest mon-
soon (May to October)
Terrain: mostly mountains with narrow to
extensive coastal lowlands
Natural resources: timber, crude oil,
nickel, cobalt, silver, gold, salt, copper
Land use: 26% arable land; 1 1% perma-
nent crops; 4% meadows and pastures;
40% forest and woodland; 19% other; in-
cludes 5% irrigated
Environment: astride typhoon belt, usually
affected by 1 5 and struck by five to six
cyclonic storms per year; subject to land-
slides, active volcanoes, destructive earth-
quakes, tsunami; deforestation; soil ero-
sion; water pollution
Total area: 2,149,690 km2; land area:
2,149,690km2
Comparative area: slightly less than one-
fourth the size of US
Land boundaries: 4,410 km total; Iraq 488
km, Iraq-Saudi Arabia Neutral Zone 198
km, Jordan 742 km, Kuwait 222 km,
Oman 676 km, Qatar 40 km, UAE 586
km, PDRY 830 km, YAR 628 km
Coastline: 2,510 km
Maritime claims:
Contiguous zone: 1 8 nm
Continental shelf: not specific
Exclusive fishing zone: not specific
Territorial sea: 1 2 nm
Disputes: no defined boundaries with
PDRY, UAE, and YAR; shares Neutral
Zone with Iraq — in July 1975, Iraq and
Saudi Arabia signed an agreement to di-
vide the zone between them, but the
agreement must be ratified, however, be-
fore it becomes effective; Kuwaiti owner-
ship of Qaruh and Umm al Maradim Is-
lands is disputed by Saudi Arabia
Climate: harsh, dry desert with great ex-
tremes of temperature
Terrain: mostly uninhabited, sandy desert
Natural resources: crude oil, natural gas,
iron ore, gold, copper
Land use: 1% arable land; NEGL% per-
manent crops; 39% meadows and pastures;
1% forest and woodland; 59% other; in-
cludes NEGL% irrigated
Environment: no perennial rivers or per-
manent water bodies; developing extensive
coastal seawater desalination facilities;
desertification
Note: extensive coastlines on Persian Gulf
and Red Sea provide great leverage on
shipping (especially crude oil) through Per-
sian Gulf and Suez Canal
273
Saudi Arabia (continued)','ea031e5a4eef60efb71ee3fc35cc53bb63e181486358b23ecf6714c623d7c2ef','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ecbea8d5375f567a5b8857947b7ed82f982cde55e37061f2420470123399d8b',1981,'MT','Malta','geography',189,'Total area: 135 km2; land area: 135 km2
Comparative area: about 0.8 times the size
of Washington, DC
Land boundaries: none
Coastline: 138.9 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; heat and humidity mod-
erated by trade winds
Terrain: steep cliffs along coast rise
abruptly to central plateau
Natural resources: phosphate
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: almost completely
surrounded by a reef
Note: located along major sea lanes of
Indian Ocean
Total area: undetermined
Comparative area: undetermined
Land boundaries: none
Coastline: 11.1 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical
Terrain: coral atoll
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other (coral)
Environment: reef about 8 km in circum-
ference
Note: located 1,120 km southwest of Mex-
ico in the North Pacific Ocean
Total area: 320 km2; land area: 320 km2
Comparative area: slightly less than twice
the size of Washington, DC
Land boundaries: none
Coastline: 140 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 25 nm
Territorial sea: 12 nm
Climate: Mediterranean with mild, rainy
winters and hot, dry summers
Terrain: mostly low, rocky, flat to
dissected plains; many coastal cliffs
Natural resources: limestone, salt
Land use: 38% arable land; 3% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 59% other; includes 3%
irrigated
Environment: numerous bays provide good
harbors; fresh water very scarce — increas-
ing reliance on desalination
Note: strategic location in central Medi-
terranean, 93 km south of Sicily, 290 km
north of Libya
Total area: 588 km2; land area; 588 km2
Comparative area: slightly less than 3.5
times the size of Washington, DC
Land boundaries: none
Coastline: 1 1 3 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: cool summers and mild winters;
humid; overcast about half the time
Terrain: hills in north and south bisected
by central valley
Natural resources: lead, iron ore
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
extensive arable land and forests
Environment: strong westerly winds prevail
Note: located in Irish Sea equidistant
from England, Scotland, and Ireland','0cca9b9ae0d5bebacf49d3c28fc5c3c5391b0b5e635f6e5364d4e94c70486ab0','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93d5d4f7d1d01fbf694786775cd5ccaa3f75cd6b545fbb145b49b31d70a0121b',1981,'CC','Cocos (Keeling) Islands','geography',194,'Total area: 14 km2; land area: 14 km2;
main islands are West Island and Home
Island
Comparative area: about 24 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 42.6 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: pleasant, modified by the south-
east trade winds for about nine months of
the year; moderate rainfall
Terrain: flat, low-lying coral atolls
Natural resources: fish
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: two coral atolls thickly cov-
ered with coconut palms and other vegeta-
tion
Note: located 1 ,070 km southwest of Su-
matra (Indonesia) in the Indian Ocean
about halfway between Australia and Sri
Lanka','88224fa8b80dc156b2d37aa4a90288638f0767121b23518cb13d82abd9df2176','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d560a38d79643b400e41002d733735192de31480dbee6a2e8a07c85fe44b20b',1981,'CO','Colombia','geography',199,'Total area: 1,138,910 km2; land area:
1,038,700 km2; includes Isla de Malpelo,
Roncador Cay, Serrana Bank, and Serra-
nilla Bank
Comparative area: slightly less than three
times the size of Montana
Land boundaries: 7,408 km total; Brazil
1,643 km, Ecuador 590 km, Panama 225
km, Peru 2,900, Venezuela 2,050 km
Coastline: 3,208 km total (1,448 km North
Pacific Ocean; 1,760 Caribbean Sea)
Maritime claims:
Continental shelf: not specified
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: maritime boundary dispute with
Venezuela in the Gulf of Venezuela; terri-
torial dispute with Nicaragua over Archi-
pelago de San Andres y Providencia and
Quita Sueno Bank
Climate: tropical along coast and eastern
plains; cooler in highlands
Terrain: mixture of flat coastal lowlands,
plains in east, central highlands, some
high mountains
Natural resources: crude oil, natural gas,
coal, iron ore, nickel, gold, copper, emer-
alds
Land use: 4% arable land; 2% permanent
crops; 29% meadows and pastures; 49%
forest and woodland; 16% other; includes
NEGL% irrigated
Environment: highlands subject to volcanic
eruptions; deforestation; soil damage from
overuse of pesticides; periodic droughts
Note: only South American country with
coastlines on both North Pacific Ocean
and Caribbean Sea','983a219a3f88969438a182d85945374c4b36b99f6a1f809ad769e7fd19e22c72','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b875b3f77f88175db8cd5ad45afb66663df804e4dbe0a9a9552f37f9e76a789',1981,'MZ','Mozambique','geography',204,'Total area: 2,170 km2; land area: 2,170
km2
Comparative area: slightly more than 12
times the size of Washington, DC
Land boundaries: none
Coastline: 340 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claims French-administered Ma-
yotte
Climate: tropical marine; rainy season
(November to May)
Terrain: volcanic islands, interiors vary
from steep mountains to low hills
Natural resources: negligible
Land use: 35% arable land; 8% permanent
crops; 7% meadows and pastures; 16%
forest and woodland; 34% other
Environment: soil degradation and erosion;
deforestation; cyclones possible during
rainy season
Note: important location at northern end
of Mozambique Channel
Total area: 28 km2; land area: 28 km2
Comparative area: about 0.2 times the size
of Washington, DC
Land boundaries: none
Coastline: 22.2 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Disputes: claimed by Madagascar
Climate: tropical
Terrain: NA
Natural resources: negligible
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
heavily wooded
Environment: wildlife sanctuary
Note: located in the Mozambique Channel
340 km west of Madagascar
Total area: 801,590 km2; land area:
784,090 km2
Comparative area: slightly less than twice
the size of California
Land boundaries: 4,571 km total; Malawi
1,569 km, South Africa 491 km, Swazi-
land 105 km, Tanzania 756 km, Zambia
419 km, Zimbabwe 1,231 km
Coastline: 2,470 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands
in center, high plateaus in northwest,
mountains in west
Natural resources: coal, titanium
Land use: 4% arable land; NEGL% per-
manent crops; 56% meadows and pastures;
20% forest and woodland; 20% other; in-
cludes NEGL% irrigated
Environment: severe drought and floods
occur in south; desertification','f71b524f458a3ac4d1d0e4f9790297df700c2f2861a5da472ddbbcbba4167c58','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4685e7d98728f4ac30fe2b2848d1b482a79645c17580f425c8469711471be83c',1981,'CG','Congo','geography',210,'Total area: 342,000 km2; land area:
341,500km2
Comparative area: slightly smaller than
Montana
Land boundaries: 5,504 km total; Angola
201 km, Cameroon 523 km, Central Afri-
can Republic 467 km, Gabon 1 ,903 km,
Zaire 2,410 km
Coastline: 169 km
Maritime claims:
Territorial sea: 200 nm
Disputes: long section with Zaire along
the Congo River is indefinite (no division
of the river or its islands has been made)
Climate: tropical; rainy season (March to
June); dry season (June to October); con-
stantly high temperatures and humidity;
particularly enervating climate astride the
Equator
Terrain: coastal plain, southern basin, cen-
tral plateau, northern basin
Natural resources: petroleum, timber, pot-
ash, lead, zinc, uranium, copper, phos-
phates, natural gas
Land use: 2% arable land; NEGL% per-
manent crops; 29% meadows and pastures;
62% forest and woodland; 7% other
Environment: deforestation; about 70% of
the population lives in Brazzaville, Pointe
Noire, or along the railroad between them','6347e2eeeef61446479a741d95c4e1593fbd8d8ac572f57a4efed210390156e5','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e570174c2844535899b180cd997b0f83def3ab04500c8468c31978ad6ab7dd3b',1981,'CK','Cook Islands','geography',214,'Total area: 240 km2; land area: 240 km2
Comparative area: slightly less than 1.5
times the size of Washington, DC
Land boundaries: none
Coastline: 120 km
Maritime claims:
Continental shelf: 200 meters or edge
of continental margin
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; moderated by trade
winds
Terrain: low coral atolls in north; volcanic,
hilly islands in south
Natural resources: negligible
Land use: 4% arable land; 22% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 74% other
Environment: subject to typhoons from
November to March
Note: located 4,500 km south of Hawaii
in the South Pacific Ocean
Total area: undetermined; includes numer-
ous small islands and reefs scattered over
a sea area of about 1 million km2, with
Willis Islets the most important
Comparative area: undetermined
Land boundaries: none
Coastline: 3,095 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical
Terrain: sand and coral reefs and islands
(or cays)
Natural resources: negligible
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other, mostly
grass or scrub cover; Lihou Reef Reserve
and Coringa-Herald Reserve were
declared National Nature Reserves on 3
August 1982
Environment: subject to occasional tropical
cyclones; no permanent fresh water; im-
portant nesting area for birds and turtles
Note: the islands are located just off the
northeast coast of Australia in the Coral
Sea','1f3421f10fe296e9dc8995a6e2610314a2a151cf6cb2c1d02af9ede699fb84f4','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd6ce1f302dcd8573a2e45729d9f7d01fbc2f5829e63225f7221bce3a0059885',1981,'CR','Costa Rica','geography',219,'Total area: 51,100 km2; land area: 50,660
km2; includes Isla del Coco
Comparative area: slightly smaller than
West Virginia
Land boundaries: 639 km total; Nicaragua
309 km, Panama 330 km
Coastline: 1,290 km
Maritime claims:
Continental shelf: 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; dry season (December to
April); rainy season (May to November)
Terrain: coastal plains separated by rug-
ged mountains
Natural resources: hydropower potential
Land use: 6% arable land; 7% permanent
crops; 45% meadows and pastures; 34%
forest and woodland; 8% other; includes
1% irrigated
Environment: subject to occasional earth-
quakes, hurricanes along Atlantic coast;
frequent flooding of lowlands at onset of
rainy season; active volcanoes; deforesta-
tion; soil erosion','28b18d638a408ac3c15d7ce3c9b5cff3fa3c0981c4ec0113708660d2a6037c02','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82949732687aa2e23ca02a6ffdc21dbb2d9d540077f81203de32b95fab9f03e5',1981,'CU','Cuba','geography',224,'Total area: 1 10,860 km2; land area:
110,860km2
Comparative area: slightly smaller than
Pennsylvania
Land boundary: 29. 1 km with US Naval
Base at Guantanamo; note — Guantanamo
is leased and as such remains part of
Coastline: 3,735 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: US Naval Base at Guantanamo
is leased to US and only mutual agree-
ment or US abandonment of the area can
terminate the lease
Climate: tropical; moderated by trade
winds; dry season (November to April);
rainy season (May to October)
Terrain: mostly flat to rolling plains with
rugged hills and mountains in the south-
east
Natural resources: cobalt, nickel, iron ore,
copper, manganese, salt, timber, silica
Land use: 23% arable land; 6% permanent
crops; 23% meadows and pastures; 17%
forest and woodland; 31% other; includes
10% irrigated
Environment: averages one hurricane every
other year
Note: largest country in Caribbean; 145
km south of Florida','b0db496931c28a101d0de0314cafaa11ae7ce2740a75743d6774e5ac869151dc','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b2cb3eda2e9c6ab4eed8a7f48d5caed251dee3773c3c67a341c7d8db8ed556f',1981,'CY','Cyprus','geography',228,'Total area: 9,250 km2; land area: 9,240
km2
Comparative area: about 0.7 times the size
of Connecticut
Land boundaries: none
Coastline: 648 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 1 2 nm
Disputes: 1974 hostilities divided the is-
land into two de facto autonomous ar-
eas— a Greek area controlled by the Cyp-
riot Government (60% of the island''s land
area) and a Turkish-Cypriot area (35% of
the island) that are separated by a narrow
UN buffer zone; in addition, there are two
UK sovereign base areas (about 5% of the
island''s land area)
Climate: temperate, Mediterranean with
hot, dry summers and cool, wet winters
Terrain: central plain with mountains to
north and south
Natural resources: copper, pyrites, asbes-
tos, gypsum, timber, salt, marble, clay
earth pigment
Land use: 40% arable land; 7% permanent
crops; 10% meadows and pastures; 18%
forest and woodland; 25% other; includes
10% irrigated (most irrigated lands are in
the Turkish-Cypriot area of the island)
Environment: moderate earthquake activ-
ity; water resource problems (no natural
reservoir catchments, seasonal disparity in
rainfall, and most potable resources con-
centrated in the Turkish-Cypriot area)
Total area: 127,870 km2; land area:
125,460km2
Comparative area: slightly larger than
New York State
Land boundaries: 3,446 km total; Austria
548 km, GDR 459 km, Hungary 676 km,
Poland 1,309 km, USSR 98 km, FRG 356
km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: Nagymaros Dam dispute with','6b7eabb7ffa70db186e7ec37fd7994cf102f25567bd851684ed7c5de120f1c40','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('767260108386374ba667cc14c39410f90468c4d6b7050d3d7e1e01bf482db12b',1981,'HU','Hungary','geography',232,'Climate: temperate; cool summers; cold,
cloudy, humid winters
Terrain: mixture of hills and mountains
separated by plains and basins
Natural resources: coal, timber, lignite,
uranium, magnesite, iron ore, copper, zinc
Land use: 40% arable land; 1% permanent
crops; 13% meadows and pastures; 37%
forest and woodland; 9% other; includes
1% irrigated
Environment: infrequent earthquakes; acid
rain; water pollution; air pollution
Note: landlocked; strategically located
astride some of oldest and most significant
land routes in Europe; Moravian Gate is a
traditional military corridor between the
North European Plain and the Danube in
central Europe
Total area: 93,030 km2; land area: 92,340
km2
Comparative area: slightly smaller than
Indiana
Land boundaries: 2,251 km total; Austria
366 km, Czechoslovakia 676 km, Roma-
nia 443 km, USSR 135 km, Yugoslavia
631 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: Transylvania question with Ro-
mania; Nagymaros Dam dispute with
Czechoslovakia
Climate: temperate; cold, cloudy, humid
winters; warm summers
Terrain: mostly flat to rolling plains
Natural resources: bauxite, coal, natural
gas, fertile soils
Land use: 54% arable land; 3% permanent
crops; 14% meadows and pastures; 18%
forest and woodland; 1 1 % other; includes
2% irrigated
Environment: levees are common along
many streams, but flooding occurs almost
every year
Note: landlocked; strategic location astride
main land routes between Western Europe
and Balkan Peninsula as well as between
USSR and Mediterranean basin','e7af4243f9ed543a4b296c6e2aa45225202344325ebc03d7cee9e8c588338efd','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e934040bd1743bde3cc5dd7bbfd30aca661901334f2c352b0c59fe87780a4773',1981,'DK','Denmark','geography',238,'Total area: 43,070 km2; land area: 42,370
km2; includes the island of Bornholtn in
the Baltic Sea and the rest of metropoli-
tan Denmark, but excludes the Faroe Is-
lands and Greenland
Comparative area: slightly more than
twice the size of Massachusetts
Land boundaries: 68 km with FRG
Coastline: 3,379 km
Maritime claims:
Contiguous zone: 4 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Disputes: Rockall continental shelf dispute
involving Iceland, Ireland, and the UK
(Ireland and the UK have signed a bound-
ary agreement in the Rockall area); Den-
mark has challenged Norway''s maritime
claims between Greenland and Jan Mayen
Climate: temperate; humid and overcast;
mild, windy winters and cool summers
Terrain: low and flat to gently rolling
plains
Natural resources: crude oil, natural gas,
fish, salt, limestone
Land use: 61% arable land; NEGL% per-
manent crops; 6% meadows and pastures;
12% forest and woodland; 21% other; in-
cludes 9% irrigated
Environment: air and water pollution
Note: controls Danish Straits linking Bal-
tic and North Seas','47e0a511eb57523bde9dd5aa3b1965c4bcc1b60efc4e57ebd93c9cfdaabaae2c','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('835c53a5aa07684bc7f48f757d721baca678e23117ea1ef2e8f54da8f20e924b',1981,'DJ','Djibouti','geography',244,'Total area: 22,000 km2; land area: 21,980
km2
Comparative area: slightly larger than
Massachusetts
Land boundaries: 517 km total; Ethiopia
459 km, Somalia 58 km
Coastline: 314 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Disputes: possible claim by Somalia based
on unification of ethnic Somalis
Climate: desert; torrid, dry
Terrain: coastal plain and plateau sepa-
rated by central mountains
Natural resources: geothermal areas
Land use: 0% arable land; 0% permanent
crops; 9% meadows and pastures;
NEGL% forest and woodland; 91% other
Environment: vast wasteland
Note: strategic location near world''s busi-
est shipping lanes and close to Arabian
oilfields; terminus of rail traffic into Ethio-
pia
Total area: 332,970 km2; land area:
332,970 km2; includes Perim, Socotra
Comparative area: slightly larger than
New Mexico
Land boundaries: 1,699 km total; Oman
288 km, Saudi Arabia 830 km, YAR 581
km
Coastline: 1,383 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: sections of boundary with YAR
indefinite or undefined; Administrative
Line with Oman; no defined boundary
with Saudi Arabia
Climate: desert; extraordinarily hot and
dry
Terrain: mostly upland desert plains; nar-
row, flat, sandy coastal plain backed by
flat-topped hills and rugged mountains
Natural resources: fish, oil, minerals (gold,
copper, lead)
Land use: 1% arable land; NEGL% per-
manent crops; 27% meadows and pastures;
7% forest and woodland; 65% other; in-
cludes NEGL% irrigated
Environment: scarcity of natural freshwa-
ter resources; overgrazing; soil erosion;
desertification
Note: controls southern approaches to Bab
el Mandeb linking Red Sea to Gulf of
Aden, one of world''s most active shipping
lanes','4b542f3aefd4eedf7e55c7093afcacb9203a2a936b5d7b65a0715daf525c0a3d','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a72a7fd211df900a2118a17c5bdbccba62b13e12cf5ee5d0f9bd411b6b485c7',1981,'DM','Dominica','geography',247,'Total area: 750 km2; land area: 750 km2
Comparative area: slightly more than four
times the size of Washington, DC
Land boundaries: none
Coastline: 148 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; moderated by northeast
trade winds; heavy rainfall
Terrain: rugged mountains of volcanic ori-
gin
Natural resources: timber
Land use: 9% arable land; 1 3% permanent
crops; 3% meadows and pastures; 41%
forest and woodland; 34% other
Environment: flash floods a constant haz-
ard; occasional hurricanes
Note: located 550 km southeast of Puerto
Rico in the Caribbean Sea','70a1f8599aee178813576590b9d8b32ee307ef66b4a79d392a024a89e8c4e550','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5622acb9c86609884991eda3353122679251c5398d197a2bcd2dfce3e8adf560',1981,'DO','Dominican Republic','geography',253,'Total area: 48,730 km2; land area: 48,380
km2
Comparative area: slightly more than
twice the size of New Hampshire
Land boundary 275 km with Haiti
Coastline: 1,288 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: outer edge of conti-
nental margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 6 nm
Climate: tropical maritime; little seasonal
temperature variation
Terrain: rugged highlands and mountains
with fertile valleys interspersed
Natural resources: nickel, bauxite, gold,
silver
Land use: 23% arable land; 7% permanent
crops; 43% meadows and pastures; 13%
forest and woodland; 14% other; includes
4% irrigated
Environment: subject to occasional hurri-
canes (July to October); deforestation
Note: shares island of Hispaniola with
Haiti (western one-third is Haiti, eastern
two-thirds is the Dominican Republic)','69b71201b4122aebe631d4acc8d5571f9682cea6ef09d3e2fc945802b32336ce','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25e8506ccb03e1bf13ed951965cfa5055a557e85a25bac47a0d5304799dbc164',1981,'EC','Ecuador','geography',257,'Total area: 283,560 km2; land area:
276,840 km2; includes Galapagos Islands
Comparative area: slightly smaller than
Nevada
Land boundaries: 2,010 km total; Colom-
bia 590 km, Peru 1,420 km
Coastline: 2,237 km
Maritime claims:
Continental shelf: 200 m
Territorial sea: 200 nm
Disputes: two sections of the boundary
with Peru are in dispute
Climate: tropical along coast becoming
cooler inland
Terrain: coastal plain (Costa),
inter-Andean central highlands (Sierra),
and flat to rolling eastern jungle (Oriente)
Natural resources: petroleum, fish, timber
Land use: 6% arable land; 3% permanent
crops; 17% meadows and pastures; 51%
forest and woodland; 23% other; includes
2% irrigated
Environment: subject to frequent earth-
quakes, landslides, volcanic activity; defor-
estation; desertification; soil erosion; peri-
odic droughts
Note: Cotopaxi in Andes is highest active
volcano in world','61284811c744a1ec1fb7adcb4e44ecc242bd647fdffbe2e8a81065935c116642','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acbcb86d2ca30482a98ec2a1723ef0cf9a69c5b2fef620937220815f5aaf7a1e',1981,'EG','Egypt','geography',261,'Total area: 1,001,450 km2; land area:
995,450 km2
Comparative area: slightly more than
three times the size of New Mexico
Land boundaries: 2,689 km total; Gaza
Strip 11, Israel 255 km, Libya 1,150 km,
Sudan 1,273 km
Coastline: 2,450 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: undefined
Territorial sea: 1 2 nm
Disputes: Administrative Boundary and
international boundary with Sudan
Climate: desert; hot, dry summers with
moderate winters
Terrain: vast desert plateau interrupted by
Nile valley and delta
Natural resources: crude oil, natural gas,
iron ore, phosphates, manganese, lime-
stone, gypsum, talc, asbestos, lead, zinc
Land use: 3% arable land; 2% permanent
crops; 0% meadows and pastures;
NEGL% forest and woodland; 95% other;
includes 5% irrigated
Environment: Nile is only perennial water
source; increasing soil salinization below
Aswan High Dam; hot, driving windstorm
called khamsin occurs in spring; water
pollution; desertification
Note: controls Sinai Peninsula, only land
bridge between Africa and remainder of
Eastern Hemisphere; controls Suez Canal,
shortest sea link between Indian Ocean
and Mediterranean; size and juxtaposition
to Israel establish its major role in Middle
Eastern geopolitics','c96047c114605bb382d03825abc6eb4f7e0ba367cec73686eddb2dfeeaac01db','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cac46e22b60984eb26b116fa20dd5a107134f70c2dfcaa71836ef04952b7d9f',1981,'SV','El Salvador','geography',265,'Total area: 21,040 km2; land area: 20,720
km2
Comparative area: slightly smaller than
Massachusetts
Land boundaries: 545 km total; Guate-
mala 203 km, Honduras 342 km
Coastline: 307 km
Maritime claims:
Territorial sea: 200 nm (overflight and
navigation permitted beyond 1 2 nm)
Disputes: several sections of the boundary
with Honduras are in dispute
Climate: tropical; rainy season (May to
October); dry season (November to April)
Terrain: mostly mountains with narrow
coastal belt and central plateau
Natural resources: hydropower and geo-
thermal power, crude oil
Land use: 27% arable land; 8% permanent
crops; 29% meadows and pastures; 6%
forest and woodland; 30% other; includes
5% irrigated
Environment: The Land of Volcanoes; sub-
ject to frequent and sometimes very de-
structive earthquakes; deforestation; soil
erosion; water pollution
Note: smallest Central American country
and only one without a coastline on Carib-
bean Sea','32dc6008ac382310579a511da6beb81f5081791642b4618f63c720f7d0bbd9fe','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92995610ff04c2169dc355a81774a1af7ae612302467ed8e57cda11f3cf4ac5b',1981,'GQ','Equatorial Guinea','geography',270,'Total area: 28,050 km2; land area: 28,050
km2
Comparative area: slightly larger than
Maryland
Land boundaries: 539 km total; Cameroon
189 km, Gabon 350 km
Coastline: 296 km
Maritime claims:
Exclusive economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: maritime boundary dispute with','e88d7c84454e7f19a708d2b5bc0d74badbb54e8cf1c29e3c1daaf8ba8f6acd30','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bd8875df11cfb9bd0c083be8a82133b457c60781184c6e10d4809381255b6db',1981,'GA','Gabon','geography',271,'Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills;
islands are volcanic
Natural resources: timber, crude oil, small
unexploited deposits of gold, manganese,
uranium
Land use: 8% arable land; 4% permanent
crops; 4% meadows and pastures; 51%
forest and woodland; 33% other
Environment: subject to violent windstorms
Note: insular and continental regions
rather widely separated
Total area: 7,7,81 km2; land ar§a: 7,781
km2; includes lie Amsterdam, He Saint-
Paul, lies Kerguelen, and lies Crozet; ex-
cludes claim not recognized by the US of
about 500,000 km2 in Antarctica known
as Terre Adelie
Comparative area: slightly less than 1 .5
times the size of Delaware
Land boundaries: none
Coastline: 1,232 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploration
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claim in Antarctica (Terre
Adelie) not recognized by the US
Climate: antarctic
Terrain: volcanic
Natural resources: fish, crayfish
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: lie Amsterdam and lie
Saint-Paul are extinct volcanoes
Note: located in the southern Indian
Ocean about equidistant between Africa,
Antarctica, and Australia','2f33d0a57c6ebb9cb291b1d6785eef311708eee65778be5f9860bfaeaa115dad','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7971ff4e769a66b13aae2b7ea6963353a74ebebaa58bcc65c4dd0c3bdba31de',1981,'ET','Ethiopia','geography',277,'Total area: 1,221,900 km2; land area:
1,101,000km2
Comparative area: slightly less than twice
the size of Texas
Land boundaries: 5,141 km total; Djibouti
459 km, Kenya 861 km, Somalia 1,600
km, Sudan 2,221 km
Coastline: 1,094km
Maritime claims:
Territorial sea: 1 2 nm
Disputes: southern half of the boundary
with Somalia is a Provisional Administra-
tive Line; possible claim by Somalia based
on unification of ethnic Somalis; territorial
dispute with Somalia over the Ogaden;
separatist movement in Eritrea; antigo-
vernment insurgencies in Tigray and other
areas
Climate: tropical monsoon with wide
topographic-induced variation; prone to
extended droughts
Terrain: high plateau with central moun-
tain range divided by Great Rift Valley
Natural resources: small reserves of gold,
platinum, copper, potash
Land use: 12% arable land; 1% permanent
crops; 41% meadows and pastures; 24%
forest and woodland; 22% other; includes
NEGL% irrigated
Environment: geologically active Great
Rift Valley susceptible to earthquakes,
volcanic eruptions; deforestation; overgraz-
ing; soil erosion; desertification; frequent
droughts; famine
Note: strategic geopolitical position along
world''s busiest shipping lanes and close to
Arabian oilfields; major resettlement
project ongoing in rural areas will signifi-
cantly alter population distribution and
settlement patterns over the next several
decades','4971813fb12c13831e58f3eaf9efa13c1a3406f130d5e01907946409355b0e8b','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('074e9bca41660ee2b52141e2792a5f19da635dbf415cdc928598eaf1a615806c',1981,'FO','Faroe Islands','geography',282,'Total area: 1 ,400 km2; land area: 1 ,400
km2
Comparative area: slightly less than eight
times the size of Washington, DC
Land boundaries: none
Coastline: 764 km
Maritime claims:
Contiguous zone: 4 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: mild winters, cool summers; usu-
ally overcast; foggy, windy
Terrain: rugged, rocky, some low peaks;
cliffs along most of coast
Natural resources: fish
Land use: 2% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 98% other
Environment: precipitous terrain limits
habitation to small coastal lowlands; ar-
chipelago of 18 inhabited islands and a
few uninhabited islets
Note: strategically located along impor-
tant sea lanes in northeastern Atlantic
about midway between Iceland and Shet-
land Islands','dd206ba18ed106c62f14132cc0a67dbb404a4c88ecffc5fb4bde7b4d1c5418d3','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d46c94a3fd0a174b109ba1d3101b18508d8473d6bbf84baf01dd96fb6d4e68d',1981,'FJ','Fiji','geography',286,'Total area: 18,270 km2; land area: 18,270
km2
Comparative area: slightly smaller than
New Jersey
Land boundaries: none
Coastline: 1,129 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical marine; only slight sea-
sonal temperature variation
Terrain: mostly mountains of volcanic ori-
gin
Natural resources: timber, fish, gold, cop-
per; offshore oil potential
Land use: 8% arable land; 5% permanent
crops; 3% meadows and pastures; 65%
forest and woodland; 19% other; includes
NEGL% irrigated
Environment: subject to hurricanes from
November to January; includes 332 is-
lands of which approximately 1 10 are in-
habited
Note: located 2,500 km north of New
Zealand in the South Pacific Ocean','64f6aca38ac256e6fc2c972fd2ed814b363fd633c664900b481cf65bd7bbe515','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('212a0b8bd5a50e7ebb80f445760c8f8079720ca2be00e018fc3ed8a9c059f429',1981,'FI','Finland','geography',292,'Total area: 337,030 km2; land area:
305,470 km2
Comparative area: slightly smaller than
Montana
Land boundaries: 2,578 km total; Norway
729 km, Sweden 536 km, USSR 1,313 km
Coastline: 1 , 1 26 km excluding islands and
coastal indentations
Maritime claims:
Contiguous zone: 6 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 12 nm
Territorial sea: 4 nm
Climate: cold temperate; potentially sub-
arctic, but comparatively mild because of
moderating influence of the North Atlan-
tic Current, Baltic Sea, and more than
60,000 lakes
Terrain: mostly low, flat to rolling plains
interspersed with lakes and low hills
Natural resources: timber, copper, zinc,
iron ore, silver
Land use: 8% arable land; 0% permanent
crops; NEGL% meadows and pastures;
76% forest and woodland; 16% other; in-
cludes NEGL% irrigated
Environment: permanently wet ground
covers about 30% of land; population con-
centrated on small southwestern coastal
plain
Note: long boundary with USSR; Helsinki
is northernmost national capital on Euro-
pean continent','768f42b9f3a6379cfcf28f8d4bd9038b1fb182c256b8c0aacdf6eca8876caffe','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('666704c7b862dff75bddc02cb6a2d2e265b71d47051a8b9834466ad81cdbad2b',1981,'GF','French Guiana','geography',299,'Total area: 91,000 km2; land area: 89,150
km2
Comparative area: slightly smaller than
Indiana
Land boundaries: 1,183 km total; Brazil
673 km, Suriname 510 km
Coastline: 378 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: Suriname claims area between
Riviere Litani and Riviere Marouini (both
headwaters of the Lawa)
Climate: tropical; hot, humid; little sea-
sonal temperature variation
Terrain: low-lying coastal plains rising to
hills and small mountains
Natural resources: bauxite, timber, gold
(widely scattered), cinnabar, kaolin, fish
Land use: NEGL% arable land; NEGL%
permanent crops; NEGL% meadows and
pastures; 82% forest and woodland; 18%
other
Environment: mostly an unsettled wilder-
ness','af6943682f532f72ea424a74529f0c89cf573be42457a642c5d3093ee36461a9','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9710d850fe2c870db5bea7ec977854c4d9bd15736b54183e56f9f75cb40ee333',1981,'GN','Guinea','geography',307,'Total area: 267,670 km2; land area:
257,670 km2
Comparative area: slightly smaller than
Colorado
Land boundaries: 2,551 km total; Came-
roon 298 km, Congo 1 ,903 km, Equatorial
Guinea 350 km
Coastline: 885 km
Maritime claims:
Contiguous zone: 24 nm
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Disputes: maritime boundary with Equato-
rial Guinea
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly inte-
rior; savanna in east and south
Natural resources: crude oil, manganese,
uranium, gold, timber, iron ore
Land use: 1% arable land; 1% permanent
crops; 18% meadows and pastures; 78%
forest and woodland; 2% other
Environment: deforestation
Total area: 1 1,300 km2; land area: 10,000
km2
Comparative area: slightly more than
twice the size of Delaware
Land boundary: 740 km with Senegal
Coastline: 80 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: not specific
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Disputes: short section of boundary with
Senegal is indefinite
Climate: tropical; hot, rainy season (June
to November); cooler, dry season
(November to May)
Terrain: flood plain of the Gambia River
flanked by some low hills
Natural resources: fish
Land use: 1 6% arable land; 0% permanent
crops; 9% meadows and pastures; 20%
forest and woodland; 55% other; includes
3% irrigated
Environment: deforestation
Note: almost an enclave of Senegal; small-
est country on the continent of Africa
Total area: 380km2; land area: 380 km2
Comparative area: slightly more than
twice the size of Washington, DC
Land boundaries: 62 km total; Egypt 1 1
km, Israel 51 km
Coastline: 40 km
Maritime claims: Israeli occupied with
status to be determined
Disputes: Israeli occupied with status to
be determined
Climate: temperate, mild winters, dry and
warm to hot summers
Terrain: flat to rolling, sand and dune cov-
ered coastal plain
Natural resources: negligible
Land use: 13% arable land, 32% perma-
nent crops, 0% meadows and pastures, 0%
forest and woodland, 55% other
Environment: desertification
Note: there are 1 8 Jewish settlements in
the Gaza Strip
Total area: 108,330 km2; land area:
105,980 km2
Comparative area: slightly smaller than
Tennessee
Land boundaries: 2,296 km total; Czecho-
slovakia 459 km, Poland 456 km, FRG
1,381 km
Coastline: 901 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Disputes: it is US policy that the final
borders of Germany have not been estab-
lished; the US is seeking to settle the
property claims of US nationals against
the GDR
Climate: temperate; cloudy, cold winters
with frequent rain and snow; cool, wet
summers
Terrain: mostly flat plain with hills and
mountains in south
Natural resources: lignite, potash, ura-
nium, copper, natural gas, salt, nickel
Land use: 45% arable land; 3% permanent
crops; 12% meadows and pastures; 28%
forest and woodland; 1 2% other; includes
2% irrigated
Environment: significant deforestation in
mountains caused by air pollution and
acid rain
Note: strategic location on North Euro-
pean Plain and near the entrance to the
Baltic Sea; West Berlin is an enclave
(about 1 16 km by air or 176 km by road
from FRG)
Total area: 245,860 km2; land area:
245,860 km2
Comparative area: slightly smaller than
Oregon
Land boundaries: 3,399 km total; Guinea-
Bissau 386 km. Ivory Coast 610 km, Libe-
ria 563 km, Mali 858 km, Senegal 330
km, Sierra Leone 652 km
Coastline: 320 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: generally hot and humid;
monsoonal-type rainy season (June to No-
vember) with southwesterly winds; dry
season (December to May) with northeast-
erly harmattan winds
Terrain: generally flat coastal plain, hilly
to mountainous interior
Natural resources: bauxite, iron ore, dia-
monds, gold, uranium, hydropower, fish
Land use: 6% arable land; NEGL% per-
manent crops; 1 2% meadows and pastures;
42% forest and woodland; 40% other; in-
cludes NEGL% irrigated
Environment: hot, dry, dusty harmattan
haze may reduce visibility during dry sea-
son; deforestation
Total area: 1,919,440 km2; land area:
1,826,440km2
Comparative area: slightly less than three
times the size of Texas
Land boundaries: 2,602 km total; Malay-
sia 1,782 km, Papua New Guinea 820 km
Coastline: 54,716 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: to depth of exploita-
tion
Extended economic zone: 200 nm Ter-
ritorial sea: 1 2 nm
Disputes: East Timor question with Portu-
gal
Climate: tropical; hot, humid; more mod-
erate in highlands
Terrain: mostly coastal lowlands; larger
islands have interior mountains
Natural resources: crude oil, tin, natural
gas, nickel, timber, bauxite, copper, fertile
soils, coal, gold, silver
Land use: 8% arable land; 3% permanent
crops; 7% meadows and pastures; 67%
forest and woodland; 1 5% other; includes
3% irrigated
Environment: archipelago of 1 3,500 islands
(6,000 inhabited); occasional floods, severe
droughts, and tsunamis; deforestation
Note: straddles Equator; strategic location
astride or along major sea lanes from In-
dian Ocean to Pacific Ocean
Total area: 960 km2; land area: 960 km2
Comparative area: slightly less than 5.5
times the size of Washington, DC
Land boundaries: none
Coastline: 209 km
Maritime claims: (measured from claimed
archipelagic baselines)
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; hot, humid; one rainy
season (October to May)
Terrain: volcanic, mountainous
Natural resources: fish
Land use: 1% arable land; 20% permanent
crops; 1% meadows and pastures; 75%
forest and woodland; 3% other
Environment: deforestation; soil erosion
Note: located south of Nigeria and west of
Gabon near the Equator in the North At-
lantic Ocean','bdbe466d5e1162378829a48b103007eb46bfdcf145501bc7b6fd18008a126ab9','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec007944cd28af4476d16e577eb2ceb73e6f2d90dd05e279a9f0d49a8201acf7',1981,'RO','Romania','geography',311,'Total area: 248,580 km2; land area:
244,280 km2; includes West Berlin
Comparative area: slightly smaller than
Oregon
Land boundaries: 4,256 km total; Austria
784 km, Belgium 167 km, Czechoslovakia
356 km, Denmark 68 km, France 451 km,
GDR 1,381 km; Luxembourg 138 km,
Netherlands 577 km, Switzerland 334 km
Coastline: 1,488 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm (extends, at one
point, to 16 nm in the Helgolander
Bucht)
Disputes: it is US policy that the final
borders of Germany have not been estab-
lished
Climate: temperate and marine; cool,
cloudy, wet winters and summers; occa-
sional warm, tropical foehn wind; high
relative humidity
Terrain: lowlands in north, uplands in cen-
ter, Bavarian Alps in south
Natural resources: iron ore, coal, potash,
timber
Land use: 30% arable land; 1% permanent
crops; 1 9% meadows and pastures; 30%
forest and woodland; 20% other; includes
1% irrigated
Environment: air and water pollution
Note: West Berlin is an exclave (about
1 1 6 km by air or 1 76 km by road from
FRG)','9196a34ab77a791506f4c5634901ebc339d3c150d70a1ab88063e4c2c6fcb054','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('551f6bee390af1acd339802c14dbb7bd3e18437f6bbf6eb5a851fd31a1fcf8d8',1981,'GH','Ghana','geography',315,'Total area: 238,540 km2; land area:
230,020 km2
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,093 km total; Burkina
548 km, Ivory Coast 668 km, Togo 877
km
Coastline: 539 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 nm
Exclusive economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; warm and comparatively
dry along southeast coast; hot and humid
in southwest; hot and dry in north
Terrain: mostly low plains with dissected
plateau in south-central area
Natural resources: gold, timber, industrial
diamonds, bauxite, manganese, fish, rub-
ber
Land use: 5% arable land; 7% permanent
crops; 1 5% meadows and pastures; 37%
forest and woodland; 36% other; includes
NEGL% irrigated
Environment: recent drought in north se-
verely affecting marginal agricultural ac-
tivities; deforestation; overgrazing; soil
erosion; dry, northeasterly harmattan wind
(January to March)
Note: Lake Volta is world''s largest artifi-
cial lake','350ff7e31350f22b68b86e97d183f1c3a77ce2fac2c308ebe37bdb62341c3207','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('631b930214c8f00487da1e499558753ac4879fe6f7d4fca02fe297ad42f262e9',1981,'GI','Gibraltar','geography',320,'Total area: 6.5 km2; land area: 6.5 km2
Comparative area: about 1 1 times the size
of The Mall in Washington, DC
Land boundaries: 1.2 km with Spain
Coastline: 12 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 3 nm
Territorial sea: 3 nm
Disputes: source of occasional friction be-
tween Spain and the UK
Climate: Mediterranean with mild winters
and warm summers
Terrain: a narrow coastal lowland borders
The Rock
Natural resources: negligible
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: natural freshwater sources
are meager so large water catchments
(concrete or natural rock) collect rain wa-
ter
Note: strategic location on Strait of Gi-
braltar that links the North Atlantic
Ocean and Mediterranean Sea
Total area: 5 km2; land area: 5 km2; in-
cludes lie Glorieuse, lie du Lys, Verte
Rocks, Wreck Rock, and South Rock
Comparative area: about 8.5 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 35.2 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf :2QQ meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Disputes: claimed by Madagascar
Climate: tropical
Terrain: undetermined
Natural resources: guano, coconuts
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other — lush vege-
tation and coconut palms
Environment: subject to periodic cyclones
Note: located in the Indian Ocean just
north of the Mozambique Channel be-
tween Africa and Madagascar
Total area: 504,750 km2; land area:
499,400 km2; includes Balaeric Islands,
Canary Islands, Ceuta, Mellila, bias Cha-
farinas, Penon de Alhucemas, and Penon
de Velez de la Gomera
Comparative area: slightly more than
twice the size of Oregon
Land boundaries: 1,903.2 km total; An-
dorra 65 km, France 623 km, Gibraltar
1.2 km, Portugal 1,214 km
Coastline: 4,964 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: Gibraltar question with UK;
controls two presidios or places of sover-
eignty (Ceuta and Melilla) on the north
coast of Morocco
Climate: temperate; clear, hot summers in
interior, more moderate and cloudy along
coast; cloudy, cold winters in interior,
partly cloudy and cool along coast
Terrain: large, flat to dissected plateau
surrounded by rugged hills; Pyrenees in
north
Natural resources: coal, lignite, iron ore,
uranium, mercury, pyrites, fluorspar, gyp-
sum, zinc, lead, tungsten, copper, kaolin,
potash, hydropower
Land use: 31% arable land; 10% perma-
nent crops; 21% meadows and pastures;
31% forest and woodland; 7% other; in-
cludes 6% irrigated
Environment: deforestation; air pollution
Note: strategic location along approaches
to Strait of Gibraltar','cbda2010636641dbe839f04df89cda4c31f2f1b4c179803a52d3337d41e778ea','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f824554801d31fb470f6f803dd2668d8334b2fce749a334ce5311fb27247f7b5',1981,'GL','Greenland','geography',327,'Total area: 2,175,600 km2; land area:
34 1,700 km2 (ice free)
Comparative area: slightly more than
three times the size of Texas
Land boundaries: none
Coastline: 44,087 km
Maritime claims:
Contiguous zone: 4 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Disputes: Denmark has challenged Nor-
way''s maritime claims between Greenland
and Jan Mayen
Climate: arctic to subarctic; cool summers,
cold winters
Terrain: flat to gradually sloping icecap
covers all but a narrow, mountainous, bar-
ren, rocky coast
Natural resources: zinc, lead, iron ore,
coal, molybdenum, cryolite, uranium, fish
Land use: 0% arable land; 0% permanent
crops; 1% meadows and pastures;
NEGL% forest and woodland; 99% other
Environment: sparse population confined to
small settlements along coast; continuous
permafrost over northern two-thirds of the
island
Note: dominates North Atlantic Ocean
between North America and Europe','7eb226045a353f7b6f96506ed80abd2bfbbf8651fdcbe18d7e3ec1a0874d9161','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b2ef1ba43eebaece1ab969aa2b9a69cd023dc2c1a2ec81a0e7e414d3523a76f',1981,'GD','Grenada','geography',332,'Total area: 340 km2; land area: 340 km2
Comparative area: slightly less than twice
the size of Washington, DC
Land boundaries: none
Coastline: 121 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; tempered by northeast
trade winds
Terrain: volcanic in origin with central
mountains
Natural resources: timber, tropical fruit,
deepwater harbors
Land use: 1 5% arable land; 26% perma-
nent crops; 3% meadows and pastures; 9%
forest and woodland; 47% other
Environment: lies on edge of hurricane
belt; hurricane season lasts from June to
November
Note: islands of the Grenadines group are
divided politically with St. Vincent and
the Grenadines','8a55ceacaa6238246fa7df3d721399687c620a68a21b27b4b00512e4d8032682','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2650bf4f22715d91dd33e67c7d0ecee5486255ddd0faa5bb4fd1d8252de54f8',1981,'GP','Guadeloupe','geography',338,'Total area: 1,780 km2; land area: 1,760
km2
Comparative area: 10 times the size of
Washington, DC
Land boundaries: 14 km with Netherlands
Antilles
Coastline: 306 km
Maritime claims:
Contijienlal shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: subtropical tempered by trade
winds; relatively high humidity
Terrain: Basse-Terre is volcanic in origin
with interior mountains; Grand-Terre is
low limestone formation
Natural resources: cultivable land,
beaches, and climate that foster tourism
Land use: 18% arable land; 5% permanent
crops; 13% meadows and pastures; 40%
forest and woodland; 24% other; includes
1% irrigated
Environment: subject to hurricanes (June
to October); La Soufriere is an active vol-
cano
Note: located 500 km southeast of Puerto
Rico in the Caribbean Sea','5976e306cc033adb1c2c589fa746dccc79aa5eb0af420747c53a269ed97334c7','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86badca0e6c9a0d35f881fb074c76e9e1b3431820d6e22741680706311f4ce95',1981,'GU','Guam','geography',341,'Total area: 541 km2; land area: 541 km2
Comparative area: slightly more than
three times the size of Washington, DC
Land boundaries: none
Coastline: 125.5 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical marine; generally warm
and humid, moderated by northeast trade
winds; dry season from January to June,
rainy season from July to December; little
seasonal temperature variation
Terrain: volcanic origin, surrounded by
coral reefs; relatively flat coraline lime-
stone plateau (source of most fresh water)
with steep coastal cliffs and narrow
coastal plains in north, low-rising hills in
center, mountains in south
Natural resources: fishing (largely undevel-
oped), tourism (especially from Japan)
Land use: 1 1% arable land; 1 1% perma-
nent crops; 1 5% meadows and pastures;
1 8% forest and woodland; 45% other
Environment: frequent squalls during rainy
season; subject to relatively rare, but po-
tentially very destructive typhoons (espe-
cially in August)
Note: largest and southernmost island in
the Mariana Islands archipelago; strategic
location in western North Pacific Ocean
5,955 km west-southwest of Honolulu
about three-quarters of the way between
Hawaii and the Philippines','9ae3b3cd715ae19b2359444dd3a842dc8b37c1664b7a46917d86096483388c9f','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1036db43d4141c3abd82fa8f7a2065edd8caf6537fb1e62f40bd95fd44226d5',1981,'GT','Guatemala','geography',346,'Total area: 108,890 km2; land area:
108,430 km2
Comparative area: slightly smaller than
Tennessee
Land boundaries: 1 ,687 km total; Belize
266 km, El Salvador 203 km, Honduras
256 km, Mexico 962 km
Coastline: 400 km
Maritime claims:
Continental shelf: not specific
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claims Belize, but boundary ne-
gotiations are under way
Climate: tropical; hot, humid in lowlands;
cooler in highlands
Terrain: mostly mountains with narrow
coastal plains and rolling limestone pla-
teau (Peten)
Natural resources: crude oil, nickel, rare
woods, fish, chicle
Land use: 12% arable land; 4% permanent
crops; 12% meadows and pastures; 40%
forest and woodland; 32% other; includes
1% irrigated
Environment: numerous volcanoes in
mountains, with frequent violent earth-
quakes; Caribbean coast subject to hurri-
canes and other tropical storms; deforesta-
tion; soil erosion; water pollution
Note: no natural harbors on west coast','3359ccac890869763a8c6835737f29caa8582a17879c2b2283d78992a2d29512','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d77b1080200c8419ec5d17e7dfaf1cd08d114fbc8876e505e5247700e1e41950',1981,'GG','Guernsey','geography',351,'Total area: 194 km2; land area: 194 km2;
includes Alderney, Guernsey, Herm, Sark,
and some other smaller islands
Comparative area: slightly larger than
Washington, DC
Land boundaries: none
Coastline: SO km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: temperate with mild winters and
cool summers; about 50% of days are
overcast
Terrain: mostly level with low hills in
southwest
Natural resources: cropland
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
about 50% cultivated
Environment: large, deepwater harbor at
St. Peter Port
Note: 52 km west of France','6898ba3ba0610a6315ab187505220725b6906d04699dfb0f0637c3020ae75508','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39b0f40e8bc09e798b19af1beb140223d21d2375bbb945db241c9ee4d90a0a30',1981,'GW','Guinea-Bissau','geography',357,'Total area: 36,120 km2; land area: 28,000
km2
Comparative area: slightly less than three
times the size of Connecticut
Land boundaries: 724 km total; Guinea
386, Senegal 338 km
Coastline: 350 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: the International Court of Jus-
tice (ICJ) has rendered its decision on the
Guinea-Bissau/Senegal maritime bound-
ary (in favor of Senegal) — that decision
has been rejected by Guinea-Bissau
Climate: tropical; generally hot and hu-
mid; monsoon-type rainy season (June to
November) with southwesterly winds; dry
season (December to May) with northeast-
erly harmattan winds
Terrain: mostly low coastal plain rising to
savanna in east
Natural resources: unexploited deposits of
petroleum, bauxite, phosphates; fish, tim-
ber
Land use: 1 1% arable land; 1% permanent
crops; 43% meadows and pastures; 38%
forest and woodland; 7% other
Environment: hot, dry, dusty harmattan
haze may reduce visibility during dry sea-
son','662d483f00159a66e00125229f168f711f3f5cd57fbda5836b22645b5c18efce','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35bee900b5577462a732c22c0ab50dceb5769f28c10beac7246d2d59e2111d4a',1981,'GY','Guyana','geography',361,'Total area: 214,970 km2; land area:
196,850 km2
Comparative area: slightly smaller than
Idaho
Land boundaries: 2,462 km total; Brazil
1,119 km, Suriname 600 km, Venezuela
743 km
Coastline: 459 km
Maritime claims:
Continental shelf: outer edge of conti-
nental margin or 200 nm
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Disputes: Essequibo area claimed by Ven-
ezuela; Suriname claims area between
New (Upper Courantyne) and Courantyne/
Kutari Rivers (all headwaters of the Cou-
rantyne)
Climate: tropical; hot, humid, moderated
by northeast trade winds; two rainy sea-
sons (May to mid-August, mid-November
to mid- January)
Terrain: mostly rolling highlands; low
coastal plain; savanna in south
Natural resources: bauxite, gold,
diamonds, hardwood timber, shrimp, fish
Land use: 3% arable land; NEGL% per-
manent crops; 6% meadows and pastures;
83% forest and woodland; 8% other; in-
cludes 1% irrigated
Environment: flash floods a constant threat
during rainy seasons; water pollution','e5c11f074fe9b7696480694d18a05c9afe82284ff6272c7aa70577dacc387917','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8773406ded3298e4deb7cf328c5b46fdc0bc35a2d016e856591651daaf82cee0',1981,'HT','Haiti','geography',367,'Total area: 27,750 km2; land area: 27,560
km2
Comparative area: slightly larger than
Maryland
Land boundary: 275 km with the Domini-
can Republic
Coastline: 1,771 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: to depth of exploita-
tion
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claims US-administered Na-
vassa Island
Climate: tropical; semiarid where moun-
tains in east cut off trade winds
Terrain: mostly rough and mountainous
Natural resources: bauxite
Land use: 20% arable land; 13% perma-
nent crops; 18% meadows and pastures;
4% forest and woodland; 45% other; in-
cludes 3% irrigated
Environment: lies in the middle of the hur-
ricane belt and subject to severe storms
from June to October; occasional flooding
and earthquakes; deforestation
Note: shares island of Hispaniola with Do-
minican Republic
Total area: 412 km2; land area: 412 km2
Comparative area: slightly less than 2.5
times the size of Washington, DC
Land boundaries: none
Coastline: 101.9 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploration
Exclusive fishing zone: 200 nm Territo-
rial sea: 3 nm
Climate: antarctic
Terrain: Heard Island — bleak and moun-
tainous, with an extinct volcano; McDon-
ald Islands — small and rocky
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: primarily used as research
stations
Note: located 4, 1 00 km southwest of Aus-
tralia in the southern Indian Ocean','7f8fc360aeba60e9b8fbe502dfb66bc8e3444438202a741075c2d36352b7b03f','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd68b6a7f0fc1352cbcb38ebacbc76c49e02b3e456ff142ccdb1976493126882',1981,'HN','Honduras','geography',371,'Total area: 112,090 km2; land area:
111,890km2
Comparative area: slightly larger than
Tennessee
Land boundaries: 1,520 km total; Guate-
mala 256 km, El Salvador 342 km, Nica-
ragua 922 km
Coastline: 820 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: several sections of the boundary
with El Salvador are in dispute
Climate: subtropical in lowlands, temper-
ate in mountains
Terrain: mostly mountains in interior, nar-
row coastal plains
Natural resources: timber, gold, silver,
copper, lead, zinc, iron ore, antimony,
coal, fish
Land use: 14% arable land; 2% permanent
crops; 30% meadows and pastures; 34%
forest and woodland; 20% other; includes
1% irrigated
Environment: subject to frequent, but gen-
erally mild, earthquakes; damaging hurri-
canes along Caribbean coast; deforesta-
tion; soil erosion','2b1471c222614688a824bfb7bc3bbbb60d86e449fefce4151f3a81482459f20b','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dac49eb6f9eac021ab7cabb15733e8426cef56c6a3a061252ae739d6dd654494',1981,'HK','Hong Kong','geography',377,'Total area: 1,040 km2; land area: 990 km2
Comparative area: slightly less than six
times the size of Washington, DC
Land boundary: 30 km with China
Coastline: 733 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 3 nm
Territorial sea: 3 nm
Disputes: scheduled to become a Special
Administrative Region of China in 1997
Climate: tropical monsoon; cool and hu-
mid in winter, hot and rainy from spring
through summer, warm and sunny in fall
Terrain: hilly to mountainous with steep
slopes; lowlands in north
Natural resources: outstanding deepwater
harbor, feldspar
Land use: 7% arable land; 1% permanent
crops; 1% meadows and pastures; 12%
forest and woodland; 79% other; includes
3% irrigated
Environment: more than 200 islands; occa-
sional typhoons
Total area: 1.6 km2; land area: 1.6 km2
Comparative area: about 2.7 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 6.4 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: equatorial; scant rainfall, con-
stant wind, burning sun
Terrain: low-lying, nearly level, sandy,
coral island surrounded by a narrow fring-
ing reef; depressed central area
Natural resources: guano (deposits worked
until late 1800s)
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 5% for-
est and woodland; 95% other
Environment: almost totally covered with
grasses, prostrate vines, and low-growing
shrubs; small area of trees in the center;
lacks fresh water; primarily a nesting,
roosting, and foraging habitat for
seabirds, shorebirds, and marine wildlife;
feral cats
Note: remote location 2,575 km southwest
of Honolulu in the North Pacific Ocean,
just north of the Equator, about halfway
between Hawaii and Australia
Total area: 4,066 km2; land area: 4,066
km2; includes Shag and Clerke Rocks
Comparative area: slightly larger than
Rhode Island
Land boundaries: none
Coastline: undetermined
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Disputes: administered by the UK,
claimed by Argentina
Climate: variable, with mostly westerly
winds throughout the year, interspersed
with periods of calm; nearly all precipita-
tion falls as snow
Terrain: most of the islands, rising steeply
from the sea, are rugged and mountain-
ous; South Georgia is largely barren and
has steep, glacier-covered mountains; the
South Sandwich Islands are of volcanic
origin with some active volcanoes
Natural resources: fish
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other; largely
covered by permanent ice and snow with
some sparse vegetation consisting of grass,
moss, and lichen
Environment: reindeer, introduced early in
this century, live on South Georgia;
weather conditions generally make it diffi-
cult to approach the South Sandwich Is-
lands; the South Sandwich Islands are
subject to active volcanism
Note: the north coast of South Georgia
has several large bays, which provide good
anchorage
Total area: 22,402,200 km2; land area:
22,272,000 km2
Comparative area: slightly less than 2.5
times the size of US
Land boundaries: 19,933 km total; Af-
ghanistan 2,384 km, Czechoslovakia 98
km, China 7,520 km, Finland 1,313 km,
Hungary 1 35 km, Iran 1 ,690 km. North
Korea 17 km, Mongolia 3,441 km, Nor-
way 196 km, Poland 1,215 km, Romania
1,307km, Turkey 617 km
Coastline: 42,777 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: bilateral negotiations are under
way to resolve four disputed sections of
the boundary with China (Pamir, Argun,
Amur, and Khabarovsk areas); US Gov-
ernment has not recognized the incorpora-
tion of Estonia, Latvia, and Lithuania into
the Soviet Union; Habomai Islands, Eto-
rofu, Kunashiri, and Shikotan islands oc-
cupied by Soviet Union since 1945,
claimed by Japan; Kuril Islands adminis-
tered by Soviet Union; maritime dispute
with Norway over portion of Barents Sea;
has made no territorial claim in Antarc-
tica (but has reserved the right tc do so)
and does not recognize the claims of any
other nation; Bessarabia question with
Romania; Kurdish question among Iran,
Iraq, Syria, Turkey, and the USSR
Climate: mostly temperate to arctic conti-
nental; winters vary from cool along Black
Sea to frigid in Siberia; summers vary
from hot in southern deserts to cool along
Arctic coast
Terrain: broad plain with low hills west of
Urals; vast coniferous forest and tundra in
Siberia, deserts in Central Asia, moun-
tains in south
286
Natural resources: self-sufficient in oil,
natural gas, coal, and strategic minerals
(except bauxite, alumina, tantalum, tin,
tungsten, fluorspar, and molybdenum),
timber, gold, manganese, lead, zinc,
nickel, mercury, potash, phosphates
Land use: 10% arable land; NEGL% per-
manent crops; 1 7% meadows and pastures;
41% forest and woodland; 32% other; in-
cludes 1% irrigated
Environment: despite size and diversity,
small percentage of land is arable and
much is too far north; some of most fertile
land is water deficient or has insufficient
growing season; many better climates have
poor soils; hot, dry, desiccating sukhovey
wind affects south; desertification; contin-
uous permafrost over much of Siberia is a
major impediment to development
Note: largest country in world, but unfa-
vorably located in relation to major sea
lanes of world','58afd27989cfe7d88acf3eda7e7120fcce59a312ff7c438da8c32640ce7b5e00','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad40feb68486a5e51d12bb9c87cc30f1a5d9e22b2543aa90d7cbc89dc6834afa',1981,'IS','Iceland','geography',382,'Total area: 103,000 km2; land area:
100,250 km2
Comparative area: slightly smaller than
Kentucky
Land boundaries: none
Coastline: 4,988 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: Rockall continental shelf dispute
involving Denmark, Ireland, and the UK
(Ireland and the UK have signed a bound-
ary agreement in the Rockall area)
Climate: temperate; moderated by North
Atlantic Current; mild, windy winters;
damp, cool summers
Terrain: mostly plateau interspersed with
mountain peaks, icefields; coast deeply
indented by bays and fiords
Natural resources: fish, hydroelectric and
geothermal power, diatomite
Land use: NEGL% arable land; 0% per-
manent crops; 23% meadows and pastures;
1% forest and woodland; 76% other
Environment: subject to earthquakes and
volcanic activity
Note: strategic location between Green-
land and Europe; westernmost European
country','c4f7ae01e877ba1acd717f1b4a79fe9d821d43fb1ee96a463839d4b787c66eae','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('271ffa1906555e85fa92e8e5ecacc2e1e389e89e878d660ff057a96a2db4fdbb',1981,'IN','India','geography',386,'Total area: 3,287,590 km2; land area:
2,973,190 km2
Comparative area: slightly more than one-
third the size of the US
Land boundaries: 14,103 km total; Bangla-
desh 4,053 km, Bhutan 605 km, Burma
1,463 km, China 3,380, Nepal 1,690 km,
Pakistan 2,912 km
Coastline: 7,000 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Disputes: boundaries with Bangladesh,
China, and Pakistan; water sharing prob-
lems with downstream riparians, Bangla-
desh over the Ganges and Pakistan over
the Indus
Climate: varies from tropical monsoon in
south to temperate in north
Terrain: upland plain (Deccan Plateau) in
south, flat to rolling plain along the
Ganges, deserts in west, Himalayas in
north
Natural resources: coal (fourth-largest re-
serves in the world), iron ore, manganese,
mica, bauxite, titanium ore, chromite, nat-
ural gas, diamonds, crude oil, limestone
Land use: 55% arable land; 1% permanent
crops; 4% meadows and pastures; 23%
forest and woodland; 17% other; includes
13% irrigated
Environment: droughts, flash floods, severe
thunderstorms common; deforestation; soil
erosion; overgrazing; air and water pollu-
tion; desertification
Note: dominates South Asian subconti-
nent; near important Indian Ocean trade
routes','79aeaf518a80247fa1279333b0006fbb46eb3f39daab369b7c8f963771f9b365','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb5680f8170249d9d2e3f2543c1ebfef76370172683caea7dbab6ff89c2d4ff6',1981,'PK','Pakistan','geography',389,'Total area: 73,600,000 km2; Arabian Sea,
Bass Strait, Bay of Bengal, Java Sea, Per-
sian Gulf, Red Sea, Strait of Malacca,
Timor Sea, and other tributary water bod-
ies
Comparative area: slightly less than eight
times the size of the US; third-largest
ocean (after the Pacific Ocean and Atlan-
tic Ocean, but larger than the Arctic
Ocean)
Coastline: 66,526 km
Climate: northeast monsoon (December to
April), southwest monsoon (June to Octo-
ber); tropical cyclones occur during May/
June and October/November in the north
Indian Ocean and January/ February in
the south Indian Ocean
Terrain: surface dominated by counter-
clockwise gyre (broad, circular system of
currents) in the south Indian Ocean;
unique reversal of surface currents in the
north Indian Ocean — low pressure over
southwest Asia from hot, rising, summer
air results in the southwest monsoon and
southwest-tc-northeast winds and currents,
while high pressure over northern Asia
from cold, falling, winter air results in the
northeast monsoon and
northeast-to-southwest winds and currents;
ocean floor is dominated by the
Mid-Indian Ocean Ridge and subdivided
by the Southeast Indian Ocean Ridge,
Southwest Indian Ocean Ridge, and
Ninety East Ridge; maximum depth is
7,258 meters in the Java Trench
Natural resources: oil and gas fields, fish,
shrimp, sand and gravel aggregates, placer
deposits, polymetallic nodules
Environment: endangered marine species
include the dugong, seals, turtles, and
whales; oil pollution in the Arabian Sea,
Persian Gulf, and Red Sea
Note: major choke points include Bab el
Mandeb, Strait of Hormuz, Strait of Ma-
lacca, southern access to the Suez Canal,
and the I.ombok Strait; ships subject to
superstructure icing in extreme south near
Antarctica from May to October
Total area: 803,940 km2; land area:
778,720 km2
Comparative area: slightly less than twice
the size of California
Land boundaries: 6,774 km total; Afghani-
stan 2,430 km, China 523 km, India 2,912
km, Iran 909 km
Coastline: 1,046 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: boundary with India; Pashtun
question with Afghanistan; Baloch ques-
tion with Afghanistan and Iran; water
sharing problems with upstream riparian
India over the Indus
Climate: mostly hot, dry desert; temperate
in northwest; arctic in north
Terrain: flat Indus plain in east; moun-
tains in north and northwest; Balochistan
plateau in west
Natural resources: land, extensive natural
gas reserves, limited crude oil, poor qual-
ity coal, iron ore, copper, salt, limestone
Land use: 26% arable land; NEGL% per-
manent crops; 6% meadows and pastures;
4% forest and woodland; 64% other; in-
cludes 19% irrigated
Environment: frequent earthquakes, occa-
sionally severe especially in north and
west; flooding along the Indus after heavy
rains (July and August); deforestation; soil
erosion; desertification; water logging
Note: controls Khyber Pass and Malakand
Pass, traditional invasion routes between
Central Asia and the Indian Subcontinent
Total area: 1 1.9 km2; land area: 1 1.9 km2
Comparative area: about 20 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 14.5 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: equatorial, hot, and very rainy
Terrain: low, with maximum elevations of
about 2 meters
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 100%
forest and woodland; 0% other
Environment: about 50 islets covered with
dense vegetation, coconut trees, and balsa-
like trees up to 30 meters tall
Note: located 1 ,600 km south-southwest of
Honolulu in the North Pacific Ocean, al-
most halfway between Hawaii and Ameri-
can Samoa','4c07d6bdfaa170d7ddea66a8e42f05beb55d460e3636b9f17fe69b5929db664a','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('000f8b3c97e762212892bde5f5b390941a3fb13cc4991c2c82987f4f67712f90',1981,'OM','Oman','geography',392,'Total area: 1,648,000 km2; land area:
1,636,000km2
Comparative area: slightly larger than
Alaska
Land boundaries: 5,492 km total; Afghani-
stan 936 km, Iraq 1,458 km, Pakistan 909
km, Turkey 499 km, USSR 1,690 km
Coastline: 3,180 km
Maritime claims:
Continental shelf: not specific
Exclusive fishing zone: 50 nm in the
Sea of Oman; median-line boundaries
in the Persian Gulf
Territorial sea: 1 2 nm
Disputes: Iran began formal UN peace
negotiations with Iraq in August 1988 to
end the war that began on 22 September
1980 — troop withdrawal, freedom of navi-
gation, sovereignty over the Shatt al Arab
waterway and prisoner-of-war exchange
are the major issues for negotiation; Kurd-
ish question among Iran, Iraq, Syria, Tur-
key, and the USSR; occupies three islands
in the Persian Gulf claimed by UAE
(JazTreh-ye Abu Musa or Abu Musi,
Jazlreh-ye Tonb-e Bozorg or Greater
Tunb, and Jazlreh-ye Tonb-e Kuchek or
Lesser Tunb); periodic disputes with Af-
ghanistan over Helmand water rights; Bo-
luch question with Afghanistan and Paki-
stan
Climate: mostly arid or semiarid, subtro-
pical along Caspian coast
Terrain: rugged, mountainous rim; high,
central basin with deserts, mountains;
small, discontinuous plains along both
coasts
Natural resources: petroleum, natural gas,
coal, chromium, copper, iron ore, lead,
manganese, zinc, sulfur
Land use: 8% arable land; NEGL% per-
manent crops; 27% meadows and pastures;
1 1% forest and woodland; 54% other; in-
cludes 2% irrigated
Environment: deforestation; overgrazing;
desertification','80e3c3b9e045765960532e2b69ae122dd52f3d813018bf37d6f6e52cbae4f05f','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a34b94b017ec9198926c64de7e2411354b88f98a7a6f1fe415083ff200fb6ec',1981,'IQ','Iraq','geography',398,'Total area: 434,920 km2; land area:
433,970 km2
Comparative area: slightly more than
twice the size of Idaho
Land boundaries: 3,454 km total; Iran
1,458 km, Iraq —Saudi Arabia Neutral
Zone 191 km, Jordan 134 km, Kuwait
240 km, Saudi Arabia 495 km, Syria 605
km, Turkey 331 km
Coastline: 58 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 1 2 nm
Disputes: Iraq began formal UN peace
negotiations with Iran in August 1988 to
end the war that began on 22 September
1980 — sovereignty over the Shatt al Arab
waterway, troop withdrawal, freedom of
navigation, and prisoner of war exchange
are the major issues for negotiation; Kurd-
ish question among Iran, Iraq, Syria, Tur-
key, and the USSR; shares Neutral Zone
with Saudi Arabia — in July 1975, Iraq
and Saudi Arabia signed an agreement to
divide the zone between them, but the
agreement must be ratified before it be-
comes effective; disputes Kuwaiti owner-
ship of Warbah and Bubiyan islands; peri-
odic disputes with upstream riparian Syria
over Euphrates water rights; potential dis-
pute over water development plans by
Turkey for the Tigris and Euphrates Riv-
ers
Climate: desert; mild to cool winters with
dry, hot, cloudless summers
Terrain: mostly broad plains; reedy
marshes in southeast; mountains along
borders with Iran and Turkey
Natural resources: crude oil, natural gas,
phosphates, sulfur
Land use: 12% arable land; 1% permanent
crops; 9% meadows and pastures; 3% for-
est and woodland; 75% other; includes 4%
irrigated
Environment: development of
Tigris-Euphrates river systems contingent
upon agreements with upstream riparians
(Syria, Turkey); air and water pollution;
soil degradation (salinization) and erosion;
desertification
Total area: 3,520 km2; land area: 3,520
km2
Comparative area: slightly larger than
Rhode Island
Land boundaries: 389 km total; 191 km
Iraq, 198 km Saudi Arabia
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: harsh, dry desert
Terrain: sandy desert
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other (sandy
desert)
Environment: harsh, inhospitable
Note: landlocked; located west of quadri-
point with Iraq, Kuwait, and Saudi Ara-
bia','e051c487f72d93bbff8b74e0fbd141793385486ff2f4e147117d743d8dd035f9','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dd97b300918ab5168362ae35547c4a54b9be224aee15ccd05fda4705b0444b9',1981,'IE','Ireland','geography',403,'Total area: 70,280 km2; land area: 68,890
km2
Comparative area: slightly larger than
West Virginia
Land boundary: 360 km with UK
Coastline: 1,448 km
Maritime claims:
Continental shelf: no precise definition
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Disputes: maritime boundary with the
UK; Northern Ireland question with the
UK; Rockall continental shelf dispute in-
volving Denmark, Iceland, and the UK
(Ireland and the UK have signed a bound-
ary agreement in the Rockall area)
Climate: temperate maritime; modified by
North Atlantic Current; mild winters, cool
summers; consistently humid; overcast
about half the time
Terrain: mostly level to rolling interior
plain surrounded by rugged hills and low
mountains; sea cliffs on west coast
Natural resources: zinc, lead, natural gas,
crude oil, barite, copper, gypsum, lime-
stone, dolomite, peat, silver
Land use: 14% arable land; NEGL% per-
manent crops; 7 1 % meadows and pastures;
5% forest and woodland; 10% other
Environment: deforestation
Total area: 20,770 km2; land area: 20,330
km2
Comparative area: slightly larger than
New Jersey
Land boundaries: 1 ,006 km total; Egypt
255 km, Jordan 238 km, Lebanon 79 km,
Syria 76 km, West Bank 307, Gaza Strip
51 km
Coastline: 273 km
Maritime claims:
Continental shelf: to depth of exploita-
tion
Territorial sea: 6 nm
Disputes: separated from Lebanon, Syria,
and the West Bank by the 1949 Armistice
Line; differences with Jordan over the lo-
cation of the 1949 Armistice Line which
separates the two countries; West Bank
and Gaza Strip are Israeli occupied with
status to be determined; Golan Heights is
Israeli occupied; Israeli troops in southern
Lebanon since June 1982; water-sharing
issues with Jordan
Climate: temperate; hot and dry in desert
areas
Terrain: Negev desert in the south; low
coastal plain; central mountains; Jordan
Rift Valley
Natural resources: copper, phosphates,
bromide, potash, clay, sand, sulfur, as-
phalt, manganese, small amounts of natu-
ral gas and crude oil
Land use: 17% arable land; 5% permanent
crops; 40% meadows and pastures; 6%
forest and woodland; 32% other; includes
11% irrigated
Environment: sandstorms may occur dur-
ing spring and summer; limited arable
land and natural water resources pose se-
rious constraints; deforestation;
Note: there are 1 73 Jewish settlements in
the West Bank, 35 in the Israeli-occupied
Golan Heights, 18 in the Gaza Strip, and
14 Israeli-built Jewish neighborhoods in
East Jerusalem','20d562ee07f1d5a96d1fc91273637a96a6fa45c974e528b25377a8503814e520','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72635c300a8a7fbcfc5d1d01c3f2cfb48c82435e98740f4d9ab442104a3e1859',1981,'IT','Italy','geography',408,'Total area: 301,230 km2; land area:
294,020 km2; includes Sardinia and Sicily
Comparative area: slightly larger than Ar-
izona
Land boundaries: 1,902.2 km total; Aus-
tria 430 km, France 488 km, San Marino
39 km, Switzerland 740 km, Vatican City
3.2 km, Yugoslavia 202 km
Coastline: 4,996 km
Maritime claims:
Continental shelf: 200 m or to depth of
exploitation
Territorial sea: 1 2 nm
Disputes: South Tyrol question with Aus-
tria
Climate: predominantly Mediterranean;
Alpine in far north; hot, dry in south
Terrain: mostly rugged and mountainous;
some plains, coastal lowlands
Natural resources: mercury, potash, mar-
ble, sulfur, dwindling natural gas and
crude oil reserves, fish, coal
Land use: 32% arable land; 10% perma-
nent crops; 1 7% meadows and pastures;
22% forest and woodland; 19% other; in-
cludes 10% irrigated
Environment: regional risks include land-
slides, mudflows, snowslides, earthquakes,
volcanic eruptions, flooding, pollution;
land sinkage in Venice
Note: strategic location dominating cen-
tral Mediterranean as well as southern sea
and air approaches to Western Europe
Total area: 322,460 km2; land area:
318,000 km2
Comparative area: slightly larger than
New Mexico
Land boundaries: 3,1 10 km total; Burkina
584 km, Ghana 668 km, Guinea 610 km,
Liberia 716 km, Mali 532 km
Coastline: 515 km
Maritime claims:
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical along coast, semiarid in
far north; three seasons — warm and dry
(November to March), hot and dry
(March to May), hot and wet (June to Oc-
tober)
Terrain: mostly flat to undulating plains;
mountains in northwest
Natural resources: crude oil, diamonds,
manganese, iron ore, cobalt, bauxite, cop-
per
Land use: 9% arable land; 4% permanent
crops; 9% meadows and pastures; 26%
forest and woodland; 52% other; includes
NEGL% irrigated
Environment: coast has heavy surf and no
natural harbors; severe deforestation','94cceed6e6ff87bccb56778833a38aab407472b611f7ac159c48086d04382cbb','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e22961b2af766af8ac6b102a48dd53ccb5e32c4aeda329063e220868285f984',1981,'JM','Jamaica','geography',414,'Total area: 10,990 km2; land area: 10,830
km2
Comparative area: slightly smaller than
Connecticut
Land boundaries: none
Coastline: 1,022 km
Maritime claim:
Territorial sea: 1 2 nm
Climate: tropical; hot, humid; temperate
interior
Terrain: mostly mountains with narrow,
discontinuous coastal plain
Natural resources: bauxite, gypsum, lime-
stone
Land use: 19% arable land; 6% permanent
crops; 18% meadows and pastures; 28%
forest and woodland; 29% other; includes
3% irrigated
Environment: subject to hurricanes (espe-
cially July to November); deforestation;
water pollution
Note: strategic location between Cayman
Trench and Jamaica Channel, the main
sea lanes for Panama Canal','bfae6df770e84224bab92127787443b3d1e4003044f70e354dca4f2e5b0bfb7f','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d4185b18492f99dda17c87dc8b4675311102ba75f8a1cd8c3d68592145346da',1981,'JP','Japan','geography',418,'Total area: 373 km2; land area: 373 km2
Comparative area: slightly more than
twice the size of Washington, DC
Land boundaries: none
Coastline: 124.1 km
Maritime claims:
Contiguous zone: 10 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm Territo-
rial sea: 4 nm
Disputes: Denmark has challenged Nor-
way''s maritime claims beween Greenland
and Jan Mayen
Climate: arctic maritime with frequent
storms and persistent fog
Terrain: volcanic island, partly covered by
glaciers; Beerenberg is the highest peak,
with an elevation of 2,277 meters
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: barren volcanic island with
some moss and grass; volcanic activity
resumed in 1970
Note: located 590 km north-northwest of
Iceland between the Greenland Sea and
the Norwegian Sea north of the Arctic
Circle
Total area: 377,835 km2; land area:
374,744 km2; includes Bonin Islands
(Ogasawara-gunto), DaitO-shotO, Minami-
jima, Okinotori-shima, Ryukyu Islands
(Nansei-shotO), and Volcano Islands
(Kazan-retto)
Comparative area: slightly smaller than
California
Land boundaries: none
Coastline: 29,751 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm (3 nm in inter-
national straits — La Perouse or Soya,
Tsugaru, Osumi, and Eastern and
Western channels of the Korea or
Tsushima Strait)
Disputes: Habomai Islands, Etorofu, Ku-
nashiri, and Shikotan Islands occupied by
Soviet Union since 1945, claimed by Ja-
pan; Kuril Islands administered by Soviet
Union; Liancourt Rocks disputed with
South Korea; Senkaku-shoto (Senkaku
Islands) claimed by China and Taiwan
Climate: varies from tropical in south to
cool temperate in north
Terrain: mostly rugged and mountainous
Natural resources: negligible mineral re-
sources, fish
Land use: 13% arable land; 1% permanent
crops; 1% meadows and pastures; 67%
forest and woodland; 18% other; includes
9% irrigated
Environment: many dormant and some
active volcanoes; about 1,500 seismic oc-
currences (mostly tremors) every year;
subject to tsunamis
Note: strategic location in northeast Asia
Total area: 4.5 km2; land area: 4.5 km2
Comparative area: about 7.5 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 8 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; scant rainfall, constant
wind, burning sun
Terrain: sandy, coral island surrounded by
a narrow fringing reef
Natural resources: guano (deposits worked
until late 1800s)
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: sparse bunch grass, prostrate
vines, and low-growing shrubs; lacks fresh
water; primarily a nesting, roosting, and
foraging habitat for seabirds, shorebirds,
and marine wildlife; feral cats
Note: 2,090 km south of Honolulu in the
South Pacific Ocean, just south of the
Equator, about halfway between Hawaii
and the Cook Islands
Total area: 120,540 km2; land area:
120,410km2
Comparative area: slightly smaller than
Mississippi
Land boundaries: 1,671 km total; China
1,416 km, South Korea 238 km, USSR 17
km
Coastline: 2,495 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Military boundary line: 50 nm (all for-
eign vessels and aircraft without per-
mission are banned)
Disputes: short section of boundary with
China is indefinite; Demarcation Line
with South Korea
Climate: temperate with rainfall concen-
trated in summer
Terrain: mostly hills and mountains sepa-
rated by deep, narrow valleys; coastal
plains wide in west, discontinuous in east
Natural resources: coal, lead, tungsten,
zinc, graphite, magnesite, iron ore, copper,
gold, pyrites, salt, fluorspar, hydropower
Land use: 18% arable land; 1% permanent
crops; NEGL% meadows and pastures;
74% forest and woodland; 7% other; in-
cludes 9% irrigated
Environment: mountainous interior is iso-
lated, nearly inaccessible, and sparsely
populated; late spring droughts often fol-
lowed by severe flooding
Note: strategic location bordering China,
South Korea, and USSR
Total area: 98,480 km2; land area: 98,190
km2
Comparative area: slightly larger than In-
diana
Land boundary: 238 km with North Korea
Coastline: 2,413 km
Maritime claims:
Territorial sea: 12 nm (3 nm in the Ko-
rea Strait)
Disputes: Demarcation Line with North
Korea; Liancourt Rocks claimed by Japan
Climate: temperate, with rainfall heavier
in summer than winter
Terrain: mostly hills and mountains; wide
coastal plains in west and south
Natural resources: coal, tungsten, graph-
ite, molybdenum, lead, hydropower
Land use: 21% arable land; 1% permanent
crops; 1% meadows and pastures; 67%
forest and woodland; 10% other; includes
1 2% irrigated
Environment: occasional typhoons bring
high winds and floods; earthquakes in
southwest; air pollution in large cities
Notes: strategic location along the Korea
Strait, Sea of Japan, and Yellow Sea
Total area: 824,290 km2; land area:
823,290 km2
Comparative area: slightly more than half
the size of Alaska
Land boundaries: 3,935 km total; Angola
1,376 km, Botswana 1,360 km, South Af-
rica 966 km, Zambia 233 km
Coastline: 1,489 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 6 nm
Disputes: short section of boundary with
Botswana is indefinite; quadripoint with
Botswana, Zambia, and Zimbabwe is in
disagreement; possible future claim to
South Africa''s Walvis Bay
Climate: desert; hot, dry; rainfall sparse
and erratic
Terrain: mostly high plateau; Namib
Desert along coast; Kalahari Desert in
east
Natural resources: diamonds, copper, ura-
nium, gold, lead, tin, zinc, salt, vanadium,
natural gas, fish; suspected deposits of
coal and iron ore
Land use: 1% arable land; NEGL% per-
manent crops; 64% meadows and pastures;
22% forest and woodland; 13% other; in-
cludes NEGL% irrigated
Environment: inhospitable with very lim-
ited natural water resources; desertifica-
tion
Note: Walvis Bay area is an exclave of
South Africa in Namibia
Total area: 752,610 km2; land area:
740,720 km2
Comparative area: slightly larger than
Texas
Land boundaries: 5,664 km total; Angola
1,110 km, Malawi 837 km, Mozambique
419 km, Namibia 233 km, Tanzania 338
km, Zaire 1,930 km, Zimbabwe 797 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: quadripoint with Botswana, Na-
mibia, and Zimbabwe is in disagreement;
Tanzania-Zaire-Zambia tripoint in Lake
Tanganyika may no longer be indefinite
since it is reported that the indefinite sec-
tion of the Zaire-Zambia boundary has
been settled
Climate: tropical; modified by altitude;
rainy season (October to April)
Terrain: mostly high plateau with some
hills and mountains
Natural resources: copper, cobalt, zinc,
lead, coal, emeralds, gold, silver, uranium,
hydropower potential
Land use: 7% arable land; NEGL% per-
manent crops; 47% meadows and pastures;
27% forest and woodland; 19% other; in-
cludes NEGL% irrigated
Environment: deforestation; soil erosion;
desertification
Note: landlocked','7c1edc894f3ca5174af6cedc68a41e88e769419fe7ba72a761fae1fa92f9fe29','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd2ecef69d8ae07e4138feeb6ee0baf5a33399333f44031c6a419cc1f2eb21df',1981,'JE','Jersey','geography',426,'Total area: 1 17 km2; land area: 1 17 km2
Comparative area: about 0.7 times the size
of Washington, DC
Land boundaries: none
Coastline: 70 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: temperate; mild winters and cool
summers
Terrain: gently rolling plain with low, rug-
ged hills along north coast
Natural resources: agricultural land
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
about 58% of land under cultivation
Environment: about 30% of population
concentrated in Saint Helier
Note: largest and southernmost of Chan-
nel Islands; 27 km from France
Total area: 2.8 km2; land area: 2.8 km2
Comparative area: about 4.7 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 10 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical, but generally dry; con-
sistent northeast trade winds with little
seasonal temperature variation
Terrain: mostly flat with a maximum ele-
vation of 4 meters
Natural resources: guano (deposits worked
until about 1890)
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: some low-growing vegetation
Note: strategic location 1,328 km west-
southwest of Honolulu in the North Pa-
cific Ocean, about one-third of the way
between Hawaii and the Marshall Islands;
Johnston Island and Sand Island are natu-
ral islands; North Island (Akau) and East
Island (Hikina) are manmade islands
formed from coral dredging; closed to the
public; former nuclear weapons test site','ce42c4ed74fff0d6d16d8be53507fdaf0d22658fdce56270ed66126fccebc3c5','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ab23793d183532bd3bea0f800d32bdc4287808367c97f9e431d5354d531390f',1981,'JO','Jordan','geography',428,'Total area: 91,880 km2; land area: 91,540
km2
Comparative area: slightly smaller than
Indiana
Land boundaries: 1,586 km total; Iraq 134
km, Israel 238 km, Saudi Arabia 742 km,
Syria 375 km, West Bank 97 km
Coastline: 26 km
Maritime claim:
Territorial sea: 3 nm
Disputes: differences with Israel over the
location of the 1949 Armistice Line which
separates the two countries
Climate: mostly arid desert; rainy season
in west (November to April)
Terrain: mostly desert plateau in east,
highland area in west; Great Rift Valley
separates East and West Banks of the Jor-
dan River
Natural resources: phosphates, potash,
shale oil
Land use: 4% arable land; 0.5% perma-
nent crops; 1% meadows and pastures;
0.5% forest and woodland; 94% other; in-
cludes 0.5% irrigated
Environment: lack of natural water re-
sources; deforestation; overgrazing; soil
erosion; desertification
Total area: 4.4 km2; land area: 4.4 km2
Comparative area: about 7.5 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 24.1 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claimed by Madagascar
Climate: tropical
Terrain: undetermined
Natural resources: guano deposits and
other fertilizers
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 90%
forest and woodland; 10% other
Environment: subject to periodic cyclones;
wildlife sanctuary
Note: located in the central Mozambique
Channel about halfway between Africa
and Madagascar','aae283c2666177ae95751b215b84a599cf8708e11067a56818ceb549e7a82e80','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c8402e182f2104683a5920ffe46b8d0b3a4efaed3a1ded17478bc8f6fdc7fb4',1981,'KI','Kiribati','geography',434,'Total area: 1 km2; land area: 1 km2
Comparative area: about 1 .7 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 3 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical, but moderated by pre-
vailing winds
Terrain: low and nearly level with a maxi-
mum elevation of about 1 meter
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: barren coral atoll with deep
interior lagoon; wet or awash most of the
time
Note: located 1,600 km south-southwest of
Honolulu in the North Pacific Ocean,
about halfway between Hawaii and Amer-
ican Samoa; maximum elevation of about
1 meter makes this a navigational hazard;
closed to the public
Total area: 717 km2; land area: 717 km2;
includes three island groups — Gilbert Is-
lands, Line Islands, Phoenix Islands
Comparative area: slightly more than four
times the size of Washington, DC
Land boundaries: none
Coastline: 1,143 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; marine, hot and humid,
moderated by trade winds
Terrain: mostly low-lying coral atolls sur-
rounded by extensive reefs
Natural resources: phosphate (production
discontinued in 1979)
Land use: NEGL% arable land; 51% per-
manent crops; 0% meadows and pastures;
3% forest and woodland; 46% other
Environment: typhoons can occur any
time, but usually November to March; 20
of the 33 islands are inhabited
Note: Banaba or Ocean Island is one of
the three great phosphate rock islands in
the Pacific (the others are Makatea in
French Polynesia and Nauru)','8679db5d0ab11853269991d8e0f0158e76c1d9537e40ddd67290cad505d31f02','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a4af3899dbc349fa362467b772287d7cd0722fbf366c5fe7297c9074c7f1ab3',1981,'KW','Kuwait','geography',441,'Total area: 17,820 km2; land area: 17,820
km2
Comparative area: slightly smaller than
New Jersey
Land boundaries: 462 km total; Iraq 240
km, Saudi Arabia 222 km
Coastline: 499 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 1 2 nm
Disputes: ownership of Warbah and
Bubiyan islands disputed by Iraq; owner-
ship of Qaruh and LJmm al Maradim Is-
lands disputed by Saudi Arabia
Climate: dry desert; intensely hot sum-
mers; short, cool winters
Terrain: flat to slightly undulating desert
plain
Natural resources: petroleum, fish, shrimp,
natural gas
Land use: NEGL% arable land; 0% per-
manent crops; 8% meadows and pastures;
NEGL% forest and woodland; 92% other;
includes NEGL% irrigated
Environment: some of world''s largest and
most sophisticated desalination facilities
provide most of water; air and water pol-
lution; desertification
Note: strategic location at head of Persian
Gulf
Total area: 236,800 km2; land area:
230,800 km2
Comparative area: slightly larger than
Utah
Land boundaries: 5,083 km total; Burma
235 km, Cambodia 541 km, China 423
km, Thailand 1,754 km, Vietnam 2,130
km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: boundary dispute with Thailand
Climate: tropical monsoon; rainy season
(May to November); dry season
(December to April)
Terrain: mostly rugged mountains; some
plains and plateaus
Natural resources: timber, hydropower,
gypsum, tin, gold, gemstones
Land use: 4% arable land; NEGL% per-
manent crops; 3% meadows and pastures;
58% forest and woodland; 35% other; in-
cludes 1% irrigated
Environment: deforestation; soil erosion;
subject to floods
Note: landlocked','baa370695a1ea53d7b9130e29b9c4bb278a4e37b79ebb71eaaaee69f702e73c2','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a45f9599eddf9bff0337128207242e680d7a90d5fb4b9aa689e1fcbedf31c14f',1981,'LB','Lebanon','geography',446,'Total area: 10,400 km2; land area: 10,230
km2
Comparative area: about 0.8 times the size
of Connecticut
Land boundaries: 454 km total; Israel 79
km, Syria 375 km
Coastline: 225 km
Maritime claim:
Territorial sea: \\ 2 nm
Disputes: separated from Israel by the
1949 Armistice Line; Israeli troops in
southern Lebanon since June 1982; Syrian
troops in northern Lebanon since October
1976
Climate: Mediterranean; mild to cool, wet
winters with hot, dry summers
Terrain: narrow coastal plain; AI Biqa"
separates Lebanon and Anti-Lebanon
Mountains
Natural resources: limestone, iron ore,
salt; water-surplus state in a water-deficit
region
Land use: 21% arable land; 9% permanent
crops; 1% meadows and pastures; 8% for-
est and woodland; 61% other; includes 7%
irrigated
Environment: rugged terrain historically
helped isolate, protect, and develop nu-
merous factional groups based on religion,
clan, ethnicity; deforestation; soil erosion;
air and water pollution; desertification
Note: Nahr al Ll|anl only major river in
Near East not crossing an international
boundary','d76cfa51e40a0875d0b94a9306ed841b3b45c0a4b04d8fb570782c8e26b9dfb6','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ad5d444a2ecc1bcfc8bde81d11afa87c55ce4bf4219980ae76ea0bab79cec89',1981,'LS','Lesotho','geography',451,'Total area: 30,350 km2; land area: 30,350
km2 Comparative area: slightly larger than
Maryland
Land boundary: 909 km with South Africa
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: temperate; cool to cold, dry win-
ters; hot, wet summers
Terrain: mostly highland with some pla-
teaus, hills, and mountains
Natural resources: some diamonds and
other minerals, water, agricultural and
grazing land
Land use: 10% arable land; 0% permanent
crops; 66% meadows and pastures; 0%
forest and woodland; 24% other
Environment: population pressure forcing
settlement in marginal areas results in
overgrazing, severe soil erosion, soil ex-
haustion; desertification
Note: surrounded by South Africa; High-
lands Water Project will control, store,
and redirect water to South Africa','a959da6ace794a494c53b4c822666f158ca004aa297095c5fdf98c645f2f46de','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32f6af00675f64cd19a7d20e8dfd423095c461700d3395ae9a21c3a69bafc21f',1981,'LR','Liberia','geography',455,'Total area: 1 1 1,370 km2; land area:
96,320 km2
Comparative area: slightly larger than
Tennessee
Land boundaries: 1,585 km total; Guinea
563 km, Ivory Coast 716 km, Sierra
Leone 306 km
Coastline: 579 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters
with hot days and cool to cold nights; wet,
cloudy summers with frequent heavy
showers
Terrain: mostly flat to rolling coastal
plains rising to rolling plateau and low
mountains in northeast
Natural resources: iron ore, timber, dia-
monds, gold
Land use: 1% arable land; 3% permanent
crops; 2% meadows and pastures; 39%
forest and woodland; 55% other; includes
NEGL% irrigated
Environment: West Africa''s largest tropi-
cal rain forest, subject to deforestation','b12cce40ea3e400ef7e1a75582b83768c722e30eda47ec66e62f47ea372aa980','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a36b9437e6d1d4091475f212771916902de7ed39046b1a6e176c1177607a0664',1981,'LY','Libya','geography',461,'Total area: 1,759,540 km2; land area:
1,759,540km2
Comparative area: slightly larger than
Alaska
Land boundaries: 4,383 km total; Algeria
982 km, Chad 1,055 km, Egypt 1,150 km,
Niger 354 km, Sudan 383 km, Tunisia
459km
Coastline: 1,770 km
Maritime claims:
Territorial sea: 1 2 nm
GulfofSidra closing line: 32° 30'' N
Disputes: claims and occupies a small por-
tion of the Aozou Strip in northern Chad;
maritime boundary dispute with Tunisia;
Libya claims about 19,400 km2 in north-
ern Niger; Libya claims about 19,400 km2
in southeastern Algeria
Climate: Mediterranean along coast; dry,
extreme desert interior
Terrain: mostly barren, flat to undulating
plains, plateaus, depressions
Natural resources: crude oil, natural gas,
gypsum
Land use: 1% arable land; 0% permanent
crops; 8% meadows and pastures; 0% for-
est and woodland; 91% other; includes
NEGL% irrigated
Environment: hot, dry, dust-laden ghibli is
a southern wind lasting one to four days
in spring and fall; desertification; sparse
natural surface-water resources
Note: the Great Manmade River Project,
the largest water development scheme in
the world, is being built to bring water
from large aquifers under the Sahara to
coastal cities
Climate: temperate in north with mild,
rainy winters and hot, dry summers;
desert in south
Terrain: mountains in north; hot, dry cen-
tral plain; semiarid south merges into the
Sahara
Natural resources: crude oil, phosphates,
iron ore, lead, zinc, salt
Land use: 20% arable land; 10% perma-
nent crops; 19% meadows and pastures;
4% forest and woodland; 47% other; in-
cludes 1% irrigated
Environment: deforestation; overgrazing;
soil erosion; desertification
Note: strategic location in central Medi-
terranean; only 144 km from Italy across
the Strait of Sicily; borders Libya on east
Total area: 780,580 km2; land area:
770,760 km2
Comparative area: slightly larger than
Texas
Land boundaries: 2,715 km total; Bulgaria
240 km, Greece 206 km, Iran 499 km,
Iraq 331 km, Syria 822 km, USSR 617
km
Coastline: 7,200 km
Maritime claims:
Extended economic zone: in Black Sea
only — to the maritime boundary agreed
upon with the USSR
Territorial sea: 6 nm (12 nm in Black
Sea and Mediterranean Sea)
Disputes: complex maritime and air (but
not territorial) disputes with Greece in
Aegean Sea; Cyprus question; Hatay
question with Syria; ongoing dispute with
downstream riparians (Syria and Iraq)
over water development plans for the Ti-
gris and Euphrates rivers; Kurdish ques-
tion among Iran, Iraq, Syria, Turkey, and
the USSR
Climate: temperate; hot, dry summers
with mild, wet winters; harsher in interior
Terrain: mostly mountains; narrow coastal
plain; high central plateau (Anatolia)
Natural resources: antimony, coal, chro-
mium, mercury, copper, borate, sulphur,
iron ore
Land use: 30% arable land; 4% permanent
crops; 12% meadows and pastures; 26%
forest and woodland; 28% other; includes
3% irrigated
Environment: subject to severe earth-
quakes, especially along major river val-
leys in west; air pollution; desertification
Note: strategic location controlling the
Turkish straits (Bosporus, Sea of Mar-
mara, Dardanelles) that link Black and
Aegean Seas; Turkey and Norway only
NATO members having a land boundary
with the USSR','0ffd49bd7246e58d44bab16471c681668470bf420a6115198111d34a5ff7799a','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('add652a870d75b3089b382e60e68f73d746e4b78fa37fdb7085fc1f527444829',1981,'LI','Liechtenstein','geography',465,'Total area: 160 km2; land area: 160 km2
Comparative area: about 0.9 times the size
of Washington, DC
Land boundaries: 78 km total; Austria 37
km, Switzerland 41 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: continental; cold, cloudy winters
with frequent snow or rain; cool to moder-
ately warm, cloudy, humid summers
Terrain: mostly mountainous (Alps) with
Rhine Valley in western third
Natural resources: hydroelectric potential
Land use: 25% arable land; 0% permanent
crops; 38% meadows and pastures; 19%
forest and woodland; 18% other
Environment: variety of microclimatic
variations based on elevation
Note: landlocked','4f14217206df540ba49b5e24fcfcada90b42f892a5d483cb90caec15aefdf0a1','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb4dcadaf3d826ca247f57998d1e3f1157e1673c5c7755080122601d0746160d',1981,'LU','Luxembourg','geography',471,'Total area: 2,586 km2; land area: 2,586
km2
Comparative area: slightly smaller than
Rhode Island
Land boundaries: 359 km total; Belgium
148 km, France 73 km, FRG 138 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: modified continental with mild
winters, cool summers
Terrain: mostly gently rolling uplands
with broad, shallow valleys; uplands to
slightly mountainous in the north; steep
slope down to Moselle floodplain in the
southeast
Natural resources: iron ore (no longer ex-
ploited)
Land use: 24% arable land; 1% permanent
crops; 20% meadows and pastures; 21%
forest and woodland; 34% other
Environment: deforestation
Note: landlocked
Total area: 16 km2; land area: 16 km2
Comparative area: about 0.1 times the size
of Washington, DC
Land boundary: 0.34 km with China
Coastline: 40 km
Maritime claims:
Exclusive fishing zone: 1 2 nm
Territorial sea: 6 nm
Disputes: scheduled to become a Special
Administrative Region of China in 1999
Climate: subtropical; marine with cool
winters, warm summers
Terrain: generally flat
Natural resources: negligible
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: essentially urban; one cause-
way and one bridge connect the two is-
lands to the peninsula on mainland
Note: 27 km west southwest of Hong
Kong on the southeast coast of China','3010ce394364d17db73448aa07e7deda87754ca5d5bf18a28796d1678d9a333e','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('389c8d16d48219cbf1a4f8ebc393e0548d8fef2685fc0da9ebbedaf821e71acd',1981,'MG','Madagascar','geography',474,'Total area: 587,040 km2; land area:
581,540km2
Comparative area: slightly less than twice
the size of Arizona
Land boundaries: none
Coastline: 4,828 km
Maritime claims:
Exclusive fishing zone: 150 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claims Bassas da India, Europa
Island, Glorioso Islands, Juan de Nova
Island, and Tromelin Island (all adminis-
tered by France)
Climate: tropical along coast, temperate
inland, arid in south
Terrain: narrow coastal plain, high pla-
teau and mountains in center
Natural resources: graphite, chromite,
coal, bauxite, salt, quartz, tar sands, semi-
precious stones, mica, fish
Land use: 4% arable land; 1% permanent
crops; 58% meadows and pastures; 26%
forest and woodland; 1 1% other; includes
2% irrigated
Environment: subject to periodic cyclones;
deforestation; overgrazing; soil erosion;
desertification
Note: world''s fourth-largest island; strate-
gic location along Mozambique Channel','e8dd6532673ea5ddc05d52e914d38640b47bd9b0b2670979dbbac21e205ae4ac','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b1eef0d3cb88ac16dbd58fe2c9a8a5d20da9b1089516ecfee1f9bbb36a0f3f8',1981,'MW','Malawi','geography',479,'Total area: 1 18,480 km2; land area:
94,080 km2
Comparative area: slightly larger than
Pennsylvania
Land boundaries: 2,881 km total; Mozam-
bique 1,569 km, Tanzania 475 km, Zam--
bia 837 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: dispute with Tanzania over the
boundary in Lake Nyasa (Lake Malawi)
Climate: tropical; rainy season (November
to May); dry season (May to November)
Terrain: narrow elongated plateau with
rolling plains, rounded hills, some moun-
tains
Natural resources: limestone; unexploited
deposits of uranium, coal, and bauxite
Land use: 25% arable land; NEGL% per-
manent crops; 20% meadows and pastures;
50% forest and woodland; 5% other; in-
cludes NEGL% irrigated
Environment: deforestation
Note: landlocked','87fc4a448c3d160e0583017a8c4b1021519b39356af5f4c4a077ab59563876ab','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76cce929e8540995004250227b612789e2f738d9c91ff054325f3d676378d972',1981,'MV','Maldives','geography',486,'Total area: 300 km2; land area: 300 km2
Comparative area: slightly more than 1 .5
times the size of Washington, DC
Land boundaries: none
Coastline: 644 km
Maritime claims:
Exclusive fishing zone: about 100 nm
(defined by geographic coordinates)
Extended economic zone: 37-3 1 0 nm
(segment of zone coincides with mari-
time boundary with India)
Territorial sea: 1 2 nm
Climate: tropical; hot, humid; dry, north-
east monsoon (November to March);
rainy, southwest monsoon (June to Au-
gust)
Terrain: flat with elevations only as high
as 2.5 meters
Natural resources: fish
Land use: 10% arable land; 0% permanent
crops; 3% meadows and pastures; 3% for-
est and woodland; 84% other
Environment: 1 ,200 coral islands grouped
into 19 atolls
Note: archipelago of strategic location
astride and along major sea lanes in In-
dian Ocean','cda5557d5ab08b872eae232c8b246f74cd80d9d716a0a01a66c1dd68b2a5a928','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c611c25f40ccfe80f60d2794b1576bfaaebbda55a46a74067d8feb63327ad6b',1981,'ML','Mali','geography',492,'Total area: 1,240,000 km2; land area:
1 ,220,000 km2
Comparative area: slightly less than twice
the size of Texas
Land boundaries: 7,243 km total; Algeria
1,376 km, Burkina 1,000 km, Guinea 858
km. Ivory Coast 532 km, Mauritania
2,237 km, Niger 821 km, Senegal 419 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: the disputed international
boundary between Burkina and Mali was
submitted to the International Court of
Justice (ICJ) in October 1983 and the ICJ
issued its final ruling in December 1986,
which both sides agreed to accept; Burk-
ina and Mali are proceeding with bound-
ary demarcation, including the tripoint
with Niger
Climate: subtropical to arid; hot and dry
February to June; rainy, humid, and mild
June to November; cool and dry Novem-
ber to February
Terrain: mostly flat to rolling northern
plains covered by sand; savanna in south,
rugged hills in northeast
Natural resources: gold, phosphates, ka-
olin, salt, limestone, uranium; bauxite,
iron ore, manganese, tin, and copper de-
posits are known but not exploited
Land use: 2% arable land; NEGL% per-
manent crops; 25% meadows and pastures;
7% forest and woodland; 66% other; in-
cludes NEGL% irrigated
Environment: hot, dust-laden harmattan
haze common during dry seasons; deserti-
fication
Note: landlocked','bdf872128b483524a47642eaeff7069e2c92048afb28ccd6be583b04ac0ead6a','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35a9c3fbb90f9c54e2bbfcfbf2c3bec34eefcd1dd9c3fa8a91d416d06ad80759',1981,'MH','Marshall Islands','geography',496,'Total area: 181.3 km2; land area: 181.3
km2; includes the atolls of Bikini, Eniwe-
tak, and Kwajalein
Comparative area: slightly larger than
Washington, DC
Land boundaries: none
Coastline: 370.4 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claims US-administered Wake
Island
Climate: wet season May to November;
hot and humid; islands border typhoon
belt
Terrain: low coral limestone and sand is-
lands
Natural resources: phosphate deposits, ma-
rine products, deep seabed minerals
Land use: 0% arable land; 60% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 40% other
Environment: occasionally subject to ty-
phoons; two archipelagic island chains of
30 atolls and 1,152 islands
Note: located 3,825 km southwest of Ho-
nolulu in the North Pacific Ocean, about
two-thirds of the way between Hawaii and
Papua New Guinea; Bikini and Eniwetak
are former US nuclear test sites; Kwaja-
lein, the famous World War II battle-
ground, is now used as a US missile test
range
Climate: tropical
Terrain: atoll of three coral islands built
up on an underwater volcano; central la-
goon is former crater, islands are part of
the rim; average elevation less than four
meters
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: subject to occasional
typhoons
Note: strategic location 3,700 km west of
Honolulu in the North Pacific Ocean,
about two-thirds of the way between Ha-
waii and the Northern Mariana Islands;
emergency landing location for transpa-
cific flights','c86bdbd14937dd7f68e6fb44fb3fc0ef63a6931fd7859d6e5ade789bb49d5bbb','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09cdac5799d768e9cc4bba3d16ef7039a31b46c49ef55bae06f2344d0d41e722',1981,'MQ','Martinique','geography',502,'Total area: 1,100 km2; land area: 1,060
km2
Comparative area: slightly more than six
times the size of Washington, DC
Land boundaries: none
Coastline: 290 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by trade
winds; rainy season (June to October)
Terrain: mountainous with indented coast-
line; dormant volcano
Natural resources: coastal scenery and
beaches, cultivable land
Land use: 10% arable land; 8% permanent
crops; 30% meadows and pastures; 26%
forest and woodland; 26% other; includes
5% irrigated
Environment: subject to hurricanes,
flooding, and volcanic activity that result
in an average of one major natural disas-
ter every five years
Note: located 625 km southeast of Puerto
Rico in the Caribbean Sea','1c40c574f2ac8c1598661ac838b6f630b4657bb153e5e7aa46e6a212bfd872bc','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbfece4ae32ba82de548cf7d216c6af7d9f737f1ceea3730942258e41bfc81ac',1981,'MR','Mauritania','geography',504,'Total area: 1,030,700 km2; land area:
1 ,030,400 km2
Comparative area: slightly larger than
three times the size of New Mexico
Land boundaries: 5,074 km total; Algeria
463 km, Mali 2,237 km, Senegal 813 km,
Western Sahara 1,561 km
Coastline: 754 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: armed conflict in Western Sa-
hara; boundary with Senegal
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the
Sahara; some central hills
Natural resources: iron ore, gypsum, fish,
copper, phosphate
Land use: 1% arable land; NEGL% per-
manent crops; 38% meadows and pastures;
5% forest and woodland; 56% other; in-
cludes NEGL% irrigated
Environment: hot, dry, dust/sand-laden
sirocco wind blows primarily in March
and April; desertification; only perennial
river is the Senegal','e0308d4b28e9314e2833c7cb6c803fc2cd1317751b5423f06abe315b5c8cd562','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('829ea0c4b7316a3e024470f91ce15e0fbccda35b4a390ee2a8b8b3c1b77156d0',1981,'YT','Mayotte','geography',509,'Total area: 375 km2; land area: 375 km2
Comparative area: slightly more than
twice the size of Washington, DC
Land boundaries: none
Coastline: 185.2 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claimed by Comoros
Climate: tropical; marine; hot, humid,
rainy season during northeastern monsoon
(November to May); dry season is cooler
(May to November)
Terrain: generally undulating with ancient
volcanic peaks, deep ravines
Natural resources: negligible
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other
Environment: subject to cyclones during
rainy season
Note: part of Comoro Archipelago; lo-
cated in the Mozambique Channel about
halfway between Africa and Madagascar','a1caf70189e33dd58ac11f77eeac5c19a1352aed20f8b40782e0fc57942d4f58','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40766789590227bcfda7025700a620c7fe31004d960f97e5c0a6ccbbf5c0946f',1981,'MX','Mexico','geography',514,'Total area: 1,972,550 km2; land area:
1,923,040 km2
Comparative area: slightly less than three
times the size of Texas
Land boundaries: 4,538 km total; Belize
250 km, Guatemala 962 km, US 3,326
km
Coastline: 9,330 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: natural prolongation
of continental margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: varies from tropical to desert
Terrain: high, rugged mountains, low
coastal plains, high plateaus, and desert
Natural resources: crude oil, silver, copper,
gold, lead, zinc, natural gas, timber
Land use: 12% arable land; 1% permanent
crops; 39% meadows and pastures; 24%
forest and woodland; 24% other; includes
3% irrigated
Environment: subject to tsunamis along
the Pacific coast and destructive earth-
quakes in the center and south; natural
water resources scarce and polluted in
north, inaccessible and poor quality in
center and extreme southeast; deforesta-
tion; erosion widespread; desertification;
serious air pollution in Mexico City and
urban centers along US-Mexico border
Note: strategic location on southern bor-
der of US
Total area: 9,372,610 km2; land area:
9,166,600 km2; includes only the 50 states
and District of Colombia
Comparative area: about four-tenths the
size of USSR; about one-third the size of
Africa; about one-half the size of South
America (or slightly larger than Brazil);
slightly smaller than China; about two
and one-half times the size of Western
Europe
Land boundaries: 12,248.1 km total; Can-
ada 8,893 km (including 2,477 km with
Alaska), Mexico 3,326 km, Cuba (US na-
val base at Guantanamo) 29.1 km
C oastline: 19,924 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: not specified
Extended economic zone: 200 nm
Territorial sea: 12 nm
Disputes: maritime boundary disputes
with Canada; US Naval Base at Guan-
tanamo is leased from Cuba and only mu-
tual agreement or US abandonment of the
area can terminate the lease; Haiti claims
Navassa Island; has made no territorial
claim in Antarctica (but has reserved the
right to do so) and does not recognize the
claims of any other nation
Climate: mostly temperate, but varies
from tropical (Hawaii) to arctic (Alaska);
arid to semiarid in west with occasional
warm, dry Chinook wind
Terrain: vast central plain, mountains in
west, hills and low mountains in east; rug-
ged mountains and broad river valleys in
Alaska; rugged, volcanic topography in
Hawaii
Natural resources: coal, copper, lead, mo-
lybdenum, phosphates, uranium, bauxite,
gold, iron, mercury, nickel, potash, silver,
tungsten, zinc, crude oil, natural gas, tim-
ber
Land use: 20% arable land; NEGL% per-
manent crops; 26% meadows and pastures;
29% forest and woodland; 25% other; in-
cludes 2% irrigated
Environment: pollution control measures
improving air and water quality; acid rain;
agricultural fertilizer and pesticide pollu-
tion; management of sparse natural water
resources in west; desertification; tsuna-
mis, volcanoes, and earthquake activity
around Pacific Basin; continuous perma-
frost in northern Alaska is a major imped-
iment to development
Note: world''s fourth-largest country (after
USSR, Canada, and China)','1dac42ad65d40d7eb56599656e7ccd1be504d79b2e80fc8d3390fce7953e618f','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a97cf406c4d4f2d85551aff71c0d96e925046004dcad0da0dc0ad470c896860d',1981,'FM','Micronesia, Federated States of','geography',518,'Total area: 702 km2; land area: 702 km2;
includes Pohnpei, Truk, Yap, and Kosrae
Comparative area: slightly less than four
times the size of Washington, DC
Land boundaries: none
Coastline: 6,1 12 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; heavy year-round rain-
fall, especially in the eastern islands; lo-
cated on southern edge of the typhoon belt
with occasional severe damage
Terrain: islands vary geologically from
high mountainous islands to low, coral
atolls; volcanic outcroppings on Pohnpei,
Kosrae, and Truk
Natural resources: forests, marine prod-
ucts, deep-seabed minerals
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other
Environment: subject to typhoons from
June to December; four major island
groups totaling 607 islands
Note: located 5,150 km west-southwest of
Honolulu in the North Pacific Ocean,
about three-quarters of the way between
Hawaii and Indonesia
Total area: 5.2 km2; land area: 5.2 km2;
includes Eastern Island and Sand Island
Comparative area: about nine times the
size of The Mall in Washington, DC
Land boundaries: none
Coastline: 1 5 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical, but moderated by pre-
vailing easterly winds
Terrain: low, nearly level
Natural resources: fish and wildlife
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: coral atoll
Note: located 2,350 km west-northwest of
Honolulu at the western end of Hawaiian
Islands group, about one-third of the way
between Honolulu and Tokyo; closed to
the public','dd558117fd53cc0a44338f8bfe98e241f4e8e4bd77ccc298450333e124249b83','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('288ab971996e4c74e7c78b92869b88f6224a200e8870d31058d1bef25b6f55a8',1981,'MC','Monaco','geography',523,'Total area: 1.9 km2; land area: 1.9 km2
Comparative area: about three times the
size of The Mall in Washington, DC
Land boundary: 4.4 km with France
Coastline: 4.1 km
Maritime claim:
Territorial sea: 1 2 nm
Climate: Mediterranean with mild, wet
winters and hot, dry summers
Terrain: hilly, rugged, rocky
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: almost entirely urban
Note: second-smallest independent state in
world (after Vatican City)','7866b4d46477ce7e006c42e15cd76157987fc375fc8ab3cab9d1ba793ca842fb','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9c36c61b4575253069fff1725abb2e97151a36905801f55bcc3c0f3e4eff9d9',1981,'MS','Montserrat','geography',531,'Total area: 100 km2; land area: 100 km2
Comparative area: about 0.6 times the size
of Washington, DC
Land boundaries: none
Coastline: 40 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; little daily or seasonal
temperature variation
Terrain: volcanic islands, mostly moun-
tainous, with small coastal lowland
Natural resources: negligible
Land use: 20% arable land; 0% permanent
crops; 10% meadows and pastures; 40%
forest and woodland; 30% other
Environment: subject to severe hurricanes
from June to November
Note: located 400 km southeast of Puerto
Rico in the Caribbean Sea','2d38367a36c8d6979d2c6707ea6a7f69ac8c1bc564e2dd1732bd191b7d70cf79','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cebbfe7ac6bad8078be1559f829786ac72c63151131a7bb05e1802b9e33ad7ed',1981,'MA','Morocco','geography',537,'Total area: 446,550 km2; land area:
446,300 km2
Comparative area: slightly larger than
California
Land boundaries: 2,002 km total; Algeria
1,559 km. Western Sahara 443 km
Coastline: 1,835 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claims and administers Western
Sahara, but sovereignty is unresolved;
armed conflict in Western Sahara; Spain
controls two coastal presidios or places of
sovereignty (Ceuta, Melilla)
Climate: Mediterranean, becoming more
extreme in the interior
Terrain: mostly mountains with rich
coastal plains
Natural resources: phosphates, iron ore,
manganese, lead, zinc, fish, salt
Land use: 18% arable land; 1% permanent
crops; 28% meadows and pastures; 12%
forest and woodland; 41% other; includes
1% irrigated
Environment: northern mountains geologi-
cally unstable and subject to earthquakes;
desertification
Note: strategic location along Strait of','d7c7294a9f762979e542f89c2dc798bf83fee4b971b7fb95335705eb8f6773c3','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b49e9dbade24ec009f3ccec543d5a9f0372fbda7f3c2fed2d0348cd67d8f4be',1981,'NR','Nauru','geography',541,'Total area: 21 km2; land area: 21 km2
Comparative area: about 0.1 times the size
of Washington, DC
Land boundaries: none
Coastline: 30 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm .
Climate: tropical; monsoonal; rainy season
(November to February)
Terrain: sandy beach rises to fertile ring
around raised coral reefs with phosphate
plateau in center
Natural resources: phosphates
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: only 53 km south of Equator
Note: one of three great phosphate rock
islands in the Pacific (others are Banaba
or Ocean Island in Kiribati and Makatea
in French Polynesia)
Total area: 5.2 knr; land area: 5.2 km2
Comparative area: about nine times the
size of The Mall in Washington, DC
Land boundaries: none
Coastline: 8 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claimed by Haiti
Climate: marine, tropical
Terrain: raised coral and limestone pla-
teau, flat to undulating; ringed by vertical
white cliffs (9 to 15 meters high)
Natural resources: guano
Land use: 0% arable land; 0% permanent
crops; 10% meadows and pastures; 0%
forest and woodland; 90% other
Environment: mostly exposed rock, but
enough grassland to support goat herds;
dense stands of fig-like trees, scattered
cactus
Note: strategic location between Cuba,
Haiti, and Jamaica in the Caribbean Sea;
160 km south of the US Naval Base at
Guantanamo, Cuba','7f9b154d9aefbe62752dcdccd9b2c7aa602fc82fb549c7a8c4d908212035fc5e','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8225047f1827ff87641e5836b787e78a2a9f63157c943e94d9dd1855d1f16c9b',1981,'NP','Nepal','geography',546,'Total area: 140,800 km2; land area:
1 36,800 km2
Comparative area: slightly larger than Ar-
kansas
Land boundaries: 2,926 km total; China
1,236 km, India 1,690 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: varies from cool summers and
severe winters in north to subtropical sum-
mers and mild winter in south
Terrain: Tarai or flat river plain of the
Ganges in south, central hill region, rug-
ged Himalayas in north
Natural resources: quartz, water, timber,
hydroelectric potential, scenic beauty;
small deposits of lignite, copper, cobalt,
iron ore
Land use: 17% arable land; NEGL% per-
manent crops; 1 3% meadows and pastures;
33% forest and woodland; 37% other; in-
cludes 2% irrigated
Environment: contains eight of world''s 10
highest peaks; deforestation; soil erosion;
water pollution
Note: landlocked; strategic location be-
tween China and India','238899616c457499c261923a9905b5edfba1202c87cdf176c9ede2c4e812ac66','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2150150b19a40c78268caf54a7efb8a36afe1c50f36aedc36811624ca819802',1981,'NL','Netherlands','geography',551,'Total area: 37,290 km2; land area: 33,940
km2
Comparative area: slightly less than twice
the size of New Jersey
Land boundaries: 1,027 km total; Belgium
450 km, FRG 577 km
Coastline: 45 1 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Climate: temperate; marine; cool summers
and mild winters
Terrain: mostly coastal lowland and re-
claimed land (polders); some hills in south-
east
Natural resources: natural gas, crude oil,
fertile soil
Land use: 25% arable land; 1% permanent
crops; 34% meadows and pastures; 9%
forest and woodland; 31% other; includes
15% irrigated
Environment: 27% of the land area is be-
low sea level and protected from the
North Sea by dikes
Note: located at mouths of three major
European rivers (Rhine, Maas or Meuse,
Schelde)
Total area: 960 km2; land area: 960 km2;
includes Bonaire, Curacao, Saba, Sint
Eustatius, and Sint Maarten (Dutch part
of the island of Saint Martin)
Comparative area: slightly less than 5.5
times the size of Washington, DC
Land boundaries: 14 km with Guadeloupe
Coastline: 364 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 1 2 nm
Climate: tropical; modified by northeast
trade winds
Terrain: generally hilly, volcanic interiors
Natural resources: phosphates (Curacao
only), salt (Bonaire only)
Land use: 8% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 92% other
Environment: Curacao and Bonaire are
south of Caribbean hurricane belt, so
rarely threatened; Sint Maarten, Saba,
and Sint Eustatius are subject to hurri-
canes from July to October
Note: consists of two island groups — Cu-
racao and Bonaire are located off the
coast of Venezuela, and Sint Maarten,
Saba, and Sint Eustatius lie 800 km to
the north','ec3b962b20b52a080c211bf0295523f4022af552dbdf1af0a26ecebaeaa137dc','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c00f6fe9a8263d0d4711e48d674419fca6dd5e7e38d0a0c17977bab38140089',1981,'NC','New Caledonia','geography',555,'Total area: 19,060 km2; land area: 18,760
km2
Comparative area: slightly smaller than
New Jersey
Land boundaries: none
Coastline: 2,254 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; modified by southeast
trade winds; hot, humid
Terrain: coastal plains with interior moun-
tains
Natural resources: nickel, chrome, iron,
cobalt, manganese, silver, gold, lead, cop-
per
Land use: NEGL% arable land; NEGL%
permanent crops; 14% meadows and pas-
tures; 51% forest and woodland; 35%
other
Environment: typhoons most frequent from
November to March
Note: located 1,750 km east of Australia
in the South Pacific Ocean','9654e63017ea918d8dd5f645a9952e33fc8611bf8b00ae900fc764372bb8a585','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2ad2a17cfd3e14a6bc353256b7976b0b9f19f35bbb0c81c625314fc18b1e5f2',1981,'NI','Nicaragua','geography',560,'Total area: 129,494 km2; land area:
120,254km2
Comparative area: slightly larger than
New York State
Land boundaries: 1,231 km total; Costa
Rica 309 km, Honduras 922 km
Coastline: 910 km
Maritime claims:
Contiguous zone: 25 nm security zone
(status of claim uncertain)
Continental shelf: not specified
Territorial sea: 200 nm
Disputes: territorial disputes with Colom-
bia over the Archipelago de San Andres y
Providencia and Quita Sueno Bank
Climate: tropical in lowlands, cooler in
highlands
Terrain: extensive Atlantic coastal plains
rising to central interior mountains; nar-
row Pacific coastal plain interrupted by
volcanoes
Natural resources: gold, silver, copper,
tungsten, lead, zinc, timber, fish
Land use: 9% arable land; 1% permanent
crops; 43% meadows and pastures; 35%
forest and woodland; 12% other; including
1% irrigated
Environment: subject to destructive earth-
quakes, volcanoes, landslides, and occa-
sional severe hurricanes; deforestation; soil
erosion; water pollution','16f1be071ed63c135d498144a34e82d1ef0ed3c8b659ead98bf1131d0b60b27a','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('208b77ac17d5ffff5d36ec7a3fc8782e47a9098ede5cb0a0e39d37d257d437d8',1981,'NE','Niger','geography',565,'Total area: 1,267,000 km2; land area:
1,266,700km2
Comparative area: slightly less than twice
the size of Texas
Land boundaries: 5,697 km total; Algeria
956 km, Benin 266 km, Burkina 628 km,
Chad 1,175 km, Libya 354 km, Mali 821
km, Nigeria 1,497 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: Libya claims about 19,400 km2
in northern Niger; exact locations of the
Chad-Niger-Nigeria and Cameroon-Chad-
Nigeria tripoints in Lake Chad have not
been determined, so the boundary has not
been demarcated and border incidents
have resulted; Burkina and Mali are pro-
ceeding with boundary demarcation, in-
cluding the tripoint with Niger
Climate: desert; mostly hot, dry, dusty;
tropical in extreme south
Terrain: predominately desert plains and
sand dunes; flat to rolling plains in south;
hills in north
Natural resources: uranium, coal, iron ore,
tin, phosphates
Land use: 3% arable land; 0% permanent
crops; 7% meadows and pastures; 2% for-
est and woodland; 88% other; includes
NEGL% irrigated
Environment: recurrent drought and deser-
tification severely affecting marginal agri-
cultural activities; overgrazing; soil erosion
Note: landlocked','221196787d7f1503e1f4401ff9c7094e4dd8bd67587381075e87a6176c4c4460','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d95ed095df96283a453bb6abf8def8fcfe590e0a6d97bb67be12b5f25136fb5',1981,'NU','Niue','geography',571,'Total area: 260 km2; land area: 260 km2
Comparative area: slightly less than 1.5
times the size of Washington, DC
Land boundaries: none
Coastline: 64 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; modified by southeast
trade winds
Terrain: steep limestone cliffs along coast,
central plateau
Natural resources: fish, arable land
Land use: 61% arable land; 4% permanent
crops; 4% meadows and pastures; 19%
forest and woodland; 1 2% other
Environment: subject to typhoons
Note: one of world''s largest coral islands;
located about 460 km east of Tonga','de4493dd5c84aa48acb6a5bb43329002689363be53561a97ae042c5957668500','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('243fa9aee162cb46b68fa2072dd9a190ca11738370a17e87584088456676b162',1981,'NF','Norfolk Island','geography',577,'Total area: 34.6 km2; land area: 34.6 km2
Comparative area: about 0.2 times the size
of Washington, DC
Land boundaries: none
Coastline: 32 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: subtropical, mild, little seasonal
temperature variation
Terrain: volcanic formation with mostly
rolling plains
Natural resources: fish
Land use: 0% arable land; 0% permanent
crops; 25% meadows and pastures; 0%
forest and woodland; 75% other
Environment: subject to typhoons (espe-
cially May to July)
Note: located 1,575 km east of Australia
in the South Pacific Ocean','2fbfacf191116d74b3de92ed225bff657fade4b74f5f30c5a0354d088aa4ab60','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87e8d2c5f6b9fec0022087bf88d36cf7acea9d325982c65bfc56adb21202fe26',1981,'MP','Northern Mariana Islands','geography',582,'Total area: 477 km2; land area: 477 km2;
includes Saipan, Rota, and Tinian
Comparative area: slightly more than 2.5
times the size of Washington, DC
Land boundaries: none
Coastline: 1 ,482 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 3 nm
Climate: tropical marine; moderated by
northeast trade winds, little seasonal tem-
perature variation; dry season December
to July, rainy season July to October
Terrain: southern islands are limestone
with level terraces and fringing coral
reefs; northern islands are volcanic; high-
est elevation is 471 meters (Mt. Tagpochu
on Saipan)
Natural resources: arable land, fish
Land use: 1% arable land; NA% perma-
nent crops; 19% meadows and pastures;
NA% forest and woodland; NA% other
Environment: Mt. Pagan is an active vol-
cano (last erupted in October 1 988); sub-
ject to typhoons during the rainy season
Note: strategic location 5,635 km west-
southwest of Honolulu in the North Pa-
cific Ocean, about three-quarters of the
way between Hawaii and the Philippines
Total area: 212.460 fan1: land area:
212,460 fair
Comparative area: slightly smaller than
Kansas
Land hiiaadniri 1.374 km total; Saudi
Arabia 676 fan, UAE 410 km. PDRY 288
km
Coasdme: 2,092 fan
Maritime claims:
Continental skeif: to be denned
Extended economic zone: 200 nm
Territorial sea: 12 an
DJjpntti. Administrative Line with
PDRY. BO defined boandary with most of
UAE. Administrative Line in far north
nhnali dry desert; hot, hnmid along
coast; hot, dry interior; strong soathwest
summer monsoon (May to September) in
far sooth
TerranE vast lAJilial dueil plain, rvgcjed
monntains ia north and soath
Nararai ujomcti: cmde oiL copper, as-
bestos, witte marble.
NEGL%
permanent crops; 5%
tares; 0% forest and
, NEGL% irrigated
and pas-
large
il fresh
strategic location with ''.
foot-
Strait of Hormaz (17% of world''s ofl pn>-
i transits this pan
i Gatf to Arabeui Seal
1. 457.064 (Jary 19901 growth
rate 3.1% (19901
Barn rate 43 births/1.000 popabtioa
Death rale 12 deaths/ 1. 000 popnbtion
•M
Oman (continued)
Net migration rate: 0 migrants/ 1 ,000 pop-
ulation (1990)
Infant mortality rate: 105 deaths/ 1,000
live births (1990)
Life expectancy at birth: 56 years male,
58 years female (1990)
Total fertility rate: 6.8 children born/
woman (1990)
Nationality: noun — Omani(s); adjective —
Omani
Ethnic divisions: almost entirely Arab,
with small Balochi, Zanzibar!, and Indian
groups
Religion: 75% Ibadhi Muslim; remainder
Sunni Muslim, Shi''a Muslim, some Hindu
Language: Arabic (official); English, Balo-
chi, Urdu, Indian dialects
Literacy: 20%
Labor force: 430,000; 60% agriculture
(est.); 58% are non-Omani
Organized labor: trade unions are illegal
Total area: 458 km2; land area: 458 km2
Comparative area: slightly more than 2.5
times the size of Washington, DC
Land boundaries: none
Coastline: 1,519 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 3 nm
Climate: wet season May to November;
hot and humid
Terrain: islands vary geologically from the
high mountainous main island of Babel-
thuap to low, coral islands usually fringed
by large barrier reefs
Natural resources: forests, minerals (espe-
cially gold), marine products; deep-seabed
minerals
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other
Environment: subject to typhoons from
June to December; archipelago of six is-
land groups totaling over 200 islands in
the Caroline chain
Note: important location 850 km south-
east of the Philippines; includes World
War II battleground of Peleliu and world-
famous rock islands
Total area: 165,384,000 km2; includes
Arafura Sea, Banda Sea, Bellingshausen
Sea, Bering Sea, Bering Strait, Coral Sea,
East China Sea, Gulf of Alaska, Makas-
sar Strait, Philippine Sea, Ross Sea, Sea
of Japan, Sea of Okhotsk, South China
Sea, Tasman Sea, and other tributary wa-
ter bodies
Comparative area: slightly less than 18
times the size of the US; the largest ocean
(followed by the Atlantic Ocean, Indian
Ocean, and Arctic Ocean); covers about
one-third of the global surface; larger
than the total land area of the world
Coastline: 135,663km
Climate: the western Pacific is
monsoonal — a rainy season occurs during
the summer months, when moisture-laden
winds blow from the ocean over the land,
and a dry season during the winter
months, when dry winds blow from the
Asian land mass back to the ocean
Terrain: surface in the northern Pacific
dominated by a clockwise, warm water
gyre (broad, circular system of currents)
and in the southern Pacific by a counter-
clockwise, cool water gyre; sea ice occurs
in the Bering Sea and Sea of Okhotsk
during winter and reaches maximum
northern extent from Antarctica in Octo-
ber; the ocean floor in the eastern Pacific
is dominated by the East Pacific Rise,
while the western Pacific is dissected by
deep trenches; the world''s greatest depth
is 10,924 meters in the Marianas Trench
Natural resources: oil and gas fields, poly-
metallic nodules, sand and gravel aggre-
gates, placer deposits, fish
Environment: endangered marine species
include the dugong, sea lion, sea otter,
seals, turtles, and whales; oil pollution in
Philippine Sea and South China Sea; dot-
ted with low coral islands and rugged vol-
canic islands in the southwestern Pacific
Ocean; subject to tropical cyclones (ty-
phoons) in southeast and east Asia from
May to December (most frequent from
July to October); tropical cyclones (hurri-
canes) may form south of Mexico and
strike Central America and Mexico from
June to October (most common in August
and September); southern shipping lanes
subject to icebergs from Antarctica; occa-
sional El Nifio phenomenon occurs off the
coast of Peru when the trade winds
slacken and the warm Equatorial Coun-
tercurrent moves south, which kills the
plankton that is the primary food source
for anchovies; consequently, the anchovies
move to better feeding grounds, causing
resident marine birds to starve by the
thousands because of their lost food
source
Note: the major choke points are the Ber-
ing Strait, Panama Canal, Luzon Strait,
and the Singapore Strait; the Equator di-
vides the Pacific Ocean into the North
Pacific Ocean and the South Pacific
Ocean; ships subject to superstructure ic-
ing in extreme north from October to
May and in extreme south from May to
October; persistent fog in the northern
Pacific from June to December is a haz-
ard to shipping; surrounded by a zone of
violent volcanic and earthquake activity
sometimes referred to as the Pacific Ring
of Fire','336bd9da64ff5b692ac7499c9391684cb2fbb46b926d75622b0acb8efbdf24fa','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f23a03ec7891a937c431095365521b4afdbf4b7b3879cbf22c56a47341032b1',1981,'PA','Panama','geography',587,'Total area: 78,200 km2; land area: 75,990
km2
Comparative area: slightly smaller than
South Carolina
Land boundaries: 555 km total; Colombia
225 km, Costa Rica 330 km
Coastline: 2,490 km
Maritime claims:
Territorial sea: 200 nm
Climate: tropical; hot, humid, cloudy; pro-
longed rainy season (May to January),
short dry season (January to May)
Terrain: interior mostly steep, rugged
mountains and dissected, upland plains;
coastal areas largely plains and rolling
hills
Natural resources: copper, mahogany for-
ests, shrimp
Land use: 6% arable land; 2% permanent
crops; 15% meadows and pastures; 54%
forest and woodland; 23% other; includes
NEGL% irrigated
Environment: dense tropical forest in east
and northwest
Note: strategic location on eastern end of
isthmus forming land bridge connecting
North and South America; controls Pan-
ama Canal that links North Atlantic
Ocean via Caribbean Sea with North Pa-
cific Ocean','764a17abc5985741618d531ec11a5131e70464c2b1f0ebe00c500424d4d2e2f5','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91c52895e7e1025bb2df5b2fd39002b0e50fa9bb936adbb2b175c61a044ffe0e',1981,'PG','Papua New Guinea','geography',593,'Total area: 461,690 km2; land area:
451,710km2
Comparative area: slightly larger than
California
Land boundary: 820 km with Indonesia
Coastline: 5,152km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; northwest monsoon (De-
cember to March), southeast monsoon
(May to October); slight seasonal tempera-
ture variation
Terrain: mostly mountains with coastal
lowlands and rolling foothills
Natural resources: gold, copper, silver,
natural gas, timber, oil potential
Land use: NEGL% arable land; 1% per-
manent crops; NEGL% meadows and pas-
tures; 71% forest and woodland; 28%
other
Environment: one of world''s largest
swamps along southwest coast; some ac-
tive volcanos; frequent earthquakes
Note: shares island of New Guinea with','9ba2874a54d98e12e53ee2c34016d2fbe9956ccdfd4f702fcbf39aace32601ae','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9663622fccda92dc66fc26c0e9c0150985c3df2820421a3144b9df8eccdb0cfb',1981,'PY','Paraguay','geography',596,'Total area: undetermined
Comparative area: undetermined
Land boundaries: none
Coastline: 518 km
Maritime claims: undetermined
Disputes: occupied by China, but claimed
by Taiwan and Vietnam
Climate: tropical
Terrain: undetermined
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: subject to typhoons
Note: located 400 km east of Vietnam in
the South China Sea about one-third of
the way between Vietnam and the Philip-
pines
Total area: 406,750 km2; land area:
397,300 km2
Comparative area: slightly smaller than
California
Land boundaries: 3,920 km total; Argen-
tina 1,880 km, Bolivia 750 km, Brazil
1,290km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: short section of the boundary
with Brazil (just west of Guaira Falls on
the Rio Parana) is in dispute
Climate: varies from temperate in east to
semiarid in far west
Terrain: grassy plains and wooded hills
east of Rio Paraguay; Gran Chaco region
west of Rio Paraguay mostly low, marshy
plain near the river, and dry forest and
thorny scrub elsewhere
Natural resources: iron ore, manganese,
limestone, hydropower, timber
Land use: 20% arable land; 1% permanent
crops; 39% meadows and pastures; 35%
forest and woodland; 5% other; includes
NEGL% irrigated
Environment: local flooding in southeast
(early September to June); poorly drained
plains may become boggy (early October
to June)
Note: landlocked; buffer between Argen-
tina and Brazil','500a3224a70cad33ca77c34dea5d1bab676ea0e8d57ad71b8ed74a2b34819378','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91ff84b67fe5876a8897f1627245f5287546b7d5be4d7187e15c1ff19176124d',1981,'PE','Peru','geography',600,'Total area: 1,285,220 km2; land area:
1,280,000km2
Comparative area: slightly smaller than
Alaska
Land boundaries: 6,940 km total; Bolivia
900 km, Brazil 1,560 km, Chile 160 km,
Colombia 2,900 km, Ecuador 1 ,420 km
Coastline: 2,414 km
Maritime claims:
Territorial sea: 200 nm
Disputes: two sections of the boundary
with Ecuador are in dispute
Climate: varies from tropical in east to dry
desert in west
Terrain: western coastal plain (costa), high
and rugged Andes in center (sierra), east-
ern lowland jungle of Amazon Basin
(selva)
Natural resources: copper, silver, gold, pe-
troleum, timber, fish, iron ore, coal, phos-
phate, potash
Land use: 3% arable land; NEGL% per-
manent crops; 21% meadows and pastures;
55% forest and woodland; 21% other; in-
cludes 1% irrigated
Environment: subject to earthquakes, tsu-
namis, landslides, mild volcanic activity;
deforestation; overgrazing; soil erosion;
desertification; air pollution in Lima
Note: shares control of Lago Titicaca,
world''s highest navigable lake, with Bo-
livia','a1728be4444ac318f13833798372a9ef8180d2e344becded56b494d4e69936c7','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8536619164ea8c77b430cfe5a2dca03aad84072451e1527ee258aa66e5e41e1a',1981,'PN','Pitcairn','geography',605,'Total area: 47 km2; land area: 47 km2
Comparative area: about 0.3 times the size
of Washington, DC
Land boundaries: none
Coastline: 51 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical, hot, humid, modified by
southeast trade winds; rainy season (No-
vember to March)
Terrain: rugged volcanic formation; rocky
coastline with cliffs
Natural resources: miro trees (used for
handicrafts), fish
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other
Environment: subject to typhoons (espe-
cially November to March)
Note: located in the South Pacific Ocean
about halfway between Peru and New
Zealand','7a71c62cab9b3aa1e8dcff618e96ae65686272e270428fbfb24a6d5c31ad0a2b','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7691ce6b41e51652cdea9424a860ca96e84e933fea1fd6a7d9020aef6baf8870',1981,'PL','Poland','geography',611,'Total area: 312,680 km2; land area:
304,510 km2
Comparative area: slightly smaller than
New Mexico
Land boundaries: 2,980 km total; Czecho-
slovakia 1,309 km, GDR 456 km, USSR
1,215km
Coastline: 491 km
Maritime claims:
Territorial sea: 1 2 nm
Climate: temperate with cold, cloudy,
moderately severe winters with frequent
precipitation; mild summers with frequent
showers and thundershowers
Terrain: mostly flat plain, mountains along
southern border
Natural resources: coal, sulfur, copper,
natural gas, silver, lead, salt
Land use: 46% arable land; 1% permanent
crops; 1 3% meadows and pastures; 28%
forest and woodland; 1 2% other; includes
NEGL% irrigated
Environment: plain crossed by a few north-
flowing, meandering streams; severe air
and water pollution in south
Note: historically, an area of conflict be-
cause of flat terrain and the lack of natu-
ral barriers on the North European Plain','ce2fabe8a2a670a6c621dafb98b2e05d02b63e9332697791b140394f30f1371a','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e55158042e00155265655af05204efafa9ee5a9ea20f10a5cabde16c20a3ba1b',1981,'PT','Portugal','geography',614,'Total area: 92,080 km2; land area: 91,640
km2; includes Azores and Madeira Islands
Comparative area: slightly smaller than
Indiana
Land boundary: 1,214 km with Spain
Coastline: 1,793 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: Macau is scheduled to become a
Special Administrative Region of China in
1999; East Timor question with Indonesia
Climate: maritime temperate; cool and
rainy in north, warmer and drier in south
Terrain: mountainous north of the Tagus,
rolling plains in south
Natural resources: fish, forests (cork),
tungsten, iron ore, uranium ore, marble
Land use: 32% arable land; 6% permanent
crops; 6% meadows and pastures; 40%
forest and woodland; 1 6% other; includes
7% irrigated
Environment: Azores subject to severe
earthquakes
Note: Azores and Madeira Islands occupy
strategic locations along western sea ap-
proaches to Strait of Gibraltar','abe86c8d7d9db364b65e64af79f198a3f99b9fe5a47b39fd5929ee110b7fae01','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('312f66af3940e544316f2fb63affa3c97470ba5291f16b11eb0cf2f934f8be6e',1981,'PR','Puerto Rico','geography',618,'Total area: 9,104 km2; land area: 8,959
km2
Comparative area: slightly less than three
times the size of Rhode Island
Land boundaries: none
Coastline: 501 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical marine, mild, little sea-
sonal temperature variation
Terrain: mostly mountains with coastal
plain belt in north; mountains precipitous
to sea on west coast
Natural resources: some copper and
nickel; potential for onshore and offshore
crude oil
Land use: 8% arable land; 9% permanent
crops; 51% meadows and pastures; 25%
forest and woodland; 7% other
Environment: many small rivers and high
central mountains ensure land is well wa-
tered; south coast relatively dry; fertile
coastal plain belt in north
Note: important location between the Do-
minican Republic and the Virgin Islands
group along the Mona Passage — a key
shipping lane to the Panama Canal; San
Juan is one of the biggest and best natural
harbors in the Caribbean
Total area: 6.5 km2; land area: 6.5 km2
Comparative area: about 1 1 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 19.3 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claimed by the Republic of the','73397349f3b84a5fc6f93ad4aa555e2f2c4ca21f29b4722b42a7d669ea33e7b8','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8572482f9038456f2f111c803d9cd89686f28da1ed38ed2196f5bc27ea12ed1d',1981,'QA','Qatar','geography',624,'Total area: 1 1,000 km2; land area: 1 1,000
km2
Comparative area: slightly smaller than
Connecticut
Land boundaries: 60 km total; Saudi Ara-
bia 40 km, UAE 20 km
Coastline: 563 km
Maritime claims:
Continental shelf: not specific
Exclusive fishing zone: as delimited
with neighboring states, or to limit of
shelf, or to median line
Extended economic zone: to median
line
Territorial sea: 3 nm
Disputes: boundary with UAE is in dis-
pute; territorial dispute with Bahrain over
the Hawar Islands
Climate: desert; hot, dry; humid and sultry
in summer
Terrain: mostly flat and barren desert cov-
ered with loose sand and gravel
Natural resources: crude oil, natural gas,
fish
Land use: NEGL% arable land; 0% per-
manent crops; 5% meadows and pastures;
0% forest and woodland; 95% other
Environment: haze, duststorms, sandstorms
common; limited freshwater resources
mean increasing dependence on
large-scale desalination facilities .
Note: strategic location in central Persian
Gulf near major crude oil sources
Total area: 2,510 km2; land area: 2,500
km2
Comparative area: slightly smaller than
Rhode Island
Land boundaries: none
Coastline: 201 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical, but moderates with ele-
vation; cool and dry from May to Novem-
ber, hot and rainy from November to
April
Terrain: mostly rugged and mountainous;
fertile lowlands along coast
Natural resources: fish, arable land
Land use: 20% arable land; 2% permanent
crops; 4% meadows and pastures; 35%
forest and woodland; 39% other; includes
2% irrigated
Environment: periodic devastating cyclones
Note: located 750 km east of Madagascar
in the Indian Ocean','c15b76797b63ac055508d7ac5f3b620e2175485c80751c2e33d606058d7be155','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f135d4d9014cba732b4bf188f916355cdb55aa33f67c88a5cf92a276f11206a',1981,'RW','Rwanda','geography',627,'Total area: 26,340 km2; land area: 24,950
km2
Comparative area: slightly smaller than
Maryland
Land boundaries: 893 km total; Burundi
290 km, Tanzania 217 km, Uganda 169
km, Zaire 217 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: temperate; two rainy seasons
(February to April, November to Janu-
ary); mild in mountains with frost and
snow possible
Terrain: mostly grassy uplands and hills;
mountains in west
Natural resources: gold, cassiterite (tin
ore), wolframite (tungsten ore), natural
gas, hydropower
Land use: 29% arable land; 1 1 % perma-
nent crops; 1 8% meadows and pastures;
10% forest and woodland; 32% other; in-
cludes NEGL% irrigated
Environment: deforestation; overgrazing;
soil exhaustion; soil erosion; periodic
droughts
Note: landlocked
Total area: 410 km2; land area: 410 km2;
includes Ascension, Gough Island, Inac-
cessible Island, Nightingale Island, and
Tristan da Cunha
Comparative area: slightly more than 2.3
times the size of Washington, DC
Land boundaries: none
Coastline: 60 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; marine; mild, tempered
by trade winds
Terrain: rugged, volcanic; small scattered
plateaus and plains
Natural resources: fish; Ascension is a
breeding ground for sea turtles and sooty
terns; no minerals
Land use: 7% arable land; 0% permanent
crops; 7% meadows and pastures; 3% for-
est and woodland; 83% other
Environment: very few perennial streams
Note: Napoleon Bonaparte''s place of exile
and burial; the remains were taken to
Paris in 1840
Total area: 360 km2; land area: 360 km2
Comparative area: slightly more than
twice the size of Washington, DC
Land boundaries: none
Coastline: 135 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: subtropical tempered by constant
sea breezes; little seasonal temperature
variation; rainy season (May to Novem-
ber)
Terrain: volcanic with mountainous interi-
ors
Natural resources: negligible
Land use: 22% arable land; 17% perma-
nent crops; 3% meadows and pastures;
17% forest and woodland; 41% other
Environment: subject to hurricanes (July to
October)
Note: located 320 km southeast of Puerto
Rico
Total area: 620 km2; land area: 610 km2
Comparative area: slightly less than 3.5
times the size of Washington, DC
Land boundaries: none
Coastline: 1 58 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical, moderated by northeast
trade winds; dry season from January to
April, rainy season from May to August
Terrain: volcanic and mountainous with
some broad, fertile valleys
Natural resources: forests, sandy beaches,
minerals (pumice), mineral springs, geo-
thermal potential
Land use: 8% arable land; 20% permanent
crops; 5% meadows and pastures; 1 3%
forest and woodland; 54% other; includes
2% irrigated
Environment: subject to hurricanes and
volcanic activity; deforestation; soil erosion
Note: located 700 km southeast of Puerto
Rico
Total area: 242 km2; land area: 242 km2;
includes eight small islands in the St.
Pierre and the Miquelon groups
Comparative area: slightly less than 1.5
times the size of Washington, DC
Land boundaries: none
Coastline: 120 km
Maritime claims:
Contiguous zone: 1 2 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: focus of maritime boundary dis-
pute between Canada and France
Climate: cold and wet, with much mist
and fog; spring and autumn are windy
Terrain: mostly barren rock
Natural resources: fish, deep-water ports
Land use: 1 3% arable land; 0% permanent
crops; 0% meadows and pastures; 4% for-
est and woodland; 83% other
Environment: vegetation scanty
Note: located 25 km south of Newfound-
land, Canada, in the North Atlantic
Ocean','65d146b1b0d9d3a7b1fadfd1c69cbb739188c1ed5a3857e95aae8f647b199f15','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19c31f32c2c9a2ed70683bf8b4b53eaae6dfa6ade446e97554058e626c78285a',1981,'SM','San Marino','geography',631,'Total area: 60 km2; land area: 60 km2
Comparative area: about 0.3 times the size
of Washington, DC
Land boundary: 39 km with Italy
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: Mediterranean; mild to cool win-
ters; warm, sunny summers
Terrain: rugged mountains
Natural resources: building stones
Land use: 17% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 83% other
Environment: dominated by the Appenines
Note: landlocked; world''s smallest repub-
lic; enclave of Italy','9db4eaef1f97129d8678b2633e6ecab6d7ba47141fe030a881d69c04f5b12d6d','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3a02731b4322b556df65baacabef810c056233b5ff530407dfbfd761844624d',1981,'SN','Senegal','geography',639,'Total area: 196,190 km2; land area:
192,000 km2
Comparative area: slightly smaller than
South Dakota
Land boundaries: 2,640 km total; The
Gambia 740 km, Guinea 330 km, Guinea-
Bissau 338 km, Mali 419 km, Mauritania
813km
Coastline: 531 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Disputes: short section of the boundary
with The Gambia is indefinite; the Inter-
national Court of Justice (ICJ) rendered
its decision on the Guinea-Bissau/Senegal
maritime boundary in favor of Senegal —
that decision has been rejected by Guinea-
Bissau; boundary with Mauritania
Climate: tropical; hot, humid; rainy season
(December to April) has strong southeast
winds; dry season (May to November)
dominated by hot, dry harmattan wind
Terrain: generally low, rolling, plains ris-
ing to foothills in southeast
Natural resources: fish, phosphates, iron
ore
Land use: 27% arable land; 0% permanent
crops; 30% meadows and pastures; 31%
forest and woodland; 12% other; includes
1% irrigated
Environment: lowlands seasonally flooded;
deforestation; overgrazing; soil erosion;
desertification
Note: The Gambia is almost an enclave','70688ca8208d0616f71f6845d77afd6d0c8389f481e45b635194f8f0cee24bc2','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a375d55989844af192885168b2e3b8894ea5678f5c6c14558f0fdd12c0b5f39',1981,'SC','Seychelles','geography',644,'Total area: 455 km2; land area: 455 km2
Comparative area: slightly more than 2.5
times the size of Washington, DC
Land boundaries: none
Coastline: 491 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claims Tromelin Island
Climate: tropical marine; humid; cooler
season during southeast monsoon (late
May to September); warmer season during
northwest monsoon (March to May)
Terrain: Mahe Group is granitic, narrow
coastal strip, rocky, hilly; others are coral,
flat, elevated reefs
Natural resources: fish, copra, cinnamon
trees
Land use: 4% arable land; 18% permanent
crops; 0% meadows and pastures; 1 8%
forest and woodland; 60% other
Environment: lies outside the cyclone belt,
so severe storms are rare; short droughts
possible; no fresh water, catchements col-
lect rain; 40 granitic and about 50 coral-
line islands
Note: located north-northeast of Madaga-
scar in the Indian Ocean','fbfaa503ab26e526826b5bb41dbf729a0700ec2d1487417d613534417eede25b','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14ea039f85250a8246b0e2d196d2314e5ec12fef49a1da0853f8b9e94dba3ae2',1981,'SL','Sierra Leone','geography',650,'Total area: 71,740 km2; land area: 71,620
km2
Comparative area: slightly smaller than
South Carolina
Land boundaries: 958 km total; Guinea
652 km, Liberia 306 km
Coastline: 402 km
Maritime claims:
Territorial sea: 200 nm
Climate: tropical; hot, humid; summer
rainy season (May to December); winter
dry season (December to April)
Terrain: coastal belt of mangrove swamps,
wooded hill country, upland plateau,
mountains in east
Natural resources: diamonds, titanium ore,
bauxite, iron ore, gold, chromite
Land use: 25% arable land; 2% permanent
crops; 3 1 % meadows and pastures; 29%
forest and woodland; 1 3% other; includes
NEGL% irrigated
Environment: extensive mangrove swamps
hinder access to sea; deforestation; soil
degradation','1542cf779d26ecb72afc58a74104e2c5bdf6045bb08c98d9b8a73f96ddccd7d3','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e86dcb17c24eb2d96cace54f3823f9c9cc86db5cae790e3fd4dda1f6a1a4722',1981,'SG','Singapore','geography',654,'Total area: 632.6 km2; land area: 622.6
km2
Comparative area: slightly less than 3.5
times the size of Washington, DC
Land boundaries: none
Coastline: 193 km
Maritime claims:
Exclusive fishing zone: not specific
Territorial sea: 3 nm
Climate: tropical; hot, humid, rainy; no
pronounced rainy or dry seasons; thunder-
storms occur on 40% of all days (67% of
days in April)
Terrain: lowland; gently undulating cen-
tral plateau contains water catchment
area and nature preserve
Natural resources: fish, deepwater ports
Land use: 4% arable land; 7% permanent
crops; 0% meadows and pastures; 5% for-
est and woodland; 84% other
Environment: mostly urban and industrial-
ized
Note: focal point for Southeast Asian sea
routes
Total area: 255,800 km2; land area:
255,400 km2
Comparative area: slightly larger than
Wyoming
Land boundaries: 2,961 km total; Albania
486 km, Austria 311 km, Bulgaria 539
km, Greece 246 km, Hungary 631 km,
Italy 202 km, Romania 546 km
Coastline: 3,935 km (including 2,414 km
offshore islands)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 1 2 nm
Disputes: Kosovo question with Albania;
Macedonia question with Bulgaria and','444272a846d989eea43433b57b25d52701c7571a9b63ff795ce09a2953b080ce','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02fff54785747b47e2d621326b00c4d1439e7ea76435dc706c733b759ab316a9',1981,'SB','Solomon Islands','geography',657,'Total area: 28,450 km2; land area: 27,540
km2
Comparative area: slightly larger than
Maryland
Land boundaries: none
Coastline: 5,313 km
Maritime claims: (measured from claimed
archipelagic baselines)
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical monsoon; few extremes
of temperature and weather
Terrain: mostly rugged mountains with
some low coral atolls
Natural resources: fish, forests, gold, baux-
ite, phosphates
Land use: 1% arable land; 1% permanent
crops; 1% meadows and pastures; 93%
forest and woodland; 4% other
Environment: subject to typhoons, which
are rarely destructive; geologically active
region with frequent earth tremors
Note: located just east of Papua New
Guinea in the South Pacific Ocean','8eb0b31ed19bd53f4bbb2461ff9104ed1dd3d9298397985a7fd49eabd0c832b6','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aec6a2b6ed1b81cbb8b5f37e17f537f3da6de500cefb59127e917b160ca786da',1981,'SO','Somalia','geography',663,'Total area: 637,660 km2; land area:
627,340 km2
Comparative area: slightly smaller than
Texas
Land boundaries: 2,340 km total; Djibouti
58 km, Ethiopia 1,600 km, Kenya 682 km
Coastline: 3,025 km
Maritime claims:
Territorial sea: 200 nm
Disputes: southern half of boundary with
Ethiopia is a Provisional Administrative
Line; territorial dispute with Ethiopia over
the Ogaden; possible claims to Djibouti,
Ethiopia, and Kenya based on unification
of ethnic Somalis
Climate: desert; northeast monsoon (De-
cember to February), cooler southwest
monsoon (May to October); irregular rain-
fall; hot, humid periods (tangambili) be-
tween monsoons
Terrain: mostly flat to undulating plateau
rising to hills in north
Natural resources: uranium, and largely
unexploited reserves of iron ore, tin, gyp-
sum, bauxite, copper, salt
Land use: 2% arable land; NEGL% per-
manent crops; 46% meadows and pastures;
14% forest and woodland; 38% other; in-
cludes 3% irrigated
Environment: recurring droughts; frequent
dust storms over eastern plains in summer;
deforestation; overgrazing; soil erosion;
desertification
Note: strategic location on Horn of Africa
along southern approaches to Bab el Man-
deb and route through Red Sea and Suez
Canal','86de72d88f748bc1118632c9ba794c7ef7cb374afcc3e617a9a357b668c7fcbe','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55a5e254d7da003f06647ac3372727095de11619a9f27a8602c799a416faa9c7',1981,'ZA','South Africa','geography',666,'Total area: 1,221,040 km2; land area:
1,221,040 km2; includes Walvis Bay, Ma-
rion Island, and Prince Edward Island
Comparative area: slightly less than twice
the size of Texas
Land boundaries: 4,973 km total; Bots-
wana 1,840 km, Lesotho 909 km, Mozam-
bique 491 km, Namibia 1,078 km, Swazi-
land 430 km, Zimbabwe 225 km
Coastline: 2,881 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Disputes: South Africa administered Na-
mibia until independence was achieved on
21 March 1990; possible future claim to
Walvis Bay by Namibia
Climate: mostly semiarid; subtropical
along coast; sunny days, cool nights
Terrain: vast interior plateau rimmed by
rugged hills and narrow coastal plain
Natural resources: gold, chromium, anti-
mony, coal, iron ore, manganese, nickel,
phosphates, tin, uranium, gem diamonds,
platinum, copper, vanadium, salt, natural
gas
Land use: 10% arable land; 1% permanent
crops; 65% meadows and pastures; 3%
forest and woodland; 21% other; includes
1% irrigated
Environment: lack of important arterial
rivers or lakes requires extensive water
conservation and control measures
Note: Walvis Bay is an exclave of South
Africa in Namibia; completely surrounds
Lesotho; almost completely surrounds
Swaziland','f977bfb90b20b1bd90ebf43e331e37ca7443baf3e3c944328ef5dd6be08c8bce','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba16263fce02f9e7c0d94af62961cf91e20de5899af7fc8317ac2245634f58cb',1981,'LK','Sri Lanka','geography',669,'Total area: less than 5 km2; land area:
less than 5 km2; includes 100 or so islets,
coral reefs, and sea mounts scattered over
the South China Sea
Comparative area: undetermined
Land boundaries: none
Coastline: 926 km
Maritime claims: undetermined
Disputes: China, Malaysia, the Philip-
pines, Taiwan, and Vietnam claim all or
part of the Spratly Islands
Climate: tropical
Terrain: flat
Natural resources: fish, guano; oil and nat-
ural gas potential
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: subject to typhoons; includes
numerous small islands, atolls, shoals, and
coral reefs
Note: strategically located near several
primary shipping lanes in the central
South China Sea; serious navigational
hazard
Total area: 65,610 km2; land area: 64,740
km2
Comparative area: slightly larger than
West Virginia
Land boundaries: none
Coastline: 1,340 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; monsoonal; northeast
monsoon (December to March); southwest
monsoon (June to October)
Terrain: mostly low, flat to rolling plain;
mountains in south-central interior
Natural resources: limestone, graphite,
mineral sands, gems, phosphates, clay
Land use: 1 6% arable land; 1 7% perma-
nent crops; 7% meadows and pastures;
37% forest and woodland; 23% other; in-
cludes 8% irrigated
Environment: occasional cyclones, torna-
dos; deforestation; soil erosion
Note: only 29 km from India across the
Palk Strait; near major Indian Ocean sea
lanes','ea3745375366fb32547485b1724d73e1fbc7d47d8796dd049a1531599db410ff','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f9563fcebf47a652ca6e3de455a096573dc26132768ff01eedd269265b66656',1981,'SD','Sudan','geography',674,'Total area: 2,505,810 km2; land area:
2,376,000 km2
Comparative area: slightly more than one
quarter the size of US
Land boundaries: 7,697 km total; Central
African Republic 1,165 km, Chad 1,360
km, Egypt 1,273 km, Ethiopia 2,221 km,
Kenya 232 km, Libya 383 km, Uganda
435 km, Zaire 628 km
Coastline: 853 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 1 2 nm
Disputes: international boundary and Ad-
ministrative Boundary with Kenya; inter-
national boundary and Administrative
Boundary with Egypt
Climate: tropical in south; arid desert in
north; rainy season (April to October)
Terrain: generally flat, featureless plain;
mountains in east and west
Natural resources: modest reserves of
crude oil, iron ore, copper, chromium ore,
zinc, tungsten, mica, silver, crude oil
Land use: 5% arable land; NEGL% per-
manent crops; 24% meadows and pastures;
20% forest and woodland; 51% other; in-
cludes 1% irrigated
Environment: dominated by the Nile and
its tributaries; dust storms; desertification
Note: largest country in Africa','4fe6d6d516e0e952ac915b90654249183157e30696e089b4d8c2737ab4856ef1','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78f7d31af59e134a34ecad797f64d3e4a637d6ba87e0958d3210d8b2c268c1d4',1981,'SR','Suriname','geography',679,'Total area: 163,270 km2; land area:
161,470km2
Comparative area: slightly larger than','70697d3bee952f86e8b0595b47696a3d85de10aee40c8f94cdbd09383886d7fc','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bb232e726ed1f11e887d42270d3fcc350f06c091dcfbf2663ee1fdad50d3163',1981,'GE','Georgia','geography',680,'Land boundaries: 1,707 km total; Brazil
597 km, French Guiana 510 km, Guyana
600 km
Coastline: 386 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claims area in French Guiana
between Litani Rivier and Riviere Ma-
rouini (both headwaters of the Lawa);
claims area in Guyana between New
(Upper Courantyne) and Courantyne/
Kutari Rivers (all headwaters of the Cou-
rantyne)
Climate: tropical; moderated by trade
winds
Terrain: mostly rolling hills; narrow
coastal plain with swamps
Natural resources: timber, hydropower
potential, fish, shrimp, bauxite, iron ore,
and modest amounts of nickel, copper,
platinum, gold
Land use: NEGL% arable land; NEGL%
permanent crops; NEGL% meadows and
pastures; 97% forest and woodland; 3%
other; includes NEGL% irrigated
Environment: mostly tropical rain forest
Total area: 62,049 km2; land area: 62,049
km2; includes Spitsbergen and Bjerneya
(Bear Island)
Comparative area: slightly smaller than
West Virginia
Land boundaries: none
Coastline: 3,587 km
Maritime claims:
Contiguous zone: 10 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm uni-
laterally claimed by Norway, not recog-
nized by USSR
Territorial sea: 4 nm
Disputes: focus of maritime boundary dis-
pute between Norway and USSR
Climate: arctic, tempered by warm North
Atlantic Current; cool summers, cold win-
ters; North Atlantic Current flows along
west and north coasts of Spitsbergen,
keeping water open and navigable most of
the year
Terrain: wild, rugged mountains; much of
high land ice covered; west coast clear of
ice about half the year; fjords along west
and north coasts
Natural resources: coal, copper, iron ore,
phosphate, zinc, wildlife, fish
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other; there are
no trees and the only bushes are crow-
berry and cloudberry
Environment: great calving glaciers de-
scend to the sea
Note: located 445 km north of Norway
where the Arctic Ocean, Barents Sea,
Greenland Sea, and Norwegian Sea meet
Total area: 17,360 km2; land area: 17,200
km2
Comparative area: slightly smaller than
New Jersey
Land boundaries: 535 km total; Mozambi-
que 105 km, South Africa 430 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: varies from tropical to near tem-
perate
Terrain: mostly mountains and hills; some
moderately sloping plains
Natural resources: asbestos, coal, clay, tin,
hydroelelectric power, forests, and small
gold and diamond deposits
Land use: 8% arable land; NEGL% per-
manent crops; 67% meadows and pastures;
6% forest and woodland; 19% other; in-
cludes 2% irrigated
Environment: overgrazing; soil degrada-
tion; soil erosion
Note: landlocked; almost completely sur-
rounded by South Africa
Land boundaries: 1,424 km total; Algeria
965 km, Libya 459 km
Coastline: 1,148 km
Maritime claims:
Territorial sea: 12 nm
Disputes: maritime boundary dispute with','3fff75a84d6a7cbcc7ad3b17ef5389f3d12724f3d77a942d0ebdbbfdac377d2c','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8752100b5e3cc99ec3f17a4523c4a286c3a5c5b9ff10d58e38bb36895566141d',1981,'SE','Sweden','geography',686,'Total area: 449,960 km2; land area:
411,620km2
Comparative area: slightly larger than
California
Land boundaries: 2,193 km total; Finland
536 km, Norway 1,657 km
Coastline: 3,218 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Climate: temperate in south with cold,
cloudy winters and cool, partly cloudy
summers; subarctic in north
Terrain: mostly flat or gently rolling low-
lands; mountains in west
Natural resources: zinc, iron ore, lead,
copper, silver, timber, uranium, hydro-
power potential
Land use: 7% arable land; 0% permanent
crops; 2% meadows and pastures; 64%
forest and woodland; 27% other; includes
NEGL% irrigated
Environment: water pollution; acid rain
Note: strategic location along Danish
Straits linking Baltic and North Seas','efe7cfed00ffc02c67951db1700dc2f9959e48f0cf6117f2b904aea30d5a9cdf','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b782ea99862576f1e13a5156dfe908aa9a09a1c12d9f0811b1d5b1e52b60081f',1981,'CH','Switzerland','geography',692,'Total area: 41,290 km2; land area: 39,770
km2
Comparative area: slightly more than
twice the size of New Jersey
Land boundaries: 1,852 km total; Austria
164 km, France 573 km, Italy 740 km,
Liechtenstein 41 km, FRG 334 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: temperate, but varies with alti-
tude; cold, cloudy, rainy /snowy winters;
cool to warm, cloudy, humid summers
with occasional showers
Terrain: mostly mountains (Alps in south.
Jura in northwest) with a central plateau
of rolling hills, plains, and large lakes
Natural resources: hydropower potential,
timber, salt
Land use: 10% arable land; 1% permanent
crops; 40% meadows and pastures; 26%
forest and woodland; 23% other; includes
1% irrigated
Environment: dominated by Alps
Note: landlocked; crossroads of northern
and southern Europe
Total area: 185,180 km2; land area:
184,050 km2 (including 1,295 km2 of
Israeli-occupied territory)
Comparative area: slightly larger than
North Dakota
Land boundaries: 2,253 km total; Iraq 605
km, Israel 76 km, Jordan 375 km, Leba-
non 375 km, Turkey 822 km
Coastline: 193 km
Maritime claims:
Contiguous zone: 6 nm beyond territo-
rial sea limit
Territorial sea: 35 nm
Disputes: separated from Israel by the
1949 Armistice Line; Golan Heights is
Israeli occupied; Hatay question with Tur-
key; periodic disputes with Iraq over
Euphrates water rights; ongoing dispute
over water development plans by Turkey
for the Tigris and Euphrates Rivers;
Kurdish question among Iran, Iraq, Syria,
Turkey, and the USSR
Climate: mostly desert; hot, dry, sunny
summers (June to August) and mild, rainy
winters (December to February) along
coast
Terrain: primarily semiarid and desert
plateau; narrow coastal plain; mountains
in west
Natural resources: crude oil, phosphates,
chrome and manganese ores, asphalt, iron
ore, rock salt, marble, gypsum
Land use: 28% arable land; 3% permanent
crops; 46% meadows and pastures; 3%
forest and woodland; 20% other; includes
3% irrigated
Environment: deforestation; overgrazing;
soil erosion; desertification
Note: there are 35 Jewish settlements in
the Israeli-occupied Golan Heights
Total area: 945,090 km2; land area:
886,040 km2
Comparative area: slightly larger than
twice the size of California
Land boundaries: 3,402 km total; Burundi
451 km, Kenya 769 km, Malawi 475 km,
Mozambique 756 km, Rwanda 217 km,
Uganda 396 km, Zambia 338 km
Coastline: 1,424 km
Maritime claim:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: boundary dispute with Malawi
in Lake Nyasa; Tanzania-Zaire-Zambia
tripoint in Lake Tanganyika may no
longer be indefinite since it is reported
that the indefinite section of the Zaire-
Zambia boundary has been settled
Climate: varies from tropical along coast
to temperate in highlands
Terrain: plains along coast; central pla-
teau; highlands in north, south
Natural resources: hydropower potential,
tin, phosphates, iron ore, coal, diamonds,
gemstones, gold, natural gas, nickel
Land use: 5% arable land; 1% permanent
crops; 40% meadows and pastures; 47%
forest and woodland; 7% other; includes
NEGL% irrigated
Environment: lack of water and tsetse fly
limit agriculture; recent droughts affected
marginal agriculture; Kilimanjaro is high-
est point in Africa','6a2faf5f1b7f655ec6332dcae8fa53802d0b1579be05769a558f444339b52039','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99f98eaa1b334994b5e5193f1c30db7c0dd569be9c07be17a949db71ef4610ad',1981,'TG','Togo','geography',697,'Total area: 56,790 km2; land area: 54,390
km2
Comparative area: slightly smaller than
West Virginia
Land boundaries: 1,647 km total; Benin
644 km, Burkina 126 km, Ghana 877 km
Coastline: 56 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 30 nm
Climate: tropical; hot, humid in south; se-
miarid in north
Terrain: gently rolling savanna in north;
central hills; southern plateau; low coastal
plain with extensive lagoons and marshes
Natural resources: phosphates, limestone,
marble
Land use: 25% arable land; 1% permanent
crops; 4% meadows and pastures; 28%
forest and woodland; 42% other; includes
NEGL% irrigated
Environment: hot, dry harmattan wind can
reduce visibility in north during winter;
recent droughts affecting agriculture; de-
forestation','b6f6e7957b6a5148fbe6adbf1b4c406eca2f3297068aef242ed24e0f66dd1fab','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4cd6097b58a2cf104d89ead58686ae7d1ac699acdda3f315ab68b91e9dc2b54',1981,'TK','Tokelau','geography',701,'Total area: 10 km2; land area: 10 km2
Comparative area: about 1 7 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 101 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; moderated by trade
winds (April to November)
Terrain: coral atolls enclosing large la-
goons
Natural resources: negligible
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: lies in Pacific typhoon belt
Note: located 3,750 km southwest of Ho-
nolulu in the South Pacific Ocean, about
halfway between Hawaii and New Zea-
land','48ca8b44753aab7bbf2afd9bd9c7270ac78ae5d6336654a9faa79a67b1d96ef4','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b998d75434c8bfb1575eabe0ac66f2231e667e44cf62f7f0cda0d1d31e10ee0',1981,'TO','Tonga','geography',706,'Total area: 748 km2; land area: 718 km2
Comparative area: slightly more than four
times the size of Washington, DC
Land boundaries: none
Coastline: 419 km
Maritime claims:
Continental shelf: no specific limits
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; modified by trade winds;
warm season (December to May), cool
season (May to December)
Terrain: most islands have limestone base
formed from uplifted coral formation; oth-
ers have limestone overlying volcanic base
Natural resources: fish, fertile soil
Land use: 25% arable land; 55% perma-
nent crops; 6% meadows and pastures;
1 2% forest and woodland; 2% other
Environment: archipelago of 170 islands
(36 inhabited); subject to cyclones (Oc-
tober to April); deforestation
Note: located about 2,250 km north-
northwest of New Zealand, about two-
thirds of the way between Hawaii and','820aa6f63d2ead34fa3ed533ae3e81db25edc9e64a3eb5a9481d602addef9cad','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e979a69d64f9a2d4b272df1219aefd8b631b3cd35db07e4d9ffc3ae2a36dff5f',1981,'TT','Trinidad and Tobago','geography',710,'Total area: 5,130 km2; land area: 5,130
km2
Comparative area: slightly smaller than
Delaware
Land boundaries: none
Coastline: 362 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: maritime boundary with Vene-
zuela in the Gulf of Paria
Climate: tropical; rainy season (June to
December)
Terrain: mostly plains with some hills and
low mountains
Natural resources: crude oil, natural gas,
asphalt
Land use: 14% arable land; 17% perma-
nent crops; 2% meadows and pastures;
44% forest and woodland; 23% other; in-
cludes 4% irrigated
Environment: outside usual path of hurri-
canes and other tropical storms
Note: located 1 1 km from Venezuela','0dfe63898f463120ef314e15e6c098df0354ff718b907d360ba5f904de616682','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e82a6ae0067cfc3f847a4fa3fc6ee3e91bd2165522f52760b7fec56ba87f9b23',1981,'TC','Turks and Caicos Islands','geography',716,'Total area: 430 km2; land area: 430 km2
Comparative area: slightly less than 2.5
times the size of Washington, DC
Land boundaries: none
Coastline: 389 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; marine; moderated by
trade winds; sunny and relatively dry
Terrain: low, flat limestone; extensive
marshes and mangrove swamps
Natural resources: spiny lobster, conch-
Land use: 2% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 98% other
Environment: 30 islands (eight inhabited);
subject to frequent hurricanes
Note: located 190 km north of the Domin-
ican Republic in the North Atlantic
Ocean','ba5840edd699d345c215d16f4fca0a0af0c834dc54829fd0392e6095f821847c','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1966988289e49ed3d768f027d7c758a44406a6338ec419ee8871602441b57c72',1981,'TV','Tuvalu','geography',721,'Total area: 26 km2; land area: 26 km2
Comparative area: about 0.1 times the size
of Washington, DC
Land boundaries: none
Coastline: 24 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; moderated by easterly
trade winds (March to November); west-
erly gales and heavy rain (November to
March)
Terrain: very low-lying and narrow coral
atolls
Natural resources: fish
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: severe tropical storms are
rare
Note: located 3,000 km east of Papua
New Guinea in the South Pacific Ocean','908c332af8052ad79f9d7bf9321777f26b460fe0ce7170d4be95c1215b78c679','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35aa6e1fcc1b79202422c108c0ffe56cfb0490e22873ee0019f0c32ed54fb6c6',1981,'UG','Uganda','geography',725,'Total area: 236,040 km2; land area:
199,710km2
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,698 km total; Kenya
933 km, Rwanda 169 km, Sudan 435 km,
Tanzania 396 km, Zaire 765 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: tropical; generally rainy with two
dry seasons (December to February, June
to August); semiarid in northeast
Terrain: mostly plateau with rim of moun-
tains
Natural resources: copper, cobalt, lime-
stone, salt
Land use: 23% arable land; 9% permanent
crops; 25% meadows and pastures; 30%
forest and woodland; 1 3% other; includes
NEGL% irrigated
Environment: straddles Equator; deforesta-
tion; overgrazing; soil erosion
Note: landlocked','799d35a6a5329cb21b12830653e515a2d53469598a5b9455bbe32c4b852ac899','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f167e010c46ccd9152c43d6242113587b22a92764a03ec86bfdae69f1ad68ec8',1981,'AE','United Arab Emirates','geography',731,'Total area: 83,600 km2; land area: 83,600
km2
Comparative area: slightly smaller than
Maine
Land boundaries: 1,016 km total; Oman
410 km, Saudi Arabia 586 km, Qatar 20
km
Coastline: 1 ,448 km
Maritime claims:
Continental shelf: defined by bilateral
boundaries or equidistant line
Extended economic zone: 200 nm
Territorial sea: 3 nm
Disputes: boundary with Qatar is in dis-
pute; no defined boundary with Saudi
Arabia; no defined boundary with most of
Oman, but Administrative Line in far
north; claims three islands in the Persian
Gulf occupied by Iran (Jazlreh-ye Abu
Musa or Abu Musa, JazTreh-ye Tonb-e
Bozorg or Greater Tunb, and Jazlreh-ye
Tonb-e Kuchek or Lesser Tunb)
Climate: desert; cooler in eastern moun-
tains
Terrain: flat, barren coastal plain merging
into rolling sand dunes of vast desert
wasteland; mountains in east
Natural resources: crude oil and natural
gas
Land use: NEGL% arable land; NEGL%
permanent crops; 2% meadows and pas-
tures; NEGL% forest and woodland; 98%
other; includes NEGL% irrigated
Environment: frequent dust and sand
storms; lack of natural freshwater
resources being overcome by desalination
plants; desertification
Note: strategic location along southern
approaches to Strait of Hormuz, a vital
transit point for world crude oil','753827c0ac7039fee17fe977f1897e7dee53ed6e69510208036ce17e21e3cee6','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c77411e6565ac859761bef728ff143eb12fccf0bf9eebd5f62bdbdb7c94c18ed',1981,'GB','United Kingdom','geography',737,'Total area: 244,820 km2; land area:
241,590 km2; includes Rockall and Shet-
land Islands
Comparative area: slightly smaller than
Oregon
Land boundary: Ireland 360 km
Coastline: 12,429km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation or in accordance
with agreed upon boundaries
Exclusive fishing zone: 200 nm
Territorial sea: 1 2 nm
Disputes: maritime boundary with Ireland;
Northern Ireland question with Ireland;
Gibraltar question with Spain; Argentina
claims Falkland Islands (Islas Malvinas);
Argentina claims South Georgia and the
South Sandwich Islands; Mauritius claims
island of Diego Garcia in British Indian
Ocean Territory; Hong Kong is scheduled
to become a Special Administrative Re-
gion of China in 1997; Rockall continental
shelf dispute involving Denmark, Iceland,
and Ireland (Ireland and the UK have
signed a boundary agreement in the Rock-
all area); territorial claim in Antarctica
(British Antarctic Territory)
Climate: temperate; moderated by prevail-
ing southwest winds over the North At-
lantic Current; more than half of the days
are overcast
Terrain: mostly rugged hills and low
mountains; level to rolling plains in east
and southeast
Natural resources: coal, crude oil, natural
gas, tin, limestone, iron ore, salt, clay,
chalk, gypsum, lead, silica
Land use: 29% arable land; NEGL% per-
manent crops; 48% meadows and pastures;
9% forest and woodland; 14% other; in-
cludes 1% irrigated
Environment: pollution control measures
improving air, water quality; because of
321
United Kingdom (continued)
heavily indented coastline, no location is
more than 1 25 km from tidal waters
Note: lies near vital North Atlantic sea
lanes; only 35 km from France','90ca3176186f1640f8ac891b714a8eaee4db1d60b53c9e8dae54e85ed20c9510','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f816e63d5542936d9e1a79e4e7ac306e9725eb0112c926c7b52ff0b9476458a9',1981,'UY','Uruguay','geography',740,'Total area: 1 76,220 km2; land area:
173,620 km2
Comparative area: slightly smaller than
Washington State
Land boundaries: 1,564 km total; Argen-
tina 579 km, Brazil 985 km
Coastline: 660 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm (overflight and
navigation permitted beyond 12 nm)
Disputes: short section of boundary with
Argentina is in dispute; two short sections
of the boundary with Brazil are in dispute
(Arroyo de la Invernada area of the Rio
Quarai and the islands at the confluence
of the Rio Quarai and the Uruguay)
Climate: warm temperate; freezing tem-
peratures almost unknown
Terrain: mostly rolling plains and low
hills; fertile coastal lowland
Natural resources: soil, hydropower poten-
tial, minor minerals
Land use: 8% arable land; NEGL% per-
manent crops; 78% meadows and pastures;
4% forest and woodland; 10% other; in-
cludes 1% irrigated
Environment: subject to seasonally high
winds, droughts, floods','b583802527879133b94890214e9dc3f684c44cff9aacdce107716ca734080b03','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4587624ee2a3ba1d515e27c3cd3ccb55d837cabe981926451382fd94747f510b',1981,'VU','Vanuatu','geography',746,'«
Total area: 14,760 km2; land area: 14,760
km2; includes more than 80 islands
Comparative area: slightly larger than
Connecticut
Land boundary: none
Coastline: 2,528 km
Maritime claims: (measured from claimed
archipelagic baselines)
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; moderated by southeast
trade winds
Terrain: mostly mountains of volcanic ori-
gin; narrow coastal plains
Natural resources: manganese, hardwood
forests, fish
Land use: 1% arable land; 5% permanent
crops; 2% meadows and pastures; 1% for-
est and woodland; 91% other
Environment: subject to tropical cyclones
or typhoons (January to April); volcanism
causes minor earthquakes
Note: located 5,750 km southwest of Ho-
nolulu in the South Pacific Ocean about
three-quarters of the way between Hawaii
and Australia
Total area: 0.438 km2; land area: 0.438
km2
Comparative area: about 0.7 times the size
of The Mall in Washington, DC
Land boundary: 3.2 km with Italy
Coastline: none — landlocked
Maritime claims: none — landlocked
Climate: temperate; mild, rainy winters
(September to mid-May) with hot, dry
summers (May to September)
Terrain: low hill
Natural resources: none
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 100% other
Environment: urban
Note: landlocked; enclave of Rome, Italy;
world''s smallest state; outside the Vatican
City, 13 buildings in Rome and Castel
Gandolfo (the pope''s summer residence)
enjoy extraterritorial rights
Total area: 912,050 km2; land area:
882,050 km2
Comparative area: slightly more than
twice the size of California
Land boundaries: 4,993 km total; Brazil
2,200 km, Colombia 2,050 km, Guyana
743 km
Coastline: 2,800 km
Maritime claims:
Contiguous zone: 15 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: claims Essequibo area of Gu-
yana; maritime boundary disputes with
Colombia in the Gulf of Venezuela and
with Trinidad and Tobago in the Gulf of
Paria
Climate: tropical; hot, humid; more mod-
erate in highlands
Terrain: Andes mountains and Maracaibo
lowlands in northwest; central plains
(llanos); Guyana highlands in southeast
Natural resources: crude oil, natural gas,
iron ore, gold, bauxite, other minerals,
hydropower, diamonds
Land use: 3% arable land; 1% permanent
crops; 20% meadows and pastures; 39%
forest and woodland; 37% other; includes
NEGL% irrigated
Environment: subject to floods, rockslides,
mudslides; periodic droughts; increasing
industrial pollution in Caracas and Mara-
caibo
Note: on major sea and air routes linking
North and South America','5abe8728d469453980c8951f4d76fd4e51dd2c46a5b8d7b1f76ef2691b0ce66f','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3d628592a04bf51617e37669630ef139144dfea70a42b8b058e8114597434b2',1981,'WF','Wallis and Futuna','geography',752,'Total area: 274 km2; land area: 274 km2
Comparative area: slightly larger than
Washington, DC
Land boundaries: none
Coastline: 1 29 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Climate: tropical; hot, rainy season (No-
vember to April); cool, dry season (May to
October)
Terrain: volcanic origin; low hills
Natural resources: negligible
Land use: 5% arable land; 20% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland; 75% other
Environment: both island groups have
fringing reefs
Note: located 4,600 km southwest of Ho-
nolulu in the South Pacific Ocean about
two-thirds of the way from Hawaii to','38dc790cf4d784cc9ad6238b853d00abd58ad0cd60df8db46bc519995d6b5c96','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7cbd446db6b22989672ace1128d270893db85fc4988922441f7888f4da8578d',1981,'IL','Israel','geography',757,'Total area: 266,000 km2; land area:
266,000 km2
Comparative area: slightly smaller than
Colorado
Land boundaries: 2,046 km total; Algeria
42 km, Mauritania 1,561 km, Morocco
443 km
Coastline: 1,110 km
Maritime claims: contingent upon resolu-
tion of sovereignty issue
Disputes: claimed and administered by
Morocco, but sovereignty is unresolved
and guerrilla fighting continues in the
area
Climate: hot, dry desert; rain is rare; cold
offshore currents produce fog and heavy
dew
Terrain: mostly low, flat desert with large
areas of rocky or sandy surfaces rising to
small mountains in south and northeast
Natural resources: phosphates, iron ore
Land use: NEGL% arable land; 0% per-
manent crops; 19% meadows and pastures;
0% forest and woodland; 81% other
Environment: hot, dry, dust/sand-laden
sirocco wind can occur during winter and
spring; widespread harmattan haze exists
60% of time, often severely restricting vis-
ibility; sparse water and arable land
Total area: 2,860 km2; land area: 2,850
km2
Comparative area: slightly smaller than
Rhode Island
Land boundaries: none
Coastline: 403 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; rainy season (October to
March), dry season (May to October)
Terrain: narrow coastal plain with volca-
nic, rocky, rugged mountains in interior
Natural resources: hardwood forests, fish
Land use: 19% arable land; 24% perma-
nent crops; NEGL% meadows and pas-
tures; 47% forest and woodland; 1 0%
other
Environment: subject to occasional
typhoons; active volcanism
Note: located 4,300 km southwest of Ho-
nolulu in the South Pacific Ocean about
halfway between Hawaii and New Zea-
land
Total area: 510,072,000 km2; 361,132,000
km2 (70.8%) is water and 148,940,000
km2 (29.2%) is land
Comparative area: land area about 1 6
times the size of the US
Land boundaries: 442,000 km
Coastline: 359,000 km
Maritime claims:
Contiguous zone: generally 24 nm, but
varies from 4 nm to 24 nm
Continental shelf: generally 200 nm,
but some are 200 meters in depth
Exclusive fishing zone: most are 200
nm, but varies from 12 nm to 200 nm
Extended economic zone: 200 nm, only
Madagascar claims 1 50 nm
Territorial sea: generally 1 2 nm, but
varies from 3 nm to 200 nm
Disputes: 13 international land boundary
disputes — Argentina-Uruguay,
Bangladesh-India, Brazil-Paraguay,
Brazil-Uruguay, Cambodia- Vietnam,
China-India, China-USSR, Ecuador-Peru,
El Salvador-Honduras, French Guiana-
Suriname, Guyana-Suriname, Guyana-
Venezuela, Qatar-UAE
Climate: two large areas of polar climates
separated by two rather narrow temperate
zones from a wide equatorial band of
tropical to subtropical climates
Terrain: highest elevation is Mt. Everest
at 8,848 meters and lowest elevation is the
Dead Sea at 392 meters below sea level;
greatest ocean depth is the Marianas
Trench at 10,924 meters
Natural resources: the oceans represent
the last major frontier for the discovery
and development of natural resources
Land use: 10% arable land; 1% permanent
crops; 24% meadows and pastures; 31%
forest and woodland; 34% other; includes
1 .6% irrigated
Environment: large areas subject to severe
weather (tropical cyclones), natural disas-
ters (earthquakes, landslides, tsunamis,
volcanic eruptions), industrial disasters,
pollution (air, water, acid rain, toxic sub-
stances), loss of vegetation (overgrazing,
deforestation, desertification), loss of wild-
life resources, soil degradation, soil deple-
tion, erosion
Total area: 195,000 km2; land area:
195,000km2
Comparative area: slightly smaller than
South Dakota
Land boundaries: 1 ,209 km total; Saudi
Arabia 628 km, PDRY 581 km
Coastline: 523 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: 200 meters
Territorial sea: 1 2 nm
Disputes: sections of the boundary with
PDRY are indefinite or undefined; unde-
fined section of boundary with Saudi Ara-
bia
Climate: desert; hot and humid along
coast; temperate in central mountains;
harsh desert in east
Terrain: narrow coastal plain (Tihama);
western mountains; flat dissected plain in
center sloping into desert interior of Ara-
bian Peninsula
Natural resources: crude oil, rock salt,
marble; small deposits of coal, nickel, and
copper; fertile soil
Land use: 14% arable land; NEGL% per-
manent crops; 36% meadows and pastures;
8% forest and woodland; 42% other; in-
cludes 1% irrigated
Environment: subject to sand and dust
storms in summer; overgrazing; soil ero-
sion; desertification
Note: controls northern approaches to Bab
el Mandeb linking Red Sea and Gulf of
Aden, one of world''s most active shipping
lanes','520eb8ba8f3e07c36b9f76662f386097d53e40b1dd8f970eca5599b822d31d38','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a36da1f20173065c29a953545fb724131280a4ee1bc77df51f2f2d99088f78d2',1981,'GR','Greece','geography',760,'Climate: temperate; hot, relatively dry
summers with mild, rainy winters along
coast; warm summer with cold winters
inland
Terrain: mostly mountains with large ar-
eas of karst topography; plain in north
Natural resources: coal, copper, bauxite,
timber, iron ore, antimony, chromium,
lead, zinc, asbestos, mercury, crude oil,
natural gas, nickel, uranium
Land use: 28% arable land; 3% permanent
crops; 25% meadows and pastures; 36%
forest and woodland; 8% other; includes
1% irrigated
Environment: subject to frequent and de-
structive earthquakes
Note: controls the most important land
routes from central and western Europe to
Aegean Sea and Turkish straits
Total area: 2,345,410 km2; land area:
2,267,600 km2
Comparative area: slightly more than one-
quarter the size of US
Land boundaries: 10,271 km total; Angola
2,511 km, Burundi 233 km, Central Afri-
can Republic 1,577 km, Congo 2,410 km,
Rwanda 217 km, Sudan 628 km, Uganda
765 km, Zambia 1,930 km
Coastline: 37 km
Maritime claims:
Territorial sea: 1 2 nm
Disputes: Tanzania-Zaire-Zambia tripoint
in Lake Tanganyika may no longer be
indefinite since it is reported that the in-
definite section of the Zaire-Zambia
boundary has been settled; long section
with Congo along the Congo River is in-
definite (no division of the river or its is-
lands has been made)
Climate: tropical; hot and humid in equa-
torial river basin; cooler and drier in
southern highlands; cooler and wetter in
eastern highlands; north of Equator — wet
season April to October, dry season De-
cember to February; south of Equator —
wet season November to March, dry sea-
son April to October
Terrain: vast central basin is a low-lying
plateau; mountains in east
Natural resources: cobalt, copper, cad-
mium, crude oil, industrial and gem dia-
monds, gold, silver, zinc, manganese, tin,
germanium, uranium, radium, bauxite,
iron ore, coal, hydropower potential
Land use: 3% arable land; NEGL% per-
manent crops; 4% meadows and pastures;
78% forest and woodland; 15% other; in-
cludes NEGL% irrigated
Environment: dense tropical rainforest in
central river basin and eastern highlands;
periodic droughts in south
Note: straddles Equator; very narrow strip
of land is only outlet to South Atlantic
Ocean','162c29aed674c2fa7363bcdd1ab1dd03bc523109ed12a75e0e3994ccffbf5e1f','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06490ce00f789b10154349e06e342e5d1a9daafbe8216ba6b18b21c667534cda',1981,'ZW','Zimbabwe','geography',765,'Total area: 390,580 km2; land area:
386,670 km2
Comparative area: slightly larger than
Montana
Land boundaries: 3,066 km total; Bots-
wana 813 km, Mozambique 1,231 km,
South Africa 225 km, Zambia 797 km
Coastline: none — landlocked
Maritime claims: none — landlocked
Disputes: quadripoint with Botswana, Na-
mibia, and Zambia is in disagreement
Climate: tropical; moderated by altitude;
rainy season (November to March)
Terrain: mostly high plateau with higher
central plateau (high veld); mountains in
east
Natural resources: coal, chromium ore,
asbestos, gold, nickel, copper, iron ore,
vanadium, lithium, tin
Land use: 7% arable land; NEGL% per-
manent crops; 1 2% meadows and pastures;
62% forest and woodland; 1 9% other; in-
cludes NEGL% irrigated
Environment: recurring droughts; floods
and severe storms are rare; deforestation;
soil erosion; air and water pollution; deser-
tification
Note: landlocked
Total area: 35,980 km2; land area: 32,260
km2; includes the Pescadores, Matsu, and
Quemoy
Comparative area: slightly less than three
times the size of Connecticut
Land boundaries: none
Coastline: 1,448 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 1 2 nm
Disputes: involved in complex dispute over
the Spratly Islands with China, Malaysia,
Philippines, and Vietnam; Paracel Islands
occupied by China, but claimed by Viet-
nam and Taiwan; Japanese-administered
Senkaku-shotO (Senkaku Islands) claimed
by China and Taiwan
Climate: tropical; marine; rainy season
during southwest monsoon (June to
August); cloudiness is persistent and ex-
tensive all year
Terrain: eastern two-thirds mostly rugged
mountains; flat to gently rolling plains in
west
Natural resources: small deposits of coal,
natural gas, limestone, marble, and asbes-
tos
Land use: 24% arable land; 1% permanent
crops; 5% meadows and pastures; 55%
forest and woodland; 1 5% other; 1 4% irri-
gated
Environment: subject to earthquakes and
typhoons','49741da6a0100568fb5278dab3c25447f202c3fb95d634bd3615b28c9d9aa4fa','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2af7e9500211cb49e84f4cd7fb3dfb209e9780f7bcca50916958f33edafb558b',1981,'','','raw',1,'UNIVERSITY OF
ILLINOIS LIBRARY
AT URBANA CHAMPAIGN
BOOKSTACKS
Central
Intelligence
Agency
The
World
Factbook
1987
CP/1S WF 87-001
US Government officials should obtain copies of
The World Factbook directly from their own
organization or through liaison channels from the
Central Intelligence Agency.
Requesters in the Department of Defense may
obtain copies from:
Defense Intelligence Agency
RTS-2C
Washington, D.C. 20340-3344
Tel: (202) 373-3869 or Autovon 243-3869
Requesters in the Department of State may
obtain copies from:
Department of State
INR/IC/CD
Room 8646 New State
Washington, D.C. 20520
Tel: (202) 647-9673.
Requesters outside the US Government may
purchase copies from:
Superintendent of Documents
US Government Printing Office
Washington, D.C. 20402
Tel: (202) 783-3238
Requesters outside the US Government may
obtain a subscription from:
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Tel: (703) 487-4630
or: Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
Tel: (202) 287-9527
Requesters outside the US Government may .... ''
purchase this publication in photocopy or micro-
form from:
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Tel: (703) 487-4650
i
or: Photoduplication Service
Library of Congress
Washington, D.C. 20540
Tel: (202) 287-5640
Central
Intelligence!
Agency
toOC.
The
World
Factbook
1987
The person charging this material is re-
sponsible for its return to the library from
which it was withdrawn on or before the
Latest Date stamped below.
The World Factbook is
by the Directorate of II
Central Intelligence Ag
United States Governm'' i • 11 n n
style, format, coverage, ^
designed to meet their <
requirements.
Comments and queries
may be addressed to: ,. j £.
Central Intelligence Ag« M f* ''
Attn: Public Affairs
Washington, D.C. 20505
(703)351-2053 >^ .
Theft, mut.lat.on. and underllnln, of book, or. reo.on,
for dl,«ipllnory action ond moy re.ult In dl.ml».ol fron,
the University.
To renew call Telephone Center, 333-840O
UNIVERSITY OF ILLINOIS LIBRARY AT URBANA-CHAMPAIGN
m 02
m 08
APR 15
APR 1 8
CPAS WF 87-001
(Supersedes CR WF 86-001)
June 1987
Contents
Page
Notes, Definitions, and Abbreviations ix','b2b7737d0d67750721d6cab2c937ffc54fc7fd538d25c0330e88c57ec4d03428','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4dbc9febcf0a052ef018cb18547e5d33f5451e2bad834cf762f8ae5d0cb7008',1981,'AR','Argentina','raw',2,'Aruba 11
Australia 12
Austria 13
Bahamas, The 15
Bahrain 16
Bangladesh 17
Barbados 19
Belgium 20
Belize 22
Benin 23
Bermuda 25
Bhutan 26
Bolivia 27
Botswana 28
Brazil 30
British Indian Ocean Territory 31
British Virgin Islands 32
Brunei 33
Bulgaria 34
Burkina 36
Burma 37
Burundi 38
Cambodia 40
Cameroon 41
Canada 42
Cape Verde 44
Cayman Islands 45
Central African Republic -l(i
Chad 47
Chile 49
China (Taiwan entry on page 274) 50
Christmas Island 52
Colombia 53
Comoros 54
iii
Page
(.''nnvjn 55
Cook Islands 57
Costa Rica 58
Cuba 59
Cyprus 61
Czechoslovakia 62
D Denmark 64
Djibouti 05
Dominica 66
Dominican Republic 67
Ecuador 69
Egypt 70
El Salvador 72
Equatorial Guinea 74
Ethiopia 75
Falkland Islands (Islas Malvinas) 76
Faroe Islands 77
Fiji 78
Finland 79_
France 81
French Guiana 83
French Polynesia 84
Gabon 85
Gambia, The 87
Gaza Strip (see West Bank and Gaza Strip entry on page 276)
German Democratic Republic (East Germany) 88
Germany, Federal Republic of (West Germany) 90
Ghana 91_
Gibraltar 93^
Greece 9£
Greenland 95
Grenada 96
Guadeloupe 98
Guatemala 99
(iuenisey 101
Guinea 102
Guinea-Bissau 103
Guyana 104
H Haiti 105
Honduras 107
Hong Kong 108
Hungary 110
iv
Page
Iceland 111
India 112
Indonesia 114
Iran 116
Iraq 117
Ireland 119
Israel (West Bank and Gaza Strip entry on page 276) 120
Italy 122
Ivory Coast (Cote d''lvoire) 124
Jamaica 125
Japan 126
Jersey 128
Jordan (West Bank and Gaza Strip entry on page 276) 129
Kenya 130
Kiribati 132
Korea, North 133
Korea, South 134
Kuwait 136
Laos 137
Lebanon 138
Lesotho 140
Liberia 142
Libya 143
Liechtenstein 144
Luxembourg 146
M Macau 147
Madagascar 148
Malawi 150
Malaysia 151
Maldives 153
Mali 154
Malta 155
Man. Isle of 157
Martinique 158
Mauritania 159
Mauritius 160
Mayotte 162
Mexico 163
Monaco 164
Mongolia 165
Montserrat 167
Morocco 168
Mozambique 169
Page
N Namibia 1 7 1
Nauru 172
Nepal 17:5
Netherlands 1 71
Netherlands Antilles 176
New Caledonia 177
New Zealand 178
Nicaragua 180
Niger 182
Nigeria 183
Niue IS I
Norfolk Island 1 S5
Norway 186
jO Oman 188
P Pakistan 189
Panama 191
Papua New Guinea 1 93
Paraguay 194
Peru 195
Philippines 197
Pitcairn Islands 198
Poland 199
Portugal 200
Qatar 202
Reunion 203
Romania 205
Rwanda 206
S St. Christopher and Nevis 207
St. Helena 20S
St. Lucia 209
St. Vincent and the Grenadines 210
San Marino 211
Sao Tome and Principe 213
Saudi Arabia 214
Senegal 215
Seychelles 216
Sierra Leone 218
Singapore 219
Solomon Islands 220
Somalia 221
South Africa 223
Soviet Union 224
Spain 226
Page
Sri Lanka 228
Sudan 230
Suriname 231
Swaziland 232
Sweden 234
Switzerland 235
Syria 237
Taiwan (see Taiwan entry on page 274)
Tanzania 238
Thailand 240
Togo 241
Tokelau 242
Toiwa 243
Trinidad and Tobago 244
Tunisia 246
Turkey 247
Turks and Caicos Islands 249
Tuvalu 250
U Uganda 251
United Arab Emirates 252
United Kingdom 253
United States 255
Uruguay 257
Vanuatu 259
Vatican City 260
Venezuela 261
Vietnam 262
W Wallis and Futuna 263
West Bank (see West Bank and Gaza Strip entry on page 276)
Western Sahara 264
Western Samoa 265
Yemen Arab Republic (North Yemen) 266
Yemen, People''s Democratic Republic of (South Yemen) 267
Yugoslavia 269
Zaire 270
Zambia 272
Zimbabwe 273
Taiwan 274
West Bank and Gaza Strip 276
vii
Page
Appendixes
A. The United Nations System 278
B. International Organizations 279
C. Country Membership in International Organizations 282
D. Mathematical Conversions 290
Maps
I. The World (Guide to Regional Maps)
II. North America
III. Central America and the Caribbean
IV. South America
V. Europe
VI. Middle East
VII. Africa
VIII. Soviet Union, East and South Asia
IX. Southeast Asia
X. Oceania
XI. Arctic Region
XII. Antarctic Region
XIII. Standard Time Zones of the World
Notes, Definitions,
and Abbreviations
There have been some significant changes in this edition. A new
Geography section has replaced the former Land and Water sections.
Entries in the new section include area (total and land), comparative
area, land boundaries, coastline, maritime claims, boundary disputes,
climate, terrain, land use, environment, and special notes. In the
Government section, a new entry on dependent areas has also been
added.
Area: Total area is the sum of all land and water areas delimited by
international boundaries and/or coastlines. Land area is the aggregate
of all surfaces delimited by international boundaries and/or coastlines,
excluding inland water bodies (lakes, reservoirs, rivers). Comparative
areas are based on total area equivalents.
Boundary disputes: Every international land boundary in dispute
from the "Guide to International Boundaries" published by the
Department of State is included; the absence of this entry or
"none"indicates no boundaries are in dispute. Additional information
may follow that is border- or frontier-relevant, such as maritime
disputes, geopolitical questions, or irredentist issues. However, inclu-
sion does not necessarily constitute official acceptance or recognition
by the US Government.
Contributors: The data are provided by the Central Intelligence
Agency, the Defense Intelligence Agency, the Bureau of the Census,
and the Department of State.
Country abbreviations:
CAR Central African Republic
FRG Federal Republic of Germany (West Germany)
GDR German Democratic Republic (East Germany)
PDRY People''s Democratic Republic of Yemen (South
Yemen)
UAE United Arab Emirates
UK United Kingdom
US United States
USSR Union of Soviet Socialist Republics (Soviet Union)
YAR Yemen Arab Republic (North Yemen)
Dates of information: In general, information available as of 1
January 1987 was used in the preparation of this edition, with the
following exceptions: population figures are projected for 1 July 1987,
with the average annual population growth rates estimated for mid-
1986 through mid-1987; major political events have been updated
through 26 March 1987; military age figures are projected for
1987-91.
Notes, Definitions,
and Abbreviations (continued)
Economic abbreviations:
ave. average
bbl barrel (159 liters, 42 gallons)
b/d barrel(s) per day
c.i.f cost, insurance, and freight
est. estimate
Ex-Im Export-Import Bank of the United States
f.o.b. free on board
GDP gross domestic product
GNP gross national product
kW kilowatt
kWh kilowatt-hour
ODA official development assistance
OOF other official flows
proj. projected
International organization abbreviations: see Appendix B
Land use abbreviations:
NA% data not available
NEGL% negligible (magnitude of data is less than 0.5%)
0% none (a determined value, not the absence of data)
Maritime claims: Inclusion of a claim does not necessarily constitute
official acceptance or recognition by the US Government. Also, the
proximity of neighboring states may prevent some national claims
from being fully extended.
Money: All money figures are in US dollars unless otherwise
indicated.
Political entities: Some of the countries, entities, dependencies, areas
of special sovereignty, and governments included in this publication
are not independent, and others are not officially recognized by the
US Government.
Years: All year references are for the calendar year (CY) unless
indicated as fiscal year (FY) or otherwise.','0a1c7084b1acc10e3c010b101d58dc16b35c2501c96ed69ea47a3452a21cd3c9','internet-archive','worldfactbook87nati','txt','ae50995693c6c6de6c792c3fc367b216e19dfb64c972007cc68eb9effe5ec8cb','https://archive.org/download/worldfactbook87nati/worldfactbook87nati_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('285d50369b3c99625ee911fb29c3b8b1bd2aace2225f0298aaed98a9f441a7d1',1981,'','','raw',1,',
U <1 "3 A \\
^V/^^v Central
l(f JL. A Intelligence
ilp.Jx m\\ ?) Agency
THE LIBRARY OF THE
SEP a 6
UNIVERSITY Or ILLINOj
"''''
* *''•'' f
The
World
Factbook
Nineteen Hundred and Eighty-Four
•*• -H
This publication is prepared for the use of US
Government officials, and the format, coverage,
and content are designed to meet their specific
requirements. US Government officials may ob-
tain additional copies of this document directly
or through liaison channels from the Central
Intelligence Agency.
Requesters outside the US Government may ob-
tain subscriptions to CIA publications similar to
this one by addressing inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Requesters outside the US Government not inter-
ested in subscription service may purchase spe-
cific publications either in paper copy or micro-
form from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
(To expedite service call the
NTIS Order Desk (703) 487-4650
This publication may also be purchased from:
Superintendent of Documents
US Government Printing Office
Washington, D.C. 20402
(Stock Number 041-015-00157-4)
Central
Intelligence
Agency
The
World
Factbook
Nineteen Hundred and Eighty-Four
The World Factbook is produced annually
by the Directorate of Intelligence of the
Central Intelligence Agency. The data are
provided by various components of the
Central Intelligence Agency, the Defense
Intelligence Agency, the Bureau of the
Census, and the US Department of State. In
general, information available as of 1
January 1984 was used in the preparation of
this edition, with the following exceptions:
• Population figures are projected estimates
for 1 July 1984; the average annual
growth rates listed are projected estimates
for the period mid-1983 to mid-1984.
• Military manpower estimates are as of 1
January 1984, except the numbers of
males reaching military age, which are
projected averages for the five-year
period 1984-88.
• Major political developments through 13
April 1984 have been included.
Comments and queries are welcome and
may be addressed to:
Central Intelligence Agency
Attn: Public Affairs
Washington, D.C. 20505
(703) 351-7676
Publications are not available to the public
from the Central Intelligence Agency. For
information on how to obtain additional
copies, see the inside of the front cover.
Supersedes the 1983 edition of The
World Factbook.
April 1984
Contents
Page
Definitions, Abbreviations, and Explanatory Notes
Abu Dhabi (see United Arab Emirates)','4fdaffe7a081f533b5e11e82a0d88256083d68ef77b33834899a68eabbe681dc','internet-archive','worldfactbook84natiilli','txt','91923936495632c360f1a6e6847d516e90c99e3c12607d225f12505721b89f60','https://archive.org/download/worldfactbook84natiilli/worldfactbook84natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aea826c298c81a2ebb77d3dbd9b7f1dd2a03d23caa719bca7d85423bc0d34971',1981,'AF','Afghanistan','raw',2,'Ajman (see United Arab Emirates)
(See reference map VIII)
Land
637,397 km2; 75% desert, waste, or urban;
22% arable(12% cultivated, 10% pasture); 3%
forest
Land boundaries: 5,510 km','b35696606d84c3e2e7cef9859460386fd0ae4329da79e52ff75c6343df8e8d11','internet-archive','worldfactbook84natiilli','txt','91923936495632c360f1a6e6847d516e90c99e3c12607d225f12505721b89f60','https://archive.org/download/worldfactbook84natiilli/worldfactbook84natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbfe69762318bc836118377ec68811c0874573b359e16df08eac5b5ca8407a3d',1981,'AU','Australia','raw',3,'Austria 12_
Azores (see Portugal)
Bahamas, The
Bahrain 15
Balearic Islands (see Spain)
Bangladesh 16
Barbados 1§_
Belgian Congo (see Zaire)
Belgium 1°
Belize (formerly British Honduras) 21
Benin (formerly Dahomey) 22_
Bermuda 23
Bhutan ?4_
Bioko (see Equatorial Guinea)
Bolivia 25_
Bophuthatswana (see South Africa)
Botswana 27
Brazil 28
British Honduras (see Belize)
British Solomon Islands (see Solomon Islands)
Brunei 30
Bulgaria ?J_
Burma ?J5_
Burundi 34
Cabinda (see Angola)
Cambodia (see Kampuchea)
Cameroon 35
Canada ?J_
Canary Islands (see Spain)
Cape Verde
38
Central African Republic 39
D
Page
Ceylon (see Sri Lanka)
Chad -«
China (Taiwan listed at end of table)
Dahomey (see Benin)
Falkland Islands (Islas Malvinas)
i Territory of the Afars and Issas (see Djibouti)
Fujayrah, al (see United Arab Emirates)
Germany, Federal Republic of
44
«
Czechoslovakia ____
Djibouti (formerly French Territory of the Afars and Issas) 59
Dominic^: -~-
Dominican Republic _
Dubai (see United Arab Emirates)
68
69
Islands
ndo Po (see Equatorial Guinea)
ch Guiana _ -™-
ch Polynesia ____ ^~','8778ec9cbe2961262c8815e2898bd3e04fac43a415e1734d21f6376f7638d1a3','internet-archive','worldfactbook84natiilli','txt','91923936495632c360f1a6e6847d516e90c99e3c12607d225f12505721b89f60','https://archive.org/download/worldfactbook84natiilli/worldfactbook84natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00f0bf10146c1a4dbac78bc6ce8533c5b30881c6fa1da3ec5dbd52ec9c985d92',1981,'GA','Gabon','raw',4,'Gambia The 80
Gaza Strip (see West Bank and Gaza Strip, listed at end of table)
ft 1
German Democratic Republic
83','7026b25c3e8a4bd3b8ce8bd68a7434f299ac647f8525740a8499c530b5f6e027','internet-archive','worldfactbook84natiilli','txt','91923936495632c360f1a6e6847d516e90c99e3c12607d225f12505721b89f60','https://archive.org/download/worldfactbook84natiilli/worldfactbook84natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0609c19f6d0725a3aa672755f405472ca7f99e7e7d212e3594ade9a37c001e1b',1981,'GH','Ghana','raw',5,'G^bTaltarl -15-
Gilbert Islands (see Kiribati)
87
iv
Page
Greenland . ^
Grenada 89','4d3db76d30d62995c67fff0b8d61bd2028f8319c6fd4cf0846e5ae465853f4bf','internet-archive','worldfactbook84natiilli','txt','91923936495632c360f1a6e6847d516e90c99e3c12607d225f12505721b89f60','https://archive.org/download/worldfactbook84natiilli/worldfactbook84natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e68a3dd5d9e37fe5aaec5ce839796861a6e915521f190e924cc8838e0db45c5',1981,'GP','Guadeloupe','raw',6,'Guatemala 92
Guinea . 94
Guinea-Bissau (formerly Portuguese Guinea) 95
Guyana 96
H Haiti
Honduras ?9_
Hong Kong 1*L
Hungary I?2-','5b9935b72401ac1135c05886f505234e9e90d33b3451077e945f2fcf126259cf','internet-archive','worldfactbook84natiilli','txt','91923936495632c360f1a6e6847d516e90c99e3c12607d225f12505721b89f60','https://archive.org/download/worldfactbook84natiilli/worldfactbook84natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44dd86a9ec75eb2ccb2d50e97f8e3775998d2a09d347d7588d65e440ec9e2023',1981,'IE','Ireland','raw',7,'Israel (West Bank and Gaza Strip listed at end of table) _ 112_
Italy _ _ . _ 111
Ivory Coast __ _ _ 115','de5e44b45e62a66ed09fcaed73fc7a18ae8783d0e2fc66ba9038c07b05841a0b','internet-archive','worldfactbook84natiilli','txt','91923936495632c360f1a6e6847d516e90c99e3c12607d225f12505721b89f60','https://archive.org/download/worldfactbook84natiilli/worldfactbook84natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd75e4e251b4860829f249ca9442676032e30bb47af9497b2109939b7cbb88a9',1981,'JM','Jamaica','raw',8,'Japan . LUL
Jordan (West Bank and Gaza Strip listed at end of table) 120
Kampuchea (formerly Cambodia) 121
Kenya 123
Kiribati (formerly Gilbert Islands) 124
Korea, North ]%L.
Korea, South 1%L
Kuwait 128_
Laos','ff177039f90e5333dbc6ce948d0f5ee5464814aa7842fb8b2682c2113e115510','internet-archive','worldfactbook84natiilli','txt','91923936495632c360f1a6e6847d516e90c99e3c12607d225f12505721b89f60','https://archive.org/download/worldfactbook84natiilli/worldfactbook84natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('896dd0080b02e14f6be58a8e86d600657f578091fe048584b74a1722538bb7b1',1981,'PT','Portugal','raw',9,'187
Portuguese Guinea (see Guinea-Bissau)
Portuguese Timor (see Indonesia)
0 Qatar
188
R Ra''s al-Khaymah (see United Arab Emirates)
Reunion
189
Rhodesia (see Zimbabwe)
Rio Muni (see Equatorial Guinea)','b398928c45e8fb892f6fed2598e120b8e63a6f19126f6d534a7ece362c8f10d4','internet-archive','worldfactbook84natiilli','txt','91923936495632c360f1a6e6847d516e90c99e3c12607d225f12505721b89f60','https://archive.org/download/worldfactbook84natiilli/worldfactbook84natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f88b099770b214071ba6227b0b7b3eaeaed438a08c8413b94066e91ac5d212e',1981,'RW','Rwanda','raw',10,'192
Page
St. Christopher and Nevis (formerly St. Christopher-Nevis-Anguilla) 193
St. Lucia 194
St. Vincent and the Grenadines 195
San Marino 196
Sao Tome and Principe 198
Saudi Arabia 199
Senegal 200
Seychelles 201
Sharjah (see United Arab Emirates)
Sierra Leone 203
Singapore 204
Solomon Islands (formerly British Solomon Islands) 205
Somalia 206
South Africa 208
Southern Rhodesia (see Zimbabwe)
South- West Africa (see Namibia)
Soviet Union 209
Spain 211
Spanish Sahara (see Western Sahara)
Sri Lanka (formerly Ceylon) 213
Sudan 215
Suriname 216
Swaziland 217
Sweden 219
Switzerland 220
Syria 222
Tanganyika (see Tanzania)
Tanzania 223
Tasmania (see Australia)
Thailand 225
Togo 226
Tonga 227
Transkei (see South Africa)
Trinidad and Tobago 228
Tunisia 230
Turkey 231
Turks and Caicos Islands 233
Tuvalu (formerly Ellice Islands) 234
U Uganda 235
Umm al-Qaywayn (see United Arab Emirates)
United Arab Emirates (Abu Dhabi, Ajman, Dubai, al Fujayrah, 236
Ra''s al-Khaymah, Sharjah, Umm al-Qaywayn)
United Arab Republic (see Egypt)
Page
United Kingdom 237
United States 239
Upper Volta 241
Uruguay 242
Vanuatu (formerly New Hebrides) 243
Vatican City 244
Venezuela 245
Vietnam 247
W Wallis and Futuna 248
Walvis Bay (see South Africa)
Western Sahara (formerly Spanish Sahara) 249
Western Samoa 250
Yemen Arab Republic (North Yemen) 251
Yemen, People''s Democratic Republic of (South Yemen) 252
Yugoslavia 253
Zaire 255
Zambia (formerly Northern Rhodesia) 256
Zanzibar (see Tanzania)
Zimbabwe (formerly Southern Rhodesia) 257
Taiwan (China listed alphabetically) 259
West Bank and Gaza Strip 260
Appendixes
A. The United Nations System 262
B. Selected UN Organizations 263
C. Selected International Organizations 264
D. Country Membership in Selected Organizations 266
E. Conversion Table 274
Maps
I. The World (Guide to Reference Maps II-XII)
II. North America
III. Central America and the Caribbean
IV. South America
V. Europe
VI. Middle East
VII. Africa
VIII. Soviet Union, East and South Asia
IX. Southeast Asia
X. Oceania
XI. Arctic Region
XII. Antarctic Region
Definitions, Abbreviations,
and Explanatory Notes
Fiscal Year: The abbreviation FY stands for fiscal year; all years are
calendar years unless otherwise indicated.
GDP and GNP: GDP is the total market value of all goods and
services produced within the domestic borders of a country over a
particular time period, normally a year. GNP equals GDP plus the
income accruing to domestic residents arising from investment abroad
less income earned in the domestic market accruing to foreigners
abroad.
Imports, Exports, and Aid: Standard abbreviations used in individual
entries throughout this factbook are c.i.f. (cost, insurance, and freight),
f.o.b. (free on board), ODA (official development assistance), and OOF
(other official flows).
Land Utilization: Most of the land utilization percentages are rough
estimates. Figures for "arable" land in some cases reflect the area
under cultivation rather than the total cultivable area.
Maritime Zones: Fishing and economic zones claimed by coastal
states are included only when they differ from territorial sea limits.
Maritime claims do not necessarily represent the position of the
United States Government.
Money: All money figures are in contemporaneous US dollars unless
otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to express
volume of crude oil and refined products; a barrel equals 42.00
gallons, 158.99 liters, 5.61 cubic feet, or 0.16 cubic meters.
Note: Some of the countries and governments included in this
publication are not fully independent, and others are not officially
recognized by the United States Government.','32f926931d3bcd749b4506fbfdbcb50300343195b31bc865fd5d6651bb470098','internet-archive','worldfactbook84natiilli','txt','91923936495632c360f1a6e6847d516e90c99e3c12607d225f12505721b89f60','https://archive.org/download/worldfactbook84natiilli/worldfactbook84natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91b5d3cb269dc555937950834241d6f30ca64c0a0db0efb82bdf8fd1a43112e8',1981,'','','raw',1,'Central
Intelligence
Vgency
The
World
Factbook
Nineteen Hundred and Eighty-Five
This publication is prepared for the use of US
Government officials, and the format, coverage,
and content are designed to meet their specific
requirements. US Government officials may ob-
tain additional copies of this document directly
or through liaison channels from the Central
Intelligence Agency.
Requesters outside the US Government may ob-
tain subscriptions to CIA publications similar to
this one by addressing inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
or: National Technical information Service
5285 Port Royal Road
Springfield, VA 22161
Requesters outside the US Government not inter-
ested in subscription service may purchase spe-
cific publications either in paper copy or micro-
form from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
To expedite service call the
NTIS Order Desk (703) 487-4650
This publication may also be purchased from:
Superintendent of Documents
US Government Printing Office
Washington, D.C. 20402
(Stock Number 041-015-00159-2)
Central
Intelligence
Agency
The
World
Factbook
Nineteen Hundred and Eighty-Five
The World Factbook is produced annually
by the Directorate of Intelligence of the
Central Intelligence Agency. The data are
provided by various components of the
Central Intelligence Agency, the Defense
Intelligence Agency, the Bureau of the
Census, and the US Department of State. In
general, information available as of 1
January 1985 was used in the preparation of
this edition, with the following exceptions:
• Population figures are projected estimates
for 1 July 1985; the average annual
growth rates listed are projected estimates
for the period mid-1984 to mid-1985.
• Military manpower estimates are as of 1
January 1985, except the numbers of
males reaching military age, which are
projected averages for the five-year
period 1985-89.
• Major political developments through 22
April 1985 have been included.
Comments and queries are welcome and
may be addressed to:
Central Intelligence Agency
Attn: Public Affairs
Washington, D.C. 20505
(703) 351-2053
Publications are not available to the public
from the Central Intelligence Agency. For
information on how to obtain additional
copies, see the inside of the front cover.
Supersedes the 1984 edition of The
World Factbook.
CENTRAL CIRCULATION AND BOOKSTACKS
The person borrowing this material is re-
sponsible for its renewal or return before
the Latest Date stamped below. You may
be charged a minimum fee of $75.00 for
each non-returned or lost item.
Theft, mutilation, or defacement of library materials can b*
causes for student disciplinary action. All materials owned by
the University of Illinois Library are the property of the State
of Illinois and are protected by Article 16B of Illinois Criminal
low and Procedure.
TO RENEW, CALL (217) 333-8400.
University of Illinois Library at Urbana-Champalgn
«AR13»
H* J 5 2000
HAY
2* 2m
When renewing by phone, write new due date
below previous due date. L162
May 1985
I
Contents
Page
Definitions, Abbreviations, and Explanatory Notes
Abu Dhabi (see United Arab Emirates)','9769bae7a019306fd04515a2781c31c34002dce3d4104a4c431be7788a1271a5','internet-archive','worldfactbook85natiilli','txt','1a177159eccdef493e9c7ebb9ffaabe6cd5e49b9d4c1a63b9f7e15ee5a08d7a2','https://archive.org/download/worldfactbook85natiilli/worldfactbook85natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f184163124b1b6810b14254307a8617d39a61111fe4a86b6b03e364540733b2a',1981,'AF','Afghanistan','raw',2,'Ajman (see United Arab Emirates)
Sttre|!onilntipVIII
Land
647,497 km2; about the size of Texas; 75%
desert, waste, or urban; 22% arable (12% cul-
tivated, 10% pasture); 3% forest
Land boundaries: 5,510 km','8de66b390a32278dd04602e855af7b658060efbe0fab16427ae3e343f986bd85','internet-archive','worldfactbook85natiilli','txt','1a177159eccdef493e9c7ebb9ffaabe6cd5e49b9d4c1a63b9f7e15ee5a08d7a2','https://archive.org/download/worldfactbook85natiilli/worldfactbook85natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61d78131d0eefb64cb710d7d41839ad91747aeff16843c929a58f06e780ed91d',1981,'AR','Argentina','raw',3,'Australia 1 1
Austria 1 3
Azores (see Portugal)
Bahamas, The 14
Bahrain 16
Balearic Islands (see Spain)
Bangladesh 17
Barbados _ 18
Belgian Congo (see Zaire)
Belgium 20
Belize (formerly British Honduras) 21
Benin (formerly Dahomey) 23
Bermuda 24
Bjiutan 25
Bioko (see Equatorial Guinea)
Bolivia 26
Bophuthatswana (see South Africa)
Botswana 27_
Bj^zil 29
British Honduras (see Belize)
British Solomon Islands (see Solomon Islands)
Brunei 30
Bulgaria 32
Burkina Faso (formerly Upper Volta) 33
Burma 34
JSurundi^ 36
Cabinda (see Angola)
Cambodia (formerly Kampuchea) 37
Cameroon 38
Canada 40
Canary Islands (see Spain)
Cape Verde 41
Page
Central African Republic 42
Ceylon (see Sri Lanka)
Chad 44
Chile 45
China (Taiwan listed at end of table) 47
Colombia 48
Comoros 50
Congo 51
Cook Islands 52
Costa Rica 53
Cuba 55
Cyprus 56
Czechoslovakia 58
Dahomey (see Benin)
Denmark 59
Djibouti (formerly French Territory of the Afars and Issas) 61
Dominica 62
Dominican Republic 63
Dubai (see United Arab Emirates)
Ecuador 64
Egypt 66
Ellice Islands (see Tuvalu)
El Salvador 67
Equatorial Guinea 69
Ethiopia 70
Falkland Islands (Islas Malvinas) 72
Faroe Islands 73
Fernando Po (see Equatorial Guinea)
Fiji 74
Finland 75
France 77
French Guiana 78
French Polynesia 80
French Territory of the Afars and Issas (see Djibouti)
Fujayrah, al (see United Arab Emirates)
Gabon 81
Gambia, The 82
Gaza Strip (see West Bank and Gaza Strip, listed at end of table)
German Democratic Republic 83
Germany, Federal Republic of 85
Ghana 87
Gibraltar 88
Gilbert Islands (see Kiribati)
IV
Page
Greece 89
Greenland 91
Grenada 92
Guadeloupe 93
Guatemala 94
Guinea 96
Guinea-Bissau (formerly Portuguese Guinea) 97
Guyana 99
H Haiti 100
Honduras 101
Hong Kong 103
Hungary^ 104
Iceland 106
India 107
Indonesia 109
Iran 110
Iraq 112
Ireland 113
Israel (West Bank and Gaza Strip listed at end of table) 114
Italy 116
Ivory Coast 118
Jamaica 119
Japan 121
Jordan (West Bank and Gaza Strip listed at end of table) 122
Kampuchea (see Cambodia)
Kenya _ 124
Kiribati (formerly Gilbert Islands) __ 125
126
Korea, South _ _ 127
_____ Kuwait 129
L Laos 130
Lebanon _ 132
Lesotho _ 133
Liberia _ _ 135
Libya 136
Liechtenstein _ 137
____ Luxembourg __ 139
M Macau 140
Madagascar __ 141
Madeira Islands (see Portugal) _
Malagasy Republic (see Madagascar)
Malawi 143
Malaysia 144
Page
Maldives 147
Mali^ 148
Malta 1 49
Martinique 150
Mauritania 152
Mauritius 153
Mexico 1 54
Monaco 156
Mongolia 157
Morocco 158
Mozambique _Jj>P_
Namibia (South- West A_f ri_ca)_ <^ 161
Nauru 162
Nepal 163
Netherlands 165
Netherlands Antilles 166
New Caledonia 168
New Hebrides (see Vanuatu)
New Zealand 169
Nicaragua 170
Niger_ 172
Nigeria 173
Northern Rhodesia (see Zambia)
Norway 1 75
O Oman 176
P Pakistan 178
Panama 179
Papua New Guinea 181
Paraguay 182
Pemba (see Tanzania)
Peru 184
Philippines 185
Poland 186
Portugal 188
Portuguese Guinea (see Guinea-Bissau)
Portuguese Timor (see Indonesia)
Qatar 189
Ra''s al-Khaymah (see United Arab Emirates)
Reunion 190
Rhodesia (see Zimbabwe)
Rio Muni (see Equatorial Guinea)
Romania 192
Rwanda 193
VI
____ Page
St. Christopher and Nevis (formerly St. Christopher-Nevis-Anguilla) ___ 194
195
St. Vincent and the Grenadines 196
Spanish Sahara (see Western Sahara)
Soviet Union 210
Spain 212
Sri Lanka (formerly Ceylon) 214
Sudan 216
Suriname 217
Swaziland 218
Tanzania 224
Tasmania (see Australia)
Thailand_ 226
Togo 227
Tonga 228
Transkei (see South Africa)
Trinidad and Tobago ___ 229
Tunisia 231
Turkey 232
Turks and Caicos Islands _ 233
Tuvalu (formerly Ellice Islands) 234
u
San Marino 197
Sao Tome and Principe 199
Saudi_Arabia_ 200
Senegal 201
Seychelles^ 202
Sharjah (see^United Arab Emirates)
Sierra Leone 204
Singapore 205
Solomon Islands (formerly British Solomon Islands) 206
Somalia JJ07
South _Africa_ J209
Southern Rhodesia (see Zimbabwe)
South- West Africa (see Namibia)','057629fd00adfdc053adb92c471debf198278341dddd291780ac711be4d6c5da','internet-archive','worldfactbook85natiilli','txt','1a177159eccdef493e9c7ebb9ffaabe6cd5e49b9d4c1a63b9f7e15ee5a08d7a2','https://archive.org/download/worldfactbook85natiilli/worldfactbook85natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e64e3504aa6335df84d3ebf50c88addea81d4f9554d1d0ac7aa324d1f720004',1981,'CH','Switzerland','raw',4,'221
Syria
223
Tanganyika (see Tanzania)
Umm al-Qaywayn (see United Arab Emirates)
United Arab Emirates (Abu Dhabi, Ajman, Dubai, al Fujayrah, 237
Ra''s al-Khaymah, Sharjah, Umm al-Qaywayn)
United Arab Republic (see Egypt)
vii
Page
United Kingdom 238
United States 240
Upper Volta (see Burkina Faso)
Uruguay 241
Vanuatu (formerly New Hebrides) 243
Vatican City 244
Venezuela 245
Vietnam 246
W Wallis and Futuna 247
Walvis Bay (see South Africa)
Western Sahara (formerly Spanish Sahara) 248
Western Samoa 249
Yemen Arab Republic (North Yemen) 250
Yemen, People''s Democratic Republic of (South Yemen) 25 1
Yugoslavia 252
Zaire 254
Zambia (formerly Northern Rhodesia) 255
Zanzibar (see Tanzania)
Zimbabwe (formerly Southern Rhodesia) 257
Taiwan (China listed alphabetically) 258
West Bank and Gaza Strip 260
Appendixes
A. The United Nations System 262
B. Selected UN Organizations 263
C. Selected International Organizations 26-1
D. Country Membership in Selected Organizations 266
E. Conversion Table 274
Maps
I. The World (Guide to Regional Maps II-XIII)
II. North America
III. Central America and the Caribbean
IV. South America
V. Europe
VI. Middle East
VII. Africa
VIII. Soviet Union, East and South Asia
IX. Southeast Asia
X. Oceania
XI. Arctic Region
XII. Antarctic Region
XIII. Standard Time Zones of the World
Definitions, Abbreviations,
and Explanatory Notes
Fiscal Year: The abbreviation FY stands for fiscal year; all years are
calendar years unless otherwise indicated.
GDP and GNP: GDP is the total market value of all goods and
services produced within the domestic borders of a country over a
particular time period, normally a year. GNP equals GDP plus the
income accruing to domestic residents arising from investment abroad
less income earned in the domestic market accruing to foreigners
abroad.
Imports, Exports, and Aid: Standard abbreviations used in individual
entries throughout this factbook are c.i.f. (cost, insurance, and freight),
f.o.b. (free on board), ODA (official development assistance), and OOF
(other official flows).
Land Utilization: Most of the land utilization percentages are rough
estimates. Figures for "arable" land in some cases reflect the area
under cultivation rather than the total cultivable area.
Maritime Zones: Fishing and economic zones claimed by coastal
states are included only when they differ from territorial sea limits.
Maritime claims do not necessarily represent the position of the
United States Government.
Money: All money figures are in contemporaneous US dollars unless
otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to express
volume of crude oil and refined products; a barrel equals 42.00
gallons, 158.99 liters, 5.61 cubic feet, or 0.16 cubic meters.
Note: Some of the countries and governments included in this
publication are not fully independent, and others are not officially
recognized by the United States Government.','de3308fa09ada2596384d3fbd213e1cdf08bd0d367de30fd27f5cdf2de2cd15b','internet-archive','worldfactbook85natiilli','txt','1a177159eccdef493e9c7ebb9ffaabe6cd5e49b9d4c1a63b9f7e15ee5a08d7a2','https://archive.org/download/worldfactbook85natiilli/worldfactbook85natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17fdd574012f576941fc30864137c8b849d5b9fcbf18c4225aa5410db3fb00a9',1981,'','','raw',1,'CENTRAL CIRCULATION AND BOOKSTACKS
The person borrowing this material is re-
sponsible for its renewal or return before
the Latest Date stamped below. You may
be charged a minimum fee of $75.00 for
each non-returned or lost item.
Theft, mutilation, or defacement of library materials can be
causes for student disciplinary action. All materials owned by
the University of Illinois Library are the property of the State
of Illinois and are protected by Article 16B of Illinois Criminal
Law and Procedure.
TO RENEW, CALL (217) 333-8400.
University of Illinois Library at Urbana-Champaign
''^N 18 200)
2 £
200
JUL 2 7 2001
When renewing by phone, write new due date
below previous due date. L162
Central
Intelligence
Agency
The
World
Factbook
1990
The World Factbook is produced annually
by the Central Intelligence Agency for the
use of United States Government officials,
and the style, format, coverage, and
content are designed to meet their specific
requirements.
Comments and queries are welcome and
may be addressed to:
Central Intelligence Agency
Attn: Public Affairs
Washington, DC 20505
(703)351-2053
"BUILDING USE ONLY1
, 5
<^v
Contents
r
Notes, Definitions, and
Abbreviations
vii
A Afghanistan
1','bf964ff282c4ebce4401617a42c6b11a9681ced16c55eba1f65d37488ff867c7','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99823b6639fd94e7ccf52191b5ea69acc2a652510ab4d6c4edcce57615c5b2dd',1981,'GA','Gabon','raw',2,'107
Gambia, The
109
Gaza Strip
110
German Democratic Republic
(East Germany)
111
Germany, Federal Republic of
(West Germany)
113','ee8b361ce0b2cd4ff03debc7693087d443a1e4051ebf926a0ba70780e59ba1ec','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2baecf3cd949667dba5bf911736b3371797f60f32d474a5bddead06431260ae',1981,'JE','Jersey','raw',3,'1
Johnston Atoll
1
Jordan (also see separate
West Bank entry)
1
Juan de Nova Island
1
K','1345220e89034e48e55621c88b209907167d005abdb383d966596661dc107606','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5471c074e53c9c8b02e28d8a7092f372191edaf27d2bc6cec3cd8de7b438b41',1981,'RW','Rwanda','raw',4,'263
S St. Helena
264
St. Kitts and Nevis
265
St. Lucia
267
St. Pierre and Miquelon
268
St. Vincent and the Grenadines
269','9928929210c814535d90fb6cf0f11e1f6aceb37b056341cc5b97e96519ab7828','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('318dc9ecaa614fcbb854a73d3f93c33c49e4992354872b6b90b89ab5ec6fd318',1981,'VU','Vanuatu','raw',5,'327
Vatican City
329
Venezuela
330
Vietnam
331
Virgin Islands
333
W
Wake Island
334','bf11a693cb4e25b763c775ccf361d614aac1764984622860a1d5d9e93b090206','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8636e4b5c4898837c875ace1ef3d2e3062527b7e18cd1895f3844f51c90e5d7a',1981,'EH','Western Sahara','raw',6,'337
Western Samoa
338
World
340
Yemen Arab Republic [Yemen 341
(Sanaa) or North Yemen]
Yemen, People''s Democratic 342
Republic of [Yemen (Aden)
or South Yemen]
Yugoslavia
344
Zaire
346','1f2d4b3fd6ca6283ec9c9c0a474adf235dcfda6d694ade2269a3839fe646a697','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d09b9ed2e21f96e324ffc17654b55d2ce59428c1f41ff986c2f82462fc7a62e1',1981,'ZW','Zimbabwe','raw',7,'349
Taiwan
350
Pag
Appendixes A: The United Nations System 35:
B: International Organizations 35''.
C: Country Membership in International Organizations 35<
D: Weights and Measures 36''
E: Cross-Reference List of Geographic Names 36''
Maps I. The World (Guide to Regional Maps)
II. North America
III. Central America and the Caribbean
IV. South America
V. Europe
VI. Middle East
VII. Africa
VIII. Soviet Union, East and South Asia
IX. Southeast Asia
X. Oceania
XI. Arctic Region
XII. Antarctic Region
XIII. Standard Time Zones of the World
Notes, Definitions,
and Abbreviations
There have been some significant changes in this edition. In the
Goverment section the former Branches entry has been replaced by
three entries — Executive branch, Legislative branch, and Judicial
branch. The Leaders entry now has subentries for Chief of State,
Head of Government, and their deputies. The Elections entry has
been completely redone with information for each branch of the
national government, including the date for the last election, the date
for the next election, results (percent of vote by candidate or party),
and current distribution of seats by party. In the Economy section
there is a new entry on Illicit drugs.
Abbreviations: (see Appendix B for international organizations)
avdp. avoirdupois
c.i.f. cost, insurance, and freight
CY calendar year
DWT deadweight ton
est. estimate
Ex-Im Export-Import Bank of the United States
f.o.b. free on board
FRG Federal Republic of Germany (West Germany)
FY fiscal year
GDP gross domestic product
GDR German Democratic Republic (East Germany)
GNP gross national product
GRT gross register ton
km kilometer
km2 square kilometer
kW kilowatt
kWh kilowatt-hour
m meter
NA not available
NEGL negligible
nm nautical mile
NZ New Zealand
ODA official development assistance
OOF other official flows
PDRY People''s Democratic Republic of Yemen [Yemen
(Aden) or South Yemen]
UAE United Arab Emirates
UK United Kingdom
US United States
USSR Union of Soviet Socialist Republics (Soviet Union)
YAR Yemen Arab Republic [Yemen (Sanaa) or North
Yemen]
Administrative divisions: The numbers, designatory terms, and first-
order administrative divisions are generally those approved by the
United States Board on Geographic Names (BGN) as of 5 April
1990. Changes that have been reported but not yet acted upon by
BGN are noted.
Area: Total area is the sum of all land and water areas delimited by
international boundaries and/or coastlines. Land area is the aggre-
gate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers).
Comparative areas are based on total area equivalents. Most entities
are compared with the entire US or one of the 50 states. The smaller
entities are compared with Washington, DC (178 km2, 69 miles2) or
The Mall in Washington, DC (0.59 km2, 0.23 miles2, 146 acres).
Birth rate: The average annual number of births during a year per
1 ,000 population at midyear. Also known as crude birth rate.
VH
Notes, Definitions,
and Abbreviations (continued)
Contributors: Information was provided by the Bureau of the Census
(Department of Commerce), Central Intelligence Agency, Defense
Intelligence Agency, Defense Nuclear Agency, Department of State,
Foreign Broadcast Information Service, Navy Operational Intelli-
gence Center and Maritime Administration (merchant marine data),
Office of Territorial and International Affairs (Department of the
Interior), United States Board on Geographic Names, United States
Coast Guard, and others.
Dates of information: In general, information available as of 1
January 1990 was used in the preparation of this edition. Population
figures are estimates for 1 July 1990, with population growth rates
estimated for mid- 1990 through mid- 1991. Major political events
have been updated through 30 March 1990. Military age figures are
average annual estimates for 1990-94.
Death rate: The average annual number of deaths during a year per
1 ,000 population at midyear. Also known as crude death rate.
Diplomatic representation: The US Government has diplomatic rela-
tions with 162 nations. There are only 144 US embassies, since some
nations have US ambassadors accredited to them, but no physical US
mission exists. The US has diplomatic relations with 149 of the 159
UN members — the exceptions are Albania, Angola, Byelorussia
(constituent republic of the Soviet Union), Cambodia, Cuba, Iran,
Vietnam, People''s Democratic Republic of Yemen [Yemen (Aden) or
South Yemen], Ukraine (constituent republic of the Soviet Union),
and, obviously, the US itself. In addition, the US has diplomatic
relations with 1 3 nations that are not in the UN — Andorra, Federat-
ed States of Micronesia, Kiribati, Liechtenstein, Marshall Islands,
Monaco, Nauru, San Marino, South Korea, Switzerland, Tonga,
Tuvalu, and the Vatican City. North Korea is not in the UN and the
US does not have diplomatic relations with that nation. The US has
not recognized the incorporation of Estonia, Latvia, and Lithuania
into the Soviet Union and continues to accredit the diplomatic
representatives of their last free governments.
Disputes: This category includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral
claims of one sort or another. Every international land boundary
dispute in the "Guide to International Boundaries," a map published
by the Department of State, is included. References to other situa-
tions may also be included that are border- or frontier-relevant, such
as maritime disputes, geopolitical questions, or irredentist issues.
However, inclusion does not necessarily constitute official acceptance
or recognition by the US Government.
Entities: Some of the nations, dependent areas, areas of special
sovereignty, and governments included in this publication are not
independent, and others are not officially recognized by the US
Government. Nation refers to a people politically organized into a
sovereign state with a definite territory. Dependent area refers to a
broad category of political entities that are associated in some way
with a nation. Names used for page headings are usually the short-
form names as approved by the US Board on Geographic Names. The
long-form name is included in the Government section and an entry
of "none" indicates a long-form name does not exist. In some
instances, no short-form name exists — then the long-form name must
serve for all usages.
There are 249 entities in the Factbook that may be categorized as
follows:
VIM
Notes, Definitions,
and Abbreviations (continued)
NATIONS
157 UN members (There are 159 members in the UN, but only 157
are included in The World Factbook because Byelorussia and
Ukraine are constituent republics of the Soviet Union.)
1 5 nations that are not members of the UN — Andorra, Federated
States of Micronesia, Kiribati, Liechtenstein, Marshall Islands,
Monaco, Namibia, Nauru, North Korea, San Marino, South
Korea, Switzerland, Tonga, Tuvalu, Vatican City
OTHER
1 Taiwan
DEPENDENT AREAS
6 Australia — Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
2 Denmark — Faroe Islands, Greenland
16 France — Bassas da India, Clipperton Island, Europa Island,
French Guiana, French Polynesia, French Southern and Antarctic
Lands, Glorioso Islands, Guadeloupe, Juan de Nova Island,
Martinique, Mayotte, New Caledonia, Reunion, St. Pierre and
Miquelon, Tromelin Island, Wallis and Futuna
2 Netherlands— Aruba, Netherlands Antilles
3 New Zealand — Cook Islands, Niue, Tokelau
3 Norway — Bouvet Island, Jan Mayen, Svalbard
1 Portugal — Macau
16 United Kingdom — Anguilla, Bermuda, British Indian Ocean
Territory, British Virgin Islands, Cayman Islands, Falkland Is-
lands, Gibraltar, Guernsey, Hong Kong, Isle of Man, Jersey,
Montserrat, Pitcairn Islands, St. Helena, South Georgia and the
South Sandwich Islands, Turks and Caicos Islands
15 United States — American Samoa, Baker Island, Guam, Howland
Island, Jarvis Island, Johnston Atoll, Kingman Reef, Midway
Islands, Navassa Island, Northern Mariana Islands, Palmyra
Atoll, Puerto Rico, Trust Territory of the Pacific Islands (Palau),
Virgin Islands, Wake Island
MISCELLANEOUS
7 Antarctica, Gaza Strip, Iraq-Saudi Arabia Neutral Zone, Paracel
Islands, Spratly Islands, West Bank, Western Sahara
OTHER ENTITIES
4 oceans— Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific
Ocean
1 World
249 total
Notes: The US Government has not recognized the incorporation of
Estonia, Latvia, and Lithuania into the Soviet Union as constituent
republics during World War II. Those Baltic states are not members
of the UN and are not included in the list of nations. The US
Government does not recognize the four so-called "independent"
homelands of Bophuthatswana, Ciskei, Transkei, and Venda in South
Africa.
Gross domestic product (GDP): The value of all goods and services
produced domestically.
Gross national product (GNP): The value of all goods and services
produced domestically, plus income earned abroad, minus income
earned by foreigners from domestic production.
IX
Notes, Definitions,
and Abbreviations (continued)
GNP/GDP methodology: GNP/GDP dollar estimates for the OECD
countries, the USSR, Eastern Europe, and a portion of the developing
countries, are derived from purchasing power parity (PPP) calculations
rather than from conversions at official currency exchange rates. The
PPP methods involve the use of average price weights, which lie
between the weights of the domestic and foreign price systems; using
these weights US $100 converted into German marks by a PPP
method will buy an equal amount of goods and services in both the
US and Germany. One caution: the proportion of, say, military
expenditures as a percent of GNP/GDP in local currency accounts
may differ substantially from the proportion when GNP/GDP is
expressed in PPP dollar terms, as, for example, when an observer
estimates the dollar level of Soviet or Japanese military expenditures.
Similarly, dollar figures for exports and imports reflect the price
patterns of international markets rather than PPP price patterns.
Growth rate (population): The annual percent change in the popula-
tion, resulting from a surplus (or deficit) of births over deaths and the
balance of migrants entering and leaving a country. The rate may be
positive or negative.
Illicit drugs: There are five categories of illicit drugs — narcotics,
stimulants, depressants (sedatives), hallucinogens, and cannabis.
These categories include many drugs legally produced and prescribed
by doctors as well as those illegally produced and sold outside medical
channels.
Cannabis (Cannabis sativa) is the common hemp plant, provides
hallucinogens with some sedative properties, and includes marijuana
(pot, Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Mar-
inol), hashish (hash), and hashish oil (hash oil).
Coca (Erythroxylon coca) is a bush and the leaves contain the
stimulant cocaine. Coca is not to be confused with cocoa which comes
from cacao seeds and is used in making chocolate, cocoa, and cocoa
butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety
and include chloral hydrate, barbiturates (Amytal, Nembutal, Se-
conal, phenobarbital), benzodiazepines (Librium, Valium), methaqua-
lone (Quaalude), glutethimide (Doriden), and others (Equanil, Placi-
dyl, Valmid).
Drugs are any chemical substances that effect a physical, mental,
emotional, or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that
results in physical, mental, emotional, or behavioral impairment in an
individual.
Hallucinogens are drugs that affect sensation, thinking, self-
awareness, and emotion. Hallucinogens include LSD (acid, microdot),
mescaline and peyote (mexc, buttons, cactus), amphetamine variants
(PMA, STP, DOB), phencyclidine (PCP, angel dust, hog), phencycli-
dine analogues (PCE, PCPy, TCP), and others (psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant
(Cannabis sativa).
Heroin is a semisynthetic derivative of morphine.
Marijuana is the dried leaves of the cannabis or hemp plant
(Cannabis sativa).
Narcotics are drugs that relieve pain, often induce sleep, and refer
to opium, opium derivatives, and synthetic substitutes. Natural
narcotics include opium (paregoric, parepectolin), morphine (MS-
Contin, Roxanol), codeine (Tylenol w/codeine, Empirin w/codeine,
Robitussan A-C), and thebaine. Semisynthetic narcotics include
heroin (horse, smack) and hydromorphone (Dilaudid). Synthetic nar-
cotics include meperidine or Pethidine (Demerol, Mepergan), metha-
done (Dolophine, Methadose), and others (Darvon, Lomotil).
Notes, Definitions,
and Abbreviations (continued)
Opium is the milky exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for many natural
and semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature
dried opium poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha
edulis and is chewed or drunk as tea.
Stimulants are drugs that relieve mild depression, increase energy
and activity, and include cocaine (coke, snow, crack), amphetamines
(Desoxyn, Dexedrine), phenmetrazine (Preludin), methylphenidate
(Ritalin), and others (Cylert, Sanorex, Tenuate).
Infant mortality rate: The number of deaths to infants under one year
of age in a given year per 1,000 live births occurring in the same year.
Land use: Human use of the land surface is categorized as arable
land — land cultivated for crops that are replanted after each harvest
(wheat, maize, rice); permanent crops — land cultivated for crops that
are not replanted after each harvest (citrus, coffee, rubber); meadows
and pastures — land permanently used for herbaceous forage crops;
forest and woodland — land under dense or open stands of trees; and
other — any land type not specifically mentioned above (urban areas,
roads, desert). The percentage figure for irrigated refers to the portion
of the entire amount of land area that is artificially supplied with
water.
Leaders: The chief of state is the titular leader of the country who
represents the state at official and ceremonial functions but is not
involved with the day-to-day activities of the government. The head
of government is the administrative leader who manages the day-to-
day activities of the government. In the UK, the monarch is the chief
of state and the prime minister is the head of government. In the US,
the President is both the chief of state and the head of government.
Life expectancy at birth: The average number of years to be lived by
a group of people all born in the same year, if mortality at each age
remains constant in the future.
Maritime claims: The proximity of neighboring states may prevent
some national claims from being fully extended.
Merchant marine: All ships engaged in the carriage of goods. All
commercial vessels (as opposed to all nonmilitary ships), which
excludes tugs, fishing vessels, offshore oil rigs, etc. Also, a grouping of
merchant ships by nationality or register.
Captive register — A register of ships maintained by a territory,
possession, or colony primarily or exclusively for the use of ships
owned in the parent country. Also referred to as an offshore register,
the offshore equivalent of an internal register. Ships on a captive
register will fly the same flag as the parent country, or a local variant
of it, but will be subject to the maritime laws and taxation rules of the
offshore territory. Although the nature of a captive register makes it
especially desirable for ships owned in the parent country, just as in
the internal register, the ships may also be owned abroad. The captive
register then acts as a flag of convenience register, except that it is
not the register of an independent state.
Flag of convenience register — A national register offering registra-
tion to a merchant ship not owned in the flag state. The major flags of
convenience (FOC) attract ships to their register by virtue of low fees,
XI
Notes, Definitions,
and Abbreviations (continued)
low or nonexistent taxation of profits, and liberal manning require-
ments. True FOC registers are characterized by having relatively few
of the ships registered actually owned in the flag state. Thus, while
virtually any flag can be used for ships under a given set of
circumstances, an FOC register is one where the majority of the
merchant fleet is owned abroad. It is also referred to as an open
register.
Flag state — The nation in which a ship is registered and which
holds legal jurisdiction over operation of the ship, whether at home or
abroad. Differences in flag state maritime legislation determine how
a ship is manned and taxed and whether a foreign-owned ship may be
placed on the register.
Internal register — A register of ships maintained as a subset of a
national register. Ships on the internal register fly the national flag
and have that nationality but are subject to a separate set of maritime
rules from those on the main national register. These differences
usually include lower taxation of profits, manning by foreign nation-
als, and, usually, ownership outside the flag state (when it functions
as an FOC register). The Norwegian International Ship Register and
Danish International Ship Register are the most notable examples of
an internal register. Both have been instrumental in stemming flight
from the national flag to flags of convenience and in attracting
foreign-owned ships to the Norwegian and Danish flags.
Merchant ship — A vessel that carries goods against payment of
freight. Commonly used to denote any nonmilitary ship but accurate-
ly restricted to commercial vessels only.
Register — The record of a ship''s ownership and nationality as
listed with the maritime authorities of a country. Also, the compendi-
um of such individual ships'' registrations. Registration of a ship
provides it with a nationality and makes it subject to the laws of the
country in which registered (the flag state) regardless of the national-
ity of the ship''s ultimate owner.
Money figures: All are expressed in contemporaneous US dollars
unless otherwise indicated.
Net migration rate: The balance between the number of persons
entering and leaving a country during the year per 1 ,000 persons
(based on midyear population). An excess of persons entering the
country is referred to as net immigration (3.56 migrants/ 1 ,000
population); an excess of persons leaving the country as net emigra-
tion (—9.26 migrants/ 1 ,000 population).
Population: Figures are estimates from the Bureau of the Census
based on statistics from population censuses, vital registration sys-
tems, or sample surveys pertaining to the recent past, and on
assumptions about future trends.
Total fertility rate: The average number of children that would be
born per woman if all women lived to the end of their childbearing
years and bore children according to a given fertility rate at each age.
Years: All year references are for the calendar year (CY) unless
indicated as fiscal year (FY).
xii','b3a74403f55918f5cff4fd526d5de767ba0eafe703af27eb938cfc7d3b7f290a','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c0cfccdb5a5b94cdbed4fc292a19e809abd09afc652282d53898b865b4bc39f',1981,'','','raw',1,'entral
986 COP 2 itelligence
.gency
THF UBRARV OF THE
06 1986
OF HUMS
The
World
Factbook
Nineteen Hundred and Eighty-Six
This publication is prepared for the use of US
Government officials, and the format, coverage,
and content are designed to meet their specific
requirements. US Government officials may ob-
tain additional copies of this d^''ment directly
or through liaison channels frc
Intelligence Agency.
Requesters outside the US Go
tain subscriptions to CIA pub
this one by addressing inquir
Document Expeditir
Exchange and Gift
Library of Congress
Washington, D.C. 2
or: National Technical
5285 Port Royal Re
Springfield, VA 22
Requesters outside the US
ested in subscription serv:
cific publications either ii
form from:
Photoduplicatioi
Library of Cong
Washington, D.<
or: National Techn
5285 Port Roya
Springfield, VA
To expedite se
NTIS Order D
This publication may
Superintende
US Governm
Washington,
(Stock Numb
Central
Intelligence
Agency
The
World
Factbook
Nineteen Hundred and Eighty-Six
The World Factbook is produced annually
by the Directorate of Intelligence of the
Central Intelligence Agency. The data are
provided by various components of the
Central Intelligence Agency, the Defense
Intelligence Agency, the Bureau of the
Census, and the US Department of State. In
general, information available as of 1
January 1986 was used in the preparation of
this edition, with the following exceptions:
• Population figures are projected estimates
for 1 July 1986; the average annual
growth rates listed are projected estimates
for the period mid- 1985 to mid- 1986.
• Military manpower estimates are as of 1
January 1986, except the numbers of
males reaching military age, which are
projected averages for the five-year
period 1986-90.
• Major political developments through 14
April 1986 have been included.
Comments and queries are welcome and
may be addressed to:
Central Intelligence Agency
Attn: Public Affairs
Washington, D.C. 20505
(703) 351-2053
For information on how to obtain addi-
tional copies, see the inside of the front
cover.
AGRICULTURE LIBRA.;/
APR 1 4 1838
UNIVERSITY OF Ui''jV''Jj?
041-015-00163-9
(Supersedes 041-015-00159-2)
June 1986
Contents
Page
Definitions, Abbreviations, and Explanatory Notes
Abu Dhabi (see United Arab Emirates)','549561315e6ebce44516ac94e52db57f01640e5ea452fbfbb36c20b18b0b8e7a','internet-archive','worldfactbook86natiilli','txt','3715030f4ec03a181adceb1f7d2ceab87bb4208622c96fd755345c5e988bc4b0','https://archive.org/download/worldfactbook86natiilli/worldfactbook86natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8ca43b5db2a8309d6b822bc467b9a6de523c3303401c5a0490dc66e2ee861a2',1981,'AF','Afghanistan','raw',2,'Ajman (see United Arab Emirates)
300km
See regional mip \\ 111
Land
647,497 km2; about the size of Texas; 75%
desert, waste, or urban; 22% arable (12%
cultivated, 10% pasture); 3% forest
Land boundaries: 5,510 km','5d9d3180b114c81da3ab33b919a203a319e9948905fb16ebe60681f57d38028e','internet-archive','worldfactbook86natiilli','txt','3715030f4ec03a181adceb1f7d2ceab87bb4208622c96fd755345c5e988bc4b0','https://archive.org/download/worldfactbook86natiilli/worldfactbook86natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72b6eb99f227d4a04a059efd17f2756f96b4f6cf58cbb1123dfaa38f75411a66',1981,'AR','Argentina','raw',3,'Aruba 11
Australia 12
Austria 13
Azores (see Portugal)
B Bahamas, The 15
Bahrain 16
Balearic Islands (see Spain)
Bangladesh 17_
Barbados 19^
Belgian Congo (see Zaire)
Belgium 20^
Belize (formerly British Honduras) 22
Benin (formerly Dahomey) 23
Bermuda 24
Bhutan 26^
Bioko (see Equatorial Guinea)
Bolivia 27_
Bophuthatswana (see South Africa)
Botswana 28_
Brazil 30_
British Honduras (see Belize)
British Indian Ocean Territory 31
British Solomon Islands (see Solomon Islands)
British Virgin Islands 32
Brunei 33^
Bulgaria 34
Burkina (formerly Upper Volta) 36
Burma 37
Burundi 38
Cabinda (see Angola)
Cambodia (formerly Kampuchea) 40
Cameroon 41
iii
Page
Canada 12
Canary Islands (see Spain)
Cape Verde 44
Cayman Islands 45
Central African Republic 46
Ceylon (see Sri Lanka)
Chad 48
Channel Islands (see Guernsey and Jersey)
Chile 49
China (Taiwan listed at end of table) ol
Christmas Island 52
Colombia 53
Comoros 55
Congo 56
Cook Islands 57
Costa Rica 58
Cuba 60
Cyprus 61
Czechoslovakia 63
D Dahomey (see Benin)
Denmark 64
Djibouti (formerly French Territory of the Afars and Issas) 66
Dominica 67
Dominican Republic 68
Dubai (see United Arab Emirates)','78e5ad034687422fb629090f7b18cc8039e093c7de174a740a3dbaea0adcda5b','internet-archive','worldfactbook86natiilli','txt','3715030f4ec03a181adceb1f7d2ceab87bb4208622c96fd755345c5e988bc4b0','https://archive.org/download/worldfactbook86natiilli/worldfactbook86natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46c8900d84515a56109f6a8f2b01af4e4da25c3d29841b6683e15ef208b2abba',1981,'EC','Ecuador','raw',4,'Egypt 71
Kllk-e Islands (see Tuvalu)
El Salvador 73
Equatorial Guinea 74
Ethiopia 76
Falkland Islands (Islas Malvinas) 77
Faroe Islands 78
Fernando Po (see Equatorial Guinea)
Fiji 79
Finland 80
France 82
French Guiana 84
French Polynesia S5
French Territory of the Afars and Issas (see Djibouti)
Fujayrah, al (see United Arab Emirates)
Gabon 86
Gambia, The 88
Page
Gaza Strip (see West Bank and Gaza Strip, listed at end of table)
German Democratic Republic W)
Germany. Federal Republic of 91
Ghana 92
Gibraltar 94
Gilbert Islands (see Kiribati)
Greece 95
Greenland 96
Grenada 97
Guadeloupe 99
Guatemala 100
Guernsey 102
Guinea 103
Guinea-Bissau (formerly Portuguese Guinea) 104
Guyana 105
H Haiti 107
Honduras 108
Hong Kong 110
Hungary 111
Iceland 112_
India 114
Indonesia 1 15
Iran 117
Iraq 119
Ireland 120
Israel (West Bank and Gaza Strip listed at end of table) 122
Italy 124
Ivory Coast 125
Jamaica 127
Japan 128
Jersey 130
Jordan (West Bank and Gaza Strip listed at end of table) 131
Kampuchea (see Cambodia)
Kenya 132
Kiribati (formerly Gilbert Islands) 133
Korea, North 134
Korea. South 136
Kuwait 137
Laos 139
Lebanon 140
Lesotho 142
Liberia 113
Libya 144
Page
Liechtenstein 146
Luxembourg 147
M Macau 148
Madagascar 1 49
Madeira Islands (see Portugal)
Malagasy Republic (see Madagascar)
Malawi 151
Malaysia 152
Maldives 155
Mali 156
Malta 157
Man, Isle of 159
Martinique 160
Mauritania 161
Mauritius 162
Mayotte 164
Mexico 165
Monaco 166
Mongolia 167
Montserrat 168
Morocco 169
Mozambique 171
N Namibia (formerly South- West Africa) 172
Nauru 174
Nepal 175
Netherlands 176
Netherlands Antilles 178
New Caledonia 179
New Hebrides (see Vanuatu)
New Zealand 180
Nicaragua 181
Niger 183
Nigeria 185
Niue 186
Norfolk Island 187
Northern Rhodesia (see Zambia)
Norway 188
Oman 190
Pakistan 191
Panama 193
Papua New Guinea 194
Paraguay 196
Pemba (see Tanzania)
vi
Page
Peru 197
Philippines 198
Pitcairn 200
Poland 201
Portugal 202
Portuguese Guinea (see Guinea-Bissau)
Portuguese Timor (see Indonesia)
Qatar 204
R Ra''s al-Khaymah (see United Arab Emirates)
Reunion 205
Rhodesia (see Zimbabwe)
Rio Muni (see Equatorial Guinea)
Romania 206
Rwanda 207
St. Christopher and Nevis (formerly St. Christopher-Nevis-Anguilla) 209
St. Helena 210
St. Lucia 211
St. Vincent and the Grenadines 212
San Marino 213
Sao Tome and Principe 214
Saudi Arabia 215
Senegal 217
Seychelles 218
Sharjah (see United Arab Emirates)
Sierra Leone 219
Singapore 221
Solomon Islands (formerly British Solomon Islands) 222
Somalia 223
South Africa 224
Southern Rhodesia (see Zimbabwe)
South- West Africa (see Namibia)
Soviet Union 226
Spain 228
Spanish Sahara (see Western Sahara)
Sri Lanka (formerly Ceylon) 230
Sudan 231
Suriname 233
Swaziland 234
Sweden 235
Switzerland 237
Syria 239
vii
Page
Tanganyika (see Tanzania)
Tanzania 240
Tasmania (see Australia)
Thailand 242
Togo 2-1 o
Tokelau 244
Tonga 245
Transkei (see South Africa)
Trinidad and Tobago 246
Tunisia 248
Turkey 249
Turks and Caicos Islands 251
Tuvalu (formerly Ellice Islands) 252
U Uganda 253
Umm al-Qaywayn (see United Arab Emirates)
United Arab Emirates (Abu Dhabi, Ajman, Dubai, al Fujayrah, 254
Ra''s al-Khaymah, Sharjah, Umm al-Qaywayn)
United Arab Republic (see Egypt)
United Kingdom 255
United States 257
Upper Volta (see Burkina)
Uruguay 259
Vanuatu (formerly New Hebrides) 2(i()
Vatican City 261
Venda (see South Africa)
Venezuela 2li2
Vietnam 263
W Wallis and Futuna 265
Walvis Bay (see South Africa)
Western Sahara (formerly Spanish Sahara) 265
Western Samoa 266
Yemen Arab Republic (North Yemen) 267
Yemen, People''s Democratic Republic of (South Yemen) 268
Yugoslavia 270
Zaire 271
Zambia (formerly Northern Rhodesia) 27 >
Zanzibar (see Tanzania)
Zimbabwe (formerly Southern Rhodesia) 274
Taiwan (China listed alphabetically) 275
West Bank and Gaza Strip 277
viii
Page
Appendixes
A. The United Nations System 279
B. Selected UN Organizations 280
C. Selected International Organizations 281
D. Conversion Table 283
E. Country Membership in Selected Organizations 284
Maps
I. The World (Guide to Regional Maps II-XIII)
II. North America
III. Central America and the Caribbean
IV. South America
V. Europe
VI. Middle East
VII. Africa
VIII. Soviet Union, East and South Asia
IX. Southeast Asia
X. Oceania
XI. Arctic Region
XII. Antarctic Region
XIII. Standard Time Zones of the World
ix
Definitions, Abbreviations,
and Explanatory Notes
Fiscal Year: The abbreviation FY stands for fiscal year; all years are
calendar years unless otherwise indicated.
GDP and GNP: GDP is the total market value of all goods and
services produced within the domestic borders of a country over a
particular time period, normally a year. GNP equals GDP plus the
income accruing to domestic residents arising from investment abroad
less income earned in the domestic market accruing to foreigners
abroad.
Imports, Exports, and Aid: Standard abbreviations used in individual
entries throughout this factbook are c.i.f. (cost, insurance, and freight),
f.o.b. (free on board), ODA (official development assistance), and OOF
(other official flows).
Land Utilization: Most of the land utilization percentages are rough
estimates. Figures for "arable" land in some cases reflect the area
under cultivation rather than the total cultivable area.
Maritime Zones: Fishing and economic zones claimed by coastal
states are included only when they differ from territorial sea limits.
Maritime claims do not necessarily represent the position of the
United States Government.
Money: All money figures are in contemporaneous US dollars unless
otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to express
volume of crude oil and refined products; a barrel equals 42.00
gallons, 158.99 liters, 5.61 cubic feet, or 0.16 cubic meters.
Note: Some of the countries and governments included in this
publication are not fully independent, and others are not officially
recognized by the United States Government.','c71571e42ed0ca7fef5c65f53fafe98094aded21c1e31542cad54651f88f8aa5','internet-archive','worldfactbook86natiilli','txt','3715030f4ec03a181adceb1f7d2ceab87bb4208622c96fd755345c5e988bc4b0','https://archive.org/download/worldfactbook86natiilli/worldfactbook86natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43479ba9ac4b84fb92e23fbe18a1f605b830c574546e3b65ba49ba632de0150d',1981,'','','raw',1,'UNIVERSITY OF
ILLINOIS LIBRARY
AT URBANA-CHAMPAIGN
BOOKSTACKS
BOOKSTACKS
DOCUMENTS
DoC
THE LIBRARY Of; THE
AUG - 6 1982
UNIVERSITY OF ILLINOIS
AT URBANA-CHAMPAIGN
Produced by the Central Intelligence Agency
CR 82-1 1 1 17
I
/
I
UNIVERSITY OF
ILLINOIS LIBRARY
AT URBANA-CHAMPAIGN
DOCUMENTS
This publication is prepared for the use of US Government
officials, and the format, coverage, and content are designed to
meet their specific requirements. US Government officials may
obtain additional copies of this document directly or through
liaison channels from the Central Intelligence Agency.
Requesters outside the US Government may obtain subscriptions to
CIA publications similar to this one by addressing inquiries to:
.Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
*
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Requesters outside the US Government not interested in subscription
service may purchase specific publications either in paper copy or
microform from:
Photoduplication Service
Library of Congress
Ungton, D.C. 20540
Wasfpi
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
(To expedite service call the
NTIS Order Desk (703) 487-4650)
This publication is also for sale by the Superintendent of Documents,
US Government Printing Office, Washington, D.C. 20402
(Stock No. 041-015-00151-5).
Central
Intelligence
Agency
The World Factbook— 1982
The World Factbook is produced annually by the Di
Central Intelligence Agency. The data are provided I
Central Intelligence Agency, the Defense Intelligenc
Census, and the US State Department. In general, ii
1 January 1982 was used in the preparation of this e
ary cutoff date are explained on page vii. Comments
may be addressed to:
Central Intelligence Agency
Attn: Public Affairs
Washington, D.C. 20505
(703)351-7676
For information on how to obtain additional copies.
To renew coll Telephone Cenler, 333-8400
._._ o r\\ «Q,
nH\\ " 3
. 2 \\m
3 0
JAN 0 2 1988i
DEC 0 4 1987
L161 — O-1096
(Supersedes GS WF 8 1-001)
April 1982
CONTENTS
Page
Definitions, Abbreviations, and Explanatory Notes ... vii
United Nations (UN): Structure and Associated
Agencies viii
Abbreviations for Other Important International
Organizations ix
Conversion Factors xi
— A—
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN 1
''Ajrnan (see UNITED ARAB EMIRATES)','dbf547be3390790ace18143ca60ba14ea0aadb8531cb9316f42d109ca9ee4928','internet-archive','worldfactbook82natiilli','txt','3a5dfcad5bfb61c090518e903878a462b8ade799a00c8e0b811d86153e2d6b8c','https://archive.org/download/worldfactbook82natiilli/worldfactbook82natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('649176877850334c8df7ac9d50b3bd73f4b856b46595faad6562ea90f6a8c620',1981,'AT','Austria','raw',2,'Azores (see PORTUGAL)
2
4
5
6
8
9
10
12
BAHAMAS, THE 13
BAHRAIN 14
Balearic Islands (see SPAIN)
BANGLADESH 15
BARBADOS 17
BELGIUM 18
BELIZE 19
BENIN 21
BERMUDA 22
BHUTAN 23
BOLIVIA 24
Bophuthatswana (see SOUTH AFRICA)
BOTSWANA 26
BRAZIL 27
British Honduras (see BELIZE)
British Solomon Islands (see SOLOMON ISLANDS)
BRUNEI 29
BULGARIA 30
BURMA 31
BURUNDI... 33
Page
Cabinda (see ANGOLA)
Cambodia (see KAMPUCHEA)
CAMEROON 34
CANADA 36
Canary Islands (see SPAIN)
CAPE VERDE 37
CENTRAL AFRICAN REPUBLIC 38
Ceylon (see SRI LANKA)
CHAD 40
CHILE 41
CHINA (Taiwan listed at end of table) 43
COLOMBIA 44
COMOROS 46
CONGO (Brazzaville) 47
Congo (Kinshasa) (see ZAIRE)
COOK ISLANDS 48
COSTA RICA .. 49','dc18419f92f00ed0b14b672e560371f2116ce45c025e285e15975b7e268fa692','internet-archive','worldfactbook82natiilli','txt','3a5dfcad5bfb61c090518e903878a462b8ade799a00c8e0b811d86153e2d6b8c','https://archive.org/download/worldfactbook82natiilli/worldfactbook82natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cbc76259c9a2ff491c27f160015bdaaba450a8de5174067ced27f0ac62208de',1981,'CY','Cyprus','raw',3,'CZECHOSLOVAKIA .
— D—
51
52
54
Dahomey (see BENIN)
DENMARK 56
DJIBOUTI (formerly French Territory of the Afars
and Issas) 57
DOMINICA 58
DOMINICAN REPUBLIC 59
Dubai (see UNITED ARAB EMIRATES)
— E—
ECUADOR 61
EGYPT 62
Ellice Islands (see TUVALU)
EL SALVADOR 64
EQUATORIAL GUINEA 65
ETHIOPIA 67
— F—
FALKLAND ISLANDS (MALVINAS) 68
FAROE ISLANDS 69
Fernando Po (see EQUATORIAL GUINEA)
in
Page
Page
FIJI 70
FINLAND 72
FRANCE 73
FRENCH GUIANA 75
FRENCH POLYNESIA 77
French Territory of the Afars and Issas (see DJIBOUTI)
Fujairah (see UNITED ARAB EMIRATES)
GABON 78
GAMBIA, THE 79
GERMAN DEMOCRATIC REPUBLIC 81
GERMANY, FEDERAL REPUBLIC OF 82
GHANA 84
GIBRALTAR 85
Gilbert Islands (see KIRIBATI)
GREECE 87
GREENLAND 88
GRENADA 89
GUADELOUPE 90
GUATEMALA 92
GUINEA 93
GUINEA-BISSAU 95
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA 96
— H—
HAITI 97
HONDURAS 99
HONG KONG 100
HUNGARY... 102
ICELAND 103
INDIA 105
INDONESIA 106
IRAN 108
IRAQ 109
IRELAND Ill
ISRAEL 112
ITALY 114
IVORY COAST... 116
— K—
KAMPUCHEA (formerly Cambodia) 122
KENYA 124
KIRIBATI (formerly Gilbert Islands) 125
KOREA, NORTH 126
KOREA, SOUTH 127
KUWAIT... 129
JAMAICA 1 18
JAPAN 119
JORDAN... 121
LAOS 130
LEBANON 132
LESOTHO 133
LIBERIA 135
LIBYA 136
LIECHTENSTEIN 138
LUXEMBOURG 139
— M—
MACAU 141
MADAGASCAR 142
Madeira Islands (see PORTUGAL)
Malagasy Republic (see MADAGASCAR)
MALAWI 144
MALAYSIA 145
MALDIVES 148
MALI 149
MALTA 151
MARTINIQUE 152
MAURITANIA 154
MAURITIUS 155
MEXICO 157
MONACO 158
MONGOLIA 159
MOROCCO 160
MOZAMBIQUE 162
— N —
NAMIBIA (South-West Africa) 163
NAURU 164
NEPAL 165
NETHERLANDS 167
NETHERLANDS ANTILLES 169
NEW CALEDONIA 170
New Hebrides (see VANUATU)
NEW ZEALAND 171
NICARAGUA .. 173
IV
Page
Page
— N—
NIGER 175
NIGERIA 176
Northern Rhodesia (see ZAMBIA)
NORWAY ... 178
OMAN 179
— P—
PAKISTAN 180
PANAMA 182
PAPUA NEW GUINEA 184
PARAGUAY 185
Pemba (see TANZANIA)
PERU 187
PHILIPPINES 188
POLAND 190
PORTUGAL 191
Portuguese Guinea (see GUINEA-BISSAU)
Portuguese Timor (see INDONESIA)
193
Ras al Khaimah (see UNITED ARAB EMIRATES)
REUNION 194
Rhodesia (see ZIMBABWE)
Rio Muni (see EQUATORIAL GUINEA)
ROMANIA 196
RWANDA 197
— S—
ST. CHRISTOPHER-NEVIS 199
ST. LUCIA 200
ST. VINCENT AND THE GRENADINES 201
SAN MARINO 202
SAO TOME AND PRINCIPE 203
SAUDI ARABIA 204
SENEGAL 206
SEYCHELLES 207
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE 209
SINGAPORE 210
SOLOMON ISLANDS (formerly British Solomon
Islands) 212
SOMALIA .. 213
SOUTH AFRICA 214
Southern Rhodesia (see ZIMBABWE)
South-West Africa (see NAMIBIA)
SOVIET UNION 215
SPAIN 217
Spanish Sahara (see WESTERN SAHARA)
SRI LANKA (formerly Ceylon) 219
SUDAN 220
SURINAME 222
SWAZILAND 223
SWEDEN 224
SWITZERLAND 226
SYRIA 227
— T—
Tanganyika (see TANZANIA)
TANZANIA 229
Tasmania (see AUSTRALIA)
THAILAND 230
TOGO 232
TONGA 233
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO 234
TUNISIA 236
TURKEY 237
TUVALU (formerly Ellice Islands) 239
— U—
UGANDA 240
Umm al Qaiwain (see UNITED ARAB EMIRATES)
UNITED ARAB EMIRATES: Abu Dhabi, ''Ajman,
Dubai, Fujairah, Ras al Khaimah, Sharjah, Umm al
Qaiwain 241
United Arab Republic (see EGYPT)
UNITED KINGDOM 242
UNITED STATES 244
UPPER VOLTA 245
URUGUAY 247
— V—
VANUATU (formerly New Hebrides) 248
VATICAN CITY 249
VENEZUELA 250
VIETNAM... 252
— W—','635d4e6eea113fef824b262be0016c40ef42fe744704d881301a6004ac0f804a','internet-archive','worldfactbook82natiilli','txt','3a5dfcad5bfb61c090518e903878a462b8ade799a00c8e0b811d86153e2d6b8c','https://archive.org/download/worldfactbook82natiilli/worldfactbook82natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8255a96fff8029d9f210ef8af394c35c9ece8f64f95d6c44bf210b84ca24d3f7',1981,'WF','Wallis and Futuna','raw',4,'Walvis Bay (see SOUTH AFRICA)
253
Page
— W—
WESTERN SAHARA 254
(formerly Spanish Sahara)
WESTERN SAMOA 255
— Y—
YEMEN (Aden) 256
YEMEN (Sanaa) 258
YUGOSLAVIA.. 259
— Z—
ZAIRE','40ee6fb91923afde531a9285f3a7015e9a53eda29581d5c86d3f59f4f022485f','internet-archive','worldfactbook82natiilli','txt','3a5dfcad5bfb61c090518e903878a462b8ade799a00c8e0b811d86153e2d6b8c','https://archive.org/download/worldfactbook82natiilli/worldfactbook82natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7074330b0bded0df59958fc2bf08a321f2c99bda7e518841766e22d1a79b49d8',1981,'ZM','Zambia','raw',5,'Zanzibar (see TANZANIA)
ZIMBABWE...
TAIWAN
Page
260
262
263
265
Maps
(following text)
I The World (Guide to Reference Maps II— XI)
II North America
III Central America and the Caribbean
IV South America
V Europe
VI Middle East
VII Africa
VIII Soviet Union, East and South Asia
IX Southeast Asia
X Oceania
XI Arctic Region
XII Antarctic Region
vi
Definitions, Abbreviations, and Explanatory Notes:
Dates of Information:
• Population figures are projected estimates for 1 July 1982; the average annual growth
rates listed are projected estimates for the period mid- 1981 to mid- 1982.
• Military manpower estimates are as of 1 January 1982, except the numbers of males
reaching military age, which are projected averages for the five-year period 1982-86.
• In addition, although research for this edition was generally completed in January
1982, major political developments through 25 April 1982 have been included.
Fiscal Year: The abbreviation FY stands for fiscal year; all years are calendar years un-
less otherwise indicated.
GDP and GNP: GDP is the total market value of all goods and services produced within
the domestic borders of a country over a particular time period, normally a year. GNP
equals GDP plus the income accruing to domestic residents arising from investment
abroad less income earned in the domestic market accruing to foreigners abroad.
Imports, Exports, and Aid: Standard abbreviations used in individual entries
throughout this factbook are c.i.f. (cost, insurance, and freight), f.o.b. (free on board),
ODA (official development assistance), and OOF (other official flows).
Land Utilization: Most of the land utilization percentages are rough estimates. Figures
for "arable" land in some cases reflect the area under cultivation rather than the total
cultivable area.
Maritime Zones: Fishing and economic zones claimed by coastal states are included
only when they differ from territorial sea limits. Maritime claims do not necessarily rep-
resent the position of the United States Government.
Money: All money figures are in contemporaneous US dollars unless otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to express volume of crude oil
and refined products; a barrel equals 42.00 gallons, 158.99 liters, 5.61 cubic feet, or
0.16 cubic meters.
Some of the countries and governments included in this publication are not fully
independent, and others are not officially recognized by the United States Government.
vii
UNITED NATIONS (UN): STRUCTURE AND RELATED AGENCIES
Principal Organs:
SC
GA
ECOSOC
TC
ICJ
Security Council
General Assembly
Economic and Social Council
Trusteeship Council
International Court of Justice
Secretariat
Operating Bodies:
UNCTAD
TDB
UNDP
UNICEF
UNIDO
UN Conference on Trade and Development
Trade and Development Board
UN Development Program
UN Children''s Fund
UN Industrial Development Organization
Regional Economic Commissions:
EGA Economic Commission for Africa
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ECWA Economic Commission for Western Asia
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the UN:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development (World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFAD International Fund for Agricultural Development
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO UN Educational, Scientific, and Cultural Organization
UPU Universal Postal Union
WFC World Food Council
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
Autonomous Organization Under the UN:
IAEA International Atomic Energy Agency
VIII
ABBREVIATIONS FOR OTHER IMPORTANT INTERNATIONAL ORGANIZATIONS
AAPSO Afro-Asian People''s Solidarity Organization
ADB Asian Development Bank
AFDB African Development Bank
AIOEC Association of Iron Ore Exporting Countries
ANZUS ANZUS Council; treaty signed by Australia, New Zealand, and the','e095dda6b9826e3749477266d5ee627e27e5acaea9a185c29afbfda5605b5db9','internet-archive','worldfactbook82natiilli','txt','3a5dfcad5bfb61c090518e903878a462b8ade799a00c8e0b811d86153e2d6b8c','https://archive.org/download/worldfactbook82natiilli/worldfactbook82natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d51358255661d559364863aa761b6b5c255826d2172d923d55972950e9a0718',1981,'US','United States','raw',6,'ARC African Peanut (Groundnut) Council
ASEAN Association of Southeast Asian Nations
ASPAC Asian and Pacific Council
ASSIMER International Mercury Producers Association
BENELUX Belgium, Netherlands, Luxembourg Economic Union
BLEU Belgium-Luxembourg Economic Union
CACM Central American Common Market
CARICOM Caribbean Common Market
CARIFTA Caribbean Free Trade Association
CCC Customs Cooperation Council
CEAO West African Economic Community
CEMA Council for Mutual Economic Assistance
CENTO Central Treaty Organization
CIPEC Intergovernmental Council of Copper Exporting Countries
. . . Colombo Plan
. . . Council of Europe
DAC Development Assistance Committee (OECD)
EAMA African States associated with the EEC
EC European Communities (EEC, ECSC, EURATOM)
ECOWAS Economic Community of West African States
ECSC European Coal and Steel Community
EEC European Economic Community (Common Market)
EFTA European Free Trade Association
EIB European Investment Bank
ELDO European Space Vehicle Launcher Development Organization
EMA European Monetary Agreement
ENTENTE Political-Economic Association of Ivory Coast, Dahomey, Niger, Upper
Volta, and Togo
ESRO European Space Research Organization
EURATOM European Atomic Energy Community
G-77 Group of 77
GCC Gulf Cooperation Council
IADB Inter-American Defense Board
IATP International Association of Tungsten Producers
IBA International Bauxite Association
IBEC International Bank for Economic Cooperation
ICAC International Cotton Advisory Committee
ICCAT International Commission for the Conservation of Atlantic Tunas
ICCO International Cocoa Organization
ICEM Intergovernmental Committee for European Migration
ICES International Cooperation in Ocean Exploration
ICO International Coffee Organization
ABBREVIATIONS FOR OTHER IMPORTANT INTERNATIONAL ORGANIZATIONS (Cont.)
IDB
IEA
IHO
IIB
INRO
INTELSAT
IOOC
IPU
IRC
ISCON
ISO
ITC
IWC
IWC
LAFTA
LICROSS
NAM
NATO
OAPEC
OAS
OAU
OCAM
ODECA
OECD
OPEC
SELA
SPC
UDEAC
UEAC
UPEB
WEU
WFTU
WPC
WSG
WTO
Inter-American Development Bank
International Energy Agency (associated with OECD)
International Hydrographic Organization
International Lead and Zinc Study Group
International Investment Bank
International Natural Rubber Organization
International Telecommunications Satellite Organization
International Olive Oil Council
Inter-Parliamentary Union
International Red Cross
Islamic Conference
International Sugar Organization
International Tin Council
International Whaling Commission
International Wheat Council
Latin American Free Trade Association
League of Red Cross Societies
Non-Aligned Movement
North Atlantic Treaty Organization
Organization of Arab Petroleum Exporting Countries
Organization of American States
Organization of African Unity
Afro-Malagasy and Mauritian Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
Organization of Petroleum Exporting Countries
Latin American Economic System
South Pacific Commission
Economic and Customs Union of Central Africa
Union of Central African States
Union of Banana Exporting Countries
Western European Union
World Federation of Trade Unions
World Peace Council
International Wool Study Group
World Tourism Organization
Conversion Factors
To Convert From
To
Multiply By
Acres
Hectares
0.40468S6
Acres
Kilometers, square
0.004046856
Acres
Meters, square
4046.856
Centimeters
Meters
0.01
Centimeters, square
Meters, square
0.0001
Degrees, Fahrenheit
Degrees, Celsius
subtract 32 and
multiply by 5/9
Feet
Centimeters
30.48
Feet
Meters
0.3048
Feet
Kilometers
0.0003048
Feet, cubic
Liters
28.316847
Feet, cubic
Meters, cubic
0.028316847
Feet, square
Centimeters, square
929.0304
Feet, square
Meters, square
0.09290304
Gallons, US liquid
Liters
3.785412
Gallons, US liquid
Meters, cubic
0.003785412
Grams
Ounces, troy
0.032151
Grams
Pounds, troy
0.002679
Hectares
Kilometers, square
0.01
Hectares
Meters, square
10,000
Inches
Centimeters
2.54
Inches
Meters
0.0254
Inches, cubic
Milliliters
16.387064
Inches, cubic
Liters
0.016387064
Inches, cubic
Meters, cubic
0.000016387064
Inches, square
Centimeters, square
6.4516
Inches, square
Meters, square
0.00064516
Kilograms
Ounces, troy
32.15075
Kilograms
Pounds, troy
2.679229
Kilograms
Tons, metric
0.001
Kilometers, square
Hectares
100
Liters
Milliliters
1000
Liters
Meters, cubic
0.001
Meters
Millimeters
1000
Meters
Centimeters
100
Meters
Kilometers
0.001
Meters, cubic
Liters
1000
To Convert From
To
Multiply By
Meters, cubic
Tons, register
0.353147
Miles, nautical
Kilometers
1.852
Miles, statute
Centimeters
160934.4
Miles, statute
Meters
1609.344
Miles, statute
Kilometers
1.609344
Miles, square
Hectares
258.9998
Miles, square
Kilometers, square
2.589998
Ounces, avoirdupois
Grams
28.349523
Ounces, avoirdupois
Kilograms
0.028349523
Ounces, troy
Pounds, troy
0.083333
Ounces, troy
Grams
31.10348
Pints, liquid
Milliliters
473.176473
Pints, liquid
Liters
0.473176473
Pounds, avoirdupois
Grams
453.59237
Pounds, avoirdupois
Kilograms
0.45359237
Pounds, avoirdupois
Quintals
0.00453592
Pounds, avoirdupois
Tons, metric
0.000453592
Pounds, troy
Ounces, troy
12
Pounds, troy
Grams
373.241722
Quarts, dry
Liters
1.101221
Quarts, dry
Dekaliters
0.1101221
Quarts, liquid
Milliliters
946.352946
Quarts, liquid
Liters
0.946352946
Quintals
Tons, metric
0.1
Tons, long
Kilograms
1016.047
Tons, long
Tons, metric
1.016047
Tons, metric
Quintals
10
Ton-miles, long
Ton-kilometers, metric
1.635169
Ton-miles, short
Ton-kilometers, metric
1.459972
Tons, register
Meters, cubic
2.831685
Tons, short
Kilograms
907.185
Tons, short
Tons, metric
0.907185
Yards
Centimeters
91.44
Yards
Meters
0.9144
Yards, cubic
Liters
764.5549
Yards, cubic
Meters, cubic
0.7645549
Yards, square
Meters, square
0.836127','903546483a3dbcb42d1ffa0df59af0671419289fe8b4391f1ff31fc13c8a7afc','internet-archive','worldfactbook82natiilli','txt','3a5dfcad5bfb61c090518e903878a462b8ade799a00c8e0b811d86153e2d6b8c','https://archive.org/download/worldfactbook82natiilli/worldfactbook82natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('676442f1e53f5cb7cc1377bfc840b3c4ed6104e09986f41da5eff0076fb1bdc2',1981,'AF','Afghanistan','raw',7,'O SOVIET
UNION
(See reference map VIII)
LAND
647,500 km2; 22% arable (12% cultivated, 10% pasture),
75% desert, waste, or urban, 3% forested
Land boundaries: 5,510 km','919d51edad081171b814e8e6029b8a96d3389e32e5848b851ed077396829d2e2','internet-archive','worldfactbook82natiilli','txt','3a5dfcad5bfb61c090518e903878a462b8ade799a00c8e0b811d86153e2d6b8c','https://archive.org/download/worldfactbook82natiilli/worldfactbook82natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

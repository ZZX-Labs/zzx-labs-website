SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19c5e5061e66613a930b0d2d844baaa9ea28a17beb4066d9a09b4ef9a18a729f',1981,'JP','Japan','military-and-security',764,'Military manpower: males 1 5-49,
1,683,758; 883,283 fit for military service
Defense expenditures: NA
348','d017cf0d92be713ee653604ddc867419a90b468ccc01b3a347a819294d98e83c','internet-archive','worldfactbook90natiilli','txt','33a0cc49cdd07fa7f7c42061eaac128e5d5b05f44ab395d31d42a9078938ea62','https://archive.org/download/worldfactbook90natiilli/worldfactbook90natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca8672d2294598a35c21839b464b81e52822056d94a6418773e1d10e9283cc6d',1981,'DJ','Djibouti','military-and-security',172,'Electric power: 80,100 kW capacity (1985);
140 million kWh produced (1985), 471 kWh
per capita
Exports: $88 million (f.o.b., 1984 prelim.);
hides and skins and transit of coffee; a large
portion consists of reexports to foreign resi-
dents of Djibouti
Imports: $200 million (f.o.b., 1984 prelim.);
almost all domestically needed goods —
foods, machinery, transport equipment
Budget: (1983) revenues, $118 million;
grants, $27 million; current expenditures,
$120 million; development expenditures,
$32 million; extrabudgetary expenditures,
$21 million
Monetary conversion rate: 177.67 Djibouti
francs=US$l (October 1984)
Fiscal year: calendar year
Gommunications
Railroads: the Ethiopian-Djibouti railroad
extends for 97 km through Djibouti
Highways: 2,800 km total; 279 km bitumi-
nous surface, 229 km improved earth, 2,292
km unimproved earth
Ports: 1 major (Djibouti)
Civil air: 1 major transport aircraft
Airfields: 12 total, 10 usable; 1 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 4 with runways
1, 220-2,439 m
Telecommunications: fair system of urban
facilities in Djibouti and radio-relay stations
at outlying places; 7,200 telephones (2.0 per
100 popl.); 2 AM stations, 1 FM station, 2 TV
stations; 1 Indian Ocean satellite ground
station, 1 Arab satellite station, 1 submarine
cable to Saudi Arabia under construction
Defense Forces
Branches: Army, Navy, Air Force; paramili-
tary National Security Force
Military manpower: males 15-49, about
66,000; about 39,000 fit for military service
Military budget: for fiscal year ending 31
December 1984, $27.8 million; about 22% of
central government budget
66','f86bc5ba3c09f1b1c23c807f4533d9915d87e62fb662ba8f2d69ed357a16d4c4','internet-archive','worldfactbook86natiilli','txt','3715030f4ec03a181adceb1f7d2ceab87bb4208622c96fd755345c5e988bc4b0','https://archive.org/download/worldfactbook86natiilli/worldfactbook86natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e3201a64a253807ed971d954eeef6b5e0400912611a04464fdbdb7c30b55cec',1981,'DM','Dominica','military-and-security',173,'See regional map 111
Land
752.7 km2; about one-fourth the size of
Rhode Island; 67% forest; 24% arable; 2%
pasture; 7% other
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 148 km','911a4175e2d1448fc0343e32597159ec0f554e9818d8227389b45dd95824ca8f','internet-archive','worldfactbook86natiilli','txt','3715030f4ec03a181adceb1f7d2ceab87bb4208622c96fd755345c5e988bc4b0','https://archive.org/download/worldfactbook86natiilli/worldfactbook86natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

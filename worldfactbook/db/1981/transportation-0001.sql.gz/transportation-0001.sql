SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1c232fa7fde2d480786183425e6467044ada895c07728c5d940025ed6962530',1981,'NZ','New Zealand','transportation',406,'Pipelines: natural gas, 785 km
Ports: 3 major
Civil air: about 40 major transport aircraft
Airfields: 193 total, 185 usable; 25 with permanent-
surface runways; 2 with runways 2,440-3,659 m; 50 with
runways 1,220-2,439 m
Telecommunications: excellent international and domes-
tic systems; 1.7 million telephones (55 per 100 popl.); 64 AM
stations, no FM, 14 TV stations, and 129 repeaters; subma-
rine cables extend to Australia and Fiji Islands; 1 ground
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 814,000; 587,000 fit for
military service; 30,000 reach military age (20) annually
about
Military budget: est. for fiscal year ending 31 March
1982, $457.0 million; about 4.9% of central government
budget
172','333f0cc7a0ddd7d5dd268f7ff0440bbde5419e8235a6feb582e618d8be2b8c5d','internet-archive','worldfactbook82natiilli','txt','3a5dfcad5bfb61c090518e903878a462b8ade799a00c8e0b811d86153e2d6b8c','https://archive.org/download/worldfactbook82natiilli/worldfactbook82natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d4fa322911cb2c19c7b6aeb0243a3938f8837437c1aee07f213eedcc1f89f42',1981,'NI','Nicaragua','transportation',407,'(See reference map III)
LAND
147,900 km2; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other
Land boundaries: 1,220 km
WATER
Limits of territorial waters (claimed): 200 nm (fishing,
200 nm; continental shelf, including sovereignty over super-
jacent waters)
Coastline: 910 km','9b1a90c323cde925be1242c6d767d40b9ccc9a1d52fcea34a4ea0325d4f849b6','internet-archive','worldfactbook82natiilli','txt','3a5dfcad5bfb61c090518e903878a462b8ade799a00c8e0b811d86153e2d6b8c','https://archive.org/download/worldfactbook82natiilli/worldfactbook82natiilli_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2e42bb510c0439f218afd88d4316640e4712b37d9f1fa99255d79bfa433745',2000,'DZ','Algeria','people-and-society',19,'Population: 31,193,917 (July 2000 est.)
Age structure:
0-14 years: 35% (male 5,591,044; female 5,389,046)
15-64 years: 61% (male 9,582,864; female
9,381,088)
65 years and over: 4% (male 577,875; female
672,000) (2000 est.)
Population growth rate: 1 .74% (2000 est.)
Birth rate: 23.14 births/1,000 population (2000 est.)
Death rate: 5.3 deaths/1,000 population (2000 est.)
Net migration rate: -0.47 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.02 male(s)/female (2000 est.)
Infant mortality rate: 41.97 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 69.65 years
male: 68.34 years
female: 71 .02 years (2000 est.)
Total fertility rate: 2.8 children born/woman
(2000 est.)
Nationality:
noun: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less
than 1%
Religions: Sunni Muslim (state religion) 99%,
Christian and Jewish 1%
Languages: Arabic (official), French, Berber dialects
Literacy:
definition: age 15 and over can read and write
total population: 61 .6%
male: 73.9%
female: 49% (1 995 est.)','d91a8e747619989068f41c982e95e5fb77ba7e256ffc9ed5127981bf186fd4fa','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37b27150127643711459b0753238159d1f8b20bc20999e672e0a2cf436c9c90e',2000,'AD','Andorra','people-and-society',28,'Population: 66,824 (July 2000 est.)
Age structure:
0-14 years: 15% (male 5,382; female 4,883)
15-64 years: 72% (male 25,463; female 22,837)
65 years and over: 1 3% (male 4, 1 60; female 4,099)
(2000 est.)
Population growth rate: 1 .22% (2000 est.)
Birth rate: 10.58 births/1 ,000 population (2000 est.)
Death rate: 5.27 deaths/1 ,000 population
(2000 est.)
Net migration rate: 6.9 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .1 male(s)/female
15-64 years: 1.M male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 1 .1 male(s)/female (2000 est.)
Infant mortality rate: 4.08 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 83.46 years
male: 80.56 years
female: 86.56 years (2000 est.)
Total fertility rate: 1 .25 children born/woman
(2000 est.)
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic groups: Spanish 43%, Andorran 33%,
Portuguese 11%, French 7%, other 6% (1998)
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castilian
Literacy:
definition: NA
total population: 1 00%
maie: NA%
female: NA%
Population; 10,145,267 (July 2000 est.)
Age structure;
0-14 years: 43% (male 2,215,706; female 2,172,106)
15-64 years: 54% (male 2,792,313; female
2,692,790)
65 years and over: 3% (male 124,404; female
147,948) (2000 est.)
Population growth rate: 2.15% (2000 est.)
Birth rate: 46.89 births/1 ,000 population (2000 est.)
Death rate: 25.01 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.34 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.02 male(s)/female (2000 est.)
infant mortaiity rate: 1 95.78 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth;
total population: 38.31 years
male: 37.11 years
female: 39.56 years (2000 est.)
Total fertility rate: 6.52 children born/woman
(2000 est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%,
Bakongo 13%, mestico (mixed European and Native
African) 2%, European 1%, other 22%
12
Angola (continued)
Religions: indigenous beliefs 47%, Roman Cathoiic
38%, Protestant 15% (1998 est.)
Languages; Portuguese (official), Bantu and other
African languages
Literacy:
definition: age 15 and over can read and write
total population: 42%
male: 56%
female: 2S% (19% est.)
Gov e r nln e n f
Country name;
conventional long form: Republic of Angola
conventional short form: Angola
local long form: Republica de Angola
local short form: Angola
former: People''s Republic of Angola
Data code: AO
Government type; transitional government,
nominally a multiparty democracy with a strong
presidential system
Capital: Luanda
Administrative divisions; 1 8 provinces (provincias,
singular - provincia); Bengo, Benguela, Bie, Cabinda,
Cuando Cubango, Cuanza Norte, Cuanza Sul,
Cunene, Huambo, Huila, Luanda, Lunda Norte, Lunda
Sul, Malanje, Mexico, Namibe, Uige, Zaire
Independence: 11 November 1975 (from Portugal)
National holiday; Independence Day, 1 1 November
(1975)
Constitution: 1 1 November 1 975; revised 7 January
1 978, 1 1 August 1 980, 6 March 1991, and 26 August
1992
Legal system: based on Portuguese civil law
system and customary law; recently modified to
accommodate political pluralism and increased use of
free markets
Suffrage: 18 years of age; universal
Executive branch;
chief of state: President Jose Eduardo DOS SANTOS
(since 21 September 1979); note - the president is
both chief of state and head of government
head of government: President Jose Eduardo DOS
SANTOS (since January 1 999); note - the president is
both chief of state and head of government
cabinet: Council of Ministers appointed by the
president
elections: President DOS SANTOS originally elected
(in 1 979) without opposition under a one-party system
and stood for reelection in Angola''s first multiparty
elections 28-29 September 1 992, the last elections to
be held (next to be held NA)
election results: DOS SANTOS received 49.6% of the
total vote, making a run-off election necessary
between him and second-place finisher Jonas
SAVIMBI (40.1% of the vote); the run-off was not held
and SAVIMBI''s National Union for the Total
Independence of Angola (UNITA) repudiated the
results of the first election; the civil war resumed
Legislative branch: unicameral National Assembly
or Assembleia Nacional (220 seats; members elected
by proportional vote to serve four-year terms)
elections: last held 29-30 September 1 992 (next to be
held NA)
election results: percent of vote by party - MPLA 54%,
UNITA 34%, others 12%; seats by party - MPLA 129,
UNITA 70, PRS 6, FNLA 5, PLD 3, others 7
Judicial branch: Supreme Court or Tribunal da
Relacao, judges of the Supreme Court are appointed
by the president
Political parties and leaders: Liberal Democratic
Party or PLD [Analia de Victoria PEREIRA]; National
Front for the Liberation of Angola or FNLA [disputed
leadership: Lucas NGONDA, Holden ROBERTO];
National Union for the Total Independence of Angola
or UNITA [Jonas SAVIMBI], largest opposition party
engaged in years of armed resistance before joining
the current unity government in April 1997; Popular
Movement for the Liberation of Angola or MPLA [Jose
Eduardo DOS SANTOS] ruling party in power since
1975; Social Renewal Party or PRS [disputed
leadership: Eduardo KUANGANA, Antonio
MUACHICUNGO]
note: about a dozen minor parties participated in the
1992 elections but won few seats and have little
influence in the National Assembly
Political pressure groups and leaders; Front for
the Liberation of the Enclave of Cabinda or FLEC
[N''zita Henriques TIAGO; Antonio Bento BEMBE]
note: FLEC is waging a small-scale, highly
factionalized, armed struggle for the independence of
Cabinda Province
International organization participation; ACP,
AfDB, CCC, CEEAC, ECA, FAO, G-77, IBRD, ICAO,
ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, IMO,
Intelsat, Interpol, IOC, lOM, ITU, NAM, OAS
(observer), OAU, SADC, UN, UNCTAD, UNESCO,
UNIDO, UPU, WCL, WFTU, WHO, WlPO, WMO,
WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Antonio dos Santos
FRANCA "N''dalu"
chancery: 1615 M Street, NW, Suite 900,
Washington, DC 20036
fe/ep/?one;[1] (202) 785-1 156
FAX;[1] (202) 785-1258
consulate(s) general: New York
Diplomatic representation from the US:
chief of mission: Ambassador Joseph G. SULLIVAN
embassy: number 32 Rua Houari Boumedienne,
Miramar, Luanda
mailing address: international mail: Caixa Postal
6484, Luanda; pouch: American Embassy Luanda,
Department of State, Washington, DC 20521-2550
telephone: [244] (2) 345-481, 346-418
FAX; [244] (2) 346-924
Flag description; two equal horizontal bands of red
(top) and black with a centered yellow emblem
consisting of a five-pointed star within half a cogwheel
crossed by a machete (in the style of a hammer and
sickle)
I Economy
Economy - overview; Angola is an economy in
disarray because of a quarter century of nearly
continuous warfare. Despite its abundant natural
resources, output per capita is among the world''s
lowest. Subsistence agriculture provides the main
livelihood for 85% of the population. Oil production
and the supporting activities are vital to the economy,
contributing about 45% to GDP and 90% of exports.
Notwithstanding the signing of a peace accord in
November 1994, violence continues, millions of land
mines remain, and many farmers are reluotant to
return to their fields. As a result, much of the country''s
food must still be Imported. To take advantage of its
rich resources - gold, diamonds, extensive forests,
Atlantic fisheries, and large oil deposits - Angola will
need to implement the peace agreement and reform
government policies. Despite the increase in the pace
of civil warfare in late 1998, the economy grew by an
estimated 4% in 1999. The government introduced
new currency denominations in 1999, including a 1
and 5 kwanza note. Expanded oil production
brightens prospects for 2000, but internal strife
discourages investment outside of the petroleum
sector.
GDP: purchasing power parity - $1 1 .6 billion
(1999 est.)
GDP - real growth rate: 4% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,030
(1999 est.)
GDP ■ composition by sector;
agriculture: 13%
industry: 53%
services: 34% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 270% (1 999 est.)
Labor force: 5 million (1997 est.)
Labor force - by occupation: agriculture 85%,
industry and services 15% (1997 est.)
Unemployment rate: extensive unemployment and
underemployment affecting more than half the
population (1999 est.)
Budget:
revenues: $928 million
expenditures: $2.5 billion, including capital
expenditures of $963 million (1992 est.)
Industries; petroleum; diamonds, iron ore,
phosphates, feldspar, bauxite, uranium, and gold;
cement; basic metal products; fish processing; food
processing; brewing; tobacco products; sugar; textiles
industrial production growth rate: NA%
Electricity - production: 1.886 billion kWh (1998)
Electricity - production by source;
fossil fuel: 24.97%
hydro: 75.03%
nuclear: 0%
other; 0% (1998)
13
Angola (continued)
Electricity - consumption; 1 .754 billion kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: bananas, sugarcane,
coffee, sisal, corn, cotton, manioc (tapioca), tobacco,
vegetables, plantains; livestock; forest products; fish
Exports: $5 billion (f.o.b., 1999 est.)
Exports - commodities: crude oil 90%, diamonds,
refined petroleum products, gas, coffee, sisal, fish and
fish products, timber, cotton
Exports - partners: US 63%, Benelux 9%, China,
Chile, France (1998)
Imports: $3 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and electrical
equipment, vehicles and spare parts; medicines, food,
textiles, military goods
Imports - partners: Portugal 20%, US 17%, South
Africa 10%, Spain, Brazil, France (1998)
Debt - external: $1 0.5 billion (1 999 est.)
Economic aid - recipient: $493.1 million (1995)
Currency: 1 kwanza (NKz) = 100 Iwei
Exchange rates: kwanza (NKz) per US$1 - 577,304
(January 2000), 2,790,706 (1999), 392,824 (1998),
229,040 (1997), 128,029 (1996), 2,750 (1995); note -
beginning in June 1998, the official rate is determined
weekly in accordance with a crawling peg scheme
Fiscal year: calendar year','cfa4301b55dfb2980f4b45172b7cd806587dc88d4c910c8f82fe3263b5a0a3e7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd05ea3b81bd2c1a7dd42ab64dd388167e9045cc3702004b2fd7d682ad999c8c',2000,'AI','Anguilla','people-and-society',36,'Population: no indigenous inhabitants, but there are
seasonally staffed research stations
note: approximately 29 nations, all signatory to the
Antarctic Treaty, send personnel to perform seasonal
(summer) and year-round research on the continent
and in its surrounding oceans; the population of
persons doing and supporting science on the
continent and its nearby islands south of 60 degrees
south latitude (the region covered by the Antarctic
T reaty) varies from approximately 4,000 in summer to
1 ,000 in winter; in addition, approximately 1 ,000
personnel including ship''s crew and scientists doing
onboard research are present in the waters of the
treaty region; Summer (January) population - 3,687
total; Argentina 302, Australia 201 , Belgium 13, Brazil
80, Bulgaria 16, Chile 352, China 70, Finland 11,
France 100, Germany 51 , India 60, Italy 106, Japan
136, South Korea 14, Netherlands 10, NZ60, Norway
40, Peru 28, Poland 70, Russia 254, South Africa 80,
Spain 43, Sweden 20, UK 192, US 1,378 (1998-99);
Winter (July) population - 964 total; Argentina 165,
Australia 75, Brazil 12, Chile 129, China 33, France
33, Germany 9, India 25, Japan 40, South Korea 14,
NZ 10, Poland 20, Russia 102, South Africa 10, UK
39, US 248 (1998-99); year-round stations - 42 total;
Argentina 6, Australia 4, Brazil 1 , Chile 4, China 2,
Finland 1 , France 1 , Germany 1 , India 1 , Italy 1 , Japan
16
Antarctica (continued)
1, South Korea 1, NZ 1, Norway 1, Poland 1, Russia
6, South Africa 1 , Spain 1 , Ukraine 1 , UK 2, US 3,
Uruguay 1 (1 998-99); Summer-oniy stations - 32 total;
Argentina 3, Austraiia 4, Buigaria 1 , Chile 7, Germany
1, India 1, Japan 3, NZ 1, Peru 1, Russia 3, Sweden
2, UK 5 (1998-99); in addition, during the austral
summer some nations have numerous occupied
locations such as tent camps, summer-long
temporary facilities, and mobile traverses in support of
research (Juiy 2000 est.)
1^ Government
Country name:
conventional long form: none
conventional short form: Antarctica
Data code; AY
Government type; Antarctic Treaty Summary - the
Antarctic Treaty, signed on 1 December 1959 and
entered into force on 23 June 1961 , establishes the
legal framework for the management of Antarctica.
Administration is carried out through consuitative
member meetings - the 23rd Antarctic Treaty
Consuitative Meeting was in Peru in May 1 999. At the
end of 1 999, there were 44 treaty member nations: 27
consuitative and 17 acceding. Consuitative (voting)
members include the seven nations that ciaim
portions of Antarctica as nationai territory (some
claims overiap) and 20 nonciaimant nations. The US
and some other nations that have made no ciaims
have reserved the right to do so. The US does not
recognize the claims of others. The year in
parentheses indicates when an acceding nation was
voted to fuli consultative (voting) status, while no date
Indicates the country was an originai 1959 treaty
signatory. Claimant nations are - Argentina, Austraiia,
Chiie, France, New Zealand, Norway, and the UK.
Nonclaimant consultative nations are - Belgium, Brazil
(1983), Bulgaria (1998) China (1985), Ecuador
(1 990), Finiand (1989), Germany (1 981 ), India (1983),
Italy (1987), Japan, South Korea (1989), Netherlands
(1990), Peru (1989), Poland (1977), Russia, South
Africa, Spain (1988), Sweden (1988), Uruguay (1985),
and the US. Acceding (nonvoting) members, with year
of accession in parentheses, are - Austria (1987),
Canada (1988), Coiombia (1988), Cuba (1984),
Czech Republic (1993), Denmark (1965), Greece
(1987), Guatemaia (1991), Hungary (1984), North
Korea (1987), Papua New Guinea (1981), Romania
(1971), Siovakia (1993), Switzerland (1990), Turkey
(1 995), Ukraine (1 992), and Venezuela (1 999). Article
1 - area to be used for peaceful purposes only; military
activity, such as weapons testing, is prohibited, but
military personnel and equipment may be used for
scientific research or any other peaceful purpose;
Article 2 - freedom of scientific investigation and
cooperation shall continue; Article 3 - free exchange of
information and personnel in cooperation with the UN
and other international agencies; Article 4 - does not
recognize, dispute, or establish territorial claims and
no new claims shall be asserted while the treaty is in
force; Article 5 - prohibits nuclear explosions or
disposal of radioactive wastes; Article 6 - includes
under the treaty all land and ice shelves south of 60
degrees 00 minutes south; Article 7 - treaty-state
observers have free access, including aerial
obsen/ation, to any area and may inspect all stations,
installations, and equipment; advance notice of all
activities and of the introduction of military personnel
must be given; Article 8 - allows for jurisdiction over
observers and scientists by their own states; Article 9
- frequent consultative meetings take place among
member nations; Article 1 0 - treaty states will
discourage activities by any country in Antarctica that
are contrary to the treaty; Article 1 1 - disputes to be
settled peacefully by the parties concerned or,
ultimately, by the ICJ; Articles 12, 13, 14 - deal with
upholding, interpreting, and amending the treaty
among involved nations. Other agreements - some
200 recommendations adopted at treaty consultative
meetings and ratified by governments include -
Agreed Measures for the Conservation of Antarctic
Fauna and Flora (1964); Convention for the
Conservation of Antarctic Seals (1972); Convention
on the Conservation of Antarctic Marine Living
Resources (1980); a mineral resources agreement
was signed in 1988 but was subsequently rejected;
the Protocol on Environmental Protection to the
Antarctic Treaty was signed 4 October 1991 and
entered into force 14 January 1998; this agreement
provides for the protection of the Antarctic
environment through five specific annexes on marine
pollution, fauna, and flora, environmental impact
assessments, waste management, and protected
areas; it prohibits all activities relating to mineral
resources except scientific research.
Legal system: US law, including certain criminal
offenses by or against US nationals, such as murder,
may apply to areas not under jurisdiction of other
countries. Some US laws directly apply to Antarctica.
For example, the Antarctic Conservation Act, 16
U.S.C. section 2401 et seq., provides civil and criminal
penalties for the following activities, unless authorized
by regulation of statute: the taking of native mammals
or birds; the introduction of nonindigenous plants and
animals; entry into specially protected or scientific
areas; the discharge or disposal of pollutants; and the
importation into the US of certain items from
Antarctica. Violation of the Antarctic Conservation Act
carries penalties of up to $10,000 in fines and one
year in prison. The Departments of Treasury,
Commerce, Transportation, and Interior share
enforcement responsibilities. Public Law 95-541, the
US Antarctic Conservation Act of 1978, requires
expeditions from the US to Antarctica to notify, in
advance, the Office of Oceans and Polar Affairs,
Room 5801 , Department of State, Washington, DC
20520, which reports such plans to other nations as
required by the Antarctic Treaty. For more
information, contact Permit Office, Office of Polar
Programs, National Science Foundation, Arlington,
Virginia 22230; telephone: (703) 306-1031 , or see
their website at ww/w.nsf.gov.
I i c 0 n 0 m y
Economy - overview: No economic activity is
conducted at present, except for fishing off the coast
and small-scale tourism, both based abroad. Antarctic
fisheries in 1998-99 (1 July-30 June) reported landing
1 1 9,898 metric tons. Unregulated fishing landed five
to six times more than the regulated fishery, and
allegedly illegal fishing in antarctic waters in 1998
resulted in the seizure (by France and Australia) of at
least eight fishing ships. A total of 10,013 tourists
visited in the 1 998-99 summer, up from the 9,604 who
visited the previous year. Nearly all of them were
passengers on 16 commercial (nongovernmental)
ships and several yachts that made 1 1 6 trips during
the summer. Most tourist trips lasted approximately
two weeks.
I C 0 m m u nTi^ a 1 1 0 n s
Telephones - main lines in use: 0 (1997)
Telephones - mobile cellular: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM 2,
shortwave 1 (1998)
Radios; NA
Television broadcast stations: 1 (American
Forces Antarctic Network-McMurdo) (1999)
Televisions: several hundred at McMurdo Sound
Internet Service Providers (ISPs): NA
|"~ t r a n s p b r t a t i 0 n
Ports and harbors: McMurdo (77 51 S, 166 40 E),
Palmer (64 43 S, 64 03 W); government use only
except by permit (see Permit Office under "Legal
System"); offshore anchorage
Airports; 18
note: 27 stations, operated by 16 national
governments party to the Antarctic Treaty, have
landing facilities for either helicopters and/or
fixed-wing aircraft; commercial enterprises operate
two additional air facilities; helicopter pads are
available at 27 stations; runways at 15 locations are
gravel, sea-ice, blue-ice, or compacted snow suitable
for landing wheeled, fixed-wing aircraft; of these, 1 is
greater than 3 km in length, 6 are between 2 km and
3 km in length, 3 are between 1 km and 2 km in length,
3 are less than 1 km in length, and 2 are of unknown
length; snow surface skiways, limited to use by
ski-equipped, fixed-wing aircraft,are available at
another 1 5 locations; of these, 4 are greater than 3 km
in length, 3 are between 2 km and 3 km in length, 2 are
between 1 km and 2 km in length, 2 are less than 1 km
in length, and 4 are of unknown length; airports
generally subject to severe restrictions and limitations
resulting from extreme seasonal and geographic
conditions; airports do not meet ICAO standards;
advance approval from the respective governmental
or nongovernmental operating organization required
for landing (1999 est.)
17
Antarctica (continued)
Airports - with unpaved runways:
total: 18
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m; 5 (1 999 est.)
Heiiports: 1 (1999 est.)
M i i i t a r y
Military - note: the Antarctic Treaty prohibits any
measures of a military nature, such as the
establishment of military bases and fortifications, the
carrying out of military maneuvers, or the testing of
any type of weapon; it permits the use of military
personnel or equipment for scientific research or for
any other peaceful purposes','e1a9cb3675169ac2b71a2c33991ea51dee46504f221bf7fe5de4f4504df94555','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfaab1d88bc462420254f06c7efd82254d4745f3b7904ca864d90e1066823b23',2000,'AG','Antigua and Barbuda','people-and-society',39,'Population: 66,422 (July 2000 est.)
Age structure:
0-14 years: 28% (male 9,414; female 9,098)
15-64 years: 67% (male 22,199; female 22,341)
65 years and over: 5% (male 1 ,424; female 1 ,946)
(2000 est.)
Population growth rate: 0.73% (2000 est.)
Birth rate: 19.6 births/1 ,000 population (2000 est.)
Death rate: 5.99 deaths/1 ,000 population
(2000 est.)
Net migration rate: -6.32 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate: 23.05 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 70.46 years
rrra/e.- 68.19 years
female: 72.84 years (2000 est.)
Total fertility rate: 1 .92 children born/woman
(2000 est.)
Nationality:
noun: Antiguan(s), Barbudan(s)
adjective: Antiguan, Barbudan
Ethnic groups: black, British, Portuguese,
Lebanese, Syrian
Religions: Anglican (predominant), other Protestant,
some Roman Catholic
18
Antigua and Barbuda (continued)
Languages: English (official), local dialects
Literacy;
definition: age 1 5 and over has completed five or more
years of schooling
total population: 89%
male: 90%
fema/e; 88% (1960 est.)
f Government
Country name;
conventional long form: none
conventional short form: Antigua and Barbuda
Data code: AC
Government type: constitutional monarchy with
Westminster-style parliament
Capital: Saint John''s
Administrative divisions: 6 parishes and 2
dependencies*; Barbuda*, Redonda*, Saint George,
Saint John, Saint Mary, Saint Paul, Saint Peter, Saint
Philip
Independence: 1 November 1981 (from UK)
National holiday: Independence Day, 1 November
(1981)
Constitution: 1 November 1981
Legal system: based on English common law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH 1 1 (since 6 February
1952), represented by Governor General James B.
CARLISLE (since NA 1993)
head of government: Prime Minister Lester Bryant
BIRD (since 8 March 1994)
cabinet: Council of Ministers appointed by the
governor general on the advice of the prime minister
elections: none; the monarch is hereditary; governor
general chosen by the monarch on the advice of the
prime minister; prime minister appointed by the
governor general
Legislative branch: bicameral Parliament consists
of the Senate (17-member body appointed by the
governor general) and the House of Representatives
(17 seats; members are elected by proportional
representation to serve five-year terms)
elections: House of Representatives - last held 9
March 1999 (next to be held NA March 2004)
election results: percent of vote by party - NA; seats
by party - ALP 12, UPP 4, independent 1
Judicial branch: Eastern Caribbean Supreme Court
(based in Saint Lucia) (one judge of the Supreme
Court is a resident of the islands and presides over the
Court of Summary Jurisdiction)
Political parties and leaders; Antigua Caribbean
Liberation Movement or ACLM [leader NA]; Antigua
Labor Party or ALP [Lester Bryant BIRD]; Barbuda
People''s Movement or BPM [leader NA]; Progressive
Labor Movement or PLM [leader NA]; United National
Democratic Party or UNDP [leader NA]; United
Progressive Party or UPP [Baldwin SPENCER], a
coalition of three opposition political parties - UNDP,
ACLM, and PLM
Political pressure groups and leaders: Antigua
Trades and Labor Union or ATLU [William
ROBINSON]; People''s Democratic Movement or PDM
[Hugh MARSHALL]
International organization participation: ACP, C,
Caricom, CDB, ECLAC, FAO, G-77. IBRD, ICAO,
ICFTU, ICRM, IFAD, IFC, IFRCS, ILO, IMF, IMO,
Intelsat (nonsignatory user), Interpol, IOC, ITU, NAM
(observer), OAS, OECS, OPANAL, UN, UNCTAD,
UNESCO, UPU, WCL, WFTU, WHO, WMO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Lionel Alexander
HURST
chancery: 321 6 New Mexico Avenue NW,
Washington, DC 20016
fe/ep/)one;[1] (202) 362-5211
FAX; [1] (202) 362-5225
consulate(s) general: Miami
Diplomatic representation from the US: the US
does not have an embassy in Antigua and Barbuda
(embassy closed 30 June 1994); the US Ambassador
to Barbados is accredited to Antigua and Barbuda
Flag description: red, with an inverted isosceles
triangle based on the top edge of the flag; the triangle
contains three horizontal bands of black (top), light
blue, and white, with a yellow rising sun in the black
band
I Economy -
Economy ■ overview: Tourism continues to be the
dominant activity in the economy accounting directly
or indirectly for more than half of GDP, In 1 999 the
budding offshore financial sector was seriously hurt by
financial sanctions imposed by the US and UK as a
result of the loosening of its money-laundering
controls. The government has made efforts to comply
with international demands in order to get the
sanctions lifted. The dual island nation''s agricultural
production is mainly directed to the domestic market;
the sector is constrained by the limited water supply
and labor shortages that reflect the pull of higher
wages in tourism and construction. Manufacturing
comprises enclave-type assembly for export with
major products being bedding, handicrafts, and
electronic components. Prospects for economic
growth in the medium term will continue to depend on
income growth in the industrialized world, especially in
the US, which accounts for about one-third of all
tourist arrivals.
GDP: purchasing power parity - $524 million
(1999 est.)
GDP - real growth rate: 2.8% (1999 est.)
GDP - per capita: purchasing power parity - $8,200
(1999 est.)
GDP - composition by sector:
agriculture: 4-%
Industry: 12.5%
services: 83.5% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); 1 .6% (1 999 est.)
Labor force; 30,000
Labor force - by occupation; commerce and
services 82%, agriculture 11%, industry 7% (1983)
Unemployment rate: 7% (1999 est.)
Budget:
revenues; $122.6 million
expend/fures; $141.2 million, including capital
expenditures of $17.3 million (1997 est.)
Industries: tourism, construction, light
manufacturing (clothing, alcohol, household
appliances)
Industrial production growth rate: 6% (1997 est.)
Electricity - production; 90 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 84 million kWh (1998)
Electricity • exports: 0 kWh (1 998)
Electricity ■ imports: 0 kWh (1998)
Agriculture ■ products: cotton, fruits, vegetables,
bananas, coconuts, cucumbers, mangoes,
sugarcane; livestock
Exports: $38 million (1998)
Exports ■ commodities: petroleum products 48%,
manufactures 23%, food and live animals 4%,
machinery and transport equipment 17%
Exports ■ partners: OECS 26%, Barbados 15%,
Guyana 4%, Trinidad and Tobago 2%, US 0.3%
Imports: $330 million (1998)
Imports ■ commodities: food and live animals,
machinery and transport equipment, manufactures,
chemicals, oil
Imports - partners: US 27%, UK 1 6%, Canada 4%,
OECS 3%
Debt - external: $357 million (1 998)
Economic aid - recipient; $2.3 million (1995)
Currency: 1 East Caribbean dollar (EC$) = 100
cents
Exchange rates: East Caribbean dollars (EC$) per
US$1 - 2.7000 (fixed rate since 1976)
Fiscal year: 1 April - 31 March
I Communication s
Telephones - main lines in use: 20,000 (1994)
Telephones - mobile cellular; NA
Telephone system;
domestic: good automatic telephone system
international: 1 coaxial submarine cable; satellite
earth station - 1 1ntelsat (Atlantic Ocean); tropospheric
scatter to Saba (Netherlands Antilles) and','af1028b9add7dfe769a3e94a3270209d1493eb3cb256fb4da2849491651a05e3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('492dd848808539d7765f9fef738b925e5bd6d061e67a142ca8e5724571c43137',2000,'GP','Guadeloupe','people-and-society',40,'Radio broadcast stations: AM 4, FM 2, shortwave
0(1998)
19
Antigua and Barbuda (continued)
Radios: 36,000(1997)
Television broadcast stations: 2 (1997)
Televisions: 31,000(1997)
Internet Service Providers (ISPs): NA','9c38bc700cbf9c294873a41994cc58a26fd1bf7ff0d12c1f3dd8cb2643086630','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('182364edd17fd6e915608f0a7fdc7718366b6b9c49ed39ac62d3c5f73979f776',2000,'AQ','Antarctica','people-and-society',47,'Population: 69,539 (July 2000 est.)
Age structure:
0-14 years: 22% (male 7,770; female 7,194)
15-64 years: 69% (male 22,944; female 24,810)
65 years and over: 9% (male 2,831 ; female 3,990)
(2000 est.)
Population growth rate: 0.7% (2000 est.)
Birth rate: 13.1 births/1,000 population (2000 est.)
Death rate: 6.13 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.93 male(s)/female (2000 est.)
Infant mortality rate: 6.51 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.37 years
male: 75 years
female: 81 .9 years (2000 est.)
Total fertility rate: 1 .8 children born/woman
(2000 est.)
Nationality:
noun: Aruban(s)
adjective: Aruban
Ethnic groups: mixed white/Caribbean Amerindian
80%
Religions: Roman Catholic 82%, Protestant 8%,
Hindu, Muslim, Confucian, Jewish
Languages: Dutch (official), Papiamento (a Spanish,
Portuguese, Dutch, English dialect), English (widely
spoken), Spanish
Literacy:
definition: NA
total population: 97%
male: NA%i
female: NA%','faca284add3293c8c90d3dfcc1fc6a12e97606d77a91e4e03e7a82c011536ad3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cb2607ec113f9bd5f9b845a9bc525d734ccefce7e7e702c9fd2c011c70d4f43',2000,'AZ','Azerbaijan','people-and-society',56,'Population: 7,748,163 (July 2000 est.)
Age structure:
0-14 years: 30% (male 1 ,172,944; female 1 ,1 27,624)
15-64 years: 63% (male 2,388,737; female
2,525,797)
65 years and over: 7% (male 21 0,774; female
322,287) (2000 est.)
Population growth rate: 0.27% (2000 est.)
Birth rate: 1 8.08 births/1 ,000 population (2000 est.)
Death rate: 9.47 deaths/1 ,000 population
(2000 est.)
Net migration rate: -5.92 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.65 male(s)/temale
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 83.41 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 62.87 years
male: 58.51 years
female: 67.45 years (2000 est.)
Total fertility rate: 2.19 children born/woman
(2000 est.)
Nationality:
noun: Azerbaijani(s)
adjective: Azerbaijani
Ethnic groups: Azeri 90%, Dagestani 3.2%,
Russian 2.5%, Armenian 2%, other 2.3% (1998 est.)
note: almost all Armenians live in the separatist
Nagorno-Karabakh region
Religions: Muslim 93.4%, Russian Orthodox 2.5%,
Armenian Orthodox 2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan;
percentages for actual practicing adherents are much
lower
Languages: Azeri 89%, Russian 3%, Armenian 2%,
other 6% (1995 est.)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 96% (1 989 est.)','6625437e41905efa8c8ab7545903b673b1b82fc821d5f21f761e2a050530e29f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b4fe79b2985724bb873ad34deb44305771f33daa4ad017e32236f30d3a03cad',2000,'BD','Bangladesh','people-and-society',68,'Population: 274,540 (July 2000 est.)
Age structure:
0-14 years: 22% (male 30,687; female 30,1 72)
15-64 years: 69% (male 92,241 ; female 96,866)
65 years and over: 9% (male 9,506; female 15,068)
(2000 est.)
Population growth rate: 0.55% (2000 est.)
Birth rate: 14.45 births/1 ,000 population (2000 est.)
Death rate: 8.68 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.32 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.93 male(s)/temale (2000 est.)
infant mortality rate: 12.37 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 73 years
male: 70.43 years
female: 75.6 years (2000 est.)
Totai fertiiity rate: 1 .7 children born/woman
(2000 est.)
Nationality:
noun: Barbadian(s) or Bajan (colloquial)
adjective: Barbadian or Bajan (colloquial)
Ethnic groups: black 80%, white 4%, other 16%
Religions: Protestant 67% (Anglican 40%,
Pentecostal 8%, Methodist 7%, other 12%), Roman
Catholic 4%, none 17%, other 12%
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97.4%
male: 98%
female: 96.8% (1995 est.)','6bbc6aac6afa378488f0c7853facb09b18a73a504121e3a9d8c8ebdf0639c189','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2715172ca16a51fe1e0b6e01afb249ef29459a2cc7aafcde5550cd452d0c3a7',2000,'BY','Belarus','people-and-society',75,'Population: 10,366,719 (July 2000 est.)
Age structure:
0-14 years: 19% (male 982,959; female 942,062)
15-64 years: 68% (male 3,41 1 ,684; female
3,614,453)
65 years and over: 1 3% (male 466,929; female
948,632) (2000 est.)
Population growth rate: -0.17% (2000 est.)
Birth rate: 9.27 births/1 ,000 population (2000 est.)
Death rate: 13.96 deaths/1,000 population
(2000 est.)
Net migration rate: 3.01 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.49 male(s)/female
total population: 0.88 male(s)/female (2000 est.)
Infant mortality rate: 14.63 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 68 years
male: 61 .83 years
female: 74.48 years (2000 est.)
Total fertility rate: 1 .25 children born/woman
(2000 est.)
Nationality:
noun: Belarusian(s)
adjective: Belarusian
Ethnic groups: Byelorussian 77.9%, Russian
13.2%, Polish 4.1%, Ukrainian 2.9%, other 1.9%
Religions: Eastern Orthodox 80%, other (including
Roman Catholic, Protestant, Jewish, and Muslim)
20% (1997 est.)
Languages: Byelorussian, Russian, other
Literacy;
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
46
Belarus (continued)
r Government
Country name:
conventional long form: Republic of Belarus
conventional short form: Belarus
local long form: Respublika Byelarus''
local short form: r]one
former: Belorussian (Byelorussian) Soviet Socialist
Republic
Data code: BO
Government type: republic
Capital: Minsk
Administrative divisions: 6 voblastsi (singular -
voblasts'') and one municipality* (harady, singular -
horad); Brestskaya (Brest), Homyel''skaya (Homyel''),
Horad Minsk*, Hrodzyenskaya (Hrodna),
Mahilyowskaya (Mahilyow), Minskaya, Vitsyebskaya
(Vitsyebsk)
rrofe; voblasti have the administrative center name
following in parentheses
Independence: 25 August 1991 (Belarusian
Supreme Soviet declaration of independence from the
Soviet Union)
National holiday: Independence Day, 3 July (1 944);
note - represents Minsk liberation from German
occupation
Constitution: 30 March 1994; revised by national
referendum of 24 November 1996 giving the
presidency greatly expanded powers and became
effective 27 November 1996
Legal system: based on civil law system
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Aleksandr LUKASHENKO
(since 20 July 1994)
head of government: Prime Minister Sergey LING
(acting since 18 November 1996, confirmed 19
February 1997); First Deputy Prime Minister Vasiliy
DOLGOLEV (since 2 December 1998); Deputy Prime
Ministers Vladimir ZAMETALIN (since 15 July 1997),
Ural LATYPOV (since 30 December 1997), Gennadiy
NOVITSKIY (since 1 1 February 1997), Leonid KOZIK
(since 4 February 1997), Aleksandr POPKOV (since
10 November 1998)
cabinet: Council of Ministers
elections: president elected by popular vote for a
five-year term; election last held 24 June and 1 0 July
1994 (next to be held NA; according to the 1994
constitution, the next election should have been held
in 1999, however LUKASHENKO extended his term
to 2001 via the November 1996 referendum); prime
minister and deputy prime ministers appointed by the
president
election results: Aleksandr LUKASHENKO elected
president; percent of vote - Aleksandr LUKASHENKO
85%, Vyacheslav KEBICH 15%
note: first presidential elections took place in
June-July 1994
Legislative branch: bicameral Parliament or
Natsionalnoye Sobranie consists of the Council of the
Republic or Soviet Respubliki (64 seats; eight
appointed by the president and 56 indirectly elected
by deputies of local councils for four-year terms) and
the Chamber of Representatives or Palata
Pretsaviteley (110 seats; note - present members
came from the former Supreme Soviet which
LUKASHENKO disbanded in November 1996)
elections: last held May and November-December
1 995 (two rounds, each with a run-off; disbanded after
the November 1996 referendum; next to be held NA)
election results: after the November 1996
referendum, seats for the Chamber of
Representatives were filled by former Supreme Soviet
members as follows: PKB 24, Agrarian 14, Party of
Peoples Concord 5, LDPB 1, UPNAZ 1, Green World
Party 1, Belarusian Social Sports Party 1, Ecological
Party 1 , Republican Party of Labor and Justice 1 ,
independents 61; 58 of the 64 seats in the Council of
the Republic have been appointed/elected
Judicial branch: Supreme Court, judges are
appointed by the president; Constitutional Court, half
of the judges appointed by the president and half
appointed by the Chamber of Representatives
Political parties and leaders: Agrarian Party
[Aleksandr PAVLOV, acting chairman]; Belarusian
Communist Party or KPB [Viktor CHIKIN, chairman);
Belarusian Green Party or BPZ [Mikalay KARTASH,
chairman); Belarusian Labor Party or BPP [Aleksandr
BUKHVOSTOV, chairman); Belarusian Patriotic
Movement (Belarusian Patriotic Party) or BPR
[Anatoliy BARANKEVICH, chairman); Belarusian
Popular Front or BNF [Vintsuk VYACHORKA,
chairman); Belarusian Social-Democrat or SDBP
[Nikolay STATKEVICH, chairman); Belarusian
Social-Democratic Party Hramada [Stanislav
SHUSHKEVICH, chairman); Belarusian Social Sports
Party or BSSP [Aleksandr ALEKSANDROVICH,
chairman); Belarusian Socialist Party [Vyacheslav
KUZNETSOV); Civic Accord Bloc (United Civic Party)
or CAB [Stanislav BOGDANKEVICH, chairman);
Ecological Party or BEP [Liudmila YELIZAROVA,
chairperson); Liberal-Democratic Party or LDPB
[Sergei GAYDUKEVICH, chairman); Party of
All-Belarusian Unity and Concord or UPNAZ [Dmitriy
BULAKOV, chairman); Party of Communists
Belarusian or PKB [Sergei KALYAKIN, chairman);
Party of Popular Accord or PPA [Leanid SECHKA);
Republican Party of Labor and Justice or RPPS
[Anatoliy NETYLKIN, chairman); Women''s Party
Nadezhda [Valentina POLEVIKOVA, chairperson]
International organization participation: CCC,
CEI, CIS, EAPC, EBRD, ECE, IAEA, IBRD, ICAO,
ICRM, IFC, IFRCS, ILO, IMF, Inmarsat, Intelsat
(nonsignatory user), Interpol, IOC, lOM (observer),
ISO, ITU, NAM, OPCW, OSCE, PCA, PFP, UN,
UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO,
WlPO, WMO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Valery TSEPAKO
c/iance/y; 1619 New Hampshire Avenue NW,
Washington, DC 20009
telephone: [t] {202) m-im
FAX; [1] (202) 986-1805
consulate(s) general: New York
Diplomatic representation from the US:
chief of mission: Ambassador Daniel V.
SPECKHARD
embassy: Starovilenskaya #46-220002, Minsk
mailing address: use embassy street address
fe/ephorre; [375] (17) 231-5000
FAX; [375] (17) 234-7853
Flag description: red horizontal band (top) and
green horizontal band one-half the width of the red
band; a white vertical stripe on the hoist side bears the
Belarusian national ornament in red
Population: 249,183 (July 2000 est.)
Age structure:
0-14 years: 43% (male 54,009; female 51 ,945)
15-64 years: 54% (male 68,052; female 66,366)
65 years and over: 3% (male 4,298; female 4,51 3)
(2000 est.)
Population growth rate: 2.75% (2000 est.)
Birth rate: 32.29 births/1,000 population (2000 est.)
Death rate: 4.81 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1.03 male(s)/female (2000 est.)
Infant mortality rate: 25.97 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 70.91 years
maie: 68.66 years
female: 73.28 years (2000 est.)
Total fertility rate: 4.14 children born/woman
(2000 est.)
Nationality:
noun: Belizean(s)
adjective: Belizean
Ethnic groups: mestizo 44.1%, Creole 31%, Maya
9.2%, Garifuna 6.2%, other 9.5%
51
Bolizo (continued)
Religions: Roman Catholic 62%, Protestant 30%
(Anglican 12%, Methodist 6%, Mennonite 4%,
Seventh-Day Adventist 3%, Pentecostal 2%,
Jehovah''s Witnesses 1%, other 2%), none 2%, other
6% (1980)
Languages: English (official), Spanish, Mayan,
Garifuna (Carib), Creole
Literacy:
definition: age 1 5 and over can read and write
total population: 70.3%
male: 70.3%
female: 70.3% (1991 est.)
note: other sources list the literacy rate as high as
75%
I . Government
Country name:
conventional long form: none
conventional short form: Belize
former: British Honduras
Data code: BH
Government type: parliamentary democracy
Capital: Belmopan
Administrative divisions: 6 districts; Belize, Cayo,
Corozal, Orange Walk, Stann Creek, Toledo
Independence: 21 September 1981 (from UK)
National holiday: Independence Day, 21
September (1981)
Constitution: 21 September 1981
Legal system: English law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Sir Colville
YOUNG (since 17 November 1993)
head of government: Prime Minister Said MUSA
(since 27 August 1998); Deputy Prime Minister John
BRICENO (since 1 September 1998)
cabinet: Cabinet appointed by the governor general
on the advice of the prime minister
elections: none; the monarch is hereditary; governor
general appointed by the monarch; governor general
appoints the member of the House of Representatives
who is leader of the majority party to be prime minister
Legislative branch: bicameral National Assembly
consists of the Senate (eight members, five appointed
on the advice of the prime minister, two on the advice
of the leader of the opposition, and one by the
governor general; members are appointed for
five-year terms); and the House of Representatives
(29 seats; members are elected by direct popular vote
to serve five-year terms)
elections: House of Representatives - last held 27
August 1998 (next to be held NA August 2003)
election results: percent of vote by party - NA; seats
by party -PUP 26, UDP3
Judicial branch: Supreme Court, the chief justice is
appointed by the governor general on advice of the
prime minister
Political parties and leaders: People''s United
Party or PUP [Said MUSA); United Democratic Party
or UDP [Manuel ESQUIVEL, Dean BARROW]
Political pressure groups and leaders: Society for
the Promotion of Education and Research or SPEAR
[Assad SHOMAN]; United Worker''s Front
International organization participation: ACP, C,
Caricom, CDB, ECLAC, FAO, G-77, lADB, IBRD,
ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS, ILO,
IMF, IMO, Intelsat (nonsignatory user), Interpol, IOC,
lOM (observer), ITU, LAES, NAM, OAS, OPANAL,
UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO,
WMO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador James Schofield
MURPHY
chancery: 2535 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] (202) 332-9636
FAX; [1] (202) 332-6888
consulate(s) general: Los Angeles
Diplomatic representation from the US:
chief of mission: Ambassador Carolyn CURIEL
embassy: Gabourel Lane and Hutson Street, Belize
City
mailing address: P. 0. Box 286, Unit 7401 , APO AA
34025
telephone: [501] (2) 77161 through 77163
FAX; [501] (2) 30802
Flag description: blue with a narrow red stripe along
the top and the bottom edges; centered is a large
white disk bearing the coat of arms; the coat of arms
features a shield flanked by two workers in front of a
mahogany tree with the related motto SUB UMBRA
FLOREO (I Flourish in the Shade) on a scroll at the
bottom, all encircled by a green garland
Population: 62,997 (July 2000 est.)
Age structure:
0-14years:20% (male 6,107; female 6,212)
15-64 years: 70% (male 21,620; female 22,171)
65 years and over: 1 0% (male 2,972; female 3,91 5)
(2000 est.)
Population growth rate: 0.75% (2000 est.)
Birth rate: 1 2.24 births/1 ,000 population (2000 est.)
Death rate: 7.37 deaths/1 ,000 population
(2000 est.)
Net migration rate: 2.67 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 0.98 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 9.82 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 76.94 years
male: 74.89 years
female: 78.86 years (2000 est.)
Total fertility rate: 1 .68 children born/woman
(2000 est.)
Nationality;
noun: Bermudian(s)
adjective: Bermudian
Ethnic groups: black 58%, white 36%, other 6%
Religions: non-Anglican Protestant 39%, Anglican
27%, Roman Catholic 15%, other 19%
Languages: English (official), Portuguese
Literacy;
definition: age 1 5 and over can read and write
total population: 98%
male: 98%
fema/e;99% (1970 est.)
Population: 3,835,777
note: all data dealing with population are subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing (July 2000 est.)
Age structure:
0-14 years: 20% (male 401 ,554; female 379,303)
15-64 years: 71% (male 1,403,618; female
1,323,307)
65 years and over: 9% (male 1 38,173; female
189,822) (2000 est.)
Population growth rate: 3.1% (2000 est.)
Birth rate: 1 2.92 births/1 ,000 population (2000 est.)
Death rate: 7.87 deaths/1 ,000 population
(2000 est.)
Net migration rate: 25.92 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.00 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 1.03 male(s)/female (2000 est.)
Infant mortality rate: 25.17 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 71 .49 years
male: 68.78 years
female: 74.38 years (2000 est.)
Total fertility rate: 1.71 children born/woman
(2000 est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic groups: Serb 31%, Bosniak 44%, Croat
17%, Yugoslav 5.5%, other 2.5% (1991)
note: Bosniak has replaced muslim as an ethnic term
in part to avoid confusion with the religious term
Muslim - an adherent of Islam
Religions: Muslim 40%, Orthodox 31%, Roman
Catholic 15%, Protestant 4%, other 10%
Languages: Croatian, Serbian, Bosnian
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','7945f01c2b43a1982730fafc16d5098e10283f54669086b72774211acd01ee2f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6355c7834190f9bc9035eef2a1d082823e14e7ddb0209b375260968207a64c6e',2000,'ET','Ethiopia','people-and-society',99,'Population: 12,212,306
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 42% (male 2,610,009; female 2,505,932)
15-64 years: 55% (male 3,132,198; female
3,542,655)
65 years and over: 3% (male 1 73, 1 79; female
248,333) (2000 est.)
Population growth rate: 2.27% (2000 est.)
Birth rate: 33.48 births/1,000 population (2000 est.)
Death rate: 10.79 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.88 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 66.82 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
tofa/ population: 56.53 years
male: 54.44 years
female: 58.74 years (2000 est.)
Total fertility rate: 4.82 children born/woman
(2000 est.)
Nationality:
noun: Cambodian(s)
adjective: Cambodian
Ethnic groups: Khmer 90%, Vietnamese 5%,
Chinese 1%, other 4%
Religions: Theravada Buddhist 95%, other 5%
Languages: Khmer (official) 95%, French, English
Literacy:
definition: age 15 and over can read and write
total population: 35%
male: 48%
female: 22% (1990 est.)
r Government
Country name:
conventional long form: Kingdom of Cambodia
conventional short form: Cambodia
local long form: Preahreacheanachakr Kampuchea
local short form: Kampuchea
Data code: CB
Government type: multiparty liberal democracy
under a constitutional monarchy established in
September 1993
Capital: Phnom Penh
Administrative divisions: 20 provinces (khett,
singular and plural) and 3 municipalities* (krong,
singular and plural); Banteay Mean Cheay,
Batdambang, Kampong Cham, Kampong Chhnang,
Kampong Spoe, Kampong Thum, Kampot, Kandal,
Kaoh Kong, Keb*, Krachen, Mondol Kiri, Otdar Mean
Cheay, Phnum Penh*, Pouthisat, Preah Seihanu*
(Sihanoukville), Preah Vihear, Prey Veng, Rotanah
Kiri, Siam Reab, Stoeng Treng, Svay Rieng, Takev
note: there may be a new municipality called Pailin
Independence: 9 November 1953 (from France)
National holiday: Independence Day, 9 November
(1953)
Constitution: promulgated 21 September 1993
Legal system: primarily a civil law mixture of
French-influenced codes from the United Nations
Transitional Authority in Cambodia (UNTAC) period,
royal decrees, and acts of the legislature, with
influences of customary law and remnants of
communist legal theory; increasing influence of
common law in recent years
Suffrage: 18 years of age; universal
Executive branch:
chief of state: King Norodom SIHANOUK (reinstated
24 September 1993)
head of government: Prime Minister HUN SEN (since
30 November 1998)
cabinet: Council of Ministers appointed by the
monarch
84
Cambodia (continued)
elections: none; the monarch is chosen by a Royal
Throne Council; prime minister appointed by the
monarch after a vote of confidence by the National
Assembly
Legislative branch: bicameral consists of the
National Assembly (122 seats; members elected by
popular vote to serve five-year terms) and the Senate
(61 seats; two members appointed by the monarch,
two elected by the National Assembly, and 57 elected
by “functional constituencies”; members serve
five-year terms
elections: National Assembly - last held 26 July 1998
(next to be held NA 2003); Senate - last held 2 March
1999 (next to be held NA2004)
election results: National Assembly - percent of vote
by party - CPP 41%, FUNCINPEC 32%, SRP 14%,
other 13%; seats by party - CPP 64, FUNCINPEC 43,
SRP 1 5; Senate - percent of vote by party - NA; seats
by party - CPP 31 , FUNCINPEC 21 , SRP 7
Judicial branch; Supreme Council of the
Magistracy, provided for in the constitution, was
formed in December 1997; a Supreme Court and
lower courts exercise judicial authority
Political parties and leaders: Buddhist Liberal
Party or BLP [lENG MOULY]; Cambodian
Pracheachon Party or Cambodian People''s Party or
CPP [CHEA SIM]; Khmer Citizen Party or KCP
[NGUON SOEURj; National United Front for an
independent. Neutral, Peaceful, and Cooperative
Cambodia or FUNCINPEC [Prince NORODOM
RANARIDDH]; Sam Rangsi Party or SRP (formerly
Khmer Nation Party or KNP) [SAM RANGSI]
International organization participation; ACCT,
AsDB, ASEAN, CP, ESCAP, FAO, G-77, IAEA, IBRD,
ICAO, ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, IMO,
Intelsat (nonsignatory user), Interpol, IOC, ISO
(subscriber), ITU, NAM, OPCW, PCA, UN, UNCTAD,
UNESCO, UNIDO, UPU, WFTU, WHO. WlPO, WMO,
WToO, WTrO (applicant)
Diplomatic representation in the US:
cWef of m/ss/on; Ambassador Roland ENG
chancery: A500 16th Street NW, Washington, DC
20011
fe/ep/rorre; [1 1(202) 726-7742
FAX; [11(202)726-8381
Diplomatic representation from the US:
chief of mission: ^mbassador Kent M. WIEDEMANN
embassy: 27 EO Street 240, Phnom Penh
mailing address: Box P, APO AP 96546
telephone: [8551 (23) 216-436, 216-438
FAX;[8551 (23) 216-811
Flag description: three horizontal bands of blue
(top), red (double width), and blue with a white
three-towered temple representing Angkor Wat
outlined in black in the center of the red band
Economy - overview: After four years of solid
macroeconomic performance, Cambodia''s economy
slowed dramatically in 1997-98 due to the regional
economic crisis, civil violence, and political infighting.
Foreign investment and tourism fell off. Also, in 1998
the main harvest was hit by drought. But in 1999, the
first full year of peace in 30 years, progress was made
on economic reforms and growth resumed at 4%. The
long-term development of the economy after decades
of war remains a daunting challenge. The population
lacks education and productive skills, particularly in
the poverty-ridden countryside, which suffers from an
almost total lack of basic infrastructure. Recurring
political instability and corruption within government
discourage foreign investment and delay foreign aid.
On the brighter side, the government is addressing
these issues with assistance from bilateral and
multilateral donors. So long as political stability lasts,
the Cambodian economy is likely to grow at a
respectable pace.
GDP: purchasing power parity - $8.2 billion
(1999 est.)
GDP - real growth rate: 4% (1999 est.)
GDP - per capita: purchasing power parity - $71 0
(1999 est.)
GDP - composition by sector:
agriculture: 43%
industry: 20%
services: 37% (1 998 est.)
Population below poverty line: 36% (1997 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4.5% (1999 est.)
Labor force: 6 million (1998 est.)
Labor force - by occupation: agriculture 80%
(1999 est.)
Unemployment rate: 2.8% (1999 est.)
Budget:
revenues: $327 million
expenditures: $393 million, including capital
expenditures of $NA (1999 est.)
Industries; garments, rice milling, fishing, wood and
wood products, rubber, cement, gem mining, textiles
Industrial production growth rate: NA%
Electricity - production: 210 million kWh (1998)
Electricity - production by source;
fossil fuel: 59.52%
hydro; 40.48%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 195 million kWh (1998)
Electricity - exports; 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: rice, rubber, corn,
vegetables
Exports: $821 million (f.o.b., 1999 est.)
Exports - commodities: timber, garments, rubber,
rice, fish
Exports - partners; US, Singapore, Japan,
Thailand, Hong Kong, Indonesia, Malaysia, US
Imports: $1.2 billion (f.o.b., 1999 est.)
Imports - commodities: cigarettes, gold,
construction materials, petroleum products,
machinery, motor vehicles
Imports - partners: Singapore, Vietnam, Japan,
Australia, Hong Kong, Indonesia, Thailand
Debt - external: $829 million (1 999 est.)
Economic aid - recipient: $470 million pledged in
grants and concessional loans for 2000 by
international donors
Currency: 1 new riel (CR) = 100 sen
Exchange rates: new riels (CR) per US$1 - 3,786.0
(January 2000), 3,807.8 (1999), 3,744.4 (1998),
2,946.3 (1997), 2,624.1 (1996), 2,450.8 (1995)
Fiscal year: calendar year
I C 0 m munications
Telephones - main lines in use; 21,800(mid-1998)
Telephones - mobile cellular; 34,880 (1998)
Telephone system: adequate landline and/or
cellular sen/ice in Phnom Penh and other provincial
cities; rural areas have little telephone service
domestic: NA
international: adequate but expensive landline and
cellular service available to all countries from Phnom
Penh and major provincial cities; satellite earth station
- 1 1ntersputnik (Indian Ocean region)
Radio broadcast stations: AM 7, FM 3, shortwave
3(1999)
Radios; 1.34 million (1997)
Television broadcast stations; 5 (1999)
Televisions: 94,000(1997)
Internet Service Providers (ISPs): 2 (1999)
I? t r a n s p 0 r t a f ToT n
Railways;
total: 603 km
narrow gauge: 603 km 1 .000-m gauge
Highways;
total: 35,769 km
paved; 4,165 km
unpaved: 31 ,604 km (1 997 est.)
Waterways: 3,700 km navigable all year to craft
drawing 0.6 m or less; 282 km navigable to craft
drawing 1 .8 m or less
Ports and harbors: Kampong Saom
(Sihanoukville), Kampot, Krong Kaoh Kong, Phnom
Penh
Merchant marine;
total: 21 1 ships (1 ,000 GRT or over) totaling 953,105
GRT/1 ,345,766 DWT
ships by type: bulk 20, cargo 1 66, combination bulk 1 ,
container 5, livestock carrier 2, multi-functional large
load carrier 1 , passenger/cargo 1 , petroleum tanker 2,
refrigerated cargo 7, roll-on/roll-off 6 (1999 est.)
note: a flag of convenience registry; includes ships of
8 countries: Aruba 1 , Cyprus 7, Egypt 1 , South Korea
1 , Malta 1 , Panama 1 , Russia 5, Singapore 1
(1998 est.)
Airports: 19 (1999 est.)
Airports - with paved runways:
total: 6
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m; 2 (1999 est.)
85
Cambodia (continued)
Airports ■ with unpaved runways;
fofa/;13
1,524 to 2,437 m: 2
914 to 1,523 m:U (1999 est.)
Heliports: 3 (1999 est.)','4211c3510d32b6d799a87d617acc3dfe1721304dbf55095d0df392868564ba1f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f20d899b06ebc36e72ba7a2a5502b7f15b5044659ecec30cf8b9e2c3f6f3ce3e',2000,'CM','Cameroon','people-and-society',104,'Population: 15,421,937
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 43% (male 3,326,334; female 3,251 ,402)
15-64 years: 54% (male 4,181 ,038; female
4,153,680)
65 years and over: 3% (male 235,741 ; female
273,742) (2000 est.)
Population growth rate: 2.47% (2000 est.)
Birth rate: 36.6 births/1 ,000 population (2000 est.)
Death rate: 1 1 .89 deaths/1 ,000 population
(2000 est.)
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1 .01 male(s)/female (2000 est.)
Infant mortality rate: 70.87 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 54.82 years
male: 54.01 years
female: 55.64 years (2000 est.)
Total fertility rate: 4.88 children born/woman
(2000 est.)
Nationality;
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic groups: Cameroon Highlanders 31%,
Equatorial Bantu 19%, Kirdi 11%, Fulani 10%,
Northwestern Bantu 8%, Eastern Nigritic 7%, other
African 13%, non-African less than 1%
86
Camoroon (continued)
Religions: indigenous beliefs 40%, Christian 40%,
Muslim 20%
Languages: 24 major African language groups,
English (official), French (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 63A%
male: 75%
fema/e; 52.1% (1995 est.)
I G"o vis Fn ¥61^1
Country name:
conventional long form: Republic of Cameroon
conventional short form: Cameroon
former: French Cameroon
Data code: CM
Government type: unitary republic; multiparty
presidential regime (opposition parties legalized in
1990)
note: preponderance of power remains with the
president
Capital: Yaounde
Administrative divisions: 10 provinces;
Adamaoua, Centre, Est, Extreme-Nord, Littoral, Nord,
Nord-Ouest, Quest, Sud, Sud-Ouest
Independence: 1 January 1960 (from UN
trusteeship under French administration), 1 October
1 961 (for areas ruled by Britain under UN trusteeship)
National holiday: National Day, 20 May (1972)
Constitution: 20 May 1972 approved by
referendum; 2 June 1972 formally adopted
Legal system: based on French civil law system,
with common law influence; does not accept
compulsory ICJ jurisdiction
Suffrage: 21 years of age; universal
Executive branch:
chief of state: President Paul BIYA (since 6
November 1982)
head of government: Prime Minister Peter Mafany
MUSONGE (since 19 September 1996)
cabinet: Cabinet appointed by the president
elections: president elected by popular vote for a
seven-year term; election last held 12 October 1997
(next to be held NA October 2004); prime minister
appointed by the president
election results: President Paul BIYA reelected;
percent of vote - Paul BIYA 92.6%; note - supporters
of the opposition candidates boycotted the elections,
making a comparison of vote shares relatively
meaningless
Legislative branch: unicameral National Assembly
or Assemblee Nationale (180 seats; members are
elected by direct popular vote to serve five-year terms;
note - the president can either lengthen or shorten the
term of the legislature)
elections: last held 1 1 May 1997 (next to be held NA
2002)
election results: percent of vote by party - NA; seats
by party - RDCP 109, SDF 43, UNDP 13, UDC 5,
UPC-K 1 , MDR 1 , MLJC 1 ; note - results from 7
contested seats were cancelled by the Supreme Court
and have yet to be filled
note: the constitution calls for an upper chamber for
the legislature, to be called a Senate, but it has yet to
be established
Judicial branch: Supreme Court, judges are
appointed by the president
Political parties and leaders: Cameroonian
Democratic Union or UDC [Adamou NDAM NJOYAj;
Cameroon Liberation and Development Movement or
MLDC [Marcel YONDOj; Democratic Rally of the
Cameroon People or RDPC (the RDPC or its
predecessor parties have ruled since independence)
[Paul BIYA, president]; Movement for the Defense of
the Republic or MDR [Dakole DAISSALAj; Movement
for the Liberation of Cameroonian Youths or MUC
[leader NAj; National Union for Democracy and
Progress or UNDP [Maigari BELLO BOUBA,
chairman]; Social Democratic Front or SDF [John
FRU NDIj; Union of Cameroonian Populations or
UPC-K [Augustin Frederick KODOG]
Political pressure groups and leaders: Alliance
for Change or FAC [leader NA]; Cameroon
Anglophone Movement or CAM [Vishe FAI, secretary
general]; Southern Cameroon National Council
[Henry FOSSUNG]
International organization participation: ACCT,
ACP, AfDB, BDEAC, C, CCC, CEEAC, ECA, FAO,
FZ, G-19, G-77, IAEA, IBRD, ICAO, ICC, ICFTU,
ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO,
Inmarsat, Intelsat, Interpol, IOC, ITU, NAM, OAU,
OIC, OPCW, PCA, UDEAC, UN, UNCTAD, UNESCO,
UNIDO, UNITAR, UPU, WCL, WFTU, WHO, WlPO,
WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Jerome MENDOUGA
chancery: 2349 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [t] {202) 265-8790
FAX; [1] (202) 387-3826
Diplomatic representation from the US:
ch/ef of m/ss/on; Ambassador John M. YATES
embassy: Rue Nachtigal, Yaounde
mailing address: B. P. 817, Yaounde; pouch:
American Embassy, Department of State,
Washington, DC 20521-2520
fe/ephone; [237] 23-45-52
FAX; [237] 23-07-53
Flag description; three equal vertical bands of
green (hoist side), red, and yellow with a yellow
five-pointed star centered in the red band; uses the
popular pan-African colors of Ethiopia
I " E c oTi 0 my
Economy - overview: Because of its oil resources
and favorable agricultural conditions, Cameroon has
one of the best-endowed primary commodity
economies in sub-Saharan Africa. Still, it faces many
of the serious problems facing other underdeveloped
countries, such as a top-heavy civil service and a
generaliy unfavorable climate for business enterprise.
Since 1 990, the government has embarked on various
IMF and World Bank programs designed to spur
business investment, increase efficiency in
agriculture, improve trade, and recapitalize the
nation''s banks. The government, however, has failed
to press forward vigorously with these programs. The
latest enhanced structural adjustment agreement was
signed in October 1997; the parties hope this wiii
prove more successful, yet government
mismanagement and corruption remain problems.
Inflation has been brought back under control.
Progress toward privatization of remaining state
industry should support continued economic growth
in 2000.
GDP: purchasing power parity -$31.5 billion
(1999 est.)
GDP - real growth rate: 5.2% (1999 est.)
GDP - per capita; purchasing power parity - $2,000
(1999 est.)
GDP - composition by sector;
agriculture: 42%
industry: 22%
services: 36% (1 997 est.)
Population below poverty line: 40% (1984 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.1% (1999 est.)
Labor force: NA
Labor force ■ by occupation: agriculture 70%,
industry and commerce 13%, other 17%
Unemployment rate: 30% (1998 est.)
Budget;
revenues: $2.23 billion
expenditures: $2.23 billion, including capital
expenditures of $NA (FY96/97 est.)
Industries; petroleum production and refining, food
processing, light consumer goods, textiles, lumber
Industrial production growth rate; NA%
Electricity - production: 3.285 billion kWh (1998)
Electricity - production by source:
fossil fuel: 2.59% ■
hydro: 97.41%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 3.055 billion kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: coffee, cocoa, cotton,
rubber, bananas, oilseed, grains, root starches;
livestock; timber
Exports: $2 billion (f.o.b., 1999)
Exports - commodities: crude oil and petroleum
products, lumber, cocoa beans, aluminum, coffee,
cotton
Exports - partners: Italy 25%, Spain 20%, France
16%, Netherlands 7% (1997 est.)
Imports: $1.5 billion (f.o.b., 1999)
Imports - commodities: machines and electrical
equipment, transport equipment, fuel, food
Imports - partners: France 25%, Nigeria 8%, US
8%, Germany 6% (1997 est.)
Debt - external: $1 1 .5 billion (1 999 est.)
87
Cameroon (continued)
Economic aid - recipient: $606.1 million (1995);
note - France signed two loan agreements totaling
$55 million in September 1997, and the Paris Club
agreed in October 1997 to reduce the official debt by
50% and to reschedule it on favorable terms with a
consolidation of payments due through 2000
Currency: 1 CommunauteFinanciereAfricaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiers Africaine
francs (CFAF) per US$1 - 647.25 (January 2000),
615.70 (1999), 589.95 (1998), 583.67 (1997), 511.55
(1996), 499.15 (1995)
note: since 1 January 1999, the CFAF is pegged to
the euro at a rate of 655.957 CFA francs per euro
Fiscal year: 1 July - 30 June
I Communications
Telephones ■ main lines in use: 60,000 (1995)
Telephones - mobile cellular: 2,800 (1995)
Telephone system: available only to business and','856cf9f7f8fdfd5dccaf93915bd3c0446e3580a212f0be6698d20cfeb5cf1b7f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62ab4f6ce2b35260e6144bb8671225b8d828a24a88616a3b25dfdfd57d878be5',2000,'HN','Honduras','people-and-society',113,'Population: 34,763 (July 2000 est.)
Age structure:
0-14 years: 22.36% (male 3,769; female 4,005)
15-64 years: 69.84% (male 1 1 ,864; female 12,416)
65 years and over: 7.79% (male 1 ,241 ; female 1 ,468)
(2000 est.)
Population growth rate: 2.22% (2000 est.)
Birth rate: 14.21 births/1,000 population (2000 est.)
Death rate: 5.09 deaths/1 ,000 population
(2000 est.)
Net migration rate: 13.12 migrant(s)/1 ,000
population (2000 est.)
note: major destination for Cubans trying to migrate to
the US
Sex ratio;
at birth: 0.S6 male(s)/female
under 15 years: 0.94 male(s)/female
15-64 years: 0.96 mal6(s)/female
65 years and over: 0.85 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 10.44 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.88 years
male: 76.1 years
female: 81 .27 years (2000 est.)
Total fertility rate: 2.05 children born/woman
(2000 est.)
Nationality:
noun: Caymanian(s)
adjective: Caymanian
Ethnic groups: mixed 40%, white 20%, black 20%,
expatriates of various ethnic groups 20%
Religions: United Church (Presbyterian and
Congregational), Anglican, Baptist, Roman Catholic.
Church of God, other Protestant
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 96%
male: 98%
female: 96% (1970 est.)','85141761c040cfb02ea44918db42a8cdb5b7a48a81898e54e89ba4561e63787e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('287f7cf9b7acd710e815daf037b15709ef542ea7e3ffb30b17b661fdce0fd0bb',2000,'AU','Australia','people-and-society',122,'Population: uninhabited (July 2000 est.)
m
Clipperton Island (continued)
Population: 880 (July 2000 est.)
Population growth rate: 1 .15% (2000 est.)
Nationality:
noun: none
adjective: none
Ethnic groups: Italians, Swiss, other
Religions: Roman Catholic
Languages: Italian, Latin, various other languages
Literacy:
definition: NA
total population: 100%
male: NA%
female: NA%
Population: 7,1 16,302 (July 2000 est.)
Age structure:
0-14 years: 18% (male 676,756; female 602,434)
15-64 years: 71% (male 2,520,473; female
2,563,355)
65 years and over: 11% (male 342,942; female
410,342) (2000 est.)
Population growth rate: 1.35% (2000 est.)
Birth rate: 1 1 .29 births/1 ,000 population (2000 est.)
Death rate: 5.93 deaths/1 ,000 population
(2000 est.)
Net migration rate: 8.12 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1.12 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate: 5.93 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 79.54 years
male: 76.85 years
female: 82.41 years (2000 est.)
Total fertility rate: 1 .27 children born/woman
(2000 est.)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, other 5%
Religions: eclectic mixture of local religions 90%,
Christian 10%
Languages: Chinese (Cantonese), English; both are
official
Literacy;
definition: age 15 and over has ever attended school
total population: 92.2%
male: 96%
female: 88.2% (1996 est.)','7971cb96d1e9790318d337cdb68f5490b42385358d5ce04124b06abbb55f4be1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f35daa04a319dcd5deea01e5cfd3d1d1a80d8f78de7667bbcc507f808c9be67d',2000,'CG','Congo','people-and-society',145,'Population: 2,830,961
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 42% (male 605,546; female 596,971 )
15-64 years: 54% (male 748,217; female 785,278)
65 years and over: 4% (male 38,170; female 56,779)
(2000 est.)
Population growth rate: 2.23% (2000 est.)
Birth rate: 38.61 births/1,000 population (2000 est.)
Death rate: 1 6.35 deaths/1 ,000 population (2000
est.)
Net migration rate: 0 migrant(s)/1,000 population
(2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate: 101 .55 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 47.43 years
male: 44.49 years
female: 50.47 years (2000 est.)
Total fertility rate: 5.06 children born/woman
(2000 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: Kongo 48%, Sangha 20%, M''Bochi
12%, Teke 17%, Europeans NA%; note - Europeans
estimated at 8,500, mostly French, before the 1997
civil war; may be half of that in 1998, following the
widespread destruction of foreign businesses in 1997
Religions: Christian 50%, animist 48%, Muslim 2%
Languages: French (official), Lingala and
Monokutuba (lingua franca trade languages), many
local languages and dialects (of which Kikongo has
the most users)
Literacy:
definition: age 15 and over can read and write
totai population: 74.9%
male: 83.1%
female: 67.2% {19% est)','7486984c3645aa1ab44d57be80a9ff60d1a5817b2a1c943da7b0317418658f3d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ead45da52cb37d14c7945af19344487c72c02d99789acc09a92663e633a15cb7',2000,'CK','Cook Islands','people-and-society',152,'Population: 20,407 (July 2000 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1 .6% (2000 est.)
Birth rate: 22.18 births/1 ,000 population (2000 est.)
Death rate: 5.2 deaths/1 ,000 population (2000 est.)
Net migration rate: -0.99 migrant(s)/1 ,000
population (2000 est.)
Infant mortality rate: 24.7 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 71 .1 4 years
male: 69.2 years
female: 73.1 years (2000 est.)
Total fertility rate: 3.14 children born/woman (2000
est.)
Nationality:
noun: Cook Islander(s)
adjective: Cook Islander
Ethnic groups: Polynesian (full blood) 81 .3%,
Polynesian and European 7.7%, Polynesian and
non-European 7.7%, European 2.4%, other 0.9%
Religions: Christian (majority of populace are
members of the Cook Islands Christian Church)
Languages: English (official), Maori
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
Population: no indigenous inhabitants
note: there is a staff of three to four at the
meteorological station (July 2000 est.)
Population; 3,710,558 (July 2000 est.)
Age structure;
0-14 years: 32% (male 609,051 ; female 581 ,302)
15-64 years: 63% (male 1 ,177,262; female
1,150,673)
65 years and over: 5% (male 89,541 ; female
102,729) (2000 est.)
Population growth rate; 1.69% (2000 est.)
Birth rate; 20.69 births/1 ,000 population (2000 est.)
Death rate; 4.31 deaths/1 ,000 population (2000 est.)
Net migration rate; 0.54 migrant(s)/1,000
population (2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 1 .02 male(s)/female (2000 est.)
Infant mortality rate; 1 1 .49 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 75.82 years
male: 73.3 years
female: 78.47 years (2000 est.)
Total fertility rate; 2.52 children born/woman (2000
est.)
Nationality;
noun: Costa Rican(s)
adjective: Costa Rican
Ethnic groups; white (including mestizo) 94%, black
3%, Amerindian 1%, Chinese 1%, other 1%
Religions; Roman Catholic 85%, Evangelical
Protestant, approximately 14%, other less than 1%
Languages; Spanish (official), English spoken
around Puerto Limon
Literacy;
definition: age 1 5 and over can read and write
total population: 94.8%
male: 94.7%
fema/e; 95% (1995 est.)
I Government
Country name;
conventional long form: Republic of Costa Rica
conventional short form: Costa Rica
local long form: Republica de Costa Rica
local short form: Costa Rica
Data code; CS
Government type; democratic republic
Capital; San Jose
Administrative divisions; 7 provinces (provincias,
singular - provincia); Alajuela, Cartage, Guanacaste,
Heredia, Limon, Puntarenas, San Jose
Independence; 15 September 1821 (from Spain)
National holiday; Independence Day, 15
September (1821)
Constitution; 7 November 1949
Legal system; based on Spanish civil law system;
judicial review of legislative acts in the Supreme
Court; has not accepted compulsory ICJ jurisdiction
Suffrage; 1 8 years of age; universal and compulsory
Executive branch;
chief of state: President Miguel Angel RODRIGUEZ
(since 8 May 1998); First Vice President Astrid
FISCHEL Volio (since 8 May 1998), Second Vice
President Elizabeth ODIO Benito (since 8 May 1998);
note - president is both the chief of state and head of
Population: uninhabited
note: Millersville settlement on western side of island
occasionally used as a weather station from 1 935 until
World War II, when it was abandoned; reoccupied in
1957 during the International Geophysical Year by
scientists who left in 1958; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; visited annually by US Fish and Wildlife
Senrice (July 2000 est.)
Population; 91 ,985 (July 2000 est.)
Age structure;
0-14 years: 40.65% (male 19,027; female 18,551)
15-64 years: 56% (male 25,41 1 ; female 26,097)
65 years and over: 3.1 5% (male 1 ,239; female 1 ,660)
(2000 est.)
Population growth rate; 2.34% (2000 est.)
Birth rate; 32.43 birlhs/1 ,000 population (2000 est.)
Death rate; 9.01 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate; 55.36 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 59.78 years
male: 56.89 years
female: 62.82 years (2000 est.)
Total fertility rate; 4.4 children born/woman
(2000 est.)
Nationality;
noun: l-Kiribati (singular and plural)
adjective: l-Kiribati
Ethnic groups; Micronesian
Religions; Roman Catholic 53%, Protestant
(Congregational) 41%, Seventh-Day Adventist,
Baha''i, Church of God, Mormon 6% (1985 est.)
Languages; English (official), Gilbertese
Literacy;
definition: NA
total population: NA%
male: NA%
female: NA%','a0dcd42622d6d29248d5b9eedc804dee74bdbc96ad271b64e7c47d3517669748','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec112c682be43e88b916d4169387d2ce4fcf493a5875f2645c8da38d44bbb166',2000,'CU','Cuba','people-and-society',165,'Population: 1 1 ,141 ,997 (July 2000 est.)
Age structure:
0-14 years: 21% (male 1,221 ,602; female 1 ,157,846)
15-64 years: 69% (male 3,849,135; female
3,829,599)
65 years and over: 1 0% (male 503,71 1 ; female
580,104) (2000 est.)
Population growth rate: 0.39% (2000 est.)
Birth rate: 12.68 births/1 ,000 population (2000 est.)
Death rate: 7.31 deaths/1 ,000 population
(2000 est.)
Net migration rate: -1.52 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 1 male(s)/female (2000 est.)
Infant mortality rate: 7.51 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 76.21 years
male: 73.84 years
female: 78.73 years (2000 est.)
Total fertility rate: 1 .6 children born/woman
(2000 est.)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic groups: mulatto 51 %, white 37%, black 11%,
Chinese 1%
Religions: nominally 85% Roman Catholic prior to
CASTRO assuming power; Protestants, Jehovah''s
Witnesses, Jews, and Santeria are also represented
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 95.7%
male: 96.2%
female: 95.3% (1995 est.)
People - note: illicit migration is a continuing
problem; Cubans attempt to depart the island and
enter the US using homemade rafts, alien smugglers,
or falsified visas; some 3,800 Cubans took to the
Florida Straits in 1999; the US Coast Guard
interdicted about 40% of these migrants
Population: 10,272,179 (July 2000 est.)
Age structure:
0-14 years; 16% (male 866,754; female 823,795)
15-64 years: 70% (male 3,579,454; female
3,577,919)
65 years and over: 14% (male 547,462; female
876,795) (2000 est.)
Population growth rate: -0.08% (2000 est.)
Birth rate: 9.1 births/1,000 population (2000 est.)
Death rate: 10.87 deaths/1,000 population
(2000 est.)
Net migration rate: 0.95 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 5.63 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 74.51 years
male: 71 .01 years
female: 78.22 years (2000 est.)
Total fertility rate: 1 .18 children born/woman
(2000 est.)
Nationality:
noun: Czech(s)
adjective: Czech
Ethnic groups: Czech 81.2%, Moravian 13.2%,
Slovak 3.1%, Polish 0.6%, German 0.5%, Silesian
0.4%, Roma 0.3%, Hungarian 0.2%, other 0.5%
(March 1991)
Religions: atheist 39.8%, Roman Catholic 39.2%,
Protestant 4.6%, Orthodox 3%, other 13.4%
Languages: Czech
Literacy:
definition: NA
total population: 99.9% (1999 est.)
male: NA%
female: NA%
Population: 451 ,442 (July 2000 est.)
Age structure:
0-14 years: A3% (male 96,482; female 96,025)
15-64 years: 55% (male 130,264; female 1 1 6,270)
65 years and over: 2% (male 6,426; female 5,975)
(2000 est.)
Population growth rate: 1.45% (2000 est.)
Birth rate: 40.98 births/1,000 population (2000 est.)
Death rate: 14.87 deaths/1,000 population
(2000 est.)
Net migration rate: -1 1 .63 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .12 male(s)/female
65 years and over: 1 .08 male(s)/female
total population: 1 .07 male(s)/female (2000 est.)
Infant mortality rate: 1 03.32 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 50.82 years
male: 49.01 years
female: 52.68 years (2000 est.)
Total fertility rate: 5.8 children born/woman
(2000 est.)
Nationality:
noun: D]iboutian(s)
adjective: Djiboutian
Ethnic groups: Somali 60%, Afar 35%, French,
Arab, Ethiopian, and Italian 5%
Religions: Muslim 94%, Christian 6%
Languages: French (official), Arabic (official),
Somali, Afar
Literacy;
definition: age 15 and over can read and write
total population: 46.2%
male: 60.3%
female: 32.7% (1995 est.)','819d9dfa04a5caed4fa4cc74abbf8c5ba707cc050b57cdb02858d23dee084fb5','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27f2ac3f425f5eea9ff2f767adbcd1fa5785a978c2a14263ec0061346f290bc0',2000,'PE','Peru','people-and-society',177,'Land boundaries:
total: 545 km
border countries: Guatemala 203 km, Honduras 342
km
Coastline: 307 km
Maritime claims;
territorial sea: 200 nm
Climate: tropical; rainy season (May to October); dry
season (November to April); tropical on coast;
temperate in uplands
Terrain: mostly mountains with narrow coastal belt
and central plateau
Elevation extremes;
lowest point: Pacific Ocean 0 m
Population: 6,122,515 (July 2000 est.)
Age structure;
0-14 years: 38% (male 1 ,186,328; female 1 ,141 ,245)
15-64 years: 57% (male 1 ,652,083; female
1,833,998)
65 years and over: 5% (male 139,919; female
168,942) (2000 est.)
Population growth rate: 1 .87% (2000 est.)
Birth rate: 29.02 births/1 ,000 population (2000 est.)
Death rate: 6.27 deaths/1 ,000 population
(2000 est.)
Net migration rate: -4.02 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
highest point: Cerro El Pital 2,730 m
Natural resources: hydropower, geothermal power,
petroleum, arable land
Land use;
arable land: 27%
permanent crops: 8%
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
150
El Salvador (continued)
Infant mortality rate: 29.22 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 69.74 years
male: 66.14 years
female: 73.52 years (2000 est.)
Total fertility rate: 3.38 children born/woman
(2000 est.)
Nationality:
noun: Salvadoran(s)
adjective: Salvadoran
Ethnic groups: mestizo 90%, Amerindian 1%, white
9%
Religions: Roman Catholic 86%
note; there is extensive activity by Protestant groups
throughout the country; by the end of 1 992, there were
an estimated 1 million Protestant evangelicals in El
Salvador
Languages: Spanish, Nahua (among some
Amerindians)
Literacy:
definition: age 10 and over can read and write
total population: 71 .5%
male: 73.5%
fema/e; 69.8% (1995 est.)
I Government
Country name:
conventional long form: Republic of El Salvador
conventional short form: El Salvador
local long form: Republica de El Salvador
local short form: El Salvador
Data code: ES
Government type: republic
Capital: San Salvador
Administrative divisions: 14 departments
(departamentos, singular - departamento);
Ahuachapan, Cabanas, Chalatenango, Cuscatlan, La
Libertad, La Paz, La Union, Morazan, San Miguel,
San Salvador, Santa Ana, San Vicente, Sonsonate,
Usulutan
Independence: 15 September 1821 (from Spain)
National holiday: Independence Day, 15
September (1821)
Constitution: 23 December 1983
Legal system: based on civil and Roman law, with _
traces of common law; judicial review of legislative
acts in the Supreme Court; accepts compulsory ICJ
jurisdiction, with resen/ations
note: Legislative Assembly passed landmark judicial
reforms in 1996
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Francisco FLORES Perez
(since 1 June 1999); Vice President Carlos
QUINTANILLA Schmidt (since 1 June 1999); note -
the president is both the chief of state and head of','250f048a090340ab4e2f20e0a3410cf70069eb7f3756be00fe053fdd2751b47a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6716681efb709de95fbcd1f1fa988b7fba299a9fb4a8ea236f8cbe54bce7e19',2000,'GN','Guinea','people-and-society',186,'Population: no indigenous inhabitants
note: there is a small French military garrison (July
2000 est.)','4adf9c4ee3fe846cfcdb73e3687ef17ee859dffe5a6e56ed84748e3e0d0d1f6d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('022dd0071b54db19914f8f3cc2e29bfee45ac1d4a37bd2522e90df0b6ac17ea7',2000,'JE','Jersey','people-and-society',192,'Population: 832,494 (July 2000 est.)
Age structure:
0-14years:mo (male 141,779; female 136,212)
15-64 years: 63% (male 263,127; female 262,686)
65 years and over: 4% (male 1 3,405; female 1 5,285)
(2000 est.)
Population growth rate: 1 .41% (2000 est.)
Birth rate: 23.48 births/1,000 population (2000 est.)
Death rate: 5.78 deaths/1,000 population
(2000 est.)
Net migration rate: -3.6 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1.01 male(s)/female (2000 est.)
Infant mortality rate: 14.45 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 67.94 years
male: 65.54 years
female: 70.45 years (2000 est.)
Total fertility rate: 2.89 children born/woman
(2000 est.)
Nationality:
noun: Fijian(s)
adjective: Fijian
Ethnic groups: Fijian 51% (predominantly
Melanesian with a Polynesian admixture), Indian
44%, European, other Pacific Islanders, overseas
Chinese, and other 5% (1998 est.)
Religions: Christian 52% (Methodist 37%, Roman
Catholic 9%), Hindu 38%, Muslim 8%, other 2%
note: Fijians are mainly Christian, Indians are Hindu,
and there is a Muslim minority (1986)
Languages: English (official), Fijian, Hindustani
Literacy:
definition: age 15 and over can read and write
total population: 91.0%
male: 93.8%
female: 89.3% (1995 est.)
Population; 5,167,486 (July 2000 est.)
Age structure;
0-14 years: 18% (male 478,497; female 459,646)
15-64 years: 67% (male 1 ,747,738; female
1,712,058)
168
Finland (continued)
65 years and over: 15% (male 295,177; female
474,370) (2000 est.)
Population growth rate: 0.17% (2000 est.)
Birth rate: 10.8 births/1 ,000 population (2000 est.)
Death rate: 9.73 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0.58 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: t.OA male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over. 0.62 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 3.82 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77. 41 years
male: 73.74 years
female: 81 .2 years (2000 est.)
Total fertility rate: 1 .7 children born/woman
(2000 est.)
Nationality:
noun: Finn(s)
adjective: Finnish
Ethnic groups: Finn 93%, Swede 6%, Lapp 0.1 1 %,
Roma 0.12%, Tatar 0.02%
Religions: Evangelical Lutheran 89%, Greek
Orthodox 1%, none 9%, other 1%
Languages: Finnish 93.4% (official), Swedish 5.9%
(official), small Lapp- and Russian-speaking
minorities
Literacy:
definition: age 15 and over can read and write
total population: 100% (1980 est.)
male: NA%
female: NA%
I Government
Country name:
conventional long form: Republic of Finland
conventional short form: Finland
local long form: Suomen Tasavalta
local short form: Suomi
Data code: FI
Government type: republic
Capital: Helsinki
Administrative divisions: 6 provinces (laanit,
singular - laani); Aland, Etela-Suomen Laani,
Ita-Suomen Laani, Lansi-Suomen Laani, Lappi, Oulun
Laani
Independence: 6 December 1917 (from Russia)
National holiday: Independence Day, 6 December
(1917)
Constitution: 17 July 1919
Legal system: civil law system based on Swedish
law; Supreme Court may request legislation
interpreting or modifying laws; accepts compulsory
ICJ jurisdiction, with reservations
Suffrage: 18 years of age; universai
Executive branch:
chief of state: President Tarja HALONEN (since 1
March 2000)
head of government: Prime Minister Paavo
LIPPONEN (since 13 April 1995) and Deputy Prime
Minister Saul! NIINISTO (since 13 April 1995)
cabinet: Council of State or Valtioneuvosto appointed
by the president, responsible to Parliament
elections: president elected by popular vote for a
six-year term; election last held 6 February 2000 (next
to be held NA February 2006); prime minister and
deputy prime minister appointed from the majority
party by the president after parliamentary elections
election results: Tarja HALONEN elected president;
percent of vote - Tarja HALONEN (SDP) 51 .6%, Esco
AHO (Kesk) 48.4%
note: government coalition - SFP, Kok, Leftist Alliance
(People''s Democratic Union and Democratic
Alternative), SFP, and Green Union
Legislative branch: unicameral Parliament or
Eduskunta (200 seats; members are elected by
popular vote on a proportional basis to serve four-year
terms)
elections: last held 21 March 1 999 (next to be held NA
March 2003)
election results: percent of vote by party - SDP
22.9%, Kesk 22.5%, Kok 21.0%, Leftist Alliance
(Communist) 10.9%, SFP 5.1%, Green Union 7.2%,
SKL 4.2%; seats by party - SDP 51 , Kesk 48, Kok 46,
Leftist Alliance (Communist) 20, SFP 1 1 , Green Union
11, SKL 10, others
Judicial branch: Supreme Court or KorkeinOikeus,
judges appointed by the president
Political parties and leaders: Center Party or Kesk
[Esko AHOj; Ecological Party or EPV [Eugen
PARKATTIj; Finnish Christian Union or SKL [C. P.
Bjarne KALLISj; Green Union [Satu HASSI); Leftist
Alliance (Communist) composed of People''s
Democratic League and Democratic Alternative
[Claes ANDERSSON]; Liberal People''s Party or LKP
[Pekka RYTILAj; National Coalition (conservative)
Party or Kok [Sauli NIINISTO]; Rural Party or SMP
[Raimo VISTBACKAj; Social Democratic Party or
SDP [Paavo LIPPONEN]; Swedish People''s Party or
SFP [(Johan) Ole NORRBACK]; Young Finns [Risto
PENTTILA]
Political pressure groups and leaders:
Communist Workers Party [Timo LAHDENMAKI];
Constitutional Rightist Party; Finnish Communist
Party-Unity [Yrjo HAKANEN]; Finnish Pensioners Party
International organization participation: AfDB,
AsDB; Australia Group, BIS, CBSS, CCC, CE, CERN,
EAPC, EBRD, ECE, EIB, EMU, ESA, EU, FAO, G- 9,
lADB, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IDA,
lEA, IFAD, IFC, IFRCS, IHO, iLO, IMF, IMO, Inmarsat,
Intelsat, Interpol, IOC, lOM, ISO, ITU, NAM (guest),
NC, NEA, NIB, NSG, OAS (observer), OECD, OPCW,
OSCE, PCA, PFP, UN, UNCTAD, UNESCO,
UNFICYP, UNHCR, UNIDO, UNIFIL, UNIKOM,
UNMIBH, UNMIK, UNMOGIP, UNMOP, UNTSO,
UPU, WEU (Observer), WFTU, WHO, WlPO, WMO,
WToO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Jaakko Tapani
LAAJAVA
chancery: 3301 Massachusetts Avenue NW,
Washington, DC 20008
fe/ep/rorre; [1] (202) 298-5800
FAX; [1] (202) 298-6030
consulate(s) general: Los Angeles and New York
Diplomatic representation from the US:
chief of mission: ^mbassador Eric EDELMAN
embassy: Itainen Puistotie 14A, FIN-00140, Helsinki
mailing address: APO AE 09723
telephone: [358] (9)171931
FAX; [358] (9) 174681
Flag description: white with a blue cross that
extends to the edges of the flag; the vertical part of the
cross is shifted to the hoist side in the style of the
Dannebrog (Danish flag)
|r - """E c 0 h 0 m y
Economy - overview: Finland has a highly
industrialized, largely free-market economy, with per
capita output roughly that of the UK, France,
Germany, and Italy. Its key economic sector is
manufacturing - principally the wood, metals,
engineering, telecommunications, and electronics
industries. Trade is important, with exports equaling
more than one-third of GDP. Except for timber and
several minerals, Finland depends on imports of raw
materials, energy, and some components for
manufactured goods. Because of the climate,
agricultural development is limited to maintaining
self-sufficiency in basic products. Forestry, an
important export earner, provides a secondary
occupation for the rural population. The economy has
come back from the recession of 1 990-92, which had
been caused by economic overheating, depressed
foreign markets, and the dismantling of the barter
system between Finland and the former Soviet Union.
Rapidly increasing integration with Western Europe -
Finland was one of the 1 1 countries joining the euro
monetary system (EMU) on 1 January 1999 - will
dominate the economic picture over the next several
years. Growth in 2000 will probably be at the same
level as in 1999, enough to continue the decline in
unemployment from its current high level.
GDP: purchasing power parity - $1 08.6 billion
(1999 est.)
GDP - real growth rate: 3.5% (1999 est.)
GDP - per capita: purchasing power parity -
$21 ,000 (1999 est.)
GDP - composition by sector:
agriculture: 5%
industry: 32%
services: 63% (1997)
Population below poverty line: NA%
Househoid income or consumption by percentage
share:
lowest 10%: 4.2%
highest 10%: 21. 6% (1991)
Infiation rate (consumer prices): 1% (1999 est.)
169
Finland (continued)
Labor force: 2.533 million
Labor force - by occupation: public services 32%,
industry 22%, commerce 14%, finance, insurance,
and business services 10%, agriculture and forestry
8%, transport and communications 8%, construction
6%
Unemployment rate: 10% (1999 est.)
Budget:
revenues.- $41 biiiion
expenditures: $4''[ biiiion, including capitai
expenditures of $NA (1997 est.)
Industries: metal products, shipbuilding, pulp and
paper, copper refining, foodstuffs, chemicals, textiles,
clothing
Industrial production growth rate: 4.8% (1999)
Electricity - production: 75.299 billion kWh (1998)
Electricity ■ production by source:
fossil fuel: At. G2%
hydro: 19.59%
nuclear: 27.59%
of/ier.-11.2%(1998)
Electricity - consumption: 79.278 billion kWh
(1998)
Electricity - exports: 300 million kWh (1998)
Electricity - imports: 9.55 billion kWh (1998)
Agriculture • products: cereals, sugar beets,
potatoes; dairy cattle; fish
Exports: $43 billion (f.o.b,, 1998)
Exports - commodities: machinery and equipment,
chemicals, metals; timber, paper, and pulp
Exports ■ partners: EU 56% (Germany 12%, UK
9%, Sweden 9%, France 5%), US 7%, Russia 6%,
Japan (1998)
Imports: $30.7 billion (f.o.b., 1998)
Imports - commodities: foodstuffs, petroleum and
petroleum products, chemicals, transport equipment,
iron and steel, machinery, textile yarn and fabrics,
fodder grains
Imports - partners: EU 60% (Germany 15%,
Sweden 1 2%, UK 7%), US 8%, Russia 7%, Japan 6%
(1998)
Debt - external: $30 billion (December 1993)
Economic aid - donor: ODA, $379 million (1997)
Currency: 1 markka (FWIk) or Finmark = 100 pennia
Exchange rates: euros per US$1 - 0.9867 (January
2000), 0.9386 (1999); markkaa (FMk) per US$1 -
5.3441 (1998), 5.1914 (1997), 4.5936 (1996), 4.3667
(1995)
note: on 1 January 1999, the EU introduced a
common currency that is now being used by financial
institutions in some member countries at a fixed rate
of 5.94573 markkaa per euro; the euro will replace the
local currency in consenting countries for all
transactions in 2002
Fiscal year: calendar year
Population: 1 ,927,593 (July 2000 est.)
Age structure:
0-14 years: 16% (male 162,932; female 154,513)
15-64 years: 69% (male 678,502; female 660,637)
65 years and over; 15% (male 98,739; female
172,270) (2000 est.)
Population growth rate: 0.12% (2000 est.)
Birth rate: 9.35 births/1,000 population (2000 est.)
Death rate: 9.9 deaths/1 ,000 population (2000 est.)
Net migration rate: 1 .75 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.57 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 4.56 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 74.86 years
male: 70.97 years
female: 78.97 years (2000 est.)
Total fertility rate: 1 .28 children born/woman
(2000 est.)
Nationality:
noun: Slovene(s)
adjective: Slovenian
Ethnic groups: Slovene 88%, Croat 3%, Serb 2%,
Bosniak 1%, Yugoslav 0.6%, Hungarian 0.4%, other
5% (1991)
Religions: Roman Catholic 70.8% (including Uniate
2%), Lutheran 1%, Muslim 1%, atheist 4.3%, other
22.9%
Languages: Slovenian 91%, Serbo-Croatian 6%,
other 3%
Literacy:
definition: NA
total population: 99%
male: NA%
female: NA%','58813e4c61ccd7ee8666807d45f4d8ade685886bb807889eb6562faa579f7a53','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf026bee228933989c05c6496a4dd4360622a53e1f1b7d70fcddb8721dc2d147',2000,'GF','French Guiana','people-and-society',202,'Population: 172,605 (July 2000 est.)
Age structure:
0-14 years: 31% (male 27,1 16; female 25,902)
15-64 years: 64% (male 59,690; female 50,621 )
65 years and over: 5% (male 4,694; female 4,582)
(2000 est.)
Population growth rate: 2.93% (2000 est.)
Birth rate: 22.44 births/1,000 population (2000 est.)
Death rate: 4.76 deaths/1,000 population
(2000 est.)
Net migration rate: 1 1 .59 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 maie(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .18 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 1.13 male(s)/female (2000 est.)
Infant mortality rate: 13.99 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 76.1 years
male: 72.77 years
female: 79.6 years (2000 est.)
Total fertility rate: 3.21 children born/woman
(2000 est.)
Nationality:
noun: French Guianese (singular and plural)
adjective: French Guianese
Ethnic groups: black or mulatto 66%, white 1 2%,
East Indian, Chinese, Amerindian 12%, other 10%
Religions: Roman Catholic
Languages: French
Literacy:
definition: age 1 5 and over can read and write
total population: 83%
male: 84%
female: 82% (1982 est.)','b709d80ca15a7de12aa0e80f721531c4f982d5414089b3b865d79c4cc85d05ae','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f2c3ab6954d35baaf7ac529507790e2b83113f887ecfa3133c7ab97c62ad4eb',2000,'NR','Nauru','people-and-society',209,'Population: 249,1 1 0 (July 2000 est.)
Age structure:
0-14 years: 30% (male 38,736; female 37,1 97)
15-64 years: 65% (male 83,986; female 76,973)
65 years and over: 5% (male 6,1 27; female 6,091 )
(2000 est.)
Population growth rate: 1.78% (2000 est.)
Birth rate: 1 9.01 births/1 ,000 population (2000 est.)
Death rate: 4.41 deaths/1 ,000 popuiation
(2000 est.)
Net migration rate: 3.14 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.09 male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 1.07 male(s)/female (2000 est.)
Infant mortality rate: 9.3 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 74.79 years
male: 72.47 years
female: 77.22 years (2000 est.)
Total fertility rate: 2.28 children born/woman
(2000 est.)
Nationality:
noun: French Polynesian(s)
adjective: French Polynesian
Ethnic groups: Polynesian 78%, Chinese 12%,
local French 6%, metropolitan French 4%
Religions: Protestant 54%, Roman Catholic 30%,
other 16%
Languages: French (official), Tahitian (official)
Literacy:
definition: age 1 4 and over can read and write
total population: 98%
male: 98%
female: 98% (1 977 est.)','8e2d2b0cdb4bef82e72801d3b9a6659e7fa6d99eb3b0bc3b4b8ed67e17305339','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93337536090f7ef2721a4403181029c8b19f963d5aae054ec187935b01e100a8',2000,'FR','France','people-and-society',211,'Population: no indigenous inhabitants
note: in 1997, there were about 100 researchers
whose numbers vary from winter (July) to summer
(January) (July 2000 est.)
Population: uninhabited (July 2000 est.)
194
0 75 150 mi
I'' Introduction
I.
Background: Greece achieved its independence
from the Ottoman Empire in 1829. During the second
half of the 19th century and the first half of the 20th
century, it gradually added neighboring islands and
territories with Greek-speaking populations. Following
the defeat of communist rebels in 1 949, Greece joined
NATO in 1952. A military dictatorship, which in 1967
had suspended many political liberties and forced the
king to flee the country, was itself overthrown seven
years later. Democratic elections in 1974 abolished
the monarchy and created a parliamentary republic;
Greece joined the ED in 1981.
I Geography
Location: Southern Europe, bordering the Aegean
Sea, Ionian Sea, and the Mediterranean Sea,
between Albania and Turkey
Geographic coordinates: 39 00 N, 22 00 E
Map references: Europe
Area:
tofa/; 131,940 sq km
/and; 1 30,800 sq km
wafer; 1,140 sq km
Area - comparative: slightly smaller than Alabama
Land boundaries:
fo/a/; 1,210 km
border countries: Albania 282 km, Bulgaria 494 km,
Turkey 206 km. The Former Yugoslav Republic of
Macedonia 228 km
Coastline: 13,676 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation''
territorial sea: enm
Climate: temperate; mild, wet winters; hot, dry
summers
Terrain: mostly mountains with ranges extending
into the sea as peninsulas or chains of islands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Olympus 2,917 m
Natural resources: bauxite, lignite, magnesite,
petroleum, marble, hydropower
Land use:
arable land: 19%
permanent crops: 8%
permanent pastures: 41 %
forests and woodland: 20%
other: 12% (1993 est.)
Irrigated land: 13,140 sq km (1993 est.)
Natural hazards: severe earthquakes
Environment - current issues: air pollution; water
pollution
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Climate Change-Kyoto Protocol
Geography - note: strategic location dominating the
Aegean Sea and southern approach to Turkish
Straits; a peninsular country, possessing an
archipelago of about 2,000 islands
I'' ■ p e 0 pTe '' '' "
Population: 1 0,601 ,527 (July 2000 est.)
Age structure:
0-14 years: 15% (male 828,585; female 779,902)
15-64 years: 67% (male 3,580,079; female 3,574,788)
65 years and over: 1 8% (male 81 5,247; female
1,022,926) (2000 est.)
Population growth rate: 0.21% (2000 est.)
Birth rate: 9.82 births/1,000 population (2000 est.)
Death rate: 9.64 deaths/1 ,000 population (2000 est.)
Net migration rate: 1 .97 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate: 6.51 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.44 years
male: 75.89 years
female: 81.16 years (2000 est.)
Total fertility rate: 1 .33 children born/woman
(2000 est.)
Nationality:
noun: Greek(s)
adjective: Greek
Ethnic groups: Greek 98%, other 2%
note: the Greek Government states there are no
ethnic divisions in Greece
Religions: Greek Orthodox 98%, Muslim 1 .3%,
other 0.7%
Languages: Greek 99% (official), English, French
Literacy:
definition: age 15 and over can read and write
total population: %%
male: 98%
female: 93% (1991 est.)
Population: 59,51 1 ,464 (July 2000 est.)
Age structure:
0-14 years: 19% (male 5,816,313; female 5,519,479)
15-64 years: 65% (male 19,622,152; female
19,228,938)
65 years and over: 16% (male 3,864,612; female
5,459,970) (2000 est.)
Population growth rate: 0.25% (2000 est.)
Birth rate: 1 1 .76 births/1 ,000 population (2000 est.)
Death rate: 10.38 deaths/1,000 population
(2000 est.)
Net migration rate: 1 .07 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/femaie
under 15 years: 1 .05 maie(s)/femaie
15-64 years: 1 .02 maie(s)/female
65 years and over: 0.71 maie(s)/female
total population: 0.97 maie(s)/female (2000 est.)
Infant mortality rate: 5.63 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77.66 years
male: 74.97 years
female: 80.49 years (2000 est.)
Total fertility rate: 1 .74 children born/woman
(2000 est.)
Nationality;
noun: Briton(s), British (collective plural)
adjective: British
Ethnic groups: English 81.5%, Scottish 9.6%, Irish
2.4%, Welsh 1.9%, Ulster 1.8%, West Indian, Indian,
Pakistani, and other 2.8%
Religions: Anglican 27 million, Roman Catholic 9
million, Muslim 1 million, Presbyterian 800,000,
Methodist 760,000, Sikh 400,000, Hindu 350,000,
Jewish 300,000 (1991 est.)
Languages: English, Welsh (about 26% of the
population of Wales), Scottish form of Gaelic (about
60,000 in Scotland)
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 99% (1 978 est.)
male: NA%
female: NA%
I? G o V e r n m ell t
Country name:
conventional long form: United Kingdom of Great
Britain and Northern Ireland
conventional short form: United Kingdom
abbreviation: UK
Data code; UK
Government type: constitutional monarchy
Capital: London
Administrative divisions: 47 counties, 7
metropolitan counties, 26 districts, 9 regions, and 3
islands areas; England - 39 counties, 7 metropolitan
counties*; Avon, Bedford, Berkshire, Buckingham,
Cambridge, Cheshire, Cleveland, Cornwall, Cumbria,
Derby, Devon, Dorset, Durham, East Sussex, Essex,
Gloucester, Greater London*, Greater Manchester*,
Hampshire, Hereford and Worcester, Hertford,
Humberside, Isle of Wight, Kent, Lancashire,
Leicester, Lincoln, Merseyside*, Norfolk,
Northampton, Northumberland, North Yorkshire,
Nottingham, Oxford, Shropshire, Somerset, South
Yorkshire*, Stafford, Suffolk, Surrey, Tyne and Wear*,
Warwick, West Midlands*, West Sussex, West
Yorkshire*, Wiltshire; Northern Ireland - 26 districts;
Antrim, Ards, Armagh, Ballymena, Ballymoney,
Banbridge, Belfast, Carrickfergus, Castlereagh,
Coleraine, Cookstown, Craigavon, Down,
Dungannon, Fermanagh, Larne, Limavady, Lisburn,
Londonderry, Magherafelt, Moyle, Newry and Mourne,
Newtownabbey, North Down, Omagh, Strabane;
Scotland - 9 regions, 3 islands areas*; Borders,
Central, Dumfries and Galloway, Fife, Grampian,
Highland, Lothian, Orkney*, Shetland*, Strathclyde,
Tayside, Western Isles*; Wales - 8 counties; Clwyd,
Dyfed, Gwent, Gwynedd, Mid Glamorgan, Poiwys,
South Glamorgan, West Glamorgan
note: England may now have 35 counties and Wales
9 counties
Dependent areas: Anguilla, Bermuda, British Indian
Ocean Territory, British Virgin Islands, Cayman
Islands, Falkland Islands, Gibraltar, Guernsey,
Jersey, Isle of Man, Montserrat, Pitcairn Islands, Saint
Helena, South Georgia and the South Sandwich
Islands, Turks and Caicos Islands
Independence: England has existed as a unified
entity since the 10th century; the union between
England and Wales was enacted under the Statute of
Rhuddlan in 1284; in the Act of Union of 1707,
England and Scotland agreed to permanent union as
Great Britain; the legislative union of Great Britain and
Ireland was implemented in 1 801 , with the adoption of
the name the United Kingdom of Great Britain and
Ireland; the Anglo-Irish treaty of 1921 formalized a
partition of Ireland; six northern Irish counties
remained part of the United Kingdom as Northern
Ireland and the current name of the country, the
United Kingdom of Great Britain and Northern Ireland,
was adopted in 1927
National holiday: Celebration of the Birthday of. the
Queen (second Saturday in June)
Constitution: unwritten; partly statutes, partly
common law and practice
Legal system: common law tradition with early
Roman and modern continental influences; no judicial
review of Acts of Parliament; accepts compulsory ICJ
jurisdiction, with reservations; British courts and
legislation are increasingly subject to review by
European Union courts
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952); Heir Apparent Prince CHARLES (son of the
queen, born 14 November 1948)
United Kingdom (continued)
head of government: Prime Minister Anthony C. L.
(Tony) BLAIR (since 2 May 1997)
cabinet: Cabinet of Ministers appointed by the prime
minister
etections: none; the monarch is hereditary; the prime
minister is the leader of the majority party in the House
of Commons (assuming there is no majority party, a
prime minister would have a majority coalition or at
least a coalition that was not rejected by the majority)
Legislative branch: bicameral Parliament consists
of House of Lords (the old House of Lords has been
disbanded, and the new one is still being formed; the
most likely plan calls for 500 members, one-fifth
elected and the rest appointed) and House of
Commons (659 seats; members are elected by
popular vote to serve five-year terms unless the
House is dissolved earlier)
elections: House of Lords - no elections; note - the
newly-forming House of Lords may call for some
elected seats; House of Commons - last held 1 May
1 997 (next to be held by NA May 2002); note - in 1 998
elections were held for a Northern Ireland Parliament
(because of unresolved disputes among existing
parties, the transfer of power from London to Northern
Ireland came only at the end of 1 999 and was
rescinded in February 2000); in 1999 there were
elections for a new Scottish Parliament and a new
Welsh Assembly
election results: House of Commons - percent of vote
by party - Labor 45%, Conservative and Unionist
31%, Liberal Democratic 17%, other 7%; seats by
party - Labor 418, Conservative and Unionist 165,
Liberal Democrat 46, other 30
note: in 1999, the government ended the right of most
hereditary members, except for life members and 92
hereditary members, to sit in the House of Lords; they
will sit until final reforms are made
Judicial branch: House of Lords, several Lords of
Appeal in Ordinary are appointed by the monarch for
life
Political parties and leaders: Alliance Party
(Northern Ireland) [Seamus CLOSE]; Conservative
and Unionist Party [William HAGUE]; Democratic
Unionist Party (Northern Ireland) [Rev. Ian PAISLEY];
Labor Party [Anthony (Tony) Blair]; Liberal Democrats
[Charles KENNEDY]; Scottish National Party [Alex
SALMOND]; Sinn Fein (Northern Ireland) [Gerry
ADAMS]; Social Democratic and Labor Party or SDLP
(Northern Ireland) [John HUME]; Ulster Unionist Party
(Northern Ireland) [David TRIMBLE]; Welsh National
Party (Plaid Cymru) [Dafydd Iwan WIGLEY]
Political pressure groups and leaders: Campaign
for Nuclear Disarmament; Confederation of British
Industry; National Farmers'' Union; Trades Union
Congress
International organization participation: AfDB,
AsDB, Australia Group, BIS, C, CCC, CDB
(non-regional), CE, CERN, EAPC, EBRD, ECA
(associate), ECE, ECLAC, EIB, ESA, ESCAP, EU,
FAO, G- 5, G- 7, G-1 0, lADB, IAEA, IBRD, ICAO, ICC,
ICFTU, ICRM, IDA, lEA, IFAD, IFC, IFRCS, IHO, ILO,
IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, lOM
(observer), ISO, ITU, MONUC, NAM (guest), NATO,
NEA, NSG, OAS (observer), OECD, OPCW, OSCE,
PCA, SPC, UN, UN Security Council, UNAMSIL,
UNCTAD, UNESCO, UNFICYP, UNHCR, UNIDO,
UNIKOM, UNMIBH, UNMIK, UNOMIG, UNRWA,
UNTAET, UNU, UPU, WCL, WEU, WHO, WlPO,
WMO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Sir Christopher J. R.
MEYER
chancery: 3100 Massachusetts Avenue NW,
Washington, DC 20008
fe/ephone; [1] (202) 588-6500
FAY; [1] (202) 588-7870
consulate(s) general: Atlanta, Boston, Chicago,
Cleveiand, Houston, Los Angeles, New York, and San
Francisco
consulate(s): Daiias, Miami, and Seattle
Diplomatic representation from the US:
chief of mission: Ambassador Philip LADER
embassy: 24/31 Grosvenor Square, London, W.
1A1AE
mailing address: PSC 801 , Box 40, FPO AE
09498-4040
telephone: [44] (1 71 ) 499-9000
FAY; [44] (171) 409-1637
consulate(s) general: Belfast, Edinburgh
Flag description: blue with the red cross of Saint
George (patron saint of England) edged in white
superimposed on the diagonal red cross of Saint
Patrick (patron saint of ireland) and which is
superimposed on the diagonal white cross of Saint
Andrew (patron saint of Scotland); known as the
Union Flag or Union Jack; the design and colors
(especially the Blue Ensign) have been the basis for a
number of other flags including other Commonwealth
countries and their constituent states or provinces, as
well as British overseas territories
f '' E''cFnTmT ”
Economy - overview: The UK, a leading trading
power and financiai center, deploys an essentially
capitalistic economy, one of the quartet of triilion doliar
economies of Western Europe. Over the past two
decades the government has greatly reduced public
ownership and contained the growth of sociai weifare
programs. Agricuiture is intensive, highly mechanized,
and efficient by European standards, producing about
60% of food needs with only 1 % of the labor force. The
UK has large coal, natural gas, and oil reserves;
primary energy production accounts for 10% of GDP,
one of the highest shares of any industriai nation.
Services, particularly banking, insurance, and
business services, account by far for the iargest
proportion of GDP while industry continues to deciine
in importance. Economic growth has been slowed in
1999; recovery to 3% is in prospect for 2000, based on
a rise in exports and domestic demand. The BLAiR
government has put off the question of participation in
the euro system untii after the next eiection, not
expected until 2001; Chancellor of the Exchequer
BROWN has identified some key economic tests to
determine whether the UK should join the common
currency system.
GDP: purchasing power parity - $1 .29 triiiion
(1999 est.)
GDP - real growth rate: 1 .9% (1 999 est.)
GDP - per capita: purchasing power parity -
$21,800 (1999 est.)
GDP - composition by sector:
agriculture: 1 .7%
industry: 25.3%
services: 73% (1998)
Population below poverty line: 17%
Household income or consumption by percentage
share:
lowest 10%; 2.4%
highest 10%; 24.7% (1986)
Inflation rate (consumer prices): 2.3% (1999)
Labor force: 29.2 million (1999)
Labor force - by occupation: services 68.9%,
manufacturing and construction 17.5%, government
1 1 .3%, energy 1 .2%, agricuiture 1 .1% (1996)
Unemployment rate: 6% (1999)
Budget:
revenues; $541 billion
expenditures: $507.5 billion, including capital
expenditures of $35.1 billion (FY98/99)
Industries: production machinery including machine
tools, electric power equipment, automation
equipment, railroad equipment, shipbuilding, aircraft,
motor vehicles and parts, electronics and
communications equipment, metals, chemicals, coal,
petroleum, paper and paper products, food
processing, textiles, clothing, and other consumer
goods
Industrial production growth rate: -0.3% (1999)
Electricity - production: 343.099 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 68.24%
hydro; 1.49%
nuclear: 28.48%
other; 1.79% (1998)
Electricity - consumption: 331 .482 billion kWh
(1998)
Electricity - exports: 200 million kWh (1998)
Electricity - imports: 12.6 billion kWh (1998)
Agriculture - products: cereals, oilseed, potatoes,
vegetables; cattle, sheep, poultry; fish
Exports: $271 billion (f.o.b., 1998)
Exports - commodities: manufactured goods,
fuels, chemicals; food, beverages, tobacco
Exports - partners: EU 58% (Germany 12%,
France 10%, Netherlands 8%), US 13% (1998)
Imports: $305.9 billion (f.o.b., 1998)
Imports - commodities: manufactured goods,
machinery, fuels; foodstuffs
Imports - partners: EU 53% (Germany 1 3%, France
9%, Netherlands 7%, Italy 5%), US 14% (1998)
Debt - external: $NA
Economic aid - donor: ODA, $3.4 billion (1997)
Currency: 1 British pound = 100 pence
519
United Kingdom (continued)
Exchange rates; British pounds per US$1 - 0.6092
(January 2000), 0.61 80 (1999), 0.6037 (1 998), 0.61 06
(1997), 0.6403 (1996), 0.6335 (1995)
Fiscal year: 1 April - 31 March
I Communications
Teiephones - main iines in use: 29.41 million
(1995)
Telephones - mobile cellular: 13 million (yearend
1998)
Telephone system; technologically advanced
domestic and international system
domestic: equal mix of buried cables, microwave
radio relay, and fiber-optic systems
international: 40 coaxial submarine cables; satellite
earth stations - 10 Intelsat (7 Atlantic Ocean and 3
Indian Ocean), 1 1nmarsat (Atlantic Ocean region),
and 1 Eutelsat; at least 8 large international switching
centers
Radio broadcast stations; AM 21 9, FM 431 ,
shortwave 3 (1998)
Radios: 84.5 million (1997)
Television broadcast stations: 78 (plus 869
repeaters) (1997)
Televisions: 30.5 million (1997)
Internet Service Providers (ISPs): 364 (1999)
I Transportation
Railways:
total: 16,878 km
broad gauge: 342 km 1 .600-m gauge (1 90 km double
track); note - all 1 .600-m gauge track, of which 342 km
is in common carrier use, and is in Northern Ireland
standard gauge: 1 6,536 km 1 .435-m gauge (4,928 km
electrified; 1 2,591 km double or multiple track) (1 996)
Highways;
total: 371 ,603 km
paved; 371,603 km (including 3,303 km of
expressways)
unpaved: 0 km (1998 est.)
Waterways: 3,200 km
Pipelines: crude oil (almost all insignificant) 933 km;
petroleum products 2,993 km; natural gas 12,800 km
Ports and harbors: Aberdeen, Belfast, Bristol,
Cardiff, Dover, Falmouth, Felixstowe, Glasgow,
Grangemouth, Hull, Leith, Liverpool, London,
Manchester, Peterhead, Plymouth, Portsmouth,
Scapa Flow, Southampton, Sullom Voe, Tees, Tyne
Merchant marine;
total: 173 ships (1 ,000 GRT or over) totaling
2,917,708 GRT/3,063,1 13 DWT
ships by type: bulk 4, cargo 33, chemical tanker 5,
combination ore/oil 1, container 39, liquified gas 2,
passenger 8, passenger/cargo 1, petroleum tanker
50, roll-on/roll-off 18, short-sea passenger 10,
specialized tanker 1, vehicle carrier 1 (1999 est.)
Airports: 498 (1999 est.)
Airports - with paved runways:
total: 357
over 3,047 m: W
2,438 to 3,047 m: 33
1,524 to 2,437 m:m
914 to 1,523 m: 93
under 914 m: 55 (1 999 est.)
Airports - with unpaved runways;
fofa/;141
1,524 to 2,437 m:1
914 to 1,523 m: 23
under 914 m: 117(1 999 est.)
Heliports: 12 (1999 est.)
f Military
Military branches:" Army, Royal Navy (includes
Royal Marines), Royal Air Force
Military manpower - availability:
males age 15-49: 14,574,955 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 12,134,272 (2000 est.)
Military expenditures - dollar figure; $36,884
billion (FY97/98)
Military expenditures - percent of GDP: 2.7%
(FY97/98)
I T r a n s n a t i 0 n a i is sues
Disputes - international; Northern Ireland issue
with Ireland (historic peace agreement signed 10 April
1998); Gibraltar issue with Spain; Argentina claims
Falkland Islands (Islas Malvinas); Argentina claims
South Georgia and the South Sandwich Islands;
Mauritius claims island of Diego Garcia In British
Indian Ocean Territory; Rockall continental shelf
dispute involving Denmark, Iceland, and Ireland
(Ireland and the UK have signed a boundary
agreement in the Rockall area); territorial claim in
Antarctica (British Antarctic Territory); Seychelles
claims Chagos Archipelago in British Indian Ocean
Territory
Illicit drugs: gateway country for Latin American
cocaine entering the European market; producer and
major consumer of synthetic drugs, synthetic
precursor chemicals; major consumer of Southwest
Asian heroin; money-laundering center
f Introduction
Background: The United States became the world''s
first modern democracy after its break with Great
Britain (1776) and the adoption of a constitution
(1789). During the 19th century, many new states
were added to the original 13 as the nation expanded
across the North American continent and acquired a
number of overseas possessions. The two major
traumatic experiences in the nation''s history were the
Civil War (1861-65) and the Great Depression of the
1930s. Buoyed by victories in Worid Wars I and II and
the end of the Cold War in 1 991 , the US remains the
world''s most powerful nation-state. The economy is
marked by steady growth, low unemployment and
inflation, and rapid advances in technology.
I Geography
Location: North America, bordering both the North
Atiantic Ocean and the North Pacific Ocean, between
Canada and Mexico
Geographic coordinates: 38 00 N, 97 00 W
Map references: North America
Area:
total: 9,629,091 sq km
/ancf;9,158,960sqkm
wafer; 470,131 sqkm
note: includes only the 50 states and District of
Coiumbia
Area - comparative: about one-haif the size of
Russia; about three-tenths the size of Africa; about
one-half the size of South America (or siightly iarger
than Brazil); slightly larger than China; about two and
one-half times the size of Western Europe
Land boundaries:
total: 12,248 km
border countries: Cana6a 8,893 km (inciuding 2,477
km with Alaska), Cuba 29 km (US Naval Base at
Guantanamo Bay), Mexico 3,326 km
note: Guantanamo Naval Base Is leased by the US
and thus remains part of Cuba
Coastline: 19,924 km
Maritime ciaims:
contiguous zone: 24 nm
continental shelf: not specified
exclusive economic zone: 200 nm
territorial sea: 12 nm
Ciimate: mostly temperate, buttropical in Hawaii and
Florida, arctic in Alaska, semiarid in the great plains
west of the Mississippi River, and arid in the Great
Basin of the southwest; low winter temperatures in the
northwest are ameiiorated occasionaiiy in January
and February by warm Chinook winds from the eastern
slopes of the Rocky Mountains
Terrain: vast central plain, mountains in west, hilis
and low mountains in east; rugged mountains and
broad river valieys in Aiaska; rugged, volcanic
topography in Hawaii
Elevation extremes:
lowest point: Death Valley -86 m
highest point: Mount McKinley 6,194 m
Natural resources: coal, copper, lead,
molybdenum, phosphates, uranium, bauxite, goid,
iron, mercury, nickel, potash, silver, tungsten, zinc,
petroleum, natural gas, timber
Land use:
arable land: 19%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 30%
other; 26% (1 993 est.)
Irrigated land: 207,000 sq km (1993 est.)
Natural hazards: tsunamis, volcanoes, and
earthquake activity around Pacific Basin; hurricanes
along the Atlantic and Gulf of Mexico coasts;
tornadoes in the midwest and southeast; mud slides in
California; forest fires in the west; flooding; permafrost
in northern Alaska, a major impediment to
development
Environment - current issues: air pollution
resulting in acid rain in both the US and Canada; the
US is the largest single emitter of carbon dioxide from
the burning of fossil fuels; water pollution from runoff
of pesticides and fertilizers; very limited natural fresh
water resources in much of the western part of the
country require careful management; desertification
Environment - international agreements:
party to; Air Pollution, Air Pollution-Nitrogen Oxides,
Antarctic-Environmental Protocol, Antarctic Treaty,
Climate Change, Endangered Species,
Environmental Modification, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes
Geography - note: world''s third-largest country
(after Russia and Canada)
Population: 275,562,673 (July 2000 est.)
Age structure:
0-14 years: 21 .25% (male 2','bfd25c00b61be4114b3ea70ccbe6006c6b22fb4eb821a4b00899a289e1f8b527','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb182aaebeb7730dcdfc3eda9025d55fa339ff97aa689928daf77c6a9e789826',2000,'FR','France','people-and-society',212,'9,956,875; female
28,597,880)
15-64 years: 66.1 1 % (male 90,345,1 54; female
91,827,471)
65 years and over: 12.64% (male 14,472,865; female
20,362,428) (2000 est.)
Population growth rate: 0.91% (2000 est.)
Birth rate: 14.2 births/l ,000 population (2000 est.)
Death rate: 8.7 deaths/1 ,000 population (2000 est.)
Net migration rate: 3.5 migrant(s)/1,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate: 6.82 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77. 1 2 years
male: 74.24 years
female: 79.9 years (2000 est.)
Total fertility rate: 2.06 children born/woman
(2000 est.)
Nationality:
noun; American(s)
adjective: American
Ethnic groups: white 83.5%, black 12.4%, Asian
3.3%, Amerindian 0.8% (1992)
note: a separate listing for Hispanic is not included
because the US Census Bureau considers Hispanic
to mean a person of Latin American descent
(especially of Cuban, Mexican, or Puerto Rican origin)
living in the US who may be of any race or ethnic
group (white, black, Asian, etc.)
Religions: Protestant 56%, Roman Catholic 28%,
Jewish 2%, other 4%, none 10% (1989)
Languages: English, Spanish (spoken by a sizable
minority)
521
United States (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 97%
fema/e; 97% (1979 est.)
Population: 244,943 (July 2000 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: Hh
Population growth rate: 2.29% (2000 est.)
Birth rate: 45.07 births/1,000 population (2000 est.)
Death rate: 16.11 deaths/1,000 population
(2000 est.)
Net migration rate: -6.05 migrant(s)/1 ,000
population (2000 est.)
Infant mortality rate: 133.59 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 49.81 years
male: 48.65 years
female: 51 .33 years (2000 est.)
Total fertility rate: 6.64 children born/woman
(2000 est.)
Nationality:
noun: Sahrawi(s), Sahraoui(s)
adjective: Sahrawian, Sahraouian
Ethnic groups: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan Arabic
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','3192fb37ca0010eeed242c08c5935e6638be126309359a6c65946c3ed21149f1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f80eff282b2ddb4a53b8e14d7037fa007ce31d2b5ae2ee9718def0dbc983509c',2000,'GH','Ghana','people-and-society',215,'Population: 19,533,560
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 42% (male 4,120,240; female 4,063,960)
15-64 years: 55% (male 5,290,675; female
5,391,175)
65 years and over: 3% (male 31 8,890; female
348,620) (2000 est.)
Population growth rate: 1 .87% (2000 est.)
Birth rate: 29.81 births/1 ,000 population (2000 est.)
Death rate: 1 0.22 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.89 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate: 57.43 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 57.42 years
male: 56.07 years
female: 58.82 years (2000 est.)
Total fertility rate: 3.95 children born/woman
(2000 est.)
Nationality:
noun: Ghanaian(s)
190
Ghana (continued)
adjective: Ghanaian
Ethnic groups: black African 99.8% (major tribes -
Akan 44%, Moshi-Dagomba 1 6%, Ewe 1 3%, Ga 8%),
European and other 0.2%
Religions: indigenous beliefs 38%, Muslim 30%,
Christian 24%, other 8%
Languages: English (official), African languages
(including Akan, Moshi-Dagomba, Ewe, and Ga)
Literacy:
definition: age 1 5 and over can read and write
totai population: 64.5%
male: 75.9%
female: 53.5% (1995 est.)
I Government
Country name:
conventional long form: Republic of Ghana
conventional short form: Ghana
former: Gold Coast
Data code: GH
Government type: constitutional democracy
Capital: Accra
Administrative divisions: 10 regions; Ashanti,
Brong-Ahafo, Central, Eastern, Greater Accra,
Northern, Upper East, Upper West, Volta, Western
Independence: 6 March 1957 (from UK)
National holiday: Independence Day, 6 March
(1957)
Constitution: new constitution approved 28 April
1992
Legal system: based on English common law and
customary law; has not accepted compulsory ICJ
jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Jerry John RAWLINGS
(since 7 January 1993); Vice President John Evans
Atta MILLS (since 7 January 1993); note - the
president is both the chief of state and head of','9226a76554a2e44bfce8e986f411af06ac55609e1f490c1501042e0f223bb821','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1111bedea0d68d7d534196da5574d863f31e93eac5e6915b0e750dc7fda76821',2000,'DK','Denmark','people-and-society',227,'Population: 426,493 (July 2000 est.)
Age structure:
0-14 years: 25% (male 54,603; female 52,339)
15-64 years: 66% (male 139,640; female 142,706)
65 years and over: 9% (male 1 5,647; female 21 ,558)
(2000 est.)
Population growth rate: 1.11% (2000 est.)
Birth rate: 17.25 births/1 ,000 population (2000 est.)
Death rate: 6.01 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.15 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate: 9.77 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 76.99 years
male: 73.82 years
female: 80.3 years (2000 est.)
Total fertility rate: 1 .93 children born/woman
(2000 est.)
Nationality:
noun: Guadeloupian(s)
adjective: Guadeloupe
Ethnic groups: black or mulatto 90%, white 5%,
East Indian, Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 4%, Protestant 1%
Languages: French (official) 99%, Creole patois
Literacy:
definition: age 1 5 and over can read and write
total population: 90%
male: 90%
female: 90% (1 982 est.)','090bd83b491d10bea4f69fba8de750b54b9efcd5625e7521e37049f9cbc3b445','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57f5c220ae437027ad6c2ddab6cfe4f99aec9947824e430ea86b3b6c64e2b5e8',2000,'IQ','Iraq','people-and-society',245,'Population: 22,675,617 (July 2000 est.)
Age structure:
0-14 years: 42% (male 4,860,795; female 4,708,453)
15-64 years: 55% (male 6,272,842; female
6,123,188)
65 years and over: 3% (male 331 ,840; female
378,499) (2000 est.)
Population growth rate: 2.86% (2000 est.)
Birth rate: 35.04 births/1 ,000 population (2000 est.)
Death rate: 6.4 deaths/1 ,000 population (2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1 .02 male(s)/female (2000 est.)
Infant mortality rate: 62.49 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 66.53 years
male: 65.54 years
female: 67.56 years (2000 est.)
238
Iraq (continued)
Total fertility rate: 4.87 children born/woman
(2000 est.)
Nationality:
noun: Iraqi(s)
adjective: Iraqi
Ethnic groups: Arab 75%-80%, Kurdish 15%-20%,
Turkoman, Assyrian or other 5%
Religions: Muslim 97% (Shi''a 60%-65%, Sunni
32%-37%), Christian or other 3%
Languages: Arabic, Kurdish (official in Kurdish
regions), Assyrian, Armenian
Literacy:
definition: age 15 and over can read and write
total population: 58%
male: 70.7%
female: 45% (1 995 est.)
I Government
Country name:
conventional long form: Republic of Iraq
conventional short form: Iraq
local long form: Al Jumhuriyah al Iraqiyah
local short form: M Iraq
Data code: IZ
Government type: republic
Capital: Baghdad
Administrative divisions: 18 provinces
(muhafazat, singular - muhafazah); Al Anbar, Al
Basrah, Al Muthanna, Al Qadisiyah, An Najaf, Arbil,
As Sulaymaniyah, AtTa''mim, Babil, Baghdad, Dahuk,
Dhi Qar, Diyala, Karbala'', Maysan, Ninawa, Salah ad
Din, Wasit
Independence: 3 October 1932 (from League of
Nations mandate under British administration)
National holiday: Anniversary of the Revolution, 17
July (1968)
Constitution: 22 September 1968, effective 16 July
1970 (provisional constitution); new constitution
drafted in 1990 but not adopted
Legal system: based on Islamic law in special
religious courts, civil law system elsewhere; has not
accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President SADDAM Husayn (since 16
July 1979); Vice PresidentTaha Muhyi al-Din MARUF
(since 21 April 1974); Vice President Taha Yasin
RAMADAN (since 23 March 1 991 )
head of government: Prime Minister SADDAM
Husayn (since 29 May 1994); Deputy Prime Minister
Tariq Mikhail AZIZ (since NA 1979); Deputy Prime
Minister Taha Yasin RAMADAN (since NA May 1 994);
Deputy Prime Minister Muhammad Hamza
al-ZUBAYDI (since NA May 1994)
cabinet: Council of Ministers
note: there is also a Revolutionary Command Council
or RCC (Chairman SADDAM Husayn, Vice Chairman
Izzat IBRAHIM al-Duri) which controls the ruling Ba''th
Party, and is the most powerful political entity in the
country
elections: president and vice presidents elected by a
two-thirds majority of the Revolutionary Command
Council; election last held 1 7 October 1 995 (next to be
held NA 2002)
election results: SADDAM Husayn reelected
president; percent of vote - 99%; Taha Muhyi al-Din
MARUF and Taha Yasin RAMADAN elected vice
presidents; percent of vote - NA
Legislative branch: unicameral National Assembly
or Majlis al-Watani (250 seats; 30 appointed by the
president to represent the three northern provinces of
Dahuk, Arbil, and As Sulaymaniyah; 220 elected by
popular vote; members serve four-year terms)
elections: last held 24 March 1 996 (next to be held NA
March 2000)
election results: percent of vote by party - NA; seats
by party - NA
Judicial branch: Court of Cassation
Political parties and leaders: Ba''th Party
[SADDAM Husayn, central party leader]
Political pressure groups and leaders: any formal
political activity must be sanctioned by the
government; opposition to regime from Kurdish
groups and southern Shi''a dissidents
international organization participation: ABEDA,
ACC, AFESD, AL, AMF, CAEU, CCC, ESCWA, FAO,
G-19, G-77, IAEA, IBRD, ICAO, ICRM, IDA, IDB,
IFAD, IFC, IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat,
Interpol, IOC, ITU, NAM, OAPEC, OIC, OPEC, PCA,
UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU,
WHO, WlPO, WMO, WToO
Diplomatic representation in the US: none; note -
Iraq has an Interest Section in the Algerian Embassy
headed by Mr. Akram AL DOURi; address: Iraqi
Interests Section, Algerian Embassy, 2118 Kalorama
Road NW, Washington, DC 20008; telephone: [1]
(202) 265-2800; FAX: [1] (202) 667-2174
Diplomatic representation from the US: none;
note - the US has an Interests Section in the Polish
Embassy in Baghdad; address: P. 0. Box 2051 Hay
Babel, Baghdad; telephone: [964] (1)71 8-9267; FAX:
[964] (1) 718-9297
Flag description: three equal horizontal bands of
red (top), white, and black with three green
five-pointed stars in a horizontal line centered in the
white band; the phrase ALLAHU AKBAR (God is
Great) in green Arabic script - Allahu to the right of the
middle star and Akbar to the left of the middle star -
was added in January 1991 during the Persian Gulf
crisis; similar to the flag of Syria which has two stars
but no script and the flag of Yemen which has a plain
white band; also similar to the flag of Egypt which has
a symbolic eagle centered in the white band
I Economy
Economy - overview: Iraq''s economy is dominated
by the oil sector, which has traditionally provided
about 95% of foreign exchange earnings. In the
1980s, financial problems caused by massive
expenditures in the eight-year war with Iran and
damage to oil export facilities by Iran led the
government to implement austerity measures, borrow
heavily, and later reschedule foreign debt payments;
Iraq suffered economic losses of at least $100 billion
from the war. After the end of hostilities in 1988, oil
exports gradually increased with the construction of
new pipelines and restoration of damaged facilities.
Iraq''s seizure of Kuwait in August 1990, subsequent
international economic sanctions, and damage from
military action by an international coalition beginning
in January 1 991 drastically reduced economic activity.
The government''s policies of supporting large military
and internal security forces and of allocating
resources to key supporters of the regime have
exacerbated shortages. The implementation of the
UN''s oil-for-food program in December 1996 has
helped improve economic conditions. For the first six
six-month phases of the program, Iraq was allowed to
export limited amounts of oil in exchange for food,
medicine, and other humanitarian goods. In
December 1999, the UN Security Council authorized
Iraq to export under the oil-for-food program as much
oil as required to meet humanitarian needs. Oil
exports are now about three-quarters their prewar
level. Per capita food imports have increased
significantly, while medical supplies and health care
sen/ices are steadily improving. Per capita output and
living standards are still well below the prewar level,
but any estimates have a wide range of error.
GDP: purchasing power parity - $59.9 billion
(1999 est.)
GDP ■ real growth rate: 1 3% (1 999 est.)
GDP - per capita: purchasing power parity - $2,700
(1999 est.)
GDP - composition by sector:
agriculture: 6%
industry: 13%
senrices: 81 % (1 993 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Infiation rate (consumer prices): 135% (1999 est.)
Labor force: 4.4 million (1989)
Labor force ■ by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: petroleum, chemicals, textiles,
construction materials, food processing
Industrial production growth rate: NA%
Eiectricity - production: 28.4 billion kWh (1998)
Electricity - production by source:
fossil fuel: 97.89%
hydro; 2.11%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 26.412 billion kWh
(1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: wheat, barley, rice,
vegetables, dates, cotton; cattle, sheep
239
Iraq (continued)
Exports: $12.7 billion (1999 est.)
Exports - commodities: crude oil
Exports - partners: Russia, France, China (1999)
Imports: $8.9 billion (1999 est.)
Imports - commodities: food, medicine,
manufactures
Imports - partners: Russia, France, Egypt, Vietnam
(1999)
Debt - external: $130 billion (1999 est.)
Economic aid - recipient: $327.5 million (1995)
Currency: 1 1raqi dinar (ID) = 1 ,000 fils
Exchange rates: Iraqi dinars (ID) per US$1 - 0.3109
(fixed official rate since 1 982); black market rate - Iraqi
dinars (ID) per US$1 - 1 ,900 (December 1 999), 1 ,81 5
(December 1998), 1,530 (December 1997), 3,000
(December 1995); subject to wide fluctuations
Fiscal year: calendar year
I Communications
Telephones - main lines in use: 675,000 (1995)
Telephones - mobile cellular: NA
Telephone system: reconstitution of damaged
telecommunication facilities began after the Gulf war;
most damaged facilities have been rebuilt
domestic: the network consists of coaxial cables and
microwave radio relay links
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean), 1 Intersputnik
(Atlantic Ocean region) and 1 Arabsat (inoperative);
coaxial cable and microwave radio relay to Jordan,
Kuwait, Syria, and Turkey; Kuwait line is probably
nonoperational
Radio broadcast stations: AM 19 (5 are inactive),
FM 51 , shortwave 4 (1 998)
Radios: 4.85 million (1997)
Television broadcast stations: 13(1 997)
Televisions: 1.75 million (1997)
Internet Service Providers (ISPs): 1 (1999)
I transportation
Railways:
total: 2,032 km
standard gauge: 2,032 km 1.435-m gauge
Highways:
total: 45,550 km
paved: 38,400 km
unpaved: 7, too km (1996 est.)
Waterways: 1 ,015 km; Shatt al Arab is usually
navigable by maritime traffic for about 130 km;
channel has been dredged to 3 m and is in use; Tigris
and Euphrates Rivers have navigable sections for
shallow-draft watercraft; Shatt al Basrah canal was
navigable by shallow-draft craft before closing in 1 991
because of the Gulf war
Pipelines: crude oil 4,350 km; petroleum products
725 km; natural gas 1 ,360 km
Ports and harbors: Umm Qasr, Khawr az Zubayr,
and Al Basrah have limited functionality
Merchant marine:
total: 32 ships (1 ,000 GRT or over) totaling 606,227
GRT/1 ,067,770 DWT
ships by type: cargo 14, passenger 1 , passenger/
cargo 1 , petroleum tanker 13, refrigerated cargo 1 ,
roll-on/roll-off 2 (1999 est.)
Airports: 113 (1999 est.)
Airports - with paved runways:
total: 80
over 3,047 m: 20
2,438 to 3,047 m: 30
1,524 to 2,437 m: 4
914 to 1,523 m: 7
under 914 m: 10(1 999 est.)
Airports - with unpaved runways:
total: 33
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m: 12 (1999 est.)
Heliports: 5 (1999 est.)
I M j il t a r y
Military branches: Army, Republican Guard, Navy,
Air Force, Air Defense Force, Border Guard Force,
Fedayeen Saddam
Military manpower • military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 5,674,990 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 3,176,826 (2000 est.)
Military manpower - reaching military age
annually:
males: 266,736 (2000 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Nreland
Background: A failed 1916 Easter Monday
Rebellion touched off several years of guerrilla
warfare that in 1921 resulted in independence from
the UK for the 26 southern counties; the six northern
counties (Ulster) remained part of Great Britain. In
1948 Ireland withdrew from the British
Commonwealth; it joined the European Community in
1973. Irish governments have sought the peaceful
unification of Ireland and have cooperated with Britain
against terrorist groups. A peace settlement for
Northern Ireland, approved in 1998, has not yet been
implemented.
( T r a n s n a t i 0 iTa I Issues
Disputes - international: Iran and Iraq restored
diplomatic relations in 1990 but are still trying to work
out written agreements settling outstanding disputes
from their eight-year war concerning border
demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shatt al Arab
waterway; in November 1994, Iraq formally accepted
the UN-demarcated border with Kuwait which had
been spelled out in Security Council Resolutions 687
(1 991 ), 773 (1 993), and 883 (1 993); this formally ends
earlier claims to Kuwait and to Bubiyan and Warbah
islands although the government continues periodic
rhetorical challenges; dispute over water development
plans by Turkey for the Tigris and Euphrates rivers
F "Geograph''y
Location: Western Europe, occupying five-sixths of
the island of Ireland In the North Atlantic Ocean, west
of Great Britain
Geographic coordinates: 53 00 N, 8 00 W
Map references: Europe
Area:
total: 70,280 sq km
land: 68,890 sq km
water: 1 ,390 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries:
total: 360 km
border countries: UK 360 km
Coastline: 1,448 km
Maritime ciaims:
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Ciimate: temperate maritime; modified by North
Atlantic Current; mild winters, cool summers;
consistently humid; overcast about half the time
Terrain: mostly level to rolling interior plain
surrounded by rugged hills and low mountains; sea
cliffs on west coast
240
IrGland (continued)
Elevation extremes:
toivesfpo/nf; Atlantic Ocean 0 m
highest point: CammtoohW 1,041 m
Natural resources; zinc, lead, natural gas, barite,
copper, gypsum, limestone, dolomite, peat, silver
Land use;
arable land: 13%
permanent crops: 0%
permanent pastures: 68%
forests and woodland: 5%
other: 14% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues; water pollution,
especially of lakes, from agricultural runoff
Environment - international agreements;
party to; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Biodiversity, Climate
Change, Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Endangered Species, Marine Life Conservation,
Tropical Timber 94
Geography • note; strategic location on major air
and sea routes between North America and northern
Europe; over 40% of the population resides within 97
km of Dublin
Population; 3,797,257 (July 2000 est.)
Age structure:
0-14 years: 21 .85% (male 425,795; female 403,777)
15-64 years: 66.83% (male 1 ,271 ,367; female
1,266,150)
65 years and over: 1 1 .33% (male 1 85,91 3; female
244,255) (2000 est.)
Population growth rate; 1.16% (2000 est.)
Birth rate: 14.51 births/1,000 population (2000 est.)
Death rate: 8.14 deaths/1 ,000 population
(2000 est.)
Net migration rate: 5.27 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate; 5.62 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population:76.61 years
male: 74.06 years
female: 79.74 years (2000 est.)
Total fertility rate: 1.91 children born/woman
(2000 est.)
Nationality:
noun: Irishman(men), Irishwoman(women), Irish
(collective plural)
adjective: Irish
Ethnic groups: Celtic, English
Religions: Roman Catholic 91 .6%, Church of Ireland
2.5%, other 5.9% (1998)
Languages: English is the language generally used,
Irish (Gaelic) spoken mainly in areas located along the
western seaboard
Literacy;
definition: age 15 and over can read and write
total population: 98% (1981 est.)
male: NA%
female: NA%
I GovernmenT
Country name:
conventional long form: none
conventional short form: Ireland
Data code: El
Government type: republic
Capital; Dublin
Administrative divisions: 26 counties; Carlow,
Cavan, Clare, Cork, Donegal, Dublin, Galway, Kerry,
Kildare, Kilkenny, Laois, Leitrim, Limerick, Longford,
Louth, Mayo, Meath, Monaghan, Offaly, Roscommon,
Sligo, Tipperary, Waterford, Westmeath, Wexford,
Wicklow
Independence: 6 December 1921 (from UK by
treaty)
National holiday: Saint Patrick''s Day, 17 March
Constitution: 29 December 1937; adopted 1 July
1937 by plebiscite
Legal system: based on English common law,
substantially modified by indigenous concepts; judicial
review of legislative acts in Supreme Court; has not
accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Mary MCALEESE (since 1 1
November 1997)
head of government: Prime Minister Bertie AHERN
(since 26 June 1997)
cabinet: Cabinet appointed by the president with
previous nomination by the prime minister and
approval of the House of Representatives
elections: president elected by popular vote for a
seven-year term; election last held 31 October 1 997
(next to be held NA November 2004); prime minister
nominated by the House of Representatives and
appointed by the president
election results: Mary MCALEESE elected president;
percent of vote - Mary MCALEESE 44.8%, Mary
BANOTTI 29.6%
note: government coalition - Fianna Fail and the
Progressive Democrats
Legislative branch; bicameral Parliament or
Oireachtas consists of the Senate or Seanad Eireann
(60 seats - 49 elected by the universities and from
candidates put forward by five vocational panels, 1 1
are nominated by the prime minister; members serve
five-year terms) and the House of Representatives or
Dali Eireann (16fi seats; members are elected by
popular vote on the basis of proportional
representation to serve five-year terms)
elections: Senate - last held NA August 1997 (next to
be held NA 2002); House of Representatives - last
held 6 June 1 997 (next to be held NA 2002)
election results: Senate - percent of vote by party -
Fianna Fail 29, Fine Gael 16, Labor Party 4,
Progressive Democrats 4, others 7; seats by party -
NA; House of Representatives - percent of vote by
party ■ NA; seats by party - Fianna Fail 76, Fine Gael
53, Labor Party 19, Progressive Democrats 4,
Democratic Left 4, Green Alliance 2, Sinn Fein 1,
independents 7
Judicial branch: Supreme Court, judges appointed
by the president on the advice of the government
(prime minister and cabinet)
Political parties and leaders: Communist Party of
Ireland [Michael O''RIORDANj; Democratic Left
[Proinsias DE ROSSAj; Fianna Fail [Bertie AHERN];
Fine Gael [John BRUTON]; Green Alliance [Patricia
HOWARD]; Labor Party [Ruairi QUINN]; Progressive
Democrats [Mary HARNEY]; Sinn Fein [Gerry
ADAMS]; The Workers'' Party [Marion DONNELLY]
International organization participation; Australia
Group, BIS, CCC, CE, EBRD, ECE, EIB, EMU, ESA,
EU, FAO, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM,
IDA, lEA, IFAD, IFC, IFRCS, ILO, IMF, IMO, Intelsat,
Interpol, IOC, lOM (observer), ISO, ITU, MINURSO,
NAM (guest), NEA, NSG, OECD, OPCW, OSCE, UN,
UNCTAD, UNESCO, UNFICYP, UNHCR, UNIDO,
UNIFIL, UNIKOM, UNITAR, UNMIBH, UNMIK,
UNMOP, UNTAET, UNTSO, UPU, WEU (observer),
WHO, WlPO, WMO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Sean O''HUIGINN
chancery: 2234 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] (202) 462-3939
FAX; [1] (202) 232-5993
consulate(s) general: Boston, Chicago, New York,
and San Francisco
Diplomatic representation from the US:
chief of mission: Ambassador Michael SULLIVAN
embassy: 42 Elgin Road, Ballsbridge, Dublin 4
mailing address: use embassy street address
te/eptone; [353] (1)668-71 22
FAX; [353] (1)668-9946
Flag description: three equal vertical bands of
green (hoist side), white, and orange; similar to the
flag of Cote d''Ivoire, which is shorter and has the
colors reversed - orange (hoist side), white, and
green; also similar to the flag of Italy, which is shorter
and has colors of green (hoist side), white, and red
If ~ Econo nTy
Economy - overview; Ireland is a small, modern,
trade-dependent economy with growth averaging a
robust 9% in 1995-99. Agriculture, once the most
important sector, is now dwarfed by industry, which
accounts for 39% of GDP and about 80% of exports
and employs 28% of the labor force. Although exports
remain the primary engine for Ireland''s robust growth.
241
Ireland (continued)
the economy is also benefiting from a rise in consumer
spending and recovery in both construction and
business investment. Over the past decade, the Irish
government has implemented a series of national
economic programs designed to curb inflation, reduce
government spending, and promote foreign
investment. The unemployment rate has been halved;
job creation remains a primary concern of government
policy. Recent efforts have concentrated on improving
workers'' qualifications and the education system.
Ireland joined in launching the euro currency system
in January 1999 along with 10 other EU nations. The
construction and other sectors are beginning to press
against capacity, and growth is expected to drop in
2000, perhaps by 1 percentage point.
GDP: purchasing power parity - $73.7 billion
(1999 est.)
GDP - real growth rate: 8.4% (1 999 est.)
GDP - per capita: purchasing power parity -
$20,300(1999 est.)
GDP - composition by sector:
agriculture: 5%
industry: 39%
services: 56% (1998)
Population below poverty line: 1 0% (1 997 est.)
Household income or consumption by percentage
share:
lowest 10%: 2%
highest 10%: 27.3% {1997)
Inflation rate (consumer prices): 2.2% (1999)
Labor force: 1 .77 million (1 999 est.)
Labor force - by occupation: services 63%,
industry 28%, agriculture 9% (1999 est.)
Unemployment rate: 5.5% (1999)
Budget:
revenues: $25.3 billion
expenditures: $20.9 billion, including capital
expenditures of $2 billion (1999)
Industries: food products, brewing, textiles, clothing;
chemicals, pharmaceuticals, machinery,
transportation equipment, glass and crystal; software
Industrial production growth rate: 10%
(1999 est.)
Electricity - production: 1 9.71 5 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 94.12%
hydro: 4.63%
nuclear: 0%
other: 1.25% (1998)
Electricity - consumption: 1 8.41 5 billion kWh
(1998)
Electricity - exports: 1 00 million kWh (1 998)
Electricity - imports: 180 million kWh (1998)
Agriculture - products: turnips, barley, potatoes,
sugar beets, wheat; beef, dairy products
Exports: $66 billion (f.o.b., 1999 est.)
Exports - commodities: machinery and equipment,
computers, chemicals, pharmaceuticals; live animals,
animal products
Exports - partners: EU 68% (UK 22%, Germany
15%, France 8%), US 15% (1998)
Imports: $44 billion (c.i.f., 1 999 est.)
Imports - commodities: data processing
equipment, other machinery and equipment,
chemicals; petroleum and petroleum products,
textiles, clothing
Imports - partners: EU 54% (UK 31%, Germany
6%, France 5%), US 16%, Japan 7%, Singapore 4%
(1998)
Debt - external: $11 billion (1998)
Economic aid - donor: ODA, $240 million (1999)
Currency: 1 Irish pound = 100 pence
Exchange rates: Irish pounds per US$1 - 0.9865
(January 2000), 0.9374 (1 999), 0.701 4 (1 998), 0.6588
(1997), 0.6248 (1996), 0.6235 (1995)
note: on 1 January 1999, the European Union
introduced a common currency the euro, which is now
being used at a fixed rate of 0.787564 Irish pounds per
euro; the euro has replaced the pound in many
financial and business transactions; it will replace the
local currency in consenting countries for all
transactions in 2002
Fiscal year: calendar year','811a592622bad2601b5ce4e7be0d300c97ba77b9afbf03ceb79e71b62c612fc9','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f1edfbb2f0cd84de2b5234de836e5560a9324c2a622cfa75bc4b315e154e925',2000,'TN','Tunisia','people-and-society',252,'Population: 57,634,327 (July 2000 est.)
Age structure:
0-14 years: 14% (male 4,220,973; female 3,977,962)
15-64 years: 68% (male 19,413,219; female
19,596,668)
65 years and over; 18% (male 4,297,962; female
6,127,543) (2000 est.)
Population growth rate: 0.09% (2000 est.)
Birth rate: 9.13 births/1,000 population (2000 est.)
Death rate: 9.99 deaths/1 ,000 population
(2000 est.)
Net migration rate: 1 .74 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.94 maie(s)/female (2000 est.)
Infant mortality rate: 5.92 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 79.03 years
male: 75.85 years
female: 82.41 years (2000 est.)
Total fertility rate: 1 .18 chiidren born/woman
(2000 est.)
Nationality:
noun: Italian(s)
adjective: Italian
Ethnic groups: Itaiian (inciudes small clusters of
German-, French-, and Slovene-ltalians in the north
and Albanian-ltalians and Greek-ltalians in the south)
Religions: predominateiy Roman Catholic with
mature Protestant and Jewish communities and a
growing Muslim immigrant community
Languages: Italian (official), German (parts of
T rentino-Alto Adige region are predominantly German
speaking), French (small French-speaking minority in
Valle d''Aosta region), Slovene (Slovene-speaking
minority in the Trieste-Gorizia area)
Literacy:
definition: age 15 and over can read and write
total population: 98% (1998)
male: NA%
female: NA%
Land boundaries; 0 km
Coastline; 1,022 km
Maritime claims: measured from claimed
archipeiagic baselines
continental shelf: 200-m depth or to the depth of
expioitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; temperate interior
Terrain: mostly mountains, with narrow,
discontinuous coastal plain
Elevation extremes;
lowest point: Caribbean Sea 0 m
highest point: Biue Mountain Peak 2,256 m
Natural resources: bauxite, gypsum, iimestone
Land use:
arable land: 14%
permanent crops: 3%
Population: 2,652,689 (July 2000 est.)
Age structure:
0-14 years: 30% (male 41 1 ,448; female 392,559)
15-64 years: 63% (male 832,314; female 837,133)
65 years and over: 7% (male 80,059; female 99,176)
(2000 est.)
Population growth rate: 0.46% (2000 est.)
Birth rate; 18.51 births/1,000 popuiation (2000 est.)
Death rate: 5.51 deaths/1 ,000 popuiation
(2000 est.)
Net migration rate: -8.39 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 male(s)/female (2000 est.)
Jamaica (continued)
Infant mortality rate: 14.61 cleaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 75.2''\\ years
male: 73.26 years
female: 77.26 years (2000 est.)
Total fertiiity rate: 2.1 1 children born/woman
(2000 est.)
Nationality:
noun; Jamaican(s)
ad/ecf/Ve; Jamaican
Ethnic groups: black 90.9%, East Indian 1.3%,
white 0.2%, Chinese 0.2%, mixed 7.3%, other 0.1%
Religions: Protestant 61 .3% (Church of God 21 .2%,
Baptist 8.8%, Anglican 5.5%, Seventh-Day Adventist
9%, Pentecostal 7.6%, Methodist 2.7%, United
Church 2.7%, Brethren 1 .1%, Jehovah''s Witness
1.6%, Moravian 1.1%), Roman Catholic 4%, other,
including some spiritual cults 34.7%
Languages: English, Creole
Literacy:
definition: age 15 and over has ever attended school
total population: 85%
mate: 80.8%
female: 89.1% (1995 est.)
f Govern mTii j "
Country name:
conventional long form: none
conventional short form: Jamaica
Data code: JM
Government type: constitutional parliamentary
democracy
Capital: Kingston
Administrative divisions: 14 parishes; Clarendon,
Hanover, Kingston, Manchester, Portland, Saint
Andrew, Saint Ann, Saint Catherine, Saint Elizabeth,
Saint James, Saint Mary, Saint Thomas, Trelawny,
Westmoreland
Independence: 6 August 1962 (from UK)
National holiday: Independence Day (first Monday
in August) (1962)
Constitution: 6 August 1962
Legal system: based on English common law; has
not accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Sir Howard
Felix COOKE (since 1 August 1991)
head of government: Prime Minister Percival James
PATTERSON (since 30 March 1992) and Deputy
Prime Minister Seymour MULLINGS (since NA 1993)
cabinet: Cabinet appointed by the governor general
on the advice of the prime minister
elections: none; the monarch is hereditary; governor
general appointed by the monarch on the
recommendation of the prime minister; prime minister
and deputy prime minister appointed by the governor
general
Legislative branch: bicameral Parliament consists
of the Senate (a 21 -member body appointed by the
governor general on the recommendations of the
prime minister and the leader of the opposition; ruling
party is allocated 13 seats, and the opposition is
allocated eight seats) and the House of
Representatives (60 seats; members are elected by
popular vote to serve five-year terms)
elections: last held 18 December 1997 (next to be
held by March 2002)
election results: percent of vote by party - NA; seats
by party - PNP 50, JLP 10
Judicial branch: Supreme Court, judges appointed
by the governor general on the advice of the prime
minister; Court of Appeal
Political parties and leaders: Jamaica Labor Party
or JLP [Edward SEAGA]; National Democratic
Movement or NDM [Bruce GOLDING]; People''s
National Party or PNP [P. J. PAHERSONj
Political pressure groups and leaders: New
Beginnings Movement or NBM; Rastafarians (black
religious/racial cultists, pan-Africanists)
International organization participation: ACP, C,
Caricom, CCC, CDB, ECLAC, FAO, G-15, G-19,
G-77, lADB, IAEA, IBRD, ICAO, ICFTU, ICRM, IFAD,
IFC, IFRCS, IHO (pending member), ILO, IMF, IMO,
Intelsat, Interpol, IOC, lOM (observer), ISO, ITU,
LAES, NAM, OAS, OPANAL, OPCW, UN, UN
Security Council (temporary), UNCTAD, UNESCO,
UNIDO, UPU, WCL, WFTU, WHO, WlPO, WMO,
WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Richard Leighton
BERNAL
chancery: 1520 New Hampshire Avenue NW,
Washington, DC 20036
fe/ephorre; [1 1(202) 452-0660
FAX; [1 1(202) 452-0081
consulate(s) general: Miami and New York
Diplomatic representation from the US:
chief of mission: Ambassador Stanley Louis
MCLELLAND
embassy; Jamaica Mutual Life Center, 2 Oxford
Road, 3rd floor, Kingston
mailing address: use embassy street address
telephone: [1] (809) 929-4850 through 4859
FAX; [1j (809) 926-6743
Flag description: diagonal yellow cross divides the
flag into four triangles - green (top and bottom) and
black (hoist side and outer side)
I " '' E c cTn 0 m y
Economy - overview: Key sectors in this island
economy are bauxite (alumina and bauxite account
for more than half of exports) and tourism. Since
assuming office in 1 992, Prime Minister PATTERSON
has eliminated most price controls, streamlined tax
schedules, and privatized government enterprises.
Continued tight monetary and fiscal policies have
helped slow inflation - although inflationary pressures
are mounting - and stabilize the exchange rate, but
have resulted in the slowdown of economic growth
(moving from 1.5% in 1992 to 0.5% in 1995). In 1996,
GDP showed negative growth (-1.4%) and remained
negative through 1999. Serious problems include:
high interest rates; increased foreign competition; the
weak financial condition of business in general
resulting in receiverships or closures and downsizings
of companies; the shift in investment portfolios to
non-productive, short-term high yield instruments; a
pressured, sometimes sliding, exchange rate; a
widening merchandise trade deficit; and a growing
internal debt for government bailouts to various ailing
sectors of the economy, particularly the financial
sector. Depressed economic conditions in 1 999 led to
increased civil unrest, including a mounting crime
rate. Jamaica''s medium-term prospects will depend
upon encouraging investment in the productive
sectors, maintaining a competitive exchange rate,
stabilizing the labor environment, selling off
reacquired firms, and implementing proper fiscal and
monetary policies.
GDP: purchasing power parity - $8.8 billion
(1999 est.)
GDP - real growth rate: -0.5% (1999 est.)
GDP - per capita: purchasing power parity - $3,350
(1999 est.)
GDP - composition by sector:
agriculture: 7.4%
industry: 42.1%
services: 50.5% (1997 est.)
Population below poverty line: 34.2% (1992 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.4%
highest f0%;31.9%(1991)
Inflation rate (consumer prices): 9.4% (1999 est.)
Laborforce: 1.13 million (1998)
Labor force ■ by occupation: services 60%,
agriculture 21%, industry 19% (1998)
Unemployment rate: 1 5.5% (1 998)
Budget:
revenues: $2.27 billion
expenditures: $3.66 billion, including capital
expenditures of $1 .265 billion (FY98/99 est.)
Industries: tourism, bauxite, textiles, food
processing, light manufactures, rum, cement, metal,
paper, chemical products
Industrial production growth rate: NA%
Electricity - production: 6.386 billion kWh (1998)
Electricity - production by source:
fossil fuel: 92.7%
hydro: 2.21%
nuclear: 0%
ofher; 5.09% (1998)
Electricity - consumption: 5.939 billion kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: sugarcane, bananas,
coffee, citrus, potatoes, vegetables; poultry, goats,
milk
Exports: $1.4 billion (f.o.b., 1999 est.)
Exports - commodities: alumina, bauxite, sugar,
bananas, rum
Exports - partners: US 39.5%, EU (excluding UK)
15.6%, UK 12.1%, Canada 11.5% (1998)
249
Jamaica (continued)
Imports: $2.7 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and transport
equipment, construction materials, fuel, food,
chemicals, fertilizers
Imports - partners: US 50.9%, EU (excluding UK)
9.5%, Caricom countries 10.4%, Latin America 6%
(1998)
Debt - external: $3.8 billion (1998 est.)
Economic aid - recipient: $102.7 million (1995)
Currency: 1 Jamaican dollar (J$) = 100 cents
Exchange rates: Jamaican dollars (J$) per US$1 -
41.139 (December 1999), 9.044 (1999), 36.550
(1998), 35.404 (1997), 37.120 (1996), 35.142 (1995)
Fiscal year: 1 April - 31 March','1a611e478b21dfc9e08b9a9825c2ab92bcc29263bf0d18de938ae5ea12f671d0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d138d6f7186d3c6e0152f4a0a76e72e92ddc4a1b101b7b293f0defb280e1b54',2000,'JP','Japan','people-and-society',275,'Population; 21 ,687,550 (July 2000 est.)
Age structure;
0-14 years: 26% (male 2,843,250; female 2,705,206)
15-64 years: 68% (male 7,223,364; female
7,502,094)
65 years and over: 6% (male 448,242; female
965,394) (2000 est.)
Population growth rate; 1 .35% (2000 est.)
Birth rate; 20.43 births/1 ,000 population (2000 est.)
Death rate; 6.88 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.46 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate; 24.29 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 70.74 years
male: 67.76 years
female: 73.86 years (2000 est.)
Total fertility rate; 2.3 children born/woman
(2000 est.)
Nationality;
noun: Korean(s)
adjective: Korean
Ethnic groups; racially homogeneous; there is a
small Chinese community and a few ethnic Japanese
Religions; traditionally Buddhist and Confucianist,
some Christian and syncretic Chondogyo (Religion of
the Heavenly Way)
note: autonomous religious activities now almost
nonexistent; government-sponsored religious groups
exist to provide illusion of religious freedom
Languages; Korean
Literacy;
definition: age 1 5 and over can read and write Korean
total population: 99%
mate: 99%
female: 99% (1990 est.)
Population: 47,470,969 (July 2000 est.)
Age structure:
0-14 years: 22% (male 5,471 ,520; female 4,867,688)
15-64 years: 71% (male 17,155,401; female
16,662,227)
65 years and over: 7% (male 1 ,274,943; female
2,039,190) (2000 est.)
Population growth rate: 0.93% (2000 est.)
Birth rate: 15.12 births/1,000 population (2000 est.)
Death rate: 5.85 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1.13 male(s)/female
under 15 years: 1 .12 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 1 .01 male(s)/female (2000 est.)
Infant mortality rate: 7.85 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 74.43 years
male: 70.75 years
female: 78.54 years (2000 est.)
Total fertility rate: 1.72 children born/woman
(2000 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: homogeneous (except for about
20,000 Chinese)
Religions: Christian 49%, Buddhist 47%,
Confucianist 3%, Shamanist, Chondogyo (Religion of
the Heavenly Way), and other 1%
Languages: Korean, English widely taught in junior
high and high school
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99.3%
female: 96.7% (1995 est.)','ae9877af9648d8283701f132ebaad96f39bcd769b0ef21ba8dfe6a40d0d718fa','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad649f38dc23ba21bb3b3819c6f48bb93b97f62ab16a50b107a8bbaf51cf6d70',2000,'CN','China','people-and-society',283,'total: 3,878 km
border countries: China 858 km, Kazakhstan 1 ,051
km, Tajikistan 870 km, Uzbekistan 1 ,099 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: dry continental to polar in high Tien Shan;
subtropical in southwest (Fergana Valley); temperate
in northern foothill zone
Terrain: peaks of Tien Shan and associated valleys
and basins encompass entire nation
Elevation extremes:
lowest point: Kara-Darya 132 m
highest point: Jengish Chokusu (Pik Pobedy) 7,439 m
Natural resources: abundant hydropower;
significant deposits of gold and rare earth metals;
locally exploitable coal, oil, and natural gas; other
deposits of nepheline, mercury, bismuth, lead, and
zinc
Population: 4,685,230 (July 2000 est.)
Age structure:
0-14 years: 36% (male 843,038; female 825,51 9)
15-64 years: 58% (male 1 ,337,268; female
1,393,397)
65 years and over: 6% (male 1 07,405; female
178,603) (2000 est.)
Population growth rate: 1 .43% (2000 est.)
Birth rate: 26.29 births/1 ,000 population (2000 est.)
Death rate; 9.15 deaths/1 ,000 population
(2000 est.)
Net migration rate: -2.81 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.6 male(s)/female
Kyrgyzstan (continued)
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 77.08 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 63.37 years
male: 59.06 years
female: 67.9 years (2000 est.)
Total fertility rate: 3.22 children born/w/oman
(2000 est.)
Nationality:
noun: Kyrgyzstani(s)
adjective: Kyrgyzstan!
Ethnic groups: Kirghiz 52.4%, Russian 1 8%, Uzbek
12.9%, Ukrainian 2.5%, German 2.4%, other 11.8%
Religions: Muslim 75%, Russian Orthodox 20%,
other 5%
Languages: Kirghiz (Kyrgyz) - official language,
Russian - official language
note; in March 1996, the Kyrgyzstani legislature
amended the constitution to make Russian an official
language, along with Kirghiz, in territories and work
places where Russian-speaking citizens predominate
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 99%
female: 95% (^989 est.)
Population; 3,578,036 (July 2000 est.)
Age structure;
0-14years:28% (male 508,936; female 489,122)
15-64 years: 65% (male 1,11 5,457; female
1,226,448)
65 years and over: 7% (male 1 08,706; female
129,367) (2000 est.)
Population growth rate; 1 .38% (2000 est.)
Birth rate; 20.26 births/1 ,000 population (2000 est.)
Death rate; 6.42 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.84 male(s)/female
total populatbn: 0.94 maie(s)/female (2000 est.)
Infant mortality rate; 29.3 deafhs/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 71 .25 years
male: 68.87 years
female: 73.74 years (2000 est.)
Total fertility rate; 2.08 children born/woman
(2000 est.)
Nationality;
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic groups; Arab 95%, Armenian 4%, other 1%
Religions; Muslim 70% (5 legally recognized Islamic
groups - Shi''a, Sunni, Druze, Isma''ilite, Alawite or
Nusayri), Christian 30% (11 legally recognized
Christian groups - 4 Orthodox Christian, 6 Catholic, 1
Protestant), Jewish NEGL%
Languages; Arabic (official), French, English,
Armenian widely understood
Literacy;
definition: age 15 and over can read and write
total population: 86.4%
male: 90.8%
female: 82.2% (1997 est.)
Population: 6,409
note: an estimated 8,000 refugees left the island
following the resumption of volcanic activity in July
1995; some have returned (July 2000 est.)
Age structure;
0-14 years: 24.23% (male 778; female 775)
15-64 years: 64.25% (male 1,969; female 2,149)
65 years and over: 1 1 .52% (male 395; female 343)
(2000 est.)
Population growth rate: 20.53% (2000 est.)
Birth rate: 17.48 births/1,000 population (2000 est.)
Death rate: 7.49 deaths/1 ,000 population
(2000 est.)
Net migration rate: 1 95.35 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .04 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 1.15 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 9.1 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 77.96 years
male: 75.78 years
female: 80.23 years (2000 est.)
Total fertility rate: 1 .85 children born/woman
(2000 est.)
Nationality:
noun: l\\/lontserratian(s)
adjective: Montserratian
Ethnic groups; black, white
Religions: Anglican, Methodist, Roman Catholic,
Pentecostal, Seventh-Day Adventist, other Christian
denominations
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
female: 97% (1970 est.)','3a89d8ad1824a3557576f5b35dca90aaa05a3aa447e2ad559db4432d9bbc40c8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5322cf40570583551a8e6f3f0f4a562db413f0f04f410c3e7379e237f1fe098d',2000,'ZA','South Africa','people-and-society',291,'Population: 3,164,156 (July 2000 est.)
Age structure:
0-14 years: 43% (male 681,136; female 680,501)
15-64 years: 54% (male 826,751 ; female 867,402)
65 years and over: 3% (male 54,334; female 54,032)
(2000 est.)
Population growth rate: 1.94% (2000 est.)
Birth rate: 47,22 births/1 ,000 population (2000 est.)
Death rate: 1 6.58 deaths/1 ,000 population
(2000 est.)
Net migration rate: -1 1 .22 migrant(s)/1 ,000
population (2000 est.)
note: by the end of 1999, all Liberian refugees, who
had fled the domestic strife, were assumed to have
returned
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 1 .01 male(s)/female
total population: OM male(s)/female (2000 est.)
Infant mortality rate: 134.63 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 51 .02 years
male: 49.6 years
female: 52.49 years (2000 est.)
Total fertility rate: 6.43 children born/woman
(2000 est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic groups: indigenous African tribes 95%
(including Kpelle, Bassa, Gio, Kru, Grebo, Mano,
Krahn, Gola, Gbandi, Loma, Kissi, Vai, and Bella),
Americo-Liberians 2.5% (descendants of immigrants
from the US who had been slaves), Congo People
2.5% (descendants of immigrants from the Caribbean
who had been slaves)
Religions: indigenous beliefs 40%, Christian 40%,
Muslim 20%
Languages: English 20% (official), some 20 ethnic
group languages, of which a few can be written and
are used in correspondence
Literacy:
definition: age 1 5 and over can read and write
totai popuiation: 38.3%
male: 53.9%
female: 22.4% (1 995 est.)
note: these figures are increasing because of the
improving school system
Population; 43,421,021
note: South Africa took a census October 1 996 which
showed a population of 40,583,61 1 (after an official
adjustment for a 6.8% underenumeration based on a
post-enumeration survey); estimates for this country
explicitly take into account the effects of excess
mortality due to AIDS; this can result in lower life
expectancy, higher infant mortality and death rates,
lower population and growth rates, and changes in the
distribution of population by age and sex than would
otherwise be expected (July 2000 est.)
Age structure;
0-14 years: 32.46% (male 7,094,756; female
6,999,009)
15-64 years: 62.76% (male 1 3,1 1 1 ,457; female
14,139,372)
55 years and over: 4.78% (male 782,397; female
1,294,030) (2000 est.)
Population growth rate: 0.5% (2000 est.)
3irth rate: 24.56 births/1 ,000 population (2000 est.)
}eath rate: 14.69 deaths/1 ,000 population
2000 est.)
Jet migration rate: -1 .9 migrant(s)/1 ,000 population
2000 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 58.88 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 51.1 years
male: 50.41 years
female: 51 .81 years (2000 est.)
Total fertility rate: 2.47 children bom/woman
(2000 est.)
Nationality:
noun: South African(s)
adjective: South African
Ethnic groups: black 75.2%, white 13.6%, Colored
8.6%, Indian 2.6%
Religions: Christian 68% (includes most whites and
Coloreds, about 60% of blacks and about 40% of
Indians), Muslim 2%, Hindu 1.5% (60% of Indians),
indigenous beliefs and animist 28.5%
Languages; 1 1 official languages, including
Afrikaans, English, Ndebele, Pedi, Sotho, Swazi,
Tsonga, Tswana, Venda, Xhosa, Zulu
Literacy;
definition: age 1 5 and over can read and write
total population: 81. 8%
male: 81 ,9%
fema/e; 81 .7% (1995 est.)
i Government
Country name;
conventional long form: Republic of South Africa
conventional short form: South Africa
abbreviation: RSA
Data code; SF
Government type: republic
Capital; Pretoria; note - Cape Town is the legislative
center and Bloemfontein the judicial center
Administrative divisions; 9 provinces; Eastern
Cape, Free State, Gauteng, KwaZulu-Natal,
Mpumalanga, North-West, Northern Cape, Northern
Province, Western Cape
Independence: 31 May 1910 (from UK)
National holiday: Freedom Day, 27 April (1994)
Constitution: 10 December 1996; this new
constitution was certified by the Constitutional Court
on 4 December 1 996, was signed by then President
MANDELA on 10 December 1996, and entered into
effect on 3 February 1997; it is being implemented in
phases
Legal system: based on Roman-Dutch law and
English common law; accepts compulsory ICJ
jurisdiction, with reservations
Suffrage: 18 years of age; universal
Executive branch;
chief of state: President Thabo MBEKI (since 1 6 June
1999); Executive Deputy President Jacob ZUMA
(since 17 June 1999); note - the president is both the
chief of state and head of government
head of government: President Thabo MBEKI (since
16 June 1999); Executive Deputy President Jacob
ZUMA (since 17 June 1999); note - the president is
both the chief of state and head of government
cabinet: Cabinet appointed by the president
elections: president elected by the National Assembly
for a five-year term; election last held 2 June 1 999
(next scheduled for sometime between May and July
2004)
election results: Thabo MBEKI elected president;
percent of National Assembly vote - 100% (by
acclamation)
note: ANC-IFP governing coalition
Legislative branch: bicameral parliament
consisting of the National Assembly (400 seats;
members are elected by popular vote under a system
of proportional representation to serve five-year
terms) and the National Council of Provinces (90
seats, 10 members elected by each of the nine
provincial legislatures for five-year terms; has special
powers to protect regional interests, including the
safeguarding of cultural and linguistic traditions
among ethnic minorities); note - following the
implementation of the new constitution on 3 February
1997 the former Senate was disbanded and replaced
by the National Council of Provinces with essentially
no change in membership and party affiliations,
although the new institution''s responsibilities have
been changed somewhat by the new constitution
elections: National Assembly and National Council of
Provinces - last held 2 June 1 999 (next to be held NA
2004)
election results: National Assembly - percent of vote
by party - ANC 66.4%, DP 9.6%, IFP 8.6%, NP 6.9%,
UDM 3.4, FF 0.8%, other 4.3%; seats by party - ANC
266, DP 38, IFP 34, NP 28, UDM 14, FF 3, other 17;
National Council of Provinces - percent of vote by
party - NA; seats by party - ANC 61 , NP 17, FF 4, IFP
5, DP 3
Judicial branch: Constitutional Court; Supreme
Court of Appeals; High Courts; Magistrate Courts
Political parties and leaders: African Christian
Democratic Party or ACDP [Kenneth MESHOE,
president]; African National Congress or ANC [Thabo
MBEKI, president]; Democratic Party or DP [Tony
LEON, president]; Freedom Front or FF [Constand
VILJOEN, president]; Inkatha Freedom Party or IFP
[Mangosuthu BUTHELEZI, president]; National Party
(now the New National Party) or NP [Marthinus VAN
SCHALKWYK, executive director]; Pan-Africanist
Congress or PAC [Stanley MOGOBA, president];
United Democratic Movement or UDM [Bantu
HOLOMISA]
Political pressure groups and leaders: Congress
of South African Trade Unions or COSATU
[Zwelinzima VAVI, general secretary]; South African
Communist Party or SACP [Blade NZIMANDE,
general secretary]; South African National Civics
Organization or SANCO [Mlungisi HLONGWANE,
national president]; note - COSATU and SACP are in
a formal alliance with the ANC
457
South Africa (continued)
International organization participation; AGP,
AfDB, BiS, C, CCC, EGA, FAO, G-77, IAEA, IBRD,
IGAO, IGG, IGFTU, IGRM, IDA, IFAD, IFG, IFRGS,
IHO, ILO, IMF, IMG, Inmarsat, Intelsat, Interpol, lOG,
lOM, ISO, ITU, MONUG, NAM, NSG, OAU, OPGW,
PGA, SAGU, SADG, UN, UNGTAD, UNESGO,
UNHGR, UNITAR, UPU, WFTU, WHO, WlPO, WMO,
WToO, WTrO, ZG
Diplomatic representation in the US:
chief of mission: Ambassador Makate Sheila SISULU
chancery: 3051 Massachusetts Avenue NW,
Washington, DG 20008
telephone: [1] (202} 232-4400
FAX; [1] (202) 265-1607
consulate(s) general: Ghicago, Los Angeles, and New
York
Diplomatic representation from the US;
c/i/ef of m;ss/on; Ambassador Delano E. LEWIS
embassy: 877 Pretorlus Street, Arcadia 0083
mailing address: P. 0. Box 9536, Pretoria 0001
fe/epfione; [27] (12) 342-1048
FAX; [27] (12) 342-2244
consulate(s) general: Gape Town, Durban,
Johannesburg
Flag description; two equal width horizontal bands
of red (top) and blue separated by a central green
band which splits Into a horizontal Y, the arms of
which end at the corners of the hoist side; the Y
embraces a black Isosceles triangle from which the
arms are separated by narrow yellow bands; the red
and blue bands are separated from the green band
and Its arms by narrow white stripes
note: prior to 26 April 1 994, the flag was actually four
flags in one - three miniature flags reproduced in the
center of the white band of the former flag of the
Netherlands, which has three equal horizontal bands
of orange (fop), white, and blue; the miniature flags
are a vertically hanging flag of the old Orange Free
State with a horizontal flag of the UK adjoining on the
hoist side and a horizontal flag of the old Transvaal
Republic adjoining on the other side
Population: no indigenous inhabitants
note: there is a small military garrison on South
Georgia, and the British Antarctic Survey has a
biological station on Bird Island; the South Sandwich
Islands are uninhabited (July 2000 est.)','68618bfd68a607aa79ea8face42ac7f52431fabf1b5d856058f9ba70323dca50','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ce5c5deb73602d4f6e65a6b09a21eb46e85985e9d6e277f2f7a22b3179be4aa',2000,'DE','Germany','people-and-society',307,'Population: 15,506,472 (July 2000 est.)
Age structure:
0-14 years: 45% (male 3,504,562; female 3,481 ,056)
15-64 years: 52% (male 3,964,564; female
4,052,056)
65 years and over: 3% (male 237,691 ; female
266,543) (2000 est.)
Population growth rate: 3.02% (2000 est.)
Birth rate: 42.92 births/1 ,000 population (2000 est.)
Death rate: 12.69 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate: 85.26 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 54.95 years
male: 52.71 years
female: 57.26 years (2000 est.)
Total fertility rate: 5.84 children born/woman
(2000 est.)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic groups: Malayo-Indonesian (Merina and
related Betsileo), Cotiers (mixed African,
Malayo-Indonesian, and Arab ancestry -
Betsimisaraka, Tsimihety, Antaisaka, Sakalava),
French, Indian, Creole, Comoran
Religions: indigenous beliefs 52%, Christian 41%,
Muslim 7%
Languages: French (official), Malagasy (official)
Literacy:
definition: age 15 and over can read and write
total population: 80%
male: 88%
female: 73% (1990 est.)','d63de66017cff43a6bbe8dc766194c8e9b045965f654b641c88dd43cda9ebc45','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f52c7d1f716f2d58bd961213e65e45aa4cabc6f21e3a45fcbb2878c9828835f',2000,'MY','Malaysia','people-and-society',310,'Population: 21 ,793,293 (July 2000 est.)
Age structure:
0-14 years: 35% (male 3,914,1 12; female 3,697,731)
15-64 years: 61% (male 6,655,506; female
6,642,073)
65 years and over: 4% (male 386,387; female
497,484) (2000 est.)
Population growth rate: 2.01% (2000 est.)
Birth rate: 25.3 births/1 ,000 population (2000 est.)
Death rate: 5.25 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2000 est.)
note: does not reflect net flow of an unknown number
of illegal immigrants from other countries in the region
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1.01 male(s)/female (2000 est.)
Infant mortality rate: 20.96 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 70.83 years
male: 68.22 years
female: 73.63 years (2000 est.)
Total fertility rate: 3.29 children born/woman
(2000 est.)
Nationality:
noun: Malaysian(s)
adjective: Malaysian
Ethnic groups: Malay and other indigenous 58%,
Chinese 26%, Indian 7%, others 9%
Religions; Islam, Buddhism, Daoism, Hinduism,
Christianity, Sikhism; note - in addition. Shamanism is
practiced in East Malaysia
Languages: Bahasa Melayu (official), English,
Chinese dialects (Cantonese, Mandarin, Hokkien,
Hakka, Hainan, Foochow), Tamil, Telugu, Malayalam,
Panjabi, Thai; note - in addition, in East Malaysia
several indigenous languages are spoken, the largest
of which are Iban and Kadazan
Literacy:
definition: age 15 and over can read and write
total population: 83.5%
male: 69.1%
fema/e; 78.1% (1995 est.)','d221e4a74bd53cf0fb775777f7a91b59323d50e4a7a531417e3141627b5e0b42','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d2a2278e6a4706953cae280baf302dd062123e4ae47d5f4667579b91b87bd24',2000,'MH','Marshall Islands','people-and-society',323,'Population: 68,126 (July 2000 est.)
Age structure:
0-14years:50% (male 17,204; female 16,521)
15-64 years: 48% (male 1 6,826; female 1 6,1 1 1 )
65 years and over: 2% (male 693; female 771 )
(2000 est.)
Population growth rate: 3.88% (2000 est.)
Birth rate: 45.17 births/l ,000 population (2000 est.)
Death rate: 6.4 deaths/1 ,000 population (2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1 .04 male(s)/female (2000 est.)
Infant mortality rate: 40.95 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 65.5 years
male: 63.72 years
female: 67.36 years (2000 est.)
Total fertility rate: 6.61 children born/woman
(2000 est.)
Nationality;
noun: Marshallese (singular and plural)
adjective: Marshallese
Ethnic groups: Micronesian
Religions: Christian (mostly Protestant)
Languages; English (universally spoken and is the
official language), two major Marshallese dialects
from the Malayo-Polynesian family, Japanese
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 100%
female: 88% (1980 est.)
316
Marshall Islands (continued)
I Go V e r n m e n t
Country name:
conventional long form: Republic of the Marshall
Islands
conventional short form: Marshall Islands
former: Marshall Islands District (Trust Territory of the
Pacific Islands)
Data code: RM
Government type: constitutional government in free
association with the US; the Compact of Free
Association entered into force 21 October 1986
Capital: Majuro
Administrative divisions: 33 municipalities;
Ailinginae, Ailinglaplap, Ailuk, Arno, Aur, Bikar, Bikini,
Bokak, Ebon, Enewetak, Erikub, Jabat, Jaluit, Jemo,
Kill, Kwajalein, Lae, Lib, Likiep, Majuro, Maloelap,
Mejit, Mill, Namorik, Namu, Rongelap, Rongrik, Toke,
Ujae, Ujelang, Utirik, Wotho, Wotje
Independence: 21 October 1986 (from the
US-administered UN trusteeship)
National holiday: Proclamation of the Republic of
the Marshall Islands, 1 May (1979)
Constitution: 1 May 1979
Legal system: based on adapted Trust Territory
laws, acts of the legislature, municipal, common, and
customary laws
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Kessai Hesa NOTE (since 3
January 2000); note - the president is both the chief of
state and head of government
head of government: President Kessai Hesa NOTE
(since 3 January 2000); note - the president is both
the chief of state and head of government
cabinet: Cabinet selected by the president from
among the members of Parliament
elections: president elected by Parliament from
among its own members for a four-year term; election
last held 15 November 1999 (next to be held NA
November 2003)
election results: Kessai Hesa NOTE elected
president; percent of Parliament vote - 100%
Legislative branch: unicameral Parliament or
Nitijela (33 seats; members elected by popular vote to
serve four-year terms)
elections: last held NA November 1 999 (next to be
held NA November 2003)
election results: percent of vote by party - NA; seats
by party - NA
/70fe;the Council of Chiefs is a 12-member body that
advises on matters affecting customary law and
practice
Judicial branch: Supreme Court; High Court
Political parties and leaders: traditionally there
have been no formally organized political parties;
what has existed more closely resembles factions or
interest groups because they do not have party
headquarters, formal platforms, or party structures;
the following two "groupings" have competed in
legislative balloting in recent years - Kabua Party
[Imata KABUA] and United Democratic Party or UDP
[Litokwa TOMLING]
International organization participation: AsDB,
ESCAP, G-77, IAEA, IBRD, ICAO, IDA, IFC, IMF,
IMO, Inmarsat, Intelsat (nonsignatory user), Interpol,
ITU, OPCW, Sparteca, SPC, SPF, UN, UNCTAD,
UNESCO, WHO
Diplomatic representation in the US:
chief of mission: Ambassador Banny DE BRUM
chancery: 2433 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [t] {202) 234-5414
FAX; [11(202)232-3236
consulate(s) general: Honolulu
Diplomatic representation from the US:
c/i/efofrrr/ss/on; Ambassador Joan M. PLAISTED
embassy: Oceanside, Mejen Weto, Long Island,
Majuro
mailing address: P. 0. Box 1379, Majuro, Republic of
the Marshall Islands 96960-1379
telephone: [692] 247-401 1
FAX; [692] 247-4012
Flag description: blue with two stripes radiating
from the lower hoist-side comer - orange (top) and
white; there is a white star with four large rays and 20
small rays on the hoist side above the two stripes
Economy - overview: US Government assistance is
the mainstay of this tiny island economy. Agricultural
production is concentrated on small farms, and the
most important commercial crops are coconuts,
tomatoes, melons, and breadfruit. Small-scale
industry is limited to handicrafts, fish processing, and
copra. The tourist industry, now a small source of
foreign exchange employing less than 10% of the
labor force, remains the best hope for future added
income. The islands have few natural resources, and
imports far exceed exports. Under the terms of the
Compact of Free Association, the US provides
roughly $65 million in annual aid. Negotiations were
underway in 1999 for an extended agreement.
Government downsizing, drought, a drop in
construction, and the decline in tourism and foreign
investment due to the Asian financial difficulties
caused GDP to fall in 1996-98.
GDP: purchasing power parity - $105 million
(1998 est.), supplemented by approximately $65
million annual US aid
GDP - real growth rate: -5% (1998 est.)
GDP - per capita: purchasing power parity - $1 ,670
(1998 est.)
GDP - composition by sector:
agriculture: t5%
industry: 13%
services: 72% (1995)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 5% (1997)
Labor force: NA
Labor force - by occupation; agriculture NA%,
industry NA%, services NA%
Unemployment rate: 16% (1991 est.)
Budget;
reverrues; $80.1 million
expenditures: $77.4 miilion, including capital
expenditures of $19.5 million (FY95/96 est.)
Industries: copra, fish, tourism, craft items from
shell, wood, and pearls, offshore banking (embryonic)
Industrial production growth rate; NA%
Electricity - production: 57 million kWh (1994)
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: 57 million kWh (1994)
Electricity - exports: 0 kWh (1 994)
Electricity - imports; 0 kWh (1994)
Agriculture - products: coconuts, cacao, taro,
breadfruit, fruits; pigs, chickens
Exports; $28 million (f.o.b., 1997 est.)
Exports - commodities: fish, coconut oil, fish,
trochus shells
Exports - partners; US, Japan, Australia
Imports: $58 million (f.o.b., 1997 est.)
Imports ■ commodities: foodstuffs, machinery and
equipment, fuels, beverages and tobacco
Imports - partners: US, Japan, Australia, NZ,
Guam, Singapore
Debt - external; $125 million (FY96/97 est.)
Economic aid ■ recipient: approximately $65
million annually from the US
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates; US currency Is used
Fiscal year: 1 October - 30 September
I" Comniunications~"
Telephones - main lines in use; 3,000 (1994)
Telephones - mobile cellular; 280 (1994)
Telephone system; telex services
domestic: Majuro Atoll and Ebeye and Kwajalein
islands have regular, seven-digit, direct-dial
telephones; other islands interconnected by
shortwave radiotelephone (used mostly for
government purposes)
international: satellite earth stations - 2 Intelsat
(Pacific Ocean); US Government satellite
communications system on Kwajalein
Radio broadcast stations; AM 3, FM 4, shortwave
0(1998)
Radios: NA
Television broadcast stations: 3 (of which two are
US military stations) (1997)
Televisions: NA
Internet Service Providers (ISPs); NA
317
Marshall Islands (continued)
Population: 414,516 (July 2000 est.)
Age structure:
0-14 years: 23% (male 48,578; female 47,283)
15-64 years: 07% (male 137,724; female 139,241)
65 years and over: 10% (male 18,508; female
23,182) (2000 est.)
Population growth rate: 0.96% (2000 est.)
Birth rate: 16.1 births/1,000 population (2000 est.)
Death rate: 6.38 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.09 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 7.97 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.25 years
male: 79.03 years
female: 77.46 years (2000 est.)
Total fertility rate: 1 .8 children born/woman
(2000 est.)
Nationality:
noun: Martiniquais (singular and plural)
adjective: Martiniquais
Ethnic groups: African and African-white-Indian
mixture 90%, white 5%, East Indian, Lebanese,
Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 5%
Languages: French, Creole patois
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 92%
female: 93% [1982 est.)','3fd7b2d76a3ea14b39bb43f85c7aeaac037b120020cae7b0f8326de6e34d3341','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c3efce562165eb24759715e43d059fc9210d9527dec96c3b592d7812735c05d',2000,'MR','Mauritania','people-and-society',334,'Population: 1,179,368 (July 2000 est.)
Age structure:
0-14 years: 26% (male 153,385; female 149,451)
15-64 years: 68% (male 401 ,032; female 403,295)
65 years and over: 6% (male 28,981 ; female 43,224)
(2000 est.)
Population growth rate: 0.89% (2000 est.)
Birth rate: 16.66 births/1 ,000 population (2000 est.)
Death rate: 6.83 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.93 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 1 7.73 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 70.98 years
male: 66.98 years
female: 75.04 years (2000 est.)
Total fertility rate: 2.02 children born/woman
(2000 est.)
Nationality;
noun: Mauritian(s)
adjective: Mauritian
Ethnic groups: Indo-Mauritian 68%, Creole 27%,
Sino-Mauritian 3%, Franco-Mauritian 2%
Religions: Hindu 52%, Christian 28.3% (Roman
Catholic 26%, Protestant 2.3%), Muslim 16.6%, other
3.1%
Languages: English (official). Creole, French, Hindi,
Urdu, Hakka, Bojpoori
Literacy:
definition: age 15 and over can read and write
total population: 82.9%
male: 37.1%
female: 78.8% (1995 est.)
322
Mauritius (continued)
I Government
r.
Country name;
conventional long form: Republic of Mauritius
conventional short form: Mauritius
Data code: MP
Government type: pariiamentary democracy
Capital; Port Louis
Administrative divisions: 9 districts and 3
dependencies*; Agaiega Islands*, Black River,
Cargados Carajos Shoals*, Flacq, Grand Port, Moka,
Pamplemousses, Plaines Wilhems, Port Louis,
Riviere du Rempart, Rodrigues*, Savanne
Independence; 12 March 1968 (from UK)
National holiday: Independence Day, 12 March
(1968)
Constitution: 12 March 1968; amended 12 March
1992
Legal system: based on French civil law system
with elements of English common law in certain areas
Suffrage; 1 8 years of age; universal
Executive branch:
chief of state: President Cassam UTEEM (since 1
July 1992) and Vice President Angidi Verriah
CHETTIAR (since 28 June 1997)
head of government: Prime Minister Navinchandra
RAMGOOLAM (since 27 December 1995)
cabinet: Council of Ministers appointed by the
president on the recommendation of the prime
minister
elections: president and vice president elected by the
National Assembly for five-year terms; election last
held 28 June 1997 (next to be held NA 2002); prime
minister and deputy prime minister appointed by the
president and are responsible to the National
Assembly
election results: Cassam UTEEM reelected president
and Angidi Verriah CHETTIAR elected vice president;
percent of vote by the National Assembly - NA
Legislative branch; unicameral National Assembly
(66 seats - 62 elected by popular vote, 4 appointed by
the election commission from the losing political
parties to give representation to various ethnic
minorities; members serve five-year terms)
elections: last held on 20 December 1995 (next to be
held by December 2000)
election results: percent of vote by party - MLP/MMM
65%, MSM/MMR 20%, other 15%; seats by party -
MLR 35, MMM 25, allies of MLR and MMM on
Rodrigues Island 2; appointed were Rodrigues
Movement 2, RMSD 1 , Hizbuilah 1
Judicial branch: Supreme Court
Political parties and leaders: Hizbullah [Cehl
Mohamed FAKEEMEEAH]; Mauritian Labor Rarty or
MLR [Navinchandra RAMGOOLAM] - governing
party; Mauritian Militant Movement or MMM [Raul
BERENGERj; Mauritian Militant Renaissance or MMR
[Dr. Raramhansa NABABSINGj; Mauritian Social
Democrat Rarty or RMSD [Xavier-Luc DUVAL];
Militant Socialist Movement or MSM [Sir Anerood
JUGNAUTH]; Organization of the Reopie of
Rodrigues orORR [Louis Serge CLAIR]; Rodrigues
Movement [Nicholas Von MALLY]
Political pressure groups and leaders: various
labor unions
International organization participation: ACCT,
ACP, AfDB, C, CCC, ECA, FAO, G-77, IAEA, IBRD,
ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS, ILO,
IMF, IMO, Inmarsat, InOC, Intelsat, Interpol, IOC,
ISO, ITU, NAM, OAU, OPCW, RCA, SADC, UN,
UNCTAD, UNESCO, UNIDO, URU, lA/CL, WFTU,
WHO, WIRO, WMO, WToO, VI/TrO
Diplomatic representation in the US:
chief of mission: Ambassador Chitmansing
JESSERAMSiNG
chancery: Suite 441 , 4301 Connecticut Avenue NW,
Washington, DC 20008
telephone: [1] (202) 244-1491, 1492
FAX: [1] (202) 966-0983
Diplomatic representation from the US:
chief of mission: Ambassador Mark W. ERWIN
embassy; 4th Floor, Rogers House, John Kennedy
Street, Port Louis
mailing address: international mail: P. 0. Box 544,
Port Louis; US mail: American Embassy, Port Louis,
Department of State, Washington, DC 20521-2450
telephone: [230] 208-2347, 208-2354, 208-9763
through 9767
FAX; [230] 208-9534
Flag description: four equal horizontal bands of red
(top), blue, yellow, and green
F
Economy - overview: Since independence in 1 968,
Mauritius has developed from a low income,
agriculturally based economy to a middle income
diversified economy with growing industrial, financial,
and tourist sectors. For most of the period, annual
growth has been of the order of 5% to 6%. This
remarkable achievement has been reflected In
increased life expectancy, lowered infant mortality,
and a much improved infrastructure. Sugarcane is
grown on about 90% of the cultivated land area and
accounts for 25% of export earnings. A record-setting
drought severely damaged the sugar crop in 1 999,
however. The government''s development strategy
centers on foreign investment. Mauritius has attracted
more than 9,000 offshore entities, many aimed at
commerce in India and South Africa, and investment
in the banking sector alone has reached over $1
billion. Economic performance in 1991-99 continued
strong with solid growth and low unemployment.
GDP: purchasing power parity - $12.3 biliion
(1999 est.)
GDP - real growth rate: 4% (1999 est.)
GDP - per capita: purchasing power parity -
$10,400(1999 est.)
GDP - composition by sector:
agriculture: 10%
Industry: 29%
serv/ces; 61% (1996)
Population below poverty line: 10.6% (1992 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: HA%
Inflation rate (consumer prices): 6.8% (1999)
Labor force: 514,000(1995)
Labor force - by occupation: construction and
industry 36%, services 24%, agriculture and fishing
14%, trade, restaurants, hotels 16%, transportation
and communication 7%, finance 3% (1995)
Unemployment rate: 2% (1996 est.)
Budget:
revenues; $1.1 billion
expenditures: $1 .2 biliion, including capital
expenditures of $NA (1999 est.)
Industries; food processing (largely sugar milling),
textiles, clothing; chemicals, metal products, transport
equipment, nonelectrical machinery; tourism
Industrial production growth rate: 3.5%
(1999 est.)
Electricity - production: 1 .225 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 91.84%
hydro: 8.18%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 1 .139 billion kWh (1998)
Electricity - exports; 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture ■ products; sugarcane, tea, corn,
potatoes, bananas, pulses; cattle, goats; fish
Exports; $1.7 billion (f.o.b,, 1999)
Exports - commodities: clothing and textiles,
sugar, cut flowers, molasses
Exports - partners: UK 32%, France 1 9%, US 1 4%,
Germany 6%, Italy 4% (1997)
Imports: $2.1 billion (f.o.b., 1998)
Imports ■ commodities: manufactured goods,
capital equipment, foodstuffs, petroleum products,
chemicals (1996)
Imports - partners: France 1 9%, South Africa 1 2%,
India 9%, Hong Kong 7%, UK 6% (1997)
Debt - external: $1 .9 billion (1 998 est.)
Economic aid - recipient: $42 million (1997)
Currency: 1 Mauritian rupee (MauR) = 100 cents
Exchange rates: Mauritian rupees (MauRs) per
US$1 - 25.485 (January 2000), 25.1 86 (1 999), 22.993
(1998), 21.057 (1997), 17.948 (1996), 17.386 (1995)
Fiscal year: 1 July - 30 June
|r ~ ~^C 0 m m u n i c a t i 0 n s
Telephones - main lines in use; 148,000 (1995)
Telephones - mobile cellular: 1 1 ,735 (1 995)
Telephone system: small system with good service
domestic: primarily microwave radio relay
international: satellite earth station - 1 1ntelsat (Indian
Ocean); new microwave link to Reunion; HF
radiotelephone links to several countries
Radio broadcast stations; AM 5, FM 9, shortwave
2(1998)
Radios: 420,000(1997)
Television broadcast stations: 2 (plus 1 1
repeaters) (1997)
Televisions: 258,000(1997)
Internet Service Providers (ISPs): 1 (1999)
323
Mauritius (continued)
Population: 9,987,494 (July 2000 est.)
Age structure:
0-14 years: 45% (male 2,237,678; female 2,213,632)
15-64 years: 52% (male 2,501 ,649; female
2,729,412)
65 years and over: 3% (male 152,236; female
152,887) (2000 est.)
Population growth rate: 2.94% (2000 est.)
Birth rate: 37.94 births/1 ,000 population (2000 est.)
Death rate: 8.57 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 1 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate: 58.08 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 62.1 9 years
male: 60.6 years
female: 63.82 years (2000 est.)
Total fertility rate: 5.21 children born/woman
(2000 est.)
Nationality:
noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic groups: Wolof 43.3%, Pular 23.8%,
Serer 14.7%, Jola 3.7%, Mandinka 3%,
Soninke 1.1%, European and Lebanese 1%,
other 9.4%
Religions: Muslim 92%, indigenous beliefs 6%,
Christian 2% (mostly Roman Catholic)
Languages: French (official), Wolof, Pulaar, Jola,
Mandinka
Literacy:
definition: age 15 and over can read and write
total population: 33. 1 %
male: 43%
fema/e; 23.2% (1995 est.)
Population: 10,662,087 (Serbia - 9,981 ,929;
Montenegro -680,158)
note: all data dealing with population is subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing (July 2000 est.)
Age structure:
0-14 years: Serbia - 19.95% (male 1 ,028,355; female
963,366); Montenegro - 22.05% (male 77,582; female
72,395)
15-64 years: Serbia - 65.22% (male 3,187,746;
female 3,322,425); Montenegro - 66.16% (male
222,095; female 227,923)
65 years and over: Serbia - 1 4.83% (male 638,204;
female 841 ,833); Montenegro - 1 1 .79% (male 32,400;
female 47,763) (2000 est.)
Population growth rate: Serbia - 0.739%;
Montenegro - 12.22% (2000 est.)
Birth rate: Serbia - 12.20 births/l ,000 population;
Montenegro - 14.9 births/1 ,000 population (2000 est.)
Death rate: Serbia - 1 1 .08 deaths/1 ,000 population;
Montenegro - 7.9 deaths/1 ,000 population (2000 est.)
Net migration rate: Serbia - 6.26 migrants/1 ,000
population; Montenegro - -29.18 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: Serbia - 1.08 male(s)/female; Montenegro -
1 .09 male(s)/female
under 15 years: Serbia - 1.07 male(s)/female;
Montenegro - 1 .07 male(s)/female
15-64 years: Serbia - 0.96 male(s)/female;
Montenegro - 0.97 male(s)/female
65 years and over: Serbia - 0.76 male(s)/female;
Montenegro - 0.68 male(s)/female
total population: Serbia - 0.95 male(s)/female;
Montenegro - 0.95 male(s)/female (2000 est.)
infant mortaiity rate: Serbia - 20.1 3 deaths/1 ,000
live births; Montenegro - 10.97 deaths/1,000 live
births (2000 est.)
Life expectancy at birth;
total population: Serbia - 72.39 years; Montenegro -
75.46 years
male: Serbia - 69.31 years; Montenegro - 71 .45 years
female: Serbia - 75.72 years; Montenegro - 79.82
years (2000 est.)
Total fertility rate: Serbia - 1 .70 children born/
woman; Montenegro - 1 .96 children born/woman
(2000 est.)
Nationality;
noun: Serb(s); Montenegrin(s)
adjective: Serbian; Montenegrin
Ethnic groups: Serb 62.6%, Albanian 16.5%,
Montenegrin 5%, Yugoslav 3.4%, Hungarian 3.3%,
other 9.2% (1991)
Religions: Orthodox 65%, Muslim 19%, Roman
Catholic 4%, Protestant 1%, other 11%
Languages: Serbian 95%, Albanian 5%
Literacy;
definition: NA
total population: NA%
mate: NA%
female: NA%','4e6b6355570335b8f048910ba7ed1103037c80815d3d0253f0819b05fbe80e74','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9070d456bbb0214d3064f769e947c2d87c58374f3c093afc2928051bacc89e1e',2000,'YT','Mayotte','people-and-society',338,'Population: 1 00,349,766 (July 2000 est.)
Age structure:
0-14 years: 34% (male 17,306,548; female
16,632,827)
15-64 years: 62% (male 30,223,31 7; female
31,868,213)
65 years and over: 4% (male 1 ,927,850; female
2,391 ,011) (2000 est.)
Population growth rate: 1 .53% (2000 est.)
Birth rate: 23.15 births/1,000 population (2000 est.)
Death rate: 5.05 deaths/1 ,000 population
(2000 est.)
Net migration rate: -2.84 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate: 26.1 9 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 71 .49 years
male: 68.47 years
female: 74.66 years (2000 est.)
Total fertility rate: 2.67 children born/woman
(2000 est.)
Nationality:
noun: Mexican(s)
adjective: Mexican
Ethnic groups: mestizo (Amerindian-Spanish) 60%,
Amerindian or predominantly Amerindian 30%, white
9%, other 1%
Religions: nominally Roman Catholic 89%,
Protestant 6%, other 5%
Languages: Spanish, various Mayan, Nahuatl, and
other regional indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 89.6%
male: 91 .8%
fema/e; 87.4% (1995 est.)','9b32779fbbb5bade7b5b47f741c8516cbdfb381ca04d422c171a8667ad09f725','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dafad566e6abe5d468fa5745d4e2f2dd450006fb463fb820d4fdc1ca131684ed',2000,'ID','Indonesia','people-and-society',348,'Population: 4,430,654 (July 2000 est.)
Age structure:
0-14 years: 23% (male 523,373; female 505,064)
15-64 years: 67% (male 1 ,422,470; female
1,544,169)
65 years and over: 1 0% (male 1 61 ,659; female
273,919) (2000 est.)
Population growth rate: -0% (2000 est.)
Birth rate: 12.86 births/1 ,000 population (2000 est.)
Death rate: 12.58 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.31 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.91 male(s)/female (2000 est.)
Infant mortality rate: 43.32 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 64.45 years
male: 59.92 years
female: 69.22 years (2000 est.)
Total fertility rate: 1 .63 children born/woman
(2000 est.)
Nationality:
noun: Moldovan(s)
adjective: Moldovan
331
Moldova (continued)
Ethnic groups: Moldavian/Romanian 64.5%,
Ukrainian 13.8%, Russian 13%, Gagauz 3.5%,
Jewish 1.5%, Buigarian 2%, other 1.7% (1989 est.)
note: internal disputes with ethnic Siavs in the
Transnistrian region
Religions: Eastern Orthodox 98.5%, Jewish 1 .5%,
Baptist (only about 1,000 members) (1991)
Languages: Moldovan (official, virtually the same as
the Romanian language), Russian, Gagauz (a Turkish
dialect)
Literacy:
definition: age 1 5 and over can read and write
total population: 96%
mate: 99%
fema/e; 94% (1989 est.)
Population: 31 ,693 (July 2000 est.)
Age structure:
0-14 years: t5% (male 2,449; female 2,336)
15-64 years: 62% (male 9,723; female 1 0,074)
65 years and over: 23% (male 2,907; female 4,204)
(2000 est.)
Population growth rate: 0.48% (2000 est.)
Birth rate: 9.94 births/1 ,000 population (2000 est.)
Death rate: 13.06 deaths/1 ,000 population
(2000 est.)
Net migration rate: 7.89 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/temale
65 years and over: 0.69 male(s)/female
totai population: 0.91 male(s)/female (2000 est.)
Infant mortality rate: 5.92 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.84 years
male: 74.88 years
female: 83 years (2000 est.)
Total fertility rate: 1 .76 children born/woman
(2000 est.)
Nationality;
noun: Monegasque(s) or Monacan(s)
adjective: Monegasque or Monacan
Ethnic groups; French 47%, Monegasque 16%,
Italian 16%, other 21%
Religions: Roman Catholic 90%
Languages: French (official), English, Italian,
Monegasque
Literacy:
definition: NA
total population: 99%
male: NA%
female: NA%','b610e96bd307cd14a6515402c07f4c473c9cfd13f3dbaa5ff3017fee0a9e0746','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e6eabdb1bef5d9fa1ea99ecd6edee256feefa419cbd756c7854098d026702bd',2000,'NZ','New Zealand','people-and-society',363,'Population: 3,819,762 (July 2000 est.)
Age structure:
0-14 years: 23% (male 440,824; female 41 9,740)
15-64 years: 66% (male 1 ,263,71 0; female
1,254,958)
65 years and over: 1 1 % (male 191,511; female
249,019) (2000 est.)
Population growth rate: 1.17% (2000 est.)
Birth rate: 1 4.28 births/1 ,000 population (2000 est.)
Death rate: 7.57 deaths/1,000 population
(2000 est.)
Net migration rate: 4.95 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years; 1.01 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate: 6.39 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77.82 years
male: 74.85 years
female: 80.93 years (2000 est.)
Total fertility rate: 1 .8 children born/woman
(2000 est.)
Nationality:
noun: New Zealander(s)
adjective: New Zealand
Ethnic groups: New Zealand European 74.5%,
Maori 9.7%, other European 4.6%, Pacific Islander
3.8%, Asian and others 7.4%
Religions: Anglican 24%, Presbyterian 1 8%, Roman
Catholic 15%, Methodist 5%, Baptist 2%, other
Protestant 3%, unspecified or none 33% (1986)
Languages: English (official), Maori
Literacy:
definition: age 15 and over can read and write
total population: 99% (1 980 est.)
male: NA%
female: NA%
u *
Population: 2,1 1 3 (July 2000 est.)
Age structure:
0-M years; NA
15-64 years: M
65 years and over: NA
Population growth rate: 0.47% (2000 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Niuean(s)
adjective: Niuean
Ethnic groups: Polynesian (with some 200
Europeans, Samoans, and Tongans)
Religions: Ekalesia Niue (Niuean Church - a
Protestant church closely related to the London
Missionary Society) 75%, Latter-Day Saints 10%,
other 15% (mostly Roman Catholic, Jehovah''s
Witnesses, Seventh-Day Adventist)
Languages: Polynesian closely related to Tongan
and Samoan, English
Literacy:
definition: NA
total population: 95%
male: NA%
female: NA%
f Government
Country name:
conventional long form: none
conventional short form: Niue
Data code: NE
Dependency status: self-governing in free
association with New Zealand; Niue fully responsible
for internal affairs; New Zealand retains responsibility
for external affairs
Government type: self-governing parliamentary
democracy
Capital: Alofi
Administrative divisions: none; note - there are no
first-order administrative divisions as defined by the
US Government, but there are 1 4 villages each with its
own village council whose members are elected and
serve three-year terms
Independence: on 1 9 October 1 974, Niue became a
self-governing parliamentary government in free
association with New Zealand
National holiday: Waitangi Day, 6 February (1840)
(Treaty of Waitangi established British sovereignty)
Constitution: 19 October 1974 (Niue Constitution
Act)
Legal system: English common law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1 952); the UK and New Zealand are represented by
New Zealand High Commissioner Warren SEARELL
(since NA August 1993)
head 0/ government; Premier Sani LAKATANI (since
1 April 1999)
cabinet: Cabinet consists of the premier and three
ministers
elections: the monarch is hereditary; premier elected
by the Legislative Assembly for a three-year term;
election last held 19 March 1999 (next to be held NA
March 2002)
election results: Sani LAKATANI elected premier;
percent of Legislative Assembly vote - NA
Legislative branch: unicameral Legislative
Assembly (20 seats; members elected by popular
vote to serve three-year terms; six elected from a
common roll and 14 are village representatives)
elections: last held 19 March 1999 (next to be held NA
March 2002) ■
election results: percent of vote by party - NA; seats
by party - NPP 9, independents 1 1
Judicial branch: Supreme Court of New Zealand;
High Court of Niue
Political parties and leaders: Niue People''s Action
Party or NPP [Young VIVIAN]
International organization participation: ESCAP
(associate), Intelsat (nonsignatory user), Sparteca,
SPC, SPF, UNESCO, WHO, WMO
Diplomatic representation in the US: none
(self-governing territory in free association with New
Zealand)
Diplomatic representation from the US: none
(self-governing territory in free association with New
Zealand)
Flag description: yellow with the flag of the UK in
the upper hoist-side quadrant; the flag of the UK bears
five yellow five-pointed stars - a large one on a blue
disk in the center and a smaller one on each arm of the
bold red cross
Population: 1 ,1 75,523 (July 2000 est.)
Age structure:
0-14years:25% (male 151,736; female 146,135)
15-64 years: 68% (male 410,668; female 389,303)
65 years and over: 7% (male 34,559; female 43, 1 22)
(2000 est.)
Population growth rate: -0.49% (2000 est.)
Birth rate: 1 3.84 births/1 ,000 population (2000 est.)
Death rate: 8.84 deaths/1 ,000 population
(2000 est.)
Net migration rate: -9.92 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1.03 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1.03 male(s)/female (2000 est.)
Infant mortality rate: 25.76 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 67.97 years
male: 65.45 years
female: 70.59 years (2000 est.)
Total fertility rate: 1 .83 children born/woman
(2000 est.)
Nationality:
noun; Trinidadian(s), Tobagonian(s)
acfy''ecf/ve; Trinidadian, Tobagonian
Ethnic groups: black 39.5%, East Indian (a local
term - primarily immigrants from northern India)
40.3%, mixed 18.4%, white 0.6%, Chinese and other
1.2%
Reiigions: Roman Catholic 29.4%, Hindu 23.8%,
Anglican 10.9%, Muslim 5.8%, Presbyterian 3.4%,
other 26.7%
Languages: English (official), Hindi, French,
Spanish, Chinese
Literacy:
definition: age 15 and over can read and write
total population: 97.9%
male: 98.8%
fema/e; 97% (1995 est.)
496
Trinidad and Tobago (continued)
I Government
Country name;
conventional long form: Republic of T rinidad and
Tobago
conventional short form: T rinidad and T obago
Data code: TD
Government type; pariiamentary democracy
Capital: Port-of-Spain
Administrative divisions; 8 counties, 3
municipalities*, and 1 ward**; Arima*, Caroni, Mayaro,
Nariva, Port-of-Spain*, Saint Andrew, Saint David,
Saint George, Saint Patrick, San Fernando*,
Tobago**, Victoria
Independence: 31 August 1962 (from UK)
National holiday: Independence Day, 31 August
(1962)
Constitution: 1 August 1976
Legal system; based on English common law;
judicial review of legislative acts in the Supreme
Court; has not accepted compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universai
Executive branch:
chief of state: President Arthur Napoleon Raymond
ROBINSON (since 19 March 1997)
head of government: Prime Minister Basdeo
PANDAY (since 9 November 1995)
cabinet: Cabinet appointed from among the members
of Parliament
elections: president elected by an electoral college,
which consists of the members of the Senate and
House of Representatives, for a five-year term;
election last held NA November 1995 (next to be held
by November 2000); prime minister appointed from
among the members of Parliament; following
legislative elections, the leader of the majority party in
the House of Representatives is usually appointed
prime minister
election results: Arthur Napoleon Raymond
ROBINSON elected president; percent of electoral
college vote - 69%
Legislative branch; bicameral Parliament consists
of the Senate (31 seats; members appointed by the
president for a maximum term of five years) and the
House of Representatives (36 seats; members are
elected by popular vote to serve five-year terms)
elections: House of Representatives - last held 6
November 1 995 (next to be held by December 2000)
election results: House of Representatives - percent
of vote - PNM 52%, UNC 42.2%, NAR 5.2%; seats by
party - PNM 15, UNC 19, NAR 1, independent 1 ;
note - the UNC formed a coalition with the NAR
note; Tobago has a unicameral House of Assembly,
with 15 members serving four-year terms
Judicial branch; Supreme Court comprised of the
High Court of Justice and the Court of Appeals, judges
are appointed by the president on the advice of the
prime minister
Political parties and leaders; Movement for Social
Transformation or MOTION [David ABDULLAH];
Movement for Unity and Progress or MUP [Hulsie
BHAGGANj; National Alliance for Reconstruction or
NAR [leader NA]; National Development Party or NDP
[Carson CHARLES]; NationalJoint Action Committee
or NJAC [Makandal DAAGA]; People''s National
Movement or PNM [Patrick MANNING]; United
National Congress or UNC [Basdeo PANDAY]
Political pressure groups and leaders: Jamaat Al
Musilmeen [Abu BAKR]
International organization participation: ACP, C,
Caricom, CCC, CDB, ECUC, FAO, G-24, G-77,
lADB, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC,
IFRCS, IHO, ILO, IMF, IMO, Intelsat, Interpol, IOC,
ISO, ITU, LAES, NAM, OAS, OPANAL, OPCW, UN,
UNCTAD, UNESCO, UNIDO, UNU, UPU, WFTU,
WHO, WlPO, WMO.WTrO
Diplomatic representation in the US;
chief of mission: Ambassador Michael A. ARNEAUD
chancery: 1708 Massachusetts Avenue NW,
Washington, DC 20036
fe/ep/7or7e;[1] (202) 467-6490
FAX;[1] (202) 785-3130
consulate(s) general: Miami and New York
Diplomatic representation from the US:
chief of mission: Ambassador Edward E.
SHUMAKER, III
embassy; 15 Queen''s Park West, Port-of-Spain
mailing address: P. 0. Box 752, Port-of-Spain
telephone: [1] (809) 622-6372 through 6376, 6176
FAX; [1] (809) 628-5462
Flag description; red with a white-edged black
diagonal band from the upper hoist side
I E c o n o ~m y ™
Economy - overview: Trinidad and Tobago has
earned a reputation as an excellent investment site for
internationai businesses. Successful economic
reforms were implemented in 1995, and foreign
investment and trade are flourishing. Persistentiy high
unemployment remains one of the chief challenges of
the government. The petrochemical sector has
spurred growth in other related sectors, reinforcing the
government''s commitment to economic
diversification. Tourism is growing, especially in the
pieasure boat sector.
GDP: purchasing power parity - $9.41 biilion
(1999 est.)
GDP - real growth rate: 5% (1999 est.)
GDP - per capita: purchasing power parity - $8,500
(1999 est.)
GDP - composition by sector:
agriculture: 2%
industry: 44%
services: 54% (1 998 est.)
Population below poverty line: 21% (1992 est.)
Household income or consumption by percentage
share:
towesf 10%; NA%
highest 10%: NA%
Inflation rate (consumer prices): 3.5% (1999 est.)
Labor force: 558,700(1998)
Labor force - by occupation: construction and
utilities 12.4%, manufacturing, mining, and quarrying
14%, agricuiture 9.5%, services 64.1% (1997 est.)
Unemployment rate: 14.2% (1998)
Budget;
revenues: $1 .54 biilion
expenditures: $1.& biiiion, including capital
expenditures of $1 17.3 miilion (1998)
Industries: petroleum, chemicals, tourism, food
processing, cement, beverage, cotton textiles
Industrial production growth rate: 7.5% (1995)
Electricity - production: 4.763 billion kWh (1998)
Electricity - production by source:
fossil fuel: 99.27%
hydro: 0%
nuclear: 0%
other; 0.73% (1998)
Electricity - consumption: 4.43 biiiion kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products; cocoa, sugarcane, rice,
citrus, coffee, vegetables; poultry
Exports; $2.4 billion (f.o.b., 1998)
Exports - commodities: petroleum and petroleum
products, chemicals, steel products, fertilizer, sugar,
cocoa, coffee, citrus, flowers
Exports - partners: US 36.9%, Caricom countries
29.4%, Central and South America 9.7%, EU 6.3%
(1998)
Imports; $3 billion (c.i.f., 1998)
Imports • commodities; machinery, transportation
equipment, manufactured goods, food, live animals
Imports ■ partners: US 44.7%, Latin America
18,9%, EU 13.7%, Japan 4.8% (1998)
Debt - external; $2.2 billion (1997 est.)
Economic aid - recipient; $121 .4 million (1995)
Currency: 1 T rinidad and Tobago dollar (TT$) = 1 00
cents
Exchange rates: Trinidad and Tobago dollars (TT$)
per US$1 - 6.2697 (January 2000), 6.2963 (1999),
6.2983 (1998), 6.2517 (1997), 6.0051 (1996), 5.9478
(1995)
Fiscal year: 1 October - 30 September
I Communications
Telephones - main lines in use: 209,000 (1995)
Telephones - mobile cellular; 5,615 (1995)
Telephone system; excellent international service;
good local service
domestic: NA
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean); tropospheric scatter to Barbados
and Guyana
Radio broadcast stations: AM 2, FM 10, shortwave
0(1998)
Radios: 680,000(1997)
Television broadcast stations; 4 (1997)
Televisions: 425,000(1997)
Internet Service Providers (ISPs): 5 (1999)
I " f r a n s p 0 r t a t i 0 n
Railways: minimal agricultural railroad system near
San Fernando; railway service was discontinued in
1968
497
Trinidad and Tobago (continued)
Highways:
total: 8,320 km
paved: 4,252 km
unpaired; 4,068 km (1996 est.)
Pipelines: crude oil 1 ,032 km; petroleum products
19 km; natural gas 904 km
Ports and harbors: Pointe-a-Pierre, Point Fortin,
Point Lisas, Port-of-Spain, Scarborough, Tembiadora
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 2,439 GRT/
4,040 DWT
ships by type: cargo 1 , petroieum tanker 1 (1 999 est.)
Airports: 6 (1999 est.)
Airports - with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m:t
1,524 to 2,437 m:t (1999 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:1
under 914 m; 2 (1999 est.)
Population: uninhabited (July 2000 est.)','96053996bd005881bb192f615fdb9cd4b18310b4028ce9458b00dd3270166f95','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3db95bcf852c0b0fae3ffba72100ac1b9ad30ccdf9b87011468355f1d4473238',2000,'WS','Samoa','people-and-society',380,'Population: uninhabited (July 2000 est.)
382
Palmyra Atoll (continued)
I Government
Country name:
conventional long form: none
conventional short form: Palmyra Atoll
Data code; LQ
Dependency status: Incorporated territory of the
US; privately owned, but administered from
Washington, DC by the Office of Insular Affairs, US
Department of the Interior
Flag description; the flag of the US is used
I Economy
Economy - overview: no economic activity
I Transportation''^
Highways: much of the road and many causeways
built during World War II are unserviceable and
overgrown
Ports and harbors; West Lagoon
Airports: 1 (1999est.)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m-.t (1999 est.)
I Mllffary
Military - note: defense is the responsibility of the
US
I Transnational Issues
Disputes - international; none
from Colombia in 1903 and promptly signed a treaty
with the US allowing for the construction of a canal
and US sovereignty over a strip of land on either side
of the structure (the Panama Canal Zone). The
Panama Canal was built by the US Army Corps of
Engineers between 1904 and 1914. On 7 September
1 977, an agreement was signed for the complete
transfer of the Canal from the US to Panama by 1 999.
Certain portions of the Zone and increasing
responsibility over the Canal were turned over in the
intervening years. With US help, dictator Manuel
NORIEGA was deposed in 1989. The entire Panama
Canal, the area supporting the Canal, and remaining
US military bases were turned over to Panama on 31
December 1999.
I "g e pTfy™
Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Colombia and Costa Rica
Geographic coordinates; 9 00 N, 80 00 W
Map references: Central America and the
Caribbean
Area;
total: 78,200 sq km
land: 75,990 sq km
wafer; 2,21 Osq km
Area - comparative; slightly smaller than South
Carolina
Land boundaries:
total: 555 km
border countries: Colombia 225 km, Costa Rica 330
km
Coastline: 2,490 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
ferr/for/a/sea;12nm
Terrain; interior mostly steep, rugged mountains and
dissected, upland plains; coastal areas largely plains
and rolling hills
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: Volcan de Chiriqui 3,475 m
Natural resources; copper, mahogany forests,
shrimp, hydropower
Land use;
arable land: 7%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 44%
other; 27% (1993 est.)
Irrigated land: 320 sq km (1993 est.)
Natural hazards: NA
Environment - current issues; water pollution from
agricultural runoff threatens fishery resources;
deforestation of tropical rain forest; land degradation
and soil erosion threatens siltation of Panama Canal
Environment - international agreements;
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
Geography - note; strategic location on eastern end
of isthmus forming land bridge connecting North and
South America; controls Panama Canal that links
North Atlantic Ocean via Caribbean Sea with North
Pacific Ocean
I People
Population: 2,808,268 (July 2000 est.)
Age structure;
0-14 years: 31% (male 439,590; female 422,949)
383
Panama (continued)
15-64 years: 63% (male 901 ,793; female 878,138)
65 years and over: 6% (male 79,330; female 86,468)
(2000 est.)
Population growth rate: 1 .34% (2000 est.)
Birth rate: 19.53 births/1,000 population (2000 est.)
Death rate: 4.95 deaths/1 ,000 population
(2000 est.)
Net migration rate: -1.16 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .04 male(s)/femaie
under 15 years: 1.04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 1 .02 male(s)/female (2000 est.)
Infant mortality rate: 20.8 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
totai population: 75.47 years
male: 72.74 years
female: 78.31 years (2000 est.)
Total fertility rate: 2.32 children born/woman
(2000 est.)
Nationality:
noun: Panamanian(s)
adjective: Panamanian
Ethnic groups: mestizo (mixed Amerindian and
white) 70%, Amerindian and mixed (West Indian)
14%, white 10%, Amerindian 6%
Religions: Roman Catholic 85%, Protestant 15%
Languages: Spanish (official), English 14%
note: many Panamanians bilingual
Literacy:
definition: age 1 5 and over can read and write
total population: 90.8%
male: 91 .4%
female: 90.2% (1 995 est.)
I Government
Country name:
conventional long form: Republic of Panama
conventional short form: Panama
local long form: Republica de Panama
local short form: Panama
Data code: PM
Government type: constitutional democracy
Capital: Panama
Administrative divisions: 9 provinces (provincias,
singular - provincia) and 2 territories* (comarca);
Bocas del Toro, ChlrIquI, Code, Colon, Darien,
Herrera, Los Santos, Ngobe-Bugle*, Panama, San
Bias*, and Veraguas
Independence: 3 November 1903 (from Colombia;
became independent from Spain 28 November 1821)
National holiday: Independence Day, 3 November
(1903)
Constitution: 11 October 1972; major reforms
adopted April 1983 and In 1994
Legal system: based on civil law system; judicial
review of legislative acts in the Supreme Court of
Justice; accepts compulsory ICJ jurisdiction, with
reservations
Suffrage: 1 8 years of age; universal and compulsory
Executive branch:
chief of state: President Mireya Elisa MOSCOSO
Rodriguez (since 1 September 1999); First Vice
President Arturo Ulises VALLARINO (since 1
September 1999); Second Vice President
(Dominador) Kaiser Baldonero BAZAN (since 1
September 1999); note - the president is both the
chief of state and head of government
head of government: President Mireya Elisa
MOSCOSO Rodriguez (since 1 September 1999);
First Vice President Arturo Ulises VALLARINO (since
1 September 1999); Second Vice President
(Dominador) Kaiser Baldonero BAZAN (since 1
September 1999); note - the president is both the
chief of state and head of government
cabinet: Cabinet appointed by the president
elections: president and vice presidents elected on
the same ticket by popular vote for five-year terms;
election last held 2 May 1999 (next to be held NA May
2004)
election results: Mireya Elisa MOSCOSO Rodriguez
eiected president; percent of vote - Mireya Elisa
MOSCOSO Rodriguez (PA) 44%, Martin TORRIJOS
(PRD) 37%
note: government coalition - PRD, PLN, and Popular
Nationalist Party
Legislative branch: unicameral Legislative
Assembly or Asamblea Legislativa (72 seats;
members are elected by popular vote to serve
five-year terms)
elections: last held 2 May 1999 (next to be held May
2004)
election results: percent of vote by party - NA; seats
by party - PRD 35, PA 18. PS 4, PDC 4, MOLIRENA
3, PRC 2, PLN 2, Democratic Change 2, MORENA 1 ;
note - one seat had yet to be decided
note: legislators from outlying rural districts are
chosen on a plurality basis while districts located in
more populous towns and cities elect multiple
legislators by means of a proportion-based formula
Judicial branch: Supreme Court of Justice or Corte
Suprema de Justicia, nine judges appointed for
10-year terms; five superior courts; three courts of
appeal
Political parties and leaders: Arnulfista Party or PA
[Mireya Eiisa MOSCOSO Rodriguez]; Christian
Democratic Party or PDC [Ruben AROSEMENAj;
Civic Renewal Party or PRC [Serguei DE LA ROSA];
Democratic Change [Ricardo MARTINELLI];
Democratic Revolutionary Party or PRD [Martin
TORRIJOS]; National Liberal Party or PLN [Dr.
Roberto ALEMAN Zubieta, Oscar UCROS, Raul
ARANGO]; National Renovation Movement or
MORENA [Joaquin Jose VALLARINO]; Nationalist
Republican Liberal Movement or MOLIRENA [Arturo
VALLARINO]; Solidarity Party or PS [Ricardo
FABREGA]
Political pressure groups and leaders: Chamber
of Commerce; National Civic Crusade; National
Council of Organized Workers or CONATO; National
Council of Private Enterprise or CONEP; Panamanian
Association of Business Executives or APEDE;
Panamanian Industrialists Society or SIP; Workers
Confederation of the Republic of Panama or CTRP
International organization participation: CAN
(associate), CCC, ECLAC, FAO, G-77, lADB, IAEA,
IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS,
ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, lOM,
ISO, ITU, LAES, LAIA (observer), NAM, OAS,
OPANAL, OPCW, PCA, RG, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WlPO,
WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Guillermo FORD
chancery: 2862 McGill Terrace NW, Washington, DC
20008
telephone: [\\] (202) 483-1407
consulate(s) general: Atlanta, Houston, Miami, New
Orleans, New York, Philadelphia, San Francisco,
Tampa
Diplomatic representation from the US:
chief of mission: Ambassador Simon FERRO
embassy: Avenida Baiboa and Calle 38, Apartado
6959, Panama City 5
mailing address: American Embassy Panama, Unit
0945, APO AA 34002
fe/ephone; [507] 227-1777
FAX; [507] 227-1 964
Flag description: divided Into four, equal
rectangles; the top quadrants are white (hoist side)
with a blue five-pointed star in the center and plain
red; the bottom quadrants are plain blue (hoist side)
and white with a red five-pointed star in the center
I Economy
Economy • overview: Because of its key
geographic location, Panama''s economy is
service-based, heavily weighted toward banking,
commerce, and tourism. The hand-over of the canal
and military installations by the US has given rise to
new construction projects. The MOSCOSO
administration inherited an economy that is much
more structurally sound and liberalized than the one
inherited by its predecessor. Even though export
demand is likely to remain slack in some key markets -
especially the Andean countries - GDP growth in 2000
probably will be 3% to 4%. Key reform initiatives from
the previous administration - including the
privatization of public utilities - remain uncompleted.
Although President MOSCOSO is unlikeiy to overturn
any previous reforms, her populist leanings make it
unlikely any new initiatives will be undertaken in the
near future, indeed, the government has failed to
formulate a comprehensive economic policy
framework, and the only concrete step it has taken by
yearend 1999 has been a hike in agricultural tariffs.
GDP: purchasing power parity - $21 billion
(1999 est.)
GDP - real growth rate: 4.4% (1999 est.)
GDP - per capita: purchasing power parity - $7,600
(1999 est.)
GDP ■ composition by sector:
agriculture: 8%
384
Panama (continued)
industry: 25%
services: 57% (1997 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: 0.5%
highest 10%: 42.5% (1991)
Inflation rate (consumer prices): 1 .5% (1 999 est.)
Labor force: 1 .044 million (1 997 est.)
note: shortage of skilled labor, but an oversupply of
unskilled labor
Labor force - by occupation: agriculture 18%,
industry 18%, services 64% (1997 est.)
Unemployment rate: 13.1% (1997 est.)
Budget:
revenues: $2.4 billion
expenditures: $2.4 billion, including capital
expenditures of $341 million (1997 est.)
Industries: construction, petroleum refining,
brewing, cement and other construction materials,
sugar milling
Industrial production growth rate: 0.4%
(1995 est.)
Electricity - production: 4.523 billion kWh (1998)
Electricity - production by source:
fossil fuel: 25.55%
hydro: 73.78%
nuclear. 0%
of/ier; 0.66% (1998)
Electricity - consumption: 4.329 billion kWh (1998)
Electricity - exports: 13 million kWh (1998)
Electricity - imports: 136 million kWh (1998)
Agriculture - products: bananas, rice, corn, coffee,
sugarcane, vegetables; livestock; shrimp
Exports: $4.7 billion (f.o.b., 1999 est.)
Exports - commodities: bananas, shrimp, sugar,
coffee
Exports - partners: US 40%, Sweden, Costa Rica,
Spain, Benelux, Honduras (1998)
Imports: $6.4 billion (f.o.b., 1999 est.)
Imports - commodities: capital goods, crude oil,
foodstuffs, consumer goods, chemicals
Imports - partners: US 40%, Central America and
Caribbean, Japan (1998)
Debt - external: $7 billion (1 999)
Economic aid - recipient: $197.1 million (1995)
Currency: 1 balboa (B) = 100 centesimos
Exchange rates: balboas (B) per US$1 - 1 .000
(fixed rate)
Fiscal year: calendar year
ipToln^ ¥fl i c a tTo
Telephones - main lines in use: 325,300 (1998)
Telephones - mobile cellular: 0 (1995)
Telephone system: domestic and international
facilities well developed
domestic: NA
international: 1 coaxial submarine cable; satellite
earth stations - 2 Intelsat (Atlantic Ocean); connected
to the Central American Microwave System
Radio broadcast stations: AM 80, FM 44,
shortwave 0 (1998)
Radios: 815,000(1997)
Television broadcast stations: 9 (plus 17
repeaters) (1997)
Televisions: 510,000(1997)
Internet Service Providers (ISPs): 3 (1 999)
|7"~" f r a n 8 p 0 r tat ion
Railways:
total: 355 km
broad gauge: 75 km 1.524-m gauge
narrow gauge: 279 km 0.91 4-m gauge
Highways:
total: 1 1 ,258 km
paved: 3,783 km (including 30 km of expressways)
unpaved: 7,475 km (1999 est.)
Waterways: 800 km navigable by shallow draft
vessels; 82 km Panama Canal
Pipelines: crude oil 130 km
Ports and harbors: Balboa, Cristobal, Coco Solo,
Manzanillo (part of Colon area), Vacamonte
Merchant marine:
total: 4,732 ships (1 ,000 GRT or over) totaling
106,054,086 GRT/1 59,304,01 9 DWT
ships by type: bulk 1,377, cargo 976, chemical tanker
323, combination bulk 68, combination ore/oil 15,
container 525, liquified gas 184, livestock carrier 8,
multi-functional large load carrier 12, passenger 46,
passenger/cargo 4, petroleum tanker 496, rail car
carrier 2, refrigerated cargo 313, roll-on/roll-off 106,
short-sea passenger 42, specialized tanker 33,
vehicle carrier 202 (1 999 est.)
note: a flag of convenience registry; includes ships
from 71 countries among which are Japan 1 ,262,
Greece 378, Hong Kong 244, South Korea 259,
Taiwan 229, China 193, Singapore 103, US 116,
Switzerland 78, and Indonesia 53 (1998 est.)
Airports: 105 (1999 est.)
Airports - with paved runways:
total: 41
over 3,047 m:1
2,438 to 3,047 m:\\
1,524 to 2,437 m: 5
914 to 1,523 m: 13
under 914 m: 21 (1 999 est.)
Airports - with unpaved runways:
total: 64
914 to 1,523 m: 15
under 914 m: 49 (1 999 est.)
I" " ’ ''■""''TrrM t-aTy™""'' ''
Military branches: an amendment to the
Constitution abolished the armed forces,'' but there are
security forces (Panamanian Public Forces or PPF
includes the National Police, National Maritime
Service, and National Air Service)
Military manpower - availability:
males age 15-49: 761 ,568 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 521 ,487 (2000 est.)
Military expenditures - dollar figure: $132 million
(FY97)
Military expenditures - percent of GDP: 1 .6%
(FY97)
Military - note: on 1 0 February 1 990, the
government of then President ENDARA abolished
Panama''s military and reformed the security
apparatus by creating the Panamanian Public Forces;
in October 1994, Panama''s Legislative Assembly
approved a constitutional amendment prohibiting the
creation of a standing military force, but allowing the
temporary establishment of special police units to
counter acts of "external aggression”
Disputes - international: none
Illicit drugs: major cocaine transshipment point and
major drug-money-laundering center; no recent signs
of coca cultivation; monitoring of financial transactions
is improving, yet Panama has failed to prosecute
anyone for money laundering - official corruption
remains a major problem
385
{Papua New Guinea
Background: The eastern half of the island of New
Guinea - second iargest in the worid - was divided
between Germany (north) and the UK (south) in 1 885.
The iatter area was transferred to Austraiia in 1902,
which occupied the northern portion during World War
I and continued to administerthe combined areas untii
independence in 1 975. A nine-year secessionist revolt
on the island of Bougainville ended in 1997, after
claiming some 20,000 iives.
highest point: Mount Wilhelm 4,509 m
Natural resources; gold, copper, silver, natural gas,
timber, oil, fisheries
Land use:
arabie land: 0.1%
permanent crops: 1%
permanent pastures: 0%
forests and woodland: 92.9%
other: 6% (1993est.)
Irrigated land: NAsqkm
Natural hazards: active volcanism; situated aiong
the Pacific "Rim of Fire”; the country is subject to
frequent and sometimes severe earthquakes; mud
slides; tsunamis
Environment - current issues: rain forest subject to
deforestation as a result of growing commercial
demand for tropical timber; pollution from mining
projects; severe drought
Environment - international agreements;
party to: Antarctic Treaty, Biodiversity, Ciimate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol, Climate Change-Kyoto Protocol
Geography • note: shares island of New Guinea
with Indonesia; one of world''s largest swamps along
southwest coast
ir People
I Geography
Location: Southeastern Asia, group of islands
including the eastern half of the island of New Guinea
between the Coral Sea and the South Pacific Ocean,
east of Indonesia
Geographic coordinates: 6 00 S, 147 00 E
Map references: Oceania
Area;
total: 462,840 sq km
land: 452,860 sq km
water: 9,980 sq km
Area - comparative: slightly larger than California
Land boundaries;
total: 820 km
border countries: Indonesia 820 km
Coastline: 5,152 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 200 nm
territorial sea: t2nm
Climate: tropical; northwest monsoon (December to
March), southeast monsoon (May to October); slight
seasonal temperature variation
Terrain: mostly mountains with coastal lowlands and
rolling foothills
Elevation extremes:
lowest point: Pacific Ocean 0 m
Population: 4,926,984 (July 2000 est.)
Age structure:
0-14 years: 39% (male 972,289; female 940,049)
15-64 years: 58% (male 1 ,470,1 58; female
1,365,523)
65 years and over: 3% (male 84,942; female 94,023)
(2000 est.)
Population growth rate: 2.47% (2000 est.)
Birth rate: 32.68 births/1,000 population (2000 est.)
Death rate: 8 deaths/1 ,000 population (2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1 .05 male(s)/female (2000 est.)
Infant mortality rate: 59.89 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 63.1 years
male: 61 .05 years
female: 65.26 years (2000 est.)
Total fertility rate: 4.38 children born/woman
(2000 est.)
Nationality:
noun: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic groups: Melanesian, Papuan, Negrito,
Micronesian, Polynesian
Religions: Roman Catholic 22%, Lutheran 16%,
Presbyterian/Methodist/London Missionary Society
8%, Anglican 5%, Evangelical Alliance 4%,
Seventh-Day Adventist 1%, other Protestant 10%,
indigenous beliefs 34%
Languages; English spoken by 1%-2%, pidgin
English widespread, Motu spoken in Papua region
note: 715 indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 72.2%
male: 81%
female: 62.7% (1995 est.)','8eed30ed7cef845fe8695af56b4e3a9ec745a4b8ab3a3d9ea9151dbf35307c3a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af32844b5b4f6a0bf6f8df3344b45e99f508d70499fcbe69b8777575fac3870d',2000,'PH','Philippines','people-and-society',384,'Location: Central South America, northeast of
Population: no indigenous inhabitants
note; there are scattered garrisons occupied by
personnel of several claimant states (July 2000 est.)','6a8dd6d9d21b529790df0f7d5be07e9ba40bcd788bfe26295ffa4cffa73a66dd','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cff672830e589e643f38ecae4c1afaa76ffac62ebc1e7010989e80a049e122f7',2000,'AR','Argentina','people-and-society',385,'Geographic coordinates: 23 00 S, 58 00 W
Map references: South America
Area:
total: 406,750 sq km
land: 397,300 sq km
water: 9,450 sq km
Area - comparative: slightly smaller than California
Land boundaries:
total: 3,920 km
border countries: Argentina 1 ,880 km, Bolivia 750 km,
Brazil 1,290 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to temperate; substantial rainfall
in the eastern portions, becoming semiarid in the far
west
Terrain: grassy plains and wooded hills east of Rio
Paraguay; Gran Chaco region west of Rio Paraguay
mostly low, marshy plain near the river, and dry forest
and thorny scrub elsewhere
Elevation extremes:
lowest point: junction of Rio Paraguay and Rio Parana
46 m
highest point: Cerro San Rafael 850 m
Natural resources: hydropower, timber, iron ore,
manganese, limestone
Population: 5,585,828 (July 2000 est.)
Age structure:
0-14 years: 39% (male 1 ,109,887; female 1 ,074,81 5)
15-64 years: 56% (male 1 ,574,978; female
1,563,872)
65 years and over: 5% (male 120,662; female
141,614) (2000 est.)
Population growth rate: 2.64% (2000 est.)
Birth rate: 31 .27 bir1hs/1 ,000 population (2000 est.)
Death rate: 4.81 deaths/1,000 population
(2000 est.)
Net migration rate: -0.09 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.01 male(s)/female (2000 est.)
Infant mortality rate: 30.81 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 73.68 years
male: 71 .22 years
female: 76.27 years (2000 est.)
Total fertility rate: 4.16 children bom/woman
(2000 est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic groups: mestizo (mixed Spanish and
Amerindian) 95%
Religions: Roman Catholic 90%, Mennonite, and
other Protestant
Languages: Spanish (official). Guarani (spoken by
most of rural population)
Literacy:
definition: age 15 and over can read and write
total population: 92. 1 %
male: 93.5%
female: 90.6% (1995 est.)
| "" G o v e r n m
Country name:
conventional long form: Republic of Paraguay
conventional short form: Paraguay
local long form: Republics dei Paraguay
local short form: Paraguay
Data code: PA
Government type: constitutional republic
Capital: Asuncion
Administrative divisions: 17 departments
(departamentos, singular - departamento) and one
capital city; Alto Paraguay, Alto Parana, Amambay,
Asuncion (city), Boqueron, Caaguazu, Caazapa,
Canindeyu, Centrai, Concepcion, Cordiliera, Guaira,
Itapua, Misiones, Neembucu, Paraguari, Presidents
Hayes, San Pedro
Independence: 14 May 1811 (from Spain)
National holiday: Independence Days, 14-15 May
(1811)
Constitution: promulgated 20 June 1992
Legal system: based on Argentine codes, Roman
law, and French codes; judicial review of legislative
acts in Supreme Court of Justice; does not accept
compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal and compulsory
up to age 75
Executive branch:
chief of state: President Luis GONZALEZ Macchi
(since 28 March 1 999); vice president (vacant); note -
the president is both the chief of state and head of','52454191a00654f48b530729d1b0d0a893328b9a901bbc8e459d2da0a8cbbd63','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4070a247d71289c5e491654fa77fa4d506344e29f88673cbdf0ef2ae650cddd4',2000,'MX','Mexico','people-and-society',393,'Population: 38,646,023 (July 2000 est.)
Age structure:
0-14 years: 1 9% (male 3,767,454; female 3,587,822)
1 5-64 years: 69% (male 1 3,201 ,825; female
13,352,950)
65 years and over: 1 2% (male 1 ,809,839; female
2,926,133) (2000 est.)
Population growth rate: -0.04% (2000 est.)
Birth rate: 10.13 births/1 ,000 population (2000 est.)
Death rate: 9.99 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.49 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 9.61 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
totai population: 73.19 years
male: 69.01 years
female: 77.6 years (2000 est.)
Total fertility rate: 1 .38 children born/woman
(2000 est.)
Nationality:
noun: Pole(s)
adjective: Poiish
Ethnic groups: Polish 97.6%, German 1 .3%,
Ukrainian 0.6%, Byelorussian 0.5% (1990 est.)
Religions: Roman Catholic 95% (about 75%
practicing). Eastern Orthodox, Protestant, and other
5%
Languages: Polish
Literacy:
definition: age 15 and over can read and write
totai population: 99%
male: 99%
female: 98% (1 978 est.)','2d92284039341eb8ccc32537cff3a7b402035e90ee9460ca598e0f72701d0767','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f71c6fe2cef443143896f7a72d3bcb5408f330c50f17f3d8c30e198e356a7be',2000,'MQ','Martinique','people-and-society',413,'Population: 6,896 (July 2000 est.)
Age structure:
0-14 years: 26A9% (male 924; female 882)
15-64 years: M.OtJo (male 2,254; female 2,160)
65 years and over: 9.8% (male 286; female 390)
(2000 est.)
Population growth rate: 0.49% (2000 est.)
Birth rate: 1 6.53 births/1 ,000 population (2000 est.)
Death rate: 6.67 deaths/1 ,000 population
(2000 est.)
Net migration rate: -4.93 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 1 .01 male(s)/female (2000 est.)
Infant mortality rate: 8.61 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77.6 years
male: 75.36 years
female: 79.95 years (2000 est.)
Total fertility rate: 2.14 children born/woman
(2000 est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Basques and Bretons (French
fishermen)
Religions: Roman Catholic 99%
Languages: French
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)
I Government
Country name:
conventional long form: Territorial Collectivity of Saint
Pierre and Miquelon
conventional short form: Saint Pierre and Miquelon
local long form: Departement de Saint-Pierre et
Miquelon
local short form: Saint-Pierre et Miquelon
Data code: SB
Dependency status: self-governing territorial
collectivity of France
Government type: NA
Capital: Saint-Pierre
Administrative divisions: none (territorial
collectivity of France)
note: there are no first-order administrative divisions
approved by the US Government, but there are two
communes - Saint Pierre, Miquelon
Independence: none (territorial collectivity of
France; has been under French control since 1763)
National holiday: National Day, Taking of the
Bastille, 14 July (1789)
Constitution: 28 September 1958 (French
Constitution)
Legal system: French law with special adaptations
for local conditions, such as housing and taxation
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Jacques CHIRAC of France
(since 17 May 1995), represented by Prefect Remi
THUAU (since NA)
head of government: President of the General
Council Bernard LE SOAVEC (since NA 1996)
cabinet: NA
elections: French president elected by popular vote
for a seven-year term; prefect appointed by the
French president on the advice of the French Ministry
of Interior; president of the General Council is elected
by the members of the council
Legislative branch: unicameral General Council or
Conseil General (19 seats - 15 from Saint Pierre and
4 from Miquelon; members are elected by popular
vote to serve six-year terms)
elections: elections last held 20 March 1994 (next to
be held NA April 2000)
election results: percent of vote by party ■ NA; seats
by party -RPR 15, other 4
note: Saint Pierre and Miquelon elect 1 seat to the
French Senate; elections last held NA September
1995 (next to be held NA September 2004); results -
percent of vote by party - NA; seats by party - RPR 1 ;
Saint Pierre and Miquelon also elects 1 seat to the
French National Assembly: elections last held 25
May-1 June 1 997 (next to be held NA 2002); results -
percent of vote by party - NA; seats by party - UDF 1
Judicial branch: Superior Tribunal of Appeals or
Tribunal Superieur d''Appel
Political parties and leaders: Rassemblement
pour la Republique or RPR [leader NA]; Socialist Party
or PS [leader NA]; Union pour la Democratie
Francaise or UDF [leader NA]
International organization participation: FZ,
WFTU
Diplomatic representation in the US: none
(territorial collectivity of France)
Diplomatic representation from the US: none
(territorial collectivity of France)
Flag description: a yellow sailing ship facing the
hoist side rides on a dark blue background with a
black wave line under the ship; on the hoist side, a
vertical band is divided into three parts: the top part is
red with a green diagonal cross extending to the
corners overlaid by a white cross dividing the square
into four sections: the middle part has a white
background with an ermine pattern; the third part has
a red background with two stylized yellow lions
outlined in black, one on top of the other; the flag of
France is used for official occasions','62638a2230d2ed83e8db1bd57dcd15144c9d414afbb4fa46e8211e389f9ec9c6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3e7c06933787c2437e0d8cac461eebaa9fc3527cda1720e2904eadc78cce484',2000,'GY','Guyana','people-and-society',444,'Population: 431 ,303 (July 2000 est.)
Age structure:
0-14 years: 32% (male 70,871 ; female 67,466)
15-64 years: 62% (male 1 37,209; female 1 31 ,905)
65 years and over: 6% (male 1 0,907; female 1 2,945)
(2000 est.)
Population growth rate: 0.65% (2000 est.)
Birth rate: 21.08 births/1,000 population (2000 est.)
Death rate: 5.69 deaths/1,000 population
(2000 est.)
Net migration rate: -8.92 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1 .03 male(s)/female (2000 est.)
Infant mortality rate: 25.06 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 71. 36 years
mate: 68.71 years
female: 74.14 years (20(X) est.)
Total fertility rate: 2.5 children born/woman
(2000 est.)
Nationality:
noun: Surinamer(s)
adjective: Surinamese
Ethnic groups: Hindustani (also known locally as
"East Indians"; their ancestors emigrated from
northern India in the latter part of the 1 9th century)
37%, Creole (mixed white and black) 31%, Javanese
1 5%, "Maroons" (their African ancestors were brought
to the country in the 17th and 18th centuries as slaves
and escaped to the interior) 10%, Amerindian 2%,
Chinese 2%, white 1%, other 2%
Religions: Hindu 27.4%, Muslim 19.6%, Roman
Catholic 22.8%, Protestant 25.2% (predominantly
Moravian), indigenous beliefs 5%
470
Languages: Dutch (official), English (widely
spoken), Sranang Tongo (Surinamese, sometimes
called Taki-Taki, is native language of Creoles and
much of the younger population and is lingua franca
among others), Hindustani (a dialect of Hindi),
Javanese
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 95%
female: 91% (1995 est.)','2763d0523391c67fc64573b193a0626176a64c961da6726f3630afbf5ba59b8a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ad4fdb2bcf415af72148078e4c4502643c7d8dc90f466fdf9213a6caa16de50',2000,'IT','Italy','people-and-society',448,'Population: 7,262,372 (July 2000 est.)
Age structure:
0-14 years: 17% (male 637,782; female 605,626)
15-64 years: 68% (male 2,498,540; female
2,421,802)
65 years and over: 15% (male 444,627; female
653,995) (2000 est.)
Population growth rate: 0.3% (2000 est.)
Birth rate: 10.4 births/1,000 population (2000 est.)
Death rate: 8.75 deaths/1 ,000 population
(2000 est.)
Net migration rate: 1 .38 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
infant mortaiity rate: 4.53 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 79.6 years
male: 76.73 years
female: 82.63 years (2000 est.)
Total fertility rate: 1 .47 children born/woman
(2000 est.)
Nationality:
noun: Swiss (singular and plural)
adjective: Swiss
Ethnic groups: German 65%, French 18%, Italian
10%, Romansch 1%, other 6%
Religions: Roman Catholic 46.1%, Protestant 40%,
other 5%, none 8.9% (1990)
Languages: German (official) 63.7%, French
(official) 19.2%, Italian (official) 7.6%, Romansch
0.6%, other 8.9%
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%','fbb2811e524499d2786a4f2f969cf01175fb691333af365a4754f2cd40830357','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3ade1c93553d2e3bcd5e2d6c553a54ed6c8aba050aae8745daf4bfff65c9efe',2000,'ZW','Zimbabwe','people-and-society',458,'Population: 35,306,126
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 45% (male 7,970,453; female 7,883,442)
15-64 years: 52% (male 9,1 10,501 ; female
9,325,726)
65 years and over: 3% (male 463,889; female
552,115) (2000 est.)
Population growth rate: 2.57% (2000 est.)
Birth rate: 40.17 births/1,000 population (2000 est.)
Death rate: 12.88 deaths/1 ,000 population
(2000 est.)
Net migration rate: -1 .59 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1.03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
infant mortality rate: 80.97 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 52.26 years
male: 51 .32 years
female: 53.23 years (2000 est.)
Total fertility rate: 5.51 children born/woman
(2000 est.)
Nationality:
noun; Tanzanian(s)
adjective: Tanzanian
Ethnic groups: mainland - native African 99% (of
which 95% are Bantu consisting of more than 130
tribes), other 1% (consisting of Asian, European, and
Arab); Zanzibar - Arab, native African, mixed Arab
and native African
Religions: mainland - Christian 45%, Muslim 35%,
indigenous beliefs 20%; Zanzibar - more than 99%
Muslim
Languages: Kiswahili or Swahili (official), Kiunguju
(name for Swahili in Zanzibar), English (official,
primary language of commerce, administration, and
higher education), Arabic (widely spoken in Zanzibar),
many local languages
note: Kiswahili (Swahili) is the mother tongue of the
Bantu people living in Zanzibar and nearby coastal
Tanzania; although Kiswahili is Bantu in structure and
origin, its vocabulary draws on a variety of sources,
including Arabic and English, and it has become the
lingua franca of central and eastern Africa; the first
language of most people is one of the local languages
Literacy;
definition: age 15 and over can read and write
Kiswahili (Swahili), English, or Arabic
total population: 67.8%
male: 79.4%
female: 56.8% (1995 est.)
Population: 61,230,874
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 24% (male 7,386,231; female 7,107,010)
15-64 years: 70% (male 21 ,1 02,363; female
21,714,411)
65 years and over: 6% (male 1 ,726,043; female
2,194,816) (2000 est.)
Population growth rate: 0.93% (2000 est.)
Birth rate: 16.86 births/1 ,000 population (2000 est.)
Thailand (continued)
Death rate: 7.53 dealhs/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/temale
under 15 years: 1 .04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate: 31 .48 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 68.55 years
male: 65.29 years
female: 71 .97 years (2000 est.)
Total fertility rate: 1 .88 children born/woman
(2000 est.)
Nationality:
noun; Thai (singular and plural)
adjective: Thai
Ethnic groups: Thai 75%, Chinese 14%, other 1 1 %
Religions: Buddhism 95%, Muslim 3.8%,
Christianity 0.5%, Hinduism 0.1%, other 0.6% (1991)
Languages: Thai, English (secondary language of
the elite), ethnic and regional dialects
Literacy:
definition: age 15 and over can read and write
total population: 92.6%
male: 96%
fema/e: 91. 6% (1995 est.)
I Government
Country name:
conventional long form: Kingdom of Thailand
conventional short form: Thailand
Data code: TH
Government type: constitutional monarchy
Capital: Bangkok
Administrative divisions: 76 provinces (changwat,
singular and plural); Amnat Charoen, Ang Thong,
Buriram, Chachoengsao, Chai Nat, Chaiyaphum,
Chanthaburi, Chiang Mai, Chiang Rai, Chon Buri,
Chumphon, Kalasin, Kamphaeng Phet,
Kanchanaburi, Khon Kaen, Krabi, Krung Thep
Mahanakhon (Bangkok), Lampang, Lamphun, Loei,
Lop Buri, Mae Hong Son, Maha Sarakham,
Mukdahan, Nakhon Nayok, Nakhon Pathom, Nakhon
Phanom, Nakhon Ratchasima, Nakhon Sawan,
Nakhon Si Thammarat, Nan, Narathiwat, Nong Bua
Lamphu, Nong Khai, Nonthaburi, Pathum Thani,
Pattani, Phangnga, Phatthalung, Phayao,
Phetchabun, Phetchaburi, Phichit, Phitsanulok, Phra
Nakhon Si Ayutthaya, Phrae, Phuket, Prachin Buri,
Prachuap Khiri Khan, Ranong, Ratchaburi, Rayong,
Roi Et, Sa Kaeo, Sakon Nakhon, Samut Prakan,
Samut Sakhon, Samut Songkhram, Sara Buri, Satun,
Sing Buri, Sisaket, Songkhia, Sukhothai, Suphan Buri,
Surat Thani, Surin, Tak, Trang, Trat, Ubon
Ratchathani, Udon Thani, Uthai Thani, Uttaradit, Yala,
/asothon
Independence: 1238 (traditional founding date;
never colonized)
National holiday: Birthday of His Majesty the King, 5
December (1927)
Constitution: new constitution signed by King
PHUMIPHON on 11 October 1997
Legal system: based on civil law system, with
influences of common law; has not accepted
compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal and compulsory
Executive branch:
chief of state: King PHUMIPHON Adunyadet (since 9
June 1946)
head of government: Prime Minister CHUAN Likphai
(since 15 November 1997)
cabinet: Council of Ministers
rrofe; there is also a Privy Council
elections: none; the monarch is hereditary; prime
minister designated from among the members of the
House of Representatives: following a national
election for the House of Representatives, the leader
of the party that can organize a majority coalition
usually becomes prime minister
Legislative branch: bicameral National Assembly or
Rathasapha consists of the Senate or Wuthisapha (a
253-member appointed body which will be phased
into a 200-member elected body starting in March
2000; members serve six-year terms) and the House
of Representatives or Sapha Phuthaen Ratsadon
(currently has 392 members, but will become a
500-member body after the next election; members
elected by popular vote to serve four-year terms)
elections: House of Representatives - last held 17
November 1996 (next scheduled to be held by 17
November 2000, but may be held earlier)
election results: House of Representatives - percent
of vote by party - NA; seats by party - NAP 125, DP
123, NDP52, TNP 39, SAP 20, TCP 18, SP8, LDP 4,
MP2, PDP1
Judicial branch: Supreme Court (Sandika), judges
appointed by the monarch
Political parties and leaders: Democratic Party or
DP (Prachathipat Party) [CHUAN Likphai); Liberal
Democratic Party or LDP (Seri Tham) [PHINIT
Charusombatj; Mass Party or MP [CHALERM
Yoobamrung, SOPHON Petchsavang); National
Development Party or NDP (Chat Phattana) [KON
Thappharangsi); New Aspiration Party or NAP
(Khwamwang Mai) [Gen. CHAWALIT Yongchaiyut);
Phalang Dharma Party or PDP (Phaiang Tham)
[CHAIWAT Sinsuwong); Social Action Party or SAP
(Kitsangkhom Party) [SUWIT Khunkitti); Solidarity
Party or SP (Ekkaphap Parly) [CHAIYOT Sasomsapj;
Thai Citizen''s Party or TCP (Prachakon Thai) [SAMAK
Sunthonwetj; Thai Nation Party or TNP (Chat Thai
Party) [BANHAN Sinlapa-acha); Thai Rak Thai Party
or TRT [THAKSIN Chinnawat]
International organization participation: APEC,
AsDB, ASEAN, CCC, CP, ESCAP, FAO, G-77, IAEA,
IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS,
IHO, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC,
lOM, ISO, ITU, NAM, OAS (observer), OPCW, PCA,
UN, UNCTAD, UNESCO, UNHCR, UNIDO, UNIKOM,
UNITAR, UNMIBH, UNTAET, UNU, UPU, WCL,
WFTU, WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador NIT Phibunsongkhram
(due to leave March 2000)
chancery: 1024 Wisconsin Avenue NW, Washington,
DC 20007
telephone: [1] {202) 944-3600
FAY;[1] (202) 944-3611
consulate(s) general: Chicago, Los Angeles, and New
York
Diplomatic representation from the US:
chief of mission: Ambassador Richard HECKLINGER
embassy: 120 Wireless Road, Bangkok
mailing address: APO AP 96546
fe/ephorre; [661(2) 205-4000
FAX; [661(2)254-2990
consulate(s) general: Chiang Mai
Flag description; five horizontal bands of red (top),
white, blue (double width), white, and red
.
Economy ■ overview: After enjoying the world''s
highest growth rate from 1 985 to 1 995 - averaging
almost 9% annually - increased speculative pressure
on Thailand''s currency in 1997 led to a crisis that
uncovered financial sector weaknesses and forced
the government to float the baht. Long pegged at 25 to
the dollar, the baht reached its lowest point of 56 to the
dollar in January 1 998 and the economy contracted by
nearly 10% that same year. Thailand entered a
recovery stage in 1 999; preliminary estimates are that
the economy expanded by about 4% - most
forecasters expect similar growth in 2000. Beginning
in 1999 the baht stabilized and inflation and interest
rates began coming down. The CHUAN government
has cooperated closely with the IMF and adhered to
its mandated recovery program, including passage of
new bankruptcy and foreclosure laws. The regional
recovery boosted exports, while fiscal stimulus
buoyed domestic demand. While slow progress has
been made in recapitalizing the financial sector, tough
measures - such as implementing a privatization plan
and forcing the private sector to restructure - remain
undone.
GDP: purchasing power parity - $388.7 billion
(1999 est.)
GDP - real growth rate: 4% (1999 est.)
GDP - per capita: purchasing power parity - $6,400
(1999 est.)
GDP - composition by sector;
agriculture: 12%
industry: 39%
serv/ces; 49% (1997 est.)
Population beiow poverty iine; 12.5% (1998 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.5%
highest 10%; 37.1% (1992)
Inflation rate (consumer prices); 2.4% (1999 est.)
Labor force: 32.6 million (1 997 est.)
489
Thailand (continued)
Labor force - by occupation: agriculture 54%,
industry 15%, services 31% (1996 est.)
Unemployment rate: 4.5% (1998 est.)
Budget:
revenues: $20 billion
expenditures: $23 biiiion, inciuding capital
expenditures of $NA (1999 est.)
Industries: tourism; textiles and garments,
agricultural processing, beverages, tobacco, cement,
light manufacturing, such as jeweiry; electric
appliances and components, computers and parts,
integrated circuits, furniture, piastics; worid''s
second-largest tungsten producer and third-largest tin
producer
Industrial production growth rate: 12.6%
(1999 est.)
Electricity - production: 85 billion kWh (1999)
Electricity - production by source:
fossii fuei: 91 .44%
hydro; 8.56%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 80.293 billion kWh
(1999)
Electricity • exports: 1 38 million kWh (1 998)
Electricity ■ imports: 700 million kWh (1998)
Agriculture - products: rice, cassava (tapioca),
rubber, corn, sugarcane, coconuts, soybeans
Exports: $58.5 billion (f.o.b., 1999 est.)
Exports - commodities: computers and parts,
textiles, rice
Exports - partners: US 22.3%, Japan 13.7%,
Singapore 8.6%, Hong Kong 5.1%, Netherlands
4.0%, UK 3.9%, Malaysia 3.3%, China 3.2%, Taiwan
3.2%, Germany 2.9% (1998)
Imports: $45 billion (f.o.b., 1999 est.)
Imports - commodities: capital goods, intermediate
goods and raw materials, consumer goods, fuels
imports - partners: Japan 23.6%, US 14.0%,
Singapore 5.5%, Malaysia 5.1%, Taiwan 5.2%,
Germany 4.2%, China 4.2%, South Korea 3.5%,
Oman 2.6%, Indonesia 2.1% (1998)
Debt - external: $80 billion (1999 est.)
Economic aid - recipient: $1 .732 billion (1 995)
Currency: 1 baht (B) = 100 satang
Exchange rates: baht (B) per US$1 - 37.349
(January 2000), 37.844 (1 999), 41 .359 (1 998), 31 .364
(1997), 25.343 (1996), 24.915 (1995)
Fiscal year: 1 October - 30 September','dc3002d6d8aa234c082e784c782deb8694b3e1d0f64a413b95ee34490d2f0f7c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1ce4587ca0cc6cb7d862519db573c04a4a8be3b8acc0b705c0b30dd9db2cdda',2000,'UY','Uruguay','people-and-society',472,'Population: 24,755,51 9 (July 2000 est.) -
Age structure:
0-14 years: 37% (male 4,673,501 ; female 4,520,471 )
526
Uzbekistan (continued)
15-64 years: 58% (male 7,140,215; female
7,283,143)
65 years and over: 5% (male 452,480; female
685,709) (2000 est.)
Population growth rate: 1 .6% (2000 est.)
Birth rate; 26.1 8 births/1 ,000 population (2000 est.)
Death rate: 8.02 deaths/1 ,000 popuiation
(2000 est.)
Net migration rate: -2.18 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 72.13 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 83.71 years
male: 60.09 years
female: 67.52 years (2000 est.)
Total fertility rate: 3.09 children born/woman
(2000 est.)
Nationality;
noun: Uzbekistani(s)
adjective: Uzbekistan!
Ethnic groups: Uzbek 80%, Russian 5.5%, Tajik
5%, Kazakh 3%, Karakalpak 2.5%, Tatar 1 .5%, other
2.5% (1996 est.)
Religions: Muslim 88% (mostly Sunnis), Eastern
Orthodox 9%, other 3%
Languages: Uzbek 74.3%, Russian 14.2%, Tajik
4.4%, other 7.1%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (yearend 1996)
I Government
Country name;
conventional long form: Republic of Uzbekistan
conventional short form: Uzbekistan
local long form: Uzbekistan Respublikasi
local short form: none
former: Uzbek Soviet Socialist Republic
Data code: UZ
Government type: republic; effectively authoritarian
presidential rule, with little power outside the
executive branch; executive power concentrated in
the presidency
Capital: Tashkent (Tashkent)
Administrative divisions; 1 2 wiloyatlar (singular -
wiloyat), 1 autonomous republic* (respublikasi), and 1
city** (shahri); Andijon Wiloyati, Bukhoro Wiloyati,
Farghona Wiloyati, Jizzakh Wiloyati, Khorazm
Wiloyati (Urganch), Namangan Wiloyati, Nawoiy
Wiloyati, Qashqadaryo Wiloyati (Qarshi),
Qoraqalpoghiston* (Nukus), Samarqand Wiloyati,
Sirdaryo Wiloyati (Guliston), Surkhondaryo Wiloyati
(Termiz), Tashkent Shahri**, Tashkent Wiloyati
note: administrative divisions have the same names
as their administrative centers (exceptions have the
administrative center name following in parentheses)
Independence; 31 August 1991 (from Soviet Union)
National holiday: Independence Day, 1 September
(1991)
Constitution : new constitution adopted 8 December
1992
Legal system: evolution of Soviet civil law; still lacks
independent judicial system
Suffrage: 1 8 years of age; universal
Executive branch;
chief of state: President Islom KARIMOV (since 24
March 1990, when he was elected president by the
then Supreme Soviet)
head of government: Prime Minister Otkir
SULTONOV (since 21 December 1995) and 10
deputy prime ministers
cabinet: Cabinet of Ministers appointed by the
president with approval of the Supreme Assembly
elections: president elected by popular vote for a
five-year term; election last held 9 January 2000 (next
to be held NA January 2005); note - extension of
President KARIMOV''S original term for an additional
five years overwhelmingly approved - 99.6% of total
vote in favor - by national referendum held 26 March
1 995); prime minister and deputy ministers appointed
by the president
election results: Islom KARIMOV reelected president;
percent of vote - Islom KARIMOV 91 .9%, Abdulkhafiz
D2HALALOV4.2%
Legislative branch: unicameral Supreme Assembly
or Oliy Majlis (250 seats; members elected by popular
vote to serve five-year terms)
elections: last held 5 December 1999 (next to be held
NA December 2004)
election results: percent of vote by party - NA; seats
by party - NDP 32, Fidokorlar 1 9. Fatherland Progress
Party 9, Adolat Social Democratic Party 9, MTP 6,
local government 98, initiative groups 1 1 , other 66
note: not all seats in the last Supreme Assembly
election were contested; all parties in the Supreme
Assembly support President KARIMOV
Judicial branch: Supreme Court, judges are
nominated by the president and confirmed by the
Supreme Assembly
Political parties and leaders; Adolat (Justice)
Social Democratic Party [Turgunpulat DAMINOV, first
secretary]; Democratic National Rebirth Party (Milly
Tiklanish) or MTP [Ibrahim GAFUROV, chairman];
Fatherland Progress Party (Vatan Tarakiyoti) or VTP
[Anvar YULDASHEV, chairman]; People''s
Democratic Party or NDP (formerly Communist Party)
[Abdulkhafiz JALOLOV, first secretary];
Self-Sacrificers Party or Fidokorlar [Erkin
NORBOTAEV, general secretary]
Political pressure groups and leaders; Birlik
(Unity) Movement [Abdurakhim PULATOV,
chairman]; Erk (Freedom) Democratic Party [Muhamd
SOLIH, chairman] was banned 9 December 1992;
Human Rights Society of Uzbekistan [Abdumanob
PULATOV, chairman]; Independent Human Rights
Society of Uzbekistan [Mikhail AROZINOV, chairman]
International organization participation: AsDB,
CCC, CIS, EAPC, EBRD, ECE, ECO, ESCAP, IAEA,
IBRD, ICAO, ICRM, IDA, IFC, IFRCS, ILO, IMF,
Intelsat, Interpol, IOC, ISO, ITU, NAM, OPCW, OSCE,
PFP, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU,
WHO, WlPO, WMO, WToO, WTrO (applicant)
Diplomatic representation in the US;
chief of mission: Ambassador Sadyk SAFAYEV
chancery: 1746 Massachusetts Avenue NW,
Washington, DC 20036
fe/eptor7e;[1] (202) 887-5300
FAY; [1] (202) 293-6804
consulate(s) general: New York
Diplomatic representation from the US;
c/r/e/ofm/ss/orr; Ambassador Joseph A. PRESEL
embassy: 82 Chilanzarskaya, Tashkent 700115
mailing address: use embassy street address; US
Embassy Tashkent, Department of State,
Washington, DC 20521-71 10
fe/ep/7or)e;[998] (71) 120-5450
FAX;[998] (71) 120-6335
Flag description: three equal horizontal bands of
blue (top), white, and green separated by red
fimbriations with a white crescent moon and 12 white
stars in the upper hoist-side quadrant
- E g Q n Q y "
Economy - overview; Uzbekistan is a dry,
landlocked country of which 10% consists of intensely
cultivated, irrigated river valleys. It was one of the
poorest areas of the former Soviet Union with more
than 60% of its population living in densely populated
rural communities. Uzbekistan is now the world''s third
largest cotton exporter, a major producer of gold and
natural gas, and a regionally significant producer of
chemicals and machinery. Following independence in
December 1991, the government sought to prop up its
Soviet-style command economy with subsidies and
tight controls on production and prices. Faced with
high rates of inflation, however, the government
began to reform in mid-1994, by introducing tighter
monetary policies, expanding privatization, slightly
reducing the role of the state in the economy, and
improving the environment for foreign investors. The
state continues to be a dominating influence in the
economy, and reforms have so far failed to bring
about much-needed structural changes. The IMF
suspended Uzbekistan''s $185 million standby
arrangement in late 1996 because of governmental
steps that made impossible fulfillment of Fund
conditions. Uzbekistan has responded to the negative
external conditions generated by the Asian and
Russian financial crises by tightening export and
currency controls within its already largely closed
economy. Economic policies that have repelled
foreign investment are a major factor in the economy''s
stagnation. A growing debt burden, persistent
inflation, and a poor business climate cloud growth
prospects in 2000.
GDP: purchasing power parity - $59.3 billion
(1999 est.)
GDP - real growth rate: -1% (1999 est.)
527
Uzbekistan (continued)
GDP ■ per capita: purchasing power parity - $2,500
(1999 est.)
GDP - composition by sector:
agriculture: 27%
industry: 27%
sen/ices: 46% (1 997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 29% (1999 est.)
Labor force: 11.9 million (1998 est.)
Labor force - by occupation: agriculture and
forestry 44%, industry 20%, services 36% (1995)
Unemployment rate: 5% plus another 10%
underemployed (December 1996 est.)
Budget:
revenues: $4.4 billion
expenditures: $4.7 billion, including capital
expenditures of $1 .1 billion (1 997 est.)
Industries: textiles, food processing, machine
building, metallurgy, natural gas
Industrial production growth rate: 6% (1999 est.)
Electricity - production: 43.47 billion kWh (1998)
Electricity - production by source:
fossil fuel: 85.2%
hydro: 14.8%
nuclear: 0%
other; 0% (1998)
Electricity ■ consumption: 41 .327 billion kWh
(1998)
Electricity ■ exports: 5.1 billion kWh (1998)
Electricity - imports: 6 billion kWh (1998)
Agriculture ■ products: cotton, vegetables, fruits,
grain; livestock
Exports: $2.9 billion (1999 est.)
Exports - commodities: cotton, gold, natural gas,
mineral fertilizers, ferrous metals, textiles, food
products, automobiles
Exports - partners: Russia 15%, Switzerland 10%,
UK 10%, Belgium 4%, Kazakhstan 4%, Tajikistan 4%
(1998)
Imports: $3.1 billion (1999 est.)
Imports - commodities: machinery and equipment,
chemicals, metals; foodstuffs
Imports - partners: Russia 1 6%, South Korea 11%,
Germany 8%, US 7%, Turkey 6%, Kazakhstan 5%
(1998)
Debt - external: $3.2 billion (1998 est.)
Economic aid - recipient: $276.6 million (1995)
Currency: Uzbekistan! som (UKS)
Exchange rates: Uzbekistan! soms (UKS) per
US$1 - 1 41 .4 (January 2000), 1 1 1 .9 (February 1 999),
110.95 (December 1998), 75.8 (September 1997),
41.1 (1996), 30.2 (1995)
Fiscal year: calendar year
I Communications
Telephones - main lines in use: 1.976 million
(1999)
Telephones - mobile cellular: 26,000 (1998)
Telephone system: antiquated and inadequate; in
serious need of modernization
domesf/c; the domestic telephone system is being
expanded and technologically improved, particularly
in Tashkent and Samarqand, under contracts with
prominent companies in industrialized countries;
moreover, by 1998, six cellular networks had been
placed in operation - four of the GSM type (Global
System for Mobile Communication), one D-AMPS
type (Digital Advanced Mobile Phone System), and
one AMPS type (Advanced Mobile Phone System)
international: linked by landline or microwave radio
relay with CIS member states and to other countries
by leased connection via the Moscow international
gateway switch; after the completion of the Uzbek link
to the Trans-Asia-Europe (TAE) fiber-optic cable,
Uzbekistan will be independent of Russian facilities
for international communications; Inmarsat also
provides an international connection, albeit an
expensive one; satellite earth stations - NA (1998)
Radio broadcast stations: AM 20, FM 7, shortwave
10 (1998)
Radios: 10.2 million (1997)
Television broadcast stations: 4 (plus two
repeater stations that relay Russian, Kazakh, Kyrgyz,
and Tadzhik programs) (1997)
Televisions: 6.4 million (1997)
Internet Service Providers (ISPs): 1 (1999)
|[ ~ t r a iTs p b Ft Tt i b n
Railways:
total: 3,380 km in common carrier service; does not
include industrial lines
broad gauge: 3,380 km 1 .520-m gauge (300 km
electrified) (1993)
Highways:
total: 81 ,600 km
paved: 71 ,237 km (these roads are said to be
hard-surfaced, meaning that some are paved and
some are all-weather gravel-surfaced)
unpaved: 10, 3Q3 km (dirt) (1996 est.)
Waterways: 1,100(1990)
Pipelines: crude oil 250 km; petroleum products 40
km; natural gas 810 km (1992)
Ports and harbors: Termiz (Amu Darya river)
Airports: 3 (1997 est.)
Airports - with paved runways:
total: 3
over 3,047 m: 2
2,438 to 3,047 m:1 (1997 est.)
f: Military
Military branches: Army, Air and Air Defense
Forces, Security Forces (internal and border troops).
National Guard
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 6,357,625 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 5, 1 61 ,926 (2000 est.)
Military manpower - reaching military age
annually:
males: 262,289 (2000 est.)
Military expenditures - dollar figure: $200 million
(FY97)
Military expenditures - percent of GDP: 2%
(FY97)
I transnational Issues
Disputes - international: none
Illicit drugs: limited illicit cultivation of cannabis and
very small amounts of opium poppy, mostly for
domestic consumption, almost entirely eradicated by
an effective government eradication program;
increasingly used as transshipment point for illicit
drugs from Afghanistan to Russia and Western
Europe and for acetic anhydride destined for','19502ef84090bb03e3fba0c15c2995f98f1f2250ef8e8c179e628d60091e963d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dca48284cc6984ef8f852ad433bc6781ecaf473c1205da46d8a1c1f8f31d5ba',2000,'AF','Afghanistan','people-and-society',473,'528
Background; The British and French who settled the
New Hebrides in the 19th century, agreed in 1906 to
an Anglo-French Condominium, which administered
the islands until independence in 1980.
f G ''e”o g r a pThf ”
Location: Oceania, group of islands in the South
Pacific Ocean, about three-quarters of the way from
Hawaii to Australia
Geographic coordinates: 16 00 S, 167 00 E
Map references: Oceania
Area:
total: 14,760 sq km
/and; 14,760 sq km
water: 0 sq km
note: includes more than 80 islands
Area - comparative; slightly larger than Connecticut
Land boundaries: 0 km
Coastline: 2,528 km
Maritime claims: measured from claimed
archipelagic baselines
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: ''\\2nm
Climate: tropical; moderated by southeast trade
winds
Terrain: mostly mountains of volcanic origin; narrow
coastal plains
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: Tabwemasana 1 ,877 m
Natural resources; manganese, hardwood forests,
fish
Land use;
arable land: 2%
permanent crops: 10%
permanent pastures: 2%
forests and woodland: 75%
ote11%(1993 est.)
Irrigated land; NAsqkm
Natural hazards; tropical cyclones or typhoons
(January to April); volcanism causes minor
earthquakes
Environment - current issues: a majority of the
population does not have access to a potable and
reliable supply of water; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected
agreements
I People
Population: 1 89,61 8 (July 2000 est.)
Age structure:
0-14 years: 37% (male 35,934; female 34,404)
15-64 years: 60% (male 58,155; female 55,156)
65 years and over: 3% (male 3,228; female 2,741 )
(2000 est.)
Population growth rate: 1.74% (2000 est.)
Birth rate: 25.93 births/1,000 population (2000 est.)
Death rate: 8.52 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 1.18 male(s)/female
totai population: 1.05 male(s)/female (2000 est.)
Infant mortality rate: 62.52 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
totai population: 60.57 years
male: 59.23 years
female: 61 .98 years (2000 est.)
Total fertility rate: 3.29 children born/woman
(2000 est.)
Nationality:
noun: Ni-Vanuatu (singular and plural)
adjective: Ni-Vanuatu
Ethnic groups: indigenous Melanesian 94%,
French 4%, Vietnamese, Chinese, Pacific Islanders
Religions: Presbyterian 36.7%, Anglican 15%,
Roman Catholic 15%, indigenous beliefs 7.6%,
Seventh-Day Adventist 6.2%, Church of Christ 3.8%,
other 15.7%
Languages: English (official), French (official),
pidgin (known as Bislama or Bichelama)
Literacy:
definition: age 15 and over can read and write
total population: 53%
male: 57%
female: 48% (1 979 est.)
I 6 oTv e^r nTm^ nT
Country name;
conventional long form: Republic of Vanuatu
conventional short form: Vanuatu
former: New Hebrides
Data code; NH
Government type: republic
Capital; Port-Vila
Administrative divisions; 6 provinces; Malampa,
Penama, Sanma, Shefa, Tafea, Torba
Independence: 30 July 1980 (from France and UK)
National holiday; Independence Day, 30 July
(1980)
Constitution; 30 July 1 980
Legal system: unified system being created from
former dual French and British systems
Suffrage; 18 years of age; universal
Executive branch;
chief of state: President Father John BANI (since 25
March 1999)
head of government: Prime Minister Barak SOPE
(since 25 November 1999); Deputy Prime Minister
Stanley REGINALD (since 25 November 1999)
cabinet: Council of Ministers appointed by the prime
minister, responsible to Parliament
elections: president elected by an electoral college
consisting of Parliament and the presidents of the
regional councils for a five-year term; election for
president last held 25 March 1 999 (next to be held NA
2004); following legislative elections, the leader of the
majority party or majority coalition is usually elected
prime minister by Parliament from among its
members; election for prime minister last held 6 March
1998 (next to be held NA2002)
eiection resuits: Father John BANI elected president;
percent of electoral college vote - NA; Barak SOPE
elected prime minister by Parliament with a total of 28
votes; other candidate, Edward NATAPEI, received
24 votes
note: as a result of legislative elections in March 1 998,
Donald KALPOKAS was elected prime minister and
the VP formed a coalition government with the NUP;
in November 1999, KALPOKAS, facing strong
opposition and the threat of a no confidence vote.
529
Vanuatu (continued)
resigned; Barak SOPE was elected prime minister in
his place and a coalition government was formed
Legislative branch: unicameral Parliament (52
seats; members elected by popular vote to serve
four-year terms)
elections: last held 6 March 1 998 (next to be held NA
2002)
election results: percent of vote by party - NA; seats
by party- VP 18, UMP 12, NUP 11, other and
independent 1 1 ; note - political party associations are
fluid; there have been four changes of government
since the November 1995 elections
note; the National Council of Chiefs advises on
matters of custom and land
Judicial branch: Supreme Court, chief justice is
appointed by the president after consultation with the
prime minister and the leader of the opposition, three
other justices are appointed by the president on the
advice of the Judicial Service Commission
Political parties and leaders: Friend Melanesian
Party [Albert RAVUTIAj; John Frum Movement
[leader NAj; Melanesian Progressive Party or MPP
[Barak SOPEj; Na-Griamei Movement [Frankie
STEVENS]; National United Party or NUP [Willie
TITONGOAj; Tan Union orTU [Vincent
BOULEKONEj; Union of Moderate Parties or UMP
[Serge VOHORj; Vanuatu Party or VP [Donald
KALPOKASj; Vanuatu Republican Party [Maxime
Carlot KORMAN]
International organization participation: ACCT,
ACP, AsDB, C, ESCAP, FAO, G-77, IBRD, ICAO,
ICFU, ICRM, IDA, IFC, IFRCS, IMF, IMO, Intelsat
(nonsignatory user), IOC, ITU, NAM, Sparteca, SPC,
SPF, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU,
WHO, WMO, WTrO (applicant)
Diplomatic representation in the US: Vanuatu
does not have an embassy in the US, it does,
however, have a Permanent Mission to the UN
Diplomatic representation from the US: the US
does not have an embassy in Vanuatu; the
ambassador to Papua New Guinea is accredited to','dd6566762819410ddecb93dcb0fd247fae9be39f972cd180f07f0c4a8cef6c4f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88725d3f9c2ca7a0db2b4b63b3a6d261e373e466e25189fccb860e780a8bfde4',2000,'VU','Vanuatu','people-and-society',474,'Flag description: two equal horizontal bands of red
(top) and green with a black isosceles triangle (based
on the hoist side) all separated by a black-edged
yellow stripe in the shape of a horizontal Y (the two
points of the Y face the hoist side and enclose the
triangle); centered in the triangle is a boar''s tusk
encircling two crossed namele leaves, all in yellow
f Economy
Economy - overview: The economy is based
primarily on subsistence or small-scale agriculture
which provides a living for 65% of the population.
Fishing, offshore financial services, and tourism, with
about 50,000 visitors in 1997, are other mainstays of
the economy. Mineral deposits are negligibie; the
country has no known petroleum deposits. A smali
light industry sector caters to the local market. Tax
revenues come mainly from import duties. Economic
development is hindered by dependence on relativeiy
few commodity exports, vulnerability to naturai
disasters, and long distances from main markets and
between constituent islands. The most recent natural
disaster, a severe earthquake in November 1999
followed by a tsunami, caused extensive damage to
the northern island of Pentecote and left thousands
homeless.
GDP: purchasing power parity - $245 million
(1999 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $1 ,300
(1999 est.)
GDP - composition by sector:
agriculture: 24%
industry: 13%
services: 63% (1997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3.9% (1998 est.)
Labor force: NA
Labor force - by occupation: agriculture 65%,
services 32%, industry 3% (1995 est.)
Unemployment rate: NA%
Budget:
revenues: $94.4 million
expenditures: $99.8 million, including capital
expenditures of $30.4 million (1996 est.)
Industries: food and fish freezing, wood processing,
meat canning
Industrial production growth rate: 1% (1997 est.)
Electricity • production: 32 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%{im)
Electricity - consumption: 30 million kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: copra, coconuts, cocoa,
coffee, taro, yams, coconuts, fruits, vegetables; fish,
beef
Exports: $33.8 million (f.o.b., 1998)
Exports - commodities: copra, beef, cocoa, timber,
coffee
Exports - partners: Japan 32%, Germany 14%,
Spain 8%, New Caledonia 7%, Australia 2%
(1997 est.)
Imports: $76.2 million (f.o.b., 1998)
Imports - commodities: machinery and equipment,
foodstuffs, fuels
Imports - partners: Japan 52%, Australia 20%, New
Caledonia, Singapore, New Zealand, France, Fiji
(1997 est.)
Debt - external: $48 million (1997 est.)
Economic aid - recipient; $45.8 million (1995)
Currency: 1 vatu (VT) = 100 centimes
Exchange rates: vatu (VT) per US$1 - 129.76
(December 1999), 129.08 (1999), 127.52 (1998),
1 1 5.87 (1 997), 1 1 1 .72 (1 996), 1 1 2.1 1 (1 995)
Fiscal year: calendar year
t Communications
Telephones - main lines in use: 2,500 (1995)
Telephones - mobile cellular: 121 (1995)
Telephone system;
domestic: NA
International: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM 2, shortwave
1 (1998)
Radios: 62,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 2,000(1997)
Internet Service Providers (ISPs): 2 (1999)','3e3a9046290c51c640a1b47a0b2b269ae202d7a7418c582542f1ff04443458f4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9613ca9ff85eacf465addfd17e3121c5bedc807c0e07060dc6fca6eebc917590',2000,'MP','Northern Mariana Islands','people-and-society',483,'Population: no indigenous inhabitants
note: US miiitary personnel have left the island, but
some civilian personnel remain (July 2000 est.)','b1e8ff878448cb5a3b7aa928ab234f6e7640022f726c1d51c9569cca9781b9d2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3d9bf8f069b7db2556eea2754b69242d083411e5f22f25e747985b6779560aa',2000,'SO','Somalia','people-and-society',490,'Population: 17,479,206 (July 2000 est.)
Age structure;
0-14 years: 47% (male 4,220,621 ; female 4,076,902)
15-64 years: 49% (male 4,416,139; female
4,224,474)
65 years and over: 4% (male 275,590; female
265,480) (2000 est.)
Population growth rate: 3.36% (2000 est.)
Birth rate: 43.44 bir1hs/1 ,000 population (2000 est.)
Death rate: 9.86 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 1 .04 male(s)/female
total population: 1.04 male(s)/female (2000 est.)
Infant mortality rate: 70.28 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 59.83 years
male: 58.1 years
female: 61 .64 years (2000 est.)
Total fertility rate: 7.05 children born/woman
(2000 est.)
Nationality;
noun: Yemeni(s)
adjective: Yemeni
Ethnic groups: predominantly Arab; but also
Afro-Arab, South Asians, Europeans
Religions: Muslim including Shaf''i (Sunni) and Zaydi
(Shi''a), small numbers of Jewish, Christian, and Hindu
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 53%
female: 28% (1990 est.)','aa4bf64d7827d5240c211a2ea002dd1bad49646279a36109ddc1acba65031058','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

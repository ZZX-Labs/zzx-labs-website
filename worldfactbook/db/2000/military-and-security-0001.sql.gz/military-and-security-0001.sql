SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b89628e5b0b850f56a23cdd07439071ead746418200d46ae224b6a221209f0cd',2000,'EH','Western Sahara','military-and-security',16,'Military branches
Military manpower - military age
Military manpower - availability
mates age 15-49
females age 15-49
Military manpower - fit for military service
mates age 15-49
females age 15-49
Military manpower - reaching military age
annually
males
females
Military expenditures - dollar figure
Military expenditures - percent of GDP
Military - note','867ae754fb779ab60c85fda4840072be3164e3b01d67d9ba19ad4c900bd13eb7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1feef3bfcf11a95680af6f59ff8e25711b9fb5097aee8b8df5d6201005640dd',2000,'AD','Andorra','military-and-security',25,'Military ■ note: defense is the responsibility of
the US
Military branches: Army, Navy, Air and Air Defense
Forces, National Police Force
Military manpower - military age: 18 years of age
Military manpower - availability;
males age 15-49: 2,429,842 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,221 ,277 (2000 est.)
Military manpower - reaching military age
annuaily;
males: 101 ,434 (2000 est.)
Military expenditures - dollar figure: $1 .2 billion
(FY97/98)
Military expenditures - percent of GDP; 25%
(FY97/98)','98b75f068d02579397c29d412f08fb89053f997621436649b64eb25cb927c3d4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a7b2898d8f8ec4e28af12020f924d990c6465ae6aee7c26d07db3a540afb2a2',2000,'AI','Anguilla','military-and-security',30,'(overseas territory
of the UK)
Sombrero North
Atlantic
Caribbean Ocean
Sea
Anguill^
St. Martin^^^y^''''
Prjckley
Pear - Seal
o Dog Cays island
Island
Road Bay
Caribbean
Sea
North
Atlantic
Ocean
. THE V«^Y
""Blowing Point
St Martin
(FRANCE and NETH.)','10c189bc0abab22fc6f79ae09fcb79c4d41a82d04b1d036d8594e2d6b6e9a071','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2829734553d77f57381ec33a4f68db7b9400da39937bab295298c144bfb5f612',2000,'AZ','Azerbaijan','military-and-security',58,'Military branches: Army, Navy, Air and Air Defense
Forces, Border Guards
Military manpower ■ military age: 1 8 years of age
Military manpower • availability:
males age 15-49; 2,073,067 (2000 est.)
Military manpower - fit for military service:
males age 15-49; 1,662,435 (2000 est.)
Military manpower - reaching military age
annually;
males: 74,496 (2000 est.)
Military expenditures - dollar figure: $121 million
(FY99)
Military expenditures - percent of GDP: 2.6%
(FY99)
T r a n s n a t i 0 n a i i s s u e s
Disputes - international: Armenia supports ethnic
Armenians In the Nagorno-Karabakh region of
Azerbaijan In the longstanding, separatist conflict
against the Azerbaijani Government; Caspian Sea
boundaries are not yet determined among Azerbaijan,
Iran, Kazakhstan, Russia, and Turkmenistan
Illicit drugs: limited illicit cultivation of cannabis and
opium poppy, mostly for CIS consumption; limited
government eradication program; transshipment point
for opiates via Iran, Central Asia, and Russia to
Western Europe
Background: Since attaining independence from
the UK in 1973, The Bahamas have prospered
through tourism and international banking and
investment management. By the early 1980s, the
islands had become a major center for drug trafficking,
particularly shipments to the US.
I Geography
Location: Caribbean, chain of islands in the North
Atlantic Ocean, southeast of Florida
Geographic coordinates: 24 15 N, 76 00 W
Map references: Central America and the
Caribbean
Area:
total: 13,940 sq km
land: 10,070 sq km
water: 3,870 sq km
Area - comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline; 3,542 km
Maritime claims;
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; moderated by warm waters
of Gulf Stream
Terrain: long, flat coral formations with some low
rounded hills
Elevation extremes;
towestpo/nf; Atlantic Ocean 0 m
highest point: Mount Alvernia, on Cat Island 63 m
Natural resources: salt, aragonite, timber
Land use;
arable land: 1%
permanent crops: 0%
permanent pastures: 0%
36
Bahamas, The (continued)
forests and woodland: 32%
of/7er;67%(1993 est.)
Irrigate(l land; NAsqkm
Natural hazards; hurricanes and other tropical
storms that cause extensive flood and wind damage
Environment - current issues; coral reef decay;
solid waste disposal .
Environment - international agreements;
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Endangered Species,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note; strategic location adjacent to US
and Cuba; extensive island chain
I — ^ - P g Q p 1^ ’
Population; 294,982
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 30% (male 44,339; female 43,667)
15-64 years: 64% (male 93,072; female 96,457)
65 years and over: 6% (male 7,298; female 10,149)
(2000 est.)
Population growth rate; 1.01% (2000 est.)
Birth rate; 19.54 births/1 ,000 population (2000 est.)
Death rate; 6.81 deaths/1 ,000 population
(2000 est.)
Net migration rate; -2.67 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1.02 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and oven 0.72 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate; 16.99 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 71 .07 years
male: 68.25 years
female: 73.94 years (2000 est.)
Total fertility rate; 2.33 children born/woman
(2000 est.)
Nationality;
noun: Bahamian(s)
adjective: Bahamian
Ethnic groups; black 85%, white 12%, Asian and
Hispanic 3%
Religions; Baptist 32%, Anglican 20%, Roman
Catholic 1 9%, Methodist 6%, Church of God 6%, other
Protestant 12%, none or unknown 3%, other 2%
Languages; English, Creole (among Haitian
immigrants)
Literacy;
definition: age 15 and over can read and write
total population: 98.2%
male: 98.5%
female: 98% (1995 est.)
I 0 V e r nTn e n f
Country name;
conventional long form: Commonwealth of The','5451305216ee12224f4b9894907695a327eb5d04567fe17890d2405a9344b009','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a15d206fad7110c8e83040d55ec4f8ac874676afabcf08cedd6cc23e31360f58',2000,'BS','Bahamas','military-and-security',59,'conventional short form: The Bahamas
Data code; BF
Government type; constitutional parliamentary
democracy
Capital; Nassau
Administrative divisions; 21 districts; Acklins and
Crooked Islands, Bimini, Cat Island, Exuma, Freeport,
Fresh Creek, Governor''s Harbour, Green Turtle Cay,
Harbour Island, High Rock, Inagua, Kemps Bay, Long
Island, Marsh Harbour, Mayaguana, New Providence,
Nicholls Town and Berry Islands, Ragged Island,
Rock Sound, Sandy Point, San Salvador and Rum
Cay
Independence; 1 0 July 1 973 (from UK)
National holiday; National Day, 10 July (1973)
Constitution; 10 July 1973
Legal system; based on English common law
Suffrage; 1 8 years of age; universal
Executive branch;
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Sir Orville
TURNQUEST (since 2 January 1995)
head of government: Prime Minister Hubert
Alexander INGRAHAM (since 19 August 1992) and
Deputy Prime Minister Frank WATSON (since
December 1994)
cabinet: Cabinet appointed by the governor general
on the prime minister''s recommendation
elections: none; the monarch is hereditary; governor
general appointed by the monarch; prime minister and
deputy prime minister appointed by the governor
general
Legislative branch; bicameral Parliament consists
of the Senate (16-member body appointed by the
governor general upon the advice of the prime
minister and the opposition leader for a five-year term)
and the House of Assembly (40 seats; members
elected by direct popular vote to serve five-year terms)
elections: last held 14 March 1997 (next to be held by
March 2002)
election results: percent of vote by party - NA; seats
by party - FNM 35, PLP 5
Judicial branch; Supreme Court; Court of Appeal;
magistrate''s courts
Political parties and leaders; Free National
Movement or FNM [Hubert Alexander INGRAHAM];
Progressive Liberal Party or PLP [Perry CHRISTIE]
International organization participation; ACP, C,
Caricom, CCC, CDB, ECLAC, FAO, G-77, lADB,
IBRD, ICAO, ICFU, ICRM, IFC, IFRCS, ILO, IMF,
IMO, Inmarsat, Intelsat, Interpol, IOC, ITU, LAES,
NAM, OAS, OPANAL, OPCW, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WlPO, WMO, WTrO
(applicant)
Diplomatic representation in the US;
chief of mission: Ambassador Arlington Griffith
BUTLER
chancery: 2220 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] [202] 319-2660
FAX; [1] (202) 319-2668
consulate(s) general: Miami and New York
Diplomatic representation from the US;
chief of mission: Ambassador Arthur SCHECHTER
embassy: Queen Street, Nassau
mailing address: local or express mail address: P. 0.
Box N-8197, Nassau; stateside address: American
Embassy Nassau, P. 0. Box 599009, Miami, FL
33159-9009; pouch address: Nassau, Department of
State, Washington, DC 20521-3370
fe/eptone;[1] (242) 322-1181
FAX; [1] (242) 356-0222
Flag description: three equal horizontal bands of
aquamarine (top), gold, and aquamarine, with a black
equilateral triangle based on the hoist side
p E c 0 n oTti y ''
Economy - overview: The Bahamas is a stable,
developing nation with an economy heavily
dependent on tourism and offshore banking. Tourism
alone accounts for more than 60% of GDP and directly
or indirectly employs 40% of the archipelago''s labor
force. Moderate growth in tourism receipts and a
boom in construction of new hotels, resorts, and
residences led to an increase of the country''s GDP by
an estimated 3% in 1998. Manufacturing and
agriculture together contribute less than 10% of GDP
and show little growth, despite government incentives
aimed at those sectors. Overall growth prospects in
the short run will depend heavily on the fortunes of the
tourism sector and continued income growth in the
US, which accounts for the majority of tourist visitors.
GDP: purchasing power parity - $5.58 billion
(1998 est.)
GDP - real growth rate: 3% (1998 est.)
GDP - per capita: purchasing power parity - $20,000
(1998 est.)
GDP - composition by sector:
agriculture: 3%
industry: 5%
services: 92% (1997 est.)
Popuiation below poverty line; NA%
Househoid income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
inflation rate (consumer prices); 1 .3% (1 998)
Labor force: 148,000(1996)
Labor force - by occupation: tourism 40%, other
services 50%, industry 5%, agriculture 5% (1 995 est.)
Unemployment rate: 9% (1998 est.)
37
Bahamas, The (continued)
Budget:
revenues: $766 million
expenditures: $845 million, including capital
expenditures of $97 million (FY97/98)
Industries: tourism, banking, cement, oil refining
and transshipment, salt, rum, aragonite,
pharmaceuticals, spiral-welded steel pipe
Industrial production growth rate: NA%
Electricity - production: 1 .34 billion kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other 0% (1998)
Electricity - consumption: 1 .246 billion kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: citrus, vegetables; poultry
Exports: $362.8 million (1998)
Exports - commodities: pharmaceuticals, cement,
rum, crawfish, refined petroleum products
Exports - partners: US 22.3%, Switzerland 15.6%,
UK 15%, Denmark 7.4% (1998)
Imports: $1.74 billion (1998)
Imports - commodities: foodstuffs, manufactured
goods, crude oil, vehicles, electronics
Imports - partners: US 27.3%, Italy 26.5%, Japan
10%, Denmark 4.2% (1998)
Debt -external: $349 million (1998)
Economic aid - recipient: $9.8 million (1995)
Currency: 1 Bahamian dollar (B$) = 100 cents
Exchange rates: Bahamian dollar (B$) per US$1 -
1 .000 (fixed rate pegged to the dollar)
Fiscal year: 1 July - 30 June
Military branches: Royal Bahamas Defense Force
(Coast Guard only). Royal Bahamas Police Force
Military expenditures - dollar figure: $20 million
(FY95/96)
Military expenditures - percent of GDP: NA%','2fe8da713958462389ff4997963e61de13fe21b416f3d1be610951438140b6f4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0d21293b0685a7c641127a9eef179223badb5e3b413e8765404f517c7f4fa85',2000,'BD','Bangladesh','military-and-security',67,'Military branches: Army, Navy, Coast Guard, Air
Force, paramilitary forces (includes Bangladesh
Rifles, Bangladesh Ansars, Village Defense Parties,
National Cadet Corps), Armed Police battalions
Military manpower - availability:
males age 15-49: 34,683,414 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 20,565,193 (2000 est.)
Military expenditures - dollar figure: $559 million
(FY96/97)
Military expenditures - percent of GDP: 1 .8%
(FY96/97)
I transnational Issues
Disputes - international: a portion of the boundary
with India is indefinite; dispute with India over South
Talpatty/New Moore Island
Illicit drugs: transit country for illegal drugs
produced in neighboring countries
[ Intfoductioh
Background: The island was uninhabited when first
settled by the British in 1627. Its economy remained
heavily dependent on sugar, rum, and molasses
production through most of the 20th century. In the
1990s, tourism and manufacturing surpassed the
sugar industry in economic importance.
f . . G"^ o g r ayh y . .
Location; Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, northeast of
Venezuela
Geographic coordinates; 13 10 N, 59 32 W
Map references: Central America and the
Caribbean
Area;
fofa/;430sqkm
land: 430 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 97 km
Maritime claims:
exclusive economic zone: 200 nm
femfor/a/sea;12nm
Climate: tropical; rainy season (June to October)
Terrain: relatively flat; rises gently to central highland
region
Elevation extremes;
lowest point: Atlantic Ocean 0 m
highest point: Mount Hillaby 336 m
Natural resources: petroleum, fish, natural gas
Land use:
arable land: 37%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 12%
other: 48% (1993 est.)
Irrigated land; NA sq km
43
Barbados (continued)
Natural hazards: infrequent hurricanes; periodic
landslides
Environment - current issues: pollution of coastai
waters from waste disposai by ships; soii erosion;
iiiegal solid waste disposal threatens contamination of
aquifers
Environment - internationai agreements:
par^ to; Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Biodiversity
Geography - note: easternmost Caribbean island','8ec1c31e34fc72deeb99c141152adf0e277576167fe6a46710fae2a68d60a20c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8b383470f08ebcd54b4493e41e3ead041d8d82d9476107d3a3547588306e3b6',2000,'BY','Belarus','military-and-security',80,'Military branches: Army, Navy, Air Force, National
Gendarmerie
Military manpower - military age; 19 years of age
Military manpower - availability;
males age 15-49: 2,527,752 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 2,090,800 (2000 est.)
Military manpower - reaching military age
annually:
mates; 64,165 (2000 est.)
Military expenditures - dollar figure; $2.8 billion
(FY99)
Military expenditures - percent of GDP: 1 .2%
(FY99)
50
Belgium (continued)
I transnational Issues
5.
Disputes - international: none
Illicit drugs: source of precursor chemicals for
South American cocaine processors; transshipment
point for cocaine, heroin, hashish, and marijuana
entering Western Europe
^Belize
Background: Territorial disputes between the UK
and Guatemala delayed the independence of Belize
(formerly British Honduras) untii 1981. Guatemala
refused to recognize the new nation until 1992.
Tourism has become the mainstay of the economy.
The country remains plagued by high unemployment,
growing involvement in the South American drug
trade, and increased urban crime.
f Geography
Location: Middle America, bordering the Caribbean
Sea, between Guatemala and Mexico
Geographic coordinates: 17 15 N, 88 45 W
Map references: Central America and the
Caribbean
Area:
total: 22,960 sq km
land: 22,800 sq km
water: 160 sq km
Area - comparative: slightly smaller than
Massachusetts
Land boundaries:
total: 516 km
border countries: Guatemala 266 km, Mexico 250 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm in the north, 3 nm in the south;
note - from the mouth of the Sarstoon River to
Ranguana Cay, Belize''s territorial sea is 3 nm;
according to Belize''s Maritime Areas Act, 1992, the
purpose of this limitation is to provide a framework for
the negotiation of a definitive agreement on territorial
differences with Guatemala
Climate: tropical; very hot and humid; rainy season
(May to February)
Terrain: flat, swampy coastal plain; low mountains in
south
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: V\\c\\ona Peak 1,160 m
Natural resources: arable land potential, timber,
fish, hydropower
Land use:
arable land: 2%
permanent crops:
permanent pastures: 2%
forests and woodland: 92%
other: 3% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: frequent, devastating hurricanes
(September to December) and coastal flooding
(especially in south)
Environment - current issues: deforestation; water
pollution from sewage, industrial effluents, agricultural
runoff; solid waste disposal
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Marine Dumping, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography ■ note: only country in Central America
without a coastline on the North Pacific Ocean
Miiitary branches: Federation Army or VF
(composed of both Croatian and Bosniak elements).
Army of the Serb Republic (composed of Bosnian
Serb elements); note - within both of these forces air
and air defense are subordinate commands
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 1 ,1 1 4,1 80 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 886,464 (2000 est.)
Military manpower - reaching military age
annually:
males: 29,325 (2000 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Botswana Defense Force
(includes Army and Air Wing), Botswana National
Police
Military manpower - military age; 1 8 years of age
Military manpower - availability:
males age 15-49: 373,990 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 196,572 (2000 est.)
Military manpower - reaching military age
annually;
males: 19,132 (2000 est.)
Military expenditures ■ dollar figure: $61 million
(FY99/00)
Military expenditures - percent of GDP: 1 .2%
(FY99/00)
Military - note: defense is the responsibility of','14e8e39710f2bf86d1cbfba5053a26767df927aecc10ee70432817acb75d8555','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('091944b825c8b645be2ced0cc2652788f7b4a3531a5ab7ccf24ec86fd80ddcd8',2000,'NO','Norway','military-and-security',83,'f t r a n s national I s s u e"s
Disputes • international: none
Background: Following three centuries under the
rule of Portugal, Brazil became an independent nation
in 1 822. By tar the largest and most populous country
in South America, Brazil has overcome more than half
a century of military intervention in the governance of
the country to pursue industrial and agricultural
growth and development of the interior. Exploiting
vast natural resources and a large labor pool, Brazil
became Latin America''s leading economic power by
the 1970s. Highly unequal income distribution
remains a pressing problem.
i; Transnationallssues
Disputes - international: none
Military branches: Norwegian Army, Royal
Norwegian Navy (inciudes Coast Artillery and Coast
Guard), Royal Norwegian Air Force, Home Guard
Military manpower - military age: 20 years of age
Military manpower ■ availability:
males age 15-49: 1 ,1 03,256 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 915,949 (2000 est.)
Military manpower - reaching military age
annually:
mates; 27,41 7 (2000 est.)
Military expenditures - dollar figure: $3,113 billion
(FY98)
Military expenditures - percent of GDP: 2.1%
(FY98)','15d0f4cd1ba4a1b75e0cd2896f4e295171a1461d4ce7cd5cad48dd4f09a6ea1e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9c52bc54c015f8a018a332bb3f6cd0e2d4bb86fd5b8b737065bf6a7297e8f24',2000,'IO','British Indian Ocean Territory','military-and-security',93,'Military branches: Land Forces, Navy, Air Force,
Royal Brunei Police
Military manpower - military age: 1 8 years of age
Military manpower ■ availability:
males age 15-49: 104,447 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 60,395 (2000 est.)
Military manpower - reaching military age
annually:
males: 2,957 (2000 est.)
Military expenditures - dollar figure: $343 million
(FY98)
Military expenditures - percent of GDP: 5.1%
(FY98)','3d4470566685e55c34ebfe81bb1714c9b53c48571f2b1bb34dcfe0b2a47b3b34','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d1d89447d2bc97bd51732a44eb11fcaee8aa2df477f69cf7b713f06b1d751b8',2000,'ET','Ethiopia','military-and-security',100,'Miiitary branches: Royal Cambodian Armed Forces
(RCAF), including Army, Navy, and Air Force ■ created
in 1993 by the merger of the Cambodian People''s
Armed Forces and the two noncommunist resistance
armies
note: there are also resistance forces comprised of
the Khmer Rouge (also known as the National United
Army or NUA) and a separate royalist resistance
movement
Military manpower - military age: 18 years of age
Military manpower ■ availability:
males age 15-49: 2,763,568 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 1 ,547,078 (2000 est.)
Military manpower - reaching military age
annually:
mates; 156,119 (2000 est.)
Military expenditures - dollar figure; $85 million
(FY98)
Military expenditures - percent of GDP: 2.4%
(FY98)
Military branches: People''s Revolutionary Armed
Force (FARP; includes Army, Navy, and Air Force),
paramilitary force
Military manpower - availability;
males age 15-49: 296,482 (2000 est.)
Miiitary manpower - fit for military service;
males age 15-49; 168,930 (2000 est.)
Miiitary expenditures - dollar figure; $8 million
(FY96)
Military expenditures - percent of GDP: 2.8%
(FY96)','4c603f45233559b2a2e1f6b6a2d3e78c3450938cf47ee6f44d81f0e7520cab84','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36c4485b4711c66239535cde262cfcfdce6a2fc4e9ccb272642db72c6630d468',2000,'HN','Honduras','military-and-security',116,'Military manpower - miiitary age; 1 9 years of age
Military manpower - availability:
males age 15-49: 4,012,900 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 2,973,246 (2000 est.)
101
Chile (continued)
Military manpower - reaching military age
annualiy;
males: 136,912 (2000 est.)
Military expenditures - doilar figure: $2.5 billion
(FY99)
Military expenditures - percent of GDP: 3.1 %
(FY99)
Military branches: People''s Liberation Army (PLA),
which includes the Ground Forces, Navy (includes
Marines and Naval Aviation), Air Force, Second
Artillery Corps (the strategic missile force). People''s
Armed Polioe (internal security troops, nominally
subordinate to Ministry of Public Security, but included
by the Chinese as part of the "armed forces" and
considered to be an adjunct to the PLA in wartime)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 363,050,980 (2000 est.)
104
China (continued)
Military manpower - fit for military service:
males age f5-49; 199,178,361 (2000 est.)
Military manpower - reaching military age
annuaily:
mates; 10,839,039 (2000 est.)
Military expenditures - dollar figure; $1 2.608
billion (FY99); note - Western analysts believe that
China''s real defense spending is several times higher
than the official figure because a number of significant
items are funded elsewhere
Military expenditures - percent of GDP; 1 .2%
(FY99)
E fratisnatlona] Issues
ti.
Disputes - international: boundary with India in
dispute; dispute over at least two small sections of the
boundary with Russia remain to be settled, despite
1997 boundary agreement: portions of the boundary
with Tajikistan are indefinite; 33-km section of
boundary with North Korea in the Paektu-san
(mountain) area is indefinite; involved in a complex
dispute over the Spratly Islands with Malaysia,
Philippines, Taiwan, Vietnam, and possibly Brunei;
maritime boundary dispute with Vietnam in the Gulf of
Tonkin; Paracel Islands occupied by China, but
claimed by Vietnam and Taiwan; claims
Japanese-administered Senkaku-shoto (Senkaku
Islands/Diaoyu Tai), as does Taiwan; agreement on
land border with Vietnam was signed in December
1 999, but details of alignment have not yet been made
public
Illicit drugs: major transshipment point for heroin
produced in the Golden Triangle; growing domestic
drug abuse problem
I n t r o’d u c t i o n
Background: This uninhabited island was annexed
by the UK in 1888, following the discovery of
phosphate rock.
. . oYr a"p¥ r''~ . .
Location: Southeastern Asia, island in the Indian
Ocean, south of Indonesia
Geographic coordinates: 10 30 S, 105 40 E
Map references: Southeast Asia
Area:
tofa/; 135 sq km
land: 135 sq km
water: 0 sq km
Area - comparative: about 0.7 times the size of
Washington, DC
Land boundaries; 0 km
Coastline: 138.9 km
Maritime claims;
contiguous zone: 12 nm
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; heat and humidity moderated by
trade winds
Terrain: steep cliffs along coast rise abruptly to
central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Murray Hill 361 m
Natural resources: phosphate
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
note: mainly tropical rainforest of which 60%-70% is in
a national park
Irrigated land: NAsqkm
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues; NA
Geography - note: located along major sea lanes of
Indian Ocean
I People
Population: 2,564 (July 2000 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: M
Population growth rate: 7.77% (2000 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate; NA migrant(s)/1 ,000 population
Infant mortality rate; NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Christmas Islander(s)
adjective: Christmas Island
Ethnic groups: Chinese 61%, Malay 25%,
European 11%, other 3%, no indigenous population
Religions: Buddhist 55%, Christian 15%, Muslim
10%, other 20% (1991)
Languages; English, Chinese, Malay
I ’Governmeht
Country name;
conventional long form; Territory of Christmas Island
conventional short form: Christmas Island
Data code: KT
Dependency status; territory of Australia;
administered from Canberra by the Australian
Department of the Environment, Sport and Territories
Government type; NA
Capital; The Settlement
Administrative divisions: none (territory of
Australia)
Independence: none (territory of Australia)
National holiday: NA
Constitution: Christmas Island Act of 1958
Legal system: under the authority of the governor
general of Australia and Australian law
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by the Australian governor
general
head of government: Administrator (acting) Graham
NICHOLLS (since NA)
elections: none; the monarch is hereditary;
administrator appointed by the governor general of
Australia and represents the monarch and Australia
Legislative branch: unicameral Christmas Island
Shire Council (9 seats; members elected by popular
vote to serve one-year terms)
105
Christmas Island (continued)
elections: last held NA December 1999 (next to be
held NA December 2000)
election results: percent of vote - NA; seats -
Independents 9
Judicial branch: Supreme Court
Political parties and leaders; none
International organization participation: none
Diplomatic representation in the US; none
(territory of Australia)
Diplomatic representation from the US: none
(territory of Australia)
Flag description: the flag of Australia is used
Military - note: defense is the responsibility of','26ce50c9b52f193f86fe438920e45e5de1af22994e541342ae6ca7fd6d72e4b3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95b3beb6e3a8a65875faf65e9e51167112f9a029eb827499f726fc0cbcb3b86d',2000,'FR','France','military-and-security',133,'Military - note: defense is the responsibility of
I Transnational issues
Disputes - international: claimed by Madagascar
(Falkland Islands
( (Islas Malvinas)
l (overseas territory of the UK;
i also claimed by Argentina)
Background: Discovered in the 16th century and
settled in the mid-1 8th century, the islands have since
been the subject of a territorial dispute, first between
Britain and Spain, then between Britain and
Argentina. The UK asserted its claim to the islands by
establishing a naval garrison there in 1833. Argentina
invaded the islands on 2 April 1982. The British
responded with an expeditionary force that landed
seven weeks later and after fierce fighting forced
Argentine surrender on 14 June 1982.
Military - note: defense is the responsibility of
Miiitary branches: Army, Navy (inciudes Navai Air
Arm), Air Force, Medicai Corps, Border Poiice, Coast
Guard
Miiitary manpower - miiitary age: 1 8 years of age
Military manpower • availability:
males age 15-49: 20,863,020 (2000 est.)
Military manpower • fit for military service:
males age 15-49: 17,800,862 (2000 est.)
Military manpower - reaching military age
annually:
mates; 485,422 (2000 est.)
Military expenditures - dollar figure: $32.8 billion
(FY98)
Military expenditures ■ percent of GDP: 1 .5%
(FY98)
Military - note: defense is the responsibility of the
US
Military - note: defense is the responsibility of the
UK
Military branches: Army, Navy, Air Force,
Republican Guard, Presidential Guard, paramilitary
National Gendarmerie, National Police Force (Surete
National)
Military manpower - availability:
males age 15-49: 1 ,721 ,941 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 869,442 (2000 est.)
Military expenditures - dollar figure; $56 million
(FY96)
Military expenditures - percent of GDP; 1 .4%
(FY96)
Military branches: French forces (Army, Navy, Air
Force), Gendarmerie
Miiitary - note: defense is the responsibility of','85cddf26c90f183e17cdce6ef727cb622c143c00287e234aff555f60e871f3ef','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5f312a9335894fe7b0ea40047b159b97a750859b7529cef91e512b697b17b74',2000,'AU','Australia','military-and-security',134,'TransnaHonai issues
Disputes - international: none
[Colombia
Military branches: Army (Ejercito Nacional), Navy
(Armada Nacional, includes Marines and Coast
Guard), Air Force (Fuerza Aerea Colombiana),
National Police (Policia Nacional)
Military manpower - military age; 1 8 years of age
Military manpower ■ availability:
males age 15-49: 10,599,704 (2000 est.)
110
Colombia (continued)
Military manpower - fit for military service;
males age 15-49: 7,093,676 (2000 est.)
Military manpower - reaching military age
annually;
males: 370,356 (2000 est.)
Military expenditures - dollar figure; $3.4 billion
(FY99)
Military expenditures - percent of GDP; 3.7%
(FY99)
I transnational Issues
Disputes - international; maritime boundary
dispute with Venezuela in the Gulf of Venezuela;
territorial disputes with Nicaragua over Archipelago de
San Andres y Providencia and Quita Sueno Bank
Illicit drugs; illicit producer of coca, opium poppies,
and cannabis; world''s leading coca cultivator
(cultivation of coca in 1998 - 101 ,500 hectares, a 28%
increase over 1997); cultivation of opium in 1998
remained steady at 6,600 hectares; potential
production of opium in 1997 - 66 metric tons, a 5%
increase over 1996; the world''s largest processor of
coca derivatives into cocaine; supplier of cocaine to
the US and other international drug markets, and an
important supplier of heroin to the US market; active
aerial eradication program
IComoros
Indian Ocean
Lmoroni
{Grande Comore
(NJazidja)
Moutsamoudo^^^Xanp
Military - note: defense is the responsibility of
TransnaUonal Issues
Disputes - international: none
Northern Mariana
Isiands
(commonwealth in political
union with the US)
0 100 200 km
Pajaros,
r,Maug Islands
''Asuncion Island
Philippine ^Agrihan
Sea
Pagan^ North
Pacific
Guguan" Ocean
,Sarigan
°Anatahan
‘Farallon de
„ . Medinilla
®"''P""<fsAlPAN
• Tinian
‘^Rota','14f0ce038ae2c9c4aa4c2061bdda1eb15831117ad6c51830b43f188cfb53bcb0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a8d7b2446ec79b8654cd5e6ec99990261bd3b1dd74d653c199d2980f7f27f40',2000,'MZ','Mozambique','military-and-security',137,'Channel
Military branches: National Defense Force (Army),
Police
Military manpower - availability;
males age 15-49: 41 6,529 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 248,581 (2000 est.)
Military expenditures - dollar figure; $90 million
(FY97/98)
Military expenditures - percent of GDP: 2.6%
(FY97/98)
Background: Nauru''s phosphate deposits began to
be mined eariy in the 20th century by a German-British
consortium; the island was occupied by Australian
forces in World War I. Upon achieving independence
in 1968, Nauru became the smaiiest independent
repubiic in the world; it joined the UN in 1999.
Miiitary branches: no regular armed forces;
Directorate of the Nauru Police Force
Military manpower - availabiiity:
males age 15-49: 2,945 (2000 est.)
Miiitary manpower - fit for miiitary service:
males age 15-49: 1 ,620 (2000 est.)
Military expenditures ■ doliar figure: $NA
Military expenditures - percent of GDP: NA%
Miiitary - note: Nauru maintains no defense forces;
under an informal agreement, Australia Is responsible
for defense of the island
Military branches: Zimbabwe National Army, Air
Force of Zimbabwe, Zimbabwe Republic Police
(includes Police Support Unit, Paramilitary Police)
Military manpower ■ availability;
males age 15-49: 2,924,630 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,81 4, 1 68 (2000 est.)
Military expenditures - dollar figure: $127 million
(FY99/00)
Military expenditures - percent of GDP: 3.1 %
(FY99/00)
r Transnational Issues
Illicit drugs: significant transit point for African
cannabis and South Asian heroin, mandrax, and
methamphetamines destined for the South African
and European markets
I ’ " I n t r 0 d u c t i 0 n
Background: In 1 895, military defeat forced China to
cede Taiwan to Japan, however it reverted to Chinese
control after World War II. Following the communist
victory on the mainland in 1949, 2 million Nationalists
fled to T aiwan and established a government that over
five decades has gradually democratized and
incorporated the native population within its structure.
Throughout this period, the island has prospered to
become one of East Asia''s economic "Tigers." The
dominant political issue continues to be the
relationship between Taiwan and China and the
question of eventual reunification.
I G e ’o g r a y
Location: Eastern Asia, islands bordering the East
China Sea, Philippine Sea, South China Sea, and
Taiwan Strait, north of the Philippines, off the
southeastern coast of China
Geographic coordinates: 23 30 N, 121 00 E
Map references; Southeast Asia
Area;
total: 35,980 sq km
land: 32,260 sq km
water: 3,720 sq km
note: includes the Pescadores, Matsu, and Quemoy
Area - comparative: slightly smaller than Maryland
and Delaware combined
Land boundaries; 0 km
Coastline: 1,566.3 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine; rainy season during
southwest monsoon (June to August); cloudiness is
persistent and extensive all year
Terrain: eastern two-thirds mostly rugged
mountains; flat to gently rolling plains in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Yu Shan 3,997 m
Natural resources: small deposits of coal, natural
gas, limestone, marble, and asbestos
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 5%
forests and woodland: 55%
other: 15%
Irrigated land; NA sq km
Natural hazards: earthquakes and typhoons
Environment - current issues: air pollution; water
pollution from industrial emissions, raw sewage;
contamination of drinking water supplies; trade in
endangered species; low-level radioactive waste
disposal
Environment - international agreements;
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
r P e o"^Y e " ”
Population: 22,1 91 ,087 (July 2000 est.)
Age structure:
0-14 years: 22% (male 2,485,421 ; female 2,292,901)
15-64 years: 70% (male 7,869,939; female
7,629,195)
65 years and over: 8% (male 1,01 3,074; female
900,557) (2000 est.)
Population growth rate: 0.81% (2000 est.)
Birth rate: 14.42 births/1,000 population (2000 est.
Death rate: 5.91 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.38 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 1.12 male(s)/female
total population: 1.05 male(s)/female (2000 est.)
Infant mortality rate: 7.06 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 76.35 years
male: 73.62 years
female: 79.32 years (2000 est.)
Total fertility rate: 1.76 children born/woman
(2000 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Taiwanese (including Hakka) 84%
mainland Chinese 14%, aborigine 2%
Religions: mixture of Buddhist, Confucian, and
Taoist 93%, Christian 4.5%, other 2.5%
Languages: Mandarin Chinese (official), Taiwanes
(Min), Hakka dialects
Taiwan (continued)
Literacy:
definition: age 15 and over can read and write
total population: 86% (1 980 est.); note - literacy for
the total population has reportedly increased to 94%
(1998 est.)
ma/e; 93% (1980 est.)
female: 79% (1980 est.)
I Government
Country name:
conventional long form: none
conventional short form: Taiwan
local long form: none
local short form: T''ai-wan
Data code: TW
Government type: multiparty democratic regime
headed by popularly elected president
Capital: Taipei
Administrative divisions: since in the past the
authorities claimed to be the government of all China,
the central administrative divisions include the
provinces of Fu-chien (some 20 offshore islands of
Fujian Province including Quemoy and Matsu) and
Taiwan (the island of Taiwan and the Pescadores
islands); note - the more commonly referenced
administrative divisions are those of Taiwan
Province - 16 counties (hsien, singular and plural), 5
municipalities* (shih, singular and plural), and 2
special municipalities** (chuan-shih, singular and
plural); Chang-hua, Chla-I, Chia-i*, Chi-lung*,
Hsin-chu, Hsin-chu*, Hua-lien, l-lan, Kao-hsiung,
Kao-hslung**, Miao-ll, Nan-t''ou, P''eng-hu, P''ing-tung,
T''ai-chung, T''ai-chung*, T''ai-nan, T''ai-nan*, T''ai-pei,
T''ai-pei**, T''al-tung, Tao-yuan, and Yun-lin; the
provincial capital is at Chung-hsing-hsin-ts''un
nofe; Taiwan uses the Wade-Giles system for
romanization
National holiday: National Day, 1 0 October (1 91 1 )
(Anniversary of the Chinese Revolution)
Constitution: 1 January 1947, amended in 1992,
1994, and 1997
Legal system: based on civil law system; accepts
compulsory ICJ jurisdiction, with reservations
Suffrage: 20 years of age; universal
Executive branch;
note: President-elect CHEN Shui-bian is scheduled to
ake office on 20 May 2000
:hlef of state: President LEE Teng-hui (succeeded to
he presidency following the death of President
^HIANG Ching-kuo 13 January 1988, elected by the
ilational Assembly 21 March 1 990, elected by popular
''Ote in the first-ever direct elections for president 23
ferch 1996); Vice President LIEN Chan (since 20
/lay 1996)
lead of government: Premier (President of the
ixecutive Yuan) Vincent SIEW (since 1 September
997) and Vice Premier (Vice President of the
ixecutive Yuan) LIU Chao-shiuan (since 10
ecember 1997)
abinet: Executive Yuan appointed by the president
lections: president and vice president elected on the
ime ticket by popular vote for four-year terms;
election last held 1 8 March 2000 (next to be held NA
March 2004); premier appointed by the president; vice
premiers appointed by the president on the
recommendation of the premier
election results: CHEN Shui-bian elected president;
percent of vote - CHEN Shui-bian (DPP) 39.3%,
James SOONG (independent) 36.84%, LIEN Chan
(KMT) 23.1%, HSU Hsin-liang (independent) .63%,
LEEAo(CNP).13%
Legislative branch: unicameral Legislative Yuan
(225 seats - 168 elected by popular vote, 41 elected
on the basis of the proportion of nationwide votes
received by participating political parties, eight elected
from overseas Chinese constituencies on the basis of
the proportion of nationwide votes received by
participating political parties, eight elected by popular
vote among the aboriginal populations; members
serve three-year terms) and unicameral National
Assembly (334 seats; members elected by popular
vote to serve four-year terms)
elections: Legislative Yuan - last held 5 December
1998 (next to be held NA December 2001); National
Assembly - last held 23 March 1996 (next to be held
NA2000)
election results: Legislative Yuan - percent of vote by
party - KMT 46%, DPP 29%, CNP 7%, independents
1 0%, other parties 8%; seats by party - KMT 1 23, DPP
70, CNP 1 1 , independents 15, other parties 6;
National Assembly - percent of vote by party - KMT
55%, DPP 30%, CNP 14%, other 1%; seats by party -
KMT 183, DPP 99, CNP 46, other 6
Judicial branch; Judicial Yuan, justices appointed
by the president with the consent of the National
Assembly
Political parties and leaders: Chinese New Party
or CNP [CHOU Yang-sun]; Democratic Progressive
Party or DPP [LiN Yi-hsiung, chairman]; Kuomintang
or KMT (Nationalist Party) [LIEN Chan, acting
chairman]; Taiwan Independence Party or TAIP
[CHENG Pang-chen]; other minor parties
Political pressure groups and leaders: Taiwan
independence movement, various business and
environmental groups
note: debate on Taiwan independence has become
acceptable within the mainstream of domestic politics
on Taiwan; political liberalization and the increased
representation of opposition parties in Taiwan''s
legislature have opened public debate on the island''s
national identity; advocates of Taiwan independence
oppose the ruling party''s traditional stand that the
island will eventually reunify with mainland China;
goals of the Taiwan independence movement include
establishing a sovereign nation on Taiwan and
entering the UN; other organizations supporting
Taiwan independence include the World United
Formosans for Independence and the Organization
for Taiwan Nation Building
International organization participation: APEC,
AsDB, BCIE, ICC, IOC, WCL, WTrO (applicant)
Diplomatic representation in the US: none;
unofficial commercial and cultural relations with the
people of the US are maintained through a private
instrumentality, the Taipei Economic and Cultural
Representative Office (TECRO) in the US with
headquarters in Taipei and field offices in Washington
and 12 other US cities
Diplomatic representation from the US: none;
unofficial commercial and cultural relations with the
people on Taiwan are maintained through a private
corporation, the American Institute in Taiwan (AIT),
which has its headquarters in Rosslyn, Virginia
(telephone; [1] (703) 525-8474 and FAX; [1] (703)
841-1385) and offices in Taipei at #7 Lane 134, Hsin
Yi Road, Section 3, telephone [886] (2) 2709-2000,
FAX [886] (2) 2702-7675, and in Kao-hsiung at #2
Chung Cheng 3d Road, telephone [886] (7) 224-0154
through 0157, FAX [886] (7) 223-8237, and the
American Trade Center at Room 3207 International
Trade Building, Taipei World Trade Center, 333
Keelung Road Section 1 , Taipei 10548, telephone
[886] (2) 2720-1550, FAX [886] (2) 2757-71 62
Flag description; red with a dark blue rectangle in
the upper hoist-side corner bearing a white sun with
12 triangular rays
I EconTorSy’
Economy - overview: Taiwan has a dynamic
capitalist economy with gradually decreasing
guidance of investment and foreign trade by
government authorities. In keeping with this trend,
some large government-owned banks and industrial
firms are being privatized. Real growth in GDP has
averaged about 8% during the past three decades.
Exports have grown even faster and have provided
the primary impetus for industrialization. Inflation and
unemployment are low; the trade surplus is
substantial; and foreign reserves are the world''s third
largest. Agriculture contributes 3% to GDP, down from
35% in 1952. Traditional labor-intensive industries are
steadily being moved off-shore and replaced with
more capital- and technology-intensive industries.
Taiwan has become a major investor in China,
Thailand, Indonesia, the Philippines, Malaysia, and
Vietnam. The tightening of labor markets has led to an
influx of foreign workers, both legal and illegal.
Because of its conservative financial approach and its
entrepreneurial strengths, Taiwan suffered little
compared with many of its neighbors from the Asian
financial crisis in 1 998-99. Growth in 2000 should pick
up a bit from 1999, backed by expansion in domestic
consumption, exports, and private investment.
GDP: purchasing power parity - $357 billion
(1999 est.)
GDP - real growth rate: 5.5% (1999 est.)
GDP - per capita: purchasing power parity -
$16,100 (1999 est.)
GDP - composition by sector;
agriculture: 3%
Industry: 33%
services: 64% (1 999 est.)
Popuiation beiow poverty iine: 1% (1999 est.)
Household income or consumption by percentage
share;
lowest 10%: NA%
553
Taiwan (continued)
highest 10%: NA%
Inflation rate (consumer prices): 0.4% (1999 est.)
Labor force: 9.7 million (1999 est.)
Labor force - by occupation: services 55%,
industry 37%, agriculture 8% (1999 est.)
Unemployment rate: 2.9% (1999 est.)
Budget:
revenues: $36.82 billion
expenditures: $40.53 biilion, including capitai
expenditures of $NA (1999 est.)
Industries: electronics, petroieum refining,
chemicals, textiles, iron and steei, machinery, cement,
food processing
Industrial production growth rate: 7.5%
(1999 est.)
Electricity - production: 1 33.586 billion kWh (1 998)
Electricity - production by source:
fossil fuel: S5.91%
hydro: 7.84%
nuclear: 26.25%
ote0%(1998)
Electricity - consumption: 124.235 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: rice, corn, vegetables, fruit,
tea; pigs, poultry, beef, milk; fish
Exports: $121.6 billion (f.o.b., 1999)
Exports - commodities: electronics, electric and
machinery equipment 52%, metals, textiles, plastics,
chemicals
Exports - partners: US 26%, Hong Kong 21%,
Europe 18%, Japan 10%, Singapore 3% (1999)
Imports: $101.7 billion (c.i.f., 1999)
Imports - commodities: electronics, electric and
machinery equipment 45%, minerals, precision
instruments
Imports - partners: Japan 27%, US 18%, Europe
16%, South Korea 6%, Malaysia 4% (1999)
Debt - external: $35 billion (September 1999)
Economic aid - recipient: $NA
Currency: 1 New Taiwan dollar (NT$) = 100 cents
Exchange rates: New Taiwan dollars per US$1 -
31 .395 (yearend 1 999), 32.21 6 (1 998), 32.052 (1 997),
27.5 (1996), 27.5 (1995)
Fiscal year: 1 July - 30 June (up to FY98/99); 1 July
1999 - 31 December 2000 for FYOO; calendar year
(after FYOO)
Military branches: Army, Navy (includes Marines),
Air Force, Coastal Patrol and Defense Command,
Armed Forces Reserve Command, Combined Service
Forces
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 6,554,373 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 5,017,643 (2000 est.)
Military manpower - reaching military age
annually:
mates: 201 ,413 (2000 est.)
Military expenditures - dollar figure: $8,042 billion
(FY98/99)
Military expenditures - percent of GDP: 2.8%
(FY98/99)','eb96c06bac48853e497f73d60a8364127a7467e6092d407609515e3747447ce0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0aad9204192d6bfcb835ae221dd0f34d7d87a43f5e98d9ff5a2ca9ccb843b79b',2000,'YT','Mayotte','military-and-security',138,'Administered by FRANCE,
claimed by COMOROS.
Military - note: defense is the responsibility of
France; small contingent of French forces stationed
on the island
I ’Tr”a n s Fal i o n aT i s s u e s
Disputes - international: claimed by Comoros
325
r Introduction
Background: The site of advanced Amerindian
civilizations, Mexico came under Spanish rule for
three centuries before achieving independence early
in the 19th century. A devaluation of the peso in late
1994 threw Mexico into economic turmoil, triggering
the worst recession in over half a century. The nation
continues to make an impressive recovery. Ongoing
economic and social concerns include low real wages,
underemployment for a large segment of the
population, inequitable income distribution, and few
advancement opportunities for the largely Amerindian
population in the impoverished southern states,
I Geography
Location: Middle America, bordering the Caribbean
Sea and the Gulf of Mexico, between Belize and the
US and bordering the North Pacific Ocean, between
Guatemala and the US
Geographic coordinates: 23 00 N, 102 00 W
Map references: North America
Area:
tofa/; 1,972,550 sq km
land: 1 ,923,040 sq km
wafer; 49,510 sq km
Area - comparative: slightly less than three times
the size of Texas
Land boundaries:
total: 4,538 km
border countries: Belize 250 km, Guatemala 962 km,
US 3,326 km
Coastline: 9,330 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 20Q nm
territorial sea: ''\\2 nm
Climate: varies from tropical to desert
Terrain: high, rugged mountains; low coastal plains;
high plateaus; desert
Elevation extremes:
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba 5,700 m
Natural resources: petroleum, silver, copper, gold,
lead, zinc, natural gas, timber
Land use:
arable land: 12%
permanent crops: ^%
permanent pastures: 39%
forests and woodland: 26%
of/)er;22%(1993est.)
Irrigated land: 61 ,000 sq km (1 993 est.)
Natural hazards: tsunamis along the Pacific coast,
volcanoes and destructive earthquakes in the center
and south, and hurricanes on the Gulf of Mexico and
Caribbean coasts
Environment - current issues: natural fresh water
resources scarce and polluted in north, inaccessible
and poor quality in center and extreme southeast; raw
sewage and industrial effluents polluting rivers in
urban areas; deforestation; widespread erosion;
desertification; serious air pollution in the national
capital and urban centers along US-Mexico border
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: strategic location on southern
border of US','944edf63423e3f022f565292a5ce2dbf2e778573c0a0ee1426db9c83e815ab45','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69ec524cf3964fdf80d4d906fe2f825edc4cb9d392fecbd8c07e1d0b2539b46d',2000,'CG','Congo','military-and-security',147,'Military branches: Army, Air Force, Navy,
Gendarmerie
Military manpower - military age: 20 years of age
Military manpower - availabiiity:
males age f5-49; 668,1 63 (2000 est.)
Miiitary manpower - fit for military service:
males age 15-49: 339,687 (2000 est.)
Miiitary manpower - reaching miiitary age
annualiy:
mates: 30,775 (2000 est.)
Military expenditures - doliar figure: $110 million
(FY93)
Miiitary expenditures - percent of GDP: 3.8%
(FY93)','21af7108ba1b7a9c6fef5dfdf301f5237c0e6117207bd669cdeed9cf5b7aa6d8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('511e3b2b45fcdb23436a0b91e635aa6ce65197714d11e85649472ab6d5c05d01',2000,'CK','Cook Islands','military-and-security',156,'Military - note: defense is the responsibility of
Australia; visited regularly by the Royal Australian
Navy; Australia has control over the activities of
visitors
Military branches: Coast Guard, Air Section,
Ministry of Public Security Force (Fuerza Publica);
Miiitary manpower - military age: 1 8 years of age
Miiitary manpower - availability;
males age 15-49: 1 ,010,087 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 676,691 (2000 est.)
Military manpower - reaching military age
annually:
males: 38,043 (2000 est.)
Military expenditures - dollar figure; $55 million
(FY95)
Military expenditures - percent of GDP: 2%
(FY95)
Military - note: defense is the responsibiiity of the
UK
Military - note: defense is the responsibility of the US','a00c1667c8816fd28b0f286d486379c25725b9b6dcccaae93b266c9e7494401a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06ab2e92dc5f934f3b670dbd74cc3601797ecfd28c5eb2d0b7c8344e5709fb12',2000,'CU','Cuba','military-and-security',170,'Military branches: Revolutionary Armed Forces
(FAR) includes ground forces. Revolutionary Navy
(MGR), Air and Air Defense Force (DAAFAR),
Territorial Troops Militia (MTT), and Youth Labor Army
(EJT); the Border Guard (TGF) is controlled by the
Interior Ministry
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 3,079,352
females age 15-49: 3,022,063 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,906,172
females age 15-49: 1 ,865,369 (2000 est.)
Military manpower - reaching military age
annually:
males: 80,771
females: 76,819 (2000 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: roughly
4% (FY95 est.)
Military - note: Moscow, for decades the key military
supporter and supplier of Cuba, cut off almost all
military aid by 1993
Miiitary branches: Royal Danish Army, Royal
Danish Navy, Royal Danish Air Force, Home Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 1 ,299,250 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1,11 3,378 (2000 est.)
Military manpower - reaching military age
annually:
mates; 30,471 (2000 est.)
Military expenditures - dollar figure; $2,822 billion
(FY98)
Military expenditures - percent of GDP: 1 .7%
(FY98)
I Transnational issues
Disputes - international: Rockall continental shelf
dispute involving Iceland, Ireland, and the UK (Ireland
and the UK have signed a boundary agreement in the
Rockall area)
138','d365336ae371aedabfcf7ea9115da5e769ceb0759cb931a48cdf6bb9128cc78a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f723a999c2ee25f851cffcae6cd1a1b38b03e25b192f3f1f6cdc4c8e7e09c4a9',2000,'GN','Guinea','military-and-security',185,'Military branches: Army, Navy, Air Force
Military expenditures - dollar figure; $1 96 million
(FY97)
Military expenditures - percent of GDP; 28.6%
(FY97)
I transnational Issues
Disputes - international; dispute over alignment of
boundary with Ethiopia led to armed conflict in 1998,
which is still unresolved despite arbitration efforts
156
I n t r 0 d u c t i 0 n
Background: After centuries of Swedish and
Russian rule, Estonia attained independence in 1 91 8.
Forcibly incorporated into the USSR in 1940, it
regained its freedom in 1991 with the collapse of the
Soviet Union. Since the last Russian troops left in
1 994, Estonia has been free to promote economic and
poiitical ties with Western Europe.
Location: Eastern Europe, bordering the Baltic Sea
and Guif of Finland, between Latvia and Russia
Geographic coordinates: 59 00 N, 26 00 E
Map references: Europe
Area:
total: 45,226 sq km
land: 43,21 1 sq km
wafer; 2,01 5 sq km
note; inciudes 1,520 islands in the Baltic Sea
Area - comparative: slightiy smaller than New
Hampshire and Vermont combined
Land boundaries:
total: 633 km
border countries: Latvia 339 km, Russia 294 km
Coastline: 3,794 km
Maritime claims:
exclusive economic zone: limits fixed in coordination
with neighboring states
ferr/for/a/sea;12nm
Climate: maritime, wet, moderate winters, cool
summers
Terrain: marshy, lowlands
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Smr Munamagi 318 m
Natural resources: shale oil (kukersite), peat,
phosphorite, amber, Cambrian blue clay, limestone,
dolomite, arable land
Land use:
arable land: 25%
permanent crops: 0%
permanent pastures: 1 1%
forests and woodland: 44%
other; 20% (1996 est.)
Irrigated land: 1 10 sq km (1996 est.)
Natural hazards: flooding occurs frequently in the
spring
Environment - current issues: air heavily polluted
with sulfur dioxide from oil-shale burning power plants
in northeast; contamination of soil and groundwater
with petroleum products, chemicals at former Soviet
military bases; Estonia has more than 1,400 natural
and manmade lakes, the smaller of which in
agricultural areas are heavily affected by organic
waste; coastal sea water is polluted in many locations
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Ship Pollution, Ozone
Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol
I, " ’ —
Population: 1,431,471 (July 2000 est.)
Age structure:
0-14 years: 18% (male 129,204; female 124,269)
15-64 years: 68% (male 466,960; female 503,233)
65 years and over: 1 4% (male 67,781 ; female
140,024) (2000 est.)
Population growth rate: -0.59% (2000 est.)
Birth rate: 8.45 births/1,000 population (2000 est.)
Death rate: 1 3.55 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.79 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.87 male(s)/female (2000 est.)
Infant mortality rate: 12.92 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 69.45 years
maie: 63.4 years
female: 75.79 years (2000 est.)
Total fertility rate: 1 .19 children born/woman
(2000 est.)
Nationality:
noun: Estonian(s)
adjective: Estonian
Ethnic groups: Estonian 65.1%, Russian 28.1%,
Ukrainian 2.5%, Byelorussian 1.5%, Finn 1%, other
1.8% (1998)
Religions: Evangelical Lutheran, Russian Orthodox,
Estonian Orthodox, Baptist, Methodist, Seventh-Day
Adventist, Roman Catholic, Pentecostal, Word of Life,
Jewish
Languages: Estonian (official), Russian, Ukrainian,
English, Finnish, other
Literacy:
definition: age 1 5 and over can read and write
total population: 1 00%
male: 100%
fema/e; 100% (1998 est.)
i" (Sovernment
t;'',.
Country name:
conventional long form: Republic of Estonia
conventional short form: Estonia
local long form: Eesti Vabariik
local short form: EesW
former: Estonian Soviet Socialist Republic
Data code: EN
Government type: parliamentary democracy
Capital: Tallinn
Administrative divisions: 15 counties
(maakonnad, singular - maakond): Harjumaa
(Tallinn), Hiiumaa (Kardia), Ida-Virumaa (Johvi),
Jarvamaa (Paide), Jogevamaa (Jogeva), Laanemaa
(Haapsalu), Laane-Virumaa (Rakvere), Parnumaa
(Parnu), Polvamaa (Polva), Raplamaa (Rapla),
Saaremaa (Kuessaare), Tartumaa (Tartu), Valgamaa
(Valga), Viljandimaa (Viljandi), Vorumaa (Voru)
note: counties have the administrative center name
following in parentheses
Independence: 6 September 1991 (from Soviet
Union)
National holiday: Independence Day, 24 February
(1918)
Constitution: adopted 28 June 1992
Legal system: based on civil law system; no judicial
review of legislative-acts
Suffrage: 18 years of age; universal for all Estonian
citizens
Executive branch:
chief of state: President Lennart MERI (since 5
October 1992)
head of government: Prime Minister Mart LAAR
(since 29 March 1999)
cabinet: Council of Ministers appointed by the prime
minister, approved by Parliament
elections: president elected by Parliament for a
five-year term; if he or she does not secure two-thirds
of the votes after three rounds of balloting, then an
electoral assembly (made up of Parliament plus
members of local governments) elects the president,
choosing between the two candidates with the largest
percentage of votes; election last held
August-September 1996 (next to be held fall 2001);
prime minister nominated by the president and
approved by Parliament
election results: Lennart MERI reelected president by
an electoral assembly after Parliament was unable to
break a deadlock between MERI and RUUTEL;
percent of electoral assembly vote - Lennart MERI
61%, Arnold RUUTEL 39%
Legislative branch: unicameral Parliament or
Riigikogu (1 01 seats; members are elected by popular
vote to serve four-year terms)
elections: last held 7 March 1999 (next to be held NA
March 2003)
157
Estonia (continued)
election results: percent of vote by party - NA; seats
by party - Center Party 28, Union of Pro Patria
(Fatherland League) 18, Reform Party 18, Moderates
17, Country People''s Party (Agrarians) 7, Coalition
Party 7, UPPE6,
Judicial branch: National Court, chairman
appointed by Parliament for life
Political parties and leaders: Center Party or K
[Edgar SAVISAAR, chairman]; Coalition Party and
Rural Union or KMU [Andrus OOVEL, chairman];
Country People''s Party [Arnold RUUTEL]; Moderates
or M [Andres TARAND]; Reform Party or RE [Slim
KALLAS, chairman]; Union of Pro Patria or Fatherland
League (Isamaallit) [Mart LAAR, chairman]; United
People''s Party or UPPE [Viktor ANDREJEV,
chairman]
International organization participation; BIS,
CBSS, CCC, CE, EAPC, EBRD, ECE, EU (applicant),
FAO, IAEA, IBRD, ICAO, ICFU, ICRM, IFC, IFRCS,
IHO, ILO, IMF, IMO, Interpol, IOC, lOM (observer),
ISO (correspondent), ITU, OPCW, OSCE, PFP, UN,
UNCTAD, UNESCO, UNMIBH, UNMIK, UNTSO,
UPU, WEU (associate partner), WHO, WlPO, WMO,
WTrO
Diplomatic representation in the US:
ch/ef of m/ss/or?; Ambassador Sven JURGENSON
chancery: 2t3t Massachusetts Avenue NW,
Washington, DC 20008
telephone: [t] (202) 588-0101
FAX; [1] (202) 588-0108
consulate(s) general: New York
Diplomatic representation from the US;
chief of mission: Ambassador Melissa WELLS
embassy: Kentmanni 20, Tallinn EE 0001
mailing address: use embassy street address
telephone: [372] (6) 312-021
FAX; [372] (6) 312-025
Flag description: pre-1940 flag restored by
Supreme Soviet in May 1990 - three equal horizontal
bands of blue (top), black, and white
Military - note: defense is the responsibility of','2a6fdd2557064bf9eb6a462d939e56e7283e16ba71ba467e22d9030b6fa8df80','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('826db2a0541494ac44e8f8a7ee2c512e1957b583df5956537419321ee84814ca',2000,'JE','Jersey','military-and-security',196,'Military branches; Republic of Fiji Military Forces
(RFMF; includes ground and naval forces)
Military manpower - military age; 18 years of age
Military manpower - availability;
males age 15-49: 223,496 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 123,051 (2000 est.)
Military manpower - reaching military age
annually;
males: 9,426 (2000 est.)
Military expenditures - dollar figure; $24 million
(FY98)
Military expenditures - percent of GDP; 1 .1%
(FY98)
Military branches: Army, Navy, Air Force, Frontier
Guard (includes Sea Guard)
Military manpower - military age: 1 7 years of age
Military manpower - availability:
males age 15-49; 1,262,526 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,041 ,795 (2000 est.)
Military manpower - reaching military age
annually:
males: 34,651 (2000 est.)
Military expenditures - dollar figure: $1 .8 billion
(FY98)
Military expenditures - percent of GDP: 2%
(FY98)
Military branches: no regular military forces;
Solomon Islands National Reconnaissance and
Surveillance Force; Royal Solomon Islands Police
(RSIP)
Military expenditures - dollar figure; $NA
Military expenditures - percent of GDP; NA%
Land boundaries:
total: 535 km
border countries: Mozambique 105 km. South Africa
430 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from tropical to near temperate
Terrain: mostly mountains and hills; some
moderately sloping plains
Elevation extremes:
lowest point: Great Usutu River 21 m
highest point: Emiembe 1 ,862 m
Natural resources: asbestos, coal, clay, cassiterite,
hydropower, forests, small gold and diamond
deposits, quarry stone, and talc
Land use:
arable land: 11%
permanent crops: 0%
permanent pastures: 62%
forests and woodland: 7%
473
Swaziland (continued)
other: 20% {m3 est.)
Irrigated land: 670 sq km (1993 est.)
Natural hazards: NA
Environment ■ current issues: limited supplies of
potable water; wildlife populations being depleted
because of excessive hunting; overgrazing; soil
degradation; soil erosion
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Desertification, Law of the
Sea
Geography - note: landlocked; almost completely
surrounded by South Africa
I People
Population: 1,083,289
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years; 46% (male 245,626; female 247,825)
15-64 years: 52% (male 270,308; female 291 ,884)
65 years and over: 2% (male 1 1 ,357; female 1 6,289)
(2000 est.)
Population growth rate: 2.02% (2000 est.)
Birth rate: 40.64 births/1,000 population (2000 est.)
Death rate: 20.4 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 108.95 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 40.44 years
male: 39.54 years
female: 41 .37 years (2000 est.)
Total fertility rate: 5.87 children born/woman
(2000 est.)
Nationality:
noun: Swazi(s)
adjective: Swazi
Ethnic groups: African 97%, European 3%
Religions: Christian 60%, indigenous beliefs 40%
Languages: English (official, government business
conducted in English), siSwati (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 76.7%
male: 78%
female: 75.6% (1995 est.)','5c65f277ef3a3804195bfe6ebd59b94f164c12f656773bea0697e23e1198d277','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fc01c66d1625e9ef441bafc295822cec7070f6060ac8886ab38899205e4ed3a',2000,'ES','Spain','military-and-security',220,'Military branches: British Army, Royal Navy, Royal
Air Force
Military - note: defense is the responsibility of the
UK
Military - note: defense is the responsibility of','e831d61bbc587afde3457ebf8ae3265a45c28fddcd86ac45274e2af62f7fc9a0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ddf2d97d98255744c3371233ab2582ba3f9e9e6a6e4296328b40f3cb361c4f2',2000,'IQ','Iraq','military-and-security',248,'Military branches: Army (includes Naval Service
and Air Corps), National Police (Garda Siochana)
Military manpower - military age: 1 7 years of age
Military manpower - availability:
males age 15-49: 994,040 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 801 ,975 (2000 est.)
Military manpower - reaching military age
annually:
males: 33,303 (2000 est.)
Military expenditures - dollar figure: $732 million
(FY98)
Military expenditures - percent of GDP: 0.9%
(FY98)','af470e990237815ac6af77c3ba8bd3f305ff673b7c3f9d532c29b1f7b198ff15','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('102e9dcaad3930c0674d399d0707e435200bcb55c480c09042db57a6db8a0e09',2000,'TN','Tunisia','military-and-security',254,'Military branches: Army, Navy, Air Force,
Carabinieri
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 14,315,634 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 12,331 ,306 (2000 est.)
Military manpower - reaching military age
annually:
males: 31 1 ,160 (2000 est.)
Military expenditures - dollar figure: $23,294
billion (FY99)
Military expenditures - percent of GDP: 1 .7%
(FY99)
f Transnational Issues
Disputes - international: Italy and Slovenia made
progress in resoiving bilaterai issues; Croatia and itaiy
made progress toward resoiving a biiaterai issue
dating from Worid War il over property and ethnic
minority rights
Illicit drugs: important gateway for and consumer of
Latin American cocaine and Southwest Asian heroin
entering the European market
^Jamaica
Discovery Bay
Caribbean Sea
Mandeville,
AlligatorPond
Spanish
Town,
May
Pen, PortmoreJ
Port EsquiveUr^ ^
Caribbean
Sea
0 15 30 km
i Introduction
Background: Jamaica gained fuii independence
within the British Commonweaith in 1962.
Deteriorating economic conditions during the 1970s
led to recurrent violence and a dropoff in tourism.
Eiections in 1980 saw the democratic socialists voted
out of office, and a more conservative government
instaiied. Poiitical violence marred elections during
the 1990s.
Military branches: Jamaica Defense Force
(includes Ground Forces, Coast Guard, and Air
Wing), Jamaica Constabulary Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49:725,975 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 510,419 (2000 est.)
Military manpower - reaching miiitary age
annuaily:
males: 27,202 (2000 est.)
Military expenditures - dollar figure: $30 million
(FY95/96 est.)
Military expenditures - percent of GDP: NA%','04db31a4ae75c49524b4766107a5bf4e1d754f2c981ddc1d717a727db9292857','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01c4c71b3bb6549ee2bc26a13b3ca97b665cbcca6e1b0651d7f5fa9244e69188',2000,'JP','Japan','military-and-security',280,'Military branches: Army, Navy, Air Force, National
Police Force, National Guard, Coast Guard
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 749,252 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 446,51 8 (2000 est.)
Military manpower - reaching military age
annually:
mates; 17,919 (2000 est.)
Military expenditures - dollar figure; $2.51 8 billion
(FY99/00)
Military expenditures - percent of GDP; 8%
(FY99/00)','c6c660436b144f3cfd925d3546815ba985c86b6d29533f32469d054a9116ec4a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e3ab8b10b574eed682281547e9170d67da7a28b77aa617d22a433d889e58822',2000,'CN','China','military-and-security',287,'Military branches: Lao People''s Army (LPA;
includes militia element), Lao People''s Navy (LPN;
includes riverine element), Air Force, National Police
Department
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 1 ,275,1 84 (2000 est.)
Military manpower ■ fit for military service;
males age 15-49: 686,803 (2000 est.)
Military manpower - reaching military age
annually:
males: 62,243 (2000 est.)
Military expenditures - dollar figure: $77 million
(FY96/97)
278
Laos (continued)
Military expenditures - percent of GDP: 4.2%
(FY96/97)
I Transnational Issues
Disputes - international: parts of the border with
Thailand are indefinite
Illicit drugs: world''s third-largest illicit opium
producer (estimated cultivation in 1999 - 21,800
hectares, a 16% decrease over 1998; estimated
potential production in 1999 - 140 metric tons, about
the same as in 1998); potential heroin producer;
transshipment point for heroin and
methamphetamines produced in Burma; illicit
producer of cannabis
between the two World Wars, Latvia was annexed by
the USSR in 1940. It reestablished its independence
in 1991 following the breakup of the Soviet Union.
Although the last Russian troops left in 1994, the
status of the Russian minority (some 30% of the
population) remains of concern to Moscow. Latvia
continues to revamp its economy for eventual
integration into various Western European political
and economic institutions.
r
Geo g’r h y
Location: Eastern Europe, bordering the Baltic Sea,
between Estonia and Lithuania
Geographic coordinates: 57 00 N, 25 00 E
Map references: Europe
Area:
total: 64,589 sq km
land: 64,589 sq km
water: 0 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries:
fofa/; 1,150 km
border countries: Belarus 141 km, Estonia 339 km,
Lithuania 453 km, Russia 217 km
Coastline: 531 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: t2 rvm
Climate: maritime; wet, moderate winters
Terrain: low plain
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Gaizinkalns 312 m
Natural resources: minimal; amber, peat,
limestone, dolomite, hydropower, arable land
permanent pastures: 1 3%
forests and woodland: 46%
other; 14% (1993 est.)
Irrigated land: 160 sq km (1993 est.)
Natural hazards: NA
Environment ■ current issues: air and water
pollution because of a lack of waste conversion
equipment; Gulf of Riga and Daugava River heavily
polluted; contamination of soil and groundwater with
chemicals and petroleum products at military bases
Environment - international agreements:
party to: Mr Pollution, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
I People
Population: 2,404,926 (July 2000 est.)
Age structure:
0-14 years: 17% (male 212,483; female 203,417)
15-64 years: 68% (male 777,289; female 849,967)
65 years and over: 1 5% (male 1 1 6,575; female
245,195) (2000 est.)
Population growth rate: -0.84% (2000 est.)
Birth rate: 7.8 births/1,000 population (2000 est.)
Death rate: 14.88 deaths/1 ,000 population
(2000 est.)
Net migration rate: -1 .32 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.85 male(s)/female (2000 est.)
Infant mortality rate: 15.71 deaths/1,000 live births
(2000 est.)
279
Latvia (continued)
Life expectancy at birth:
total population: 68.41 years
male: 62.48 years
female: 74.62 years (2000 est.)
Totai fertiiity rate: 1.13 children born/woman
(2000 est.)
Nationality:
noun: Latvian(s)
adjective: Latvian
Ethnic groups: Latvian 56.5%, Russian 30.4%,
Byelorussian 4.3%, Ukrainian 2.8%, Polish 2.6%,
other 3.4%
Religions: Lutheran, Roman Catholic, Russian
Orthodox
Languages: Lettish (official), Lithuanian, Russian,
other
Literacy:
definition: age 15 and over can read and write
total population: tOOVo
mate; 100%
femate; 99% (1989 est.)
I Government
Country name:
conventional long form: Republic of Latvia
conventional short form: Latvia
local long form: Latvijas Republika
local short form: Latvija
former: Latvian Soviet Socialist Republic
Data code: LG
Government type: parliamentary democracy
Capital: Riga
Administrative divisions: 26 counties (singular •
rajons) and 7 municipalities*: Aizkraukles Rajons,
Aluksnes Rajons, Baivu Rajons, Bauskas Rajons,
Cesu Rajons, Daugavpils*, Daugavpils Rajons,
Dobeles Rajons, Gulbenes Rajons, Jekabpils Rajons,
Jelgava*, Jelgavas Rajons, Jurmala*, Kraslavas
Rajons, Kuldigas Rajons, Leipaja*, Liepajas Rajons,
Limbazu Rajons, Ludzas Rajons, Madonas Rajons,
Ogres Rajons, Preilu Rajons, Rezekne*, Rezeknes
Rajons, Riga*, Rigas Rajons, Saldus Rajons, Talsu
Rajons, Tukuma Rajons, Valkas Rajons, Valmieras
Rajons, Ventspils*, Ventspils Rajons
Independence: 6 September 1991 (from Soviet
Union)
National holiday: Independence Day, 18 November
(1918)
Constitution: the 1991 Constitutional Law which
supplements the 1922 constitution, provides for basic
rights and freedoms
Legal system: based on civil law system
Suffrage: 1 8 years of age; universal for Latvian
citizens
Executive branch:
chief of state: President Vaira VIKE-FREIBERGA
(since8 July 1999)
head of government: Prime Minister Andris BERZINS
(since 5 May 2000)
cabinet: Council of Ministers nominated by the prime
minister and appointed by the Parliament
elections: president elected by Parliament for a
four-year term (amended from a three-year term on 4
December 1997); election last held 17 June 1999
(next to be held by NA June 2003); prime minister
appointed by the president
election results: Maita VIKE-FREIBERGA elected as
a compromise candidate in second phase of balloting,
second round (after five rounds in first phase failed);
percent of parliamentary vote - Vaira
VIKE-FREIBERGA 53%, Valdis BIRKAVS 20%,
Ingrida UDRE 9%
Legislative branch: unicameral Parliament or
Saeima (100 seats; members are elected by direct
popular vote to serve four-year terms - amended from
three-year terms on 4 December 1 997)
elections: last held 3 October 1998 (next to be held
NA October 2002)
election results: percent of vote by party - People''s
Party 21%, LC 18%, TSP 14%, TB/LNNK 14%, Social
Democrats 13%, New Party 8%; seats by party -
People''s Party 24, LC 21, TSP 16, TB/LNNK 17,
Social Democrats 14, New Party 8
Judicial branch: Supreme Court, judges''
appointments are confirmed by Parliament
Political parties and leaders: Anticommunist Union
or PA [P. MUCENIEKS]; Association of Latvian Social
Democrats [Juris BOJARS, Janis ADAMSONS];
Christian Democrat Union or LKDS [Talavs
JUNDZISj; Christian People''s Party or KTP (formerly
People''s Front of Latvia or LTF) [UIdis
AUGSTKALNS); Democratic Party "Saimnieks" or
DPS [Ziedonis CEVERS, chairman); For Fatherland
and Freedom orTB [Maris GRINBLATS], merged with
LNNK; Green Party or LZP [Olegs BATAREVSK);
Latvian Liberal Party or LLP [J. DANOSSj; Latvian
National Conservative Party or LNNK [Andrejs
KRASTINSj; Latvian National Democratic Party or
LNDP [A. MALINS); Latvian Social-Democratic
Workers Party (Social Democrats) or LSDSP [Janis
BOJARS); Latvian Socialist Party or LSP [Sergejs
DIAMANIS); Latvian Unity Party or LVP [Alberis
KAULS); Latvia''s Way or LC [Andrei PANTELEJEVS);
National Harmony Party or TSP [Janis JURKANS);
New Party [Raimonds PAULS); “Our Land" or MZ [M.
DAMBEKALNE); Party for the Defense of Latvia''s
Defrauded People [leader NA); Party of Russian
Citizens or LKPP [V. SOROCHIN, V. IVANOV);
Political Association of the Underprivileged or MPA [B.
PELSE, V. DIMANTS, J. KALNINS); Political Union of
Economists or TPA [Edvins KIDE); People''s Party
[Andris SKELE]
International organization participation: BIS,
CBSS; CCC, CE, EAPC, EBRD, ECE, EU (applicant),
FAO, IAEA, IBRD, ICAO, ICFTU, ICRM, IDA, IFC,
IFRCS, ILO, IMF, IMO, Intelsat (nonsignatory user),
Interpol, IOC, lOM (observer), ISO (correspondent),
ITU, NSG, OAS (observer), OPCW, OSCE, PFP, UN,
UNCTAD, UNESCO, UNIDO, UPU, WEU (associate
partner), WHO, WlPO, WMO, WTrO, WTrO
(applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Aivis RONIS
chancery: 4325 17th Street NW, Washington, DC
20011
telephone: [1] (202) 726-8213, 8214
FAX; [1] (202) 726-6785
Diplomatic representation from the US:
chief of mission: Ambassador James H. HOLMES
embassy: Raina Boulevard 7, LV-1510, Riga
mailing address: American Embassy Riga, PSC 78,
Box Riga, APO AE 09723
te/ep/rone; [371] 721-0005
FAX; [371] 782-0047
Flag description: three horizontal bands of maroon
(top), white (half-width), and maroon
I; Economy
Economy - overview: In 1 999 Latvia, a transitional
economy, experienced zero GDP growth as it
continued to feel the impact of the August 1998
Russian financial crisis. Latvia officially joined the
World Trade Organization (WTrO) in February 1999 -
the first Baltic state to join - band was invited at the
Helsinki EU Summit in December 1999 to begin
accession talks in early 2000. Unemployment reached
9.6% in 1 999, up from 9.2% in 1 998 and 6.7% in 1 997.
Privatization of large state-owned utilities, especially
the energy sector, faced more delays in 1999, but is
expected to accelerate in the next two years. Latvia
projects 3.5% GDP growth, 3% inflation, and a 2%
fiscal deficit in 2000. Preparing for EU membership by
2003 remains a top foreign policy priority.
GDP: purchasing power parity - $9.8 billion
(1999 est.)
GDP - real growth rate: 0% (1999 est.)
GDP - per capita: purchasing power parity - $4,200
(1999 est.)
GDP ■ composition by sector:
agriculture: 8%
industry: 29%
services: 63% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
towesf 10%; 4.3%
highest f0%; 22.1% (1993)
Inflation rate (consumer prices): 3.2% (1999 est.)
Labor force: 1 .4 million (1 997)
Labor force ■ by occupation: agriculture and
forestry 16%, industry 41%, services 43% (1990)
Unemployment rate: 9.6% (1999 est.)
Budget:
revenues: $1 .33 billion
expenditures: $1 .27 billion, including capital
expenditures of $NA (1998 est.)
Industries: buses, vans, street and railroad cars,
synthetic fibers, agricultural machinery, fertilizers,
washing machines, radios, electronios,
pharmaceuticals, processed foods, textiles;
dependent on imports for energy, raw materials, and
intermediate products
Industrial production growth rate: -5% (1999 est.)
Electricity - production: 4.766 billion kWh (1998)
280
Latvia (continued)
Electricity - production by source:
fossil fuel: 29.58%
hydro: 70.42%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 4.882 billion kWh (1 998)
Electricity - exports: 400 million kWh (1998)
Electricity - imports: 850 million kWh (1998)
Agriculture - products: grain, sugar beets,
potatoes, vegetables; beef, milk, eggs; fish
Exports: $1.9 billion (f.o.b., 1999)
Exports - commodities: wood and wood products,
machinery and equipment, metals, textiles, foodstuffs
Exports - partners: Germany 1 6%, UK 1 4%, Russia
12%, Sweden 10% (1998)
Imports: $2.8 billion (f.o.b., 1998)
Imports - commodities: machinery and equipment,
chemicals, fuels
Imports - partners: Germany 17%, Russia 12%,
Finland 10%, Sweden 7% (1998)
Debt - external: $212 million (1998)
Economic aid - recipient: $96.2 million (1995)
Currency: 1 Latvian lat (LVL) = 100 santims
Exchange rates: lats (LVL) per US$1 - 0.583
(January 2000),0.585 (1999), 0.590 (1998), 0.581
(1997), 0.551 (1996), 0.528 (1995)
Fiscal year: calendar year
1^ ^0 tn m u n i c a t i 0 n s
Telephones - main lines in use: 748,000 (1997)
Telephones - mobile cellular: 1 75,348 (1 999)
Telephone system: inadequate but is being
modernized to provide an international capability
independent of the Moscow international switch; more
facilities are being installed for individual use
domestic: expansion underway in intercity trunk line
connections, rural exchanges, and mobile systems;
still many unsatisfied subscriber applications
international: international connections are now
available via cable and a satellite earth station at Riga,
enabling direct connections for most calls (1 998)
Radio broadcast stations: AM 8, FM 56, shortwave
1 (1998)
Radios; 1.76 million (1997)
Television broadcast stations: 74 (1998)
Televisions; 1.22 million (1997)
Internet Service Providers (ISPs): 1 1 (1 999)
I Tran s p oil a t i o n^ ^ "
Railways:
fofa/;2,412km
broad gauge: 2,879 km 1.520-m gauge (271 km
electrified) (1992)
narrow gauge: 33 km 0.750-m gauge (1994)
Highways:
fofa/; 59,178 km
paved: 22,843 km
unpaved: 36,335 km (1 998 est.)
Waterways; 300 km perennially navigable
Pipelines; crude oil 750 km; refined products 780
km; natural gas 560 km (1992)
Ports and harbors: Daugavpils, Liepaja, Riga,
Ventspils
Merchant marine:
total: 1 4 ships (1 ,000 GRT or over) totaling 58,699
GRT/64,043 DWT
ships by type: cargo 4, petroleum tanker 4,
refrigerated cargo 6 (1999 est.)
Airports; 50 (1994 est.)
Airports - with paved runways:
total: 36
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m:1
under 914 m: 27 (1 994 est.)
Airports - with unpaved runways;
total: 14
2,438 to 3,047 m: 2
914 to 1,523 m: 2
under 914 m: 10 (1994 est.)
. ''■''IwTTTt''a''ry .
Military branches: Ground Forces, Navy, Air and Air
Defense Forces, Security Forces, Border Guard,
Home Guard (Zemessardze)
Military manpower - military age: 1 8 years of age
Military manpower - availability;
males age 15-49: 590,236 (2000 est.)
Military manpower - fit for miiitary service;
males age 15-49: 463,254 (2000 est.)
Military manpower • reaching military age
annually;
mates; 18,239 (2000 est.)
Military expenditures - dollar figure: $60 million
(FY99)
Military expenditures - percent of GDP; 0.9%
(FY99)
ransnational Issue r™
Disputes - international: draft treaty delimiting the
boundary with Russia has not been signed; ongoing
talks over maritime boundary dispute with Lithuania
(primary concern is oil exploration rights)
Illicit drugs: transshipment point for opiates and
cannabis from Central and Southwest Asia to Western
Europe and Scandinavia and Latin American cocaine
and some synthetics from Western Europe to CiS;
iimited production of iiiicit amphetamines, ephedrine,
and ecstasy for export
Background; Lebanon has made progress toward
rebuilding its political institutions and regaining its
national sovereignty since 1991 and the end of the
devastating 1 6-year civil war. Under the Ta''if Accord -
the blueprint for national reconciliation - the Lebanese
have estabiished a more equitable political system,
particularly by giving Musiims a greater say in the
political process while institutionalizing sectarian
divisions in the government. Since the end of the war,
the Lebanese have conducted several successful
elections, most of the militias have been weakened or
disbanded, and the Lebanese Armed Forces (LAF)
have extended centrai government authority over
about two-thirds of the country. Hizballah, the radical
Shi''a party, retains its weapons. Foreign forces stili
occupy areas of Lebanon, israel maintains troops in
southern Lebanon and continues to support a proxy
militia, the Army of South Lebanon (ASL), along a
narrow stretch of territory contiguous to its border.
Syria maintains about 25,000 troops in Lebanon
based mainly in Beirut, North Lebanon, and the Bekaa
Vailey. Syria''s troop depioyment was legitimized by
the Arab League during Lebanon''s civil war and in the
Ta''if Accord. Damascus justifies its continued miiitary
presence in Lebanon by citing the continued
weakness of the LAF, Beirut''s requests, and the
faiiure of the Lebanese Government to implement all
of the constitutional reforms in the Ta''if Accord.
. . .
Location; Middie East, bordering the Mediterranean
Sea, between israel and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references; Middie East
Area:
fofa/; 1 0,400 sq km
land: 10,280 sq km
wafer; 170 sq km
Area - comparative: about 0.7 times the size of
Connecticut
281
Lebanon (continued)
Land boundaries;
total: 454 km
border countries: Israel 79 km, Syria 375 km
Coastline; 225 km
Maritime claims;
territorial sea: ^2 nm
Climate; Mediterranean; mild to cool, wet winters
with hot, dry summers; Lebanon mountains
experience heavy winter snows
Terrain; narrow coastal plain; Al Biqa'' (Bekaa Valley)
separates Lebanon and Anti-Lebanon Mountains
Elevation extremes;
lowest point: Mediterranean Sea 0 m
highest point: Qurnat as Sawda'' 3,088 m
Natural resources; limestone, iron ore, salt,
water-surplus state in a water-deficit region, arable
land
Land use;
arable land: 2^%
permanent crops: 9%
permanent pastures: 1 %
forests and woodland: 8%
of/ier;61%(1993 est.)
Irrigated land; 860 sq km (1993 est.)
Natural hazards; dust storms, sandstorms
Environment - current issues; deforestation; soil
erosion; desertification; air pollution in Beirut from
vehicular traffic and the burning of industrial wastes;
pollution of coastal waters from raw sewage and oil
spills
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification,
Marine Dumping, Marine Life Conservation
Geography - note; Nahr al Litani only major river in
Near East not crossing an international boundary;
rugged terrain historically helped isolate, protect, and
develop numerous factional groups based on religion,
clan, and ethnicity','bb56255b9b0e18b59c0aaa74f41b92543b5404c9a09d7b015a3f65374827cfa3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f059d17c4bd4d9a57da1b18032408d40b58df69a1650b926c3ce8e13aea63da6',2000,'CH','Switzerland','military-and-security',301,'Military branches: Ground Forces, Navy, Air and Air
Defense Force, Security Forces (internal and border
troops). National Guard (Skat)
Military manpower - military age: 18 years of age
Military manpower ■ availability:
males age 15-49: 925,551 (2000 est.)
Military manpower - fit for military service:
mates age 15-49: 727,609 (2000 est.)
Military manpower - reaching military age
annually:
males: 27,259 (2000 est.)
Military expenditures - dollar figure: $181 million
(FY99)
Military expenditures - percent of GDP: 1 .5%
(FY99)','b5a68abf1bdb93563fba21ca73411c3e720030b0f6419a1cf6c51c3601068c43','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('049033fa1cd3e3dda20ad176a2f9b02d6b89a3fa934f22f2c334244a4ac835c2',2000,'MV','Maldives','military-and-security',314,'Military branches; National Security Service
(paramilitary police force)
Military manpower - availability:
mates age 15-49: 68,940 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 38,402 (2000 est.)
Miiitary expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Air Force, Gendarmerie,
Republican Guard, National Guard, National Police
(Surete Nationale)
Military manpower - availability;
males age 15-49: 2,202,950 (2000 est.)
Military manpower - fit for military service;
males age 1 5-49: 1 ,262,242 (2000 est.)
Military expenditures - dollar figure; $49 million
(FY96)
Military expenditures - percent of GDP; 2%
(FY96)
; Transnationallssues
Disputes - international; none
"Film
0 4 8 km
0 4 8 ml
f Introduction
Background: Great Britain formally acquired
possession of Malta in 1814. The island staunchly
supported the UK through both World Wars and
remained in the Commonwealth when it became
independent in 1964. A decade later Malta became a
republic. Over the last 15 years, the island has
become a major freight transshipment point, financial
center, and tourist destination. It is an official
candidate for EU membership.
Military branches: Armed Forces (including land
forces, an air squadron, a maritime squadron, and the
Revenue Security Corps), Maltese Police Force
Military manpower • availability:
males age 15-49: 98,850 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 78,677 (2000 est.)
Military expenditures • dollar figure: $201 million
(FY98/99)
Military expenditures • percent of GDP: 5.5%
(FY98/99)
Military - note: defense is the responsibility of the
UK','aeeba4e0175bd70832ffcad2c462060063a77e6d5e3268e8c27ab5ac252b14db','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa2b389be9804905aeeca1ae6ff1becce0a24feac8f4e78f54d323c4ecfd7f80',2000,'MH','Marshall Islands','military-and-security',325,'Military branches: no regular military forces (a
coast guard may be established); Police Force
Military expenditures - dollar figure: $NA
Military expenditures ■ percent of GDP: NA%
Military - note: defense is the responsibility of the
US','a8de4e8668036b41edd3eafabe3fd7e5d40b0000f7844aea33d7addfef5621bc','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c91e76465066924fd2c121f83188cf6daaaca777403f54170e019a1bb8531261',2000,'MR','Mauritania','military-and-security',331,'Military branches: Army, Navy, Air Force, Nationai
Gendarmerie, National Guard, National Police,
Presidentiai Guard
Military manpower - availability:
males age 15-49: 605,124 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 293,445 (2000 est.)
Military expenditures - dollar figure: $41 million
(FY97)
Military expenditures - percent of GDP: 2.7%
(FY97)
Military branches: Army (including ground forces
with border troops, naval forces, air and air defense
forces)
Military manpower - military age: Serbia - 1 9
years of age; Montenegro - 1 9 years of age
Military manpower - availability;
males age 15-49: 2,603,224 (Serbia - 2,424,990;
Montenegro - 178,234) (2000 est.)
Military manpower - fit for military service;
males age 15-49; 2,089,1 91 (Serbia - 1,945,422;
Montenegro - 143,769) (2000 est.)
Military manpower - reaching military age
annually:
males: 82,553 (Serbia - 76,856; Montenegro - 5,697)
(2000 est.)
Military expenditures - dollar figure; $91 1 million
(FY99)
Military expenditures - percent of GDP: 6.5%
(FY99)
( T f a n s n a fl 0 n a I IVs u e s
Disputes - international: disputes with Bosnia and
Herzegovina over Serbian populated areas; Albanian
majority in Kosovo seeks independence from Serbian
republic; Serbia and Montenegro is disputing Croatia''s
claim to the Prevlaka Peninsula in southern Croatia
because it controls the entrance to Boka Kotorska in
Montenegro; Prevlaka is currently under obsen/ation
by the UN military observer mission in Prevlaka
(UNMOP); the border commission formed by The
Former Yugoslav Republic of Macedonia and Serbia
and Montenegro in April 1 996 to resolve differences in
delineation of their border has made no progress so
far
Illicit drugs: transshipment point for Southwest
Asian heroin moving to Western Europe on the Balkan
route
440
{Seychelles
0 100 200 km
6 100 200 mi
VICTORIA
Les
Amirantes. ''
Mahd
Indian Ocean
Coetivy °
Groups
d’Aldabra
^Atoll de
Cosmoledo
''''^Atoll de
Farquhar
I n Tr b due t i b n
Background: A lengthy struggle between France
and Great Britain for the islands ended in 1814, when
they were ceded to the latter. Independence came in
1 976. Socialist rule was brought to a close with a new
constitution and free elections in 1993.
I G e b''g r a''p by" .
Location: Eastern Africa, group of islands in the
Indian Ocean, northeast of Madagascar
Geographic coordinates: 4 35 S, 55 40 E
Map references: Africa
Area:
total: 455 sq km
land: 455 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 491 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; humid; cooler season
during southeast monsoon (late May to September);
warmer season during northwest monsoon (March to
May)
Terrain: Mahe Group is granitic, narrow coastal strip,
rocky, hilly; others are coral, flat, elevated reefs
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Morne Seychellois 905 m
Natural resources: fish, copra, cinnamon trees
Land use:
arable land: 2%
permanent crops: 13%
permanent pastures: 0%
forests and woodland: 1 1%
other:7A%{im est.)
Irrigated land: NAsqkm
Natural hazards: lies outside the cyclone belt, so
severe storms are rare; short droughts possible
Environment - current issues: water supply
depends on catchments to collect rain water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: 40 granitic and about 50
coralline islands
I People ,
Population: 79,326 (July 2000 est.)
Age structure:
0- 14 years: 29% (male 1 1 ,499; female 1 1 ,338)
15-64 years: 65% (male 25,143; female 26,386)
65 years and over: 6% (male 1 ,674; female 3,286)
(2000 est.)
Population growth rate: 0.49% (2000 est.)
Birth rate: 1 7.99 births/1 ,000 population (2000 est.)
Death rate: 6.74 deaths/1,000 population
(2000 est.)
Net migration rate: -6.3 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.51 male(s)/female
total population: 0.93 male(s)/female (2000 est.)
Infant mortality rate: 1 7.74 deaths/l ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 70A1 years
male: 64.87 years
female: 76.12 years (2000 est.)
Total fertility rate: 1 .85 children born/woman
(2000 est.)
Nationality:
noun: Seychellois (singular and plural)
adjective: Seychelles
Ethnic groups: Seychellois (mixture of Asians,
Africans, Europeans)
Religions: Roman Catholic 90%, Anglican 8%, other
2%
Languages: English (official), French (official).
Creole
Literacy:
definition: age 15 and over can read and write
total population: 58%
male: 56%
fema/e; 60% (1971 est.)
I Government
Country name:
conventional long form: Republic of Seychelles
conventional short form: Seychelles
Data code: SE
Government type: republic
Capital: Victoria
Administrative divisions: 23 administrative
districts; Anse aux Pins, Anse Boileau, Anse Etoile,
Anse Louis, Anse Royale, Bale Lazare, Bale Sainte
Anne, Beau Vallon, Bel Air, Bel Ombre, Cascade,
Glacis, Grand'' Anse (on Mahe), Grand'' Anse (on
Praslin), La Digue, La Riviere Anglaise, Mont Buxton,
Mont Fleuri, Plaisance, Pointe La Rue, Port Glaud,
Saint Louis, Takamaka
Independence: 29 June 1976 (from UK)
National holiday: National Day, 18 June (1993)
(adoption of the constitution)
Constitution: 18 June 1993
Legal system: based on English common law,
French civil law, and customary law
Suffrage: 17 years of age; universal
Executive branch:
chief of state: President France Albert RENE (since 5
June 1977); note - the president is both the chief of
state and head of government
head of government: President France Albert RENE
(since 5 June 1977); note - the president is both the
chief of state and head of government
cabinet: Council of Ministers appointed by the
president
elections: president elected by popular vote for a
five-year term; election last held 20-22 March 1998
(next to be held by NA 2003)
election results: France Albert RENE reelected
president; percent of vote - France Albert RENE
(SPPF) 66.7%, Wavel RAMKALAWAN (UO) 19.5%,
Sir James MANCHAM (DP) 13.8%
Legislative branch: unicameral National Assembly
or Assemblee Nationale (35 seats - 25 elected by
popular vote, 10 allocated on a proportional basis to
parties winning at least nine percent of the vote;
members serve five-year terms)
elections: last held 20-22 March 1 998 (next to be held
by NA 2003)
election results: percent of vote by party - NA; seats
by party (elected) - SPPF 24, DP 1; seats by party
(awarded) -SPPF 6, DP1,U0 3
note: the 1 0 awarded seats are apportioned according
to the share of each party in the total vote
Judicial branch: Court of Appeal, judges are
appointed by the president; Supreme Court, judges
are appointed by the president
Political parties and leaders: Democratic Party or
DP [leader NA]; New Democratic Party [Christopher
GILL (former member of DP)]; Seychelles People''s
Progressive Front or SPPF [France Albert RENE] -
the governing party; United Opposition or UO [Wavel
RAMKALAWAN] - a coalition of the following parties:
Seychelles Party or PS [Wavel RAMKALAWAN],
441
Seychelles (continued)
Seychelles Democratic Movement or MSPD [Jacques
HONDOUL], and Seychelles Liberal Party or SLP
[Ogllvie BERLOUIS]
Political pressure groups and leaders: Roman
Catholic Church; trade unions
International organization participation: ACCT,
ACP, AfDB, C, ECA, FAO, G-77, IBRD, ICAO, ICFU,
ICRM, IFAD, IFC, IFRCS, ILO, IMF, IMO, InOC,
Intelsat (nonsignatory user), Interpol, IOC, ISO
(correspondent), NAM, OAU, OPCW, SADC, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO,
WMO, WToO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Harold Walter GEISEL
chancery: 800 Second Avenue, Suite 400C, New
York, NY 10017
fe/ep/7one;[1](212) 972-1785
FAX; [1] (21 2) 972-1786
Diplomatic representation from the US: the US
does not have an embassy in Seychelles; the
ambassador to Mauritius is accredited to Seychelles
Flag description: five oblique bands of blue (hoist
side), yellow, red, white, and green (bottom) radiating
from the bottom of the hoist side
Military branches: Army, Coast Guard, Marines, air
wing. National Guard, Presidential Protection Unit,
Police Force
Military manpower - availability:
males age 15-49: 22,677 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,345 (2000 est.)
Military expenditures - dollar figure: $13 million
(FY93)
Military expenditures ■ percent of GDP: 2.8%
(FY93)','43988639028882254c5fd1a7949e0ef78cca2d2a3f418e862b3f4ae69233dcf1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51adaf9cf6329cff15fc015b08c1676216c9488c684c9fb8c53532782583f6db',2000,'ID','Indonesia','military-and-security',346,'Military - note: Federated States of Micronesia
(FSM) is a sovereign, self-governing state in free
association with the US; FSM is totally dependent on
the US for its defense
Military branches: Army, Navy, Air Force, People''s
Defense Force, Police Force
Military manpower - availability:
males age 15-49: 1 ,278,525 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 932,978 (2000 est.)
Military expenditures - dollar figure: $4.4 billion
(FY98/99)
Military expenditures - percent of GDP: 4.9%
(FY98/99)','16429a4061e55fdf439ffa63da0a218ce086075437dc3a0c96a1dfada9b7f87e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('945a11db889ab36ec7adafd984b8ddc2322babbc63831d3e070de90746a32d99',2000,'NZ','New Zealand','military-and-security',368,'Military branches: New Zealand Army, Royal New
Zealand Navy, Royal New Zealand Air Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 990,774 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 834,289 (2000 est.)
Military manpower - reaching military age
annually:
males: 26,649 (2000 est.)
Military expenditures - dollar figure: $883 million
(FY97/98)
Military expenditures - percent of GDP: 1.1%
(FY97/98)
Military branches: Army, Navy, Air Force
Military manpower - military age; 1 8 years of age
Military manpower - availability:
males age 15-49; 1,229,103 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 755,002 (2000 est.)
Military manpower - reaching military age
annually:
males: 57,125 (2000 est.)
Military expenditures - dollar figure; $26 million
(FY98)
Military expenditures - percent of GDP; 1 .2%
(FY98)
Military branches: Army, Air Force, National
Gendarmerie, Republican Guard, National Police
Military manpower - military age: 1 8 years of age
Military manpower - availability;
males age 15-49; 2,137,181 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,155,054 (2000 est.)
Military manpower - reaching military age
annually:
mates; 105,884 (2000 est.)
Military expenditures - dollar figure: $20 million
(FY96)
Military expenditures - percent of GDP: 1.1%
(FY96)
364
Niger (continued)
f T r a li s n a 1 1 o rt¥a I Issues
Disputes - international; Libya claims about 1 9,400
sq km in northern Niger; deiimitation of international
boundaries In the vicinity of Lake Chad, the lack of
which led to border incidents in the past, has been
completed and awaits ratification by Cameroon,
Chad, Niger, and Nigeria
Background; Foilowing nearly 16 years of military
rule, a new constitution was adopted in 1 999 and a
peaceful transition to civilian government completed.
The new president faces the daunting task of
rebuilding a petroleum-based economy, whose
revenues have been squandered through corruption
and mismanagement, and institutionalizing
democracy. In addition, the OBASANJO
administration must defuse longstanding ethnic and
religious tensions, it it is to build a sound foundation
for economic growth and political stability.
I Geography
Location; Western Africa, bordering the Gulf of
Guinea, between Benin and Cameroon
Geographic coordinates; 10 00 N, 8 00 E
Map references; Africa
Area;
total: 923,768 sq km
/and; 910,768 sqkm
wafer; 13,000 sqkm
Area - comparative; slightly more than twice the
size of California
Land boundaries;
total: 4,047 km
border countries: Benin 773 km, Cameroon 1 ,690 km,
Chad 87 km, Niger 1,497 km
Coastline; 853 km
Maritime claims;
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate; varies; equatorial in south, tropical in
center, arid in north
Terrain; southern lowlands merge into central hills
and plateaus; mountains in southeast, plains in north
Elevation extremes;
lowest point: Atlantic Ocean 0 m
highest point: Chappal Waddi 2,419 m
Natural resources; petroleum, tin, columbite, iron
ore, coal, limestone, lead, zinc, natural gas,
hydropower, arable land
Land use;
arable land: 33%
permanent crops: 3%
permanent pastures: 44%
forests and woodland: 12%
of/7er;8%(1993est.)
Irrigated land; 9,570 sq km (1993 est.)
Natural hazards; periodic droughts
Environment - current issues; soil degradation;
rapid deforestation; desertification; recent droughts in
north severely affecting marginal agricultural activities
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Consen/ation, Nuclear Test Ban, Ozone Layer
Protection
signed, but not ratified: none of the selected
agreements
I "P e o^TT~
Population; 123,337,822
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 44% (male 27,181,020; female
26,872,317)
15-64 years: 53% (male 33,495,794; female
32,337,193)
65 years and over: 3% (male 1 ,729, 1 49; female
1,722,349) (2000 est.)
Population growth rate; 2.67% (2000 est.)
Birth rate; 40.16 births/1 ,000 population (2000 est.)
Death rate; 13.72 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0.28 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 1 male(s)/female
total population: 1 .02 male(s)/female (2000 est.)
Infant mortality rate; 74.18 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 51 .56 years
male: 51 .58 years
female: 51 .55 years (2000 est.)
Total fertility rate; 5.66 children born/woman
(2000 est.)
Nationality;
noun: Nigerian(s)
adjective: Nigerian
365
Nigoria (continued)
Ethnic groups: Nigeria, which is Africa''s most
populous country, is composed of more than 250
ethnic groups; the following are the most populous
and politically influential: Hausa and Fulani 29%,
Yoruba21%, Igbo (Ibo) 18%, Ijaw 10%, Kanuri 4%,
Ibibio 3.5%, Tiv 2.5%
Religions: Muslim 50%, Christian 40%, indigenous
beliefs 10%
Languages: English (official), Hausa, Yoruba, Igbo
(Ibo), Fulani
Literacy:
definition: age 1 5 and over can read and write
total population: 57 A%
male: 67.3%
fema/e; 47.3% (1995 est.)
Military branches: Tonga Defense Services
(includes. Royal Tongan Marines, Tongan Royal
Guards, Maritime Force, Police); note ■ a new Air
Wing which will be subordinate to the Defense
Ministry is being developed
Military expenditures - doliar figure: $NA
Miiitary expenditures - percent of GDP: NA%
Military branches: Trinidad and Tobago Defense
Force (inciudes Ground Forces, Coast Guard, and Air
Wing), Trinidad and Tobago Poiice Service
Military manpower • availability:
males age 15-49: 342,980 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 245,253 (2000 est.)
Military expenditures - dollar figure: $83 million
(FY94)
Military expenditures • percent of GDP: NA%
Military - note: defense is the responsibility of','e2a01e5c90b7d380f792d4cc056293fa48f061d9966c39f860ea48605ea19718','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6746ccd13260f2f68356863e990cd86d1dc5a6f53bee27f6b7dc09fb2954141e',2000,'MP','Northern Mariana Islands','military-and-security',372,'Military - note: defense is the responsibility of the
US
Military - note: defense is the responsibility of the
US','6f75d34e097b117b9add09a066dae95e2d2a46a6e85ab39c03b02681b0c6af76','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ed945793d1cc26811d6bdbc05314d62d8161a9e073094af1b2980ca3b04df87',2000,'MX','Mexico','military-and-security',398,'Military branches: Army, Navy (includes Marines),
Air Force, National Republican Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 2,534,872 (2000 est.)
Military manpower - fit for military service:
males age 15-49:2,036,712 (2000 est.)
Military manpower ■ reaching military age
annually:
males: 74,050 (2000 est.)
Military expenditures - dollar figure: $2,458 billion
(FY97)
Military expenditures - percent of GDP: 2.6%
(FY97)','befd93a798dd4ef8db80c4baf4a7cee724ce77cf523ba67bfe65ced42f9fea06','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd2ca57b75c377b40ca5585f217ffbdee7244882d4bca8ceb20551f0dcf1568c',2000,'DO','Dominican Republic','military-and-security',402,'Military branches: paramilitary National Guard,
Police Force
Military - note: defense is the responsibility of the
US
p t r a n s n a t i 0 n a i issues
Disputes - international; none
Background: During the (ate 1 980s and early 1 990s,
the Qatari economy was crippled by a continuous
siphoning off of petroleum revenues by the amir who
had ruled the country since 1972. He was overthrown
in a bloodless coup by his own son in 1995. Oil and
natural gas revenues enable Qatar to have a per
capita income not far below the leading industrial
countries of Western Europe.
I’”" . . .
Location: Middle East, peninsula bordering the
Persian Gulf and Saudi Arabia
Geographic coordinates; 25 SON, 51 15 E
Map references; Middle East
Area:
tofa/; 11,437 sqkm
land: 11,437 sq km
wafer; 0 sq km
Area - comparative: slightiy smaller than
Connecticut
Land boundaries:
total: 60 km
border countries: Saudi Arabia 60 km
Coastline: 563 km
Maritime ciaims:
contiguous zone: 24 nm
exclusive economic zone: as determined by bilateral
agreements, or the median line
ferr/for/a/ sea; 12 nm
Climate; desert; hot, dry; humid and sultry in summer
Terrain; mostly flat and barren desert covered with
loose sand and gravel
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Qurayn Abu al Bawl 1 03 m
Natural resources: petroleum, natural gas, fish
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 0%
of/7er;94%(1993est.)
Irrigated land: 80 sqkm (1993 est.)
Natural hazards: haze, dust storms, sandstorms
common
Environment - current issues: limited natural fresh
water resources are Increasing dependence on
large-scale desalination facilities
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: Law of the Sea
Geography • note: strategic location in central
Persian Gulf near major petroleum deposits
I P ® 0 p I e
Population: 744,483 (July 2000 est.)
Age structure:
0-14 years: 26% (male 99,702; female 95,960)
15-64 years: 71% (male 378,741; female 152,978)
65 years and over: 3% (male 12,120; female 4,982)
(2000 est.)
Population growth rate: 3.35% (2000 est.)
Birth rate; 16.07 births/1 ,000 population (2000 est.)
Death rate: 4.19 deaths/1,000 population
(2000 est.)
Net migration rate: 21 .58 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/temale
under 15 years: 1 .04 male(s)/female
15-64 years: 2.48 male(s)/female
65 years and over: 2.43 male(s)/f emale
total population: 1.98 male(s)/temale (2000 est.)
Infant mortality rate: 22.14 deaths/1,000 live births
(2000 est.)
Life expectancy at birth;
total population: 72.37 years
male: 69.92 years
female: 74.94 years (2000 est.)
Total fertility rate: 3.25 children born/woman
(2000 est.)
405
Qatar (continued)
Nationality;
noun: Qatari(s)
adjective: Qatari
Ethnic groups; Arab 40%, Pakistani 18%, Indian
18%, iranian 10%, other 14%
Religions; Muslim 95%
Languages; Arabic (official), English commonly
used as a second language
Literacy;
definition: age 15 and over can read and w/rite
total population: 79.4%
male: 79.2%
fema/e; 79.9% (1995 est.)','6b34722318f7c7827babe4d8cb18becf3d1eca8351661052a504b98849b6927b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03126f5af8adf44c69ab7170837bca9689a6f8aeb88ed8109da29450d4488eb3',2000,'SO','Somalia','military-and-security',429,'Military branches; no functioning central
government military forces; clan militias continue to
battle for control of key economic or political prizes
Military manpower - availability:
males age 15-49; 1,772,631 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 984,103 (2000 est.)
Military expenditures - dollar figure; $NA
Military expenditures - percent of GDP: NA%','41a66017bbd448ea5f2ec239c5862d2bc03954907705e0601aa728dff802f6e7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ddd2d8271c3676758fc56d3926b4a7bb277d4bc7d4748ccb77f84ae5fc9293a',2000,'ZA','South Africa','military-and-security',435,'Miiitary branches: Army, Navy, Air Force, Marines,
Civil Guard, National Police, Coastal Civil Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
mates age 15-49.- 10,569,785 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 8,481 ,690 (2000 est.)
Military manpower - reaching military age
annually:
males: 295,335 (2000 est.)
Military expenditures - dollar figure: $6 billion
(FY97)
Military expenditures ■ percent of GDP: 1 .1%
(FY97)','59d4da7fd6ddfa922c144a14b25b6dbceaff46b3a95f33b6632790e4ea7696cf','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4701fc4d754d59212b4a842cb35ded7f1e36f7ec74908b60f5cc9957a47eba89',2000,'PH','Philippines','military-and-security',438,'Military ■ note: Spratly Islands consist of more than
100 small islands or reefs, of which about 45 are
claimed and occupied by China, Malaysia, the
Philippines, Taiwan, and Vietnam','7670065f801cc1b417150463b19e97a12405fc3aed9d9fba23fb7c5eade02316','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0d8a3b5282784f1f4755a3f833fe0a29436430e8cef9890c4eeda51ccedc21b',2000,'GY','Guyana','military-and-security',446,'Military branches; National Army (includes small
Navy and Air Force elements). Civil Police
Military manpower - availability;
males age 15-49: 120,152 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 70,580 (2000 est.)
Military expenditures - dollar figure; $8.5 million
(FY97 est.)
Military expenditures - percent of GDP; 1 .6%
(FY97 est.)
I Transnational issues
Disputes - international; claims area in French
Guiana between Litani Rivier and Riviere Marouini
(both headwaters of the Lawa); claims area in Guyana
between New (Upper Courantyne) and Courantyne/
Koetari [Kutari] Rivers (all headwaters of the
Courantyne)
Illicit drugs; transshipmentpointforSouth American
drugs destined mostly for Europe
iSvalbard
I (territory of Norway)
Background; First discovered by the Norwegians in
the 12th century, the islands served as an
international whaling base during the 17th and 18th
centuries. Norway''s sovereignty was recognized in
1 920; five years later it officially took over the territory.
Location; Northern Europe, islands between the
Arctic Ocean, Barents Sea, Greenland Sea, and
Norwegian Sea, north of Norway
Geographic coordinates; 78 00 N, 20 00 E
Map references; Arctic Region
Area;
total: 62,049 sq km
land: 62,049 sq km
water: 0 sq km
note: includes Spitsbergen and Bjornoya (Bear
Island)
Area - comparative; slightly smaller than West
Virginia
Land boundaries; 0 km
Coastline; 3,587 km
Maritime claims;
exclusive fishing zone: 200 nm unilaterally claimed by
Norway but not recognized by Russia
territorial sea: 4 nm
Climate; arctic, tempered by warm North Atlantic
Current; cool summers, cold winters; North Atlantic
Current flows along west and north coasts of
Spitsbergen, keeping water open and navigable most
of the year
Terrain; wild, rugged mountains; much of high land
ice covered; west coast clear of ice about one-half of
the year; fjords along west and north coasts
Elevation extremes;
lowest point: Arctic Ocean 0 m
highest point: Newtontoppen 1,717 m
Natural resources; coal, copper, iron ore,
phosphate, zinc, wildlife, fish
Land use;
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (no trees and the only bushes are
crowberry and cloudberry)
Irrigated land; NAsqkm
Natural hazards; ice floes often block up the
entrance to Bellsund (a transit point for coal export) on
the west coast and occasionally make parts of the
northeastern coast inaccessible to maritime traffic
Environment - current issues; NA
Geography - note; northernmost part of the
Kingdom of Norway; consists of nine main islands;
glaciers and snowfields cover 60% of the total area
I People
Population; 2,416 (July 2000 est.)
Age structure;
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate; -3.55% (2000 est.)
Birth rate; NA births/1 ,000 population
Death rate; NA deaths/1 ,000 population
Net migration rate; NA migrant(s)/1 ,000 population
Infant mortality rate; NA deaths/1 ,000 live births
Life expectancy at birth;
total population: NA years
male: NA years
female: NA years
Total fertility rate; NA children born/woman
Ethnic groups; Russian and Ukrainian 62%,
Norwegian 38%, other NEGL% (1994)
Languages; Russian, Norwegian
i Government
Country name;
conventional long form: none
conventional short form: Svalbard (sometimes
referred to as Spitzbergen)
Data code; SV
Dependency status; territory of Norway;
administered by the Ministry of Industry, Oslo, through
a governor (sysselmann) residing in Longyearbyen,
Spitsbergen; by treaty (9 February 1920) sovereignty
was given to Norway
Government type; NA
Capital; Longyearbyen
Independence; none (territory of Norway)
National holiday; NA
Legal system; NA
Executive branch;
chief of state: King HARALD V of Norway (since 17
January 1991)
head of government: Governor Morten RUUD (since
NA November 1998) and Assistant Governor Rune
Baard HANSEN (since NA 1996)
elections: none; the monarch is hereditary; governor
and assistant governor responsible to the Polar
Department of the Ministry of Justice
472
Svalbard (continued)
Televisions: NA
Internet Service Providers (ISPs): NA
P fra n sIjo r t a t i o n
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Barentsburg, Longyearbyen,
Ny-Alesund, Pyramiden
Merchant marine: none (1999 est.)
Airports: 4 (1999 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m;1 (1999 est.)
Airports - with unpaved runways:
total: 3
under 914 m: 3 (1 999 est.)
I””" — -r- ^
Military - note: demilitarized by treaty (9 February
1920)
Swaziland
Piggs
/ .Peak
» SOUTH /
g AFRICA /
Mhlume*
s
o
N
, >
s
I
/ ^MBABANE f
/ Siteki, \\
1 Lobamba* .Manzini ^
BIQUE
.Mankayane
Big
Bend.
J .Hlatikulu
.Nhlangano
f SOUTH
AFRICA
;0
20 40 km
Lavumisa. ''
i
''6
X 40 mi
_ 1
I Introduction
Background: Autonomy for the Swazis of southern
Africa was guaranteed by the British in the late 19th
century; independence was granted 1968. Student
and labor unrest during the 1 990s have pressured the
monarchy (one of the oldest on the continent) to
grudgingly allow political reform and greater
democracy.
International organization participation: none
Flag description: the flag of Norway is used
p Econom y”^
Economy - overview: Coal mining is the major
economic activity on Svalbard. The treaty of 9
February 1 920 gives the 41 signatories equal rights to
exploit mineral deposits, subject to Norwegian
regulation. Although US, UK, Dutch, and Swedish
coal companies have mined in the past, the only
companies still mining are Norwegian and Russian.
The settlements on Svalbard are essentially company
towns. The Norwegian state-owned coal company
employs nearly 60% of the Norwegian population on
the island, runs many of the local services, and
provides most of the local infrastructure. There is also
some trapping of seal, polar bear, fox, and walrus.
GDP: $NA
GDP - real growth rate: NA%
GDP - per capita: $NA
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: HA%
Inflation rate (consumer prices): NA%
Labor force: NA
Budget:
revenues: $1 1 ,7 million
expenditures: $11. 7 million, including capital
expenditures of $NA (1997 est.)
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
Exports: $NA
Imports: $NA
Economic aid - recipient: $8.7 million from Norway
(1997)
Currency: 1 Norwegian krone (NKr) = 100 oere
Exchange rates: Norwegian kroner (NKr) per
US$1 - 8.01 29 (January 2000), 7.7992 (1 999), 7.5451
(1998), 7.0734 (1997), 6.4498 (1996), 6.3352 (1995)
I Communications
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
domestic: local telephone service
international: satellite earth station - 1 of NA type (for
communication with Norwegian mainland only)
Radio broadcast stations: AM 1 , FM 1 (plus 2
repeaters), shortwave 0 (1998)
Radios: NA
Television broadcast stations: NA
^ g - p -
Location: Southern Africa, between Mozambique
and South Africa
Geographic coordinates: 26 30 S, 31 30 E
Map references: Africa
Area:
total: 17,363 sq km
land: 17,203 sq km
water: 160 sq km
Area - comparative: slightly smaller than New','3260571b6f0c2db5beb7d863a1e0e044d7a66396f99efcd691a3cc61c5f99d81','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e812cc5ade8112248f644383113ab2f0c7016cd615d207e3e9b08b7c224051a',2000,'IT','Italy','military-and-security',450,'Military branches: Army, Air Force, Frontier
Guards, Fortification Guards
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49; 1,855,808 (2000 est.)
Military manpower - fit for military service:
males age 15-49; 1,579,921 (2000 est.)
Military manpower - reaching military age
annually:
ma/es;42,169 (2000 est.)
Military expenditures -dollar figure: $3.1 billion
(FY98)
Military expenditures - percent of GDP: 1 .2%
(FY98)
I Transnational i s sH e s
Disputes - international: none
Illicit drugs: because of more stringent government
regulations, used significantly less as a
money-laundering center; transit country for and
consumer of South American cocaine and Southwest
Asian heroin
i n t r 0 d u c t i 0 n
Background: Following the breakup of the Ottoman
Empire during World War I, Syria was administered by
the French until independence in 1946. In the 1967
Arab-lsraeli War, Syria lost the Golan Heights to
Israel. Since 1 976, Syrian troops have been stationed
in Lebanon, ostensibly in a peacekeeping capacity.
Talks with Israel over the return of the Golan Heights
have recently been revived.
i Geography
Location: Middle East, bordering the Mediterranean
Sea, between Lebanon and Turkey
Geographic coordinates: 35 00 N, 38 00 E
Map references: Middle East
Area:
tola/; 185,180 sq km
land: 184,050 sq km
wafer; 1,130 sq km
note: includes 1 ,295 sq km of Israeli-occupied territory
Area - comparative: slightly larger than North
Dakota
Land boundaries:
total: 2,253 km
border countries: Iraq 605 km, Israel 76 km, Jordan
375 km, Lebanon 375 km, Turkey 822 km
Coastline: 193 km
Maritime claims:
contiguous zone: 41 nm
territorial sea: 35 nm
Climate: mostly desert; hot, dry, sunny summers
(June to August) and mild, rainy winters (December to
February) along coast; cold weather with snow or
sleet periodically hitting Damascus
Terrain: primarily semiarid and desert plateau;
narrow coastal plain; mountains in west
Elevation extremes:
lowest point: unnamed location near Lake Tiberias
-200 m
highest point: Mount Hermon 2,814 m
Syria (continued)
Natural resources: petroleum, phosphates, chrome
and manganese ores, asphalt, iron ore, rock salt,
marble, gypsum, hydropower
Land use;
arable land: 28%
permanent crops: A%
permanent pastures: 43%
forests and woodland: 3%
other; 22% (1 993 est.)
Irrigated land: 9,060 sq km (1993 est.)
Natural hazards; dust storms, sandstorms
Environment - current issues; deforestation;
overgrazing; soil erosion; desertification; water
pollution from dumping of raw sewage and wastes
from petroieum refining; inadequate supplies of
potable water
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, NuclearTestBan,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
Geography - note: there are 42 Israeli settlements
and civilian land use sites in the Israeli-occupied
Golan Heights (August 1999 est.)
I * " p e''S''pTe
Population; 16,305,659
note: in addition, there are about 38,200 peopie living
in the Israeli-occupied Goian Heights - 18,200 Arabs
(16,500 Druze and 1 ,700 Alawites) and about 20,000
Israeli settlers (July 2000 est.)
Age structure:
0-14 years: AV/c (male 3,410,417; female 3,210,215)
15-64 years: 56% (male 4,688,967; female
4,476,022)
65 years and over: 3% (male 254,448; female
265,590) (2000 est.)
Population growth rate; 2.58% (2000 est.)
Birth rate: 31.11 births/1,000 population (2000 est.)
Death rate: 5.29 deaths/1,000 population
(2000 est.)
Net migration rate; 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 1 .05 male(s)/female (2000 est.)
Infant mortality rate: 34.86 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 68.46 years
male: 67.35 years
female: 69.64 years (2000 est.)
Total fertility rate: 4.06 children born/woman
(2000 est.)
Nationality:
noun: Syrian(s)
adjective: Syrian
Ethnic groups; Arab 90.3%, Kurds, Armenians, and
)ther 9.7%
Religions; Sunni Muslim 74%, Alawite, Druze, and
other Muslim sects 16%, Christian (various sects)
10%, Jewish (tiny communities in Damascus, Al
Qamishli, and Aleppo)
Languages: Arabic (official); Kurdish, Armenian,
Aramaic, Circassian widely understood; French, .
English somewhat understood
Literacy:
definition: age 1 5 and over can read and write
total population: 70.8%
male: 85.7%
fema/e; 55.8% (1997 est.)
I Gov e r n lin e n t ^
Country name:
conventional long form: Syrian Arab Republic
conventional short form: Syria
local long form: Al Jumhuriyah al Arabiyah as Suriyah
local short form: Suriyah
former: United Arab Republic (with Egypt)
Data code: SY
Government type: republic under military regime
since March 1963
Capital: Damascus
Administrative divisions: 14 provinces
(muhafazat, singular - muhafazah); Al Hasakah, Al
Ladhiqiyah, Al Qunaytirah, Ar Raqqah, As Suwayda'',
Dar''a, Dayr az Zawr, Dimashq, Halab, Hamah, Hims,
Idlib, Rif Dimashq, Tarfus
Independence; 17 April 1946 (from League of
Nations mandate under French administration)
National holiday: National Day, 17 April (1946)
Constitution: 13 March 1973
Legal system; based on Islamic law and civil law
system; special religious courts; has not accepted
compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch;
chief of state: President Hafiz al-ASAD (since 22
February 1971); note - President ASAD seized power
in the November 1970 coup, assumed presidential
powers 22 February 1971, and was confirmed as
president in the 12 March 1971 national elections;
Vice Presidents ''Abd al-Halim ibn Said KHADDAM
(since 1 1 March 1984) and Muhammad Zuhayr
MASHARIQA (since 11 March 1984)
head of government: Prime Minister Mohammad
Mustaf MIRU (since 13 March 2000), Deputy Prime
Ministers Lt. Gen. Mustafa TALAS (since 1 1 March
1984), Dr. Salim YASIN (since NA December 1981),
and Rashid AKHTARINI (since 4 July 1 992)
cabinet: Council of Ministers appointed by the
president
elections: president elected by popular vote for a
seven-year term; referendum/election last held 8
February 1999 (next to be held NA 2006); vice
presidents appointed by the president; prime minister
and deputy prime ministers appointed by the
president
election results: Hafiz al-ASAD reelected president;
percent of vote - Hafiz al-ASAD 99%
Legislative branch: unicameral People''s Council or
Majlis al-shaab (250 seats; members elected by
popular vote to serve four-year terms)
elections: last held 30 November-1 December 1998
(next to be held NA 2002)
election results: percent of vote by party - NPF 67%,
non-NPF 33%; seats by party - NPF 167,
Independents 83; note - the constitution guarantees
that the Ba''th Party (part of the NPF alliance) receive
one-half of the seats
Judicial branch: Supreme Constitutional Court,
justices are appointed for four-year terms by the
president; High Judicial Council; Court of Cassation;
State Security Courts
Political parties and leaders: National Progressive
Front (NPF) (includes the Ba''th Party, ASU, Arab
Socialist Party, Socialist Unionist Democratic Party,
ASP, SCP) [President Hafiz al-ASAD]; Arab Socialist
Renaissance (Ba''th) Party (governing party) [Hafiz
al-ASAD, president of the republic, secretary general
of the party, and chairman of the National Progressive
Front]; Arab Socialist Unionist Movement or ASU
[Fayiz ISMAIL]; Arab Socialist Party [Abd al-Ghani
KANNUT]; Socialist Unionist Democratic Party
[Ahmad al-ASAD]; Syrian Arab Socialist Party or ASP
[Ghassan ''Abd-al-Aziz UTHMAN]; Syrian Communist
Party or SCP [Yusuf FAYSAL]
Political pressure groups and leaders;
Communist party ineffective; conservative religious
leaders; Muslim Brotherhood (operates in exile In
Jordan and Yemen); non-Ba''th parties have little
effective political Influence
International organization participation; ABEDA,
AFESD, AL, AMF, CAEU, CCC, ESCWA, FAO, G-24,
G-77, IAEA, IBRD, ICAO, ICC, ICRM, IDA, IDB, IFAD,
IFC, IFRCS, IHO, ILO, IMF, IMO, Intelsat, Interpol,
IOC, ISO, ITU, NAM, OAPEC, OIC, UN, UNCTAD,
UNESCO, UNIDO, UNRWA, UPU, WFTU, WHO,
WMO, WToO
Diplomatic representation in the US;
chief of mission: Ambassador (vacant)
c/rancery; 2215 Wyoming Avenue NW, Washington,
DC 20008
telephone: [1] {202) 282-8313
FAX; [1] (202) 234-9548
Diplomatic representation from the US:
ch/ef of m/ss/or?; Ambassador Ryan C. CROCKER
embassy; Abou Roumaneh, Al-Mansur Street, No. 2,
Damascus
mailing address: P. 0. Box 29, Damascus
telephone: [963] (11) 333-2814, 333-0788, 332-0783
FAX; [963] (11)224-7938
Flag description: three equal horizontal bands of
red (top), white, and black, with two smali green
five-pointed stars in a horizontal line centered in the
white band; similar to the flag of Yemen, which has a
plain white band, and of Iraq, which has three green
stars (plus an Arabic inscription) in a horizontal line
centered in the white band; also similar to the flag of
Egypt, which has a heraldic eagle centered in the
white band
481
Syria (continued)
Military branches: Syrian Arab Army, Syrian Arab
Navy, Syrian Arab Air Force, Syrian Arab Air Defense
Forces, Police and Security Force
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 4,220,578 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 2,358,973 (2000 est.)
Military manpower - reaching military age
annually:
males: 196,616 (2000 est.)
Military expenditures ■ dollar figure: $800
million-$1 billion (FY97 est.); note - based on official
budget data that may understate actual spending
Military expenditures - percent of GDP: 5.9%
(FY98)','2dc72ec34d4d9e7b37e7f3ca778c3d423579eef0179c1311f908be881584519f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdd25084c041458ee10c64f6509a718172d25a0129c63419889e485b764a6a9f',2000,'ZW','Zimbabwe','military-and-security',461,'Military branches: Royal Thai Army, Royal Thai
Navy (includes Royal Thai Marine Corps), Royal Thai
Air Force, Paramilitary Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 17,621,080 (2000 est.)
Military manpower - fit for military service:
males age 15-49; 10,603,857 (2000 est.)
Military manpower - reaching military age
annually:
males: 580,014 (2000 est.)
490
Military expenditures - dollar figure: $2,075 billion
(FY97/98)
Military expenditures - percent of GDP: 1 .3%
(FY97/98)
Military - note: defense is the responsibility of New
Zealand','203fa67b0f237e66d05f3eecdf98ee7ed0a033f3bd0dca7b49c60b3f69d9190f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43dbfd474b3c3e210ab04910b108d27792f623fb620fddfdc19d6adec7659ad1',2000,'VU','Vanuatu','military-and-security',476,'Military branches: no regular military forces;
Vanuatu Police Force (VPF; inciudes the paramilitary
Vanuatu Mobile Force or VMF)
Military expenditures - dollar figure; $NA
Military expenditures - percent of GDP: NA%
i transnational Issues
Disputes ■ international: claims Matthew and
Hunter Islands east of New Caledonia
530
Military branches: National Armed Forces (Fuerzas
Armadas Nacionales or FAN) includes Ground Forces
or Army (Fuerzas Terrestres or Ejercito), Naval
Forces (Fuerzas Navales or Armada), Air Force
(Fuerzas Aereas or Aviacion), Armed Forces of
Cooperation or National Guard (Fuerzas Armadas de
Cooperacion or Guardia Nacional)
Military manpower - military age: 1 8 years of age
Military manpower • availability;
males age 15-49: 6,398,169 (2000 est.)
Military manpower - fit for military service;
mates age 15-49: 4,612,754 (2000 est.)
Military manpower • reaching military age
annually;
males: 244,350 (2000 est.)
Military expenditures - dollar figure; $934 million
(FY99)
Military expenditures - percent of GDP: 0.9%
(FY99)','865864bf3f81242215ac0bda2353e22c056c999a1a8f04d5c0e889db1580d255','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
